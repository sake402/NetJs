
(function ($global, $, $spc, $mwp, $sc, $sdt, $st, $scc, $sm, $spu, $sr, $sris, $stt, $ssc) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Security.Principal.Windows", 
    {"h":36222,"f":"System.Security.Principal.Windows","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B99807a3edea449997cda60d38046fed69821a2f6","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Security.Principal.Windows","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Security.Principal.Windows","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sspw.System.Security.Principal.IdentityReference", ($self) => class IdentityReference extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static /*bool */ op_Equality(/*System.Security.Principal.IdentityReference?*/ left, /*System.Security.Principal.IdentityReference?*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ op_Inequality(/*System.Security.Principal.IdentityReference?*/ left, /*System.Security.Principal.IdentityReference?*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 232830;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12885134718,"f":257},"n":"Value","d":232830,"h":8590167422,"f":257}],"m":[{"r":262145,"p":[{"n":"o","p":131073}],"n":"Equals","d":232830,"h":17180102014,"f":33025},{"r":655361,"n":"GetHashCode","d":232830,"h":21475069310,"f":33025},{"r":262145,"p":[{"n":"targetType","p":142606337}],"n":"IsValidTargetType","d":232830,"h":25770036606,"f":257},{"r":1310721,"n":"ToString","d":232830,"h":38654938494,"f":33025},{"r":232830,"p":[{"n":"targetType","p":142606337}],"n":"Translate","d":232830,"h":42949905790,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":232830,"h":4295200126,"f":8}],"h":232830}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Security.Principal.IdentityReference`; }
        });
        
        $asm.$cls("$sspw.System.Security.Principal.IdentityReferenceCollection", ($self) => class IdentityReferenceCollection extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*int*/ capacity)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get Count()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IdentityReference*/ get_Item(/*int*/ index)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void*/ set_Item(/*int*/ index, /*System.Security.Principal.IdentityReference*/ value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get System$Collections$Generic$ICollection$$$IsReadOnly()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Add(/*System.Security.Principal.IdentityReference*/ identity)
            {
            }
            /*void */ Clear()
            {
            }
            /*bool */ Contains(/*System.Security.Principal.IdentityReference*/ identity)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CopyTo(/*System.Security.Principal.IdentityReference[]*/ array, /*int*/ offset)
            {
            }
            /*System.Collections.Generic.IEnumerator<System.Security.Principal.IdentityReference> */ GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Remove(/*System.Security.Principal.IdentityReference*/ identity)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IdentityReferenceCollection */ Translate(/*System.Type*/ targetType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IdentityReferenceCollection */ Translate$1(/*System.Type*/ targetType, /*bool*/ forceSuccess)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Security.Principal.IdentityReference>.Count.get
            get System$Collections$Generic$ICollection$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Security.Principal.IdentityReference>.Add(System.Security.Principal.IdentityReference)
            System$Collections$Generic$ICollection$$$Add()
            {
                return this.Add(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Security.Principal.IdentityReference>.Clear()
            System$Collections$Generic$ICollection$$$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Security.Principal.IdentityReference>.Contains(System.Security.Principal.IdentityReference)
            System$Collections$Generic$ICollection$$$Contains()
            {
                return this.Contains(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Security.Principal.IdentityReference>.CopyTo(System.Security.Principal.IdentityReference[], int)
            System$Collections$Generic$ICollection$$$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Security.Principal.IdentityReference>.Remove(System.Security.Principal.IdentityReference)
            System$Collections$Generic$ICollection$$$Remove()
            {
                return this.Remove(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Security.Principal.IdentityReference>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 298366;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":17180167550,"f":1},"n":"Count","d":298366,"h":12885200254,"f":1},{"p":232830,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":25770102142,"f":1},"s":{"r":0,"d":0,"h":30065069438,"f":1},"n":"Item","o":"@$2","d":298366,"h":21475134846,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":38655004030,"f":2},"n":"{$.$spc.System.Collections.Generic.ICollection$$($.$sspw.System.Security.Principal.IdentityReference).$h}.IsReadOnly","o":"System$Collections$Generic$ICollection$$$IsReadOnly","d":298366,"h":34360036734,"f":2}],"m":[{"r":65537,"p":[{"n":"identity","p":232830}],"n":"Add","d":298366,"h":42949971326,"f":1},{"r":65537,"n":"Clear","d":298366,"h":47244938622,"f":1},{"r":262145,"p":[{"n":"identity","p":232830}],"n":"Contains","d":298366,"h":51539905918,"f":1},{"r":65537,"p":[{"n":"array","p":0},{"n":"offset","p":655361}],"n":"CopyTo","d":298366,"h":55834873214,"f":1},{"r":$.$spc.System.Collections.Generic.IEnumerator$$($.$sspw.System.Security.Principal.IdentityReference).$h,"n":"GetEnumerator","d":298366,"h":60129840510,"f":1},{"r":262145,"p":[{"n":"identity","p":232830}],"n":"Remove","d":298366,"h":64424807806,"f":1},{"r":298366,"p":[{"n":"targetType","p":142606337}],"n":"Translate","d":298366,"h":73014742398,"f":1},{"r":298366,"p":[{"n":"targetType","p":142606337},{"n":"forceSuccess","p":262145}],"n":"Translate","o":"@$1","d":298366,"h":77309709694,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":298366,"h":4295265662,"f":1},{"p":[{"n":"capacity","p":655361}],"n":".ctor","o":"$ctor$2","d":298366,"h":8590232958,"f":1}],"i":[$.$spc.System.Collections.Generic.ICollection$$($.$sspw.System.Security.Principal.IdentityReference).$h,$.$spc.System.Collections.Generic.IEnumerable$$($.$sspw.System.Security.Principal.IdentityReference).$h,31653889],"h":298366}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.ICollection$$($.$sspw.System.Security.Principal.IdentityReference), $.$spc.System.Collections.Generic.IEnumerable$$($.$sspw.System.Security.Principal.IdentityReference), $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Security.Principal.IdentityReferenceCollection`; }
        });
        
        $asm.$cls("$sspw.System.Security.Principal.NTAccount", ($self) => class NTAccount extends $.$sspw.System.Security.Principal.IdentityReference
        {
            $ctor$2(/*string*/ name)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$3(/*string*/ domainName, /*string*/ accountName)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*string */ get Value()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ o)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sspw.System.Security.Principal.NTAccount.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sspw.System.Security.Principal.NTAccount.GetHashCode.apply(this, arguments); }
            /*bool */ IsValidTargetType(/*System.Type*/ targetType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ op_Equality$1(/*System.Security.Principal.NTAccount?*/ left, /*System.Security.Principal.NTAccount?*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ op_Inequality$1(/*System.Security.Principal.NTAccount?*/ left, /*System.Security.Principal.NTAccount?*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sspw.System.Security.Principal.NTAccount.ToString.apply(this, arguments); }
            /*System.Security.Principal.IdentityReference */ Translate(/*System.Type*/ targetType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 363902;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":232830,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17180233086,"f":32769},"n":"Value","d":363902,"h":12885265790,"f":32769}],"m":[{"r":262145,"p":[{"n":"o","p":131073}],"n":"Equals","d":363902,"h":21475200382,"f":32769},{"r":655361,"n":"GetHashCode","d":363902,"h":25770167678,"f":32769},{"r":262145,"p":[{"n":"targetType","p":142606337}],"n":"IsValidTargetType","d":363902,"h":30065134974,"f":32769},{"r":1310721,"n":"ToString","d":363902,"h":42950036862,"f":32769},{"r":232830,"p":[{"n":"targetType","p":142606337}],"n":"Translate","d":363902,"h":47245004158,"f":32769}],"c":[{"p":[{"n":"name","p":1310721}],"n":".ctor","o":"$ctor$2","d":363902,"h":4295331198,"f":1},{"p":[{"n":"domainName","p":1310721},{"n":"accountName","p":1310721}],"n":".ctor","o":"$ctor$3","d":363902,"h":8590298494,"f":1}],"h":363902}; }
            static get $b() { return $.$sspw.System.Security.Principal.IdentityReference; }
            static get $fullName() { return `System.Security.Principal.NTAccount`; }
        });
        
        $asm.$cls("$sspw.System.Security.Principal.SecurityIdentifier", ($self) => class SecurityIdentifier extends $.$sspw.System.Security.Principal.IdentityReference
        {
            /*int*/ static MaxBinaryLength = 0;
            /*int*/ static MinBinaryLength = 0;
            $ctor$2(/*byte[]*/ binaryForm, /*int*/ offset)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$3(/*System.IntPtr*/ binaryForm)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$4(/*System.Security.Principal.WellKnownSidType*/ sidType, /*System.Security.Principal.SecurityIdentifier?*/ domainSid)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$5(/*string*/ sddlForm)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Security.Principal.SecurityIdentifier? */ get AccountDomainSid()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get BinaryLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Value()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ CompareTo(/*System.Security.Principal.SecurityIdentifier?*/ sid)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ o)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sspw.System.Security.Principal.SecurityIdentifier.Equals.apply(this, arguments); }
            /*bool */ Equals$2(/*System.Security.Principal.SecurityIdentifier*/ sid)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sspw.System.Security.Principal.SecurityIdentifier.GetHashCode.apply(this, arguments); }
            /*bool */ IsAccountSid()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ IsEqualDomainSid(/*System.Security.Principal.SecurityIdentifier*/ sid)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ IsValidTargetType(/*System.Type*/ targetType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ IsWellKnown(/*System.Security.Principal.WellKnownSidType*/ type)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ op_Equality$1(/*System.Security.Principal.SecurityIdentifier?*/ left, /*System.Security.Principal.SecurityIdentifier?*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ op_Inequality$1(/*System.Security.Principal.SecurityIdentifier?*/ left, /*System.Security.Principal.SecurityIdentifier?*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sspw.System.Security.Principal.SecurityIdentifier.ToString.apply(this, arguments); }
            /*System.Security.Principal.IdentityReference */ Translate(/*System.Type*/ targetType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.IComparable<System.Security.Principal.SecurityIdentifier>.CompareTo(System.Security.Principal.SecurityIdentifier?)
            System$IComparable$$$CompareTo()
            {
                return this.CompareTo(...arguments);
            }
            static $h = 429438;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":232830,"p":[{"p":429438,"g":{"r":0,"d":0,"h":34360167806,"f":1},"n":"AccountDomainSid","d":429438,"h":30065200510,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":42950102398,"f":1},"n":"BinaryLength","d":429438,"h":38655135102,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":51540036990,"f":32769},"n":"Value","d":429438,"h":47245069694,"f":32769}],"m":[{"r":655361,"p":[{"n":"sid","p":429438}],"n":"CompareTo","d":429438,"h":55835004286,"f":1},{"r":262145,"p":[{"n":"o","p":131073}],"n":"Equals","d":429438,"h":60129971582,"f":32769},{"r":262145,"p":[{"n":"sid","p":429438}],"n":"Equals","o":"@$2","d":429438,"h":64424938878,"f":1},{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":429438,"h":68719906174,"f":1},{"r":655361,"n":"GetHashCode","d":429438,"h":73014873470,"f":32769},{"r":262145,"n":"IsAccountSid","d":429438,"h":77309840766,"f":1},{"r":262145,"p":[{"n":"sid","p":429438}],"n":"IsEqualDomainSid","d":429438,"h":81604808062,"f":1},{"r":262145,"p":[{"n":"targetType","p":142606337}],"n":"IsValidTargetType","d":429438,"h":85899775358,"f":32769},{"r":262145,"p":[{"n":"type","p":560510}],"n":"IsWellKnown","d":429438,"h":90194742654,"f":1},{"r":1310721,"n":"ToString","d":429438,"h":103079644542,"f":32769},{"r":232830,"p":[{"n":"targetType","p":142606337}],"n":"Translate","d":429438,"h":107374611838,"f":32769}],"l":[{"t":655361,"n":"MaxBinaryLength","d":429438,"h":4295396734,"f":33},{"t":655361,"n":"MinBinaryLength","d":429438,"h":8590364030,"f":33}],"c":[{"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":".ctor","o":"$ctor$2","d":429438,"h":12885331326,"f":1},{"p":[{"n":"binaryForm","p":786433}],"n":".ctor","o":"$ctor$3","d":429438,"h":17180298622,"f":1},{"p":[{"n":"sidType","p":560510},{"n":"domainSid","p":429438}],"n":".ctor","o":"$ctor$4","d":429438,"h":21475265918,"f":1},{"p":[{"n":"sddlForm","p":1310721}],"n":".ctor","o":"$ctor$5","d":429438,"h":25770233214,"f":1}],"i":[$.$spc.System.IComparable$$($.$sspw.System.Security.Principal.SecurityIdentifier).$h],"h":429438}; }
            static get $b() { return $.$sspw.System.Security.Principal.IdentityReference; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable$$($.$sspw.System.Security.Principal.SecurityIdentifier) ]; }
            static get $fullName() { return `System.Security.Principal.SecurityIdentifier`; }
        });
        
        $asm.$cls("$sspw.Microsoft.Win32.SafeHandles.SafeAccessTokenHandle", ($self) => class SafeAccessTokenHandle extends $.$spc.System.Runtime.InteropServices.SafeHandle
        {
            $ctor$3()
            {
                super.$ctor$2(0, false);
                {
                }
                return this;
            }
            $ctor$4(/*System.IntPtr*/ handle)
            {
                super.$ctor$2(0, false);
                {
                }
                return this;
            }
            static /*Microsoft.Win32.SafeHandles.SafeAccessTokenHandle */ get InvalidHandle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsInvalid()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ReleaseHandle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 101758;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":109576193,"p":[{"p":101758,"g":{"r":0,"d":0,"h":17179970942,"f":33},"n":"InvalidHandle","d":101758,"h":12885003646,"f":33},{"p":262145,"g":{"r":0,"d":0,"h":25769905534,"f":32769},"n":"IsInvalid","d":101758,"h":21474938238,"f":32769}],"m":[{"r":262145,"n":"ReleaseHandle","d":101758,"h":30064872830,"f":32772}],"c":[{"n":".ctor","o":"$ctor$3","d":101758,"h":4295069054,"f":1},{"p":[{"n":"handle","p":786433}],"n":".ctor","o":"$ctor$4","d":101758,"h":8590036350,"f":1}],"i":[57540609],"h":101758}; }
            static get $b() { return $.$spc.System.Runtime.InteropServices.SafeHandle; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Win32.SafeHandles.SafeAccessTokenHandle`; }
        });
        
        $asm.$str("$sspw.System.Security.Principal.TokenAccessLevels", ($self) => class TokenAccessLevels extends $.$spc.System.Enum
        {
            static AssignPrimary = 1;
            static Duplicate = 2;
            static Impersonate = 4;
            static Query = 8;
            static QuerySource = 16;
            static AdjustPrivileges = 32;
            static AdjustGroups = 64;
            static AdjustDefault = 128;
            static AdjustSessionId = 256;
            static Read = 131080;
            static Write = 131296;
            static AllAccess = 983551;
            static MaximumAllowed = 33554432;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "AssignPrimary": 1n,
                    "Duplicate": 2n,
                    "Impersonate": 4n,
                    "Query": 8n,
                    "QuerySource": 16n,
                    "AdjustPrivileges": 32n,
                    "AdjustGroups": 64n,
                    "AdjustDefault": 128n,
                    "AdjustSessionId": 256n,
                    "Read": 131080n,
                    "Write": 131296n,
                    "AllAccess": 983551n,
                    "MaximumAllowed": 33554432n
                };
            }
            static $h = 494974;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":494974,"n":"AssignPrimary","d":494974,"h":4295462270,"f":33},{"t":494974,"n":"Duplicate","d":494974,"h":8590429566,"f":33},{"t":494974,"n":"Impersonate","d":494974,"h":12885396862,"f":33},{"t":494974,"n":"Query","d":494974,"h":17180364158,"f":33},{"t":494974,"n":"QuerySource","d":494974,"h":21475331454,"f":33},{"t":494974,"n":"AdjustPrivileges","d":494974,"h":25770298750,"f":33},{"t":494974,"n":"AdjustGroups","d":494974,"h":30065266046,"f":33},{"t":494974,"n":"AdjustDefault","d":494974,"h":34360233342,"f":33},{"t":494974,"n":"AdjustSessionId","d":494974,"h":38655200638,"f":33},{"t":494974,"n":"Read","d":494974,"h":42950167934,"f":33},{"t":494974,"n":"Write","d":494974,"h":47245135230,"f":33},{"t":494974,"n":"AllAccess","d":494974,"h":51540102526,"f":33},{"t":494974,"n":"MaximumAllowed","d":494974,"h":55835069822,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":494974,"h":60130037118,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":494974,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.Principal.TokenAccessLevels`; }
        });
        
        $asm.$str("$sspw.System.Security.Principal.WellKnownSidType", ($self) => class WellKnownSidType extends $.$spc.System.Enum
        {
            static NullSid = 0;
            static WorldSid = 1;
            static LocalSid = 2;
            static CreatorOwnerSid = 3;
            static CreatorGroupSid = 4;
            static CreatorOwnerServerSid = 5;
            static CreatorGroupServerSid = 6;
            static NTAuthoritySid = 7;
            static DialupSid = 8;
            static NetworkSid = 9;
            static BatchSid = 10;
            static InteractiveSid = 11;
            static ServiceSid = 12;
            static AnonymousSid = 13;
            static ProxySid = 14;
            static EnterpriseControllersSid = 15;
            static SelfSid = 16;
            static AuthenticatedUserSid = 17;
            static RestrictedCodeSid = 18;
            static TerminalServerSid = 19;
            static RemoteLogonIdSid = 20;
            static LogonIdsSid = 21;
            static LocalSystemSid = 22;
            static LocalServiceSid = 23;
            static NetworkServiceSid = 24;
            static BuiltinDomainSid = 25;
            static BuiltinAdministratorsSid = 26;
            static BuiltinUsersSid = 27;
            static BuiltinGuestsSid = 28;
            static BuiltinPowerUsersSid = 29;
            static BuiltinAccountOperatorsSid = 30;
            static BuiltinSystemOperatorsSid = 31;
            static BuiltinPrintOperatorsSid = 32;
            static BuiltinBackupOperatorsSid = 33;
            static BuiltinReplicatorSid = 34;
            static BuiltinPreWindows2000CompatibleAccessSid = 35;
            static BuiltinRemoteDesktopUsersSid = 36;
            static BuiltinNetworkConfigurationOperatorsSid = 37;
            static AccountAdministratorSid = 38;
            static AccountGuestSid = 39;
            static AccountKrbtgtSid = 40;
            static AccountDomainAdminsSid = 41;
            static AccountDomainUsersSid = 42;
            static AccountDomainGuestsSid = 43;
            static AccountComputersSid = 44;
            static AccountControllersSid = 45;
            static AccountCertAdminsSid = 46;
            static AccountSchemaAdminsSid = 47;
            static AccountEnterpriseAdminsSid = 48;
            static AccountPolicyAdminsSid = 49;
            static AccountRasAndIasServersSid = 50;
            static NtlmAuthenticationSid = 51;
            static DigestAuthenticationSid = 52;
            static SChannelAuthenticationSid = 53;
            static ThisOrganizationSid = 54;
            static OtherOrganizationSid = 55;
            static BuiltinIncomingForestTrustBuildersSid = 56;
            static BuiltinPerformanceMonitoringUsersSid = 57;
            static BuiltinPerformanceLoggingUsersSid = 58;
            static BuiltinAuthorizationAccessSid = 59;
            static MaxDefined = 60;
            static WinBuiltinTerminalServerLicenseServersSid = 60;
            static WinBuiltinDCOMUsersSid = 61;
            static WinBuiltinIUsersSid = 62;
            static WinIUserSid = 63;
            static WinBuiltinCryptoOperatorsSid = 64;
            static WinUntrustedLabelSid = 65;
            static WinLowLabelSid = 66;
            static WinMediumLabelSid = 67;
            static WinHighLabelSid = 68;
            static WinSystemLabelSid = 69;
            static WinWriteRestrictedCodeSid = 70;
            static WinCreatorOwnerRightsSid = 71;
            static WinCacheablePrincipalsGroupSid = 72;
            static WinNonCacheablePrincipalsGroupSid = 73;
            static WinEnterpriseReadonlyControllersSid = 74;
            static WinAccountReadonlyControllersSid = 75;
            static WinBuiltinEventLogReadersGroup = 76;
            static WinNewEnterpriseReadonlyControllersSid = 77;
            static WinBuiltinCertSvcDComAccessGroup = 78;
            static WinMediumPlusLabelSid = 79;
            static WinLocalLogonSid = 80;
            static WinConsoleLogonSid = 81;
            static WinThisOrganizationCertificateSid = 82;
            static WinApplicationPackageAuthoritySid = 83;
            static WinBuiltinAnyPackageSid = 84;
            static WinCapabilityInternetClientSid = 85;
            static WinCapabilityInternetClientServerSid = 86;
            static WinCapabilityPrivateNetworkClientServerSid = 87;
            static WinCapabilityPicturesLibrarySid = 88;
            static WinCapabilityVideosLibrarySid = 89;
            static WinCapabilityMusicLibrarySid = 90;
            static WinCapabilityDocumentsLibrarySid = 91;
            static WinCapabilitySharedUserCertificatesSid = 92;
            static WinCapabilityEnterpriseAuthenticationSid = 93;
            static WinCapabilityRemovableStorageSid = 94;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "NullSid": 0n,
                    "WorldSid": 1n,
                    "LocalSid": 2n,
                    "CreatorOwnerSid": 3n,
                    "CreatorGroupSid": 4n,
                    "CreatorOwnerServerSid": 5n,
                    "CreatorGroupServerSid": 6n,
                    "NTAuthoritySid": 7n,
                    "DialupSid": 8n,
                    "NetworkSid": 9n,
                    "BatchSid": 10n,
                    "InteractiveSid": 11n,
                    "ServiceSid": 12n,
                    "AnonymousSid": 13n,
                    "ProxySid": 14n,
                    "EnterpriseControllersSid": 15n,
                    "SelfSid": 16n,
                    "AuthenticatedUserSid": 17n,
                    "RestrictedCodeSid": 18n,
                    "TerminalServerSid": 19n,
                    "RemoteLogonIdSid": 20n,
                    "LogonIdsSid": 21n,
                    "LocalSystemSid": 22n,
                    "LocalServiceSid": 23n,
                    "NetworkServiceSid": 24n,
                    "BuiltinDomainSid": 25n,
                    "BuiltinAdministratorsSid": 26n,
                    "BuiltinUsersSid": 27n,
                    "BuiltinGuestsSid": 28n,
                    "BuiltinPowerUsersSid": 29n,
                    "BuiltinAccountOperatorsSid": 30n,
                    "BuiltinSystemOperatorsSid": 31n,
                    "BuiltinPrintOperatorsSid": 32n,
                    "BuiltinBackupOperatorsSid": 33n,
                    "BuiltinReplicatorSid": 34n,
                    "BuiltinPreWindows2000CompatibleAccessSid": 35n,
                    "BuiltinRemoteDesktopUsersSid": 36n,
                    "BuiltinNetworkConfigurationOperatorsSid": 37n,
                    "AccountAdministratorSid": 38n,
                    "AccountGuestSid": 39n,
                    "AccountKrbtgtSid": 40n,
                    "AccountDomainAdminsSid": 41n,
                    "AccountDomainUsersSid": 42n,
                    "AccountDomainGuestsSid": 43n,
                    "AccountComputersSid": 44n,
                    "AccountControllersSid": 45n,
                    "AccountCertAdminsSid": 46n,
                    "AccountSchemaAdminsSid": 47n,
                    "AccountEnterpriseAdminsSid": 48n,
                    "AccountPolicyAdminsSid": 49n,
                    "AccountRasAndIasServersSid": 50n,
                    "NtlmAuthenticationSid": 51n,
                    "DigestAuthenticationSid": 52n,
                    "SChannelAuthenticationSid": 53n,
                    "ThisOrganizationSid": 54n,
                    "OtherOrganizationSid": 55n,
                    "BuiltinIncomingForestTrustBuildersSid": 56n,
                    "BuiltinPerformanceMonitoringUsersSid": 57n,
                    "BuiltinPerformanceLoggingUsersSid": 58n,
                    "BuiltinAuthorizationAccessSid": 59n,
                    "MaxDefined": 60n,
                    "WinBuiltinTerminalServerLicenseServersSid": 60n,
                    "WinBuiltinDCOMUsersSid": 61n,
                    "WinBuiltinIUsersSid": 62n,
                    "WinIUserSid": 63n,
                    "WinBuiltinCryptoOperatorsSid": 64n,
                    "WinUntrustedLabelSid": 65n,
                    "WinLowLabelSid": 66n,
                    "WinMediumLabelSid": 67n,
                    "WinHighLabelSid": 68n,
                    "WinSystemLabelSid": 69n,
                    "WinWriteRestrictedCodeSid": 70n,
                    "WinCreatorOwnerRightsSid": 71n,
                    "WinCacheablePrincipalsGroupSid": 72n,
                    "WinNonCacheablePrincipalsGroupSid": 73n,
                    "WinEnterpriseReadonlyControllersSid": 74n,
                    "WinAccountReadonlyControllersSid": 75n,
                    "WinBuiltinEventLogReadersGroup": 76n,
                    "WinNewEnterpriseReadonlyControllersSid": 77n,
                    "WinBuiltinCertSvcDComAccessGroup": 78n,
                    "WinMediumPlusLabelSid": 79n,
                    "WinLocalLogonSid": 80n,
                    "WinConsoleLogonSid": 81n,
                    "WinThisOrganizationCertificateSid": 82n,
                    "WinApplicationPackageAuthoritySid": 83n,
                    "WinBuiltinAnyPackageSid": 84n,
                    "WinCapabilityInternetClientSid": 85n,
                    "WinCapabilityInternetClientServerSid": 86n,
                    "WinCapabilityPrivateNetworkClientServerSid": 87n,
                    "WinCapabilityPicturesLibrarySid": 88n,
                    "WinCapabilityVideosLibrarySid": 89n,
                    "WinCapabilityMusicLibrarySid": 90n,
                    "WinCapabilityDocumentsLibrarySid": 91n,
                    "WinCapabilitySharedUserCertificatesSid": 92n,
                    "WinCapabilityEnterpriseAuthenticationSid": 93n,
                    "WinCapabilityRemovableStorageSid": 94n
                };
            }
            static $h = 560510;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":560510,"n":"NullSid","d":560510,"h":4295527806,"f":33},{"t":560510,"n":"WorldSid","d":560510,"h":8590495102,"f":33},{"t":560510,"n":"LocalSid","d":560510,"h":12885462398,"f":33},{"t":560510,"n":"CreatorOwnerSid","d":560510,"h":17180429694,"f":33},{"t":560510,"n":"CreatorGroupSid","d":560510,"h":21475396990,"f":33},{"t":560510,"n":"CreatorOwnerServerSid","d":560510,"h":25770364286,"f":33},{"t":560510,"n":"CreatorGroupServerSid","d":560510,"h":30065331582,"f":33},{"t":560510,"n":"NTAuthoritySid","d":560510,"h":34360298878,"f":33},{"t":560510,"n":"DialupSid","d":560510,"h":38655266174,"f":33},{"t":560510,"n":"NetworkSid","d":560510,"h":42950233470,"f":33},{"t":560510,"n":"BatchSid","d":560510,"h":47245200766,"f":33},{"t":560510,"n":"InteractiveSid","d":560510,"h":51540168062,"f":33},{"t":560510,"n":"ServiceSid","d":560510,"h":55835135358,"f":33},{"t":560510,"n":"AnonymousSid","d":560510,"h":60130102654,"f":33},{"t":560510,"n":"ProxySid","d":560510,"h":64425069950,"f":33},{"t":560510,"n":"EnterpriseControllersSid","d":560510,"h":68720037246,"f":33},{"t":560510,"n":"SelfSid","d":560510,"h":73015004542,"f":33},{"t":560510,"n":"AuthenticatedUserSid","d":560510,"h":77309971838,"f":33},{"t":560510,"n":"RestrictedCodeSid","d":560510,"h":81604939134,"f":33},{"t":560510,"n":"TerminalServerSid","d":560510,"h":85899906430,"f":33},{"t":560510,"n":"RemoteLogonIdSid","d":560510,"h":90194873726,"f":33},{"t":560510,"n":"LogonIdsSid","d":560510,"h":94489841022,"f":33},{"t":560510,"n":"LocalSystemSid","d":560510,"h":98784808318,"f":33},{"t":560510,"n":"LocalServiceSid","d":560510,"h":103079775614,"f":33},{"t":560510,"n":"NetworkServiceSid","d":560510,"h":107374742910,"f":33},{"t":560510,"n":"BuiltinDomainSid","d":560510,"h":111669710206,"f":33},{"t":560510,"n":"BuiltinAdministratorsSid","d":560510,"h":115964677502,"f":33},{"t":560510,"n":"BuiltinUsersSid","d":560510,"h":120259644798,"f":33},{"t":560510,"n":"BuiltinGuestsSid","d":560510,"h":124554612094,"f":33},{"t":560510,"n":"BuiltinPowerUsersSid","d":560510,"h":128849579390,"f":33},{"t":560510,"n":"BuiltinAccountOperatorsSid","d":560510,"h":133144546686,"f":33},{"t":560510,"n":"BuiltinSystemOperatorsSid","d":560510,"h":137439513982,"f":33},{"t":560510,"n":"BuiltinPrintOperatorsSid","d":560510,"h":141734481278,"f":33},{"t":560510,"n":"BuiltinBackupOperatorsSid","d":560510,"h":146029448574,"f":33},{"t":560510,"n":"BuiltinReplicatorSid","d":560510,"h":150324415870,"f":33},{"t":560510,"n":"BuiltinPreWindows2000CompatibleAccessSid","d":560510,"h":154619383166,"f":33},{"t":560510,"n":"BuiltinRemoteDesktopUsersSid","d":560510,"h":158914350462,"f":33},{"t":560510,"n":"BuiltinNetworkConfigurationOperatorsSid","d":560510,"h":163209317758,"f":33},{"t":560510,"n":"AccountAdministratorSid","d":560510,"h":167504285054,"f":33},{"t":560510,"n":"AccountGuestSid","d":560510,"h":171799252350,"f":33},{"t":560510,"n":"AccountKrbtgtSid","d":560510,"h":176094219646,"f":33},{"t":560510,"n":"AccountDomainAdminsSid","d":560510,"h":180389186942,"f":33},{"t":560510,"n":"AccountDomainUsersSid","d":560510,"h":184684154238,"f":33},{"t":560510,"n":"AccountDomainGuestsSid","d":560510,"h":188979121534,"f":33},{"t":560510,"n":"AccountComputersSid","d":560510,"h":193274088830,"f":33},{"t":560510,"n":"AccountControllersSid","d":560510,"h":197569056126,"f":33},{"t":560510,"n":"AccountCertAdminsSid","d":560510,"h":201864023422,"f":33},{"t":560510,"n":"AccountSchemaAdminsSid","d":560510,"h":206158990718,"f":33},{"t":560510,"n":"AccountEnterpriseAdminsSid","d":560510,"h":210453958014,"f":33},{"t":560510,"n":"AccountPolicyAdminsSid","d":560510,"h":214748925310,"f":33},{"t":560510,"n":"AccountRasAndIasServersSid","d":560510,"h":219043892606,"f":33},{"t":560510,"n":"NtlmAuthenticationSid","d":560510,"h":223338859902,"f":33},{"t":560510,"n":"DigestAuthenticationSid","d":560510,"h":227633827198,"f":33},{"t":560510,"n":"SChannelAuthenticationSid","d":560510,"h":231928794494,"f":33},{"t":560510,"n":"ThisOrganizationSid","d":560510,"h":236223761790,"f":33},{"t":560510,"n":"OtherOrganizationSid","d":560510,"h":240518729086,"f":33},{"t":560510,"n":"BuiltinIncomingForestTrustBuildersSid","d":560510,"h":244813696382,"f":33},{"t":560510,"n":"BuiltinPerformanceMonitoringUsersSid","d":560510,"h":249108663678,"f":33},{"t":560510,"n":"BuiltinPerformanceLoggingUsersSid","d":560510,"h":253403630974,"f":33},{"t":560510,"n":"BuiltinAuthorizationAccessSid","d":560510,"h":257698598270,"f":33},{"t":560510,"n":"MaxDefined","d":560510,"h":261993565566,"f":33,"a":[{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]},{"t":70909953,"c":8660844545,"a":[{"v":"This member has been deprecated and is only maintained for backwards compatability. WellKnownSidType values greater than MaxDefined may be defined in future releases.","t":1310721}]}]},{"t":560510,"n":"WinBuiltinTerminalServerLicenseServersSid","d":560510,"h":266288532862,"f":33},{"t":560510,"n":"WinBuiltinDCOMUsersSid","d":560510,"h":270583500158,"f":33},{"t":560510,"n":"WinBuiltinIUsersSid","d":560510,"h":274878467454,"f":33},{"t":560510,"n":"WinIUserSid","d":560510,"h":279173434750,"f":33},{"t":560510,"n":"WinBuiltinCryptoOperatorsSid","d":560510,"h":283468402046,"f":33},{"t":560510,"n":"WinUntrustedLabelSid","d":560510,"h":287763369342,"f":33},{"t":560510,"n":"WinLowLabelSid","d":560510,"h":292058336638,"f":33},{"t":560510,"n":"WinMediumLabelSid","d":560510,"h":296353303934,"f":33},{"t":560510,"n":"WinHighLabelSid","d":560510,"h":300648271230,"f":33},{"t":560510,"n":"WinSystemLabelSid","d":560510,"h":304943238526,"f":33},{"t":560510,"n":"WinWriteRestrictedCodeSid","d":560510,"h":309238205822,"f":33},{"t":560510,"n":"WinCreatorOwnerRightsSid","d":560510,"h":313533173118,"f":33},{"t":560510,"n":"WinCacheablePrincipalsGroupSid","d":560510,"h":317828140414,"f":33},{"t":560510,"n":"WinNonCacheablePrincipalsGroupSid","d":560510,"h":322123107710,"f":33},{"t":560510,"n":"WinEnterpriseReadonlyControllersSid","d":560510,"h":326418075006,"f":33},{"t":560510,"n":"WinAccountReadonlyControllersSid","d":560510,"h":330713042302,"f":33},{"t":560510,"n":"WinBuiltinEventLogReadersGroup","d":560510,"h":335008009598,"f":33},{"t":560510,"n":"WinNewEnterpriseReadonlyControllersSid","d":560510,"h":339302976894,"f":33},{"t":560510,"n":"WinBuiltinCertSvcDComAccessGroup","d":560510,"h":343597944190,"f":33},{"t":560510,"n":"WinMediumPlusLabelSid","d":560510,"h":347892911486,"f":33},{"t":560510,"n":"WinLocalLogonSid","d":560510,"h":352187878782,"f":33},{"t":560510,"n":"WinConsoleLogonSid","d":560510,"h":356482846078,"f":33},{"t":560510,"n":"WinThisOrganizationCertificateSid","d":560510,"h":360777813374,"f":33},{"t":560510,"n":"WinApplicationPackageAuthoritySid","d":560510,"h":365072780670,"f":33},{"t":560510,"n":"WinBuiltinAnyPackageSid","d":560510,"h":369367747966,"f":33},{"t":560510,"n":"WinCapabilityInternetClientSid","d":560510,"h":373662715262,"f":33},{"t":560510,"n":"WinCapabilityInternetClientServerSid","d":560510,"h":377957682558,"f":33},{"t":560510,"n":"WinCapabilityPrivateNetworkClientServerSid","d":560510,"h":382252649854,"f":33},{"t":560510,"n":"WinCapabilityPicturesLibrarySid","d":560510,"h":386547617150,"f":33},{"t":560510,"n":"WinCapabilityVideosLibrarySid","d":560510,"h":390842584446,"f":33},{"t":560510,"n":"WinCapabilityMusicLibrarySid","d":560510,"h":395137551742,"f":33},{"t":560510,"n":"WinCapabilityDocumentsLibrarySid","d":560510,"h":399432519038,"f":33},{"t":560510,"n":"WinCapabilitySharedUserCertificatesSid","d":560510,"h":403727486334,"f":33},{"t":560510,"n":"WinCapabilityEnterpriseAuthenticationSid","d":560510,"h":408022453630,"f":33},{"t":560510,"n":"WinCapabilityRemovableStorageSid","d":560510,"h":412317420926,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":560510,"h":416612388222,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":560510}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.Principal.WellKnownSidType`; }
        });
        
        $asm.$str("$sspw.System.Security.Principal.WindowsAccountType", ($self) => class WindowsAccountType extends $.$spc.System.Enum
        {
            static Normal = 0;
            static Guest = 1;
            static System = 2;
            static Anonymous = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Normal": 0n,
                    "Guest": 1n,
                    "System": 2n,
                    "Anonymous": 3n
                };
            }
            static $h = 626046;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":626046,"n":"Normal","d":626046,"h":4295593342,"f":33},{"t":626046,"n":"Guest","d":626046,"h":8590560638,"f":33},{"t":626046,"n":"System","d":626046,"h":12885527934,"f":33},{"t":626046,"n":"Anonymous","d":626046,"h":17180495230,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":626046,"h":21475462526,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":626046}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.Principal.WindowsAccountType`; }
        });
        
        $asm.$str("$sspw.System.Security.Principal.WindowsBuiltInRole", ($self) => class WindowsBuiltInRole extends $.$spc.System.Enum
        {
            static Administrator = 544;
            static User = 545;
            static Guest = 546;
            static PowerUser = 547;
            static AccountOperator = 548;
            static SystemOperator = 549;
            static PrintOperator = 550;
            static BackupOperator = 551;
            static Replicator = 552;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Administrator": 544n,
                    "User": 545n,
                    "Guest": 546n,
                    "PowerUser": 547n,
                    "AccountOperator": 548n,
                    "SystemOperator": 549n,
                    "PrintOperator": 550n,
                    "BackupOperator": 551n,
                    "Replicator": 552n
                };
            }
            static $h = 691582;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":691582,"n":"Administrator","d":691582,"h":4295658878,"f":33},{"t":691582,"n":"User","d":691582,"h":8590626174,"f":33},{"t":691582,"n":"Guest","d":691582,"h":12885593470,"f":33},{"t":691582,"n":"PowerUser","d":691582,"h":17180560766,"f":33},{"t":691582,"n":"AccountOperator","d":691582,"h":21475528062,"f":33},{"t":691582,"n":"SystemOperator","d":691582,"h":25770495358,"f":33},{"t":691582,"n":"PrintOperator","d":691582,"h":30065462654,"f":33},{"t":691582,"n":"BackupOperator","d":691582,"h":34360429950,"f":33},{"t":691582,"n":"Replicator","d":691582,"h":38655397246,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":691582,"h":42950364542,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":691582}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.Principal.WindowsBuiltInRole`; }
        });
        
        $asm.$cls("$sspw.System.Security.Principal.WindowsPrincipal", ($self) => class WindowsPrincipal extends $.$ssc.System.Security.Claims.ClaimsPrincipal
        {
            $ctor$7(/*System.Security.Principal.WindowsIdentity*/ ntIdentity)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*System.Collections.Generic.IEnumerable<System.Security.Claims.Claim> */ get DeviceClaims()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IIdentity */ get Identity()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.IEnumerable<System.Security.Claims.Claim> */ get UserClaims()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ IsInRole$1(/*int*/ rid)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ IsInRole$2(/*System.Security.Principal.SecurityIdentifier*/ sid)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ IsInRole$3(/*System.Security.Principal.WindowsBuiltInRole*/ role)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ IsInRole(/*string*/ role)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 822654;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":425999,"p":[{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"g":{"r":0,"d":0,"h":12885724542,"f":129},"n":"DeviceClaims","d":822654,"h":8590757246,"f":129},{"p":117047297,"g":{"r":0,"d":0,"h":21475659134,"f":32769},"n":"Identity","d":822654,"h":17180691838,"f":32769},{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"g":{"r":0,"d":0,"h":30065593726,"f":129},"n":"UserClaims","d":822654,"h":25770626430,"f":129}],"m":[{"r":262145,"p":[{"n":"rid","p":655361}],"n":"IsInRole","o":"@$1","d":822654,"h":34360561022,"f":129},{"r":262145,"p":[{"n":"sid","p":429438}],"n":"IsInRole","o":"@$2","d":822654,"h":38655528318,"f":129},{"r":262145,"p":[{"n":"role","p":691582}],"n":"IsInRole","o":"@$3","d":822654,"h":42950495614,"f":129},{"r":262145,"p":[{"n":"role","p":1310721}],"n":"IsInRole","d":822654,"h":47245462910,"f":32769}],"c":[{"p":[{"n":"ntIdentity","p":757118}],"n":".ctor","o":"$ctor$7","d":822654,"h":4295789950,"f":1}],"i":[117112833],"h":822654}; }
            static get $b() { return $.$ssc.System.Security.Claims.ClaimsPrincipal; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Security.Principal.IPrincipal ]; }
            static get $fullName() { return `System.Security.Principal.WindowsPrincipal`; }
        });
        
        $asm.$cls("$sspw.System.Security.Principal.WindowsIdentity", ($self) => class WindowsIdentity extends $.$ssc.System.Security.Claims.ClaimsIdentity
        {
            /*string*/ static DefaultIssuer = null;
            $ctor$17(/*System.IntPtr*/ userToken)
            {
                super.$ctor$14(null, null, null, null, null, 5);
                {
                }
                return this;
            }
            $ctor$18(/*System.IntPtr*/ userToken, /*string*/ type)
            {
                super.$ctor$14(null, null, null, null, null, 5);
                {
                }
                return this;
            }
            $ctor$19(/*System.IntPtr*/ userToken, /*string*/ type, /*System.Security.Principal.WindowsAccountType*/ acctType)
            {
                super.$ctor$14(null, null, null, null, null, 5);
                {
                }
                return this;
            }
            $ctor$20(/*System.IntPtr*/ userToken, /*string*/ type, /*System.Security.Principal.WindowsAccountType*/ acctType, /*bool*/ isAuthenticated)
            {
                super.$ctor$14(null, null, null, null, null, 5);
                {
                }
                return this;
            }
            $ctor$21(/*System.Runtime.Serialization.SerializationInfo*/ info, /*System.Runtime.Serialization.StreamingContext*/ context)
            {
                super.$ctor$14(null, null, null, null, null, 5);
                {
                }
                return this;
            }
            $ctor$22(/*System.Security.Principal.WindowsIdentity*/ identity)
            {
                super.$ctor$14(null, null, null, null, null, 5);
                {
                }
                return this;
            }
            $ctor$23(/*string*/ sUserPrincipalName)
            {
                super.$ctor$14(null, null, null, null, null, 5);
                {
                }
                return this;
            }
            /*Microsoft.Win32.SafeHandles.SafeAccessTokenHandle */ get AccessToken()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get AuthenticationType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.IEnumerable<System.Security.Claims.Claim> */ get Claims()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.IEnumerable<System.Security.Claims.Claim> */ get DeviceClaims()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IdentityReferenceCollection? */ get Groups()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.TokenImpersonationLevel */ get ImpersonationLevel()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsAnonymous()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsAuthenticated()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsGuest()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsSystem()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Name()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ get Owner()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ get Token()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ get User()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.IEnumerable<System.Security.Claims.Claim> */ get UserClaims()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Claims.ClaimsIdentity */ Clone()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose()
            {
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            static /*System.Security.Principal.WindowsIdentity */ GetAnonymous()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Security.Principal.WindowsIdentity */ GetCurrent()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Security.Principal.WindowsIdentity? */ GetCurrent$1(/*bool*/ ifImpersonating)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Security.Principal.WindowsIdentity */ GetCurrent$2(/*System.Security.Principal.TokenAccessLevels*/ desiredAccess)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*void */ RunImpersonated(/*Microsoft.Win32.SafeHandles.SafeAccessTokenHandle*/ safeAccessTokenHandle, /*System.Action*/ action)
            {
            }
            static /*System.Threading.Tasks.Task */ RunImpersonatedAsync(/*Microsoft.Win32.SafeHandles.SafeAccessTokenHandle*/ safeAccessTokenHandle, /*System.Func<System.Threading.Tasks.Task>*/ func)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<T> */ RunImpersonatedAsync$1(T, /*Microsoft.Win32.SafeHandles.SafeAccessTokenHandle*/ safeAccessTokenHandle, /*System.Func<System.Threading.Tasks.Task<T>>*/ func)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*T */ RunImpersonated$1(T, /*Microsoft.Win32.SafeHandles.SafeAccessTokenHandle*/ safeAccessTokenHandle, /*System.Func<T>*/ func)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ System$Runtime$Serialization$IDeserializationCallback$OnDeserialization(/*object?*/ sender)
            {
            }
            /*void */ System$Runtime$Serialization$ISerializable$GetObjectData(/*System.Runtime.Serialization.SerializationInfo*/ info, /*System.Runtime.Serialization.StreamingContext*/ context)
            {
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.DefaultIssuer = "AD AUTHORITY";
                }
            }
            static $h = 757118;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":294927,"p":[{"p":101758,"g":{"r":0,"d":0,"h":42950430078,"f":1},"n":"AccessToken","d":757118,"h":38655462782,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":51540364670,"f":98305},"n":"AuthenticationType","d":757118,"h":47245397374,"f":98305},{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"g":{"r":0,"d":0,"h":60130299262,"f":32769},"n":"Claims","d":757118,"h":55835331966,"f":32769},{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"g":{"r":0,"d":0,"h":68720233854,"f":129},"n":"DeviceClaims","d":757118,"h":64425266558,"f":129},{"p":298366,"g":{"r":0,"d":0,"h":77310168446,"f":1},"n":"Groups","d":757118,"h":73015201150,"f":1},{"p":117243905,"g":{"r":0,"d":0,"h":85900103038,"f":1},"n":"ImpersonationLevel","d":757118,"h":81605135742,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":94490037630,"f":129},"n":"IsAnonymous","d":757118,"h":90195070334,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":103079972222,"f":32769},"n":"IsAuthenticated","d":757118,"h":98785004926,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":111669906814,"f":129},"n":"IsGuest","d":757118,"h":107374939518,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":120259841406,"f":129},"n":"IsSystem","d":757118,"h":115964874110,"f":129},{"p":1310721,"g":{"r":0,"d":0,"h":128849775998,"f":32769},"n":"Name","d":757118,"h":124554808702,"f":32769},{"p":429438,"g":{"r":0,"d":0,"h":137439710590,"f":1},"n":"Owner","d":757118,"h":133144743294,"f":1},{"p":786433,"g":{"r":0,"d":0,"h":146029645182,"f":129},"n":"Token","d":757118,"h":141734677886,"f":129},{"p":429438,"g":{"r":0,"d":0,"h":154619579774,"f":1},"n":"User","d":757118,"h":150324612478,"f":1},{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"g":{"r":0,"d":0,"h":163209514366,"f":129},"n":"UserClaims","d":757118,"h":158914547070,"f":129}],"m":[{"r":294927,"n":"Clone","d":757118,"h":167504481662,"f":32769},{"r":65537,"n":"Dispose","d":757118,"h":171799448958,"f":1},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":757118,"h":176094416254,"f":132},{"r":757118,"n":"GetAnonymous","d":757118,"h":180389383550,"f":33},{"r":757118,"n":"GetCurrent","d":757118,"h":184684350846,"f":33},{"r":757118,"p":[{"n":"ifImpersonating","p":262145}],"n":"GetCurrent","o":"@$1","d":757118,"h":188979318142,"f":33},{"r":757118,"p":[{"n":"desiredAccess","p":494974}],"n":"GetCurrent","o":"@$2","d":757118,"h":193274285438,"f":33},{"r":65537,"p":[{"n":"safeAccessTokenHandle","p":101758},{"n":"action","p":11665409}],"n":"RunImpersonated","d":757118,"h":197569252734,"f":33},{"r":133300225,"p":[{"n":"safeAccessTokenHandle","p":101758},{"n":"func","p":$.$spc.System.Func$$($.$spc.System.Threading.Tasks.Task).$h}],"n":"RunImpersonatedAsync","d":757118,"h":201864220030,"f":33},{"r":(T) => $.$spc.System.Threading.Tasks.Task$$(T).$h,"p":[{"n":"safeAccessTokenHandle","p":101758},{"n":"func","p":(T) => $.$spc.System.Func$$($.$spc.System.Threading.Tasks.Task$$(T)).$h}],"g":["T"],"n":"RunImpersonatedAsync","o":"@$1","d":757118,"h":206159187326,"f":131105},{"r":(T) => T.$h,"p":[{"n":"safeAccessTokenHandle","p":101758},{"n":"func","p":(T) => $.$spc.System.Func$$(T).$h}],"g":["T"],"n":"RunImpersonated","o":"@$1","d":757118,"h":210454154622,"f":131105}],"l":[{"t":1310721,"n":"DefaultIssuer","d":757118,"h":4295724414,"f":33}],"c":[{"p":[{"n":"userToken","p":786433}],"n":".ctor","o":"$ctor$17","d":757118,"h":8590691710,"f":1},{"p":[{"n":"userToken","p":786433},{"n":"type","p":1310721}],"n":".ctor","o":"$ctor$18","d":757118,"h":12885659006,"f":1},{"p":[{"n":"userToken","p":786433},{"n":"type","p":1310721},{"n":"acctType","p":626046}],"n":".ctor","o":"$ctor$19","d":757118,"h":17180626302,"f":1},{"p":[{"n":"userToken","p":786433},{"n":"type","p":1310721},{"n":"acctType","p":626046},{"n":"isAuthenticated","p":262145}],"n":".ctor","o":"$ctor$20","d":757118,"h":21475593598,"f":1},{"p":[{"n":"info","p":113967105},{"n":"context","p":114098177}],"n":".ctor","o":"$ctor$21","d":757118,"h":25770560894,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This API supports obsolete formatter-based serialization. It should not be called or extended by application code.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0051","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]},{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]},{"p":[{"n":"identity","p":757118}],"n":".ctor","o":"$ctor$22","d":757118,"h":30065528190,"f":4},{"p":[{"n":"sUserPrincipalName","p":1310721}],"n":".ctor","o":"$ctor$23","d":757118,"h":34360495486,"f":1}],"i":[117047297,57540609,113115137,113377281],"h":757118}; }
            static get $b() { return $.$ssc.System.Security.Claims.ClaimsIdentity; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Security.Principal.IIdentity, $.$spc.System.IDisposable, $.$spc.System.Runtime.Serialization.IDeserializationCallback, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Security.Principal.WindowsIdentity`; }
        });
        
        $asm.$cls("$sspw.System.Security.Principal.IdentityNotMappedException", ($self) => class IdentityNotMappedException extends $.$spc.System.SystemException
        {
            $ctor$9()
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            $ctor$10(/*string?*/ message)
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            $ctor$11(/*string?*/ message, /*System.Exception?*/ inner)
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            /*System.Security.Principal.IdentityReferenceCollection */ get UnmappedIdentities()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetObjectData(/*System.Runtime.Serialization.SerializationInfo*/ serializationInfo, /*System.Runtime.Serialization.StreamingContext*/ streamingContext)
            {
            }
            static $h = 167294;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":119668737,"h":167294}; }
            static get $b() { return $.$spc.System.SystemException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Security.Principal.IdentityNotMappedException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Threading.Thread", "NetJs.System.Security.Claims"))