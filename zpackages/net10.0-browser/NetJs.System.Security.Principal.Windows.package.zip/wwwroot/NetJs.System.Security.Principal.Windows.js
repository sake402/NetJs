
//--TRIMMABLE-BOUNDARY-START(70)
(async function () {
(function ($global, $, $$, $mwp, $sc, $sdt, $st, $scc, $sm, $spu, $sr, $sris, $stt, $ssc) {
    "use strict";
    let _;

    
    
    
	$.$asm(
    "NetJs.System.Security.Principal.Windows", 
    {
  "h": 70,
  "f": "System.Security.Principal.Windows",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B96771abe2820045936210554b19d0578b9bc2b1c",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "NetJs.System.Security.Principal.Windows",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "NetJs.System.Security.Principal.Windows",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160104449,
      "c": 4455071745,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(196678)
        $asm.$cls(`$sspw.SSP.IdentityReference`, ($self) => class IdentityReference extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295163974)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295163974);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295163974)
            
            //--TRIMMABLE-BOUNDARY-START(30064967750)
            static /*bool */ op_Equality(/*System.Security.Principal.IdentityReference?*/ left, /*System.Security.Principal.IdentityReference?*/ right)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064967750);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(30064967750)
            
            //--TRIMMABLE-BOUNDARY-START(34359935046)
            static /*bool */ op_Inequality(/*System.Security.Principal.IdentityReference?*/ left, /*System.Security.Principal.IdentityReference?*/ right)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359935046);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(34359935046)
            
            //--TRIMMABLE-BOUNDARY-START(4295163974)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295163974)
            
            static $h = 196678;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(47244836934),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180065862,
        "f": 50331905
      },
      "n": "Value",
      "d": 196678,
      "h": 47244836934,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(47244836934)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590131270),
    {
      "r": 262145,
      "p": [
        {
          "n": "o",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 196678,
      "h": 8590131270,
      "f": 16810241
    },
//--TRIMMABLE-BOUNDARY-END(8590131270),
//--TRIMMABLE-BOUNDARY-START(21475033158),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 196678,
      "h": 21475033158,
      "f": 16810241
    },
//--TRIMMABLE-BOUNDARY-END(21475033158),
//--TRIMMABLE-BOUNDARY-START(25770000454),
    {
      "r": 262145,
      "p": [
        {
          "n": "targetType",
          "p": 188547073
        }
      ],
      "n": "IsValidTargetType",
      "d": 196678,
      "h": 25770000454,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(25770000454),
//--TRIMMABLE-BOUNDARY-START(38654902342),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 196678,
      "h": 38654902342,
      "f": 16810241
    },
//--TRIMMABLE-BOUNDARY-END(38654902342),
//--TRIMMABLE-BOUNDARY-START(42949869638),
    {
      "r": 196678,
      "p": [
        {
          "n": "targetType",
          "p": 188547073
        }
      ],
      "n": "Translate",
      "d": 196678,
      "h": 42949869638,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(42949869638)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295163974),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 196678,
      "h": 4295163974,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4295163974)
  ],
  "h": 196678
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.Principal.IdentityReference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}Principal${separator}IdentityReference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196678)
        
        

        //--TRIMMABLE-BOUNDARY-START(327750)
        $asm.$cls(`$sspw.SSP.NTAccount`, ($self) => class NTAccount extends $.$sspw.SSP.IdentityReference
        {
            //--TRIMMABLE-BOUNDARY-START(8590262342)
            $ctor$3(/*string*/ name)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590262342);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590262342)
            
            //--TRIMMABLE-BOUNDARY-START(4295295046)
            $ctor$2(/*string*/ domainName, /*string*/ accountName)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295295046);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295295046)
            
            //--TRIMMABLE-BOUNDARY-START(51539935302)
            /*string */ get Value()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475164230);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(51539935302)
            
            //--TRIMMABLE-BOUNDARY-START(12885229638)
            /*bool */ Equals$1(/*object?*/ o)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885229638);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(12885229638)
            
            //--TRIMMABLE-BOUNDARY-START(25770131526)
            /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770131526);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(25770131526)
            
            //--TRIMMABLE-BOUNDARY-START(30065098822)
            /*bool */ IsValidTargetType(/*System.Type*/ targetType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065098822);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(30065098822)
            
            //--TRIMMABLE-BOUNDARY-START(34360066118)
            static /*bool */ op_Equality$1(/*System.Security.Principal.NTAccount?*/ left, /*System.Security.Principal.NTAccount?*/ right)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360066118);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(34360066118)
            
            //--TRIMMABLE-BOUNDARY-START(38655033414)
            static /*bool */ op_Inequality$1(/*System.Security.Principal.NTAccount?*/ left, /*System.Security.Principal.NTAccount?*/ right)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655033414);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(38655033414)
            
            //--TRIMMABLE-BOUNDARY-START(42950000710)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950000710);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(42950000710)
            
            //--TRIMMABLE-BOUNDARY-START(47244968006)
            /*System.Security.Principal.IdentityReference */ Translate(/*System.Type*/ targetType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244968006);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(47244968006)
            
            static $h = 327750;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$sspw.SSP.IdentityReference; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51539935302),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475164230,
        "f": 50364417
      },
      "n": "Value",
      "d": 327750,
      "h": 51539935302,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(51539935302)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885229638),
    {
      "r": 262145,
      "p": [
        {
          "n": "o",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 327750,
      "h": 12885229638,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(12885229638),
//--TRIMMABLE-BOUNDARY-START(25770131526),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 327750,
      "h": 25770131526,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25770131526),
//--TRIMMABLE-BOUNDARY-START(30065098822),
    {
      "r": 262145,
      "p": [
        {
          "n": "targetType",
          "p": 188547073
        }
      ],
      "n": "IsValidTargetType",
      "d": 327750,
      "h": 30065098822,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30065098822),
//--TRIMMABLE-BOUNDARY-START(42950000710),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 327750,
      "h": 42950000710,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(42950000710),
//--TRIMMABLE-BOUNDARY-START(47244968006),
    {
      "r": 196678,
      "p": [
        {
          "n": "targetType",
          "p": 188547073
        }
      ],
      "n": "Translate",
      "d": 327750,
      "h": 47244968006,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47244968006)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590262342),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 327750,
      "h": 8590262342,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590262342),
//--TRIMMABLE-BOUNDARY-START(4295295046),
    {
      "p": [
        {
          "n": "domainName",
          "p": 1310721
        },
        {
          "n": "accountName",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 327750,
      "h": 4295295046,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295295046)
  ],
  "h": 327750
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.Principal.NTAccount`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}Principal${separator}NTAccount`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327750)
        
        

        //--TRIMMABLE-BOUNDARY-START(393286)
        $asm.$cls(`$sspw.SSP.SecurityIdentifier`, ($self) => class SecurityIdentifier extends $.$sspw.SSP.IdentityReference
        {
            //--TRIMMABLE-BOUNDARY-START(94489673798)
            /*int*/ static MaxBinaryLength = 0;
            //--TRIMMABLE-BOUNDARY-END(94489673798)
            
            //--TRIMMABLE-BOUNDARY-START(98784641094)
            /*int*/ static MinBinaryLength = 0;
            //--TRIMMABLE-BOUNDARY-END(98784641094)
            
            //--TRIMMABLE-BOUNDARY-START(4295360582)
            $ctor$2(/*byte[]*/ binaryForm, /*int*/ offset)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295360582);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295360582)
            
            //--TRIMMABLE-BOUNDARY-START(8590327878)
            $ctor$3(/*System.IntPtr*/ binaryForm)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590327878);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590327878)
            
            //--TRIMMABLE-BOUNDARY-START(12885295174)
            $ctor$4(/*System.Security.Principal.WellKnownSidType*/ sidType, /*System.Security.Principal.SecurityIdentifier?*/ domainSid)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885295174);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885295174)
            
            //--TRIMMABLE-BOUNDARY-START(17180262470)
            $ctor$5(/*string*/ sddlForm)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180262470);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180262470)
            
            //--TRIMMABLE-BOUNDARY-START(21475229766)
            /*System.Security.Principal.SecurityIdentifier? */ get AccountDomainSid()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245033542);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(21475229766)
            
            //--TRIMMABLE-BOUNDARY-START(25770197062)
            /*int */ get BinaryLength()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834968134);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(25770197062)
            
            //--TRIMMABLE-BOUNDARY-START(120259477574)
            /*string */ get Value()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424902726);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(120259477574)
            
            //--TRIMMABLE-BOUNDARY-START(30065164358)
            /*int */ CompareTo(/*System.Security.Principal.SecurityIdentifier?*/ sid)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065164358);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(30065164358)
            
            //--TRIMMABLE-BOUNDARY-START(34360131654)
            /*bool */ Equals$1(/*object?*/ o)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360131654);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(34360131654)
            
            //--TRIMMABLE-BOUNDARY-START(38655098950)
            /*bool */ Equals$2(/*System.Security.Principal.SecurityIdentifier*/ sid)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655098950);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(38655098950)
            
            //--TRIMMABLE-BOUNDARY-START(68719870022)
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719870022);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(68719870022)
            
            //--TRIMMABLE-BOUNDARY-START(73014837318)
            /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014837318);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(73014837318)
            
            //--TRIMMABLE-BOUNDARY-START(77309804614)
            /*bool */ IsAccountSid()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309804614);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(77309804614)
            
            //--TRIMMABLE-BOUNDARY-START(81604771910)
            /*bool */ IsEqualDomainSid(/*System.Security.Principal.SecurityIdentifier*/ sid)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604771910);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(81604771910)
            
            //--TRIMMABLE-BOUNDARY-START(85899739206)
            /*bool */ IsValidTargetType(/*System.Type*/ targetType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899739206);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(85899739206)
            
            //--TRIMMABLE-BOUNDARY-START(90194706502)
            /*bool */ IsWellKnown(/*System.Security.Principal.WellKnownSidType*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194706502);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(90194706502)
            
            //--TRIMMABLE-BOUNDARY-START(103079608390)
            static /*bool */ op_Equality$1(/*System.Security.Principal.SecurityIdentifier?*/ left, /*System.Security.Principal.SecurityIdentifier?*/ right)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079608390);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(103079608390)
            
            //--TRIMMABLE-BOUNDARY-START(107374575686)
            static /*bool */ op_Inequality$1(/*System.Security.Principal.SecurityIdentifier?*/ left, /*System.Security.Principal.SecurityIdentifier?*/ right)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374575686);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(107374575686)
            
            //--TRIMMABLE-BOUNDARY-START(111669542982)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669542982);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(111669542982)
            
            //--TRIMMABLE-BOUNDARY-START(115964510278)
            /*System.Security.Principal.IdentityReference */ Translate(/*System.Type*/ targetType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964510278);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(115964510278)
            
            //--TRIMMABLE-BOUNDARY-START(4385865729)
            //Generated interface implemetation for System.IComparable<System.Security.Principal.SecurityIdentifier>.CompareTo(System.Security.Principal.SecurityIdentifier?)
            S$IComparable$System$Security$Principal$SecurityIdentifier$CompareTo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385865729);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CompareTo(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385865729)
            
            static $h = 393286;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$sspw.SSP.IdentityReference; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475229766),
    {
      "p": 393286,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245033542,
        "f": 50331649
      },
      "n": "AccountDomainSid",
      "d": 393286,
      "h": 21475229766,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475229766),
//--TRIMMABLE-BOUNDARY-START(25770197062),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834968134,
        "f": 50331649
      },
      "n": "BinaryLength",
      "d": 393286,
      "h": 25770197062,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770197062),
//--TRIMMABLE-BOUNDARY-START(120259477574),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424902726,
        "f": 50364417
      },
      "n": "Value",
      "d": 393286,
      "h": 120259477574,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(120259477574)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30065164358),
    {
      "r": 655361,
      "p": [
        {
          "n": "sid",
          "p": 393286
        }
      ],
      "n": "CompareTo",
      "d": 393286,
      "h": 30065164358,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065164358),
//--TRIMMABLE-BOUNDARY-START(34360131654),
    {
      "r": 262145,
      "p": [
        {
          "n": "o",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 393286,
      "h": 34360131654,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34360131654),
//--TRIMMABLE-BOUNDARY-START(38655098950),
    {
      "r": 262145,
      "p": [
        {
          "n": "sid",
          "p": 393286
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 393286,
      "h": 38655098950,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655098950),
//--TRIMMABLE-BOUNDARY-START(68719870022),
    {
      "r": 65537,
      "p": [
        {
          "n": "binaryForm",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        }
      ],
      "n": "GetBinaryForm",
      "d": 393286,
      "h": 68719870022,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68719870022),
//--TRIMMABLE-BOUNDARY-START(73014837318),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 393286,
      "h": 73014837318,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(73014837318),
//--TRIMMABLE-BOUNDARY-START(77309804614),
    {
      "r": 262145,
      "n": "IsAccountSid",
      "d": 393286,
      "h": 77309804614,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77309804614),
//--TRIMMABLE-BOUNDARY-START(81604771910),
    {
      "r": 262145,
      "p": [
        {
          "n": "sid",
          "p": 393286
        }
      ],
      "n": "IsEqualDomainSid",
      "d": 393286,
      "h": 81604771910,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(81604771910),
//--TRIMMABLE-BOUNDARY-START(85899739206),
    {
      "r": 262145,
      "p": [
        {
          "n": "targetType",
          "p": 188547073
        }
      ],
      "n": "IsValidTargetType",
      "d": 393286,
      "h": 85899739206,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(85899739206),
//--TRIMMABLE-BOUNDARY-START(90194706502),
    {
      "r": 262145,
      "p": [
        {
          "n": "type",
          "p": 524358
        }
      ],
      "n": "IsWellKnown",
      "d": 393286,
      "h": 90194706502,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(90194706502),
//--TRIMMABLE-BOUNDARY-START(111669542982),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 393286,
      "h": 111669542982,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(111669542982),
//--TRIMMABLE-BOUNDARY-START(115964510278),
    {
      "r": 196678,
      "p": [
        {
          "n": "targetType",
          "p": 188547073
        }
      ],
      "n": "Translate",
      "d": 393286,
      "h": 115964510278,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(115964510278)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(94489673798),
    {
      "t": 655361,
      "n": "MaxBinaryLength",
      "d": 393286,
      "h": 94489673798,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(94489673798),
//--TRIMMABLE-BOUNDARY-START(98784641094),
    {
      "t": 655361,
      "n": "MinBinaryLength",
      "d": 393286,
      "h": 98784641094,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(98784641094)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295360582),
    {
      "p": [
        {
          "n": "binaryForm",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 393286,
      "h": 4295360582,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295360582),
//--TRIMMABLE-BOUNDARY-START(8590327878),
    {
      "p": [
        {
          "n": "binaryForm",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 393286,
      "h": 8590327878,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590327878),
//--TRIMMABLE-BOUNDARY-START(12885295174),
    {
      "p": [
        {
          "n": "sidType",
          "p": 524358
        },
        {
          "n": "domainSid",
          "p": 393286
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 393286,
      "h": 12885295174,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885295174),
//--TRIMMABLE-BOUNDARY-START(17180262470),
    {
      "p": [
        {
          "n": "sddlForm",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 393286,
      "h": 17180262470,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180262470)
  ],
  "h": 393286
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable$$($.$sspw.SSP.SecurityIdentifier) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.Principal.SecurityIdentifier`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}Principal${separator}SecurityIdentifier`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393286)
        
        

        //--TRIMMABLE-BOUNDARY-START(262214)
        $asm.$cls(`$sspw.SSP.IdentityReferenceCollection`, ($self) => class IdentityReferenceCollection extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295229510)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295229510);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295229510)
            
            //--TRIMMABLE-BOUNDARY-START(8590196806)
            $ctor$2(/*int*/ capacity)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590196806);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590196806)
            
            //--TRIMMABLE-BOUNDARY-START(30065033286)
            /*int */ get Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654967878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(30065033286)
            
            //--TRIMMABLE-BOUNDARY-START(85899608134)
            /*System.Security.Principal.IdentityReference*/ get_Item$1(/*int*/ index)
            {
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*void*/ set_Item$1(/*int*/ index, /*System.Security.Principal.IdentityReference*/ value)
            {
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(85899608134)
            
            //--TRIMMABLE-BOUNDARY-START(77309673542)
            /*bool */ get SCG$ICollection$$$IsReadOnly()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014706246);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(77309673542)
            
            //--TRIMMABLE-BOUNDARY-START(12885164102)
            /*void */ Add(/*System.Security.Principal.IdentityReference*/ identity)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885164102);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(12885164102)
            
            //--TRIMMABLE-BOUNDARY-START(17180131398)
            /*void */ Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180131398);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(17180131398)
            
            //--TRIMMABLE-BOUNDARY-START(21475098694)
            /*bool */ Contains(/*System.Security.Principal.IdentityReference*/ identity)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475098694);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(21475098694)
            
            //--TRIMMABLE-BOUNDARY-START(25770065990)
            /*void */ CopyTo(/*System.Security.Principal.IdentityReference[]*/ array, /*int*/ offset)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770065990);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(25770065990)
            
            //--TRIMMABLE-BOUNDARY-START(51539869766)
            /*System.Collections.Generic.IEnumerator<System.Security.Principal.IdentityReference> */ GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539869766);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(51539869766)
            
            //--TRIMMABLE-BOUNDARY-START(55834837062)
            /*bool */ Remove(/*System.Security.Principal.IdentityReference*/ identity)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834837062);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(55834837062)
            
            //--TRIMMABLE-BOUNDARY-START(81604640838)
            /*System.Collections.IEnumerator */ SC$1$IEnumerable$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604640838);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(81604640838)
            
            //--TRIMMABLE-BOUNDARY-START(94489542726)
            /*System.Security.Principal.IdentityReferenceCollection */ Translate$1(/*System.Type*/ targetType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489542726);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(94489542726)
            
            //--TRIMMABLE-BOUNDARY-START(90194575430)
            /*System.Security.Principal.IdentityReferenceCollection */ Translate(/*System.Type*/ targetType, /*bool*/ forceSuccess)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194575430);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(90194575430)
            
            //--TRIMMABLE-BOUNDARY-START(30124802049)
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Security.Principal.IdentityReference>.Count.get
            get SCG$ICollection$$$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21534867457);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(30124802049)
            
            //--TRIMMABLE-BOUNDARY-START(4354998273)
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Security.Principal.IdentityReference>.Add(System.Security.Principal.IdentityReference)
            SCG$ICollection$$$Add()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4354998273);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Add(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4354998273)
            
            //--TRIMMABLE-BOUNDARY-START(8649965569)
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Security.Principal.IdentityReference>.Clear()
            SCG$ICollection$$$Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8649965569);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Clear(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8649965569)
            
            //--TRIMMABLE-BOUNDARY-START(12944932865)
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Security.Principal.IdentityReference>.Contains(System.Security.Principal.IdentityReference)
            SCG$ICollection$$$Contains()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12944932865);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Contains(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12944932865)
            
            //--TRIMMABLE-BOUNDARY-START(17239900161)
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Security.Principal.IdentityReference>.CopyTo(System.Security.Principal.IdentityReference[], int)
            SCG$ICollection$$$CopyTo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17239900161);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CopyTo(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17239900161)
            
            //--TRIMMABLE-BOUNDARY-START(47304671233)
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Security.Principal.IdentityReference>.Remove(System.Security.Principal.IdentityReference)
            SCG$ICollection$$$Remove()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47304671233);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Remove(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(47304671233)
            
            //--TRIMMABLE-BOUNDARY-START(4355325953)
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Security.Principal.IdentityReference>.GetEnumerator()
            SCG$IEnumerable$$$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4355325953);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetEnumerator(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4355325953)
            
            //--TRIMMABLE-BOUNDARY-START(4295229510)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295229510)
            
            static $h = 262214;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30065033286),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38654967878,
        "f": 50331649
      },
      "n": "Count",
      "d": 262214,
      "h": 30065033286,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065033286),
//--TRIMMABLE-BOUNDARY-START(85899608134),
    {
      "p": 196678,
      "i": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244902470,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64424771654,
        "f": 83886081
      },
      "n": "Item",
      "o": "@$1",
      "d": 262214,
      "h": 85899608134,
      "f": 538968065
    },
//--TRIMMABLE-BOUNDARY-END(85899608134),
//--TRIMMABLE-BOUNDARY-START(77309673542),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014706246,
        "f": 50331650
      },
      "n": "{$.$$.SCG.ICollection$$($.$sspw.SSP.IdentityReference).$h}.IsReadOnly",
      "o": "SCG$ICollection$$$IsReadOnly",
      "d": 262214,
      "h": 77309673542,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(77309673542)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885164102),
    {
      "r": 65537,
      "p": [
        {
          "n": "identity",
          "p": 196678
        }
      ],
      "n": "Add",
      "d": 262214,
      "h": 12885164102,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885164102),
//--TRIMMABLE-BOUNDARY-START(17180131398),
    {
      "r": 65537,
      "n": "Clear",
      "d": 262214,
      "h": 17180131398,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180131398),
//--TRIMMABLE-BOUNDARY-START(21475098694),
    {
      "r": 262145,
      "p": [
        {
          "n": "identity",
          "p": 196678
        }
      ],
      "n": "Contains",
      "d": 262214,
      "h": 21475098694,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475098694),
//--TRIMMABLE-BOUNDARY-START(25770065990),
    {
      "r": 65537,
      "p": [
        {
          "n": "array",
          "p": $.$typeArray($.$sspw.SSP.IdentityReference).$h
        },
        {
          "n": "offset",
          "p": 655361
        }
      ],
      "n": "CopyTo",
      "d": 262214,
      "h": 25770065990,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770065990),
//--TRIMMABLE-BOUNDARY-START(51539869766),
    {
      "r": $.$$.SCG.IEnumerator$$($.$sspw.SSP.IdentityReference).$h,
      "n": "GetEnumerator",
      "d": 262214,
      "h": 51539869766,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51539869766),
//--TRIMMABLE-BOUNDARY-START(55834837062),
    {
      "r": 262145,
      "p": [
        {
          "n": "identity",
          "p": 196678
        }
      ],
      "n": "Remove",
      "d": 262214,
      "h": 55834837062,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55834837062),
//--TRIMMABLE-BOUNDARY-START(94489542726),
    {
      "r": 262214,
      "p": [
        {
          "n": "targetType",
          "p": 188547073
        }
      ],
      "n": "Translate",
      "o": "@$1",
      "d": 262214,
      "h": 94489542726,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(94489542726),
//--TRIMMABLE-BOUNDARY-START(90194575430),
    {
      "r": 262214,
      "p": [
        {
          "n": "targetType",
          "p": 188547073
        },
        {
          "n": "forceSuccess",
          "p": 262145
        }
      ],
      "n": "Translate",
      "d": 262214,
      "h": 90194575430,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(90194575430)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295229510),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 262214,
      "h": 4295229510,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295229510),
//--TRIMMABLE-BOUNDARY-START(8590196806),
    {
      "p": [
        {
          "n": "capacity",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 262214,
      "h": 8590196806,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590196806)
  ],
  "h": 262214
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SCG.ICollection$$($.$sspw.SSP.IdentityReference), $.$$.SCG.IEnumerable$$($.$sspw.SSP.IdentityReference), $.$$.SC$1.IEnumerable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.Principal.IdentityReferenceCollection`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}Principal${separator}IdentityReferenceCollection`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262214)
        
        

        //--TRIMMABLE-BOUNDARY-START(65606)
        $asm.$cls(`$sspw.MWS.SafeAccessTokenHandle`, ($self) => class SafeAccessTokenHandle extends $.$$.SRI.SafeHandle
        {
            //--TRIMMABLE-BOUNDARY-START(4295032902)
            $ctor$3()
            {
                super.$ctor$2(0, false);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295032902);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295032902)
            
            //--TRIMMABLE-BOUNDARY-START(8590000198)
            $ctor$4(/*System.IntPtr*/ handle)
            {
                super.$ctor$2(0, false);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590000198);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590000198)
            
            //--TRIMMABLE-BOUNDARY-START(30064836678)
            static /*Microsoft.Win32.SafeHandles.SafeAccessTokenHandle */ get InvalidHandle()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17179934790);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(30064836678)
            
            //--TRIMMABLE-BOUNDARY-START(34359803974)
            /*bool */ get IsInvalid()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25769869382);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(34359803974)
            
            //--TRIMMABLE-BOUNDARY-START(38654771270)
            /*bool */ ReleaseHandle()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654771270);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(38654771270)
            
            //--TRIMMABLE-BOUNDARY-START(4295032902)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295032902)
            
            static $h = 65606;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.SRI.SafeHandle; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30064836678),
    {
      "p": 65606,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17179934790,
        "f": 50331681
      },
      "n": "InvalidHandle",
      "d": 65606,
      "h": 30064836678,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(30064836678),
//--TRIMMABLE-BOUNDARY-START(34359803974),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25769869382,
        "f": 50364417
      },
      "n": "IsInvalid",
      "d": 65606,
      "h": 34359803974,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34359803974)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38654771270),
    {
      "r": 262145,
      "n": "ReleaseHandle",
      "d": 65606,
      "h": 38654771270,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(38654771270)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295032902),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 65606,
      "h": 4295032902,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295032902),
//--TRIMMABLE-BOUNDARY-START(8590000198),
    {
      "p": [
        {
          "n": "handle",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 65606,
      "h": 8590000198,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590000198)
  ],
  "h": 65606
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Win32.SafeHandles.SafeAccessTokenHandle`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Win32${separator}SafeHandles${separator}SafeAccessTokenHandle`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65606)
        
        

        //--TRIMMABLE-BOUNDARY-START(458822)
        $asm.$str(`$sspw.SSP.TokenAccessLevels`, ($self) => class TokenAccessLevels extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static AssignPrimary = 1;
            static Duplicate = 2;
            static Impersonate = 4;
            static Query = 8;
            static QuerySource = 16;
            static AdjustPrivileges = 32;
            static AdjustGroups = 64;
            static AdjustDefault = 128;
            static AdjustSessionId = 256;
            static Read = 131080;
            static Write = 131296;
            static AllAccess = 983551;
            static MaximumAllowed = 33554432;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(458822);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "AssignPrimary": 1n,
                    "Duplicate": 2n,
                    "Impersonate": 4n,
                    "Query": 8n,
                    "QuerySource": 16n,
                    "AdjustPrivileges": 32n,
                    "AdjustGroups": 64n,
                    "AdjustDefault": 128n,
                    "AdjustSessionId": 256n,
                    "Read": 131080n,
                    "Write": 131296n,
                    "AllAccess": 983551n,
                    "MaximumAllowed": 33554432n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295426118)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295426118);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295426118)
            
            //--TRIMMABLE-BOUNDARY-START(4295426118)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295426118)
            
            static $h = 458822;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(30065229894),
    {
      "t": 458822,
      "n": "AssignPrimary",
      "d": 458822,
      "h": 30065229894,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065229894),
//--TRIMMABLE-BOUNDARY-START(34360197190),
    {
      "t": 458822,
      "n": "Duplicate",
      "d": 458822,
      "h": 34360197190,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360197190),
//--TRIMMABLE-BOUNDARY-START(38655164486),
    {
      "t": 458822,
      "n": "Impersonate",
      "d": 458822,
      "h": 38655164486,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38655164486),
//--TRIMMABLE-BOUNDARY-START(47245099078),
    {
      "t": 458822,
      "n": "Query",
      "d": 458822,
      "h": 47245099078,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47245099078),
//--TRIMMABLE-BOUNDARY-START(51540066374),
    {
      "t": 458822,
      "n": "QuerySource",
      "d": 458822,
      "h": 51540066374,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51540066374),
//--TRIMMABLE-BOUNDARY-START(17180328006),
    {
      "t": 458822,
      "n": "AdjustPrivileges",
      "d": 458822,
      "h": 17180328006,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180328006),
//--TRIMMABLE-BOUNDARY-START(12885360710),
    {
      "t": 458822,
      "n": "AdjustGroups",
      "d": 458822,
      "h": 12885360710,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885360710),
//--TRIMMABLE-BOUNDARY-START(8590393414),
    {
      "t": 458822,
      "n": "AdjustDefault",
      "d": 458822,
      "h": 8590393414,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590393414),
//--TRIMMABLE-BOUNDARY-START(21475295302),
    {
      "t": 458822,
      "n": "AdjustSessionId",
      "d": 458822,
      "h": 21475295302,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475295302),
//--TRIMMABLE-BOUNDARY-START(55835033670),
    {
      "t": 458822,
      "n": "Read",
      "d": 458822,
      "h": 55835033670,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55835033670),
//--TRIMMABLE-BOUNDARY-START(60130000966),
    {
      "t": 458822,
      "n": "Write",
      "d": 458822,
      "h": 60130000966,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60130000966),
//--TRIMMABLE-BOUNDARY-START(25770262598),
    {
      "t": 458822,
      "n": "AllAccess",
      "d": 458822,
      "h": 25770262598,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770262598),
//--TRIMMABLE-BOUNDARY-START(42950131782),
    {
      "t": 458822,
      "n": "MaximumAllowed",
      "d": 458822,
      "h": 42950131782,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42950131782)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295426118),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 458822,
      "h": 4295426118,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295426118)
  ],
  "h": 458822,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.Principal.TokenAccessLevels`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}Principal${separator}TokenAccessLevels`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458822)
        
        

        //--TRIMMABLE-BOUNDARY-START(524358)
        $asm.$str(`$sspw.SSP.WellKnownSidType`, ($self) => class WellKnownSidType extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static NullSid = 0;
            static WorldSid = 1;
            static LocalSid = 2;
            static CreatorOwnerSid = 3;
            static CreatorGroupSid = 4;
            static CreatorOwnerServerSid = 5;
            static CreatorGroupServerSid = 6;
            static NTAuthoritySid = 7;
            static DialupSid = 8;
            static NetworkSid = 9;
            static BatchSid = 10;
            static InteractiveSid = 11;
            static ServiceSid = 12;
            static AnonymousSid = 13;
            static ProxySid = 14;
            static EnterpriseControllersSid = 15;
            static SelfSid = 16;
            static AuthenticatedUserSid = 17;
            static RestrictedCodeSid = 18;
            static TerminalServerSid = 19;
            static RemoteLogonIdSid = 20;
            static LogonIdsSid = 21;
            static LocalSystemSid = 22;
            static LocalServiceSid = 23;
            static NetworkServiceSid = 24;
            static BuiltinDomainSid = 25;
            static BuiltinAdministratorsSid = 26;
            static BuiltinUsersSid = 27;
            static BuiltinGuestsSid = 28;
            static BuiltinPowerUsersSid = 29;
            static BuiltinAccountOperatorsSid = 30;
            static BuiltinSystemOperatorsSid = 31;
            static BuiltinPrintOperatorsSid = 32;
            static BuiltinBackupOperatorsSid = 33;
            static BuiltinReplicatorSid = 34;
            static BuiltinPreWindows2000CompatibleAccessSid = 35;
            static BuiltinRemoteDesktopUsersSid = 36;
            static BuiltinNetworkConfigurationOperatorsSid = 37;
            static AccountAdministratorSid = 38;
            static AccountGuestSid = 39;
            static AccountKrbtgtSid = 40;
            static AccountDomainAdminsSid = 41;
            static AccountDomainUsersSid = 42;
            static AccountDomainGuestsSid = 43;
            static AccountComputersSid = 44;
            static AccountControllersSid = 45;
            static AccountCertAdminsSid = 46;
            static AccountSchemaAdminsSid = 47;
            static AccountEnterpriseAdminsSid = 48;
            static AccountPolicyAdminsSid = 49;
            static AccountRasAndIasServersSid = 50;
            static NtlmAuthenticationSid = 51;
            static DigestAuthenticationSid = 52;
            static SChannelAuthenticationSid = 53;
            static ThisOrganizationSid = 54;
            static OtherOrganizationSid = 55;
            static BuiltinIncomingForestTrustBuildersSid = 56;
            static BuiltinPerformanceMonitoringUsersSid = 57;
            static BuiltinPerformanceLoggingUsersSid = 58;
            static BuiltinAuthorizationAccessSid = 59;
            static MaxDefined = 60;
            static WinBuiltinTerminalServerLicenseServersSid = 60;
            static WinBuiltinDCOMUsersSid = 61;
            static WinBuiltinIUsersSid = 62;
            static WinIUserSid = 63;
            static WinBuiltinCryptoOperatorsSid = 64;
            static WinUntrustedLabelSid = 65;
            static WinLowLabelSid = 66;
            static WinMediumLabelSid = 67;
            static WinHighLabelSid = 68;
            static WinSystemLabelSid = 69;
            static WinWriteRestrictedCodeSid = 70;
            static WinCreatorOwnerRightsSid = 71;
            static WinCacheablePrincipalsGroupSid = 72;
            static WinNonCacheablePrincipalsGroupSid = 73;
            static WinEnterpriseReadonlyControllersSid = 74;
            static WinAccountReadonlyControllersSid = 75;
            static WinBuiltinEventLogReadersGroup = 76;
            static WinNewEnterpriseReadonlyControllersSid = 77;
            static WinBuiltinCertSvcDComAccessGroup = 78;
            static WinMediumPlusLabelSid = 79;
            static WinLocalLogonSid = 80;
            static WinConsoleLogonSid = 81;
            static WinThisOrganizationCertificateSid = 82;
            static WinApplicationPackageAuthoritySid = 83;
            static WinBuiltinAnyPackageSid = 84;
            static WinCapabilityInternetClientSid = 85;
            static WinCapabilityInternetClientServerSid = 86;
            static WinCapabilityPrivateNetworkClientServerSid = 87;
            static WinCapabilityPicturesLibrarySid = 88;
            static WinCapabilityVideosLibrarySid = 89;
            static WinCapabilityMusicLibrarySid = 90;
            static WinCapabilityDocumentsLibrarySid = 91;
            static WinCapabilitySharedUserCertificatesSid = 92;
            static WinCapabilityEnterpriseAuthenticationSid = 93;
            static WinCapabilityRemovableStorageSid = 94;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(524358);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "NullSid": 0n,
                    "WorldSid": 1n,
                    "LocalSid": 2n,
                    "CreatorOwnerSid": 3n,
                    "CreatorGroupSid": 4n,
                    "CreatorOwnerServerSid": 5n,
                    "CreatorGroupServerSid": 6n,
                    "NTAuthoritySid": 7n,
                    "DialupSid": 8n,
                    "NetworkSid": 9n,
                    "BatchSid": 10n,
                    "InteractiveSid": 11n,
                    "ServiceSid": 12n,
                    "AnonymousSid": 13n,
                    "ProxySid": 14n,
                    "EnterpriseControllersSid": 15n,
                    "SelfSid": 16n,
                    "AuthenticatedUserSid": 17n,
                    "RestrictedCodeSid": 18n,
                    "TerminalServerSid": 19n,
                    "RemoteLogonIdSid": 20n,
                    "LogonIdsSid": 21n,
                    "LocalSystemSid": 22n,
                    "LocalServiceSid": 23n,
                    "NetworkServiceSid": 24n,
                    "BuiltinDomainSid": 25n,
                    "BuiltinAdministratorsSid": 26n,
                    "BuiltinUsersSid": 27n,
                    "BuiltinGuestsSid": 28n,
                    "BuiltinPowerUsersSid": 29n,
                    "BuiltinAccountOperatorsSid": 30n,
                    "BuiltinSystemOperatorsSid": 31n,
                    "BuiltinPrintOperatorsSid": 32n,
                    "BuiltinBackupOperatorsSid": 33n,
                    "BuiltinReplicatorSid": 34n,
                    "BuiltinPreWindows2000CompatibleAccessSid": 35n,
                    "BuiltinRemoteDesktopUsersSid": 36n,
                    "BuiltinNetworkConfigurationOperatorsSid": 37n,
                    "AccountAdministratorSid": 38n,
                    "AccountGuestSid": 39n,
                    "AccountKrbtgtSid": 40n,
                    "AccountDomainAdminsSid": 41n,
                    "AccountDomainUsersSid": 42n,
                    "AccountDomainGuestsSid": 43n,
                    "AccountComputersSid": 44n,
                    "AccountControllersSid": 45n,
                    "AccountCertAdminsSid": 46n,
                    "AccountSchemaAdminsSid": 47n,
                    "AccountEnterpriseAdminsSid": 48n,
                    "AccountPolicyAdminsSid": 49n,
                    "AccountRasAndIasServersSid": 50n,
                    "NtlmAuthenticationSid": 51n,
                    "DigestAuthenticationSid": 52n,
                    "SChannelAuthenticationSid": 53n,
                    "ThisOrganizationSid": 54n,
                    "OtherOrganizationSid": 55n,
                    "BuiltinIncomingForestTrustBuildersSid": 56n,
                    "BuiltinPerformanceMonitoringUsersSid": 57n,
                    "BuiltinPerformanceLoggingUsersSid": 58n,
                    "BuiltinAuthorizationAccessSid": 59n,
                    "MaxDefined": 60n,
                    "WinBuiltinTerminalServerLicenseServersSid": 60n,
                    "WinBuiltinDCOMUsersSid": 61n,
                    "WinBuiltinIUsersSid": 62n,
                    "WinIUserSid": 63n,
                    "WinBuiltinCryptoOperatorsSid": 64n,
                    "WinUntrustedLabelSid": 65n,
                    "WinLowLabelSid": 66n,
                    "WinMediumLabelSid": 67n,
                    "WinHighLabelSid": 68n,
                    "WinSystemLabelSid": 69n,
                    "WinWriteRestrictedCodeSid": 70n,
                    "WinCreatorOwnerRightsSid": 71n,
                    "WinCacheablePrincipalsGroupSid": 72n,
                    "WinNonCacheablePrincipalsGroupSid": 73n,
                    "WinEnterpriseReadonlyControllersSid": 74n,
                    "WinAccountReadonlyControllersSid": 75n,
                    "WinBuiltinEventLogReadersGroup": 76n,
                    "WinNewEnterpriseReadonlyControllersSid": 77n,
                    "WinBuiltinCertSvcDComAccessGroup": 78n,
                    "WinMediumPlusLabelSid": 79n,
                    "WinLocalLogonSid": 80n,
                    "WinConsoleLogonSid": 81n,
                    "WinThisOrganizationCertificateSid": 82n,
                    "WinApplicationPackageAuthoritySid": 83n,
                    "WinBuiltinAnyPackageSid": 84n,
                    "WinCapabilityInternetClientSid": 85n,
                    "WinCapabilityInternetClientServerSid": 86n,
                    "WinCapabilityPrivateNetworkClientServerSid": 87n,
                    "WinCapabilityPicturesLibrarySid": 88n,
                    "WinCapabilityVideosLibrarySid": 89n,
                    "WinCapabilityMusicLibrarySid": 90n,
                    "WinCapabilityDocumentsLibrarySid": 91n,
                    "WinCapabilitySharedUserCertificatesSid": 92n,
                    "WinCapabilityEnterpriseAuthenticationSid": 93n,
                    "WinCapabilityRemovableStorageSid": 94n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295491654)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295491654);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295491654)
            
            //--TRIMMABLE-BOUNDARY-START(4295491654)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295491654)
            
            static $h = 524358;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(223338823750),
    {
      "t": 524358,
      "n": "NullSid",
      "d": 524358,
      "h": 223338823750,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(223338823750),
//--TRIMMABLE-BOUNDARY-START(416612352070),
    {
      "t": 524358,
      "n": "WorldSid",
      "d": 524358,
      "h": 416612352070,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(416612352070),
//--TRIMMABLE-BOUNDARY-START(188979085382),
    {
      "t": 524358,
      "n": "LocalSid",
      "d": 524358,
      "h": 188979085382,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(188979085382),
//--TRIMMABLE-BOUNDARY-START(163209281606),
    {
      "t": 524358,
      "n": "CreatorOwnerSid",
      "d": 524358,
      "h": 163209281606,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(163209281606),
//--TRIMMABLE-BOUNDARY-START(154619347014),
    {
      "t": 524358,
      "n": "CreatorGroupSid",
      "d": 524358,
      "h": 154619347014,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(154619347014),
//--TRIMMABLE-BOUNDARY-START(158914314310),
    {
      "t": 524358,
      "n": "CreatorOwnerServerSid",
      "d": 524358,
      "h": 158914314310,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(158914314310),
//--TRIMMABLE-BOUNDARY-START(150324379718),
    {
      "t": 524358,
      "n": "CreatorGroupServerSid",
      "d": 524358,
      "h": 150324379718,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(150324379718),
//--TRIMMABLE-BOUNDARY-START(214748889158),
    {
      "t": 524358,
      "n": "NTAuthoritySid",
      "d": 524358,
      "h": 214748889158,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(214748889158),
//--TRIMMABLE-BOUNDARY-START(167504248902),
    {
      "t": 524358,
      "n": "DialupSid",
      "d": 524358,
      "h": 167504248902,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(167504248902),
//--TRIMMABLE-BOUNDARY-START(210453921862),
    {
      "t": 524358,
      "n": "NetworkSid",
      "d": 524358,
      "h": 210453921862,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(210453921862),
//--TRIMMABLE-BOUNDARY-START(73014968390),
    {
      "t": 524358,
      "n": "BatchSid",
      "d": 524358,
      "h": 73014968390,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(73014968390),
//--TRIMMABLE-BOUNDARY-START(180389150790),
    {
      "t": 524358,
      "n": "InteractiveSid",
      "d": 524358,
      "h": 180389150790,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(180389150790),
//--TRIMMABLE-BOUNDARY-START(253403594822),
    {
      "t": 524358,
      "n": "ServiceSid",
      "d": 524358,
      "h": 253403594822,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(253403594822),
//--TRIMMABLE-BOUNDARY-START(64425033798),
    {
      "t": 524358,
      "n": "AnonymousSid",
      "d": 524358,
      "h": 64425033798,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(64425033798),
//--TRIMMABLE-BOUNDARY-START(231928758342),
    {
      "t": 524358,
      "n": "ProxySid",
      "d": 524358,
      "h": 231928758342,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(231928758342),
//--TRIMMABLE-BOUNDARY-START(176094183494),
    {
      "t": 524358,
      "n": "EnterpriseControllersSid",
      "d": 524358,
      "h": 176094183494,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(176094183494),
//--TRIMMABLE-BOUNDARY-START(249108627526),
    {
      "t": 524358,
      "n": "SelfSid",
      "d": 524358,
      "h": 249108627526,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(249108627526),
//--TRIMMABLE-BOUNDARY-START(68720001094),
    {
      "t": 524358,
      "n": "AuthenticatedUserSid",
      "d": 524358,
      "h": 68720001094,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(68720001094),
//--TRIMMABLE-BOUNDARY-START(240518692934),
    {
      "t": 524358,
      "n": "RestrictedCodeSid",
      "d": 524358,
      "h": 240518692934,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(240518692934),
//--TRIMMABLE-BOUNDARY-START(257698562118),
    {
      "t": 524358,
      "n": "TerminalServerSid",
      "d": 524358,
      "h": 257698562118,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(257698562118),
//--TRIMMABLE-BOUNDARY-START(236223725638),
    {
      "t": 524358,
      "n": "RemoteLogonIdSid",
      "d": 524358,
      "h": 236223725638,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(236223725638),
//--TRIMMABLE-BOUNDARY-START(197569019974),
    {
      "t": 524358,
      "n": "LogonIdsSid",
      "d": 524358,
      "h": 197569019974,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(197569019974),
//--TRIMMABLE-BOUNDARY-START(193274052678),
    {
      "t": 524358,
      "n": "LocalSystemSid",
      "d": 524358,
      "h": 193274052678,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(193274052678),
//--TRIMMABLE-BOUNDARY-START(184684118086),
    {
      "t": 524358,
      "n": "LocalServiceSid",
      "d": 524358,
      "h": 184684118086,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(184684118086),
//--TRIMMABLE-BOUNDARY-START(206158954566),
    {
      "t": 524358,
      "n": "NetworkServiceSid",
      "d": 524358,
      "h": 206158954566,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(206158954566),
//--TRIMMABLE-BOUNDARY-START(94489804870),
    {
      "t": 524358,
      "n": "BuiltinDomainSid",
      "d": 524358,
      "h": 94489804870,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(94489804870),
//--TRIMMABLE-BOUNDARY-START(81604902982),
    {
      "t": 524358,
      "n": "BuiltinAdministratorsSid",
      "d": 524358,
      "h": 81604902982,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(81604902982),
//--TRIMMABLE-BOUNDARY-START(146029412422),
    {
      "t": 524358,
      "n": "BuiltinUsersSid",
      "d": 524358,
      "h": 146029412422,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(146029412422),
//--TRIMMABLE-BOUNDARY-START(98784772166),
    {
      "t": 524358,
      "n": "BuiltinGuestsSid",
      "d": 524358,
      "h": 98784772166,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(98784772166),
//--TRIMMABLE-BOUNDARY-START(120259608646),
    {
      "t": 524358,
      "n": "BuiltinPowerUsersSid",
      "d": 524358,
      "h": 120259608646,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(120259608646),
//--TRIMMABLE-BOUNDARY-START(77309935686),
    {
      "t": 524358,
      "n": "BuiltinAccountOperatorsSid",
      "d": 524358,
      "h": 77309935686,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(77309935686),
//--TRIMMABLE-BOUNDARY-START(141734445126),
    {
      "t": 524358,
      "n": "BuiltinSystemOperatorsSid",
      "d": 524358,
      "h": 141734445126,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(141734445126),
//--TRIMMABLE-BOUNDARY-START(128849543238),
    {
      "t": 524358,
      "n": "BuiltinPrintOperatorsSid",
      "d": 524358,
      "h": 128849543238,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(128849543238),
//--TRIMMABLE-BOUNDARY-START(90194837574),
    {
      "t": 524358,
      "n": "BuiltinBackupOperatorsSid",
      "d": 524358,
      "h": 90194837574,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(90194837574),
//--TRIMMABLE-BOUNDARY-START(137439477830),
    {
      "t": 524358,
      "n": "BuiltinReplicatorSid",
      "d": 524358,
      "h": 137439477830,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(137439477830),
//--TRIMMABLE-BOUNDARY-START(124554575942),
    {
      "t": 524358,
      "n": "BuiltinPreWindows2000CompatibleAccessSid",
      "d": 524358,
      "h": 124554575942,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(124554575942),
//--TRIMMABLE-BOUNDARY-START(133144510534),
    {
      "t": 524358,
      "n": "BuiltinRemoteDesktopUsersSid",
      "d": 524358,
      "h": 133144510534,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(133144510534),
//--TRIMMABLE-BOUNDARY-START(107374706758),
    {
      "t": 524358,
      "n": "BuiltinNetworkConfigurationOperatorsSid",
      "d": 524358,
      "h": 107374706758,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(107374706758),
//--TRIMMABLE-BOUNDARY-START(8590458950),
    {
      "t": 524358,
      "n": "AccountAdministratorSid",
      "d": 524358,
      "h": 8590458950,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590458950),
//--TRIMMABLE-BOUNDARY-START(42950197318),
    {
      "t": 524358,
      "n": "AccountGuestSid",
      "d": 524358,
      "h": 42950197318,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42950197318),
//--TRIMMABLE-BOUNDARY-START(47245164614),
    {
      "t": 524358,
      "n": "AccountKrbtgtSid",
      "d": 524358,
      "h": 47245164614,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47245164614),
//--TRIMMABLE-BOUNDARY-START(25770328134),
    {
      "t": 524358,
      "n": "AccountDomainAdminsSid",
      "d": 524358,
      "h": 25770328134,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770328134),
//--TRIMMABLE-BOUNDARY-START(34360262726),
    {
      "t": 524358,
      "n": "AccountDomainUsersSid",
      "d": 524358,
      "h": 34360262726,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360262726),
//--TRIMMABLE-BOUNDARY-START(30065295430),
    {
      "t": 524358,
      "n": "AccountDomainGuestsSid",
      "d": 524358,
      "h": 30065295430,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065295430),
//--TRIMMABLE-BOUNDARY-START(17180393542),
    {
      "t": 524358,
      "n": "AccountComputersSid",
      "d": 524358,
      "h": 17180393542,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180393542),
//--TRIMMABLE-BOUNDARY-START(21475360838),
    {
      "t": 524358,
      "n": "AccountControllersSid",
      "d": 524358,
      "h": 21475360838,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475360838),
//--TRIMMABLE-BOUNDARY-START(12885426246),
    {
      "t": 524358,
      "n": "AccountCertAdminsSid",
      "d": 524358,
      "h": 12885426246,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885426246),
//--TRIMMABLE-BOUNDARY-START(60130066502),
    {
      "t": 524358,
      "n": "AccountSchemaAdminsSid",
      "d": 524358,
      "h": 60130066502,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60130066502),
//--TRIMMABLE-BOUNDARY-START(38655230022),
    {
      "t": 524358,
      "n": "AccountEnterpriseAdminsSid",
      "d": 524358,
      "h": 38655230022,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38655230022),
//--TRIMMABLE-BOUNDARY-START(51540131910),
    {
      "t": 524358,
      "n": "AccountPolicyAdminsSid",
      "d": 524358,
      "h": 51540131910,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51540131910),
//--TRIMMABLE-BOUNDARY-START(55835099206),
    {
      "t": 524358,
      "n": "AccountRasAndIasServersSid",
      "d": 524358,
      "h": 55835099206,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55835099206),
//--TRIMMABLE-BOUNDARY-START(219043856454),
    {
      "t": 524358,
      "n": "NtlmAuthenticationSid",
      "d": 524358,
      "h": 219043856454,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(219043856454),
//--TRIMMABLE-BOUNDARY-START(171799216198),
    {
      "t": 524358,
      "n": "DigestAuthenticationSid",
      "d": 524358,
      "h": 171799216198,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(171799216198),
//--TRIMMABLE-BOUNDARY-START(244813660230),
    {
      "t": 524358,
      "n": "SChannelAuthenticationSid",
      "d": 524358,
      "h": 244813660230,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(244813660230),
//--TRIMMABLE-BOUNDARY-START(261993529414),
    {
      "t": 524358,
      "n": "ThisOrganizationSid",
      "d": 524358,
      "h": 261993529414,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(261993529414),
//--TRIMMABLE-BOUNDARY-START(227633791046),
    {
      "t": 524358,
      "n": "OtherOrganizationSid",
      "d": 524358,
      "h": 227633791046,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(227633791046),
//--TRIMMABLE-BOUNDARY-START(103079739462),
    {
      "t": 524358,
      "n": "BuiltinIncomingForestTrustBuildersSid",
      "d": 524358,
      "h": 103079739462,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(103079739462),
//--TRIMMABLE-BOUNDARY-START(115964641350),
    {
      "t": 524358,
      "n": "BuiltinPerformanceMonitoringUsersSid",
      "d": 524358,
      "h": 115964641350,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(115964641350),
//--TRIMMABLE-BOUNDARY-START(111669674054),
    {
      "t": 524358,
      "n": "BuiltinPerformanceLoggingUsersSid",
      "d": 524358,
      "h": 111669674054,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(111669674054),
//--TRIMMABLE-BOUNDARY-START(85899870278),
    {
      "t": 524358,
      "n": "BuiltinAuthorizationAccessSid",
      "d": 524358,
      "h": 85899870278,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(85899870278),
//--TRIMMABLE-BOUNDARY-START(201863987270),
    {
      "t": 524358,
      "n": "MaxDefined",
      "d": 524358,
      "h": 201863987270,
      "f": 4194337,
      "a": [
        {
          "t": 65011713,
          "c": 12949913601,
          "a": [
            {
              "v": 1,
              "t": 65077249
            }
          ]
        },
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "This member has been deprecated and is only maintained for backwards compatability. WellKnownSidType values greater than MaxDefined may be defined in future releases.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(201863987270),
//--TRIMMABLE-BOUNDARY-START(300648235078),
    {
      "t": 524358,
      "n": "WinBuiltinTerminalServerLicenseServersSid",
      "d": 524358,
      "h": 300648235078,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(300648235078),
//--TRIMMABLE-BOUNDARY-START(287763333190),
    {
      "t": 524358,
      "n": "WinBuiltinDCOMUsersSid",
      "d": 524358,
      "h": 287763333190,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(287763333190),
//--TRIMMABLE-BOUNDARY-START(296353267782),
    {
      "t": 524358,
      "n": "WinBuiltinIUsersSid",
      "d": 524358,
      "h": 296353267782,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(296353267782),
//--TRIMMABLE-BOUNDARY-START(369367711814),
    {
      "t": 524358,
      "n": "WinIUserSid",
      "d": 524358,
      "h": 369367711814,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(369367711814),
//--TRIMMABLE-BOUNDARY-START(283468365894),
    {
      "t": 524358,
      "n": "WinBuiltinCryptoOperatorsSid",
      "d": 524358,
      "h": 283468365894,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(283468365894),
//--TRIMMABLE-BOUNDARY-START(408022417478),
    {
      "t": 524358,
      "n": "WinUntrustedLabelSid",
      "d": 524358,
      "h": 408022417478,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(408022417478),
//--TRIMMABLE-BOUNDARY-START(377957646406),
    {
      "t": 524358,
      "n": "WinLowLabelSid",
      "d": 524358,
      "h": 377957646406,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(377957646406),
//--TRIMMABLE-BOUNDARY-START(382252613702),
    {
      "t": 524358,
      "n": "WinMediumLabelSid",
      "d": 524358,
      "h": 382252613702,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(382252613702),
//--TRIMMABLE-BOUNDARY-START(365072744518),
    {
      "t": 524358,
      "n": "WinHighLabelSid",
      "d": 524358,
      "h": 365072744518,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(365072744518),
//--TRIMMABLE-BOUNDARY-START(399432482886),
    {
      "t": 524358,
      "n": "WinSystemLabelSid",
      "d": 524358,
      "h": 399432482886,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(399432482886),
//--TRIMMABLE-BOUNDARY-START(412317384774),
    {
      "t": 524358,
      "n": "WinWriteRestrictedCodeSid",
      "d": 524358,
      "h": 412317384774,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(412317384774),
//--TRIMMABLE-BOUNDARY-START(356482809926),
    {
      "t": 524358,
      "n": "WinCreatorOwnerRightsSid",
      "d": 524358,
      "h": 356482809926,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(356482809926),
//--TRIMMABLE-BOUNDARY-START(304943202374),
    {
      "t": 524358,
      "n": "WinCacheablePrincipalsGroupSid",
      "d": 524358,
      "h": 304943202374,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(304943202374),
//--TRIMMABLE-BOUNDARY-START(395137515590),
    {
      "t": 524358,
      "n": "WinNonCacheablePrincipalsGroupSid",
      "d": 524358,
      "h": 395137515590,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(395137515590),
//--TRIMMABLE-BOUNDARY-START(360777777222),
    {
      "t": 524358,
      "n": "WinEnterpriseReadonlyControllersSid",
      "d": 524358,
      "h": 360777777222,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(360777777222),
//--TRIMMABLE-BOUNDARY-START(266288496710),
    {
      "t": 524358,
      "n": "WinAccountReadonlyControllersSid",
      "d": 524358,
      "h": 266288496710,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(266288496710),
//--TRIMMABLE-BOUNDARY-START(292058300486),
    {
      "t": 524358,
      "n": "WinBuiltinEventLogReadersGroup",
      "d": 524358,
      "h": 292058300486,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(292058300486),
//--TRIMMABLE-BOUNDARY-START(390842548294),
    {
      "t": 524358,
      "n": "WinNewEnterpriseReadonlyControllersSid",
      "d": 524358,
      "h": 390842548294,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(390842548294),
//--TRIMMABLE-BOUNDARY-START(279173398598),
    {
      "t": 524358,
      "n": "WinBuiltinCertSvcDComAccessGroup",
      "d": 524358,
      "h": 279173398598,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(279173398598),
//--TRIMMABLE-BOUNDARY-START(386547580998),
    {
      "t": 524358,
      "n": "WinMediumPlusLabelSid",
      "d": 524358,
      "h": 386547580998,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(386547580998),
//--TRIMMABLE-BOUNDARY-START(373662679110),
    {
      "t": 524358,
      "n": "WinLocalLogonSid",
      "d": 524358,
      "h": 373662679110,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(373662679110),
//--TRIMMABLE-BOUNDARY-START(352187842630),
    {
      "t": 524358,
      "n": "WinConsoleLogonSid",
      "d": 524358,
      "h": 352187842630,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(352187842630),
//--TRIMMABLE-BOUNDARY-START(403727450182),
    {
      "t": 524358,
      "n": "WinThisOrganizationCertificateSid",
      "d": 524358,
      "h": 403727450182,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(403727450182),
//--TRIMMABLE-BOUNDARY-START(270583464006),
    {
      "t": 524358,
      "n": "WinApplicationPackageAuthoritySid",
      "d": 524358,
      "h": 270583464006,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(270583464006),
//--TRIMMABLE-BOUNDARY-START(274878431302),
    {
      "t": 524358,
      "n": "WinBuiltinAnyPackageSid",
      "d": 524358,
      "h": 274878431302,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(274878431302),
//--TRIMMABLE-BOUNDARY-START(322123071558),
    {
      "t": 524358,
      "n": "WinCapabilityInternetClientSid",
      "d": 524358,
      "h": 322123071558,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(322123071558),
//--TRIMMABLE-BOUNDARY-START(317828104262),
    {
      "t": 524358,
      "n": "WinCapabilityInternetClientServerSid",
      "d": 524358,
      "h": 317828104262,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(317828104262),
//--TRIMMABLE-BOUNDARY-START(335007973446),
    {
      "t": 524358,
      "n": "WinCapabilityPrivateNetworkClientServerSid",
      "d": 524358,
      "h": 335007973446,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(335007973446),
//--TRIMMABLE-BOUNDARY-START(330713006150),
    {
      "t": 524358,
      "n": "WinCapabilityPicturesLibrarySid",
      "d": 524358,
      "h": 330713006150,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(330713006150),
//--TRIMMABLE-BOUNDARY-START(347892875334),
    {
      "t": 524358,
      "n": "WinCapabilityVideosLibrarySid",
      "d": 524358,
      "h": 347892875334,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(347892875334),
//--TRIMMABLE-BOUNDARY-START(326418038854),
    {
      "t": 524358,
      "n": "WinCapabilityMusicLibrarySid",
      "d": 524358,
      "h": 326418038854,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(326418038854),
//--TRIMMABLE-BOUNDARY-START(309238169670),
    {
      "t": 524358,
      "n": "WinCapabilityDocumentsLibrarySid",
      "d": 524358,
      "h": 309238169670,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(309238169670),
//--TRIMMABLE-BOUNDARY-START(343597908038),
    {
      "t": 524358,
      "n": "WinCapabilitySharedUserCertificatesSid",
      "d": 524358,
      "h": 343597908038,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(343597908038),
//--TRIMMABLE-BOUNDARY-START(313533136966),
    {
      "t": 524358,
      "n": "WinCapabilityEnterpriseAuthenticationSid",
      "d": 524358,
      "h": 313533136966,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(313533136966),
//--TRIMMABLE-BOUNDARY-START(339302940742),
    {
      "t": 524358,
      "n": "WinCapabilityRemovableStorageSid",
      "d": 524358,
      "h": 339302940742,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(339302940742)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295491654),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 524358,
      "h": 4295491654,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295491654)
  ],
  "h": 524358
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.Principal.WellKnownSidType`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}Principal${separator}WellKnownSidType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524358)
        
        

        //--TRIMMABLE-BOUNDARY-START(589894)
        $asm.$str(`$sspw.SSP.WindowsAccountType`, ($self) => class WindowsAccountType extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Normal = 0;
            static Guest = 1;
            static System = 2;
            static Anonymous = 3;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(589894);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Normal": 0n,
                    "Guest": 1n,
                    "System": 2n,
                    "Anonymous": 3n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295557190)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295557190);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295557190)
            
            //--TRIMMABLE-BOUNDARY-START(4295557190)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295557190)
            
            static $h = 589894;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180459078),
    {
      "t": 589894,
      "n": "Normal",
      "d": 589894,
      "h": 17180459078,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180459078),
//--TRIMMABLE-BOUNDARY-START(12885491782),
    {
      "t": 589894,
      "n": "Guest",
      "d": 589894,
      "h": 12885491782,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885491782),
//--TRIMMABLE-BOUNDARY-START(21475426374),
    {
      "t": 589894,
      "n": "System",
      "d": 589894,
      "h": 21475426374,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475426374),
//--TRIMMABLE-BOUNDARY-START(8590524486),
    {
      "t": 589894,
      "n": "Anonymous",
      "d": 589894,
      "h": 8590524486,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590524486)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295557190),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 589894,
      "h": 4295557190,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295557190)
  ],
  "h": 589894
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.Principal.WindowsAccountType`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}Principal${separator}WindowsAccountType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589894)
        
        

        //--TRIMMABLE-BOUNDARY-START(655430)
        $asm.$str(`$sspw.SSP.WindowsBuiltInRole`, ($self) => class WindowsBuiltInRole extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Administrator = 544;
            static User = 545;
            static Guest = 546;
            static PowerUser = 547;
            static AccountOperator = 548;
            static SystemOperator = 549;
            static PrintOperator = 550;
            static BackupOperator = 551;
            static Replicator = 552;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(655430);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Administrator": 544n,
                    "User": 545n,
                    "Guest": 546n,
                    "PowerUser": 547n,
                    "AccountOperator": 548n,
                    "SystemOperator": 549n,
                    "PrintOperator": 550n,
                    "BackupOperator": 551n,
                    "Replicator": 552n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295622726)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295622726);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295622726)
            
            //--TRIMMABLE-BOUNDARY-START(4295622726)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295622726)
            
            static $h = 655430;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885557318),
    {
      "t": 655430,
      "n": "Administrator",
      "d": 655430,
      "h": 12885557318,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885557318),
//--TRIMMABLE-BOUNDARY-START(42950328390),
    {
      "t": 655430,
      "n": "User",
      "d": 655430,
      "h": 42950328390,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42950328390),
//--TRIMMABLE-BOUNDARY-START(21475491910),
    {
      "t": 655430,
      "n": "Guest",
      "d": 655430,
      "h": 21475491910,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475491910),
//--TRIMMABLE-BOUNDARY-START(25770459206),
    {
      "t": 655430,
      "n": "PowerUser",
      "d": 655430,
      "h": 25770459206,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770459206),
//--TRIMMABLE-BOUNDARY-START(8590590022),
    {
      "t": 655430,
      "n": "AccountOperator",
      "d": 655430,
      "h": 8590590022,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590590022),
//--TRIMMABLE-BOUNDARY-START(38655361094),
    {
      "t": 655430,
      "n": "SystemOperator",
      "d": 655430,
      "h": 38655361094,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38655361094),
//--TRIMMABLE-BOUNDARY-START(30065426502),
    {
      "t": 655430,
      "n": "PrintOperator",
      "d": 655430,
      "h": 30065426502,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065426502),
//--TRIMMABLE-BOUNDARY-START(17180524614),
    {
      "t": 655430,
      "n": "BackupOperator",
      "d": 655430,
      "h": 17180524614,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180524614),
//--TRIMMABLE-BOUNDARY-START(34360393798),
    {
      "t": 655430,
      "n": "Replicator",
      "d": 655430,
      "h": 34360393798,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360393798)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295622726),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 655430,
      "h": 4295622726,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295622726)
  ],
  "h": 655430
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.Principal.WindowsBuiltInRole`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}Principal${separator}WindowsBuiltInRole`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655430)
        
        

        //--TRIMMABLE-BOUNDARY-START(786502)
        $asm.$cls(`$sspw.SSP.WindowsPrincipal`, ($self) => class WindowsPrincipal extends $.$ssc.SSC.ClaimsPrincipal
        {
            //--TRIMMABLE-BOUNDARY-START(4295753798)
            $ctor$7(/*System.Security.Principal.WindowsIdentity*/ ntIdentity)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295753798);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295753798)
            
            //--TRIMMABLE-BOUNDARY-START(8590721094)
            /*System.Collections.Generic.IEnumerable<System.Security.Claims.Claim> */ get DeviceClaims()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180655686);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(8590721094)
            
            //--TRIMMABLE-BOUNDARY-START(38655492166)
            /*System.Security.Principal.IIdentity */ get Identity()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770590278);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(38655492166)
            
            //--TRIMMABLE-BOUNDARY-START(60130328646)
            /*System.Collections.Generic.IEnumerable<System.Security.Claims.Claim> */ get UserClaims()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360524870);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(60130328646)
            
            //--TRIMMABLE-BOUNDARY-START(42950459462)
            /*bool */ IsInRole$1(/*int*/ rid)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950459462);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(42950459462)
            
            //--TRIMMABLE-BOUNDARY-START(47245426758)
            /*bool */ IsInRole$2(/*System.Security.Principal.SecurityIdentifier*/ sid)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245426758);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(47245426758)
            
            //--TRIMMABLE-BOUNDARY-START(51540394054)
            /*bool */ IsInRole$3(/*System.Security.Principal.WindowsBuiltInRole*/ role)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540394054);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(51540394054)
            
            //--TRIMMABLE-BOUNDARY-START(55835361350)
            /*bool */ IsInRole(/*string*/ role)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835361350);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(55835361350)
            
            static $h = 786502;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ssc.SSC.ClaimsPrincipal; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8590721094),
    {
      "p": $.$$.SCG.IEnumerable$$($.$ssc.SSC.Claim).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180655686,
        "f": 50331777
      },
      "n": "DeviceClaims",
      "d": 786502,
      "h": 8590721094,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(8590721094),
//--TRIMMABLE-BOUNDARY-START(38655492166),
    {
      "p": 161939457,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770590278,
        "f": 50364417
      },
      "n": "Identity",
      "d": 786502,
      "h": 38655492166,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(38655492166),
//--TRIMMABLE-BOUNDARY-START(60130328646),
    {
      "p": $.$$.SCG.IEnumerable$$($.$ssc.SSC.Claim).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360524870,
        "f": 50331777
      },
      "n": "UserClaims",
      "d": 786502,
      "h": 60130328646,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(60130328646)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(42950459462),
    {
      "r": 262145,
      "p": [
        {
          "n": "rid",
          "p": 655361
        }
      ],
      "n": "IsInRole",
      "o": "@$1",
      "d": 786502,
      "h": 42950459462,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(42950459462),
//--TRIMMABLE-BOUNDARY-START(47245426758),
    {
      "r": 262145,
      "p": [
        {
          "n": "sid",
          "p": 393286
        }
      ],
      "n": "IsInRole",
      "o": "@$2",
      "d": 786502,
      "h": 47245426758,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(47245426758),
//--TRIMMABLE-BOUNDARY-START(51540394054),
    {
      "r": 262145,
      "p": [
        {
          "n": "role",
          "p": 655430
        }
      ],
      "n": "IsInRole",
      "o": "@$3",
      "d": 786502,
      "h": 51540394054,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(51540394054),
//--TRIMMABLE-BOUNDARY-START(55835361350),
    {
      "r": 262145,
      "p": [
        {
          "n": "role",
          "p": 1310721
        }
      ],
      "n": "IsInRole",
      "d": 786502,
      "h": 55835361350,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(55835361350)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295753798),
    {
      "p": [
        {
          "n": "ntIdentity",
          "p": 720966
        }
      ],
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 786502,
      "h": 4295753798,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295753798)
  ],
  "h": 786502
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SSP$1.IPrincipal ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.Principal.WindowsPrincipal`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}Principal${separator}WindowsPrincipal`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786502)
        
        

        //--TRIMMABLE-BOUNDARY-START(720966)
        $asm.$cls(`$sspw.SSP.WindowsIdentity`, ($self) => class WindowsIdentity extends $.$ssc.SSC.ClaimsIdentity
        {
            //--TRIMMABLE-BOUNDARY-START(51540328518)
            /*string*/ static DefaultIssuer$1 = null;
            //--TRIMMABLE-BOUNDARY-END(51540328518)
            
            //--TRIMMABLE-BOUNDARY-START(17180590150)
            $ctor$20(/*System.IntPtr*/ userToken)
            {
                super.$ctor$9(null, null, null, null, null, 5);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180590150);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180590150)
            
            //--TRIMMABLE-BOUNDARY-START(12885622854)
            $ctor$19(/*System.IntPtr*/ userToken, /*string*/ type)
            {
                super.$ctor$9(null, null, null, null, null, 5);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885622854);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885622854)
            
            //--TRIMMABLE-BOUNDARY-START(8590655558)
            $ctor$18(/*System.IntPtr*/ userToken, /*string*/ type, /*System.Security.Principal.WindowsAccountType*/ acctType)
            {
                super.$ctor$9(null, null, null, null, null, 5);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590655558);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590655558)
            
            //--TRIMMABLE-BOUNDARY-START(4295688262)
            $ctor$17(/*System.IntPtr*/ userToken, /*string*/ type, /*System.Security.Principal.WindowsAccountType*/ acctType, /*bool*/ isAuthenticated)
            {
                super.$ctor$9(null, null, null, null, null, 5);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295688262);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295688262)
            
            //--TRIMMABLE-BOUNDARY-START(21475557446)
            $ctor$21(/*System.Runtime.Serialization.SerializationInfo*/ info, /*System.Runtime.Serialization.StreamingContext*/ context)
            {
                super.$ctor$9(null, null, null, null, null, 5);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475557446);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475557446)
            
            //--TRIMMABLE-BOUNDARY-START(30065492038)
            $ctor$23(/*System.Security.Principal.WindowsIdentity*/ identity)
            {
                super.$ctor$9(null, null, null, null, null, 5);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065492038);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065492038)
            
            //--TRIMMABLE-BOUNDARY-START(25770524742)
            $ctor$22(/*string*/ sUserPrincipalName)
            {
                super.$ctor$9(null, null, null, null, null, 5);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770524742);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770524742)
            
            //--TRIMMABLE-BOUNDARY-START(34360459334)
            /*Microsoft.Win32.SafeHandles.SafeAccessTokenHandle */ get AccessToken()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015164998);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(34360459334)
            
            //--TRIMMABLE-BOUNDARY-START(38655426630)
            /*string? */ get AuthenticationType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605099590);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(38655426630)
            
            //--TRIMMABLE-BOUNDARY-START(42950393926)
            /*System.Collections.Generic.IEnumerable<System.Security.Claims.Claim> */ get Claims()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195034182);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(42950393926)
            
            //--TRIMMABLE-BOUNDARY-START(55835295814)
            /*System.Collections.Generic.IEnumerable<System.Security.Claims.Claim> */ get DeviceClaims()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784968774);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(55835295814)
            
            //--TRIMMABLE-BOUNDARY-START(214749085766)
            /*System.Security.Principal.IdentityReferenceCollection? */ get Groups()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374903366);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(214749085766)
            
            //--TRIMMABLE-BOUNDARY-START(219044053062)
            /*System.Security.Principal.TokenImpersonationLevel */ get ImpersonationLevel()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964837958);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(219044053062)
            
            //--TRIMMABLE-BOUNDARY-START(223339020358)
            /*bool */ get IsAnonymous()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554772550);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(223339020358)
            
            //--TRIMMABLE-BOUNDARY-START(227633987654)
            /*bool */ get IsAuthenticated()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144707142);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(227633987654)
            
            //--TRIMMABLE-BOUNDARY-START(231928954950)
            /*bool */ get IsGuest()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734641734);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(231928954950)
            
            //--TRIMMABLE-BOUNDARY-START(236223922246)
            /*bool */ get IsSystem()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324576326);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(236223922246)
            
            //--TRIMMABLE-BOUNDARY-START(240518889542)
            /*string */ get Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914510918);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(240518889542)
            
            //--TRIMMABLE-BOUNDARY-START(244813856838)
            /*System.Security.Principal.SecurityIdentifier? */ get Owner()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504445510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(244813856838)
            
            //--TRIMMABLE-BOUNDARY-START(274878627910)
            /*System.IntPtr */ get Token()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094380102);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(274878627910)
            
            //--TRIMMABLE-BOUNDARY-START(279173595206)
            /*System.Security.Principal.SecurityIdentifier? */ get User()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184684314694);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(279173595206)
            
            //--TRIMMABLE-BOUNDARY-START(283468562502)
            /*System.Collections.Generic.IEnumerable<System.Security.Claims.Claim> */ get UserClaims()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193274249286);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(283468562502)
            
            //--TRIMMABLE-BOUNDARY-START(47245361222)
            /*System.Security.Claims.ClaimsIdentity */ Clone()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245361222);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(47245361222)
            
            //--TRIMMABLE-BOUNDARY-START(60130263110)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130263110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(60130263110)
            
            //--TRIMMABLE-BOUNDARY-START(64425230406)
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425230406);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(64425230406)
            
            //--TRIMMABLE-BOUNDARY-START(197569216582)
            static /*System.Security.Principal.WindowsIdentity */ GetAnonymous()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197569216582);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(197569216582)
            
            //--TRIMMABLE-BOUNDARY-START(201864183878)
            static /*System.Security.Principal.WindowsIdentity */ GetCurrent()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201864183878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(201864183878)
            
            //--TRIMMABLE-BOUNDARY-START(206159151174)
            static /*System.Security.Principal.WindowsIdentity? */ GetCurrent$1(/*bool*/ ifImpersonating)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206159151174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(206159151174)
            
            //--TRIMMABLE-BOUNDARY-START(210454118470)
            static /*System.Security.Principal.WindowsIdentity */ GetCurrent$2(/*System.Security.Principal.TokenAccessLevels*/ desiredAccess)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210454118470);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(210454118470)
            
            //--TRIMMABLE-BOUNDARY-START(249108824134)
            static /*void */ RunImpersonated(/*Microsoft.Win32.SafeHandles.SafeAccessTokenHandle*/ safeAccessTokenHandle, /*System.Action*/ action)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249108824134);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(249108824134)
            
            //--TRIMMABLE-BOUNDARY-START(257698758726)
            static /*System.Threading.Tasks.Task */ RunImpersonatedAsync(/*Microsoft.Win32.SafeHandles.SafeAccessTokenHandle*/ safeAccessTokenHandle, /*System.Func<System.Threading.Tasks.Task>*/ func)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257698758726);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(257698758726)
            
            //--TRIMMABLE-BOUNDARY-START(261993726022)
            static /*System.Threading.Tasks.Task<T> */ RunImpersonatedAsync$1(T, /*Microsoft.Win32.SafeHandles.SafeAccessTokenHandle*/ safeAccessTokenHandle, /*System.Func<System.Threading.Tasks.Task<T>>*/ func)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261993726022);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(261993726022)
            
            //--TRIMMABLE-BOUNDARY-START(253403791430)
            static /*T */ RunImpersonated$1(T, /*Microsoft.Win32.SafeHandles.SafeAccessTokenHandle*/ safeAccessTokenHandle, /*System.Func<T>*/ func)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253403791430);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(253403791430)
            
            //--TRIMMABLE-BOUNDARY-START(266288693318)
            /*void */ SRS$IDeserializationCallback$OnDeserialization(/*object?*/ sender)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266288693318);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(266288693318)
            
            //--TRIMMABLE-BOUNDARY-START(270583660614)
            /*void */ SRS$ISerializable$GetObjectData(/*System.Runtime.Serialization.SerializationInfo*/ info, /*System.Runtime.Serialization.StreamingContext*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270583660614);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(270583660614)
            
            //--TRIMMABLE-BOUNDARY-START(4386062337)
            //Generated interface implemetation for System.IDisposable.Dispose()
            S$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386062337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386062337)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(51540328518)
                    this.DefaultIssuer$1 = "AD AUTHORITY";
                    //--TRIMMABLE-BOUNDARY-END(51540328518)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 720966;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ssc.SSC.ClaimsIdentity; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360459334),
    {
      "p": 65606,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015164998,
        "f": 50331649
      },
      "n": "AccessToken",
      "d": 720966,
      "h": 34360459334,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360459334),
//--TRIMMABLE-BOUNDARY-START(38655426630),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605099590,
        "f": 50429953
      },
      "n": "AuthenticationType",
      "d": 720966,
      "h": 38655426630,
      "f": 2195457
    },
//--TRIMMABLE-BOUNDARY-END(38655426630),
//--TRIMMABLE-BOUNDARY-START(42950393926),
    {
      "p": $.$$.SCG.IEnumerable$$($.$ssc.SSC.Claim).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195034182,
        "f": 50364417
      },
      "n": "Claims",
      "d": 720966,
      "h": 42950393926,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(42950393926),
//--TRIMMABLE-BOUNDARY-START(55835295814),
    {
      "p": $.$$.SCG.IEnumerable$$($.$ssc.SSC.Claim).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784968774,
        "f": 50331777
      },
      "n": "DeviceClaims",
      "d": 720966,
      "h": 55835295814,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(55835295814),
//--TRIMMABLE-BOUNDARY-START(214749085766),
    {
      "p": 262214,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374903366,
        "f": 50331649
      },
      "n": "Groups",
      "d": 720966,
      "h": 214749085766,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(214749085766),
//--TRIMMABLE-BOUNDARY-START(219044053062),
    {
      "p": 162136065,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964837958,
        "f": 50331649
      },
      "n": "ImpersonationLevel",
      "d": 720966,
      "h": 219044053062,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(219044053062),
//--TRIMMABLE-BOUNDARY-START(223339020358),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554772550,
        "f": 50331777
      },
      "n": "IsAnonymous",
      "d": 720966,
      "h": 223339020358,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(223339020358),
//--TRIMMABLE-BOUNDARY-START(227633987654),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133144707142,
        "f": 50364417
      },
      "n": "IsAuthenticated",
      "d": 720966,
      "h": 227633987654,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(227633987654),
//--TRIMMABLE-BOUNDARY-START(231928954950),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141734641734,
        "f": 50331777
      },
      "n": "IsGuest",
      "d": 720966,
      "h": 231928954950,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(231928954950),
//--TRIMMABLE-BOUNDARY-START(236223922246),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150324576326,
        "f": 50331777
      },
      "n": "IsSystem",
      "d": 720966,
      "h": 236223922246,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(236223922246),
//--TRIMMABLE-BOUNDARY-START(240518889542),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158914510918,
        "f": 50364417
      },
      "n": "Name",
      "d": 720966,
      "h": 240518889542,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(240518889542),
//--TRIMMABLE-BOUNDARY-START(244813856838),
    {
      "p": 393286,
      "g": {
        "r": 0,
        "d": 0,
        "h": 167504445510,
        "f": 50331649
      },
      "n": "Owner",
      "d": 720966,
      "h": 244813856838,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(244813856838),
//--TRIMMABLE-BOUNDARY-START(274878627910),
    {
      "p": 786433,
      "g": {
        "r": 0,
        "d": 0,
        "h": 176094380102,
        "f": 50331777
      },
      "n": "Token",
      "d": 720966,
      "h": 274878627910,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(274878627910),
//--TRIMMABLE-BOUNDARY-START(279173595206),
    {
      "p": 393286,
      "g": {
        "r": 0,
        "d": 0,
        "h": 184684314694,
        "f": 50331649
      },
      "n": "User",
      "d": 720966,
      "h": 279173595206,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(279173595206),
//--TRIMMABLE-BOUNDARY-START(283468562502),
    {
      "p": $.$$.SCG.IEnumerable$$($.$ssc.SSC.Claim).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 193274249286,
        "f": 50331777
      },
      "n": "UserClaims",
      "d": 720966,
      "h": 283468562502,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(283468562502)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(47245361222),
    {
      "r": 262213,
      "n": "Clone",
      "d": 720966,
      "h": 47245361222,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47245361222),
//--TRIMMABLE-BOUNDARY-START(60130263110),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 720966,
      "h": 60130263110,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60130263110),
//--TRIMMABLE-BOUNDARY-START(64425230406),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposing",
          "p": 262145
        }
      ],
      "n": "Dispose",
      "o": "@$1",
      "d": 720966,
      "h": 64425230406,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(64425230406),
//--TRIMMABLE-BOUNDARY-START(197569216582),
    {
      "r": 720966,
      "n": "GetAnonymous",
      "d": 720966,
      "h": 197569216582,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(197569216582),
//--TRIMMABLE-BOUNDARY-START(201864183878),
    {
      "r": 720966,
      "n": "GetCurrent",
      "d": 720966,
      "h": 201864183878,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(201864183878),
//--TRIMMABLE-BOUNDARY-START(206159151174),
    {
      "r": 720966,
      "p": [
        {
          "n": "ifImpersonating",
          "p": 262145
        }
      ],
      "n": "GetCurrent",
      "o": "@$1",
      "d": 720966,
      "h": 206159151174,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(206159151174),
//--TRIMMABLE-BOUNDARY-START(210454118470),
    {
      "r": 720966,
      "p": [
        {
          "n": "desiredAccess",
          "p": 458822
        }
      ],
      "n": "GetCurrent",
      "o": "@$2",
      "d": 720966,
      "h": 210454118470,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(210454118470),
//--TRIMMABLE-BOUNDARY-START(249108824134),
    {
      "r": 65537,
      "p": [
        {
          "n": "safeAccessTokenHandle",
          "p": 65606
        },
        {
          "n": "action",
          "p": 43122689
        }
      ],
      "n": "RunImpersonated",
      "d": 720966,
      "h": 249108824134,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(249108824134),
//--TRIMMABLE-BOUNDARY-START(257698758726),
    {
      "r": 178454529,
      "p": [
        {
          "n": "safeAccessTokenHandle",
          "p": 65606
        },
        {
          "n": "func",
          "p": $.$$.S.Func$$($.$$.STT.Task).$h
        }
      ],
      "n": "RunImpersonatedAsync",
      "d": 720966,
      "h": 257698758726,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(257698758726),
//--TRIMMABLE-BOUNDARY-START(261993726022),
    {
      "r": (T) => $.$$.STT.Task$$(T).$h,
      "p": [
        {
          "n": "safeAccessTokenHandle",
          "p": 65606
        },
        {
          "n": "func",
          "p": (T) => $.$$.S.Func$$($.$$.STT.Task$$(T)).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "RunImpersonatedAsync",
      "o": "@$1",
      "d": 720966,
      "h": 261993726022,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(261993726022),
//--TRIMMABLE-BOUNDARY-START(253403791430),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "safeAccessTokenHandle",
          "p": 65606
        },
        {
          "n": "func",
          "p": (T) => $.$$.S.Func$$(T).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "RunImpersonated",
      "o": "@$1",
      "d": 720966,
      "h": 253403791430,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(253403791430)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(51540328518),
    {
      "t": 1310721,
      "n": "DefaultIssuer",
      "o": "@$1",
      "d": 720966,
      "h": 51540328518,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51540328518)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180590150),
    {
      "p": [
        {
          "n": "userToken",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$20",
      "d": 720966,
      "h": 17180590150,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180590150),
//--TRIMMABLE-BOUNDARY-START(12885622854),
    {
      "p": [
        {
          "n": "userToken",
          "p": 786433
        },
        {
          "n": "type",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$19",
      "d": 720966,
      "h": 12885622854,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885622854),
//--TRIMMABLE-BOUNDARY-START(8590655558),
    {
      "p": [
        {
          "n": "userToken",
          "p": 786433
        },
        {
          "n": "type",
          "p": 1310721
        },
        {
          "n": "acctType",
          "p": 589894
        }
      ],
      "n": ".ctor",
      "o": "$ctor$18",
      "d": 720966,
      "h": 8590655558,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590655558),
//--TRIMMABLE-BOUNDARY-START(4295688262),
    {
      "p": [
        {
          "n": "userToken",
          "p": 786433
        },
        {
          "n": "type",
          "p": 1310721
        },
        {
          "n": "acctType",
          "p": 589894
        },
        {
          "n": "isAuthenticated",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$17",
      "d": 720966,
      "h": 4295688262,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295688262),
//--TRIMMABLE-BOUNDARY-START(21475557446),
    {
      "p": [
        {
          "n": "info",
          "p": 158859265
        },
        {
          "n": "context",
          "p": 158990337
        }
      ],
      "n": ".ctor",
      "o": "$ctor$21",
      "d": 720966,
      "h": 21475557446,
      "f": 16777217,
      "a": [
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "DiagnosticId",
              "v": "SYSLIB0051",
              "t": 1310721
            },
            {
              "n": "UrlFormat",
              "v": "https://aka.ms/dotnet-warnings/{0}",
              "t": 1310721
            }
          ]
        },
        {
          "t": 65011713,
          "c": 12949913601,
          "a": [
            {
              "v": 1,
              "t": 65077249
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475557446),
//--TRIMMABLE-BOUNDARY-START(30065492038),
    {
      "p": [
        {
          "n": "identity",
          "p": 720966
        }
      ],
      "n": ".ctor",
      "o": "$ctor$23",
      "d": 720966,
      "h": 30065492038,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(30065492038),
//--TRIMMABLE-BOUNDARY-START(25770524742),
    {
      "p": [
        {
          "n": "sUserPrincipalName",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$22",
      "d": 720966,
      "h": 25770524742,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770524742)
  ],
  "h": 720966
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SSP$1.IIdentity, $.$$.S.IDisposable, $.$$.SRS.IDeserializationCallback, $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.Principal.WindowsIdentity`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}Principal${separator}WindowsIdentity`; }
        });
        //--TRIMMABLE-BOUNDARY-END(720966)
        
        

        //--TRIMMABLE-BOUNDARY-START(131142)
        $asm.$cls(`$sspw.SSP.IdentityNotMappedException`, ($self) => class IdentityNotMappedException extends $.$$.S.SystemException
        {
            //--TRIMMABLE-BOUNDARY-START(4295098438)
            $ctor$9()
            {
                super.$ctor$5();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295098438);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295098438)
            
            //--TRIMMABLE-BOUNDARY-START(12885033030)
            $ctor$11(/*string?*/ message)
            {
                super.$ctor$5();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885033030);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885033030)
            
            //--TRIMMABLE-BOUNDARY-START(8590065734)
            $ctor$10(/*string?*/ message, /*System.Exception?*/ inner)
            {
                super.$ctor$5();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590065734);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590065734)
            
            //--TRIMMABLE-BOUNDARY-START(30064902214)
            /*System.Security.Principal.IdentityReferenceCollection */ get UnmappedIdentities()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21474967622);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(30064902214)
            
            //--TRIMMABLE-BOUNDARY-START(25769934918)
            /*void */ GetObjectData(/*System.Runtime.Serialization.SerializationInfo*/ serializationInfo, /*System.Runtime.Serialization.StreamingContext*/ streamingContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25769934918);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(25769934918)
            
            //--TRIMMABLE-BOUNDARY-START(4295098438)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(4295098438)
            
            static $h = 131142;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.SystemException; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 131142
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.Principal.IdentityNotMappedException`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}Principal${separator}IdentityNotMappedException`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131142)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Threading.Thread", "NetJs.System.Security.Claims"));
})();
//--TRIMMABLE-BOUNDARY-END(70)
