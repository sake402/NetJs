
(function ($global, $, $spc, $mwp, $sc, $sdt, $sm, $spu, $st, $stt, $sr, $scc, $ssc, $sris) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Security.Principal.Windows", 
    {"h":41860,"f":"System.Security.Principal.Windows","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bbeaaf5d41a0179d1ed930cf3efa03ea73d37a2ca","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Security.Principal.Windows","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Security.Principal.Windows","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sspw.System.Security.Principal.IdentityReference", ($self) => class IdentityReference extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static /*bool */ op_Equality(/*System.Security.Principal.IdentityReference?*/ left, /*System.Security.Principal.IdentityReference?*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ op_Inequality(/*System.Security.Principal.IdentityReference?*/ left, /*System.Security.Principal.IdentityReference?*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 238468;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12885140356,"f":257},"n":"Value","d":238468,"h":8590173060,"f":257}],"m":[{"r":262145,"p":[{"n":"o","p":131073}],"n":"Equals","d":238468,"h":17180107652,"f":33025},{"r":655361,"n":"GetHashCode","d":238468,"h":21475074948,"f":33025},{"r":262145,"p":[{"n":"targetType","p":142606337}],"n":"IsValidTargetType","d":238468,"h":25770042244,"f":257},{"r":1310721,"n":"ToString","d":238468,"h":38654944132,"f":33025},{"r":238468,"p":[{"n":"targetType","p":142606337}],"n":"Translate","d":238468,"h":42949911428,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":238468,"h":4295205764,"f":8}],"h":238468}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Security.Principal.IdentityReference`; }
        });
        
        $asm.$cls("$sspw.System.Security.Principal.IdentityReferenceCollection", ($self) => class IdentityReferenceCollection extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*int*/ capacity)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get Count()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IdentityReference*/ get_Item(/*int*/ index)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void*/ set_Item(/*int*/ index, /*System.Security.Principal.IdentityReference*/ value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get System$Collections$Generic$ICollection$$$IsReadOnly()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Add(/*System.Security.Principal.IdentityReference*/ identity)
            {
            }
            /*void */ Clear()
            {
            }
            /*bool */ Contains(/*System.Security.Principal.IdentityReference*/ identity)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CopyTo(/*System.Security.Principal.IdentityReference[]*/ array, /*int*/ offset)
            {
            }
            /*System.Collections.Generic.IEnumerator<System.Security.Principal.IdentityReference> */ GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Remove(/*System.Security.Principal.IdentityReference*/ identity)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IdentityReferenceCollection */ Translate(/*System.Type*/ targetType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IdentityReferenceCollection */ Translate$1(/*System.Type*/ targetType, /*bool*/ forceSuccess)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Security.Principal.IdentityReference>.Count.get
            get System$Collections$Generic$ICollection$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Security.Principal.IdentityReference>.Add(System.Security.Principal.IdentityReference)
            System$Collections$Generic$ICollection$$$Add()
            {
                return this.Add(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Security.Principal.IdentityReference>.Clear()
            System$Collections$Generic$ICollection$$$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Security.Principal.IdentityReference>.Contains(System.Security.Principal.IdentityReference)
            System$Collections$Generic$ICollection$$$Contains()
            {
                return this.Contains(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Security.Principal.IdentityReference>.CopyTo(System.Security.Principal.IdentityReference[], int)
            System$Collections$Generic$ICollection$$$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Security.Principal.IdentityReference>.Remove(System.Security.Principal.IdentityReference)
            System$Collections$Generic$ICollection$$$Remove()
            {
                return this.Remove(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Security.Principal.IdentityReference>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 304004;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":17180173188,"f":1},"n":"Count","d":304004,"h":12885205892,"f":1},{"p":238468,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":25770107780,"f":1},"s":{"r":0,"d":0,"h":30065075076,"f":1},"n":"Item","o":"@$2","d":304004,"h":21475140484,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":38655009668,"f":2},"n":"{$.$spc.System.Collections.Generic.ICollection$$($.$sspw.System.Security.Principal.IdentityReference).$h}.IsReadOnly","o":"System$Collections$Generic$ICollection$$$IsReadOnly","d":304004,"h":34360042372,"f":2}],"m":[{"r":65537,"p":[{"n":"identity","p":238468}],"n":"Add","d":304004,"h":42949976964,"f":1},{"r":65537,"n":"Clear","d":304004,"h":47244944260,"f":1},{"r":262145,"p":[{"n":"identity","p":238468}],"n":"Contains","d":304004,"h":51539911556,"f":1},{"r":65537,"p":[{"n":"array","p":0},{"n":"offset","p":655361}],"n":"CopyTo","d":304004,"h":55834878852,"f":1},{"r":$.$spc.System.Collections.Generic.IEnumerator$$($.$sspw.System.Security.Principal.IdentityReference).$h,"n":"GetEnumerator","d":304004,"h":60129846148,"f":1},{"r":262145,"p":[{"n":"identity","p":238468}],"n":"Remove","d":304004,"h":64424813444,"f":1},{"r":304004,"p":[{"n":"targetType","p":142606337}],"n":"Translate","d":304004,"h":73014748036,"f":1},{"r":304004,"p":[{"n":"targetType","p":142606337},{"n":"forceSuccess","p":262145}],"n":"Translate","o":"@$1","d":304004,"h":77309715332,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":304004,"h":4295271300,"f":1},{"p":[{"n":"capacity","p":655361}],"n":".ctor","o":"$ctor$2","d":304004,"h":8590238596,"f":1}],"i":[$.$spc.System.Collections.Generic.ICollection$$($.$sspw.System.Security.Principal.IdentityReference).$h,$.$spc.System.Collections.Generic.IEnumerable$$($.$sspw.System.Security.Principal.IdentityReference).$h,31588353],"h":304004}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.ICollection$$($.$sspw.System.Security.Principal.IdentityReference), $.$spc.System.Collections.Generic.IEnumerable$$($.$sspw.System.Security.Principal.IdentityReference), $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Security.Principal.IdentityReferenceCollection`; }
        });
        
        $asm.$cls("$sspw.System.Security.Principal.NTAccount", ($self) => class NTAccount extends $.$sspw.System.Security.Principal.IdentityReference
        {
            $ctor$2(/*string*/ name)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$3(/*string*/ domainName, /*string*/ accountName)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*string */ get Value()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ o)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sspw.System.Security.Principal.NTAccount.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sspw.System.Security.Principal.NTAccount.GetHashCode.apply(this, arguments); }
            /*bool */ IsValidTargetType(/*System.Type*/ targetType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ op_Equality$1(/*System.Security.Principal.NTAccount?*/ left, /*System.Security.Principal.NTAccount?*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ op_Inequality$1(/*System.Security.Principal.NTAccount?*/ left, /*System.Security.Principal.NTAccount?*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sspw.System.Security.Principal.NTAccount.ToString.apply(this, arguments); }
            /*System.Security.Principal.IdentityReference */ Translate(/*System.Type*/ targetType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 369540;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":238468,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17180238724,"f":32769},"n":"Value","d":369540,"h":12885271428,"f":32769}],"m":[{"r":262145,"p":[{"n":"o","p":131073}],"n":"Equals","d":369540,"h":21475206020,"f":32769},{"r":655361,"n":"GetHashCode","d":369540,"h":25770173316,"f":32769},{"r":262145,"p":[{"n":"targetType","p":142606337}],"n":"IsValidTargetType","d":369540,"h":30065140612,"f":32769},{"r":1310721,"n":"ToString","d":369540,"h":42950042500,"f":32769},{"r":238468,"p":[{"n":"targetType","p":142606337}],"n":"Translate","d":369540,"h":47245009796,"f":32769}],"c":[{"p":[{"n":"name","p":1310721}],"n":".ctor","o":"$ctor$2","d":369540,"h":4295336836,"f":1},{"p":[{"n":"domainName","p":1310721},{"n":"accountName","p":1310721}],"n":".ctor","o":"$ctor$3","d":369540,"h":8590304132,"f":1}],"h":369540}; }
            static get $b() { return $.$sspw.System.Security.Principal.IdentityReference; }
            static get $fullName() { return `System.Security.Principal.NTAccount`; }
        });
        
        $asm.$cls("$sspw.System.Security.Principal.SecurityIdentifier", ($self) => class SecurityIdentifier extends $.$sspw.System.Security.Principal.IdentityReference
        {
            /*int*/ static MaxBinaryLength = 0;
            /*int*/ static MinBinaryLength = 0;
            $ctor$2(/*byte[]*/ binaryForm, /*int*/ offset)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$3(/*System.IntPtr*/ binaryForm)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$4(/*System.Security.Principal.WellKnownSidType*/ sidType, /*System.Security.Principal.SecurityIdentifier?*/ domainSid)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$5(/*string*/ sddlForm)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Security.Principal.SecurityIdentifier? */ get AccountDomainSid()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get BinaryLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Value()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ CompareTo(/*System.Security.Principal.SecurityIdentifier?*/ sid)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ o)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sspw.System.Security.Principal.SecurityIdentifier.Equals.apply(this, arguments); }
            /*bool */ Equals$2(/*System.Security.Principal.SecurityIdentifier*/ sid)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sspw.System.Security.Principal.SecurityIdentifier.GetHashCode.apply(this, arguments); }
            /*bool */ IsAccountSid()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ IsEqualDomainSid(/*System.Security.Principal.SecurityIdentifier*/ sid)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ IsValidTargetType(/*System.Type*/ targetType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ IsWellKnown(/*System.Security.Principal.WellKnownSidType*/ type)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ op_Equality$1(/*System.Security.Principal.SecurityIdentifier?*/ left, /*System.Security.Principal.SecurityIdentifier?*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ op_Inequality$1(/*System.Security.Principal.SecurityIdentifier?*/ left, /*System.Security.Principal.SecurityIdentifier?*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sspw.System.Security.Principal.SecurityIdentifier.ToString.apply(this, arguments); }
            /*System.Security.Principal.IdentityReference */ Translate(/*System.Type*/ targetType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.IComparable<System.Security.Principal.SecurityIdentifier>.CompareTo(System.Security.Principal.SecurityIdentifier?)
            System$IComparable$$$CompareTo()
            {
                return this.CompareTo(...arguments);
            }
            static $h = 435076;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":238468,"p":[{"p":435076,"g":{"r":0,"d":0,"h":34360173444,"f":1},"n":"AccountDomainSid","d":435076,"h":30065206148,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":42950108036,"f":1},"n":"BinaryLength","d":435076,"h":38655140740,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":51540042628,"f":32769},"n":"Value","d":435076,"h":47245075332,"f":32769}],"m":[{"r":655361,"p":[{"n":"sid","p":435076}],"n":"CompareTo","d":435076,"h":55835009924,"f":1},{"r":262145,"p":[{"n":"o","p":131073}],"n":"Equals","d":435076,"h":60129977220,"f":32769},{"r":262145,"p":[{"n":"sid","p":435076}],"n":"Equals","o":"@$2","d":435076,"h":64424944516,"f":1},{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":435076,"h":68719911812,"f":1},{"r":655361,"n":"GetHashCode","d":435076,"h":73014879108,"f":32769},{"r":262145,"n":"IsAccountSid","d":435076,"h":77309846404,"f":1},{"r":262145,"p":[{"n":"sid","p":435076}],"n":"IsEqualDomainSid","d":435076,"h":81604813700,"f":1},{"r":262145,"p":[{"n":"targetType","p":142606337}],"n":"IsValidTargetType","d":435076,"h":85899780996,"f":32769},{"r":262145,"p":[{"n":"type","p":566148}],"n":"IsWellKnown","d":435076,"h":90194748292,"f":1},{"r":1310721,"n":"ToString","d":435076,"h":103079650180,"f":32769},{"r":238468,"p":[{"n":"targetType","p":142606337}],"n":"Translate","d":435076,"h":107374617476,"f":32769}],"l":[{"t":655361,"n":"MaxBinaryLength","d":435076,"h":4295402372,"f":33},{"t":655361,"n":"MinBinaryLength","d":435076,"h":8590369668,"f":33}],"c":[{"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":".ctor","o":"$ctor$2","d":435076,"h":12885336964,"f":1},{"p":[{"n":"binaryForm","p":786433}],"n":".ctor","o":"$ctor$3","d":435076,"h":17180304260,"f":1},{"p":[{"n":"sidType","p":566148},{"n":"domainSid","p":435076}],"n":".ctor","o":"$ctor$4","d":435076,"h":21475271556,"f":1},{"p":[{"n":"sddlForm","p":1310721}],"n":".ctor","o":"$ctor$5","d":435076,"h":25770238852,"f":1}],"i":[$.$spc.System.IComparable$$($.$sspw.System.Security.Principal.SecurityIdentifier).$h],"h":435076}; }
            static get $b() { return $.$sspw.System.Security.Principal.IdentityReference; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable$$($.$sspw.System.Security.Principal.SecurityIdentifier) ]; }
            static get $fullName() { return `System.Security.Principal.SecurityIdentifier`; }
        });
        
        $asm.$cls("$sspw.Microsoft.Win32.SafeHandles.SafeAccessTokenHandle", ($self) => class SafeAccessTokenHandle extends $.$spc.System.Runtime.InteropServices.SafeHandle
        {
            $ctor$3()
            {
                super.$ctor$2(0, false);
                {
                }
                return this;
            }
            $ctor$4(/*System.IntPtr*/ handle)
            {
                super.$ctor$2(0, false);
                {
                }
                return this;
            }
            static /*Microsoft.Win32.SafeHandles.SafeAccessTokenHandle */ get InvalidHandle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsInvalid()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ReleaseHandle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 107396;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":109576193,"p":[{"p":107396,"g":{"r":0,"d":0,"h":17179976580,"f":33},"n":"InvalidHandle","d":107396,"h":12885009284,"f":33},{"p":262145,"g":{"r":0,"d":0,"h":25769911172,"f":32769},"n":"IsInvalid","d":107396,"h":21474943876,"f":32769}],"m":[{"r":262145,"n":"ReleaseHandle","d":107396,"h":30064878468,"f":32772}],"c":[{"n":".ctor","o":"$ctor$3","d":107396,"h":4295074692,"f":1},{"p":[{"n":"handle","p":786433}],"n":".ctor","o":"$ctor$4","d":107396,"h":8590041988,"f":1}],"i":[57475073],"h":107396}; }
            static get $b() { return $.$spc.System.Runtime.InteropServices.SafeHandle; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Win32.SafeHandles.SafeAccessTokenHandle`; }
        });
        
        $asm.$str("$sspw.System.Security.Principal.TokenAccessLevels", ($self) => class TokenAccessLevels extends $.$spc.System.Enum
        {
            static AssignPrimary = 1;
            static Duplicate = 2;
            static Impersonate = 4;
            static Query = 8;
            static QuerySource = 16;
            static AdjustPrivileges = 32;
            static AdjustGroups = 64;
            static AdjustDefault = 128;
            static AdjustSessionId = 256;
            static Read = 131080;
            static Write = 131296;
            static AllAccess = 983551;
            static MaximumAllowed = 33554432;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "AssignPrimary": 1n,
                    "Duplicate": 2n,
                    "Impersonate": 4n,
                    "Query": 8n,
                    "QuerySource": 16n,
                    "AdjustPrivileges": 32n,
                    "AdjustGroups": 64n,
                    "AdjustDefault": 128n,
                    "AdjustSessionId": 256n,
                    "Read": 131080n,
                    "Write": 131296n,
                    "AllAccess": 983551n,
                    "MaximumAllowed": 33554432n
                };
            }
            static $h = 500612;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":500612,"n":"AssignPrimary","d":500612,"h":4295467908,"f":33},{"t":500612,"n":"Duplicate","d":500612,"h":8590435204,"f":33},{"t":500612,"n":"Impersonate","d":500612,"h":12885402500,"f":33},{"t":500612,"n":"Query","d":500612,"h":17180369796,"f":33},{"t":500612,"n":"QuerySource","d":500612,"h":21475337092,"f":33},{"t":500612,"n":"AdjustPrivileges","d":500612,"h":25770304388,"f":33},{"t":500612,"n":"AdjustGroups","d":500612,"h":30065271684,"f":33},{"t":500612,"n":"AdjustDefault","d":500612,"h":34360238980,"f":33},{"t":500612,"n":"AdjustSessionId","d":500612,"h":38655206276,"f":33},{"t":500612,"n":"Read","d":500612,"h":42950173572,"f":33},{"t":500612,"n":"Write","d":500612,"h":47245140868,"f":33},{"t":500612,"n":"AllAccess","d":500612,"h":51540108164,"f":33},{"t":500612,"n":"MaximumAllowed","d":500612,"h":55835075460,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":500612,"h":60130042756,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":500612,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.Principal.TokenAccessLevels`; }
        });
        
        $asm.$str("$sspw.System.Security.Principal.WellKnownSidType", ($self) => class WellKnownSidType extends $.$spc.System.Enum
        {
            static NullSid = 0;
            static WorldSid = 1;
            static LocalSid = 2;
            static CreatorOwnerSid = 3;
            static CreatorGroupSid = 4;
            static CreatorOwnerServerSid = 5;
            static CreatorGroupServerSid = 6;
            static NTAuthoritySid = 7;
            static DialupSid = 8;
            static NetworkSid = 9;
            static BatchSid = 10;
            static InteractiveSid = 11;
            static ServiceSid = 12;
            static AnonymousSid = 13;
            static ProxySid = 14;
            static EnterpriseControllersSid = 15;
            static SelfSid = 16;
            static AuthenticatedUserSid = 17;
            static RestrictedCodeSid = 18;
            static TerminalServerSid = 19;
            static RemoteLogonIdSid = 20;
            static LogonIdsSid = 21;
            static LocalSystemSid = 22;
            static LocalServiceSid = 23;
            static NetworkServiceSid = 24;
            static BuiltinDomainSid = 25;
            static BuiltinAdministratorsSid = 26;
            static BuiltinUsersSid = 27;
            static BuiltinGuestsSid = 28;
            static BuiltinPowerUsersSid = 29;
            static BuiltinAccountOperatorsSid = 30;
            static BuiltinSystemOperatorsSid = 31;
            static BuiltinPrintOperatorsSid = 32;
            static BuiltinBackupOperatorsSid = 33;
            static BuiltinReplicatorSid = 34;
            static BuiltinPreWindows2000CompatibleAccessSid = 35;
            static BuiltinRemoteDesktopUsersSid = 36;
            static BuiltinNetworkConfigurationOperatorsSid = 37;
            static AccountAdministratorSid = 38;
            static AccountGuestSid = 39;
            static AccountKrbtgtSid = 40;
            static AccountDomainAdminsSid = 41;
            static AccountDomainUsersSid = 42;
            static AccountDomainGuestsSid = 43;
            static AccountComputersSid = 44;
            static AccountControllersSid = 45;
            static AccountCertAdminsSid = 46;
            static AccountSchemaAdminsSid = 47;
            static AccountEnterpriseAdminsSid = 48;
            static AccountPolicyAdminsSid = 49;
            static AccountRasAndIasServersSid = 50;
            static NtlmAuthenticationSid = 51;
            static DigestAuthenticationSid = 52;
            static SChannelAuthenticationSid = 53;
            static ThisOrganizationSid = 54;
            static OtherOrganizationSid = 55;
            static BuiltinIncomingForestTrustBuildersSid = 56;
            static BuiltinPerformanceMonitoringUsersSid = 57;
            static BuiltinPerformanceLoggingUsersSid = 58;
            static BuiltinAuthorizationAccessSid = 59;
            static MaxDefined = 60;
            static WinBuiltinTerminalServerLicenseServersSid = 60;
            static WinBuiltinDCOMUsersSid = 61;
            static WinBuiltinIUsersSid = 62;
            static WinIUserSid = 63;
            static WinBuiltinCryptoOperatorsSid = 64;
            static WinUntrustedLabelSid = 65;
            static WinLowLabelSid = 66;
            static WinMediumLabelSid = 67;
            static WinHighLabelSid = 68;
            static WinSystemLabelSid = 69;
            static WinWriteRestrictedCodeSid = 70;
            static WinCreatorOwnerRightsSid = 71;
            static WinCacheablePrincipalsGroupSid = 72;
            static WinNonCacheablePrincipalsGroupSid = 73;
            static WinEnterpriseReadonlyControllersSid = 74;
            static WinAccountReadonlyControllersSid = 75;
            static WinBuiltinEventLogReadersGroup = 76;
            static WinNewEnterpriseReadonlyControllersSid = 77;
            static WinBuiltinCertSvcDComAccessGroup = 78;
            static WinMediumPlusLabelSid = 79;
            static WinLocalLogonSid = 80;
            static WinConsoleLogonSid = 81;
            static WinThisOrganizationCertificateSid = 82;
            static WinApplicationPackageAuthoritySid = 83;
            static WinBuiltinAnyPackageSid = 84;
            static WinCapabilityInternetClientSid = 85;
            static WinCapabilityInternetClientServerSid = 86;
            static WinCapabilityPrivateNetworkClientServerSid = 87;
            static WinCapabilityPicturesLibrarySid = 88;
            static WinCapabilityVideosLibrarySid = 89;
            static WinCapabilityMusicLibrarySid = 90;
            static WinCapabilityDocumentsLibrarySid = 91;
            static WinCapabilitySharedUserCertificatesSid = 92;
            static WinCapabilityEnterpriseAuthenticationSid = 93;
            static WinCapabilityRemovableStorageSid = 94;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "NullSid": 0n,
                    "WorldSid": 1n,
                    "LocalSid": 2n,
                    "CreatorOwnerSid": 3n,
                    "CreatorGroupSid": 4n,
                    "CreatorOwnerServerSid": 5n,
                    "CreatorGroupServerSid": 6n,
                    "NTAuthoritySid": 7n,
                    "DialupSid": 8n,
                    "NetworkSid": 9n,
                    "BatchSid": 10n,
                    "InteractiveSid": 11n,
                    "ServiceSid": 12n,
                    "AnonymousSid": 13n,
                    "ProxySid": 14n,
                    "EnterpriseControllersSid": 15n,
                    "SelfSid": 16n,
                    "AuthenticatedUserSid": 17n,
                    "RestrictedCodeSid": 18n,
                    "TerminalServerSid": 19n,
                    "RemoteLogonIdSid": 20n,
                    "LogonIdsSid": 21n,
                    "LocalSystemSid": 22n,
                    "LocalServiceSid": 23n,
                    "NetworkServiceSid": 24n,
                    "BuiltinDomainSid": 25n,
                    "BuiltinAdministratorsSid": 26n,
                    "BuiltinUsersSid": 27n,
                    "BuiltinGuestsSid": 28n,
                    "BuiltinPowerUsersSid": 29n,
                    "BuiltinAccountOperatorsSid": 30n,
                    "BuiltinSystemOperatorsSid": 31n,
                    "BuiltinPrintOperatorsSid": 32n,
                    "BuiltinBackupOperatorsSid": 33n,
                    "BuiltinReplicatorSid": 34n,
                    "BuiltinPreWindows2000CompatibleAccessSid": 35n,
                    "BuiltinRemoteDesktopUsersSid": 36n,
                    "BuiltinNetworkConfigurationOperatorsSid": 37n,
                    "AccountAdministratorSid": 38n,
                    "AccountGuestSid": 39n,
                    "AccountKrbtgtSid": 40n,
                    "AccountDomainAdminsSid": 41n,
                    "AccountDomainUsersSid": 42n,
                    "AccountDomainGuestsSid": 43n,
                    "AccountComputersSid": 44n,
                    "AccountControllersSid": 45n,
                    "AccountCertAdminsSid": 46n,
                    "AccountSchemaAdminsSid": 47n,
                    "AccountEnterpriseAdminsSid": 48n,
                    "AccountPolicyAdminsSid": 49n,
                    "AccountRasAndIasServersSid": 50n,
                    "NtlmAuthenticationSid": 51n,
                    "DigestAuthenticationSid": 52n,
                    "SChannelAuthenticationSid": 53n,
                    "ThisOrganizationSid": 54n,
                    "OtherOrganizationSid": 55n,
                    "BuiltinIncomingForestTrustBuildersSid": 56n,
                    "BuiltinPerformanceMonitoringUsersSid": 57n,
                    "BuiltinPerformanceLoggingUsersSid": 58n,
                    "BuiltinAuthorizationAccessSid": 59n,
                    "MaxDefined": 60n,
                    "WinBuiltinTerminalServerLicenseServersSid": 60n,
                    "WinBuiltinDCOMUsersSid": 61n,
                    "WinBuiltinIUsersSid": 62n,
                    "WinIUserSid": 63n,
                    "WinBuiltinCryptoOperatorsSid": 64n,
                    "WinUntrustedLabelSid": 65n,
                    "WinLowLabelSid": 66n,
                    "WinMediumLabelSid": 67n,
                    "WinHighLabelSid": 68n,
                    "WinSystemLabelSid": 69n,
                    "WinWriteRestrictedCodeSid": 70n,
                    "WinCreatorOwnerRightsSid": 71n,
                    "WinCacheablePrincipalsGroupSid": 72n,
                    "WinNonCacheablePrincipalsGroupSid": 73n,
                    "WinEnterpriseReadonlyControllersSid": 74n,
                    "WinAccountReadonlyControllersSid": 75n,
                    "WinBuiltinEventLogReadersGroup": 76n,
                    "WinNewEnterpriseReadonlyControllersSid": 77n,
                    "WinBuiltinCertSvcDComAccessGroup": 78n,
                    "WinMediumPlusLabelSid": 79n,
                    "WinLocalLogonSid": 80n,
                    "WinConsoleLogonSid": 81n,
                    "WinThisOrganizationCertificateSid": 82n,
                    "WinApplicationPackageAuthoritySid": 83n,
                    "WinBuiltinAnyPackageSid": 84n,
                    "WinCapabilityInternetClientSid": 85n,
                    "WinCapabilityInternetClientServerSid": 86n,
                    "WinCapabilityPrivateNetworkClientServerSid": 87n,
                    "WinCapabilityPicturesLibrarySid": 88n,
                    "WinCapabilityVideosLibrarySid": 89n,
                    "WinCapabilityMusicLibrarySid": 90n,
                    "WinCapabilityDocumentsLibrarySid": 91n,
                    "WinCapabilitySharedUserCertificatesSid": 92n,
                    "WinCapabilityEnterpriseAuthenticationSid": 93n,
                    "WinCapabilityRemovableStorageSid": 94n
                };
            }
            static $h = 566148;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":566148,"n":"NullSid","d":566148,"h":4295533444,"f":33},{"t":566148,"n":"WorldSid","d":566148,"h":8590500740,"f":33},{"t":566148,"n":"LocalSid","d":566148,"h":12885468036,"f":33},{"t":566148,"n":"CreatorOwnerSid","d":566148,"h":17180435332,"f":33},{"t":566148,"n":"CreatorGroupSid","d":566148,"h":21475402628,"f":33},{"t":566148,"n":"CreatorOwnerServerSid","d":566148,"h":25770369924,"f":33},{"t":566148,"n":"CreatorGroupServerSid","d":566148,"h":30065337220,"f":33},{"t":566148,"n":"NTAuthoritySid","d":566148,"h":34360304516,"f":33},{"t":566148,"n":"DialupSid","d":566148,"h":38655271812,"f":33},{"t":566148,"n":"NetworkSid","d":566148,"h":42950239108,"f":33},{"t":566148,"n":"BatchSid","d":566148,"h":47245206404,"f":33},{"t":566148,"n":"InteractiveSid","d":566148,"h":51540173700,"f":33},{"t":566148,"n":"ServiceSid","d":566148,"h":55835140996,"f":33},{"t":566148,"n":"AnonymousSid","d":566148,"h":60130108292,"f":33},{"t":566148,"n":"ProxySid","d":566148,"h":64425075588,"f":33},{"t":566148,"n":"EnterpriseControllersSid","d":566148,"h":68720042884,"f":33},{"t":566148,"n":"SelfSid","d":566148,"h":73015010180,"f":33},{"t":566148,"n":"AuthenticatedUserSid","d":566148,"h":77309977476,"f":33},{"t":566148,"n":"RestrictedCodeSid","d":566148,"h":81604944772,"f":33},{"t":566148,"n":"TerminalServerSid","d":566148,"h":85899912068,"f":33},{"t":566148,"n":"RemoteLogonIdSid","d":566148,"h":90194879364,"f":33},{"t":566148,"n":"LogonIdsSid","d":566148,"h":94489846660,"f":33},{"t":566148,"n":"LocalSystemSid","d":566148,"h":98784813956,"f":33},{"t":566148,"n":"LocalServiceSid","d":566148,"h":103079781252,"f":33},{"t":566148,"n":"NetworkServiceSid","d":566148,"h":107374748548,"f":33},{"t":566148,"n":"BuiltinDomainSid","d":566148,"h":111669715844,"f":33},{"t":566148,"n":"BuiltinAdministratorsSid","d":566148,"h":115964683140,"f":33},{"t":566148,"n":"BuiltinUsersSid","d":566148,"h":120259650436,"f":33},{"t":566148,"n":"BuiltinGuestsSid","d":566148,"h":124554617732,"f":33},{"t":566148,"n":"BuiltinPowerUsersSid","d":566148,"h":128849585028,"f":33},{"t":566148,"n":"BuiltinAccountOperatorsSid","d":566148,"h":133144552324,"f":33},{"t":566148,"n":"BuiltinSystemOperatorsSid","d":566148,"h":137439519620,"f":33},{"t":566148,"n":"BuiltinPrintOperatorsSid","d":566148,"h":141734486916,"f":33},{"t":566148,"n":"BuiltinBackupOperatorsSid","d":566148,"h":146029454212,"f":33},{"t":566148,"n":"BuiltinReplicatorSid","d":566148,"h":150324421508,"f":33},{"t":566148,"n":"BuiltinPreWindows2000CompatibleAccessSid","d":566148,"h":154619388804,"f":33},{"t":566148,"n":"BuiltinRemoteDesktopUsersSid","d":566148,"h":158914356100,"f":33},{"t":566148,"n":"BuiltinNetworkConfigurationOperatorsSid","d":566148,"h":163209323396,"f":33},{"t":566148,"n":"AccountAdministratorSid","d":566148,"h":167504290692,"f":33},{"t":566148,"n":"AccountGuestSid","d":566148,"h":171799257988,"f":33},{"t":566148,"n":"AccountKrbtgtSid","d":566148,"h":176094225284,"f":33},{"t":566148,"n":"AccountDomainAdminsSid","d":566148,"h":180389192580,"f":33},{"t":566148,"n":"AccountDomainUsersSid","d":566148,"h":184684159876,"f":33},{"t":566148,"n":"AccountDomainGuestsSid","d":566148,"h":188979127172,"f":33},{"t":566148,"n":"AccountComputersSid","d":566148,"h":193274094468,"f":33},{"t":566148,"n":"AccountControllersSid","d":566148,"h":197569061764,"f":33},{"t":566148,"n":"AccountCertAdminsSid","d":566148,"h":201864029060,"f":33},{"t":566148,"n":"AccountSchemaAdminsSid","d":566148,"h":206158996356,"f":33},{"t":566148,"n":"AccountEnterpriseAdminsSid","d":566148,"h":210453963652,"f":33},{"t":566148,"n":"AccountPolicyAdminsSid","d":566148,"h":214748930948,"f":33},{"t":566148,"n":"AccountRasAndIasServersSid","d":566148,"h":219043898244,"f":33},{"t":566148,"n":"NtlmAuthenticationSid","d":566148,"h":223338865540,"f":33},{"t":566148,"n":"DigestAuthenticationSid","d":566148,"h":227633832836,"f":33},{"t":566148,"n":"SChannelAuthenticationSid","d":566148,"h":231928800132,"f":33},{"t":566148,"n":"ThisOrganizationSid","d":566148,"h":236223767428,"f":33},{"t":566148,"n":"OtherOrganizationSid","d":566148,"h":240518734724,"f":33},{"t":566148,"n":"BuiltinIncomingForestTrustBuildersSid","d":566148,"h":244813702020,"f":33},{"t":566148,"n":"BuiltinPerformanceMonitoringUsersSid","d":566148,"h":249108669316,"f":33},{"t":566148,"n":"BuiltinPerformanceLoggingUsersSid","d":566148,"h":253403636612,"f":33},{"t":566148,"n":"BuiltinAuthorizationAccessSid","d":566148,"h":257698603908,"f":33},{"t":566148,"n":"MaxDefined","d":566148,"h":261993571204,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]},{"t":70909953,"c":8660844545,"a":[{"v":"This member has been deprecated and is only maintained for backwards compatability. WellKnownSidType values greater than MaxDefined may be defined in future releases.","t":1310721}]}]},{"t":566148,"n":"WinBuiltinTerminalServerLicenseServersSid","d":566148,"h":266288538500,"f":33},{"t":566148,"n":"WinBuiltinDCOMUsersSid","d":566148,"h":270583505796,"f":33},{"t":566148,"n":"WinBuiltinIUsersSid","d":566148,"h":274878473092,"f":33},{"t":566148,"n":"WinIUserSid","d":566148,"h":279173440388,"f":33},{"t":566148,"n":"WinBuiltinCryptoOperatorsSid","d":566148,"h":283468407684,"f":33},{"t":566148,"n":"WinUntrustedLabelSid","d":566148,"h":287763374980,"f":33},{"t":566148,"n":"WinLowLabelSid","d":566148,"h":292058342276,"f":33},{"t":566148,"n":"WinMediumLabelSid","d":566148,"h":296353309572,"f":33},{"t":566148,"n":"WinHighLabelSid","d":566148,"h":300648276868,"f":33},{"t":566148,"n":"WinSystemLabelSid","d":566148,"h":304943244164,"f":33},{"t":566148,"n":"WinWriteRestrictedCodeSid","d":566148,"h":309238211460,"f":33},{"t":566148,"n":"WinCreatorOwnerRightsSid","d":566148,"h":313533178756,"f":33},{"t":566148,"n":"WinCacheablePrincipalsGroupSid","d":566148,"h":317828146052,"f":33},{"t":566148,"n":"WinNonCacheablePrincipalsGroupSid","d":566148,"h":322123113348,"f":33},{"t":566148,"n":"WinEnterpriseReadonlyControllersSid","d":566148,"h":326418080644,"f":33},{"t":566148,"n":"WinAccountReadonlyControllersSid","d":566148,"h":330713047940,"f":33},{"t":566148,"n":"WinBuiltinEventLogReadersGroup","d":566148,"h":335008015236,"f":33},{"t":566148,"n":"WinNewEnterpriseReadonlyControllersSid","d":566148,"h":339302982532,"f":33},{"t":566148,"n":"WinBuiltinCertSvcDComAccessGroup","d":566148,"h":343597949828,"f":33},{"t":566148,"n":"WinMediumPlusLabelSid","d":566148,"h":347892917124,"f":33},{"t":566148,"n":"WinLocalLogonSid","d":566148,"h":352187884420,"f":33},{"t":566148,"n":"WinConsoleLogonSid","d":566148,"h":356482851716,"f":33},{"t":566148,"n":"WinThisOrganizationCertificateSid","d":566148,"h":360777819012,"f":33},{"t":566148,"n":"WinApplicationPackageAuthoritySid","d":566148,"h":365072786308,"f":33},{"t":566148,"n":"WinBuiltinAnyPackageSid","d":566148,"h":369367753604,"f":33},{"t":566148,"n":"WinCapabilityInternetClientSid","d":566148,"h":373662720900,"f":33},{"t":566148,"n":"WinCapabilityInternetClientServerSid","d":566148,"h":377957688196,"f":33},{"t":566148,"n":"WinCapabilityPrivateNetworkClientServerSid","d":566148,"h":382252655492,"f":33},{"t":566148,"n":"WinCapabilityPicturesLibrarySid","d":566148,"h":386547622788,"f":33},{"t":566148,"n":"WinCapabilityVideosLibrarySid","d":566148,"h":390842590084,"f":33},{"t":566148,"n":"WinCapabilityMusicLibrarySid","d":566148,"h":395137557380,"f":33},{"t":566148,"n":"WinCapabilityDocumentsLibrarySid","d":566148,"h":399432524676,"f":33},{"t":566148,"n":"WinCapabilitySharedUserCertificatesSid","d":566148,"h":403727491972,"f":33},{"t":566148,"n":"WinCapabilityEnterpriseAuthenticationSid","d":566148,"h":408022459268,"f":33},{"t":566148,"n":"WinCapabilityRemovableStorageSid","d":566148,"h":412317426564,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":566148,"h":416612393860,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":566148}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.Principal.WellKnownSidType`; }
        });
        
        $asm.$str("$sspw.System.Security.Principal.WindowsAccountType", ($self) => class WindowsAccountType extends $.$spc.System.Enum
        {
            static Normal = 0;
            static Guest = 1;
            static System = 2;
            static Anonymous = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Normal": 0n,
                    "Guest": 1n,
                    "System": 2n,
                    "Anonymous": 3n
                };
            }
            static $h = 631684;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":631684,"n":"Normal","d":631684,"h":4295598980,"f":33},{"t":631684,"n":"Guest","d":631684,"h":8590566276,"f":33},{"t":631684,"n":"System","d":631684,"h":12885533572,"f":33},{"t":631684,"n":"Anonymous","d":631684,"h":17180500868,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":631684,"h":21475468164,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":631684}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.Principal.WindowsAccountType`; }
        });
        
        $asm.$str("$sspw.System.Security.Principal.WindowsBuiltInRole", ($self) => class WindowsBuiltInRole extends $.$spc.System.Enum
        {
            static Administrator = 544;
            static User = 545;
            static Guest = 546;
            static PowerUser = 547;
            static AccountOperator = 548;
            static SystemOperator = 549;
            static PrintOperator = 550;
            static BackupOperator = 551;
            static Replicator = 552;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Administrator": 544n,
                    "User": 545n,
                    "Guest": 546n,
                    "PowerUser": 547n,
                    "AccountOperator": 548n,
                    "SystemOperator": 549n,
                    "PrintOperator": 550n,
                    "BackupOperator": 551n,
                    "Replicator": 552n
                };
            }
            static $h = 697220;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":697220,"n":"Administrator","d":697220,"h":4295664516,"f":33},{"t":697220,"n":"User","d":697220,"h":8590631812,"f":33},{"t":697220,"n":"Guest","d":697220,"h":12885599108,"f":33},{"t":697220,"n":"PowerUser","d":697220,"h":17180566404,"f":33},{"t":697220,"n":"AccountOperator","d":697220,"h":21475533700,"f":33},{"t":697220,"n":"SystemOperator","d":697220,"h":25770500996,"f":33},{"t":697220,"n":"PrintOperator","d":697220,"h":30065468292,"f":33},{"t":697220,"n":"BackupOperator","d":697220,"h":34360435588,"f":33},{"t":697220,"n":"Replicator","d":697220,"h":38655402884,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":697220,"h":42950370180,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":697220}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.Principal.WindowsBuiltInRole`; }
        });
        
        $asm.$cls("$sspw.System.Security.Principal.WindowsPrincipal", ($self) => class WindowsPrincipal extends $.$ssc.System.Security.Claims.ClaimsPrincipal
        {
            $ctor$7(/*System.Security.Principal.WindowsIdentity*/ ntIdentity)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*System.Collections.Generic.IEnumerable<System.Security.Claims.Claim> */ get DeviceClaims()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IIdentity */ get Identity()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.IEnumerable<System.Security.Claims.Claim> */ get UserClaims()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ IsInRole$1(/*int*/ rid)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ IsInRole$2(/*System.Security.Principal.SecurityIdentifier*/ sid)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ IsInRole$3(/*System.Security.Principal.WindowsBuiltInRole*/ role)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ IsInRole(/*string*/ role)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 828292;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":437148,"p":[{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"g":{"r":0,"d":0,"h":12885730180,"f":129},"n":"DeviceClaims","d":828292,"h":8590762884,"f":129},{"p":117047297,"g":{"r":0,"d":0,"h":21475664772,"f":32769},"n":"Identity","d":828292,"h":17180697476,"f":32769},{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"g":{"r":0,"d":0,"h":30065599364,"f":129},"n":"UserClaims","d":828292,"h":25770632068,"f":129}],"m":[{"r":262145,"p":[{"n":"rid","p":655361}],"n":"IsInRole","o":"@$1","d":828292,"h":34360566660,"f":129},{"r":262145,"p":[{"n":"sid","p":435076}],"n":"IsInRole","o":"@$2","d":828292,"h":38655533956,"f":129},{"r":262145,"p":[{"n":"role","p":697220}],"n":"IsInRole","o":"@$3","d":828292,"h":42950501252,"f":129},{"r":262145,"p":[{"n":"role","p":1310721}],"n":"IsInRole","d":828292,"h":47245468548,"f":32769}],"c":[{"p":[{"n":"ntIdentity","p":762756}],"n":".ctor","o":"$ctor$7","d":828292,"h":4295795588,"f":1}],"i":[117112833],"h":828292}; }
            static get $b() { return $.$ssc.System.Security.Claims.ClaimsPrincipal; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Security.Principal.IPrincipal ]; }
            static get $fullName() { return `System.Security.Principal.WindowsPrincipal`; }
        });
        
        $asm.$cls("$sspw.System.Security.Principal.WindowsIdentity", ($self) => class WindowsIdentity extends $.$ssc.System.Security.Claims.ClaimsIdentity
        {
            /*string*/ static DefaultIssuer = null;
            $ctor$17(/*System.IntPtr*/ userToken)
            {
                super.$ctor$14(null, null, null, null, null, 5);
                {
                }
                return this;
            }
            $ctor$18(/*System.IntPtr*/ userToken, /*string*/ type)
            {
                super.$ctor$14(null, null, null, null, null, 5);
                {
                }
                return this;
            }
            $ctor$19(/*System.IntPtr*/ userToken, /*string*/ type, /*System.Security.Principal.WindowsAccountType*/ acctType)
            {
                super.$ctor$14(null, null, null, null, null, 5);
                {
                }
                return this;
            }
            $ctor$20(/*System.IntPtr*/ userToken, /*string*/ type, /*System.Security.Principal.WindowsAccountType*/ acctType, /*bool*/ isAuthenticated)
            {
                super.$ctor$14(null, null, null, null, null, 5);
                {
                }
                return this;
            }
            $ctor$21(/*System.Runtime.Serialization.SerializationInfo*/ info, /*System.Runtime.Serialization.StreamingContext*/ context)
            {
                super.$ctor$14(null, null, null, null, null, 5);
                {
                }
                return this;
            }
            $ctor$22(/*System.Security.Principal.WindowsIdentity*/ identity)
            {
                super.$ctor$14(null, null, null, null, null, 5);
                {
                }
                return this;
            }
            $ctor$23(/*string*/ sUserPrincipalName)
            {
                super.$ctor$14(null, null, null, null, null, 5);
                {
                }
                return this;
            }
            /*Microsoft.Win32.SafeHandles.SafeAccessTokenHandle */ get AccessToken()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get AuthenticationType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.IEnumerable<System.Security.Claims.Claim> */ get Claims()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.IEnumerable<System.Security.Claims.Claim> */ get DeviceClaims()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IdentityReferenceCollection? */ get Groups()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.TokenImpersonationLevel */ get ImpersonationLevel()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsAnonymous()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsAuthenticated()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsGuest()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsSystem()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Name()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ get Owner()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ get Token()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ get User()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.IEnumerable<System.Security.Claims.Claim> */ get UserClaims()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Claims.ClaimsIdentity */ Clone()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose()
            {
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            static /*System.Security.Principal.WindowsIdentity */ GetAnonymous()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Security.Principal.WindowsIdentity */ GetCurrent()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Security.Principal.WindowsIdentity? */ GetCurrent$1(/*bool*/ ifImpersonating)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Security.Principal.WindowsIdentity */ GetCurrent$2(/*System.Security.Principal.TokenAccessLevels*/ desiredAccess)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*void */ RunImpersonated(/*Microsoft.Win32.SafeHandles.SafeAccessTokenHandle*/ safeAccessTokenHandle, /*System.Action*/ action)
            {
            }
            static /*System.Threading.Tasks.Task */ RunImpersonatedAsync(/*Microsoft.Win32.SafeHandles.SafeAccessTokenHandle*/ safeAccessTokenHandle, /*System.Func<System.Threading.Tasks.Task>*/ func)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<T> */ RunImpersonatedAsync$1(T, /*Microsoft.Win32.SafeHandles.SafeAccessTokenHandle*/ safeAccessTokenHandle, /*System.Func<System.Threading.Tasks.Task<T>>*/ func)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*T */ RunImpersonated$1(T, /*Microsoft.Win32.SafeHandles.SafeAccessTokenHandle*/ safeAccessTokenHandle, /*System.Func<T>*/ func)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ System$Runtime$Serialization$IDeserializationCallback$OnDeserialization(/*object?*/ sender)
            {
            }
            /*void */ System$Runtime$Serialization$ISerializable$GetObjectData(/*System.Runtime.Serialization.SerializationInfo*/ info, /*System.Runtime.Serialization.StreamingContext*/ context)
            {
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.DefaultIssuer = "AD AUTHORITY";
                }
            }
            static $h = 762756;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":306076,"p":[{"p":107396,"g":{"r":0,"d":0,"h":42950435716,"f":1},"n":"AccessToken","d":762756,"h":38655468420,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":51540370308,"f":98305},"n":"AuthenticationType","d":762756,"h":47245403012,"f":98305},{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"g":{"r":0,"d":0,"h":60130304900,"f":32769},"n":"Claims","d":762756,"h":55835337604,"f":32769},{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"g":{"r":0,"d":0,"h":68720239492,"f":129},"n":"DeviceClaims","d":762756,"h":64425272196,"f":129},{"p":304004,"g":{"r":0,"d":0,"h":77310174084,"f":1},"n":"Groups","d":762756,"h":73015206788,"f":1},{"p":117243905,"g":{"r":0,"d":0,"h":85900108676,"f":1},"n":"ImpersonationLevel","d":762756,"h":81605141380,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":94490043268,"f":129},"n":"IsAnonymous","d":762756,"h":90195075972,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":103079977860,"f":32769},"n":"IsAuthenticated","d":762756,"h":98785010564,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":111669912452,"f":129},"n":"IsGuest","d":762756,"h":107374945156,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":120259847044,"f":129},"n":"IsSystem","d":762756,"h":115964879748,"f":129},{"p":1310721,"g":{"r":0,"d":0,"h":128849781636,"f":32769},"n":"Name","d":762756,"h":124554814340,"f":32769},{"p":435076,"g":{"r":0,"d":0,"h":137439716228,"f":1},"n":"Owner","d":762756,"h":133144748932,"f":1},{"p":786433,"g":{"r":0,"d":0,"h":146029650820,"f":129},"n":"Token","d":762756,"h":141734683524,"f":129},{"p":435076,"g":{"r":0,"d":0,"h":154619585412,"f":1},"n":"User","d":762756,"h":150324618116,"f":1},{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"g":{"r":0,"d":0,"h":163209520004,"f":129},"n":"UserClaims","d":762756,"h":158914552708,"f":129}],"m":[{"r":306076,"n":"Clone","d":762756,"h":167504487300,"f":32769},{"r":65537,"n":"Dispose","d":762756,"h":171799454596,"f":1},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":762756,"h":176094421892,"f":132},{"r":762756,"n":"GetAnonymous","d":762756,"h":180389389188,"f":33},{"r":762756,"n":"GetCurrent","d":762756,"h":184684356484,"f":33},{"r":762756,"p":[{"n":"ifImpersonating","p":262145}],"n":"GetCurrent","o":"@$1","d":762756,"h":188979323780,"f":33},{"r":762756,"p":[{"n":"desiredAccess","p":500612}],"n":"GetCurrent","o":"@$2","d":762756,"h":193274291076,"f":33},{"r":65537,"p":[{"n":"safeAccessTokenHandle","p":107396},{"n":"action","p":11665409}],"n":"RunImpersonated","d":762756,"h":197569258372,"f":33},{"r":133300225,"p":[{"n":"safeAccessTokenHandle","p":107396},{"n":"func","p":$.$spc.System.Func$$($.$spc.System.Threading.Tasks.Task).$h}],"n":"RunImpersonatedAsync","d":762756,"h":201864225668,"f":33},{"r":(T) => $.$spc.System.Threading.Tasks.Task$$(T).$h,"p":[{"n":"safeAccessTokenHandle","p":107396},{"n":"func","p":(T) => $.$spc.System.Func$$($.$spc.System.Threading.Tasks.Task$$(T)).$h}],"g":["T"],"n":"RunImpersonatedAsync","o":"@$1","d":762756,"h":206159192964,"f":131105},{"r":206162034688,"p":[{"n":"safeAccessTokenHandle","p":107396},{"n":"func","p":(T) => $.$spc.System.Func$$(T).$h}],"g":["T"],"n":"RunImpersonated","o":"@$1","d":762756,"h":210454160260,"f":131105}],"l":[{"t":1310721,"n":"DefaultIssuer","d":762756,"h":4295730052,"f":33}],"c":[{"p":[{"n":"userToken","p":786433}],"n":".ctor","o":"$ctor$17","d":762756,"h":8590697348,"f":1},{"p":[{"n":"userToken","p":786433},{"n":"type","p":1310721}],"n":".ctor","o":"$ctor$18","d":762756,"h":12885664644,"f":1},{"p":[{"n":"userToken","p":786433},{"n":"type","p":1310721},{"n":"acctType","p":631684}],"n":".ctor","o":"$ctor$19","d":762756,"h":17180631940,"f":1},{"p":[{"n":"userToken","p":786433},{"n":"type","p":1310721},{"n":"acctType","p":631684},{"n":"isAuthenticated","p":262145}],"n":".ctor","o":"$ctor$20","d":762756,"h":21475599236,"f":1},{"p":[{"n":"info","p":113967105},{"n":"context","p":114098177}],"n":".ctor","o":"$ctor$21","d":762756,"h":25770566532,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This API supports obsolete formatter-based serialization. It should not be called or extended by application code.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0051","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]},{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"p":[{"n":"identity","p":762756}],"n":".ctor","o":"$ctor$22","d":762756,"h":30065533828,"f":4},{"p":[{"n":"sUserPrincipalName","p":1310721}],"n":".ctor","o":"$ctor$23","d":762756,"h":34360501124,"f":1}],"i":[117047297,57475073,113115137,113377281],"h":762756}; }
            static get $b() { return $.$ssc.System.Security.Claims.ClaimsIdentity; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Security.Principal.IIdentity, $.$spc.System.IDisposable, $.$spc.System.Runtime.Serialization.IDeserializationCallback, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Security.Principal.WindowsIdentity`; }
        });
        
        $asm.$cls("$sspw.System.Security.Principal.IdentityNotMappedException", ($self) => class IdentityNotMappedException extends $.$spc.System.SystemException
        {
            $ctor$9()
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            $ctor$10(/*string?*/ message)
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            $ctor$11(/*string?*/ message, /*System.Exception?*/ inner)
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            /*System.Security.Principal.IdentityReferenceCollection */ get UnmappedIdentities()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetObjectData(/*System.Runtime.Serialization.SerializationInfo*/ serializationInfo, /*System.Runtime.Serialization.StreamingContext*/ streamingContext)
            {
            }
            static $h = 172932;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":119668737,"h":172932}; }
            static get $b() { return $.$spc.System.SystemException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Security.Principal.IdentityNotMappedException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Threading", "NetJs.System.Threading.Thread", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Security.Claims", "NetJs.System.Runtime.InteropServices"))