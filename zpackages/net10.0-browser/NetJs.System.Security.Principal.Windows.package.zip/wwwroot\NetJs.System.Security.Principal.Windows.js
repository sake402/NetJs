
(function ($global, $, $spc, $mwp, $sc, $sdt, $sm, $spu, $st, $stt, $sr, $scc, $ssc, $sris) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Security.Principal.Windows", 
    {"h":43433,"f":"System.Security.Principal.Windows","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bb2f64e36cd2325469603c9f9f7251f0c62e9b41f","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Security.Principal.Windows","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Security.Principal.Windows","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sspw.System.Security.Principal.IdentityReference", ($self) => class IdentityReference extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static /*bool */ op_Equality(/*System.Security.Principal.IdentityReference?*/ left, /*System.Security.Principal.IdentityReference?*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ op_Inequality(/*System.Security.Principal.IdentityReference?*/ left, /*System.Security.Principal.IdentityReference?*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 240041;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12885141929,"f":257},"n":"Value","d":240041,"h":8590174633,"f":257}],"m":[{"r":262145,"p":[{"n":"o","p":131073}],"n":"Equals","d":240041,"h":17180109225,"f":33025},{"r":655361,"n":"GetHashCode","d":240041,"h":21475076521,"f":33025},{"r":262145,"p":[{"n":"targetType","p":142606337}],"n":"IsValidTargetType","d":240041,"h":25770043817,"f":257},{"r":1310721,"n":"ToString","d":240041,"h":38654945705,"f":33025},{"r":240041,"p":[{"n":"targetType","p":142606337}],"n":"Translate","d":240041,"h":42949913001,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":240041,"h":4295207337,"f":8}],"h":240041}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Security.Principal.IdentityReference`; }
        });
        
        $asm.$cls("$sspw.System.Security.Principal.IdentityReferenceCollection", ($self) => class IdentityReferenceCollection extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*int*/ capacity)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get Count()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IdentityReference*/ get_Item(/*int*/ index)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void*/ set_Item(/*int*/ index, /*System.Security.Principal.IdentityReference*/ value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get System$Collections$Generic$ICollection$$$IsReadOnly()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Add(/*System.Security.Principal.IdentityReference*/ identity)
            {
            }
            /*void */ Clear()
            {
            }
            /*bool */ Contains(/*System.Security.Principal.IdentityReference*/ identity)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CopyTo(/*System.Security.Principal.IdentityReference[]*/ array, /*int*/ offset)
            {
            }
            /*System.Collections.Generic.IEnumerator<System.Security.Principal.IdentityReference> */ GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Remove(/*System.Security.Principal.IdentityReference*/ identity)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IdentityReferenceCollection */ Translate(/*System.Type*/ targetType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IdentityReferenceCollection */ Translate$1(/*System.Type*/ targetType, /*bool*/ forceSuccess)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Security.Principal.IdentityReference>.Count.get
            get System$Collections$Generic$ICollection$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Security.Principal.IdentityReference>.Add(System.Security.Principal.IdentityReference)
            System$Collections$Generic$ICollection$$$Add()
            {
                return this.Add(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Security.Principal.IdentityReference>.Clear()
            System$Collections$Generic$ICollection$$$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Security.Principal.IdentityReference>.Contains(System.Security.Principal.IdentityReference)
            System$Collections$Generic$ICollection$$$Contains()
            {
                return this.Contains(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Security.Principal.IdentityReference>.CopyTo(System.Security.Principal.IdentityReference[], int)
            System$Collections$Generic$ICollection$$$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Security.Principal.IdentityReference>.Remove(System.Security.Principal.IdentityReference)
            System$Collections$Generic$ICollection$$$Remove()
            {
                return this.Remove(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Security.Principal.IdentityReference>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 305577;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":17180174761,"f":1},"n":"Count","d":305577,"h":12885207465,"f":1},{"p":240041,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":25770109353,"f":1},"s":{"r":0,"d":0,"h":30065076649,"f":1},"n":"Item","o":"@$2","d":305577,"h":21475142057,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":38655011241,"f":2},"n":"{$.$spc.System.Collections.Generic.ICollection$$($.$sspw.System.Security.Principal.IdentityReference).$h}.IsReadOnly","o":"System$Collections$Generic$ICollection$$$IsReadOnly","d":305577,"h":34360043945,"f":2}],"m":[{"r":65537,"p":[{"n":"identity","p":240041}],"n":"Add","d":305577,"h":42949978537,"f":1},{"r":65537,"n":"Clear","d":305577,"h":47244945833,"f":1},{"r":262145,"p":[{"n":"identity","p":240041}],"n":"Contains","d":305577,"h":51539913129,"f":1},{"r":65537,"p":[{"n":"array","p":0},{"n":"offset","p":655361}],"n":"CopyTo","d":305577,"h":55834880425,"f":1},{"r":$.$spc.System.Collections.Generic.IEnumerator$$($.$sspw.System.Security.Principal.IdentityReference).$h,"n":"GetEnumerator","d":305577,"h":60129847721,"f":1},{"r":262145,"p":[{"n":"identity","p":240041}],"n":"Remove","d":305577,"h":64424815017,"f":1},{"r":305577,"p":[{"n":"targetType","p":142606337}],"n":"Translate","d":305577,"h":73014749609,"f":1},{"r":305577,"p":[{"n":"targetType","p":142606337},{"n":"forceSuccess","p":262145}],"n":"Translate","o":"@$1","d":305577,"h":77309716905,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":305577,"h":4295272873,"f":1},{"p":[{"n":"capacity","p":655361}],"n":".ctor","o":"$ctor$2","d":305577,"h":8590240169,"f":1}],"i":[$.$spc.System.Collections.Generic.ICollection$$($.$sspw.System.Security.Principal.IdentityReference).$h,$.$spc.System.Collections.Generic.IEnumerable$$($.$sspw.System.Security.Principal.IdentityReference).$h,31588353],"h":305577}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.ICollection$$($.$sspw.System.Security.Principal.IdentityReference), $.$spc.System.Collections.Generic.IEnumerable$$($.$sspw.System.Security.Principal.IdentityReference), $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Security.Principal.IdentityReferenceCollection`; }
        });
        
        $asm.$cls("$sspw.System.Security.Principal.NTAccount", ($self) => class NTAccount extends $.$sspw.System.Security.Principal.IdentityReference
        {
            $ctor$2(/*string*/ name)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$3(/*string*/ domainName, /*string*/ accountName)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*string */ get Value()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ o)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sspw.System.Security.Principal.NTAccount.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sspw.System.Security.Principal.NTAccount.GetHashCode.apply(this, arguments); }
            /*bool */ IsValidTargetType(/*System.Type*/ targetType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ op_Equality$1(/*System.Security.Principal.NTAccount?*/ left, /*System.Security.Principal.NTAccount?*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ op_Inequality$1(/*System.Security.Principal.NTAccount?*/ left, /*System.Security.Principal.NTAccount?*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sspw.System.Security.Principal.NTAccount.ToString.apply(this, arguments); }
            /*System.Security.Principal.IdentityReference */ Translate(/*System.Type*/ targetType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 371113;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":240041,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17180240297,"f":32769},"n":"Value","d":371113,"h":12885273001,"f":32769}],"m":[{"r":262145,"p":[{"n":"o","p":131073}],"n":"Equals","d":371113,"h":21475207593,"f":32769},{"r":655361,"n":"GetHashCode","d":371113,"h":25770174889,"f":32769},{"r":262145,"p":[{"n":"targetType","p":142606337}],"n":"IsValidTargetType","d":371113,"h":30065142185,"f":32769},{"r":1310721,"n":"ToString","d":371113,"h":42950044073,"f":32769},{"r":240041,"p":[{"n":"targetType","p":142606337}],"n":"Translate","d":371113,"h":47245011369,"f":32769}],"c":[{"p":[{"n":"name","p":1310721}],"n":".ctor","o":"$ctor$2","d":371113,"h":4295338409,"f":1},{"p":[{"n":"domainName","p":1310721},{"n":"accountName","p":1310721}],"n":".ctor","o":"$ctor$3","d":371113,"h":8590305705,"f":1}],"h":371113}; }
            static get $b() { return $.$sspw.System.Security.Principal.IdentityReference; }
            static get $fullName() { return `System.Security.Principal.NTAccount`; }
        });
        
        $asm.$cls("$sspw.System.Security.Principal.SecurityIdentifier", ($self) => class SecurityIdentifier extends $.$sspw.System.Security.Principal.IdentityReference
        {
            /*int*/ static MaxBinaryLength = 0;
            /*int*/ static MinBinaryLength = 0;
            $ctor$2(/*byte[]*/ binaryForm, /*int*/ offset)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$3(/*System.IntPtr*/ binaryForm)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$4(/*System.Security.Principal.WellKnownSidType*/ sidType, /*System.Security.Principal.SecurityIdentifier?*/ domainSid)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$5(/*string*/ sddlForm)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Security.Principal.SecurityIdentifier? */ get AccountDomainSid()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get BinaryLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Value()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ CompareTo(/*System.Security.Principal.SecurityIdentifier?*/ sid)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ o)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sspw.System.Security.Principal.SecurityIdentifier.Equals.apply(this, arguments); }
            /*bool */ Equals$2(/*System.Security.Principal.SecurityIdentifier*/ sid)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sspw.System.Security.Principal.SecurityIdentifier.GetHashCode.apply(this, arguments); }
            /*bool */ IsAccountSid()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ IsEqualDomainSid(/*System.Security.Principal.SecurityIdentifier*/ sid)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ IsValidTargetType(/*System.Type*/ targetType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ IsWellKnown(/*System.Security.Principal.WellKnownSidType*/ type)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ op_Equality$1(/*System.Security.Principal.SecurityIdentifier?*/ left, /*System.Security.Principal.SecurityIdentifier?*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ op_Inequality$1(/*System.Security.Principal.SecurityIdentifier?*/ left, /*System.Security.Principal.SecurityIdentifier?*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sspw.System.Security.Principal.SecurityIdentifier.ToString.apply(this, arguments); }
            /*System.Security.Principal.IdentityReference */ Translate(/*System.Type*/ targetType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.IComparable<System.Security.Principal.SecurityIdentifier>.CompareTo(System.Security.Principal.SecurityIdentifier?)
            System$IComparable$$$CompareTo()
            {
                return this.CompareTo(...arguments);
            }
            static $h = 436649;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":240041,"p":[{"p":436649,"g":{"r":0,"d":0,"h":34360175017,"f":1},"n":"AccountDomainSid","d":436649,"h":30065207721,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":42950109609,"f":1},"n":"BinaryLength","d":436649,"h":38655142313,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":51540044201,"f":32769},"n":"Value","d":436649,"h":47245076905,"f":32769}],"m":[{"r":655361,"p":[{"n":"sid","p":436649}],"n":"CompareTo","d":436649,"h":55835011497,"f":1},{"r":262145,"p":[{"n":"o","p":131073}],"n":"Equals","d":436649,"h":60129978793,"f":32769},{"r":262145,"p":[{"n":"sid","p":436649}],"n":"Equals","o":"@$2","d":436649,"h":64424946089,"f":1},{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":436649,"h":68719913385,"f":1},{"r":655361,"n":"GetHashCode","d":436649,"h":73014880681,"f":32769},{"r":262145,"n":"IsAccountSid","d":436649,"h":77309847977,"f":1},{"r":262145,"p":[{"n":"sid","p":436649}],"n":"IsEqualDomainSid","d":436649,"h":81604815273,"f":1},{"r":262145,"p":[{"n":"targetType","p":142606337}],"n":"IsValidTargetType","d":436649,"h":85899782569,"f":32769},{"r":262145,"p":[{"n":"type","p":567721}],"n":"IsWellKnown","d":436649,"h":90194749865,"f":1},{"r":1310721,"n":"ToString","d":436649,"h":103079651753,"f":32769},{"r":240041,"p":[{"n":"targetType","p":142606337}],"n":"Translate","d":436649,"h":107374619049,"f":32769}],"l":[{"t":655361,"n":"MaxBinaryLength","d":436649,"h":4295403945,"f":33},{"t":655361,"n":"MinBinaryLength","d":436649,"h":8590371241,"f":33}],"c":[{"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":".ctor","o":"$ctor$2","d":436649,"h":12885338537,"f":1},{"p":[{"n":"binaryForm","p":786433}],"n":".ctor","o":"$ctor$3","d":436649,"h":17180305833,"f":1},{"p":[{"n":"sidType","p":567721},{"n":"domainSid","p":436649}],"n":".ctor","o":"$ctor$4","d":436649,"h":21475273129,"f":1},{"p":[{"n":"sddlForm","p":1310721}],"n":".ctor","o":"$ctor$5","d":436649,"h":25770240425,"f":1}],"i":[$.$spc.System.IComparable$$($.$sspw.System.Security.Principal.SecurityIdentifier).$h],"h":436649}; }
            static get $b() { return $.$sspw.System.Security.Principal.IdentityReference; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable$$($.$sspw.System.Security.Principal.SecurityIdentifier) ]; }
            static get $fullName() { return `System.Security.Principal.SecurityIdentifier`; }
        });
        
        $asm.$cls("$sspw.Microsoft.Win32.SafeHandles.SafeAccessTokenHandle", ($self) => class SafeAccessTokenHandle extends $.$spc.System.Runtime.InteropServices.SafeHandle
        {
            $ctor$3()
            {
                super.$ctor$2(0, false);
                {
                }
                return this;
            }
            $ctor$4(/*System.IntPtr*/ handle)
            {
                super.$ctor$2(0, false);
                {
                }
                return this;
            }
            static /*Microsoft.Win32.SafeHandles.SafeAccessTokenHandle */ get InvalidHandle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsInvalid()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ReleaseHandle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 108969;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":109576193,"p":[{"p":108969,"g":{"r":0,"d":0,"h":17179978153,"f":33},"n":"InvalidHandle","d":108969,"h":12885010857,"f":33},{"p":262145,"g":{"r":0,"d":0,"h":25769912745,"f":32769},"n":"IsInvalid","d":108969,"h":21474945449,"f":32769}],"m":[{"r":262145,"n":"ReleaseHandle","d":108969,"h":30064880041,"f":32772}],"c":[{"n":".ctor","o":"$ctor$3","d":108969,"h":4295076265,"f":1},{"p":[{"n":"handle","p":786433}],"n":".ctor","o":"$ctor$4","d":108969,"h":8590043561,"f":1}],"i":[57475073],"h":108969}; }
            static get $b() { return $.$spc.System.Runtime.InteropServices.SafeHandle; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Win32.SafeHandles.SafeAccessTokenHandle`; }
        });
        
        $asm.$str("$sspw.System.Security.Principal.TokenAccessLevels", ($self) => class TokenAccessLevels extends $.$spc.System.Enum
        {
            static AssignPrimary = 1;
            static Duplicate = 2;
            static Impersonate = 4;
            static Query = 8;
            static QuerySource = 16;
            static AdjustPrivileges = 32;
            static AdjustGroups = 64;
            static AdjustDefault = 128;
            static AdjustSessionId = 256;
            static Read = 131080;
            static Write = 131296;
            static AllAccess = 983551;
            static MaximumAllowed = 33554432;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "AssignPrimary": 1n,
                    "Duplicate": 2n,
                    "Impersonate": 4n,
                    "Query": 8n,
                    "QuerySource": 16n,
                    "AdjustPrivileges": 32n,
                    "AdjustGroups": 64n,
                    "AdjustDefault": 128n,
                    "AdjustSessionId": 256n,
                    "Read": 131080n,
                    "Write": 131296n,
                    "AllAccess": 983551n,
                    "MaximumAllowed": 33554432n
                };
            }
            static $h = 502185;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":502185,"n":"AssignPrimary","d":502185,"h":4295469481,"f":33},{"t":502185,"n":"Duplicate","d":502185,"h":8590436777,"f":33},{"t":502185,"n":"Impersonate","d":502185,"h":12885404073,"f":33},{"t":502185,"n":"Query","d":502185,"h":17180371369,"f":33},{"t":502185,"n":"QuerySource","d":502185,"h":21475338665,"f":33},{"t":502185,"n":"AdjustPrivileges","d":502185,"h":25770305961,"f":33},{"t":502185,"n":"AdjustGroups","d":502185,"h":30065273257,"f":33},{"t":502185,"n":"AdjustDefault","d":502185,"h":34360240553,"f":33},{"t":502185,"n":"AdjustSessionId","d":502185,"h":38655207849,"f":33},{"t":502185,"n":"Read","d":502185,"h":42950175145,"f":33},{"t":502185,"n":"Write","d":502185,"h":47245142441,"f":33},{"t":502185,"n":"AllAccess","d":502185,"h":51540109737,"f":33},{"t":502185,"n":"MaximumAllowed","d":502185,"h":55835077033,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":502185,"h":60130044329,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":502185,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.Principal.TokenAccessLevels`; }
        });
        
        $asm.$str("$sspw.System.Security.Principal.WellKnownSidType", ($self) => class WellKnownSidType extends $.$spc.System.Enum
        {
            static NullSid = 0;
            static WorldSid = 1;
            static LocalSid = 2;
            static CreatorOwnerSid = 3;
            static CreatorGroupSid = 4;
            static CreatorOwnerServerSid = 5;
            static CreatorGroupServerSid = 6;
            static NTAuthoritySid = 7;
            static DialupSid = 8;
            static NetworkSid = 9;
            static BatchSid = 10;
            static InteractiveSid = 11;
            static ServiceSid = 12;
            static AnonymousSid = 13;
            static ProxySid = 14;
            static EnterpriseControllersSid = 15;
            static SelfSid = 16;
            static AuthenticatedUserSid = 17;
            static RestrictedCodeSid = 18;
            static TerminalServerSid = 19;
            static RemoteLogonIdSid = 20;
            static LogonIdsSid = 21;
            static LocalSystemSid = 22;
            static LocalServiceSid = 23;
            static NetworkServiceSid = 24;
            static BuiltinDomainSid = 25;
            static BuiltinAdministratorsSid = 26;
            static BuiltinUsersSid = 27;
            static BuiltinGuestsSid = 28;
            static BuiltinPowerUsersSid = 29;
            static BuiltinAccountOperatorsSid = 30;
            static BuiltinSystemOperatorsSid = 31;
            static BuiltinPrintOperatorsSid = 32;
            static BuiltinBackupOperatorsSid = 33;
            static BuiltinReplicatorSid = 34;
            static BuiltinPreWindows2000CompatibleAccessSid = 35;
            static BuiltinRemoteDesktopUsersSid = 36;
            static BuiltinNetworkConfigurationOperatorsSid = 37;
            static AccountAdministratorSid = 38;
            static AccountGuestSid = 39;
            static AccountKrbtgtSid = 40;
            static AccountDomainAdminsSid = 41;
            static AccountDomainUsersSid = 42;
            static AccountDomainGuestsSid = 43;
            static AccountComputersSid = 44;
            static AccountControllersSid = 45;
            static AccountCertAdminsSid = 46;
            static AccountSchemaAdminsSid = 47;
            static AccountEnterpriseAdminsSid = 48;
            static AccountPolicyAdminsSid = 49;
            static AccountRasAndIasServersSid = 50;
            static NtlmAuthenticationSid = 51;
            static DigestAuthenticationSid = 52;
            static SChannelAuthenticationSid = 53;
            static ThisOrganizationSid = 54;
            static OtherOrganizationSid = 55;
            static BuiltinIncomingForestTrustBuildersSid = 56;
            static BuiltinPerformanceMonitoringUsersSid = 57;
            static BuiltinPerformanceLoggingUsersSid = 58;
            static BuiltinAuthorizationAccessSid = 59;
            static MaxDefined = 60;
            static WinBuiltinTerminalServerLicenseServersSid = 60;
            static WinBuiltinDCOMUsersSid = 61;
            static WinBuiltinIUsersSid = 62;
            static WinIUserSid = 63;
            static WinBuiltinCryptoOperatorsSid = 64;
            static WinUntrustedLabelSid = 65;
            static WinLowLabelSid = 66;
            static WinMediumLabelSid = 67;
            static WinHighLabelSid = 68;
            static WinSystemLabelSid = 69;
            static WinWriteRestrictedCodeSid = 70;
            static WinCreatorOwnerRightsSid = 71;
            static WinCacheablePrincipalsGroupSid = 72;
            static WinNonCacheablePrincipalsGroupSid = 73;
            static WinEnterpriseReadonlyControllersSid = 74;
            static WinAccountReadonlyControllersSid = 75;
            static WinBuiltinEventLogReadersGroup = 76;
            static WinNewEnterpriseReadonlyControllersSid = 77;
            static WinBuiltinCertSvcDComAccessGroup = 78;
            static WinMediumPlusLabelSid = 79;
            static WinLocalLogonSid = 80;
            static WinConsoleLogonSid = 81;
            static WinThisOrganizationCertificateSid = 82;
            static WinApplicationPackageAuthoritySid = 83;
            static WinBuiltinAnyPackageSid = 84;
            static WinCapabilityInternetClientSid = 85;
            static WinCapabilityInternetClientServerSid = 86;
            static WinCapabilityPrivateNetworkClientServerSid = 87;
            static WinCapabilityPicturesLibrarySid = 88;
            static WinCapabilityVideosLibrarySid = 89;
            static WinCapabilityMusicLibrarySid = 90;
            static WinCapabilityDocumentsLibrarySid = 91;
            static WinCapabilitySharedUserCertificatesSid = 92;
            static WinCapabilityEnterpriseAuthenticationSid = 93;
            static WinCapabilityRemovableStorageSid = 94;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "NullSid": 0n,
                    "WorldSid": 1n,
                    "LocalSid": 2n,
                    "CreatorOwnerSid": 3n,
                    "CreatorGroupSid": 4n,
                    "CreatorOwnerServerSid": 5n,
                    "CreatorGroupServerSid": 6n,
                    "NTAuthoritySid": 7n,
                    "DialupSid": 8n,
                    "NetworkSid": 9n,
                    "BatchSid": 10n,
                    "InteractiveSid": 11n,
                    "ServiceSid": 12n,
                    "AnonymousSid": 13n,
                    "ProxySid": 14n,
                    "EnterpriseControllersSid": 15n,
                    "SelfSid": 16n,
                    "AuthenticatedUserSid": 17n,
                    "RestrictedCodeSid": 18n,
                    "TerminalServerSid": 19n,
                    "RemoteLogonIdSid": 20n,
                    "LogonIdsSid": 21n,
                    "LocalSystemSid": 22n,
                    "LocalServiceSid": 23n,
                    "NetworkServiceSid": 24n,
                    "BuiltinDomainSid": 25n,
                    "BuiltinAdministratorsSid": 26n,
                    "BuiltinUsersSid": 27n,
                    "BuiltinGuestsSid": 28n,
                    "BuiltinPowerUsersSid": 29n,
                    "BuiltinAccountOperatorsSid": 30n,
                    "BuiltinSystemOperatorsSid": 31n,
                    "BuiltinPrintOperatorsSid": 32n,
                    "BuiltinBackupOperatorsSid": 33n,
                    "BuiltinReplicatorSid": 34n,
                    "BuiltinPreWindows2000CompatibleAccessSid": 35n,
                    "BuiltinRemoteDesktopUsersSid": 36n,
                    "BuiltinNetworkConfigurationOperatorsSid": 37n,
                    "AccountAdministratorSid": 38n,
                    "AccountGuestSid": 39n,
                    "AccountKrbtgtSid": 40n,
                    "AccountDomainAdminsSid": 41n,
                    "AccountDomainUsersSid": 42n,
                    "AccountDomainGuestsSid": 43n,
                    "AccountComputersSid": 44n,
                    "AccountControllersSid": 45n,
                    "AccountCertAdminsSid": 46n,
                    "AccountSchemaAdminsSid": 47n,
                    "AccountEnterpriseAdminsSid": 48n,
                    "AccountPolicyAdminsSid": 49n,
                    "AccountRasAndIasServersSid": 50n,
                    "NtlmAuthenticationSid": 51n,
                    "DigestAuthenticationSid": 52n,
                    "SChannelAuthenticationSid": 53n,
                    "ThisOrganizationSid": 54n,
                    "OtherOrganizationSid": 55n,
                    "BuiltinIncomingForestTrustBuildersSid": 56n,
                    "BuiltinPerformanceMonitoringUsersSid": 57n,
                    "BuiltinPerformanceLoggingUsersSid": 58n,
                    "BuiltinAuthorizationAccessSid": 59n,
                    "MaxDefined": 60n,
                    "WinBuiltinTerminalServerLicenseServersSid": 60n,
                    "WinBuiltinDCOMUsersSid": 61n,
                    "WinBuiltinIUsersSid": 62n,
                    "WinIUserSid": 63n,
                    "WinBuiltinCryptoOperatorsSid": 64n,
                    "WinUntrustedLabelSid": 65n,
                    "WinLowLabelSid": 66n,
                    "WinMediumLabelSid": 67n,
                    "WinHighLabelSid": 68n,
                    "WinSystemLabelSid": 69n,
                    "WinWriteRestrictedCodeSid": 70n,
                    "WinCreatorOwnerRightsSid": 71n,
                    "WinCacheablePrincipalsGroupSid": 72n,
                    "WinNonCacheablePrincipalsGroupSid": 73n,
                    "WinEnterpriseReadonlyControllersSid": 74n,
                    "WinAccountReadonlyControllersSid": 75n,
                    "WinBuiltinEventLogReadersGroup": 76n,
                    "WinNewEnterpriseReadonlyControllersSid": 77n,
                    "WinBuiltinCertSvcDComAccessGroup": 78n,
                    "WinMediumPlusLabelSid": 79n,
                    "WinLocalLogonSid": 80n,
                    "WinConsoleLogonSid": 81n,
                    "WinThisOrganizationCertificateSid": 82n,
                    "WinApplicationPackageAuthoritySid": 83n,
                    "WinBuiltinAnyPackageSid": 84n,
                    "WinCapabilityInternetClientSid": 85n,
                    "WinCapabilityInternetClientServerSid": 86n,
                    "WinCapabilityPrivateNetworkClientServerSid": 87n,
                    "WinCapabilityPicturesLibrarySid": 88n,
                    "WinCapabilityVideosLibrarySid": 89n,
                    "WinCapabilityMusicLibrarySid": 90n,
                    "WinCapabilityDocumentsLibrarySid": 91n,
                    "WinCapabilitySharedUserCertificatesSid": 92n,
                    "WinCapabilityEnterpriseAuthenticationSid": 93n,
                    "WinCapabilityRemovableStorageSid": 94n
                };
            }
            static $h = 567721;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":567721,"n":"NullSid","d":567721,"h":4295535017,"f":33},{"t":567721,"n":"WorldSid","d":567721,"h":8590502313,"f":33},{"t":567721,"n":"LocalSid","d":567721,"h":12885469609,"f":33},{"t":567721,"n":"CreatorOwnerSid","d":567721,"h":17180436905,"f":33},{"t":567721,"n":"CreatorGroupSid","d":567721,"h":21475404201,"f":33},{"t":567721,"n":"CreatorOwnerServerSid","d":567721,"h":25770371497,"f":33},{"t":567721,"n":"CreatorGroupServerSid","d":567721,"h":30065338793,"f":33},{"t":567721,"n":"NTAuthoritySid","d":567721,"h":34360306089,"f":33},{"t":567721,"n":"DialupSid","d":567721,"h":38655273385,"f":33},{"t":567721,"n":"NetworkSid","d":567721,"h":42950240681,"f":33},{"t":567721,"n":"BatchSid","d":567721,"h":47245207977,"f":33},{"t":567721,"n":"InteractiveSid","d":567721,"h":51540175273,"f":33},{"t":567721,"n":"ServiceSid","d":567721,"h":55835142569,"f":33},{"t":567721,"n":"AnonymousSid","d":567721,"h":60130109865,"f":33},{"t":567721,"n":"ProxySid","d":567721,"h":64425077161,"f":33},{"t":567721,"n":"EnterpriseControllersSid","d":567721,"h":68720044457,"f":33},{"t":567721,"n":"SelfSid","d":567721,"h":73015011753,"f":33},{"t":567721,"n":"AuthenticatedUserSid","d":567721,"h":77309979049,"f":33},{"t":567721,"n":"RestrictedCodeSid","d":567721,"h":81604946345,"f":33},{"t":567721,"n":"TerminalServerSid","d":567721,"h":85899913641,"f":33},{"t":567721,"n":"RemoteLogonIdSid","d":567721,"h":90194880937,"f":33},{"t":567721,"n":"LogonIdsSid","d":567721,"h":94489848233,"f":33},{"t":567721,"n":"LocalSystemSid","d":567721,"h":98784815529,"f":33},{"t":567721,"n":"LocalServiceSid","d":567721,"h":103079782825,"f":33},{"t":567721,"n":"NetworkServiceSid","d":567721,"h":107374750121,"f":33},{"t":567721,"n":"BuiltinDomainSid","d":567721,"h":111669717417,"f":33},{"t":567721,"n":"BuiltinAdministratorsSid","d":567721,"h":115964684713,"f":33},{"t":567721,"n":"BuiltinUsersSid","d":567721,"h":120259652009,"f":33},{"t":567721,"n":"BuiltinGuestsSid","d":567721,"h":124554619305,"f":33},{"t":567721,"n":"BuiltinPowerUsersSid","d":567721,"h":128849586601,"f":33},{"t":567721,"n":"BuiltinAccountOperatorsSid","d":567721,"h":133144553897,"f":33},{"t":567721,"n":"BuiltinSystemOperatorsSid","d":567721,"h":137439521193,"f":33},{"t":567721,"n":"BuiltinPrintOperatorsSid","d":567721,"h":141734488489,"f":33},{"t":567721,"n":"BuiltinBackupOperatorsSid","d":567721,"h":146029455785,"f":33},{"t":567721,"n":"BuiltinReplicatorSid","d":567721,"h":150324423081,"f":33},{"t":567721,"n":"BuiltinPreWindows2000CompatibleAccessSid","d":567721,"h":154619390377,"f":33},{"t":567721,"n":"BuiltinRemoteDesktopUsersSid","d":567721,"h":158914357673,"f":33},{"t":567721,"n":"BuiltinNetworkConfigurationOperatorsSid","d":567721,"h":163209324969,"f":33},{"t":567721,"n":"AccountAdministratorSid","d":567721,"h":167504292265,"f":33},{"t":567721,"n":"AccountGuestSid","d":567721,"h":171799259561,"f":33},{"t":567721,"n":"AccountKrbtgtSid","d":567721,"h":176094226857,"f":33},{"t":567721,"n":"AccountDomainAdminsSid","d":567721,"h":180389194153,"f":33},{"t":567721,"n":"AccountDomainUsersSid","d":567721,"h":184684161449,"f":33},{"t":567721,"n":"AccountDomainGuestsSid","d":567721,"h":188979128745,"f":33},{"t":567721,"n":"AccountComputersSid","d":567721,"h":193274096041,"f":33},{"t":567721,"n":"AccountControllersSid","d":567721,"h":197569063337,"f":33},{"t":567721,"n":"AccountCertAdminsSid","d":567721,"h":201864030633,"f":33},{"t":567721,"n":"AccountSchemaAdminsSid","d":567721,"h":206158997929,"f":33},{"t":567721,"n":"AccountEnterpriseAdminsSid","d":567721,"h":210453965225,"f":33},{"t":567721,"n":"AccountPolicyAdminsSid","d":567721,"h":214748932521,"f":33},{"t":567721,"n":"AccountRasAndIasServersSid","d":567721,"h":219043899817,"f":33},{"t":567721,"n":"NtlmAuthenticationSid","d":567721,"h":223338867113,"f":33},{"t":567721,"n":"DigestAuthenticationSid","d":567721,"h":227633834409,"f":33},{"t":567721,"n":"SChannelAuthenticationSid","d":567721,"h":231928801705,"f":33},{"t":567721,"n":"ThisOrganizationSid","d":567721,"h":236223769001,"f":33},{"t":567721,"n":"OtherOrganizationSid","d":567721,"h":240518736297,"f":33},{"t":567721,"n":"BuiltinIncomingForestTrustBuildersSid","d":567721,"h":244813703593,"f":33},{"t":567721,"n":"BuiltinPerformanceMonitoringUsersSid","d":567721,"h":249108670889,"f":33},{"t":567721,"n":"BuiltinPerformanceLoggingUsersSid","d":567721,"h":253403638185,"f":33},{"t":567721,"n":"BuiltinAuthorizationAccessSid","d":567721,"h":257698605481,"f":33},{"t":567721,"n":"MaxDefined","d":567721,"h":261993572777,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]},{"t":70909953,"c":8660844545,"a":[{"v":"This member has been deprecated and is only maintained for backwards compatability. WellKnownSidType values greater than MaxDefined may be defined in future releases.","t":1310721}]}]},{"t":567721,"n":"WinBuiltinTerminalServerLicenseServersSid","d":567721,"h":266288540073,"f":33},{"t":567721,"n":"WinBuiltinDCOMUsersSid","d":567721,"h":270583507369,"f":33},{"t":567721,"n":"WinBuiltinIUsersSid","d":567721,"h":274878474665,"f":33},{"t":567721,"n":"WinIUserSid","d":567721,"h":279173441961,"f":33},{"t":567721,"n":"WinBuiltinCryptoOperatorsSid","d":567721,"h":283468409257,"f":33},{"t":567721,"n":"WinUntrustedLabelSid","d":567721,"h":287763376553,"f":33},{"t":567721,"n":"WinLowLabelSid","d":567721,"h":292058343849,"f":33},{"t":567721,"n":"WinMediumLabelSid","d":567721,"h":296353311145,"f":33},{"t":567721,"n":"WinHighLabelSid","d":567721,"h":300648278441,"f":33},{"t":567721,"n":"WinSystemLabelSid","d":567721,"h":304943245737,"f":33},{"t":567721,"n":"WinWriteRestrictedCodeSid","d":567721,"h":309238213033,"f":33},{"t":567721,"n":"WinCreatorOwnerRightsSid","d":567721,"h":313533180329,"f":33},{"t":567721,"n":"WinCacheablePrincipalsGroupSid","d":567721,"h":317828147625,"f":33},{"t":567721,"n":"WinNonCacheablePrincipalsGroupSid","d":567721,"h":322123114921,"f":33},{"t":567721,"n":"WinEnterpriseReadonlyControllersSid","d":567721,"h":326418082217,"f":33},{"t":567721,"n":"WinAccountReadonlyControllersSid","d":567721,"h":330713049513,"f":33},{"t":567721,"n":"WinBuiltinEventLogReadersGroup","d":567721,"h":335008016809,"f":33},{"t":567721,"n":"WinNewEnterpriseReadonlyControllersSid","d":567721,"h":339302984105,"f":33},{"t":567721,"n":"WinBuiltinCertSvcDComAccessGroup","d":567721,"h":343597951401,"f":33},{"t":567721,"n":"WinMediumPlusLabelSid","d":567721,"h":347892918697,"f":33},{"t":567721,"n":"WinLocalLogonSid","d":567721,"h":352187885993,"f":33},{"t":567721,"n":"WinConsoleLogonSid","d":567721,"h":356482853289,"f":33},{"t":567721,"n":"WinThisOrganizationCertificateSid","d":567721,"h":360777820585,"f":33},{"t":567721,"n":"WinApplicationPackageAuthoritySid","d":567721,"h":365072787881,"f":33},{"t":567721,"n":"WinBuiltinAnyPackageSid","d":567721,"h":369367755177,"f":33},{"t":567721,"n":"WinCapabilityInternetClientSid","d":567721,"h":373662722473,"f":33},{"t":567721,"n":"WinCapabilityInternetClientServerSid","d":567721,"h":377957689769,"f":33},{"t":567721,"n":"WinCapabilityPrivateNetworkClientServerSid","d":567721,"h":382252657065,"f":33},{"t":567721,"n":"WinCapabilityPicturesLibrarySid","d":567721,"h":386547624361,"f":33},{"t":567721,"n":"WinCapabilityVideosLibrarySid","d":567721,"h":390842591657,"f":33},{"t":567721,"n":"WinCapabilityMusicLibrarySid","d":567721,"h":395137558953,"f":33},{"t":567721,"n":"WinCapabilityDocumentsLibrarySid","d":567721,"h":399432526249,"f":33},{"t":567721,"n":"WinCapabilitySharedUserCertificatesSid","d":567721,"h":403727493545,"f":33},{"t":567721,"n":"WinCapabilityEnterpriseAuthenticationSid","d":567721,"h":408022460841,"f":33},{"t":567721,"n":"WinCapabilityRemovableStorageSid","d":567721,"h":412317428137,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":567721,"h":416612395433,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":567721}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.Principal.WellKnownSidType`; }
        });
        
        $asm.$str("$sspw.System.Security.Principal.WindowsAccountType", ($self) => class WindowsAccountType extends $.$spc.System.Enum
        {
            static Normal = 0;
            static Guest = 1;
            static System = 2;
            static Anonymous = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Normal": 0n,
                    "Guest": 1n,
                    "System": 2n,
                    "Anonymous": 3n
                };
            }
            static $h = 633257;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":633257,"n":"Normal","d":633257,"h":4295600553,"f":33},{"t":633257,"n":"Guest","d":633257,"h":8590567849,"f":33},{"t":633257,"n":"System","d":633257,"h":12885535145,"f":33},{"t":633257,"n":"Anonymous","d":633257,"h":17180502441,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":633257,"h":21475469737,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":633257}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.Principal.WindowsAccountType`; }
        });
        
        $asm.$str("$sspw.System.Security.Principal.WindowsBuiltInRole", ($self) => class WindowsBuiltInRole extends $.$spc.System.Enum
        {
            static Administrator = 544;
            static User = 545;
            static Guest = 546;
            static PowerUser = 547;
            static AccountOperator = 548;
            static SystemOperator = 549;
            static PrintOperator = 550;
            static BackupOperator = 551;
            static Replicator = 552;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Administrator": 544n,
                    "User": 545n,
                    "Guest": 546n,
                    "PowerUser": 547n,
                    "AccountOperator": 548n,
                    "SystemOperator": 549n,
                    "PrintOperator": 550n,
                    "BackupOperator": 551n,
                    "Replicator": 552n
                };
            }
            static $h = 698793;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":698793,"n":"Administrator","d":698793,"h":4295666089,"f":33},{"t":698793,"n":"User","d":698793,"h":8590633385,"f":33},{"t":698793,"n":"Guest","d":698793,"h":12885600681,"f":33},{"t":698793,"n":"PowerUser","d":698793,"h":17180567977,"f":33},{"t":698793,"n":"AccountOperator","d":698793,"h":21475535273,"f":33},{"t":698793,"n":"SystemOperator","d":698793,"h":25770502569,"f":33},{"t":698793,"n":"PrintOperator","d":698793,"h":30065469865,"f":33},{"t":698793,"n":"BackupOperator","d":698793,"h":34360437161,"f":33},{"t":698793,"n":"Replicator","d":698793,"h":38655404457,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":698793,"h":42950371753,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":698793}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.Principal.WindowsBuiltInRole`; }
        });
        
        $asm.$cls("$sspw.System.Security.Principal.WindowsPrincipal", ($self) => class WindowsPrincipal extends $.$ssc.System.Security.Claims.ClaimsPrincipal
        {
            $ctor$7(/*System.Security.Principal.WindowsIdentity*/ ntIdentity)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*System.Collections.Generic.IEnumerable<System.Security.Claims.Claim> */ get DeviceClaims()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IIdentity */ get Identity()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.IEnumerable<System.Security.Claims.Claim> */ get UserClaims()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ IsInRole$1(/*int*/ rid)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ IsInRole$2(/*System.Security.Principal.SecurityIdentifier*/ sid)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ IsInRole$3(/*System.Security.Principal.WindowsBuiltInRole*/ role)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ IsInRole(/*string*/ role)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 829865;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":450305,"p":[{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"g":{"r":0,"d":0,"h":12885731753,"f":129},"n":"DeviceClaims","d":829865,"h":8590764457,"f":129},{"p":117047297,"g":{"r":0,"d":0,"h":21475666345,"f":32769},"n":"Identity","d":829865,"h":17180699049,"f":32769},{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"g":{"r":0,"d":0,"h":30065600937,"f":129},"n":"UserClaims","d":829865,"h":25770633641,"f":129}],"m":[{"r":262145,"p":[{"n":"rid","p":655361}],"n":"IsInRole","o":"@$1","d":829865,"h":34360568233,"f":129},{"r":262145,"p":[{"n":"sid","p":436649}],"n":"IsInRole","o":"@$2","d":829865,"h":38655535529,"f":129},{"r":262145,"p":[{"n":"role","p":698793}],"n":"IsInRole","o":"@$3","d":829865,"h":42950502825,"f":129},{"r":262145,"p":[{"n":"role","p":1310721}],"n":"IsInRole","d":829865,"h":47245470121,"f":32769}],"c":[{"p":[{"n":"ntIdentity","p":764329}],"n":".ctor","o":"$ctor$7","d":829865,"h":4295797161,"f":1}],"i":[117112833],"h":829865}; }
            static get $b() { return $.$ssc.System.Security.Claims.ClaimsPrincipal; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Security.Principal.IPrincipal ]; }
            static get $fullName() { return `System.Security.Principal.WindowsPrincipal`; }
        });
        
        $asm.$cls("$sspw.System.Security.Principal.WindowsIdentity", ($self) => class WindowsIdentity extends $.$ssc.System.Security.Claims.ClaimsIdentity
        {
            /*string*/ static DefaultIssuer = null;
            $ctor$17(/*System.IntPtr*/ userToken)
            {
                super.$ctor$14(null, null, null, null, null, 5);
                {
                }
                return this;
            }
            $ctor$18(/*System.IntPtr*/ userToken, /*string*/ type)
            {
                super.$ctor$14(null, null, null, null, null, 5);
                {
                }
                return this;
            }
            $ctor$19(/*System.IntPtr*/ userToken, /*string*/ type, /*System.Security.Principal.WindowsAccountType*/ acctType)
            {
                super.$ctor$14(null, null, null, null, null, 5);
                {
                }
                return this;
            }
            $ctor$20(/*System.IntPtr*/ userToken, /*string*/ type, /*System.Security.Principal.WindowsAccountType*/ acctType, /*bool*/ isAuthenticated)
            {
                super.$ctor$14(null, null, null, null, null, 5);
                {
                }
                return this;
            }
            $ctor$21(/*System.Runtime.Serialization.SerializationInfo*/ info, /*System.Runtime.Serialization.StreamingContext*/ context)
            {
                super.$ctor$14(null, null, null, null, null, 5);
                {
                }
                return this;
            }
            $ctor$22(/*System.Security.Principal.WindowsIdentity*/ identity)
            {
                super.$ctor$14(null, null, null, null, null, 5);
                {
                }
                return this;
            }
            $ctor$23(/*string*/ sUserPrincipalName)
            {
                super.$ctor$14(null, null, null, null, null, 5);
                {
                }
                return this;
            }
            /*Microsoft.Win32.SafeHandles.SafeAccessTokenHandle */ get AccessToken()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get AuthenticationType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.IEnumerable<System.Security.Claims.Claim> */ get Claims()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.IEnumerable<System.Security.Claims.Claim> */ get DeviceClaims()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IdentityReferenceCollection? */ get Groups()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.TokenImpersonationLevel */ get ImpersonationLevel()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsAnonymous()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsAuthenticated()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsGuest()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsSystem()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Name()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ get Owner()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ get Token()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ get User()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.IEnumerable<System.Security.Claims.Claim> */ get UserClaims()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Claims.ClaimsIdentity */ Clone()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose()
            {
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            static /*System.Security.Principal.WindowsIdentity */ GetAnonymous()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Security.Principal.WindowsIdentity */ GetCurrent()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Security.Principal.WindowsIdentity? */ GetCurrent$1(/*bool*/ ifImpersonating)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Security.Principal.WindowsIdentity */ GetCurrent$2(/*System.Security.Principal.TokenAccessLevels*/ desiredAccess)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*void */ RunImpersonated(/*Microsoft.Win32.SafeHandles.SafeAccessTokenHandle*/ safeAccessTokenHandle, /*System.Action*/ action)
            {
            }
            static /*System.Threading.Tasks.Task */ RunImpersonatedAsync(/*Microsoft.Win32.SafeHandles.SafeAccessTokenHandle*/ safeAccessTokenHandle, /*System.Func<System.Threading.Tasks.Task>*/ func)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<T> */ RunImpersonatedAsync$1(T, /*Microsoft.Win32.SafeHandles.SafeAccessTokenHandle*/ safeAccessTokenHandle, /*System.Func<System.Threading.Tasks.Task<T>>*/ func)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*T */ RunImpersonated$1(T, /*Microsoft.Win32.SafeHandles.SafeAccessTokenHandle*/ safeAccessTokenHandle, /*System.Func<T>*/ func)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ System$Runtime$Serialization$IDeserializationCallback$OnDeserialization(/*object?*/ sender)
            {
            }
            /*void */ System$Runtime$Serialization$ISerializable$GetObjectData(/*System.Runtime.Serialization.SerializationInfo*/ info, /*System.Runtime.Serialization.StreamingContext*/ context)
            {
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.DefaultIssuer = "AD AUTHORITY";
                }
            }
            static $h = 764329;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":319233,"p":[{"p":108969,"g":{"r":0,"d":0,"h":42950437289,"f":1},"n":"AccessToken","d":764329,"h":38655469993,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":51540371881,"f":98305},"n":"AuthenticationType","d":764329,"h":47245404585,"f":98305},{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"g":{"r":0,"d":0,"h":60130306473,"f":32769},"n":"Claims","d":764329,"h":55835339177,"f":32769},{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"g":{"r":0,"d":0,"h":68720241065,"f":129},"n":"DeviceClaims","d":764329,"h":64425273769,"f":129},{"p":305577,"g":{"r":0,"d":0,"h":77310175657,"f":1},"n":"Groups","d":764329,"h":73015208361,"f":1},{"p":117243905,"g":{"r":0,"d":0,"h":85900110249,"f":1},"n":"ImpersonationLevel","d":764329,"h":81605142953,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":94490044841,"f":129},"n":"IsAnonymous","d":764329,"h":90195077545,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":103079979433,"f":32769},"n":"IsAuthenticated","d":764329,"h":98785012137,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":111669914025,"f":129},"n":"IsGuest","d":764329,"h":107374946729,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":120259848617,"f":129},"n":"IsSystem","d":764329,"h":115964881321,"f":129},{"p":1310721,"g":{"r":0,"d":0,"h":128849783209,"f":32769},"n":"Name","d":764329,"h":124554815913,"f":32769},{"p":436649,"g":{"r":0,"d":0,"h":137439717801,"f":1},"n":"Owner","d":764329,"h":133144750505,"f":1},{"p":786433,"g":{"r":0,"d":0,"h":146029652393,"f":129},"n":"Token","d":764329,"h":141734685097,"f":129},{"p":436649,"g":{"r":0,"d":0,"h":154619586985,"f":1},"n":"User","d":764329,"h":150324619689,"f":1},{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"g":{"r":0,"d":0,"h":163209521577,"f":129},"n":"UserClaims","d":764329,"h":158914554281,"f":129}],"m":[{"r":319233,"n":"Clone","d":764329,"h":167504488873,"f":32769},{"r":65537,"n":"Dispose","d":764329,"h":171799456169,"f":1},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":764329,"h":176094423465,"f":132},{"r":764329,"n":"GetAnonymous","d":764329,"h":180389390761,"f":33},{"r":764329,"n":"GetCurrent","d":764329,"h":184684358057,"f":33},{"r":764329,"p":[{"n":"ifImpersonating","p":262145}],"n":"GetCurrent","o":"@$1","d":764329,"h":188979325353,"f":33},{"r":764329,"p":[{"n":"desiredAccess","p":502185}],"n":"GetCurrent","o":"@$2","d":764329,"h":193274292649,"f":33},{"r":65537,"p":[{"n":"safeAccessTokenHandle","p":108969},{"n":"action","p":11665409}],"n":"RunImpersonated","d":764329,"h":197569259945,"f":33},{"r":133300225,"p":[{"n":"safeAccessTokenHandle","p":108969},{"n":"func","p":$.$spc.System.Func$$($.$spc.System.Threading.Tasks.Task).$h}],"n":"RunImpersonatedAsync","d":764329,"h":201864227241,"f":33},{"r":(T) => $.$spc.System.Threading.Tasks.Task$$(T).$h,"p":[{"n":"safeAccessTokenHandle","p":108969},{"n":"func","p":(T) => $.$spc.System.Func$$($.$spc.System.Threading.Tasks.Task$$(T)).$h}],"g":["T"],"n":"RunImpersonatedAsync","o":"@$1","d":764329,"h":206159194537,"f":131105},{"r":206162034688,"p":[{"n":"safeAccessTokenHandle","p":108969},{"n":"func","p":(T) => $.$spc.System.Func$$(T).$h}],"g":["T"],"n":"RunImpersonated","o":"@$1","d":764329,"h":210454161833,"f":131105}],"l":[{"t":1310721,"n":"DefaultIssuer","d":764329,"h":4295731625,"f":33}],"c":[{"p":[{"n":"userToken","p":786433}],"n":".ctor","o":"$ctor$17","d":764329,"h":8590698921,"f":1},{"p":[{"n":"userToken","p":786433},{"n":"type","p":1310721}],"n":".ctor","o":"$ctor$18","d":764329,"h":12885666217,"f":1},{"p":[{"n":"userToken","p":786433},{"n":"type","p":1310721},{"n":"acctType","p":633257}],"n":".ctor","o":"$ctor$19","d":764329,"h":17180633513,"f":1},{"p":[{"n":"userToken","p":786433},{"n":"type","p":1310721},{"n":"acctType","p":633257},{"n":"isAuthenticated","p":262145}],"n":".ctor","o":"$ctor$20","d":764329,"h":21475600809,"f":1},{"p":[{"n":"info","p":113967105},{"n":"context","p":114098177}],"n":".ctor","o":"$ctor$21","d":764329,"h":25770568105,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This API supports obsolete formatter-based serialization. It should not be called or extended by application code.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0051","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]},{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"p":[{"n":"identity","p":764329}],"n":".ctor","o":"$ctor$22","d":764329,"h":30065535401,"f":4},{"p":[{"n":"sUserPrincipalName","p":1310721}],"n":".ctor","o":"$ctor$23","d":764329,"h":34360502697,"f":1}],"i":[117047297,57475073,113115137,113377281],"h":764329}; }
            static get $b() { return $.$ssc.System.Security.Claims.ClaimsIdentity; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Security.Principal.IIdentity, $.$spc.System.IDisposable, $.$spc.System.Runtime.Serialization.IDeserializationCallback, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Security.Principal.WindowsIdentity`; }
        });
        
        $asm.$cls("$sspw.System.Security.Principal.IdentityNotMappedException", ($self) => class IdentityNotMappedException extends $.$spc.System.SystemException
        {
            $ctor$9()
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            $ctor$10(/*string?*/ message)
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            $ctor$11(/*string?*/ message, /*System.Exception?*/ inner)
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            /*System.Security.Principal.IdentityReferenceCollection */ get UnmappedIdentities()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetObjectData(/*System.Runtime.Serialization.SerializationInfo*/ serializationInfo, /*System.Runtime.Serialization.StreamingContext*/ streamingContext)
            {
            }
            static $h = 174505;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":119668737,"h":174505}; }
            static get $b() { return $.$spc.System.SystemException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Security.Principal.IdentityNotMappedException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Threading", "NetJs.System.Threading.Thread", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Security.Claims", "NetJs.System.Runtime.InteropServices"))