
(function ($global, $, $spc, $mwp, $sc, $sdt, $sm, $spu, $st, $stt, $sr, $scc, $ssc, $sris) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Security.Principal.Windows", 
    {"h":59208,"f":"System.Security.Principal.Windows","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B760b8187d87d291733fdcda9f4d484d24d61a938","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Security.Principal.Windows","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Security.Principal.Windows","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sspw.System.Security.Principal.IdentityReference", ($self) => class IdentityReference extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static /*bool */ op_Equality(/*System.Security.Principal.IdentityReference?*/ left, /*System.Security.Principal.IdentityReference?*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ op_Inequality(/*System.Security.Principal.IdentityReference?*/ left, /*System.Security.Principal.IdentityReference?*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 255816;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12885157704,"f":257},"n":"Value","d":255816,"h":8590190408,"f":257}],"m":[{"r":262145,"p":[{"n":"o","p":131073}],"n":"Equals","d":255816,"h":17180125000,"f":33025},{"r":655361,"n":"GetHashCode","d":255816,"h":21475092296,"f":33025},{"r":262145,"p":[{"n":"targetType","p":142606337}],"n":"IsValidTargetType","d":255816,"h":25770059592,"f":257},{"r":1310721,"n":"ToString","d":255816,"h":38654961480,"f":33025},{"r":255816,"p":[{"n":"targetType","p":142606337}],"n":"Translate","d":255816,"h":42949928776,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":255816,"h":4295223112,"f":8}],"h":255816}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Security.Principal.IdentityReference`; }
        });
        
        $asm.$cls("$sspw.System.Security.Principal.IdentityReferenceCollection", ($self) => class IdentityReferenceCollection extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*int*/ capacity)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get Count()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IdentityReference*/ get_Item(/*int*/ index)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void*/ set_Item(/*int*/ index, /*System.Security.Principal.IdentityReference*/ value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get System$Collections$Generic$ICollection$$$IsReadOnly()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Add(/*System.Security.Principal.IdentityReference*/ identity)
            {
            }
            /*void */ Clear()
            {
            }
            /*bool */ Contains(/*System.Security.Principal.IdentityReference*/ identity)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CopyTo(/*System.Security.Principal.IdentityReference[]*/ array, /*int*/ offset)
            {
            }
            /*System.Collections.Generic.IEnumerator<System.Security.Principal.IdentityReference> */ GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Remove(/*System.Security.Principal.IdentityReference*/ identity)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IdentityReferenceCollection */ Translate(/*System.Type*/ targetType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IdentityReferenceCollection */ Translate$1(/*System.Type*/ targetType, /*bool*/ forceSuccess)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Security.Principal.IdentityReference>.Count.get
            get System$Collections$Generic$ICollection$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Security.Principal.IdentityReference>.Add(System.Security.Principal.IdentityReference)
            System$Collections$Generic$ICollection$$$Add()
            {
                return this.Add(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Security.Principal.IdentityReference>.Clear()
            System$Collections$Generic$ICollection$$$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Security.Principal.IdentityReference>.Contains(System.Security.Principal.IdentityReference)
            System$Collections$Generic$ICollection$$$Contains()
            {
                return this.Contains(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Security.Principal.IdentityReference>.CopyTo(System.Security.Principal.IdentityReference[], int)
            System$Collections$Generic$ICollection$$$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Security.Principal.IdentityReference>.Remove(System.Security.Principal.IdentityReference)
            System$Collections$Generic$ICollection$$$Remove()
            {
                return this.Remove(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Security.Principal.IdentityReference>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 321352;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":17180190536,"f":1},"n":"Count","d":321352,"h":12885223240,"f":1},{"p":255816,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":25770125128,"f":1},"s":{"r":0,"d":0,"h":30065092424,"f":1},"n":"Item","o":"@$2","d":321352,"h":21475157832,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":38655027016,"f":2},"n":"{$.$spc.System.Collections.Generic.ICollection$$($.$sspw.System.Security.Principal.IdentityReference).$h}.IsReadOnly","o":"System$Collections$Generic$ICollection$$$IsReadOnly","d":321352,"h":34360059720,"f":2}],"m":[{"r":65537,"p":[{"n":"identity","p":255816}],"n":"Add","d":321352,"h":42949994312,"f":1},{"r":65537,"n":"Clear","d":321352,"h":47244961608,"f":1},{"r":262145,"p":[{"n":"identity","p":255816}],"n":"Contains","d":321352,"h":51539928904,"f":1},{"r":65537,"p":[{"n":"array","p":0},{"n":"offset","p":655361}],"n":"CopyTo","d":321352,"h":55834896200,"f":1},{"r":$.$spc.System.Collections.Generic.IEnumerator$$($.$sspw.System.Security.Principal.IdentityReference).$h,"n":"GetEnumerator","d":321352,"h":60129863496,"f":1},{"r":262145,"p":[{"n":"identity","p":255816}],"n":"Remove","d":321352,"h":64424830792,"f":1},{"r":321352,"p":[{"n":"targetType","p":142606337}],"n":"Translate","d":321352,"h":73014765384,"f":1},{"r":321352,"p":[{"n":"targetType","p":142606337},{"n":"forceSuccess","p":262145}],"n":"Translate","o":"@$1","d":321352,"h":77309732680,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":321352,"h":4295288648,"f":1},{"p":[{"n":"capacity","p":655361}],"n":".ctor","o":"$ctor$2","d":321352,"h":8590255944,"f":1}],"i":[$.$spc.System.Collections.Generic.ICollection$$($.$sspw.System.Security.Principal.IdentityReference).$h,$.$spc.System.Collections.Generic.IEnumerable$$($.$sspw.System.Security.Principal.IdentityReference).$h,31588353],"h":321352}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.ICollection$$($.$sspw.System.Security.Principal.IdentityReference), $.$spc.System.Collections.Generic.IEnumerable$$($.$sspw.System.Security.Principal.IdentityReference), $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Security.Principal.IdentityReferenceCollection`; }
        });
        
        $asm.$cls("$sspw.System.Security.Principal.NTAccount", ($self) => class NTAccount extends $.$sspw.System.Security.Principal.IdentityReference
        {
            $ctor$2(/*string*/ name)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$3(/*string*/ domainName, /*string*/ accountName)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*string */ get Value()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ o)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sspw.System.Security.Principal.NTAccount.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sspw.System.Security.Principal.NTAccount.GetHashCode.apply(this, arguments); }
            /*bool */ IsValidTargetType(/*System.Type*/ targetType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ op_Equality$1(/*System.Security.Principal.NTAccount?*/ left, /*System.Security.Principal.NTAccount?*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ op_Inequality$1(/*System.Security.Principal.NTAccount?*/ left, /*System.Security.Principal.NTAccount?*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sspw.System.Security.Principal.NTAccount.ToString.apply(this, arguments); }
            /*System.Security.Principal.IdentityReference */ Translate(/*System.Type*/ targetType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 386888;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":255816,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17180256072,"f":32769},"n":"Value","d":386888,"h":12885288776,"f":32769}],"m":[{"r":262145,"p":[{"n":"o","p":131073}],"n":"Equals","d":386888,"h":21475223368,"f":32769},{"r":655361,"n":"GetHashCode","d":386888,"h":25770190664,"f":32769},{"r":262145,"p":[{"n":"targetType","p":142606337}],"n":"IsValidTargetType","d":386888,"h":30065157960,"f":32769},{"r":1310721,"n":"ToString","d":386888,"h":42950059848,"f":32769},{"r":255816,"p":[{"n":"targetType","p":142606337}],"n":"Translate","d":386888,"h":47245027144,"f":32769}],"c":[{"p":[{"n":"name","p":1310721}],"n":".ctor","o":"$ctor$2","d":386888,"h":4295354184,"f":1},{"p":[{"n":"domainName","p":1310721},{"n":"accountName","p":1310721}],"n":".ctor","o":"$ctor$3","d":386888,"h":8590321480,"f":1}],"h":386888}; }
            static get $b() { return $.$sspw.System.Security.Principal.IdentityReference; }
            static get $fullName() { return `System.Security.Principal.NTAccount`; }
        });
        
        $asm.$cls("$sspw.System.Security.Principal.SecurityIdentifier", ($self) => class SecurityIdentifier extends $.$sspw.System.Security.Principal.IdentityReference
        {
            /*int*/ static MaxBinaryLength = 0;
            /*int*/ static MinBinaryLength = 0;
            $ctor$2(/*byte[]*/ binaryForm, /*int*/ offset)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$3(/*System.IntPtr*/ binaryForm)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$4(/*System.Security.Principal.WellKnownSidType*/ sidType, /*System.Security.Principal.SecurityIdentifier?*/ domainSid)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$5(/*string*/ sddlForm)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Security.Principal.SecurityIdentifier? */ get AccountDomainSid()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get BinaryLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Value()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ CompareTo(/*System.Security.Principal.SecurityIdentifier?*/ sid)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ o)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sspw.System.Security.Principal.SecurityIdentifier.Equals.apply(this, arguments); }
            /*bool */ Equals$2(/*System.Security.Principal.SecurityIdentifier*/ sid)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sspw.System.Security.Principal.SecurityIdentifier.GetHashCode.apply(this, arguments); }
            /*bool */ IsAccountSid()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ IsEqualDomainSid(/*System.Security.Principal.SecurityIdentifier*/ sid)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ IsValidTargetType(/*System.Type*/ targetType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ IsWellKnown(/*System.Security.Principal.WellKnownSidType*/ type)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ op_Equality$1(/*System.Security.Principal.SecurityIdentifier?*/ left, /*System.Security.Principal.SecurityIdentifier?*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ op_Inequality$1(/*System.Security.Principal.SecurityIdentifier?*/ left, /*System.Security.Principal.SecurityIdentifier?*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sspw.System.Security.Principal.SecurityIdentifier.ToString.apply(this, arguments); }
            /*System.Security.Principal.IdentityReference */ Translate(/*System.Type*/ targetType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.IComparable<System.Security.Principal.SecurityIdentifier>.CompareTo(System.Security.Principal.SecurityIdentifier?)
            System$IComparable$$$CompareTo()
            {
                return this.CompareTo(...arguments);
            }
            static $h = 452424;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":255816,"p":[{"p":452424,"g":{"r":0,"d":0,"h":34360190792,"f":1},"n":"AccountDomainSid","d":452424,"h":30065223496,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":42950125384,"f":1},"n":"BinaryLength","d":452424,"h":38655158088,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":51540059976,"f":32769},"n":"Value","d":452424,"h":47245092680,"f":32769}],"m":[{"r":655361,"p":[{"n":"sid","p":452424}],"n":"CompareTo","d":452424,"h":55835027272,"f":1},{"r":262145,"p":[{"n":"o","p":131073}],"n":"Equals","d":452424,"h":60129994568,"f":32769},{"r":262145,"p":[{"n":"sid","p":452424}],"n":"Equals","o":"@$2","d":452424,"h":64424961864,"f":1},{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":452424,"h":68719929160,"f":1},{"r":655361,"n":"GetHashCode","d":452424,"h":73014896456,"f":32769},{"r":262145,"n":"IsAccountSid","d":452424,"h":77309863752,"f":1},{"r":262145,"p":[{"n":"sid","p":452424}],"n":"IsEqualDomainSid","d":452424,"h":81604831048,"f":1},{"r":262145,"p":[{"n":"targetType","p":142606337}],"n":"IsValidTargetType","d":452424,"h":85899798344,"f":32769},{"r":262145,"p":[{"n":"type","p":583496}],"n":"IsWellKnown","d":452424,"h":90194765640,"f":1},{"r":1310721,"n":"ToString","d":452424,"h":103079667528,"f":32769},{"r":255816,"p":[{"n":"targetType","p":142606337}],"n":"Translate","d":452424,"h":107374634824,"f":32769}],"l":[{"t":655361,"n":"MaxBinaryLength","d":452424,"h":4295419720,"f":33},{"t":655361,"n":"MinBinaryLength","d":452424,"h":8590387016,"f":33}],"c":[{"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":".ctor","o":"$ctor$2","d":452424,"h":12885354312,"f":1},{"p":[{"n":"binaryForm","p":786433}],"n":".ctor","o":"$ctor$3","d":452424,"h":17180321608,"f":1},{"p":[{"n":"sidType","p":583496},{"n":"domainSid","p":452424}],"n":".ctor","o":"$ctor$4","d":452424,"h":21475288904,"f":1},{"p":[{"n":"sddlForm","p":1310721}],"n":".ctor","o":"$ctor$5","d":452424,"h":25770256200,"f":1}],"i":[$.$spc.System.IComparable$$($.$sspw.System.Security.Principal.SecurityIdentifier).$h],"h":452424}; }
            static get $b() { return $.$sspw.System.Security.Principal.IdentityReference; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable$$($.$sspw.System.Security.Principal.SecurityIdentifier) ]; }
            static get $fullName() { return `System.Security.Principal.SecurityIdentifier`; }
        });
        
        $asm.$cls("$sspw.Microsoft.Win32.SafeHandles.SafeAccessTokenHandle", ($self) => class SafeAccessTokenHandle extends $.$spc.System.Runtime.InteropServices.SafeHandle
        {
            $ctor$3()
            {
                super.$ctor$2(0, false);
                {
                }
                return this;
            }
            $ctor$4(/*System.IntPtr*/ handle)
            {
                super.$ctor$2(0, false);
                {
                }
                return this;
            }
            static /*Microsoft.Win32.SafeHandles.SafeAccessTokenHandle */ get InvalidHandle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsInvalid()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ReleaseHandle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 124744;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":109576193,"p":[{"p":124744,"g":{"r":0,"d":0,"h":17179993928,"f":33},"n":"InvalidHandle","d":124744,"h":12885026632,"f":33},{"p":262145,"g":{"r":0,"d":0,"h":25769928520,"f":32769},"n":"IsInvalid","d":124744,"h":21474961224,"f":32769}],"m":[{"r":262145,"n":"ReleaseHandle","d":124744,"h":30064895816,"f":32772}],"c":[{"n":".ctor","o":"$ctor$3","d":124744,"h":4295092040,"f":1},{"p":[{"n":"handle","p":786433}],"n":".ctor","o":"$ctor$4","d":124744,"h":8590059336,"f":1}],"i":[57475073],"h":124744}; }
            static get $b() { return $.$spc.System.Runtime.InteropServices.SafeHandle; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Win32.SafeHandles.SafeAccessTokenHandle`; }
        });
        
        $asm.$str("$sspw.System.Security.Principal.TokenAccessLevels", ($self) => class TokenAccessLevels extends $.$spc.System.Enum
        {
            static AssignPrimary = 1;
            static Duplicate = 2;
            static Impersonate = 4;
            static Query = 8;
            static QuerySource = 16;
            static AdjustPrivileges = 32;
            static AdjustGroups = 64;
            static AdjustDefault = 128;
            static AdjustSessionId = 256;
            static Read = 131080;
            static Write = 131296;
            static AllAccess = 983551;
            static MaximumAllowed = 33554432;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "AssignPrimary": 1n,
                    "Duplicate": 2n,
                    "Impersonate": 4n,
                    "Query": 8n,
                    "QuerySource": 16n,
                    "AdjustPrivileges": 32n,
                    "AdjustGroups": 64n,
                    "AdjustDefault": 128n,
                    "AdjustSessionId": 256n,
                    "Read": 131080n,
                    "Write": 131296n,
                    "AllAccess": 983551n,
                    "MaximumAllowed": 33554432n
                };
            }
            static $h = 517960;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":517960,"n":"AssignPrimary","d":517960,"h":4295485256,"f":33},{"t":517960,"n":"Duplicate","d":517960,"h":8590452552,"f":33},{"t":517960,"n":"Impersonate","d":517960,"h":12885419848,"f":33},{"t":517960,"n":"Query","d":517960,"h":17180387144,"f":33},{"t":517960,"n":"QuerySource","d":517960,"h":21475354440,"f":33},{"t":517960,"n":"AdjustPrivileges","d":517960,"h":25770321736,"f":33},{"t":517960,"n":"AdjustGroups","d":517960,"h":30065289032,"f":33},{"t":517960,"n":"AdjustDefault","d":517960,"h":34360256328,"f":33},{"t":517960,"n":"AdjustSessionId","d":517960,"h":38655223624,"f":33},{"t":517960,"n":"Read","d":517960,"h":42950190920,"f":33},{"t":517960,"n":"Write","d":517960,"h":47245158216,"f":33},{"t":517960,"n":"AllAccess","d":517960,"h":51540125512,"f":33},{"t":517960,"n":"MaximumAllowed","d":517960,"h":55835092808,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":517960,"h":60130060104,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":517960,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.Principal.TokenAccessLevels`; }
        });
        
        $asm.$str("$sspw.System.Security.Principal.WellKnownSidType", ($self) => class WellKnownSidType extends $.$spc.System.Enum
        {
            static NullSid = 0;
            static WorldSid = 1;
            static LocalSid = 2;
            static CreatorOwnerSid = 3;
            static CreatorGroupSid = 4;
            static CreatorOwnerServerSid = 5;
            static CreatorGroupServerSid = 6;
            static NTAuthoritySid = 7;
            static DialupSid = 8;
            static NetworkSid = 9;
            static BatchSid = 10;
            static InteractiveSid = 11;
            static ServiceSid = 12;
            static AnonymousSid = 13;
            static ProxySid = 14;
            static EnterpriseControllersSid = 15;
            static SelfSid = 16;
            static AuthenticatedUserSid = 17;
            static RestrictedCodeSid = 18;
            static TerminalServerSid = 19;
            static RemoteLogonIdSid = 20;
            static LogonIdsSid = 21;
            static LocalSystemSid = 22;
            static LocalServiceSid = 23;
            static NetworkServiceSid = 24;
            static BuiltinDomainSid = 25;
            static BuiltinAdministratorsSid = 26;
            static BuiltinUsersSid = 27;
            static BuiltinGuestsSid = 28;
            static BuiltinPowerUsersSid = 29;
            static BuiltinAccountOperatorsSid = 30;
            static BuiltinSystemOperatorsSid = 31;
            static BuiltinPrintOperatorsSid = 32;
            static BuiltinBackupOperatorsSid = 33;
            static BuiltinReplicatorSid = 34;
            static BuiltinPreWindows2000CompatibleAccessSid = 35;
            static BuiltinRemoteDesktopUsersSid = 36;
            static BuiltinNetworkConfigurationOperatorsSid = 37;
            static AccountAdministratorSid = 38;
            static AccountGuestSid = 39;
            static AccountKrbtgtSid = 40;
            static AccountDomainAdminsSid = 41;
            static AccountDomainUsersSid = 42;
            static AccountDomainGuestsSid = 43;
            static AccountComputersSid = 44;
            static AccountControllersSid = 45;
            static AccountCertAdminsSid = 46;
            static AccountSchemaAdminsSid = 47;
            static AccountEnterpriseAdminsSid = 48;
            static AccountPolicyAdminsSid = 49;
            static AccountRasAndIasServersSid = 50;
            static NtlmAuthenticationSid = 51;
            static DigestAuthenticationSid = 52;
            static SChannelAuthenticationSid = 53;
            static ThisOrganizationSid = 54;
            static OtherOrganizationSid = 55;
            static BuiltinIncomingForestTrustBuildersSid = 56;
            static BuiltinPerformanceMonitoringUsersSid = 57;
            static BuiltinPerformanceLoggingUsersSid = 58;
            static BuiltinAuthorizationAccessSid = 59;
            static MaxDefined = 60;
            static WinBuiltinTerminalServerLicenseServersSid = 60;
            static WinBuiltinDCOMUsersSid = 61;
            static WinBuiltinIUsersSid = 62;
            static WinIUserSid = 63;
            static WinBuiltinCryptoOperatorsSid = 64;
            static WinUntrustedLabelSid = 65;
            static WinLowLabelSid = 66;
            static WinMediumLabelSid = 67;
            static WinHighLabelSid = 68;
            static WinSystemLabelSid = 69;
            static WinWriteRestrictedCodeSid = 70;
            static WinCreatorOwnerRightsSid = 71;
            static WinCacheablePrincipalsGroupSid = 72;
            static WinNonCacheablePrincipalsGroupSid = 73;
            static WinEnterpriseReadonlyControllersSid = 74;
            static WinAccountReadonlyControllersSid = 75;
            static WinBuiltinEventLogReadersGroup = 76;
            static WinNewEnterpriseReadonlyControllersSid = 77;
            static WinBuiltinCertSvcDComAccessGroup = 78;
            static WinMediumPlusLabelSid = 79;
            static WinLocalLogonSid = 80;
            static WinConsoleLogonSid = 81;
            static WinThisOrganizationCertificateSid = 82;
            static WinApplicationPackageAuthoritySid = 83;
            static WinBuiltinAnyPackageSid = 84;
            static WinCapabilityInternetClientSid = 85;
            static WinCapabilityInternetClientServerSid = 86;
            static WinCapabilityPrivateNetworkClientServerSid = 87;
            static WinCapabilityPicturesLibrarySid = 88;
            static WinCapabilityVideosLibrarySid = 89;
            static WinCapabilityMusicLibrarySid = 90;
            static WinCapabilityDocumentsLibrarySid = 91;
            static WinCapabilitySharedUserCertificatesSid = 92;
            static WinCapabilityEnterpriseAuthenticationSid = 93;
            static WinCapabilityRemovableStorageSid = 94;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "NullSid": 0n,
                    "WorldSid": 1n,
                    "LocalSid": 2n,
                    "CreatorOwnerSid": 3n,
                    "CreatorGroupSid": 4n,
                    "CreatorOwnerServerSid": 5n,
                    "CreatorGroupServerSid": 6n,
                    "NTAuthoritySid": 7n,
                    "DialupSid": 8n,
                    "NetworkSid": 9n,
                    "BatchSid": 10n,
                    "InteractiveSid": 11n,
                    "ServiceSid": 12n,
                    "AnonymousSid": 13n,
                    "ProxySid": 14n,
                    "EnterpriseControllersSid": 15n,
                    "SelfSid": 16n,
                    "AuthenticatedUserSid": 17n,
                    "RestrictedCodeSid": 18n,
                    "TerminalServerSid": 19n,
                    "RemoteLogonIdSid": 20n,
                    "LogonIdsSid": 21n,
                    "LocalSystemSid": 22n,
                    "LocalServiceSid": 23n,
                    "NetworkServiceSid": 24n,
                    "BuiltinDomainSid": 25n,
                    "BuiltinAdministratorsSid": 26n,
                    "BuiltinUsersSid": 27n,
                    "BuiltinGuestsSid": 28n,
                    "BuiltinPowerUsersSid": 29n,
                    "BuiltinAccountOperatorsSid": 30n,
                    "BuiltinSystemOperatorsSid": 31n,
                    "BuiltinPrintOperatorsSid": 32n,
                    "BuiltinBackupOperatorsSid": 33n,
                    "BuiltinReplicatorSid": 34n,
                    "BuiltinPreWindows2000CompatibleAccessSid": 35n,
                    "BuiltinRemoteDesktopUsersSid": 36n,
                    "BuiltinNetworkConfigurationOperatorsSid": 37n,
                    "AccountAdministratorSid": 38n,
                    "AccountGuestSid": 39n,
                    "AccountKrbtgtSid": 40n,
                    "AccountDomainAdminsSid": 41n,
                    "AccountDomainUsersSid": 42n,
                    "AccountDomainGuestsSid": 43n,
                    "AccountComputersSid": 44n,
                    "AccountControllersSid": 45n,
                    "AccountCertAdminsSid": 46n,
                    "AccountSchemaAdminsSid": 47n,
                    "AccountEnterpriseAdminsSid": 48n,
                    "AccountPolicyAdminsSid": 49n,
                    "AccountRasAndIasServersSid": 50n,
                    "NtlmAuthenticationSid": 51n,
                    "DigestAuthenticationSid": 52n,
                    "SChannelAuthenticationSid": 53n,
                    "ThisOrganizationSid": 54n,
                    "OtherOrganizationSid": 55n,
                    "BuiltinIncomingForestTrustBuildersSid": 56n,
                    "BuiltinPerformanceMonitoringUsersSid": 57n,
                    "BuiltinPerformanceLoggingUsersSid": 58n,
                    "BuiltinAuthorizationAccessSid": 59n,
                    "MaxDefined": 60n,
                    "WinBuiltinTerminalServerLicenseServersSid": 60n,
                    "WinBuiltinDCOMUsersSid": 61n,
                    "WinBuiltinIUsersSid": 62n,
                    "WinIUserSid": 63n,
                    "WinBuiltinCryptoOperatorsSid": 64n,
                    "WinUntrustedLabelSid": 65n,
                    "WinLowLabelSid": 66n,
                    "WinMediumLabelSid": 67n,
                    "WinHighLabelSid": 68n,
                    "WinSystemLabelSid": 69n,
                    "WinWriteRestrictedCodeSid": 70n,
                    "WinCreatorOwnerRightsSid": 71n,
                    "WinCacheablePrincipalsGroupSid": 72n,
                    "WinNonCacheablePrincipalsGroupSid": 73n,
                    "WinEnterpriseReadonlyControllersSid": 74n,
                    "WinAccountReadonlyControllersSid": 75n,
                    "WinBuiltinEventLogReadersGroup": 76n,
                    "WinNewEnterpriseReadonlyControllersSid": 77n,
                    "WinBuiltinCertSvcDComAccessGroup": 78n,
                    "WinMediumPlusLabelSid": 79n,
                    "WinLocalLogonSid": 80n,
                    "WinConsoleLogonSid": 81n,
                    "WinThisOrganizationCertificateSid": 82n,
                    "WinApplicationPackageAuthoritySid": 83n,
                    "WinBuiltinAnyPackageSid": 84n,
                    "WinCapabilityInternetClientSid": 85n,
                    "WinCapabilityInternetClientServerSid": 86n,
                    "WinCapabilityPrivateNetworkClientServerSid": 87n,
                    "WinCapabilityPicturesLibrarySid": 88n,
                    "WinCapabilityVideosLibrarySid": 89n,
                    "WinCapabilityMusicLibrarySid": 90n,
                    "WinCapabilityDocumentsLibrarySid": 91n,
                    "WinCapabilitySharedUserCertificatesSid": 92n,
                    "WinCapabilityEnterpriseAuthenticationSid": 93n,
                    "WinCapabilityRemovableStorageSid": 94n
                };
            }
            static $h = 583496;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":583496,"n":"NullSid","d":583496,"h":4295550792,"f":33},{"t":583496,"n":"WorldSid","d":583496,"h":8590518088,"f":33},{"t":583496,"n":"LocalSid","d":583496,"h":12885485384,"f":33},{"t":583496,"n":"CreatorOwnerSid","d":583496,"h":17180452680,"f":33},{"t":583496,"n":"CreatorGroupSid","d":583496,"h":21475419976,"f":33},{"t":583496,"n":"CreatorOwnerServerSid","d":583496,"h":25770387272,"f":33},{"t":583496,"n":"CreatorGroupServerSid","d":583496,"h":30065354568,"f":33},{"t":583496,"n":"NTAuthoritySid","d":583496,"h":34360321864,"f":33},{"t":583496,"n":"DialupSid","d":583496,"h":38655289160,"f":33},{"t":583496,"n":"NetworkSid","d":583496,"h":42950256456,"f":33},{"t":583496,"n":"BatchSid","d":583496,"h":47245223752,"f":33},{"t":583496,"n":"InteractiveSid","d":583496,"h":51540191048,"f":33},{"t":583496,"n":"ServiceSid","d":583496,"h":55835158344,"f":33},{"t":583496,"n":"AnonymousSid","d":583496,"h":60130125640,"f":33},{"t":583496,"n":"ProxySid","d":583496,"h":64425092936,"f":33},{"t":583496,"n":"EnterpriseControllersSid","d":583496,"h":68720060232,"f":33},{"t":583496,"n":"SelfSid","d":583496,"h":73015027528,"f":33},{"t":583496,"n":"AuthenticatedUserSid","d":583496,"h":77309994824,"f":33},{"t":583496,"n":"RestrictedCodeSid","d":583496,"h":81604962120,"f":33},{"t":583496,"n":"TerminalServerSid","d":583496,"h":85899929416,"f":33},{"t":583496,"n":"RemoteLogonIdSid","d":583496,"h":90194896712,"f":33},{"t":583496,"n":"LogonIdsSid","d":583496,"h":94489864008,"f":33},{"t":583496,"n":"LocalSystemSid","d":583496,"h":98784831304,"f":33},{"t":583496,"n":"LocalServiceSid","d":583496,"h":103079798600,"f":33},{"t":583496,"n":"NetworkServiceSid","d":583496,"h":107374765896,"f":33},{"t":583496,"n":"BuiltinDomainSid","d":583496,"h":111669733192,"f":33},{"t":583496,"n":"BuiltinAdministratorsSid","d":583496,"h":115964700488,"f":33},{"t":583496,"n":"BuiltinUsersSid","d":583496,"h":120259667784,"f":33},{"t":583496,"n":"BuiltinGuestsSid","d":583496,"h":124554635080,"f":33},{"t":583496,"n":"BuiltinPowerUsersSid","d":583496,"h":128849602376,"f":33},{"t":583496,"n":"BuiltinAccountOperatorsSid","d":583496,"h":133144569672,"f":33},{"t":583496,"n":"BuiltinSystemOperatorsSid","d":583496,"h":137439536968,"f":33},{"t":583496,"n":"BuiltinPrintOperatorsSid","d":583496,"h":141734504264,"f":33},{"t":583496,"n":"BuiltinBackupOperatorsSid","d":583496,"h":146029471560,"f":33},{"t":583496,"n":"BuiltinReplicatorSid","d":583496,"h":150324438856,"f":33},{"t":583496,"n":"BuiltinPreWindows2000CompatibleAccessSid","d":583496,"h":154619406152,"f":33},{"t":583496,"n":"BuiltinRemoteDesktopUsersSid","d":583496,"h":158914373448,"f":33},{"t":583496,"n":"BuiltinNetworkConfigurationOperatorsSid","d":583496,"h":163209340744,"f":33},{"t":583496,"n":"AccountAdministratorSid","d":583496,"h":167504308040,"f":33},{"t":583496,"n":"AccountGuestSid","d":583496,"h":171799275336,"f":33},{"t":583496,"n":"AccountKrbtgtSid","d":583496,"h":176094242632,"f":33},{"t":583496,"n":"AccountDomainAdminsSid","d":583496,"h":180389209928,"f":33},{"t":583496,"n":"AccountDomainUsersSid","d":583496,"h":184684177224,"f":33},{"t":583496,"n":"AccountDomainGuestsSid","d":583496,"h":188979144520,"f":33},{"t":583496,"n":"AccountComputersSid","d":583496,"h":193274111816,"f":33},{"t":583496,"n":"AccountControllersSid","d":583496,"h":197569079112,"f":33},{"t":583496,"n":"AccountCertAdminsSid","d":583496,"h":201864046408,"f":33},{"t":583496,"n":"AccountSchemaAdminsSid","d":583496,"h":206159013704,"f":33},{"t":583496,"n":"AccountEnterpriseAdminsSid","d":583496,"h":210453981000,"f":33},{"t":583496,"n":"AccountPolicyAdminsSid","d":583496,"h":214748948296,"f":33},{"t":583496,"n":"AccountRasAndIasServersSid","d":583496,"h":219043915592,"f":33},{"t":583496,"n":"NtlmAuthenticationSid","d":583496,"h":223338882888,"f":33},{"t":583496,"n":"DigestAuthenticationSid","d":583496,"h":227633850184,"f":33},{"t":583496,"n":"SChannelAuthenticationSid","d":583496,"h":231928817480,"f":33},{"t":583496,"n":"ThisOrganizationSid","d":583496,"h":236223784776,"f":33},{"t":583496,"n":"OtherOrganizationSid","d":583496,"h":240518752072,"f":33},{"t":583496,"n":"BuiltinIncomingForestTrustBuildersSid","d":583496,"h":244813719368,"f":33},{"t":583496,"n":"BuiltinPerformanceMonitoringUsersSid","d":583496,"h":249108686664,"f":33},{"t":583496,"n":"BuiltinPerformanceLoggingUsersSid","d":583496,"h":253403653960,"f":33},{"t":583496,"n":"BuiltinAuthorizationAccessSid","d":583496,"h":257698621256,"f":33},{"t":583496,"n":"MaxDefined","d":583496,"h":261993588552,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]},{"t":70909953,"c":8660844545,"a":[{"v":"This member has been deprecated and is only maintained for backwards compatability. WellKnownSidType values greater than MaxDefined may be defined in future releases.","t":1310721}]}]},{"t":583496,"n":"WinBuiltinTerminalServerLicenseServersSid","d":583496,"h":266288555848,"f":33},{"t":583496,"n":"WinBuiltinDCOMUsersSid","d":583496,"h":270583523144,"f":33},{"t":583496,"n":"WinBuiltinIUsersSid","d":583496,"h":274878490440,"f":33},{"t":583496,"n":"WinIUserSid","d":583496,"h":279173457736,"f":33},{"t":583496,"n":"WinBuiltinCryptoOperatorsSid","d":583496,"h":283468425032,"f":33},{"t":583496,"n":"WinUntrustedLabelSid","d":583496,"h":287763392328,"f":33},{"t":583496,"n":"WinLowLabelSid","d":583496,"h":292058359624,"f":33},{"t":583496,"n":"WinMediumLabelSid","d":583496,"h":296353326920,"f":33},{"t":583496,"n":"WinHighLabelSid","d":583496,"h":300648294216,"f":33},{"t":583496,"n":"WinSystemLabelSid","d":583496,"h":304943261512,"f":33},{"t":583496,"n":"WinWriteRestrictedCodeSid","d":583496,"h":309238228808,"f":33},{"t":583496,"n":"WinCreatorOwnerRightsSid","d":583496,"h":313533196104,"f":33},{"t":583496,"n":"WinCacheablePrincipalsGroupSid","d":583496,"h":317828163400,"f":33},{"t":583496,"n":"WinNonCacheablePrincipalsGroupSid","d":583496,"h":322123130696,"f":33},{"t":583496,"n":"WinEnterpriseReadonlyControllersSid","d":583496,"h":326418097992,"f":33},{"t":583496,"n":"WinAccountReadonlyControllersSid","d":583496,"h":330713065288,"f":33},{"t":583496,"n":"WinBuiltinEventLogReadersGroup","d":583496,"h":335008032584,"f":33},{"t":583496,"n":"WinNewEnterpriseReadonlyControllersSid","d":583496,"h":339302999880,"f":33},{"t":583496,"n":"WinBuiltinCertSvcDComAccessGroup","d":583496,"h":343597967176,"f":33},{"t":583496,"n":"WinMediumPlusLabelSid","d":583496,"h":347892934472,"f":33},{"t":583496,"n":"WinLocalLogonSid","d":583496,"h":352187901768,"f":33},{"t":583496,"n":"WinConsoleLogonSid","d":583496,"h":356482869064,"f":33},{"t":583496,"n":"WinThisOrganizationCertificateSid","d":583496,"h":360777836360,"f":33},{"t":583496,"n":"WinApplicationPackageAuthoritySid","d":583496,"h":365072803656,"f":33},{"t":583496,"n":"WinBuiltinAnyPackageSid","d":583496,"h":369367770952,"f":33},{"t":583496,"n":"WinCapabilityInternetClientSid","d":583496,"h":373662738248,"f":33},{"t":583496,"n":"WinCapabilityInternetClientServerSid","d":583496,"h":377957705544,"f":33},{"t":583496,"n":"WinCapabilityPrivateNetworkClientServerSid","d":583496,"h":382252672840,"f":33},{"t":583496,"n":"WinCapabilityPicturesLibrarySid","d":583496,"h":386547640136,"f":33},{"t":583496,"n":"WinCapabilityVideosLibrarySid","d":583496,"h":390842607432,"f":33},{"t":583496,"n":"WinCapabilityMusicLibrarySid","d":583496,"h":395137574728,"f":33},{"t":583496,"n":"WinCapabilityDocumentsLibrarySid","d":583496,"h":399432542024,"f":33},{"t":583496,"n":"WinCapabilitySharedUserCertificatesSid","d":583496,"h":403727509320,"f":33},{"t":583496,"n":"WinCapabilityEnterpriseAuthenticationSid","d":583496,"h":408022476616,"f":33},{"t":583496,"n":"WinCapabilityRemovableStorageSid","d":583496,"h":412317443912,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":583496,"h":416612411208,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":583496}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.Principal.WellKnownSidType`; }
        });
        
        $asm.$str("$sspw.System.Security.Principal.WindowsAccountType", ($self) => class WindowsAccountType extends $.$spc.System.Enum
        {
            static Normal = 0;
            static Guest = 1;
            static System = 2;
            static Anonymous = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Normal": 0n,
                    "Guest": 1n,
                    "System": 2n,
                    "Anonymous": 3n
                };
            }
            static $h = 649032;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":649032,"n":"Normal","d":649032,"h":4295616328,"f":33},{"t":649032,"n":"Guest","d":649032,"h":8590583624,"f":33},{"t":649032,"n":"System","d":649032,"h":12885550920,"f":33},{"t":649032,"n":"Anonymous","d":649032,"h":17180518216,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":649032,"h":21475485512,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":649032}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.Principal.WindowsAccountType`; }
        });
        
        $asm.$str("$sspw.System.Security.Principal.WindowsBuiltInRole", ($self) => class WindowsBuiltInRole extends $.$spc.System.Enum
        {
            static Administrator = 544;
            static User = 545;
            static Guest = 546;
            static PowerUser = 547;
            static AccountOperator = 548;
            static SystemOperator = 549;
            static PrintOperator = 550;
            static BackupOperator = 551;
            static Replicator = 552;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Administrator": 544n,
                    "User": 545n,
                    "Guest": 546n,
                    "PowerUser": 547n,
                    "AccountOperator": 548n,
                    "SystemOperator": 549n,
                    "PrintOperator": 550n,
                    "BackupOperator": 551n,
                    "Replicator": 552n
                };
            }
            static $h = 714568;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":714568,"n":"Administrator","d":714568,"h":4295681864,"f":33},{"t":714568,"n":"User","d":714568,"h":8590649160,"f":33},{"t":714568,"n":"Guest","d":714568,"h":12885616456,"f":33},{"t":714568,"n":"PowerUser","d":714568,"h":17180583752,"f":33},{"t":714568,"n":"AccountOperator","d":714568,"h":21475551048,"f":33},{"t":714568,"n":"SystemOperator","d":714568,"h":25770518344,"f":33},{"t":714568,"n":"PrintOperator","d":714568,"h":30065485640,"f":33},{"t":714568,"n":"BackupOperator","d":714568,"h":34360452936,"f":33},{"t":714568,"n":"Replicator","d":714568,"h":38655420232,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":714568,"h":42950387528,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":714568}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.Principal.WindowsBuiltInRole`; }
        });
        
        $asm.$cls("$sspw.System.Security.Principal.WindowsPrincipal", ($self) => class WindowsPrincipal extends $.$ssc.System.Security.Claims.ClaimsPrincipal
        {
            $ctor$7(/*System.Security.Principal.WindowsIdentity*/ ntIdentity)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*System.Collections.Generic.IEnumerable<System.Security.Claims.Claim> */ get DeviceClaims()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IIdentity */ get Identity()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.IEnumerable<System.Security.Claims.Claim> */ get UserClaims()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ IsInRole$1(/*int*/ rid)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ IsInRole$2(/*System.Security.Principal.SecurityIdentifier*/ sid)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ IsInRole$3(/*System.Security.Principal.WindowsBuiltInRole*/ role)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ IsInRole(/*string*/ role)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 845640;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":438614,"p":[{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"g":{"r":0,"d":0,"h":12885747528,"f":129},"n":"DeviceClaims","d":845640,"h":8590780232,"f":129},{"p":117047297,"g":{"r":0,"d":0,"h":21475682120,"f":32769},"n":"Identity","d":845640,"h":17180714824,"f":32769},{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"g":{"r":0,"d":0,"h":30065616712,"f":129},"n":"UserClaims","d":845640,"h":25770649416,"f":129}],"m":[{"r":262145,"p":[{"n":"rid","p":655361}],"n":"IsInRole","o":"@$1","d":845640,"h":34360584008,"f":129},{"r":262145,"p":[{"n":"sid","p":452424}],"n":"IsInRole","o":"@$2","d":845640,"h":38655551304,"f":129},{"r":262145,"p":[{"n":"role","p":714568}],"n":"IsInRole","o":"@$3","d":845640,"h":42950518600,"f":129},{"r":262145,"p":[{"n":"role","p":1310721}],"n":"IsInRole","d":845640,"h":47245485896,"f":32769}],"c":[{"p":[{"n":"ntIdentity","p":780104}],"n":".ctor","o":"$ctor$7","d":845640,"h":4295812936,"f":1}],"i":[117112833],"h":845640}; }
            static get $b() { return $.$ssc.System.Security.Claims.ClaimsPrincipal; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Security.Principal.IPrincipal ]; }
            static get $fullName() { return `System.Security.Principal.WindowsPrincipal`; }
        });
        
        $asm.$cls("$sspw.System.Security.Principal.WindowsIdentity", ($self) => class WindowsIdentity extends $.$ssc.System.Security.Claims.ClaimsIdentity
        {
            /*string*/ static DefaultIssuer = null;
            $ctor$17(/*System.IntPtr*/ userToken)
            {
                super.$ctor$14(null, null, null, null, null, 5);
                {
                }
                return this;
            }
            $ctor$18(/*System.IntPtr*/ userToken, /*string*/ type)
            {
                super.$ctor$14(null, null, null, null, null, 5);
                {
                }
                return this;
            }
            $ctor$19(/*System.IntPtr*/ userToken, /*string*/ type, /*System.Security.Principal.WindowsAccountType*/ acctType)
            {
                super.$ctor$14(null, null, null, null, null, 5);
                {
                }
                return this;
            }
            $ctor$20(/*System.IntPtr*/ userToken, /*string*/ type, /*System.Security.Principal.WindowsAccountType*/ acctType, /*bool*/ isAuthenticated)
            {
                super.$ctor$14(null, null, null, null, null, 5);
                {
                }
                return this;
            }
            $ctor$21(/*System.Runtime.Serialization.SerializationInfo*/ info, /*System.Runtime.Serialization.StreamingContext*/ context)
            {
                super.$ctor$14(null, null, null, null, null, 5);
                {
                }
                return this;
            }
            $ctor$22(/*System.Security.Principal.WindowsIdentity*/ identity)
            {
                super.$ctor$14(null, null, null, null, null, 5);
                {
                }
                return this;
            }
            $ctor$23(/*string*/ sUserPrincipalName)
            {
                super.$ctor$14(null, null, null, null, null, 5);
                {
                }
                return this;
            }
            /*Microsoft.Win32.SafeHandles.SafeAccessTokenHandle */ get AccessToken()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get AuthenticationType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.IEnumerable<System.Security.Claims.Claim> */ get Claims()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.IEnumerable<System.Security.Claims.Claim> */ get DeviceClaims()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IdentityReferenceCollection? */ get Groups()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.TokenImpersonationLevel */ get ImpersonationLevel()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsAnonymous()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsAuthenticated()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsGuest()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsSystem()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Name()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ get Owner()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ get Token()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ get User()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.IEnumerable<System.Security.Claims.Claim> */ get UserClaims()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Claims.ClaimsIdentity */ Clone()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose()
            {
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            static /*System.Security.Principal.WindowsIdentity */ GetAnonymous()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Security.Principal.WindowsIdentity */ GetCurrent()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Security.Principal.WindowsIdentity? */ GetCurrent$1(/*bool*/ ifImpersonating)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Security.Principal.WindowsIdentity */ GetCurrent$2(/*System.Security.Principal.TokenAccessLevels*/ desiredAccess)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*void */ RunImpersonated(/*Microsoft.Win32.SafeHandles.SafeAccessTokenHandle*/ safeAccessTokenHandle, /*System.Action*/ action)
            {
            }
            static /*System.Threading.Tasks.Task */ RunImpersonatedAsync(/*Microsoft.Win32.SafeHandles.SafeAccessTokenHandle*/ safeAccessTokenHandle, /*System.Func<System.Threading.Tasks.Task>*/ func)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<T> */ RunImpersonatedAsync$1(T, /*Microsoft.Win32.SafeHandles.SafeAccessTokenHandle*/ safeAccessTokenHandle, /*System.Func<System.Threading.Tasks.Task<T>>*/ func)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*T */ RunImpersonated$1(T, /*Microsoft.Win32.SafeHandles.SafeAccessTokenHandle*/ safeAccessTokenHandle, /*System.Func<T>*/ func)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ System$Runtime$Serialization$IDeserializationCallback$OnDeserialization(/*object?*/ sender)
            {
            }
            /*void */ System$Runtime$Serialization$ISerializable$GetObjectData(/*System.Runtime.Serialization.SerializationInfo*/ info, /*System.Runtime.Serialization.StreamingContext*/ context)
            {
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.DefaultIssuer = "AD AUTHORITY";
                }
            }
            static $h = 780104;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":307542,"p":[{"p":124744,"g":{"r":0,"d":0,"h":42950453064,"f":1},"n":"AccessToken","d":780104,"h":38655485768,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":51540387656,"f":98305},"n":"AuthenticationType","d":780104,"h":47245420360,"f":98305},{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"g":{"r":0,"d":0,"h":60130322248,"f":32769},"n":"Claims","d":780104,"h":55835354952,"f":32769},{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"g":{"r":0,"d":0,"h":68720256840,"f":129},"n":"DeviceClaims","d":780104,"h":64425289544,"f":129},{"p":321352,"g":{"r":0,"d":0,"h":77310191432,"f":1},"n":"Groups","d":780104,"h":73015224136,"f":1},{"p":117243905,"g":{"r":0,"d":0,"h":85900126024,"f":1},"n":"ImpersonationLevel","d":780104,"h":81605158728,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":94490060616,"f":129},"n":"IsAnonymous","d":780104,"h":90195093320,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":103079995208,"f":32769},"n":"IsAuthenticated","d":780104,"h":98785027912,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":111669929800,"f":129},"n":"IsGuest","d":780104,"h":107374962504,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":120259864392,"f":129},"n":"IsSystem","d":780104,"h":115964897096,"f":129},{"p":1310721,"g":{"r":0,"d":0,"h":128849798984,"f":32769},"n":"Name","d":780104,"h":124554831688,"f":32769},{"p":452424,"g":{"r":0,"d":0,"h":137439733576,"f":1},"n":"Owner","d":780104,"h":133144766280,"f":1},{"p":786433,"g":{"r":0,"d":0,"h":146029668168,"f":129},"n":"Token","d":780104,"h":141734700872,"f":129},{"p":452424,"g":{"r":0,"d":0,"h":154619602760,"f":1},"n":"User","d":780104,"h":150324635464,"f":1},{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"g":{"r":0,"d":0,"h":163209537352,"f":129},"n":"UserClaims","d":780104,"h":158914570056,"f":129}],"m":[{"r":307542,"n":"Clone","d":780104,"h":167504504648,"f":32769},{"r":65537,"n":"Dispose","d":780104,"h":171799471944,"f":1},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":780104,"h":176094439240,"f":132},{"r":780104,"n":"GetAnonymous","d":780104,"h":180389406536,"f":33},{"r":780104,"n":"GetCurrent","d":780104,"h":184684373832,"f":33},{"r":780104,"p":[{"n":"ifImpersonating","p":262145}],"n":"GetCurrent","o":"@$1","d":780104,"h":188979341128,"f":33},{"r":780104,"p":[{"n":"desiredAccess","p":517960}],"n":"GetCurrent","o":"@$2","d":780104,"h":193274308424,"f":33},{"r":65537,"p":[{"n":"safeAccessTokenHandle","p":124744},{"n":"action","p":11665409}],"n":"RunImpersonated","d":780104,"h":197569275720,"f":33},{"r":133300225,"p":[{"n":"safeAccessTokenHandle","p":124744},{"n":"func","p":$.$spc.System.Func$$($.$spc.System.Threading.Tasks.Task).$h}],"n":"RunImpersonatedAsync","d":780104,"h":201864243016,"f":33},{"r":(T) => $.$spc.System.Threading.Tasks.Task$$(T).$h,"p":[{"n":"safeAccessTokenHandle","p":124744},{"n":"func","p":(T) => $.$spc.System.Func$$($.$spc.System.Threading.Tasks.Task$$(T)).$h}],"g":["T"],"n":"RunImpersonatedAsync","o":"@$1","d":780104,"h":206159210312,"f":131105},{"r":(T) => T.$h,"p":[{"n":"safeAccessTokenHandle","p":124744},{"n":"func","p":(T) => $.$spc.System.Func$$(T).$h}],"g":["T"],"n":"RunImpersonated","o":"@$1","d":780104,"h":210454177608,"f":131105}],"l":[{"t":1310721,"n":"DefaultIssuer","d":780104,"h":4295747400,"f":33}],"c":[{"p":[{"n":"userToken","p":786433}],"n":".ctor","o":"$ctor$17","d":780104,"h":8590714696,"f":1},{"p":[{"n":"userToken","p":786433},{"n":"type","p":1310721}],"n":".ctor","o":"$ctor$18","d":780104,"h":12885681992,"f":1},{"p":[{"n":"userToken","p":786433},{"n":"type","p":1310721},{"n":"acctType","p":649032}],"n":".ctor","o":"$ctor$19","d":780104,"h":17180649288,"f":1},{"p":[{"n":"userToken","p":786433},{"n":"type","p":1310721},{"n":"acctType","p":649032},{"n":"isAuthenticated","p":262145}],"n":".ctor","o":"$ctor$20","d":780104,"h":21475616584,"f":1},{"p":[{"n":"info","p":113967105},{"n":"context","p":114098177}],"n":".ctor","o":"$ctor$21","d":780104,"h":25770583880,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This API supports obsolete formatter-based serialization. It should not be called or extended by application code.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0051","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]},{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"p":[{"n":"identity","p":780104}],"n":".ctor","o":"$ctor$22","d":780104,"h":30065551176,"f":4},{"p":[{"n":"sUserPrincipalName","p":1310721}],"n":".ctor","o":"$ctor$23","d":780104,"h":34360518472,"f":1}],"i":[117047297,57475073,113115137,113377281],"h":780104}; }
            static get $b() { return $.$ssc.System.Security.Claims.ClaimsIdentity; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Security.Principal.IIdentity, $.$spc.System.IDisposable, $.$spc.System.Runtime.Serialization.IDeserializationCallback, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Security.Principal.WindowsIdentity`; }
        });
        
        $asm.$cls("$sspw.System.Security.Principal.IdentityNotMappedException", ($self) => class IdentityNotMappedException extends $.$spc.System.SystemException
        {
            $ctor$9()
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            $ctor$10(/*string?*/ message)
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            $ctor$11(/*string?*/ message, /*System.Exception?*/ inner)
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            /*System.Security.Principal.IdentityReferenceCollection */ get UnmappedIdentities()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetObjectData(/*System.Runtime.Serialization.SerializationInfo*/ serializationInfo, /*System.Runtime.Serialization.StreamingContext*/ streamingContext)
            {
            }
            static $h = 190280;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":119668737,"h":190280}; }
            static get $b() { return $.$spc.System.SystemException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Security.Principal.IdentityNotMappedException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Threading", "NetJs.System.Threading.Thread", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Security.Claims", "NetJs.System.Runtime.InteropServices"))