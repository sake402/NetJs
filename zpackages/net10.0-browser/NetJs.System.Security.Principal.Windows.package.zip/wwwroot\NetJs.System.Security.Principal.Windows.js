
(function ($global, $, $spc, $mwp, $sc, $sdt, $sm, $spu, $st, $stt, $sr, $scc, $ssc, $sris) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Security.Principal.Windows", 
    {"h":50399,"f":"System.Security.Principal.Windows","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B5b8aaafb3aebad7fc7141c6e509af03c92d8b793","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Security.Principal.Windows","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Security.Principal.Windows","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sspw.System.Security.Principal.IdentityReference", ($self) => class IdentityReference extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static /*bool */ op_Equality(/*System.Security.Principal.IdentityReference?*/ left, /*System.Security.Principal.IdentityReference?*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ op_Inequality(/*System.Security.Principal.IdentityReference?*/ left, /*System.Security.Principal.IdentityReference?*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 247007;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12885148895,"f":257},"n":"Value","d":247007,"h":8590181599,"f":257}],"m":[{"r":262145,"p":[{"n":"o","p":131073}],"n":"Equals","d":247007,"h":17180116191,"f":33025},{"r":655361,"n":"GetHashCode","d":247007,"h":21475083487,"f":33025},{"r":262145,"p":[{"n":"targetType","p":142606337}],"n":"IsValidTargetType","d":247007,"h":25770050783,"f":257},{"r":1310721,"n":"ToString","d":247007,"h":38654952671,"f":33025},{"r":247007,"p":[{"n":"targetType","p":142606337}],"n":"Translate","d":247007,"h":42949919967,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":247007,"h":4295214303,"f":8}],"h":247007}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Security.Principal.IdentityReference`; }
        });
        
        $asm.$cls("$sspw.System.Security.Principal.IdentityReferenceCollection", ($self) => class IdentityReferenceCollection extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*int*/ capacity)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get Count()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IdentityReference*/ get_Item(/*int*/ index)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void*/ set_Item(/*int*/ index, /*System.Security.Principal.IdentityReference*/ value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get System$Collections$Generic$ICollection$$$IsReadOnly()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Add(/*System.Security.Principal.IdentityReference*/ identity)
            {
            }
            /*void */ Clear()
            {
            }
            /*bool */ Contains(/*System.Security.Principal.IdentityReference*/ identity)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CopyTo(/*System.Security.Principal.IdentityReference[]*/ array, /*int*/ offset)
            {
            }
            /*System.Collections.Generic.IEnumerator<System.Security.Principal.IdentityReference> */ GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Remove(/*System.Security.Principal.IdentityReference*/ identity)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IdentityReferenceCollection */ Translate(/*System.Type*/ targetType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IdentityReferenceCollection */ Translate$1(/*System.Type*/ targetType, /*bool*/ forceSuccess)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Security.Principal.IdentityReference>.Count.get
            get System$Collections$Generic$ICollection$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Security.Principal.IdentityReference>.Add(System.Security.Principal.IdentityReference)
            System$Collections$Generic$ICollection$$$Add()
            {
                return this.Add(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Security.Principal.IdentityReference>.Clear()
            System$Collections$Generic$ICollection$$$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Security.Principal.IdentityReference>.Contains(System.Security.Principal.IdentityReference)
            System$Collections$Generic$ICollection$$$Contains()
            {
                return this.Contains(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Security.Principal.IdentityReference>.CopyTo(System.Security.Principal.IdentityReference[], int)
            System$Collections$Generic$ICollection$$$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Security.Principal.IdentityReference>.Remove(System.Security.Principal.IdentityReference)
            System$Collections$Generic$ICollection$$$Remove()
            {
                return this.Remove(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Security.Principal.IdentityReference>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 312543;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":17180181727,"f":1},"n":"Count","d":312543,"h":12885214431,"f":1},{"p":247007,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":25770116319,"f":1},"s":{"r":0,"d":0,"h":30065083615,"f":1},"n":"Item","o":"@$2","d":312543,"h":21475149023,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":38655018207,"f":2},"n":"{$.$spc.System.Collections.Generic.ICollection$$($.$sspw.System.Security.Principal.IdentityReference).$h}.IsReadOnly","o":"System$Collections$Generic$ICollection$$$IsReadOnly","d":312543,"h":34360050911,"f":2}],"m":[{"r":65537,"p":[{"n":"identity","p":247007}],"n":"Add","d":312543,"h":42949985503,"f":1},{"r":65537,"n":"Clear","d":312543,"h":47244952799,"f":1},{"r":262145,"p":[{"n":"identity","p":247007}],"n":"Contains","d":312543,"h":51539920095,"f":1},{"r":65537,"p":[{"n":"array","p":0},{"n":"offset","p":655361}],"n":"CopyTo","d":312543,"h":55834887391,"f":1},{"r":$.$spc.System.Collections.Generic.IEnumerator$$($.$sspw.System.Security.Principal.IdentityReference).$h,"n":"GetEnumerator","d":312543,"h":60129854687,"f":1},{"r":262145,"p":[{"n":"identity","p":247007}],"n":"Remove","d":312543,"h":64424821983,"f":1},{"r":312543,"p":[{"n":"targetType","p":142606337}],"n":"Translate","d":312543,"h":73014756575,"f":1},{"r":312543,"p":[{"n":"targetType","p":142606337},{"n":"forceSuccess","p":262145}],"n":"Translate","o":"@$1","d":312543,"h":77309723871,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":312543,"h":4295279839,"f":1},{"p":[{"n":"capacity","p":655361}],"n":".ctor","o":"$ctor$2","d":312543,"h":8590247135,"f":1}],"i":[$.$spc.System.Collections.Generic.ICollection$$($.$sspw.System.Security.Principal.IdentityReference).$h,$.$spc.System.Collections.Generic.IEnumerable$$($.$sspw.System.Security.Principal.IdentityReference).$h,31588353],"h":312543}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.ICollection$$($.$sspw.System.Security.Principal.IdentityReference), $.$spc.System.Collections.Generic.IEnumerable$$($.$sspw.System.Security.Principal.IdentityReference), $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Security.Principal.IdentityReferenceCollection`; }
        });
        
        $asm.$cls("$sspw.System.Security.Principal.NTAccount", ($self) => class NTAccount extends $.$sspw.System.Security.Principal.IdentityReference
        {
            $ctor$2(/*string*/ name)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$3(/*string*/ domainName, /*string*/ accountName)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*string */ get Value()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ o)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sspw.System.Security.Principal.NTAccount.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sspw.System.Security.Principal.NTAccount.GetHashCode.apply(this, arguments); }
            /*bool */ IsValidTargetType(/*System.Type*/ targetType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ op_Equality$1(/*System.Security.Principal.NTAccount?*/ left, /*System.Security.Principal.NTAccount?*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ op_Inequality$1(/*System.Security.Principal.NTAccount?*/ left, /*System.Security.Principal.NTAccount?*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sspw.System.Security.Principal.NTAccount.ToString.apply(this, arguments); }
            /*System.Security.Principal.IdentityReference */ Translate(/*System.Type*/ targetType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 378079;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":247007,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17180247263,"f":32769},"n":"Value","d":378079,"h":12885279967,"f":32769}],"m":[{"r":262145,"p":[{"n":"o","p":131073}],"n":"Equals","d":378079,"h":21475214559,"f":32769},{"r":655361,"n":"GetHashCode","d":378079,"h":25770181855,"f":32769},{"r":262145,"p":[{"n":"targetType","p":142606337}],"n":"IsValidTargetType","d":378079,"h":30065149151,"f":32769},{"r":1310721,"n":"ToString","d":378079,"h":42950051039,"f":32769},{"r":247007,"p":[{"n":"targetType","p":142606337}],"n":"Translate","d":378079,"h":47245018335,"f":32769}],"c":[{"p":[{"n":"name","p":1310721}],"n":".ctor","o":"$ctor$2","d":378079,"h":4295345375,"f":1},{"p":[{"n":"domainName","p":1310721},{"n":"accountName","p":1310721}],"n":".ctor","o":"$ctor$3","d":378079,"h":8590312671,"f":1}],"h":378079}; }
            static get $b() { return $.$sspw.System.Security.Principal.IdentityReference; }
            static get $fullName() { return `System.Security.Principal.NTAccount`; }
        });
        
        $asm.$cls("$sspw.System.Security.Principal.SecurityIdentifier", ($self) => class SecurityIdentifier extends $.$sspw.System.Security.Principal.IdentityReference
        {
            /*int*/ static MaxBinaryLength = 0;
            /*int*/ static MinBinaryLength = 0;
            $ctor$2(/*byte[]*/ binaryForm, /*int*/ offset)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$3(/*System.IntPtr*/ binaryForm)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$4(/*System.Security.Principal.WellKnownSidType*/ sidType, /*System.Security.Principal.SecurityIdentifier?*/ domainSid)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$5(/*string*/ sddlForm)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Security.Principal.SecurityIdentifier? */ get AccountDomainSid()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get BinaryLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Value()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ CompareTo(/*System.Security.Principal.SecurityIdentifier?*/ sid)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ o)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sspw.System.Security.Principal.SecurityIdentifier.Equals.apply(this, arguments); }
            /*bool */ Equals$2(/*System.Security.Principal.SecurityIdentifier*/ sid)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sspw.System.Security.Principal.SecurityIdentifier.GetHashCode.apply(this, arguments); }
            /*bool */ IsAccountSid()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ IsEqualDomainSid(/*System.Security.Principal.SecurityIdentifier*/ sid)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ IsValidTargetType(/*System.Type*/ targetType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ IsWellKnown(/*System.Security.Principal.WellKnownSidType*/ type)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ op_Equality$1(/*System.Security.Principal.SecurityIdentifier?*/ left, /*System.Security.Principal.SecurityIdentifier?*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ op_Inequality$1(/*System.Security.Principal.SecurityIdentifier?*/ left, /*System.Security.Principal.SecurityIdentifier?*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sspw.System.Security.Principal.SecurityIdentifier.ToString.apply(this, arguments); }
            /*System.Security.Principal.IdentityReference */ Translate(/*System.Type*/ targetType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.IComparable<System.Security.Principal.SecurityIdentifier>.CompareTo(System.Security.Principal.SecurityIdentifier?)
            System$IComparable$$$CompareTo()
            {
                return this.CompareTo(...arguments);
            }
            static $h = 443615;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":247007,"p":[{"p":443615,"g":{"r":0,"d":0,"h":34360181983,"f":1},"n":"AccountDomainSid","d":443615,"h":30065214687,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":42950116575,"f":1},"n":"BinaryLength","d":443615,"h":38655149279,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":51540051167,"f":32769},"n":"Value","d":443615,"h":47245083871,"f":32769}],"m":[{"r":655361,"p":[{"n":"sid","p":443615}],"n":"CompareTo","d":443615,"h":55835018463,"f":1},{"r":262145,"p":[{"n":"o","p":131073}],"n":"Equals","d":443615,"h":60129985759,"f":32769},{"r":262145,"p":[{"n":"sid","p":443615}],"n":"Equals","o":"@$2","d":443615,"h":64424953055,"f":1},{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":443615,"h":68719920351,"f":1},{"r":655361,"n":"GetHashCode","d":443615,"h":73014887647,"f":32769},{"r":262145,"n":"IsAccountSid","d":443615,"h":77309854943,"f":1},{"r":262145,"p":[{"n":"sid","p":443615}],"n":"IsEqualDomainSid","d":443615,"h":81604822239,"f":1},{"r":262145,"p":[{"n":"targetType","p":142606337}],"n":"IsValidTargetType","d":443615,"h":85899789535,"f":32769},{"r":262145,"p":[{"n":"type","p":574687}],"n":"IsWellKnown","d":443615,"h":90194756831,"f":1},{"r":1310721,"n":"ToString","d":443615,"h":103079658719,"f":32769},{"r":247007,"p":[{"n":"targetType","p":142606337}],"n":"Translate","d":443615,"h":107374626015,"f":32769}],"l":[{"t":655361,"n":"MaxBinaryLength","d":443615,"h":4295410911,"f":33},{"t":655361,"n":"MinBinaryLength","d":443615,"h":8590378207,"f":33}],"c":[{"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":".ctor","o":"$ctor$2","d":443615,"h":12885345503,"f":1},{"p":[{"n":"binaryForm","p":786433}],"n":".ctor","o":"$ctor$3","d":443615,"h":17180312799,"f":1},{"p":[{"n":"sidType","p":574687},{"n":"domainSid","p":443615}],"n":".ctor","o":"$ctor$4","d":443615,"h":21475280095,"f":1},{"p":[{"n":"sddlForm","p":1310721}],"n":".ctor","o":"$ctor$5","d":443615,"h":25770247391,"f":1}],"i":[$.$spc.System.IComparable$$($.$sspw.System.Security.Principal.SecurityIdentifier).$h],"h":443615}; }
            static get $b() { return $.$sspw.System.Security.Principal.IdentityReference; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable$$($.$sspw.System.Security.Principal.SecurityIdentifier) ]; }
            static get $fullName() { return `System.Security.Principal.SecurityIdentifier`; }
        });
        
        $asm.$cls("$sspw.Microsoft.Win32.SafeHandles.SafeAccessTokenHandle", ($self) => class SafeAccessTokenHandle extends $.$spc.System.Runtime.InteropServices.SafeHandle
        {
            $ctor$3()
            {
                super.$ctor$2(0, false);
                {
                }
                return this;
            }
            $ctor$4(/*System.IntPtr*/ handle)
            {
                super.$ctor$2(0, false);
                {
                }
                return this;
            }
            static /*Microsoft.Win32.SafeHandles.SafeAccessTokenHandle */ get InvalidHandle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsInvalid()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ReleaseHandle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 115935;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":109576193,"p":[{"p":115935,"g":{"r":0,"d":0,"h":17179985119,"f":33},"n":"InvalidHandle","d":115935,"h":12885017823,"f":33},{"p":262145,"g":{"r":0,"d":0,"h":25769919711,"f":32769},"n":"IsInvalid","d":115935,"h":21474952415,"f":32769}],"m":[{"r":262145,"n":"ReleaseHandle","d":115935,"h":30064887007,"f":32772}],"c":[{"n":".ctor","o":"$ctor$3","d":115935,"h":4295083231,"f":1},{"p":[{"n":"handle","p":786433}],"n":".ctor","o":"$ctor$4","d":115935,"h":8590050527,"f":1}],"i":[57475073],"h":115935}; }
            static get $b() { return $.$spc.System.Runtime.InteropServices.SafeHandle; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Win32.SafeHandles.SafeAccessTokenHandle`; }
        });
        
        $asm.$str("$sspw.System.Security.Principal.TokenAccessLevels", ($self) => class TokenAccessLevels extends $.$spc.System.Enum
        {
            static AssignPrimary = 1;
            static Duplicate = 2;
            static Impersonate = 4;
            static Query = 8;
            static QuerySource = 16;
            static AdjustPrivileges = 32;
            static AdjustGroups = 64;
            static AdjustDefault = 128;
            static AdjustSessionId = 256;
            static Read = 131080;
            static Write = 131296;
            static AllAccess = 983551;
            static MaximumAllowed = 33554432;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "AssignPrimary": 1n,
                    "Duplicate": 2n,
                    "Impersonate": 4n,
                    "Query": 8n,
                    "QuerySource": 16n,
                    "AdjustPrivileges": 32n,
                    "AdjustGroups": 64n,
                    "AdjustDefault": 128n,
                    "AdjustSessionId": 256n,
                    "Read": 131080n,
                    "Write": 131296n,
                    "AllAccess": 983551n,
                    "MaximumAllowed": 33554432n
                };
            }
            static $h = 509151;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":509151,"n":"AssignPrimary","d":509151,"h":4295476447,"f":33},{"t":509151,"n":"Duplicate","d":509151,"h":8590443743,"f":33},{"t":509151,"n":"Impersonate","d":509151,"h":12885411039,"f":33},{"t":509151,"n":"Query","d":509151,"h":17180378335,"f":33},{"t":509151,"n":"QuerySource","d":509151,"h":21475345631,"f":33},{"t":509151,"n":"AdjustPrivileges","d":509151,"h":25770312927,"f":33},{"t":509151,"n":"AdjustGroups","d":509151,"h":30065280223,"f":33},{"t":509151,"n":"AdjustDefault","d":509151,"h":34360247519,"f":33},{"t":509151,"n":"AdjustSessionId","d":509151,"h":38655214815,"f":33},{"t":509151,"n":"Read","d":509151,"h":42950182111,"f":33},{"t":509151,"n":"Write","d":509151,"h":47245149407,"f":33},{"t":509151,"n":"AllAccess","d":509151,"h":51540116703,"f":33},{"t":509151,"n":"MaximumAllowed","d":509151,"h":55835083999,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":509151,"h":60130051295,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":509151,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.Principal.TokenAccessLevels`; }
        });
        
        $asm.$str("$sspw.System.Security.Principal.WellKnownSidType", ($self) => class WellKnownSidType extends $.$spc.System.Enum
        {
            static NullSid = 0;
            static WorldSid = 1;
            static LocalSid = 2;
            static CreatorOwnerSid = 3;
            static CreatorGroupSid = 4;
            static CreatorOwnerServerSid = 5;
            static CreatorGroupServerSid = 6;
            static NTAuthoritySid = 7;
            static DialupSid = 8;
            static NetworkSid = 9;
            static BatchSid = 10;
            static InteractiveSid = 11;
            static ServiceSid = 12;
            static AnonymousSid = 13;
            static ProxySid = 14;
            static EnterpriseControllersSid = 15;
            static SelfSid = 16;
            static AuthenticatedUserSid = 17;
            static RestrictedCodeSid = 18;
            static TerminalServerSid = 19;
            static RemoteLogonIdSid = 20;
            static LogonIdsSid = 21;
            static LocalSystemSid = 22;
            static LocalServiceSid = 23;
            static NetworkServiceSid = 24;
            static BuiltinDomainSid = 25;
            static BuiltinAdministratorsSid = 26;
            static BuiltinUsersSid = 27;
            static BuiltinGuestsSid = 28;
            static BuiltinPowerUsersSid = 29;
            static BuiltinAccountOperatorsSid = 30;
            static BuiltinSystemOperatorsSid = 31;
            static BuiltinPrintOperatorsSid = 32;
            static BuiltinBackupOperatorsSid = 33;
            static BuiltinReplicatorSid = 34;
            static BuiltinPreWindows2000CompatibleAccessSid = 35;
            static BuiltinRemoteDesktopUsersSid = 36;
            static BuiltinNetworkConfigurationOperatorsSid = 37;
            static AccountAdministratorSid = 38;
            static AccountGuestSid = 39;
            static AccountKrbtgtSid = 40;
            static AccountDomainAdminsSid = 41;
            static AccountDomainUsersSid = 42;
            static AccountDomainGuestsSid = 43;
            static AccountComputersSid = 44;
            static AccountControllersSid = 45;
            static AccountCertAdminsSid = 46;
            static AccountSchemaAdminsSid = 47;
            static AccountEnterpriseAdminsSid = 48;
            static AccountPolicyAdminsSid = 49;
            static AccountRasAndIasServersSid = 50;
            static NtlmAuthenticationSid = 51;
            static DigestAuthenticationSid = 52;
            static SChannelAuthenticationSid = 53;
            static ThisOrganizationSid = 54;
            static OtherOrganizationSid = 55;
            static BuiltinIncomingForestTrustBuildersSid = 56;
            static BuiltinPerformanceMonitoringUsersSid = 57;
            static BuiltinPerformanceLoggingUsersSid = 58;
            static BuiltinAuthorizationAccessSid = 59;
            static MaxDefined = 60;
            static WinBuiltinTerminalServerLicenseServersSid = 60;
            static WinBuiltinDCOMUsersSid = 61;
            static WinBuiltinIUsersSid = 62;
            static WinIUserSid = 63;
            static WinBuiltinCryptoOperatorsSid = 64;
            static WinUntrustedLabelSid = 65;
            static WinLowLabelSid = 66;
            static WinMediumLabelSid = 67;
            static WinHighLabelSid = 68;
            static WinSystemLabelSid = 69;
            static WinWriteRestrictedCodeSid = 70;
            static WinCreatorOwnerRightsSid = 71;
            static WinCacheablePrincipalsGroupSid = 72;
            static WinNonCacheablePrincipalsGroupSid = 73;
            static WinEnterpriseReadonlyControllersSid = 74;
            static WinAccountReadonlyControllersSid = 75;
            static WinBuiltinEventLogReadersGroup = 76;
            static WinNewEnterpriseReadonlyControllersSid = 77;
            static WinBuiltinCertSvcDComAccessGroup = 78;
            static WinMediumPlusLabelSid = 79;
            static WinLocalLogonSid = 80;
            static WinConsoleLogonSid = 81;
            static WinThisOrganizationCertificateSid = 82;
            static WinApplicationPackageAuthoritySid = 83;
            static WinBuiltinAnyPackageSid = 84;
            static WinCapabilityInternetClientSid = 85;
            static WinCapabilityInternetClientServerSid = 86;
            static WinCapabilityPrivateNetworkClientServerSid = 87;
            static WinCapabilityPicturesLibrarySid = 88;
            static WinCapabilityVideosLibrarySid = 89;
            static WinCapabilityMusicLibrarySid = 90;
            static WinCapabilityDocumentsLibrarySid = 91;
            static WinCapabilitySharedUserCertificatesSid = 92;
            static WinCapabilityEnterpriseAuthenticationSid = 93;
            static WinCapabilityRemovableStorageSid = 94;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "NullSid": 0n,
                    "WorldSid": 1n,
                    "LocalSid": 2n,
                    "CreatorOwnerSid": 3n,
                    "CreatorGroupSid": 4n,
                    "CreatorOwnerServerSid": 5n,
                    "CreatorGroupServerSid": 6n,
                    "NTAuthoritySid": 7n,
                    "DialupSid": 8n,
                    "NetworkSid": 9n,
                    "BatchSid": 10n,
                    "InteractiveSid": 11n,
                    "ServiceSid": 12n,
                    "AnonymousSid": 13n,
                    "ProxySid": 14n,
                    "EnterpriseControllersSid": 15n,
                    "SelfSid": 16n,
                    "AuthenticatedUserSid": 17n,
                    "RestrictedCodeSid": 18n,
                    "TerminalServerSid": 19n,
                    "RemoteLogonIdSid": 20n,
                    "LogonIdsSid": 21n,
                    "LocalSystemSid": 22n,
                    "LocalServiceSid": 23n,
                    "NetworkServiceSid": 24n,
                    "BuiltinDomainSid": 25n,
                    "BuiltinAdministratorsSid": 26n,
                    "BuiltinUsersSid": 27n,
                    "BuiltinGuestsSid": 28n,
                    "BuiltinPowerUsersSid": 29n,
                    "BuiltinAccountOperatorsSid": 30n,
                    "BuiltinSystemOperatorsSid": 31n,
                    "BuiltinPrintOperatorsSid": 32n,
                    "BuiltinBackupOperatorsSid": 33n,
                    "BuiltinReplicatorSid": 34n,
                    "BuiltinPreWindows2000CompatibleAccessSid": 35n,
                    "BuiltinRemoteDesktopUsersSid": 36n,
                    "BuiltinNetworkConfigurationOperatorsSid": 37n,
                    "AccountAdministratorSid": 38n,
                    "AccountGuestSid": 39n,
                    "AccountKrbtgtSid": 40n,
                    "AccountDomainAdminsSid": 41n,
                    "AccountDomainUsersSid": 42n,
                    "AccountDomainGuestsSid": 43n,
                    "AccountComputersSid": 44n,
                    "AccountControllersSid": 45n,
                    "AccountCertAdminsSid": 46n,
                    "AccountSchemaAdminsSid": 47n,
                    "AccountEnterpriseAdminsSid": 48n,
                    "AccountPolicyAdminsSid": 49n,
                    "AccountRasAndIasServersSid": 50n,
                    "NtlmAuthenticationSid": 51n,
                    "DigestAuthenticationSid": 52n,
                    "SChannelAuthenticationSid": 53n,
                    "ThisOrganizationSid": 54n,
                    "OtherOrganizationSid": 55n,
                    "BuiltinIncomingForestTrustBuildersSid": 56n,
                    "BuiltinPerformanceMonitoringUsersSid": 57n,
                    "BuiltinPerformanceLoggingUsersSid": 58n,
                    "BuiltinAuthorizationAccessSid": 59n,
                    "MaxDefined": 60n,
                    "WinBuiltinTerminalServerLicenseServersSid": 60n,
                    "WinBuiltinDCOMUsersSid": 61n,
                    "WinBuiltinIUsersSid": 62n,
                    "WinIUserSid": 63n,
                    "WinBuiltinCryptoOperatorsSid": 64n,
                    "WinUntrustedLabelSid": 65n,
                    "WinLowLabelSid": 66n,
                    "WinMediumLabelSid": 67n,
                    "WinHighLabelSid": 68n,
                    "WinSystemLabelSid": 69n,
                    "WinWriteRestrictedCodeSid": 70n,
                    "WinCreatorOwnerRightsSid": 71n,
                    "WinCacheablePrincipalsGroupSid": 72n,
                    "WinNonCacheablePrincipalsGroupSid": 73n,
                    "WinEnterpriseReadonlyControllersSid": 74n,
                    "WinAccountReadonlyControllersSid": 75n,
                    "WinBuiltinEventLogReadersGroup": 76n,
                    "WinNewEnterpriseReadonlyControllersSid": 77n,
                    "WinBuiltinCertSvcDComAccessGroup": 78n,
                    "WinMediumPlusLabelSid": 79n,
                    "WinLocalLogonSid": 80n,
                    "WinConsoleLogonSid": 81n,
                    "WinThisOrganizationCertificateSid": 82n,
                    "WinApplicationPackageAuthoritySid": 83n,
                    "WinBuiltinAnyPackageSid": 84n,
                    "WinCapabilityInternetClientSid": 85n,
                    "WinCapabilityInternetClientServerSid": 86n,
                    "WinCapabilityPrivateNetworkClientServerSid": 87n,
                    "WinCapabilityPicturesLibrarySid": 88n,
                    "WinCapabilityVideosLibrarySid": 89n,
                    "WinCapabilityMusicLibrarySid": 90n,
                    "WinCapabilityDocumentsLibrarySid": 91n,
                    "WinCapabilitySharedUserCertificatesSid": 92n,
                    "WinCapabilityEnterpriseAuthenticationSid": 93n,
                    "WinCapabilityRemovableStorageSid": 94n
                };
            }
            static $h = 574687;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":574687,"n":"NullSid","d":574687,"h":4295541983,"f":33},{"t":574687,"n":"WorldSid","d":574687,"h":8590509279,"f":33},{"t":574687,"n":"LocalSid","d":574687,"h":12885476575,"f":33},{"t":574687,"n":"CreatorOwnerSid","d":574687,"h":17180443871,"f":33},{"t":574687,"n":"CreatorGroupSid","d":574687,"h":21475411167,"f":33},{"t":574687,"n":"CreatorOwnerServerSid","d":574687,"h":25770378463,"f":33},{"t":574687,"n":"CreatorGroupServerSid","d":574687,"h":30065345759,"f":33},{"t":574687,"n":"NTAuthoritySid","d":574687,"h":34360313055,"f":33},{"t":574687,"n":"DialupSid","d":574687,"h":38655280351,"f":33},{"t":574687,"n":"NetworkSid","d":574687,"h":42950247647,"f":33},{"t":574687,"n":"BatchSid","d":574687,"h":47245214943,"f":33},{"t":574687,"n":"InteractiveSid","d":574687,"h":51540182239,"f":33},{"t":574687,"n":"ServiceSid","d":574687,"h":55835149535,"f":33},{"t":574687,"n":"AnonymousSid","d":574687,"h":60130116831,"f":33},{"t":574687,"n":"ProxySid","d":574687,"h":64425084127,"f":33},{"t":574687,"n":"EnterpriseControllersSid","d":574687,"h":68720051423,"f":33},{"t":574687,"n":"SelfSid","d":574687,"h":73015018719,"f":33},{"t":574687,"n":"AuthenticatedUserSid","d":574687,"h":77309986015,"f":33},{"t":574687,"n":"RestrictedCodeSid","d":574687,"h":81604953311,"f":33},{"t":574687,"n":"TerminalServerSid","d":574687,"h":85899920607,"f":33},{"t":574687,"n":"RemoteLogonIdSid","d":574687,"h":90194887903,"f":33},{"t":574687,"n":"LogonIdsSid","d":574687,"h":94489855199,"f":33},{"t":574687,"n":"LocalSystemSid","d":574687,"h":98784822495,"f":33},{"t":574687,"n":"LocalServiceSid","d":574687,"h":103079789791,"f":33},{"t":574687,"n":"NetworkServiceSid","d":574687,"h":107374757087,"f":33},{"t":574687,"n":"BuiltinDomainSid","d":574687,"h":111669724383,"f":33},{"t":574687,"n":"BuiltinAdministratorsSid","d":574687,"h":115964691679,"f":33},{"t":574687,"n":"BuiltinUsersSid","d":574687,"h":120259658975,"f":33},{"t":574687,"n":"BuiltinGuestsSid","d":574687,"h":124554626271,"f":33},{"t":574687,"n":"BuiltinPowerUsersSid","d":574687,"h":128849593567,"f":33},{"t":574687,"n":"BuiltinAccountOperatorsSid","d":574687,"h":133144560863,"f":33},{"t":574687,"n":"BuiltinSystemOperatorsSid","d":574687,"h":137439528159,"f":33},{"t":574687,"n":"BuiltinPrintOperatorsSid","d":574687,"h":141734495455,"f":33},{"t":574687,"n":"BuiltinBackupOperatorsSid","d":574687,"h":146029462751,"f":33},{"t":574687,"n":"BuiltinReplicatorSid","d":574687,"h":150324430047,"f":33},{"t":574687,"n":"BuiltinPreWindows2000CompatibleAccessSid","d":574687,"h":154619397343,"f":33},{"t":574687,"n":"BuiltinRemoteDesktopUsersSid","d":574687,"h":158914364639,"f":33},{"t":574687,"n":"BuiltinNetworkConfigurationOperatorsSid","d":574687,"h":163209331935,"f":33},{"t":574687,"n":"AccountAdministratorSid","d":574687,"h":167504299231,"f":33},{"t":574687,"n":"AccountGuestSid","d":574687,"h":171799266527,"f":33},{"t":574687,"n":"AccountKrbtgtSid","d":574687,"h":176094233823,"f":33},{"t":574687,"n":"AccountDomainAdminsSid","d":574687,"h":180389201119,"f":33},{"t":574687,"n":"AccountDomainUsersSid","d":574687,"h":184684168415,"f":33},{"t":574687,"n":"AccountDomainGuestsSid","d":574687,"h":188979135711,"f":33},{"t":574687,"n":"AccountComputersSid","d":574687,"h":193274103007,"f":33},{"t":574687,"n":"AccountControllersSid","d":574687,"h":197569070303,"f":33},{"t":574687,"n":"AccountCertAdminsSid","d":574687,"h":201864037599,"f":33},{"t":574687,"n":"AccountSchemaAdminsSid","d":574687,"h":206159004895,"f":33},{"t":574687,"n":"AccountEnterpriseAdminsSid","d":574687,"h":210453972191,"f":33},{"t":574687,"n":"AccountPolicyAdminsSid","d":574687,"h":214748939487,"f":33},{"t":574687,"n":"AccountRasAndIasServersSid","d":574687,"h":219043906783,"f":33},{"t":574687,"n":"NtlmAuthenticationSid","d":574687,"h":223338874079,"f":33},{"t":574687,"n":"DigestAuthenticationSid","d":574687,"h":227633841375,"f":33},{"t":574687,"n":"SChannelAuthenticationSid","d":574687,"h":231928808671,"f":33},{"t":574687,"n":"ThisOrganizationSid","d":574687,"h":236223775967,"f":33},{"t":574687,"n":"OtherOrganizationSid","d":574687,"h":240518743263,"f":33},{"t":574687,"n":"BuiltinIncomingForestTrustBuildersSid","d":574687,"h":244813710559,"f":33},{"t":574687,"n":"BuiltinPerformanceMonitoringUsersSid","d":574687,"h":249108677855,"f":33},{"t":574687,"n":"BuiltinPerformanceLoggingUsersSid","d":574687,"h":253403645151,"f":33},{"t":574687,"n":"BuiltinAuthorizationAccessSid","d":574687,"h":257698612447,"f":33},{"t":574687,"n":"MaxDefined","d":574687,"h":261993579743,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]},{"t":70909953,"c":8660844545,"a":[{"v":"This member has been deprecated and is only maintained for backwards compatability. WellKnownSidType values greater than MaxDefined may be defined in future releases.","t":1310721}]}]},{"t":574687,"n":"WinBuiltinTerminalServerLicenseServersSid","d":574687,"h":266288547039,"f":33},{"t":574687,"n":"WinBuiltinDCOMUsersSid","d":574687,"h":270583514335,"f":33},{"t":574687,"n":"WinBuiltinIUsersSid","d":574687,"h":274878481631,"f":33},{"t":574687,"n":"WinIUserSid","d":574687,"h":279173448927,"f":33},{"t":574687,"n":"WinBuiltinCryptoOperatorsSid","d":574687,"h":283468416223,"f":33},{"t":574687,"n":"WinUntrustedLabelSid","d":574687,"h":287763383519,"f":33},{"t":574687,"n":"WinLowLabelSid","d":574687,"h":292058350815,"f":33},{"t":574687,"n":"WinMediumLabelSid","d":574687,"h":296353318111,"f":33},{"t":574687,"n":"WinHighLabelSid","d":574687,"h":300648285407,"f":33},{"t":574687,"n":"WinSystemLabelSid","d":574687,"h":304943252703,"f":33},{"t":574687,"n":"WinWriteRestrictedCodeSid","d":574687,"h":309238219999,"f":33},{"t":574687,"n":"WinCreatorOwnerRightsSid","d":574687,"h":313533187295,"f":33},{"t":574687,"n":"WinCacheablePrincipalsGroupSid","d":574687,"h":317828154591,"f":33},{"t":574687,"n":"WinNonCacheablePrincipalsGroupSid","d":574687,"h":322123121887,"f":33},{"t":574687,"n":"WinEnterpriseReadonlyControllersSid","d":574687,"h":326418089183,"f":33},{"t":574687,"n":"WinAccountReadonlyControllersSid","d":574687,"h":330713056479,"f":33},{"t":574687,"n":"WinBuiltinEventLogReadersGroup","d":574687,"h":335008023775,"f":33},{"t":574687,"n":"WinNewEnterpriseReadonlyControllersSid","d":574687,"h":339302991071,"f":33},{"t":574687,"n":"WinBuiltinCertSvcDComAccessGroup","d":574687,"h":343597958367,"f":33},{"t":574687,"n":"WinMediumPlusLabelSid","d":574687,"h":347892925663,"f":33},{"t":574687,"n":"WinLocalLogonSid","d":574687,"h":352187892959,"f":33},{"t":574687,"n":"WinConsoleLogonSid","d":574687,"h":356482860255,"f":33},{"t":574687,"n":"WinThisOrganizationCertificateSid","d":574687,"h":360777827551,"f":33},{"t":574687,"n":"WinApplicationPackageAuthoritySid","d":574687,"h":365072794847,"f":33},{"t":574687,"n":"WinBuiltinAnyPackageSid","d":574687,"h":369367762143,"f":33},{"t":574687,"n":"WinCapabilityInternetClientSid","d":574687,"h":373662729439,"f":33},{"t":574687,"n":"WinCapabilityInternetClientServerSid","d":574687,"h":377957696735,"f":33},{"t":574687,"n":"WinCapabilityPrivateNetworkClientServerSid","d":574687,"h":382252664031,"f":33},{"t":574687,"n":"WinCapabilityPicturesLibrarySid","d":574687,"h":386547631327,"f":33},{"t":574687,"n":"WinCapabilityVideosLibrarySid","d":574687,"h":390842598623,"f":33},{"t":574687,"n":"WinCapabilityMusicLibrarySid","d":574687,"h":395137565919,"f":33},{"t":574687,"n":"WinCapabilityDocumentsLibrarySid","d":574687,"h":399432533215,"f":33},{"t":574687,"n":"WinCapabilitySharedUserCertificatesSid","d":574687,"h":403727500511,"f":33},{"t":574687,"n":"WinCapabilityEnterpriseAuthenticationSid","d":574687,"h":408022467807,"f":33},{"t":574687,"n":"WinCapabilityRemovableStorageSid","d":574687,"h":412317435103,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":574687,"h":416612402399,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":574687}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.Principal.WellKnownSidType`; }
        });
        
        $asm.$str("$sspw.System.Security.Principal.WindowsAccountType", ($self) => class WindowsAccountType extends $.$spc.System.Enum
        {
            static Normal = 0;
            static Guest = 1;
            static System = 2;
            static Anonymous = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Normal": 0n,
                    "Guest": 1n,
                    "System": 2n,
                    "Anonymous": 3n
                };
            }
            static $h = 640223;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":640223,"n":"Normal","d":640223,"h":4295607519,"f":33},{"t":640223,"n":"Guest","d":640223,"h":8590574815,"f":33},{"t":640223,"n":"System","d":640223,"h":12885542111,"f":33},{"t":640223,"n":"Anonymous","d":640223,"h":17180509407,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":640223,"h":21475476703,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":640223}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.Principal.WindowsAccountType`; }
        });
        
        $asm.$str("$sspw.System.Security.Principal.WindowsBuiltInRole", ($self) => class WindowsBuiltInRole extends $.$spc.System.Enum
        {
            static Administrator = 544;
            static User = 545;
            static Guest = 546;
            static PowerUser = 547;
            static AccountOperator = 548;
            static SystemOperator = 549;
            static PrintOperator = 550;
            static BackupOperator = 551;
            static Replicator = 552;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Administrator": 544n,
                    "User": 545n,
                    "Guest": 546n,
                    "PowerUser": 547n,
                    "AccountOperator": 548n,
                    "SystemOperator": 549n,
                    "PrintOperator": 550n,
                    "BackupOperator": 551n,
                    "Replicator": 552n
                };
            }
            static $h = 705759;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":705759,"n":"Administrator","d":705759,"h":4295673055,"f":33},{"t":705759,"n":"User","d":705759,"h":8590640351,"f":33},{"t":705759,"n":"Guest","d":705759,"h":12885607647,"f":33},{"t":705759,"n":"PowerUser","d":705759,"h":17180574943,"f":33},{"t":705759,"n":"AccountOperator","d":705759,"h":21475542239,"f":33},{"t":705759,"n":"SystemOperator","d":705759,"h":25770509535,"f":33},{"t":705759,"n":"PrintOperator","d":705759,"h":30065476831,"f":33},{"t":705759,"n":"BackupOperator","d":705759,"h":34360444127,"f":33},{"t":705759,"n":"Replicator","d":705759,"h":38655411423,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":705759,"h":42950378719,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":705759}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.Principal.WindowsBuiltInRole`; }
        });
        
        $asm.$cls("$sspw.System.Security.Principal.WindowsPrincipal", ($self) => class WindowsPrincipal extends $.$ssc.System.Security.Claims.ClaimsPrincipal
        {
            $ctor$7(/*System.Security.Principal.WindowsIdentity*/ ntIdentity)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*System.Collections.Generic.IEnumerable<System.Security.Claims.Claim> */ get DeviceClaims()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IIdentity */ get Identity()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.IEnumerable<System.Security.Claims.Claim> */ get UserClaims()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ IsInRole$1(/*int*/ rid)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ IsInRole$2(/*System.Security.Principal.SecurityIdentifier*/ sid)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ IsInRole$3(/*System.Security.Principal.WindowsBuiltInRole*/ role)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ IsInRole(/*string*/ role)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 836831;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":450666,"p":[{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"g":{"r":0,"d":0,"h":12885738719,"f":129},"n":"DeviceClaims","d":836831,"h":8590771423,"f":129},{"p":117047297,"g":{"r":0,"d":0,"h":21475673311,"f":32769},"n":"Identity","d":836831,"h":17180706015,"f":32769},{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"g":{"r":0,"d":0,"h":30065607903,"f":129},"n":"UserClaims","d":836831,"h":25770640607,"f":129}],"m":[{"r":262145,"p":[{"n":"rid","p":655361}],"n":"IsInRole","o":"@$1","d":836831,"h":34360575199,"f":129},{"r":262145,"p":[{"n":"sid","p":443615}],"n":"IsInRole","o":"@$2","d":836831,"h":38655542495,"f":129},{"r":262145,"p":[{"n":"role","p":705759}],"n":"IsInRole","o":"@$3","d":836831,"h":42950509791,"f":129},{"r":262145,"p":[{"n":"role","p":1310721}],"n":"IsInRole","d":836831,"h":47245477087,"f":32769}],"c":[{"p":[{"n":"ntIdentity","p":771295}],"n":".ctor","o":"$ctor$7","d":836831,"h":4295804127,"f":1}],"i":[117112833],"h":836831}; }
            static get $b() { return $.$ssc.System.Security.Claims.ClaimsPrincipal; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Security.Principal.IPrincipal ]; }
            static get $fullName() { return `System.Security.Principal.WindowsPrincipal`; }
        });
        
        $asm.$cls("$sspw.System.Security.Principal.WindowsIdentity", ($self) => class WindowsIdentity extends $.$ssc.System.Security.Claims.ClaimsIdentity
        {
            /*string*/ static DefaultIssuer = null;
            $ctor$17(/*System.IntPtr*/ userToken)
            {
                super.$ctor$14(null, null, null, null, null, 5);
                {
                }
                return this;
            }
            $ctor$18(/*System.IntPtr*/ userToken, /*string*/ type)
            {
                super.$ctor$14(null, null, null, null, null, 5);
                {
                }
                return this;
            }
            $ctor$19(/*System.IntPtr*/ userToken, /*string*/ type, /*System.Security.Principal.WindowsAccountType*/ acctType)
            {
                super.$ctor$14(null, null, null, null, null, 5);
                {
                }
                return this;
            }
            $ctor$20(/*System.IntPtr*/ userToken, /*string*/ type, /*System.Security.Principal.WindowsAccountType*/ acctType, /*bool*/ isAuthenticated)
            {
                super.$ctor$14(null, null, null, null, null, 5);
                {
                }
                return this;
            }
            $ctor$21(/*System.Runtime.Serialization.SerializationInfo*/ info, /*System.Runtime.Serialization.StreamingContext*/ context)
            {
                super.$ctor$14(null, null, null, null, null, 5);
                {
                }
                return this;
            }
            $ctor$22(/*System.Security.Principal.WindowsIdentity*/ identity)
            {
                super.$ctor$14(null, null, null, null, null, 5);
                {
                }
                return this;
            }
            $ctor$23(/*string*/ sUserPrincipalName)
            {
                super.$ctor$14(null, null, null, null, null, 5);
                {
                }
                return this;
            }
            /*Microsoft.Win32.SafeHandles.SafeAccessTokenHandle */ get AccessToken()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get AuthenticationType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.IEnumerable<System.Security.Claims.Claim> */ get Claims()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.IEnumerable<System.Security.Claims.Claim> */ get DeviceClaims()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IdentityReferenceCollection? */ get Groups()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.TokenImpersonationLevel */ get ImpersonationLevel()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsAnonymous()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsAuthenticated()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsGuest()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsSystem()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Name()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ get Owner()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ get Token()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ get User()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.IEnumerable<System.Security.Claims.Claim> */ get UserClaims()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Claims.ClaimsIdentity */ Clone()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose()
            {
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            static /*System.Security.Principal.WindowsIdentity */ GetAnonymous()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Security.Principal.WindowsIdentity */ GetCurrent()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Security.Principal.WindowsIdentity? */ GetCurrent$1(/*bool*/ ifImpersonating)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Security.Principal.WindowsIdentity */ GetCurrent$2(/*System.Security.Principal.TokenAccessLevels*/ desiredAccess)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*void */ RunImpersonated(/*Microsoft.Win32.SafeHandles.SafeAccessTokenHandle*/ safeAccessTokenHandle, /*System.Action*/ action)
            {
            }
            static /*System.Threading.Tasks.Task */ RunImpersonatedAsync(/*Microsoft.Win32.SafeHandles.SafeAccessTokenHandle*/ safeAccessTokenHandle, /*System.Func<System.Threading.Tasks.Task>*/ func)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<T> */ RunImpersonatedAsync$1(T, /*Microsoft.Win32.SafeHandles.SafeAccessTokenHandle*/ safeAccessTokenHandle, /*System.Func<System.Threading.Tasks.Task<T>>*/ func)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*T */ RunImpersonated$1(T, /*Microsoft.Win32.SafeHandles.SafeAccessTokenHandle*/ safeAccessTokenHandle, /*System.Func<T>*/ func)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ System$Runtime$Serialization$IDeserializationCallback$OnDeserialization(/*object?*/ sender)
            {
            }
            /*void */ System$Runtime$Serialization$ISerializable$GetObjectData(/*System.Runtime.Serialization.SerializationInfo*/ info, /*System.Runtime.Serialization.StreamingContext*/ context)
            {
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.DefaultIssuer = "AD AUTHORITY";
                }
            }
            static $h = 771295;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":319594,"p":[{"p":115935,"g":{"r":0,"d":0,"h":42950444255,"f":1},"n":"AccessToken","d":771295,"h":38655476959,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":51540378847,"f":98305},"n":"AuthenticationType","d":771295,"h":47245411551,"f":98305},{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"g":{"r":0,"d":0,"h":60130313439,"f":32769},"n":"Claims","d":771295,"h":55835346143,"f":32769},{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"g":{"r":0,"d":0,"h":68720248031,"f":129},"n":"DeviceClaims","d":771295,"h":64425280735,"f":129},{"p":312543,"g":{"r":0,"d":0,"h":77310182623,"f":1},"n":"Groups","d":771295,"h":73015215327,"f":1},{"p":117243905,"g":{"r":0,"d":0,"h":85900117215,"f":1},"n":"ImpersonationLevel","d":771295,"h":81605149919,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":94490051807,"f":129},"n":"IsAnonymous","d":771295,"h":90195084511,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":103079986399,"f":32769},"n":"IsAuthenticated","d":771295,"h":98785019103,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":111669920991,"f":129},"n":"IsGuest","d":771295,"h":107374953695,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":120259855583,"f":129},"n":"IsSystem","d":771295,"h":115964888287,"f":129},{"p":1310721,"g":{"r":0,"d":0,"h":128849790175,"f":32769},"n":"Name","d":771295,"h":124554822879,"f":32769},{"p":443615,"g":{"r":0,"d":0,"h":137439724767,"f":1},"n":"Owner","d":771295,"h":133144757471,"f":1},{"p":786433,"g":{"r":0,"d":0,"h":146029659359,"f":129},"n":"Token","d":771295,"h":141734692063,"f":129},{"p":443615,"g":{"r":0,"d":0,"h":154619593951,"f":1},"n":"User","d":771295,"h":150324626655,"f":1},{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"g":{"r":0,"d":0,"h":163209528543,"f":129},"n":"UserClaims","d":771295,"h":158914561247,"f":129}],"m":[{"r":319594,"n":"Clone","d":771295,"h":167504495839,"f":32769},{"r":65537,"n":"Dispose","d":771295,"h":171799463135,"f":1},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":771295,"h":176094430431,"f":132},{"r":771295,"n":"GetAnonymous","d":771295,"h":180389397727,"f":33},{"r":771295,"n":"GetCurrent","d":771295,"h":184684365023,"f":33},{"r":771295,"p":[{"n":"ifImpersonating","p":262145}],"n":"GetCurrent","o":"@$1","d":771295,"h":188979332319,"f":33},{"r":771295,"p":[{"n":"desiredAccess","p":509151}],"n":"GetCurrent","o":"@$2","d":771295,"h":193274299615,"f":33},{"r":65537,"p":[{"n":"safeAccessTokenHandle","p":115935},{"n":"action","p":11665409}],"n":"RunImpersonated","d":771295,"h":197569266911,"f":33},{"r":133300225,"p":[{"n":"safeAccessTokenHandle","p":115935},{"n":"func","p":$.$spc.System.Func$$($.$spc.System.Threading.Tasks.Task).$h}],"n":"RunImpersonatedAsync","d":771295,"h":201864234207,"f":33},{"r":(T) => $.$spc.System.Threading.Tasks.Task$$(T).$h,"p":[{"n":"safeAccessTokenHandle","p":115935},{"n":"func","p":(T) => $.$spc.System.Func$$($.$spc.System.Threading.Tasks.Task$$(T)).$h}],"g":["T"],"n":"RunImpersonatedAsync","o":"@$1","d":771295,"h":206159201503,"f":131105},{"r":206162034688,"p":[{"n":"safeAccessTokenHandle","p":115935},{"n":"func","p":(T) => $.$spc.System.Func$$(T).$h}],"g":["T"],"n":"RunImpersonated","o":"@$1","d":771295,"h":210454168799,"f":131105}],"l":[{"t":1310721,"n":"DefaultIssuer","d":771295,"h":4295738591,"f":33}],"c":[{"p":[{"n":"userToken","p":786433}],"n":".ctor","o":"$ctor$17","d":771295,"h":8590705887,"f":1},{"p":[{"n":"userToken","p":786433},{"n":"type","p":1310721}],"n":".ctor","o":"$ctor$18","d":771295,"h":12885673183,"f":1},{"p":[{"n":"userToken","p":786433},{"n":"type","p":1310721},{"n":"acctType","p":640223}],"n":".ctor","o":"$ctor$19","d":771295,"h":17180640479,"f":1},{"p":[{"n":"userToken","p":786433},{"n":"type","p":1310721},{"n":"acctType","p":640223},{"n":"isAuthenticated","p":262145}],"n":".ctor","o":"$ctor$20","d":771295,"h":21475607775,"f":1},{"p":[{"n":"info","p":113967105},{"n":"context","p":114098177}],"n":".ctor","o":"$ctor$21","d":771295,"h":25770575071,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This API supports obsolete formatter-based serialization. It should not be called or extended by application code.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0051","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]},{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"p":[{"n":"identity","p":771295}],"n":".ctor","o":"$ctor$22","d":771295,"h":30065542367,"f":4},{"p":[{"n":"sUserPrincipalName","p":1310721}],"n":".ctor","o":"$ctor$23","d":771295,"h":34360509663,"f":1}],"i":[117047297,57475073,113115137,113377281],"h":771295}; }
            static get $b() { return $.$ssc.System.Security.Claims.ClaimsIdentity; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Security.Principal.IIdentity, $.$spc.System.IDisposable, $.$spc.System.Runtime.Serialization.IDeserializationCallback, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Security.Principal.WindowsIdentity`; }
        });
        
        $asm.$cls("$sspw.System.Security.Principal.IdentityNotMappedException", ($self) => class IdentityNotMappedException extends $.$spc.System.SystemException
        {
            $ctor$9()
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            $ctor$10(/*string?*/ message)
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            $ctor$11(/*string?*/ message, /*System.Exception?*/ inner)
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            /*System.Security.Principal.IdentityReferenceCollection */ get UnmappedIdentities()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetObjectData(/*System.Runtime.Serialization.SerializationInfo*/ serializationInfo, /*System.Runtime.Serialization.StreamingContext*/ streamingContext)
            {
            }
            static $h = 181471;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":119668737,"h":181471}; }
            static get $b() { return $.$spc.System.SystemException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Security.Principal.IdentityNotMappedException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Threading", "NetJs.System.Threading.Thread", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Security.Claims", "NetJs.System.Runtime.InteropServices"))