
(function ($global, $, $spc, $mwp, $sc, $sdt, $st, $scc, $sm, $spu, $sr, $sris, $stt, $ssc) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Security.Principal.Windows", 
    {"h":53279,"f":"System.Security.Principal.Windows","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bf7a34a6f78fee11131301a9f55ca16a968616013","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Security.Principal.Windows","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Security.Principal.Windows","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sspw.System.Security.Principal.IdentityReference", ($self) => class IdentityReference extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static /*bool */ op_Equality(/*System.Security.Principal.IdentityReference?*/ left, /*System.Security.Principal.IdentityReference?*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ op_Inequality(/*System.Security.Principal.IdentityReference?*/ left, /*System.Security.Principal.IdentityReference?*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 249887;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12885151775,"f":257},"n":"Value","d":249887,"h":8590184479,"f":257}],"m":[{"r":262145,"p":[{"n":"o","p":131073}],"n":"Equals","d":249887,"h":17180119071,"f":33025},{"r":655361,"n":"GetHashCode","d":249887,"h":21475086367,"f":33025},{"r":262145,"p":[{"n":"targetType","p":142606337}],"n":"IsValidTargetType","d":249887,"h":25770053663,"f":257},{"r":1310721,"n":"ToString","d":249887,"h":38654955551,"f":33025},{"r":249887,"p":[{"n":"targetType","p":142606337}],"n":"Translate","d":249887,"h":42949922847,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":249887,"h":4295217183,"f":8}],"h":249887}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Security.Principal.IdentityReference`; }
        });
        
        $asm.$cls("$sspw.System.Security.Principal.IdentityReferenceCollection", ($self) => class IdentityReferenceCollection extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*int*/ capacity)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get Count()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IdentityReference*/ get_Item(/*int*/ index)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void*/ set_Item(/*int*/ index, /*System.Security.Principal.IdentityReference*/ value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get System$Collections$Generic$ICollection$$$IsReadOnly()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Add(/*System.Security.Principal.IdentityReference*/ identity)
            {
            }
            /*void */ Clear()
            {
            }
            /*bool */ Contains(/*System.Security.Principal.IdentityReference*/ identity)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CopyTo(/*System.Security.Principal.IdentityReference[]*/ array, /*int*/ offset)
            {
            }
            /*System.Collections.Generic.IEnumerator<System.Security.Principal.IdentityReference> */ GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Remove(/*System.Security.Principal.IdentityReference*/ identity)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IdentityReferenceCollection */ Translate(/*System.Type*/ targetType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IdentityReferenceCollection */ Translate$1(/*System.Type*/ targetType, /*bool*/ forceSuccess)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Security.Principal.IdentityReference>.Count.get
            get System$Collections$Generic$ICollection$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Security.Principal.IdentityReference>.Add(System.Security.Principal.IdentityReference)
            System$Collections$Generic$ICollection$$$Add()
            {
                return this.Add(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Security.Principal.IdentityReference>.Clear()
            System$Collections$Generic$ICollection$$$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Security.Principal.IdentityReference>.Contains(System.Security.Principal.IdentityReference)
            System$Collections$Generic$ICollection$$$Contains()
            {
                return this.Contains(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Security.Principal.IdentityReference>.CopyTo(System.Security.Principal.IdentityReference[], int)
            System$Collections$Generic$ICollection$$$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Security.Principal.IdentityReference>.Remove(System.Security.Principal.IdentityReference)
            System$Collections$Generic$ICollection$$$Remove()
            {
                return this.Remove(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Security.Principal.IdentityReference>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 315423;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":17180184607,"f":1},"n":"Count","d":315423,"h":12885217311,"f":1},{"p":249887,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":25770119199,"f":1},"s":{"r":0,"d":0,"h":30065086495,"f":1},"n":"Item","o":"@$2","d":315423,"h":21475151903,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":38655021087,"f":2},"n":"{$.$spc.System.Collections.Generic.ICollection$$($.$sspw.System.Security.Principal.IdentityReference).$h}.IsReadOnly","o":"System$Collections$Generic$ICollection$$$IsReadOnly","d":315423,"h":34360053791,"f":2}],"m":[{"r":65537,"p":[{"n":"identity","p":249887}],"n":"Add","d":315423,"h":42949988383,"f":1},{"r":65537,"n":"Clear","d":315423,"h":47244955679,"f":1},{"r":262145,"p":[{"n":"identity","p":249887}],"n":"Contains","d":315423,"h":51539922975,"f":1},{"r":65537,"p":[{"n":"array","p":0},{"n":"offset","p":655361}],"n":"CopyTo","d":315423,"h":55834890271,"f":1},{"r":$.$spc.System.Collections.Generic.IEnumerator$$($.$sspw.System.Security.Principal.IdentityReference).$h,"n":"GetEnumerator","d":315423,"h":60129857567,"f":1},{"r":262145,"p":[{"n":"identity","p":249887}],"n":"Remove","d":315423,"h":64424824863,"f":1},{"r":315423,"p":[{"n":"targetType","p":142606337}],"n":"Translate","d":315423,"h":73014759455,"f":1},{"r":315423,"p":[{"n":"targetType","p":142606337},{"n":"forceSuccess","p":262145}],"n":"Translate","o":"@$1","d":315423,"h":77309726751,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":315423,"h":4295282719,"f":1},{"p":[{"n":"capacity","p":655361}],"n":".ctor","o":"$ctor$2","d":315423,"h":8590250015,"f":1}],"i":[$.$spc.System.Collections.Generic.ICollection$$($.$sspw.System.Security.Principal.IdentityReference).$h,$.$spc.System.Collections.Generic.IEnumerable$$($.$sspw.System.Security.Principal.IdentityReference).$h,31653889],"h":315423}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.ICollection$$($.$sspw.System.Security.Principal.IdentityReference), $.$spc.System.Collections.Generic.IEnumerable$$($.$sspw.System.Security.Principal.IdentityReference), $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Security.Principal.IdentityReferenceCollection`; }
        });
        
        $asm.$cls("$sspw.System.Security.Principal.NTAccount", ($self) => class NTAccount extends $.$sspw.System.Security.Principal.IdentityReference
        {
            $ctor$2(/*string*/ name)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$3(/*string*/ domainName, /*string*/ accountName)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*string */ get Value()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ o)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sspw.System.Security.Principal.NTAccount.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sspw.System.Security.Principal.NTAccount.GetHashCode.apply(this, arguments); }
            /*bool */ IsValidTargetType(/*System.Type*/ targetType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ op_Equality$1(/*System.Security.Principal.NTAccount?*/ left, /*System.Security.Principal.NTAccount?*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ op_Inequality$1(/*System.Security.Principal.NTAccount?*/ left, /*System.Security.Principal.NTAccount?*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sspw.System.Security.Principal.NTAccount.ToString.apply(this, arguments); }
            /*System.Security.Principal.IdentityReference */ Translate(/*System.Type*/ targetType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 380959;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":249887,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17180250143,"f":32769},"n":"Value","d":380959,"h":12885282847,"f":32769}],"m":[{"r":262145,"p":[{"n":"o","p":131073}],"n":"Equals","d":380959,"h":21475217439,"f":32769},{"r":655361,"n":"GetHashCode","d":380959,"h":25770184735,"f":32769},{"r":262145,"p":[{"n":"targetType","p":142606337}],"n":"IsValidTargetType","d":380959,"h":30065152031,"f":32769},{"r":1310721,"n":"ToString","d":380959,"h":42950053919,"f":32769},{"r":249887,"p":[{"n":"targetType","p":142606337}],"n":"Translate","d":380959,"h":47245021215,"f":32769}],"c":[{"p":[{"n":"name","p":1310721}],"n":".ctor","o":"$ctor$2","d":380959,"h":4295348255,"f":1},{"p":[{"n":"domainName","p":1310721},{"n":"accountName","p":1310721}],"n":".ctor","o":"$ctor$3","d":380959,"h":8590315551,"f":1}],"h":380959}; }
            static get $b() { return $.$sspw.System.Security.Principal.IdentityReference; }
            static get $fullName() { return `System.Security.Principal.NTAccount`; }
        });
        
        $asm.$cls("$sspw.System.Security.Principal.SecurityIdentifier", ($self) => class SecurityIdentifier extends $.$sspw.System.Security.Principal.IdentityReference
        {
            /*int*/ static MaxBinaryLength = 0;
            /*int*/ static MinBinaryLength = 0;
            $ctor$2(/*byte[]*/ binaryForm, /*int*/ offset)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$3(/*System.IntPtr*/ binaryForm)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$4(/*System.Security.Principal.WellKnownSidType*/ sidType, /*System.Security.Principal.SecurityIdentifier?*/ domainSid)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$5(/*string*/ sddlForm)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Security.Principal.SecurityIdentifier? */ get AccountDomainSid()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get BinaryLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Value()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ CompareTo(/*System.Security.Principal.SecurityIdentifier?*/ sid)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ o)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sspw.System.Security.Principal.SecurityIdentifier.Equals.apply(this, arguments); }
            /*bool */ Equals$2(/*System.Security.Principal.SecurityIdentifier*/ sid)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetBinaryForm(/*byte[]*/ binaryForm, /*int*/ offset)
            {
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sspw.System.Security.Principal.SecurityIdentifier.GetHashCode.apply(this, arguments); }
            /*bool */ IsAccountSid()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ IsEqualDomainSid(/*System.Security.Principal.SecurityIdentifier*/ sid)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ IsValidTargetType(/*System.Type*/ targetType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ IsWellKnown(/*System.Security.Principal.WellKnownSidType*/ type)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ op_Equality$1(/*System.Security.Principal.SecurityIdentifier?*/ left, /*System.Security.Principal.SecurityIdentifier?*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ op_Inequality$1(/*System.Security.Principal.SecurityIdentifier?*/ left, /*System.Security.Principal.SecurityIdentifier?*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sspw.System.Security.Principal.SecurityIdentifier.ToString.apply(this, arguments); }
            /*System.Security.Principal.IdentityReference */ Translate(/*System.Type*/ targetType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.IComparable<System.Security.Principal.SecurityIdentifier>.CompareTo(System.Security.Principal.SecurityIdentifier?)
            System$IComparable$$$CompareTo()
            {
                return this.CompareTo(...arguments);
            }
            static $h = 446495;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":249887,"p":[{"p":446495,"g":{"r":0,"d":0,"h":34360184863,"f":1},"n":"AccountDomainSid","d":446495,"h":30065217567,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":42950119455,"f":1},"n":"BinaryLength","d":446495,"h":38655152159,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":51540054047,"f":32769},"n":"Value","d":446495,"h":47245086751,"f":32769}],"m":[{"r":655361,"p":[{"n":"sid","p":446495}],"n":"CompareTo","d":446495,"h":55835021343,"f":1},{"r":262145,"p":[{"n":"o","p":131073}],"n":"Equals","d":446495,"h":60129988639,"f":32769},{"r":262145,"p":[{"n":"sid","p":446495}],"n":"Equals","o":"@$2","d":446495,"h":64424955935,"f":1},{"r":65537,"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":"GetBinaryForm","d":446495,"h":68719923231,"f":1},{"r":655361,"n":"GetHashCode","d":446495,"h":73014890527,"f":32769},{"r":262145,"n":"IsAccountSid","d":446495,"h":77309857823,"f":1},{"r":262145,"p":[{"n":"sid","p":446495}],"n":"IsEqualDomainSid","d":446495,"h":81604825119,"f":1},{"r":262145,"p":[{"n":"targetType","p":142606337}],"n":"IsValidTargetType","d":446495,"h":85899792415,"f":32769},{"r":262145,"p":[{"n":"type","p":577567}],"n":"IsWellKnown","d":446495,"h":90194759711,"f":1},{"r":1310721,"n":"ToString","d":446495,"h":103079661599,"f":32769},{"r":249887,"p":[{"n":"targetType","p":142606337}],"n":"Translate","d":446495,"h":107374628895,"f":32769}],"l":[{"t":655361,"n":"MaxBinaryLength","d":446495,"h":4295413791,"f":33},{"t":655361,"n":"MinBinaryLength","d":446495,"h":8590381087,"f":33}],"c":[{"p":[{"n":"binaryForm","p":0},{"n":"offset","p":655361}],"n":".ctor","o":"$ctor$2","d":446495,"h":12885348383,"f":1},{"p":[{"n":"binaryForm","p":786433}],"n":".ctor","o":"$ctor$3","d":446495,"h":17180315679,"f":1},{"p":[{"n":"sidType","p":577567},{"n":"domainSid","p":446495}],"n":".ctor","o":"$ctor$4","d":446495,"h":21475282975,"f":1},{"p":[{"n":"sddlForm","p":1310721}],"n":".ctor","o":"$ctor$5","d":446495,"h":25770250271,"f":1}],"i":[$.$spc.System.IComparable$$($.$sspw.System.Security.Principal.SecurityIdentifier).$h],"h":446495}; }
            static get $b() { return $.$sspw.System.Security.Principal.IdentityReference; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable$$($.$sspw.System.Security.Principal.SecurityIdentifier) ]; }
            static get $fullName() { return `System.Security.Principal.SecurityIdentifier`; }
        });
        
        $asm.$cls("$sspw.Microsoft.Win32.SafeHandles.SafeAccessTokenHandle", ($self) => class SafeAccessTokenHandle extends $.$spc.System.Runtime.InteropServices.SafeHandle
        {
            $ctor$3()
            {
                super.$ctor$2(0, false);
                {
                }
                return this;
            }
            $ctor$4(/*System.IntPtr*/ handle)
            {
                super.$ctor$2(0, false);
                {
                }
                return this;
            }
            static /*Microsoft.Win32.SafeHandles.SafeAccessTokenHandle */ get InvalidHandle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsInvalid()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ReleaseHandle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 118815;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":109576193,"p":[{"p":118815,"g":{"r":0,"d":0,"h":17179987999,"f":33},"n":"InvalidHandle","d":118815,"h":12885020703,"f":33},{"p":262145,"g":{"r":0,"d":0,"h":25769922591,"f":32769},"n":"IsInvalid","d":118815,"h":21474955295,"f":32769}],"m":[{"r":262145,"n":"ReleaseHandle","d":118815,"h":30064889887,"f":32772}],"c":[{"n":".ctor","o":"$ctor$3","d":118815,"h":4295086111,"f":1},{"p":[{"n":"handle","p":786433}],"n":".ctor","o":"$ctor$4","d":118815,"h":8590053407,"f":1}],"i":[57540609],"h":118815}; }
            static get $b() { return $.$spc.System.Runtime.InteropServices.SafeHandle; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Win32.SafeHandles.SafeAccessTokenHandle`; }
        });
        
        $asm.$str("$sspw.System.Security.Principal.TokenAccessLevels", ($self) => class TokenAccessLevels extends $.$spc.System.Enum
        {
            static AssignPrimary = 1;
            static Duplicate = 2;
            static Impersonate = 4;
            static Query = 8;
            static QuerySource = 16;
            static AdjustPrivileges = 32;
            static AdjustGroups = 64;
            static AdjustDefault = 128;
            static AdjustSessionId = 256;
            static Read = 131080;
            static Write = 131296;
            static AllAccess = 983551;
            static MaximumAllowed = 33554432;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "AssignPrimary": 1n,
                    "Duplicate": 2n,
                    "Impersonate": 4n,
                    "Query": 8n,
                    "QuerySource": 16n,
                    "AdjustPrivileges": 32n,
                    "AdjustGroups": 64n,
                    "AdjustDefault": 128n,
                    "AdjustSessionId": 256n,
                    "Read": 131080n,
                    "Write": 131296n,
                    "AllAccess": 983551n,
                    "MaximumAllowed": 33554432n
                };
            }
            static $h = 512031;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":512031,"n":"AssignPrimary","d":512031,"h":4295479327,"f":33},{"t":512031,"n":"Duplicate","d":512031,"h":8590446623,"f":33},{"t":512031,"n":"Impersonate","d":512031,"h":12885413919,"f":33},{"t":512031,"n":"Query","d":512031,"h":17180381215,"f":33},{"t":512031,"n":"QuerySource","d":512031,"h":21475348511,"f":33},{"t":512031,"n":"AdjustPrivileges","d":512031,"h":25770315807,"f":33},{"t":512031,"n":"AdjustGroups","d":512031,"h":30065283103,"f":33},{"t":512031,"n":"AdjustDefault","d":512031,"h":34360250399,"f":33},{"t":512031,"n":"AdjustSessionId","d":512031,"h":38655217695,"f":33},{"t":512031,"n":"Read","d":512031,"h":42950184991,"f":33},{"t":512031,"n":"Write","d":512031,"h":47245152287,"f":33},{"t":512031,"n":"AllAccess","d":512031,"h":51540119583,"f":33},{"t":512031,"n":"MaximumAllowed","d":512031,"h":55835086879,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":512031,"h":60130054175,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":512031,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.Principal.TokenAccessLevels`; }
        });
        
        $asm.$str("$sspw.System.Security.Principal.WellKnownSidType", ($self) => class WellKnownSidType extends $.$spc.System.Enum
        {
            static NullSid = 0;
            static WorldSid = 1;
            static LocalSid = 2;
            static CreatorOwnerSid = 3;
            static CreatorGroupSid = 4;
            static CreatorOwnerServerSid = 5;
            static CreatorGroupServerSid = 6;
            static NTAuthoritySid = 7;
            static DialupSid = 8;
            static NetworkSid = 9;
            static BatchSid = 10;
            static InteractiveSid = 11;
            static ServiceSid = 12;
            static AnonymousSid = 13;
            static ProxySid = 14;
            static EnterpriseControllersSid = 15;
            static SelfSid = 16;
            static AuthenticatedUserSid = 17;
            static RestrictedCodeSid = 18;
            static TerminalServerSid = 19;
            static RemoteLogonIdSid = 20;
            static LogonIdsSid = 21;
            static LocalSystemSid = 22;
            static LocalServiceSid = 23;
            static NetworkServiceSid = 24;
            static BuiltinDomainSid = 25;
            static BuiltinAdministratorsSid = 26;
            static BuiltinUsersSid = 27;
            static BuiltinGuestsSid = 28;
            static BuiltinPowerUsersSid = 29;
            static BuiltinAccountOperatorsSid = 30;
            static BuiltinSystemOperatorsSid = 31;
            static BuiltinPrintOperatorsSid = 32;
            static BuiltinBackupOperatorsSid = 33;
            static BuiltinReplicatorSid = 34;
            static BuiltinPreWindows2000CompatibleAccessSid = 35;
            static BuiltinRemoteDesktopUsersSid = 36;
            static BuiltinNetworkConfigurationOperatorsSid = 37;
            static AccountAdministratorSid = 38;
            static AccountGuestSid = 39;
            static AccountKrbtgtSid = 40;
            static AccountDomainAdminsSid = 41;
            static AccountDomainUsersSid = 42;
            static AccountDomainGuestsSid = 43;
            static AccountComputersSid = 44;
            static AccountControllersSid = 45;
            static AccountCertAdminsSid = 46;
            static AccountSchemaAdminsSid = 47;
            static AccountEnterpriseAdminsSid = 48;
            static AccountPolicyAdminsSid = 49;
            static AccountRasAndIasServersSid = 50;
            static NtlmAuthenticationSid = 51;
            static DigestAuthenticationSid = 52;
            static SChannelAuthenticationSid = 53;
            static ThisOrganizationSid = 54;
            static OtherOrganizationSid = 55;
            static BuiltinIncomingForestTrustBuildersSid = 56;
            static BuiltinPerformanceMonitoringUsersSid = 57;
            static BuiltinPerformanceLoggingUsersSid = 58;
            static BuiltinAuthorizationAccessSid = 59;
            static MaxDefined = 60;
            static WinBuiltinTerminalServerLicenseServersSid = 60;
            static WinBuiltinDCOMUsersSid = 61;
            static WinBuiltinIUsersSid = 62;
            static WinIUserSid = 63;
            static WinBuiltinCryptoOperatorsSid = 64;
            static WinUntrustedLabelSid = 65;
            static WinLowLabelSid = 66;
            static WinMediumLabelSid = 67;
            static WinHighLabelSid = 68;
            static WinSystemLabelSid = 69;
            static WinWriteRestrictedCodeSid = 70;
            static WinCreatorOwnerRightsSid = 71;
            static WinCacheablePrincipalsGroupSid = 72;
            static WinNonCacheablePrincipalsGroupSid = 73;
            static WinEnterpriseReadonlyControllersSid = 74;
            static WinAccountReadonlyControllersSid = 75;
            static WinBuiltinEventLogReadersGroup = 76;
            static WinNewEnterpriseReadonlyControllersSid = 77;
            static WinBuiltinCertSvcDComAccessGroup = 78;
            static WinMediumPlusLabelSid = 79;
            static WinLocalLogonSid = 80;
            static WinConsoleLogonSid = 81;
            static WinThisOrganizationCertificateSid = 82;
            static WinApplicationPackageAuthoritySid = 83;
            static WinBuiltinAnyPackageSid = 84;
            static WinCapabilityInternetClientSid = 85;
            static WinCapabilityInternetClientServerSid = 86;
            static WinCapabilityPrivateNetworkClientServerSid = 87;
            static WinCapabilityPicturesLibrarySid = 88;
            static WinCapabilityVideosLibrarySid = 89;
            static WinCapabilityMusicLibrarySid = 90;
            static WinCapabilityDocumentsLibrarySid = 91;
            static WinCapabilitySharedUserCertificatesSid = 92;
            static WinCapabilityEnterpriseAuthenticationSid = 93;
            static WinCapabilityRemovableStorageSid = 94;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "NullSid": 0n,
                    "WorldSid": 1n,
                    "LocalSid": 2n,
                    "CreatorOwnerSid": 3n,
                    "CreatorGroupSid": 4n,
                    "CreatorOwnerServerSid": 5n,
                    "CreatorGroupServerSid": 6n,
                    "NTAuthoritySid": 7n,
                    "DialupSid": 8n,
                    "NetworkSid": 9n,
                    "BatchSid": 10n,
                    "InteractiveSid": 11n,
                    "ServiceSid": 12n,
                    "AnonymousSid": 13n,
                    "ProxySid": 14n,
                    "EnterpriseControllersSid": 15n,
                    "SelfSid": 16n,
                    "AuthenticatedUserSid": 17n,
                    "RestrictedCodeSid": 18n,
                    "TerminalServerSid": 19n,
                    "RemoteLogonIdSid": 20n,
                    "LogonIdsSid": 21n,
                    "LocalSystemSid": 22n,
                    "LocalServiceSid": 23n,
                    "NetworkServiceSid": 24n,
                    "BuiltinDomainSid": 25n,
                    "BuiltinAdministratorsSid": 26n,
                    "BuiltinUsersSid": 27n,
                    "BuiltinGuestsSid": 28n,
                    "BuiltinPowerUsersSid": 29n,
                    "BuiltinAccountOperatorsSid": 30n,
                    "BuiltinSystemOperatorsSid": 31n,
                    "BuiltinPrintOperatorsSid": 32n,
                    "BuiltinBackupOperatorsSid": 33n,
                    "BuiltinReplicatorSid": 34n,
                    "BuiltinPreWindows2000CompatibleAccessSid": 35n,
                    "BuiltinRemoteDesktopUsersSid": 36n,
                    "BuiltinNetworkConfigurationOperatorsSid": 37n,
                    "AccountAdministratorSid": 38n,
                    "AccountGuestSid": 39n,
                    "AccountKrbtgtSid": 40n,
                    "AccountDomainAdminsSid": 41n,
                    "AccountDomainUsersSid": 42n,
                    "AccountDomainGuestsSid": 43n,
                    "AccountComputersSid": 44n,
                    "AccountControllersSid": 45n,
                    "AccountCertAdminsSid": 46n,
                    "AccountSchemaAdminsSid": 47n,
                    "AccountEnterpriseAdminsSid": 48n,
                    "AccountPolicyAdminsSid": 49n,
                    "AccountRasAndIasServersSid": 50n,
                    "NtlmAuthenticationSid": 51n,
                    "DigestAuthenticationSid": 52n,
                    "SChannelAuthenticationSid": 53n,
                    "ThisOrganizationSid": 54n,
                    "OtherOrganizationSid": 55n,
                    "BuiltinIncomingForestTrustBuildersSid": 56n,
                    "BuiltinPerformanceMonitoringUsersSid": 57n,
                    "BuiltinPerformanceLoggingUsersSid": 58n,
                    "BuiltinAuthorizationAccessSid": 59n,
                    "MaxDefined": 60n,
                    "WinBuiltinTerminalServerLicenseServersSid": 60n,
                    "WinBuiltinDCOMUsersSid": 61n,
                    "WinBuiltinIUsersSid": 62n,
                    "WinIUserSid": 63n,
                    "WinBuiltinCryptoOperatorsSid": 64n,
                    "WinUntrustedLabelSid": 65n,
                    "WinLowLabelSid": 66n,
                    "WinMediumLabelSid": 67n,
                    "WinHighLabelSid": 68n,
                    "WinSystemLabelSid": 69n,
                    "WinWriteRestrictedCodeSid": 70n,
                    "WinCreatorOwnerRightsSid": 71n,
                    "WinCacheablePrincipalsGroupSid": 72n,
                    "WinNonCacheablePrincipalsGroupSid": 73n,
                    "WinEnterpriseReadonlyControllersSid": 74n,
                    "WinAccountReadonlyControllersSid": 75n,
                    "WinBuiltinEventLogReadersGroup": 76n,
                    "WinNewEnterpriseReadonlyControllersSid": 77n,
                    "WinBuiltinCertSvcDComAccessGroup": 78n,
                    "WinMediumPlusLabelSid": 79n,
                    "WinLocalLogonSid": 80n,
                    "WinConsoleLogonSid": 81n,
                    "WinThisOrganizationCertificateSid": 82n,
                    "WinApplicationPackageAuthoritySid": 83n,
                    "WinBuiltinAnyPackageSid": 84n,
                    "WinCapabilityInternetClientSid": 85n,
                    "WinCapabilityInternetClientServerSid": 86n,
                    "WinCapabilityPrivateNetworkClientServerSid": 87n,
                    "WinCapabilityPicturesLibrarySid": 88n,
                    "WinCapabilityVideosLibrarySid": 89n,
                    "WinCapabilityMusicLibrarySid": 90n,
                    "WinCapabilityDocumentsLibrarySid": 91n,
                    "WinCapabilitySharedUserCertificatesSid": 92n,
                    "WinCapabilityEnterpriseAuthenticationSid": 93n,
                    "WinCapabilityRemovableStorageSid": 94n
                };
            }
            static $h = 577567;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":577567,"n":"NullSid","d":577567,"h":4295544863,"f":33},{"t":577567,"n":"WorldSid","d":577567,"h":8590512159,"f":33},{"t":577567,"n":"LocalSid","d":577567,"h":12885479455,"f":33},{"t":577567,"n":"CreatorOwnerSid","d":577567,"h":17180446751,"f":33},{"t":577567,"n":"CreatorGroupSid","d":577567,"h":21475414047,"f":33},{"t":577567,"n":"CreatorOwnerServerSid","d":577567,"h":25770381343,"f":33},{"t":577567,"n":"CreatorGroupServerSid","d":577567,"h":30065348639,"f":33},{"t":577567,"n":"NTAuthoritySid","d":577567,"h":34360315935,"f":33},{"t":577567,"n":"DialupSid","d":577567,"h":38655283231,"f":33},{"t":577567,"n":"NetworkSid","d":577567,"h":42950250527,"f":33},{"t":577567,"n":"BatchSid","d":577567,"h":47245217823,"f":33},{"t":577567,"n":"InteractiveSid","d":577567,"h":51540185119,"f":33},{"t":577567,"n":"ServiceSid","d":577567,"h":55835152415,"f":33},{"t":577567,"n":"AnonymousSid","d":577567,"h":60130119711,"f":33},{"t":577567,"n":"ProxySid","d":577567,"h":64425087007,"f":33},{"t":577567,"n":"EnterpriseControllersSid","d":577567,"h":68720054303,"f":33},{"t":577567,"n":"SelfSid","d":577567,"h":73015021599,"f":33},{"t":577567,"n":"AuthenticatedUserSid","d":577567,"h":77309988895,"f":33},{"t":577567,"n":"RestrictedCodeSid","d":577567,"h":81604956191,"f":33},{"t":577567,"n":"TerminalServerSid","d":577567,"h":85899923487,"f":33},{"t":577567,"n":"RemoteLogonIdSid","d":577567,"h":90194890783,"f":33},{"t":577567,"n":"LogonIdsSid","d":577567,"h":94489858079,"f":33},{"t":577567,"n":"LocalSystemSid","d":577567,"h":98784825375,"f":33},{"t":577567,"n":"LocalServiceSid","d":577567,"h":103079792671,"f":33},{"t":577567,"n":"NetworkServiceSid","d":577567,"h":107374759967,"f":33},{"t":577567,"n":"BuiltinDomainSid","d":577567,"h":111669727263,"f":33},{"t":577567,"n":"BuiltinAdministratorsSid","d":577567,"h":115964694559,"f":33},{"t":577567,"n":"BuiltinUsersSid","d":577567,"h":120259661855,"f":33},{"t":577567,"n":"BuiltinGuestsSid","d":577567,"h":124554629151,"f":33},{"t":577567,"n":"BuiltinPowerUsersSid","d":577567,"h":128849596447,"f":33},{"t":577567,"n":"BuiltinAccountOperatorsSid","d":577567,"h":133144563743,"f":33},{"t":577567,"n":"BuiltinSystemOperatorsSid","d":577567,"h":137439531039,"f":33},{"t":577567,"n":"BuiltinPrintOperatorsSid","d":577567,"h":141734498335,"f":33},{"t":577567,"n":"BuiltinBackupOperatorsSid","d":577567,"h":146029465631,"f":33},{"t":577567,"n":"BuiltinReplicatorSid","d":577567,"h":150324432927,"f":33},{"t":577567,"n":"BuiltinPreWindows2000CompatibleAccessSid","d":577567,"h":154619400223,"f":33},{"t":577567,"n":"BuiltinRemoteDesktopUsersSid","d":577567,"h":158914367519,"f":33},{"t":577567,"n":"BuiltinNetworkConfigurationOperatorsSid","d":577567,"h":163209334815,"f":33},{"t":577567,"n":"AccountAdministratorSid","d":577567,"h":167504302111,"f":33},{"t":577567,"n":"AccountGuestSid","d":577567,"h":171799269407,"f":33},{"t":577567,"n":"AccountKrbtgtSid","d":577567,"h":176094236703,"f":33},{"t":577567,"n":"AccountDomainAdminsSid","d":577567,"h":180389203999,"f":33},{"t":577567,"n":"AccountDomainUsersSid","d":577567,"h":184684171295,"f":33},{"t":577567,"n":"AccountDomainGuestsSid","d":577567,"h":188979138591,"f":33},{"t":577567,"n":"AccountComputersSid","d":577567,"h":193274105887,"f":33},{"t":577567,"n":"AccountControllersSid","d":577567,"h":197569073183,"f":33},{"t":577567,"n":"AccountCertAdminsSid","d":577567,"h":201864040479,"f":33},{"t":577567,"n":"AccountSchemaAdminsSid","d":577567,"h":206159007775,"f":33},{"t":577567,"n":"AccountEnterpriseAdminsSid","d":577567,"h":210453975071,"f":33},{"t":577567,"n":"AccountPolicyAdminsSid","d":577567,"h":214748942367,"f":33},{"t":577567,"n":"AccountRasAndIasServersSid","d":577567,"h":219043909663,"f":33},{"t":577567,"n":"NtlmAuthenticationSid","d":577567,"h":223338876959,"f":33},{"t":577567,"n":"DigestAuthenticationSid","d":577567,"h":227633844255,"f":33},{"t":577567,"n":"SChannelAuthenticationSid","d":577567,"h":231928811551,"f":33},{"t":577567,"n":"ThisOrganizationSid","d":577567,"h":236223778847,"f":33},{"t":577567,"n":"OtherOrganizationSid","d":577567,"h":240518746143,"f":33},{"t":577567,"n":"BuiltinIncomingForestTrustBuildersSid","d":577567,"h":244813713439,"f":33},{"t":577567,"n":"BuiltinPerformanceMonitoringUsersSid","d":577567,"h":249108680735,"f":33},{"t":577567,"n":"BuiltinPerformanceLoggingUsersSid","d":577567,"h":253403648031,"f":33},{"t":577567,"n":"BuiltinAuthorizationAccessSid","d":577567,"h":257698615327,"f":33},{"t":577567,"n":"MaxDefined","d":577567,"h":261993582623,"f":33,"a":[{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]},{"t":70909953,"c":8660844545,"a":[{"v":"This member has been deprecated and is only maintained for backwards compatability. WellKnownSidType values greater than MaxDefined may be defined in future releases.","t":1310721}]}]},{"t":577567,"n":"WinBuiltinTerminalServerLicenseServersSid","d":577567,"h":266288549919,"f":33},{"t":577567,"n":"WinBuiltinDCOMUsersSid","d":577567,"h":270583517215,"f":33},{"t":577567,"n":"WinBuiltinIUsersSid","d":577567,"h":274878484511,"f":33},{"t":577567,"n":"WinIUserSid","d":577567,"h":279173451807,"f":33},{"t":577567,"n":"WinBuiltinCryptoOperatorsSid","d":577567,"h":283468419103,"f":33},{"t":577567,"n":"WinUntrustedLabelSid","d":577567,"h":287763386399,"f":33},{"t":577567,"n":"WinLowLabelSid","d":577567,"h":292058353695,"f":33},{"t":577567,"n":"WinMediumLabelSid","d":577567,"h":296353320991,"f":33},{"t":577567,"n":"WinHighLabelSid","d":577567,"h":300648288287,"f":33},{"t":577567,"n":"WinSystemLabelSid","d":577567,"h":304943255583,"f":33},{"t":577567,"n":"WinWriteRestrictedCodeSid","d":577567,"h":309238222879,"f":33},{"t":577567,"n":"WinCreatorOwnerRightsSid","d":577567,"h":313533190175,"f":33},{"t":577567,"n":"WinCacheablePrincipalsGroupSid","d":577567,"h":317828157471,"f":33},{"t":577567,"n":"WinNonCacheablePrincipalsGroupSid","d":577567,"h":322123124767,"f":33},{"t":577567,"n":"WinEnterpriseReadonlyControllersSid","d":577567,"h":326418092063,"f":33},{"t":577567,"n":"WinAccountReadonlyControllersSid","d":577567,"h":330713059359,"f":33},{"t":577567,"n":"WinBuiltinEventLogReadersGroup","d":577567,"h":335008026655,"f":33},{"t":577567,"n":"WinNewEnterpriseReadonlyControllersSid","d":577567,"h":339302993951,"f":33},{"t":577567,"n":"WinBuiltinCertSvcDComAccessGroup","d":577567,"h":343597961247,"f":33},{"t":577567,"n":"WinMediumPlusLabelSid","d":577567,"h":347892928543,"f":33},{"t":577567,"n":"WinLocalLogonSid","d":577567,"h":352187895839,"f":33},{"t":577567,"n":"WinConsoleLogonSid","d":577567,"h":356482863135,"f":33},{"t":577567,"n":"WinThisOrganizationCertificateSid","d":577567,"h":360777830431,"f":33},{"t":577567,"n":"WinApplicationPackageAuthoritySid","d":577567,"h":365072797727,"f":33},{"t":577567,"n":"WinBuiltinAnyPackageSid","d":577567,"h":369367765023,"f":33},{"t":577567,"n":"WinCapabilityInternetClientSid","d":577567,"h":373662732319,"f":33},{"t":577567,"n":"WinCapabilityInternetClientServerSid","d":577567,"h":377957699615,"f":33},{"t":577567,"n":"WinCapabilityPrivateNetworkClientServerSid","d":577567,"h":382252666911,"f":33},{"t":577567,"n":"WinCapabilityPicturesLibrarySid","d":577567,"h":386547634207,"f":33},{"t":577567,"n":"WinCapabilityVideosLibrarySid","d":577567,"h":390842601503,"f":33},{"t":577567,"n":"WinCapabilityMusicLibrarySid","d":577567,"h":395137568799,"f":33},{"t":577567,"n":"WinCapabilityDocumentsLibrarySid","d":577567,"h":399432536095,"f":33},{"t":577567,"n":"WinCapabilitySharedUserCertificatesSid","d":577567,"h":403727503391,"f":33},{"t":577567,"n":"WinCapabilityEnterpriseAuthenticationSid","d":577567,"h":408022470687,"f":33},{"t":577567,"n":"WinCapabilityRemovableStorageSid","d":577567,"h":412317437983,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":577567,"h":416612405279,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":577567}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.Principal.WellKnownSidType`; }
        });
        
        $asm.$str("$sspw.System.Security.Principal.WindowsAccountType", ($self) => class WindowsAccountType extends $.$spc.System.Enum
        {
            static Normal = 0;
            static Guest = 1;
            static System = 2;
            static Anonymous = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Normal": 0n,
                    "Guest": 1n,
                    "System": 2n,
                    "Anonymous": 3n
                };
            }
            static $h = 643103;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":643103,"n":"Normal","d":643103,"h":4295610399,"f":33},{"t":643103,"n":"Guest","d":643103,"h":8590577695,"f":33},{"t":643103,"n":"System","d":643103,"h":12885544991,"f":33},{"t":643103,"n":"Anonymous","d":643103,"h":17180512287,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":643103,"h":21475479583,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":643103}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.Principal.WindowsAccountType`; }
        });
        
        $asm.$str("$sspw.System.Security.Principal.WindowsBuiltInRole", ($self) => class WindowsBuiltInRole extends $.$spc.System.Enum
        {
            static Administrator = 544;
            static User = 545;
            static Guest = 546;
            static PowerUser = 547;
            static AccountOperator = 548;
            static SystemOperator = 549;
            static PrintOperator = 550;
            static BackupOperator = 551;
            static Replicator = 552;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Administrator": 544n,
                    "User": 545n,
                    "Guest": 546n,
                    "PowerUser": 547n,
                    "AccountOperator": 548n,
                    "SystemOperator": 549n,
                    "PrintOperator": 550n,
                    "BackupOperator": 551n,
                    "Replicator": 552n
                };
            }
            static $h = 708639;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":708639,"n":"Administrator","d":708639,"h":4295675935,"f":33},{"t":708639,"n":"User","d":708639,"h":8590643231,"f":33},{"t":708639,"n":"Guest","d":708639,"h":12885610527,"f":33},{"t":708639,"n":"PowerUser","d":708639,"h":17180577823,"f":33},{"t":708639,"n":"AccountOperator","d":708639,"h":21475545119,"f":33},{"t":708639,"n":"SystemOperator","d":708639,"h":25770512415,"f":33},{"t":708639,"n":"PrintOperator","d":708639,"h":30065479711,"f":33},{"t":708639,"n":"BackupOperator","d":708639,"h":34360447007,"f":33},{"t":708639,"n":"Replicator","d":708639,"h":38655414303,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":708639,"h":42950381599,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":708639}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.Principal.WindowsBuiltInRole`; }
        });
        
        $asm.$cls("$sspw.System.Security.Principal.WindowsPrincipal", ($self) => class WindowsPrincipal extends $.$ssc.System.Security.Claims.ClaimsPrincipal
        {
            $ctor$7(/*System.Security.Principal.WindowsIdentity*/ ntIdentity)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*System.Collections.Generic.IEnumerable<System.Security.Claims.Claim> */ get DeviceClaims()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IIdentity */ get Identity()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.IEnumerable<System.Security.Claims.Claim> */ get UserClaims()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ IsInRole$1(/*int*/ rid)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ IsInRole$2(/*System.Security.Principal.SecurityIdentifier*/ sid)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ IsInRole$3(/*System.Security.Principal.WindowsBuiltInRole*/ role)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ IsInRole(/*string*/ role)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 839711;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":447163,"p":[{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"g":{"r":0,"d":0,"h":12885741599,"f":129},"n":"DeviceClaims","d":839711,"h":8590774303,"f":129},{"p":117047297,"g":{"r":0,"d":0,"h":21475676191,"f":32769},"n":"Identity","d":839711,"h":17180708895,"f":32769},{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"g":{"r":0,"d":0,"h":30065610783,"f":129},"n":"UserClaims","d":839711,"h":25770643487,"f":129}],"m":[{"r":262145,"p":[{"n":"rid","p":655361}],"n":"IsInRole","o":"@$1","d":839711,"h":34360578079,"f":129},{"r":262145,"p":[{"n":"sid","p":446495}],"n":"IsInRole","o":"@$2","d":839711,"h":38655545375,"f":129},{"r":262145,"p":[{"n":"role","p":708639}],"n":"IsInRole","o":"@$3","d":839711,"h":42950512671,"f":129},{"r":262145,"p":[{"n":"role","p":1310721}],"n":"IsInRole","d":839711,"h":47245479967,"f":32769}],"c":[{"p":[{"n":"ntIdentity","p":774175}],"n":".ctor","o":"$ctor$7","d":839711,"h":4295807007,"f":1}],"i":[117112833],"h":839711}; }
            static get $b() { return $.$ssc.System.Security.Claims.ClaimsPrincipal; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Security.Principal.IPrincipal ]; }
            static get $fullName() { return `System.Security.Principal.WindowsPrincipal`; }
        });
        
        $asm.$cls("$sspw.System.Security.Principal.WindowsIdentity", ($self) => class WindowsIdentity extends $.$ssc.System.Security.Claims.ClaimsIdentity
        {
            /*string*/ static DefaultIssuer = null;
            $ctor$17(/*System.IntPtr*/ userToken)
            {
                super.$ctor$14(null, null, null, null, null, 5);
                {
                }
                return this;
            }
            $ctor$18(/*System.IntPtr*/ userToken, /*string*/ type)
            {
                super.$ctor$14(null, null, null, null, null, 5);
                {
                }
                return this;
            }
            $ctor$19(/*System.IntPtr*/ userToken, /*string*/ type, /*System.Security.Principal.WindowsAccountType*/ acctType)
            {
                super.$ctor$14(null, null, null, null, null, 5);
                {
                }
                return this;
            }
            $ctor$20(/*System.IntPtr*/ userToken, /*string*/ type, /*System.Security.Principal.WindowsAccountType*/ acctType, /*bool*/ isAuthenticated)
            {
                super.$ctor$14(null, null, null, null, null, 5);
                {
                }
                return this;
            }
            $ctor$21(/*System.Runtime.Serialization.SerializationInfo*/ info, /*System.Runtime.Serialization.StreamingContext*/ context)
            {
                super.$ctor$14(null, null, null, null, null, 5);
                {
                }
                return this;
            }
            $ctor$22(/*System.Security.Principal.WindowsIdentity*/ identity)
            {
                super.$ctor$14(null, null, null, null, null, 5);
                {
                }
                return this;
            }
            $ctor$23(/*string*/ sUserPrincipalName)
            {
                super.$ctor$14(null, null, null, null, null, 5);
                {
                }
                return this;
            }
            /*Microsoft.Win32.SafeHandles.SafeAccessTokenHandle */ get AccessToken()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get AuthenticationType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.IEnumerable<System.Security.Claims.Claim> */ get Claims()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.IEnumerable<System.Security.Claims.Claim> */ get DeviceClaims()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IdentityReferenceCollection? */ get Groups()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.TokenImpersonationLevel */ get ImpersonationLevel()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsAnonymous()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsAuthenticated()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsGuest()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsSystem()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Name()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ get Owner()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ get Token()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.SecurityIdentifier? */ get User()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.IEnumerable<System.Security.Claims.Claim> */ get UserClaims()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Claims.ClaimsIdentity */ Clone()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose()
            {
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            static /*System.Security.Principal.WindowsIdentity */ GetAnonymous()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Security.Principal.WindowsIdentity */ GetCurrent()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Security.Principal.WindowsIdentity? */ GetCurrent$1(/*bool*/ ifImpersonating)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Security.Principal.WindowsIdentity */ GetCurrent$2(/*System.Security.Principal.TokenAccessLevels*/ desiredAccess)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*void */ RunImpersonated(/*Microsoft.Win32.SafeHandles.SafeAccessTokenHandle*/ safeAccessTokenHandle, /*System.Action*/ action)
            {
            }
            static /*System.Threading.Tasks.Task */ RunImpersonatedAsync(/*Microsoft.Win32.SafeHandles.SafeAccessTokenHandle*/ safeAccessTokenHandle, /*System.Func<System.Threading.Tasks.Task>*/ func)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<T> */ RunImpersonatedAsync$1(T, /*Microsoft.Win32.SafeHandles.SafeAccessTokenHandle*/ safeAccessTokenHandle, /*System.Func<System.Threading.Tasks.Task<T>>*/ func)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*T */ RunImpersonated$1(T, /*Microsoft.Win32.SafeHandles.SafeAccessTokenHandle*/ safeAccessTokenHandle, /*System.Func<T>*/ func)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ System$Runtime$Serialization$IDeserializationCallback$OnDeserialization(/*object?*/ sender)
            {
            }
            /*void */ System$Runtime$Serialization$ISerializable$GetObjectData(/*System.Runtime.Serialization.SerializationInfo*/ info, /*System.Runtime.Serialization.StreamingContext*/ context)
            {
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.DefaultIssuer = "AD AUTHORITY";
                }
            }
            static $h = 774175;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":316091,"p":[{"p":118815,"g":{"r":0,"d":0,"h":42950447135,"f":1},"n":"AccessToken","d":774175,"h":38655479839,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":51540381727,"f":98305},"n":"AuthenticationType","d":774175,"h":47245414431,"f":98305},{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"g":{"r":0,"d":0,"h":60130316319,"f":32769},"n":"Claims","d":774175,"h":55835349023,"f":32769},{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"g":{"r":0,"d":0,"h":68720250911,"f":129},"n":"DeviceClaims","d":774175,"h":64425283615,"f":129},{"p":315423,"g":{"r":0,"d":0,"h":77310185503,"f":1},"n":"Groups","d":774175,"h":73015218207,"f":1},{"p":117243905,"g":{"r":0,"d":0,"h":85900120095,"f":1},"n":"ImpersonationLevel","d":774175,"h":81605152799,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":94490054687,"f":129},"n":"IsAnonymous","d":774175,"h":90195087391,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":103079989279,"f":32769},"n":"IsAuthenticated","d":774175,"h":98785021983,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":111669923871,"f":129},"n":"IsGuest","d":774175,"h":107374956575,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":120259858463,"f":129},"n":"IsSystem","d":774175,"h":115964891167,"f":129},{"p":1310721,"g":{"r":0,"d":0,"h":128849793055,"f":32769},"n":"Name","d":774175,"h":124554825759,"f":32769},{"p":446495,"g":{"r":0,"d":0,"h":137439727647,"f":1},"n":"Owner","d":774175,"h":133144760351,"f":1},{"p":786433,"g":{"r":0,"d":0,"h":146029662239,"f":129},"n":"Token","d":774175,"h":141734694943,"f":129},{"p":446495,"g":{"r":0,"d":0,"h":154619596831,"f":1},"n":"User","d":774175,"h":150324629535,"f":1},{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"g":{"r":0,"d":0,"h":163209531423,"f":129},"n":"UserClaims","d":774175,"h":158914564127,"f":129}],"m":[{"r":316091,"n":"Clone","d":774175,"h":167504498719,"f":32769},{"r":65537,"n":"Dispose","d":774175,"h":171799466015,"f":1},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":774175,"h":176094433311,"f":132},{"r":774175,"n":"GetAnonymous","d":774175,"h":180389400607,"f":33},{"r":774175,"n":"GetCurrent","d":774175,"h":184684367903,"f":33},{"r":774175,"p":[{"n":"ifImpersonating","p":262145}],"n":"GetCurrent","o":"@$1","d":774175,"h":188979335199,"f":33},{"r":774175,"p":[{"n":"desiredAccess","p":512031}],"n":"GetCurrent","o":"@$2","d":774175,"h":193274302495,"f":33},{"r":65537,"p":[{"n":"safeAccessTokenHandle","p":118815},{"n":"action","p":11665409}],"n":"RunImpersonated","d":774175,"h":197569269791,"f":33},{"r":133300225,"p":[{"n":"safeAccessTokenHandle","p":118815},{"n":"func","p":$.$spc.System.Func$$($.$spc.System.Threading.Tasks.Task).$h}],"n":"RunImpersonatedAsync","d":774175,"h":201864237087,"f":33},{"r":(T) => $.$spc.System.Threading.Tasks.Task$$(T).$h,"p":[{"n":"safeAccessTokenHandle","p":118815},{"n":"func","p":(T) => $.$spc.System.Func$$($.$spc.System.Threading.Tasks.Task$$(T)).$h}],"g":["T"],"n":"RunImpersonatedAsync","o":"@$1","d":774175,"h":206159204383,"f":131105},{"r":(T) => T.$h,"p":[{"n":"safeAccessTokenHandle","p":118815},{"n":"func","p":(T) => $.$spc.System.Func$$(T).$h}],"g":["T"],"n":"RunImpersonated","o":"@$1","d":774175,"h":210454171679,"f":131105}],"l":[{"t":1310721,"n":"DefaultIssuer","d":774175,"h":4295741471,"f":33}],"c":[{"p":[{"n":"userToken","p":786433}],"n":".ctor","o":"$ctor$17","d":774175,"h":8590708767,"f":1},{"p":[{"n":"userToken","p":786433},{"n":"type","p":1310721}],"n":".ctor","o":"$ctor$18","d":774175,"h":12885676063,"f":1},{"p":[{"n":"userToken","p":786433},{"n":"type","p":1310721},{"n":"acctType","p":643103}],"n":".ctor","o":"$ctor$19","d":774175,"h":17180643359,"f":1},{"p":[{"n":"userToken","p":786433},{"n":"type","p":1310721},{"n":"acctType","p":643103},{"n":"isAuthenticated","p":262145}],"n":".ctor","o":"$ctor$20","d":774175,"h":21475610655,"f":1},{"p":[{"n":"info","p":113967105},{"n":"context","p":114098177}],"n":".ctor","o":"$ctor$21","d":774175,"h":25770577951,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This API supports obsolete formatter-based serialization. It should not be called or extended by application code.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0051","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]},{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]},{"p":[{"n":"identity","p":774175}],"n":".ctor","o":"$ctor$22","d":774175,"h":30065545247,"f":4},{"p":[{"n":"sUserPrincipalName","p":1310721}],"n":".ctor","o":"$ctor$23","d":774175,"h":34360512543,"f":1}],"i":[117047297,57540609,113115137,113377281],"h":774175}; }
            static get $b() { return $.$ssc.System.Security.Claims.ClaimsIdentity; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Security.Principal.IIdentity, $.$spc.System.IDisposable, $.$spc.System.Runtime.Serialization.IDeserializationCallback, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Security.Principal.WindowsIdentity`; }
        });
        
        $asm.$cls("$sspw.System.Security.Principal.IdentityNotMappedException", ($self) => class IdentityNotMappedException extends $.$spc.System.SystemException
        {
            $ctor$9()
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            $ctor$10(/*string?*/ message)
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            $ctor$11(/*string?*/ message, /*System.Exception?*/ inner)
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            /*System.Security.Principal.IdentityReferenceCollection */ get UnmappedIdentities()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetObjectData(/*System.Runtime.Serialization.SerializationInfo*/ serializationInfo, /*System.Runtime.Serialization.StreamingContext*/ streamingContext)
            {
            }
            static $h = 184351;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":119668737,"h":184351}; }
            static get $b() { return $.$spc.System.SystemException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Security.Principal.IdentityNotMappedException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Threading.Thread", "NetJs.System.Security.Claims"))