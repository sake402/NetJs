
(function ($global, $, $$, $sm, $snv, $spu, $sr, $sri, $st) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Text.Encodings.Web", 
    {"h":59813,"f":"System.Text.Encodings.Web","v":"1.0.35.0","a":[{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Beff628fa5ab8bd29ec37e9c13a50148694bea088","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Text.Encodings.Web","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Text.Encodings.Web","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115081217,"c":4410048513,"a":[{"v":"browser1.0","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$stew.System.Text.Encodings.Web.ScalarEscaperBase", ($self) => class ScalarEscaperBase extends $.$$.System.Object
        {
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 1436069;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":655361,"p":[{"n":"value","p":122617857},{"n":"destination","p":$.$$.System.Span$$($.$$.System.Char).$h}],"n":"EncodeUtf16","d":1436069,"h":4296403365,"f":16777480},{"r":655361,"p":[{"n":"value","p":122617857},{"n":"destination","p":$.$$.System.Span$$($.$$.System.Byte).$h}],"n":"EncodeUtf8","d":1436069,"h":8591370661,"f":16777480}],"c":[{"n":".ctor","o":"$ctor$1","d":1436069,"h":12886337957,"f":16777220}],"h":1436069}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Text.Encodings.Web.ScalarEscaperBase`; }
        });
        
        $asm.$cls("$stew.System.Text.Encodings.Web.TextEncoder", ($self) => class TextEncoder extends $.$$.System.Object
        {
            /*int*/ static EncodeStartingOutputBufferSize = 1024;
            /*bool */ TryEncodeUnicodeScalar$1(/*uint*/ unicodeScalar, /*Span<char>*/ buffer, /*out int*/ charsWritten)
            {
                /*fixed*/ 
                {
                    /*char**/ let pBuffer = $.$$.System.Runtime.InteropServices.MemoryMarshal.GetReference$1($.$$.System.Char, buffer);
                    return this.TryEncodeUnicodeScalar((unicodeScalar | 0), pBuffer, buffer.Length, charsWritten);
                }
            }
            /*bool */ TryEncodeUnicodeScalarUtf8(/*uint*/ unicodeScalar, /*Span<char>*/ utf16ScratchBuffer, /*Span<byte>*/ utf8Destination, /*out int*/ bytesWritten)
            {
                /*int*/ let charsWritten;
                if (!this.TryEncodeUnicodeScalar$1(unicodeScalar, utf16ScratchBuffer, $.$ref(() => charsWritten, ($v) => charsWritten = $v, $.$$.System.Int32)))
                {
                    $.$stew.System.Text.Encodings.Web.TextEncoder.ThrowArgumentException_MaxOutputCharsPerInputChar();
                }
                utf16ScratchBuffer = utf16ScratchBuffer.Slice(0, charsWritten);
                /*int*/ let dstIdx = 0;
                while(!utf16ScratchBuffer.IsEmpty)
                {
                    /*Rune*/ let nextScalarValue;
                    /*int*/ let scalarUtf16CodeUnitCount;
                    if ($.$$.System.Text.Rune.DecodeFromUtf16($.$$.System.Span$$($.$$.System.Char).op_Implicit(utf16ScratchBuffer), $.$ref(() => nextScalarValue, ($v) => nextScalarValue = $v, $.$$.System.Text.Rune), $.$ref(() => scalarUtf16CodeUnitCount, ($v) => scalarUtf16CodeUnitCount = $v, $.$$.System.Int32)) !== 0/*OperationStatus.Done*/)
                    {
                        $.$stew.System.Text.Encodings.Web.TextEncoder.ThrowArgumentException_MaxOutputCharsPerInputChar();
                    }
                    /*uint*/ let utf8lsb = ($.$stew.System.Text.Unicode.UnicodeHelpers.GetUtf8RepresentationForScalarValue((nextScalarValue.Value >>> 0)) >>> 0);
                    do
                    {
                        if ((utf8Destination.Length >>> 0) > (dstIdx >>> 0))
                        {
                            utf8Destination.get_Item(dstIdx++).$v = $.$cast(utf8lsb, $.$$.System.Byte);
                        }
                        else 
                        {
                            bytesWritten.$v = 0;
                            return false;
                        }
                    }
                    while((utf8lsb >>= 8) !== 0);
                    utf16ScratchBuffer = utf16ScratchBuffer.Slice$1(scalarUtf16CodeUnitCount);
                }
                bytesWritten.$v = dstIdx;
                return true;
            }
            /*string */ Encode$4(/*string*/ value)
            {
                if (value === null)
                {
                    $.$stew.System.Text.Encodings.Web.ThrowHelper.ThrowArgumentNullException(0/*ExceptionArgument.value*/);
                }
                /*int*/ let indexOfFirstCharToEncode = this.FindFirstCharacterToEncode$1($.$$.System.MemoryExtensions.AsSpan$4(value));
                if (indexOfFirstCharToEncode < 0)
                {
                    return value;
                }
                return this.EncodeToNewString($.$$.System.MemoryExtensions.AsSpan$4(value), indexOfFirstCharToEncode);
            }
            /*string */ EncodeToNewString(/*ReadOnlySpan<char>*/ value, /*int*/ indexOfFirstCharToEncode)
            {
                /*ReadOnlySpan<char>*/ let remainingInput = value.Slice$1(indexOfFirstCharToEncode);
                /*ValueStringBuilder*/ let stringBuilder = new $.$stew.System.Text.ValueStringBuilder().$ctor$4($.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Char, 1024/*EncodeStartingOutputBufferSize*/, null));
                /*int*/ let minBufferBumpEachIteration = $.$$.System.Math.Max$4(this.MaxOutputCharactersPerInputCharacter, 1024/*EncodeStartingOutputBufferSize*/);
                do
                {
                    /*Span<char>*/ let destBuffer = stringBuilder.AppendSpan($.$$.System.Math.Max$4(remainingInput.Length, minBufferBumpEachIteration));
                    /*int*/ let charsConsumedJustNow;
                    /*int*/ let charsWrittenJustNow;
                    this.EncodeCore$1(remainingInput, destBuffer, $.$ref(() => charsConsumedJustNow, ($v) => charsConsumedJustNow = $v, $.$$.System.Int32), $.$ref(() => charsWrittenJustNow, ($v) => charsWrittenJustNow = $v, $.$$.System.Int32), true);
                    if (charsWrittenJustNow === 0 || (charsWrittenJustNow >>> 0) > (destBuffer.Length >>> 0))
                    {
                        $.$stew.System.Text.Encodings.Web.TextEncoder.ThrowArgumentException_MaxOutputCharsPerInputChar();
                    }
                    remainingInput = remainingInput.Slice$1(charsConsumedJustNow);
                    stringBuilder.Length -= ((destBuffer.Length - charsWrittenJustNow) | 0);
                }
                while(!remainingInput.IsEmpty);
                /*string*/ let retVal = $.$$.System.String.Concat$8(value.Slice(0, indexOfFirstCharToEncode), stringBuilder.AsSpan());
                stringBuilder.Dispose();
                return retVal;
            }
            /*void */ Encode$2(/*TextWriter*/ output, /*string*/ value)
            {
                this.Encode$1(output, value, 0, value.length);
            }
            /*void */ Encode$1(/*TextWriter*/ output, /*string*/ value, /*int*/ startIndex, /*int*/ characterCount)
            {
                if (output === null)
                {
                    $.$stew.System.Text.Encodings.Web.ThrowHelper.ThrowArgumentNullException(2/*ExceptionArgument.output*/);
                }
                if (value === null)
                {
                    $.$stew.System.Text.Encodings.Web.ThrowHelper.ThrowArgumentNullException(0/*ExceptionArgument.value*/);
                }
                $.$stew.System.Text.Encodings.Web.TextEncoder.ValidateRanges(startIndex, characterCount, value.length);
                /*int*/ let indexOfFirstCharToEncode = this.FindFirstCharacterToEncode$1($.$$.System.MemoryExtensions.AsSpan$1(value, startIndex, characterCount));
                if (indexOfFirstCharToEncode < 0)
                {
                    indexOfFirstCharToEncode = characterCount;
                }
                $.$stew.System.IO.TextWriterExtensions.WritePartialString(output, value, startIndex, indexOfFirstCharToEncode);
                if (indexOfFirstCharToEncode !== characterCount)
                {
                    this.EncodeCore(output, $.$$.System.MemoryExtensions.AsSpan$1(value, ((startIndex + indexOfFirstCharToEncode) | 0), ((characterCount - indexOfFirstCharToEncode) | 0)));
                }
            }
            /*void */ Encode(/*TextWriter*/ output, /*char[]*/ value, /*int*/ startIndex, /*int*/ characterCount)
            {
                if (output === null)
                {
                    $.$stew.System.Text.Encodings.Web.ThrowHelper.ThrowArgumentNullException(2/*ExceptionArgument.output*/);
                }
                if (value === null)
                {
                    $.$stew.System.Text.Encodings.Web.ThrowHelper.ThrowArgumentNullException(0/*ExceptionArgument.value*/);
                }
                $.$stew.System.Text.Encodings.Web.TextEncoder.ValidateRanges(startIndex, characterCount, value.length);
                /*int*/ let indexOfFirstCharToEncode = this.FindFirstCharacterToEncode$1($.$$.System.Span$$($.$$.System.Char).op_Implicit($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Char, value, startIndex, characterCount)));
                if (indexOfFirstCharToEncode < 0)
                {
                    indexOfFirstCharToEncode = characterCount;
                }
                output.Write$2(value, startIndex, indexOfFirstCharToEncode);
                if (indexOfFirstCharToEncode !== characterCount)
                {
                    this.EncodeCore(output, $.$$.System.Span$$($.$$.System.Char).op_Implicit($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Char, value, ((startIndex + indexOfFirstCharToEncode) | 0), ((characterCount - indexOfFirstCharToEncode) | 0))));
                }
            }
            /*OperationStatus */ EncodeUtf8(/*ReadOnlySpan<byte>*/ utf8Source, /*Span<byte>*/ utf8Destination, /*out int*/ bytesConsumed, /*out int*/ bytesWritten, /*bool*/ isFinalBlock)
            {
                /*ReadOnlySpan<byte>*/ let sourceSearchSpace = utf8Source;
                if (utf8Destination.Length < utf8Source.Length)
                {
                    sourceSearchSpace = utf8Source.Slice(0, utf8Destination.Length);
                }
                /*int*/ let idxOfFirstByteToEncode = this.FindFirstCharacterToEncodeUtf8(sourceSearchSpace);
                if (idxOfFirstByteToEncode < 0)
                {
                    idxOfFirstByteToEncode = sourceSearchSpace.Length;
                }
                utf8Source.Slice(0, idxOfFirstByteToEncode).CopyTo(utf8Destination);
                if (idxOfFirstByteToEncode === utf8Source.Length)
                {
                    bytesConsumed.$v = utf8Source.Length;
                    bytesWritten.$v = utf8Source.Length;
                    return 0/*OperationStatus.Done*/;
                }
                /*int*/ let innerBytesConsumed;
                /*int*/ let innerBytesWritten;
                /*OperationStatus*/ let status = this.EncodeUtf8Core(utf8Source.Slice$1(idxOfFirstByteToEncode), utf8Destination.Slice$1(idxOfFirstByteToEncode), $.$ref(() => innerBytesConsumed, ($v) => innerBytesConsumed = $v, $.$$.System.Int32), $.$ref(() => innerBytesWritten, ($v) => innerBytesWritten = $v, $.$$.System.Int32), isFinalBlock);
                bytesConsumed.$v = ((idxOfFirstByteToEncode + innerBytesConsumed) | 0);
                bytesWritten.$v = ((idxOfFirstByteToEncode + innerBytesWritten) | 0);
                return status;
            }
            /*OperationStatus */ EncodeUtf8Core(/*ReadOnlySpan<byte>*/ utf8Source, /*Span<byte>*/ utf8Destination, /*out int*/ bytesConsumed, /*out int*/ bytesWritten, /*bool*/ isFinalBlock)
            {
                /*int*/ let originalUtf8SourceLength;
                /*int*/ let originalUtf8DestinationLength;
                /*int*/ let TempUtf16CharBufferLength;
                /*Span<char>*/ let utf16ScratchBuffer;
                /*OperationStatus*/ let retVal;
                let $gotoJumpState1 = 0;
                $gotoJumpStart1: while(true)
                {
                    switch($gotoJumpState1)
                    {
                        case 0:
                        {
                            originalUtf8SourceLength = utf8Source.Length;
                            originalUtf8DestinationLength = utf8Destination.Length;
                            TempUtf16CharBufferLength = 24;
                            utf16ScratchBuffer = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Char, TempUtf16CharBufferLength, null);
                            $whileJumpStart2: while(!utf8Source.IsEmpty)
                            {
                                /*OperationStatus*/ let opStatus;
                                let $gotoJumpState3 = 0;
                                $gotoJumpStart3: while(true)
                                {
                                    switch($gotoJumpState3)
                                    {
                                        case 0:
                                        {
                                            /*Rune*/ let scalarValue;
                                            /*int*/ let bytesConsumedJustNow;
                                            opStatus = $.$$.System.Text.Rune.DecodeFromUtf8(utf8Source, $.$ref(() => scalarValue, ($v) => scalarValue = $v, $.$$.System.Text.Rune), $.$ref(() => bytesConsumedJustNow, ($v) => bytesConsumedJustNow = $v, $.$$.System.Int32));
                                            if (opStatus !== 0/*OperationStatus.Done*/)
                                            {
                                                if (!isFinalBlock && opStatus === 2/*OperationStatus.NeedMoreData*/)
                                                {
                                                    $gotoJumpState1 = 2; /*goto NeedMoreData*/
                                                    continue $gotoJumpStart1;
                                                }
                                                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Text.Rune.op_Equality(scalarValue, $.$$.System.Text.Rune.ReplacementChar), "scalarValue == Rune.ReplacementChar");
                                                $gotoJumpState3 = 1; /*goto MustEncode*/
                                                continue $gotoJumpStart3;
                                            }
                                            if (!this.WillEncode(scalarValue.Value))
                                            {
                                                /*uint*/ let utf8lsb = ($.$stew.System.Text.Unicode.UnicodeHelpers.GetUtf8RepresentationForScalarValue((scalarValue.Value >>> 0)) >>> 0);
                                                /*int*/ let dstIdxTemp = 0;
                                                do
                                                {
                                                    if ((dstIdxTemp >>> 0) >= (utf8Destination.Length >>> 0))
                                                    {
                                                        $gotoJumpState1 = 3; /*goto DestinationTooSmall*/
                                                        continue $gotoJumpStart1;
                                                    }
                                                    utf8Destination.get_Item(dstIdxTemp++).$v = $.$cast(utf8lsb, $.$$.System.Byte);
                                                }
                                                while((utf8lsb >>= 8) !== 0);
                                                utf8Source = utf8Source.Slice$1(bytesConsumedJustNow);
                                                utf8Destination = utf8Destination.Slice$1(dstIdxTemp);
                                                continue $whileJumpStart2;
                                            }
                                        }
                                        case 1: /*MustEncode*/
                                        /*int*/ let bytesWrittenJustNow;
                                        if (!this.TryEncodeUnicodeScalarUtf8((scalarValue.Value >>> 0), utf16ScratchBuffer, utf8Destination, $.$ref(() => bytesWrittenJustNow, ($v) => bytesWrittenJustNow = $v, $.$$.System.Int32)))
                                        {
                                            $gotoJumpState1 = 3; /*goto DestinationTooSmall*/
                                            continue $gotoJumpStart1;
                                        }
                                        utf8Source = utf8Source.Slice$1(bytesConsumedJustNow);
                                        utf8Destination = utf8Destination.Slice$1(bytesWrittenJustNow);
                                    }
                                    break;
                                }
                            }
                            retVal = 0/*OperationStatus.Done*/;
                        }
                        case 1: /*ReturnCommon*/
                        bytesConsumed.$v = ((originalUtf8SourceLength - utf8Source.Length) | 0);
                        bytesWritten.$v = ((originalUtf8DestinationLength - utf8Destination.Length) | 0);
                        return retVal;
                        case 2: /*NeedMoreData*/
                        retVal = 2/*OperationStatus.NeedMoreData*/;
                        $gotoJumpState1 = 1; /*goto ReturnCommon*/
                        continue $gotoJumpStart1;
                        case 3: /*DestinationTooSmall*/
                        retVal = 1/*OperationStatus.DestinationTooSmall*/;
                        $gotoJumpState1 = 1; /*goto ReturnCommon*/
                        continue $gotoJumpStart1;
                    }
                    break;
                }
            }
            /*OperationStatus */ Encode$3(/*ReadOnlySpan<char>*/ source, /*Span<char>*/ destination, /*out int*/ charsConsumed, /*out int*/ charsWritten, /*bool*/ isFinalBlock)
            {
                /*ReadOnlySpan<char>*/ let sourceSearchSpace = source;
                if (destination.Length < source.Length)
                {
                    sourceSearchSpace = source.Slice(0, destination.Length);
                }
                /*int*/ let idxOfFirstCharToEncode = this.FindFirstCharacterToEncode$1(sourceSearchSpace);
                if (idxOfFirstCharToEncode < 0)
                {
                    idxOfFirstCharToEncode = sourceSearchSpace.Length;
                }
                source.Slice(0, idxOfFirstCharToEncode).CopyTo(destination);
                if (idxOfFirstCharToEncode === source.Length)
                {
                    charsConsumed.$v = source.Length;
                    charsWritten.$v = source.Length;
                    return 0/*OperationStatus.Done*/;
                }
                /*int*/ let innerCharsConsumed;
                /*int*/ let innerCharsWritten;
                /*OperationStatus*/ let status = this.EncodeCore$1(source.Slice$1(idxOfFirstCharToEncode), destination.Slice$1(idxOfFirstCharToEncode), $.$ref(() => innerCharsConsumed, ($v) => innerCharsConsumed = $v, $.$$.System.Int32), $.$ref(() => innerCharsWritten, ($v) => innerCharsWritten = $v, $.$$.System.Int32), isFinalBlock);
                charsConsumed.$v = ((idxOfFirstCharToEncode + innerCharsConsumed) | 0);
                charsWritten.$v = ((idxOfFirstCharToEncode + innerCharsWritten) | 0);
                return status;
            }
            /*OperationStatus */ EncodeCore$1(/*ReadOnlySpan<char>*/ source, /*Span<char>*/ destination, /*out int*/ charsConsumed, /*out int*/ charsWritten, /*bool*/ isFinalBlock)
            {
                /*int*/ let originalSourceLength;
                /*int*/ let originalDestinationLength;
                /*OperationStatus*/ let retVal;
                let $gotoJumpState1 = 0;
                $gotoJumpStart1: while(true)
                {
                    switch($gotoJumpState1)
                    {
                        case 0:
                        {
                            originalSourceLength = source.Length;
                            originalDestinationLength = destination.Length;
                            $whileJumpStart2: while(!source.IsEmpty)
                            {
                                /*OperationStatus*/ let status;
                                let $gotoJumpState3 = 0;
                                $gotoJumpStart3: while(true)
                                {
                                    switch($gotoJumpState3)
                                    {
                                        case 0:
                                        {
                                            /*Rune*/ let scalarValue;
                                            /*int*/ let charsConsumedJustNow;
                                            status = $.$$.System.Text.Rune.DecodeFromUtf16(source, $.$ref(() => scalarValue, ($v) => scalarValue = $v, $.$$.System.Text.Rune), $.$ref(() => charsConsumedJustNow, ($v) => charsConsumedJustNow = $v, $.$$.System.Int32));
                                            if (status !== 0/*OperationStatus.Done*/)
                                            {
                                                if (!isFinalBlock && status === 2/*OperationStatus.NeedMoreData*/)
                                                {
                                                    $gotoJumpState1 = 2; /*goto NeedMoreData*/
                                                    continue $gotoJumpStart1;
                                                }
                                                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Text.Rune.op_Equality(scalarValue, $.$$.System.Text.Rune.ReplacementChar), "scalarValue == Rune.ReplacementChar");
                                                $gotoJumpState3 = 1; /*goto MustEncode*/
                                                continue $gotoJumpStart3;
                                            }
                                            if (!this.WillEncode(scalarValue.Value))
                                            {
                                                if (!scalarValue.TryEncodeToUtf16(destination, $.$discardRef()))
                                                {
                                                    $gotoJumpState1 = 3; /*goto DestinationTooSmall*/
                                                    continue $gotoJumpStart1;
                                                }
                                                source = source.Slice$1(charsConsumedJustNow);
                                                destination = destination.Slice$1(charsConsumedJustNow);
                                                continue $whileJumpStart2;
                                            }
                                        }
                                        case 1: /*MustEncode*/
                                        /*int*/ let charsWrittenJustNow;
                                        if (!this.TryEncodeUnicodeScalar$1((scalarValue.Value >>> 0), destination, $.$ref(() => charsWrittenJustNow, ($v) => charsWrittenJustNow = $v, $.$$.System.Int32)))
                                        {
                                            $gotoJumpState1 = 3; /*goto DestinationTooSmall*/
                                            continue $gotoJumpStart1;
                                        }
                                        source = source.Slice$1(charsConsumedJustNow);
                                        destination = destination.Slice$1(charsWrittenJustNow);
                                    }
                                    break;
                                }
                            }
                            retVal = 0/*OperationStatus.Done*/;
                        }
                        case 1: /*ReturnCommon*/
                        charsConsumed.$v = ((originalSourceLength - source.Length) | 0);
                        charsWritten.$v = ((originalDestinationLength - destination.Length) | 0);
                        return retVal;
                        case 2: /*NeedMoreData*/
                        retVal = 2/*OperationStatus.NeedMoreData*/;
                        $gotoJumpState1 = 1; /*goto ReturnCommon*/
                        continue $gotoJumpStart1;
                        case 3: /*DestinationTooSmall*/
                        retVal = 1/*OperationStatus.DestinationTooSmall*/;
                        $gotoJumpState1 = 1; /*goto ReturnCommon*/
                        continue $gotoJumpStart1;
                    }
                    break;
                }
            }
            /*void */ EncodeCore(/*TextWriter*/ output, /*ReadOnlySpan<char>*/ value)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(output !== null, "output != null");
                $.$$.System.Diagnostics.Debug.Assert$2(!value.IsEmpty, "Caller should've special-cased 'no encoding needed'.");
                /*int*/ let minBufferBumpEachIteration = $.$$.System.Math.Max$4(this.MaxOutputCharactersPerInputCharacter, 1024/*EncodeStartingOutputBufferSize*/);
                /*char[]*/ let rentedArray = $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared.Rent($.$$.System.Math.Max$4(value.Length, minBufferBumpEachIteration));
                /*Span<char>*/ let scratchBuffer = $.$$.System.Span$$($.$$.System.Char).op_Implicit$2(rentedArray);
                do
                {
                    /*int*/ let charsConsumedJustNow;
                    /*int*/ let charsWrittenJustNow;
                    this.EncodeCore$1(value, scratchBuffer, $.$ref(() => charsConsumedJustNow, ($v) => charsConsumedJustNow = $v, $.$$.System.Int32), $.$ref(() => charsWrittenJustNow, ($v) => charsWrittenJustNow = $v, $.$$.System.Int32), true);
                    if (charsWrittenJustNow === 0 || (charsWrittenJustNow >>> 0) > (scratchBuffer.Length >>> 0))
                    {
                        $.$stew.System.Text.Encodings.Web.TextEncoder.ThrowArgumentException_MaxOutputCharsPerInputChar();
                    }
                    output.Write$2(rentedArray, 0, charsWrittenJustNow);
                    value = value.Slice$1(charsConsumedJustNow);
                }
                while(!value.IsEmpty);
                $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared.Return(rentedArray, false);
            }
            /*int */ FindFirstCharacterToEncode$1(/*ReadOnlySpan<char>*/ text)
            {
                /*fixed*/ 
                {
                    /*char**/ let pText = $.$$.System.Runtime.InteropServices.MemoryMarshal.GetReference($.$$.System.Char, text);
                    return this.FindFirstCharacterToEncode(pText, text.Length);
                }
            }
            /*int */ FindFirstCharacterToEncodeUtf8(/*ReadOnlySpan<byte>*/ utf8Text)
            {
                /*int*/ let utf8TextOriginalLength = utf8Text.Length;
                while(!utf8Text.IsEmpty)
                {
                    /*Rune*/ let scalarValue;
                    /*int*/ let bytesConsumed;
                    /*OperationStatus*/ let opStatus = $.$$.System.Text.Rune.DecodeFromUtf8(utf8Text, $.$ref(() => scalarValue, ($v) => scalarValue = $v, $.$$.System.Text.Rune), $.$ref(() => bytesConsumed, ($v) => bytesConsumed = $v, $.$$.System.Int32));
                    if (opStatus !== 0/*OperationStatus.Done*/ || this.WillEncode(scalarValue.Value))
                    {
                        break;
                    }
                    utf8Text = utf8Text.Slice$1(bytesConsumed);
                }
                return (utf8Text.IsEmpty) ? -1 : ((utf8TextOriginalLength - utf8Text.Length) | 0);
            }
            static /*bool */ TryCopyCharacters(/*string*/ source, /*Span<char>*/ destination, /*out int*/ numberOfCharactersWritten)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(!$.$$.System.String.IsNullOrEmpty(source), "!string.IsNullOrEmpty(source)");
                if (destination.Length < source.length)
                {
                    numberOfCharactersWritten.$v = 0;
                    return false;
                }
                for(/*int*/ let i = 0; i < source.length; i++)
                {
                    destination.get_Item(i).$v = $.$$.System.String.get_Chars.call(source, i);
                }
                numberOfCharactersWritten.$v = source.length;
                return true;
            }
            static /*bool */ TryWriteScalarAsChar(/*int*/ unicodeScalar, /*Span<char>*/ destination, /*out int*/ numberOfCharactersWritten)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(unicodeScalar < 65535/*ushort.MaxValue*/, "unicodeScalar < ushort.MaxValue");
                if (destination.IsEmpty)
                {
                    numberOfCharactersWritten.$v = 0;
                    return false;
                }
                destination.get_Item(0).$v = $.$cast(unicodeScalar, $.$$.System.Char);
                numberOfCharactersWritten.$v = 1;
                return true;
            }
            static /*void */ ValidateRanges(/*int*/ startIndex, /*int*/ characterCount, /*int*/ actualInputLength)
            {
                if (startIndex < 0 || startIndex > actualInputLength)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("startIndex");
                }
                if (characterCount < 0 || characterCount > (((actualInputLength - startIndex) | 0)))
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("characterCount");
                }
            }
            static /*void */ ThrowArgumentException_MaxOutputCharsPerInputChar()
            {
                throw new $.$$.System.ArgumentException().$ctor$14($.$stew.System.SR.TextEncoderDoesNotImplementMaxOutputCharsPerInputChar);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 1501605;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":34361239973,"f":50331905},"n":"MaxOutputCharactersPerInputCharacter","d":1501605,"h":30066272677,"f":2097409,"a":[{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]}]}],"m":[{"r":262145,"p":[{"n":"unicodeScalar","p":655361},{"n":"buffer","p":$.$typePointer($.$$.System.Char).$h},{"n":"bufferLength","p":655361},{"n":"numberOfCharactersWritten","p":655361,"f":2}],"n":"TryEncodeUnicodeScalar","d":1501605,"h":8591436197,"f":16777473,"a":[{"t":23527425,"c":8613462017,"a":[{"v":false,"t":262145}]},{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]}]},{"r":262145,"p":[{"n":"unicodeScalar","p":720897},{"n":"buffer","p":$.$$.System.Span$$($.$$.System.Char).$h},{"n":"charsWritten","p":655361,"f":2}],"n":"TryEncodeUnicodeScalar","o":"@$1","d":1501605,"h":12886403493,"f":16777218},{"r":262145,"p":[{"n":"unicodeScalar","p":720897},{"n":"utf16ScratchBuffer","p":$.$$.System.Span$$($.$$.System.Char).$h},{"n":"utf8Destination","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"bytesWritten","p":655361,"f":2}],"n":"TryEncodeUnicodeScalarUtf8","d":1501605,"h":17181370789,"f":16777218},{"r":655361,"p":[{"n":"text","p":$.$typePointer($.$$.System.Char).$h},{"n":"textLength","p":655361}],"n":"FindFirstCharacterToEncode","d":1501605,"h":21476338085,"f":16777473,"a":[{"t":23527425,"c":8613462017,"a":[{"v":false,"t":262145}]},{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]}]},{"r":262145,"p":[{"n":"unicodeScalar","p":655361}],"n":"WillEncode","d":1501605,"h":25771305381,"f":16777473,"a":[{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]}]},{"r":1310721,"p":[{"n":"value","p":1310721}],"n":"Encode","o":"@$4","d":1501605,"h":38656207269,"f":16777345},{"r":1310721,"p":[{"n":"value","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h},{"n":"indexOfFirstCharToEncode","p":655361}],"n":"EncodeToNewString","d":1501605,"h":42951174565,"f":16777218},{"r":65537,"p":[{"n":"output","p":63045633},{"n":"value","p":1310721}],"n":"Encode","o":"@$2","d":1501605,"h":47246141861,"f":16777217},{"r":65537,"p":[{"n":"output","p":63045633},{"n":"value","p":1310721},{"n":"startIndex","p":655361},{"n":"characterCount","p":655361}],"n":"Encode","o":"@$1","d":1501605,"h":51541109157,"f":16777345},{"r":65537,"p":[{"n":"output","p":63045633},{"n":"value","p":$.$typeArray($.$$.System.Char).$h},{"n":"startIndex","p":655361},{"n":"characterCount","p":655361}],"n":"Encode","d":1501605,"h":55836076453,"f":16777345},{"r":18743297,"p":[{"n":"utf8Source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"utf8Destination","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"bytesConsumed","p":655361,"f":2},{"n":"bytesWritten","p":655361,"f":2},{"n":"isFinalBlock","p":262145,"f":65,"v":true}],"n":"EncodeUtf8","d":1501605,"h":60131043749,"f":16777345},{"r":18743297,"p":[{"n":"utf8Source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"utf8Destination","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"bytesConsumed","p":655361,"f":2},{"n":"bytesWritten","p":655361,"f":2},{"n":"isFinalBlock","p":262145}],"n":"EncodeUtf8Core","d":1501605,"h":64426011045,"f":16777344},{"r":18743297,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h},{"n":"destination","p":$.$$.System.Span$$($.$$.System.Char).$h},{"n":"charsConsumed","p":655361,"f":2},{"n":"charsWritten","p":655361,"f":2},{"n":"isFinalBlock","p":262145,"f":65,"v":true}],"n":"Encode","o":"@$3","d":1501605,"h":68720978341,"f":16777345},{"r":18743297,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h},{"n":"destination","p":$.$$.System.Span$$($.$$.System.Char).$h},{"n":"charsConsumed","p":655361,"f":2},{"n":"charsWritten","p":655361,"f":2},{"n":"isFinalBlock","p":262145}],"n":"EncodeCore","o":"@$1","d":1501605,"h":73015945637,"f":16777344},{"r":65537,"p":[{"n":"output","p":63045633},{"n":"value","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h}],"n":"EncodeCore","d":1501605,"h":77310912933,"f":16777218},{"r":655361,"p":[{"n":"text","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h}],"n":"FindFirstCharacterToEncode","o":"@$1","d":1501605,"h":81605880229,"f":16777344},{"r":655361,"p":[{"n":"utf8Text","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h}],"n":"FindFirstCharacterToEncodeUtf8","d":1501605,"h":85900847525,"f":16777345,"a":[{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]}]},{"r":262145,"p":[{"n":"source","p":1310721},{"n":"destination","p":$.$$.System.Span$$($.$$.System.Char).$h},{"n":"numberOfCharactersWritten","p":655361,"f":2}],"n":"TryCopyCharacters","d":1501605,"h":90195814821,"f":16777256},{"r":262145,"p":[{"n":"unicodeScalar","p":655361},{"n":"destination","p":$.$$.System.Span$$($.$$.System.Char).$h},{"n":"numberOfCharactersWritten","p":655361,"f":2}],"n":"TryWriteScalarAsChar","d":1501605,"h":94490782117,"f":16777256},{"r":65537,"p":[{"n":"startIndex","p":655361},{"n":"characterCount","p":655361},{"n":"actualInputLength","p":655361}],"n":"ValidateRanges","d":1501605,"h":98785749413,"f":16777250},{"r":65537,"n":"ThrowArgumentException_MaxOutputCharsPerInputChar","d":1501605,"h":103080716709,"f":16777250}],"l":[{"t":655361,"n":"EncodeStartingOutputBufferSize","d":1501605,"h":4296468901,"f":4194338}],"c":[{"n":".ctor","o":"$ctor$1","d":1501605,"h":107375684005,"f":16777220}],"h":1501605}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Text.Encodings.Web.TextEncoder`; }
        });
        
        $asm.$cls("$stew.System.Text.Encodings.Web.HtmlEncoder", ($self) => class HtmlEncoder extends $.$stew.System.Text.Encodings.Web.TextEncoder
        {
            static /*HtmlEncoder */ get Default()
            {
                return $.$stew.System.Text.Encodings.Web.DefaultHtmlEncoder.BasicLatinSingleton;
            }
            static /*HtmlEncoder */ Create(/*TextEncoderSettings*/ settings)
            {
                return new $.$stew.System.Text.Encodings.Web.DefaultHtmlEncoder().$ctor$3(settings);
            }
            static /*HtmlEncoder */ Create$1(/*params UnicodeRange[]*/ allowedRanges)
            {
                return new $.$stew.System.Text.Encodings.Web.DefaultHtmlEncoder().$ctor$3(new $.$stew.System.Text.Encodings.Web.TextEncoderSettings().$ctor$3(allowedRanges));
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 1173925;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1501605,"p":[{"p":1173925,"g":{"r":0,"d":0,"h":8591108517,"f":50331681},"n":"Default","d":1173925,"h":4296141221,"f":2097185}],"m":[{"r":1173925,"p":[{"n":"settings","p":1567141}],"n":"Create","d":1173925,"h":12886075813,"f":16777249},{"r":1173925,"p":[{"n":"allowedRanges","p":$.$typeArray($.$stew.System.Text.Unicode.UnicodeRange).$h,"f":16}],"n":"Create","o":"@$1","d":1173925,"h":17181043109,"f":16777249}],"c":[{"n":".ctor","o":"$ctor$2","d":1173925,"h":21476010405,"f":16777220}],"h":1173925}; }
            static get $b() { return $.$stew.System.Text.Encodings.Web.TextEncoder; }
            static get $fullName() { return `System.Text.Encodings.Web.HtmlEncoder`; }
        });
        
        $asm.$cls("$stew.System.Text.Encodings.Web.JavaScriptEncoder", ($self) => class JavaScriptEncoder extends $.$stew.System.Text.Encodings.Web.TextEncoder
        {
            static /*JavaScriptEncoder */ get Default()
            {
                return $.$stew.System.Text.Encodings.Web.DefaultJavaScriptEncoder.BasicLatinSingleton;
            }
            static /*JavaScriptEncoder */ get UnsafeRelaxedJsonEscaping()
            {
                return $.$stew.System.Text.Encodings.Web.DefaultJavaScriptEncoder.UnsafeRelaxedEscapingSingleton;
            }
            static /*JavaScriptEncoder */ Create(/*TextEncoderSettings*/ settings)
            {
                return new $.$stew.System.Text.Encodings.Web.DefaultJavaScriptEncoder().$ctor$4(settings);
            }
            static /*JavaScriptEncoder */ Create$1(/*params UnicodeRange[]*/ allowedRanges)
            {
                return new $.$stew.System.Text.Encodings.Web.DefaultJavaScriptEncoder().$ctor$4(new $.$stew.System.Text.Encodings.Web.TextEncoderSettings().$ctor$3(allowedRanges));
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 1239461;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1501605,"p":[{"p":1239461,"g":{"r":0,"d":0,"h":8591174053,"f":50331681},"n":"Default","d":1239461,"h":4296206757,"f":2097185},{"p":1239461,"g":{"r":0,"d":0,"h":17181108645,"f":50331681},"n":"UnsafeRelaxedJsonEscaping","d":1239461,"h":12886141349,"f":2097185}],"m":[{"r":1239461,"p":[{"n":"settings","p":1567141}],"n":"Create","d":1239461,"h":21476075941,"f":16777249},{"r":1239461,"p":[{"n":"allowedRanges","p":$.$typeArray($.$stew.System.Text.Unicode.UnicodeRange).$h,"f":16}],"n":"Create","o":"@$1","d":1239461,"h":25771043237,"f":16777249}],"c":[{"n":".ctor","o":"$ctor$2","d":1239461,"h":30066010533,"f":16777220}],"h":1239461}; }
            static get $b() { return $.$stew.System.Text.Encodings.Web.TextEncoder; }
            static get $fullName() { return `System.Text.Encodings.Web.JavaScriptEncoder`; }
        });
        
        $asm.$cls("$stew.System.Text.Encodings.Web.UrlEncoder", ($self) => class UrlEncoder extends $.$stew.System.Text.Encodings.Web.TextEncoder
        {
            static /*UrlEncoder */ get Default()
            {
                return $.$stew.System.Text.Encodings.Web.DefaultUrlEncoder.BasicLatinSingleton;
            }
            static /*UrlEncoder */ Create(/*TextEncoderSettings*/ settings)
            {
                return new $.$stew.System.Text.Encodings.Web.DefaultUrlEncoder().$ctor$3(settings);
            }
            static /*UrlEncoder */ Create$1(/*params UnicodeRange[]*/ allowedRanges)
            {
                return new $.$stew.System.Text.Encodings.Web.DefaultUrlEncoder().$ctor$3(new $.$stew.System.Text.Encodings.Web.TextEncoderSettings().$ctor$3(allowedRanges));
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 1698213;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1501605,"p":[{"p":1698213,"g":{"r":0,"d":0,"h":8591632805,"f":50331681},"n":"Default","d":1698213,"h":4296665509,"f":2097185}],"m":[{"r":1698213,"p":[{"n":"settings","p":1567141}],"n":"Create","d":1698213,"h":12886600101,"f":16777249},{"r":1698213,"p":[{"n":"allowedRanges","p":$.$typeArray($.$stew.System.Text.Unicode.UnicodeRange).$h,"f":16}],"n":"Create","o":"@$1","d":1698213,"h":17181567397,"f":16777249}],"c":[{"n":".ctor","o":"$ctor$2","d":1698213,"h":21476534693,"f":16777220}],"h":1698213}; }
            static get $b() { return $.$stew.System.Text.Encodings.Web.TextEncoder; }
            static get $fullName() { return `System.Text.Encodings.Web.UrlEncoder`; }
        });
        
        $asm.$cls("$stew.System.IO.TextWriterExtensions", ($self) => class TextWriterExtensions
        {
            static /*void */ WritePartialString(/*this TextWriter*/ writer, /*string*/ value, /*int*/ offset, /*int*/ count)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(writer !== null, "writer != null");
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.String.op_Inequality(value, null), "value != null");
                if (offset === 0 && count === value.length)
                {
                    writer.Write$16(value);
                }
                else 
                {
                    /*ReadOnlySpan<char>*/ let sliced = $.$$.System.MemoryExtensions.AsSpan$1(value, offset, count);
                    writer.Write$9(sliced);
                }
            }
            static $h = 453029;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"writer","p":63045633},{"n":"value","p":1310721},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"WritePartialString","d":453029,"h":4295420325,"f":16777249}],"h":453029}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.IO.TextWriterExtensions`; }
        });
        
        $asm.$cls("$stew.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$$.System.Object.ReferenceEquals($.$stew.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("System.Text.Encodings.Web", $.$stew.System.SR.$type.Assembly);
                    $.$stew.System.SR.s_resourceManager = temp;
                }
                return $.$stew.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$stew.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$stew.System.SR.resourceCulture = value;
            }
            static /*string */ get ArgumentOutOfRange_IndexMustBeLess()
            {
                return "Index was out of range. Must be non-negative and less than the size of the collection.";
            }
            static /*string */ get Argument_CannotExtractScalar()
            {
                return "Cannot extract a Unicode scalar value from the specified index in the input.";
            }
            static /*string */ get Argument_DestinationTooShort()
            {
                return "Destination is too short.";
            }
            static /*string */ get Arg_MustBeRune()
            {
                return "Object must be of type Rune.";
            }
            static /*string */ get TextEncoderDoesNotImplementMaxOutputCharsPerInputChar()
            {
                return "TextEncoder does not implement MaxOutputCharsPerInputChar correctly.";
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$stew.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                if ($.$stew.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$stew.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$stew.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$stew.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$stew.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$stew.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$stew.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$stew.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$stew.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$stew.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$stew.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$stew.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 518565;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":518565}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$stew.System.Text.Encodings.Web.OptimizedInboxTextEncoder", ($self) => class OptimizedInboxTextEncoder extends $.$$.System.Object
        {
            static $_AsciiPreescapedData;
            static get AsciiPreescapedData()
            {
                let $cls = $.$stew.System.Text.Encodings.Web.OptimizedInboxTextEncoder;
                return $cls.$_AsciiPreescapedData ??= $asm.$nstr("$stew.System.Text.Encodings.Web.OptimizedInboxTextEncoder.AsciiPreescapedData", ($self) => class AsciiPreescapedData extends $.$$.System.ValueType
                {
                    /*ulong[128]*/  get Data() { return this.$getField(0, 0x80000000|128); }
                    /*ulong[128]*/  set Data(value) { this.$setField(0, 0x80000000|128, value); }
                    /*void */ PopulatePreescapedData(/*in AllowedBmpCodePointsBitmap*/ allowedCodePointsBmp, /*ScalarEscaperBase*/ innerEncoder)
                    {
                        new $.$stew.System.Text.Encodings.Web.OptimizedInboxTextEncoder.AsciiPreescapedData().Clone(this);
                        /*Span<char>*/ let tempBuffer = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Char, 8, [/*\u0000*/ 0, /*\u0000*/ 0, /*\u0000*/ 0, /*\u0000*/ 0, /*\u0000*/ 0, /*\u0000*/ 0, /*\u0000*/ 0, /*\u0000*/ 0]);
                        for(/*int*/ let i = 0; i < 128; i++)
                        {
                            /*ulong*/ let thisPreescapedData;
                            /*int*/ let encodedCharCount;
                            /*Rune*/ let rune = new $.$$.System.Text.Rune().$ctor$5(i);
                            if (!$.$$.System.Text.Rune.IsControl(rune) && allowedCodePointsBmp.$v.IsCharAllowed($.$cast(i, $.$$.System.Char)))
                            {
                                thisPreescapedData = BigInt((i >>> 0));
                                encodedCharCount = 1;
                            }
                            else 
                            {
                                encodedCharCount = innerEncoder.EncodeUtf16(rune, tempBuffer.Slice(0, 6));
                                $.$$.System.Diagnostics.Debug.Assert$2(encodedCharCount > 0 && encodedCharCount <= 6, "Inner encoder returned bad length.");
                                thisPreescapedData = 0n;
                                tempBuffer.Slice$1(encodedCharCount).Clear();
                                for(/*int*/ let j = ((encodedCharCount - 1) | 0); j >= 0; j--)
                                {
                                    /*uint*/ let thisChar = tempBuffer.get_Item(j).$v;
                                    $.$$.System.Diagnostics.Debug.Assert$2(thisChar <= 127, "Inner encoder returned non-ASCII data.");
                                    thisPreescapedData = (BigInt.asUintN(64, thisPreescapedData << 8n)) | BigInt(thisChar);
                                }
                            }
                            this.Data[i] = thisPreescapedData | (BigInt.asUintN(64, $.$cast((encodedCharCount >>> 0), $.$$.System.UInt64) << 56n));
                        }
                    }
                    /*bool */ TryGetPreescapedData(/*uint*/ codePoint, /*out ulong*/ preescapedData)
                    {
                        if (codePoint <= 127)
                        {
                            preescapedData.$v = this.Data[codePoint];
                            return true;
                        }
                        else 
                        {
                            preescapedData.$v = 0n;
                            return false;
                        }
                    }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        //InlineArray(128)
                        copy.Data = [...this.Data];
                        $.$$.System.Array.CopyMetadata(copy.Data, this.Data)
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //FixedSizeArray(ulong*, 128)
                        let $t1 = this.Data;
                        $.$$.System.Array.AddMetadata($t1, $.$$.System.UInt64.$type, null, null);
                        for (let $i = 0; $i < 128; $i++)
                        {
                            $t1[$i] = 0n;
                        }
                    }
                    static $h = 1370533;
                    static $z = 128;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"m":[{"r":65537,"p":[{"n":"allowedCodePointsBmp","p":584101,"f":8},{"n":"innerEncoder","p":1436069}],"n":"PopulatePreescapedData","d":1370533,"h":8591305125,"f":16777224},{"r":262145,"p":[{"n":"codePoint","p":720897},{"n":"preescapedData","p":983041,"f":2}],"n":"TryGetPreescapedData","d":1370533,"h":12886272421,"f":16777224}],"l":[{"t":$.$typePointer($.$$.System.UInt64).$h,"n":"Data","d":1370533,"h":4296337829,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$2","d":1370533,"h":17181239717,"f":16777217}],"d":1304997,"h":1370533}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `System.Text.Encodings.Web.OptimizedInboxTextEncoder.AsciiPreescapedData`; }
                }, $cls, ($v) => $cls.$_AsciiPreescapedData = $v);
            }
            /*AsciiPreescapedData*/ _asciiPreescapedData;
            /*AllowedBmpCodePointsBitmap*/ _allowedBmpCodePoints;
            /*ScalarEscaperBase*/ _scalarEscaper = null;
            /*SearchValues<byte>*/ _allowedAsciiBytes = null;
            /*SearchValues<char>*/ _allowedAsciiChars = null;
            $ctor$1(/*ScalarEscaperBase*/ scalarEscaper, /*in AllowedBmpCodePointsBitmap*/ allowedCodePointsBmp, /*bool*/ forbidHtmlSensitiveCharacters, /*ReadOnlySpan<char>*/ extraCharactersToEscape)
            {
                super.$ctor();
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(scalarEscaper !== null, "scalarEscaper != null");
                    this._scalarEscaper = scalarEscaper;
                    this._allowedBmpCodePoints = allowedCodePointsBmp.$v;
                    allowedCodePointsBmp = $.$$.System.Runtime.CompilerServices.Unsafe.NullRef($.$stew.System.Text.Encodings.Web.AllowedBmpCodePointsBitmap);
                    this._allowedBmpCodePoints.ForbidUndefinedCharacters();
                    if (forbidHtmlSensitiveCharacters)
                    {
                        this._allowedBmpCodePoints.ForbidHtmlCharacters();
                    }
                    var $en3 = extraCharactersToEscape.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var ch = $en3.Current.$v;
                        {
                            this._allowedBmpCodePoints.ForbidChar(ch);
                        }
                    }
                    this._asciiPreescapedData.PopulatePreescapedData($.$ref(() => this._allowedBmpCodePoints, ), scalarEscaper);
                    /*Span<byte>*/ let allowedAsciiBytes = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Byte, 128, null);
                    /*Span<char>*/ let allowedAsciiChars = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Char, 128, null);
                    /*int*/ let allowedAsciiCount = 0;
                    for(/*int*/ let i = 0; i < 128; i++)
                    {
                        if (this._allowedBmpCodePoints.IsCharAllowed($.$cast(i, $.$$.System.Char)))
                        {
                            allowedAsciiBytes.get_Item(allowedAsciiCount).$v = $.$cast(i, $.$$.System.Byte);
                            allowedAsciiChars.get_Item(allowedAsciiCount).$v = $.$cast(i, $.$$.System.Char);
                            allowedAsciiCount++;
                        }
                    }
                    this._allowedAsciiBytes = $.$$.System.Buffers.SearchValues.Create($.$$.System.Span$$($.$$.System.Byte).op_Implicit(allowedAsciiBytes.Slice(0, allowedAsciiCount)));
                    this._allowedAsciiChars = $.$$.System.Buffers.SearchValues.Create$1($.$$.System.Span$$($.$$.System.Char).op_Implicit(allowedAsciiChars.Slice(0, allowedAsciiCount)));
                }
                return this;
            }
            /*int */ FindFirstCharacterToEncode(/*char**/ text, /*int*/ textLength)
            {
                return this.GetIndexOfFirstCharToEncode(new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))().$ctor$5(text, textLength));
            }
            /*bool */ TryEncodeUnicodeScalar(/*int*/ unicodeScalar, /*char**/ buffer, /*int*/ bufferLength, /*out int*/ numberOfCharactersWritten)
            {
                /*Span<char>*/ let destination = new ($.$$.System.Span$$($.$$.System.Char))().$ctor$5(buffer, bufferLength);
                if (this._allowedBmpCodePoints.IsCodePointAllowed((unicodeScalar >>> 0)))
                {
                    $.$stew.System.Text.UnicodeDebug.AssertIsBmpCodePoint((unicodeScalar >>> 0));
                    $.$stew.System.Text.UnicodeDebug.AssertIsValidScalar((unicodeScalar >>> 0));
                    if (!destination.IsEmpty)
                    {
                        destination.get_Item(0).$v = $.$cast(unicodeScalar, $.$$.System.Char);
                        numberOfCharactersWritten.$v = 1;
                        return true;
                    }
                }
                else 
                {
                    /*int*/ let innerCharsWritten = this._scalarEscaper.EncodeUtf16(new $.$$.System.Text.Rune().$ctor$5(unicodeScalar), destination);
                    $.$$.System.Diagnostics.Debug.Assert$2(innerCharsWritten <= bufferLength, "Mustn't overflow the buffer.");
                    $.$$.System.Diagnostics.Debug.Assert$2(innerCharsWritten !== 0, "Inner escaper succeeded with 0-char output?");
                    if (innerCharsWritten >= 0)
                    {
                        numberOfCharactersWritten.$v = innerCharsWritten;
                        return true;
                    }
                }
                numberOfCharactersWritten.$v = 0;
                return false;
            }
            /*OperationStatus */ Encode(/*ReadOnlySpan<char>*/ source, /*Span<char>*/ destination, /*out int*/ charsConsumed, /*out int*/ charsWritten, /*bool*/ isFinalBlock)
            {
                /*int*/ let srcIdx;
                /*int*/ let dstIdx;
                /*OperationStatus*/ let retVal;
                let $gotoJumpState1 = 0;
                $gotoJumpStart1: while(true)
                {
                    switch($gotoJumpState1)
                    {
                        case 0:
                        {
                            this._AssertThisNotNull();
                            srcIdx = 0;
                            dstIdx = 0;
                            $whileJumpStart2: while(true)
                            {
                                /*char*/ let thisChar;
                                /*int*/ let dstIdxTemp;
                                /*int*/ let charsWrittenJustNow;
                                let $gotoJumpState3 = 0;
                                $gotoJumpStart3: while(true)
                                {
                                    switch($gotoJumpState3)
                                    {
                                        case 0:
                                        {
                                            if ((source.Length >>> 0) <= (srcIdx >>> 0))
                                            {
                                                break $whileJumpStart2;
                                            }
                                            thisChar = source.get_Item(srcIdx).$v;
                                            /*ulong*/ let preescapedEntry;
                                            if (!this._asciiPreescapedData.TryGetPreescapedData(thisChar, $.$ref(() => preescapedEntry, ($v) => preescapedEntry = $v, $.$$.System.UInt64)))
                                            {
                                                $gotoJumpState3 = 1; /*goto NotAscii*/
                                                continue $gotoJumpStart3;
                                            }
                                            if ((destination.Length >>> 0) <= (dstIdx >>> 0))
                                            {
                                                $gotoJumpState1 = 2; /*goto DestTooSmall*/
                                                continue $gotoJumpStart1;
                                            }
                                            destination.get_Item(dstIdx).$v = $.$cast(preescapedEntry, $.$$.System.Byte);
                                            if (($.$cast(preescapedEntry, $.$$.System.UInt32) & 65280) === 0)
                                            {
                                                dstIdx++;
                                                srcIdx++;
                                                continue $whileJumpStart2;
                                            }
                                            preescapedEntry >>= 8n;
                                            dstIdxTemp = ((dstIdx + 1) | 0);
                                            do
                                            {
                                                if ((destination.Length >>> 0) <= (dstIdxTemp >>> 0))
                                                {
                                                    $gotoJumpState1 = 2; /*goto DestTooSmall*/
                                                    continue $gotoJumpStart1;
                                                }
                                                destination.get_Item(dstIdxTemp++).$v = $.$cast(preescapedEntry, $.$$.System.Byte);
                                            }
                                            while($.$cast((preescapedEntry >>= 8n), $.$$.System.Byte) !== 0);
                                            dstIdx = dstIdxTemp;
                                            srcIdx++;
                                            continue $whileJumpStart2;
                                        }
                                        case 1: /*NotAscii*/
                                        /*Rune*/ let scalarValue;
                                        if (!$.$$.System.Text.Rune.TryCreate$1(thisChar, $.$ref(() => scalarValue, ($v) => scalarValue = $v, $.$$.System.Text.Rune)))
                                        {
                                            /*int*/ let srcIdxTemp = ((srcIdx + 1) | 0);
                                            if ((source.Length >>> 0) > (srcIdxTemp >>> 0))
                                            {
                                                if ($.$$.System.Text.Rune.TryCreate(thisChar, source.get_Item(srcIdxTemp).$v, $.$ref(() => scalarValue, ($v) => scalarValue = $v, $.$$.System.Text.Rune)))
                                                {
                                                    $gotoJumpState3 = 2; /*goto CheckWhetherScalarValueAllowed*/
                                                    continue $gotoJumpStart3;
                                                }
                                            }
                                            else if (!isFinalBlock && $.$$.System.Char.IsHighSurrogate(thisChar))
                                            {
                                                $gotoJumpState1 = 3; /*goto NeedMoreData*/
                                                continue $gotoJumpStart1;
                                            }
                                            scalarValue = $.$$.System.Text.Rune.ReplacementChar;
                                            $gotoJumpState3 = 3; /*goto MustEncodeNonAscii*/
                                            continue $gotoJumpStart3;
                                        }
                                        case 2: /*CheckWhetherScalarValueAllowed*/
                                        if (this.IsScalarValueAllowed(scalarValue))
                                        {
                                            /*int*/ let utf16CodeUnitCount;
                                            if (!scalarValue.TryEncodeToUtf16(destination.Slice$1(dstIdx), $.$ref(() => utf16CodeUnitCount, ($v) => utf16CodeUnitCount = $v, $.$$.System.Int32)))
                                            {
                                                $gotoJumpState1 = 2; /*goto DestTooSmall*/
                                                continue $gotoJumpStart1;
                                            }
                                            dstIdx += utf16CodeUnitCount;
                                            srcIdx += utf16CodeUnitCount;
                                            continue $whileJumpStart2;
                                        }
                                        case 3: /*MustEncodeNonAscii*/
                                        charsWrittenJustNow = this._scalarEscaper.EncodeUtf16(scalarValue, destination.Slice$1(dstIdx));
                                        if (charsWrittenJustNow < 0)
                                        {
                                            $gotoJumpState1 = 2; /*goto DestTooSmall*/
                                            continue $gotoJumpStart1;
                                        }
                                        dstIdx += charsWrittenJustNow;
                                        srcIdx += scalarValue.Utf16SequenceLength;
                                    }
                                    break;
                                }
                            }
                            retVal = 0/*OperationStatus.Done*/;
                        }
                        case 1: /*CommonReturn*/
                        charsConsumed.$v = srcIdx;
                        charsWritten.$v = dstIdx;
                        return retVal;
                        case 2: /*DestTooSmall*/
                        retVal = 1/*OperationStatus.DestinationTooSmall*/;
                        $gotoJumpState1 = 1; /*goto CommonReturn*/
                        continue $gotoJumpStart1;
                        case 3: /*NeedMoreData*/
                        retVal = 2/*OperationStatus.NeedMoreData*/;
                        $gotoJumpState1 = 1; /*goto CommonReturn*/
                        continue $gotoJumpStart1;
                    }
                    break;
                }
            }
            /*OperationStatus */ EncodeUtf8(/*ReadOnlySpan<byte>*/ source, /*Span<byte>*/ destination, /*out int*/ bytesConsumed, /*out int*/ bytesWritten, /*bool*/ isFinalBlock)
            {
                /*int*/ let srcIdx;
                /*int*/ let dstIdx;
                /*OperationStatus*/ let retVal;
                let $gotoJumpState1 = 0;
                $gotoJumpStart1: while(true)
                {
                    switch($gotoJumpState1)
                    {
                        case 0:
                        {
                            this._AssertThisNotNull();
                            srcIdx = 0;
                            dstIdx = 0;
                            $whileJumpStart2: while(true)
                            {
                                /*uint*/ let thisByte;
                                /*int*/ let dstIdxTemp;
                                /*OperationStatus*/ let runeDecodeStatus;
                                /*int*/ let bytesWrittenJustNow;
                                let $gotoJumpState3 = 0;
                                $gotoJumpStart3: while(true)
                                {
                                    switch($gotoJumpState3)
                                    {
                                        case 0:
                                        {
                                            if ((source.Length >>> 0) <= (srcIdx >>> 0))
                                            {
                                                break $whileJumpStart2;
                                            }
                                            thisByte = source.get_Item(srcIdx).$v;
                                            /*ulong*/ let preescapedEntry;
                                            if (!this._asciiPreescapedData.TryGetPreescapedData(thisByte, $.$ref(() => preescapedEntry, ($v) => preescapedEntry = $v, $.$$.System.UInt64)))
                                            {
                                                $gotoJumpState3 = 1; /*goto NotAscii*/
                                                continue $gotoJumpStart3;
                                            }
                                            if ($.$$.System.Buffers.Binary.BinaryPrimitives.TryWriteUInt64LittleEndian(destination.Slice$1(dstIdx), preescapedEntry))
                                            {
                                                dstIdx += $.$cast((preescapedEntry >> 56n), $.$$.System.Int32);
                                                srcIdx++;
                                                continue $whileJumpStart2;
                                            }
                                            dstIdxTemp = dstIdx;
                                            do
                                            {
                                                if ((destination.Length >>> 0) <= (dstIdxTemp >>> 0))
                                                {
                                                    $gotoJumpState1 = 2; /*goto DestTooSmall*/
                                                    continue $gotoJumpStart1;
                                                }
                                                destination.get_Item(dstIdxTemp++).$v = $.$cast(preescapedEntry, $.$$.System.Byte);
                                            }
                                            while($.$cast((preescapedEntry >>= 8n), $.$$.System.Byte) !== 0);
                                            dstIdx = dstIdxTemp;
                                            srcIdx++;
                                            continue $whileJumpStart2;
                                        }
                                        case 1: /*NotAscii*/
                                        /*Rune*/ let scalarValue;
                                        /*int*/ let bytesConsumedJustNow;
                                        runeDecodeStatus = $.$$.System.Text.Rune.DecodeFromUtf8(source.Slice$1(srcIdx), $.$ref(() => scalarValue, ($v) => scalarValue = $v, $.$$.System.Text.Rune), $.$ref(() => bytesConsumedJustNow, ($v) => bytesConsumedJustNow = $v, $.$$.System.Int32));
                                        if (runeDecodeStatus !== 0/*OperationStatus.Done*/)
                                        {
                                            if (!isFinalBlock && runeDecodeStatus === 2/*OperationStatus.NeedMoreData*/)
                                            {
                                                $gotoJumpState1 = 3; /*goto NeedMoreData*/
                                                continue $gotoJumpStart1;
                                            }
                                            $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Text.Rune.op_Equality(scalarValue, $.$$.System.Text.Rune.ReplacementChar), "scalarValue == Rune.ReplacementChar");
                                            $gotoJumpState3 = 2; /*goto MustEncodeNonAscii*/
                                            continue $gotoJumpStart3;
                                        }
                                        if (this.IsScalarValueAllowed(scalarValue))
                                        {
                                            /*int*/ let utf8CodeUnitCount;
                                            if (!scalarValue.TryEncodeToUtf8(destination.Slice$1(dstIdx), $.$ref(() => utf8CodeUnitCount, ($v) => utf8CodeUnitCount = $v, $.$$.System.Int32)))
                                            {
                                                $gotoJumpState1 = 2; /*goto DestTooSmall*/
                                                continue $gotoJumpStart1;
                                            }
                                            dstIdx += utf8CodeUnitCount;
                                            srcIdx += utf8CodeUnitCount;
                                            continue $whileJumpStart2;
                                        }
                                        case 2: /*MustEncodeNonAscii*/
                                        bytesWrittenJustNow = this._scalarEscaper.EncodeUtf8(scalarValue, destination.Slice$1(dstIdx));
                                        if (bytesWrittenJustNow < 0)
                                        {
                                            $gotoJumpState1 = 2; /*goto DestTooSmall*/
                                            continue $gotoJumpStart1;
                                        }
                                        dstIdx += bytesWrittenJustNow;
                                        srcIdx += bytesConsumedJustNow;
                                    }
                                    break;
                                }
                            }
                            retVal = 0/*OperationStatus.Done*/;
                        }
                        case 1: /*CommonReturn*/
                        bytesConsumed.$v = srcIdx;
                        bytesWritten.$v = dstIdx;
                        return retVal;
                        case 2: /*DestTooSmall*/
                        retVal = 1/*OperationStatus.DestinationTooSmall*/;
                        $gotoJumpState1 = 1; /*goto CommonReturn*/
                        continue $gotoJumpStart1;
                        case 3: /*NeedMoreData*/
                        retVal = 2/*OperationStatus.NeedMoreData*/;
                        $gotoJumpState1 = 1; /*goto CommonReturn*/
                        continue $gotoJumpStart1;
                    }
                    break;
                }
            }
            /*int */ GetIndexOfFirstByteToEncode(/*ReadOnlySpan<byte>*/ data)
            {
                /*int*/ let asciiBytesSkipped = 0;
                asciiBytesSkipped = $.$$.System.MemoryExtensions.IndexOfAnyExcept($.$$.System.Byte, data, this._allowedAsciiBytes);
                if ((asciiBytesSkipped >>> 0) >= (data.Length >>> 0) || $.$stew.System.Text.UnicodeUtility.IsAsciiCodePoint(data.get_Item(asciiBytesSkipped).$v))
                {
                    return asciiBytesSkipped;
                }
                /*int*/ let dataOriginalLength = data.Length;
                data = data.Slice$1(asciiBytesSkipped);
                while(!data.IsEmpty)
                {
                    /*Rune*/ let scalarValue;
                    /*int*/ let bytesConsumed;
                    /*OperationStatus*/ let opStatus = $.$$.System.Text.Rune.DecodeFromUtf8(data, $.$ref(() => scalarValue, ($v) => scalarValue = $v, $.$$.System.Text.Rune), $.$ref(() => bytesConsumed, ($v) => bytesConsumed = $v, $.$$.System.Int32));
                    if (opStatus !== 0/*OperationStatus.Done*/)
                    {
                        break;
                    }
                    if (bytesConsumed >= 4)
                    {
                        break;
                    }
                    $.$stew.System.Text.UnicodeDebug.AssertIsBmpCodePoint((scalarValue.Value >>> 0));
                    if (!this._allowedBmpCodePoints.IsCharAllowed($.$cast(scalarValue.Value, $.$$.System.Char)))
                    {
                        break;
                    }
                    data = data.Slice$1(bytesConsumed);
                }
                return (data.IsEmpty) ? -1 : ((dataOriginalLength - data.Length) | 0);
            }
            /*int */ GetIndexOfFirstCharToEncode(/*ReadOnlySpan<char>*/ data)
            {
                /*int*/ let asciiCharsSkipped = 0;
                if (data.Length >= 8)
                {
                    asciiCharsSkipped = $.$$.System.MemoryExtensions.IndexOfAnyExcept($.$$.System.Char, data, this._allowedAsciiChars);
                    if ((asciiCharsSkipped >>> 0) >= (data.Length >>> 0) || $.$$.System.Char.IsAscii(data.get_Item(asciiCharsSkipped).$v))
                    {
                        return asciiCharsSkipped;
                    }
                }
                /*fixed*/ 
                {
                    /*char**/ let pData = data.GetPinnableReference();
                    /*nuint*/ let lengthInChars;
                    /*nuint*/ let idx;
                    /*int*/ let idx32;
                    let $gotoJumpState1 = 0;
                    $gotoJumpStart1: while(true)
                    {
                        switch($gotoJumpState1)
                        {
                            case 0:
                            {
                                lengthInChars = (data.Length >>> 0);
                                idx = (asciiCharsSkipped >>> 0);
                                if (idx < lengthInChars)
                                {
                                    /*nint*/ let loopIter;
                                    let $gotoJumpState2 = 0;
                                    $gotoJumpStart2: while(true)
                                    {
                                        switch($gotoJumpState2)
                                        {
                                            case 0:
                                            {
                                                this._AssertThisNotNull();
                                                loopIter = 0;
                                                for(; lengthInChars - idx >= 8; idx += 8)
                                                {
                                                    loopIter = -1;
                                                    if (!this._allowedBmpCodePoints.IsCharAllowed(pData.GetAt(idx + $.$cast((++loopIter), $.$$.System.UIntPtr))))
                                                    {
                                                        $gotoJumpState2 = 1; /*goto BrokeInUnrolledLoop*/
                                                        continue $gotoJumpStart2;
                                                    }
                                                    if (!this._allowedBmpCodePoints.IsCharAllowed(pData.GetAt(idx + $.$cast((++loopIter), $.$$.System.UIntPtr))))
                                                    {
                                                        $gotoJumpState2 = 1; /*goto BrokeInUnrolledLoop*/
                                                        continue $gotoJumpStart2;
                                                    }
                                                    if (!this._allowedBmpCodePoints.IsCharAllowed(pData.GetAt(idx + $.$cast((++loopIter), $.$$.System.UIntPtr))))
                                                    {
                                                        $gotoJumpState2 = 1; /*goto BrokeInUnrolledLoop*/
                                                        continue $gotoJumpStart2;
                                                    }
                                                    if (!this._allowedBmpCodePoints.IsCharAllowed(pData.GetAt(idx + $.$cast((++loopIter), $.$$.System.UIntPtr))))
                                                    {
                                                        $gotoJumpState2 = 1; /*goto BrokeInUnrolledLoop*/
                                                        continue $gotoJumpStart2;
                                                    }
                                                    if (!this._allowedBmpCodePoints.IsCharAllowed(pData.GetAt(idx + $.$cast((++loopIter), $.$$.System.UIntPtr))))
                                                    {
                                                        $gotoJumpState2 = 1; /*goto BrokeInUnrolledLoop*/
                                                        continue $gotoJumpStart2;
                                                    }
                                                    if (!this._allowedBmpCodePoints.IsCharAllowed(pData.GetAt(idx + $.$cast((++loopIter), $.$$.System.UIntPtr))))
                                                    {
                                                        $gotoJumpState2 = 1; /*goto BrokeInUnrolledLoop*/
                                                        continue $gotoJumpStart2;
                                                    }
                                                    if (!this._allowedBmpCodePoints.IsCharAllowed(pData.GetAt(idx + $.$cast((++loopIter), $.$$.System.UIntPtr))))
                                                    {
                                                        $gotoJumpState2 = 1; /*goto BrokeInUnrolledLoop*/
                                                        continue $gotoJumpStart2;
                                                    }
                                                    if (!this._allowedBmpCodePoints.IsCharAllowed(pData.GetAt(idx + $.$cast((++loopIter), $.$$.System.UIntPtr))))
                                                    {
                                                        $gotoJumpState2 = 1; /*goto BrokeInUnrolledLoop*/
                                                        continue $gotoJumpStart2;
                                                    }
                                                }
                                                for(; idx < lengthInChars; idx++)
                                                {
                                                    if (!this._allowedBmpCodePoints.IsCharAllowed(pData.GetAt(idx)))
                                                    {
                                                        break;
                                                    }
                                                }
                                                $gotoJumpState1 = 1; /*goto Return*/
                                                continue $gotoJumpStart1;
                                            }
                                            case 1: /*BrokeInUnrolledLoop*/
                                            idx += $.$cast(loopIter, $.$$.System.UIntPtr);
                                        }
                                        break;
                                    }
                                }
                            }
                            case 1: /*Return*/
                            $.$$.System.Diagnostics.Debug.Assert$2(0 <= idx && idx <= lengthInChars, "0 <= idx && idx <= lengthInChars");
                            idx32 = (idx | 0);
                            if (idx32 === (lengthInChars | 0))
                            {
                                idx32 = -1;
                            }
                            return idx32;
                        }
                        break;
                    }
                }
            }
            /*bool */ IsScalarValueAllowed(/*Rune*/ value)
            {
                return this._allowedBmpCodePoints.IsCodePointAllowed((value.Value >>> 0));
            }
            /*void */ _AssertThisNotNull()
            {
                if ($.$$.System.Type.op_Equality$1($.$$.System.Object.GetType.call(this), $.$stew.System.Text.Encodings.Web.OptimizedInboxTextEncoder.$type))
                {
                }
            }
            //default member initializer
            constructor()
            {
                super();
                this._asciiPreescapedData = $.$default($.$stew.System.Text.Encodings.Web.OptimizedInboxTextEncoder.AsciiPreescapedData);
                this._allowedBmpCodePoints = $.$default($.$stew.System.Text.Encodings.Web.AllowedBmpCodePointsBitmap);
            }
            static $h = 1304997;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":655361,"p":[{"n":"text","p":$.$typePointer($.$$.System.Char).$h},{"n":"textLength","p":655361}],"n":"FindFirstCharacterToEncode","d":1304997,"h":34361043365,"f":16777217,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"FindFirstCharacterToEncode has been deprecated. It should only be used by the TextEncoder adapter.","t":1310721}]}]},{"r":262145,"p":[{"n":"unicodeScalar","p":655361},{"n":"buffer","p":$.$typePointer($.$$.System.Char).$h},{"n":"bufferLength","p":655361},{"n":"numberOfCharactersWritten","p":655361,"f":2}],"n":"TryEncodeUnicodeScalar","d":1304997,"h":38656010661,"f":16777217,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"TryEncodeUnicodeScalar has been deprecated. It should only be used by the TextEncoder adapter.","t":1310721}]}]},{"r":18743297,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h},{"n":"destination","p":$.$$.System.Span$$($.$$.System.Char).$h},{"n":"charsConsumed","p":655361,"f":2},{"n":"charsWritten","p":655361,"f":2},{"n":"isFinalBlock","p":262145}],"n":"Encode","d":1304997,"h":42950977957,"f":16777217},{"r":18743297,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"destination","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"bytesConsumed","p":655361,"f":2},{"n":"bytesWritten","p":655361,"f":2},{"n":"isFinalBlock","p":262145}],"n":"EncodeUtf8","d":1304997,"h":47245945253,"f":16777217},{"r":655361,"p":[{"n":"data","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h}],"n":"GetIndexOfFirstByteToEncode","d":1304997,"h":51540912549,"f":16777217},{"r":655361,"p":[{"n":"data","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h}],"n":"GetIndexOfFirstCharToEncode","d":1304997,"h":55835879845,"f":16777217},{"r":262145,"p":[{"n":"value","p":122617857}],"n":"IsScalarValueAllowed","d":1304997,"h":60130847141,"f":16777217},{"r":65537,"n":"_AssertThisNotNull","d":1304997,"h":64425814437,"f":16777218}],"l":[{"t":1370533,"n":"_asciiPreescapedData","d":1304997,"h":8591239589,"f":4194306},{"t":584101,"n":"_allowedBmpCodePoints","d":1304997,"h":12886206885,"f":4194306},{"t":1436069,"n":"_scalarEscaper","d":1304997,"h":17181174181,"f":4194306},{"t":$.$$.System.Buffers.SearchValues$$($.$$.System.Byte).$h,"n":"_allowedAsciiBytes","d":1304997,"h":21476141477,"f":4194306},{"t":$.$$.System.Buffers.SearchValues$$($.$$.System.Char).$h,"n":"_allowedAsciiChars","d":1304997,"h":25771108773,"f":4194306}],"c":[{"p":[{"n":"scalarEscaper","p":1436069},{"n":"allowedCodePointsBmp","p":584101,"f":8},{"n":"forbidHtmlSensitiveCharacters","p":262145,"f":65,"v":true},{"n":"extraCharactersToEscape","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h,"f":65}],"n":".ctor","o":"$ctor$1","d":1304997,"h":30066076069,"f":16777224}],"j":[1370533],"h":1304997}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Text.Encodings.Web.OptimizedInboxTextEncoder`; }
        });
        
        $asm.$cls("$stew.System.Text.Encodings.Web.ThrowHelper", ($self) => class ThrowHelper
        {
            static /*void */ ThrowArgumentNullException(/*ExceptionArgument*/ argument)
            {
                throw new $.$$.System.ArgumentNullException().$ctor$19($.$stew.System.Text.Encodings.Web.ThrowHelper.GetArgumentName(argument));
            }
            static /*void */ ThrowArgumentOutOfRangeException(/*ExceptionArgument*/ argument)
            {
                throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20($.$stew.System.Text.Encodings.Web.ThrowHelper.GetArgumentName(argument));
            }
            static /*string */ GetArgumentName(/*ExceptionArgument*/ argument)
            {
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Enum.IsDefined($.$stew.System.Text.Encodings.Web.ExceptionArgument.$type, $.$box(argument, $.$stew.System.Text.Encodings.Web.ExceptionArgument)), "The enum value is not defined, please check the ExceptionArgument Enum.");
                return $.$$.System.Enum.ToStringT($.$stew.System.Text.Encodings.Web.ExceptionArgument, $.$$.System.UInt32, argument);
            }
            static $h = 1632677;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"argument","p":1108389}],"n":"ThrowArgumentNullException","d":1632677,"h":4296599973,"f":16777256},{"r":65537,"p":[{"n":"argument","p":1108389}],"n":"ThrowArgumentOutOfRangeException","d":1632677,"h":8591567269,"f":16777256},{"r":1310721,"p":[{"n":"argument","p":1108389}],"n":"GetArgumentName","d":1632677,"h":12886534565,"f":16777250}],"h":1632677}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Text.Encodings.Web.ThrowHelper`; }
        });
        
        $asm.$cls("$stew.System.Text.Encodings.Web.TextEncoderSettings", ($self) => class TextEncoderSettings extends $.$$.System.Object
        {
            /*AllowedBmpCodePointsBitmap*/ _allowedCodePointsBitmap;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*TextEncoderSettings*/ other)
            {
                super.$ctor();
                {
                    if (other === null)
                    {
                        $.$stew.System.Text.Encodings.Web.ThrowHelper.ThrowArgumentNullException(3/*ExceptionArgument.other*/);
                    }
                    this._allowedCodePointsBitmap = other.GetAllowedCodePointsBitmap().$v;
                }
                return this;
            }
            $ctor$3(/*params UnicodeRange[]*/ allowedRanges)
            {
                super.$ctor();
                {
                    if (allowedRanges === null)
                    {
                        $.$stew.System.Text.Encodings.Web.ThrowHelper.ThrowArgumentNullException(4/*ExceptionArgument.allowedRanges*/);
                    }
                    this.AllowRanges(allowedRanges);
                }
                return this;
            }
            /*void */ AllowCharacter(/*char*/ character)
            {
                this._allowedCodePointsBitmap.AllowChar(character);
            }
            /*void */ AllowCharacters(/*params char[]*/ characters)
            {
                if (characters === null)
                {
                    $.$stew.System.Text.Encodings.Web.ThrowHelper.ThrowArgumentNullException(5/*ExceptionArgument.characters*/);
                }
                for(/*int*/ let i = 0; i < characters.length; i++)
                {
                    this._allowedCodePointsBitmap.AllowChar($.$$.System.Array.$ReadT1.call(characters, i));
                }
            }
            /*void */ AllowCodePoints(/*IEnumerable<int>*/ codePoints)
            {
                if (codePoints === null)
                {
                    $.$stew.System.Text.Encodings.Web.ThrowHelper.ThrowArgumentNullException(6/*ExceptionArgument.codePoints*/);
                }
                var $en2 = codePoints.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var allowedCodePoint = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if ($.$stew.System.Text.UnicodeUtility.IsBmpCodePoint((allowedCodePoint >>> 0)))
                        {
                            this._allowedCodePointsBitmap.AllowChar($.$cast(allowedCodePoint, $.$$.System.Char));
                        }
                    }
                }
            }
            /*void */ AllowRange(/*UnicodeRange*/ range)
            {
                if (range === null)
                {
                    $.$stew.System.Text.Encodings.Web.ThrowHelper.ThrowArgumentNullException(7/*ExceptionArgument.range*/);
                }
                /*int*/ let firstCodePoint = range.FirstCodePoint;
                /*int*/ let rangeSize = range.Length;
                for(/*int*/ let i = 0; i < rangeSize; i++)
                {
                    /*int*/ let codePoint = ((firstCodePoint + i) | 0);
                    $.$stew.System.Text.UnicodeDebug.AssertIsBmpCodePoint((codePoint >>> 0));
                    this._allowedCodePointsBitmap.AllowChar($.$cast(codePoint, $.$$.System.Char));
                }
            }
            /*void */ AllowRanges(/*params UnicodeRange[]*/ ranges)
            {
                if (ranges === null)
                {
                    $.$stew.System.Text.Encodings.Web.ThrowHelper.ThrowArgumentNullException(8/*ExceptionArgument.ranges*/);
                }
                for(/*int*/ let i = 0; i < ranges.length; i++)
                {
                    this.AllowRange($.$$.System.Array.$ReadT1.call(ranges, i));
                }
            }
            /*void */ Clear()
            {
                this._allowedCodePointsBitmap = new $.$stew.System.Text.Encodings.Web.AllowedBmpCodePointsBitmap();
            }
            /*void */ ForbidCharacter(/*char*/ character)
            {
                this._allowedCodePointsBitmap.ForbidChar(character);
            }
            /*void */ ForbidCharacters(/*params char[]*/ characters)
            {
                if (characters === null)
                {
                    $.$stew.System.Text.Encodings.Web.ThrowHelper.ThrowArgumentNullException(5/*ExceptionArgument.characters*/);
                }
                for(/*int*/ let i = 0; i < characters.length; i++)
                {
                    this._allowedCodePointsBitmap.ForbidChar($.$$.System.Array.$ReadT1.call(characters, i));
                }
            }
            /*void */ ForbidRange(/*UnicodeRange*/ range)
            {
                if (range === null)
                {
                    $.$stew.System.Text.Encodings.Web.ThrowHelper.ThrowArgumentNullException(7/*ExceptionArgument.range*/);
                }
                /*int*/ let firstCodePoint = range.FirstCodePoint;
                /*int*/ let rangeSize = range.Length;
                for(/*int*/ let i = 0; i < rangeSize; i++)
                {
                    /*int*/ let codePoint = ((firstCodePoint + i) | 0);
                    $.$stew.System.Text.UnicodeDebug.AssertIsBmpCodePoint((codePoint >>> 0));
                    this._allowedCodePointsBitmap.ForbidChar($.$cast(codePoint, $.$$.System.Char));
                }
            }
            /*void */ ForbidRanges(/*params UnicodeRange[]*/ ranges)
            {
                if (ranges === null)
                {
                    $.$stew.System.Text.Encodings.Web.ThrowHelper.ThrowArgumentNullException(8/*ExceptionArgument.ranges*/);
                }
                for(/*int*/ let i = 0; i < ranges.length; i++)
                {
                    this.ForbidRange($.$$.System.Array.$ReadT1.call(ranges, i));
                }
            }
            /*IEnumerable<int> */ GetAllowedCodePoints()
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    for(/*int*/ let i = 0; i <= /*\uFFFF*/ 65535; i++)
                    {
                        if (this._allowedCodePointsBitmap.IsCharAllowed($.$cast(i, $.$$.System.Char)))
                        {
                            yield i;
                        }
                    }
                }.bind(this));
            }
            /*ref readonly AllowedBmpCodePointsBitmap */ GetAllowedCodePointsBitmap()
            {
                if ($.$$.System.Type.op_Equality$1($.$$.System.Object.GetType.call(this), $.$stew.System.Text.Encodings.Web.TextEncoderSettings.$type))
                {
                    return $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stew.System.Text.Encodings.Web.AllowedBmpCodePointsBitmap, () => this._allowedCodePointsBitmap, ($v) => this._allowedCodePointsBitmap = $v, null);
                }
                else 
                {
                    /*StrongBox<AllowedBmpCodePointsBitmap>*/ let newBitmap = new ($.$$.System.Runtime.CompilerServices.StrongBox$$($.$stew.System.Text.Encodings.Web.AllowedBmpCodePointsBitmap))().$ctor$1();
                    var $en3 = this.GetAllowedCodePoints().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var allowedCodePoint = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if ((allowedCodePoint >>> 0) <= /*\uFFFF*/ 65535)
                            {
                                newBitmap.Value.AllowChar($.$cast(allowedCodePoint, $.$$.System.Char));
                            }
                        }
                    }
                    return $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stew.System.Text.Encodings.Web.AllowedBmpCodePointsBitmap, () => newBitmap.Value, ($v) => newBitmap.Value = $v, null);
                }
            }
            //default member initializer
            constructor()
            {
                super();
                this._allowedCodePointsBitmap = $.$default($.$stew.System.Text.Encodings.Web.AllowedBmpCodePointsBitmap);
            }
            static $h = 1567141;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"character","p":458753}],"n":"AllowCharacter","d":1567141,"h":21476403621,"f":16777345},{"r":65537,"p":[{"n":"characters","p":$.$typeArray($.$$.System.Char).$h,"f":16}],"n":"AllowCharacters","d":1567141,"h":25771370917,"f":16777345},{"r":65537,"p":[{"n":"codePoints","p":$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Int32).$h}],"n":"AllowCodePoints","d":1567141,"h":30066338213,"f":16777345},{"r":65537,"p":[{"n":"range","p":1829285}],"n":"AllowRange","d":1567141,"h":34361305509,"f":16777345},{"r":65537,"p":[{"n":"ranges","p":$.$typeArray($.$stew.System.Text.Unicode.UnicodeRange).$h,"f":16}],"n":"AllowRanges","d":1567141,"h":38656272805,"f":16777345},{"r":65537,"n":"Clear","d":1567141,"h":42951240101,"f":16777345},{"r":65537,"p":[{"n":"character","p":458753}],"n":"ForbidCharacter","d":1567141,"h":47246207397,"f":16777345},{"r":65537,"p":[{"n":"characters","p":$.$typeArray($.$$.System.Char).$h,"f":16}],"n":"ForbidCharacters","d":1567141,"h":51541174693,"f":16777345},{"r":65537,"p":[{"n":"range","p":1829285}],"n":"ForbidRange","d":1567141,"h":55836141989,"f":16777345},{"r":65537,"p":[{"n":"ranges","p":$.$typeArray($.$stew.System.Text.Unicode.UnicodeRange).$h,"f":16}],"n":"ForbidRanges","d":1567141,"h":60131109285,"f":16777345},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Int32).$h,"n":"GetAllowedCodePoints","d":1567141,"h":64426076581,"f":16777345},{"r":584101,"n":"GetAllowedCodePointsBitmap","d":1567141,"h":68721043877,"f":16777224}],"l":[{"t":584101,"n":"_allowedCodePointsBitmap","d":1567141,"h":4296534437,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$1","d":1567141,"h":8591501733,"f":16777217},{"p":[{"n":"other","p":1567141}],"n":".ctor","o":"$ctor$2","d":1567141,"h":12886469029,"f":16777217},{"p":[{"n":"allowedRanges","p":$.$typeArray($.$stew.System.Text.Unicode.UnicodeRange).$h,"f":16}],"n":".ctor","o":"$ctor$3","d":1567141,"h":17181436325,"f":16777217}],"h":1567141}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Text.Encodings.Web.TextEncoderSettings`; }
        });
        
        $asm.$cls("$stew.System.Text.Unicode.UnicodeRanges", ($self) => class UnicodeRanges
        {
            static /*UnicodeRange */ get None()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._none ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateEmptyRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._none, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._none = $v, $.$stew.System.Text.Unicode.UnicodeRange));
            }
            /*UnicodeRange?*/ static _none = null;
            static /*UnicodeRange */ get All()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._all ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._all, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._all = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0000*/ 0, /*\uFFFF*/ 65535);
            }
            /*UnicodeRange?*/ static _all = null;
            static /*UnicodeRange */ CreateEmptyRange(/*ref UnicodeRange?*/ range)
            {
                range.$v = new $.$stew.System.Text.Unicode.UnicodeRange().$ctor$1(0, 0);
                return range.$v;
            }
            static /*UnicodeRange */ CreateRange(/*ref UnicodeRange?*/ range, /*char*/ first, /*char*/ last)
            {
                range.$v = $.$stew.System.Text.Unicode.UnicodeRange.Create(first, last);
                return range.$v;
            }
            static /*UnicodeRange */ get BasicLatin()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0000 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0000, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0000 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0000*/ 0, /*\u007F*/ 127);
            }
            /*UnicodeRange?*/ static _u0000 = null;
            static /*UnicodeRange */ get Latin1Supplement()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0080 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0080, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0080 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0080*/ 128, /*\u00FF*/ 255);
            }
            /*UnicodeRange?*/ static _u0080 = null;
            static /*UnicodeRange */ get LatinExtendedA()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0100 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0100, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0100 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0100*/ 256, /*\u017F*/ 383);
            }
            /*UnicodeRange?*/ static _u0100 = null;
            static /*UnicodeRange */ get LatinExtendedB()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0180 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0180, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0180 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0180*/ 384, /*\u024F*/ 591);
            }
            /*UnicodeRange?*/ static _u0180 = null;
            static /*UnicodeRange */ get IpaExtensions()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0250 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0250, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0250 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0250*/ 592, /*\u02AF*/ 687);
            }
            /*UnicodeRange?*/ static _u0250 = null;
            static /*UnicodeRange */ get SpacingModifierLetters()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u02B0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u02B0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u02B0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u02B0*/ 688, /*\u02FF*/ 767);
            }
            /*UnicodeRange?*/ static _u02B0 = null;
            static /*UnicodeRange */ get CombiningDiacriticalMarks()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0300 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0300, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0300 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0300*/ 768, /*\u036F*/ 879);
            }
            /*UnicodeRange?*/ static _u0300 = null;
            static /*UnicodeRange */ get GreekandCoptic()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0370 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0370, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0370 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0370*/ 880, /*\u03FF*/ 1023);
            }
            /*UnicodeRange?*/ static _u0370 = null;
            static /*UnicodeRange */ get Cyrillic()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0400 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0400, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0400 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0400*/ 1024, /*\u04FF*/ 1279);
            }
            /*UnicodeRange?*/ static _u0400 = null;
            static /*UnicodeRange */ get CyrillicSupplement()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0500 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0500, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0500 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0500*/ 1280, /*\u052F*/ 1327);
            }
            /*UnicodeRange?*/ static _u0500 = null;
            static /*UnicodeRange */ get Armenian()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0530 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0530, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0530 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0530*/ 1328, /*\u058F*/ 1423);
            }
            /*UnicodeRange?*/ static _u0530 = null;
            static /*UnicodeRange */ get Hebrew()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0590 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0590, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0590 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0590*/ 1424, /*\u05FF*/ 1535);
            }
            /*UnicodeRange?*/ static _u0590 = null;
            static /*UnicodeRange */ get Arabic()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0600 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0600, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0600 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0600*/ 1536, /*\u06FF*/ 1791);
            }
            /*UnicodeRange?*/ static _u0600 = null;
            static /*UnicodeRange */ get Syriac()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0700 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0700, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0700 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0700*/ 1792, /*\u074F*/ 1871);
            }
            /*UnicodeRange?*/ static _u0700 = null;
            static /*UnicodeRange */ get ArabicSupplement()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0750 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0750, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0750 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0750*/ 1872, /*\u077F*/ 1919);
            }
            /*UnicodeRange?*/ static _u0750 = null;
            static /*UnicodeRange */ get Thaana()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0780 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0780, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0780 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0780*/ 1920, /*\u07BF*/ 1983);
            }
            /*UnicodeRange?*/ static _u0780 = null;
            static /*UnicodeRange */ get NKo()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u07C0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u07C0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u07C0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u07C0*/ 1984, /*\u07FF*/ 2047);
            }
            /*UnicodeRange?*/ static _u07C0 = null;
            static /*UnicodeRange */ get Samaritan()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0800 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0800, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0800 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0800*/ 2048, /*\u083F*/ 2111);
            }
            /*UnicodeRange?*/ static _u0800 = null;
            static /*UnicodeRange */ get Mandaic()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0840 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0840, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0840 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0840*/ 2112, /*\u085F*/ 2143);
            }
            /*UnicodeRange?*/ static _u0840 = null;
            static /*UnicodeRange */ get SyriacSupplement()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0860 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0860, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0860 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0860*/ 2144, /*\u086F*/ 2159);
            }
            /*UnicodeRange?*/ static _u0860 = null;
            static /*UnicodeRange */ get ArabicExtendedB()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0870 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0870, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0870 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0870*/ 2160, /*\u089F*/ 2207);
            }
            /*UnicodeRange?*/ static _u0870 = null;
            static /*UnicodeRange */ get ArabicExtendedA()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u08A0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u08A0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u08A0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u08A0*/ 2208, /*\u08FF*/ 2303);
            }
            /*UnicodeRange?*/ static _u08A0 = null;
            static /*UnicodeRange */ get Devanagari()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0900 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0900, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0900 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0900*/ 2304, /*\u097F*/ 2431);
            }
            /*UnicodeRange?*/ static _u0900 = null;
            static /*UnicodeRange */ get Bengali()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0980 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0980, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0980 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0980*/ 2432, /*\u09FF*/ 2559);
            }
            /*UnicodeRange?*/ static _u0980 = null;
            static /*UnicodeRange */ get Gurmukhi()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0A00 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0A00, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0A00 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0A00*/ 2560, /*\u0A7F*/ 2687);
            }
            /*UnicodeRange?*/ static _u0A00 = null;
            static /*UnicodeRange */ get Gujarati()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0A80 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0A80, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0A80 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0A80*/ 2688, /*\u0AFF*/ 2815);
            }
            /*UnicodeRange?*/ static _u0A80 = null;
            static /*UnicodeRange */ get Oriya()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0B00 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0B00, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0B00 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0B00*/ 2816, /*\u0B7F*/ 2943);
            }
            /*UnicodeRange?*/ static _u0B00 = null;
            static /*UnicodeRange */ get Tamil()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0B80 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0B80, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0B80 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0B80*/ 2944, /*\u0BFF*/ 3071);
            }
            /*UnicodeRange?*/ static _u0B80 = null;
            static /*UnicodeRange */ get Telugu()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0C00 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0C00, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0C00 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0C00*/ 3072, /*\u0C7F*/ 3199);
            }
            /*UnicodeRange?*/ static _u0C00 = null;
            static /*UnicodeRange */ get Kannada()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0C80 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0C80, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0C80 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0C80*/ 3200, /*\u0CFF*/ 3327);
            }
            /*UnicodeRange?*/ static _u0C80 = null;
            static /*UnicodeRange */ get Malayalam()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0D00 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0D00, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0D00 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0D00*/ 3328, /*\u0D7F*/ 3455);
            }
            /*UnicodeRange?*/ static _u0D00 = null;
            static /*UnicodeRange */ get Sinhala()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0D80 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0D80, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0D80 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0D80*/ 3456, /*\u0DFF*/ 3583);
            }
            /*UnicodeRange?*/ static _u0D80 = null;
            static /*UnicodeRange */ get Thai()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0E00 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0E00, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0E00 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0E00*/ 3584, /*\u0E7F*/ 3711);
            }
            /*UnicodeRange?*/ static _u0E00 = null;
            static /*UnicodeRange */ get Lao()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0E80 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0E80, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0E80 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0E80*/ 3712, /*\u0EFF*/ 3839);
            }
            /*UnicodeRange?*/ static _u0E80 = null;
            static /*UnicodeRange */ get Tibetan()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0F00 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0F00, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0F00 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0F00*/ 3840, /*\u0FFF*/ 4095);
            }
            /*UnicodeRange?*/ static _u0F00 = null;
            static /*UnicodeRange */ get Myanmar()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1000 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1000, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1000 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1000*/ 4096, /*\u109F*/ 4255);
            }
            /*UnicodeRange?*/ static _u1000 = null;
            static /*UnicodeRange */ get Georgian()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u10A0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u10A0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u10A0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u10A0*/ 4256, /*\u10FF*/ 4351);
            }
            /*UnicodeRange?*/ static _u10A0 = null;
            static /*UnicodeRange */ get HangulJamo()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1100 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1100, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1100 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1100*/ 4352, /*\u11FF*/ 4607);
            }
            /*UnicodeRange?*/ static _u1100 = null;
            static /*UnicodeRange */ get Ethiopic()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1200 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1200, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1200 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1200*/ 4608, /*\u137F*/ 4991);
            }
            /*UnicodeRange?*/ static _u1200 = null;
            static /*UnicodeRange */ get EthiopicSupplement()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1380 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1380, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1380 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1380*/ 4992, /*\u139F*/ 5023);
            }
            /*UnicodeRange?*/ static _u1380 = null;
            static /*UnicodeRange */ get Cherokee()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u13A0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u13A0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u13A0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u13A0*/ 5024, /*\u13FF*/ 5119);
            }
            /*UnicodeRange?*/ static _u13A0 = null;
            static /*UnicodeRange */ get UnifiedCanadianAboriginalSyllabics()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1400 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1400, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1400 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1400*/ 5120, /*\u167F*/ 5759);
            }
            /*UnicodeRange?*/ static _u1400 = null;
            static /*UnicodeRange */ get Ogham()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1680 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1680, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1680 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1680*/ 5760, /*\u169F*/ 5791);
            }
            /*UnicodeRange?*/ static _u1680 = null;
            static /*UnicodeRange */ get Runic()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u16A0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u16A0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u16A0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u16A0*/ 5792, /*\u16FF*/ 5887);
            }
            /*UnicodeRange?*/ static _u16A0 = null;
            static /*UnicodeRange */ get Tagalog()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1700 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1700, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1700 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1700*/ 5888, /*\u171F*/ 5919);
            }
            /*UnicodeRange?*/ static _u1700 = null;
            static /*UnicodeRange */ get Hanunoo()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1720 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1720, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1720 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1720*/ 5920, /*\u173F*/ 5951);
            }
            /*UnicodeRange?*/ static _u1720 = null;
            static /*UnicodeRange */ get Buhid()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1740 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1740, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1740 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1740*/ 5952, /*\u175F*/ 5983);
            }
            /*UnicodeRange?*/ static _u1740 = null;
            static /*UnicodeRange */ get Tagbanwa()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1760 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1760, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1760 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1760*/ 5984, /*\u177F*/ 6015);
            }
            /*UnicodeRange?*/ static _u1760 = null;
            static /*UnicodeRange */ get Khmer()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1780 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1780, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1780 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1780*/ 6016, /*\u17FF*/ 6143);
            }
            /*UnicodeRange?*/ static _u1780 = null;
            static /*UnicodeRange */ get Mongolian()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1800 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1800, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1800 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1800*/ 6144, /*\u18AF*/ 6319);
            }
            /*UnicodeRange?*/ static _u1800 = null;
            static /*UnicodeRange */ get UnifiedCanadianAboriginalSyllabicsExtended()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u18B0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u18B0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u18B0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u18B0*/ 6320, /*\u18FF*/ 6399);
            }
            /*UnicodeRange?*/ static _u18B0 = null;
            static /*UnicodeRange */ get Limbu()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1900 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1900, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1900 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1900*/ 6400, /*\u194F*/ 6479);
            }
            /*UnicodeRange?*/ static _u1900 = null;
            static /*UnicodeRange */ get TaiLe()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1950 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1950, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1950 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1950*/ 6480, /*\u197F*/ 6527);
            }
            /*UnicodeRange?*/ static _u1950 = null;
            static /*UnicodeRange */ get NewTaiLue()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1980 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1980, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1980 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1980*/ 6528, /*\u19DF*/ 6623);
            }
            /*UnicodeRange?*/ static _u1980 = null;
            static /*UnicodeRange */ get KhmerSymbols()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u19E0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u19E0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u19E0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u19E0*/ 6624, /*\u19FF*/ 6655);
            }
            /*UnicodeRange?*/ static _u19E0 = null;
            static /*UnicodeRange */ get Buginese()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1A00 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1A00, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1A00 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1A00*/ 6656, /*\u1A1F*/ 6687);
            }
            /*UnicodeRange?*/ static _u1A00 = null;
            static /*UnicodeRange */ get TaiTham()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1A20 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1A20, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1A20 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1A20*/ 6688, /*\u1AAF*/ 6831);
            }
            /*UnicodeRange?*/ static _u1A20 = null;
            static /*UnicodeRange */ get CombiningDiacriticalMarksExtended()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1AB0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1AB0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1AB0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1AB0*/ 6832, /*\u1AFF*/ 6911);
            }
            /*UnicodeRange?*/ static _u1AB0 = null;
            static /*UnicodeRange */ get Balinese()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1B00 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1B00, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1B00 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1B00*/ 6912, /*\u1B7F*/ 7039);
            }
            /*UnicodeRange?*/ static _u1B00 = null;
            static /*UnicodeRange */ get Sundanese()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1B80 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1B80, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1B80 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1B80*/ 7040, /*\u1BBF*/ 7103);
            }
            /*UnicodeRange?*/ static _u1B80 = null;
            static /*UnicodeRange */ get Batak()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1BC0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1BC0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1BC0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1BC0*/ 7104, /*\u1BFF*/ 7167);
            }
            /*UnicodeRange?*/ static _u1BC0 = null;
            static /*UnicodeRange */ get Lepcha()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1C00 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1C00, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1C00 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1C00*/ 7168, /*\u1C4F*/ 7247);
            }
            /*UnicodeRange?*/ static _u1C00 = null;
            static /*UnicodeRange */ get OlChiki()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1C50 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1C50, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1C50 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1C50*/ 7248, /*\u1C7F*/ 7295);
            }
            /*UnicodeRange?*/ static _u1C50 = null;
            static /*UnicodeRange */ get CyrillicExtendedC()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1C80 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1C80, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1C80 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1C80*/ 7296, /*\u1C8F*/ 7311);
            }
            /*UnicodeRange?*/ static _u1C80 = null;
            static /*UnicodeRange */ get GeorgianExtended()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1C90 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1C90, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1C90 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1C90*/ 7312, /*\u1CBF*/ 7359);
            }
            /*UnicodeRange?*/ static _u1C90 = null;
            static /*UnicodeRange */ get SundaneseSupplement()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1CC0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1CC0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1CC0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1CC0*/ 7360, /*\u1CCF*/ 7375);
            }
            /*UnicodeRange?*/ static _u1CC0 = null;
            static /*UnicodeRange */ get VedicExtensions()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1CD0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1CD0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1CD0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1CD0*/ 7376, /*\u1CFF*/ 7423);
            }
            /*UnicodeRange?*/ static _u1CD0 = null;
            static /*UnicodeRange */ get PhoneticExtensions()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1D00 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1D00, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1D00 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1D00*/ 7424, /*\u1D7F*/ 7551);
            }
            /*UnicodeRange?*/ static _u1D00 = null;
            static /*UnicodeRange */ get PhoneticExtensionsSupplement()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1D80 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1D80, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1D80 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1D80*/ 7552, /*\u1DBF*/ 7615);
            }
            /*UnicodeRange?*/ static _u1D80 = null;
            static /*UnicodeRange */ get CombiningDiacriticalMarksSupplement()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1DC0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1DC0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1DC0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1DC0*/ 7616, /*\u1DFF*/ 7679);
            }
            /*UnicodeRange?*/ static _u1DC0 = null;
            static /*UnicodeRange */ get LatinExtendedAdditional()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1E00 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1E00, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1E00 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1E00*/ 7680, /*\u1EFF*/ 7935);
            }
            /*UnicodeRange?*/ static _u1E00 = null;
            static /*UnicodeRange */ get GreekExtended()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1F00 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1F00, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1F00 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1F00*/ 7936, /*\u1FFF*/ 8191);
            }
            /*UnicodeRange?*/ static _u1F00 = null;
            static /*UnicodeRange */ get GeneralPunctuation()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u2000 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u2000, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u2000 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u2000*/ 8192, /*\u206F*/ 8303);
            }
            /*UnicodeRange?*/ static _u2000 = null;
            static /*UnicodeRange */ get SuperscriptsandSubscripts()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u2070 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u2070, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u2070 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u2070*/ 8304, /*\u209F*/ 8351);
            }
            /*UnicodeRange?*/ static _u2070 = null;
            static /*UnicodeRange */ get CurrencySymbols()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u20A0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u20A0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u20A0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u20A0*/ 8352, /*\u20CF*/ 8399);
            }
            /*UnicodeRange?*/ static _u20A0 = null;
            static /*UnicodeRange */ get CombiningDiacriticalMarksforSymbols()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u20D0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u20D0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u20D0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u20D0*/ 8400, /*\u20FF*/ 8447);
            }
            /*UnicodeRange?*/ static _u20D0 = null;
            static /*UnicodeRange */ get LetterlikeSymbols()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u2100 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u2100, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u2100 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u2100*/ 8448, /*\u214F*/ 8527);
            }
            /*UnicodeRange?*/ static _u2100 = null;
            static /*UnicodeRange */ get NumberForms()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u2150 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u2150, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u2150 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u2150*/ 8528, /*\u218F*/ 8591);
            }
            /*UnicodeRange?*/ static _u2150 = null;
            static /*UnicodeRange */ get Arrows()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u2190 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u2190, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u2190 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u2190*/ 8592, /*\u21FF*/ 8703);
            }
            /*UnicodeRange?*/ static _u2190 = null;
            static /*UnicodeRange */ get MathematicalOperators()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u2200 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u2200, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u2200 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u2200*/ 8704, /*\u22FF*/ 8959);
            }
            /*UnicodeRange?*/ static _u2200 = null;
            static /*UnicodeRange */ get MiscellaneousTechnical()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u2300 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u2300, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u2300 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u2300*/ 8960, /*\u23FF*/ 9215);
            }
            /*UnicodeRange?*/ static _u2300 = null;
            static /*UnicodeRange */ get ControlPictures()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u2400 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u2400, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u2400 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u2400*/ 9216, /*\u243F*/ 9279);
            }
            /*UnicodeRange?*/ static _u2400 = null;
            static /*UnicodeRange */ get OpticalCharacterRecognition()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u2440 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u2440, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u2440 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u2440*/ 9280, /*\u245F*/ 9311);
            }
            /*UnicodeRange?*/ static _u2440 = null;
            static /*UnicodeRange */ get EnclosedAlphanumerics()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u2460 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u2460, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u2460 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u2460*/ 9312, /*\u24FF*/ 9471);
            }
            /*UnicodeRange?*/ static _u2460 = null;
            static /*UnicodeRange */ get BoxDrawing()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u2500 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u2500, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u2500 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u2500*/ 9472, /*\u257F*/ 9599);
            }
            /*UnicodeRange?*/ static _u2500 = null;
            static /*UnicodeRange */ get BlockElements()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u2580 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u2580, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u2580 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u2580*/ 9600, /*\u259F*/ 9631);
            }
            /*UnicodeRange?*/ static _u2580 = null;
            static /*UnicodeRange */ get GeometricShapes()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u25A0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u25A0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u25A0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u25A0*/ 9632, /*\u25FF*/ 9727);
            }
            /*UnicodeRange?*/ static _u25A0 = null;
            static /*UnicodeRange */ get MiscellaneousSymbols()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u2600 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u2600, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u2600 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u2600*/ 9728, /*\u26FF*/ 9983);
            }
            /*UnicodeRange?*/ static _u2600 = null;
            static /*UnicodeRange */ get Dingbats()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u2700 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u2700, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u2700 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u2700*/ 9984, /*\u27BF*/ 10175);
            }
            /*UnicodeRange?*/ static _u2700 = null;
            static /*UnicodeRange */ get MiscellaneousMathematicalSymbolsA()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u27C0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u27C0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u27C0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u27C0*/ 10176, /*\u27EF*/ 10223);
            }
            /*UnicodeRange?*/ static _u27C0 = null;
            static /*UnicodeRange */ get SupplementalArrowsA()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u27F0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u27F0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u27F0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u27F0*/ 10224, /*\u27FF*/ 10239);
            }
            /*UnicodeRange?*/ static _u27F0 = null;
            static /*UnicodeRange */ get BraillePatterns()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u2800 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u2800, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u2800 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u2800*/ 10240, /*\u28FF*/ 10495);
            }
            /*UnicodeRange?*/ static _u2800 = null;
            static /*UnicodeRange */ get SupplementalArrowsB()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u2900 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u2900, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u2900 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u2900*/ 10496, /*\u297F*/ 10623);
            }
            /*UnicodeRange?*/ static _u2900 = null;
            static /*UnicodeRange */ get MiscellaneousMathematicalSymbolsB()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u2980 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u2980, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u2980 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u2980*/ 10624, /*\u29FF*/ 10751);
            }
            /*UnicodeRange?*/ static _u2980 = null;
            static /*UnicodeRange */ get SupplementalMathematicalOperators()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u2A00 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u2A00, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u2A00 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u2A00*/ 10752, /*\u2AFF*/ 11007);
            }
            /*UnicodeRange?*/ static _u2A00 = null;
            static /*UnicodeRange */ get MiscellaneousSymbolsandArrows()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u2B00 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u2B00, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u2B00 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u2B00*/ 11008, /*\u2BFF*/ 11263);
            }
            /*UnicodeRange?*/ static _u2B00 = null;
            static /*UnicodeRange */ get Glagolitic()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u2C00 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u2C00, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u2C00 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u2C00*/ 11264, /*\u2C5F*/ 11359);
            }
            /*UnicodeRange?*/ static _u2C00 = null;
            static /*UnicodeRange */ get LatinExtendedC()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u2C60 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u2C60, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u2C60 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u2C60*/ 11360, /*\u2C7F*/ 11391);
            }
            /*UnicodeRange?*/ static _u2C60 = null;
            static /*UnicodeRange */ get Coptic()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u2C80 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u2C80, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u2C80 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u2C80*/ 11392, /*\u2CFF*/ 11519);
            }
            /*UnicodeRange?*/ static _u2C80 = null;
            static /*UnicodeRange */ get GeorgianSupplement()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u2D00 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u2D00, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u2D00 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u2D00*/ 11520, /*\u2D2F*/ 11567);
            }
            /*UnicodeRange?*/ static _u2D00 = null;
            static /*UnicodeRange */ get Tifinagh()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u2D30 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u2D30, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u2D30 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u2D30*/ 11568, /*\u2D7F*/ 11647);
            }
            /*UnicodeRange?*/ static _u2D30 = null;
            static /*UnicodeRange */ get EthiopicExtended()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u2D80 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u2D80, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u2D80 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u2D80*/ 11648, /*\u2DDF*/ 11743);
            }
            /*UnicodeRange?*/ static _u2D80 = null;
            static /*UnicodeRange */ get CyrillicExtendedA()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u2DE0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u2DE0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u2DE0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u2DE0*/ 11744, /*\u2DFF*/ 11775);
            }
            /*UnicodeRange?*/ static _u2DE0 = null;
            static /*UnicodeRange */ get SupplementalPunctuation()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u2E00 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u2E00, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u2E00 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u2E00*/ 11776, /*\u2E7F*/ 11903);
            }
            /*UnicodeRange?*/ static _u2E00 = null;
            static /*UnicodeRange */ get CjkRadicalsSupplement()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u2E80 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u2E80, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u2E80 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u2E80*/ 11904, /*\u2EFF*/ 12031);
            }
            /*UnicodeRange?*/ static _u2E80 = null;
            static /*UnicodeRange */ get KangxiRadicals()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u2F00 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u2F00, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u2F00 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u2F00*/ 12032, /*\u2FDF*/ 12255);
            }
            /*UnicodeRange?*/ static _u2F00 = null;
            static /*UnicodeRange */ get IdeographicDescriptionCharacters()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u2FF0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u2FF0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u2FF0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u2FF0*/ 12272, /*\u2FFF*/ 12287);
            }
            /*UnicodeRange?*/ static _u2FF0 = null;
            static /*UnicodeRange */ get CjkSymbolsandPunctuation()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u3000 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u3000, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u3000 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u3000*/ 12288, /*\u303F*/ 12351);
            }
            /*UnicodeRange?*/ static _u3000 = null;
            static /*UnicodeRange */ get Hiragana()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u3040 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u3040, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u3040 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u3040*/ 12352, /*\u309F*/ 12447);
            }
            /*UnicodeRange?*/ static _u3040 = null;
            static /*UnicodeRange */ get Katakana()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u30A0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u30A0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u30A0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u30A0*/ 12448, /*\u30FF*/ 12543);
            }
            /*UnicodeRange?*/ static _u30A0 = null;
            static /*UnicodeRange */ get Bopomofo()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u3100 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u3100, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u3100 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u3100*/ 12544, /*\u312F*/ 12591);
            }
            /*UnicodeRange?*/ static _u3100 = null;
            static /*UnicodeRange */ get HangulCompatibilityJamo()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u3130 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u3130, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u3130 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u3130*/ 12592, /*\u318F*/ 12687);
            }
            /*UnicodeRange?*/ static _u3130 = null;
            static /*UnicodeRange */ get Kanbun()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u3190 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u3190, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u3190 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u3190*/ 12688, /*\u319F*/ 12703);
            }
            /*UnicodeRange?*/ static _u3190 = null;
            static /*UnicodeRange */ get BopomofoExtended()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u31A0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u31A0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u31A0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u31A0*/ 12704, /*\u31BF*/ 12735);
            }
            /*UnicodeRange?*/ static _u31A0 = null;
            static /*UnicodeRange */ get CjkStrokes()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u31C0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u31C0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u31C0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u31C0*/ 12736, /*\u31EF*/ 12783);
            }
            /*UnicodeRange?*/ static _u31C0 = null;
            static /*UnicodeRange */ get KatakanaPhoneticExtensions()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u31F0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u31F0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u31F0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u31F0*/ 12784, /*\u31FF*/ 12799);
            }
            /*UnicodeRange?*/ static _u31F0 = null;
            static /*UnicodeRange */ get EnclosedCjkLettersandMonths()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u3200 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u3200, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u3200 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u3200*/ 12800, /*\u32FF*/ 13055);
            }
            /*UnicodeRange?*/ static _u3200 = null;
            static /*UnicodeRange */ get CjkCompatibility()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u3300 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u3300, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u3300 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u3300*/ 13056, /*\u33FF*/ 13311);
            }
            /*UnicodeRange?*/ static _u3300 = null;
            static /*UnicodeRange */ get CjkUnifiedIdeographsExtensionA()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u3400 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u3400, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u3400 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u3400*/ 13312, /*\u4DBF*/ 19903);
            }
            /*UnicodeRange?*/ static _u3400 = null;
            static /*UnicodeRange */ get YijingHexagramSymbols()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u4DC0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u4DC0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u4DC0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u4DC0*/ 19904, /*\u4DFF*/ 19967);
            }
            /*UnicodeRange?*/ static _u4DC0 = null;
            static /*UnicodeRange */ get CjkUnifiedIdeographs()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u4E00 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u4E00, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u4E00 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u4E00*/ 19968, /*\u9FFF*/ 40959);
            }
            /*UnicodeRange?*/ static _u4E00 = null;
            static /*UnicodeRange */ get YiSyllables()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uA000 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uA000, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uA000 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uA000*/ 40960, /*\uA48F*/ 42127);
            }
            /*UnicodeRange?*/ static _uA000 = null;
            static /*UnicodeRange */ get YiRadicals()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uA490 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uA490, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uA490 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uA490*/ 42128, /*\uA4CF*/ 42191);
            }
            /*UnicodeRange?*/ static _uA490 = null;
            static /*UnicodeRange */ get Lisu()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uA4D0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uA4D0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uA4D0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uA4D0*/ 42192, /*\uA4FF*/ 42239);
            }
            /*UnicodeRange?*/ static _uA4D0 = null;
            static /*UnicodeRange */ get Vai()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uA500 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uA500, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uA500 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uA500*/ 42240, /*\uA63F*/ 42559);
            }
            /*UnicodeRange?*/ static _uA500 = null;
            static /*UnicodeRange */ get CyrillicExtendedB()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uA640 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uA640, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uA640 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uA640*/ 42560, /*\uA69F*/ 42655);
            }
            /*UnicodeRange?*/ static _uA640 = null;
            static /*UnicodeRange */ get Bamum()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uA6A0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uA6A0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uA6A0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uA6A0*/ 42656, /*\uA6FF*/ 42751);
            }
            /*UnicodeRange?*/ static _uA6A0 = null;
            static /*UnicodeRange */ get ModifierToneLetters()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uA700 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uA700, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uA700 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uA700*/ 42752, /*\uA71F*/ 42783);
            }
            /*UnicodeRange?*/ static _uA700 = null;
            static /*UnicodeRange */ get LatinExtendedD()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uA720 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uA720, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uA720 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uA720*/ 42784, /*\uA7FF*/ 43007);
            }
            /*UnicodeRange?*/ static _uA720 = null;
            static /*UnicodeRange */ get SylotiNagri()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uA800 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uA800, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uA800 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uA800*/ 43008, /*\uA82F*/ 43055);
            }
            /*UnicodeRange?*/ static _uA800 = null;
            static /*UnicodeRange */ get CommonIndicNumberForms()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uA830 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uA830, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uA830 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uA830*/ 43056, /*\uA83F*/ 43071);
            }
            /*UnicodeRange?*/ static _uA830 = null;
            static /*UnicodeRange */ get Phagspa()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uA840 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uA840, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uA840 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uA840*/ 43072, /*\uA87F*/ 43135);
            }
            /*UnicodeRange?*/ static _uA840 = null;
            static /*UnicodeRange */ get Saurashtra()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uA880 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uA880, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uA880 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uA880*/ 43136, /*\uA8DF*/ 43231);
            }
            /*UnicodeRange?*/ static _uA880 = null;
            static /*UnicodeRange */ get DevanagariExtended()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uA8E0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uA8E0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uA8E0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uA8E0*/ 43232, /*\uA8FF*/ 43263);
            }
            /*UnicodeRange?*/ static _uA8E0 = null;
            static /*UnicodeRange */ get KayahLi()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uA900 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uA900, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uA900 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uA900*/ 43264, /*\uA92F*/ 43311);
            }
            /*UnicodeRange?*/ static _uA900 = null;
            static /*UnicodeRange */ get Rejang()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uA930 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uA930, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uA930 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uA930*/ 43312, /*\uA95F*/ 43359);
            }
            /*UnicodeRange?*/ static _uA930 = null;
            static /*UnicodeRange */ get HangulJamoExtendedA()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uA960 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uA960, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uA960 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uA960*/ 43360, /*\uA97F*/ 43391);
            }
            /*UnicodeRange?*/ static _uA960 = null;
            static /*UnicodeRange */ get Javanese()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uA980 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uA980, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uA980 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uA980*/ 43392, /*\uA9DF*/ 43487);
            }
            /*UnicodeRange?*/ static _uA980 = null;
            static /*UnicodeRange */ get MyanmarExtendedB()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uA9E0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uA9E0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uA9E0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uA9E0*/ 43488, /*\uA9FF*/ 43519);
            }
            /*UnicodeRange?*/ static _uA9E0 = null;
            static /*UnicodeRange */ get Cham()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uAA00 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uAA00, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uAA00 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uAA00*/ 43520, /*\uAA5F*/ 43615);
            }
            /*UnicodeRange?*/ static _uAA00 = null;
            static /*UnicodeRange */ get MyanmarExtendedA()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uAA60 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uAA60, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uAA60 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uAA60*/ 43616, /*\uAA7F*/ 43647);
            }
            /*UnicodeRange?*/ static _uAA60 = null;
            static /*UnicodeRange */ get TaiViet()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uAA80 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uAA80, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uAA80 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uAA80*/ 43648, /*\uAADF*/ 43743);
            }
            /*UnicodeRange?*/ static _uAA80 = null;
            static /*UnicodeRange */ get MeeteiMayekExtensions()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uAAE0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uAAE0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uAAE0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uAAE0*/ 43744, /*\uAAFF*/ 43775);
            }
            /*UnicodeRange?*/ static _uAAE0 = null;
            static /*UnicodeRange */ get EthiopicExtendedA()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uAB00 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uAB00, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uAB00 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uAB00*/ 43776, /*\uAB2F*/ 43823);
            }
            /*UnicodeRange?*/ static _uAB00 = null;
            static /*UnicodeRange */ get LatinExtendedE()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uAB30 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uAB30, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uAB30 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uAB30*/ 43824, /*\uAB6F*/ 43887);
            }
            /*UnicodeRange?*/ static _uAB30 = null;
            static /*UnicodeRange */ get CherokeeSupplement()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uAB70 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uAB70, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uAB70 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uAB70*/ 43888, /*\uABBF*/ 43967);
            }
            /*UnicodeRange?*/ static _uAB70 = null;
            static /*UnicodeRange */ get MeeteiMayek()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uABC0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uABC0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uABC0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uABC0*/ 43968, /*\uABFF*/ 44031);
            }
            /*UnicodeRange?*/ static _uABC0 = null;
            static /*UnicodeRange */ get HangulSyllables()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uAC00 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uAC00, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uAC00 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uAC00*/ 44032, /*\uD7AF*/ 55215);
            }
            /*UnicodeRange?*/ static _uAC00 = null;
            static /*UnicodeRange */ get HangulJamoExtendedB()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uD7B0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uD7B0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uD7B0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uD7B0*/ 55216, /*\uD7FF*/ 55295);
            }
            /*UnicodeRange?*/ static _uD7B0 = null;
            static /*UnicodeRange */ get CjkCompatibilityIdeographs()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uF900 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uF900, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uF900 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uF900*/ 63744, /*\uFAFF*/ 64255);
            }
            /*UnicodeRange?*/ static _uF900 = null;
            static /*UnicodeRange */ get AlphabeticPresentationForms()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uFB00 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uFB00, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uFB00 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uFB00*/ 64256, /*\uFB4F*/ 64335);
            }
            /*UnicodeRange?*/ static _uFB00 = null;
            static /*UnicodeRange */ get ArabicPresentationFormsA()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uFB50 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uFB50, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uFB50 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uFB50*/ 64336, /*\uFDFF*/ 65023);
            }
            /*UnicodeRange?*/ static _uFB50 = null;
            static /*UnicodeRange */ get VariationSelectors()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uFE00 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uFE00, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uFE00 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uFE00*/ 65024, /*\uFE0F*/ 65039);
            }
            /*UnicodeRange?*/ static _uFE00 = null;
            static /*UnicodeRange */ get VerticalForms()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uFE10 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uFE10, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uFE10 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uFE10*/ 65040, /*\uFE1F*/ 65055);
            }
            /*UnicodeRange?*/ static _uFE10 = null;
            static /*UnicodeRange */ get CombiningHalfMarks()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uFE20 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uFE20, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uFE20 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uFE20*/ 65056, /*\uFE2F*/ 65071);
            }
            /*UnicodeRange?*/ static _uFE20 = null;
            static /*UnicodeRange */ get CjkCompatibilityForms()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uFE30 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uFE30, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uFE30 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uFE30*/ 65072, /*\uFE4F*/ 65103);
            }
            /*UnicodeRange?*/ static _uFE30 = null;
            static /*UnicodeRange */ get SmallFormVariants()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uFE50 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uFE50, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uFE50 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uFE50*/ 65104, /*\uFE6F*/ 65135);
            }
            /*UnicodeRange?*/ static _uFE50 = null;
            static /*UnicodeRange */ get ArabicPresentationFormsB()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uFE70 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uFE70, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uFE70 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uFE70*/ 65136, /*\uFEFF*/ 65279);
            }
            /*UnicodeRange?*/ static _uFE70 = null;
            static /*UnicodeRange */ get HalfwidthandFullwidthForms()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uFF00 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uFF00, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uFF00 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uFF00*/ 65280, /*\uFFEF*/ 65519);
            }
            /*UnicodeRange?*/ static _uFF00 = null;
            static /*UnicodeRange */ get Specials()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uFFF0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uFFF0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uFFF0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uFFF0*/ 65520, /*\uFFFF*/ 65535);
            }
            /*UnicodeRange?*/ static _uFFF0 = null;
            static $h = 1894821;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1829285,"g":{"r":0,"d":0,"h":8591829413,"f":50331681},"n":"None","d":1894821,"h":4296862117,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":21476731301,"f":50331681},"n":"All","d":1894821,"h":17181764005,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":42951567781,"f":50331681},"n":"BasicLatin","d":1894821,"h":38656600485,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":55836469669,"f":50331681},"n":"Latin1Supplement","d":1894821,"h":51541502373,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":68721371557,"f":50331681},"n":"LatinExtendedA","d":1894821,"h":64426404261,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":81606273445,"f":50331681},"n":"LatinExtendedB","d":1894821,"h":77311306149,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":94491175333,"f":50331681},"n":"IpaExtensions","d":1894821,"h":90196208037,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":107376077221,"f":50331681},"n":"SpacingModifierLetters","d":1894821,"h":103081109925,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":120260979109,"f":50331681},"n":"CombiningDiacriticalMarks","d":1894821,"h":115966011813,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":133145880997,"f":50331681},"n":"GreekandCoptic","d":1894821,"h":128850913701,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":146030782885,"f":50331681},"n":"Cyrillic","d":1894821,"h":141735815589,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":158915684773,"f":50331681},"n":"CyrillicSupplement","d":1894821,"h":154620717477,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":171800586661,"f":50331681},"n":"Armenian","d":1894821,"h":167505619365,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":184685488549,"f":50331681},"n":"Hebrew","d":1894821,"h":180390521253,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":197570390437,"f":50331681},"n":"Arabic","d":1894821,"h":193275423141,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":210455292325,"f":50331681},"n":"Syriac","d":1894821,"h":206160325029,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":223340194213,"f":50331681},"n":"ArabicSupplement","d":1894821,"h":219045226917,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":236225096101,"f":50331681},"n":"Thaana","d":1894821,"h":231930128805,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":249109997989,"f":50331681},"n":"NKo","d":1894821,"h":244815030693,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":261994899877,"f":50331681},"n":"Samaritan","d":1894821,"h":257699932581,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":274879801765,"f":50331681},"n":"Mandaic","d":1894821,"h":270584834469,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":287764703653,"f":50331681},"n":"SyriacSupplement","d":1894821,"h":283469736357,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":300649605541,"f":50331681},"n":"ArabicExtendedB","d":1894821,"h":296354638245,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":313534507429,"f":50331681},"n":"ArabicExtendedA","d":1894821,"h":309239540133,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":326419409317,"f":50331681},"n":"Devanagari","d":1894821,"h":322124442021,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":339304311205,"f":50331681},"n":"Bengali","d":1894821,"h":335009343909,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":352189213093,"f":50331681},"n":"Gurmukhi","d":1894821,"h":347894245797,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":365074114981,"f":50331681},"n":"Gujarati","d":1894821,"h":360779147685,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":377959016869,"f":50331681},"n":"Oriya","d":1894821,"h":373664049573,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":390843918757,"f":50331681},"n":"Tamil","d":1894821,"h":386548951461,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":403728820645,"f":50331681},"n":"Telugu","d":1894821,"h":399433853349,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":416613722533,"f":50331681},"n":"Kannada","d":1894821,"h":412318755237,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":429498624421,"f":50331681},"n":"Malayalam","d":1894821,"h":425203657125,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":442383526309,"f":50331681},"n":"Sinhala","d":1894821,"h":438088559013,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":455268428197,"f":50331681},"n":"Thai","d":1894821,"h":450973460901,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":468153330085,"f":50331681},"n":"Lao","d":1894821,"h":463858362789,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":481038231973,"f":50331681},"n":"Tibetan","d":1894821,"h":476743264677,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":493923133861,"f":50331681},"n":"Myanmar","d":1894821,"h":489628166565,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":506808035749,"f":50331681},"n":"Georgian","d":1894821,"h":502513068453,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":519692937637,"f":50331681},"n":"HangulJamo","d":1894821,"h":515397970341,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":532577839525,"f":50331681},"n":"Ethiopic","d":1894821,"h":528282872229,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":545462741413,"f":50331681},"n":"EthiopicSupplement","d":1894821,"h":541167774117,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":558347643301,"f":50331681},"n":"Cherokee","d":1894821,"h":554052676005,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":571232545189,"f":50331681},"n":"UnifiedCanadianAboriginalSyllabics","d":1894821,"h":566937577893,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":584117447077,"f":50331681},"n":"Ogham","d":1894821,"h":579822479781,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":597002348965,"f":50331681},"n":"Runic","d":1894821,"h":592707381669,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":609887250853,"f":50331681},"n":"Tagalog","d":1894821,"h":605592283557,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":622772152741,"f":50331681},"n":"Hanunoo","d":1894821,"h":618477185445,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":635657054629,"f":50331681},"n":"Buhid","d":1894821,"h":631362087333,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":648541956517,"f":50331681},"n":"Tagbanwa","d":1894821,"h":644246989221,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":661426858405,"f":50331681},"n":"Khmer","d":1894821,"h":657131891109,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":674311760293,"f":50331681},"n":"Mongolian","d":1894821,"h":670016792997,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":687196662181,"f":50331681},"n":"UnifiedCanadianAboriginalSyllabicsExtended","d":1894821,"h":682901694885,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":700081564069,"f":50331681},"n":"Limbu","d":1894821,"h":695786596773,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":712966465957,"f":50331681},"n":"TaiLe","d":1894821,"h":708671498661,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":725851367845,"f":50331681},"n":"NewTaiLue","d":1894821,"h":721556400549,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":738736269733,"f":50331681},"n":"KhmerSymbols","d":1894821,"h":734441302437,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":751621171621,"f":50331681},"n":"Buginese","d":1894821,"h":747326204325,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":764506073509,"f":50331681},"n":"TaiTham","d":1894821,"h":760211106213,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":777390975397,"f":50331681},"n":"CombiningDiacriticalMarksExtended","d":1894821,"h":773096008101,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":790275877285,"f":50331681},"n":"Balinese","d":1894821,"h":785980909989,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":803160779173,"f":50331681},"n":"Sundanese","d":1894821,"h":798865811877,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":816045681061,"f":50331681},"n":"Batak","d":1894821,"h":811750713765,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":828930582949,"f":50331681},"n":"Lepcha","d":1894821,"h":824635615653,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":841815484837,"f":50331681},"n":"OlChiki","d":1894821,"h":837520517541,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":854700386725,"f":50331681},"n":"CyrillicExtendedC","d":1894821,"h":850405419429,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":867585288613,"f":50331681},"n":"GeorgianExtended","d":1894821,"h":863290321317,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":880470190501,"f":50331681},"n":"SundaneseSupplement","d":1894821,"h":876175223205,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":893355092389,"f":50331681},"n":"VedicExtensions","d":1894821,"h":889060125093,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":906239994277,"f":50331681},"n":"PhoneticExtensions","d":1894821,"h":901945026981,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":919124896165,"f":50331681},"n":"PhoneticExtensionsSupplement","d":1894821,"h":914829928869,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":932009798053,"f":50331681},"n":"CombiningDiacriticalMarksSupplement","d":1894821,"h":927714830757,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":944894699941,"f":50331681},"n":"LatinExtendedAdditional","d":1894821,"h":940599732645,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":957779601829,"f":50331681},"n":"GreekExtended","d":1894821,"h":953484634533,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":970664503717,"f":50331681},"n":"GeneralPunctuation","d":1894821,"h":966369536421,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":983549405605,"f":50331681},"n":"SuperscriptsandSubscripts","d":1894821,"h":979254438309,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":996434307493,"f":50331681},"n":"CurrencySymbols","d":1894821,"h":992139340197,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1009319209381,"f":50331681},"n":"CombiningDiacriticalMarksforSymbols","d":1894821,"h":1005024242085,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1022204111269,"f":50331681},"n":"LetterlikeSymbols","d":1894821,"h":1017909143973,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1035089013157,"f":50331681},"n":"NumberForms","d":1894821,"h":1030794045861,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1047973915045,"f":50331681},"n":"Arrows","d":1894821,"h":1043678947749,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1060858816933,"f":50331681},"n":"MathematicalOperators","d":1894821,"h":1056563849637,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1073743718821,"f":50331681},"n":"MiscellaneousTechnical","d":1894821,"h":1069448751525,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1086628620709,"f":50331681},"n":"ControlPictures","d":1894821,"h":1082333653413,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1099513522597,"f":50331681},"n":"OpticalCharacterRecognition","d":1894821,"h":1095218555301,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1112398424485,"f":50331681},"n":"EnclosedAlphanumerics","d":1894821,"h":1108103457189,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1125283326373,"f":50331681},"n":"BoxDrawing","d":1894821,"h":1120988359077,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1138168228261,"f":50331681},"n":"BlockElements","d":1894821,"h":1133873260965,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1151053130149,"f":50331681},"n":"GeometricShapes","d":1894821,"h":1146758162853,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1163938032037,"f":50331681},"n":"MiscellaneousSymbols","d":1894821,"h":1159643064741,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1176822933925,"f":50331681},"n":"Dingbats","d":1894821,"h":1172527966629,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1189707835813,"f":50331681},"n":"MiscellaneousMathematicalSymbolsA","d":1894821,"h":1185412868517,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1202592737701,"f":50331681},"n":"SupplementalArrowsA","d":1894821,"h":1198297770405,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1215477639589,"f":50331681},"n":"BraillePatterns","d":1894821,"h":1211182672293,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1228362541477,"f":50331681},"n":"SupplementalArrowsB","d":1894821,"h":1224067574181,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1241247443365,"f":50331681},"n":"MiscellaneousMathematicalSymbolsB","d":1894821,"h":1236952476069,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1254132345253,"f":50331681},"n":"SupplementalMathematicalOperators","d":1894821,"h":1249837377957,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1267017247141,"f":50331681},"n":"MiscellaneousSymbolsandArrows","d":1894821,"h":1262722279845,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1279902149029,"f":50331681},"n":"Glagolitic","d":1894821,"h":1275607181733,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1292787050917,"f":50331681},"n":"LatinExtendedC","d":1894821,"h":1288492083621,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1305671952805,"f":50331681},"n":"Coptic","d":1894821,"h":1301376985509,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1318556854693,"f":50331681},"n":"GeorgianSupplement","d":1894821,"h":1314261887397,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1331441756581,"f":50331681},"n":"Tifinagh","d":1894821,"h":1327146789285,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1344326658469,"f":50331681},"n":"EthiopicExtended","d":1894821,"h":1340031691173,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1357211560357,"f":50331681},"n":"CyrillicExtendedA","d":1894821,"h":1352916593061,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1370096462245,"f":50331681},"n":"SupplementalPunctuation","d":1894821,"h":1365801494949,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1382981364133,"f":50331681},"n":"CjkRadicalsSupplement","d":1894821,"h":1378686396837,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1395866266021,"f":50331681},"n":"KangxiRadicals","d":1894821,"h":1391571298725,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1408751167909,"f":50331681},"n":"IdeographicDescriptionCharacters","d":1894821,"h":1404456200613,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1421636069797,"f":50331681},"n":"CjkSymbolsandPunctuation","d":1894821,"h":1417341102501,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1434520971685,"f":50331681},"n":"Hiragana","d":1894821,"h":1430226004389,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1447405873573,"f":50331681},"n":"Katakana","d":1894821,"h":1443110906277,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1460290775461,"f":50331681},"n":"Bopomofo","d":1894821,"h":1455995808165,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1473175677349,"f":50331681},"n":"HangulCompatibilityJamo","d":1894821,"h":1468880710053,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1486060579237,"f":50331681},"n":"Kanbun","d":1894821,"h":1481765611941,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1498945481125,"f":50331681},"n":"BopomofoExtended","d":1894821,"h":1494650513829,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1511830383013,"f":50331681},"n":"CjkStrokes","d":1894821,"h":1507535415717,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1524715284901,"f":50331681},"n":"KatakanaPhoneticExtensions","d":1894821,"h":1520420317605,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1537600186789,"f":50331681},"n":"EnclosedCjkLettersandMonths","d":1894821,"h":1533305219493,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1550485088677,"f":50331681},"n":"CjkCompatibility","d":1894821,"h":1546190121381,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1563369990565,"f":50331681},"n":"CjkUnifiedIdeographsExtensionA","d":1894821,"h":1559075023269,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1576254892453,"f":50331681},"n":"YijingHexagramSymbols","d":1894821,"h":1571959925157,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1589139794341,"f":50331681},"n":"CjkUnifiedIdeographs","d":1894821,"h":1584844827045,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1602024696229,"f":50331681},"n":"YiSyllables","d":1894821,"h":1597729728933,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1614909598117,"f":50331681},"n":"YiRadicals","d":1894821,"h":1610614630821,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1627794500005,"f":50331681},"n":"Lisu","d":1894821,"h":1623499532709,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1640679401893,"f":50331681},"n":"Vai","d":1894821,"h":1636384434597,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1653564303781,"f":50331681},"n":"CyrillicExtendedB","d":1894821,"h":1649269336485,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1666449205669,"f":50331681},"n":"Bamum","d":1894821,"h":1662154238373,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1679334107557,"f":50331681},"n":"ModifierToneLetters","d":1894821,"h":1675039140261,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1692219009445,"f":50331681},"n":"LatinExtendedD","d":1894821,"h":1687924042149,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1705103911333,"f":50331681},"n":"SylotiNagri","d":1894821,"h":1700808944037,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1717988813221,"f":50331681},"n":"CommonIndicNumberForms","d":1894821,"h":1713693845925,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1730873715109,"f":50331681},"n":"Phagspa","d":1894821,"h":1726578747813,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1743758616997,"f":50331681},"n":"Saurashtra","d":1894821,"h":1739463649701,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1756643518885,"f":50331681},"n":"DevanagariExtended","d":1894821,"h":1752348551589,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1769528420773,"f":50331681},"n":"KayahLi","d":1894821,"h":1765233453477,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1782413322661,"f":50331681},"n":"Rejang","d":1894821,"h":1778118355365,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1795298224549,"f":50331681},"n":"HangulJamoExtendedA","d":1894821,"h":1791003257253,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1808183126437,"f":50331681},"n":"Javanese","d":1894821,"h":1803888159141,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1821068028325,"f":50331681},"n":"MyanmarExtendedB","d":1894821,"h":1816773061029,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1833952930213,"f":50331681},"n":"Cham","d":1894821,"h":1829657962917,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1846837832101,"f":50331681},"n":"MyanmarExtendedA","d":1894821,"h":1842542864805,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1859722733989,"f":50331681},"n":"TaiViet","d":1894821,"h":1855427766693,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1872607635877,"f":50331681},"n":"MeeteiMayekExtensions","d":1894821,"h":1868312668581,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1885492537765,"f":50331681},"n":"EthiopicExtendedA","d":1894821,"h":1881197570469,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1898377439653,"f":50331681},"n":"LatinExtendedE","d":1894821,"h":1894082472357,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1911262341541,"f":50331681},"n":"CherokeeSupplement","d":1894821,"h":1906967374245,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1924147243429,"f":50331681},"n":"MeeteiMayek","d":1894821,"h":1919852276133,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1937032145317,"f":50331681},"n":"HangulSyllables","d":1894821,"h":1932737178021,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1949917047205,"f":50331681},"n":"HangulJamoExtendedB","d":1894821,"h":1945622079909,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1962801949093,"f":50331681},"n":"CjkCompatibilityIdeographs","d":1894821,"h":1958506981797,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1975686850981,"f":50331681},"n":"AlphabeticPresentationForms","d":1894821,"h":1971391883685,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":1988571752869,"f":50331681},"n":"ArabicPresentationFormsA","d":1894821,"h":1984276785573,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":2001456654757,"f":50331681},"n":"VariationSelectors","d":1894821,"h":1997161687461,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":2014341556645,"f":50331681},"n":"VerticalForms","d":1894821,"h":2010046589349,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":2027226458533,"f":50331681},"n":"CombiningHalfMarks","d":1894821,"h":2022931491237,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":2040111360421,"f":50331681},"n":"CjkCompatibilityForms","d":1894821,"h":2035816393125,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":2052996262309,"f":50331681},"n":"SmallFormVariants","d":1894821,"h":2048701295013,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":2065881164197,"f":50331681},"n":"ArabicPresentationFormsB","d":1894821,"h":2061586196901,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":2078766066085,"f":50331681},"n":"HalfwidthandFullwidthForms","d":1894821,"h":2074471098789,"f":2097185},{"p":1829285,"g":{"r":0,"d":0,"h":2091650967973,"f":50331681},"n":"Specials","d":1894821,"h":2087356000677,"f":2097185}],"m":[{"r":1829285,"p":[{"n":"range","p":1829285,"f":4}],"n":"CreateEmptyRange","d":1894821,"h":30066665893,"f":16777250},{"r":1829285,"p":[{"n":"range","p":1829285,"f":4},{"n":"first","p":458753},{"n":"last","p":458753}],"n":"CreateRange","d":1894821,"h":34361633189,"f":16777250}],"l":[{"t":1829285,"n":"_none","d":1894821,"h":12886796709,"f":4194338},{"t":1829285,"n":"_all","d":1894821,"h":25771698597,"f":4194338},{"t":1829285,"n":"_u0000","d":1894821,"h":47246535077,"f":4194338},{"t":1829285,"n":"_u0080","d":1894821,"h":60131436965,"f":4194338},{"t":1829285,"n":"_u0100","d":1894821,"h":73016338853,"f":4194338},{"t":1829285,"n":"_u0180","d":1894821,"h":85901240741,"f":4194338},{"t":1829285,"n":"_u0250","d":1894821,"h":98786142629,"f":4194338},{"t":1829285,"n":"_u02B0","d":1894821,"h":111671044517,"f":4194338},{"t":1829285,"n":"_u0300","d":1894821,"h":124555946405,"f":4194338},{"t":1829285,"n":"_u0370","d":1894821,"h":137440848293,"f":4194338},{"t":1829285,"n":"_u0400","d":1894821,"h":150325750181,"f":4194338},{"t":1829285,"n":"_u0500","d":1894821,"h":163210652069,"f":4194338},{"t":1829285,"n":"_u0530","d":1894821,"h":176095553957,"f":4194338},{"t":1829285,"n":"_u0590","d":1894821,"h":188980455845,"f":4194338},{"t":1829285,"n":"_u0600","d":1894821,"h":201865357733,"f":4194338},{"t":1829285,"n":"_u0700","d":1894821,"h":214750259621,"f":4194338},{"t":1829285,"n":"_u0750","d":1894821,"h":227635161509,"f":4194338},{"t":1829285,"n":"_u0780","d":1894821,"h":240520063397,"f":4194338},{"t":1829285,"n":"_u07C0","d":1894821,"h":253404965285,"f":4194338},{"t":1829285,"n":"_u0800","d":1894821,"h":266289867173,"f":4194338},{"t":1829285,"n":"_u0840","d":1894821,"h":279174769061,"f":4194338},{"t":1829285,"n":"_u0860","d":1894821,"h":292059670949,"f":4194338},{"t":1829285,"n":"_u0870","d":1894821,"h":304944572837,"f":4194338},{"t":1829285,"n":"_u08A0","d":1894821,"h":317829474725,"f":4194338},{"t":1829285,"n":"_u0900","d":1894821,"h":330714376613,"f":4194338},{"t":1829285,"n":"_u0980","d":1894821,"h":343599278501,"f":4194338},{"t":1829285,"n":"_u0A00","d":1894821,"h":356484180389,"f":4194338},{"t":1829285,"n":"_u0A80","d":1894821,"h":369369082277,"f":4194338},{"t":1829285,"n":"_u0B00","d":1894821,"h":382253984165,"f":4194338},{"t":1829285,"n":"_u0B80","d":1894821,"h":395138886053,"f":4194338},{"t":1829285,"n":"_u0C00","d":1894821,"h":408023787941,"f":4194338},{"t":1829285,"n":"_u0C80","d":1894821,"h":420908689829,"f":4194338},{"t":1829285,"n":"_u0D00","d":1894821,"h":433793591717,"f":4194338},{"t":1829285,"n":"_u0D80","d":1894821,"h":446678493605,"f":4194338},{"t":1829285,"n":"_u0E00","d":1894821,"h":459563395493,"f":4194338},{"t":1829285,"n":"_u0E80","d":1894821,"h":472448297381,"f":4194338},{"t":1829285,"n":"_u0F00","d":1894821,"h":485333199269,"f":4194338},{"t":1829285,"n":"_u1000","d":1894821,"h":498218101157,"f":4194338},{"t":1829285,"n":"_u10A0","d":1894821,"h":511103003045,"f":4194338},{"t":1829285,"n":"_u1100","d":1894821,"h":523987904933,"f":4194338},{"t":1829285,"n":"_u1200","d":1894821,"h":536872806821,"f":4194338},{"t":1829285,"n":"_u1380","d":1894821,"h":549757708709,"f":4194338},{"t":1829285,"n":"_u13A0","d":1894821,"h":562642610597,"f":4194338},{"t":1829285,"n":"_u1400","d":1894821,"h":575527512485,"f":4194338},{"t":1829285,"n":"_u1680","d":1894821,"h":588412414373,"f":4194338},{"t":1829285,"n":"_u16A0","d":1894821,"h":601297316261,"f":4194338},{"t":1829285,"n":"_u1700","d":1894821,"h":614182218149,"f":4194338},{"t":1829285,"n":"_u1720","d":1894821,"h":627067120037,"f":4194338},{"t":1829285,"n":"_u1740","d":1894821,"h":639952021925,"f":4194338},{"t":1829285,"n":"_u1760","d":1894821,"h":652836923813,"f":4194338},{"t":1829285,"n":"_u1780","d":1894821,"h":665721825701,"f":4194338},{"t":1829285,"n":"_u1800","d":1894821,"h":678606727589,"f":4194338},{"t":1829285,"n":"_u18B0","d":1894821,"h":691491629477,"f":4194338},{"t":1829285,"n":"_u1900","d":1894821,"h":704376531365,"f":4194338},{"t":1829285,"n":"_u1950","d":1894821,"h":717261433253,"f":4194338},{"t":1829285,"n":"_u1980","d":1894821,"h":730146335141,"f":4194338},{"t":1829285,"n":"_u19E0","d":1894821,"h":743031237029,"f":4194338},{"t":1829285,"n":"_u1A00","d":1894821,"h":755916138917,"f":4194338},{"t":1829285,"n":"_u1A20","d":1894821,"h":768801040805,"f":4194338},{"t":1829285,"n":"_u1AB0","d":1894821,"h":781685942693,"f":4194338},{"t":1829285,"n":"_u1B00","d":1894821,"h":794570844581,"f":4194338},{"t":1829285,"n":"_u1B80","d":1894821,"h":807455746469,"f":4194338},{"t":1829285,"n":"_u1BC0","d":1894821,"h":820340648357,"f":4194338},{"t":1829285,"n":"_u1C00","d":1894821,"h":833225550245,"f":4194338},{"t":1829285,"n":"_u1C50","d":1894821,"h":846110452133,"f":4194338},{"t":1829285,"n":"_u1C80","d":1894821,"h":858995354021,"f":4194338},{"t":1829285,"n":"_u1C90","d":1894821,"h":871880255909,"f":4194338},{"t":1829285,"n":"_u1CC0","d":1894821,"h":884765157797,"f":4194338},{"t":1829285,"n":"_u1CD0","d":1894821,"h":897650059685,"f":4194338},{"t":1829285,"n":"_u1D00","d":1894821,"h":910534961573,"f":4194338},{"t":1829285,"n":"_u1D80","d":1894821,"h":923419863461,"f":4194338},{"t":1829285,"n":"_u1DC0","d":1894821,"h":936304765349,"f":4194338},{"t":1829285,"n":"_u1E00","d":1894821,"h":949189667237,"f":4194338},{"t":1829285,"n":"_u1F00","d":1894821,"h":962074569125,"f":4194338},{"t":1829285,"n":"_u2000","d":1894821,"h":974959471013,"f":4194338},{"t":1829285,"n":"_u2070","d":1894821,"h":987844372901,"f":4194338},{"t":1829285,"n":"_u20A0","d":1894821,"h":1000729274789,"f":4194338},{"t":1829285,"n":"_u20D0","d":1894821,"h":1013614176677,"f":4194338},{"t":1829285,"n":"_u2100","d":1894821,"h":1026499078565,"f":4194338},{"t":1829285,"n":"_u2150","d":1894821,"h":1039383980453,"f":4194338},{"t":1829285,"n":"_u2190","d":1894821,"h":1052268882341,"f":4194338},{"t":1829285,"n":"_u2200","d":1894821,"h":1065153784229,"f":4194338},{"t":1829285,"n":"_u2300","d":1894821,"h":1078038686117,"f":4194338},{"t":1829285,"n":"_u2400","d":1894821,"h":1090923588005,"f":4194338},{"t":1829285,"n":"_u2440","d":1894821,"h":1103808489893,"f":4194338},{"t":1829285,"n":"_u2460","d":1894821,"h":1116693391781,"f":4194338},{"t":1829285,"n":"_u2500","d":1894821,"h":1129578293669,"f":4194338},{"t":1829285,"n":"_u2580","d":1894821,"h":1142463195557,"f":4194338},{"t":1829285,"n":"_u25A0","d":1894821,"h":1155348097445,"f":4194338},{"t":1829285,"n":"_u2600","d":1894821,"h":1168232999333,"f":4194338},{"t":1829285,"n":"_u2700","d":1894821,"h":1181117901221,"f":4194338},{"t":1829285,"n":"_u27C0","d":1894821,"h":1194002803109,"f":4194338},{"t":1829285,"n":"_u27F0","d":1894821,"h":1206887704997,"f":4194338},{"t":1829285,"n":"_u2800","d":1894821,"h":1219772606885,"f":4194338},{"t":1829285,"n":"_u2900","d":1894821,"h":1232657508773,"f":4194338},{"t":1829285,"n":"_u2980","d":1894821,"h":1245542410661,"f":4194338},{"t":1829285,"n":"_u2A00","d":1894821,"h":1258427312549,"f":4194338},{"t":1829285,"n":"_u2B00","d":1894821,"h":1271312214437,"f":4194338},{"t":1829285,"n":"_u2C00","d":1894821,"h":1284197116325,"f":4194338},{"t":1829285,"n":"_u2C60","d":1894821,"h":1297082018213,"f":4194338},{"t":1829285,"n":"_u2C80","d":1894821,"h":1309966920101,"f":4194338},{"t":1829285,"n":"_u2D00","d":1894821,"h":1322851821989,"f":4194338},{"t":1829285,"n":"_u2D30","d":1894821,"h":1335736723877,"f":4194338},{"t":1829285,"n":"_u2D80","d":1894821,"h":1348621625765,"f":4194338},{"t":1829285,"n":"_u2DE0","d":1894821,"h":1361506527653,"f":4194338},{"t":1829285,"n":"_u2E00","d":1894821,"h":1374391429541,"f":4194338},{"t":1829285,"n":"_u2E80","d":1894821,"h":1387276331429,"f":4194338},{"t":1829285,"n":"_u2F00","d":1894821,"h":1400161233317,"f":4194338},{"t":1829285,"n":"_u2FF0","d":1894821,"h":1413046135205,"f":4194338},{"t":1829285,"n":"_u3000","d":1894821,"h":1425931037093,"f":4194338},{"t":1829285,"n":"_u3040","d":1894821,"h":1438815938981,"f":4194338},{"t":1829285,"n":"_u30A0","d":1894821,"h":1451700840869,"f":4194338},{"t":1829285,"n":"_u3100","d":1894821,"h":1464585742757,"f":4194338},{"t":1829285,"n":"_u3130","d":1894821,"h":1477470644645,"f":4194338},{"t":1829285,"n":"_u3190","d":1894821,"h":1490355546533,"f":4194338},{"t":1829285,"n":"_u31A0","d":1894821,"h":1503240448421,"f":4194338},{"t":1829285,"n":"_u31C0","d":1894821,"h":1516125350309,"f":4194338},{"t":1829285,"n":"_u31F0","d":1894821,"h":1529010252197,"f":4194338},{"t":1829285,"n":"_u3200","d":1894821,"h":1541895154085,"f":4194338},{"t":1829285,"n":"_u3300","d":1894821,"h":1554780055973,"f":4194338},{"t":1829285,"n":"_u3400","d":1894821,"h":1567664957861,"f":4194338},{"t":1829285,"n":"_u4DC0","d":1894821,"h":1580549859749,"f":4194338},{"t":1829285,"n":"_u4E00","d":1894821,"h":1593434761637,"f":4194338},{"t":1829285,"n":"_uA000","d":1894821,"h":1606319663525,"f":4194338},{"t":1829285,"n":"_uA490","d":1894821,"h":1619204565413,"f":4194338},{"t":1829285,"n":"_uA4D0","d":1894821,"h":1632089467301,"f":4194338},{"t":1829285,"n":"_uA500","d":1894821,"h":1644974369189,"f":4194338},{"t":1829285,"n":"_uA640","d":1894821,"h":1657859271077,"f":4194338},{"t":1829285,"n":"_uA6A0","d":1894821,"h":1670744172965,"f":4194338},{"t":1829285,"n":"_uA700","d":1894821,"h":1683629074853,"f":4194338},{"t":1829285,"n":"_uA720","d":1894821,"h":1696513976741,"f":4194338},{"t":1829285,"n":"_uA800","d":1894821,"h":1709398878629,"f":4194338},{"t":1829285,"n":"_uA830","d":1894821,"h":1722283780517,"f":4194338},{"t":1829285,"n":"_uA840","d":1894821,"h":1735168682405,"f":4194338},{"t":1829285,"n":"_uA880","d":1894821,"h":1748053584293,"f":4194338},{"t":1829285,"n":"_uA8E0","d":1894821,"h":1760938486181,"f":4194338},{"t":1829285,"n":"_uA900","d":1894821,"h":1773823388069,"f":4194338},{"t":1829285,"n":"_uA930","d":1894821,"h":1786708289957,"f":4194338},{"t":1829285,"n":"_uA960","d":1894821,"h":1799593191845,"f":4194338},{"t":1829285,"n":"_uA980","d":1894821,"h":1812478093733,"f":4194338},{"t":1829285,"n":"_uA9E0","d":1894821,"h":1825362995621,"f":4194338},{"t":1829285,"n":"_uAA00","d":1894821,"h":1838247897509,"f":4194338},{"t":1829285,"n":"_uAA60","d":1894821,"h":1851132799397,"f":4194338},{"t":1829285,"n":"_uAA80","d":1894821,"h":1864017701285,"f":4194338},{"t":1829285,"n":"_uAAE0","d":1894821,"h":1876902603173,"f":4194338},{"t":1829285,"n":"_uAB00","d":1894821,"h":1889787505061,"f":4194338},{"t":1829285,"n":"_uAB30","d":1894821,"h":1902672406949,"f":4194338},{"t":1829285,"n":"_uAB70","d":1894821,"h":1915557308837,"f":4194338},{"t":1829285,"n":"_uABC0","d":1894821,"h":1928442210725,"f":4194338},{"t":1829285,"n":"_uAC00","d":1894821,"h":1941327112613,"f":4194338},{"t":1829285,"n":"_uD7B0","d":1894821,"h":1954212014501,"f":4194338},{"t":1829285,"n":"_uF900","d":1894821,"h":1967096916389,"f":4194338},{"t":1829285,"n":"_uFB00","d":1894821,"h":1979981818277,"f":4194338},{"t":1829285,"n":"_uFB50","d":1894821,"h":1992866720165,"f":4194338},{"t":1829285,"n":"_uFE00","d":1894821,"h":2005751622053,"f":4194338},{"t":1829285,"n":"_uFE10","d":1894821,"h":2018636523941,"f":4194338},{"t":1829285,"n":"_uFE20","d":1894821,"h":2031521425829,"f":4194338},{"t":1829285,"n":"_uFE30","d":1894821,"h":2044406327717,"f":4194338},{"t":1829285,"n":"_uFE50","d":1894821,"h":2057291229605,"f":4194338},{"t":1829285,"n":"_uFE70","d":1894821,"h":2070176131493,"f":4194338},{"t":1829285,"n":"_uFF00","d":1894821,"h":2083061033381,"f":4194338},{"t":1829285,"n":"_uFFF0","d":1894821,"h":2095945935269,"f":4194338}],"h":1894821}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Text.Unicode.UnicodeRanges`; }
        });
        
        $asm.$cls("$stew.System.Text.UnicodeDebug", ($self) => class UnicodeDebug
        {
            static /*void */ AssertIsBmpCodePoint(/*uint*/ codePoint)
            {
                if (!$.$stew.System.Text.UnicodeUtility.IsBmpCodePoint(codePoint))
                {
                    $.$$.System.Diagnostics.Debug.Fail$1(`The value ${$.$stew.System.Text.UnicodeDebug.ToHexString(codePoint)} is not a valid BMP code point.`);
                }
            }
            static /*void */ AssertIsHighSurrogateCodePoint(/*uint*/ codePoint)
            {
                if (!$.$stew.System.Text.UnicodeUtility.IsHighSurrogateCodePoint(codePoint))
                {
                    $.$$.System.Diagnostics.Debug.Fail$1(`The value ${$.$stew.System.Text.UnicodeDebug.ToHexString(codePoint)} is not a valid UTF-16 high surrogate code point.`);
                }
            }
            static /*void */ AssertIsLowSurrogateCodePoint(/*uint*/ codePoint)
            {
                if (!$.$stew.System.Text.UnicodeUtility.IsLowSurrogateCodePoint(codePoint))
                {
                    $.$$.System.Diagnostics.Debug.Fail$1(`The value ${$.$stew.System.Text.UnicodeDebug.ToHexString(codePoint)} is not a valid UTF-16 low surrogate code point.`);
                }
            }
            static /*void */ AssertIsValidCodePoint(/*uint*/ codePoint)
            {
                if (!$.$stew.System.Text.UnicodeUtility.IsValidCodePoint(codePoint))
                {
                    $.$$.System.Diagnostics.Debug.Fail$1(`The value ${$.$stew.System.Text.UnicodeDebug.ToHexString(codePoint)} is not a valid Unicode code point.`);
                }
            }
            static /*void */ AssertIsValidScalar(/*uint*/ scalarValue)
            {
                if (!$.$stew.System.Text.UnicodeUtility.IsValidUnicodeScalar(scalarValue))
                {
                    $.$$.System.Diagnostics.Debug.Fail$1(`The value ${$.$stew.System.Text.UnicodeDebug.ToHexString(scalarValue)} is not a valid Unicode scalar value.`);
                }
            }
            static /*void */ AssertIsValidSupplementaryPlaneScalar(/*uint*/ scalarValue)
            {
                if (!$.$stew.System.Text.UnicodeUtility.IsValidUnicodeScalar(scalarValue) || $.$stew.System.Text.UnicodeUtility.IsBmpCodePoint(scalarValue))
                {
                    $.$$.System.Diagnostics.Debug.Fail$1(`The value ${$.$stew.System.Text.UnicodeDebug.ToHexString(scalarValue)} is not a valid supplementary plane Unicode scalar value.`);
                }
            }
            static /*string */ ToHexString(/*uint*/ codePoint)
            {
                return $.$$.System.FormattableString.Invariant((() =>
                {
                    var $handler = new $.$$.System.Runtime.CompilerServices.DefaultInterpolatedStringHandler().$ctor$5(1, 1);
                    $handler.AppendLiteral("U+");
                    $handler.AppendFormatted($.$box(codePoint, $.$$.System.UInt32), null, "X4");
                    return $handler.ToStringAndClear            ();
                })());
            }
            static $h = 1960357;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"codePoint","p":720897}],"n":"AssertIsBmpCodePoint","d":1960357,"h":4296927653,"f":16777256,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"DEBUG","t":1310721}]}]},{"r":65537,"p":[{"n":"codePoint","p":720897}],"n":"AssertIsHighSurrogateCodePoint","d":1960357,"h":8591894949,"f":16777256,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"DEBUG","t":1310721}]}]},{"r":65537,"p":[{"n":"codePoint","p":720897}],"n":"AssertIsLowSurrogateCodePoint","d":1960357,"h":12886862245,"f":16777256,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"DEBUG","t":1310721}]}]},{"r":65537,"p":[{"n":"codePoint","p":720897}],"n":"AssertIsValidCodePoint","d":1960357,"h":17181829541,"f":16777256,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"DEBUG","t":1310721}]}]},{"r":65537,"p":[{"n":"scalarValue","p":720897}],"n":"AssertIsValidScalar","d":1960357,"h":21476796837,"f":16777256,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"DEBUG","t":1310721}]}]},{"r":65537,"p":[{"n":"scalarValue","p":720897}],"n":"AssertIsValidSupplementaryPlaneScalar","d":1960357,"h":25771764133,"f":16777256,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"DEBUG","t":1310721}]}]},{"r":1310721,"p":[{"n":"codePoint","p":720897}],"n":"ToHexString","d":1960357,"h":30066731429,"f":16777250}],"h":1960357}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Text.UnicodeDebug`; }
        });
        
        $asm.$cls("$stew.System.Text.Unicode.UnicodeHelpers", ($self) => class UnicodeHelpers
        {
            /*int*/ static UNICODE_LAST_CODEPOINT = 1114111;
            static /*ReadOnlySpan<byte> */ GetDefinedBmpCodePointsBitmapLittleEndian()
            {
                return $.$stew.System.Text.Unicode.UnicodeHelpers.DefinedCharsBitmapSpan;
            }
            static /*void */ GetUtf16SurrogatePairFromAstralScalarValue(/*uint*/ scalar, /*out char*/ highSurrogate, /*out char*/ lowSurrogate)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(65536 <= scalar && scalar <= 1114111/*UNICODE_LAST_CODEPOINT*/, "0x10000 <= scalar && scalar <= UNICODE_LAST_CODEPOINT");
                $.$stew.System.Text.UnicodeDebug.AssertIsValidSupplementaryPlaneScalar(scalar);
                highSurrogate.$v = $.$cast(((((scalar + (((((55296 - 64) >>> 0)) << 10) >>> 0)) >>> 0)) >>> 10), $.$$.System.Char);
                lowSurrogate.$v = $.$cast(((((scalar & 1023) + 56320) >>> 0)), $.$$.System.Char);
            }
            static /*int */ GetUtf8RepresentationForScalarValue(/*uint*/ scalar)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(scalar <= 1114111/*UNICODE_LAST_CODEPOINT*/, "scalar <= UNICODE_LAST_CODEPOINT");
                if (scalar <= 127)
                {
                    /*byte*/ let firstByte = $.$cast(scalar, $.$$.System.Byte);
                    return firstByte;
                }
                else if (scalar <= 2047)
                {
                    /*byte*/ let firstByte = $.$cast((192 | (scalar >>> 6)), $.$$.System.Byte);
                    /*byte*/ let secondByteByte = $.$cast((128 | (scalar & 63)), $.$$.System.Byte);
                    return (((secondByteByte << 8) >>> 0) | firstByte);
                }
                else if (scalar <= 65535)
                {
                    /*byte*/ let firstByte = $.$cast((224 | (scalar >>> 12)), $.$$.System.Byte);
                    /*byte*/ let secondByte = $.$cast((128 | ((scalar >>> 6) & 63)), $.$$.System.Byte);
                    /*byte*/ let thirdByte = $.$cast((128 | (scalar & 63)), $.$$.System.Byte);
                    return (((((thirdByte << 8) >>> 0) | secondByte) << 8) | firstByte);
                }
                else 
                {
                    /*byte*/ let firstByte = $.$cast((240 | (scalar >>> 18)), $.$$.System.Byte);
                    /*byte*/ let secondByte = $.$cast((128 | ((scalar >>> 12) & 63)), $.$$.System.Byte);
                    /*byte*/ let thirdByte = $.$cast((128 | ((scalar >>> 6) & 63)), $.$$.System.Byte);
                    /*byte*/ let fourthByte = $.$cast((128 | (scalar & 63)), $.$$.System.Byte);
                    return (((((((fourthByte << 8) >>> 0) | thirdByte) << 8) | secondByte) << 8) | firstByte);
                }
            }
            static /*bool */ IsSupplementaryCodePoint(/*int*/ scalar)
            {
                return ((scalar & ~(/*\uFFFF*/ 65535)) !== 0);
            }
            static /*ReadOnlySpan<byte> */ get DefinedCharsBitmapSpan()
            {
                return this.$cacheDefinedCharsBitmapSpan ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([ 0, 0, 0, 0, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 127, 0, 0, 0, 0, 254, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 252, 240, 215, 255, 255, 251, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 254, 255, 255, 255, 127, 254, 255, 255, 255, 255, 255, 231, 254, 255, 255, 255, 255, 255, 255, 0, 255, 255, 255, 135, 31, 0, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 191, 255, 255, 255, 255, 255, 255, 255, 231, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 3, 0, 255, 255, 255, 255, 255, 255, 255, 231, 255, 255, 255, 255, 255, 63, 255, 127, 255, 255, 255, 79, 255, 7, 255, 255, 255, 127, 131, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 239, 159, 249, 255, 255, 253, 197, 243, 159, 121, 128, 176, 207, 255, 255, 127, 238, 135, 249, 255, 255, 253, 109, 211, 135, 57, 2, 94, 192, 255, 127, 0, 238, 191, 251, 255, 255, 253, 237, 243, 191, 59, 1, 0, 207, 255, 3, 254, 238, 159, 249, 255, 255, 253, 237, 243, 159, 57, 224, 176, 207, 255, 255, 0, 236, 199, 61, 214, 24, 199, 255, 195, 199, 61, 129, 0, 192, 255, 255, 7, 255, 223, 253, 255, 255, 253, 255, 243, 223, 61, 96, 39, 207, 255, 128, 255, 255, 223, 253, 255, 255, 253, 239, 243, 223, 61, 96, 96, 207, 255, 14, 0, 255, 223, 253, 255, 255, 255, 255, 255, 223, 253, 240, 255, 207, 255, 255, 255, 238, 255, 127, 252, 255, 255, 251, 47, 127, 132, 95, 255, 192, 255, 28, 0, 254, 255, 255, 255, 255, 255, 255, 135, 255, 255, 255, 15, 0, 0, 0, 0, 214, 247, 255, 255, 175, 255, 255, 63, 95, 127, 255, 243, 0, 0, 0, 0, 255, 255, 255, 255, 255, 255, 255, 255, 255, 254, 255, 255, 255, 31, 254, 255, 255, 255, 255, 254, 255, 255, 255, 223, 255, 223, 255, 7, 0, 0, 0, 0, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 191, 32, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 61, 127, 61, 255, 255, 255, 255, 255, 61, 255, 255, 255, 255, 61, 127, 61, 255, 127, 255, 255, 255, 255, 255, 255, 255, 61, 255, 255, 255, 255, 255, 255, 255, 255, 231, 255, 255, 255, 31, 255, 255, 255, 3, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 63, 63, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 254, 255, 255, 31, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 1, 255, 255, 63, 128, 255, 255, 127, 0, 255, 255, 15, 0, 255, 223, 13, 0, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 63, 255, 3, 255, 3, 255, 255, 255, 3, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 1, 255, 255, 255, 255, 255, 7, 255, 255, 255, 255, 255, 255, 255, 255, 63, 0, 255, 255, 255, 127, 255, 15, 255, 15, 241, 255, 255, 255, 255, 63, 31, 0, 255, 255, 255, 255, 255, 15, 255, 255, 255, 3, 255, 199, 255, 255, 255, 255, 255, 255, 255, 207, 255, 255, 255, 255, 255, 255, 255, 127, 255, 255, 255, 159, 255, 3, 255, 3, 255, 63, 255, 255, 255, 127, 0, 0, 0, 0, 0, 0, 255, 255, 255, 255, 255, 255, 255, 255, 255, 223, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 15, 240, 255, 255, 255, 255, 255, 255, 255, 248, 255, 227, 255, 255, 255, 255, 255, 255, 255, 7, 255, 255, 255, 255, 255, 231, 255, 0, 255, 255, 255, 255, 255, 7, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 63, 63, 255, 255, 255, 255, 63, 63, 255, 170, 255, 255, 255, 63, 255, 255, 255, 255, 255, 255, 223, 255, 223, 255, 207, 239, 255, 255, 220, 127, 0, 248, 255, 255, 255, 124, 255, 255, 255, 255, 255, 127, 223, 255, 243, 255, 255, 127, 255, 31, 255, 255, 255, 255, 1, 0, 255, 255, 255, 255, 1, 0, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 15, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 3, 0, 0, 255, 7, 0, 0, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 207, 255, 255, 255, 191, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 15, 254, 255, 255, 255, 255, 191, 32, 255, 255, 255, 255, 255, 255, 255, 128, 1, 128, 255, 255, 127, 0, 127, 127, 127, 127, 127, 127, 127, 127, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 63, 0, 0, 0, 0, 255, 255, 255, 251, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 15, 0, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 63, 0, 0, 0, 255, 255, 254, 255, 255, 255, 255, 255, 255, 255, 254, 255, 255, 255, 255, 255, 255, 255, 255, 255, 127, 254, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 224, 255, 255, 255, 255, 255, 254, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 127, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 63, 128, 255, 255, 255, 255, 255, 127, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 31, 255, 255, 255, 255, 255, 255, 127, 0, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 15, 0, 0, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 0, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 63, 235, 31, 0, 0, 252, 255, 255, 255, 255, 255, 255, 31, 255, 3, 255, 255, 255, 255, 255, 255, 255, 0, 255, 255, 255, 255, 255, 255, 255, 255, 63, 192, 255, 3, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 15, 128, 255, 255, 255, 31, 255, 255, 255, 255, 255, 255, 255, 255, 255, 191, 255, 195, 255, 255, 255, 127, 255, 255, 255, 255, 255, 255, 127, 0, 255, 63, 255, 243, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 7, 0, 0, 248, 255, 255, 127, 0, 126, 126, 126, 0, 127, 127, 255, 255, 255, 255, 255, 255, 255, 15, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 63, 255, 3, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 15, 0, 255, 255, 127, 248, 255, 255, 255, 255, 255, 15, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 63, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 3, 0, 0, 0, 0, 127, 0, 248, 224, 255, 255, 127, 95, 219, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 7, 0, 248, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 252, 255, 255, 255, 255, 255, 255, 128, 0, 0, 0, 0, 255, 255, 255, 255, 255, 3, 255, 255, 255, 255, 255, 255, 247, 255, 127, 15, 223, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 31, 254, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 127, 252, 252, 252, 28, 127, 127, 0, 62 ]);
            }
            static $h = 1763749;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":30066534821,"f":50331682},"n":"DefinedCharsBitmapSpan","d":1763749,"h":25771567525,"f":2097186}],"m":[{"r":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"n":"GetDefinedBmpCodePointsBitmapLittleEndian","d":1763749,"h":8591698341,"f":16777256},{"r":65537,"p":[{"n":"scalar","p":720897},{"n":"highSurrogate","p":458753,"f":2},{"n":"lowSurrogate","p":458753,"f":2}],"n":"GetUtf16SurrogatePairFromAstralScalarValue","d":1763749,"h":12886665637,"f":16777256},{"r":655361,"p":[{"n":"scalar","p":720897}],"n":"GetUtf8RepresentationForScalarValue","d":1763749,"h":17181632933,"f":16777256},{"r":262145,"p":[{"n":"scalar","p":655361}],"n":"IsSupplementaryCodePoint","d":1763749,"h":21476600229,"f":16777256}],"l":[{"t":655361,"n":"UNICODE_LAST_CODEPOINT","d":1763749,"h":4296731045,"f":4194344}],"h":1763749}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Text.Unicode.UnicodeHelpers`; }
        });
        
        $asm.$cls("$stew.System.Text.Unicode.UnicodeRange", ($self) => class UnicodeRange extends $.$$.System.Object
        {
            $ctor$1(/*int*/ firstCodePoint, /*int*/ length)
            {
                super.$ctor();
                {
                    if (firstCodePoint < 0 || firstCodePoint > 65535)
                    {
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("firstCodePoint");
                    }
                    if (length < 0 || ($.$cast(firstCodePoint, $.$$.System.Int64) + $.$cast(length, $.$$.System.Int64) > 65536n))
                    {
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("length");
                    }
                    this.FirstCodePoint = firstCodePoint;
                    this.Length = length;
                }
                return this;
            }
            /*int*/ FirstCodePoint = 0;
            /*int*/ Length = 0;
            static /*UnicodeRange */ Create(/*char*/ firstCharacter, /*char*/ lastCharacter)
            {
                if (lastCharacter < firstCharacter)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("lastCharacter");
                }
                return new $.$stew.System.Text.Unicode.UnicodeRange().$ctor$1(firstCharacter, ((1 + (lastCharacter - firstCharacter)) | 0));
            }
            static $h = 1829285;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":17181698469,"f":50331649},"n":"FirstCodePoint","d":1829285,"h":12886731173,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":30066600357,"f":50331649},"n":"Length","d":1829285,"h":25771633061,"f":2097153}],"m":[{"r":1829285,"p":[{"n":"firstCharacter","p":458753},{"n":"lastCharacter","p":458753}],"n":"Create","d":1829285,"h":34361567653,"f":16777249}],"c":[{"p":[{"n":"firstCodePoint","p":655361},{"n":"length","p":655361}],"n":".ctor","o":"$ctor$1","d":1829285,"h":4296796581,"f":16777217}],"h":1829285}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Text.Unicode.UnicodeRange`; }
        });
        
        $asm.$cls("$stew.System.Text.UnicodeUtility", ($self) => class UnicodeUtility
        {
            /*uint*/ static ReplacementChar = 65533;
            static /*int */ GetPlane(/*uint*/ codePoint)
            {
                $.$stew.System.Text.UnicodeDebug.AssertIsValidCodePoint(codePoint);
                return ((codePoint >>> 16) | 0);
            }
            static /*uint */ GetScalarFromUtf16SurrogatePair(/*uint*/ highSurrogateCodePoint, /*uint*/ lowSurrogateCodePoint)
            {
                $.$stew.System.Text.UnicodeDebug.AssertIsHighSurrogateCodePoint(highSurrogateCodePoint);
                $.$stew.System.Text.UnicodeDebug.AssertIsLowSurrogateCodePoint(lowSurrogateCodePoint);
                return ((((((highSurrogateCodePoint << 10) >>> 0) + lowSurrogateCodePoint) >>> 0) - (((((55296 << 10) >>> 0) + 56320) >>> 0) - (1 << 16))) >>> 0);
            }
            static /*int */ GetUtf16SequenceLength(/*uint*/ value)
            {
                $.$stew.System.Text.UnicodeDebug.AssertIsValidScalar(value);
                value -= 65536;
                value += (2 << 24);
                value >>= 24;
                return (value | 0);
            }
            static /*void */ GetUtf16SurrogatesFromSupplementaryPlaneScalar(/*uint*/ value, /*out char*/ highSurrogateCodePoint, /*out char*/ lowSurrogateCodePoint)
            {
                $.$stew.System.Text.UnicodeDebug.AssertIsValidSupplementaryPlaneScalar(value);
                highSurrogateCodePoint.$v = $.$cast(((((value + (((((55296 - 64) >>> 0)) << 10) >>> 0)) >>> 0)) >>> 10), $.$$.System.Char);
                lowSurrogateCodePoint.$v = $.$cast(((((value & 1023) + 56320) >>> 0)), $.$$.System.Char);
            }
            static /*int */ GetUtf8SequenceLength(/*uint*/ value)
            {
                $.$stew.System.Text.UnicodeDebug.AssertIsValidScalar(value);
                /*int*/ let a = ((((value | 0) - 2048) | 0)) >> 31;
                value ^= 63488;
                value -= 63616;
                value += (4 << 24);
                value >>= 24;
                return (((value | 0) + (((a * 2) | 0))) | 0);
            }
            static /*bool */ IsAsciiCodePoint(/*uint*/ value)
            {
                return value <= 127;
            }
            static /*bool */ IsBmpCodePoint(/*uint*/ value)
            {
                return value <= 65535;
            }
            static /*bool */ IsHighSurrogateCodePoint(/*uint*/ value)
            {
                return $.$stew.System.Text.UnicodeUtility.IsInRangeInclusive(value, 55296, 56319);
            }
            static /*bool */ IsInRangeInclusive(/*uint*/ value, /*uint*/ lowerBound, /*uint*/ upperBound)
            {
                return ((((value - lowerBound) >>> 0)) >>> 0) <= ((((upperBound - lowerBound) >>> 0)) >>> 0);
            }
            static /*bool */ IsLowSurrogateCodePoint(/*uint*/ value)
            {
                return $.$stew.System.Text.UnicodeUtility.IsInRangeInclusive(value, 56320, 57343);
            }
            static /*bool */ IsSurrogateCodePoint(/*uint*/ value)
            {
                return $.$stew.System.Text.UnicodeUtility.IsInRangeInclusive(value, 55296, 57343);
            }
            static /*bool */ IsValidCodePoint(/*uint*/ codePoint)
            {
                return codePoint <= 1114111;
            }
            static /*bool */ IsValidUnicodeScalar(/*uint*/ value)
            {
                return (((((value - 1114112) >>> 0)) ^ 55296) >>> 0) >= 4293855232;
            }
            static $h = 2025893;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":655361,"p":[{"n":"codePoint","p":720897}],"n":"GetPlane","d":2025893,"h":8591960485,"f":16777249},{"r":720897,"p":[{"n":"highSurrogateCodePoint","p":720897},{"n":"lowSurrogateCodePoint","p":720897}],"n":"GetScalarFromUtf16SurrogatePair","d":2025893,"h":12886927781,"f":16777249},{"r":655361,"p":[{"n":"value","p":720897}],"n":"GetUtf16SequenceLength","d":2025893,"h":17181895077,"f":16777249},{"r":65537,"p":[{"n":"value","p":720897},{"n":"highSurrogateCodePoint","p":458753,"f":2},{"n":"lowSurrogateCodePoint","p":458753,"f":2}],"n":"GetUtf16SurrogatesFromSupplementaryPlaneScalar","d":2025893,"h":21476862373,"f":16777249},{"r":655361,"p":[{"n":"value","p":720897}],"n":"GetUtf8SequenceLength","d":2025893,"h":25771829669,"f":16777249},{"r":262145,"p":[{"n":"value","p":720897}],"n":"IsAsciiCodePoint","d":2025893,"h":30066796965,"f":16777249},{"r":262145,"p":[{"n":"value","p":720897}],"n":"IsBmpCodePoint","d":2025893,"h":34361764261,"f":16777249},{"r":262145,"p":[{"n":"value","p":720897}],"n":"IsHighSurrogateCodePoint","d":2025893,"h":38656731557,"f":16777249},{"r":262145,"p":[{"n":"value","p":720897},{"n":"lowerBound","p":720897},{"n":"upperBound","p":720897}],"n":"IsInRangeInclusive","d":2025893,"h":42951698853,"f":16777249},{"r":262145,"p":[{"n":"value","p":720897}],"n":"IsLowSurrogateCodePoint","d":2025893,"h":47246666149,"f":16777249},{"r":262145,"p":[{"n":"value","p":720897}],"n":"IsSurrogateCodePoint","d":2025893,"h":51541633445,"f":16777249},{"r":262145,"p":[{"n":"codePoint","p":720897}],"n":"IsValidCodePoint","d":2025893,"h":55836600741,"f":16777249},{"r":262145,"p":[{"n":"value","p":720897}],"n":"IsValidUnicodeScalar","d":2025893,"h":60131568037,"f":16777249}],"l":[{"t":720897,"n":"ReplacementChar","d":2025893,"h":4296993189,"f":4194337}],"h":2025893}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Text.UnicodeUtility`; }
        });
        
        $asm.$cls("$stew.System.ThrowHelper", ($self) => class ThrowHelper
        {
            static /*void */ ThrowArgumentOutOfRangeException()
            {
                throw new $.$$.System.ArgumentOutOfRangeException().$ctor$15();
            }
            static /*void */ ThrowArgumentException_DestinationTooShort()
            {
                throw new $.$$.System.ArgumentException().$ctor$13($.$stew.System.SR.Argument_DestinationTooShort, "destination");
            }
            static /*void */ ThrowArgumentException_CannotExtractScalar(/*ExceptionArgument*/ argument)
            {
                throw $.$stew.System.ThrowHelper.GetArgumentException(0/*ExceptionResource.Argument_CannotExtractScalar*/, argument);
            }
            static /*void */ ThrowArgumentOutOfRange_IndexMustBeLessException()
            {
                throw $.$stew.System.ThrowHelper.GetArgumentOutOfRangeException(2/*ExceptionArgument.index*/, 1/*ExceptionResource.ArgumentOutOfRange_IndexMustBeLess*/);
            }
            static /*void */ ThrowArgumentNullException(/*ExceptionArgument*/ argument)
            {
                throw new $.$$.System.ArgumentNullException().$ctor$19($.$stew.System.ThrowHelper.GetArgumentName(argument));
            }
            static /*void */ ThrowArgumentOutOfRangeException$1(/*ExceptionArgument*/ argument)
            {
                throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20($.$stew.System.ThrowHelper.GetArgumentName(argument));
            }
            static /*ArgumentOutOfRangeException */ GetArgumentOutOfRangeException(/*ExceptionArgument*/ argument, /*ExceptionResource*/ resource)
            {
                return new $.$$.System.ArgumentOutOfRangeException().$ctor$19($.$stew.System.ThrowHelper.GetArgumentName(argument), $.$stew.System.ThrowHelper.GetResourceString(resource));
            }
            static /*ArgumentException */ GetArgumentException(/*ExceptionResource*/ resource, /*ExceptionArgument*/ argument)
            {
                return new $.$$.System.ArgumentException().$ctor$13($.$stew.System.ThrowHelper.GetResourceString(resource), $.$stew.System.ThrowHelper.GetArgumentName(argument));
            }
            static /*string */ GetArgumentName(/*ExceptionArgument*/ argument)
            {
                switch(argument)
                {
                    case 0/*ExceptionArgument.ch*/:
                    return "ch";
                    case 1/*ExceptionArgument.culture*/:
                    return "culture";
                    case 2/*ExceptionArgument.index*/:
                    return "index";
                    case 3/*ExceptionArgument.input*/:
                    return "input";
                    case 4/*ExceptionArgument.value*/:
                    return "value";
                    default:
                    $.$$.System.Diagnostics.Debug.Fail$1("The enum value is not defined, please check the ExceptionArgument Enum.");
                    return "";
                }
            }
            static /*string */ GetResourceString(/*ExceptionResource*/ resource)
            {
                switch(resource)
                {
                    case 1/*ExceptionResource.ArgumentOutOfRange_IndexMustBeLess*/:
                    return $.$stew.System.SR.ArgumentOutOfRange_IndexMustBeLess;
                    case 0/*ExceptionResource.Argument_CannotExtractScalar*/:
                    return $.$stew.System.SR.Argument_CannotExtractScalar;
                    default:
                    $.$$.System.Diagnostics.Debug.Fail$1("The enum value is not defined, please check the ExceptionResource Enum.");
                    return "";
                }
            }
            static $h = 2156965;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"n":"ThrowArgumentOutOfRangeException","d":2156965,"h":4297124261,"f":16777256},{"r":65537,"n":"ThrowArgumentException_DestinationTooShort","d":2156965,"h":8592091557,"f":16777256},{"r":65537,"p":[{"n":"argument","p":125349}],"n":"ThrowArgumentException_CannotExtractScalar","d":2156965,"h":12887058853,"f":16777256},{"r":65537,"n":"ThrowArgumentOutOfRange_IndexMustBeLessException","d":2156965,"h":17182026149,"f":16777256},{"r":65537,"p":[{"n":"argument","p":125349}],"n":"ThrowArgumentNullException","d":2156965,"h":21476993445,"f":16777256},{"r":65537,"p":[{"n":"argument","p":125349}],"n":"ThrowArgumentOutOfRangeException","o":"@$1","d":2156965,"h":25771960741,"f":16777256},{"r":13631489,"p":[{"n":"argument","p":125349},{"n":"resource","p":190885}],"n":"GetArgumentOutOfRangeException","d":2156965,"h":30066928037,"f":16777250},{"r":13500417,"p":[{"n":"resource","p":190885},{"n":"argument","p":125349}],"n":"GetArgumentException","d":2156965,"h":34361895333,"f":16777250},{"r":1310721,"p":[{"n":"argument","p":125349}],"n":"GetArgumentName","d":2156965,"h":38656862629,"f":16777250},{"r":1310721,"p":[{"n":"resource","p":190885}],"n":"GetResourceString","d":2156965,"h":42951829925,"f":16777250}],"h":2156965}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.ThrowHelper`; }
        });
        
        $asm.$cls("$stew.System.HexConverter", ($self) => class HexConverter
        {
            static $_Casing;
            static get Casing()
            {
                let $cls = $.$stew.System.HexConverter;
                return $cls.$_Casing ??= $asm.$nstr("$stew.System.HexConverter.Casing", ($self) => class Casing extends $.$$.System.Enum
                {
                    static Upper = 0;
                    static Lower = 8224;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "Upper": 0n,
                            "Lower": 8224n
                        };
                    }
                    static $h = 321957;
                    static $z = 4;
                    static $f = 0b110000011010001001;
                    static $k = 4;
                    static get $eut() { return $.$$.System.UInt32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":720897,"l":[{"t":321957,"n":"Upper","d":321957,"h":4295289253,"f":4194337},{"t":321957,"n":"Lower","d":321957,"h":8590256549,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":321957,"h":12885223845,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"d":256421,"h":321957}; }
                    static get $b() { return $.$$.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
                    static get $fullName() { return `System.HexConverter.Casing`; }
                }, $cls, ($v) => $cls.$_Casing = $v);
            }
            static /*void */ ToBytesBuffer(/*byte*/ value, /*Span<byte>*/ buffer, /*int*/ startingIndex, /*Casing*/ casing)
            {
                /*uint*/ let difference = (((((((value & 240) << 4) >>> 0) + (value & 15)) >>> 0) - 35209) >>> 0);
                /*uint*/ let packedResult = (((((((((-(difference | 0)) >>> 0) & 28784) >>> 4) + difference) >>> 0) + 47545) >>> 0)) | casing;
                buffer.get_Item(((startingIndex + 1) | 0)).$v = $.$cast(packedResult, $.$$.System.Byte);
                buffer.get_Item(startingIndex).$v = $.$cast((packedResult >>> 8), $.$$.System.Byte);
            }
            static /*void */ ToCharsBuffer(/*byte*/ value, /*Span<char>*/ buffer, /*int*/ startingIndex, /*Casing*/ casing)
            {
                /*uint*/ let difference = (((((((value & 240) << 4) >>> 0) + (value & 15)) >>> 0) - 35209) >>> 0);
                /*uint*/ let packedResult = (((((((((-(difference | 0)) >>> 0) & 28784) >>> 4) + difference) >>> 0) + 47545) >>> 0)) | casing;
                buffer.get_Item(((startingIndex + 1) | 0)).$v = $.$cast((packedResult & 255), $.$$.System.Char);
                buffer.get_Item(startingIndex).$v = $.$cast((packedResult >>> 8), $.$$.System.Char);
            }
            static /*void */ EncodeToUtf8(/*ReadOnlySpan<byte>*/ source, /*Span<byte>*/ utf8Destination, /*Casing*/ casing)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(utf8Destination.Length >= (((source.Length * 2) | 0)), "utf8Destination.Length >= (source.Length * 2)");
                for(/*int*/ let pos = 0; pos < source.Length; pos++)
                {
                    $.$stew.System.HexConverter.ToBytesBuffer(source.get_Item(pos).$v, utf8Destination, ((pos * 2) | 0), casing);
                }
            }
            static /*void */ EncodeToUtf16(/*ReadOnlySpan<byte>*/ source, /*Span<char>*/ destination, /*Casing*/ casing)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(destination.Length >= (((source.Length * 2) | 0)), "destination.Length >= (source.Length * 2)");
                for(/*int*/ let pos = 0; pos < source.Length; pos++)
                {
                    $.$stew.System.HexConverter.ToCharsBuffer(source.get_Item(pos).$v, destination, ((pos * 2) | 0), casing);
                }
            }
            static /*string */ ToString$1(/*ReadOnlySpan<byte>*/ bytes, /*Casing*/ casing)
            {
                /*SpanCasingPair*/ let args = (() =>
                {
                    //new $.$stew.System.HexConverter.SpanCasingPair()
                    const $t1 = $.$stew.System.HexConverter.SpanCasingPair;
                    const $i1 = new $t1();
                    $i1.Bytes = bytes;
                    $i1.Casing = casing;
                    return $i1;
                })();
                return $.$$.System.String.Create$10($.$stew.System.HexConverter.SpanCasingPair, ((bytes.Length * 2) | 0), args.Clone(), new ($.$$.System.Buffers.SpanAction$$$($.$$.System.Char, $.$stew.System.HexConverter.SpanCasingPair))().$ctor($.$stew.System.HexConverter, /*static*/ (/*chars*/ chars, /*args*/ args) =>
                {
                    return $.$stew.System.HexConverter.EncodeToUtf16(args.Bytes, chars, args.Casing);
                }, {"r":65537,"p":[{"n":"chars","p":$.$$.System.Span$$($.$$.System.Char).$h},{"n":"args","p":387493}],"n":"","d":256421,"h":0,"f":17825826}));
            }
            static $_SpanCasingPair;
            static get SpanCasingPair()
            {
                let $cls = $.$stew.System.HexConverter;
                return $cls.$_SpanCasingPair ??= $asm.$nstr("$stew.System.HexConverter.SpanCasingPair", ($self) => class SpanCasingPair extends $.$$.System.ValueType
                {
                    /*ReadOnlySpan<byte>*/ Bytes;
                    /*Casing*/ Casing = 0;
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Bytes = this.Bytes.Clone();
                        copy.Casing = this.Casing;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.Bytes = $.$default($.$$.System.ReadOnlySpan$$($.$$.System.Byte));
                        this.Casing = 0;
                    }
                    static $h = 387493;
                    static $z = 9;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":12885289381,"f":50331649},"s":{"r":0,"d":0,"h":17180256677,"f":83886081},"n":"Bytes","d":387493,"h":8590322085,"f":2097153},{"p":321957,"g":{"r":0,"d":0,"h":30065158565,"f":50331649},"s":{"r":0,"d":0,"h":34360125861,"f":83886081},"n":"Casing","d":387493,"h":25770191269,"f":2097153}],"c":[{"n":".ctor","o":"$ctor$2","d":387493,"h":38655093157,"f":16777217}],"d":256421,"h":387493}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `System.HexConverter.SpanCasingPair`; }
                }, $cls, ($v) => $cls.$_SpanCasingPair = $v);
            }
            static /*char */ ToCharUpper(/*int*/ value)
            {
                value &= 15;
                value += /*0*/ 48;
                if (value > /*9*/ 57)
                {
                    value += (((/*A*/ 65 - (((/*9*/ 57 + 1) | 0))) | 0));
                }
                return $.$cast(value, $.$$.System.Char);
            }
            static /*char */ ToCharLower(/*int*/ value)
            {
                value &= 15;
                value += /*0*/ 48;
                if (value > /*9*/ 57)
                {
                    value += (((/*a*/ 97 - (((/*9*/ 57 + 1) | 0))) | 0));
                }
                return $.$cast(value, $.$$.System.Char);
            }
            static /*bool */ TryDecodeFromUtf8(/*ReadOnlySpan<byte>*/ utf8Source, /*Span<byte>*/ destination, /*out int*/ bytesProcessed)
            {
                return $.$stew.System.HexConverter.TryDecodeFromUtf8_Scalar(utf8Source, destination, bytesProcessed);
            }
            static /*bool */ TryDecodeFromUtf16(/*ReadOnlySpan<char>*/ source, /*Span<byte>*/ destination, /*out int*/ charsProcessed)
            {
                return $.$stew.System.HexConverter.TryDecodeFromUtf16_Scalar(source, destination, charsProcessed);
            }
            static /*bool */ TryDecodeFromUtf8_Scalar(/*ReadOnlySpan<byte>*/ utf8Source, /*Span<byte>*/ destination, /*out int*/ bytesProcessed)
            {
                $.$$.System.Diagnostics.Debug.Assert$2((utf8Source.Length % 2) === 0, "Un-even number of characters provided");
                $.$$.System.Diagnostics.Debug.Assert$2(($.trunc(utf8Source.Length / 2)) === destination.Length, "Target buffer not right-sized for provided characters");
                /*int*/ let i = 0;
                /*int*/ let j = 0;
                /*int*/ let byteLo = 0;
                /*int*/ let byteHi = 0;
                while(j < destination.Length)
                {
                    byteLo = $.$stew.System.HexConverter.FromChar(utf8Source.get_Item(((i + 1) | 0)).$v);
                    byteHi = $.$stew.System.HexConverter.FromChar(utf8Source.get_Item(i).$v);
                    if ((byteLo | byteHi) === 255)
                    {
                        break;
                    }
                    destination.get_Item(j++).$v = $.$cast(((byteHi << 4) | byteLo), $.$$.System.Byte);
                    i += 2;
                }
                if (byteLo === 255)
                {
                    i++;
                }
                bytesProcessed.$v = i;
                return (byteLo | byteHi) !== 255;
            }
            static /*bool */ TryDecodeFromUtf16_Scalar(/*ReadOnlySpan<char>*/ source, /*Span<byte>*/ destination, /*out int*/ charsProcessed)
            {
                $.$$.System.Diagnostics.Debug.Assert$2((source.Length % 2) === 0, "Un-even number of characters provided");
                $.$$.System.Diagnostics.Debug.Assert$2(($.trunc(source.Length / 2)) === destination.Length, "Target buffer not right-sized for provided characters");
                /*int*/ let i = 0;
                /*int*/ let j = 0;
                /*int*/ let byteLo = 0;
                /*int*/ let byteHi = 0;
                while(j < destination.Length)
                {
                    byteLo = $.$stew.System.HexConverter.FromChar(source.get_Item(((i + 1) | 0)).$v);
                    byteHi = $.$stew.System.HexConverter.FromChar(source.get_Item(i).$v);
                    if ((byteLo | byteHi) === 255)
                    {
                        break;
                    }
                    destination.get_Item(j++).$v = $.$cast(((byteHi << 4) | byteLo), $.$$.System.Byte);
                    i += 2;
                }
                if (byteLo === 255)
                {
                    i++;
                }
                charsProcessed.$v = i;
                return (byteLo | byteHi) !== 255;
            }
            static /*int */ FromChar(/*int*/ c)
            {
                return (c >= $.$stew.System.HexConverter.CharToHexLookup.Length) ? 255 : $.$stew.System.HexConverter.CharToHexLookup.get_Item(c).$v;
            }
            static /*int */ FromUpperChar(/*int*/ c)
            {
                return (c > 71) ? 255 : $.$stew.System.HexConverter.CharToHexLookup.get_Item(c).$v;
            }
            static /*int */ FromLowerChar(/*int*/ c)
            {
                if (((((c - /*0*/ 48) | 0)) >>> 0) <= (/*9*/ 57 - /*0*/ 48))
                {
                    return ((c - /*0*/ 48) | 0);
                }
                if (((((c - /*a*/ 97) | 0)) >>> 0) <= (/*f*/ 102 - /*a*/ 97))
                {
                    return ((((c - /*a*/ 97) | 0) + 10) | 0);
                }
                return 255;
            }
            static /*bool */ IsHexChar(/*int*/ c)
            {
                //if (IntPtr.Size == 8) { ... }
                return $.$stew.System.HexConverter.FromChar(c) !== 255;
            }
            static /*bool */ IsHexUpperChar(/*int*/ c)
            {
                return (((((c - /*0*/ 48) | 0)) >>> 0) <= 9) || (((((c - /*A*/ 65) | 0)) >>> 0) <= (/*F*/ 70 - /*A*/ 65));
            }
            static /*bool */ IsHexLowerChar(/*int*/ c)
            {
                return (((((c - /*0*/ 48) | 0)) >>> 0) <= 9) || (((((c - /*a*/ 97) | 0)) >>> 0) <= (/*f*/ 102 - /*a*/ 97));
            }
            static /*ReadOnlySpan<byte> */ get CharToHexLookup()
            {
                return this.$cacheCharToHexLookup ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([ 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 255, 255, 255, 255, 255, 255, 255, 10, 11, 12, 13, 14, 15, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 10, 11, 12, 13, 14, 15, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255 ]);
            }
            static $h = 256421;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":90194569637,"f":50331681},"n":"CharToHexLookup","d":256421,"h":85899602341,"f":2097185}],"m":[{"r":65537,"p":[{"n":"value","p":393217},{"n":"buffer","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"startingIndex","p":655361,"f":65,"v":0},{"n":"casing","p":321957,"f":65,"v":0}],"n":"ToBytesBuffer","d":256421,"h":8590191013,"f":16777249},{"r":65537,"p":[{"n":"value","p":393217},{"n":"buffer","p":$.$$.System.Span$$($.$$.System.Char).$h},{"n":"startingIndex","p":655361,"f":65,"v":0},{"n":"casing","p":321957,"f":65,"v":0}],"n":"ToCharsBuffer","d":256421,"h":12885158309,"f":16777249},{"r":65537,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"utf8Destination","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"casing","p":321957,"f":65,"v":0}],"n":"EncodeToUtf8","d":256421,"h":17180125605,"f":16777249},{"r":65537,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"destination","p":$.$$.System.Span$$($.$$.System.Char).$h},{"n":"casing","p":321957,"f":65,"v":0}],"n":"EncodeToUtf16","d":256421,"h":21475092901,"f":16777249},{"r":1310721,"p":[{"n":"bytes","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"casing","p":321957,"f":65,"v":0}],"n":"ToString","o":"@$1","d":256421,"h":25770060197,"f":16777249},{"r":458753,"p":[{"n":"value","p":655361}],"n":"ToCharUpper","d":256421,"h":34359994789,"f":16777249},{"r":458753,"p":[{"n":"value","p":655361}],"n":"ToCharLower","d":256421,"h":38654962085,"f":16777249},{"r":262145,"p":[{"n":"utf8Source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"destination","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"bytesProcessed","p":655361,"f":2}],"n":"TryDecodeFromUtf8","d":256421,"h":42949929381,"f":16777249},{"r":262145,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h},{"n":"destination","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"charsProcessed","p":655361,"f":2}],"n":"TryDecodeFromUtf16","d":256421,"h":47244896677,"f":16777249},{"r":262145,"p":[{"n":"utf8Source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"destination","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"bytesProcessed","p":655361,"f":2}],"n":"TryDecodeFromUtf8_Scalar","d":256421,"h":51539863973,"f":16777250},{"r":262145,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h},{"n":"destination","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"charsProcessed","p":655361,"f":2}],"n":"TryDecodeFromUtf16_Scalar","d":256421,"h":55834831269,"f":16777250},{"r":655361,"p":[{"n":"c","p":655361}],"n":"FromChar","d":256421,"h":60129798565,"f":16777249},{"r":655361,"p":[{"n":"c","p":655361}],"n":"FromUpperChar","d":256421,"h":64424765861,"f":16777249},{"r":655361,"p":[{"n":"c","p":655361}],"n":"FromLowerChar","d":256421,"h":68719733157,"f":16777249},{"r":262145,"p":[{"n":"c","p":655361}],"n":"IsHexChar","d":256421,"h":73014700453,"f":16777249},{"r":262145,"p":[{"n":"c","p":655361}],"n":"IsHexUpperChar","d":256421,"h":77309667749,"f":16777249},{"r":262145,"p":[{"n":"c","p":655361}],"n":"IsHexLowerChar","d":256421,"h":81604635045,"f":16777249}],"j":[321957,387493],"h":256421}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.HexConverter`; }
        });
        
        $asm.$str("$stew.System.Text.Encodings.Web.AsciiByteMap", ($self) => class AsciiByteMap extends $.$$.System.ValueType
        {
            /*int*/ static BufferSize = 128;
            /*byte[128]*/  get Buffer() { return this.$getField(0, 0x80000000|128); }
            /*byte[128]*/  set Buffer(value) { this.$setField(0, 0x80000000|128, value); }
            /*void */ InsertAsciiChar(/*char*/ key, /*byte*/ value)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(key < 128/*BufferSize*/, "key < BufferSize");
                $.$$.System.Diagnostics.Debug.Assert$2(value !== 0, "value != 0");
                if (key < 128/*BufferSize*/)
                {
                    this.Buffer[key] = value;
                }
            }
            /*bool */ TryLookup(/*Rune*/ key, /*out byte*/ value)
            {
                if (key.IsAscii)
                {
                    /*byte*/ let entry = this.Buffer[(key.Value >>> 0)];
                    if (entry !== 0)
                    {
                        value.$v = entry;
                        return true;
                    }
                }
                value.$v = 0;
                return false;
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                //InlineArray(128)
                copy.Buffer = [...this.Buffer];
                $.$$.System.Array.CopyMetadata(copy.Buffer, this.Buffer)
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //FixedSizeArray(byte*, 128)
                let $t1 = this.Buffer;
                $.$$.System.Array.AddMetadata($t1, $.$$.System.Byte.$type, null, null);
                for (let $i = 0; $i < 128; $i++)
                {
                    $t1[$i] = 0;
                }
            }
            static $h = 649637;
            static $z = 128;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"m":[{"r":65537,"p":[{"n":"key","p":458753},{"n":"value","p":393217}],"n":"InsertAsciiChar","d":649637,"h":12885551525,"f":16777224},{"r":262145,"p":[{"n":"key","p":122617857},{"n":"value","p":393217,"f":2}],"n":"TryLookup","d":649637,"h":17180518821,"f":16777224}],"l":[{"t":655361,"n":"BufferSize","d":649637,"h":4295616933,"f":4194338},{"t":$.$typePointer($.$$.System.Byte).$h,"n":"Buffer","d":649637,"h":8590584229,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$2","d":649637,"h":21475486117,"f":16777217}],"h":649637}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.Text.Encodings.Web.AsciiByteMap`; }
        });
        
        $asm.$str("$stew.System.Text.Encodings.Web.AllowedBmpCodePointsBitmap", ($self) => class AllowedBmpCodePointsBitmap extends $.$$.System.ValueType
        {
            /*int*/ static BitmapLengthInDWords = 2048;
            /*uint[2048]*/  get Bitmap() { return this.$getField(0, 0x80000000|2048); }
            /*uint[2048]*/  set Bitmap(value) { this.$setField(0, 0x80000000|2048, value); }
            /*void */ AllowChar(/*char*/ value)
            {
                /*nuint*/ let index;
                /*int*/ let offset;
                $.$stew.System.Text.Encodings.Web.AllowedBmpCodePointsBitmap._GetIndexAndOffset(value, $.$ref(() => index, ($v) => index = $v, $.$$.System.UIntPtr), $.$ref(() => offset, ($v) => offset = $v, $.$$.System.Int32));
                this.Bitmap[index] |= (1 << offset) >>> 0;
            }
            /*void */ ForbidChar(/*char*/ value)
            {
                /*nuint*/ let index;
                /*int*/ let offset;
                $.$stew.System.Text.Encodings.Web.AllowedBmpCodePointsBitmap._GetIndexAndOffset(value, $.$ref(() => index, ($v) => index = $v, $.$$.System.UIntPtr), $.$ref(() => offset, ($v) => offset = $v, $.$$.System.Int32));
                this.Bitmap[index] &= ~((1 << offset) >>> 0);
            }
            /*void */ ForbidHtmlCharacters()
            {
                this.ForbidChar(/*<*/ 60);
                this.ForbidChar(/*>*/ 62);
                this.ForbidChar(/*&*/ 38);
                this.ForbidChar(/*'*/ 39);
                this.ForbidChar(/*\"*/ 34);
                this.ForbidChar(/*+*/ 43);
            }
            /*void */ ForbidUndefinedCharacters()
            {
                /*fixed*/ 
                {
                    /*uint**/ let pBitmap = this.Bitmap;
                    /*ReadOnlySpan<byte>*/ let definedCharsBitmapAsLittleEndian = $.$stew.System.Text.Unicode.UnicodeHelpers.GetDefinedBmpCodePointsBitmapLittleEndian();
                    /*Span<uint>*/ let thisAllowedCharactersBitmap = new ($.$$.System.Span$$($.$$.System.UInt32))().$ctor$5(pBitmap, 2048/*BitmapLengthInDWords*/);
                    $.$$.System.Diagnostics.Debug.Assert$2(definedCharsBitmapAsLittleEndian.Length === ((thisAllowedCharactersBitmap.Length * $.$$.System.UInt32.$z) | 0), "definedCharsBitmapAsLittleEndian.Length == thisAllowedCharactersBitmap.Length * sizeof(uint)");
                    //if (Vector.IsHardwareAccelerated && BitConverter.IsLittleEndian) { ... }
                    for(/*int*/ let i = 0; i < thisAllowedCharactersBitmap.Length; i++)
                    {
                        thisAllowedCharactersBitmap.get_Item(i).$v &= $.$$.System.Buffers.Binary.BinaryPrimitives.ReadUInt32LittleEndian(definedCharsBitmapAsLittleEndian.Slice$1(((i * $.$$.System.UInt32.$z) | 0)));
                    }
                }
            }
            /*bool */ IsCharAllowed(/*char*/ value)
            {
                /*nuint*/ let index;
                /*int*/ let offset;
                $.$stew.System.Text.Encodings.Web.AllowedBmpCodePointsBitmap._GetIndexAndOffset(value, $.$ref(() => index, ($v) => index = $v, $.$$.System.UIntPtr), $.$ref(() => offset, ($v) => offset = $v, $.$$.System.Int32));
                if ((this.Bitmap[index] & ((1 << offset) >>> 0)) !== 0)
                {
                    return true;
                }
                else 
                {
                    return false;
                }
            }
            /*bool */ IsCodePointAllowed(/*uint*/ value)
            {
                if (!$.$stew.System.Text.UnicodeUtility.IsBmpCodePoint(value))
                {
                    return false;
                }
                /*nuint*/ let index;
                /*int*/ let offset;
                $.$stew.System.Text.Encodings.Web.AllowedBmpCodePointsBitmap._GetIndexAndOffset(value, $.$ref(() => index, ($v) => index = $v, $.$$.System.UIntPtr), $.$ref(() => offset, ($v) => offset = $v, $.$$.System.Int32));
                if ((this.Bitmap[index] & ((1 << offset) >>> 0)) !== 0)
                {
                    return true;
                }
                else 
                {
                    return false;
                }
            }
            static /*void */ _GetIndexAndOffset(/*uint*/ value, /*out nuint*/ index, /*out int*/ offset)
            {
                $.$stew.System.Text.UnicodeDebug.AssertIsBmpCodePoint(value);
                index.$v = value >>> 5;
                offset.$v = (value | 0) & 31;
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                //InlineArray(2048)
                copy.Bitmap = [...this.Bitmap];
                $.$$.System.Array.CopyMetadata(copy.Bitmap, this.Bitmap)
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //FixedSizeArray(uint*, 2048)
                let $t1 = this.Bitmap;
                $.$$.System.Array.AddMetadata($t1, $.$$.System.UInt32.$type, null, null);
                for (let $i = 0; $i < 2048; $i++)
                {
                    $t1[$i] = 0;
                }
            }
            static $h = 584101;
            static $z = 2048;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"m":[{"r":65537,"p":[{"n":"value","p":458753}],"n":"AllowChar","d":584101,"h":12885485989,"f":16777217},{"r":65537,"p":[{"n":"value","p":458753}],"n":"ForbidChar","d":584101,"h":17180453285,"f":16777217},{"r":65537,"n":"ForbidHtmlCharacters","d":584101,"h":21475420581,"f":16777217},{"r":65537,"n":"ForbidUndefinedCharacters","d":584101,"h":25770387877,"f":16777217},{"r":262145,"p":[{"n":"value","p":458753}],"n":"IsCharAllowed","d":584101,"h":30065355173,"f":16777217},{"r":262145,"p":[{"n":"value","p":720897}],"n":"IsCodePointAllowed","d":584101,"h":34360322469,"f":16777217},{"r":65537,"p":[{"n":"value","p":720897},{"n":"index","p":851969,"f":2},{"n":"offset","p":655361,"f":2}],"n":"_GetIndexAndOffset","d":584101,"h":38655289765,"f":16777250}],"l":[{"t":655361,"n":"BitmapLengthInDWords","d":584101,"h":4295551397,"f":4194338},{"t":$.$typePointer($.$$.System.UInt32).$h,"n":"Bitmap","d":584101,"h":8590518693,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$2","d":584101,"h":42950257061,"f":16777217}],"h":584101}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.Text.Encodings.Web.AllowedBmpCodePointsBitmap`; }
        });
        
        $asm.$str("$stew.System.Text.ValueStringBuilder", ($self) => class ValueStringBuilder extends $.$$.System.ValueType
        {
            /*char[]?*/  get _arrayToReturnToPool() { return this.$getField(0, 4); }
            /*char[]?*/  set _arrayToReturnToPool(value) { this.$setField(0, 4, value); }
            /*Span<char>*/  get _chars() { return this.$getField(4, 6); }
            /*Span<char>*/  set _chars(value) { this.$setField(4, 6, value); }
            /*int*/  get _pos() { return this.$getField(10, 4); }
            /*int*/  set _pos(value) { this.$setField(10, 4, value); }
            $ctor$4(/*Span<char>*/ initialBuffer)
            {
                super.$ctor$1();
                {
                    this._arrayToReturnToPool = null;
                    this._chars = initialBuffer;
                    this._pos = 0;
                }
                return this;
            }
            $ctor$3(/*int*/ initialCapacity)
            {
                super.$ctor$1();
                {
                    this._arrayToReturnToPool = $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared.Rent(initialCapacity);
                    this._chars = $.$$.System.Span$$($.$$.System.Char).op_Implicit$2(this._arrayToReturnToPool);
                    this._pos = 0;
                }
                return this;
            }
            /*int */ get Length()
            {
                return this._pos;
            }
            /*int */ set Length(value)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(value >= 0, "value >= 0");
                $.$$.System.Diagnostics.Debug.Assert$2(value <= this._chars.Length, "value <= _chars.Length");
                this._pos = value;
            }
            /*int */ get Capacity()
            {
                return this._chars.Length;
            }
            /*void */ EnsureCapacity(/*int*/ capacity)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(capacity >= 0, "capacity >= 0");
                if ((capacity >>> 0) > (this._chars.Length >>> 0))
                {
                    this.Grow(((capacity - this._pos) | 0));
                }
            }
            /*ref char */ GetPinnableReference()
            {
                return $.$$.System.Runtime.InteropServices.MemoryMarshal.GetReference$1($.$$.System.Char, this._chars);
            }
            /*ref char */ GetPinnableReference$1(/*bool*/ terminate)
            {
                if (terminate)
                {
                    this.EnsureCapacity(((this.Length + 1) | 0));
                    this._chars.get_Item(this.Length).$v = /*\u0000*/ 0;
                }
                return $.$$.System.Runtime.InteropServices.MemoryMarshal.GetReference$1($.$$.System.Char, this._chars);
            }
            /*ref char*/ get_Item(/*int*/ index)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(index < this._pos, "index < _pos");
                return this._chars.get_Item(index);
            }
            static/*conventional*/ /*string */ ToString()
            {
                /*string*/ let s = $.$$.System.Span$$($.$$.System.Char).ToString.call(this._chars.Slice(0, this._pos));
                this.Dispose();
                return s;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$stew.System.Text.ValueStringBuilder.ToString.apply(this, arguments); }
            /*Span<char> */ get RawChars()
            {
                return this._chars;
            }
            /*ReadOnlySpan<char> */ AsSpan$1(/*bool*/ terminate)
            {
                if (terminate)
                {
                    this.EnsureCapacity(((this.Length + 1) | 0));
                    this._chars.get_Item(this.Length).$v = /*\u0000*/ 0;
                }
                return $.$$.System.Span$$($.$$.System.Char).op_Implicit(this._chars.Slice(0, this._pos));
            }
            /*ReadOnlySpan<char> */ AsSpan()
            {
                return $.$$.System.Span$$($.$$.System.Char).op_Implicit(this._chars.Slice(0, this._pos));
            }
            /*ReadOnlySpan<char> */ AsSpan$3(/*int*/ start)
            {
                return $.$$.System.Span$$($.$$.System.Char).op_Implicit(this._chars.Slice(start, ((this._pos - start) | 0)));
            }
            /*ReadOnlySpan<char> */ AsSpan$2(/*int*/ start, /*int*/ length)
            {
                return $.$$.System.Span$$($.$$.System.Char).op_Implicit(this._chars.Slice(start, length));
            }
            /*bool */ TryCopyTo(/*Span<char>*/ destination, /*out int*/ charsWritten)
            {
                if (this._chars.Slice(0, this._pos).TryCopyTo(destination))
                {
                    charsWritten.$v = this._pos;
                    this.Dispose();
                    return true;
                }
                else 
                {
                    charsWritten.$v = 0;
                    this.Dispose();
                    return false;
                }
            }
            /*void */ Insert(/*int*/ index, /*char*/ value, /*int*/ count)
            {
                if (this._pos > ((this._chars.Length - count) | 0))
                {
                    this.Grow(count);
                }
                /*int*/ let remaining = ((this._pos - index) | 0);
                this._chars.Slice(index, remaining).CopyTo(this._chars.Slice$1(((index + count) | 0)));
                this._chars.Slice(index, count).Fill(value);
                this._pos += count;
            }
            /*void */ Insert$1(/*int*/ index, /*string?*/ s)
            {
                if ($.$$.System.String.op_Equality(s, null))
                {
                    return;
                }
                /*int*/ let count = s.length;
                if (this._pos > (((this._chars.Length - count) | 0)))
                {
                    this.Grow(count);
                }
                /*int*/ let remaining = ((this._pos - index) | 0);
                this._chars.Slice(index, remaining).CopyTo(this._chars.Slice$1(((index + count) | 0)));
                $.$$.System.String.CopyTo$1.call(s, this._chars.Slice$1(index));
                this._pos += count;
            }
            /*void */ Append$1(/*char*/ c)
            {
                /*int*/ let pos = this._pos;
                /*Span<char>*/ let chars = this._chars;
                if ((pos >>> 0) < (chars.Length >>> 0))
                {
                    chars.get_Item(pos).$v = c;
                    this._pos = ((pos + 1) | 0);
                }
                else 
                {
                    this.GrowAndAppend(c);
                }
            }
            /*void */ Append$3(/*string?*/ s)
            {
                if ($.$$.System.String.op_Equality(s, null))
                {
                    return;
                }
                /*int*/ let pos = this._pos;
                if (s.length === 1 && (pos >>> 0) < (this._chars.Length >>> 0))
                {
                    this._chars.get_Item(pos).$v = $.$$.System.String.get_Chars.call(s, 0);
                    this._pos = ((pos + 1) | 0);
                }
                else 
                {
                    this.AppendSlow(s);
                }
            }
            /*void */ AppendSlow(/*string*/ s)
            {
                /*int*/ let pos = this._pos;
                if (pos > ((this._chars.Length - s.length) | 0))
                {
                    this.Grow(s.length);
                }
                $.$$.System.String.CopyTo$1.call(s, this._chars.Slice$1(pos));
                this._pos += s.length;
            }
            /*void */ Append(/*char*/ c, /*int*/ count)
            {
                if (this._pos > ((this._chars.Length - count) | 0))
                {
                    this.Grow(count);
                }
                /*Span<char>*/ let dst = this._chars.Slice(this._pos, count);
                for(/*int*/ let i = 0; i < dst.Length; i++)
                {
                    dst.get_Item(i).$v = c;
                }
                this._pos += count;
            }
            /*void */ Append$2(/*scoped ReadOnlySpan<char>*/ value)
            {
                /*int*/ let pos = this._pos;
                if (pos > ((this._chars.Length - value.Length) | 0))
                {
                    this.Grow(value.Length);
                }
                value.CopyTo(this._chars.Slice$1(this._pos));
                this._pos += value.Length;
            }
            /*Span<char> */ AppendSpan(/*int*/ length)
            {
                /*int*/ let origPos = this._pos;
                if (origPos > ((this._chars.Length - length) | 0))
                {
                    this.Grow(length);
                }
                this._pos = ((origPos + length) | 0);
                return this._chars.Slice(origPos, length);
            }
            /*void */ GrowAndAppend(/*char*/ c)
            {
                this.Grow(1);
                this.Append$1(c);
            }
            /*void */ Grow(/*int*/ additionalCapacityBeyondPos)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(additionalCapacityBeyondPos > 0, "additionalCapacityBeyondPos > 0");
                $.$$.System.Diagnostics.Debug.Assert$2(this._pos > ((this._chars.Length - additionalCapacityBeyondPos) | 0), "Grow called incorrectly, no resize is needed.");
                /*uint*/ let ArrayMaxLength = 2147483591;
                /*int*/ let newCapacity = ($.$$.System.Math.Max$10(((((this._pos + additionalCapacityBeyondPos) | 0)) >>> 0), $.$$.System.Math.Min$10((((this._chars.Length >>> 0) * 2) >>> 0), ArrayMaxLength)) | 0);
                /*char[]*/ let poolArray = $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared.Rent(newCapacity);
                this._chars.Slice(0, this._pos).CopyTo($.$$.System.Span$$($.$$.System.Char).op_Implicit$2(poolArray));
                /*char[]?*/ let toReturn = this._arrayToReturnToPool;
                this._chars = $.$$.System.Span$$($.$$.System.Char).op_Implicit$2(this._arrayToReturnToPool = poolArray);
                if (toReturn !== null)
                {
                    $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared.Return(toReturn, false);
                }
            }
            /*void */ Dispose()
            {
                /*char[]?*/ let toReturn = this._arrayToReturnToPool;
                new $.$stew.System.Text.ValueStringBuilder().Clone(this);
                if (toReturn !== null)
                {
                    $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared.Return(toReturn, false);
                }
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._arrayToReturnToPool = this._arrayToReturnToPool;
                copy._chars = this._chars.Clone();
                copy._pos = this._pos;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._arrayToReturnToPool = null;
                this._chars = $.$default($.$$.System.Span$$($.$$.System.Char));
                this._pos = 0;
            }
            static $h = 2091429;
            static $z = 14;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":655361,"g":{"r":0,"d":0,"h":30066862501,"f":50331649},"s":{"r":0,"d":0,"h":34361829797,"f":83886081},"n":"Length","d":2091429,"h":25771895205,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":42951764389,"f":50331649},"n":"Capacity","d":2091429,"h":38656797093,"f":2097153},{"p":458753,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":64426600869,"f":50331649},"n":"Item","o":"@$2","d":2091429,"h":60131633573,"f":2097153},{"p":$.$$.System.Span$$($.$$.System.Char).$h,"g":{"r":0,"d":0,"h":77311502757,"f":50331649},"n":"RawChars","d":2091429,"h":73016535461,"f":2097153}],"m":[{"r":65537,"p":[{"n":"capacity","p":655361}],"n":"EnsureCapacity","d":2091429,"h":47246731685,"f":16777217},{"r":458753,"n":"GetPinnableReference","d":2091429,"h":51541698981,"f":16777217},{"r":458753,"p":[{"n":"terminate","p":262145}],"n":"GetPinnableReference","o":"@$1","d":2091429,"h":55836666277,"f":16777217},{"r":1310721,"n":"ToString","d":2091429,"h":68721568165,"f":16809985},{"r":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h,"p":[{"n":"terminate","p":262145}],"n":"AsSpan","o":"@$1","d":2091429,"h":81606470053,"f":16777217},{"r":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h,"n":"AsSpan","d":2091429,"h":85901437349,"f":16777217},{"r":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h,"p":[{"n":"start","p":655361}],"n":"AsSpan","o":"@$3","d":2091429,"h":90196404645,"f":16777217},{"r":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h,"p":[{"n":"start","p":655361},{"n":"length","p":655361}],"n":"AsSpan","o":"@$2","d":2091429,"h":94491371941,"f":16777217},{"r":262145,"p":[{"n":"destination","p":$.$$.System.Span$$($.$$.System.Char).$h},{"n":"charsWritten","p":655361,"f":2}],"n":"TryCopyTo","d":2091429,"h":98786339237,"f":16777217},{"r":65537,"p":[{"n":"index","p":655361},{"n":"value","p":458753},{"n":"count","p":655361}],"n":"Insert","d":2091429,"h":103081306533,"f":16777217},{"r":65537,"p":[{"n":"index","p":655361},{"n":"s","p":1310721}],"n":"Insert","o":"@$1","d":2091429,"h":107376273829,"f":16777217},{"r":65537,"p":[{"n":"c","p":458753}],"n":"Append","o":"@$1","d":2091429,"h":111671241125,"f":16777217},{"r":65537,"p":[{"n":"s","p":1310721}],"n":"Append","o":"@$3","d":2091429,"h":115966208421,"f":16777217},{"r":65537,"p":[{"n":"s","p":1310721}],"n":"AppendSlow","d":2091429,"h":120261175717,"f":16777218},{"r":65537,"p":[{"n":"c","p":458753},{"n":"count","p":655361}],"n":"Append","d":2091429,"h":124556143013,"f":16777217},{"r":65537,"p":[{"n":"value","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h}],"n":"Append","o":"@$2","d":2091429,"h":128851110309,"f":16777217},{"r":$.$$.System.Span$$($.$$.System.Char).$h,"p":[{"n":"length","p":655361}],"n":"AppendSpan","d":2091429,"h":133146077605,"f":16777217},{"r":65537,"p":[{"n":"c","p":458753}],"n":"GrowAndAppend","d":2091429,"h":137441044901,"f":16777218},{"r":65537,"p":[{"n":"additionalCapacityBeyondPos","p":655361}],"n":"Grow","d":2091429,"h":141736012197,"f":16777218},{"r":65537,"n":"Dispose","d":2091429,"h":146030979493,"f":16777217}],"l":[{"t":$.$typeArray($.$$.System.Char).$h,"n":"_arrayToReturnToPool","d":2091429,"h":4297058725,"f":4194306},{"t":$.$$.System.Span$$($.$$.System.Char).$h,"n":"_chars","d":2091429,"h":8592026021,"f":4194306},{"t":655361,"n":"_pos","d":2091429,"h":12886993317,"f":4194306}],"c":[{"p":[{"n":"initialBuffer","p":$.$$.System.Span$$($.$$.System.Char).$h}],"n":".ctor","o":"$ctor$4","d":2091429,"h":17181960613,"f":16777217},{"p":[{"n":"initialCapacity","p":655361}],"n":".ctor","o":"$ctor$3","d":2091429,"h":21476927909,"f":16777217},{"n":".ctor","o":"$ctor$2","d":2091429,"h":150325946789,"f":16777217}],"h":2091429}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.Text.ValueStringBuilder`; }
        });
        
        $asm.$cls("$stew.System.Text.Encodings.Web.DefaultHtmlEncoder", ($self) => class DefaultHtmlEncoder extends $.$stew.System.Text.Encodings.Web.HtmlEncoder
        {
            /*DefaultHtmlEncoder*/ static BasicLatinSingleton = null;
            /*OptimizedInboxTextEncoder*/ _innerEncoder = null;
            $ctor$3(/*TextEncoderSettings*/ settings)
            {
                super.$ctor$2();
                {
                    if (settings === null)
                    {
                        $.$stew.System.Text.Encodings.Web.ThrowHelper.ThrowArgumentNullException(1/*ExceptionArgument.settings*/);
                    }
                    this._innerEncoder = new $.$stew.System.Text.Encodings.Web.OptimizedInboxTextEncoder().$ctor$1($.$stew.System.Text.Encodings.Web.DefaultHtmlEncoder.EscaperImplementation.Singleton, settings.GetAllowedCodePointsBitmap(), true, new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))());
                }
                return this;
            }
            /*int */ get MaxOutputCharactersPerInputCharacter()
            {
                return 8;
            }
            /*OperationStatus */ EncodeCore$1(/*ReadOnlySpan<char>*/ source, /*Span<char>*/ destination, /*out int*/ charsConsumed, /*out int*/ charsWritten, /*bool*/ isFinalBlock)
            {
                return this._innerEncoder.Encode(source, destination, charsConsumed, charsWritten, isFinalBlock);
            }
            /*OperationStatus */ EncodeUtf8Core(/*ReadOnlySpan<byte>*/ utf8Source, /*Span<byte>*/ utf8Destination, /*out int*/ bytesConsumed, /*out int*/ bytesWritten, /*bool*/ isFinalBlock)
            {
                return this._innerEncoder.EncodeUtf8(utf8Source, utf8Destination, bytesConsumed, bytesWritten, isFinalBlock);
            }
            /*int */ FindFirstCharacterToEncode$1(/*ReadOnlySpan<char>*/ text)
            {
                return this._innerEncoder.GetIndexOfFirstCharToEncode(text);
            }
            /*int */ FindFirstCharacterToEncode(/*char**/ text, /*int*/ textLength)
            {
                return this._innerEncoder.FindFirstCharacterToEncode(text, textLength);
            }
            /*int */ FindFirstCharacterToEncodeUtf8(/*ReadOnlySpan<byte>*/ utf8Text)
            {
                return this._innerEncoder.GetIndexOfFirstByteToEncode(utf8Text);
            }
            /*bool */ TryEncodeUnicodeScalar(/*int*/ unicodeScalar, /*char**/ buffer, /*int*/ bufferLength, /*out int*/ numberOfCharactersWritten)
            {
                return this._innerEncoder.TryEncodeUnicodeScalar(unicodeScalar, buffer, bufferLength, numberOfCharactersWritten);
            }
            /*bool */ WillEncode(/*int*/ unicodeScalar)
            {
                return !this._innerEncoder.IsScalarValueAllowed(new $.$$.System.Text.Rune().$ctor$5(unicodeScalar));
            }
            static $_EscaperImplementation;
            static get EscaperImplementation()
            {
                let $cls = $.$stew.System.Text.Encodings.Web.DefaultHtmlEncoder;
                return $cls.$_EscaperImplementation ??= $asm.$ncls("$stew.System.Text.Encodings.Web.DefaultHtmlEncoder.EscaperImplementation", ($self) => class EscaperImplementation extends $.$stew.System.Text.Encodings.Web.ScalarEscaperBase
                {
                    /*EscaperImplementation*/ static Singleton = null;
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    /*int */ EncodeUtf8(/*Rune*/ value, /*Span<byte>*/ destination)
                    {
                        let $gotoJumpState1 = 0;
                        $gotoJumpStart1: while(true)
                        {
                            switch($gotoJumpState1)
                            {
                                case 0:
                                {
                                    if (value.Value === /*<*/ 60)
                                    {
                                        if (!new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([38, 108, 116, 59]).TryCopyTo(destination))
                                        {
                                            $gotoJumpState1 = 1; /*goto OutOfSpace*/
                                            continue $gotoJumpStart1;
                                        }
                                        return 4;
                                    }
                                    else if (value.Value === /*>*/ 62)
                                    {
                                        if (!new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([38, 103, 116, 59]).TryCopyTo(destination))
                                        {
                                            $gotoJumpState1 = 1; /*goto OutOfSpace*/
                                            continue $gotoJumpStart1;
                                        }
                                        return 4;
                                    }
                                    else if (value.Value === /*&*/ 38)
                                    {
                                        if (!new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([38, 97, 109, 112, 59]).TryCopyTo(destination))
                                        {
                                            $gotoJumpState1 = 1; /*goto OutOfSpace*/
                                            continue $gotoJumpStart1;
                                        }
                                        return 5;
                                    }
                                    else if (value.Value === /*\"*/ 34)
                                    {
                                        if (!new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([38, 113, 117, 111, 116, 59]).TryCopyTo(destination))
                                        {
                                            $gotoJumpState1 = 1; /*goto OutOfSpace*/
                                            continue $gotoJumpStart1;
                                        }
                                        return 6;
                                    }
                                    else 
                                    {
                                        return TryEncodeScalarAsHex(this, (value.Value >>> 0), destination);
                                    }
                                }
                                case 1: /*OutOfSpace*/
                                return -1;
                                /*static int*/  function TryEncodeScalarAsHex(/*object*/ $this, /*uint*/ scalarValue, /*Span<byte>*/ destination)
                                {
                                    /*int*/ let idxOfSemicolon;
                                    let $gotoJumpState2 = 0;
                                    $gotoJumpStart2: while(true)
                                    {
                                        switch($gotoJumpState2)
                                        {
                                            case 0:
                                            {
                                                $.$stew.System.Text.UnicodeDebug.AssertIsValidScalar(scalarValue);
                                                idxOfSemicolon = (((($.trunc(($.$$.System.Numerics.BitOperations.Log2(scalarValue) >>> 0) / 4)) | 0) + 4) | 0);
                                                $.$$.System.Diagnostics.Debug.Assert$2(4 <= idxOfSemicolon && idxOfSemicolon <= 9, "Expected '&#x0;'..'&#x10FFFF;'.");
                                                if ((destination.Length >>> 0) <= (idxOfSemicolon >>> 0))
                                                {
                                                    $gotoJumpState2 = 1; /*goto OutOfSpaceInner*/
                                                    continue $gotoJumpStart2;
                                                }
                                                destination.get_Item(idxOfSemicolon).$v = /*;*/ 59;
                                                if (!new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([38, 35, 120, 48]).TryCopyTo(destination))
                                                {
                                                    $.$$.System.Diagnostics.Debug.Fail$1("We should've had enough room to write 4 bytes.");
                                                }
                                                destination = destination.Slice(3, ((idxOfSemicolon - 3) | 0));
                                                for(/*int*/ let i = ((destination.Length - 1) | 0); (destination.Length >>> 0) > (i >>> 0); i--)
                                                {
                                                    /*char*/ let asUpperHex = $.$stew.System.HexConverter.ToCharUpper((scalarValue | 0));
                                                    destination.get_Item(i).$v = $.$cast(asUpperHex, $.$$.System.Byte);
                                                    scalarValue >>= 4;
                                                }
                                                return ((destination.Length + 4) | 0);
                                            }
                                            case 1: /*OutOfSpaceInner*/
                                            return -1;
                                        }
                                        break;
                                    }
                                }
                            }
                            break;
                        }
                    }
                    /*int */ EncodeUtf16(/*Rune*/ value, /*Span<char>*/ destination)
                    {
                        let $gotoJumpState1 = 0;
                        $gotoJumpStart1: while(true)
                        {
                            switch($gotoJumpState1)
                            {
                                case 0:
                                {
                                    if (value.Value === /*<*/ 60)
                                    {
                                        if (!$.$$.System.MemoryExtensions.AsSpan$4("&lt;").TryCopyTo(destination))
                                        {
                                            $gotoJumpState1 = 1; /*goto OutOfSpace*/
                                            continue $gotoJumpStart1;
                                        }
                                        return 4;
                                    }
                                    else if (value.Value === /*>*/ 62)
                                    {
                                        if (!$.$$.System.MemoryExtensions.AsSpan$4("&gt;").TryCopyTo(destination))
                                        {
                                            $gotoJumpState1 = 1; /*goto OutOfSpace*/
                                            continue $gotoJumpStart1;
                                        }
                                        return 4;
                                    }
                                    else if (value.Value === /*&*/ 38)
                                    {
                                        if (!$.$$.System.MemoryExtensions.AsSpan$4("&amp;").TryCopyTo(destination))
                                        {
                                            $gotoJumpState1 = 1; /*goto OutOfSpace*/
                                            continue $gotoJumpStart1;
                                        }
                                        return 5;
                                    }
                                    else if (value.Value === /*\"*/ 34)
                                    {
                                        if (!$.$$.System.MemoryExtensions.AsSpan$4("&quot;").TryCopyTo(destination))
                                        {
                                            $gotoJumpState1 = 1; /*goto OutOfSpace*/
                                            continue $gotoJumpStart1;
                                        }
                                        return 6;
                                    }
                                    else 
                                    {
                                        return TryEncodeScalarAsHex(this, (value.Value >>> 0), destination);
                                    }
                                }
                                case 1: /*OutOfSpace*/
                                return -1;
                                /*static int*/  function TryEncodeScalarAsHex(/*object*/ $this, /*uint*/ scalarValue, /*Span<char>*/ destination)
                                {
                                    /*int*/ let idxOfSemicolon;
                                    let $gotoJumpState2 = 0;
                                    $gotoJumpStart2: while(true)
                                    {
                                        switch($gotoJumpState2)
                                        {
                                            case 0:
                                            {
                                                $.$stew.System.Text.UnicodeDebug.AssertIsValidScalar(scalarValue);
                                                idxOfSemicolon = (((($.trunc(($.$$.System.Numerics.BitOperations.Log2(scalarValue) >>> 0) / 4)) | 0) + 4) | 0);
                                                $.$$.System.Diagnostics.Debug.Assert$2(4 <= idxOfSemicolon && idxOfSemicolon <= 9, "Expected '&#x0;'..'&#x10FFFF;'.");
                                                if ((destination.Length >>> 0) <= (idxOfSemicolon >>> 0))
                                                {
                                                    $gotoJumpState2 = 1; /*goto OutOfSpaceInner*/
                                                    continue $gotoJumpStart2;
                                                }
                                                destination.get_Item(idxOfSemicolon).$v = /*;*/ 59;
                                                if (!$.$$.System.MemoryExtensions.AsSpan$4("&#x0").TryCopyTo(destination))
                                                {
                                                    $.$$.System.Diagnostics.Debug.Fail$1("We should've had enough room to write 4 chars.");
                                                }
                                                destination = destination.Slice(3, ((idxOfSemicolon - 3) | 0));
                                                for(/*int*/ let i = ((destination.Length - 1) | 0); (destination.Length >>> 0) > (i >>> 0); i--)
                                                {
                                                    /*char*/ let asUpperHex = $.$stew.System.HexConverter.ToCharUpper((scalarValue | 0));
                                                    destination.get_Item(i).$v = asUpperHex;
                                                    scalarValue >>= 4;
                                                }
                                                return ((destination.Length + 4) | 0);
                                            }
                                            case 1: /*OutOfSpaceInner*/
                                            return -1;
                                        }
                                        break;
                                    }
                                }
                            }
                            break;
                        }
                    }
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            this.Singleton = new $.$stew.System.Text.Encodings.Web.DefaultHtmlEncoder.EscaperImplementation().$ctor$2();
                        }
                    }
                    static $h = 780709;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1436069,"m":[{"r":655361,"p":[{"n":"value","p":122617857},{"n":"destination","p":$.$$.System.Span$$($.$$.System.Byte).$h}],"n":"EncodeUtf8","d":780709,"h":12885682597,"f":16809992},{"r":655361,"p":[{"n":"value","p":122617857},{"n":"destination","p":$.$$.System.Span$$($.$$.System.Char).$h}],"n":"EncodeUtf16","d":780709,"h":17180649893,"f":16809992}],"l":[{"t":780709,"n":"Singleton","d":780709,"h":4295748005,"f":4194344}],"c":[{"n":".ctor","o":"$ctor$2","d":780709,"h":8590715301,"f":16777218}],"d":715173,"h":780709}; }
                    static get $b() { return $.$stew.System.Text.Encodings.Web.ScalarEscaperBase; }
                    static get $fullName() { return `System.Text.Encodings.Web.DefaultHtmlEncoder.EscaperImplementation`; }
                }, $cls, ($v) => $cls.$_EscaperImplementation = $v);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.BasicLatinSingleton = new $.$stew.System.Text.Encodings.Web.DefaultHtmlEncoder().$ctor$3(new $.$stew.System.Text.Encodings.Web.TextEncoderSettings().$ctor$3($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$stew.System.Text.Unicode.UnicodeRange), [ $.$stew.System.Text.Unicode.UnicodeRanges.BasicLatin ], null, null)));
                }
            }
            static $h = 715173;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1173925,"p":[{"p":655361,"g":{"r":0,"d":0,"h":21475551653,"f":50364417},"n":"MaxOutputCharactersPerInputCharacter","d":715173,"h":17180584357,"f":2129921}],"m":[{"r":18743297,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h},{"n":"destination","p":$.$$.System.Span$$($.$$.System.Char).$h},{"n":"charsConsumed","p":655361,"f":2},{"n":"charsWritten","p":655361,"f":2},{"n":"isFinalBlock","p":262145}],"n":"EncodeCore","o":"@$1","d":715173,"h":25770518949,"f":16809984},{"r":18743297,"p":[{"n":"utf8Source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"utf8Destination","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"bytesConsumed","p":655361,"f":2},{"n":"bytesWritten","p":655361,"f":2},{"n":"isFinalBlock","p":262145}],"n":"EncodeUtf8Core","d":715173,"h":30065486245,"f":16809984},{"r":655361,"p":[{"n":"text","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h}],"n":"FindFirstCharacterToEncode","o":"@$1","d":715173,"h":34360453541,"f":16809984},{"r":655361,"p":[{"n":"text","p":$.$typePointer($.$$.System.Char).$h},{"n":"textLength","p":655361}],"n":"FindFirstCharacterToEncode","d":715173,"h":38655420837,"f":16809985},{"r":655361,"p":[{"n":"utf8Text","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h}],"n":"FindFirstCharacterToEncodeUtf8","d":715173,"h":42950388133,"f":16809985},{"r":262145,"p":[{"n":"unicodeScalar","p":655361},{"n":"buffer","p":$.$typePointer($.$$.System.Char).$h},{"n":"bufferLength","p":655361},{"n":"numberOfCharactersWritten","p":655361,"f":2}],"n":"TryEncodeUnicodeScalar","d":715173,"h":47245355429,"f":16809985},{"r":262145,"p":[{"n":"unicodeScalar","p":655361}],"n":"WillEncode","d":715173,"h":51540322725,"f":16809985}],"l":[{"t":715173,"n":"BasicLatinSingleton","d":715173,"h":4295682469,"f":4194344},{"t":1304997,"n":"_innerEncoder","d":715173,"h":8590649765,"f":4194306}],"c":[{"p":[{"n":"settings","p":1567141}],"n":".ctor","o":"$ctor$3","d":715173,"h":12885617061,"f":16777224}],"j":[780709],"h":715173}; }
            static get $b() { return $.$stew.System.Text.Encodings.Web.HtmlEncoder; }
            static get $fullName() { return `System.Text.Encodings.Web.DefaultHtmlEncoder`; }
        });
        
        $asm.$cls("$stew.System.Text.Encodings.Web.DefaultUrlEncoder", ($self) => class DefaultUrlEncoder extends $.$stew.System.Text.Encodings.Web.UrlEncoder
        {
            /*DefaultUrlEncoder*/ static BasicLatinSingleton = null;
            /*OptimizedInboxTextEncoder*/ _innerEncoder = null;
            $ctor$3(/*TextEncoderSettings*/ settings)
            {
                super.$ctor$2();
                {
                    if (settings === null)
                    {
                        $.$stew.System.Text.Encodings.Web.ThrowHelper.ThrowArgumentNullException(1/*ExceptionArgument.settings*/);
                    }
                    this._innerEncoder = new $.$stew.System.Text.Encodings.Web.OptimizedInboxTextEncoder().$ctor$1($.$stew.System.Text.Encodings.Web.DefaultUrlEncoder.EscaperImplementation.Singleton, settings.GetAllowedCodePointsBitmap(), true, $.$$.System.ReadOnlySpan$$($.$$.System.Char).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Char), [/* */ 32, /*#*/ 35, /*%*/ 37, /*/*/ 47, /*:*/ 58, /*=*/ 61, /*?*/ 63, /*[*/ 91, /*\\*/ 92, /*]*/ 93, /*^*/ 94, /*`*/ 96, /*{*/ 123, /*|*/ 124, /*}*/ 125, /*\uFFF0*/ 65520, /*\uFFF1*/ 65521, /*\uFFF2*/ 65522, /*\uFFF3*/ 65523, /*\uFFF4*/ 65524, /*\uFFF5*/ 65525, /*\uFFF6*/ 65526, /*\uFFF7*/ 65527, /*\uFFF8*/ 65528, /*\uFFF9*/ 65529, /*\uFFFA*/ 65530, /*\uFFFB*/ 65531, /*\uFFFC*/ 65532, /*\uFFFD*/ 65533, /*\uFFFE*/ 65534, /*\uFFFF*/ 65535], null, null)));
                }
                return this;
            }
            /*int */ get MaxOutputCharactersPerInputCharacter()
            {
                return 9;
            }
            /*OperationStatus */ EncodeCore$1(/*ReadOnlySpan<char>*/ source, /*Span<char>*/ destination, /*out int*/ charsConsumed, /*out int*/ charsWritten, /*bool*/ isFinalBlock)
            {
                return this._innerEncoder.Encode(source, destination, charsConsumed, charsWritten, isFinalBlock);
            }
            /*OperationStatus */ EncodeUtf8Core(/*ReadOnlySpan<byte>*/ utf8Source, /*Span<byte>*/ utf8Destination, /*out int*/ bytesConsumed, /*out int*/ bytesWritten, /*bool*/ isFinalBlock)
            {
                return this._innerEncoder.EncodeUtf8(utf8Source, utf8Destination, bytesConsumed, bytesWritten, isFinalBlock);
            }
            /*int */ FindFirstCharacterToEncode$1(/*ReadOnlySpan<char>*/ text)
            {
                return this._innerEncoder.GetIndexOfFirstCharToEncode(text);
            }
            /*int */ FindFirstCharacterToEncode(/*char**/ text, /*int*/ textLength)
            {
                return this._innerEncoder.FindFirstCharacterToEncode(text, textLength);
            }
            /*int */ FindFirstCharacterToEncodeUtf8(/*ReadOnlySpan<byte>*/ utf8Text)
            {
                return this._innerEncoder.GetIndexOfFirstByteToEncode(utf8Text);
            }
            /*bool */ TryEncodeUnicodeScalar(/*int*/ unicodeScalar, /*char**/ buffer, /*int*/ bufferLength, /*out int*/ numberOfCharactersWritten)
            {
                return this._innerEncoder.TryEncodeUnicodeScalar(unicodeScalar, buffer, bufferLength, numberOfCharactersWritten);
            }
            /*bool */ WillEncode(/*int*/ unicodeScalar)
            {
                return !this._innerEncoder.IsScalarValueAllowed(new $.$$.System.Text.Rune().$ctor$5(unicodeScalar));
            }
            static $_EscaperImplementation;
            static get EscaperImplementation()
            {
                let $cls = $.$stew.System.Text.Encodings.Web.DefaultUrlEncoder;
                return $cls.$_EscaperImplementation ??= $asm.$ncls("$stew.System.Text.Encodings.Web.DefaultUrlEncoder.EscaperImplementation", ($self) => class EscaperImplementation extends $.$stew.System.Text.Encodings.Web.ScalarEscaperBase
                {
                    /*EscaperImplementation*/ static Singleton = null;
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    /*int */ EncodeUtf8(/*Rune*/ value, /*Span<byte>*/ destination)
                    {
                        /*uint*/ let utf8lsb;
                        let $gotoJumpState1 = 0;
                        $gotoJumpStart1: while(true)
                        {
                            switch($gotoJumpState1)
                            {
                                case 0:
                                {
                                    utf8lsb = ($.$stew.System.Text.Unicode.UnicodeHelpers.GetUtf8RepresentationForScalarValue((value.Value >>> 0)) >>> 0);
                                    if ((destination.Length >>> 0) <= 2)
                                    {
                                        $gotoJumpState1 = 1; /*goto OutOfSpace*/
                                        continue $gotoJumpStart1;
                                    }
                                    destination.get_Item(0).$v = /*%*/ 37;
                                    $.$stew.System.HexConverter.ToBytesBuffer($.$cast(utf8lsb, $.$$.System.Byte), destination, 1, 0);
                                    if ((utf8lsb >>= 8) === 0)
                                    {
                                        return 3;
                                    }
                                    if ((destination.Length >>> 0) <= 5)
                                    {
                                        $gotoJumpState1 = 1; /*goto OutOfSpace*/
                                        continue $gotoJumpStart1;
                                    }
                                    destination.get_Item(3).$v = /*%*/ 37;
                                    $.$stew.System.HexConverter.ToBytesBuffer($.$cast(utf8lsb, $.$$.System.Byte), destination, 4, 0);
                                    if ((utf8lsb >>= 8) === 0)
                                    {
                                        return 6;
                                    }
                                    if ((destination.Length >>> 0) <= 8)
                                    {
                                        $gotoJumpState1 = 1; /*goto OutOfSpace*/
                                        continue $gotoJumpStart1;
                                    }
                                    destination.get_Item(6).$v = /*%*/ 37;
                                    $.$stew.System.HexConverter.ToBytesBuffer($.$cast(utf8lsb, $.$$.System.Byte), destination, 7, 0);
                                    if ((utf8lsb >>= 8) === 0)
                                    {
                                        return 9;
                                    }
                                    if ((destination.Length >>> 0) <= 11)
                                    {
                                        $gotoJumpState1 = 1; /*goto OutOfSpace*/
                                        continue $gotoJumpStart1;
                                    }
                                    destination.get_Item(9).$v = /*%*/ 37;
                                    $.$stew.System.HexConverter.ToBytesBuffer($.$cast(utf8lsb, $.$$.System.Byte), destination, 10, 0);
                                    return 12;
                                }
                                case 1: /*OutOfSpace*/
                                return -1;
                            }
                            break;
                        }
                    }
                    /*int */ EncodeUtf16(/*Rune*/ value, /*Span<char>*/ destination)
                    {
                        /*uint*/ let utf8lsb;
                        let $gotoJumpState1 = 0;
                        $gotoJumpStart1: while(true)
                        {
                            switch($gotoJumpState1)
                            {
                                case 0:
                                {
                                    utf8lsb = ($.$stew.System.Text.Unicode.UnicodeHelpers.GetUtf8RepresentationForScalarValue((value.Value >>> 0)) >>> 0);
                                    if ((destination.Length >>> 0) <= 2)
                                    {
                                        $gotoJumpState1 = 1; /*goto OutOfSpace*/
                                        continue $gotoJumpStart1;
                                    }
                                    destination.get_Item(0).$v = /*%*/ 37;
                                    $.$stew.System.HexConverter.ToCharsBuffer($.$cast(utf8lsb, $.$$.System.Byte), destination, 1, 0);
                                    if ((utf8lsb >>= 8) === 0)
                                    {
                                        return 3;
                                    }
                                    if ((destination.Length >>> 0) <= 5)
                                    {
                                        $gotoJumpState1 = 1; /*goto OutOfSpace*/
                                        continue $gotoJumpStart1;
                                    }
                                    destination.get_Item(3).$v = /*%*/ 37;
                                    $.$stew.System.HexConverter.ToCharsBuffer($.$cast(utf8lsb, $.$$.System.Byte), destination, 4, 0);
                                    if ((utf8lsb >>= 8) === 0)
                                    {
                                        return 6;
                                    }
                                    if ((destination.Length >>> 0) <= 8)
                                    {
                                        $gotoJumpState1 = 1; /*goto OutOfSpace*/
                                        continue $gotoJumpStart1;
                                    }
                                    destination.get_Item(6).$v = /*%*/ 37;
                                    $.$stew.System.HexConverter.ToCharsBuffer($.$cast(utf8lsb, $.$$.System.Byte), destination, 7, 0);
                                    if ((utf8lsb >>= 8) === 0)
                                    {
                                        return 9;
                                    }
                                    if ((destination.Length >>> 0) <= 11)
                                    {
                                        $gotoJumpState1 = 1; /*goto OutOfSpace*/
                                        continue $gotoJumpStart1;
                                    }
                                    destination.get_Item(9).$v = /*%*/ 37;
                                    $.$stew.System.HexConverter.ToCharsBuffer($.$cast(utf8lsb, $.$$.System.Byte), destination, 10, 0);
                                    return 12;
                                }
                                case 1: /*OutOfSpace*/
                                return -1;
                            }
                            break;
                        }
                    }
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            this.Singleton = new $.$stew.System.Text.Encodings.Web.DefaultUrlEncoder.EscaperImplementation().$ctor$2();
                        }
                    }
                    static $h = 1042853;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1436069,"m":[{"r":655361,"p":[{"n":"value","p":122617857},{"n":"destination","p":$.$$.System.Span$$($.$$.System.Byte).$h}],"n":"EncodeUtf8","d":1042853,"h":12885944741,"f":16809992},{"r":655361,"p":[{"n":"value","p":122617857},{"n":"destination","p":$.$$.System.Span$$($.$$.System.Char).$h}],"n":"EncodeUtf16","d":1042853,"h":17180912037,"f":16809992}],"l":[{"t":1042853,"n":"Singleton","d":1042853,"h":4296010149,"f":4194344}],"c":[{"n":".ctor","o":"$ctor$2","d":1042853,"h":8590977445,"f":16777218}],"d":977317,"h":1042853}; }
                    static get $b() { return $.$stew.System.Text.Encodings.Web.ScalarEscaperBase; }
                    static get $fullName() { return `System.Text.Encodings.Web.DefaultUrlEncoder.EscaperImplementation`; }
                }, $cls, ($v) => $cls.$_EscaperImplementation = $v);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.BasicLatinSingleton = new $.$stew.System.Text.Encodings.Web.DefaultUrlEncoder().$ctor$3(new $.$stew.System.Text.Encodings.Web.TextEncoderSettings().$ctor$3($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$stew.System.Text.Unicode.UnicodeRange), [ $.$stew.System.Text.Unicode.UnicodeRanges.BasicLatin ], null, null)));
                }
            }
            static $h = 977317;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1698213,"p":[{"p":655361,"g":{"r":0,"d":0,"h":21475813797,"f":50364417},"n":"MaxOutputCharactersPerInputCharacter","d":977317,"h":17180846501,"f":2129921}],"m":[{"r":18743297,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h},{"n":"destination","p":$.$$.System.Span$$($.$$.System.Char).$h},{"n":"charsConsumed","p":655361,"f":2},{"n":"charsWritten","p":655361,"f":2},{"n":"isFinalBlock","p":262145}],"n":"EncodeCore","o":"@$1","d":977317,"h":25770781093,"f":16809984},{"r":18743297,"p":[{"n":"utf8Source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"utf8Destination","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"bytesConsumed","p":655361,"f":2},{"n":"bytesWritten","p":655361,"f":2},{"n":"isFinalBlock","p":262145}],"n":"EncodeUtf8Core","d":977317,"h":30065748389,"f":16809984},{"r":655361,"p":[{"n":"text","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h}],"n":"FindFirstCharacterToEncode","o":"@$1","d":977317,"h":34360715685,"f":16809984},{"r":655361,"p":[{"n":"text","p":$.$typePointer($.$$.System.Char).$h},{"n":"textLength","p":655361}],"n":"FindFirstCharacterToEncode","d":977317,"h":38655682981,"f":16809985},{"r":655361,"p":[{"n":"utf8Text","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h}],"n":"FindFirstCharacterToEncodeUtf8","d":977317,"h":42950650277,"f":16809985},{"r":262145,"p":[{"n":"unicodeScalar","p":655361},{"n":"buffer","p":$.$typePointer($.$$.System.Char).$h},{"n":"bufferLength","p":655361},{"n":"numberOfCharactersWritten","p":655361,"f":2}],"n":"TryEncodeUnicodeScalar","d":977317,"h":47245617573,"f":16809985},{"r":262145,"p":[{"n":"unicodeScalar","p":655361}],"n":"WillEncode","d":977317,"h":51540584869,"f":16809985}],"l":[{"t":977317,"n":"BasicLatinSingleton","d":977317,"h":4295944613,"f":4194344},{"t":1304997,"n":"_innerEncoder","d":977317,"h":8590911909,"f":4194306}],"c":[{"p":[{"n":"settings","p":1567141}],"n":".ctor","o":"$ctor$3","d":977317,"h":12885879205,"f":16777224}],"j":[1042853],"h":977317}; }
            static get $b() { return $.$stew.System.Text.Encodings.Web.UrlEncoder; }
            static get $fullName() { return `System.Text.Encodings.Web.DefaultUrlEncoder`; }
        });
        
        $asm.$cls("$stew.System.Text.Encodings.Web.DefaultJavaScriptEncoder", ($self) => class DefaultJavaScriptEncoder extends $.$stew.System.Text.Encodings.Web.JavaScriptEncoder
        {
            /*DefaultJavaScriptEncoder*/ static BasicLatinSingleton = null;
            /*DefaultJavaScriptEncoder*/ static UnsafeRelaxedEscapingSingleton = null;
            /*OptimizedInboxTextEncoder*/ _innerEncoder = null;
            $ctor$4(/*TextEncoderSettings*/ settings)
            {
                this.$ctor$3(settings, false);
                {
                }
                return this;
            }
            $ctor$3(/*TextEncoderSettings*/ settings, /*bool*/ allowMinimalJsonEscaping)
            {
                super.$ctor$2();
                {
                    if (settings === null)
                    {
                        $.$stew.System.Text.Encodings.Web.ThrowHelper.ThrowArgumentNullException(1/*ExceptionArgument.settings*/);
                    }
                    this._innerEncoder = allowMinimalJsonEscaping ? new $.$stew.System.Text.Encodings.Web.OptimizedInboxTextEncoder().$ctor$1($.$stew.System.Text.Encodings.Web.DefaultJavaScriptEncoder.EscaperImplementation.SingletonMinimallyEscaped, settings.GetAllowedCodePointsBitmap(), false, $.$$.System.ReadOnlySpan$$($.$$.System.Char).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Char), [/*\"*/ 34, /*\\*/ 92], null, null))) : new $.$stew.System.Text.Encodings.Web.OptimizedInboxTextEncoder().$ctor$1($.$stew.System.Text.Encodings.Web.DefaultJavaScriptEncoder.EscaperImplementation.Singleton, settings.GetAllowedCodePointsBitmap(), true, $.$$.System.ReadOnlySpan$$($.$$.System.Char).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Char), [/*\\*/ 92, /*`*/ 96], null, null)));
                }
                return this;
            }
            /*int */ get MaxOutputCharactersPerInputCharacter()
            {
                return 6;
            }
            /*OperationStatus */ EncodeCore$1(/*ReadOnlySpan<char>*/ source, /*Span<char>*/ destination, /*out int*/ charsConsumed, /*out int*/ charsWritten, /*bool*/ isFinalBlock)
            {
                return this._innerEncoder.Encode(source, destination, charsConsumed, charsWritten, isFinalBlock);
            }
            /*OperationStatus */ EncodeUtf8Core(/*ReadOnlySpan<byte>*/ utf8Source, /*Span<byte>*/ utf8Destination, /*out int*/ bytesConsumed, /*out int*/ bytesWritten, /*bool*/ isFinalBlock)
            {
                return this._innerEncoder.EncodeUtf8(utf8Source, utf8Destination, bytesConsumed, bytesWritten, isFinalBlock);
            }
            /*int */ FindFirstCharacterToEncode$1(/*ReadOnlySpan<char>*/ text)
            {
                return this._innerEncoder.GetIndexOfFirstCharToEncode(text);
            }
            /*int */ FindFirstCharacterToEncode(/*char**/ text, /*int*/ textLength)
            {
                return this._innerEncoder.FindFirstCharacterToEncode(text, textLength);
            }
            /*int */ FindFirstCharacterToEncodeUtf8(/*ReadOnlySpan<byte>*/ utf8Text)
            {
                return this._innerEncoder.GetIndexOfFirstByteToEncode(utf8Text);
            }
            /*bool */ TryEncodeUnicodeScalar(/*int*/ unicodeScalar, /*char**/ buffer, /*int*/ bufferLength, /*out int*/ numberOfCharactersWritten)
            {
                return this._innerEncoder.TryEncodeUnicodeScalar(unicodeScalar, buffer, bufferLength, numberOfCharactersWritten);
            }
            /*bool */ WillEncode(/*int*/ unicodeScalar)
            {
                return !this._innerEncoder.IsScalarValueAllowed(new $.$$.System.Text.Rune().$ctor$5(unicodeScalar));
            }
            static $_EscaperImplementation;
            static get EscaperImplementation()
            {
                let $cls = $.$stew.System.Text.Encodings.Web.DefaultJavaScriptEncoder;
                return $cls.$_EscaperImplementation ??= $asm.$ncls("$stew.System.Text.Encodings.Web.DefaultJavaScriptEncoder.EscaperImplementation", ($self) => class EscaperImplementation extends $.$stew.System.Text.Encodings.Web.ScalarEscaperBase
                {
                    /*EscaperImplementation*/ static Singleton = null;
                    /*EscaperImplementation*/ static SingletonMinimallyEscaped = null;
                    /*AsciiByteMap*/ _preescapedMap;
                    $ctor$2(/*bool*/ allowMinimalEscaping)
                    {
                        super.$ctor$1();
                        {
                            this._preescapedMap.InsertAsciiChar(/*\u0008*/ 8, /*b*/ 98);
                            this._preescapedMap.InsertAsciiChar(/*\t*/ 9, /*t*/ 116);
                            this._preescapedMap.InsertAsciiChar(/*\n*/ 10, /*n*/ 110);
                            this._preescapedMap.InsertAsciiChar(/*\u000C*/ 12, /*f*/ 102);
                            this._preescapedMap.InsertAsciiChar(/*\r*/ 13, /*r*/ 114);
                            this._preescapedMap.InsertAsciiChar(/*\\*/ 92, /*\\*/ 92);
                            if (allowMinimalEscaping)
                            {
                                this._preescapedMap.InsertAsciiChar(/*\"*/ 34, /*\"*/ 34);
                            }
                        }
                        return this;
                    }
                    /*int */ EncodeUtf8(/*Rune*/ value, /*Span<byte>*/ destination)
                    {
                        /*byte*/ let preescapedForm;
                        if (this._preescapedMap.TryLookup(value, $.$ref(() => preescapedForm, ($v) => preescapedForm = $v, $.$$.System.Byte)))
                        {
                            let $gotoJumpState2 = 0;
                            $gotoJumpStart2: while(true)
                            {
                                switch($gotoJumpState2)
                                {
                                    case 0:
                                    {
                                        if ((destination.Length >>> 0) <= 1)
                                        {
                                            $gotoJumpState2 = 1; /*goto OutOfSpace*/
                                            continue $gotoJumpStart2;
                                        }
                                        destination.get_Item(0).$v = /*\\*/ 92;
                                        destination.get_Item(1).$v = preescapedForm;
                                        return 2;
                                    }
                                    case 1: /*OutOfSpace*/
                                    return -1;
                                }
                                break;
                            }
                        }
                        return TryEncodeScalarAsHex(this, value, destination);
                        /*static int*/  function TryEncodeScalarAsHex(/*object*/ $this, /*Rune*/ value, /*Span<byte>*/ destination)
                        {
                            let $gotoJumpState2 = 0;
                            $gotoJumpStart2: while(true)
                            {
                                switch($gotoJumpState2)
                                {
                                    case 0:
                                    {
                                        if (value.IsBmp)
                                        {
                                            if ((destination.Length >>> 0) <= 5)
                                            {
                                                $gotoJumpState2 = 1; /*goto OutOfSpaceInner*/
                                                continue $gotoJumpStart2;
                                            }
                                            destination.get_Item(0).$v = /*\\*/ 92;
                                            destination.get_Item(1).$v = /*u*/ 117;
                                            $.$stew.System.HexConverter.ToBytesBuffer($.$cast(value.Value, $.$$.System.Byte), destination, 4, 0);
                                            $.$stew.System.HexConverter.ToBytesBuffer($.$cast(((value.Value >>> 0) >>> 8), $.$$.System.Byte), destination, 2, 0);
                                            return 6;
                                        }
                                        else 
                                        {
                                            /*char*/ let highSurrogate;
                                            /*char*/ let lowSurrogate;
                                            $.$stew.System.Text.Unicode.UnicodeHelpers.GetUtf16SurrogatePairFromAstralScalarValue((value.Value >>> 0), $.$ref(() => highSurrogate, ($v) => highSurrogate = $v, $.$$.System.Char), $.$ref(() => lowSurrogate, ($v) => lowSurrogate = $v, $.$$.System.Char));
                                            if ((destination.Length >>> 0) <= 11)
                                            {
                                                $gotoJumpState2 = 1; /*goto OutOfSpaceInner*/
                                                continue $gotoJumpStart2;
                                            }
                                            destination.get_Item(0).$v = /*\\*/ 92;
                                            destination.get_Item(1).$v = /*u*/ 117;
                                            $.$stew.System.HexConverter.ToBytesBuffer($.$cast(highSurrogate, $.$$.System.Byte), destination, 4, 0);
                                            $.$stew.System.HexConverter.ToBytesBuffer($.$cast((highSurrogate >>> 8), $.$$.System.Byte), destination, 2, 0);
                                            destination.get_Item(6).$v = /*\\*/ 92;
                                            destination.get_Item(7).$v = /*u*/ 117;
                                            $.$stew.System.HexConverter.ToBytesBuffer($.$cast(lowSurrogate, $.$$.System.Byte), destination, 10, 0);
                                            $.$stew.System.HexConverter.ToBytesBuffer($.$cast((lowSurrogate >>> 8), $.$$.System.Byte), destination, 8, 0);
                                            return 12;
                                        }
                                    }
                                    case 1: /*OutOfSpaceInner*/
                                    return -1;
                                }
                                break;
                            }
                        }
                    }
                    /*int */ EncodeUtf16(/*Rune*/ value, /*Span<char>*/ destination)
                    {
                        /*byte*/ let preescapedForm;
                        if (this._preescapedMap.TryLookup(value, $.$ref(() => preescapedForm, ($v) => preescapedForm = $v, $.$$.System.Byte)))
                        {
                            let $gotoJumpState2 = 0;
                            $gotoJumpStart2: while(true)
                            {
                                switch($gotoJumpState2)
                                {
                                    case 0:
                                    {
                                        if ((destination.Length >>> 0) <= 1)
                                        {
                                            $gotoJumpState2 = 1; /*goto OutOfSpace*/
                                            continue $gotoJumpStart2;
                                        }
                                        destination.get_Item(0).$v = /*\\*/ 92;
                                        destination.get_Item(1).$v = preescapedForm;
                                        return 2;
                                    }
                                    case 1: /*OutOfSpace*/
                                    return -1;
                                }
                                break;
                            }
                        }
                        return TryEncodeScalarAsHex(this, value, destination);
                        /*static int*/  function TryEncodeScalarAsHex(/*object*/ $this, /*Rune*/ value, /*Span<char>*/ destination)
                        {
                            let $gotoJumpState2 = 0;
                            $gotoJumpStart2: while(true)
                            {
                                switch($gotoJumpState2)
                                {
                                    case 0:
                                    {
                                        if (value.IsBmp)
                                        {
                                            if ((destination.Length >>> 0) <= 5)
                                            {
                                                $gotoJumpState2 = 1; /*goto OutOfSpaceInner*/
                                                continue $gotoJumpStart2;
                                            }
                                            destination.get_Item(0).$v = /*\\*/ 92;
                                            destination.get_Item(1).$v = /*u*/ 117;
                                            $.$stew.System.HexConverter.ToCharsBuffer($.$cast(value.Value, $.$$.System.Byte), destination, 4, 0);
                                            $.$stew.System.HexConverter.ToCharsBuffer($.$cast(((value.Value >>> 0) >>> 8), $.$$.System.Byte), destination, 2, 0);
                                            return 6;
                                        }
                                        else 
                                        {
                                            /*char*/ let highSurrogate;
                                            /*char*/ let lowSurrogate;
                                            $.$stew.System.Text.Unicode.UnicodeHelpers.GetUtf16SurrogatePairFromAstralScalarValue((value.Value >>> 0), $.$ref(() => highSurrogate, ($v) => highSurrogate = $v, $.$$.System.Char), $.$ref(() => lowSurrogate, ($v) => lowSurrogate = $v, $.$$.System.Char));
                                            if ((destination.Length >>> 0) <= 11)
                                            {
                                                $gotoJumpState2 = 1; /*goto OutOfSpaceInner*/
                                                continue $gotoJumpStart2;
                                            }
                                            destination.get_Item(0).$v = /*\\*/ 92;
                                            destination.get_Item(1).$v = /*u*/ 117;
                                            $.$stew.System.HexConverter.ToCharsBuffer($.$cast(highSurrogate, $.$$.System.Byte), destination, 4, 0);
                                            $.$stew.System.HexConverter.ToCharsBuffer($.$cast((highSurrogate >>> 8), $.$$.System.Byte), destination, 2, 0);
                                            destination.get_Item(6).$v = /*\\*/ 92;
                                            destination.get_Item(7).$v = /*u*/ 117;
                                            $.$stew.System.HexConverter.ToCharsBuffer($.$cast(lowSurrogate, $.$$.System.Byte), destination, 10, 0);
                                            $.$stew.System.HexConverter.ToCharsBuffer($.$cast((lowSurrogate >>> 8), $.$$.System.Byte), destination, 8, 0);
                                            return 12;
                                        }
                                    }
                                    case 1: /*OutOfSpaceInner*/
                                    return -1;
                                }
                                break;
                            }
                        }
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._preescapedMap = $.$default($.$stew.System.Text.Encodings.Web.AsciiByteMap);
                    }
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            this.Singleton = new $.$stew.System.Text.Encodings.Web.DefaultJavaScriptEncoder.EscaperImplementation().$ctor$2(false);
                        }
                        {
                            this.SingletonMinimallyEscaped = new $.$stew.System.Text.Encodings.Web.DefaultJavaScriptEncoder.EscaperImplementation().$ctor$2(true);
                        }
                    }
                    static $h = 911781;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1436069,"m":[{"r":655361,"p":[{"n":"value","p":122617857},{"n":"destination","p":$.$$.System.Span$$($.$$.System.Byte).$h}],"n":"EncodeUtf8","d":911781,"h":21475748261,"f":16809992},{"r":655361,"p":[{"n":"value","p":122617857},{"n":"destination","p":$.$$.System.Span$$($.$$.System.Char).$h}],"n":"EncodeUtf16","d":911781,"h":25770715557,"f":16809992}],"l":[{"t":911781,"n":"Singleton","d":911781,"h":4295879077,"f":4194344},{"t":911781,"n":"SingletonMinimallyEscaped","d":911781,"h":8590846373,"f":4194344},{"t":649637,"n":"_preescapedMap","d":911781,"h":12885813669,"f":4194306}],"c":[{"p":[{"n":"allowMinimalEscaping","p":262145}],"n":".ctor","o":"$ctor$2","d":911781,"h":17180780965,"f":16777218}],"d":846245,"h":911781}; }
                    static get $b() { return $.$stew.System.Text.Encodings.Web.ScalarEscaperBase; }
                    static get $fullName() { return `System.Text.Encodings.Web.DefaultJavaScriptEncoder.EscaperImplementation`; }
                }, $cls, ($v) => $cls.$_EscaperImplementation = $v);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.BasicLatinSingleton = new $.$stew.System.Text.Encodings.Web.DefaultJavaScriptEncoder().$ctor$4(new $.$stew.System.Text.Encodings.Web.TextEncoderSettings().$ctor$3($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$stew.System.Text.Unicode.UnicodeRange), [ $.$stew.System.Text.Unicode.UnicodeRanges.BasicLatin ], null, null)));
                }
                {
                    this.UnsafeRelaxedEscapingSingleton = new $.$stew.System.Text.Encodings.Web.DefaultJavaScriptEncoder().$ctor$3(new $.$stew.System.Text.Encodings.Web.TextEncoderSettings().$ctor$3($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$stew.System.Text.Unicode.UnicodeRange), [ $.$stew.System.Text.Unicode.UnicodeRanges.All ], null, null)), true);
                }
            }
            static $h = 846245;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1239461,"p":[{"p":655361,"g":{"r":0,"d":0,"h":30065617317,"f":50364417},"n":"MaxOutputCharactersPerInputCharacter","d":846245,"h":25770650021,"f":2129921}],"m":[{"r":18743297,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h},{"n":"destination","p":$.$$.System.Span$$($.$$.System.Char).$h},{"n":"charsConsumed","p":655361,"f":2},{"n":"charsWritten","p":655361,"f":2},{"n":"isFinalBlock","p":262145}],"n":"EncodeCore","o":"@$1","d":846245,"h":34360584613,"f":16809984},{"r":18743297,"p":[{"n":"utf8Source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"utf8Destination","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"bytesConsumed","p":655361,"f":2},{"n":"bytesWritten","p":655361,"f":2},{"n":"isFinalBlock","p":262145}],"n":"EncodeUtf8Core","d":846245,"h":38655551909,"f":16809984},{"r":655361,"p":[{"n":"text","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h}],"n":"FindFirstCharacterToEncode","o":"@$1","d":846245,"h":42950519205,"f":16809984},{"r":655361,"p":[{"n":"text","p":$.$typePointer($.$$.System.Char).$h},{"n":"textLength","p":655361}],"n":"FindFirstCharacterToEncode","d":846245,"h":47245486501,"f":16809985},{"r":655361,"p":[{"n":"utf8Text","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h}],"n":"FindFirstCharacterToEncodeUtf8","d":846245,"h":51540453797,"f":16809985},{"r":262145,"p":[{"n":"unicodeScalar","p":655361},{"n":"buffer","p":$.$typePointer($.$$.System.Char).$h},{"n":"bufferLength","p":655361},{"n":"numberOfCharactersWritten","p":655361,"f":2}],"n":"TryEncodeUnicodeScalar","d":846245,"h":55835421093,"f":16809985},{"r":262145,"p":[{"n":"unicodeScalar","p":655361}],"n":"WillEncode","d":846245,"h":60130388389,"f":16809985}],"l":[{"t":846245,"n":"BasicLatinSingleton","d":846245,"h":4295813541,"f":4194344},{"t":846245,"n":"UnsafeRelaxedEscapingSingleton","d":846245,"h":8590780837,"f":4194344},{"t":1304997,"n":"_innerEncoder","d":846245,"h":12885748133,"f":4194306}],"c":[{"p":[{"n":"settings","p":1567141}],"n":".ctor","o":"$ctor$4","d":846245,"h":17180715429,"f":16777224},{"p":[{"n":"settings","p":1567141},{"n":"allowMinimalJsonEscaping","p":262145}],"n":".ctor","o":"$ctor$3","d":846245,"h":21475682725,"f":16777218}],"j":[911781],"h":846245}; }
            static get $b() { return $.$stew.System.Text.Encodings.Web.JavaScriptEncoder; }
            static get $fullName() { return `System.Text.Encodings.Web.DefaultJavaScriptEncoder`; }
        });
        
        $asm.$str("$stew.System.Text.Encodings.Web.ExceptionArgument", ($self) => class ExceptionArgument extends $.$$.System.Enum
        {
            static value = 0;
            static settings = 1;
            static output = 2;
            static other = 3;
            static allowedRanges = 4;
            static characters = 5;
            static codePoints = 6;
            static range = 7;
            static ranges = 8;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "value": 0n,
                    "settings": 1n,
                    "output": 2n,
                    "other": 3n,
                    "allowedRanges": 4n,
                    "characters": 5n,
                    "codePoints": 6n,
                    "range": 7n,
                    "ranges": 8n
                };
            }
            static $h = 1108389;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1108389,"n":"value","d":1108389,"h":4296075685,"f":4194337},{"t":1108389,"n":"settings","d":1108389,"h":8591042981,"f":4194337},{"t":1108389,"n":"output","d":1108389,"h":12886010277,"f":4194337},{"t":1108389,"n":"other","d":1108389,"h":17180977573,"f":4194337},{"t":1108389,"n":"allowedRanges","d":1108389,"h":21475944869,"f":4194337},{"t":1108389,"n":"characters","d":1108389,"h":25770912165,"f":4194337},{"t":1108389,"n":"codePoints","d":1108389,"h":30065879461,"f":4194337},{"t":1108389,"n":"range","d":1108389,"h":34360846757,"f":4194337},{"t":1108389,"n":"ranges","d":1108389,"h":38655814053,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":1108389,"h":42950781349,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":1108389}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Text.Encodings.Web.ExceptionArgument`; }
        });
        
        $asm.$str("$stew.System.ExceptionArgument", ($self) => class ExceptionArgument extends $.$$.System.Enum
        {
            static ch = 0;
            static culture = 1;
            static index = 2;
            static input = 3;
            static value = 4;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "ch": 0n,
                    "culture": 1n,
                    "index": 2n,
                    "input": 3n,
                    "value": 4n
                };
            }
            static $h = 125349;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":125349,"n":"ch","d":125349,"h":4295092645,"f":4194337},{"t":125349,"n":"culture","d":125349,"h":8590059941,"f":4194337},{"t":125349,"n":"index","d":125349,"h":12885027237,"f":4194337},{"t":125349,"n":"input","d":125349,"h":17179994533,"f":4194337},{"t":125349,"n":"value","d":125349,"h":21474961829,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":125349,"h":25769929125,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":125349}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.ExceptionArgument`; }
        });
        
        $asm.$str("$stew.System.ExceptionResource", ($self) => class ExceptionResource extends $.$$.System.Enum
        {
            static Argument_CannotExtractScalar = 0;
            static ArgumentOutOfRange_IndexMustBeLess = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Argument_CannotExtractScalar": 0n,
                    "ArgumentOutOfRange_IndexMustBeLess": 1n
                };
            }
            static $h = 190885;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":190885,"n":"Argument_CannotExtractScalar","d":190885,"h":4295158181,"f":4194337},{"t":190885,"n":"ArgumentOutOfRange_IndexMustBeLess","d":190885,"h":8590125477,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":190885,"h":12885092773,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":190885}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.ExceptionResource`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Threading"))