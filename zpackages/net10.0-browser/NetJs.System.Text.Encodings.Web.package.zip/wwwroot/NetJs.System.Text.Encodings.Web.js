
(function ($global, $, $spc, $sm, $snv, $spu, $sr, $sri, $st) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Text.Encodings.Web", 
    {"h":36556,"f":"System.Text.Encodings.Web","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B99807a3edea449997cda60d38046fed69821a2f6","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Text.Encodings.Web","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Text.Encodings.Web","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$stew.System.Text.Encodings.Web.ScalarEscaperBase", ($self) => class ScalarEscaperBase extends $.$spc.System.Object
        {
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 1412812;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":655361,"p":[{"n":"value","p":122748929},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Char).$h}],"n":"EncodeUtf16","d":1412812,"h":4296380108,"f":264},{"r":655361,"p":[{"n":"value","p":122748929},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"EncodeUtf8","d":1412812,"h":8591347404,"f":264}],"c":[{"n":".ctor","o":"$ctor$1","d":1412812,"h":12886314700,"f":4}],"h":1412812}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Text.Encodings.Web.ScalarEscaperBase`; }
        });
        
        $asm.$cls("$stew.System.Text.Encodings.Web.TextEncoder", ($self) => class TextEncoder extends $.$spc.System.Object
        {
            /*int*/ static EncodeStartingOutputBufferSize = 1024;
            /*bool */ TryEncodeUnicodeScalar$1(/*uint*/ unicodeScalar, /*Span<char>*/ buffer, /*out int*/ charsWritten)
            {
                /*fixed*/ 
                {
                    /*char**/ let pBuffer = $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference($.$spc.System.Char, buffer);
                    return this.TryEncodeUnicodeScalar((unicodeScalar | 0), pBuffer, buffer.Length, charsWritten);
                }
            }
            /*bool */ TryEncodeUnicodeScalarUtf8(/*uint*/ unicodeScalar, /*Span<char>*/ utf16ScratchBuffer, /*Span<byte>*/ utf8Destination, /*out int*/ bytesWritten)
            {
                /*int*/ let charsWritten;
                if (!this.TryEncodeUnicodeScalar$1(unicodeScalar, utf16ScratchBuffer, $.$ref(() => charsWritten, ($v) => charsWritten = $v, $.$spc.System.Int32)))
                {
                    $.$stew.System.Text.Encodings.Web.TextEncoder.ThrowArgumentException_MaxOutputCharsPerInputChar();
                }
                utf16ScratchBuffer = utf16ScratchBuffer.Slice$1(0, charsWritten);
                /*int*/ let dstIdx = 0;
                while(!utf16ScratchBuffer.IsEmpty)
                {
                    /*Rune*/ let nextScalarValue;
                    /*int*/ let scalarUtf16CodeUnitCount;
                    if ($.$spc.System.Text.Rune.DecodeFromUtf16($.$spc.System.Span$$($.$spc.System.Char).op_Implicit$2(utf16ScratchBuffer), $.$ref(() => nextScalarValue, ($v) => nextScalarValue = $v, $.$spc.System.Text.Rune), $.$ref(() => scalarUtf16CodeUnitCount, ($v) => scalarUtf16CodeUnitCount = $v, $.$spc.System.Int32)) !== 0/*OperationStatus.Done*/)
                    {
                        $.$stew.System.Text.Encodings.Web.TextEncoder.ThrowArgumentException_MaxOutputCharsPerInputChar();
                    }
                    /*uint*/ let utf8lsb = ($.$stew.System.Text.Unicode.UnicodeHelpers.GetUtf8RepresentationForScalarValue((nextScalarValue.Value >>> 0)) >>> 0);
                    do
                    {
                        if ((utf8Destination.Length >>> 0) > (dstIdx >>> 0))
                        {
                            utf8Destination.get_Item(dstIdx++).$v = $.$cast(utf8lsb, $.$spc.System.Byte);
                        }
                        else 
                        {
                            bytesWritten.$v = 0;
                            return false;
                        }
                    }
                    while((utf8lsb >>= 8) !== 0);
                    utf16ScratchBuffer = utf16ScratchBuffer.Slice(scalarUtf16CodeUnitCount);
                }
                bytesWritten.$v = dstIdx;
                return true;
            }
            /*string */ Encode(/*string*/ value)
            {
                if (value === null)
                {
                    $.$stew.System.Text.Encodings.Web.ThrowHelper.ThrowArgumentNullException(0/*ExceptionArgument.value*/);
                }
                /*int*/ let indexOfFirstCharToEncode = this.FindFirstCharacterToEncode$1($.$spc.System.MemoryExtensions.AsSpan$3(value));
                if (indexOfFirstCharToEncode < 0)
                {
                    return value;
                }
                return this.EncodeToNewString($.$spc.System.MemoryExtensions.AsSpan$3(value), indexOfFirstCharToEncode);
            }
            /*string */ EncodeToNewString(/*ReadOnlySpan<char>*/ value, /*int*/ indexOfFirstCharToEncode)
            {
                /*ReadOnlySpan<char>*/ let remainingInput = value.Slice(indexOfFirstCharToEncode);
                /*ValueStringBuilder*/ let stringBuilder = new $.$stew.System.Text.ValueStringBuilder().$ctor$2($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Char, 1024/*EncodeStartingOutputBufferSize*/, null));
                /*int*/ let minBufferBumpEachIteration = $.$spc.System.Math.Max$4(this.MaxOutputCharactersPerInputCharacter, 1024/*EncodeStartingOutputBufferSize*/);
                do
                {
                    /*Span<char>*/ let destBuffer = stringBuilder.AppendSpan($.$spc.System.Math.Max$4(remainingInput.Length, minBufferBumpEachIteration));
                    /*int*/ let charsConsumedJustNow;
                    /*int*/ let charsWrittenJustNow;
                    this.EncodeCore(remainingInput, destBuffer, $.$ref(() => charsConsumedJustNow, ($v) => charsConsumedJustNow = $v, $.$spc.System.Int32), $.$ref(() => charsWrittenJustNow, ($v) => charsWrittenJustNow = $v, $.$spc.System.Int32), true);
                    if (charsWrittenJustNow === 0 || (charsWrittenJustNow >>> 0) > (destBuffer.Length >>> 0))
                    {
                        $.$stew.System.Text.Encodings.Web.TextEncoder.ThrowArgumentException_MaxOutputCharsPerInputChar();
                    }
                    remainingInput = remainingInput.Slice(charsConsumedJustNow);
                    stringBuilder.Length -= ((destBuffer.Length - charsWrittenJustNow) | 0);
                }
                while(!remainingInput.IsEmpty);
                /*string*/ let retVal = $.$spc.System.String.Concat$10(value.Slice$1(0, indexOfFirstCharToEncode), stringBuilder.AsSpan$1());
                stringBuilder.Dispose();
                return retVal;
            }
            /*void */ Encode$1(/*TextWriter*/ output, /*string*/ value)
            {
                this.Encode$2(output, value, 0, value.length);
            }
            /*void */ Encode$2(/*TextWriter*/ output, /*string*/ value, /*int*/ startIndex, /*int*/ characterCount)
            {
                if (output === null)
                {
                    $.$stew.System.Text.Encodings.Web.ThrowHelper.ThrowArgumentNullException(2/*ExceptionArgument.output*/);
                }
                if (value === null)
                {
                    $.$stew.System.Text.Encodings.Web.ThrowHelper.ThrowArgumentNullException(0/*ExceptionArgument.value*/);
                }
                $.$stew.System.Text.Encodings.Web.TextEncoder.ValidateRanges(startIndex, characterCount, value.length);
                /*int*/ let indexOfFirstCharToEncode = this.FindFirstCharacterToEncode$1($.$spc.System.MemoryExtensions.AsSpan$7(value, startIndex, characterCount));
                if (indexOfFirstCharToEncode < 0)
                {
                    indexOfFirstCharToEncode = characterCount;
                }
                $.$stew.System.IO.TextWriterExtensions.WritePartialString(output, value, startIndex, indexOfFirstCharToEncode);
                if (indexOfFirstCharToEncode !== characterCount)
                {
                    this.EncodeCore$1(output, $.$spc.System.MemoryExtensions.AsSpan$7(value, ((startIndex + indexOfFirstCharToEncode) | 0), ((characterCount - indexOfFirstCharToEncode) | 0)));
                }
            }
            /*void */ Encode$3(/*TextWriter*/ output, /*char[]*/ value, /*int*/ startIndex, /*int*/ characterCount)
            {
                if (output === null)
                {
                    $.$stew.System.Text.Encodings.Web.ThrowHelper.ThrowArgumentNullException(2/*ExceptionArgument.output*/);
                }
                if (value === null)
                {
                    $.$stew.System.Text.Encodings.Web.ThrowHelper.ThrowArgumentNullException(0/*ExceptionArgument.value*/);
                }
                $.$stew.System.Text.Encodings.Web.TextEncoder.ValidateRanges(startIndex, characterCount, value.length);
                /*int*/ let indexOfFirstCharToEncode = this.FindFirstCharacterToEncode$1($.$spc.System.Span$$($.$spc.System.Char).op_Implicit$2($.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.Char, value, startIndex, characterCount)));
                if (indexOfFirstCharToEncode < 0)
                {
                    indexOfFirstCharToEncode = characterCount;
                }
                output.Write$2(value, startIndex, indexOfFirstCharToEncode);
                if (indexOfFirstCharToEncode !== characterCount)
                {
                    this.EncodeCore$1(output, $.$spc.System.Span$$($.$spc.System.Char).op_Implicit$2($.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.Char, value, ((startIndex + indexOfFirstCharToEncode) | 0), ((characterCount - indexOfFirstCharToEncode) | 0))));
                }
            }
            /*OperationStatus */ EncodeUtf8(/*ReadOnlySpan<byte>*/ utf8Source, /*Span<byte>*/ utf8Destination, /*out int*/ bytesConsumed, /*out int*/ bytesWritten, /*bool*/ isFinalBlock)
            {
                /*ReadOnlySpan<byte>*/ let sourceSearchSpace = utf8Source;
                if (utf8Destination.Length < utf8Source.Length)
                {
                    sourceSearchSpace = utf8Source.Slice$1(0, utf8Destination.Length);
                }
                /*int*/ let idxOfFirstByteToEncode = this.FindFirstCharacterToEncodeUtf8(sourceSearchSpace);
                if (idxOfFirstByteToEncode < 0)
                {
                    idxOfFirstByteToEncode = sourceSearchSpace.Length;
                }
                utf8Source.Slice$1(0, idxOfFirstByteToEncode).CopyTo(utf8Destination);
                if (idxOfFirstByteToEncode === utf8Source.Length)
                {
                    bytesConsumed.$v = utf8Source.Length;
                    bytesWritten.$v = utf8Source.Length;
                    return 0/*OperationStatus.Done*/;
                }
                /*int*/ let innerBytesConsumed;
                /*int*/ let innerBytesWritten;
                /*OperationStatus*/ let status = this.EncodeUtf8Core(utf8Source.Slice(idxOfFirstByteToEncode), utf8Destination.Slice(idxOfFirstByteToEncode), $.$ref(() => innerBytesConsumed, ($v) => innerBytesConsumed = $v, $.$spc.System.Int32), $.$ref(() => innerBytesWritten, ($v) => innerBytesWritten = $v, $.$spc.System.Int32), isFinalBlock);
                bytesConsumed.$v = ((idxOfFirstByteToEncode + innerBytesConsumed) | 0);
                bytesWritten.$v = ((idxOfFirstByteToEncode + innerBytesWritten) | 0);
                return status;
            }
            /*OperationStatus */ EncodeUtf8Core(/*ReadOnlySpan<byte>*/ utf8Source, /*Span<byte>*/ utf8Destination, /*out int*/ bytesConsumed, /*out int*/ bytesWritten, /*bool*/ isFinalBlock)
            {
                /*int*/ let originalUtf8SourceLength;
                /*int*/ let originalUtf8DestinationLength;
                /*int*/ let TempUtf16CharBufferLength;
                /*Span<char>*/ let utf16ScratchBuffer;
                /*OperationStatus*/ let retVal;
                let $gotoJumpState1 = 0;
                $gotoJumpStart1: while(true)
                {
                    switch($gotoJumpState1)
                    {
                        case 0:
                        {
                            originalUtf8SourceLength = utf8Source.Length;
                            originalUtf8DestinationLength = utf8Destination.Length;
                            TempUtf16CharBufferLength = 24;
                            utf16ScratchBuffer = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Char, TempUtf16CharBufferLength, null);
                            $whileJumpStart2: while(!utf8Source.IsEmpty)
                            {
                                /*OperationStatus*/ let opStatus;
                                let $gotoJumpState3 = 0;
                                $gotoJumpStart3: while(true)
                                {
                                    switch($gotoJumpState3)
                                    {
                                        case 0:
                                        {
                                            /*Rune*/ let scalarValue;
                                            /*int*/ let bytesConsumedJustNow;
                                            opStatus = $.$spc.System.Text.Rune.DecodeFromUtf8(utf8Source, $.$ref(() => scalarValue, ($v) => scalarValue = $v, $.$spc.System.Text.Rune), $.$ref(() => bytesConsumedJustNow, ($v) => bytesConsumedJustNow = $v, $.$spc.System.Int32));
                                            if (opStatus !== 0/*OperationStatus.Done*/)
                                            {
                                                if (!isFinalBlock && opStatus === 2/*OperationStatus.NeedMoreData*/)
                                                {
                                                    $gotoJumpState1 = 2; /*goto NeedMoreData*/
                                                    continue $gotoJumpStart1;
                                                }
                                                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Text.Rune.op_Equality(scalarValue, $.$spc.System.Text.Rune.ReplacementChar), "scalarValue == Rune.ReplacementChar");
                                                $gotoJumpState3 = 1; /*goto MustEncode*/
                                                continue $gotoJumpStart3;
                                            }
                                            if (!this.WillEncode(scalarValue.Value))
                                            {
                                                /*uint*/ let utf8lsb = ($.$stew.System.Text.Unicode.UnicodeHelpers.GetUtf8RepresentationForScalarValue((scalarValue.Value >>> 0)) >>> 0);
                                                /*int*/ let dstIdxTemp = 0;
                                                do
                                                {
                                                    if ((dstIdxTemp >>> 0) >= (utf8Destination.Length >>> 0))
                                                    {
                                                        $gotoJumpState1 = 3; /*goto DestinationTooSmall*/
                                                        continue $gotoJumpStart1;
                                                    }
                                                    utf8Destination.get_Item(dstIdxTemp++).$v = $.$cast(utf8lsb, $.$spc.System.Byte);
                                                }
                                                while((utf8lsb >>= 8) !== 0);
                                                utf8Source = utf8Source.Slice(bytesConsumedJustNow);
                                                utf8Destination = utf8Destination.Slice(dstIdxTemp);
                                                continue $whileJumpStart2;
                                            }
                                        }
                                        case 1: /*MustEncode*/
                                        /*int*/ let bytesWrittenJustNow;
                                        if (!this.TryEncodeUnicodeScalarUtf8((scalarValue.Value >>> 0), utf16ScratchBuffer, utf8Destination, $.$ref(() => bytesWrittenJustNow, ($v) => bytesWrittenJustNow = $v, $.$spc.System.Int32)))
                                        {
                                            $gotoJumpState1 = 3; /*goto DestinationTooSmall*/
                                            continue $gotoJumpStart1;
                                        }
                                        utf8Source = utf8Source.Slice(bytesConsumedJustNow);
                                        utf8Destination = utf8Destination.Slice(bytesWrittenJustNow);
                                    }
                                    break;
                                }
                            }
                            retVal = 0/*OperationStatus.Done*/;
                        }
                        case 1: /*ReturnCommon*/
                        bytesConsumed.$v = ((originalUtf8SourceLength - utf8Source.Length) | 0);
                        bytesWritten.$v = ((originalUtf8DestinationLength - utf8Destination.Length) | 0);
                        return retVal;
                        case 2: /*NeedMoreData*/
                        retVal = 2/*OperationStatus.NeedMoreData*/;
                        $gotoJumpState1 = 1; /*goto ReturnCommon*/
                        continue $gotoJumpStart1;
                        case 3: /*DestinationTooSmall*/
                        retVal = 1/*OperationStatus.DestinationTooSmall*/;
                        $gotoJumpState1 = 1; /*goto ReturnCommon*/
                        continue $gotoJumpStart1;
                    }
                    break;
                }
            }
            /*OperationStatus */ Encode$4(/*ReadOnlySpan<char>*/ source, /*Span<char>*/ destination, /*out int*/ charsConsumed, /*out int*/ charsWritten, /*bool*/ isFinalBlock)
            {
                /*ReadOnlySpan<char>*/ let sourceSearchSpace = source;
                if (destination.Length < source.Length)
                {
                    sourceSearchSpace = source.Slice$1(0, destination.Length);
                }
                /*int*/ let idxOfFirstCharToEncode = this.FindFirstCharacterToEncode$1(sourceSearchSpace);
                if (idxOfFirstCharToEncode < 0)
                {
                    idxOfFirstCharToEncode = sourceSearchSpace.Length;
                }
                source.Slice$1(0, idxOfFirstCharToEncode).CopyTo(destination);
                if (idxOfFirstCharToEncode === source.Length)
                {
                    charsConsumed.$v = source.Length;
                    charsWritten.$v = source.Length;
                    return 0/*OperationStatus.Done*/;
                }
                /*int*/ let innerCharsConsumed;
                /*int*/ let innerCharsWritten;
                /*OperationStatus*/ let status = this.EncodeCore(source.Slice(idxOfFirstCharToEncode), destination.Slice(idxOfFirstCharToEncode), $.$ref(() => innerCharsConsumed, ($v) => innerCharsConsumed = $v, $.$spc.System.Int32), $.$ref(() => innerCharsWritten, ($v) => innerCharsWritten = $v, $.$spc.System.Int32), isFinalBlock);
                charsConsumed.$v = ((idxOfFirstCharToEncode + innerCharsConsumed) | 0);
                charsWritten.$v = ((idxOfFirstCharToEncode + innerCharsWritten) | 0);
                return status;
            }
            /*OperationStatus */ EncodeCore(/*ReadOnlySpan<char>*/ source, /*Span<char>*/ destination, /*out int*/ charsConsumed, /*out int*/ charsWritten, /*bool*/ isFinalBlock)
            {
                /*int*/ let originalSourceLength;
                /*int*/ let originalDestinationLength;
                /*OperationStatus*/ let retVal;
                let $gotoJumpState1 = 0;
                $gotoJumpStart1: while(true)
                {
                    switch($gotoJumpState1)
                    {
                        case 0:
                        {
                            originalSourceLength = source.Length;
                            originalDestinationLength = destination.Length;
                            $whileJumpStart2: while(!source.IsEmpty)
                            {
                                /*OperationStatus*/ let status;
                                let $gotoJumpState3 = 0;
                                $gotoJumpStart3: while(true)
                                {
                                    switch($gotoJumpState3)
                                    {
                                        case 0:
                                        {
                                            /*Rune*/ let scalarValue;
                                            /*int*/ let charsConsumedJustNow;
                                            status = $.$spc.System.Text.Rune.DecodeFromUtf16(source, $.$ref(() => scalarValue, ($v) => scalarValue = $v, $.$spc.System.Text.Rune), $.$ref(() => charsConsumedJustNow, ($v) => charsConsumedJustNow = $v, $.$spc.System.Int32));
                                            if (status !== 0/*OperationStatus.Done*/)
                                            {
                                                if (!isFinalBlock && status === 2/*OperationStatus.NeedMoreData*/)
                                                {
                                                    $gotoJumpState1 = 2; /*goto NeedMoreData*/
                                                    continue $gotoJumpStart1;
                                                }
                                                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Text.Rune.op_Equality(scalarValue, $.$spc.System.Text.Rune.ReplacementChar), "scalarValue == Rune.ReplacementChar");
                                                $gotoJumpState3 = 1; /*goto MustEncode*/
                                                continue $gotoJumpStart3;
                                            }
                                            if (!this.WillEncode(scalarValue.Value))
                                            {
                                                if (!scalarValue.TryEncodeToUtf16(destination, $.$discardRef()))
                                                {
                                                    $gotoJumpState1 = 3; /*goto DestinationTooSmall*/
                                                    continue $gotoJumpStart1;
                                                }
                                                source = source.Slice(charsConsumedJustNow);
                                                destination = destination.Slice(charsConsumedJustNow);
                                                continue $whileJumpStart2;
                                            }
                                        }
                                        case 1: /*MustEncode*/
                                        /*int*/ let charsWrittenJustNow;
                                        if (!this.TryEncodeUnicodeScalar$1((scalarValue.Value >>> 0), destination, $.$ref(() => charsWrittenJustNow, ($v) => charsWrittenJustNow = $v, $.$spc.System.Int32)))
                                        {
                                            $gotoJumpState1 = 3; /*goto DestinationTooSmall*/
                                            continue $gotoJumpStart1;
                                        }
                                        source = source.Slice(charsConsumedJustNow);
                                        destination = destination.Slice(charsWrittenJustNow);
                                    }
                                    break;
                                }
                            }
                            retVal = 0/*OperationStatus.Done*/;
                        }
                        case 1: /*ReturnCommon*/
                        charsConsumed.$v = ((originalSourceLength - source.Length) | 0);
                        charsWritten.$v = ((originalDestinationLength - destination.Length) | 0);
                        return retVal;
                        case 2: /*NeedMoreData*/
                        retVal = 2/*OperationStatus.NeedMoreData*/;
                        $gotoJumpState1 = 1; /*goto ReturnCommon*/
                        continue $gotoJumpStart1;
                        case 3: /*DestinationTooSmall*/
                        retVal = 1/*OperationStatus.DestinationTooSmall*/;
                        $gotoJumpState1 = 1; /*goto ReturnCommon*/
                        continue $gotoJumpStart1;
                    }
                    break;
                }
            }
            /*void */ EncodeCore$1(/*TextWriter*/ output, /*ReadOnlySpan<char>*/ value)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(output !== null, "output != null");
                $.$spc.System.Diagnostics.Debug.Assert$1(!value.IsEmpty, "Caller should've special-cased 'no encoding needed'.");
                /*int*/ let minBufferBumpEachIteration = $.$spc.System.Math.Max$4(this.MaxOutputCharactersPerInputCharacter, 1024/*EncodeStartingOutputBufferSize*/);
                /*char[]*/ let rentedArray = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Char).Shared.Rent($.$spc.System.Math.Max$4(value.Length, minBufferBumpEachIteration));
                /*Span<char>*/ let scratchBuffer = $.$spc.System.Span$$($.$spc.System.Char).op_Implicit(rentedArray);
                do
                {
                    /*int*/ let charsConsumedJustNow;
                    /*int*/ let charsWrittenJustNow;
                    this.EncodeCore(value, scratchBuffer, $.$ref(() => charsConsumedJustNow, ($v) => charsConsumedJustNow = $v, $.$spc.System.Int32), $.$ref(() => charsWrittenJustNow, ($v) => charsWrittenJustNow = $v, $.$spc.System.Int32), true);
                    if (charsWrittenJustNow === 0 || (charsWrittenJustNow >>> 0) > (scratchBuffer.Length >>> 0))
                    {
                        $.$stew.System.Text.Encodings.Web.TextEncoder.ThrowArgumentException_MaxOutputCharsPerInputChar();
                    }
                    output.Write$2(rentedArray, 0, charsWrittenJustNow);
                    value = value.Slice(charsConsumedJustNow);
                }
                while(!value.IsEmpty);
                $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Char).Shared.Return(rentedArray, false);
            }
            /*int */ FindFirstCharacterToEncode$1(/*ReadOnlySpan<char>*/ text)
            {
                /*fixed*/ 
                {
                    /*char**/ let pText = $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference$1($.$spc.System.Char, text);
                    return this.FindFirstCharacterToEncode(pText, text.Length);
                }
            }
            /*int */ FindFirstCharacterToEncodeUtf8(/*ReadOnlySpan<byte>*/ utf8Text)
            {
                /*int*/ let utf8TextOriginalLength = utf8Text.Length;
                while(!utf8Text.IsEmpty)
                {
                    /*Rune*/ let scalarValue;
                    /*int*/ let bytesConsumed;
                    /*OperationStatus*/ let opStatus = $.$spc.System.Text.Rune.DecodeFromUtf8(utf8Text, $.$ref(() => scalarValue, ($v) => scalarValue = $v, $.$spc.System.Text.Rune), $.$ref(() => bytesConsumed, ($v) => bytesConsumed = $v, $.$spc.System.Int32));
                    if (opStatus !== 0/*OperationStatus.Done*/ || this.WillEncode(scalarValue.Value))
                    {
                        break;
                    }
                    utf8Text = utf8Text.Slice(bytesConsumed);
                }
                return (utf8Text.IsEmpty) ? -1 : ((utf8TextOriginalLength - utf8Text.Length) | 0);
            }
            static /*bool */ TryCopyCharacters(/*string*/ source, /*Span<char>*/ destination, /*out int*/ numberOfCharactersWritten)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(!$.$spc.System.String.IsNullOrEmpty(source), "!string.IsNullOrEmpty(source)");
                if (destination.Length < source.length)
                {
                    numberOfCharactersWritten.$v = 0;
                    return false;
                }
                for(/*int*/ let i = 0; i < source.length; i++)
                {
                    destination.get_Item(i).$v = $.$spc.System.String.get_Chars.call(source, i);
                }
                numberOfCharactersWritten.$v = source.length;
                return true;
            }
            static /*bool */ TryWriteScalarAsChar(/*int*/ unicodeScalar, /*Span<char>*/ destination, /*out int*/ numberOfCharactersWritten)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(unicodeScalar < 65535/*ushort.MaxValue*/, "unicodeScalar < ushort.MaxValue");
                if (destination.IsEmpty)
                {
                    numberOfCharactersWritten.$v = 0;
                    return false;
                }
                destination.get_Item(0).$v = $.$cast(unicodeScalar, $.$spc.System.Char);
                numberOfCharactersWritten.$v = 1;
                return true;
            }
            static /*void */ ValidateRanges(/*int*/ startIndex, /*int*/ characterCount, /*int*/ actualInputLength)
            {
                if (startIndex < 0 || startIndex > actualInputLength)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("startIndex");
                }
                if (characterCount < 0 || characterCount > (((actualInputLength - startIndex) | 0)))
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("characterCount");
                }
            }
            static /*void */ ThrowArgumentException_MaxOutputCharsPerInputChar()
            {
                throw new $.$spc.System.ArgumentException().$ctor$10($.$stew.System.SR.TextEncoderDoesNotImplementMaxOutputCharsPerInputChar);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 1478348;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":34361216716,"f":257},"n":"MaxOutputCharactersPerInputCharacter","d":1478348,"h":30066249420,"f":257,"a":[{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]}],"m":[{"r":262145,"p":[{"n":"unicodeScalar","p":655361},{"n":"buffer","p":0},{"n":"bufferLength","p":655361},{"n":"numberOfCharactersWritten","p":655361,"f":2}],"n":"TryEncodeUnicodeScalar","d":1478348,"h":8591412940,"f":257,"a":[{"t":23461889,"c":8613396481,"a":[{"v":false,"t":262145}]},{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]},{"r":262145,"p":[{"n":"unicodeScalar","p":720897},{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Char).$h},{"n":"charsWritten","p":655361,"f":2}],"n":"TryEncodeUnicodeScalar","o":"@$1","d":1478348,"h":12886380236,"f":2},{"r":262145,"p":[{"n":"unicodeScalar","p":720897},{"n":"utf16ScratchBuffer","p":$.$spc.System.Span$$($.$spc.System.Char).$h},{"n":"utf8Destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"bytesWritten","p":655361,"f":2}],"n":"TryEncodeUnicodeScalarUtf8","d":1478348,"h":17181347532,"f":2},{"r":655361,"p":[{"n":"text","p":0},{"n":"textLength","p":655361}],"n":"FindFirstCharacterToEncode","d":1478348,"h":21476314828,"f":257,"a":[{"t":23461889,"c":8613396481,"a":[{"v":false,"t":262145}]},{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]},{"r":262145,"p":[{"n":"unicodeScalar","p":655361}],"n":"WillEncode","d":1478348,"h":25771282124,"f":257,"a":[{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]},{"r":1310721,"p":[{"n":"value","p":1310721}],"n":"Encode","d":1478348,"h":38656184012,"f":129},{"r":1310721,"p":[{"n":"value","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"indexOfFirstCharToEncode","p":655361}],"n":"EncodeToNewString","d":1478348,"h":42951151308,"f":2},{"r":65537,"p":[{"n":"output","p":63045633},{"n":"value","p":1310721}],"n":"Encode","o":"@$1","d":1478348,"h":47246118604,"f":1},{"r":65537,"p":[{"n":"output","p":63045633},{"n":"value","p":1310721},{"n":"startIndex","p":655361},{"n":"characterCount","p":655361}],"n":"Encode","o":"@$2","d":1478348,"h":51541085900,"f":129},{"r":65537,"p":[{"n":"output","p":63045633},{"n":"value","p":0},{"n":"startIndex","p":655361},{"n":"characterCount","p":655361}],"n":"Encode","o":"@$3","d":1478348,"h":55836053196,"f":129},{"r":18677761,"p":[{"n":"utf8Source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"utf8Destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"bytesConsumed","p":655361,"f":2},{"n":"bytesWritten","p":655361,"f":2},{"n":"isFinalBlock","p":262145,"f":65,"v":true}],"n":"EncodeUtf8","d":1478348,"h":60131020492,"f":129},{"r":18677761,"p":[{"n":"utf8Source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"utf8Destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"bytesConsumed","p":655361,"f":2},{"n":"bytesWritten","p":655361,"f":2},{"n":"isFinalBlock","p":262145}],"n":"EncodeUtf8Core","d":1478348,"h":64425987788,"f":128},{"r":18677761,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Char).$h},{"n":"charsConsumed","p":655361,"f":2},{"n":"charsWritten","p":655361,"f":2},{"n":"isFinalBlock","p":262145,"f":65,"v":true}],"n":"Encode","o":"@$4","d":1478348,"h":68720955084,"f":129},{"r":18677761,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Char).$h},{"n":"charsConsumed","p":655361,"f":2},{"n":"charsWritten","p":655361,"f":2},{"n":"isFinalBlock","p":262145}],"n":"EncodeCore","d":1478348,"h":73015922380,"f":128},{"r":65537,"p":[{"n":"output","p":63045633},{"n":"value","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h}],"n":"EncodeCore","o":"@$1","d":1478348,"h":77310889676,"f":2},{"r":655361,"p":[{"n":"text","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h}],"n":"FindFirstCharacterToEncode","o":"@$1","d":1478348,"h":81605856972,"f":128},{"r":655361,"p":[{"n":"utf8Text","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"FindFirstCharacterToEncodeUtf8","d":1478348,"h":85900824268,"f":129,"a":[{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]},{"r":262145,"p":[{"n":"source","p":1310721},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Char).$h},{"n":"numberOfCharactersWritten","p":655361,"f":2}],"n":"TryCopyCharacters","d":1478348,"h":90195791564,"f":40},{"r":262145,"p":[{"n":"unicodeScalar","p":655361},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Char).$h},{"n":"numberOfCharactersWritten","p":655361,"f":2}],"n":"TryWriteScalarAsChar","d":1478348,"h":94490758860,"f":40},{"r":65537,"p":[{"n":"startIndex","p":655361},{"n":"characterCount","p":655361},{"n":"actualInputLength","p":655361}],"n":"ValidateRanges","d":1478348,"h":98785726156,"f":34},{"r":65537,"n":"ThrowArgumentException_MaxOutputCharsPerInputChar","d":1478348,"h":103080693452,"f":34}],"l":[{"t":655361,"n":"EncodeStartingOutputBufferSize","d":1478348,"h":4296445644,"f":34}],"c":[{"n":".ctor","o":"$ctor$1","d":1478348,"h":107375660748,"f":4}],"h":1478348}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Text.Encodings.Web.TextEncoder`; }
        });
        
        $asm.$cls("$stew.System.Text.Encodings.Web.HtmlEncoder", ($self) => class HtmlEncoder extends $.$stew.System.Text.Encodings.Web.TextEncoder
        {
            static /*HtmlEncoder */ get Default()
            {
                return $.$stew.System.Text.Encodings.Web.DefaultHtmlEncoder.BasicLatinSingleton;
            }
            static /*HtmlEncoder */ Create(/*TextEncoderSettings*/ settings)
            {
                return new $.$stew.System.Text.Encodings.Web.DefaultHtmlEncoder().$ctor$3(settings);
            }
            static /*HtmlEncoder */ Create$1(/*params UnicodeRange[]*/ allowedRanges)
            {
                return new $.$stew.System.Text.Encodings.Web.DefaultHtmlEncoder().$ctor$3(new $.$stew.System.Text.Encodings.Web.TextEncoderSettings().$ctor$3(allowedRanges));
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 1150668;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1478348,"p":[{"p":1150668,"g":{"r":0,"d":0,"h":8591085260,"f":33},"n":"Default","d":1150668,"h":4296117964,"f":33}],"m":[{"r":1150668,"p":[{"n":"settings","p":1543884}],"n":"Create","d":1150668,"h":12886052556,"f":33},{"r":1150668,"p":[{"n":"allowedRanges","p":0,"f":16}],"n":"Create","o":"@$1","d":1150668,"h":17181019852,"f":33}],"c":[{"n":".ctor","o":"$ctor$2","d":1150668,"h":21475987148,"f":4}],"h":1150668}; }
            static get $b() { return $.$stew.System.Text.Encodings.Web.TextEncoder; }
            static get $fullName() { return `System.Text.Encodings.Web.HtmlEncoder`; }
        });
        
        $asm.$cls("$stew.System.Text.Encodings.Web.JavaScriptEncoder", ($self) => class JavaScriptEncoder extends $.$stew.System.Text.Encodings.Web.TextEncoder
        {
            static /*JavaScriptEncoder */ get Default()
            {
                return $.$stew.System.Text.Encodings.Web.DefaultJavaScriptEncoder.BasicLatinSingleton;
            }
            static /*JavaScriptEncoder */ get UnsafeRelaxedJsonEscaping()
            {
                return $.$stew.System.Text.Encodings.Web.DefaultJavaScriptEncoder.UnsafeRelaxedEscapingSingleton;
            }
            static /*JavaScriptEncoder */ Create(/*TextEncoderSettings*/ settings)
            {
                return new $.$stew.System.Text.Encodings.Web.DefaultJavaScriptEncoder().$ctor$3(settings);
            }
            static /*JavaScriptEncoder */ Create$1(/*params UnicodeRange[]*/ allowedRanges)
            {
                return new $.$stew.System.Text.Encodings.Web.DefaultJavaScriptEncoder().$ctor$3(new $.$stew.System.Text.Encodings.Web.TextEncoderSettings().$ctor$3(allowedRanges));
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 1216204;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1478348,"p":[{"p":1216204,"g":{"r":0,"d":0,"h":8591150796,"f":33},"n":"Default","d":1216204,"h":4296183500,"f":33},{"p":1216204,"g":{"r":0,"d":0,"h":17181085388,"f":33},"n":"UnsafeRelaxedJsonEscaping","d":1216204,"h":12886118092,"f":33}],"m":[{"r":1216204,"p":[{"n":"settings","p":1543884}],"n":"Create","d":1216204,"h":21476052684,"f":33},{"r":1216204,"p":[{"n":"allowedRanges","p":0,"f":16}],"n":"Create","o":"@$1","d":1216204,"h":25771019980,"f":33}],"c":[{"n":".ctor","o":"$ctor$2","d":1216204,"h":30065987276,"f":4}],"h":1216204}; }
            static get $b() { return $.$stew.System.Text.Encodings.Web.TextEncoder; }
            static get $fullName() { return `System.Text.Encodings.Web.JavaScriptEncoder`; }
        });
        
        $asm.$cls("$stew.System.Text.Encodings.Web.UrlEncoder", ($self) => class UrlEncoder extends $.$stew.System.Text.Encodings.Web.TextEncoder
        {
            static /*UrlEncoder */ get Default()
            {
                return $.$stew.System.Text.Encodings.Web.DefaultUrlEncoder.BasicLatinSingleton;
            }
            static /*UrlEncoder */ Create(/*TextEncoderSettings*/ settings)
            {
                return new $.$stew.System.Text.Encodings.Web.DefaultUrlEncoder().$ctor$3(settings);
            }
            static /*UrlEncoder */ Create$1(/*params UnicodeRange[]*/ allowedRanges)
            {
                return new $.$stew.System.Text.Encodings.Web.DefaultUrlEncoder().$ctor$3(new $.$stew.System.Text.Encodings.Web.TextEncoderSettings().$ctor$3(allowedRanges));
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 1674956;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1478348,"p":[{"p":1674956,"g":{"r":0,"d":0,"h":8591609548,"f":33},"n":"Default","d":1674956,"h":4296642252,"f":33}],"m":[{"r":1674956,"p":[{"n":"settings","p":1543884}],"n":"Create","d":1674956,"h":12886576844,"f":33},{"r":1674956,"p":[{"n":"allowedRanges","p":0,"f":16}],"n":"Create","o":"@$1","d":1674956,"h":17181544140,"f":33}],"c":[{"n":".ctor","o":"$ctor$2","d":1674956,"h":21476511436,"f":4}],"h":1674956}; }
            static get $b() { return $.$stew.System.Text.Encodings.Web.TextEncoder; }
            static get $fullName() { return `System.Text.Encodings.Web.UrlEncoder`; }
        });
        
        $asm.$cls("$stew.System.Text.Encodings.Web.OptimizedInboxTextEncoder", ($self) => class OptimizedInboxTextEncoder extends $.$spc.System.Object
        {
            static $_AsciiPreescapedData;
            static get AsciiPreescapedData()
            {
                let $cls = $.$stew.System.Text.Encodings.Web.OptimizedInboxTextEncoder;
                return $cls.$_AsciiPreescapedData ??= $asm.$nstr("$stew.System.Text.Encodings.Web.OptimizedInboxTextEncoder.AsciiPreescapedData", ($self) => class AsciiPreescapedData extends $.$spc.System.ValueType
                {
                    /*ulong[128]*/  get Data() { return this.$getField(0, 0x80000000|128); }
                    /*ulong[128]*/  set Data(value) { this.$setField(0, 0x80000000|128, value); }
                    /*void */ PopulatePreescapedData(/*in AllowedBmpCodePointsBitmap*/ allowedCodePointsBmp, /*ScalarEscaperBase*/ innerEncoder)
                    {
                        new $.$stew.System.Text.Encodings.Web.OptimizedInboxTextEncoder.AsciiPreescapedData().Clone(this);
                        /*Span<char>*/ let tempBuffer = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Char, 8, [/*\u0000*/ 0, /*\u0000*/ 0, /*\u0000*/ 0, /*\u0000*/ 0, /*\u0000*/ 0, /*\u0000*/ 0, /*\u0000*/ 0, /*\u0000*/ 0]);
                        for(/*int*/ let i = 0; i < 128; i++)
                        {
                            /*ulong*/ let thisPreescapedData;
                            /*int*/ let encodedCharCount;
                            /*Rune*/ let rune = new $.$spc.System.Text.Rune().$ctor$4(i);
                            if (!$.$spc.System.Text.Rune.IsControl(rune) && allowedCodePointsBmp.$v.IsCharAllowed($.$cast(i, $.$spc.System.Char)))
                            {
                                thisPreescapedData = BigInt((i >>> 0));
                                encodedCharCount = 1;
                            }
                            else 
                            {
                                encodedCharCount = innerEncoder.EncodeUtf16(rune, tempBuffer.Slice$1(0, 6));
                                $.$spc.System.Diagnostics.Debug.Assert$1(encodedCharCount > 0 && encodedCharCount <= 6, "Inner encoder returned bad length.");
                                thisPreescapedData = 0n;
                                tempBuffer.Slice(encodedCharCount).Clear();
                                for(/*int*/ let j = ((encodedCharCount - 1) | 0); j >= 0; j--)
                                {
                                    /*uint*/ let thisChar = tempBuffer.get_Item(j).$v;
                                    $.$spc.System.Diagnostics.Debug.Assert$1(thisChar <= 127, "Inner encoder returned non-ASCII data.");
                                    thisPreescapedData = (BigInt.asUintN(64, thisPreescapedData << 8n)) | BigInt(thisChar);
                                }
                            }
                            this.Data[i] = thisPreescapedData | (BigInt.asUintN(64, $.$cast((encodedCharCount >>> 0), $.$spc.System.UInt64) << 56n));
                        }
                    }
                    /*bool */ TryGetPreescapedData(/*uint*/ codePoint, /*out ulong*/ preescapedData)
                    {
                        if (codePoint <= 127)
                        {
                            preescapedData.$v = this.Data[codePoint];
                            return true;
                        }
                        else 
                        {
                            preescapedData.$v = 0n;
                            return false;
                        }
                    }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        //InlineArray(128)
                        copy.Data = [...this.Data];
                        $.$spc.System.Array.CopyMetadata(copy.Data, this.Data)
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //FixedSizeArray(ulong*, 128)
                        let $t1 = this.Data;
                        $.$spc.System.Array.AddMetadata($t1, $.$spc.System.UInt64.$type, null, null);
                        for (let $i = 0; $i < 128; $i++)
                        {
                            $t1[$i] = 0n;
                        }
                    }
                    static $h = 1347276;
                    static $z = 128;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"m":[{"r":65537,"p":[{"n":"allowedCodePointsBmp","p":560844,"f":8},{"n":"innerEncoder","p":1412812}],"n":"PopulatePreescapedData","d":1347276,"h":8591281868,"f":8},{"r":262145,"p":[{"n":"codePoint","p":720897},{"n":"preescapedData","p":983041,"f":2}],"n":"TryGetPreescapedData","d":1347276,"h":12886249164,"f":8}],"l":[{"t":0,"n":"Data","d":1347276,"h":4296314572,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":1347276,"h":17181216460,"f":1}],"d":1281740,"h":1347276}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `System.Text.Encodings.Web.OptimizedInboxTextEncoder.AsciiPreescapedData`; }
                }, $cls, ($v) => $cls.$_AsciiPreescapedData = $v);
            }
            /*AsciiPreescapedData*/ _asciiPreescapedData;
            /*AllowedBmpCodePointsBitmap*/ _allowedBmpCodePoints;
            /*ScalarEscaperBase*/ _scalarEscaper = null;
            /*SearchValues<byte>*/ _allowedAsciiBytes = null;
            /*SearchValues<char>*/ _allowedAsciiChars = null;
            $ctor$1(/*ScalarEscaperBase*/ scalarEscaper, /*in AllowedBmpCodePointsBitmap*/ allowedCodePointsBmp, /*bool*/ forbidHtmlSensitiveCharacters, /*ReadOnlySpan<char>*/ extraCharactersToEscape)
            {
                super.$ctor();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(scalarEscaper !== null, "scalarEscaper != null");
                    this._scalarEscaper = scalarEscaper;
                    this._allowedBmpCodePoints = allowedCodePointsBmp.$v;
                    allowedCodePointsBmp = $.$spc.System.Runtime.CompilerServices.Unsafe.NullRef($.$stew.System.Text.Encodings.Web.AllowedBmpCodePointsBitmap);
                    this._allowedBmpCodePoints.ForbidUndefinedCharacters();
                    if (forbidHtmlSensitiveCharacters)
                    {
                        this._allowedBmpCodePoints.ForbidHtmlCharacters();
                    }
                    var $en3 = extraCharactersToEscape.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var ch = $en3.Current.$v;
                        {
                            this._allowedBmpCodePoints.ForbidChar(ch);
                        }
                    }
                    this._asciiPreescapedData.PopulatePreescapedData($.$ref(() => this._allowedBmpCodePoints, ), scalarEscaper);
                    /*Span<byte>*/ let allowedAsciiBytes = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, 128, null);
                    /*Span<char>*/ let allowedAsciiChars = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Char, 128, null);
                    /*int*/ let allowedAsciiCount = 0;
                    for(/*int*/ let i = 0; i < 128; i++)
                    {
                        if (this._allowedBmpCodePoints.IsCharAllowed($.$cast(i, $.$spc.System.Char)))
                        {
                            allowedAsciiBytes.get_Item(allowedAsciiCount).$v = $.$cast(i, $.$spc.System.Byte);
                            allowedAsciiChars.get_Item(allowedAsciiCount).$v = $.$cast(i, $.$spc.System.Char);
                            allowedAsciiCount++;
                        }
                    }
                    this._allowedAsciiBytes = $.$spc.System.Buffers.SearchValues.Create($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2(allowedAsciiBytes.Slice$1(0, allowedAsciiCount)));
                    this._allowedAsciiChars = $.$spc.System.Buffers.SearchValues.Create$1($.$spc.System.Span$$($.$spc.System.Char).op_Implicit$2(allowedAsciiChars.Slice$1(0, allowedAsciiCount)));
                }
                return this;
            }
            /*int */ FindFirstCharacterToEncode(/*char**/ text, /*int*/ textLength)
            {
                return this.GetIndexOfFirstCharToEncode(new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Char))().$ctor$4(text, textLength));
            }
            /*bool */ TryEncodeUnicodeScalar(/*int*/ unicodeScalar, /*char**/ buffer, /*int*/ bufferLength, /*out int*/ numberOfCharactersWritten)
            {
                /*Span<char>*/ let destination = new ($.$spc.System.Span$$($.$spc.System.Char))().$ctor$4(buffer, bufferLength);
                if (this._allowedBmpCodePoints.IsCodePointAllowed((unicodeScalar >>> 0)))
                {
                    $.$stew.System.Text.UnicodeDebug.AssertIsBmpCodePoint((unicodeScalar >>> 0));
                    $.$stew.System.Text.UnicodeDebug.AssertIsValidScalar((unicodeScalar >>> 0));
                    if (!destination.IsEmpty)
                    {
                        destination.get_Item(0).$v = $.$cast(unicodeScalar, $.$spc.System.Char);
                        numberOfCharactersWritten.$v = 1;
                        return true;
                    }
                }
                else 
                {
                    /*int*/ let innerCharsWritten = this._scalarEscaper.EncodeUtf16(new $.$spc.System.Text.Rune().$ctor$4(unicodeScalar), destination);
                    $.$spc.System.Diagnostics.Debug.Assert$1(innerCharsWritten <= bufferLength, "Mustn't overflow the buffer.");
                    $.$spc.System.Diagnostics.Debug.Assert$1(innerCharsWritten !== 0, "Inner escaper succeeded with 0-char output?");
                    if (innerCharsWritten >= 0)
                    {
                        numberOfCharactersWritten.$v = innerCharsWritten;
                        return true;
                    }
                }
                numberOfCharactersWritten.$v = 0;
                return false;
            }
            /*OperationStatus */ Encode(/*ReadOnlySpan<char>*/ source, /*Span<char>*/ destination, /*out int*/ charsConsumed, /*out int*/ charsWritten, /*bool*/ isFinalBlock)
            {
                /*int*/ let srcIdx;
                /*int*/ let dstIdx;
                /*OperationStatus*/ let retVal;
                let $gotoJumpState1 = 0;
                $gotoJumpStart1: while(true)
                {
                    switch($gotoJumpState1)
                    {
                        case 0:
                        {
                            this._AssertThisNotNull();
                            srcIdx = 0;
                            dstIdx = 0;
                            $whileJumpStart2: while(true)
                            {
                                /*char*/ let thisChar;
                                /*int*/ let dstIdxTemp;
                                /*int*/ let charsWrittenJustNow;
                                let $gotoJumpState3 = 0;
                                $gotoJumpStart3: while(true)
                                {
                                    switch($gotoJumpState3)
                                    {
                                        case 0:
                                        {
                                            if ((source.Length >>> 0) <= (srcIdx >>> 0))
                                            {
                                                break $whileJumpStart2;
                                            }
                                            thisChar = source.get_Item(srcIdx).$v;
                                            /*ulong*/ let preescapedEntry;
                                            if (!this._asciiPreescapedData.TryGetPreescapedData(thisChar, $.$ref(() => preescapedEntry, ($v) => preescapedEntry = $v, $.$spc.System.UInt64)))
                                            {
                                                $gotoJumpState3 = 1; /*goto NotAscii*/
                                                continue $gotoJumpStart3;
                                            }
                                            if ((destination.Length >>> 0) <= (dstIdx >>> 0))
                                            {
                                                $gotoJumpState1 = 2; /*goto DestTooSmall*/
                                                continue $gotoJumpStart1;
                                            }
                                            destination.get_Item(dstIdx).$v = $.$cast(preescapedEntry, $.$spc.System.Byte);
                                            if (($.$cast(preescapedEntry, $.$spc.System.UInt32) & 65280) === 0)
                                            {
                                                dstIdx++;
                                                srcIdx++;
                                                continue $whileJumpStart2;
                                            }
                                            preescapedEntry >>= 8n;
                                            dstIdxTemp = ((dstIdx + 1) | 0);
                                            do
                                            {
                                                if ((destination.Length >>> 0) <= (dstIdxTemp >>> 0))
                                                {
                                                    $gotoJumpState1 = 2; /*goto DestTooSmall*/
                                                    continue $gotoJumpStart1;
                                                }
                                                destination.get_Item(dstIdxTemp++).$v = $.$cast(preescapedEntry, $.$spc.System.Byte);
                                            }
                                            while($.$cast((preescapedEntry >>= 8n), $.$spc.System.Byte) !== 0);
                                            dstIdx = dstIdxTemp;
                                            srcIdx++;
                                            continue $whileJumpStart2;
                                        }
                                        case 1: /*NotAscii*/
                                        /*Rune*/ let scalarValue;
                                        if (!$.$spc.System.Text.Rune.TryCreate(thisChar, $.$ref(() => scalarValue, ($v) => scalarValue = $v, $.$spc.System.Text.Rune)))
                                        {
                                            /*int*/ let srcIdxTemp = ((srcIdx + 1) | 0);
                                            if ((source.Length >>> 0) > (srcIdxTemp >>> 0))
                                            {
                                                if ($.$spc.System.Text.Rune.TryCreate$1(thisChar, source.get_Item(srcIdxTemp).$v, $.$ref(() => scalarValue, ($v) => scalarValue = $v, $.$spc.System.Text.Rune)))
                                                {
                                                    $gotoJumpState3 = 2; /*goto CheckWhetherScalarValueAllowed*/
                                                    continue $gotoJumpStart3;
                                                }
                                            }
                                            else if (!isFinalBlock && $.$spc.System.Char.IsHighSurrogate(thisChar))
                                            {
                                                $gotoJumpState1 = 3; /*goto NeedMoreData*/
                                                continue $gotoJumpStart1;
                                            }
                                            scalarValue = $.$spc.System.Text.Rune.ReplacementChar;
                                            $gotoJumpState3 = 3; /*goto MustEncodeNonAscii*/
                                            continue $gotoJumpStart3;
                                        }
                                        case 2: /*CheckWhetherScalarValueAllowed*/
                                        if (this.IsScalarValueAllowed(scalarValue))
                                        {
                                            /*int*/ let utf16CodeUnitCount;
                                            if (!scalarValue.TryEncodeToUtf16(destination.Slice(dstIdx), $.$ref(() => utf16CodeUnitCount, ($v) => utf16CodeUnitCount = $v, $.$spc.System.Int32)))
                                            {
                                                $gotoJumpState1 = 2; /*goto DestTooSmall*/
                                                continue $gotoJumpStart1;
                                            }
                                            dstIdx += utf16CodeUnitCount;
                                            srcIdx += utf16CodeUnitCount;
                                            continue $whileJumpStart2;
                                        }
                                        case 3: /*MustEncodeNonAscii*/
                                        charsWrittenJustNow = this._scalarEscaper.EncodeUtf16(scalarValue, destination.Slice(dstIdx));
                                        if (charsWrittenJustNow < 0)
                                        {
                                            $gotoJumpState1 = 2; /*goto DestTooSmall*/
                                            continue $gotoJumpStart1;
                                        }
                                        dstIdx += charsWrittenJustNow;
                                        srcIdx += scalarValue.Utf16SequenceLength;
                                    }
                                    break;
                                }
                            }
                            retVal = 0/*OperationStatus.Done*/;
                        }
                        case 1: /*CommonReturn*/
                        charsConsumed.$v = srcIdx;
                        charsWritten.$v = dstIdx;
                        return retVal;
                        case 2: /*DestTooSmall*/
                        retVal = 1/*OperationStatus.DestinationTooSmall*/;
                        $gotoJumpState1 = 1; /*goto CommonReturn*/
                        continue $gotoJumpStart1;
                        case 3: /*NeedMoreData*/
                        retVal = 2/*OperationStatus.NeedMoreData*/;
                        $gotoJumpState1 = 1; /*goto CommonReturn*/
                        continue $gotoJumpStart1;
                    }
                    break;
                }
            }
            /*OperationStatus */ EncodeUtf8(/*ReadOnlySpan<byte>*/ source, /*Span<byte>*/ destination, /*out int*/ bytesConsumed, /*out int*/ bytesWritten, /*bool*/ isFinalBlock)
            {
                /*int*/ let srcIdx;
                /*int*/ let dstIdx;
                /*OperationStatus*/ let retVal;
                let $gotoJumpState1 = 0;
                $gotoJumpStart1: while(true)
                {
                    switch($gotoJumpState1)
                    {
                        case 0:
                        {
                            this._AssertThisNotNull();
                            srcIdx = 0;
                            dstIdx = 0;
                            $whileJumpStart2: while(true)
                            {
                                /*uint*/ let thisByte;
                                /*int*/ let dstIdxTemp;
                                /*OperationStatus*/ let runeDecodeStatus;
                                /*int*/ let bytesWrittenJustNow;
                                let $gotoJumpState3 = 0;
                                $gotoJumpStart3: while(true)
                                {
                                    switch($gotoJumpState3)
                                    {
                                        case 0:
                                        {
                                            if ((source.Length >>> 0) <= (srcIdx >>> 0))
                                            {
                                                break $whileJumpStart2;
                                            }
                                            thisByte = source.get_Item(srcIdx).$v;
                                            /*ulong*/ let preescapedEntry;
                                            if (!this._asciiPreescapedData.TryGetPreescapedData(thisByte, $.$ref(() => preescapedEntry, ($v) => preescapedEntry = $v, $.$spc.System.UInt64)))
                                            {
                                                $gotoJumpState3 = 1; /*goto NotAscii*/
                                                continue $gotoJumpStart3;
                                            }
                                            if ($.$spc.System.Buffers.Binary.BinaryPrimitives.TryWriteUInt64LittleEndian(destination.Slice(dstIdx), preescapedEntry))
                                            {
                                                dstIdx += $.$cast((preescapedEntry >> 56n), $.$spc.System.Int32);
                                                srcIdx++;
                                                continue $whileJumpStart2;
                                            }
                                            dstIdxTemp = dstIdx;
                                            do
                                            {
                                                if ((destination.Length >>> 0) <= (dstIdxTemp >>> 0))
                                                {
                                                    $gotoJumpState1 = 2; /*goto DestTooSmall*/
                                                    continue $gotoJumpStart1;
                                                }
                                                destination.get_Item(dstIdxTemp++).$v = $.$cast(preescapedEntry, $.$spc.System.Byte);
                                            }
                                            while($.$cast((preescapedEntry >>= 8n), $.$spc.System.Byte) !== 0);
                                            dstIdx = dstIdxTemp;
                                            srcIdx++;
                                            continue $whileJumpStart2;
                                        }
                                        case 1: /*NotAscii*/
                                        /*Rune*/ let scalarValue;
                                        /*int*/ let bytesConsumedJustNow;
                                        runeDecodeStatus = $.$spc.System.Text.Rune.DecodeFromUtf8(source.Slice(srcIdx), $.$ref(() => scalarValue, ($v) => scalarValue = $v, $.$spc.System.Text.Rune), $.$ref(() => bytesConsumedJustNow, ($v) => bytesConsumedJustNow = $v, $.$spc.System.Int32));
                                        if (runeDecodeStatus !== 0/*OperationStatus.Done*/)
                                        {
                                            if (!isFinalBlock && runeDecodeStatus === 2/*OperationStatus.NeedMoreData*/)
                                            {
                                                $gotoJumpState1 = 3; /*goto NeedMoreData*/
                                                continue $gotoJumpStart1;
                                            }
                                            $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Text.Rune.op_Equality(scalarValue, $.$spc.System.Text.Rune.ReplacementChar), "scalarValue == Rune.ReplacementChar");
                                            $gotoJumpState3 = 2; /*goto MustEncodeNonAscii*/
                                            continue $gotoJumpStart3;
                                        }
                                        if (this.IsScalarValueAllowed(scalarValue))
                                        {
                                            /*int*/ let utf8CodeUnitCount;
                                            if (!scalarValue.TryEncodeToUtf8(destination.Slice(dstIdx), $.$ref(() => utf8CodeUnitCount, ($v) => utf8CodeUnitCount = $v, $.$spc.System.Int32)))
                                            {
                                                $gotoJumpState1 = 2; /*goto DestTooSmall*/
                                                continue $gotoJumpStart1;
                                            }
                                            dstIdx += utf8CodeUnitCount;
                                            srcIdx += utf8CodeUnitCount;
                                            continue $whileJumpStart2;
                                        }
                                        case 2: /*MustEncodeNonAscii*/
                                        bytesWrittenJustNow = this._scalarEscaper.EncodeUtf8(scalarValue, destination.Slice(dstIdx));
                                        if (bytesWrittenJustNow < 0)
                                        {
                                            $gotoJumpState1 = 2; /*goto DestTooSmall*/
                                            continue $gotoJumpStart1;
                                        }
                                        dstIdx += bytesWrittenJustNow;
                                        srcIdx += bytesConsumedJustNow;
                                    }
                                    break;
                                }
                            }
                            retVal = 0/*OperationStatus.Done*/;
                        }
                        case 1: /*CommonReturn*/
                        bytesConsumed.$v = srcIdx;
                        bytesWritten.$v = dstIdx;
                        return retVal;
                        case 2: /*DestTooSmall*/
                        retVal = 1/*OperationStatus.DestinationTooSmall*/;
                        $gotoJumpState1 = 1; /*goto CommonReturn*/
                        continue $gotoJumpStart1;
                        case 3: /*NeedMoreData*/
                        retVal = 2/*OperationStatus.NeedMoreData*/;
                        $gotoJumpState1 = 1; /*goto CommonReturn*/
                        continue $gotoJumpStart1;
                    }
                    break;
                }
            }
            /*int */ GetIndexOfFirstByteToEncode(/*ReadOnlySpan<byte>*/ data)
            {
                /*int*/ let asciiBytesSkipped = 0;
                asciiBytesSkipped = $.$spc.System.MemoryExtensions.IndexOfAnyExcept$14($.$spc.System.Byte, data, this._allowedAsciiBytes);
                if ((asciiBytesSkipped >>> 0) >= (data.Length >>> 0) || $.$stew.System.Text.UnicodeUtility.IsAsciiCodePoint(data.get_Item(asciiBytesSkipped).$v))
                {
                    return asciiBytesSkipped;
                }
                /*int*/ let dataOriginalLength = data.Length;
                data = data.Slice(asciiBytesSkipped);
                while(!data.IsEmpty)
                {
                    /*Rune*/ let scalarValue;
                    /*int*/ let bytesConsumed;
                    /*OperationStatus*/ let opStatus = $.$spc.System.Text.Rune.DecodeFromUtf8(data, $.$ref(() => scalarValue, ($v) => scalarValue = $v, $.$spc.System.Text.Rune), $.$ref(() => bytesConsumed, ($v) => bytesConsumed = $v, $.$spc.System.Int32));
                    if (opStatus !== 0/*OperationStatus.Done*/)
                    {
                        break;
                    }
                    if (bytesConsumed >= 4)
                    {
                        break;
                    }
                    $.$stew.System.Text.UnicodeDebug.AssertIsBmpCodePoint((scalarValue.Value >>> 0));
                    if (!this._allowedBmpCodePoints.IsCharAllowed($.$cast(scalarValue.Value, $.$spc.System.Char)))
                    {
                        break;
                    }
                    data = data.Slice(bytesConsumed);
                }
                return (data.IsEmpty) ? -1 : ((dataOriginalLength - data.Length) | 0);
            }
            /*int */ GetIndexOfFirstCharToEncode(/*ReadOnlySpan<char>*/ data)
            {
                /*int*/ let asciiCharsSkipped = 0;
                if (data.Length >= 8)
                {
                    asciiCharsSkipped = $.$spc.System.MemoryExtensions.IndexOfAnyExcept$14($.$spc.System.Char, data, this._allowedAsciiChars);
                    if ((asciiCharsSkipped >>> 0) >= (data.Length >>> 0) || $.$spc.System.Char.IsAscii(data.get_Item(asciiCharsSkipped).$v))
                    {
                        return asciiCharsSkipped;
                    }
                }
                /*fixed*/ 
                {
                    /*char**/ let pData = data.GetPinnableReference();
                    /*nuint*/ let lengthInChars;
                    /*nuint*/ let idx;
                    /*int*/ let idx32;
                    let $gotoJumpState1 = 0;
                    $gotoJumpStart1: while(true)
                    {
                        switch($gotoJumpState1)
                        {
                            case 0:
                            {
                                lengthInChars = (data.Length >>> 0);
                                idx = (asciiCharsSkipped >>> 0);
                                if (idx < lengthInChars)
                                {
                                    /*nint*/ let loopIter;
                                    let $gotoJumpState2 = 0;
                                    $gotoJumpStart2: while(true)
                                    {
                                        switch($gotoJumpState2)
                                        {
                                            case 0:
                                            {
                                                this._AssertThisNotNull();
                                                loopIter = 0;
                                                for(; lengthInChars - idx >= 8; idx += 8)
                                                {
                                                    loopIter = -1;
                                                    if (!this._allowedBmpCodePoints.IsCharAllowed(pData.GetAt(idx + $.$cast((++loopIter), $.$spc.System.UIntPtr))))
                                                    {
                                                        $gotoJumpState2 = 1; /*goto BrokeInUnrolledLoop*/
                                                        continue $gotoJumpStart2;
                                                    }
                                                    if (!this._allowedBmpCodePoints.IsCharAllowed(pData.GetAt(idx + $.$cast((++loopIter), $.$spc.System.UIntPtr))))
                                                    {
                                                        $gotoJumpState2 = 1; /*goto BrokeInUnrolledLoop*/
                                                        continue $gotoJumpStart2;
                                                    }
                                                    if (!this._allowedBmpCodePoints.IsCharAllowed(pData.GetAt(idx + $.$cast((++loopIter), $.$spc.System.UIntPtr))))
                                                    {
                                                        $gotoJumpState2 = 1; /*goto BrokeInUnrolledLoop*/
                                                        continue $gotoJumpStart2;
                                                    }
                                                    if (!this._allowedBmpCodePoints.IsCharAllowed(pData.GetAt(idx + $.$cast((++loopIter), $.$spc.System.UIntPtr))))
                                                    {
                                                        $gotoJumpState2 = 1; /*goto BrokeInUnrolledLoop*/
                                                        continue $gotoJumpStart2;
                                                    }
                                                    if (!this._allowedBmpCodePoints.IsCharAllowed(pData.GetAt(idx + $.$cast((++loopIter), $.$spc.System.UIntPtr))))
                                                    {
                                                        $gotoJumpState2 = 1; /*goto BrokeInUnrolledLoop*/
                                                        continue $gotoJumpStart2;
                                                    }
                                                    if (!this._allowedBmpCodePoints.IsCharAllowed(pData.GetAt(idx + $.$cast((++loopIter), $.$spc.System.UIntPtr))))
                                                    {
                                                        $gotoJumpState2 = 1; /*goto BrokeInUnrolledLoop*/
                                                        continue $gotoJumpStart2;
                                                    }
                                                    if (!this._allowedBmpCodePoints.IsCharAllowed(pData.GetAt(idx + $.$cast((++loopIter), $.$spc.System.UIntPtr))))
                                                    {
                                                        $gotoJumpState2 = 1; /*goto BrokeInUnrolledLoop*/
                                                        continue $gotoJumpStart2;
                                                    }
                                                    if (!this._allowedBmpCodePoints.IsCharAllowed(pData.GetAt(idx + $.$cast((++loopIter), $.$spc.System.UIntPtr))))
                                                    {
                                                        $gotoJumpState2 = 1; /*goto BrokeInUnrolledLoop*/
                                                        continue $gotoJumpStart2;
                                                    }
                                                }
                                                for(; idx < lengthInChars; idx++)
                                                {
                                                    if (!this._allowedBmpCodePoints.IsCharAllowed(pData.GetAt(idx)))
                                                    {
                                                        break;
                                                    }
                                                }
                                                $gotoJumpState1 = 1; /*goto Return*/
                                                continue $gotoJumpStart1;
                                            }
                                            case 1: /*BrokeInUnrolledLoop*/
                                            idx += $.$cast(loopIter, $.$spc.System.UIntPtr);
                                        }
                                        break;
                                    }
                                }
                            }
                            case 1: /*Return*/
                            $.$spc.System.Diagnostics.Debug.Assert$1(0 <= idx && idx <= lengthInChars, "0 <= idx && idx <= lengthInChars");
                            idx32 = (idx | 0);
                            if (idx32 === (lengthInChars | 0))
                            {
                                idx32 = -1;
                            }
                            return idx32;
                        }
                        break;
                    }
                }
            }
            /*bool */ IsScalarValueAllowed(/*Rune*/ value)
            {
                return this._allowedBmpCodePoints.IsCodePointAllowed((value.Value >>> 0));
            }
            /*void */ _AssertThisNotNull()
            {
                if ($.$spc.System.Type.op_Equality$1($.$spc.System.Object.GetType.call(this), $.$stew.System.Text.Encodings.Web.OptimizedInboxTextEncoder.$type))
                {
                }
            }
            //default member initializer
            constructor()
            {
                super();
                this._asciiPreescapedData = $.$default($.$stew.System.Text.Encodings.Web.OptimizedInboxTextEncoder.AsciiPreescapedData);
                this._allowedBmpCodePoints = $.$default($.$stew.System.Text.Encodings.Web.AllowedBmpCodePointsBitmap);
            }
            static $h = 1281740;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":655361,"p":[{"n":"text","p":0},{"n":"textLength","p":655361}],"n":"FindFirstCharacterToEncode","d":1281740,"h":34361020108,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"FindFirstCharacterToEncode has been deprecated. It should only be used by the TextEncoder adapter.","t":1310721}]}]},{"r":262145,"p":[{"n":"unicodeScalar","p":655361},{"n":"buffer","p":0},{"n":"bufferLength","p":655361},{"n":"numberOfCharactersWritten","p":655361,"f":2}],"n":"TryEncodeUnicodeScalar","d":1281740,"h":38655987404,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"TryEncodeUnicodeScalar has been deprecated. It should only be used by the TextEncoder adapter.","t":1310721}]}]},{"r":18677761,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Char).$h},{"n":"charsConsumed","p":655361,"f":2},{"n":"charsWritten","p":655361,"f":2},{"n":"isFinalBlock","p":262145}],"n":"Encode","d":1281740,"h":42950954700,"f":1},{"r":18677761,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"bytesConsumed","p":655361,"f":2},{"n":"bytesWritten","p":655361,"f":2},{"n":"isFinalBlock","p":262145}],"n":"EncodeUtf8","d":1281740,"h":47245921996,"f":1},{"r":655361,"p":[{"n":"data","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"GetIndexOfFirstByteToEncode","d":1281740,"h":51540889292,"f":1},{"r":655361,"p":[{"n":"data","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h}],"n":"GetIndexOfFirstCharToEncode","d":1281740,"h":55835856588,"f":1},{"r":262145,"p":[{"n":"value","p":122748929}],"n":"IsScalarValueAllowed","d":1281740,"h":60130823884,"f":1},{"r":65537,"n":"_AssertThisNotNull","d":1281740,"h":64425791180,"f":2}],"l":[{"t":1347276,"n":"_asciiPreescapedData","d":1281740,"h":8591216332,"f":2},{"t":560844,"n":"_allowedBmpCodePoints","d":1281740,"h":12886183628,"f":2},{"t":1412812,"n":"_scalarEscaper","d":1281740,"h":17181150924,"f":2},{"t":$.$spc.System.Buffers.SearchValues$$($.$spc.System.Byte).$h,"n":"_allowedAsciiBytes","d":1281740,"h":21476118220,"f":2},{"t":$.$spc.System.Buffers.SearchValues$$($.$spc.System.Char).$h,"n":"_allowedAsciiChars","d":1281740,"h":25771085516,"f":2}],"c":[{"p":[{"n":"scalarEscaper","p":1412812},{"n":"allowedCodePointsBmp","p":560844,"f":8},{"n":"forbidHtmlSensitiveCharacters","p":262145,"f":65,"v":true},{"n":"extraCharactersToEscape","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h,"f":65}],"n":".ctor","o":"$ctor$1","d":1281740,"h":30066052812,"f":8}],"j":[1347276],"h":1281740}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Text.Encodings.Web.OptimizedInboxTextEncoder`; }
        });
        
        $asm.$cls("$stew.System.Text.Encodings.Web.TextEncoderSettings", ($self) => class TextEncoderSettings extends $.$spc.System.Object
        {
            /*AllowedBmpCodePointsBitmap*/ _allowedCodePointsBitmap;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*TextEncoderSettings*/ other)
            {
                super.$ctor();
                {
                    if (other === null)
                    {
                        $.$stew.System.Text.Encodings.Web.ThrowHelper.ThrowArgumentNullException(3/*ExceptionArgument.other*/);
                    }
                    this._allowedCodePointsBitmap = other.GetAllowedCodePointsBitmap().$v;
                }
                return this;
            }
            $ctor$3(/*params UnicodeRange[]*/ allowedRanges)
            {
                super.$ctor();
                {
                    if (allowedRanges === null)
                    {
                        $.$stew.System.Text.Encodings.Web.ThrowHelper.ThrowArgumentNullException(4/*ExceptionArgument.allowedRanges*/);
                    }
                    this.AllowRanges(allowedRanges);
                }
                return this;
            }
            /*void */ AllowCharacter(/*char*/ character)
            {
                this._allowedCodePointsBitmap.AllowChar(character);
            }
            /*void */ AllowCharacters(/*params char[]*/ characters)
            {
                if (characters === null)
                {
                    $.$stew.System.Text.Encodings.Web.ThrowHelper.ThrowArgumentNullException(5/*ExceptionArgument.characters*/);
                }
                for(/*int*/ let i = 0; i < characters.length; i++)
                {
                    this._allowedCodePointsBitmap.AllowChar($.$spc.System.Array.$ReadT1.call(characters, i));
                }
            }
            /*void */ AllowCodePoints(/*IEnumerable<int>*/ codePoints)
            {
                if (codePoints === null)
                {
                    $.$stew.System.Text.Encodings.Web.ThrowHelper.ThrowArgumentNullException(6/*ExceptionArgument.codePoints*/);
                }
                var $en2 = codePoints.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var allowedCodePoint = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if ($.$stew.System.Text.UnicodeUtility.IsBmpCodePoint((allowedCodePoint >>> 0)))
                        {
                            this._allowedCodePointsBitmap.AllowChar($.$cast(allowedCodePoint, $.$spc.System.Char));
                        }
                    }
                }
            }
            /*void */ AllowRange(/*UnicodeRange*/ range)
            {
                if (range === null)
                {
                    $.$stew.System.Text.Encodings.Web.ThrowHelper.ThrowArgumentNullException(7/*ExceptionArgument.range*/);
                }
                /*int*/ let firstCodePoint = range.FirstCodePoint;
                /*int*/ let rangeSize = range.Length;
                for(/*int*/ let i = 0; i < rangeSize; i++)
                {
                    /*int*/ let codePoint = ((firstCodePoint + i) | 0);
                    $.$stew.System.Text.UnicodeDebug.AssertIsBmpCodePoint((codePoint >>> 0));
                    this._allowedCodePointsBitmap.AllowChar($.$cast(codePoint, $.$spc.System.Char));
                }
            }
            /*void */ AllowRanges(/*params UnicodeRange[]*/ ranges)
            {
                if (ranges === null)
                {
                    $.$stew.System.Text.Encodings.Web.ThrowHelper.ThrowArgumentNullException(8/*ExceptionArgument.ranges*/);
                }
                for(/*int*/ let i = 0; i < ranges.length; i++)
                {
                    this.AllowRange($.$spc.System.Array.$ReadT1.call(ranges, i));
                }
            }
            /*void */ Clear()
            {
                this._allowedCodePointsBitmap = new $.$stew.System.Text.Encodings.Web.AllowedBmpCodePointsBitmap();
            }
            /*void */ ForbidCharacter(/*char*/ character)
            {
                this._allowedCodePointsBitmap.ForbidChar(character);
            }
            /*void */ ForbidCharacters(/*params char[]*/ characters)
            {
                if (characters === null)
                {
                    $.$stew.System.Text.Encodings.Web.ThrowHelper.ThrowArgumentNullException(5/*ExceptionArgument.characters*/);
                }
                for(/*int*/ let i = 0; i < characters.length; i++)
                {
                    this._allowedCodePointsBitmap.ForbidChar($.$spc.System.Array.$ReadT1.call(characters, i));
                }
            }
            /*void */ ForbidRange(/*UnicodeRange*/ range)
            {
                if (range === null)
                {
                    $.$stew.System.Text.Encodings.Web.ThrowHelper.ThrowArgumentNullException(7/*ExceptionArgument.range*/);
                }
                /*int*/ let firstCodePoint = range.FirstCodePoint;
                /*int*/ let rangeSize = range.Length;
                for(/*int*/ let i = 0; i < rangeSize; i++)
                {
                    /*int*/ let codePoint = ((firstCodePoint + i) | 0);
                    $.$stew.System.Text.UnicodeDebug.AssertIsBmpCodePoint((codePoint >>> 0));
                    this._allowedCodePointsBitmap.ForbidChar($.$cast(codePoint, $.$spc.System.Char));
                }
            }
            /*void */ ForbidRanges(/*params UnicodeRange[]*/ ranges)
            {
                if (ranges === null)
                {
                    $.$stew.System.Text.Encodings.Web.ThrowHelper.ThrowArgumentNullException(8/*ExceptionArgument.ranges*/);
                }
                for(/*int*/ let i = 0; i < ranges.length; i++)
                {
                    this.ForbidRange($.$spc.System.Array.$ReadT1.call(ranges, i));
                }
            }
            /*IEnumerable<int> */ GetAllowedCodePoints()
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    for(/*int*/ let i = 0; i <= /*\uFFFF*/ 65535; i++)
                    {
                        if (this._allowedCodePointsBitmap.IsCharAllowed($.$cast(i, $.$spc.System.Char)))
                        {
                            yield i;
                        }
                    }
                }.bind(this));
            }
            /*ref readonly AllowedBmpCodePointsBitmap */ GetAllowedCodePointsBitmap()
            {
                if ($.$spc.System.Type.op_Equality$1($.$spc.System.Object.GetType.call(this), $.$stew.System.Text.Encodings.Web.TextEncoderSettings.$type))
                {
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stew.System.Text.Encodings.Web.AllowedBmpCodePointsBitmap, () => this._allowedCodePointsBitmap, ($v) => this._allowedCodePointsBitmap = $v, null);
                }
                else 
                {
                    /*StrongBox<AllowedBmpCodePointsBitmap>*/ let newBitmap = new ($.$spc.System.Runtime.CompilerServices.StrongBox$$($.$stew.System.Text.Encodings.Web.AllowedBmpCodePointsBitmap))().$ctor$1();
                    var $en3 = this.GetAllowedCodePoints().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var allowedCodePoint = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if ((allowedCodePoint >>> 0) <= /*\uFFFF*/ 65535)
                            {
                                newBitmap.Value.AllowChar($.$cast(allowedCodePoint, $.$spc.System.Char));
                            }
                        }
                    }
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stew.System.Text.Encodings.Web.AllowedBmpCodePointsBitmap, () => newBitmap.Value, ($v) => newBitmap.Value = $v, null);
                }
            }
            //default member initializer
            constructor()
            {
                super();
                this._allowedCodePointsBitmap = $.$default($.$stew.System.Text.Encodings.Web.AllowedBmpCodePointsBitmap);
            }
            static $h = 1543884;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"character","p":458753}],"n":"AllowCharacter","d":1543884,"h":21476380364,"f":129},{"r":65537,"p":[{"n":"characters","p":0,"f":16}],"n":"AllowCharacters","d":1543884,"h":25771347660,"f":129},{"r":65537,"p":[{"n":"codePoints","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Int32).$h}],"n":"AllowCodePoints","d":1543884,"h":30066314956,"f":129},{"r":65537,"p":[{"n":"range","p":1806028}],"n":"AllowRange","d":1543884,"h":34361282252,"f":129},{"r":65537,"p":[{"n":"ranges","p":0,"f":16}],"n":"AllowRanges","d":1543884,"h":38656249548,"f":129},{"r":65537,"n":"Clear","d":1543884,"h":42951216844,"f":129},{"r":65537,"p":[{"n":"character","p":458753}],"n":"ForbidCharacter","d":1543884,"h":47246184140,"f":129},{"r":65537,"p":[{"n":"characters","p":0,"f":16}],"n":"ForbidCharacters","d":1543884,"h":51541151436,"f":129},{"r":65537,"p":[{"n":"range","p":1806028}],"n":"ForbidRange","d":1543884,"h":55836118732,"f":129},{"r":65537,"p":[{"n":"ranges","p":0,"f":16}],"n":"ForbidRanges","d":1543884,"h":60131086028,"f":129},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Int32).$h,"n":"GetAllowedCodePoints","d":1543884,"h":64426053324,"f":129},{"r":560844,"n":"GetAllowedCodePointsBitmap","d":1543884,"h":68721020620,"f":8}],"l":[{"t":560844,"n":"_allowedCodePointsBitmap","d":1543884,"h":4296511180,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":1543884,"h":8591478476,"f":1},{"p":[{"n":"other","p":1543884}],"n":".ctor","o":"$ctor$2","d":1543884,"h":12886445772,"f":1},{"p":[{"n":"allowedRanges","p":0,"f":16}],"n":".ctor","o":"$ctor$3","d":1543884,"h":17181413068,"f":1}],"h":1543884}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Text.Encodings.Web.TextEncoderSettings`; }
        });
        
        $asm.$cls("$stew.System.Text.Unicode.UnicodeHelpers", ($self) => class UnicodeHelpers
        {
            /*int*/ static UNICODE_LAST_CODEPOINT = 1114111;
            static /*ReadOnlySpan<byte> */ GetDefinedBmpCodePointsBitmapLittleEndian()
            {
                return $.$stew.System.Text.Unicode.UnicodeHelpers.DefinedCharsBitmapSpan;
            }
            static /*void */ GetUtf16SurrogatePairFromAstralScalarValue(/*uint*/ scalar, /*out char*/ highSurrogate, /*out char*/ lowSurrogate)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(65536 <= scalar && scalar <= 1114111/*UNICODE_LAST_CODEPOINT*/, "0x10000 <= scalar && scalar <= UNICODE_LAST_CODEPOINT");
                $.$stew.System.Text.UnicodeDebug.AssertIsValidSupplementaryPlaneScalar(scalar);
                highSurrogate.$v = $.$cast(((((scalar + (((((55296 - 64) >>> 0)) << 10) >>> 0)) >>> 0)) >>> 10), $.$spc.System.Char);
                lowSurrogate.$v = $.$cast(((((scalar & 1023) + 56320) >>> 0)), $.$spc.System.Char);
            }
            static /*int */ GetUtf8RepresentationForScalarValue(/*uint*/ scalar)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(scalar <= 1114111/*UNICODE_LAST_CODEPOINT*/, "scalar <= UNICODE_LAST_CODEPOINT");
                if (scalar <= 127)
                {
                    /*byte*/ let firstByte = $.$cast(scalar, $.$spc.System.Byte);
                    return firstByte;
                }
                else if (scalar <= 2047)
                {
                    /*byte*/ let firstByte = $.$cast((192 | (scalar >>> 6)), $.$spc.System.Byte);
                    /*byte*/ let secondByteByte = $.$cast((128 | (scalar & 63)), $.$spc.System.Byte);
                    return (((secondByteByte << 8) >>> 0) | firstByte);
                }
                else if (scalar <= 65535)
                {
                    /*byte*/ let firstByte = $.$cast((224 | (scalar >>> 12)), $.$spc.System.Byte);
                    /*byte*/ let secondByte = $.$cast((128 | ((scalar >>> 6) & 63)), $.$spc.System.Byte);
                    /*byte*/ let thirdByte = $.$cast((128 | (scalar & 63)), $.$spc.System.Byte);
                    return (((((thirdByte << 8) >>> 0) | secondByte) << 8) | firstByte);
                }
                else 
                {
                    /*byte*/ let firstByte = $.$cast((240 | (scalar >>> 18)), $.$spc.System.Byte);
                    /*byte*/ let secondByte = $.$cast((128 | ((scalar >>> 12) & 63)), $.$spc.System.Byte);
                    /*byte*/ let thirdByte = $.$cast((128 | ((scalar >>> 6) & 63)), $.$spc.System.Byte);
                    /*byte*/ let fourthByte = $.$cast((128 | (scalar & 63)), $.$spc.System.Byte);
                    return (((((((fourthByte << 8) >>> 0) | thirdByte) << 8) | secondByte) << 8) | firstByte);
                }
            }
            static /*bool */ IsSupplementaryCodePoint(/*int*/ scalar)
            {
                return ((scalar & ~(/*\uFFFF*/ 65535)) !== 0);
            }
            static /*ReadOnlySpan<byte> */ get DefinedCharsBitmapSpan()
            {
                return this.$cacheDefinedCharsBitmapSpan ??= new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$2([ 0, 0, 0, 0, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 127, 0, 0, 0, 0, 254, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 252, 240, 215, 255, 255, 251, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 254, 255, 255, 255, 127, 254, 255, 255, 255, 255, 255, 231, 254, 255, 255, 255, 255, 255, 255, 0, 255, 255, 255, 135, 31, 0, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 191, 255, 255, 255, 255, 255, 255, 255, 231, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 3, 0, 255, 255, 255, 255, 255, 255, 255, 231, 255, 255, 255, 255, 255, 63, 255, 127, 255, 255, 255, 79, 255, 7, 255, 255, 255, 127, 131, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 239, 159, 249, 255, 255, 253, 197, 243, 159, 121, 128, 176, 207, 255, 255, 127, 238, 135, 249, 255, 255, 253, 109, 211, 135, 57, 2, 94, 192, 255, 127, 0, 238, 191, 251, 255, 255, 253, 237, 243, 191, 59, 1, 0, 207, 255, 3, 254, 238, 159, 249, 255, 255, 253, 237, 243, 159, 57, 224, 176, 207, 255, 255, 0, 236, 199, 61, 214, 24, 199, 255, 195, 199, 61, 129, 0, 192, 255, 255, 7, 255, 223, 253, 255, 255, 253, 255, 243, 223, 61, 96, 39, 207, 255, 128, 255, 255, 223, 253, 255, 255, 253, 239, 243, 223, 61, 96, 96, 207, 255, 14, 0, 255, 223, 253, 255, 255, 255, 255, 255, 223, 253, 240, 255, 207, 255, 255, 255, 238, 255, 127, 252, 255, 255, 251, 47, 127, 132, 95, 255, 192, 255, 28, 0, 254, 255, 255, 255, 255, 255, 255, 135, 255, 255, 255, 15, 0, 0, 0, 0, 214, 247, 255, 255, 175, 255, 255, 63, 95, 127, 255, 243, 0, 0, 0, 0, 255, 255, 255, 255, 255, 255, 255, 255, 255, 254, 255, 255, 255, 31, 254, 255, 255, 255, 255, 254, 255, 255, 255, 223, 255, 223, 255, 7, 0, 0, 0, 0, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 191, 32, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 61, 127, 61, 255, 255, 255, 255, 255, 61, 255, 255, 255, 255, 61, 127, 61, 255, 127, 255, 255, 255, 255, 255, 255, 255, 61, 255, 255, 255, 255, 255, 255, 255, 255, 231, 255, 255, 255, 31, 255, 255, 255, 3, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 63, 63, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 254, 255, 255, 31, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 1, 255, 255, 63, 128, 255, 255, 127, 0, 255, 255, 15, 0, 255, 223, 13, 0, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 63, 255, 3, 255, 3, 255, 255, 255, 3, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 1, 255, 255, 255, 255, 255, 7, 255, 255, 255, 255, 255, 255, 255, 255, 63, 0, 255, 255, 255, 127, 255, 15, 255, 15, 241, 255, 255, 255, 255, 63, 31, 0, 255, 255, 255, 255, 255, 15, 255, 255, 255, 3, 255, 199, 255, 255, 255, 255, 255, 255, 255, 207, 255, 255, 255, 255, 255, 255, 255, 127, 255, 255, 255, 159, 255, 3, 255, 3, 255, 63, 255, 255, 255, 127, 0, 0, 0, 0, 0, 0, 255, 255, 255, 255, 255, 255, 255, 255, 255, 223, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 15, 240, 255, 255, 255, 255, 255, 255, 255, 248, 255, 227, 255, 255, 255, 255, 255, 255, 255, 7, 255, 255, 255, 255, 255, 231, 255, 0, 255, 255, 255, 255, 255, 7, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 63, 63, 255, 255, 255, 255, 63, 63, 255, 170, 255, 255, 255, 63, 255, 255, 255, 255, 255, 255, 223, 255, 223, 255, 207, 239, 255, 255, 220, 127, 0, 248, 255, 255, 255, 124, 255, 255, 255, 255, 255, 127, 223, 255, 243, 255, 255, 127, 255, 31, 255, 255, 255, 255, 1, 0, 255, 255, 255, 255, 1, 0, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 15, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 3, 0, 0, 255, 7, 0, 0, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 207, 255, 255, 255, 191, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 15, 254, 255, 255, 255, 255, 191, 32, 255, 255, 255, 255, 255, 255, 255, 128, 1, 128, 255, 255, 127, 0, 127, 127, 127, 127, 127, 127, 127, 127, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 63, 0, 0, 0, 0, 255, 255, 255, 251, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 15, 0, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 63, 0, 0, 0, 255, 255, 254, 255, 255, 255, 255, 255, 255, 255, 254, 255, 255, 255, 255, 255, 255, 255, 255, 255, 127, 254, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 224, 255, 255, 255, 255, 255, 254, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 127, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 63, 128, 255, 255, 255, 255, 255, 127, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 31, 255, 255, 255, 255, 255, 255, 127, 0, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 15, 0, 0, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 0, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 63, 235, 31, 0, 0, 252, 255, 255, 255, 255, 255, 255, 31, 255, 3, 255, 255, 255, 255, 255, 255, 255, 0, 255, 255, 255, 255, 255, 255, 255, 255, 63, 192, 255, 3, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 15, 128, 255, 255, 255, 31, 255, 255, 255, 255, 255, 255, 255, 255, 255, 191, 255, 195, 255, 255, 255, 127, 255, 255, 255, 255, 255, 255, 127, 0, 255, 63, 255, 243, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 7, 0, 0, 248, 255, 255, 127, 0, 126, 126, 126, 0, 127, 127, 255, 255, 255, 255, 255, 255, 255, 15, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 63, 255, 3, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 15, 0, 255, 255, 127, 248, 255, 255, 255, 255, 255, 15, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 63, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 3, 0, 0, 0, 0, 127, 0, 248, 224, 255, 255, 127, 95, 219, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 7, 0, 248, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 252, 255, 255, 255, 255, 255, 255, 128, 0, 0, 0, 0, 255, 255, 255, 255, 255, 3, 255, 255, 255, 255, 255, 255, 247, 255, 127, 15, 223, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 31, 254, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 127, 252, 252, 252, 28, 127, 127, 0, 62 ]);
            }
            static $h = 1740492;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":30066511564,"f":34},"n":"DefinedCharsBitmapSpan","d":1740492,"h":25771544268,"f":34}],"m":[{"r":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h,"n":"GetDefinedBmpCodePointsBitmapLittleEndian","d":1740492,"h":8591675084,"f":40},{"r":65537,"p":[{"n":"scalar","p":720897},{"n":"highSurrogate","p":458753,"f":2},{"n":"lowSurrogate","p":458753,"f":2}],"n":"GetUtf16SurrogatePairFromAstralScalarValue","d":1740492,"h":12886642380,"f":40},{"r":655361,"p":[{"n":"scalar","p":720897}],"n":"GetUtf8RepresentationForScalarValue","d":1740492,"h":17181609676,"f":40},{"r":262145,"p":[{"n":"scalar","p":655361}],"n":"IsSupplementaryCodePoint","d":1740492,"h":21476576972,"f":40}],"l":[{"t":655361,"n":"UNICODE_LAST_CODEPOINT","d":1740492,"h":4296707788,"f":40}],"h":1740492}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Text.Unicode.UnicodeHelpers`; }
        });
        
        $asm.$cls("$stew.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$stew.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("System.Text.Encodings.Web", $.$stew.System.SR.$type.Assembly);
                    $.$stew.System.SR.s_resourceManager = temp;
                }
                return $.$stew.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$stew.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$stew.System.SR.resourceCulture = value;
            }
            static /*string */ get ArgumentOutOfRange_IndexMustBeLess()
            {
                return "Index was out of range. Must be non-negative and less than the size of the collection.";
            }
            static /*string */ get Argument_CannotExtractScalar()
            {
                return "Cannot extract a Unicode scalar value from the specified index in the input.";
            }
            static /*string */ get Argument_DestinationTooShort()
            {
                return "Destination is too short.";
            }
            static /*string */ get Arg_MustBeRune()
            {
                return "Object must be of type Rune.";
            }
            static /*string */ get TextEncoderDoesNotImplementMaxOutputCharsPerInputChar()
            {
                return "TextEncoder does not implement MaxOutputCharsPerInputChar correctly.";
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$stew.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$stew.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$stew.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$stew.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$stew.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$stew.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$stew.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$stew.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$stew.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$stew.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$stew.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$stew.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$stew.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 495308;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":495308}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$stew.System.IO.TextWriterExtensions", ($self) => class TextWriterExtensions
        {
            static /*void */ WritePartialString(/*this TextWriter*/ writer, /*string*/ value, /*int*/ offset, /*int*/ count)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(writer !== null, "writer != null");
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.String.op_Inequality(value, null), "value != null");
                if (offset === 0 && count === value.length)
                {
                    writer.Write$12(value);
                }
                else 
                {
                    /*ReadOnlySpan<char>*/ let sliced = $.$spc.System.MemoryExtensions.AsSpan$7(value, offset, count);
                    writer.Write$3(sliced);
                }
            }
            static $h = 429772;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"writer","p":63045633},{"n":"value","p":1310721},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"WritePartialString","d":429772,"h":4295397068,"f":33}],"h":429772}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.TextWriterExtensions`; }
        });
        
        $asm.$cls("$stew.System.Text.Encodings.Web.ThrowHelper", ($self) => class ThrowHelper
        {
            static /*void */ ThrowArgumentNullException(/*ExceptionArgument*/ argument)
            {
                throw new $.$spc.System.ArgumentNullException().$ctor$16($.$stew.System.Text.Encodings.Web.ThrowHelper.GetArgumentName(argument));
            }
            static /*void */ ThrowArgumentOutOfRangeException(/*ExceptionArgument*/ argument)
            {
                throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16($.$stew.System.Text.Encodings.Web.ThrowHelper.GetArgumentName(argument));
            }
            static /*string */ GetArgumentName(/*ExceptionArgument*/ argument)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Enum.IsDefined$1($.$stew.System.Text.Encodings.Web.ExceptionArgument.$type, $.$box(argument, $.$stew.System.Text.Encodings.Web.ExceptionArgument)), "The enum value is not defined, please check the ExceptionArgument Enum.");
                return $.$spc.System.Enum.ToStringT($.$stew.System.Text.Encodings.Web.ExceptionArgument, $.$spc.System.UInt32, argument);
            }
            static $h = 1609420;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"argument","p":1085132}],"n":"ThrowArgumentNullException","d":1609420,"h":4296576716,"f":40},{"r":65537,"p":[{"n":"argument","p":1085132}],"n":"ThrowArgumentOutOfRangeException","d":1609420,"h":8591544012,"f":40},{"r":1310721,"p":[{"n":"argument","p":1085132}],"n":"GetArgumentName","d":1609420,"h":12886511308,"f":34}],"h":1609420}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Text.Encodings.Web.ThrowHelper`; }
        });
        
        $asm.$cls("$stew.System.Text.UnicodeDebug", ($self) => class UnicodeDebug
        {
            static /*void */ AssertIsBmpCodePoint(/*uint*/ codePoint)
            {
                if (!$.$stew.System.Text.UnicodeUtility.IsBmpCodePoint(codePoint))
                {
                    $.$spc.System.Diagnostics.Debug.Fail(`The value ${$.$stew.System.Text.UnicodeDebug.ToHexString(codePoint)} is not a valid BMP code point.`);
                }
            }
            static /*void */ AssertIsHighSurrogateCodePoint(/*uint*/ codePoint)
            {
                if (!$.$stew.System.Text.UnicodeUtility.IsHighSurrogateCodePoint(codePoint))
                {
                    $.$spc.System.Diagnostics.Debug.Fail(`The value ${$.$stew.System.Text.UnicodeDebug.ToHexString(codePoint)} is not a valid UTF-16 high surrogate code point.`);
                }
            }
            static /*void */ AssertIsLowSurrogateCodePoint(/*uint*/ codePoint)
            {
                if (!$.$stew.System.Text.UnicodeUtility.IsLowSurrogateCodePoint(codePoint))
                {
                    $.$spc.System.Diagnostics.Debug.Fail(`The value ${$.$stew.System.Text.UnicodeDebug.ToHexString(codePoint)} is not a valid UTF-16 low surrogate code point.`);
                }
            }
            static /*void */ AssertIsValidCodePoint(/*uint*/ codePoint)
            {
                if (!$.$stew.System.Text.UnicodeUtility.IsValidCodePoint(codePoint))
                {
                    $.$spc.System.Diagnostics.Debug.Fail(`The value ${$.$stew.System.Text.UnicodeDebug.ToHexString(codePoint)} is not a valid Unicode code point.`);
                }
            }
            static /*void */ AssertIsValidScalar(/*uint*/ scalarValue)
            {
                if (!$.$stew.System.Text.UnicodeUtility.IsValidUnicodeScalar(scalarValue))
                {
                    $.$spc.System.Diagnostics.Debug.Fail(`The value ${$.$stew.System.Text.UnicodeDebug.ToHexString(scalarValue)} is not a valid Unicode scalar value.`);
                }
            }
            static /*void */ AssertIsValidSupplementaryPlaneScalar(/*uint*/ scalarValue)
            {
                if (!$.$stew.System.Text.UnicodeUtility.IsValidUnicodeScalar(scalarValue) || $.$stew.System.Text.UnicodeUtility.IsBmpCodePoint(scalarValue))
                {
                    $.$spc.System.Diagnostics.Debug.Fail(`The value ${$.$stew.System.Text.UnicodeDebug.ToHexString(scalarValue)} is not a valid supplementary plane Unicode scalar value.`);
                }
            }
            static /*string */ ToHexString(/*uint*/ codePoint)
            {
                return $.$spc.System.FormattableString.Invariant((() =>
                {
                    var $handler = new $.$spc.System.Runtime.CompilerServices.DefaultInterpolatedStringHandler().$ctor$2(1, 1);
                    $handler.AppendLiteral("U+");
                    $handler.AppendFormatted$8($.$box(codePoint, $.$spc.System.UInt32), null, "X4");
                    return $handler.ToStringAndClear();
                })());
            }
            static $h = 1937100;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"codePoint","p":720897}],"n":"AssertIsBmpCodePoint","d":1937100,"h":4296904396,"f":40,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"DEBUG","t":1310721}]}]},{"r":65537,"p":[{"n":"codePoint","p":720897}],"n":"AssertIsHighSurrogateCodePoint","d":1937100,"h":8591871692,"f":40,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"DEBUG","t":1310721}]}]},{"r":65537,"p":[{"n":"codePoint","p":720897}],"n":"AssertIsLowSurrogateCodePoint","d":1937100,"h":12886838988,"f":40,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"DEBUG","t":1310721}]}]},{"r":65537,"p":[{"n":"codePoint","p":720897}],"n":"AssertIsValidCodePoint","d":1937100,"h":17181806284,"f":40,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"DEBUG","t":1310721}]}]},{"r":65537,"p":[{"n":"scalarValue","p":720897}],"n":"AssertIsValidScalar","d":1937100,"h":21476773580,"f":40,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"DEBUG","t":1310721}]}]},{"r":65537,"p":[{"n":"scalarValue","p":720897}],"n":"AssertIsValidSupplementaryPlaneScalar","d":1937100,"h":25771740876,"f":40,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"DEBUG","t":1310721}]}]},{"r":1310721,"p":[{"n":"codePoint","p":720897}],"n":"ToHexString","d":1937100,"h":30066708172,"f":34}],"h":1937100}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Text.UnicodeDebug`; }
        });
        
        $asm.$cls("$stew.System.Text.Unicode.UnicodeRange", ($self) => class UnicodeRange extends $.$spc.System.Object
        {
            $ctor$1(/*int*/ firstCodePoint, /*int*/ length)
            {
                super.$ctor();
                {
                    if (firstCodePoint < 0 || firstCodePoint > 65535)
                    {
                        throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("firstCodePoint");
                    }
                    if (length < 0 || ($.$cast(firstCodePoint, $.$spc.System.Int64) + $.$cast(length, $.$spc.System.Int64) > 65536n))
                    {
                        throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("length");
                    }
                    this.FirstCodePoint = firstCodePoint;
                    this.Length = length;
                }
                return this;
            }
            /*int*/ FirstCodePoint = 0;
            /*int*/ Length = 0;
            static /*UnicodeRange */ Create(/*char*/ firstCharacter, /*char*/ lastCharacter)
            {
                if (lastCharacter < firstCharacter)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("lastCharacter");
                }
                return new $.$stew.System.Text.Unicode.UnicodeRange().$ctor$1(firstCharacter, ((1 + (lastCharacter - firstCharacter)) | 0));
            }
            static $h = 1806028;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":17181675212,"f":1},"n":"FirstCodePoint","d":1806028,"h":12886707916,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":30066577100,"f":1},"n":"Length","d":1806028,"h":25771609804,"f":1}],"m":[{"r":1806028,"p":[{"n":"firstCharacter","p":458753},{"n":"lastCharacter","p":458753}],"n":"Create","d":1806028,"h":34361544396,"f":33}],"c":[{"p":[{"n":"firstCodePoint","p":655361},{"n":"length","p":655361}],"n":".ctor","o":"$ctor$1","d":1806028,"h":4296773324,"f":1}],"h":1806028}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Text.Unicode.UnicodeRange`; }
        });
        
        $asm.$cls("$stew.System.Text.UnicodeUtility", ($self) => class UnicodeUtility
        {
            /*uint*/ static ReplacementChar = 65533;
            static /*int */ GetPlane(/*uint*/ codePoint)
            {
                $.$stew.System.Text.UnicodeDebug.AssertIsValidCodePoint(codePoint);
                return ((codePoint >>> 16) | 0);
            }
            static /*uint */ GetScalarFromUtf16SurrogatePair(/*uint*/ highSurrogateCodePoint, /*uint*/ lowSurrogateCodePoint)
            {
                $.$stew.System.Text.UnicodeDebug.AssertIsHighSurrogateCodePoint(highSurrogateCodePoint);
                $.$stew.System.Text.UnicodeDebug.AssertIsLowSurrogateCodePoint(lowSurrogateCodePoint);
                return ((((((highSurrogateCodePoint << 10) >>> 0) + lowSurrogateCodePoint) >>> 0) - (((((55296 << 10) >>> 0) + 56320) >>> 0) - (1 << 16))) >>> 0);
            }
            static /*int */ GetUtf16SequenceLength(/*uint*/ value)
            {
                $.$stew.System.Text.UnicodeDebug.AssertIsValidScalar(value);
                value -= 65536;
                value += (2 << 24);
                value >>= 24;
                return (value | 0);
            }
            static /*void */ GetUtf16SurrogatesFromSupplementaryPlaneScalar(/*uint*/ value, /*out char*/ highSurrogateCodePoint, /*out char*/ lowSurrogateCodePoint)
            {
                $.$stew.System.Text.UnicodeDebug.AssertIsValidSupplementaryPlaneScalar(value);
                highSurrogateCodePoint.$v = $.$cast(((((value + (((((55296 - 64) >>> 0)) << 10) >>> 0)) >>> 0)) >>> 10), $.$spc.System.Char);
                lowSurrogateCodePoint.$v = $.$cast(((((value & 1023) + 56320) >>> 0)), $.$spc.System.Char);
            }
            static /*int */ GetUtf8SequenceLength(/*uint*/ value)
            {
                $.$stew.System.Text.UnicodeDebug.AssertIsValidScalar(value);
                /*int*/ let a = ((((value | 0) - 2048) | 0)) >> 31;
                value ^= 63488;
                value -= 63616;
                value += (4 << 24);
                value >>= 24;
                return (((value | 0) + (((a * 2) | 0))) | 0);
            }
            static /*bool */ IsAsciiCodePoint(/*uint*/ value)
            {
                return value <= 127;
            }
            static /*bool */ IsBmpCodePoint(/*uint*/ value)
            {
                return value <= 65535;
            }
            static /*bool */ IsHighSurrogateCodePoint(/*uint*/ value)
            {
                return $.$stew.System.Text.UnicodeUtility.IsInRangeInclusive(value, 55296, 56319);
            }
            static /*bool */ IsInRangeInclusive(/*uint*/ value, /*uint*/ lowerBound, /*uint*/ upperBound)
            {
                return ((((value - lowerBound) >>> 0)) >>> 0) <= ((((upperBound - lowerBound) >>> 0)) >>> 0);
            }
            static /*bool */ IsLowSurrogateCodePoint(/*uint*/ value)
            {
                return $.$stew.System.Text.UnicodeUtility.IsInRangeInclusive(value, 56320, 57343);
            }
            static /*bool */ IsSurrogateCodePoint(/*uint*/ value)
            {
                return $.$stew.System.Text.UnicodeUtility.IsInRangeInclusive(value, 55296, 57343);
            }
            static /*bool */ IsValidCodePoint(/*uint*/ codePoint)
            {
                return codePoint <= 1114111;
            }
            static /*bool */ IsValidUnicodeScalar(/*uint*/ value)
            {
                return (((((value - 1114112) >>> 0)) ^ 55296) >>> 0) >= 4293855232;
            }
            static $h = 2002636;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":655361,"p":[{"n":"codePoint","p":720897}],"n":"GetPlane","d":2002636,"h":8591937228,"f":33},{"r":720897,"p":[{"n":"highSurrogateCodePoint","p":720897},{"n":"lowSurrogateCodePoint","p":720897}],"n":"GetScalarFromUtf16SurrogatePair","d":2002636,"h":12886904524,"f":33},{"r":655361,"p":[{"n":"value","p":720897}],"n":"GetUtf16SequenceLength","d":2002636,"h":17181871820,"f":33},{"r":65537,"p":[{"n":"value","p":720897},{"n":"highSurrogateCodePoint","p":458753,"f":2},{"n":"lowSurrogateCodePoint","p":458753,"f":2}],"n":"GetUtf16SurrogatesFromSupplementaryPlaneScalar","d":2002636,"h":21476839116,"f":33},{"r":655361,"p":[{"n":"value","p":720897}],"n":"GetUtf8SequenceLength","d":2002636,"h":25771806412,"f":33},{"r":262145,"p":[{"n":"value","p":720897}],"n":"IsAsciiCodePoint","d":2002636,"h":30066773708,"f":33},{"r":262145,"p":[{"n":"value","p":720897}],"n":"IsBmpCodePoint","d":2002636,"h":34361741004,"f":33},{"r":262145,"p":[{"n":"value","p":720897}],"n":"IsHighSurrogateCodePoint","d":2002636,"h":38656708300,"f":33},{"r":262145,"p":[{"n":"value","p":720897},{"n":"lowerBound","p":720897},{"n":"upperBound","p":720897}],"n":"IsInRangeInclusive","d":2002636,"h":42951675596,"f":33},{"r":262145,"p":[{"n":"value","p":720897}],"n":"IsLowSurrogateCodePoint","d":2002636,"h":47246642892,"f":33},{"r":262145,"p":[{"n":"value","p":720897}],"n":"IsSurrogateCodePoint","d":2002636,"h":51541610188,"f":33},{"r":262145,"p":[{"n":"codePoint","p":720897}],"n":"IsValidCodePoint","d":2002636,"h":55836577484,"f":33},{"r":262145,"p":[{"n":"value","p":720897}],"n":"IsValidUnicodeScalar","d":2002636,"h":60131544780,"f":33}],"l":[{"t":720897,"n":"ReplacementChar","d":2002636,"h":4296969932,"f":33}],"h":2002636}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Text.UnicodeUtility`; }
        });
        
        $asm.$cls("$stew.System.Text.Unicode.UnicodeRanges", ($self) => class UnicodeRanges
        {
            static /*UnicodeRange */ get None()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._none ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateEmptyRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._none, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._none = $v, $.$stew.System.Text.Unicode.UnicodeRange));
            }
            /*UnicodeRange?*/ static _none = null;
            static /*UnicodeRange */ get All()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._all ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._all, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._all = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0000*/ 0, /*\uFFFF*/ 65535);
            }
            /*UnicodeRange?*/ static _all = null;
            static /*UnicodeRange */ CreateEmptyRange(/*ref UnicodeRange?*/ range)
            {
                range.$v = new $.$stew.System.Text.Unicode.UnicodeRange().$ctor$1(0, 0);
                return range.$v;
            }
            static /*UnicodeRange */ CreateRange(/*ref UnicodeRange?*/ range, /*char*/ first, /*char*/ last)
            {
                range.$v = $.$stew.System.Text.Unicode.UnicodeRange.Create(first, last);
                return range.$v;
            }
            static /*UnicodeRange */ get BasicLatin()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0000 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0000, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0000 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0000*/ 0, /*\u007F*/ 127);
            }
            /*UnicodeRange?*/ static _u0000 = null;
            static /*UnicodeRange */ get Latin1Supplement()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0080 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0080, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0080 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0080*/ 128, /*\u00FF*/ 255);
            }
            /*UnicodeRange?*/ static _u0080 = null;
            static /*UnicodeRange */ get LatinExtendedA()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0100 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0100, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0100 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0100*/ 256, /*\u017F*/ 383);
            }
            /*UnicodeRange?*/ static _u0100 = null;
            static /*UnicodeRange */ get LatinExtendedB()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0180 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0180, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0180 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0180*/ 384, /*\u024F*/ 591);
            }
            /*UnicodeRange?*/ static _u0180 = null;
            static /*UnicodeRange */ get IpaExtensions()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0250 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0250, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0250 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0250*/ 592, /*\u02AF*/ 687);
            }
            /*UnicodeRange?*/ static _u0250 = null;
            static /*UnicodeRange */ get SpacingModifierLetters()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u02B0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u02B0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u02B0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u02B0*/ 688, /*\u02FF*/ 767);
            }
            /*UnicodeRange?*/ static _u02B0 = null;
            static /*UnicodeRange */ get CombiningDiacriticalMarks()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0300 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0300, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0300 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0300*/ 768, /*\u036F*/ 879);
            }
            /*UnicodeRange?*/ static _u0300 = null;
            static /*UnicodeRange */ get GreekandCoptic()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0370 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0370, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0370 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0370*/ 880, /*\u03FF*/ 1023);
            }
            /*UnicodeRange?*/ static _u0370 = null;
            static /*UnicodeRange */ get Cyrillic()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0400 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0400, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0400 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0400*/ 1024, /*\u04FF*/ 1279);
            }
            /*UnicodeRange?*/ static _u0400 = null;
            static /*UnicodeRange */ get CyrillicSupplement()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0500 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0500, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0500 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0500*/ 1280, /*\u052F*/ 1327);
            }
            /*UnicodeRange?*/ static _u0500 = null;
            static /*UnicodeRange */ get Armenian()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0530 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0530, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0530 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0530*/ 1328, /*\u058F*/ 1423);
            }
            /*UnicodeRange?*/ static _u0530 = null;
            static /*UnicodeRange */ get Hebrew()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0590 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0590, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0590 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0590*/ 1424, /*\u05FF*/ 1535);
            }
            /*UnicodeRange?*/ static _u0590 = null;
            static /*UnicodeRange */ get Arabic()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0600 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0600, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0600 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0600*/ 1536, /*\u06FF*/ 1791);
            }
            /*UnicodeRange?*/ static _u0600 = null;
            static /*UnicodeRange */ get Syriac()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0700 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0700, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0700 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0700*/ 1792, /*\u074F*/ 1871);
            }
            /*UnicodeRange?*/ static _u0700 = null;
            static /*UnicodeRange */ get ArabicSupplement()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0750 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0750, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0750 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0750*/ 1872, /*\u077F*/ 1919);
            }
            /*UnicodeRange?*/ static _u0750 = null;
            static /*UnicodeRange */ get Thaana()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0780 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0780, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0780 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0780*/ 1920, /*\u07BF*/ 1983);
            }
            /*UnicodeRange?*/ static _u0780 = null;
            static /*UnicodeRange */ get NKo()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u07C0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u07C0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u07C0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u07C0*/ 1984, /*\u07FF*/ 2047);
            }
            /*UnicodeRange?*/ static _u07C0 = null;
            static /*UnicodeRange */ get Samaritan()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0800 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0800, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0800 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0800*/ 2048, /*\u083F*/ 2111);
            }
            /*UnicodeRange?*/ static _u0800 = null;
            static /*UnicodeRange */ get Mandaic()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0840 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0840, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0840 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0840*/ 2112, /*\u085F*/ 2143);
            }
            /*UnicodeRange?*/ static _u0840 = null;
            static /*UnicodeRange */ get SyriacSupplement()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0860 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0860, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0860 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0860*/ 2144, /*\u086F*/ 2159);
            }
            /*UnicodeRange?*/ static _u0860 = null;
            static /*UnicodeRange */ get ArabicExtendedB()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0870 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0870, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0870 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0870*/ 2160, /*\u089F*/ 2207);
            }
            /*UnicodeRange?*/ static _u0870 = null;
            static /*UnicodeRange */ get ArabicExtendedA()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u08A0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u08A0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u08A0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u08A0*/ 2208, /*\u08FF*/ 2303);
            }
            /*UnicodeRange?*/ static _u08A0 = null;
            static /*UnicodeRange */ get Devanagari()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0900 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0900, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0900 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0900*/ 2304, /*\u097F*/ 2431);
            }
            /*UnicodeRange?*/ static _u0900 = null;
            static /*UnicodeRange */ get Bengali()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0980 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0980, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0980 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0980*/ 2432, /*\u09FF*/ 2559);
            }
            /*UnicodeRange?*/ static _u0980 = null;
            static /*UnicodeRange */ get Gurmukhi()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0A00 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0A00, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0A00 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0A00*/ 2560, /*\u0A7F*/ 2687);
            }
            /*UnicodeRange?*/ static _u0A00 = null;
            static /*UnicodeRange */ get Gujarati()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0A80 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0A80, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0A80 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0A80*/ 2688, /*\u0AFF*/ 2815);
            }
            /*UnicodeRange?*/ static _u0A80 = null;
            static /*UnicodeRange */ get Oriya()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0B00 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0B00, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0B00 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0B00*/ 2816, /*\u0B7F*/ 2943);
            }
            /*UnicodeRange?*/ static _u0B00 = null;
            static /*UnicodeRange */ get Tamil()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0B80 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0B80, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0B80 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0B80*/ 2944, /*\u0BFF*/ 3071);
            }
            /*UnicodeRange?*/ static _u0B80 = null;
            static /*UnicodeRange */ get Telugu()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0C00 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0C00, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0C00 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0C00*/ 3072, /*\u0C7F*/ 3199);
            }
            /*UnicodeRange?*/ static _u0C00 = null;
            static /*UnicodeRange */ get Kannada()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0C80 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0C80, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0C80 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0C80*/ 3200, /*\u0CFF*/ 3327);
            }
            /*UnicodeRange?*/ static _u0C80 = null;
            static /*UnicodeRange */ get Malayalam()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0D00 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0D00, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0D00 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0D00*/ 3328, /*\u0D7F*/ 3455);
            }
            /*UnicodeRange?*/ static _u0D00 = null;
            static /*UnicodeRange */ get Sinhala()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0D80 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0D80, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0D80 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0D80*/ 3456, /*\u0DFF*/ 3583);
            }
            /*UnicodeRange?*/ static _u0D80 = null;
            static /*UnicodeRange */ get Thai()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0E00 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0E00, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0E00 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0E00*/ 3584, /*\u0E7F*/ 3711);
            }
            /*UnicodeRange?*/ static _u0E00 = null;
            static /*UnicodeRange */ get Lao()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0E80 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0E80, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0E80 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0E80*/ 3712, /*\u0EFF*/ 3839);
            }
            /*UnicodeRange?*/ static _u0E80 = null;
            static /*UnicodeRange */ get Tibetan()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u0F00 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u0F00, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u0F00 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u0F00*/ 3840, /*\u0FFF*/ 4095);
            }
            /*UnicodeRange?*/ static _u0F00 = null;
            static /*UnicodeRange */ get Myanmar()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1000 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1000, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1000 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1000*/ 4096, /*\u109F*/ 4255);
            }
            /*UnicodeRange?*/ static _u1000 = null;
            static /*UnicodeRange */ get Georgian()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u10A0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u10A0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u10A0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u10A0*/ 4256, /*\u10FF*/ 4351);
            }
            /*UnicodeRange?*/ static _u10A0 = null;
            static /*UnicodeRange */ get HangulJamo()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1100 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1100, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1100 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1100*/ 4352, /*\u11FF*/ 4607);
            }
            /*UnicodeRange?*/ static _u1100 = null;
            static /*UnicodeRange */ get Ethiopic()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1200 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1200, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1200 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1200*/ 4608, /*\u137F*/ 4991);
            }
            /*UnicodeRange?*/ static _u1200 = null;
            static /*UnicodeRange */ get EthiopicSupplement()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1380 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1380, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1380 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1380*/ 4992, /*\u139F*/ 5023);
            }
            /*UnicodeRange?*/ static _u1380 = null;
            static /*UnicodeRange */ get Cherokee()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u13A0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u13A0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u13A0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u13A0*/ 5024, /*\u13FF*/ 5119);
            }
            /*UnicodeRange?*/ static _u13A0 = null;
            static /*UnicodeRange */ get UnifiedCanadianAboriginalSyllabics()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1400 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1400, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1400 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1400*/ 5120, /*\u167F*/ 5759);
            }
            /*UnicodeRange?*/ static _u1400 = null;
            static /*UnicodeRange */ get Ogham()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1680 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1680, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1680 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1680*/ 5760, /*\u169F*/ 5791);
            }
            /*UnicodeRange?*/ static _u1680 = null;
            static /*UnicodeRange */ get Runic()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u16A0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u16A0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u16A0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u16A0*/ 5792, /*\u16FF*/ 5887);
            }
            /*UnicodeRange?*/ static _u16A0 = null;
            static /*UnicodeRange */ get Tagalog()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1700 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1700, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1700 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1700*/ 5888, /*\u171F*/ 5919);
            }
            /*UnicodeRange?*/ static _u1700 = null;
            static /*UnicodeRange */ get Hanunoo()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1720 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1720, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1720 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1720*/ 5920, /*\u173F*/ 5951);
            }
            /*UnicodeRange?*/ static _u1720 = null;
            static /*UnicodeRange */ get Buhid()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1740 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1740, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1740 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1740*/ 5952, /*\u175F*/ 5983);
            }
            /*UnicodeRange?*/ static _u1740 = null;
            static /*UnicodeRange */ get Tagbanwa()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1760 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1760, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1760 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1760*/ 5984, /*\u177F*/ 6015);
            }
            /*UnicodeRange?*/ static _u1760 = null;
            static /*UnicodeRange */ get Khmer()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1780 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1780, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1780 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1780*/ 6016, /*\u17FF*/ 6143);
            }
            /*UnicodeRange?*/ static _u1780 = null;
            static /*UnicodeRange */ get Mongolian()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1800 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1800, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1800 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1800*/ 6144, /*\u18AF*/ 6319);
            }
            /*UnicodeRange?*/ static _u1800 = null;
            static /*UnicodeRange */ get UnifiedCanadianAboriginalSyllabicsExtended()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u18B0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u18B0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u18B0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u18B0*/ 6320, /*\u18FF*/ 6399);
            }
            /*UnicodeRange?*/ static _u18B0 = null;
            static /*UnicodeRange */ get Limbu()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1900 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1900, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1900 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1900*/ 6400, /*\u194F*/ 6479);
            }
            /*UnicodeRange?*/ static _u1900 = null;
            static /*UnicodeRange */ get TaiLe()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1950 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1950, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1950 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1950*/ 6480, /*\u197F*/ 6527);
            }
            /*UnicodeRange?*/ static _u1950 = null;
            static /*UnicodeRange */ get NewTaiLue()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1980 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1980, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1980 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1980*/ 6528, /*\u19DF*/ 6623);
            }
            /*UnicodeRange?*/ static _u1980 = null;
            static /*UnicodeRange */ get KhmerSymbols()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u19E0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u19E0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u19E0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u19E0*/ 6624, /*\u19FF*/ 6655);
            }
            /*UnicodeRange?*/ static _u19E0 = null;
            static /*UnicodeRange */ get Buginese()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1A00 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1A00, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1A00 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1A00*/ 6656, /*\u1A1F*/ 6687);
            }
            /*UnicodeRange?*/ static _u1A00 = null;
            static /*UnicodeRange */ get TaiTham()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1A20 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1A20, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1A20 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1A20*/ 6688, /*\u1AAF*/ 6831);
            }
            /*UnicodeRange?*/ static _u1A20 = null;
            static /*UnicodeRange */ get CombiningDiacriticalMarksExtended()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1AB0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1AB0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1AB0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1AB0*/ 6832, /*\u1AFF*/ 6911);
            }
            /*UnicodeRange?*/ static _u1AB0 = null;
            static /*UnicodeRange */ get Balinese()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1B00 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1B00, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1B00 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1B00*/ 6912, /*\u1B7F*/ 7039);
            }
            /*UnicodeRange?*/ static _u1B00 = null;
            static /*UnicodeRange */ get Sundanese()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1B80 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1B80, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1B80 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1B80*/ 7040, /*\u1BBF*/ 7103);
            }
            /*UnicodeRange?*/ static _u1B80 = null;
            static /*UnicodeRange */ get Batak()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1BC0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1BC0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1BC0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1BC0*/ 7104, /*\u1BFF*/ 7167);
            }
            /*UnicodeRange?*/ static _u1BC0 = null;
            static /*UnicodeRange */ get Lepcha()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1C00 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1C00, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1C00 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1C00*/ 7168, /*\u1C4F*/ 7247);
            }
            /*UnicodeRange?*/ static _u1C00 = null;
            static /*UnicodeRange */ get OlChiki()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1C50 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1C50, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1C50 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1C50*/ 7248, /*\u1C7F*/ 7295);
            }
            /*UnicodeRange?*/ static _u1C50 = null;
            static /*UnicodeRange */ get CyrillicExtendedC()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1C80 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1C80, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1C80 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1C80*/ 7296, /*\u1C8F*/ 7311);
            }
            /*UnicodeRange?*/ static _u1C80 = null;
            static /*UnicodeRange */ get GeorgianExtended()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1C90 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1C90, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1C90 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1C90*/ 7312, /*\u1CBF*/ 7359);
            }
            /*UnicodeRange?*/ static _u1C90 = null;
            static /*UnicodeRange */ get SundaneseSupplement()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1CC0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1CC0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1CC0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1CC0*/ 7360, /*\u1CCF*/ 7375);
            }
            /*UnicodeRange?*/ static _u1CC0 = null;
            static /*UnicodeRange */ get VedicExtensions()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1CD0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1CD0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1CD0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1CD0*/ 7376, /*\u1CFF*/ 7423);
            }
            /*UnicodeRange?*/ static _u1CD0 = null;
            static /*UnicodeRange */ get PhoneticExtensions()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1D00 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1D00, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1D00 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1D00*/ 7424, /*\u1D7F*/ 7551);
            }
            /*UnicodeRange?*/ static _u1D00 = null;
            static /*UnicodeRange */ get PhoneticExtensionsSupplement()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1D80 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1D80, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1D80 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1D80*/ 7552, /*\u1DBF*/ 7615);
            }
            /*UnicodeRange?*/ static _u1D80 = null;
            static /*UnicodeRange */ get CombiningDiacriticalMarksSupplement()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1DC0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1DC0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1DC0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1DC0*/ 7616, /*\u1DFF*/ 7679);
            }
            /*UnicodeRange?*/ static _u1DC0 = null;
            static /*UnicodeRange */ get LatinExtendedAdditional()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1E00 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1E00, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1E00 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1E00*/ 7680, /*\u1EFF*/ 7935);
            }
            /*UnicodeRange?*/ static _u1E00 = null;
            static /*UnicodeRange */ get GreekExtended()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u1F00 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u1F00, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u1F00 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u1F00*/ 7936, /*\u1FFF*/ 8191);
            }
            /*UnicodeRange?*/ static _u1F00 = null;
            static /*UnicodeRange */ get GeneralPunctuation()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u2000 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u2000, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u2000 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u2000*/ 8192, /*\u206F*/ 8303);
            }
            /*UnicodeRange?*/ static _u2000 = null;
            static /*UnicodeRange */ get SuperscriptsandSubscripts()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u2070 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u2070, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u2070 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u2070*/ 8304, /*\u209F*/ 8351);
            }
            /*UnicodeRange?*/ static _u2070 = null;
            static /*UnicodeRange */ get CurrencySymbols()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u20A0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u20A0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u20A0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u20A0*/ 8352, /*\u20CF*/ 8399);
            }
            /*UnicodeRange?*/ static _u20A0 = null;
            static /*UnicodeRange */ get CombiningDiacriticalMarksforSymbols()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u20D0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u20D0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u20D0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u20D0*/ 8400, /*\u20FF*/ 8447);
            }
            /*UnicodeRange?*/ static _u20D0 = null;
            static /*UnicodeRange */ get LetterlikeSymbols()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u2100 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u2100, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u2100 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u2100*/ 8448, /*\u214F*/ 8527);
            }
            /*UnicodeRange?*/ static _u2100 = null;
            static /*UnicodeRange */ get NumberForms()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u2150 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u2150, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u2150 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u2150*/ 8528, /*\u218F*/ 8591);
            }
            /*UnicodeRange?*/ static _u2150 = null;
            static /*UnicodeRange */ get Arrows()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u2190 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u2190, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u2190 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u2190*/ 8592, /*\u21FF*/ 8703);
            }
            /*UnicodeRange?*/ static _u2190 = null;
            static /*UnicodeRange */ get MathematicalOperators()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u2200 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u2200, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u2200 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u2200*/ 8704, /*\u22FF*/ 8959);
            }
            /*UnicodeRange?*/ static _u2200 = null;
            static /*UnicodeRange */ get MiscellaneousTechnical()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u2300 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u2300, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u2300 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u2300*/ 8960, /*\u23FF*/ 9215);
            }
            /*UnicodeRange?*/ static _u2300 = null;
            static /*UnicodeRange */ get ControlPictures()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u2400 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u2400, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u2400 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u2400*/ 9216, /*\u243F*/ 9279);
            }
            /*UnicodeRange?*/ static _u2400 = null;
            static /*UnicodeRange */ get OpticalCharacterRecognition()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u2440 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u2440, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u2440 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u2440*/ 9280, /*\u245F*/ 9311);
            }
            /*UnicodeRange?*/ static _u2440 = null;
            static /*UnicodeRange */ get EnclosedAlphanumerics()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u2460 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u2460, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u2460 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u2460*/ 9312, /*\u24FF*/ 9471);
            }
            /*UnicodeRange?*/ static _u2460 = null;
            static /*UnicodeRange */ get BoxDrawing()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u2500 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u2500, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u2500 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u2500*/ 9472, /*\u257F*/ 9599);
            }
            /*UnicodeRange?*/ static _u2500 = null;
            static /*UnicodeRange */ get BlockElements()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u2580 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u2580, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u2580 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u2580*/ 9600, /*\u259F*/ 9631);
            }
            /*UnicodeRange?*/ static _u2580 = null;
            static /*UnicodeRange */ get GeometricShapes()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u25A0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u25A0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u25A0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u25A0*/ 9632, /*\u25FF*/ 9727);
            }
            /*UnicodeRange?*/ static _u25A0 = null;
            static /*UnicodeRange */ get MiscellaneousSymbols()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u2600 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u2600, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u2600 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u2600*/ 9728, /*\u26FF*/ 9983);
            }
            /*UnicodeRange?*/ static _u2600 = null;
            static /*UnicodeRange */ get Dingbats()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u2700 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u2700, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u2700 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u2700*/ 9984, /*\u27BF*/ 10175);
            }
            /*UnicodeRange?*/ static _u2700 = null;
            static /*UnicodeRange */ get MiscellaneousMathematicalSymbolsA()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u27C0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u27C0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u27C0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u27C0*/ 10176, /*\u27EF*/ 10223);
            }
            /*UnicodeRange?*/ static _u27C0 = null;
            static /*UnicodeRange */ get SupplementalArrowsA()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u27F0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u27F0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u27F0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u27F0*/ 10224, /*\u27FF*/ 10239);
            }
            /*UnicodeRange?*/ static _u27F0 = null;
            static /*UnicodeRange */ get BraillePatterns()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u2800 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u2800, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u2800 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u2800*/ 10240, /*\u28FF*/ 10495);
            }
            /*UnicodeRange?*/ static _u2800 = null;
            static /*UnicodeRange */ get SupplementalArrowsB()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u2900 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u2900, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u2900 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u2900*/ 10496, /*\u297F*/ 10623);
            }
            /*UnicodeRange?*/ static _u2900 = null;
            static /*UnicodeRange */ get MiscellaneousMathematicalSymbolsB()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u2980 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u2980, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u2980 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u2980*/ 10624, /*\u29FF*/ 10751);
            }
            /*UnicodeRange?*/ static _u2980 = null;
            static /*UnicodeRange */ get SupplementalMathematicalOperators()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u2A00 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u2A00, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u2A00 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u2A00*/ 10752, /*\u2AFF*/ 11007);
            }
            /*UnicodeRange?*/ static _u2A00 = null;
            static /*UnicodeRange */ get MiscellaneousSymbolsandArrows()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u2B00 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u2B00, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u2B00 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u2B00*/ 11008, /*\u2BFF*/ 11263);
            }
            /*UnicodeRange?*/ static _u2B00 = null;
            static /*UnicodeRange */ get Glagolitic()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u2C00 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u2C00, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u2C00 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u2C00*/ 11264, /*\u2C5F*/ 11359);
            }
            /*UnicodeRange?*/ static _u2C00 = null;
            static /*UnicodeRange */ get LatinExtendedC()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u2C60 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u2C60, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u2C60 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u2C60*/ 11360, /*\u2C7F*/ 11391);
            }
            /*UnicodeRange?*/ static _u2C60 = null;
            static /*UnicodeRange */ get Coptic()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u2C80 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u2C80, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u2C80 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u2C80*/ 11392, /*\u2CFF*/ 11519);
            }
            /*UnicodeRange?*/ static _u2C80 = null;
            static /*UnicodeRange */ get GeorgianSupplement()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u2D00 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u2D00, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u2D00 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u2D00*/ 11520, /*\u2D2F*/ 11567);
            }
            /*UnicodeRange?*/ static _u2D00 = null;
            static /*UnicodeRange */ get Tifinagh()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u2D30 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u2D30, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u2D30 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u2D30*/ 11568, /*\u2D7F*/ 11647);
            }
            /*UnicodeRange?*/ static _u2D30 = null;
            static /*UnicodeRange */ get EthiopicExtended()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u2D80 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u2D80, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u2D80 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u2D80*/ 11648, /*\u2DDF*/ 11743);
            }
            /*UnicodeRange?*/ static _u2D80 = null;
            static /*UnicodeRange */ get CyrillicExtendedA()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u2DE0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u2DE0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u2DE0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u2DE0*/ 11744, /*\u2DFF*/ 11775);
            }
            /*UnicodeRange?*/ static _u2DE0 = null;
            static /*UnicodeRange */ get SupplementalPunctuation()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u2E00 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u2E00, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u2E00 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u2E00*/ 11776, /*\u2E7F*/ 11903);
            }
            /*UnicodeRange?*/ static _u2E00 = null;
            static /*UnicodeRange */ get CjkRadicalsSupplement()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u2E80 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u2E80, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u2E80 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u2E80*/ 11904, /*\u2EFF*/ 12031);
            }
            /*UnicodeRange?*/ static _u2E80 = null;
            static /*UnicodeRange */ get KangxiRadicals()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u2F00 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u2F00, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u2F00 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u2F00*/ 12032, /*\u2FDF*/ 12255);
            }
            /*UnicodeRange?*/ static _u2F00 = null;
            static /*UnicodeRange */ get IdeographicDescriptionCharacters()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u2FF0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u2FF0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u2FF0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u2FF0*/ 12272, /*\u2FFF*/ 12287);
            }
            /*UnicodeRange?*/ static _u2FF0 = null;
            static /*UnicodeRange */ get CjkSymbolsandPunctuation()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u3000 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u3000, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u3000 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u3000*/ 12288, /*\u303F*/ 12351);
            }
            /*UnicodeRange?*/ static _u3000 = null;
            static /*UnicodeRange */ get Hiragana()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u3040 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u3040, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u3040 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u3040*/ 12352, /*\u309F*/ 12447);
            }
            /*UnicodeRange?*/ static _u3040 = null;
            static /*UnicodeRange */ get Katakana()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u30A0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u30A0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u30A0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u30A0*/ 12448, /*\u30FF*/ 12543);
            }
            /*UnicodeRange?*/ static _u30A0 = null;
            static /*UnicodeRange */ get Bopomofo()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u3100 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u3100, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u3100 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u3100*/ 12544, /*\u312F*/ 12591);
            }
            /*UnicodeRange?*/ static _u3100 = null;
            static /*UnicodeRange */ get HangulCompatibilityJamo()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u3130 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u3130, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u3130 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u3130*/ 12592, /*\u318F*/ 12687);
            }
            /*UnicodeRange?*/ static _u3130 = null;
            static /*UnicodeRange */ get Kanbun()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u3190 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u3190, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u3190 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u3190*/ 12688, /*\u319F*/ 12703);
            }
            /*UnicodeRange?*/ static _u3190 = null;
            static /*UnicodeRange */ get BopomofoExtended()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u31A0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u31A0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u31A0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u31A0*/ 12704, /*\u31BF*/ 12735);
            }
            /*UnicodeRange?*/ static _u31A0 = null;
            static /*UnicodeRange */ get CjkStrokes()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u31C0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u31C0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u31C0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u31C0*/ 12736, /*\u31EF*/ 12783);
            }
            /*UnicodeRange?*/ static _u31C0 = null;
            static /*UnicodeRange */ get KatakanaPhoneticExtensions()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u31F0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u31F0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u31F0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u31F0*/ 12784, /*\u31FF*/ 12799);
            }
            /*UnicodeRange?*/ static _u31F0 = null;
            static /*UnicodeRange */ get EnclosedCjkLettersandMonths()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u3200 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u3200, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u3200 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u3200*/ 12800, /*\u32FF*/ 13055);
            }
            /*UnicodeRange?*/ static _u3200 = null;
            static /*UnicodeRange */ get CjkCompatibility()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u3300 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u3300, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u3300 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u3300*/ 13056, /*\u33FF*/ 13311);
            }
            /*UnicodeRange?*/ static _u3300 = null;
            static /*UnicodeRange */ get CjkUnifiedIdeographsExtensionA()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u3400 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u3400, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u3400 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u3400*/ 13312, /*\u4DBF*/ 19903);
            }
            /*UnicodeRange?*/ static _u3400 = null;
            static /*UnicodeRange */ get YijingHexagramSymbols()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u4DC0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u4DC0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u4DC0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u4DC0*/ 19904, /*\u4DFF*/ 19967);
            }
            /*UnicodeRange?*/ static _u4DC0 = null;
            static /*UnicodeRange */ get CjkUnifiedIdeographs()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._u4E00 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._u4E00, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._u4E00 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\u4E00*/ 19968, /*\u9FFF*/ 40959);
            }
            /*UnicodeRange?*/ static _u4E00 = null;
            static /*UnicodeRange */ get YiSyllables()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uA000 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uA000, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uA000 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uA000*/ 40960, /*\uA48F*/ 42127);
            }
            /*UnicodeRange?*/ static _uA000 = null;
            static /*UnicodeRange */ get YiRadicals()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uA490 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uA490, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uA490 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uA490*/ 42128, /*\uA4CF*/ 42191);
            }
            /*UnicodeRange?*/ static _uA490 = null;
            static /*UnicodeRange */ get Lisu()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uA4D0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uA4D0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uA4D0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uA4D0*/ 42192, /*\uA4FF*/ 42239);
            }
            /*UnicodeRange?*/ static _uA4D0 = null;
            static /*UnicodeRange */ get Vai()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uA500 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uA500, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uA500 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uA500*/ 42240, /*\uA63F*/ 42559);
            }
            /*UnicodeRange?*/ static _uA500 = null;
            static /*UnicodeRange */ get CyrillicExtendedB()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uA640 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uA640, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uA640 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uA640*/ 42560, /*\uA69F*/ 42655);
            }
            /*UnicodeRange?*/ static _uA640 = null;
            static /*UnicodeRange */ get Bamum()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uA6A0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uA6A0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uA6A0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uA6A0*/ 42656, /*\uA6FF*/ 42751);
            }
            /*UnicodeRange?*/ static _uA6A0 = null;
            static /*UnicodeRange */ get ModifierToneLetters()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uA700 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uA700, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uA700 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uA700*/ 42752, /*\uA71F*/ 42783);
            }
            /*UnicodeRange?*/ static _uA700 = null;
            static /*UnicodeRange */ get LatinExtendedD()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uA720 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uA720, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uA720 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uA720*/ 42784, /*\uA7FF*/ 43007);
            }
            /*UnicodeRange?*/ static _uA720 = null;
            static /*UnicodeRange */ get SylotiNagri()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uA800 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uA800, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uA800 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uA800*/ 43008, /*\uA82F*/ 43055);
            }
            /*UnicodeRange?*/ static _uA800 = null;
            static /*UnicodeRange */ get CommonIndicNumberForms()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uA830 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uA830, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uA830 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uA830*/ 43056, /*\uA83F*/ 43071);
            }
            /*UnicodeRange?*/ static _uA830 = null;
            static /*UnicodeRange */ get Phagspa()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uA840 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uA840, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uA840 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uA840*/ 43072, /*\uA87F*/ 43135);
            }
            /*UnicodeRange?*/ static _uA840 = null;
            static /*UnicodeRange */ get Saurashtra()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uA880 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uA880, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uA880 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uA880*/ 43136, /*\uA8DF*/ 43231);
            }
            /*UnicodeRange?*/ static _uA880 = null;
            static /*UnicodeRange */ get DevanagariExtended()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uA8E0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uA8E0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uA8E0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uA8E0*/ 43232, /*\uA8FF*/ 43263);
            }
            /*UnicodeRange?*/ static _uA8E0 = null;
            static /*UnicodeRange */ get KayahLi()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uA900 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uA900, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uA900 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uA900*/ 43264, /*\uA92F*/ 43311);
            }
            /*UnicodeRange?*/ static _uA900 = null;
            static /*UnicodeRange */ get Rejang()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uA930 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uA930, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uA930 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uA930*/ 43312, /*\uA95F*/ 43359);
            }
            /*UnicodeRange?*/ static _uA930 = null;
            static /*UnicodeRange */ get HangulJamoExtendedA()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uA960 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uA960, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uA960 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uA960*/ 43360, /*\uA97F*/ 43391);
            }
            /*UnicodeRange?*/ static _uA960 = null;
            static /*UnicodeRange */ get Javanese()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uA980 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uA980, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uA980 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uA980*/ 43392, /*\uA9DF*/ 43487);
            }
            /*UnicodeRange?*/ static _uA980 = null;
            static /*UnicodeRange */ get MyanmarExtendedB()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uA9E0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uA9E0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uA9E0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uA9E0*/ 43488, /*\uA9FF*/ 43519);
            }
            /*UnicodeRange?*/ static _uA9E0 = null;
            static /*UnicodeRange */ get Cham()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uAA00 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uAA00, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uAA00 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uAA00*/ 43520, /*\uAA5F*/ 43615);
            }
            /*UnicodeRange?*/ static _uAA00 = null;
            static /*UnicodeRange */ get MyanmarExtendedA()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uAA60 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uAA60, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uAA60 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uAA60*/ 43616, /*\uAA7F*/ 43647);
            }
            /*UnicodeRange?*/ static _uAA60 = null;
            static /*UnicodeRange */ get TaiViet()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uAA80 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uAA80, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uAA80 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uAA80*/ 43648, /*\uAADF*/ 43743);
            }
            /*UnicodeRange?*/ static _uAA80 = null;
            static /*UnicodeRange */ get MeeteiMayekExtensions()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uAAE0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uAAE0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uAAE0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uAAE0*/ 43744, /*\uAAFF*/ 43775);
            }
            /*UnicodeRange?*/ static _uAAE0 = null;
            static /*UnicodeRange */ get EthiopicExtendedA()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uAB00 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uAB00, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uAB00 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uAB00*/ 43776, /*\uAB2F*/ 43823);
            }
            /*UnicodeRange?*/ static _uAB00 = null;
            static /*UnicodeRange */ get LatinExtendedE()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uAB30 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uAB30, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uAB30 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uAB30*/ 43824, /*\uAB6F*/ 43887);
            }
            /*UnicodeRange?*/ static _uAB30 = null;
            static /*UnicodeRange */ get CherokeeSupplement()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uAB70 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uAB70, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uAB70 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uAB70*/ 43888, /*\uABBF*/ 43967);
            }
            /*UnicodeRange?*/ static _uAB70 = null;
            static /*UnicodeRange */ get MeeteiMayek()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uABC0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uABC0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uABC0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uABC0*/ 43968, /*\uABFF*/ 44031);
            }
            /*UnicodeRange?*/ static _uABC0 = null;
            static /*UnicodeRange */ get HangulSyllables()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uAC00 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uAC00, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uAC00 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uAC00*/ 44032, /*\uD7AF*/ 55215);
            }
            /*UnicodeRange?*/ static _uAC00 = null;
            static /*UnicodeRange */ get HangulJamoExtendedB()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uD7B0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uD7B0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uD7B0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uD7B0*/ 55216, /*\uD7FF*/ 55295);
            }
            /*UnicodeRange?*/ static _uD7B0 = null;
            static /*UnicodeRange */ get CjkCompatibilityIdeographs()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uF900 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uF900, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uF900 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uF900*/ 63744, /*\uFAFF*/ 64255);
            }
            /*UnicodeRange?*/ static _uF900 = null;
            static /*UnicodeRange */ get AlphabeticPresentationForms()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uFB00 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uFB00, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uFB00 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uFB00*/ 64256, /*\uFB4F*/ 64335);
            }
            /*UnicodeRange?*/ static _uFB00 = null;
            static /*UnicodeRange */ get ArabicPresentationFormsA()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uFB50 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uFB50, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uFB50 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uFB50*/ 64336, /*\uFDFF*/ 65023);
            }
            /*UnicodeRange?*/ static _uFB50 = null;
            static /*UnicodeRange */ get VariationSelectors()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uFE00 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uFE00, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uFE00 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uFE00*/ 65024, /*\uFE0F*/ 65039);
            }
            /*UnicodeRange?*/ static _uFE00 = null;
            static /*UnicodeRange */ get VerticalForms()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uFE10 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uFE10, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uFE10 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uFE10*/ 65040, /*\uFE1F*/ 65055);
            }
            /*UnicodeRange?*/ static _uFE10 = null;
            static /*UnicodeRange */ get CombiningHalfMarks()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uFE20 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uFE20, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uFE20 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uFE20*/ 65056, /*\uFE2F*/ 65071);
            }
            /*UnicodeRange?*/ static _uFE20 = null;
            static /*UnicodeRange */ get CjkCompatibilityForms()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uFE30 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uFE30, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uFE30 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uFE30*/ 65072, /*\uFE4F*/ 65103);
            }
            /*UnicodeRange?*/ static _uFE30 = null;
            static /*UnicodeRange */ get SmallFormVariants()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uFE50 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uFE50, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uFE50 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uFE50*/ 65104, /*\uFE6F*/ 65135);
            }
            /*UnicodeRange?*/ static _uFE50 = null;
            static /*UnicodeRange */ get ArabicPresentationFormsB()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uFE70 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uFE70, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uFE70 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uFE70*/ 65136, /*\uFEFF*/ 65279);
            }
            /*UnicodeRange?*/ static _uFE70 = null;
            static /*UnicodeRange */ get HalfwidthandFullwidthForms()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uFF00 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uFF00, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uFF00 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uFF00*/ 65280, /*\uFFEF*/ 65519);
            }
            /*UnicodeRange?*/ static _uFF00 = null;
            static /*UnicodeRange */ get Specials()
            {
                return $.$stew.System.Text.Unicode.UnicodeRanges._uFFF0 ?? $.$stew.System.Text.Unicode.UnicodeRanges.CreateRange($.$ref(() => $.$stew.System.Text.Unicode.UnicodeRanges._uFFF0, ($v) => $.$stew.System.Text.Unicode.UnicodeRanges._uFFF0 = $v, $.$stew.System.Text.Unicode.UnicodeRange), /*\uFFF0*/ 65520, /*\uFFFF*/ 65535);
            }
            /*UnicodeRange?*/ static _uFFF0 = null;
            static $h = 1871564;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1806028,"g":{"r":0,"d":0,"h":8591806156,"f":33},"n":"None","d":1871564,"h":4296838860,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":21476708044,"f":33},"n":"All","d":1871564,"h":17181740748,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":42951544524,"f":33},"n":"BasicLatin","d":1871564,"h":38656577228,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":55836446412,"f":33},"n":"Latin1Supplement","d":1871564,"h":51541479116,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":68721348300,"f":33},"n":"LatinExtendedA","d":1871564,"h":64426381004,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":81606250188,"f":33},"n":"LatinExtendedB","d":1871564,"h":77311282892,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":94491152076,"f":33},"n":"IpaExtensions","d":1871564,"h":90196184780,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":107376053964,"f":33},"n":"SpacingModifierLetters","d":1871564,"h":103081086668,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":120260955852,"f":33},"n":"CombiningDiacriticalMarks","d":1871564,"h":115965988556,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":133145857740,"f":33},"n":"GreekandCoptic","d":1871564,"h":128850890444,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":146030759628,"f":33},"n":"Cyrillic","d":1871564,"h":141735792332,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":158915661516,"f":33},"n":"CyrillicSupplement","d":1871564,"h":154620694220,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":171800563404,"f":33},"n":"Armenian","d":1871564,"h":167505596108,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":184685465292,"f":33},"n":"Hebrew","d":1871564,"h":180390497996,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":197570367180,"f":33},"n":"Arabic","d":1871564,"h":193275399884,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":210455269068,"f":33},"n":"Syriac","d":1871564,"h":206160301772,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":223340170956,"f":33},"n":"ArabicSupplement","d":1871564,"h":219045203660,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":236225072844,"f":33},"n":"Thaana","d":1871564,"h":231930105548,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":249109974732,"f":33},"n":"NKo","d":1871564,"h":244815007436,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":261994876620,"f":33},"n":"Samaritan","d":1871564,"h":257699909324,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":274879778508,"f":33},"n":"Mandaic","d":1871564,"h":270584811212,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":287764680396,"f":33},"n":"SyriacSupplement","d":1871564,"h":283469713100,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":300649582284,"f":33},"n":"ArabicExtendedB","d":1871564,"h":296354614988,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":313534484172,"f":33},"n":"ArabicExtendedA","d":1871564,"h":309239516876,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":326419386060,"f":33},"n":"Devanagari","d":1871564,"h":322124418764,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":339304287948,"f":33},"n":"Bengali","d":1871564,"h":335009320652,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":352189189836,"f":33},"n":"Gurmukhi","d":1871564,"h":347894222540,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":365074091724,"f":33},"n":"Gujarati","d":1871564,"h":360779124428,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":377958993612,"f":33},"n":"Oriya","d":1871564,"h":373664026316,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":390843895500,"f":33},"n":"Tamil","d":1871564,"h":386548928204,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":403728797388,"f":33},"n":"Telugu","d":1871564,"h":399433830092,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":416613699276,"f":33},"n":"Kannada","d":1871564,"h":412318731980,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":429498601164,"f":33},"n":"Malayalam","d":1871564,"h":425203633868,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":442383503052,"f":33},"n":"Sinhala","d":1871564,"h":438088535756,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":455268404940,"f":33},"n":"Thai","d":1871564,"h":450973437644,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":468153306828,"f":33},"n":"Lao","d":1871564,"h":463858339532,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":481038208716,"f":33},"n":"Tibetan","d":1871564,"h":476743241420,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":493923110604,"f":33},"n":"Myanmar","d":1871564,"h":489628143308,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":506808012492,"f":33},"n":"Georgian","d":1871564,"h":502513045196,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":519692914380,"f":33},"n":"HangulJamo","d":1871564,"h":515397947084,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":532577816268,"f":33},"n":"Ethiopic","d":1871564,"h":528282848972,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":545462718156,"f":33},"n":"EthiopicSupplement","d":1871564,"h":541167750860,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":558347620044,"f":33},"n":"Cherokee","d":1871564,"h":554052652748,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":571232521932,"f":33},"n":"UnifiedCanadianAboriginalSyllabics","d":1871564,"h":566937554636,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":584117423820,"f":33},"n":"Ogham","d":1871564,"h":579822456524,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":597002325708,"f":33},"n":"Runic","d":1871564,"h":592707358412,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":609887227596,"f":33},"n":"Tagalog","d":1871564,"h":605592260300,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":622772129484,"f":33},"n":"Hanunoo","d":1871564,"h":618477162188,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":635657031372,"f":33},"n":"Buhid","d":1871564,"h":631362064076,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":648541933260,"f":33},"n":"Tagbanwa","d":1871564,"h":644246965964,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":661426835148,"f":33},"n":"Khmer","d":1871564,"h":657131867852,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":674311737036,"f":33},"n":"Mongolian","d":1871564,"h":670016769740,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":687196638924,"f":33},"n":"UnifiedCanadianAboriginalSyllabicsExtended","d":1871564,"h":682901671628,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":700081540812,"f":33},"n":"Limbu","d":1871564,"h":695786573516,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":712966442700,"f":33},"n":"TaiLe","d":1871564,"h":708671475404,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":725851344588,"f":33},"n":"NewTaiLue","d":1871564,"h":721556377292,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":738736246476,"f":33},"n":"KhmerSymbols","d":1871564,"h":734441279180,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":751621148364,"f":33},"n":"Buginese","d":1871564,"h":747326181068,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":764506050252,"f":33},"n":"TaiTham","d":1871564,"h":760211082956,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":777390952140,"f":33},"n":"CombiningDiacriticalMarksExtended","d":1871564,"h":773095984844,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":790275854028,"f":33},"n":"Balinese","d":1871564,"h":785980886732,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":803160755916,"f":33},"n":"Sundanese","d":1871564,"h":798865788620,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":816045657804,"f":33},"n":"Batak","d":1871564,"h":811750690508,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":828930559692,"f":33},"n":"Lepcha","d":1871564,"h":824635592396,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":841815461580,"f":33},"n":"OlChiki","d":1871564,"h":837520494284,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":854700363468,"f":33},"n":"CyrillicExtendedC","d":1871564,"h":850405396172,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":867585265356,"f":33},"n":"GeorgianExtended","d":1871564,"h":863290298060,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":880470167244,"f":33},"n":"SundaneseSupplement","d":1871564,"h":876175199948,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":893355069132,"f":33},"n":"VedicExtensions","d":1871564,"h":889060101836,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":906239971020,"f":33},"n":"PhoneticExtensions","d":1871564,"h":901945003724,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":919124872908,"f":33},"n":"PhoneticExtensionsSupplement","d":1871564,"h":914829905612,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":932009774796,"f":33},"n":"CombiningDiacriticalMarksSupplement","d":1871564,"h":927714807500,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":944894676684,"f":33},"n":"LatinExtendedAdditional","d":1871564,"h":940599709388,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":957779578572,"f":33},"n":"GreekExtended","d":1871564,"h":953484611276,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":970664480460,"f":33},"n":"GeneralPunctuation","d":1871564,"h":966369513164,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":983549382348,"f":33},"n":"SuperscriptsandSubscripts","d":1871564,"h":979254415052,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":996434284236,"f":33},"n":"CurrencySymbols","d":1871564,"h":992139316940,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1009319186124,"f":33},"n":"CombiningDiacriticalMarksforSymbols","d":1871564,"h":1005024218828,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1022204088012,"f":33},"n":"LetterlikeSymbols","d":1871564,"h":1017909120716,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1035088989900,"f":33},"n":"NumberForms","d":1871564,"h":1030794022604,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1047973891788,"f":33},"n":"Arrows","d":1871564,"h":1043678924492,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1060858793676,"f":33},"n":"MathematicalOperators","d":1871564,"h":1056563826380,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1073743695564,"f":33},"n":"MiscellaneousTechnical","d":1871564,"h":1069448728268,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1086628597452,"f":33},"n":"ControlPictures","d":1871564,"h":1082333630156,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1099513499340,"f":33},"n":"OpticalCharacterRecognition","d":1871564,"h":1095218532044,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1112398401228,"f":33},"n":"EnclosedAlphanumerics","d":1871564,"h":1108103433932,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1125283303116,"f":33},"n":"BoxDrawing","d":1871564,"h":1120988335820,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1138168205004,"f":33},"n":"BlockElements","d":1871564,"h":1133873237708,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1151053106892,"f":33},"n":"GeometricShapes","d":1871564,"h":1146758139596,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1163938008780,"f":33},"n":"MiscellaneousSymbols","d":1871564,"h":1159643041484,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1176822910668,"f":33},"n":"Dingbats","d":1871564,"h":1172527943372,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1189707812556,"f":33},"n":"MiscellaneousMathematicalSymbolsA","d":1871564,"h":1185412845260,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1202592714444,"f":33},"n":"SupplementalArrowsA","d":1871564,"h":1198297747148,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1215477616332,"f":33},"n":"BraillePatterns","d":1871564,"h":1211182649036,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1228362518220,"f":33},"n":"SupplementalArrowsB","d":1871564,"h":1224067550924,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1241247420108,"f":33},"n":"MiscellaneousMathematicalSymbolsB","d":1871564,"h":1236952452812,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1254132321996,"f":33},"n":"SupplementalMathematicalOperators","d":1871564,"h":1249837354700,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1267017223884,"f":33},"n":"MiscellaneousSymbolsandArrows","d":1871564,"h":1262722256588,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1279902125772,"f":33},"n":"Glagolitic","d":1871564,"h":1275607158476,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1292787027660,"f":33},"n":"LatinExtendedC","d":1871564,"h":1288492060364,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1305671929548,"f":33},"n":"Coptic","d":1871564,"h":1301376962252,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1318556831436,"f":33},"n":"GeorgianSupplement","d":1871564,"h":1314261864140,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1331441733324,"f":33},"n":"Tifinagh","d":1871564,"h":1327146766028,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1344326635212,"f":33},"n":"EthiopicExtended","d":1871564,"h":1340031667916,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1357211537100,"f":33},"n":"CyrillicExtendedA","d":1871564,"h":1352916569804,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1370096438988,"f":33},"n":"SupplementalPunctuation","d":1871564,"h":1365801471692,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1382981340876,"f":33},"n":"CjkRadicalsSupplement","d":1871564,"h":1378686373580,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1395866242764,"f":33},"n":"KangxiRadicals","d":1871564,"h":1391571275468,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1408751144652,"f":33},"n":"IdeographicDescriptionCharacters","d":1871564,"h":1404456177356,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1421636046540,"f":33},"n":"CjkSymbolsandPunctuation","d":1871564,"h":1417341079244,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1434520948428,"f":33},"n":"Hiragana","d":1871564,"h":1430225981132,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1447405850316,"f":33},"n":"Katakana","d":1871564,"h":1443110883020,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1460290752204,"f":33},"n":"Bopomofo","d":1871564,"h":1455995784908,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1473175654092,"f":33},"n":"HangulCompatibilityJamo","d":1871564,"h":1468880686796,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1486060555980,"f":33},"n":"Kanbun","d":1871564,"h":1481765588684,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1498945457868,"f":33},"n":"BopomofoExtended","d":1871564,"h":1494650490572,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1511830359756,"f":33},"n":"CjkStrokes","d":1871564,"h":1507535392460,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1524715261644,"f":33},"n":"KatakanaPhoneticExtensions","d":1871564,"h":1520420294348,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1537600163532,"f":33},"n":"EnclosedCjkLettersandMonths","d":1871564,"h":1533305196236,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1550485065420,"f":33},"n":"CjkCompatibility","d":1871564,"h":1546190098124,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1563369967308,"f":33},"n":"CjkUnifiedIdeographsExtensionA","d":1871564,"h":1559075000012,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1576254869196,"f":33},"n":"YijingHexagramSymbols","d":1871564,"h":1571959901900,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1589139771084,"f":33},"n":"CjkUnifiedIdeographs","d":1871564,"h":1584844803788,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1602024672972,"f":33},"n":"YiSyllables","d":1871564,"h":1597729705676,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1614909574860,"f":33},"n":"YiRadicals","d":1871564,"h":1610614607564,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1627794476748,"f":33},"n":"Lisu","d":1871564,"h":1623499509452,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1640679378636,"f":33},"n":"Vai","d":1871564,"h":1636384411340,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1653564280524,"f":33},"n":"CyrillicExtendedB","d":1871564,"h":1649269313228,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1666449182412,"f":33},"n":"Bamum","d":1871564,"h":1662154215116,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1679334084300,"f":33},"n":"ModifierToneLetters","d":1871564,"h":1675039117004,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1692218986188,"f":33},"n":"LatinExtendedD","d":1871564,"h":1687924018892,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1705103888076,"f":33},"n":"SylotiNagri","d":1871564,"h":1700808920780,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1717988789964,"f":33},"n":"CommonIndicNumberForms","d":1871564,"h":1713693822668,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1730873691852,"f":33},"n":"Phagspa","d":1871564,"h":1726578724556,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1743758593740,"f":33},"n":"Saurashtra","d":1871564,"h":1739463626444,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1756643495628,"f":33},"n":"DevanagariExtended","d":1871564,"h":1752348528332,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1769528397516,"f":33},"n":"KayahLi","d":1871564,"h":1765233430220,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1782413299404,"f":33},"n":"Rejang","d":1871564,"h":1778118332108,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1795298201292,"f":33},"n":"HangulJamoExtendedA","d":1871564,"h":1791003233996,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1808183103180,"f":33},"n":"Javanese","d":1871564,"h":1803888135884,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1821068005068,"f":33},"n":"MyanmarExtendedB","d":1871564,"h":1816773037772,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1833952906956,"f":33},"n":"Cham","d":1871564,"h":1829657939660,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1846837808844,"f":33},"n":"MyanmarExtendedA","d":1871564,"h":1842542841548,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1859722710732,"f":33},"n":"TaiViet","d":1871564,"h":1855427743436,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1872607612620,"f":33},"n":"MeeteiMayekExtensions","d":1871564,"h":1868312645324,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1885492514508,"f":33},"n":"EthiopicExtendedA","d":1871564,"h":1881197547212,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1898377416396,"f":33},"n":"LatinExtendedE","d":1871564,"h":1894082449100,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1911262318284,"f":33},"n":"CherokeeSupplement","d":1871564,"h":1906967350988,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1924147220172,"f":33},"n":"MeeteiMayek","d":1871564,"h":1919852252876,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1937032122060,"f":33},"n":"HangulSyllables","d":1871564,"h":1932737154764,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1949917023948,"f":33},"n":"HangulJamoExtendedB","d":1871564,"h":1945622056652,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1962801925836,"f":33},"n":"CjkCompatibilityIdeographs","d":1871564,"h":1958506958540,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1975686827724,"f":33},"n":"AlphabeticPresentationForms","d":1871564,"h":1971391860428,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":1988571729612,"f":33},"n":"ArabicPresentationFormsA","d":1871564,"h":1984276762316,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":2001456631500,"f":33},"n":"VariationSelectors","d":1871564,"h":1997161664204,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":2014341533388,"f":33},"n":"VerticalForms","d":1871564,"h":2010046566092,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":2027226435276,"f":33},"n":"CombiningHalfMarks","d":1871564,"h":2022931467980,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":2040111337164,"f":33},"n":"CjkCompatibilityForms","d":1871564,"h":2035816369868,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":2052996239052,"f":33},"n":"SmallFormVariants","d":1871564,"h":2048701271756,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":2065881140940,"f":33},"n":"ArabicPresentationFormsB","d":1871564,"h":2061586173644,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":2078766042828,"f":33},"n":"HalfwidthandFullwidthForms","d":1871564,"h":2074471075532,"f":33},{"p":1806028,"g":{"r":0,"d":0,"h":2091650944716,"f":33},"n":"Specials","d":1871564,"h":2087355977420,"f":33}],"m":[{"r":1806028,"p":[{"n":"range","p":1806028,"f":4}],"n":"CreateEmptyRange","d":1871564,"h":30066642636,"f":34},{"r":1806028,"p":[{"n":"range","p":1806028,"f":4},{"n":"first","p":458753},{"n":"last","p":458753}],"n":"CreateRange","d":1871564,"h":34361609932,"f":34}],"l":[{"t":1806028,"n":"_none","d":1871564,"h":12886773452,"f":34},{"t":1806028,"n":"_all","d":1871564,"h":25771675340,"f":34},{"t":1806028,"n":"_u0000","d":1871564,"h":47246511820,"f":34},{"t":1806028,"n":"_u0080","d":1871564,"h":60131413708,"f":34},{"t":1806028,"n":"_u0100","d":1871564,"h":73016315596,"f":34},{"t":1806028,"n":"_u0180","d":1871564,"h":85901217484,"f":34},{"t":1806028,"n":"_u0250","d":1871564,"h":98786119372,"f":34},{"t":1806028,"n":"_u02B0","d":1871564,"h":111671021260,"f":34},{"t":1806028,"n":"_u0300","d":1871564,"h":124555923148,"f":34},{"t":1806028,"n":"_u0370","d":1871564,"h":137440825036,"f":34},{"t":1806028,"n":"_u0400","d":1871564,"h":150325726924,"f":34},{"t":1806028,"n":"_u0500","d":1871564,"h":163210628812,"f":34},{"t":1806028,"n":"_u0530","d":1871564,"h":176095530700,"f":34},{"t":1806028,"n":"_u0590","d":1871564,"h":188980432588,"f":34},{"t":1806028,"n":"_u0600","d":1871564,"h":201865334476,"f":34},{"t":1806028,"n":"_u0700","d":1871564,"h":214750236364,"f":34},{"t":1806028,"n":"_u0750","d":1871564,"h":227635138252,"f":34},{"t":1806028,"n":"_u0780","d":1871564,"h":240520040140,"f":34},{"t":1806028,"n":"_u07C0","d":1871564,"h":253404942028,"f":34},{"t":1806028,"n":"_u0800","d":1871564,"h":266289843916,"f":34},{"t":1806028,"n":"_u0840","d":1871564,"h":279174745804,"f":34},{"t":1806028,"n":"_u0860","d":1871564,"h":292059647692,"f":34},{"t":1806028,"n":"_u0870","d":1871564,"h":304944549580,"f":34},{"t":1806028,"n":"_u08A0","d":1871564,"h":317829451468,"f":34},{"t":1806028,"n":"_u0900","d":1871564,"h":330714353356,"f":34},{"t":1806028,"n":"_u0980","d":1871564,"h":343599255244,"f":34},{"t":1806028,"n":"_u0A00","d":1871564,"h":356484157132,"f":34},{"t":1806028,"n":"_u0A80","d":1871564,"h":369369059020,"f":34},{"t":1806028,"n":"_u0B00","d":1871564,"h":382253960908,"f":34},{"t":1806028,"n":"_u0B80","d":1871564,"h":395138862796,"f":34},{"t":1806028,"n":"_u0C00","d":1871564,"h":408023764684,"f":34},{"t":1806028,"n":"_u0C80","d":1871564,"h":420908666572,"f":34},{"t":1806028,"n":"_u0D00","d":1871564,"h":433793568460,"f":34},{"t":1806028,"n":"_u0D80","d":1871564,"h":446678470348,"f":34},{"t":1806028,"n":"_u0E00","d":1871564,"h":459563372236,"f":34},{"t":1806028,"n":"_u0E80","d":1871564,"h":472448274124,"f":34},{"t":1806028,"n":"_u0F00","d":1871564,"h":485333176012,"f":34},{"t":1806028,"n":"_u1000","d":1871564,"h":498218077900,"f":34},{"t":1806028,"n":"_u10A0","d":1871564,"h":511102979788,"f":34},{"t":1806028,"n":"_u1100","d":1871564,"h":523987881676,"f":34},{"t":1806028,"n":"_u1200","d":1871564,"h":536872783564,"f":34},{"t":1806028,"n":"_u1380","d":1871564,"h":549757685452,"f":34},{"t":1806028,"n":"_u13A0","d":1871564,"h":562642587340,"f":34},{"t":1806028,"n":"_u1400","d":1871564,"h":575527489228,"f":34},{"t":1806028,"n":"_u1680","d":1871564,"h":588412391116,"f":34},{"t":1806028,"n":"_u16A0","d":1871564,"h":601297293004,"f":34},{"t":1806028,"n":"_u1700","d":1871564,"h":614182194892,"f":34},{"t":1806028,"n":"_u1720","d":1871564,"h":627067096780,"f":34},{"t":1806028,"n":"_u1740","d":1871564,"h":639951998668,"f":34},{"t":1806028,"n":"_u1760","d":1871564,"h":652836900556,"f":34},{"t":1806028,"n":"_u1780","d":1871564,"h":665721802444,"f":34},{"t":1806028,"n":"_u1800","d":1871564,"h":678606704332,"f":34},{"t":1806028,"n":"_u18B0","d":1871564,"h":691491606220,"f":34},{"t":1806028,"n":"_u1900","d":1871564,"h":704376508108,"f":34},{"t":1806028,"n":"_u1950","d":1871564,"h":717261409996,"f":34},{"t":1806028,"n":"_u1980","d":1871564,"h":730146311884,"f":34},{"t":1806028,"n":"_u19E0","d":1871564,"h":743031213772,"f":34},{"t":1806028,"n":"_u1A00","d":1871564,"h":755916115660,"f":34},{"t":1806028,"n":"_u1A20","d":1871564,"h":768801017548,"f":34},{"t":1806028,"n":"_u1AB0","d":1871564,"h":781685919436,"f":34},{"t":1806028,"n":"_u1B00","d":1871564,"h":794570821324,"f":34},{"t":1806028,"n":"_u1B80","d":1871564,"h":807455723212,"f":34},{"t":1806028,"n":"_u1BC0","d":1871564,"h":820340625100,"f":34},{"t":1806028,"n":"_u1C00","d":1871564,"h":833225526988,"f":34},{"t":1806028,"n":"_u1C50","d":1871564,"h":846110428876,"f":34},{"t":1806028,"n":"_u1C80","d":1871564,"h":858995330764,"f":34},{"t":1806028,"n":"_u1C90","d":1871564,"h":871880232652,"f":34},{"t":1806028,"n":"_u1CC0","d":1871564,"h":884765134540,"f":34},{"t":1806028,"n":"_u1CD0","d":1871564,"h":897650036428,"f":34},{"t":1806028,"n":"_u1D00","d":1871564,"h":910534938316,"f":34},{"t":1806028,"n":"_u1D80","d":1871564,"h":923419840204,"f":34},{"t":1806028,"n":"_u1DC0","d":1871564,"h":936304742092,"f":34},{"t":1806028,"n":"_u1E00","d":1871564,"h":949189643980,"f":34},{"t":1806028,"n":"_u1F00","d":1871564,"h":962074545868,"f":34},{"t":1806028,"n":"_u2000","d":1871564,"h":974959447756,"f":34},{"t":1806028,"n":"_u2070","d":1871564,"h":987844349644,"f":34},{"t":1806028,"n":"_u20A0","d":1871564,"h":1000729251532,"f":34},{"t":1806028,"n":"_u20D0","d":1871564,"h":1013614153420,"f":34},{"t":1806028,"n":"_u2100","d":1871564,"h":1026499055308,"f":34},{"t":1806028,"n":"_u2150","d":1871564,"h":1039383957196,"f":34},{"t":1806028,"n":"_u2190","d":1871564,"h":1052268859084,"f":34},{"t":1806028,"n":"_u2200","d":1871564,"h":1065153760972,"f":34},{"t":1806028,"n":"_u2300","d":1871564,"h":1078038662860,"f":34},{"t":1806028,"n":"_u2400","d":1871564,"h":1090923564748,"f":34},{"t":1806028,"n":"_u2440","d":1871564,"h":1103808466636,"f":34},{"t":1806028,"n":"_u2460","d":1871564,"h":1116693368524,"f":34},{"t":1806028,"n":"_u2500","d":1871564,"h":1129578270412,"f":34},{"t":1806028,"n":"_u2580","d":1871564,"h":1142463172300,"f":34},{"t":1806028,"n":"_u25A0","d":1871564,"h":1155348074188,"f":34},{"t":1806028,"n":"_u2600","d":1871564,"h":1168232976076,"f":34},{"t":1806028,"n":"_u2700","d":1871564,"h":1181117877964,"f":34},{"t":1806028,"n":"_u27C0","d":1871564,"h":1194002779852,"f":34},{"t":1806028,"n":"_u27F0","d":1871564,"h":1206887681740,"f":34},{"t":1806028,"n":"_u2800","d":1871564,"h":1219772583628,"f":34},{"t":1806028,"n":"_u2900","d":1871564,"h":1232657485516,"f":34},{"t":1806028,"n":"_u2980","d":1871564,"h":1245542387404,"f":34},{"t":1806028,"n":"_u2A00","d":1871564,"h":1258427289292,"f":34},{"t":1806028,"n":"_u2B00","d":1871564,"h":1271312191180,"f":34},{"t":1806028,"n":"_u2C00","d":1871564,"h":1284197093068,"f":34},{"t":1806028,"n":"_u2C60","d":1871564,"h":1297081994956,"f":34},{"t":1806028,"n":"_u2C80","d":1871564,"h":1309966896844,"f":34},{"t":1806028,"n":"_u2D00","d":1871564,"h":1322851798732,"f":34},{"t":1806028,"n":"_u2D30","d":1871564,"h":1335736700620,"f":34},{"t":1806028,"n":"_u2D80","d":1871564,"h":1348621602508,"f":34},{"t":1806028,"n":"_u2DE0","d":1871564,"h":1361506504396,"f":34},{"t":1806028,"n":"_u2E00","d":1871564,"h":1374391406284,"f":34},{"t":1806028,"n":"_u2E80","d":1871564,"h":1387276308172,"f":34},{"t":1806028,"n":"_u2F00","d":1871564,"h":1400161210060,"f":34},{"t":1806028,"n":"_u2FF0","d":1871564,"h":1413046111948,"f":34},{"t":1806028,"n":"_u3000","d":1871564,"h":1425931013836,"f":34},{"t":1806028,"n":"_u3040","d":1871564,"h":1438815915724,"f":34},{"t":1806028,"n":"_u30A0","d":1871564,"h":1451700817612,"f":34},{"t":1806028,"n":"_u3100","d":1871564,"h":1464585719500,"f":34},{"t":1806028,"n":"_u3130","d":1871564,"h":1477470621388,"f":34},{"t":1806028,"n":"_u3190","d":1871564,"h":1490355523276,"f":34},{"t":1806028,"n":"_u31A0","d":1871564,"h":1503240425164,"f":34},{"t":1806028,"n":"_u31C0","d":1871564,"h":1516125327052,"f":34},{"t":1806028,"n":"_u31F0","d":1871564,"h":1529010228940,"f":34},{"t":1806028,"n":"_u3200","d":1871564,"h":1541895130828,"f":34},{"t":1806028,"n":"_u3300","d":1871564,"h":1554780032716,"f":34},{"t":1806028,"n":"_u3400","d":1871564,"h":1567664934604,"f":34},{"t":1806028,"n":"_u4DC0","d":1871564,"h":1580549836492,"f":34},{"t":1806028,"n":"_u4E00","d":1871564,"h":1593434738380,"f":34},{"t":1806028,"n":"_uA000","d":1871564,"h":1606319640268,"f":34},{"t":1806028,"n":"_uA490","d":1871564,"h":1619204542156,"f":34},{"t":1806028,"n":"_uA4D0","d":1871564,"h":1632089444044,"f":34},{"t":1806028,"n":"_uA500","d":1871564,"h":1644974345932,"f":34},{"t":1806028,"n":"_uA640","d":1871564,"h":1657859247820,"f":34},{"t":1806028,"n":"_uA6A0","d":1871564,"h":1670744149708,"f":34},{"t":1806028,"n":"_uA700","d":1871564,"h":1683629051596,"f":34},{"t":1806028,"n":"_uA720","d":1871564,"h":1696513953484,"f":34},{"t":1806028,"n":"_uA800","d":1871564,"h":1709398855372,"f":34},{"t":1806028,"n":"_uA830","d":1871564,"h":1722283757260,"f":34},{"t":1806028,"n":"_uA840","d":1871564,"h":1735168659148,"f":34},{"t":1806028,"n":"_uA880","d":1871564,"h":1748053561036,"f":34},{"t":1806028,"n":"_uA8E0","d":1871564,"h":1760938462924,"f":34},{"t":1806028,"n":"_uA900","d":1871564,"h":1773823364812,"f":34},{"t":1806028,"n":"_uA930","d":1871564,"h":1786708266700,"f":34},{"t":1806028,"n":"_uA960","d":1871564,"h":1799593168588,"f":34},{"t":1806028,"n":"_uA980","d":1871564,"h":1812478070476,"f":34},{"t":1806028,"n":"_uA9E0","d":1871564,"h":1825362972364,"f":34},{"t":1806028,"n":"_uAA00","d":1871564,"h":1838247874252,"f":34},{"t":1806028,"n":"_uAA60","d":1871564,"h":1851132776140,"f":34},{"t":1806028,"n":"_uAA80","d":1871564,"h":1864017678028,"f":34},{"t":1806028,"n":"_uAAE0","d":1871564,"h":1876902579916,"f":34},{"t":1806028,"n":"_uAB00","d":1871564,"h":1889787481804,"f":34},{"t":1806028,"n":"_uAB30","d":1871564,"h":1902672383692,"f":34},{"t":1806028,"n":"_uAB70","d":1871564,"h":1915557285580,"f":34},{"t":1806028,"n":"_uABC0","d":1871564,"h":1928442187468,"f":34},{"t":1806028,"n":"_uAC00","d":1871564,"h":1941327089356,"f":34},{"t":1806028,"n":"_uD7B0","d":1871564,"h":1954211991244,"f":34},{"t":1806028,"n":"_uF900","d":1871564,"h":1967096893132,"f":34},{"t":1806028,"n":"_uFB00","d":1871564,"h":1979981795020,"f":34},{"t":1806028,"n":"_uFB50","d":1871564,"h":1992866696908,"f":34},{"t":1806028,"n":"_uFE00","d":1871564,"h":2005751598796,"f":34},{"t":1806028,"n":"_uFE10","d":1871564,"h":2018636500684,"f":34},{"t":1806028,"n":"_uFE20","d":1871564,"h":2031521402572,"f":34},{"t":1806028,"n":"_uFE30","d":1871564,"h":2044406304460,"f":34},{"t":1806028,"n":"_uFE50","d":1871564,"h":2057291206348,"f":34},{"t":1806028,"n":"_uFE70","d":1871564,"h":2070176108236,"f":34},{"t":1806028,"n":"_uFF00","d":1871564,"h":2083061010124,"f":34},{"t":1806028,"n":"_uFFF0","d":1871564,"h":2095945912012,"f":34}],"h":1871564}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Text.Unicode.UnicodeRanges`; }
        });
        
        $asm.$cls("$stew.System.HexConverter", ($self) => class HexConverter
        {
            static $_Casing;
            static get Casing()
            {
                let $cls = $.$stew.System.HexConverter;
                return $cls.$_Casing ??= $asm.$nstr("$stew.System.HexConverter.Casing", ($self) => class Casing extends $.$spc.System.Enum
                {
                    static Upper = 0;
                    static Lower = 8224;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "Upper": 0n,
                            "Lower": 8224n
                        };
                    }
                    static $h = 298700;
                    static $z = 4;
                    static $f = 0b110000011010001001;
                    static $k = 4;
                    static get $eut() { return $.$spc.System.UInt32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":720897,"l":[{"t":298700,"n":"Upper","d":298700,"h":4295265996,"f":33},{"t":298700,"n":"Lower","d":298700,"h":8590233292,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":298700,"h":12885200588,"f":1}],"i":[57278465,63832065,57737217,57409537],"d":233164,"h":298700}; }
                    static get $b() { return $.$spc.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                    static get $fullName() { return `System.HexConverter.Casing`; }
                }, $cls, ($v) => $cls.$_Casing = $v);
            }
            static /*void */ ToBytesBuffer(/*byte*/ value, /*Span<byte>*/ buffer, /*int*/ startingIndex, /*Casing*/ casing)
            {
                /*uint*/ let difference = (((((((value & 240) << 4) >>> 0) + (value & 15)) >>> 0) - 35209) >>> 0);
                /*uint*/ let packedResult = (((((((((-(difference | 0)) >>> 0) & 28784) >>> 4) + difference) >>> 0) + 47545) >>> 0)) | casing;
                buffer.get_Item(((startingIndex + 1) | 0)).$v = $.$cast(packedResult, $.$spc.System.Byte);
                buffer.get_Item(startingIndex).$v = $.$cast((packedResult >>> 8), $.$spc.System.Byte);
            }
            static /*void */ ToCharsBuffer(/*byte*/ value, /*Span<char>*/ buffer, /*int*/ startingIndex, /*Casing*/ casing)
            {
                /*uint*/ let difference = (((((((value & 240) << 4) >>> 0) + (value & 15)) >>> 0) - 35209) >>> 0);
                /*uint*/ let packedResult = (((((((((-(difference | 0)) >>> 0) & 28784) >>> 4) + difference) >>> 0) + 47545) >>> 0)) | casing;
                buffer.get_Item(((startingIndex + 1) | 0)).$v = $.$cast((packedResult & 255), $.$spc.System.Char);
                buffer.get_Item(startingIndex).$v = $.$cast((packedResult >>> 8), $.$spc.System.Char);
            }
            static /*void */ EncodeToUtf8(/*ReadOnlySpan<byte>*/ source, /*Span<byte>*/ utf8Destination, /*Casing*/ casing)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(utf8Destination.Length >= (((source.Length * 2) | 0)), "utf8Destination.Length >= (source.Length * 2)");
                for(/*int*/ let pos = 0; pos < source.Length; pos++)
                {
                    $.$stew.System.HexConverter.ToBytesBuffer(source.get_Item(pos).$v, utf8Destination, ((pos * 2) | 0), casing);
                }
            }
            static /*void */ EncodeToUtf16(/*ReadOnlySpan<byte>*/ source, /*Span<char>*/ destination, /*Casing*/ casing)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(destination.Length >= (((source.Length * 2) | 0)), "destination.Length >= (source.Length * 2)");
                for(/*int*/ let pos = 0; pos < source.Length; pos++)
                {
                    $.$stew.System.HexConverter.ToCharsBuffer(source.get_Item(pos).$v, destination, ((pos * 2) | 0), casing);
                }
            }
            static /*string */ ToString$1(/*ReadOnlySpan<byte>*/ bytes, /*Casing*/ casing)
            {
                /*SpanCasingPair*/ let args = (() =>
                {
                    //new $.$stew.System.HexConverter.SpanCasingPair()
                    const $t1 = $.$stew.System.HexConverter.SpanCasingPair;
                    const $i1 = new $t1();
                    $i1.Bytes = bytes;
                    $i1.Casing = casing;
                    return $i1;
                })();
                return $.$spc.System.String.Create$8($.$stew.System.HexConverter.SpanCasingPair, ((bytes.Length * 2) | 0), args.Clone(), new ($.$spc.System.Buffers.SpanAction$$$($.$spc.System.Char, $.$stew.System.HexConverter.SpanCasingPair))().$ctor($.$stew.System.HexConverter, /*static*/ (/*chars*/ chars, /*args*/ args) =>
                {
                    return $.$stew.System.HexConverter.EncodeToUtf16(args.Bytes, chars, args.Casing);
                }, {"r":65537,"p":[{"n":"chars","p":$.$spc.System.Span$$($.$spc.System.Char).$h},{"n":"args","p":364236}],"n":"","d":233164,"h":0,"f":1048610}));
            }
            static $_SpanCasingPair;
            static get SpanCasingPair()
            {
                let $cls = $.$stew.System.HexConverter;
                return $cls.$_SpanCasingPair ??= $asm.$nstr("$stew.System.HexConverter.SpanCasingPair", ($self) => class SpanCasingPair extends $.$spc.System.ValueType
                {
                    /*ReadOnlySpan<byte>*/ Bytes;
                    /*Casing*/ Casing = 0;
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Bytes = this.Bytes.Clone();
                        copy.Casing = this.Casing;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.Bytes = $.$default($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte));
                        this.Casing = 0;
                    }
                    static $h = 364236;
                    static $z = 9;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":12885266124,"f":1},"s":{"r":0,"d":0,"h":17180233420,"f":1},"n":"Bytes","d":364236,"h":8590298828,"f":1},{"p":298700,"g":{"r":0,"d":0,"h":30065135308,"f":1},"s":{"r":0,"d":0,"h":34360102604,"f":1},"n":"Casing","d":364236,"h":25770168012,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":364236,"h":38655069900,"f":1}],"d":233164,"h":364236}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `System.HexConverter.SpanCasingPair`; }
                }, $cls, ($v) => $cls.$_SpanCasingPair = $v);
            }
            static /*char */ ToCharUpper(/*int*/ value)
            {
                value &= 15;
                value += /*0*/ 48;
                if (value > /*9*/ 57)
                {
                    value += (((/*A*/ 65 - (((/*9*/ 57 + 1) | 0))) | 0));
                }
                return $.$cast(value, $.$spc.System.Char);
            }
            static /*char */ ToCharLower(/*int*/ value)
            {
                value &= 15;
                value += /*0*/ 48;
                if (value > /*9*/ 57)
                {
                    value += (((/*a*/ 97 - (((/*9*/ 57 + 1) | 0))) | 0));
                }
                return $.$cast(value, $.$spc.System.Char);
            }
            static /*bool */ TryDecodeFromUtf8(/*ReadOnlySpan<byte>*/ utf8Source, /*Span<byte>*/ destination, /*out int*/ bytesProcessed)
            {
                return $.$stew.System.HexConverter.TryDecodeFromUtf8_Scalar(utf8Source, destination, bytesProcessed);
            }
            static /*bool */ TryDecodeFromUtf16(/*ReadOnlySpan<char>*/ source, /*Span<byte>*/ destination, /*out int*/ charsProcessed)
            {
                return $.$stew.System.HexConverter.TryDecodeFromUtf16_Scalar(source, destination, charsProcessed);
            }
            static /*bool */ TryDecodeFromUtf8_Scalar(/*ReadOnlySpan<byte>*/ utf8Source, /*Span<byte>*/ destination, /*out int*/ bytesProcessed)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1((utf8Source.Length % 2) === 0, "Un-even number of characters provided");
                $.$spc.System.Diagnostics.Debug.Assert$1(($.trunc(utf8Source.Length / 2)) === destination.Length, "Target buffer not right-sized for provided characters");
                /*int*/ let i = 0;
                /*int*/ let j = 0;
                /*int*/ let byteLo = 0;
                /*int*/ let byteHi = 0;
                while(j < destination.Length)
                {
                    byteLo = $.$stew.System.HexConverter.FromChar(utf8Source.get_Item(((i + 1) | 0)).$v);
                    byteHi = $.$stew.System.HexConverter.FromChar(utf8Source.get_Item(i).$v);
                    if ((byteLo | byteHi) === 255)
                    {
                        break;
                    }
                    destination.get_Item(j++).$v = $.$cast(((byteHi << 4) | byteLo), $.$spc.System.Byte);
                    i += 2;
                }
                if (byteLo === 255)
                {
                    i++;
                }
                bytesProcessed.$v = i;
                return (byteLo | byteHi) !== 255;
            }
            static /*bool */ TryDecodeFromUtf16_Scalar(/*ReadOnlySpan<char>*/ source, /*Span<byte>*/ destination, /*out int*/ charsProcessed)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1((source.Length % 2) === 0, "Un-even number of characters provided");
                $.$spc.System.Diagnostics.Debug.Assert$1(($.trunc(source.Length / 2)) === destination.Length, "Target buffer not right-sized for provided characters");
                /*int*/ let i = 0;
                /*int*/ let j = 0;
                /*int*/ let byteLo = 0;
                /*int*/ let byteHi = 0;
                while(j < destination.Length)
                {
                    byteLo = $.$stew.System.HexConverter.FromChar(source.get_Item(((i + 1) | 0)).$v);
                    byteHi = $.$stew.System.HexConverter.FromChar(source.get_Item(i).$v);
                    if ((byteLo | byteHi) === 255)
                    {
                        break;
                    }
                    destination.get_Item(j++).$v = $.$cast(((byteHi << 4) | byteLo), $.$spc.System.Byte);
                    i += 2;
                }
                if (byteLo === 255)
                {
                    i++;
                }
                charsProcessed.$v = i;
                return (byteLo | byteHi) !== 255;
            }
            static /*int */ FromChar(/*int*/ c)
            {
                return (c >= $.$stew.System.HexConverter.CharToHexLookup.Length) ? 255 : $.$stew.System.HexConverter.CharToHexLookup.get_Item(c).$v;
            }
            static /*int */ FromUpperChar(/*int*/ c)
            {
                return (c > 71) ? 255 : $.$stew.System.HexConverter.CharToHexLookup.get_Item(c).$v;
            }
            static /*int */ FromLowerChar(/*int*/ c)
            {
                if (((((c - /*0*/ 48) | 0)) >>> 0) <= (/*9*/ 57 - /*0*/ 48))
                {
                    return ((c - /*0*/ 48) | 0);
                }
                if (((((c - /*a*/ 97) | 0)) >>> 0) <= (/*f*/ 102 - /*a*/ 97))
                {
                    return ((((c - /*a*/ 97) | 0) + 10) | 0);
                }
                return 255;
            }
            static /*bool */ IsHexChar(/*int*/ c)
            {
                //if (IntPtr.Size == 8) { ... }
                return $.$stew.System.HexConverter.FromChar(c) !== 255;
            }
            static /*bool */ IsHexUpperChar(/*int*/ c)
            {
                return (((((c - /*0*/ 48) | 0)) >>> 0) <= 9) || (((((c - /*A*/ 65) | 0)) >>> 0) <= (/*F*/ 70 - /*A*/ 65));
            }
            static /*bool */ IsHexLowerChar(/*int*/ c)
            {
                return (((((c - /*0*/ 48) | 0)) >>> 0) <= 9) || (((((c - /*a*/ 97) | 0)) >>> 0) <= (/*f*/ 102 - /*a*/ 97));
            }
            static /*ReadOnlySpan<byte> */ get CharToHexLookup()
            {
                return this.$cacheCharToHexLookup ??= new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$2([ 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 255, 255, 255, 255, 255, 255, 255, 10, 11, 12, 13, 14, 15, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 10, 11, 12, 13, 14, 15, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255 ]);
            }
            static $h = 233164;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":90194546380,"f":33},"n":"CharToHexLookup","d":233164,"h":85899579084,"f":33}],"m":[{"r":65537,"p":[{"n":"value","p":393217},{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"startingIndex","p":655361,"f":65,"v":0},{"n":"casing","p":298700,"f":65,"v":0}],"n":"ToBytesBuffer","d":233164,"h":8590167756,"f":33},{"r":65537,"p":[{"n":"value","p":393217},{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Char).$h},{"n":"startingIndex","p":655361,"f":65,"v":0},{"n":"casing","p":298700,"f":65,"v":0}],"n":"ToCharsBuffer","d":233164,"h":12885135052,"f":33},{"r":65537,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"utf8Destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"casing","p":298700,"f":65,"v":0}],"n":"EncodeToUtf8","d":233164,"h":17180102348,"f":33},{"r":65537,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Char).$h},{"n":"casing","p":298700,"f":65,"v":0}],"n":"EncodeToUtf16","d":233164,"h":21475069644,"f":33},{"r":1310721,"p":[{"n":"bytes","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"casing","p":298700,"f":65,"v":0}],"n":"ToString","o":"@$1","d":233164,"h":25770036940,"f":33},{"r":458753,"p":[{"n":"value","p":655361}],"n":"ToCharUpper","d":233164,"h":34359971532,"f":33},{"r":458753,"p":[{"n":"value","p":655361}],"n":"ToCharLower","d":233164,"h":38654938828,"f":33},{"r":262145,"p":[{"n":"utf8Source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"bytesProcessed","p":655361,"f":2}],"n":"TryDecodeFromUtf8","d":233164,"h":42949906124,"f":33},{"r":262145,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"charsProcessed","p":655361,"f":2}],"n":"TryDecodeFromUtf16","d":233164,"h":47244873420,"f":33},{"r":262145,"p":[{"n":"utf8Source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"bytesProcessed","p":655361,"f":2}],"n":"TryDecodeFromUtf8_Scalar","d":233164,"h":51539840716,"f":34},{"r":262145,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"charsProcessed","p":655361,"f":2}],"n":"TryDecodeFromUtf16_Scalar","d":233164,"h":55834808012,"f":34},{"r":655361,"p":[{"n":"c","p":655361}],"n":"FromChar","d":233164,"h":60129775308,"f":33},{"r":655361,"p":[{"n":"c","p":655361}],"n":"FromUpperChar","d":233164,"h":64424742604,"f":33},{"r":655361,"p":[{"n":"c","p":655361}],"n":"FromLowerChar","d":233164,"h":68719709900,"f":33},{"r":262145,"p":[{"n":"c","p":655361}],"n":"IsHexChar","d":233164,"h":73014677196,"f":33},{"r":262145,"p":[{"n":"c","p":655361}],"n":"IsHexUpperChar","d":233164,"h":77309644492,"f":33},{"r":262145,"p":[{"n":"c","p":655361}],"n":"IsHexLowerChar","d":233164,"h":81604611788,"f":33}],"j":[298700,364236],"h":233164}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.HexConverter`; }
        });
        
        $asm.$cls("$stew.System.ThrowHelper", ($self) => class ThrowHelper
        {
            static /*void */ ThrowArgumentOutOfRangeException()
            {
                throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$15();
            }
            static /*void */ ThrowArgumentException_DestinationTooShort()
            {
                throw new $.$spc.System.ArgumentException().$ctor$13($.$stew.System.SR.Argument_DestinationTooShort, "destination");
            }
            static /*void */ ThrowArgumentException_CannotExtractScalar(/*ExceptionArgument*/ argument)
            {
                throw $.$stew.System.ThrowHelper.GetArgumentException(0/*ExceptionResource.Argument_CannotExtractScalar*/, argument);
            }
            static /*void */ ThrowArgumentOutOfRange_IndexMustBeLessException()
            {
                throw $.$stew.System.ThrowHelper.GetArgumentOutOfRangeException(2/*ExceptionArgument.index*/, 1/*ExceptionResource.ArgumentOutOfRange_IndexMustBeLess*/);
            }
            static /*void */ ThrowArgumentNullException(/*ExceptionArgument*/ argument)
            {
                throw new $.$spc.System.ArgumentNullException().$ctor$16($.$stew.System.ThrowHelper.GetArgumentName(argument));
            }
            static /*void */ ThrowArgumentOutOfRangeException$1(/*ExceptionArgument*/ argument)
            {
                throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16($.$stew.System.ThrowHelper.GetArgumentName(argument));
            }
            static /*ArgumentOutOfRangeException */ GetArgumentOutOfRangeException(/*ExceptionArgument*/ argument, /*ExceptionResource*/ resource)
            {
                return new $.$spc.System.ArgumentOutOfRangeException().$ctor$17($.$stew.System.ThrowHelper.GetArgumentName(argument), $.$stew.System.ThrowHelper.GetResourceString(resource));
            }
            static /*ArgumentException */ GetArgumentException(/*ExceptionResource*/ resource, /*ExceptionArgument*/ argument)
            {
                return new $.$spc.System.ArgumentException().$ctor$13($.$stew.System.ThrowHelper.GetResourceString(resource), $.$stew.System.ThrowHelper.GetArgumentName(argument));
            }
            static /*string */ GetArgumentName(/*ExceptionArgument*/ argument)
            {
                switch(argument)
                {
                    case 0/*ExceptionArgument.ch*/:
                    return "ch";
                    case 1/*ExceptionArgument.culture*/:
                    return "culture";
                    case 2/*ExceptionArgument.index*/:
                    return "index";
                    case 3/*ExceptionArgument.input*/:
                    return "input";
                    case 4/*ExceptionArgument.value*/:
                    return "value";
                    default:
                    $.$spc.System.Diagnostics.Debug.Fail("The enum value is not defined, please check the ExceptionArgument Enum.");
                    return "";
                }
            }
            static /*string */ GetResourceString(/*ExceptionResource*/ resource)
            {
                switch(resource)
                {
                    case 1/*ExceptionResource.ArgumentOutOfRange_IndexMustBeLess*/:
                    return $.$stew.System.SR.ArgumentOutOfRange_IndexMustBeLess;
                    case 0/*ExceptionResource.Argument_CannotExtractScalar*/:
                    return $.$stew.System.SR.Argument_CannotExtractScalar;
                    default:
                    $.$spc.System.Diagnostics.Debug.Fail("The enum value is not defined, please check the ExceptionResource Enum.");
                    return "";
                }
            }
            static $h = 2133708;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"n":"ThrowArgumentOutOfRangeException","d":2133708,"h":4297101004,"f":40},{"r":65537,"n":"ThrowArgumentException_DestinationTooShort","d":2133708,"h":8592068300,"f":40},{"r":65537,"p":[{"n":"argument","p":102092}],"n":"ThrowArgumentException_CannotExtractScalar","d":2133708,"h":12887035596,"f":40},{"r":65537,"n":"ThrowArgumentOutOfRange_IndexMustBeLessException","d":2133708,"h":17182002892,"f":40},{"r":65537,"p":[{"n":"argument","p":102092}],"n":"ThrowArgumentNullException","d":2133708,"h":21476970188,"f":40},{"r":65537,"p":[{"n":"argument","p":102092}],"n":"ThrowArgumentOutOfRangeException","o":"@$1","d":2133708,"h":25771937484,"f":40},{"r":13565953,"p":[{"n":"argument","p":102092},{"n":"resource","p":167628}],"n":"GetArgumentOutOfRangeException","d":2133708,"h":30066904780,"f":34},{"r":13434881,"p":[{"n":"resource","p":167628},{"n":"argument","p":102092}],"n":"GetArgumentException","d":2133708,"h":34361872076,"f":34},{"r":1310721,"p":[{"n":"argument","p":102092}],"n":"GetArgumentName","d":2133708,"h":38656839372,"f":34},{"r":1310721,"p":[{"n":"resource","p":167628}],"n":"GetResourceString","d":2133708,"h":42951806668,"f":34}],"h":2133708}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.ThrowHelper`; }
        });
        
        $asm.$str("$stew.System.Text.Encodings.Web.AsciiByteMap", ($self) => class AsciiByteMap extends $.$spc.System.ValueType
        {
            /*int*/ static BufferSize = 128;
            /*byte[128]*/  get Buffer() { return this.$getField(0, 0x80000000|128); }
            /*byte[128]*/  set Buffer(value) { this.$setField(0, 0x80000000|128, value); }
            /*void */ InsertAsciiChar(/*char*/ key, /*byte*/ value)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(key < 128/*BufferSize*/, "key < BufferSize");
                $.$spc.System.Diagnostics.Debug.Assert$1(value !== 0, "value != 0");
                if (key < 128/*BufferSize*/)
                {
                    this.Buffer[key] = value;
                }
            }
            /*bool */ TryLookup(/*Rune*/ key, /*out byte*/ value)
            {
                if (key.IsAscii)
                {
                    /*byte*/ let entry = this.Buffer[(key.Value >>> 0)];
                    if (entry !== 0)
                    {
                        value.$v = entry;
                        return true;
                    }
                }
                value.$v = 0;
                return false;
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                //InlineArray(128)
                copy.Buffer = [...this.Buffer];
                $.$spc.System.Array.CopyMetadata(copy.Buffer, this.Buffer)
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //FixedSizeArray(byte*, 128)
                let $t1 = this.Buffer;
                $.$spc.System.Array.AddMetadata($t1, $.$spc.System.Byte.$type, null, null);
                for (let $i = 0; $i < 128; $i++)
                {
                    $t1[$i] = 0;
                }
            }
            static $h = 626380;
            static $z = 128;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"m":[{"r":65537,"p":[{"n":"key","p":458753},{"n":"value","p":393217}],"n":"InsertAsciiChar","d":626380,"h":12885528268,"f":8},{"r":262145,"p":[{"n":"key","p":122748929},{"n":"value","p":393217,"f":2}],"n":"TryLookup","d":626380,"h":17180495564,"f":8}],"l":[{"t":655361,"n":"BufferSize","d":626380,"h":4295593676,"f":34},{"t":0,"n":"Buffer","d":626380,"h":8590560972,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":626380,"h":21475462860,"f":1}],"h":626380}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Text.Encodings.Web.AsciiByteMap`; }
        });
        
        $asm.$str("$stew.System.Text.Encodings.Web.AllowedBmpCodePointsBitmap", ($self) => class AllowedBmpCodePointsBitmap extends $.$spc.System.ValueType
        {
            /*int*/ static BitmapLengthInDWords = 2048;
            /*uint[2048]*/  get Bitmap() { return this.$getField(0, 0x80000000|2048); }
            /*uint[2048]*/  set Bitmap(value) { this.$setField(0, 0x80000000|2048, value); }
            /*void */ AllowChar(/*char*/ value)
            {
                /*nuint*/ let index;
                /*int*/ let offset;
                $.$stew.System.Text.Encodings.Web.AllowedBmpCodePointsBitmap._GetIndexAndOffset(value, $.$ref(() => index, ($v) => index = $v, $.$spc.System.UIntPtr), $.$ref(() => offset, ($v) => offset = $v, $.$spc.System.Int32));
                this.Bitmap[index] |= (1 << offset) >>> 0;
            }
            /*void */ ForbidChar(/*char*/ value)
            {
                /*nuint*/ let index;
                /*int*/ let offset;
                $.$stew.System.Text.Encodings.Web.AllowedBmpCodePointsBitmap._GetIndexAndOffset(value, $.$ref(() => index, ($v) => index = $v, $.$spc.System.UIntPtr), $.$ref(() => offset, ($v) => offset = $v, $.$spc.System.Int32));
                this.Bitmap[index] &= ~((1 << offset) >>> 0);
            }
            /*void */ ForbidHtmlCharacters()
            {
                this.ForbidChar(/*<*/ 60);
                this.ForbidChar(/*>*/ 62);
                this.ForbidChar(/*&*/ 38);
                this.ForbidChar(/*'*/ 39);
                this.ForbidChar(/*\"*/ 34);
                this.ForbidChar(/*+*/ 43);
            }
            /*void */ ForbidUndefinedCharacters()
            {
                /*fixed*/ 
                {
                    /*uint**/ let pBitmap = this.Bitmap;
                    /*ReadOnlySpan<byte>*/ let definedCharsBitmapAsLittleEndian = $.$stew.System.Text.Unicode.UnicodeHelpers.GetDefinedBmpCodePointsBitmapLittleEndian();
                    /*Span<uint>*/ let thisAllowedCharactersBitmap = new ($.$spc.System.Span$$($.$spc.System.UInt32))().$ctor$4(pBitmap, 2048/*BitmapLengthInDWords*/);
                    $.$spc.System.Diagnostics.Debug.Assert$1(definedCharsBitmapAsLittleEndian.Length === ((thisAllowedCharactersBitmap.Length * $.$spc.System.UInt32.$z) | 0), "definedCharsBitmapAsLittleEndian.Length == thisAllowedCharactersBitmap.Length * sizeof(uint)");
                    //if (Vector.IsHardwareAccelerated && BitConverter.IsLittleEndian) { ... }
                    for(/*int*/ let i = 0; i < thisAllowedCharactersBitmap.Length; i++)
                    {
                        thisAllowedCharactersBitmap.get_Item(i).$v &= $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt32LittleEndian(definedCharsBitmapAsLittleEndian.Slice(((i * $.$spc.System.UInt32.$z) | 0)));
                    }
                }
            }
            /*bool */ IsCharAllowed(/*char*/ value)
            {
                /*nuint*/ let index;
                /*int*/ let offset;
                $.$stew.System.Text.Encodings.Web.AllowedBmpCodePointsBitmap._GetIndexAndOffset(value, $.$ref(() => index, ($v) => index = $v, $.$spc.System.UIntPtr), $.$ref(() => offset, ($v) => offset = $v, $.$spc.System.Int32));
                if ((this.Bitmap[index] & ((1 << offset) >>> 0)) !== 0)
                {
                    return true;
                }
                else 
                {
                    return false;
                }
            }
            /*bool */ IsCodePointAllowed(/*uint*/ value)
            {
                if (!$.$stew.System.Text.UnicodeUtility.IsBmpCodePoint(value))
                {
                    return false;
                }
                /*nuint*/ let index;
                /*int*/ let offset;
                $.$stew.System.Text.Encodings.Web.AllowedBmpCodePointsBitmap._GetIndexAndOffset(value, $.$ref(() => index, ($v) => index = $v, $.$spc.System.UIntPtr), $.$ref(() => offset, ($v) => offset = $v, $.$spc.System.Int32));
                if ((this.Bitmap[index] & ((1 << offset) >>> 0)) !== 0)
                {
                    return true;
                }
                else 
                {
                    return false;
                }
            }
            static /*void */ _GetIndexAndOffset(/*uint*/ value, /*out nuint*/ index, /*out int*/ offset)
            {
                $.$stew.System.Text.UnicodeDebug.AssertIsBmpCodePoint(value);
                index.$v = value >>> 5;
                offset.$v = (value | 0) & 31;
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                //InlineArray(2048)
                copy.Bitmap = [...this.Bitmap];
                $.$spc.System.Array.CopyMetadata(copy.Bitmap, this.Bitmap)
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //FixedSizeArray(uint*, 2048)
                let $t1 = this.Bitmap;
                $.$spc.System.Array.AddMetadata($t1, $.$spc.System.UInt32.$type, null, null);
                for (let $i = 0; $i < 2048; $i++)
                {
                    $t1[$i] = 0;
                }
            }
            static $h = 560844;
            static $z = 2048;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"m":[{"r":65537,"p":[{"n":"value","p":458753}],"n":"AllowChar","d":560844,"h":12885462732,"f":1},{"r":65537,"p":[{"n":"value","p":458753}],"n":"ForbidChar","d":560844,"h":17180430028,"f":1},{"r":65537,"n":"ForbidHtmlCharacters","d":560844,"h":21475397324,"f":1},{"r":65537,"n":"ForbidUndefinedCharacters","d":560844,"h":25770364620,"f":1},{"r":262145,"p":[{"n":"value","p":458753}],"n":"IsCharAllowed","d":560844,"h":30065331916,"f":1},{"r":262145,"p":[{"n":"value","p":720897}],"n":"IsCodePointAllowed","d":560844,"h":34360299212,"f":1},{"r":65537,"p":[{"n":"value","p":720897},{"n":"index","p":851969,"f":2},{"n":"offset","p":655361,"f":2}],"n":"_GetIndexAndOffset","d":560844,"h":38655266508,"f":34}],"l":[{"t":655361,"n":"BitmapLengthInDWords","d":560844,"h":4295528140,"f":34},{"t":0,"n":"Bitmap","d":560844,"h":8590495436,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":560844,"h":42950233804,"f":1}],"h":560844}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Text.Encodings.Web.AllowedBmpCodePointsBitmap`; }
        });
        
        $asm.$str("$stew.System.Text.ValueStringBuilder", ($self) => class ValueStringBuilder extends $.$spc.System.ValueType
        {
            /*char[]?*/  get _arrayToReturnToPool() { return this.$getField(0, 4); }
            /*char[]?*/  set _arrayToReturnToPool(value) { this.$setField(0, 4, value); }
            /*Span<char>*/  get _chars() { return this.$getField(4, 6); }
            /*Span<char>*/  set _chars(value) { this.$setField(4, 6, value); }
            /*int*/  get _pos() { return this.$getField(10, 4); }
            /*int*/  set _pos(value) { this.$setField(10, 4, value); }
            $ctor$2(/*Span<char>*/ initialBuffer)
            {
                super.$ctor$1();
                {
                    this._arrayToReturnToPool = null;
                    this._chars = initialBuffer;
                    this._pos = 0;
                }
                return this;
            }
            $ctor$3(/*int*/ initialCapacity)
            {
                super.$ctor$1();
                {
                    this._arrayToReturnToPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Char).Shared.Rent(initialCapacity);
                    this._chars = $.$spc.System.Span$$($.$spc.System.Char).op_Implicit(this._arrayToReturnToPool);
                    this._pos = 0;
                }
                return this;
            }
            /*int */ get Length()
            {
                return this._pos;
            }
            /*int */ set Length(value)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(value >= 0, "value >= 0");
                $.$spc.System.Diagnostics.Debug.Assert$1(value <= this._chars.Length, "value <= _chars.Length");
                this._pos = value;
            }
            /*int */ get Capacity()
            {
                return this._chars.Length;
            }
            /*void */ EnsureCapacity(/*int*/ capacity)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(capacity >= 0, "capacity >= 0");
                if ((capacity >>> 0) > (this._chars.Length >>> 0))
                {
                    this.Grow(((capacity - this._pos) | 0));
                }
            }
            /*ref char */ GetPinnableReference()
            {
                return $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference($.$spc.System.Char, this._chars);
            }
            /*ref char */ GetPinnableReference$1(/*bool*/ terminate)
            {
                if (terminate)
                {
                    this.EnsureCapacity(((this.Length + 1) | 0));
                    this._chars.get_Item(this.Length).$v = /*\u0000*/ 0;
                }
                return $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference($.$spc.System.Char, this._chars);
            }
            /*ref char*/ get_Item(/*int*/ index)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(index < this._pos, "index < _pos");
                return this._chars.get_Item(index);
            }
            static/*conventional*/ /*string */ ToString()
            {
                /*string*/ let s = $.$spc.System.Span$$($.$spc.System.Char).ToString.call(this._chars.Slice$1(0, this._pos));
                this.Dispose();
                return s;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$stew.System.Text.ValueStringBuilder.ToString.apply(this, arguments); }
            /*Span<char> */ get RawChars()
            {
                return this._chars;
            }
            /*ReadOnlySpan<char> */ AsSpan(/*bool*/ terminate)
            {
                if (terminate)
                {
                    this.EnsureCapacity(((this.Length + 1) | 0));
                    this._chars.get_Item(this.Length).$v = /*\u0000*/ 0;
                }
                return $.$spc.System.Span$$($.$spc.System.Char).op_Implicit$2(this._chars.Slice$1(0, this._pos));
            }
            /*ReadOnlySpan<char> */ AsSpan$1()
            {
                return $.$spc.System.Span$$($.$spc.System.Char).op_Implicit$2(this._chars.Slice$1(0, this._pos));
            }
            /*ReadOnlySpan<char> */ AsSpan$2(/*int*/ start)
            {
                return $.$spc.System.Span$$($.$spc.System.Char).op_Implicit$2(this._chars.Slice$1(start, ((this._pos - start) | 0)));
            }
            /*ReadOnlySpan<char> */ AsSpan$3(/*int*/ start, /*int*/ length)
            {
                return $.$spc.System.Span$$($.$spc.System.Char).op_Implicit$2(this._chars.Slice$1(start, length));
            }
            /*bool */ TryCopyTo(/*Span<char>*/ destination, /*out int*/ charsWritten)
            {
                if (this._chars.Slice$1(0, this._pos).TryCopyTo(destination))
                {
                    charsWritten.$v = this._pos;
                    this.Dispose();
                    return true;
                }
                else 
                {
                    charsWritten.$v = 0;
                    this.Dispose();
                    return false;
                }
            }
            /*void */ Insert(/*int*/ index, /*char*/ value, /*int*/ count)
            {
                if (this._pos > ((this._chars.Length - count) | 0))
                {
                    this.Grow(count);
                }
                /*int*/ let remaining = ((this._pos - index) | 0);
                this._chars.Slice$1(index, remaining).CopyTo(this._chars.Slice(((index + count) | 0)));
                this._chars.Slice$1(index, count).Fill(value);
                this._pos += count;
            }
            /*void */ Insert$1(/*int*/ index, /*string?*/ s)
            {
                if ($.$spc.System.String.op_Equality(s, null))
                {
                    return;
                }
                /*int*/ let count = s.length;
                if (this._pos > (((this._chars.Length - count) | 0)))
                {
                    this.Grow(count);
                }
                /*int*/ let remaining = ((this._pos - index) | 0);
                this._chars.Slice$1(index, remaining).CopyTo(this._chars.Slice(((index + count) | 0)));
                $.$spc.System.String.CopyTo$1.call(s, this._chars.Slice(index));
                this._pos += count;
            }
            /*void */ Append(/*char*/ c)
            {
                /*int*/ let pos = this._pos;
                /*Span<char>*/ let chars = this._chars;
                if ((pos >>> 0) < (chars.Length >>> 0))
                {
                    chars.get_Item(pos).$v = c;
                    this._pos = ((pos + 1) | 0);
                }
                else 
                {
                    this.GrowAndAppend(c);
                }
            }
            /*void */ Append$1(/*string?*/ s)
            {
                if ($.$spc.System.String.op_Equality(s, null))
                {
                    return;
                }
                /*int*/ let pos = this._pos;
                if (s.length === 1 && (pos >>> 0) < (this._chars.Length >>> 0))
                {
                    this._chars.get_Item(pos).$v = $.$spc.System.String.get_Chars.call(s, 0);
                    this._pos = ((pos + 1) | 0);
                }
                else 
                {
                    this.AppendSlow(s);
                }
            }
            /*void */ AppendSlow(/*string*/ s)
            {
                /*int*/ let pos = this._pos;
                if (pos > ((this._chars.Length - s.length) | 0))
                {
                    this.Grow(s.length);
                }
                $.$spc.System.String.CopyTo$1.call(s, this._chars.Slice(pos));
                this._pos += s.length;
            }
            /*void */ Append$2(/*char*/ c, /*int*/ count)
            {
                if (this._pos > ((this._chars.Length - count) | 0))
                {
                    this.Grow(count);
                }
                /*Span<char>*/ let dst = this._chars.Slice$1(this._pos, count);
                for(/*int*/ let i = 0; i < dst.Length; i++)
                {
                    dst.get_Item(i).$v = c;
                }
                this._pos += count;
            }
            /*void */ Append$3(/*scoped ReadOnlySpan<char>*/ value)
            {
                /*int*/ let pos = this._pos;
                if (pos > ((this._chars.Length - value.Length) | 0))
                {
                    this.Grow(value.Length);
                }
                value.CopyTo(this._chars.Slice(this._pos));
                this._pos += value.Length;
            }
            /*Span<char> */ AppendSpan(/*int*/ length)
            {
                /*int*/ let origPos = this._pos;
                if (origPos > ((this._chars.Length - length) | 0))
                {
                    this.Grow(length);
                }
                this._pos = ((origPos + length) | 0);
                return this._chars.Slice$1(origPos, length);
            }
            /*void */ GrowAndAppend(/*char*/ c)
            {
                this.Grow(1);
                this.Append(c);
            }
            /*void */ Grow(/*int*/ additionalCapacityBeyondPos)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(additionalCapacityBeyondPos > 0, "additionalCapacityBeyondPos > 0");
                $.$spc.System.Diagnostics.Debug.Assert$1(this._pos > ((this._chars.Length - additionalCapacityBeyondPos) | 0), "Grow called incorrectly, no resize is needed.");
                /*uint*/ let ArrayMaxLength = 2147483591;
                /*int*/ let newCapacity = ($.$spc.System.Math.Max$10(((((this._pos + additionalCapacityBeyondPos) | 0)) >>> 0), $.$spc.System.Math.Min$10((((this._chars.Length >>> 0) * 2) >>> 0), ArrayMaxLength)) | 0);
                /*char[]*/ let poolArray = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Char).Shared.Rent(newCapacity);
                this._chars.Slice$1(0, this._pos).CopyTo($.$spc.System.Span$$($.$spc.System.Char).op_Implicit(poolArray));
                /*char[]?*/ let toReturn = this._arrayToReturnToPool;
                this._chars = $.$spc.System.Span$$($.$spc.System.Char).op_Implicit(this._arrayToReturnToPool = poolArray);
                if (toReturn !== null)
                {
                    $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Char).Shared.Return(toReturn, false);
                }
            }
            /*void */ Dispose()
            {
                /*char[]?*/ let toReturn = this._arrayToReturnToPool;
                new $.$stew.System.Text.ValueStringBuilder().Clone(this);
                if (toReturn !== null)
                {
                    $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Char).Shared.Return(toReturn, false);
                }
            }
            //default value type constructor
            $ctor$4()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._arrayToReturnToPool = this._arrayToReturnToPool;
                copy._chars = this._chars.Clone();
                copy._pos = this._pos;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._arrayToReturnToPool = null;
                this._chars = $.$default($.$spc.System.Span$$($.$spc.System.Char));
                this._pos = 0;
            }
            static $h = 2068172;
            static $z = 14;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":655361,"g":{"r":0,"d":0,"h":30066839244,"f":1},"s":{"r":0,"d":0,"h":34361806540,"f":1},"n":"Length","d":2068172,"h":25771871948,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":42951741132,"f":1},"n":"Capacity","d":2068172,"h":38656773836,"f":1},{"p":458753,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":64426577612,"f":1},"n":"Item","o":"@$2","d":2068172,"h":60131610316,"f":1},{"p":$.$spc.System.Span$$($.$spc.System.Char).$h,"g":{"r":0,"d":0,"h":77311479500,"f":1},"n":"RawChars","d":2068172,"h":73016512204,"f":1}],"m":[{"r":65537,"p":[{"n":"capacity","p":655361}],"n":"EnsureCapacity","d":2068172,"h":47246708428,"f":1},{"r":458753,"n":"GetPinnableReference","d":2068172,"h":51541675724,"f":1},{"r":458753,"p":[{"n":"terminate","p":262145}],"n":"GetPinnableReference","o":"@$1","d":2068172,"h":55836643020,"f":1},{"r":1310721,"n":"ToString","d":2068172,"h":68721544908,"f":32769},{"r":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h,"p":[{"n":"terminate","p":262145}],"n":"AsSpan","d":2068172,"h":81606446796,"f":1},{"r":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h,"n":"AsSpan","o":"@$1","d":2068172,"h":85901414092,"f":1},{"r":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h,"p":[{"n":"start","p":655361}],"n":"AsSpan","o":"@$2","d":2068172,"h":90196381388,"f":1},{"r":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h,"p":[{"n":"start","p":655361},{"n":"length","p":655361}],"n":"AsSpan","o":"@$3","d":2068172,"h":94491348684,"f":1},{"r":262145,"p":[{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Char).$h},{"n":"charsWritten","p":655361,"f":2}],"n":"TryCopyTo","d":2068172,"h":98786315980,"f":1},{"r":65537,"p":[{"n":"index","p":655361},{"n":"value","p":458753},{"n":"count","p":655361}],"n":"Insert","d":2068172,"h":103081283276,"f":1},{"r":65537,"p":[{"n":"index","p":655361},{"n":"s","p":1310721}],"n":"Insert","o":"@$1","d":2068172,"h":107376250572,"f":1},{"r":65537,"p":[{"n":"c","p":458753}],"n":"Append","d":2068172,"h":111671217868,"f":1},{"r":65537,"p":[{"n":"s","p":1310721}],"n":"Append","o":"@$1","d":2068172,"h":115966185164,"f":1},{"r":65537,"p":[{"n":"s","p":1310721}],"n":"AppendSlow","d":2068172,"h":120261152460,"f":2},{"r":65537,"p":[{"n":"c","p":458753},{"n":"count","p":655361}],"n":"Append","o":"@$2","d":2068172,"h":124556119756,"f":1},{"r":65537,"p":[{"n":"value","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h}],"n":"Append","o":"@$3","d":2068172,"h":128851087052,"f":1},{"r":$.$spc.System.Span$$($.$spc.System.Char).$h,"p":[{"n":"length","p":655361}],"n":"AppendSpan","d":2068172,"h":133146054348,"f":1},{"r":65537,"p":[{"n":"c","p":458753}],"n":"GrowAndAppend","d":2068172,"h":137441021644,"f":2},{"r":65537,"p":[{"n":"additionalCapacityBeyondPos","p":655361}],"n":"Grow","d":2068172,"h":141735988940,"f":2},{"r":65537,"n":"Dispose","d":2068172,"h":146030956236,"f":1}],"l":[{"t":0,"n":"_arrayToReturnToPool","d":2068172,"h":4297035468,"f":2},{"t":$.$spc.System.Span$$($.$spc.System.Char).$h,"n":"_chars","d":2068172,"h":8592002764,"f":2},{"t":655361,"n":"_pos","d":2068172,"h":12886970060,"f":2}],"c":[{"p":[{"n":"initialBuffer","p":$.$spc.System.Span$$($.$spc.System.Char).$h}],"n":".ctor","o":"$ctor$2","d":2068172,"h":17181937356,"f":1},{"p":[{"n":"initialCapacity","p":655361}],"n":".ctor","o":"$ctor$3","d":2068172,"h":21476904652,"f":1},{"n":".ctor","o":"$ctor$4","d":2068172,"h":150325923532,"f":1}],"h":2068172}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Text.ValueStringBuilder`; }
        });
        
        $asm.$cls("$stew.System.Text.Encodings.Web.DefaultHtmlEncoder", ($self) => class DefaultHtmlEncoder extends $.$stew.System.Text.Encodings.Web.HtmlEncoder
        {
            /*DefaultHtmlEncoder*/ static BasicLatinSingleton = null;
            /*OptimizedInboxTextEncoder*/ _innerEncoder = null;
            $ctor$3(/*TextEncoderSettings*/ settings)
            {
                super.$ctor$2();
                {
                    if (settings === null)
                    {
                        $.$stew.System.Text.Encodings.Web.ThrowHelper.ThrowArgumentNullException(1/*ExceptionArgument.settings*/);
                    }
                    this._innerEncoder = new $.$stew.System.Text.Encodings.Web.OptimizedInboxTextEncoder().$ctor$1($.$stew.System.Text.Encodings.Web.DefaultHtmlEncoder.EscaperImplementation.Singleton, settings.GetAllowedCodePointsBitmap(), true, new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Char))());
                }
                return this;
            }
            /*int */ get MaxOutputCharactersPerInputCharacter()
            {
                return 8;
            }
            /*OperationStatus */ EncodeCore(/*ReadOnlySpan<char>*/ source, /*Span<char>*/ destination, /*out int*/ charsConsumed, /*out int*/ charsWritten, /*bool*/ isFinalBlock)
            {
                return this._innerEncoder.Encode(source, destination, charsConsumed, charsWritten, isFinalBlock);
            }
            /*OperationStatus */ EncodeUtf8Core(/*ReadOnlySpan<byte>*/ utf8Source, /*Span<byte>*/ utf8Destination, /*out int*/ bytesConsumed, /*out int*/ bytesWritten, /*bool*/ isFinalBlock)
            {
                return this._innerEncoder.EncodeUtf8(utf8Source, utf8Destination, bytesConsumed, bytesWritten, isFinalBlock);
            }
            /*int */ FindFirstCharacterToEncode$1(/*ReadOnlySpan<char>*/ text)
            {
                return this._innerEncoder.GetIndexOfFirstCharToEncode(text);
            }
            /*int */ FindFirstCharacterToEncode(/*char**/ text, /*int*/ textLength)
            {
                return this._innerEncoder.FindFirstCharacterToEncode(text, textLength);
            }
            /*int */ FindFirstCharacterToEncodeUtf8(/*ReadOnlySpan<byte>*/ utf8Text)
            {
                return this._innerEncoder.GetIndexOfFirstByteToEncode(utf8Text);
            }
            /*bool */ TryEncodeUnicodeScalar(/*int*/ unicodeScalar, /*char**/ buffer, /*int*/ bufferLength, /*out int*/ numberOfCharactersWritten)
            {
                return this._innerEncoder.TryEncodeUnicodeScalar(unicodeScalar, buffer, bufferLength, numberOfCharactersWritten);
            }
            /*bool */ WillEncode(/*int*/ unicodeScalar)
            {
                return !this._innerEncoder.IsScalarValueAllowed(new $.$spc.System.Text.Rune().$ctor$4(unicodeScalar));
            }
            static $_EscaperImplementation;
            static get EscaperImplementation()
            {
                let $cls = $.$stew.System.Text.Encodings.Web.DefaultHtmlEncoder;
                return $cls.$_EscaperImplementation ??= $asm.$ncls("$stew.System.Text.Encodings.Web.DefaultHtmlEncoder.EscaperImplementation", ($self) => class EscaperImplementation extends $.$stew.System.Text.Encodings.Web.ScalarEscaperBase
                {
                    /*EscaperImplementation*/ static Singleton = null;
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    /*int */ EncodeUtf8(/*Rune*/ value, /*Span<byte>*/ destination)
                    {
                        let $gotoJumpState1 = 0;
                        $gotoJumpStart1: while(true)
                        {
                            switch($gotoJumpState1)
                            {
                                case 0:
                                {
                                    if (value.Value === /*<*/ 60)
                                    {
                                        if (!new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$2([38, 108, 116, 59]).TryCopyTo(destination))
                                        {
                                            $gotoJumpState1 = 1; /*goto OutOfSpace*/
                                            continue $gotoJumpStart1;
                                        }
                                        return 4;
                                    }
                                    else if (value.Value === /*>*/ 62)
                                    {
                                        if (!new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$2([38, 103, 116, 59]).TryCopyTo(destination))
                                        {
                                            $gotoJumpState1 = 1; /*goto OutOfSpace*/
                                            continue $gotoJumpStart1;
                                        }
                                        return 4;
                                    }
                                    else if (value.Value === /*&*/ 38)
                                    {
                                        if (!new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$2([38, 97, 109, 112, 59]).TryCopyTo(destination))
                                        {
                                            $gotoJumpState1 = 1; /*goto OutOfSpace*/
                                            continue $gotoJumpStart1;
                                        }
                                        return 5;
                                    }
                                    else if (value.Value === /*\"*/ 34)
                                    {
                                        if (!new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$2([38, 113, 117, 111, 116, 59]).TryCopyTo(destination))
                                        {
                                            $gotoJumpState1 = 1; /*goto OutOfSpace*/
                                            continue $gotoJumpStart1;
                                        }
                                        return 6;
                                    }
                                    else 
                                    {
                                        return TryEncodeScalarAsHex(this, (value.Value >>> 0), destination);
                                    }
                                }
                                case 1: /*OutOfSpace*/
                                return -1;
                                /*static int*/  function TryEncodeScalarAsHex(/*object*/ $this, /*uint*/ scalarValue, /*Span<byte>*/ destination)
                                {
                                    /*int*/ let idxOfSemicolon;
                                    let $gotoJumpState2 = 0;
                                    $gotoJumpStart2: while(true)
                                    {
                                        switch($gotoJumpState2)
                                        {
                                            case 0:
                                            {
                                                $.$stew.System.Text.UnicodeDebug.AssertIsValidScalar(scalarValue);
                                                idxOfSemicolon = (((($.trunc(($.$spc.System.Numerics.BitOperations.Log2(scalarValue) >>> 0) / 4)) | 0) + 4) | 0);
                                                $.$spc.System.Diagnostics.Debug.Assert$1(4 <= idxOfSemicolon && idxOfSemicolon <= 9, "Expected '&#x0;'..'&#x10FFFF;'.");
                                                if ((destination.Length >>> 0) <= (idxOfSemicolon >>> 0))
                                                {
                                                    $gotoJumpState2 = 1; /*goto OutOfSpaceInner*/
                                                    continue $gotoJumpStart2;
                                                }
                                                destination.get_Item(idxOfSemicolon).$v = /*;*/ 59;
                                                if (!new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$2([38, 35, 120, 48]).TryCopyTo(destination))
                                                {
                                                    $.$spc.System.Diagnostics.Debug.Fail("We should've had enough room to write 4 bytes.");
                                                }
                                                destination = destination.Slice$1(3, ((idxOfSemicolon - 3) | 0));
                                                for(/*int*/ let i = ((destination.Length - 1) | 0); (destination.Length >>> 0) > (i >>> 0); i--)
                                                {
                                                    /*char*/ let asUpperHex = $.$stew.System.HexConverter.ToCharUpper((scalarValue | 0));
                                                    destination.get_Item(i).$v = $.$cast(asUpperHex, $.$spc.System.Byte);
                                                    scalarValue >>= 4;
                                                }
                                                return ((destination.Length + 4) | 0);
                                            }
                                            case 1: /*OutOfSpaceInner*/
                                            return -1;
                                        }
                                        break;
                                    }
                                }
                            }
                            break;
                        }
                    }
                    /*int */ EncodeUtf16(/*Rune*/ value, /*Span<char>*/ destination)
                    {
                        let $gotoJumpState1 = 0;
                        $gotoJumpStart1: while(true)
                        {
                            switch($gotoJumpState1)
                            {
                                case 0:
                                {
                                    if (value.Value === /*<*/ 60)
                                    {
                                        if (!$.$spc.System.MemoryExtensions.AsSpan$3("&lt;").TryCopyTo(destination))
                                        {
                                            $gotoJumpState1 = 1; /*goto OutOfSpace*/
                                            continue $gotoJumpStart1;
                                        }
                                        return 4;
                                    }
                                    else if (value.Value === /*>*/ 62)
                                    {
                                        if (!$.$spc.System.MemoryExtensions.AsSpan$3("&gt;").TryCopyTo(destination))
                                        {
                                            $gotoJumpState1 = 1; /*goto OutOfSpace*/
                                            continue $gotoJumpStart1;
                                        }
                                        return 4;
                                    }
                                    else if (value.Value === /*&*/ 38)
                                    {
                                        if (!$.$spc.System.MemoryExtensions.AsSpan$3("&amp;").TryCopyTo(destination))
                                        {
                                            $gotoJumpState1 = 1; /*goto OutOfSpace*/
                                            continue $gotoJumpStart1;
                                        }
                                        return 5;
                                    }
                                    else if (value.Value === /*\"*/ 34)
                                    {
                                        if (!$.$spc.System.MemoryExtensions.AsSpan$3("&quot;").TryCopyTo(destination))
                                        {
                                            $gotoJumpState1 = 1; /*goto OutOfSpace*/
                                            continue $gotoJumpStart1;
                                        }
                                        return 6;
                                    }
                                    else 
                                    {
                                        return TryEncodeScalarAsHex(this, (value.Value >>> 0), destination);
                                    }
                                }
                                case 1: /*OutOfSpace*/
                                return -1;
                                /*static int*/  function TryEncodeScalarAsHex(/*object*/ $this, /*uint*/ scalarValue, /*Span<char>*/ destination)
                                {
                                    /*int*/ let idxOfSemicolon;
                                    let $gotoJumpState2 = 0;
                                    $gotoJumpStart2: while(true)
                                    {
                                        switch($gotoJumpState2)
                                        {
                                            case 0:
                                            {
                                                $.$stew.System.Text.UnicodeDebug.AssertIsValidScalar(scalarValue);
                                                idxOfSemicolon = (((($.trunc(($.$spc.System.Numerics.BitOperations.Log2(scalarValue) >>> 0) / 4)) | 0) + 4) | 0);
                                                $.$spc.System.Diagnostics.Debug.Assert$1(4 <= idxOfSemicolon && idxOfSemicolon <= 9, "Expected '&#x0;'..'&#x10FFFF;'.");
                                                if ((destination.Length >>> 0) <= (idxOfSemicolon >>> 0))
                                                {
                                                    $gotoJumpState2 = 1; /*goto OutOfSpaceInner*/
                                                    continue $gotoJumpStart2;
                                                }
                                                destination.get_Item(idxOfSemicolon).$v = /*;*/ 59;
                                                if (!$.$spc.System.MemoryExtensions.AsSpan$3("&#x0").TryCopyTo(destination))
                                                {
                                                    $.$spc.System.Diagnostics.Debug.Fail("We should've had enough room to write 4 chars.");
                                                }
                                                destination = destination.Slice$1(3, ((idxOfSemicolon - 3) | 0));
                                                for(/*int*/ let i = ((destination.Length - 1) | 0); (destination.Length >>> 0) > (i >>> 0); i--)
                                                {
                                                    /*char*/ let asUpperHex = $.$stew.System.HexConverter.ToCharUpper((scalarValue | 0));
                                                    destination.get_Item(i).$v = asUpperHex;
                                                    scalarValue >>= 4;
                                                }
                                                return ((destination.Length + 4) | 0);
                                            }
                                            case 1: /*OutOfSpaceInner*/
                                            return -1;
                                        }
                                        break;
                                    }
                                }
                            }
                            break;
                        }
                    }
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            this.Singleton = new $.$stew.System.Text.Encodings.Web.DefaultHtmlEncoder.EscaperImplementation().$ctor$2();
                        }
                    }
                    static $h = 757452;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1412812,"m":[{"r":655361,"p":[{"n":"value","p":122748929},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"EncodeUtf8","d":757452,"h":12885659340,"f":32776},{"r":655361,"p":[{"n":"value","p":122748929},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Char).$h}],"n":"EncodeUtf16","d":757452,"h":17180626636,"f":32776}],"l":[{"t":757452,"n":"Singleton","d":757452,"h":4295724748,"f":40}],"c":[{"n":".ctor","o":"$ctor$2","d":757452,"h":8590692044,"f":2}],"d":691916,"h":757452}; }
                    static get $b() { return $.$stew.System.Text.Encodings.Web.ScalarEscaperBase; }
                    static get $fullName() { return `System.Text.Encodings.Web.DefaultHtmlEncoder.EscaperImplementation`; }
                }, $cls, ($v) => $cls.$_EscaperImplementation = $v);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.BasicLatinSingleton = new $.$stew.System.Text.Encodings.Web.DefaultHtmlEncoder().$ctor$3(new $.$stew.System.Text.Encodings.Web.TextEncoderSettings().$ctor$3($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$stew.System.Text.Unicode.UnicodeRange), [ $.$stew.System.Text.Unicode.UnicodeRanges.BasicLatin ], null, null)));
                }
            }
            static $h = 691916;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1150668,"p":[{"p":655361,"g":{"r":0,"d":0,"h":21475528396,"f":32769},"n":"MaxOutputCharactersPerInputCharacter","d":691916,"h":17180561100,"f":32769}],"m":[{"r":18677761,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Char).$h},{"n":"charsConsumed","p":655361,"f":2},{"n":"charsWritten","p":655361,"f":2},{"n":"isFinalBlock","p":262145}],"n":"EncodeCore","d":691916,"h":25770495692,"f":32768},{"r":18677761,"p":[{"n":"utf8Source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"utf8Destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"bytesConsumed","p":655361,"f":2},{"n":"bytesWritten","p":655361,"f":2},{"n":"isFinalBlock","p":262145}],"n":"EncodeUtf8Core","d":691916,"h":30065462988,"f":32768},{"r":655361,"p":[{"n":"text","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h}],"n":"FindFirstCharacterToEncode","o":"@$1","d":691916,"h":34360430284,"f":32768},{"r":655361,"p":[{"n":"text","p":0},{"n":"textLength","p":655361}],"n":"FindFirstCharacterToEncode","d":691916,"h":38655397580,"f":32769},{"r":655361,"p":[{"n":"utf8Text","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"FindFirstCharacterToEncodeUtf8","d":691916,"h":42950364876,"f":32769},{"r":262145,"p":[{"n":"unicodeScalar","p":655361},{"n":"buffer","p":0},{"n":"bufferLength","p":655361},{"n":"numberOfCharactersWritten","p":655361,"f":2}],"n":"TryEncodeUnicodeScalar","d":691916,"h":47245332172,"f":32769},{"r":262145,"p":[{"n":"unicodeScalar","p":655361}],"n":"WillEncode","d":691916,"h":51540299468,"f":32769}],"l":[{"t":691916,"n":"BasicLatinSingleton","d":691916,"h":4295659212,"f":40},{"t":1281740,"n":"_innerEncoder","d":691916,"h":8590626508,"f":2}],"c":[{"p":[{"n":"settings","p":1543884}],"n":".ctor","o":"$ctor$3","d":691916,"h":12885593804,"f":8}],"j":[757452],"h":691916}; }
            static get $b() { return $.$stew.System.Text.Encodings.Web.HtmlEncoder; }
            static get $fullName() { return `System.Text.Encodings.Web.DefaultHtmlEncoder`; }
        });
        
        $asm.$cls("$stew.System.Text.Encodings.Web.DefaultUrlEncoder", ($self) => class DefaultUrlEncoder extends $.$stew.System.Text.Encodings.Web.UrlEncoder
        {
            /*DefaultUrlEncoder*/ static BasicLatinSingleton = null;
            /*OptimizedInboxTextEncoder*/ _innerEncoder = null;
            $ctor$3(/*TextEncoderSettings*/ settings)
            {
                super.$ctor$2();
                {
                    if (settings === null)
                    {
                        $.$stew.System.Text.Encodings.Web.ThrowHelper.ThrowArgumentNullException(1/*ExceptionArgument.settings*/);
                    }
                    this._innerEncoder = new $.$stew.System.Text.Encodings.Web.OptimizedInboxTextEncoder().$ctor$1($.$stew.System.Text.Encodings.Web.DefaultUrlEncoder.EscaperImplementation.Singleton, settings.GetAllowedCodePointsBitmap(), true, $.$spc.System.ReadOnlySpan$$($.$spc.System.Char).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Char), [/* */ 32, /*#*/ 35, /*%*/ 37, /*/*/ 47, /*:*/ 58, /*=*/ 61, /*?*/ 63, /*[*/ 91, /*\\*/ 92, /*]*/ 93, /*^*/ 94, /*`*/ 96, /*{*/ 123, /*|*/ 124, /*}*/ 125, /*\uFFF0*/ 65520, /*\uFFF1*/ 65521, /*\uFFF2*/ 65522, /*\uFFF3*/ 65523, /*\uFFF4*/ 65524, /*\uFFF5*/ 65525, /*\uFFF6*/ 65526, /*\uFFF7*/ 65527, /*\uFFF8*/ 65528, /*\uFFF9*/ 65529, /*\uFFFA*/ 65530, /*\uFFFB*/ 65531, /*\uFFFC*/ 65532, /*\uFFFD*/ 65533, /*\uFFFE*/ 65534, /*\uFFFF*/ 65535], null, null)));
                }
                return this;
            }
            /*int */ get MaxOutputCharactersPerInputCharacter()
            {
                return 9;
            }
            /*OperationStatus */ EncodeCore(/*ReadOnlySpan<char>*/ source, /*Span<char>*/ destination, /*out int*/ charsConsumed, /*out int*/ charsWritten, /*bool*/ isFinalBlock)
            {
                return this._innerEncoder.Encode(source, destination, charsConsumed, charsWritten, isFinalBlock);
            }
            /*OperationStatus */ EncodeUtf8Core(/*ReadOnlySpan<byte>*/ utf8Source, /*Span<byte>*/ utf8Destination, /*out int*/ bytesConsumed, /*out int*/ bytesWritten, /*bool*/ isFinalBlock)
            {
                return this._innerEncoder.EncodeUtf8(utf8Source, utf8Destination, bytesConsumed, bytesWritten, isFinalBlock);
            }
            /*int */ FindFirstCharacterToEncode$1(/*ReadOnlySpan<char>*/ text)
            {
                return this._innerEncoder.GetIndexOfFirstCharToEncode(text);
            }
            /*int */ FindFirstCharacterToEncode(/*char**/ text, /*int*/ textLength)
            {
                return this._innerEncoder.FindFirstCharacterToEncode(text, textLength);
            }
            /*int */ FindFirstCharacterToEncodeUtf8(/*ReadOnlySpan<byte>*/ utf8Text)
            {
                return this._innerEncoder.GetIndexOfFirstByteToEncode(utf8Text);
            }
            /*bool */ TryEncodeUnicodeScalar(/*int*/ unicodeScalar, /*char**/ buffer, /*int*/ bufferLength, /*out int*/ numberOfCharactersWritten)
            {
                return this._innerEncoder.TryEncodeUnicodeScalar(unicodeScalar, buffer, bufferLength, numberOfCharactersWritten);
            }
            /*bool */ WillEncode(/*int*/ unicodeScalar)
            {
                return !this._innerEncoder.IsScalarValueAllowed(new $.$spc.System.Text.Rune().$ctor$4(unicodeScalar));
            }
            static $_EscaperImplementation;
            static get EscaperImplementation()
            {
                let $cls = $.$stew.System.Text.Encodings.Web.DefaultUrlEncoder;
                return $cls.$_EscaperImplementation ??= $asm.$ncls("$stew.System.Text.Encodings.Web.DefaultUrlEncoder.EscaperImplementation", ($self) => class EscaperImplementation extends $.$stew.System.Text.Encodings.Web.ScalarEscaperBase
                {
                    /*EscaperImplementation*/ static Singleton = null;
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                        }
                        return this;
                    }
                    /*int */ EncodeUtf8(/*Rune*/ value, /*Span<byte>*/ destination)
                    {
                        /*uint*/ let utf8lsb;
                        let $gotoJumpState1 = 0;
                        $gotoJumpStart1: while(true)
                        {
                            switch($gotoJumpState1)
                            {
                                case 0:
                                {
                                    utf8lsb = ($.$stew.System.Text.Unicode.UnicodeHelpers.GetUtf8RepresentationForScalarValue((value.Value >>> 0)) >>> 0);
                                    if ((destination.Length >>> 0) <= 2)
                                    {
                                        $gotoJumpState1 = 1; /*goto OutOfSpace*/
                                        continue $gotoJumpStart1;
                                    }
                                    destination.get_Item(0).$v = /*%*/ 37;
                                    $.$stew.System.HexConverter.ToBytesBuffer($.$cast(utf8lsb, $.$spc.System.Byte), destination, 1, 0);
                                    if ((utf8lsb >>= 8) === 0)
                                    {
                                        return 3;
                                    }
                                    if ((destination.Length >>> 0) <= 5)
                                    {
                                        $gotoJumpState1 = 1; /*goto OutOfSpace*/
                                        continue $gotoJumpStart1;
                                    }
                                    destination.get_Item(3).$v = /*%*/ 37;
                                    $.$stew.System.HexConverter.ToBytesBuffer($.$cast(utf8lsb, $.$spc.System.Byte), destination, 4, 0);
                                    if ((utf8lsb >>= 8) === 0)
                                    {
                                        return 6;
                                    }
                                    if ((destination.Length >>> 0) <= 8)
                                    {
                                        $gotoJumpState1 = 1; /*goto OutOfSpace*/
                                        continue $gotoJumpStart1;
                                    }
                                    destination.get_Item(6).$v = /*%*/ 37;
                                    $.$stew.System.HexConverter.ToBytesBuffer($.$cast(utf8lsb, $.$spc.System.Byte), destination, 7, 0);
                                    if ((utf8lsb >>= 8) === 0)
                                    {
                                        return 9;
                                    }
                                    if ((destination.Length >>> 0) <= 11)
                                    {
                                        $gotoJumpState1 = 1; /*goto OutOfSpace*/
                                        continue $gotoJumpStart1;
                                    }
                                    destination.get_Item(9).$v = /*%*/ 37;
                                    $.$stew.System.HexConverter.ToBytesBuffer($.$cast(utf8lsb, $.$spc.System.Byte), destination, 10, 0);
                                    return 12;
                                }
                                case 1: /*OutOfSpace*/
                                return -1;
                            }
                            break;
                        }
                    }
                    /*int */ EncodeUtf16(/*Rune*/ value, /*Span<char>*/ destination)
                    {
                        /*uint*/ let utf8lsb;
                        let $gotoJumpState1 = 0;
                        $gotoJumpStart1: while(true)
                        {
                            switch($gotoJumpState1)
                            {
                                case 0:
                                {
                                    utf8lsb = ($.$stew.System.Text.Unicode.UnicodeHelpers.GetUtf8RepresentationForScalarValue((value.Value >>> 0)) >>> 0);
                                    if ((destination.Length >>> 0) <= 2)
                                    {
                                        $gotoJumpState1 = 1; /*goto OutOfSpace*/
                                        continue $gotoJumpStart1;
                                    }
                                    destination.get_Item(0).$v = /*%*/ 37;
                                    $.$stew.System.HexConverter.ToCharsBuffer($.$cast(utf8lsb, $.$spc.System.Byte), destination, 1, 0);
                                    if ((utf8lsb >>= 8) === 0)
                                    {
                                        return 3;
                                    }
                                    if ((destination.Length >>> 0) <= 5)
                                    {
                                        $gotoJumpState1 = 1; /*goto OutOfSpace*/
                                        continue $gotoJumpStart1;
                                    }
                                    destination.get_Item(3).$v = /*%*/ 37;
                                    $.$stew.System.HexConverter.ToCharsBuffer($.$cast(utf8lsb, $.$spc.System.Byte), destination, 4, 0);
                                    if ((utf8lsb >>= 8) === 0)
                                    {
                                        return 6;
                                    }
                                    if ((destination.Length >>> 0) <= 8)
                                    {
                                        $gotoJumpState1 = 1; /*goto OutOfSpace*/
                                        continue $gotoJumpStart1;
                                    }
                                    destination.get_Item(6).$v = /*%*/ 37;
                                    $.$stew.System.HexConverter.ToCharsBuffer($.$cast(utf8lsb, $.$spc.System.Byte), destination, 7, 0);
                                    if ((utf8lsb >>= 8) === 0)
                                    {
                                        return 9;
                                    }
                                    if ((destination.Length >>> 0) <= 11)
                                    {
                                        $gotoJumpState1 = 1; /*goto OutOfSpace*/
                                        continue $gotoJumpStart1;
                                    }
                                    destination.get_Item(9).$v = /*%*/ 37;
                                    $.$stew.System.HexConverter.ToCharsBuffer($.$cast(utf8lsb, $.$spc.System.Byte), destination, 10, 0);
                                    return 12;
                                }
                                case 1: /*OutOfSpace*/
                                return -1;
                            }
                            break;
                        }
                    }
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            this.Singleton = new $.$stew.System.Text.Encodings.Web.DefaultUrlEncoder.EscaperImplementation().$ctor$2();
                        }
                    }
                    static $h = 1019596;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1412812,"m":[{"r":655361,"p":[{"n":"value","p":122748929},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"EncodeUtf8","d":1019596,"h":12885921484,"f":32776},{"r":655361,"p":[{"n":"value","p":122748929},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Char).$h}],"n":"EncodeUtf16","d":1019596,"h":17180888780,"f":32776}],"l":[{"t":1019596,"n":"Singleton","d":1019596,"h":4295986892,"f":40}],"c":[{"n":".ctor","o":"$ctor$2","d":1019596,"h":8590954188,"f":2}],"d":954060,"h":1019596}; }
                    static get $b() { return $.$stew.System.Text.Encodings.Web.ScalarEscaperBase; }
                    static get $fullName() { return `System.Text.Encodings.Web.DefaultUrlEncoder.EscaperImplementation`; }
                }, $cls, ($v) => $cls.$_EscaperImplementation = $v);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.BasicLatinSingleton = new $.$stew.System.Text.Encodings.Web.DefaultUrlEncoder().$ctor$3(new $.$stew.System.Text.Encodings.Web.TextEncoderSettings().$ctor$3($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$stew.System.Text.Unicode.UnicodeRange), [ $.$stew.System.Text.Unicode.UnicodeRanges.BasicLatin ], null, null)));
                }
            }
            static $h = 954060;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1674956,"p":[{"p":655361,"g":{"r":0,"d":0,"h":21475790540,"f":32769},"n":"MaxOutputCharactersPerInputCharacter","d":954060,"h":17180823244,"f":32769}],"m":[{"r":18677761,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Char).$h},{"n":"charsConsumed","p":655361,"f":2},{"n":"charsWritten","p":655361,"f":2},{"n":"isFinalBlock","p":262145}],"n":"EncodeCore","d":954060,"h":25770757836,"f":32768},{"r":18677761,"p":[{"n":"utf8Source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"utf8Destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"bytesConsumed","p":655361,"f":2},{"n":"bytesWritten","p":655361,"f":2},{"n":"isFinalBlock","p":262145}],"n":"EncodeUtf8Core","d":954060,"h":30065725132,"f":32768},{"r":655361,"p":[{"n":"text","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h}],"n":"FindFirstCharacterToEncode","o":"@$1","d":954060,"h":34360692428,"f":32768},{"r":655361,"p":[{"n":"text","p":0},{"n":"textLength","p":655361}],"n":"FindFirstCharacterToEncode","d":954060,"h":38655659724,"f":32769},{"r":655361,"p":[{"n":"utf8Text","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"FindFirstCharacterToEncodeUtf8","d":954060,"h":42950627020,"f":32769},{"r":262145,"p":[{"n":"unicodeScalar","p":655361},{"n":"buffer","p":0},{"n":"bufferLength","p":655361},{"n":"numberOfCharactersWritten","p":655361,"f":2}],"n":"TryEncodeUnicodeScalar","d":954060,"h":47245594316,"f":32769},{"r":262145,"p":[{"n":"unicodeScalar","p":655361}],"n":"WillEncode","d":954060,"h":51540561612,"f":32769}],"l":[{"t":954060,"n":"BasicLatinSingleton","d":954060,"h":4295921356,"f":40},{"t":1281740,"n":"_innerEncoder","d":954060,"h":8590888652,"f":2}],"c":[{"p":[{"n":"settings","p":1543884}],"n":".ctor","o":"$ctor$3","d":954060,"h":12885855948,"f":8}],"j":[1019596],"h":954060}; }
            static get $b() { return $.$stew.System.Text.Encodings.Web.UrlEncoder; }
            static get $fullName() { return `System.Text.Encodings.Web.DefaultUrlEncoder`; }
        });
        
        $asm.$cls("$stew.System.Text.Encodings.Web.DefaultJavaScriptEncoder", ($self) => class DefaultJavaScriptEncoder extends $.$stew.System.Text.Encodings.Web.JavaScriptEncoder
        {
            /*DefaultJavaScriptEncoder*/ static BasicLatinSingleton = null;
            /*DefaultJavaScriptEncoder*/ static UnsafeRelaxedEscapingSingleton = null;
            /*OptimizedInboxTextEncoder*/ _innerEncoder = null;
            $ctor$3(/*TextEncoderSettings*/ settings)
            {
                this.$ctor$4(settings, false);
                {
                }
                return this;
            }
            $ctor$4(/*TextEncoderSettings*/ settings, /*bool*/ allowMinimalJsonEscaping)
            {
                super.$ctor$2();
                {
                    if (settings === null)
                    {
                        $.$stew.System.Text.Encodings.Web.ThrowHelper.ThrowArgumentNullException(1/*ExceptionArgument.settings*/);
                    }
                    this._innerEncoder = allowMinimalJsonEscaping ? new $.$stew.System.Text.Encodings.Web.OptimizedInboxTextEncoder().$ctor$1($.$stew.System.Text.Encodings.Web.DefaultJavaScriptEncoder.EscaperImplementation.SingletonMinimallyEscaped, settings.GetAllowedCodePointsBitmap(), false, $.$spc.System.ReadOnlySpan$$($.$spc.System.Char).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Char), [/*\"*/ 34, /*\\*/ 92], null, null))) : new $.$stew.System.Text.Encodings.Web.OptimizedInboxTextEncoder().$ctor$1($.$stew.System.Text.Encodings.Web.DefaultJavaScriptEncoder.EscaperImplementation.Singleton, settings.GetAllowedCodePointsBitmap(), true, $.$spc.System.ReadOnlySpan$$($.$spc.System.Char).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Char), [/*\\*/ 92, /*`*/ 96], null, null)));
                }
                return this;
            }
            /*int */ get MaxOutputCharactersPerInputCharacter()
            {
                return 6;
            }
            /*OperationStatus */ EncodeCore(/*ReadOnlySpan<char>*/ source, /*Span<char>*/ destination, /*out int*/ charsConsumed, /*out int*/ charsWritten, /*bool*/ isFinalBlock)
            {
                return this._innerEncoder.Encode(source, destination, charsConsumed, charsWritten, isFinalBlock);
            }
            /*OperationStatus */ EncodeUtf8Core(/*ReadOnlySpan<byte>*/ utf8Source, /*Span<byte>*/ utf8Destination, /*out int*/ bytesConsumed, /*out int*/ bytesWritten, /*bool*/ isFinalBlock)
            {
                return this._innerEncoder.EncodeUtf8(utf8Source, utf8Destination, bytesConsumed, bytesWritten, isFinalBlock);
            }
            /*int */ FindFirstCharacterToEncode$1(/*ReadOnlySpan<char>*/ text)
            {
                return this._innerEncoder.GetIndexOfFirstCharToEncode(text);
            }
            /*int */ FindFirstCharacterToEncode(/*char**/ text, /*int*/ textLength)
            {
                return this._innerEncoder.FindFirstCharacterToEncode(text, textLength);
            }
            /*int */ FindFirstCharacterToEncodeUtf8(/*ReadOnlySpan<byte>*/ utf8Text)
            {
                return this._innerEncoder.GetIndexOfFirstByteToEncode(utf8Text);
            }
            /*bool */ TryEncodeUnicodeScalar(/*int*/ unicodeScalar, /*char**/ buffer, /*int*/ bufferLength, /*out int*/ numberOfCharactersWritten)
            {
                return this._innerEncoder.TryEncodeUnicodeScalar(unicodeScalar, buffer, bufferLength, numberOfCharactersWritten);
            }
            /*bool */ WillEncode(/*int*/ unicodeScalar)
            {
                return !this._innerEncoder.IsScalarValueAllowed(new $.$spc.System.Text.Rune().$ctor$4(unicodeScalar));
            }
            static $_EscaperImplementation;
            static get EscaperImplementation()
            {
                let $cls = $.$stew.System.Text.Encodings.Web.DefaultJavaScriptEncoder;
                return $cls.$_EscaperImplementation ??= $asm.$ncls("$stew.System.Text.Encodings.Web.DefaultJavaScriptEncoder.EscaperImplementation", ($self) => class EscaperImplementation extends $.$stew.System.Text.Encodings.Web.ScalarEscaperBase
                {
                    /*EscaperImplementation*/ static Singleton = null;
                    /*EscaperImplementation*/ static SingletonMinimallyEscaped = null;
                    /*AsciiByteMap*/ _preescapedMap;
                    $ctor$2(/*bool*/ allowMinimalEscaping)
                    {
                        super.$ctor$1();
                        {
                            this._preescapedMap.InsertAsciiChar(/*\u0008*/ 8, /*b*/ 98);
                            this._preescapedMap.InsertAsciiChar(/*\t*/ 9, /*t*/ 116);
                            this._preescapedMap.InsertAsciiChar(/*\n*/ 10, /*n*/ 110);
                            this._preescapedMap.InsertAsciiChar(/*\u000C*/ 12, /*f*/ 102);
                            this._preescapedMap.InsertAsciiChar(/*\r*/ 13, /*r*/ 114);
                            this._preescapedMap.InsertAsciiChar(/*\\*/ 92, /*\\*/ 92);
                            if (allowMinimalEscaping)
                            {
                                this._preescapedMap.InsertAsciiChar(/*\"*/ 34, /*\"*/ 34);
                            }
                        }
                        return this;
                    }
                    /*int */ EncodeUtf8(/*Rune*/ value, /*Span<byte>*/ destination)
                    {
                        /*byte*/ let preescapedForm;
                        if (this._preescapedMap.TryLookup(value, $.$ref(() => preescapedForm, ($v) => preescapedForm = $v, $.$spc.System.Byte)))
                        {
                            let $gotoJumpState2 = 0;
                            $gotoJumpStart2: while(true)
                            {
                                switch($gotoJumpState2)
                                {
                                    case 0:
                                    {
                                        if ((destination.Length >>> 0) <= 1)
                                        {
                                            $gotoJumpState2 = 1; /*goto OutOfSpace*/
                                            continue $gotoJumpStart2;
                                        }
                                        destination.get_Item(0).$v = /*\\*/ 92;
                                        destination.get_Item(1).$v = preescapedForm;
                                        return 2;
                                    }
                                    case 1: /*OutOfSpace*/
                                    return -1;
                                }
                                break;
                            }
                        }
                        return TryEncodeScalarAsHex(this, value, destination);
                        /*static int*/  function TryEncodeScalarAsHex(/*object*/ $this, /*Rune*/ value, /*Span<byte>*/ destination)
                        {
                            let $gotoJumpState2 = 0;
                            $gotoJumpStart2: while(true)
                            {
                                switch($gotoJumpState2)
                                {
                                    case 0:
                                    {
                                        if (value.IsBmp)
                                        {
                                            if ((destination.Length >>> 0) <= 5)
                                            {
                                                $gotoJumpState2 = 1; /*goto OutOfSpaceInner*/
                                                continue $gotoJumpStart2;
                                            }
                                            destination.get_Item(0).$v = /*\\*/ 92;
                                            destination.get_Item(1).$v = /*u*/ 117;
                                            $.$stew.System.HexConverter.ToBytesBuffer($.$cast(value.Value, $.$spc.System.Byte), destination, 4, 0);
                                            $.$stew.System.HexConverter.ToBytesBuffer($.$cast(((value.Value >>> 0) >>> 8), $.$spc.System.Byte), destination, 2, 0);
                                            return 6;
                                        }
                                        else 
                                        {
                                            /*char*/ let highSurrogate;
                                            /*char*/ let lowSurrogate;
                                            $.$stew.System.Text.Unicode.UnicodeHelpers.GetUtf16SurrogatePairFromAstralScalarValue((value.Value >>> 0), $.$ref(() => highSurrogate, ($v) => highSurrogate = $v, $.$spc.System.Char), $.$ref(() => lowSurrogate, ($v) => lowSurrogate = $v, $.$spc.System.Char));
                                            if ((destination.Length >>> 0) <= 11)
                                            {
                                                $gotoJumpState2 = 1; /*goto OutOfSpaceInner*/
                                                continue $gotoJumpStart2;
                                            }
                                            destination.get_Item(0).$v = /*\\*/ 92;
                                            destination.get_Item(1).$v = /*u*/ 117;
                                            $.$stew.System.HexConverter.ToBytesBuffer($.$cast(highSurrogate, $.$spc.System.Byte), destination, 4, 0);
                                            $.$stew.System.HexConverter.ToBytesBuffer($.$cast((highSurrogate >>> 8), $.$spc.System.Byte), destination, 2, 0);
                                            destination.get_Item(6).$v = /*\\*/ 92;
                                            destination.get_Item(7).$v = /*u*/ 117;
                                            $.$stew.System.HexConverter.ToBytesBuffer($.$cast(lowSurrogate, $.$spc.System.Byte), destination, 10, 0);
                                            $.$stew.System.HexConverter.ToBytesBuffer($.$cast((lowSurrogate >>> 8), $.$spc.System.Byte), destination, 8, 0);
                                            return 12;
                                        }
                                    }
                                    case 1: /*OutOfSpaceInner*/
                                    return -1;
                                }
                                break;
                            }
                        }
                    }
                    /*int */ EncodeUtf16(/*Rune*/ value, /*Span<char>*/ destination)
                    {
                        /*byte*/ let preescapedForm;
                        if (this._preescapedMap.TryLookup(value, $.$ref(() => preescapedForm, ($v) => preescapedForm = $v, $.$spc.System.Byte)))
                        {
                            let $gotoJumpState2 = 0;
                            $gotoJumpStart2: while(true)
                            {
                                switch($gotoJumpState2)
                                {
                                    case 0:
                                    {
                                        if ((destination.Length >>> 0) <= 1)
                                        {
                                            $gotoJumpState2 = 1; /*goto OutOfSpace*/
                                            continue $gotoJumpStart2;
                                        }
                                        destination.get_Item(0).$v = /*\\*/ 92;
                                        destination.get_Item(1).$v = preescapedForm;
                                        return 2;
                                    }
                                    case 1: /*OutOfSpace*/
                                    return -1;
                                }
                                break;
                            }
                        }
                        return TryEncodeScalarAsHex(this, value, destination);
                        /*static int*/  function TryEncodeScalarAsHex(/*object*/ $this, /*Rune*/ value, /*Span<char>*/ destination)
                        {
                            let $gotoJumpState2 = 0;
                            $gotoJumpStart2: while(true)
                            {
                                switch($gotoJumpState2)
                                {
                                    case 0:
                                    {
                                        if (value.IsBmp)
                                        {
                                            if ((destination.Length >>> 0) <= 5)
                                            {
                                                $gotoJumpState2 = 1; /*goto OutOfSpaceInner*/
                                                continue $gotoJumpStart2;
                                            }
                                            destination.get_Item(0).$v = /*\\*/ 92;
                                            destination.get_Item(1).$v = /*u*/ 117;
                                            $.$stew.System.HexConverter.ToCharsBuffer($.$cast(value.Value, $.$spc.System.Byte), destination, 4, 0);
                                            $.$stew.System.HexConverter.ToCharsBuffer($.$cast(((value.Value >>> 0) >>> 8), $.$spc.System.Byte), destination, 2, 0);
                                            return 6;
                                        }
                                        else 
                                        {
                                            /*char*/ let highSurrogate;
                                            /*char*/ let lowSurrogate;
                                            $.$stew.System.Text.Unicode.UnicodeHelpers.GetUtf16SurrogatePairFromAstralScalarValue((value.Value >>> 0), $.$ref(() => highSurrogate, ($v) => highSurrogate = $v, $.$spc.System.Char), $.$ref(() => lowSurrogate, ($v) => lowSurrogate = $v, $.$spc.System.Char));
                                            if ((destination.Length >>> 0) <= 11)
                                            {
                                                $gotoJumpState2 = 1; /*goto OutOfSpaceInner*/
                                                continue $gotoJumpStart2;
                                            }
                                            destination.get_Item(0).$v = /*\\*/ 92;
                                            destination.get_Item(1).$v = /*u*/ 117;
                                            $.$stew.System.HexConverter.ToCharsBuffer($.$cast(highSurrogate, $.$spc.System.Byte), destination, 4, 0);
                                            $.$stew.System.HexConverter.ToCharsBuffer($.$cast((highSurrogate >>> 8), $.$spc.System.Byte), destination, 2, 0);
                                            destination.get_Item(6).$v = /*\\*/ 92;
                                            destination.get_Item(7).$v = /*u*/ 117;
                                            $.$stew.System.HexConverter.ToCharsBuffer($.$cast(lowSurrogate, $.$spc.System.Byte), destination, 10, 0);
                                            $.$stew.System.HexConverter.ToCharsBuffer($.$cast((lowSurrogate >>> 8), $.$spc.System.Byte), destination, 8, 0);
                                            return 12;
                                        }
                                    }
                                    case 1: /*OutOfSpaceInner*/
                                    return -1;
                                }
                                break;
                            }
                        }
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._preescapedMap = $.$default($.$stew.System.Text.Encodings.Web.AsciiByteMap);
                    }
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            this.Singleton = new $.$stew.System.Text.Encodings.Web.DefaultJavaScriptEncoder.EscaperImplementation().$ctor$2(false);
                        }
                        {
                            this.SingletonMinimallyEscaped = new $.$stew.System.Text.Encodings.Web.DefaultJavaScriptEncoder.EscaperImplementation().$ctor$2(true);
                        }
                    }
                    static $h = 888524;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1412812,"m":[{"r":655361,"p":[{"n":"value","p":122748929},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"EncodeUtf8","d":888524,"h":21475725004,"f":32776},{"r":655361,"p":[{"n":"value","p":122748929},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Char).$h}],"n":"EncodeUtf16","d":888524,"h":25770692300,"f":32776}],"l":[{"t":888524,"n":"Singleton","d":888524,"h":4295855820,"f":40},{"t":888524,"n":"SingletonMinimallyEscaped","d":888524,"h":8590823116,"f":40},{"t":626380,"n":"_preescapedMap","d":888524,"h":12885790412,"f":2}],"c":[{"p":[{"n":"allowMinimalEscaping","p":262145}],"n":".ctor","o":"$ctor$2","d":888524,"h":17180757708,"f":2}],"d":822988,"h":888524}; }
                    static get $b() { return $.$stew.System.Text.Encodings.Web.ScalarEscaperBase; }
                    static get $fullName() { return `System.Text.Encodings.Web.DefaultJavaScriptEncoder.EscaperImplementation`; }
                }, $cls, ($v) => $cls.$_EscaperImplementation = $v);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.BasicLatinSingleton = new $.$stew.System.Text.Encodings.Web.DefaultJavaScriptEncoder().$ctor$3(new $.$stew.System.Text.Encodings.Web.TextEncoderSettings().$ctor$3($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$stew.System.Text.Unicode.UnicodeRange), [ $.$stew.System.Text.Unicode.UnicodeRanges.BasicLatin ], null, null)));
                }
                {
                    this.UnsafeRelaxedEscapingSingleton = new $.$stew.System.Text.Encodings.Web.DefaultJavaScriptEncoder().$ctor$4(new $.$stew.System.Text.Encodings.Web.TextEncoderSettings().$ctor$3($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$stew.System.Text.Unicode.UnicodeRange), [ $.$stew.System.Text.Unicode.UnicodeRanges.All ], null, null)), true);
                }
            }
            static $h = 822988;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1216204,"p":[{"p":655361,"g":{"r":0,"d":0,"h":30065594060,"f":32769},"n":"MaxOutputCharactersPerInputCharacter","d":822988,"h":25770626764,"f":32769}],"m":[{"r":18677761,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Char).$h},{"n":"charsConsumed","p":655361,"f":2},{"n":"charsWritten","p":655361,"f":2},{"n":"isFinalBlock","p":262145}],"n":"EncodeCore","d":822988,"h":34360561356,"f":32768},{"r":18677761,"p":[{"n":"utf8Source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"utf8Destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"bytesConsumed","p":655361,"f":2},{"n":"bytesWritten","p":655361,"f":2},{"n":"isFinalBlock","p":262145}],"n":"EncodeUtf8Core","d":822988,"h":38655528652,"f":32768},{"r":655361,"p":[{"n":"text","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h}],"n":"FindFirstCharacterToEncode","o":"@$1","d":822988,"h":42950495948,"f":32768},{"r":655361,"p":[{"n":"text","p":0},{"n":"textLength","p":655361}],"n":"FindFirstCharacterToEncode","d":822988,"h":47245463244,"f":32769},{"r":655361,"p":[{"n":"utf8Text","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"FindFirstCharacterToEncodeUtf8","d":822988,"h":51540430540,"f":32769},{"r":262145,"p":[{"n":"unicodeScalar","p":655361},{"n":"buffer","p":0},{"n":"bufferLength","p":655361},{"n":"numberOfCharactersWritten","p":655361,"f":2}],"n":"TryEncodeUnicodeScalar","d":822988,"h":55835397836,"f":32769},{"r":262145,"p":[{"n":"unicodeScalar","p":655361}],"n":"WillEncode","d":822988,"h":60130365132,"f":32769}],"l":[{"t":822988,"n":"BasicLatinSingleton","d":822988,"h":4295790284,"f":40},{"t":822988,"n":"UnsafeRelaxedEscapingSingleton","d":822988,"h":8590757580,"f":40},{"t":1281740,"n":"_innerEncoder","d":822988,"h":12885724876,"f":2}],"c":[{"p":[{"n":"settings","p":1543884}],"n":".ctor","o":"$ctor$3","d":822988,"h":17180692172,"f":8},{"p":[{"n":"settings","p":1543884},{"n":"allowMinimalJsonEscaping","p":262145}],"n":".ctor","o":"$ctor$4","d":822988,"h":21475659468,"f":2}],"j":[888524],"h":822988}; }
            static get $b() { return $.$stew.System.Text.Encodings.Web.JavaScriptEncoder; }
            static get $fullName() { return `System.Text.Encodings.Web.DefaultJavaScriptEncoder`; }
        });
        
        $asm.$str("$stew.System.Text.Encodings.Web.ExceptionArgument", ($self) => class ExceptionArgument extends $.$spc.System.Enum
        {
            static value = 0;
            static settings = 1;
            static output = 2;
            static other = 3;
            static allowedRanges = 4;
            static characters = 5;
            static codePoints = 6;
            static range = 7;
            static ranges = 8;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "value": 0n,
                    "settings": 1n,
                    "output": 2n,
                    "other": 3n,
                    "allowedRanges": 4n,
                    "characters": 5n,
                    "codePoints": 6n,
                    "range": 7n,
                    "ranges": 8n
                };
            }
            static $h = 1085132;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1085132,"n":"value","d":1085132,"h":4296052428,"f":33},{"t":1085132,"n":"settings","d":1085132,"h":8591019724,"f":33},{"t":1085132,"n":"output","d":1085132,"h":12885987020,"f":33},{"t":1085132,"n":"other","d":1085132,"h":17180954316,"f":33},{"t":1085132,"n":"allowedRanges","d":1085132,"h":21475921612,"f":33},{"t":1085132,"n":"characters","d":1085132,"h":25770888908,"f":33},{"t":1085132,"n":"codePoints","d":1085132,"h":30065856204,"f":33},{"t":1085132,"n":"range","d":1085132,"h":34360823500,"f":33},{"t":1085132,"n":"ranges","d":1085132,"h":38655790796,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1085132,"h":42950758092,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1085132}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Text.Encodings.Web.ExceptionArgument`; }
        });
        
        $asm.$str("$stew.System.ExceptionArgument", ($self) => class ExceptionArgument extends $.$spc.System.Enum
        {
            static ch = 0;
            static culture = 1;
            static index = 2;
            static input = 3;
            static value = 4;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "ch": 0n,
                    "culture": 1n,
                    "index": 2n,
                    "input": 3n,
                    "value": 4n
                };
            }
            static $h = 102092;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":102092,"n":"ch","d":102092,"h":4295069388,"f":33},{"t":102092,"n":"culture","d":102092,"h":8590036684,"f":33},{"t":102092,"n":"index","d":102092,"h":12885003980,"f":33},{"t":102092,"n":"input","d":102092,"h":17179971276,"f":33},{"t":102092,"n":"value","d":102092,"h":21474938572,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":102092,"h":25769905868,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":102092}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.ExceptionArgument`; }
        });
        
        $asm.$str("$stew.System.ExceptionResource", ($self) => class ExceptionResource extends $.$spc.System.Enum
        {
            static Argument_CannotExtractScalar = 0;
            static ArgumentOutOfRange_IndexMustBeLess = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Argument_CannotExtractScalar": 0n,
                    "ArgumentOutOfRange_IndexMustBeLess": 1n
                };
            }
            static $h = 167628;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":167628,"n":"Argument_CannotExtractScalar","d":167628,"h":4295134924,"f":33},{"t":167628,"n":"ArgumentOutOfRange_IndexMustBeLess","d":167628,"h":8590102220,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":167628,"h":12885069516,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":167628}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.ExceptionResource`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Threading"))