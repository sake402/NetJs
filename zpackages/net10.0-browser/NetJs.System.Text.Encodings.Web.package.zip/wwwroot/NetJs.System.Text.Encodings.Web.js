
//--TRIMMABLE-BOUNDARY-START(57)
(async function () {
(function ($global, $, $$, $sm, $snv, $spu, $sr, $st) {
    "use strict";
    let _;
    let $vrAaHg;
    
    
    
	$.$asm(
    "NetJs.System.Text.Encodings.Web", 
    {
  "h": 57,
  "f": "System.Text.Encodings.Web",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B96771abe2820045936210554b19d0578b9bc2b1c",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "NetJs.System.Text.Encodings.Web",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "NetJs.System.Text.Encodings.Web",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160104449,
      "c": 4455071745,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(1376313)
        $asm.$cls(`$stew.STEW.ScalarEscaperBase`, ($self) => class ScalarEscaperBase extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296343609)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296343609);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296343609)
            
            //--TRIMMABLE-BOUNDARY-START(4296343609)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296343609)
            
            static $h = 1376313;
            static $f = 0b110000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591310905),
    {
      "r": 655361,
      "p": [
        {
          "n": "value",
          "p": 167641089
        },
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Char).$h
        }
      ],
      "n": "EncodeUtf16",
      "d": 1376313,
      "h": 8591310905,
      "f": 16777480
    },
//--TRIMMABLE-BOUNDARY-END(8591310905),
//--TRIMMABLE-BOUNDARY-START(12886278201),
    {
      "r": 655361,
      "p": [
        {
          "n": "value",
          "p": 167641089
        },
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        }
      ],
      "n": "EncodeUtf8",
      "d": 1376313,
      "h": 12886278201,
      "f": 16777480
    },
//--TRIMMABLE-BOUNDARY-END(12886278201)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296343609),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1376313,
      "h": 4296343609,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4296343609)
  ],
  "h": 1376313
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Text.Encodings.Web.ScalarEscaperBase`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Text${separator}Encodings${separator}Web${separator}ScalarEscaperBase`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1376313)
        
        

        //--TRIMMABLE-BOUNDARY-START(1441849)
        $asm.$cls(`$stew.STEW.TextEncoder`, ($self) => class TextEncoder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(38656147513)
            /*int*/ static EncodeStartingOutputBufferSize = 1024;
            //--TRIMMABLE-BOUNDARY-END(38656147513)
            
            //--TRIMMABLE-BOUNDARY-START(94490722361)
            /*bool */ TryEncodeUnicodeScalar$1(/*uint*/ unicodeScalar, /*Span<char>*/ buffer, /*out int*/ charsWritten)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490722361);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*fixed*/ 
                {
                    /*char**/ let pBuffer = $.$$.SRI.MemoryMarshal.GetReference$1($.$$.S.Char, buffer);
                    return this.TryEncodeUnicodeScalar((unicodeScalar | 0), pBuffer, buffer.Length, charsWritten);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(94490722361)
            
            //--TRIMMABLE-BOUNDARY-START(98785689657)
            /*bool */ TryEncodeUnicodeScalarUtf8(/*uint*/ unicodeScalar, /*Span<char>*/ utf16ScratchBuffer, /*Span<byte>*/ utf8Destination, /*out int*/ bytesWritten)
            {
                /*int*/ let charsWritten;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785689657);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.TryEncodeUnicodeScalar$1(unicodeScalar, utf16ScratchBuffer, $.$ref(() => charsWritten, ($v) => charsWritten = $v, $.$$.S.Int32)))
                {
                    $.$stew.STEW.TextEncoder.ThrowArgumentException_MaxOutputCharsPerInputChar();
                }
                utf16ScratchBuffer = utf16ScratchBuffer.Slice(0, charsWritten);
                /*int*/ let dstIdx = 0;
                while(!utf16ScratchBuffer.IsEmpty)
                {
                    /*Rune*/ let nextScalarValue;
                    /*int*/ let scalarUtf16CodeUnitCount;
                    if ($.$$.ST.Rune.DecodeFromUtf16($.$$.S.Span$$($.$$.S.Char).op_Implicit(utf16ScratchBuffer), $.$ref(() => nextScalarValue, ($v) => nextScalarValue = $v, $.$$.ST.Rune), $.$ref(() => scalarUtf16CodeUnitCount, ($v) => scalarUtf16CodeUnitCount = $v, $.$$.S.Int32)) !== 0/*OperationStatus.Done*/)
                    {
                        $.$stew.STEW.TextEncoder.ThrowArgumentException_MaxOutputCharsPerInputChar();
                    }
                    /*uint*/ let utf8lsb = ($.$stew.STU.UnicodeHelpers.GetUtf8RepresentationForScalarValue((nextScalarValue.Value >>> 0)) >>> 0);
                    do
                    {
                        if ((utf8Destination.Length >>> 0) > (dstIdx >>> 0))
                        {
                            utf8Destination._reference.SetAt(((utf8lsb & 0xFF) >>> 0), dstIdx++);
                        }
                        else 
                        {
                            bytesWritten.$v = 0;
                            return false;
                        }
                    }
                    while((utf8lsb >>= 8) !== 0);
                    utf16ScratchBuffer = utf16ScratchBuffer.Slice$1(scalarUtf16CodeUnitCount);
                }
                bytesWritten.$v = dstIdx;
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(98785689657)
            
            //--TRIMMABLE-BOUNDARY-START(25771245625)
            /*string */ Encode$4(/*string*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771245625);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value === null)
                {
                    $.$stew.STEW.ThrowHelper.ThrowArgumentNullException(0/*ExceptionArgument.value*/);
                }
                /*int*/ let indexOfFirstCharToEncode = this.FindFirstCharacterToEncode$1($.$$.S.MemoryExtensions.AsSpan$4(value));
                if (indexOfFirstCharToEncode < 0)
                {
                    return value;
                }
                return this.EncodeToNewString($.$$.S.MemoryExtensions.AsSpan$4(value), indexOfFirstCharToEncode);
            }
            //--TRIMMABLE-BOUNDARY-END(25771245625)
            
            //--TRIMMABLE-BOUNDARY-START(42951114809)
            /*string */ EncodeToNewString(/*ReadOnlySpan<char>*/ value, /*int*/ indexOfFirstCharToEncode)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951114809);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ReadOnlySpan<char>*/ let remainingInput = value.Slice$1(indexOfFirstCharToEncode);
                /*ValueStringBuilder*/ let stringBuilder = new $.$stew.ST.ValueStringBuilder().$ctor$4($.$$.SRC.RuntimeHelpers.StackAllocSpan($.$$.S.Char, 1024/*EncodeStartingOutputBufferSize*/, null));
                /*int*/ let minBufferBumpEachIteration = $.$$.S.Math.Max$4(this.MaxOutputCharactersPerInputCharacter, 1024/*EncodeStartingOutputBufferSize*/);
                do
                {
                    /*int*/ let charsConsumedJustNow;
                    /*int*/ let charsWrittenJustNow;
                    /*Span<char>*/ let destBuffer = stringBuilder.AppendSpan($.$$.S.Math.Max$4(remainingInput.Length, minBufferBumpEachIteration));
                    this.EncodeCore$1(remainingInput, destBuffer, $.$ref(() => charsConsumedJustNow, ($v) => charsConsumedJustNow = $v, $.$$.S.Int32), $.$ref(() => charsWrittenJustNow, ($v) => charsWrittenJustNow = $v, $.$$.S.Int32), true);
                    if (charsWrittenJustNow === 0 || (charsWrittenJustNow >>> 0) > (destBuffer.Length >>> 0))
                    {
                        $.$stew.STEW.TextEncoder.ThrowArgumentException_MaxOutputCharsPerInputChar();
                    }
                    remainingInput = remainingInput.Slice$1(charsConsumedJustNow);
                    stringBuilder.Length -= ((destBuffer.Length - charsWrittenJustNow) | 0);
                }
                while(!remainingInput.IsEmpty);
                /*string*/ let retVal = $.$$.S.String.Concat$8(value.Slice(0, indexOfFirstCharToEncode), stringBuilder.AsSpan());
                stringBuilder.Dispose();
                return retVal;
            }
            //--TRIMMABLE-BOUNDARY-END(42951114809)
            
            //--TRIMMABLE-BOUNDARY-START(17181311033)
            /*void */ Encode$2(/*TextWriter*/ output, /*string*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181311033);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Encode$1(output, value, 0, value.length);
            }
            //--TRIMMABLE-BOUNDARY-END(17181311033)
            
            //--TRIMMABLE-BOUNDARY-START(12886343737)
            /*void */ Encode$1(/*TextWriter*/ output, /*string*/ value, /*int*/ startIndex, /*int*/ characterCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886343737);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (output === null)
                {
                    $.$stew.STEW.ThrowHelper.ThrowArgumentNullException(2/*ExceptionArgument.output*/);
                }
                if (value === null)
                {
                    $.$stew.STEW.ThrowHelper.ThrowArgumentNullException(0/*ExceptionArgument.value*/);
                }
                $.$stew.STEW.TextEncoder.ValidateRanges(startIndex, characterCount, value.length);
                /*int*/ let indexOfFirstCharToEncode = this.FindFirstCharacterToEncode$1($.$$.S.MemoryExtensions.AsSpan$1(value, startIndex, characterCount));
                if (indexOfFirstCharToEncode < 0)
                {
                    indexOfFirstCharToEncode = characterCount;
                }
                $.$stew.SI.TextWriterExtensions.WritePartialString(output, value, startIndex, indexOfFirstCharToEncode);
                if (indexOfFirstCharToEncode !== characterCount)
                {
                    this.EncodeCore(output, $.$$.S.MemoryExtensions.AsSpan$1(value, ((startIndex + indexOfFirstCharToEncode) | 0), ((characterCount - indexOfFirstCharToEncode) | 0)));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886343737)
            
            //--TRIMMABLE-BOUNDARY-START(8591376441)
            /*void */ Encode(/*TextWriter*/ output, /*char[]*/ value, /*int*/ startIndex, /*int*/ characterCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591376441);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (output === null)
                {
                    $.$stew.STEW.ThrowHelper.ThrowArgumentNullException(2/*ExceptionArgument.output*/);
                }
                if (value === null)
                {
                    $.$stew.STEW.ThrowHelper.ThrowArgumentNullException(0/*ExceptionArgument.value*/);
                }
                $.$stew.STEW.TextEncoder.ValidateRanges(startIndex, characterCount, value.length);
                /*int*/ let indexOfFirstCharToEncode = this.FindFirstCharacterToEncode$1($.$$.S.Span$$($.$$.S.Char).op_Implicit($.$$.S.MemoryExtensions.AsSpan$11($.$$.S.Char, value, startIndex, characterCount)));
                if (indexOfFirstCharToEncode < 0)
                {
                    indexOfFirstCharToEncode = characterCount;
                }
                output.Write$2(value, startIndex, indexOfFirstCharToEncode);
                if (indexOfFirstCharToEncode !== characterCount)
                {
                    this.EncodeCore(output, $.$$.S.Span$$($.$$.S.Char).op_Implicit($.$$.S.MemoryExtensions.AsSpan$11($.$$.S.Char, value, ((startIndex + indexOfFirstCharToEncode) | 0), ((characterCount - indexOfFirstCharToEncode) | 0))));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8591376441)
            
            //--TRIMMABLE-BOUNDARY-START(47246082105)
            /*OperationStatus */ EncodeUtf8(/*ReadOnlySpan<byte>*/ utf8Source, /*Span<byte>*/ utf8Destination, /*out int*/ bytesConsumed, /*out int*/ bytesWritten, /*bool*/ isFinalBlock)
            {
                /*int*/ let innerBytesConsumed;
                /*int*/ let innerBytesWritten;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246082105);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ReadOnlySpan<byte>*/ let sourceSearchSpace = utf8Source;
                if (utf8Destination.Length < utf8Source.Length)
                {
                    sourceSearchSpace = utf8Source.Slice(0, utf8Destination.Length);
                }
                /*int*/ let idxOfFirstByteToEncode = this.FindFirstCharacterToEncodeUtf8(sourceSearchSpace);
                if (idxOfFirstByteToEncode < 0)
                {
                    idxOfFirstByteToEncode = sourceSearchSpace.Length;
                }
                utf8Source.Slice(0, idxOfFirstByteToEncode).CopyTo(utf8Destination);
                if (idxOfFirstByteToEncode === utf8Source.Length)
                {
                    bytesConsumed.$v = utf8Source.Length;
                    bytesWritten.$v = utf8Source.Length;
                    return 0/*OperationStatus.Done*/;
                }
                /*OperationStatus*/ let status = this.EncodeUtf8Core(utf8Source.Slice$1(idxOfFirstByteToEncode), utf8Destination.Slice$1(idxOfFirstByteToEncode), $.$ref(() => innerBytesConsumed, ($v) => innerBytesConsumed = $v, $.$$.S.Int32), $.$ref(() => innerBytesWritten, ($v) => innerBytesWritten = $v, $.$$.S.Int32), isFinalBlock);
                bytesConsumed.$v = ((idxOfFirstByteToEncode + innerBytesConsumed) | 0);
                bytesWritten.$v = ((idxOfFirstByteToEncode + innerBytesWritten) | 0);
                return status;
            }
            //--TRIMMABLE-BOUNDARY-END(47246082105)
            
            //--TRIMMABLE-BOUNDARY-START(51541049401)
            /*OperationStatus */ EncodeUtf8Core(/*ReadOnlySpan<byte>*/ utf8Source, /*Span<byte>*/ utf8Destination, /*out int*/ bytesConsumed, /*out int*/ bytesWritten, /*bool*/ isFinalBlock)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541049401);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let originalUtf8SourceLength;
                /*int*/ let originalUtf8DestinationLength;
                /*int*/ let TempUtf16CharBufferLength;
                /*Span<char>*/ let utf16ScratchBuffer;
                /*OperationStatus*/ let retVal;
                let $gotoJumpState9 = 0;
                $gotoJumpStart9: while(true)
                {
                    switch($gotoJumpState9)
                    {
                        case 0:
                        {
                            originalUtf8SourceLength = utf8Source.Length;
                            originalUtf8DestinationLength = utf8Destination.Length;
                            TempUtf16CharBufferLength = 24;
                            utf16ScratchBuffer = $.$$.SRC.RuntimeHelpers.StackAllocSpan($.$$.S.Char, TempUtf16CharBufferLength, null);
                            $whileJumpStart10: while(!utf8Source.IsEmpty)
                            {
                                /*OperationStatus*/ let opStatus;
                                let $gotoJumpState11 = 0;
                                $gotoJumpStart11: while(true)
                                {
                                    /*int*/ var bytesWrittenJustNow;
                                    switch($gotoJumpState11)
                                    {
                                        case 0:
                                        {
                                            /*Rune*/ var scalarValue;
                                            /*int*/ var bytesConsumedJustNow;
                                            opStatus = $.$$.ST.Rune.DecodeFromUtf8(utf8Source, $.$ref(() => scalarValue, ($v) => scalarValue = $v, $.$$.ST.Rune), $.$ref(() => bytesConsumedJustNow, ($v) => bytesConsumedJustNow = $v, $.$$.S.Int32));
                                            if (opStatus !== 0/*OperationStatus.Done*/)
                                            {
                                                if (!isFinalBlock && opStatus === 2/*OperationStatus.NeedMoreData*/)
                                                {
                                                    $gotoJumpState9 = 2; /*goto NeedMoreData*/
                                                    continue $gotoJumpStart9;
                                                }
                                                $.$$.SD.Debug.Assert$4($.$$.ST.Rune.op_Equality(scalarValue, $.$$.ST.Rune.ReplacementChar), "scalarValue == Rune.ReplacementChar");
                                                $gotoJumpState11 = 1; /*goto MustEncode*/
                                                continue $gotoJumpStart11;
                                            }
                                            if (!this.WillEncode(scalarValue.Value))
                                            {
                                                /*uint*/ var utf8lsb = ($.$stew.STU.UnicodeHelpers.GetUtf8RepresentationForScalarValue((scalarValue.Value >>> 0)) >>> 0);
                                                /*int*/ var dstIdxTemp = 0;
                                                do
                                                {
                                                    if ((dstIdxTemp >>> 0) >= (utf8Destination.Length >>> 0))
                                                    {
                                                        $gotoJumpState9 = 3; /*goto DestinationTooSmall*/
                                                        continue $gotoJumpStart9;
                                                    }
                                                    utf8Destination._reference.SetAt(((utf8lsb & 0xFF) >>> 0), dstIdxTemp++);
                                                }
                                                while((utf8lsb >>= 8) !== 0);
                                                utf8Source = utf8Source.Slice$1(bytesConsumedJustNow);
                                                utf8Destination = utf8Destination.Slice$1(dstIdxTemp);
                                                continue $whileJumpStart10;
                                            }
                                        }
                                        case 1: /*MustEncode*/
                                        if (!this.TryEncodeUnicodeScalarUtf8((scalarValue.Value >>> 0), utf16ScratchBuffer, utf8Destination, $.$ref(() => bytesWrittenJustNow, ($v) => bytesWrittenJustNow = $v, $.$$.S.Int32)))
                                        {
                                            $gotoJumpState9 = 3; /*goto DestinationTooSmall*/
                                            continue $gotoJumpStart9;
                                        }
                                        utf8Source = utf8Source.Slice$1(bytesConsumedJustNow);
                                        utf8Destination = utf8Destination.Slice$1(bytesWrittenJustNow);
                                    }
                                    break;
                                }
                            }
                            retVal = 0/*OperationStatus.Done*/;
                        }
                        case 1: /*ReturnCommon*/
                        bytesConsumed.$v = ((originalUtf8SourceLength - utf8Source.Length) | 0);
                        bytesWritten.$v = ((originalUtf8DestinationLength - utf8Destination.Length) | 0);
                        return retVal;
                        case 2: /*NeedMoreData*/
                        retVal = 2/*OperationStatus.NeedMoreData*/;
                        $gotoJumpState9 = 1; /*goto ReturnCommon*/
                        continue $gotoJumpStart9;
                        case 3: /*DestinationTooSmall*/
                        retVal = 1/*OperationStatus.DestinationTooSmall*/;
                        $gotoJumpState9 = 1; /*goto ReturnCommon*/
                        continue $gotoJumpStart9;
                    }
                    break;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51541049401)
            
            //--TRIMMABLE-BOUNDARY-START(21476278329)
            /*OperationStatus */ Encode$3(/*ReadOnlySpan<char>*/ source, /*Span<char>*/ destination, /*out int*/ charsConsumed, /*out int*/ charsWritten, /*bool*/ isFinalBlock)
            {
                /*int*/ let innerCharsConsumed;
                /*int*/ let innerCharsWritten;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476278329);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ReadOnlySpan<char>*/ let sourceSearchSpace = source;
                if (destination.Length < source.Length)
                {
                    sourceSearchSpace = source.Slice(0, destination.Length);
                }
                /*int*/ let idxOfFirstCharToEncode = this.FindFirstCharacterToEncode$1(sourceSearchSpace);
                if (idxOfFirstCharToEncode < 0)
                {
                    idxOfFirstCharToEncode = sourceSearchSpace.Length;
                }
                source.Slice(0, idxOfFirstCharToEncode).CopyTo(destination);
                if (idxOfFirstCharToEncode === source.Length)
                {
                    charsConsumed.$v = source.Length;
                    charsWritten.$v = source.Length;
                    return 0/*OperationStatus.Done*/;
                }
                /*OperationStatus*/ let status = this.EncodeCore$1(source.Slice$1(idxOfFirstCharToEncode), destination.Slice$1(idxOfFirstCharToEncode), $.$ref(() => innerCharsConsumed, ($v) => innerCharsConsumed = $v, $.$$.S.Int32), $.$ref(() => innerCharsWritten, ($v) => innerCharsWritten = $v, $.$$.S.Int32), isFinalBlock);
                charsConsumed.$v = ((idxOfFirstCharToEncode + innerCharsConsumed) | 0);
                charsWritten.$v = ((idxOfFirstCharToEncode + innerCharsWritten) | 0);
                return status;
            }
            //--TRIMMABLE-BOUNDARY-END(21476278329)
            
            //--TRIMMABLE-BOUNDARY-START(34361180217)
            /*OperationStatus */ EncodeCore$1(/*ReadOnlySpan<char>*/ source, /*Span<char>*/ destination, /*out int*/ charsConsumed, /*out int*/ charsWritten, /*bool*/ isFinalBlock)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361180217);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let originalSourceLength;
                /*int*/ let originalDestinationLength;
                /*OperationStatus*/ let retVal;
                let $gotoJumpState17 = 0;
                $gotoJumpStart17: while(true)
                {
                    switch($gotoJumpState17)
                    {
                        case 0:
                        {
                            originalSourceLength = source.Length;
                            originalDestinationLength = destination.Length;
                            $whileJumpStart18: while(!source.IsEmpty)
                            {
                                /*OperationStatus*/ let status;
                                let $gotoJumpState19 = 0;
                                $gotoJumpStart19: while(true)
                                {
                                    /*int*/ var charsWrittenJustNow;
                                    switch($gotoJumpState19)
                                    {
                                        case 0:
                                        {
                                            /*Rune*/ var scalarValue;
                                            /*int*/ var charsConsumedJustNow;
                                            status = $.$$.ST.Rune.DecodeFromUtf16(source, $.$ref(() => scalarValue, ($v) => scalarValue = $v, $.$$.ST.Rune), $.$ref(() => charsConsumedJustNow, ($v) => charsConsumedJustNow = $v, $.$$.S.Int32));
                                            if (status !== 0/*OperationStatus.Done*/)
                                            {
                                                if (!isFinalBlock && status === 2/*OperationStatus.NeedMoreData*/)
                                                {
                                                    $gotoJumpState17 = 2; /*goto NeedMoreData*/
                                                    continue $gotoJumpStart17;
                                                }
                                                $.$$.SD.Debug.Assert$4($.$$.ST.Rune.op_Equality(scalarValue, $.$$.ST.Rune.ReplacementChar), "scalarValue == Rune.ReplacementChar");
                                                $gotoJumpState19 = 1; /*goto MustEncode*/
                                                continue $gotoJumpStart19;
                                            }
                                            if (!this.WillEncode(scalarValue.Value))
                                            {
                                                if (!scalarValue.TryEncodeToUtf16(destination, $.$discardRef()))
                                                {
                                                    $gotoJumpState17 = 3; /*goto DestinationTooSmall*/
                                                    continue $gotoJumpStart17;
                                                }
                                                source = source.Slice$1(charsConsumedJustNow);
                                                destination = destination.Slice$1(charsConsumedJustNow);
                                                continue $whileJumpStart18;
                                            }
                                        }
                                        case 1: /*MustEncode*/
                                        if (!this.TryEncodeUnicodeScalar$1((scalarValue.Value >>> 0), destination, $.$ref(() => charsWrittenJustNow, ($v) => charsWrittenJustNow = $v, $.$$.S.Int32)))
                                        {
                                            $gotoJumpState17 = 3; /*goto DestinationTooSmall*/
                                            continue $gotoJumpStart17;
                                        }
                                        source = source.Slice$1(charsConsumedJustNow);
                                        destination = destination.Slice$1(charsWrittenJustNow);
                                    }
                                    break;
                                }
                            }
                            retVal = 0/*OperationStatus.Done*/;
                        }
                        case 1: /*ReturnCommon*/
                        charsConsumed.$v = ((originalSourceLength - source.Length) | 0);
                        charsWritten.$v = ((originalDestinationLength - destination.Length) | 0);
                        return retVal;
                        case 2: /*NeedMoreData*/
                        retVal = 2/*OperationStatus.NeedMoreData*/;
                        $gotoJumpState17 = 1; /*goto ReturnCommon*/
                        continue $gotoJumpStart17;
                        case 3: /*DestinationTooSmall*/
                        retVal = 1/*OperationStatus.DestinationTooSmall*/;
                        $gotoJumpState17 = 1; /*goto ReturnCommon*/
                        continue $gotoJumpStart17;
                    }
                    break;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34361180217)
            
            //--TRIMMABLE-BOUNDARY-START(30066212921)
            /*void */ EncodeCore(/*TextWriter*/ output, /*ReadOnlySpan<char>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066212921);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(output !== null, "output != null");
                $.$$.SD.Debug.Assert$4(!value.IsEmpty, "Caller should've special-cased 'no encoding needed'.");
                /*int*/ let minBufferBumpEachIteration = $.$$.S.Math.Max$4(this.MaxOutputCharactersPerInputCharacter, 1024/*EncodeStartingOutputBufferSize*/);
                /*char[]*/ let rentedArray = $.$$.SB.ArrayPool$$($.$$.S.Char).Shared.Rent($.$$.S.Math.Max$4(value.Length, minBufferBumpEachIteration));
                /*Span<char>*/ let scratchBuffer = $.$$.S.Span$$($.$$.S.Char).op_Implicit$2(rentedArray);
                do
                {
                    /*int*/ let charsConsumedJustNow;
                    /*int*/ let charsWrittenJustNow;
                    this.EncodeCore$1(value, scratchBuffer, $.$ref(() => charsConsumedJustNow, ($v) => charsConsumedJustNow = $v, $.$$.S.Int32), $.$ref(() => charsWrittenJustNow, ($v) => charsWrittenJustNow = $v, $.$$.S.Int32), true);
                    if (charsWrittenJustNow === 0 || (charsWrittenJustNow >>> 0) > (scratchBuffer.Length >>> 0))
                    {
                        $.$stew.STEW.TextEncoder.ThrowArgumentException_MaxOutputCharsPerInputChar();
                    }
                    output.Write$2(rentedArray, 0, charsWrittenJustNow);
                    value = value.Slice$1(charsConsumedJustNow);
                }
                while(!value.IsEmpty);
                $.$$.SB.ArrayPool$$($.$$.S.Char).Shared.Return(rentedArray, false);
            }
            //--TRIMMABLE-BOUNDARY-END(30066212921)
            
            //--TRIMMABLE-BOUNDARY-START(60130983993)
            /*int */ FindFirstCharacterToEncode$1(/*ReadOnlySpan<char>*/ text)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130983993);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*fixed*/ 
                {
                    /*char**/ let pText = $.$$.SRI.MemoryMarshal.GetReference($.$$.S.Char, text);
                    return this.FindFirstCharacterToEncode(pText, text.Length);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60130983993)
            
            //--TRIMMABLE-BOUNDARY-START(64425951289)
            /*int */ FindFirstCharacterToEncodeUtf8(/*ReadOnlySpan<byte>*/ utf8Text)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425951289);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let utf8TextOriginalLength = utf8Text.Length;
                while(!utf8Text.IsEmpty)
                {
                    /*Rune*/ let scalarValue;
                    /*int*/ let bytesConsumed;
                    /*OperationStatus*/ let opStatus = $.$$.ST.Rune.DecodeFromUtf8(utf8Text, $.$ref(() => scalarValue, ($v) => scalarValue = $v, $.$$.ST.Rune), $.$ref(() => bytesConsumed, ($v) => bytesConsumed = $v, $.$$.S.Int32));
                    if (opStatus !== 0/*OperationStatus.Done*/ || this.WillEncode(scalarValue.Value))
                    {
                        break;
                    }
                    utf8Text = utf8Text.Slice$1(bytesConsumed);
                }
                return (utf8Text.IsEmpty) ? -1 : ((utf8TextOriginalLength - utf8Text.Length) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(64425951289)
            
            //--TRIMMABLE-BOUNDARY-START(85900787769)
            static /*bool */ TryCopyCharacters(/*string*/ source, /*Span<char>*/ destination, /*out int*/ numberOfCharactersWritten)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900787769);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(!$.$$.S.String.IsNullOrEmpty(source), "!string.IsNullOrEmpty(source)");
                if (destination.Length < source.length)
                {
                    numberOfCharactersWritten.$v = 0;
                    return false;
                }
                for(/*int*/ let i = 0; i < source.length; i++)
                {
                    destination._reference.SetAt($.$$.S.String.get_Chars.call(source, i), i);
                }
                numberOfCharactersWritten.$v = source.length;
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(85900787769)
            
            //--TRIMMABLE-BOUNDARY-START(103080656953)
            static /*bool */ TryWriteScalarAsChar(/*int*/ unicodeScalar, /*Span<char>*/ destination, /*out int*/ numberOfCharactersWritten)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080656953);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(unicodeScalar < 65535/*ushort.MaxValue*/, "unicodeScalar < ushort.MaxValue");
                if (destination.IsEmpty)
                {
                    numberOfCharactersWritten.$v = 0;
                    return false;
                }
                destination._reference.SetAt($.$cast(unicodeScalar, $.$$.S.Char), 0);
                numberOfCharactersWritten.$v = 1;
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(103080656953)
            
            //--TRIMMABLE-BOUNDARY-START(107375624249)
            static /*void */ ValidateRanges(/*int*/ startIndex, /*int*/ characterCount, /*int*/ actualInputLength)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375624249);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (startIndex < 0 || startIndex > actualInputLength)
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$20("startIndex");
                }
                if (characterCount < 0 || characterCount > (((actualInputLength - startIndex) | 0)))
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$20("characterCount");
                }
            }
            //--TRIMMABLE-BOUNDARY-END(107375624249)
            
            //--TRIMMABLE-BOUNDARY-START(81605820473)
            static /*void */ ThrowArgumentException_MaxOutputCharsPerInputChar()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605820473);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.ArgumentException().$ctor$14($.$stew.S.SR.TextEncoderDoesNotImplementMaxOutputCharsPerInputChar);
            }
            //--TRIMMABLE-BOUNDARY-END(81605820473)
            
            //--TRIMMABLE-BOUNDARY-START(4296409145)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296409145);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296409145)
            
            //--TRIMMABLE-BOUNDARY-START(4296409145)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296409145)
            
            static $h = 1441849;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(77310853177),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015885881,
        "f": 50331905
      },
      "n": "MaxOutputCharactersPerInputCharacter",
      "d": 1441849,
      "h": 77310853177,
      "f": 2097409,
      "a": [
        {
          "t": 65011713,
          "c": 12949913601,
          "a": [
            {
              "v": 1,
              "t": 65077249
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(77310853177)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(90195755065),
    {
      "r": 262145,
      "p": [
        {
          "n": "unicodeScalar",
          "p": 655361
        },
        {
          "n": "buffer",
          "p": $.$typePointer($.$$.S.Char).$h
        },
        {
          "n": "bufferLength",
          "p": 655361
        },
        {
          "n": "numberOfCharactersWritten",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryEncodeUnicodeScalar",
      "d": 1441849,
      "h": 90195755065,
      "f": 16777473,
      "a": [
        {
          "t": 54984705,
          "c": 8644919297,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        },
        {
          "t": 65011713,
          "c": 12949913601,
          "a": [
            {
              "v": 1,
              "t": 65077249
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(90195755065),
//--TRIMMABLE-BOUNDARY-START(94490722361),
    {
      "r": 262145,
      "p": [
        {
          "n": "unicodeScalar",
          "p": 720897
        },
        {
          "n": "buffer",
          "p": $.$$.S.Span$$($.$$.S.Char).$h
        },
        {
          "n": "charsWritten",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryEncodeUnicodeScalar",
      "o": "@$1",
      "d": 1441849,
      "h": 94490722361,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(94490722361),
//--TRIMMABLE-BOUNDARY-START(98785689657),
    {
      "r": 262145,
      "p": [
        {
          "n": "unicodeScalar",
          "p": 720897
        },
        {
          "n": "utf16ScratchBuffer",
          "p": $.$$.S.Span$$($.$$.S.Char).$h
        },
        {
          "n": "utf8Destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "bytesWritten",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryEncodeUnicodeScalarUtf8",
      "d": 1441849,
      "h": 98785689657,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(98785689657),
//--TRIMMABLE-BOUNDARY-START(55836016697),
    {
      "r": 655361,
      "p": [
        {
          "n": "text",
          "p": $.$typePointer($.$$.S.Char).$h
        },
        {
          "n": "textLength",
          "p": 655361
        }
      ],
      "n": "FindFirstCharacterToEncode",
      "d": 1441849,
      "h": 55836016697,
      "f": 16777473,
      "a": [
        {
          "t": 54984705,
          "c": 8644919297,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        },
        {
          "t": 65011713,
          "c": 12949913601,
          "a": [
            {
              "v": 1,
              "t": 65077249
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55836016697),
//--TRIMMABLE-BOUNDARY-START(111670591545),
    {
      "r": 262145,
      "p": [
        {
          "n": "unicodeScalar",
          "p": 655361
        }
      ],
      "n": "WillEncode",
      "d": 1441849,
      "h": 111670591545,
      "f": 16777473,
      "a": [
        {
          "t": 65011713,
          "c": 12949913601,
          "a": [
            {
              "v": 1,
              "t": 65077249
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(111670591545),
//--TRIMMABLE-BOUNDARY-START(25771245625),
    {
      "r": 1310721,
      "p": [
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "Encode",
      "o": "@$4",
      "d": 1441849,
      "h": 25771245625,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(25771245625),
//--TRIMMABLE-BOUNDARY-START(42951114809),
    {
      "r": 1310721,
      "p": [
        {
          "n": "value",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Char).$h
        },
        {
          "n": "indexOfFirstCharToEncode",
          "p": 655361
        }
      ],
      "n": "EncodeToNewString",
      "d": 1441849,
      "h": 42951114809,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(42951114809),
//--TRIMMABLE-BOUNDARY-START(17181311033),
    {
      "r": 65537,
      "p": [
        {
          "n": "output",
          "p": 96600065
        },
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "Encode",
      "o": "@$2",
      "d": 1441849,
      "h": 17181311033,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181311033),
//--TRIMMABLE-BOUNDARY-START(12886343737),
    {
      "r": 65537,
      "p": [
        {
          "n": "output",
          "p": 96600065
        },
        {
          "n": "value",
          "p": 1310721
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "characterCount",
          "p": 655361
        }
      ],
      "n": "Encode",
      "o": "@$1",
      "d": 1441849,
      "h": 12886343737,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12886343737),
//--TRIMMABLE-BOUNDARY-START(8591376441),
    {
      "r": 65537,
      "p": [
        {
          "n": "output",
          "p": 96600065
        },
        {
          "n": "value",
          "p": $.$typeArray($.$$.S.Char).$h
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "characterCount",
          "p": 655361
        }
      ],
      "n": "Encode",
      "d": 1441849,
      "h": 8591376441,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8591376441),
//--TRIMMABLE-BOUNDARY-START(47246082105),
    {
      "r": 50200577,
      "p": [
        {
          "n": "utf8Source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "utf8Destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "bytesWritten",
          "p": 655361,
          "f": 2
        },
        {
          "n": "isFinalBlock",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "n": "EncodeUtf8",
      "d": 1441849,
      "h": 47246082105,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(47246082105),
//--TRIMMABLE-BOUNDARY-START(51541049401),
    {
      "r": 50200577,
      "p": [
        {
          "n": "utf8Source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "utf8Destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "bytesWritten",
          "p": 655361,
          "f": 2
        },
        {
          "n": "isFinalBlock",
          "p": 262145
        }
      ],
      "n": "EncodeUtf8Core",
      "d": 1441849,
      "h": 51541049401,
      "f": 16777344
    },
//--TRIMMABLE-BOUNDARY-END(51541049401),
//--TRIMMABLE-BOUNDARY-START(21476278329),
    {
      "r": 50200577,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Char).$h
        },
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Char).$h
        },
        {
          "n": "charsConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "charsWritten",
          "p": 655361,
          "f": 2
        },
        {
          "n": "isFinalBlock",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "n": "Encode",
      "o": "@$3",
      "d": 1441849,
      "h": 21476278329,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(21476278329),
//--TRIMMABLE-BOUNDARY-START(34361180217),
    {
      "r": 50200577,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Char).$h
        },
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Char).$h
        },
        {
          "n": "charsConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "charsWritten",
          "p": 655361,
          "f": 2
        },
        {
          "n": "isFinalBlock",
          "p": 262145
        }
      ],
      "n": "EncodeCore",
      "o": "@$1",
      "d": 1441849,
      "h": 34361180217,
      "f": 16777344
    },
//--TRIMMABLE-BOUNDARY-END(34361180217),
//--TRIMMABLE-BOUNDARY-START(30066212921),
    {
      "r": 65537,
      "p": [
        {
          "n": "output",
          "p": 96600065
        },
        {
          "n": "value",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Char).$h
        }
      ],
      "n": "EncodeCore",
      "d": 1441849,
      "h": 30066212921,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(30066212921),
//--TRIMMABLE-BOUNDARY-START(60130983993),
    {
      "r": 655361,
      "p": [
        {
          "n": "text",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Char).$h
        }
      ],
      "n": "FindFirstCharacterToEncode",
      "o": "@$1",
      "d": 1441849,
      "h": 60130983993,
      "f": 16777344
    },
//--TRIMMABLE-BOUNDARY-END(60130983993),
//--TRIMMABLE-BOUNDARY-START(64425951289),
    {
      "r": 655361,
      "p": [
        {
          "n": "utf8Text",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        }
      ],
      "n": "FindFirstCharacterToEncodeUtf8",
      "d": 1441849,
      "h": 64425951289,
      "f": 16777345,
      "a": [
        {
          "t": 65011713,
          "c": 12949913601,
          "a": [
            {
              "v": 1,
              "t": 65077249
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(64425951289),
//--TRIMMABLE-BOUNDARY-START(85900787769),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": 1310721
        },
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Char).$h
        },
        {
          "n": "numberOfCharactersWritten",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryCopyCharacters",
      "d": 1441849,
      "h": 85900787769,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(85900787769),
//--TRIMMABLE-BOUNDARY-START(103080656953),
    {
      "r": 262145,
      "p": [
        {
          "n": "unicodeScalar",
          "p": 655361
        },
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Char).$h
        },
        {
          "n": "numberOfCharactersWritten",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryWriteScalarAsChar",
      "d": 1441849,
      "h": 103080656953,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(103080656953),
//--TRIMMABLE-BOUNDARY-START(107375624249),
    {
      "r": 65537,
      "p": [
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "characterCount",
          "p": 655361
        },
        {
          "n": "actualInputLength",
          "p": 655361
        }
      ],
      "n": "ValidateRanges",
      "d": 1441849,
      "h": 107375624249,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(107375624249),
//--TRIMMABLE-BOUNDARY-START(81605820473),
    {
      "r": 65537,
      "n": "ThrowArgumentException_MaxOutputCharsPerInputChar",
      "d": 1441849,
      "h": 81605820473,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(81605820473)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(38656147513),
    {
      "t": 655361,
      "n": "EncodeStartingOutputBufferSize",
      "d": 1441849,
      "h": 38656147513,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(38656147513)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296409145),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1441849,
      "h": 4296409145,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4296409145)
  ],
  "h": 1441849
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Text.Encodings.Web.TextEncoder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Text${separator}Encodings${separator}Web${separator}TextEncoder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1441849)
        
        

        //--TRIMMABLE-BOUNDARY-START(1179705)
        $asm.$cls(`$stew.STEW.JavaScriptEncoder`, ($self) => class JavaScriptEncoder extends $.$stew.STEW.TextEncoder
        {
            //--TRIMMABLE-BOUNDARY-START(17181048889)
            static /*JavaScriptEncoder */ get Default()
            {
                return $.$stew.STEW.DefaultJavaScriptEncoder.BasicLatinSingleton;
            }
            //--TRIMMABLE-BOUNDARY-END(17181048889)
            
            //--TRIMMABLE-BOUNDARY-START(38655885369)
            static /*JavaScriptEncoder */ get UnsafeRelaxedJsonEscaping()
            {
                return $.$stew.STEW.DefaultJavaScriptEncoder.UnsafeRelaxedEscapingSingleton;
            }
            //--TRIMMABLE-BOUNDARY-END(38655885369)
            
            //--TRIMMABLE-BOUNDARY-START(8591114297)
            static /*JavaScriptEncoder */ Create(/*TextEncoderSettings*/ settings)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591114297);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$stew.STEW.DefaultJavaScriptEncoder().$ctor$4(settings);
            }
            //--TRIMMABLE-BOUNDARY-END(8591114297)
            
            //--TRIMMABLE-BOUNDARY-START(12886081593)
            static /*JavaScriptEncoder */ Create$1(/*params UnicodeRange[]*/ allowedRanges)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886081593);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$stew.STEW.DefaultJavaScriptEncoder().$ctor$4(new $.$stew.STEW.TextEncoderSettings().$ctor$2(allowedRanges));
            }
            //--TRIMMABLE-BOUNDARY-END(12886081593)
            
            //--TRIMMABLE-BOUNDARY-START(4296147001)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296147001);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296147001)
            
            //--TRIMMABLE-BOUNDARY-START(4296147001)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296147001)
            
            static $h = 1179705;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$stew.STEW.TextEncoder; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17181048889),
    {
      "p": 1179705,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770983481,
        "f": 50331681
      },
      "n": "Default",
      "d": 1179705,
      "h": 17181048889,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(17181048889),
//--TRIMMABLE-BOUNDARY-START(38655885369),
    {
      "p": 1179705,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360918073,
        "f": 50331681
      },
      "n": "UnsafeRelaxedJsonEscaping",
      "d": 1179705,
      "h": 38655885369,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(38655885369)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591114297),
    {
      "r": 1179705,
      "p": [
        {
          "n": "settings",
          "p": 1507385
        }
      ],
      "n": "Create",
      "d": 1179705,
      "h": 8591114297,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591114297),
//--TRIMMABLE-BOUNDARY-START(12886081593),
    {
      "r": 1179705,
      "p": [
        {
          "n": "allowedRanges",
          "p": $.$typeArray($.$stew.STU.UnicodeRange).$h,
          "f": 16
        }
      ],
      "n": "Create",
      "o": "@$1",
      "d": 1179705,
      "h": 12886081593,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12886081593)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296147001),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1179705,
      "h": 4296147001,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4296147001)
  ],
  "h": 1179705
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Text.Encodings.Web.JavaScriptEncoder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Text${separator}Encodings${separator}Web${separator}JavaScriptEncoder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1179705)
        
        

        //--TRIMMABLE-BOUNDARY-START(1114169)
        $asm.$cls(`$stew.STEW.HtmlEncoder`, ($self) => class HtmlEncoder extends $.$stew.STEW.TextEncoder
        {
            //--TRIMMABLE-BOUNDARY-START(17180983353)
            static /*HtmlEncoder */ get Default()
            {
                return $.$stew.STEW.DefaultHtmlEncoder.BasicLatinSingleton;
            }
            //--TRIMMABLE-BOUNDARY-END(17180983353)
            
            //--TRIMMABLE-BOUNDARY-START(8591048761)
            static /*HtmlEncoder */ Create(/*TextEncoderSettings*/ settings)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591048761);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$stew.STEW.DefaultHtmlEncoder().$ctor$3(settings);
            }
            //--TRIMMABLE-BOUNDARY-END(8591048761)
            
            //--TRIMMABLE-BOUNDARY-START(12886016057)
            static /*HtmlEncoder */ Create$1(/*params UnicodeRange[]*/ allowedRanges)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886016057);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$stew.STEW.DefaultHtmlEncoder().$ctor$3(new $.$stew.STEW.TextEncoderSettings().$ctor$2(allowedRanges));
            }
            //--TRIMMABLE-BOUNDARY-END(12886016057)
            
            //--TRIMMABLE-BOUNDARY-START(4296081465)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296081465);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296081465)
            
            //--TRIMMABLE-BOUNDARY-START(4296081465)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296081465)
            
            static $h = 1114169;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$stew.STEW.TextEncoder; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180983353),
    {
      "p": 1114169,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770917945,
        "f": 50331681
      },
      "n": "Default",
      "d": 1114169,
      "h": 17180983353,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(17180983353)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591048761),
    {
      "r": 1114169,
      "p": [
        {
          "n": "settings",
          "p": 1507385
        }
      ],
      "n": "Create",
      "d": 1114169,
      "h": 8591048761,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591048761),
//--TRIMMABLE-BOUNDARY-START(12886016057),
    {
      "r": 1114169,
      "p": [
        {
          "n": "allowedRanges",
          "p": $.$typeArray($.$stew.STU.UnicodeRange).$h,
          "f": 16
        }
      ],
      "n": "Create",
      "o": "@$1",
      "d": 1114169,
      "h": 12886016057,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12886016057)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296081465),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1114169,
      "h": 4296081465,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4296081465)
  ],
  "h": 1114169
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Text.Encodings.Web.HtmlEncoder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Text${separator}Encodings${separator}Web${separator}HtmlEncoder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1114169)
        
        

        //--TRIMMABLE-BOUNDARY-START(1638457)
        $asm.$cls(`$stew.STEW.UrlEncoder`, ($self) => class UrlEncoder extends $.$stew.STEW.TextEncoder
        {
            //--TRIMMABLE-BOUNDARY-START(17181507641)
            static /*UrlEncoder */ get Default()
            {
                return $.$stew.STEW.DefaultUrlEncoder.BasicLatinSingleton;
            }
            //--TRIMMABLE-BOUNDARY-END(17181507641)
            
            //--TRIMMABLE-BOUNDARY-START(8591573049)
            static /*UrlEncoder */ Create(/*TextEncoderSettings*/ settings)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591573049);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$stew.STEW.DefaultUrlEncoder().$ctor$3(settings);
            }
            //--TRIMMABLE-BOUNDARY-END(8591573049)
            
            //--TRIMMABLE-BOUNDARY-START(12886540345)
            static /*UrlEncoder */ Create$1(/*params UnicodeRange[]*/ allowedRanges)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886540345);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$stew.STEW.DefaultUrlEncoder().$ctor$3(new $.$stew.STEW.TextEncoderSettings().$ctor$2(allowedRanges));
            }
            //--TRIMMABLE-BOUNDARY-END(12886540345)
            
            //--TRIMMABLE-BOUNDARY-START(4296605753)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296605753);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296605753)
            
            //--TRIMMABLE-BOUNDARY-START(4296605753)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296605753)
            
            static $h = 1638457;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$stew.STEW.TextEncoder; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17181507641),
    {
      "p": 1638457,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771442233,
        "f": 50331681
      },
      "n": "Default",
      "d": 1638457,
      "h": 17181507641,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(17181507641)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591573049),
    {
      "r": 1638457,
      "p": [
        {
          "n": "settings",
          "p": 1507385
        }
      ],
      "n": "Create",
      "d": 1638457,
      "h": 8591573049,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591573049),
//--TRIMMABLE-BOUNDARY-START(12886540345),
    {
      "r": 1638457,
      "p": [
        {
          "n": "allowedRanges",
          "p": $.$typeArray($.$stew.STU.UnicodeRange).$h,
          "f": 16
        }
      ],
      "n": "Create",
      "o": "@$1",
      "d": 1638457,
      "h": 12886540345,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12886540345)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296605753),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1638457,
      "h": 4296605753,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4296605753)
  ],
  "h": 1638457
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Text.Encodings.Web.UrlEncoder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Text${separator}Encodings${separator}Web${separator}UrlEncoder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1638457)
        
        

        //--TRIMMABLE-BOUNDARY-START(393273)
        $asm.$cls(`$stew.SI.TextWriterExtensions`, ($self) => class TextWriterExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(4295360569)
            static /*void */ WritePartialString(/*this TextWriter*/ writer, /*string*/ value, /*int*/ offset, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295360569);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(writer !== null, "writer != null");
                $.$$.SD.Debug.Assert$4(value !== null, "value != null");
                if (offset === 0 && count === value.length)
                {
                    writer.Write$16(value);
                }
                else 
                {
                    /*ReadOnlySpan<char>*/ let sliced = $.$$.S.MemoryExtensions.AsSpan$1(value, offset, count);
                    writer.Write$9(sliced);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295360569)
            
            static $h = 393273;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295360569),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 96600065
        },
        {
          "n": "value",
          "p": 1310721
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "WritePartialString",
      "d": 393273,
      "h": 4295360569,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295360569)
  ],
  "h": 393273
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IO.TextWriterExtensions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}TextWriterExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393273)
        
        

        //--TRIMMABLE-BOUNDARY-START(458809)
        $asm.$cls(`$stew.S.SR`, ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(146029346873)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(146029346873)
            
            //--TRIMMABLE-BOUNDARY-START(137439412281)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(137439412281)
            
            //--TRIMMABLE-BOUNDARY-START(141734379577)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669608505);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Object.ReferenceEquals($.$stew.S.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.SR$1.ResourceManager().$ctor$3("System.Text.Encodings.Web", $.$stew.S.SR.$type.Assembly);
                    $.$stew.S.SR.s_resourceManager = temp;
                }
                return $.$stew.S.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(141734379577)
            
            //--TRIMMABLE-BOUNDARY-START(25770262585)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079673913);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$stew.S.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914248761);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$stew.S.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(25770262585)
            
            //--TRIMMABLE-BOUNDARY-START(21475295289)
            static /*string */ get ArgumentOutOfRange_IndexMustBeLess()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489739321);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Index was out of range. Must be non-negative and less than the size of the collection.";
            }
            //--TRIMMABLE-BOUNDARY-END(21475295289)
            
            //--TRIMMABLE-BOUNDARY-START(12885360697)
            static /*string */ get Argument_CannotExtractScalar()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309870137);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot extract a Unicode scalar value from the specified index in the input.";
            }
            //--TRIMMABLE-BOUNDARY-END(12885360697)
            
            //--TRIMMABLE-BOUNDARY-START(17180327993)
            static /*string */ get Argument_DestinationTooShort()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899804729);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Destination is too short.";
            }
            //--TRIMMABLE-BOUNDARY-END(17180327993)
            
            //--TRIMMABLE-BOUNDARY-START(8590393401)
            static /*string */ get Arg_MustBeRune()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719935545);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Object must be of type Rune.";
            }
            //--TRIMMABLE-BOUNDARY-END(8590393401)
            
            //--TRIMMABLE-BOUNDARY-START(163209216057)
            static /*string */ get TextEncoderDoesNotImplementMaxOutputCharsPerInputChar()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259543097);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "TextEncoder does not implement MaxOutputCharsPerInputChar correctly.";
            }
            //--TRIMMABLE-BOUNDARY-END(163209216057)
            
            //--TRIMMABLE-BOUNDARY-START(150324314169)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(150324314169)
            
            //--TRIMMABLE-BOUNDARY-START(133144444985)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    /*bool*/ let usingResourceKeys;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(133144444985);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.S.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(133144444985)
            
            //--TRIMMABLE-BOUNDARY-START(167504183353)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(167504183353);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$stew.S.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(167504183353)
            
            //--TRIMMABLE-BOUNDARY-START(128849477689)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849477689);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$stew.S.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$stew.S.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(128849477689)
            
            //--TRIMMABLE-BOUNDARY-START(124554510393)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554510393);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$stew.S.SR.GetResourceString$1(resourceKey);
                return resourceKey === resourceString || resourceString === null ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(124554510393)
            
            //--TRIMMABLE-BOUNDARY-START(55835033657)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835033657);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$stew.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.S.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(55835033657)
            
            //--TRIMMABLE-BOUNDARY-START(51540066361)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540066361);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$stew.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.S.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(51540066361)
            
            //--TRIMMABLE-BOUNDARY-START(47245099065)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245099065);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$stew.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.S.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(47245099065)
            
            //--TRIMMABLE-BOUNDARY-START(60130000953)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130000953);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$stew.S.SR.UsingResourceKeys())
                    {
                        return $.$strNN(resourceFormat) + ", " + $.$strNN($.$$.S.String.Join$6(", ", args));
                    }
                    return $.$$.S.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(60130000953)
            
            //--TRIMMABLE-BOUNDARY-START(38655164473)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655164473);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$stew.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.S.String.Format$4(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(38655164473)
            
            //--TRIMMABLE-BOUNDARY-START(34360197177)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360197177);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$stew.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.S.String.Format$3(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(34360197177)
            
            //--TRIMMABLE-BOUNDARY-START(30065229881)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065229881);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$stew.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.S.String.Format$2(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(30065229881)
            
            //--TRIMMABLE-BOUNDARY-START(42950131769)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950131769);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$stew.S.SR.UsingResourceKeys())
                    {
                        return $.$strNN(resourceFormat) + ", " + $.$strNN($.$$.S.String.Join$6(", ", args));
                    }
                    return $.$$.S.String.Format$5(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(42950131769)
            
            //--TRIMMABLE-BOUNDARY-START(4295426105)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295426105);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(150324314169)
                    this.s_usingResourceKeys = $.$stew.S.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(150324314169)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295426105)
            
            static $h = 458809;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 458809
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.SR`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458809)
        
        

        //--TRIMMABLE-BOUNDARY-START(1572921)
        $asm.$cls(`$stew.STEW.ThrowHelper`, ($self) => class ThrowHelper
        {
            //--TRIMMABLE-BOUNDARY-START(8591507513)
            static /*void */ ThrowArgumentNullException(/*ExceptionArgument*/ argument)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591507513);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.ArgumentNullException().$ctor$19($.$stew.STEW.ThrowHelper.GetArgumentName(argument));
            }
            //--TRIMMABLE-BOUNDARY-END(8591507513)
            
            //--TRIMMABLE-BOUNDARY-START(12886474809)
            static /*void */ ThrowArgumentOutOfRangeException(/*ExceptionArgument*/ argument)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886474809);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.ArgumentOutOfRangeException().$ctor$20($.$stew.STEW.ThrowHelper.GetArgumentName(argument));
            }
            //--TRIMMABLE-BOUNDARY-END(12886474809)
            
            //--TRIMMABLE-BOUNDARY-START(4296540217)
            static /*string */ GetArgumentName(/*ExceptionArgument*/ argument)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296540217);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4($.$$.S.Enum.IsDefined($.$stew.STEW.ExceptionArgument.$type, $.$box(argument, $.$stew.STEW.ExceptionArgument)), "The enum value is not defined, please check the ExceptionArgument Enum.");
                return $.$$.S.Enum.ToStringT($.$stew.STEW.ExceptionArgument, $.$$.S.UInt32, argument);
            }
            //--TRIMMABLE-BOUNDARY-END(4296540217)
            
            static $h = 1572921;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591507513),
    {
      "r": 65537,
      "p": [
        {
          "n": "argument",
          "p": 1048633
        }
      ],
      "n": "ThrowArgumentNullException",
      "d": 1572921,
      "h": 8591507513,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8591507513),
//--TRIMMABLE-BOUNDARY-START(12886474809),
    {
      "r": 65537,
      "p": [
        {
          "n": "argument",
          "p": 1048633
        }
      ],
      "n": "ThrowArgumentOutOfRangeException",
      "d": 1572921,
      "h": 12886474809,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12886474809),
//--TRIMMABLE-BOUNDARY-START(4296540217),
    {
      "r": 1310721,
      "p": [
        {
          "n": "argument",
          "p": 1048633
        }
      ],
      "n": "GetArgumentName",
      "d": 1572921,
      "h": 4296540217,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(4296540217)
  ],
  "h": 1572921
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Text.Encodings.Web.ThrowHelper`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Text${separator}Encodings${separator}Web${separator}ThrowHelper`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1572921)
        
        

        //--TRIMMABLE-BOUNDARY-START(1769529)
        $asm.$cls(`$stew.STU.UnicodeRange`, ($self) => class UnicodeRange extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12886671417)
            $ctor$1(/*int*/ firstCodePoint, /*int*/ length)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886671417);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (firstCodePoint < 0 || firstCodePoint > 65535)
                    {
                        throw new $.$$.S.ArgumentOutOfRangeException().$ctor$20("firstCodePoint");
                    }
                    if (length < 0 || (BigInt.asIntN(64, $.$cast(firstCodePoint, $.$$.S.Int64) + $.$cast(length, $.$$.S.Int64)) > 65536n))
                    {
                        throw new $.$$.S.ArgumentOutOfRangeException().$ctor$20("length");
                    }
                    this.FirstCodePoint = firstCodePoint;
                    this.Length = length;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886671417)
            
            //--TRIMMABLE-BOUNDARY-START(21476606009)
            /*int*/ FirstCodePoint = 0;
            //--TRIMMABLE-BOUNDARY-END(21476606009)
            
            //--TRIMMABLE-BOUNDARY-START(42951442489)
            /*int*/ Length = 0;
            //--TRIMMABLE-BOUNDARY-END(42951442489)
            
            //--TRIMMABLE-BOUNDARY-START(17181638713)
            static /*UnicodeRange */ Create(/*char*/ firstCharacter, /*char*/ lastCharacter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181638713);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (lastCharacter < firstCharacter)
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$20("lastCharacter");
                }
                return new $.$stew.STU.UnicodeRange().$ctor$1(firstCharacter, ((1 + (lastCharacter - firstCharacter)) | 0));
            }
            //--TRIMMABLE-BOUNDARY-END(17181638713)
            
            static $h = 1769529;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21476606009),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066540601,
        "f": 50331649
      },
      "n": "FirstCodePoint",
      "d": 1769529,
      "h": 21476606009,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476606009),
//--TRIMMABLE-BOUNDARY-START(42951442489),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656475193,
        "f": 50331649
      },
      "n": "Length",
      "d": 1769529,
      "h": 42951442489,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42951442489)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181638713),
    {
      "r": 1769529,
      "p": [
        {
          "n": "firstCharacter",
          "p": 458753
        },
        {
          "n": "lastCharacter",
          "p": 458753
        }
      ],
      "n": "Create",
      "d": 1769529,
      "h": 17181638713,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17181638713)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886671417),
    {
      "p": [
        {
          "n": "firstCodePoint",
          "p": 655361
        },
        {
          "n": "length",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1769529,
      "h": 12886671417,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886671417)
  ],
  "h": 1769529
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Text.Unicode.UnicodeRange`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Text${separator}Unicode${separator}UnicodeRange`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1769529)
        
        

        //--TRIMMABLE-BOUNDARY-START(1703993)
        $asm.$cls(`$stew.STU.UnicodeHelpers`, ($self) => class UnicodeHelpers
        {
            //--TRIMMABLE-BOUNDARY-START(34361442361)
            /*int*/ static UNICODE_LAST_CODEPOINT = 1114111;
            //--TRIMMABLE-BOUNDARY-END(34361442361)
            
            //--TRIMMABLE-BOUNDARY-START(17181573177)
            static /*ReadOnlySpan<byte> */ GetDefinedBmpCodePointsBitmapLittleEndian()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181573177);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$stew.STU.UnicodeHelpers.DefinedCharsBitmapSpan;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17181573177)
            
            //--TRIMMABLE-BOUNDARY-START(21476540473)
            static /*void */ GetUtf16SurrogatePairFromAstralScalarValue(/*uint*/ scalar, /*out char*/ highSurrogate, /*out char*/ lowSurrogate)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476540473);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(65536 <= scalar && scalar <= 1114111/*UNICODE_LAST_CODEPOINT*/, "0x10000 <= scalar && scalar <= UNICODE_LAST_CODEPOINT");
                $.$stew.ST.UnicodeDebug.AssertIsValidSupplementaryPlaneScalar(scalar);
                highSurrogate.$v = ((((((scalar + (((((55296 - 64) >>> 0)) << 10) >>> 0)) >>> 0)) >>> 10) & 0xFFFF) >>> 0);
                lowSurrogate.$v = ((((((scalar & 1023) + 56320) >>> 0)) & 0xFFFF) >>> 0);
            }
            //--TRIMMABLE-BOUNDARY-END(21476540473)
            
            //--TRIMMABLE-BOUNDARY-START(25771507769)
            static /*int */ GetUtf8RepresentationForScalarValue(/*uint*/ scalar)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771507769);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(scalar <= 1114111/*UNICODE_LAST_CODEPOINT*/, "scalar <= UNICODE_LAST_CODEPOINT");
                if (scalar <= 127)
                {
                    /*byte*/ let firstByte = ((scalar & 0xFF) >>> 0);
                    return firstByte;
                }
                else if (scalar <= 2047)
                {
                    /*byte*/ let firstByte = (((192 | (scalar >>> 6)) & 0xFF) >>> 0);
                    /*byte*/ let secondByteByte = (((128 | (scalar & 63)) & 0xFF) >>> 0);
                    return (((secondByteByte << 8) >>> 0) | firstByte);
                }
                else if (scalar <= 65535)
                {
                    /*byte*/ let firstByte = (((224 | (scalar >>> 12)) & 0xFF) >>> 0);
                    /*byte*/ let secondByte = (((128 | ((scalar >>> 6) & 63)) & 0xFF) >>> 0);
                    /*byte*/ let thirdByte = (((128 | (scalar & 63)) & 0xFF) >>> 0);
                    return (((((thirdByte << 8) >>> 0) | secondByte) << 8) | firstByte);
                }
                else 
                {
                    /*byte*/ let firstByte = (((240 | (scalar >>> 18)) & 0xFF) >>> 0);
                    /*byte*/ let secondByte = (((128 | ((scalar >>> 12) & 63)) & 0xFF) >>> 0);
                    /*byte*/ let thirdByte = (((128 | ((scalar >>> 6) & 63)) & 0xFF) >>> 0);
                    /*byte*/ let fourthByte = (((128 | (scalar & 63)) & 0xFF) >>> 0);
                    return (((((((fourthByte << 8) >>> 0) | thirdByte) << 8) | secondByte) << 8) | firstByte);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25771507769)
            
            //--TRIMMABLE-BOUNDARY-START(30066475065)
            static /*bool */ IsSupplementaryCodePoint(/*int*/ scalar)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066475065);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return ((scalar & ~(/*\uFFFF*/ 65535)) !== 0);
            }
            //--TRIMMABLE-BOUNDARY-END(30066475065)
            
            //--TRIMMABLE-BOUNDARY-START(4296671289)
            static /*ReadOnlySpan<byte> */ get DefinedCharsBitmapSpan()
            {
                return this.$cacheDefinedCharsBitmapSpan ??= new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7([ 0, 0, 0, 0, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 127, 0, 0, 0, 0, 254, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 252, 240, 215, 255, 255, 251, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 254, 255, 255, 255, 127, 254, 255, 255, 255, 255, 255, 231, 254, 255, 255, 255, 255, 255, 255, 0, 255, 255, 255, 135, 31, 0, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 191, 255, 255, 255, 255, 255, 255, 255, 231, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 3, 0, 255, 255, 255, 255, 255, 255, 255, 231, 255, 255, 255, 255, 255, 63, 255, 127, 255, 255, 255, 79, 255, 7, 255, 255, 255, 127, 131, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 239, 159, 249, 255, 255, 253, 197, 243, 159, 121, 128, 176, 207, 255, 255, 127, 238, 135, 249, 255, 255, 253, 109, 211, 135, 57, 2, 94, 192, 255, 127, 0, 238, 191, 251, 255, 255, 253, 237, 243, 191, 59, 1, 0, 207, 255, 3, 254, 238, 159, 249, 255, 255, 253, 237, 243, 159, 57, 224, 176, 207, 255, 255, 0, 236, 199, 61, 214, 24, 199, 255, 195, 199, 61, 129, 0, 192, 255, 255, 7, 255, 223, 253, 255, 255, 253, 255, 243, 223, 61, 96, 39, 207, 255, 128, 255, 255, 223, 253, 255, 255, 253, 239, 243, 223, 61, 96, 96, 207, 255, 14, 0, 255, 223, 253, 255, 255, 255, 255, 255, 223, 253, 240, 255, 207, 255, 255, 255, 238, 255, 127, 252, 255, 255, 251, 47, 127, 132, 95, 255, 192, 255, 28, 0, 254, 255, 255, 255, 255, 255, 255, 135, 255, 255, 255, 15, 0, 0, 0, 0, 214, 247, 255, 255, 175, 255, 255, 63, 95, 127, 255, 243, 0, 0, 0, 0, 255, 255, 255, 255, 255, 255, 255, 255, 255, 254, 255, 255, 255, 31, 254, 255, 255, 255, 255, 254, 255, 255, 255, 223, 255, 223, 255, 7, 0, 0, 0, 0, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 191, 32, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 61, 127, 61, 255, 255, 255, 255, 255, 61, 255, 255, 255, 255, 61, 127, 61, 255, 127, 255, 255, 255, 255, 255, 255, 255, 61, 255, 255, 255, 255, 255, 255, 255, 255, 231, 255, 255, 255, 31, 255, 255, 255, 3, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 63, 63, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 254, 255, 255, 31, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 1, 255, 255, 63, 128, 255, 255, 127, 0, 255, 255, 15, 0, 255, 223, 13, 0, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 63, 255, 3, 255, 3, 255, 255, 255, 3, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 1, 255, 255, 255, 255, 255, 7, 255, 255, 255, 255, 255, 255, 255, 255, 63, 0, 255, 255, 255, 127, 255, 15, 255, 15, 241, 255, 255, 255, 255, 63, 31, 0, 255, 255, 255, 255, 255, 15, 255, 255, 255, 3, 255, 199, 255, 255, 255, 255, 255, 255, 255, 207, 255, 255, 255, 255, 255, 255, 255, 127, 255, 255, 255, 159, 255, 3, 255, 3, 255, 63, 255, 255, 255, 127, 0, 0, 0, 0, 0, 0, 255, 255, 255, 255, 255, 255, 255, 255, 255, 223, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 15, 240, 255, 255, 255, 255, 255, 255, 255, 248, 255, 227, 255, 255, 255, 255, 255, 255, 255, 7, 255, 255, 255, 255, 255, 231, 255, 0, 255, 255, 255, 255, 255, 7, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 63, 63, 255, 255, 255, 255, 63, 63, 255, 170, 255, 255, 255, 63, 255, 255, 255, 255, 255, 255, 223, 255, 223, 255, 207, 239, 255, 255, 220, 127, 0, 248, 255, 255, 255, 124, 255, 255, 255, 255, 255, 127, 223, 255, 243, 255, 255, 127, 255, 31, 255, 255, 255, 255, 1, 0, 255, 255, 255, 255, 1, 0, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 15, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 3, 0, 0, 255, 7, 0, 0, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 207, 255, 255, 255, 191, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 15, 254, 255, 255, 255, 255, 191, 32, 255, 255, 255, 255, 255, 255, 255, 128, 1, 128, 255, 255, 127, 0, 127, 127, 127, 127, 127, 127, 127, 127, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 63, 0, 0, 0, 0, 255, 255, 255, 251, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 15, 0, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 63, 0, 0, 0, 255, 255, 254, 255, 255, 255, 255, 255, 255, 255, 254, 255, 255, 255, 255, 255, 255, 255, 255, 255, 127, 254, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 224, 255, 255, 255, 255, 255, 254, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 127, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 63, 128, 255, 255, 255, 255, 255, 127, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 31, 255, 255, 255, 255, 255, 255, 127, 0, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 15, 0, 0, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 0, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 63, 235, 31, 0, 0, 252, 255, 255, 255, 255, 255, 255, 31, 255, 3, 255, 255, 255, 255, 255, 255, 255, 0, 255, 255, 255, 255, 255, 255, 255, 255, 63, 192, 255, 3, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 15, 128, 255, 255, 255, 31, 255, 255, 255, 255, 255, 255, 255, 255, 255, 191, 255, 195, 255, 255, 255, 127, 255, 255, 255, 255, 255, 255, 127, 0, 255, 63, 255, 243, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 7, 0, 0, 248, 255, 255, 127, 0, 126, 126, 126, 0, 127, 127, 255, 255, 255, 255, 255, 255, 255, 15, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 63, 255, 3, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 15, 0, 255, 255, 127, 248, 255, 255, 255, 255, 255, 15, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 63, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 3, 0, 0, 0, 0, 127, 0, 248, 224, 255, 255, 127, 95, 219, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 7, 0, 248, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 252, 255, 255, 255, 255, 255, 255, 128, 0, 0, 0, 0, 255, 255, 255, 255, 255, 3, 255, 255, 255, 255, 255, 255, 247, 255, 127, 15, 223, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 31, 254, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 127, 252, 252, 252, 28, 127, 127, 0, 62 ]);
            }
            //--TRIMMABLE-BOUNDARY-END(4296671289)
            
            static $h = 1703993;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(4296671289),
    {
      "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12886605881,
        "f": 50331682
      },
      "n": "DefinedCharsBitmapSpan",
      "d": 1703993,
      "h": 4296671289,
      "f": 2097186
    },
//--TRIMMABLE-BOUNDARY-END(4296671289)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181573177),
    {
      "r": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "n": "GetDefinedBmpCodePointsBitmapLittleEndian",
      "d": 1703993,
      "h": 17181573177,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(17181573177),
//--TRIMMABLE-BOUNDARY-START(21476540473),
    {
      "r": 65537,
      "p": [
        {
          "n": "scalar",
          "p": 720897
        },
        {
          "n": "highSurrogate",
          "p": 458753,
          "f": 2
        },
        {
          "n": "lowSurrogate",
          "p": 458753,
          "f": 2
        }
      ],
      "n": "GetUtf16SurrogatePairFromAstralScalarValue",
      "d": 1703993,
      "h": 21476540473,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(21476540473),
//--TRIMMABLE-BOUNDARY-START(25771507769),
    {
      "r": 655361,
      "p": [
        {
          "n": "scalar",
          "p": 720897
        }
      ],
      "n": "GetUtf8RepresentationForScalarValue",
      "d": 1703993,
      "h": 25771507769,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(25771507769),
//--TRIMMABLE-BOUNDARY-START(30066475065),
    {
      "r": 262145,
      "p": [
        {
          "n": "scalar",
          "p": 655361
        }
      ],
      "n": "IsSupplementaryCodePoint",
      "d": 1703993,
      "h": 30066475065,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(30066475065)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(34361442361),
    {
      "t": 655361,
      "n": "UNICODE_LAST_CODEPOINT",
      "d": 1703993,
      "h": 34361442361,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(34361442361)
  ],
  "h": 1703993
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Text.Unicode.UnicodeHelpers`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Text${separator}Unicode${separator}UnicodeHelpers`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1703993)
        
        

        //--TRIMMABLE-BOUNDARY-START(1507385)
        $asm.$cls(`$stew.STEW.TextEncoderSettings`, ($self) => class TextEncoderSettings extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296474681)
            /*AllowedBmpCodePointsBitmap*/ _allowedCodePointsBitmap;
            //--TRIMMABLE-BOUNDARY-END(4296474681)
            
            //--TRIMMABLE-BOUNDARY-START(8591441977)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591441977);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591441977)
            
            //--TRIMMABLE-BOUNDARY-START(17181376569)
            $ctor$3(/*TextEncoderSettings*/ other)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181376569);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (other === null)
                    {
                        $.$stew.STEW.ThrowHelper.ThrowArgumentNullException(3/*ExceptionArgument.other*/);
                    }
                    this._allowedCodePointsBitmap = other.GetAllowedCodePointsBitmap().$v;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181376569)
            
            //--TRIMMABLE-BOUNDARY-START(12886409273)
            $ctor$2(/*params UnicodeRange[]*/ allowedRanges)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886409273);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (allowedRanges === null)
                    {
                        $.$stew.STEW.ThrowHelper.ThrowArgumentNullException(4/*ExceptionArgument.allowedRanges*/);
                    }
                    this.AllowRanges(allowedRanges);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886409273)
            
            //--TRIMMABLE-BOUNDARY-START(21476343865)
            /*void */ AllowCharacter(/*char*/ character)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476343865);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._allowedCodePointsBitmap.AllowChar(character);
            }
            //--TRIMMABLE-BOUNDARY-END(21476343865)
            
            //--TRIMMABLE-BOUNDARY-START(25771311161)
            /*void */ AllowCharacters(/*params char[]*/ characters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771311161);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (characters === null)
                {
                    $.$stew.STEW.ThrowHelper.ThrowArgumentNullException(5/*ExceptionArgument.characters*/);
                }
                for(/*int*/ let i = 0; i < characters.length; i++)
                {
                    this._allowedCodePointsBitmap.AllowChar($.$$.System.Array.$ReadT1.call(characters, i));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25771311161)
            
            //--TRIMMABLE-BOUNDARY-START(30066278457)
            /*void */ AllowCodePoints(/*IEnumerable<int>*/ codePoints)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066278457);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (codePoints === null)
                {
                    $.$stew.STEW.ThrowHelper.ThrowArgumentNullException(6/*ExceptionArgument.codePoints*/);
                }
                let $en1 = codePoints.SCG$IEnumerable$$$GetEnumerator();
                while ($en1.SC$1$IEnumerator$MoveNext())
                {
                    let allowedCodePoint = $en1.SCG$IEnumerator$$$Current;
                    {
                        if ($.$stew.ST.UnicodeUtility.IsBmpCodePoint((allowedCodePoint >>> 0)))
                        {
                            this._allowedCodePointsBitmap.AllowChar($.$cast(allowedCodePoint, $.$$.S.Char));
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30066278457)
            
            //--TRIMMABLE-BOUNDARY-START(34361245753)
            /*void */ AllowRange(/*UnicodeRange*/ range)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361245753);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (range === null)
                {
                    $.$stew.STEW.ThrowHelper.ThrowArgumentNullException(7/*ExceptionArgument.range*/);
                }
                /*int*/ let firstCodePoint = range.FirstCodePoint;
                /*int*/ let rangeSize = range.Length;
                for(/*int*/ let i = 0; i < rangeSize; i++)
                {
                    /*int*/ let codePoint = ((firstCodePoint + i) | 0);
                    $.$stew.ST.UnicodeDebug.AssertIsBmpCodePoint((codePoint >>> 0));
                    this._allowedCodePointsBitmap.AllowChar($.$cast(codePoint, $.$$.S.Char));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34361245753)
            
            //--TRIMMABLE-BOUNDARY-START(38656213049)
            /*void */ AllowRanges(/*params UnicodeRange[]*/ ranges)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656213049);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (ranges === null)
                {
                    $.$stew.STEW.ThrowHelper.ThrowArgumentNullException(8/*ExceptionArgument.ranges*/);
                }
                for(/*int*/ let i = 0; i < ranges.length; i++)
                {
                    this.AllowRange($.$$.System.Array.$ReadT1.call(ranges, i));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38656213049)
            
            //--TRIMMABLE-BOUNDARY-START(42951180345)
            /*void */ Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951180345);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._allowedCodePointsBitmap = new $.$stew.STEW.AllowedBmpCodePointsBitmap();
            }
            //--TRIMMABLE-BOUNDARY-END(42951180345)
            
            //--TRIMMABLE-BOUNDARY-START(47246147641)
            /*void */ ForbidCharacter(/*char*/ character)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246147641);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._allowedCodePointsBitmap.ForbidChar(character);
            }
            //--TRIMMABLE-BOUNDARY-END(47246147641)
            
            //--TRIMMABLE-BOUNDARY-START(51541114937)
            /*void */ ForbidCharacters(/*params char[]*/ characters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541114937);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (characters === null)
                {
                    $.$stew.STEW.ThrowHelper.ThrowArgumentNullException(5/*ExceptionArgument.characters*/);
                }
                for(/*int*/ let i = 0; i < characters.length; i++)
                {
                    this._allowedCodePointsBitmap.ForbidChar($.$$.System.Array.$ReadT1.call(characters, i));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51541114937)
            
            //--TRIMMABLE-BOUNDARY-START(55836082233)
            /*void */ ForbidRange(/*UnicodeRange*/ range)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836082233);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (range === null)
                {
                    $.$stew.STEW.ThrowHelper.ThrowArgumentNullException(7/*ExceptionArgument.range*/);
                }
                /*int*/ let firstCodePoint = range.FirstCodePoint;
                /*int*/ let rangeSize = range.Length;
                for(/*int*/ let i = 0; i < rangeSize; i++)
                {
                    /*int*/ let codePoint = ((firstCodePoint + i) | 0);
                    $.$stew.ST.UnicodeDebug.AssertIsBmpCodePoint((codePoint >>> 0));
                    this._allowedCodePointsBitmap.ForbidChar($.$cast(codePoint, $.$$.S.Char));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55836082233)
            
            //--TRIMMABLE-BOUNDARY-START(60131049529)
            /*void */ ForbidRanges(/*params UnicodeRange[]*/ ranges)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131049529);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (ranges === null)
                {
                    $.$stew.STEW.ThrowHelper.ThrowArgumentNullException(8/*ExceptionArgument.ranges*/);
                }
                for(/*int*/ let i = 0; i < ranges.length; i++)
                {
                    this.ForbidRange($.$$.System.Array.$ReadT1.call(ranges, i));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60131049529)
            
            //--TRIMMABLE-BOUNDARY-START(64426016825)
            /*IEnumerable<int> */ GetAllowedCodePoints()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.S.Int32))().$ctor$1(function*()
                {
                    for(/*int*/ let i = 0; i <= /*\uFFFF*/ 65535; i++)
                    {
                        if (this._allowedCodePointsBitmap.IsCharAllowed($.$cast(i, $.$$.S.Char)))
                        {
                            yield i;
                        }
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(64426016825)
            
            //--TRIMMABLE-BOUNDARY-START(68720984121)
            /*ref readonly AllowedBmpCodePointsBitmap */ GetAllowedCodePointsBitmap()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720984121);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Object.GetType.call(this) === $.$stew.STEW.TextEncoderSettings.$type)
                {
                    return $.$ref(() => this._allowedCodePointsBitmap, ($v) => this._allowedCodePointsBitmap = $v, $.$stew.STEW.AllowedBmpCodePointsBitmap);
                }
                else 
                {
                    /*StrongBox<AllowedBmpCodePointsBitmap>*/ let newBitmap = new ($.$$.SRC.StrongBox$$($.$stew.STEW.AllowedBmpCodePointsBitmap))().$ctor$1();
                    let $en2 = this.GetAllowedCodePoints().SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let allowedCodePoint = $en2.SCG$IEnumerator$$$Current;
                        {
                            if ((allowedCodePoint >>> 0) <= /*\uFFFF*/ 65535)
                            {
                                newBitmap.Value.AllowChar($.$cast(allowedCodePoint, $.$$.S.Char));
                            }
                        }
                    }
                    return $.$ref(() => newBitmap.Value, ($v) => newBitmap.Value = $v, $.$stew.STEW.AllowedBmpCodePointsBitmap);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68720984121)
            
            //--TRIMMABLE-BOUNDARY-START(8591441977)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8591441977)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4296474681)
                this._allowedCodePointsBitmap = $.$default($.$stew.STEW.AllowedBmpCodePointsBitmap);
                //--TRIMMABLE-BOUNDARY-END(4296474681)
                
            }
            static $h = 1507385;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(21476343865),
    {
      "r": 65537,
      "p": [
        {
          "n": "character",
          "p": 458753
        }
      ],
      "n": "AllowCharacter",
      "d": 1507385,
      "h": 21476343865,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(21476343865),
//--TRIMMABLE-BOUNDARY-START(25771311161),
    {
      "r": 65537,
      "p": [
        {
          "n": "characters",
          "p": $.$typeArray($.$$.S.Char).$h,
          "f": 16
        }
      ],
      "n": "AllowCharacters",
      "d": 1507385,
      "h": 25771311161,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(25771311161),
//--TRIMMABLE-BOUNDARY-START(30066278457),
    {
      "r": 65537,
      "p": [
        {
          "n": "codePoints",
          "p": $.$$.SCG.IEnumerable$$($.$$.S.Int32).$h
        }
      ],
      "n": "AllowCodePoints",
      "d": 1507385,
      "h": 30066278457,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(30066278457),
//--TRIMMABLE-BOUNDARY-START(34361245753),
    {
      "r": 65537,
      "p": [
        {
          "n": "range",
          "p": 1769529
        }
      ],
      "n": "AllowRange",
      "d": 1507385,
      "h": 34361245753,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(34361245753),
//--TRIMMABLE-BOUNDARY-START(38656213049),
    {
      "r": 65537,
      "p": [
        {
          "n": "ranges",
          "p": $.$typeArray($.$stew.STU.UnicodeRange).$h,
          "f": 16
        }
      ],
      "n": "AllowRanges",
      "d": 1507385,
      "h": 38656213049,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(38656213049),
//--TRIMMABLE-BOUNDARY-START(42951180345),
    {
      "r": 65537,
      "n": "Clear",
      "d": 1507385,
      "h": 42951180345,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(42951180345),
//--TRIMMABLE-BOUNDARY-START(47246147641),
    {
      "r": 65537,
      "p": [
        {
          "n": "character",
          "p": 458753
        }
      ],
      "n": "ForbidCharacter",
      "d": 1507385,
      "h": 47246147641,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(47246147641),
//--TRIMMABLE-BOUNDARY-START(51541114937),
    {
      "r": 65537,
      "p": [
        {
          "n": "characters",
          "p": $.$typeArray($.$$.S.Char).$h,
          "f": 16
        }
      ],
      "n": "ForbidCharacters",
      "d": 1507385,
      "h": 51541114937,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(51541114937),
//--TRIMMABLE-BOUNDARY-START(55836082233),
    {
      "r": 65537,
      "p": [
        {
          "n": "range",
          "p": 1769529
        }
      ],
      "n": "ForbidRange",
      "d": 1507385,
      "h": 55836082233,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(55836082233),
//--TRIMMABLE-BOUNDARY-START(60131049529),
    {
      "r": 65537,
      "p": [
        {
          "n": "ranges",
          "p": $.$typeArray($.$stew.STU.UnicodeRange).$h,
          "f": 16
        }
      ],
      "n": "ForbidRanges",
      "d": 1507385,
      "h": 60131049529,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(60131049529),
//--TRIMMABLE-BOUNDARY-START(64426016825),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Int32).$h,
      "n": "GetAllowedCodePoints",
      "d": 1507385,
      "h": 64426016825,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(64426016825),
//--TRIMMABLE-BOUNDARY-START(68720984121),
    {
      "r": 524345,
      "n": "GetAllowedCodePointsBitmap",
      "d": 1507385,
      "h": 68720984121,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(68720984121)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296474681),
    {
      "t": 524345,
      "n": "_allowedCodePointsBitmap",
      "d": 1507385,
      "h": 4296474681,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296474681)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591441977),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1507385,
      "h": 8591441977,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591441977),
//--TRIMMABLE-BOUNDARY-START(17181376569),
    {
      "p": [
        {
          "n": "other",
          "p": 1507385
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1507385,
      "h": 17181376569,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181376569),
//--TRIMMABLE-BOUNDARY-START(12886409273),
    {
      "p": [
        {
          "n": "allowedRanges",
          "p": $.$typeArray($.$stew.STU.UnicodeRange).$h,
          "f": 16
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1507385,
      "h": 12886409273,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886409273)
  ],
  "h": 1507385
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Text.Encodings.Web.TextEncoderSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Text${separator}Encodings${separator}Web${separator}TextEncoderSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1507385)
        
        

        //--TRIMMABLE-BOUNDARY-START(1835065)
        $asm.$cls(`$stew.STU.UnicodeRanges`, ($self) => class UnicodeRanges
        {
            //--TRIMMABLE-BOUNDARY-START(2594162081849)
            static /*UnicodeRange */ get None()
            {
                return $.$stew.STU.UnicodeRanges._none ?? $.$stew.STU.UnicodeRanges.CreateEmptyRange($.$ref(() => $.$stew.STU.UnicodeRanges._none, ($v) => $.$stew.STU.UnicodeRanges._none = $v, $.$stew.STU.UnicodeRange));
            }
            //--TRIMMABLE-BOUNDARY-END(2594162081849)
            
            //--TRIMMABLE-BOUNDARY-START(8591769657)
            /*UnicodeRange?*/ static _none = null;
            //--TRIMMABLE-BOUNDARY-END(8591769657)
            
            //--TRIMMABLE-BOUNDARY-START(700081504313)
            static /*UnicodeRange */ get All()
            {
                return $.$stew.STU.UnicodeRanges._all ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._all, ($v) => $.$stew.STU.UnicodeRanges._all = $v, $.$stew.STU.UnicodeRange), /*\u0000*/ 0, /*\uFFFF*/ 65535);
            }
            //--TRIMMABLE-BOUNDARY-END(700081504313)
            
            //--TRIMMABLE-BOUNDARY-START(4296802361)
            /*UnicodeRange?*/ static _all = null;
            //--TRIMMABLE-BOUNDARY-END(4296802361)
            
            //--TRIMMABLE-BOUNDARY-START(876175163449)
            static /*UnicodeRange */ CreateEmptyRange(/*ref UnicodeRange?*/ range)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(876175163449);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                range.$v = new $.$stew.STU.UnicodeRange().$ctor$1(0, 0);
                return range.$v;
            }
            //--TRIMMABLE-BOUNDARY-END(876175163449)
            
            //--TRIMMABLE-BOUNDARY-START(880470130745)
            static /*UnicodeRange */ CreateRange(/*ref UnicodeRange?*/ range, /*char*/ first, /*char*/ last)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(880470130745);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                range.$v = $.$stew.STU.UnicodeRange.Create(first, last);
                return range.$v;
            }
            //--TRIMMABLE-BOUNDARY-END(880470130745)
            
            //--TRIMMABLE-BOUNDARY-START(751621111865)
            static /*UnicodeRange */ get BasicLatin()
            {
                return $.$stew.STU.UnicodeRanges._u0000 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u0000, ($v) => $.$stew.STU.UnicodeRanges._u0000 = $v, $.$stew.STU.UnicodeRange), /*\u0000*/ 0, /*\u007F*/ 127);
            }
            //--TRIMMABLE-BOUNDARY-END(751621111865)
            
            //--TRIMMABLE-BOUNDARY-START(12886736953)
            /*UnicodeRange?*/ static _u0000 = null;
            //--TRIMMABLE-BOUNDARY-END(12886736953)
            
            //--TRIMMABLE-BOUNDARY-START(2473902997561)
            static /*UnicodeRange */ get Latin1Supplement()
            {
                return $.$stew.STU.UnicodeRanges._u0080 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u0080, ($v) => $.$stew.STU.UnicodeRanges._u0080 = $v, $.$stew.STU.UnicodeRange), /*\u0080*/ 128, /*\u00FF*/ 255);
            }
            //--TRIMMABLE-BOUNDARY-END(2473902997561)
            
            //--TRIMMABLE-BOUNDARY-START(17181704249)
            /*UnicodeRange?*/ static _u0080 = null;
            //--TRIMMABLE-BOUNDARY-END(17181704249)
            
            //--TRIMMABLE-BOUNDARY-START(2478197964857)
            static /*UnicodeRange */ get LatinExtendedA()
            {
                return $.$stew.STU.UnicodeRanges._u0100 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u0100, ($v) => $.$stew.STU.UnicodeRanges._u0100 = $v, $.$stew.STU.UnicodeRange), /*\u0100*/ 256, /*\u017F*/ 383);
            }
            //--TRIMMABLE-BOUNDARY-END(2478197964857)
            
            //--TRIMMABLE-BOUNDARY-START(21476671545)
            /*UnicodeRange?*/ static _u0100 = null;
            //--TRIMMABLE-BOUNDARY-END(21476671545)
            
            //--TRIMMABLE-BOUNDARY-START(2486787899449)
            static /*UnicodeRange */ get LatinExtendedB()
            {
                return $.$stew.STU.UnicodeRanges._u0180 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u0180, ($v) => $.$stew.STU.UnicodeRanges._u0180 = $v, $.$stew.STU.UnicodeRange), /*\u0180*/ 384, /*\u024F*/ 591);
            }
            //--TRIMMABLE-BOUNDARY-END(2486787899449)
            
            //--TRIMMABLE-BOUNDARY-START(25771638841)
            /*UnicodeRange?*/ static _u0180 = null;
            //--TRIMMABLE-BOUNDARY-END(25771638841)
            
            //--TRIMMABLE-BOUNDARY-START(2426658357305)
            static /*UnicodeRange */ get IpaExtensions()
            {
                return $.$stew.STU.UnicodeRanges._u0250 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u0250, ($v) => $.$stew.STU.UnicodeRanges._u0250 = $v, $.$stew.STU.UnicodeRange), /*\u0250*/ 592, /*\u02AF*/ 687);
            }
            //--TRIMMABLE-BOUNDARY-END(2426658357305)
            
            //--TRIMMABLE-BOUNDARY-START(30066606137)
            /*UnicodeRange?*/ static _u0250 = null;
            //--TRIMMABLE-BOUNDARY-END(30066606137)
            
            //--TRIMMABLE-BOUNDARY-START(2658586591289)
            static /*UnicodeRange */ get SpacingModifierLetters()
            {
                return $.$stew.STU.UnicodeRanges._u02B0 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u02B0, ($v) => $.$stew.STU.UnicodeRanges._u02B0 = $v, $.$stew.STU.UnicodeRange), /*\u02B0*/ 688, /*\u02FF*/ 767);
            }
            //--TRIMMABLE-BOUNDARY-END(2658586591289)
            
            //--TRIMMABLE-BOUNDARY-START(34361573433)
            /*UnicodeRange?*/ static _u02B0 = null;
            //--TRIMMABLE-BOUNDARY-END(34361573433)
            
            //--TRIMMABLE-BOUNDARY-START(841815425081)
            static /*UnicodeRange */ get CombiningDiacriticalMarks()
            {
                return $.$stew.STU.UnicodeRanges._u0300 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u0300, ($v) => $.$stew.STU.UnicodeRanges._u0300 = $v, $.$stew.STU.UnicodeRange), /*\u0300*/ 768, /*\u036F*/ 879);
            }
            //--TRIMMABLE-BOUNDARY-END(841815425081)
            
            //--TRIMMABLE-BOUNDARY-START(38656540729)
            /*UnicodeRange?*/ static _u0300 = null;
            //--TRIMMABLE-BOUNDARY-END(38656540729)
            
            //--TRIMMABLE-BOUNDARY-START(2366528815161)
            static /*UnicodeRange */ get GreekandCoptic()
            {
                return $.$stew.STU.UnicodeRanges._u0370 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u0370, ($v) => $.$stew.STU.UnicodeRanges._u0370 = $v, $.$stew.STU.UnicodeRange), /*\u0370*/ 880, /*\u03FF*/ 1023);
            }
            //--TRIMMABLE-BOUNDARY-END(2366528815161)
            
            //--TRIMMABLE-BOUNDARY-START(42951508025)
            /*UnicodeRange?*/ static _u0370 = null;
            //--TRIMMABLE-BOUNDARY-END(42951508025)
            
            //--TRIMMABLE-BOUNDARY-START(889060065337)
            static /*UnicodeRange */ get Cyrillic()
            {
                return $.$stew.STU.UnicodeRanges._u0400 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u0400, ($v) => $.$stew.STU.UnicodeRanges._u0400 = $v, $.$stew.STU.UnicodeRange), /*\u0400*/ 1024, /*\u04FF*/ 1279);
            }
            //--TRIMMABLE-BOUNDARY-END(889060065337)
            
            //--TRIMMABLE-BOUNDARY-START(47246475321)
            /*UnicodeRange?*/ static _u0400 = null;
            //--TRIMMABLE-BOUNDARY-END(47246475321)
            
            //--TRIMMABLE-BOUNDARY-START(906239934521)
            static /*UnicodeRange */ get CyrillicSupplement()
            {
                return $.$stew.STU.UnicodeRanges._u0500 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u0500, ($v) => $.$stew.STU.UnicodeRanges._u0500 = $v, $.$stew.STU.UnicodeRange), /*\u0500*/ 1280, /*\u052F*/ 1327);
            }
            //--TRIMMABLE-BOUNDARY-END(906239934521)
            
            //--TRIMMABLE-BOUNDARY-START(51541442617)
            /*UnicodeRange?*/ static _u0500 = null;
            //--TRIMMABLE-BOUNDARY-END(51541442617)
            
            //--TRIMMABLE-BOUNDARY-START(734441242681)
            static /*UnicodeRange */ get Armenian()
            {
                return $.$stew.STU.UnicodeRanges._u0530 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u0530, ($v) => $.$stew.STU.UnicodeRanges._u0530 = $v, $.$stew.STU.UnicodeRange), /*\u0530*/ 1328, /*\u058F*/ 1423);
            }
            //--TRIMMABLE-BOUNDARY-END(734441242681)
            
            //--TRIMMABLE-BOUNDARY-START(55836409913)
            /*UnicodeRange?*/ static _u0530 = null;
            //--TRIMMABLE-BOUNDARY-END(55836409913)
            
            //--TRIMMABLE-BOUNDARY-START(2413773455417)
            static /*UnicodeRange */ get Hebrew()
            {
                return $.$stew.STU.UnicodeRanges._u0590 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u0590, ($v) => $.$stew.STU.UnicodeRanges._u0590 = $v, $.$stew.STU.UnicodeRange), /*\u0590*/ 1424, /*\u05FF*/ 1535);
            }
            //--TRIMMABLE-BOUNDARY-END(2413773455417)
            
            //--TRIMMABLE-BOUNDARY-START(60131377209)
            /*UnicodeRange?*/ static _u0590 = null;
            //--TRIMMABLE-BOUNDARY-END(60131377209)
            
            //--TRIMMABLE-BOUNDARY-START(708671438905)
            static /*UnicodeRange */ get Arabic()
            {
                return $.$stew.STU.UnicodeRanges._u0600 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u0600, ($v) => $.$stew.STU.UnicodeRanges._u0600 = $v, $.$stew.STU.UnicodeRange), /*\u0600*/ 1536, /*\u06FF*/ 1791);
            }
            //--TRIMMABLE-BOUNDARY-END(708671438905)
            
            //--TRIMMABLE-BOUNDARY-START(64426344505)
            /*UnicodeRange?*/ static _u0600 = null;
            //--TRIMMABLE-BOUNDARY-END(64426344505)
            
            //--TRIMMABLE-BOUNDARY-START(2701536264249)
            static /*UnicodeRange */ get Syriac()
            {
                return $.$stew.STU.UnicodeRanges._u0700 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u0700, ($v) => $.$stew.STU.UnicodeRanges._u0700 = $v, $.$stew.STU.UnicodeRange), /*\u0700*/ 1792, /*\u074F*/ 1871);
            }
            //--TRIMMABLE-BOUNDARY-END(2701536264249)
            
            //--TRIMMABLE-BOUNDARY-START(68721311801)
            /*UnicodeRange?*/ static _u0700 = null;
            //--TRIMMABLE-BOUNDARY-END(68721311801)
            
            //--TRIMMABLE-BOUNDARY-START(730146275385)
            static /*UnicodeRange */ get ArabicSupplement()
            {
                return $.$stew.STU.UnicodeRanges._u0750 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u0750, ($v) => $.$stew.STU.UnicodeRanges._u0750 = $v, $.$stew.STU.UnicodeRange), /*\u0750*/ 1872, /*\u077F*/ 1919);
            }
            //--TRIMMABLE-BOUNDARY-END(730146275385)
            
            //--TRIMMABLE-BOUNDARY-START(73016279097)
            /*UnicodeRange?*/ static _u0750 = null;
            //--TRIMMABLE-BOUNDARY-END(73016279097)
            
            //--TRIMMABLE-BOUNDARY-START(2740190969913)
            static /*UnicodeRange */ get Thaana()
            {
                return $.$stew.STU.UnicodeRanges._u0780 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u0780, ($v) => $.$stew.STU.UnicodeRanges._u0780 = $v, $.$stew.STU.UnicodeRange), /*\u0780*/ 1920, /*\u07BF*/ 1983);
            }
            //--TRIMMABLE-BOUNDARY-END(2740190969913)
            
            //--TRIMMABLE-BOUNDARY-START(77311246393)
            /*UnicodeRange?*/ static _u0780 = null;
            //--TRIMMABLE-BOUNDARY-END(77311246393)
            
            //--TRIMMABLE-BOUNDARY-START(2589867114553)
            static /*UnicodeRange */ get NKo()
            {
                return $.$stew.STU.UnicodeRanges._u07C0 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u07C0, ($v) => $.$stew.STU.UnicodeRanges._u07C0 = $v, $.$stew.STU.UnicodeRange), /*\u07C0*/ 1984, /*\u07FF*/ 2047);
            }
            //--TRIMMABLE-BOUNDARY-END(2589867114553)
            
            //--TRIMMABLE-BOUNDARY-START(81606213689)
            /*UnicodeRange?*/ static _u07C0 = null;
            //--TRIMMABLE-BOUNDARY-END(81606213689)
            
            //--TRIMMABLE-BOUNDARY-START(2641406722105)
            static /*UnicodeRange */ get Samaritan()
            {
                return $.$stew.STU.UnicodeRanges._u0800 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u0800, ($v) => $.$stew.STU.UnicodeRanges._u0800 = $v, $.$stew.STU.UnicodeRange), /*\u0800*/ 2048, /*\u083F*/ 2111);
            }
            //--TRIMMABLE-BOUNDARY-END(2641406722105)
            
            //--TRIMMABLE-BOUNDARY-START(85901180985)
            /*UnicodeRange?*/ static _u0800 = null;
            //--TRIMMABLE-BOUNDARY-END(85901180985)
            
            //--TRIMMABLE-BOUNDARY-START(2525442605113)
            static /*UnicodeRange */ get Mandaic()
            {
                return $.$stew.STU.UnicodeRanges._u0840 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u0840, ($v) => $.$stew.STU.UnicodeRanges._u0840 = $v, $.$stew.STU.UnicodeRange), /*\u0840*/ 2112, /*\u085F*/ 2143);
            }
            //--TRIMMABLE-BOUNDARY-END(2525442605113)
            
            //--TRIMMABLE-BOUNDARY-START(90196148281)
            /*UnicodeRange?*/ static _u0840 = null;
            //--TRIMMABLE-BOUNDARY-END(90196148281)
            
            //--TRIMMABLE-BOUNDARY-START(2705831231545)
            static /*UnicodeRange */ get SyriacSupplement()
            {
                return $.$stew.STU.UnicodeRanges._u0860 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u0860, ($v) => $.$stew.STU.UnicodeRanges._u0860 = $v, $.$stew.STU.UnicodeRange), /*\u0860*/ 2144, /*\u086F*/ 2159);
            }
            //--TRIMMABLE-BOUNDARY-END(2705831231545)
            
            //--TRIMMABLE-BOUNDARY-START(94491115577)
            /*UnicodeRange?*/ static _u0860 = null;
            //--TRIMMABLE-BOUNDARY-END(94491115577)
            
            //--TRIMMABLE-BOUNDARY-START(717261373497)
            static /*UnicodeRange */ get ArabicExtendedB()
            {
                return $.$stew.STU.UnicodeRanges._u0870 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u0870, ($v) => $.$stew.STU.UnicodeRanges._u0870 = $v, $.$stew.STU.UnicodeRange), /*\u0870*/ 2160, /*\u089F*/ 2207);
            }
            //--TRIMMABLE-BOUNDARY-END(717261373497)
            
            //--TRIMMABLE-BOUNDARY-START(98786082873)
            /*UnicodeRange?*/ static _u0870 = null;
            //--TRIMMABLE-BOUNDARY-END(98786082873)
            
            //--TRIMMABLE-BOUNDARY-START(712966406201)
            static /*UnicodeRange */ get ArabicExtendedA()
            {
                return $.$stew.STU.UnicodeRanges._u08A0 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u08A0, ($v) => $.$stew.STU.UnicodeRanges._u08A0 = $v, $.$stew.STU.UnicodeRange), /*\u08A0*/ 2208, /*\u08FF*/ 2303);
            }
            //--TRIMMABLE-BOUNDARY-END(712966406201)
            
            //--TRIMMABLE-BOUNDARY-START(103081050169)
            /*UnicodeRange?*/ static _u08A0 = null;
            //--TRIMMABLE-BOUNDARY-END(103081050169)
            
            //--TRIMMABLE-BOUNDARY-START(910534901817)
            static /*UnicodeRange */ get Devanagari()
            {
                return $.$stew.STU.UnicodeRanges._u0900 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u0900, ($v) => $.$stew.STU.UnicodeRanges._u0900 = $v, $.$stew.STU.UnicodeRange), /*\u0900*/ 2304, /*\u097F*/ 2431);
            }
            //--TRIMMABLE-BOUNDARY-END(910534901817)
            
            //--TRIMMABLE-BOUNDARY-START(107376017465)
            /*UnicodeRange?*/ static _u0900 = null;
            //--TRIMMABLE-BOUNDARY-END(107376017465)
            
            //--TRIMMABLE-BOUNDARY-START(760211046457)
            static /*UnicodeRange */ get Bengali()
            {
                return $.$stew.STU.UnicodeRanges._u0980 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u0980, ($v) => $.$stew.STU.UnicodeRanges._u0980 = $v, $.$stew.STU.UnicodeRange), /*\u0980*/ 2432, /*\u09FF*/ 2559);
            }
            //--TRIMMABLE-BOUNDARY-END(760211046457)
            
            //--TRIMMABLE-BOUNDARY-START(111670984761)
            /*UnicodeRange?*/ static _u0980 = null;
            //--TRIMMABLE-BOUNDARY-END(111670984761)
            
            //--TRIMMABLE-BOUNDARY-START(2379413717049)
            static /*UnicodeRange */ get Gurmukhi()
            {
                return $.$stew.STU.UnicodeRanges._u0A00 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u0A00, ($v) => $.$stew.STU.UnicodeRanges._u0A00 = $v, $.$stew.STU.UnicodeRange), /*\u0A00*/ 2560, /*\u0A7F*/ 2687);
            }
            //--TRIMMABLE-BOUNDARY-END(2379413717049)
            
            //--TRIMMABLE-BOUNDARY-START(115965952057)
            /*UnicodeRange?*/ static _u0A00 = null;
            //--TRIMMABLE-BOUNDARY-END(115965952057)
            
            //--TRIMMABLE-BOUNDARY-START(2375118749753)
            static /*UnicodeRange */ get Gujarati()
            {
                return $.$stew.STU.UnicodeRanges._u0A80 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u0A80, ($v) => $.$stew.STU.UnicodeRanges._u0A80 = $v, $.$stew.STU.UnicodeRange), /*\u0A80*/ 2688, /*\u0AFF*/ 2815);
            }
            //--TRIMMABLE-BOUNDARY-END(2375118749753)
            
            //--TRIMMABLE-BOUNDARY-START(120260919353)
            /*UnicodeRange?*/ static _u0A80 = null;
            //--TRIMMABLE-BOUNDARY-END(120260919353)
            
            //--TRIMMABLE-BOUNDARY-START(2615636918329)
            static /*UnicodeRange */ get Oriya()
            {
                return $.$stew.STU.UnicodeRanges._u0B00 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u0B00, ($v) => $.$stew.STU.UnicodeRanges._u0B00 = $v, $.$stew.STU.UnicodeRange), /*\u0B00*/ 2816, /*\u0B7F*/ 2943);
            }
            //--TRIMMABLE-BOUNDARY-END(2615636918329)
            
            //--TRIMMABLE-BOUNDARY-START(124555886649)
            /*UnicodeRange?*/ static _u0B00 = null;
            //--TRIMMABLE-BOUNDARY-END(124555886649)
            
            //--TRIMMABLE-BOUNDARY-START(2731601035321)
            static /*UnicodeRange */ get Tamil()
            {
                return $.$stew.STU.UnicodeRanges._u0B80 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u0B80, ($v) => $.$stew.STU.UnicodeRanges._u0B80 = $v, $.$stew.STU.UnicodeRange), /*\u0B80*/ 2944, /*\u0BFF*/ 3071);
            }
            //--TRIMMABLE-BOUNDARY-END(2731601035321)
            
            //--TRIMMABLE-BOUNDARY-START(128850853945)
            /*UnicodeRange?*/ static _u0B80 = null;
            //--TRIMMABLE-BOUNDARY-END(128850853945)
            
            //--TRIMMABLE-BOUNDARY-START(2735896002617)
            static /*UnicodeRange */ get Telugu()
            {
                return $.$stew.STU.UnicodeRanges._u0C00 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u0C00, ($v) => $.$stew.STU.UnicodeRanges._u0C00 = $v, $.$stew.STU.UnicodeRange), /*\u0C00*/ 3072, /*\u0C7F*/ 3199);
            }
            //--TRIMMABLE-BOUNDARY-END(2735896002617)
            
            //--TRIMMABLE-BOUNDARY-START(133145821241)
            /*UnicodeRange?*/ static _u0C00 = null;
            //--TRIMMABLE-BOUNDARY-END(133145821241)
            
            //--TRIMMABLE-BOUNDARY-START(2443838226489)
            static /*UnicodeRange */ get Kannada()
            {
                return $.$stew.STU.UnicodeRanges._u0C80 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u0C80, ($v) => $.$stew.STU.UnicodeRanges._u0C80 = $v, $.$stew.STU.UnicodeRange), /*\u0C80*/ 3200, /*\u0CFF*/ 3327);
            }
            //--TRIMMABLE-BOUNDARY-END(2443838226489)
            
            //--TRIMMABLE-BOUNDARY-START(137440788537)
            /*UnicodeRange?*/ static _u0C80 = null;
            //--TRIMMABLE-BOUNDARY-END(137440788537)
            
            //--TRIMMABLE-BOUNDARY-START(2521147637817)
            static /*UnicodeRange */ get Malayalam()
            {
                return $.$stew.STU.UnicodeRanges._u0D00 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u0D00, ($v) => $.$stew.STU.UnicodeRanges._u0D00 = $v, $.$stew.STU.UnicodeRange), /*\u0D00*/ 3328, /*\u0D7F*/ 3455);
            }
            //--TRIMMABLE-BOUNDARY-END(2521147637817)
            
            //--TRIMMABLE-BOUNDARY-START(141735755833)
            /*UnicodeRange?*/ static _u0D00 = null;
            //--TRIMMABLE-BOUNDARY-END(141735755833)
            
            //--TRIMMABLE-BOUNDARY-START(2649996656697)
            static /*UnicodeRange */ get Sinhala()
            {
                return $.$stew.STU.UnicodeRanges._u0D80 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u0D80, ($v) => $.$stew.STU.UnicodeRanges._u0D80 = $v, $.$stew.STU.UnicodeRange), /*\u0D80*/ 3456, /*\u0DFF*/ 3583);
            }
            //--TRIMMABLE-BOUNDARY-END(2649996656697)
            
            //--TRIMMABLE-BOUNDARY-START(146030723129)
            /*UnicodeRange?*/ static _u0D80 = null;
            //--TRIMMABLE-BOUNDARY-END(146030723129)
            
            //--TRIMMABLE-BOUNDARY-START(2744485937209)
            static /*UnicodeRange */ get Thai()
            {
                return $.$stew.STU.UnicodeRanges._u0E00 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u0E00, ($v) => $.$stew.STU.UnicodeRanges._u0E00 = $v, $.$stew.STU.UnicodeRange), /*\u0E00*/ 3584, /*\u0E7F*/ 3711);
            }
            //--TRIMMABLE-BOUNDARY-END(2744485937209)
            
            //--TRIMMABLE-BOUNDARY-START(150325690425)
            /*UnicodeRange?*/ static _u0E00 = null;
            //--TRIMMABLE-BOUNDARY-END(150325690425)
            
            //--TRIMMABLE-BOUNDARY-START(2469608030265)
            static /*UnicodeRange */ get Lao()
            {
                return $.$stew.STU.UnicodeRanges._u0E80 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u0E80, ($v) => $.$stew.STU.UnicodeRanges._u0E80 = $v, $.$stew.STU.UnicodeRange), /*\u0E80*/ 3712, /*\u0EFF*/ 3839);
            }
            //--TRIMMABLE-BOUNDARY-END(2469608030265)
            
            //--TRIMMABLE-BOUNDARY-START(154620657721)
            /*UnicodeRange?*/ static _u0E80 = null;
            //--TRIMMABLE-BOUNDARY-END(154620657721)
            
            //--TRIMMABLE-BOUNDARY-START(2748780904505)
            static /*UnicodeRange */ get Tibetan()
            {
                return $.$stew.STU.UnicodeRanges._u0F00 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u0F00, ($v) => $.$stew.STU.UnicodeRanges._u0F00 = $v, $.$stew.STU.UnicodeRange), /*\u0F00*/ 3840, /*\u0FFF*/ 4095);
            }
            //--TRIMMABLE-BOUNDARY-END(2748780904505)
            
            //--TRIMMABLE-BOUNDARY-START(158915625017)
            /*UnicodeRange?*/ static _u0F00 = null;
            //--TRIMMABLE-BOUNDARY-END(158915625017)
            
            //--TRIMMABLE-BOUNDARY-START(2572687245369)
            static /*UnicodeRange */ get Myanmar()
            {
                return $.$stew.STU.UnicodeRanges._u1000 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u1000, ($v) => $.$stew.STU.UnicodeRanges._u1000 = $v, $.$stew.STU.UnicodeRange), /*\u1000*/ 4096, /*\u109F*/ 4255);
            }
            //--TRIMMABLE-BOUNDARY-END(2572687245369)
            
            //--TRIMMABLE-BOUNDARY-START(163210592313)
            /*UnicodeRange?*/ static _u1000 = null;
            //--TRIMMABLE-BOUNDARY-END(163210592313)
            
            //--TRIMMABLE-BOUNDARY-START(957779542073)
            static /*UnicodeRange */ get Georgian()
            {
                return $.$stew.STU.UnicodeRanges._u10A0 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u10A0, ($v) => $.$stew.STU.UnicodeRanges._u10A0 = $v, $.$stew.STU.UnicodeRange), /*\u10A0*/ 4256, /*\u10FF*/ 4351);
            }
            //--TRIMMABLE-BOUNDARY-END(957779542073)
            
            //--TRIMMABLE-BOUNDARY-START(167505559609)
            /*UnicodeRange?*/ static _u10A0 = null;
            //--TRIMMABLE-BOUNDARY-END(167505559609)
            
            //--TRIMMABLE-BOUNDARY-START(2392298618937)
            static /*UnicodeRange */ get HangulJamo()
            {
                return $.$stew.STU.UnicodeRanges._u1100 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u1100, ($v) => $.$stew.STU.UnicodeRanges._u1100 = $v, $.$stew.STU.UnicodeRange), /*\u1100*/ 4352, /*\u11FF*/ 4607);
            }
            //--TRIMMABLE-BOUNDARY-END(2392298618937)
            
            //--TRIMMABLE-BOUNDARY-START(171800526905)
            /*UnicodeRange?*/ static _u1100 = null;
            //--TRIMMABLE-BOUNDARY-END(171800526905)
            
            //--TRIMMABLE-BOUNDARY-START(932009738297)
            static /*UnicodeRange */ get Ethiopic()
            {
                return $.$stew.STU.UnicodeRanges._u1200 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u1200, ($v) => $.$stew.STU.UnicodeRanges._u1200 = $v, $.$stew.STU.UnicodeRange), /*\u1200*/ 4608, /*\u137F*/ 4991);
            }
            //--TRIMMABLE-BOUNDARY-END(932009738297)
            
            //--TRIMMABLE-BOUNDARY-START(176095494201)
            /*UnicodeRange?*/ static _u1200 = null;
            //--TRIMMABLE-BOUNDARY-END(176095494201)
            
            //--TRIMMABLE-BOUNDARY-START(944894640185)
            static /*UnicodeRange */ get EthiopicSupplement()
            {
                return $.$stew.STU.UnicodeRanges._u1380 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u1380, ($v) => $.$stew.STU.UnicodeRanges._u1380 = $v, $.$stew.STU.UnicodeRange), /*\u1380*/ 4992, /*\u139F*/ 5023);
            }
            //--TRIMMABLE-BOUNDARY-END(944894640185)
            
            //--TRIMMABLE-BOUNDARY-START(180390461497)
            /*UnicodeRange?*/ static _u1380 = null;
            //--TRIMMABLE-BOUNDARY-END(180390461497)
            
            //--TRIMMABLE-BOUNDARY-START(798865752121)
            static /*UnicodeRange */ get Cherokee()
            {
                return $.$stew.STU.UnicodeRanges._u13A0 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u13A0, ($v) => $.$stew.STU.UnicodeRanges._u13A0 = $v, $.$stew.STU.UnicodeRange), /*\u13A0*/ 5024, /*\u13FF*/ 5119);
            }
            //--TRIMMABLE-BOUNDARY-END(798865752121)
            
            //--TRIMMABLE-BOUNDARY-START(184685428793)
            /*UnicodeRange?*/ static _u13A0 = null;
            //--TRIMMABLE-BOUNDARY-END(184685428793)
            
            //--TRIMMABLE-BOUNDARY-START(2757370839097)
            static /*UnicodeRange */ get UnifiedCanadianAboriginalSyllabics()
            {
                return $.$stew.STU.UnicodeRanges._u1400 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u1400, ($v) => $.$stew.STU.UnicodeRanges._u1400 = $v, $.$stew.STU.UnicodeRange), /*\u1400*/ 5120, /*\u167F*/ 5759);
            }
            //--TRIMMABLE-BOUNDARY-END(2757370839097)
            
            //--TRIMMABLE-BOUNDARY-START(188980396089)
            /*UnicodeRange?*/ static _u1400 = null;
            //--TRIMMABLE-BOUNDARY-END(188980396089)
            
            //--TRIMMABLE-BOUNDARY-START(2602752016441)
            static /*UnicodeRange */ get Ogham()
            {
                return $.$stew.STU.UnicodeRanges._u1680 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u1680, ($v) => $.$stew.STU.UnicodeRanges._u1680 = $v, $.$stew.STU.UnicodeRange), /*\u1680*/ 5760, /*\u169F*/ 5791);
            }
            //--TRIMMABLE-BOUNDARY-END(2602752016441)
            
            //--TRIMMABLE-BOUNDARY-START(193275363385)
            /*UnicodeRange?*/ static _u1680 = null;
            //--TRIMMABLE-BOUNDARY-END(193275363385)
            
            //--TRIMMABLE-BOUNDARY-START(2637111754809)
            static /*UnicodeRange */ get Runic()
            {
                return $.$stew.STU.UnicodeRanges._u16A0 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u16A0, ($v) => $.$stew.STU.UnicodeRanges._u16A0 = $v, $.$stew.STU.UnicodeRange), /*\u16A0*/ 5792, /*\u16FF*/ 5887);
            }
            //--TRIMMABLE-BOUNDARY-END(2637111754809)
            
            //--TRIMMABLE-BOUNDARY-START(197570330681)
            /*UnicodeRange?*/ static _u16A0 = null;
            //--TRIMMABLE-BOUNDARY-END(197570330681)
            
            //--TRIMMABLE-BOUNDARY-START(2710126198841)
            static /*UnicodeRange */ get Tagalog()
            {
                return $.$stew.STU.UnicodeRanges._u1700 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u1700, ($v) => $.$stew.STU.UnicodeRanges._u1700 = $v, $.$stew.STU.UnicodeRange), /*\u1700*/ 5888, /*\u171F*/ 5919);
            }
            //--TRIMMABLE-BOUNDARY-END(2710126198841)
            
            //--TRIMMABLE-BOUNDARY-START(201865297977)
            /*UnicodeRange?*/ static _u1700 = null;
            //--TRIMMABLE-BOUNDARY-END(201865297977)
            
            //--TRIMMABLE-BOUNDARY-START(2409478488121)
            static /*UnicodeRange */ get Hanunoo()
            {
                return $.$stew.STU.UnicodeRanges._u1720 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u1720, ($v) => $.$stew.STU.UnicodeRanges._u1720 = $v, $.$stew.STU.UnicodeRange), /*\u1720*/ 5920, /*\u173F*/ 5951);
            }
            //--TRIMMABLE-BOUNDARY-END(2409478488121)
            
            //--TRIMMABLE-BOUNDARY-START(206160265273)
            /*UnicodeRange?*/ static _u1720 = null;
            //--TRIMMABLE-BOUNDARY-END(206160265273)
            
            //--TRIMMABLE-BOUNDARY-START(790275817529)
            static /*UnicodeRange */ get Buhid()
            {
                return $.$stew.STU.UnicodeRanges._u1740 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u1740, ($v) => $.$stew.STU.UnicodeRanges._u1740 = $v, $.$stew.STU.UnicodeRange), /*\u1740*/ 5952, /*\u175F*/ 5983);
            }
            //--TRIMMABLE-BOUNDARY-END(790275817529)
            
            //--TRIMMABLE-BOUNDARY-START(210455232569)
            /*UnicodeRange?*/ static _u1740 = null;
            //--TRIMMABLE-BOUNDARY-END(210455232569)
            
            //--TRIMMABLE-BOUNDARY-START(2714421166137)
            static /*UnicodeRange */ get Tagbanwa()
            {
                return $.$stew.STU.UnicodeRanges._u1760 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u1760, ($v) => $.$stew.STU.UnicodeRanges._u1760 = $v, $.$stew.STU.UnicodeRange), /*\u1760*/ 5984, /*\u177F*/ 6015);
            }
            //--TRIMMABLE-BOUNDARY-END(2714421166137)
            
            //--TRIMMABLE-BOUNDARY-START(214750199865)
            /*UnicodeRange?*/ static _u1760 = null;
            //--TRIMMABLE-BOUNDARY-END(214750199865)
            
            //--TRIMMABLE-BOUNDARY-START(2461018095673)
            static /*UnicodeRange */ get Khmer()
            {
                return $.$stew.STU.UnicodeRanges._u1780 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u1780, ($v) => $.$stew.STU.UnicodeRanges._u1780 = $v, $.$stew.STU.UnicodeRange), /*\u1780*/ 6016, /*\u17FF*/ 6143);
            }
            //--TRIMMABLE-BOUNDARY-END(2461018095673)
            
            //--TRIMMABLE-BOUNDARY-START(219045167161)
            /*UnicodeRange?*/ static _u1780 = null;
            //--TRIMMABLE-BOUNDARY-END(219045167161)
            
            //--TRIMMABLE-BOUNDARY-START(2568392278073)
            static /*UnicodeRange */ get Mongolian()
            {
                return $.$stew.STU.UnicodeRanges._u1800 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u1800, ($v) => $.$stew.STU.UnicodeRanges._u1800 = $v, $.$stew.STU.UnicodeRange), /*\u1800*/ 6144, /*\u18AF*/ 6319);
            }
            //--TRIMMABLE-BOUNDARY-END(2568392278073)
            
            //--TRIMMABLE-BOUNDARY-START(223340134457)
            /*UnicodeRange?*/ static _u1800 = null;
            //--TRIMMABLE-BOUNDARY-END(223340134457)
            
            //--TRIMMABLE-BOUNDARY-START(2761665806393)
            static /*UnicodeRange */ get UnifiedCanadianAboriginalSyllabicsExtended()
            {
                return $.$stew.STU.UnicodeRanges._u18B0 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u18B0, ($v) => $.$stew.STU.UnicodeRanges._u18B0 = $v, $.$stew.STU.UnicodeRange), /*\u18B0*/ 6320, /*\u18FF*/ 6399);
            }
            //--TRIMMABLE-BOUNDARY-END(2761665806393)
            
            //--TRIMMABLE-BOUNDARY-START(227635101753)
            /*UnicodeRange?*/ static _u18B0 = null;
            //--TRIMMABLE-BOUNDARY-END(227635101753)
            
            //--TRIMMABLE-BOUNDARY-START(2512557703225)
            static /*UnicodeRange */ get Limbu()
            {
                return $.$stew.STU.UnicodeRanges._u1900 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u1900, ($v) => $.$stew.STU.UnicodeRanges._u1900 = $v, $.$stew.STU.UnicodeRange), /*\u1900*/ 6400, /*\u194F*/ 6479);
            }
            //--TRIMMABLE-BOUNDARY-END(2512557703225)
            
            //--TRIMMABLE-BOUNDARY-START(231930069049)
            /*UnicodeRange?*/ static _u1900 = null;
            //--TRIMMABLE-BOUNDARY-END(231930069049)
            
            //--TRIMMABLE-BOUNDARY-START(2718716133433)
            static /*UnicodeRange */ get TaiLe()
            {
                return $.$stew.STU.UnicodeRanges._u1950 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u1950, ($v) => $.$stew.STU.UnicodeRanges._u1950 = $v, $.$stew.STU.UnicodeRange), /*\u1950*/ 6480, /*\u197F*/ 6527);
            }
            //--TRIMMABLE-BOUNDARY-END(2718716133433)
            
            //--TRIMMABLE-BOUNDARY-START(236225036345)
            /*UnicodeRange?*/ static _u1950 = null;
            //--TRIMMABLE-BOUNDARY-END(236225036345)
            
            //--TRIMMABLE-BOUNDARY-START(2585572147257)
            static /*UnicodeRange */ get NewTaiLue()
            {
                return $.$stew.STU.UnicodeRanges._u1980 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u1980, ($v) => $.$stew.STU.UnicodeRanges._u1980 = $v, $.$stew.STU.UnicodeRange), /*\u1980*/ 6528, /*\u19DF*/ 6623);
            }
            //--TRIMMABLE-BOUNDARY-END(2585572147257)
            
            //--TRIMMABLE-BOUNDARY-START(240520003641)
            /*UnicodeRange?*/ static _u1980 = null;
            //--TRIMMABLE-BOUNDARY-END(240520003641)
            
            //--TRIMMABLE-BOUNDARY-START(2465313062969)
            static /*UnicodeRange */ get KhmerSymbols()
            {
                return $.$stew.STU.UnicodeRanges._u19E0 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u19E0, ($v) => $.$stew.STU.UnicodeRanges._u19E0 = $v, $.$stew.STU.UnicodeRange), /*\u19E0*/ 6624, /*\u19FF*/ 6655);
            }
            //--TRIMMABLE-BOUNDARY-END(2465313062969)
            
            //--TRIMMABLE-BOUNDARY-START(244814970937)
            /*UnicodeRange?*/ static _u19E0 = null;
            //--TRIMMABLE-BOUNDARY-END(244814970937)
            
            //--TRIMMABLE-BOUNDARY-START(785980850233)
            static /*UnicodeRange */ get Buginese()
            {
                return $.$stew.STU.UnicodeRanges._u1A00 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u1A00, ($v) => $.$stew.STU.UnicodeRanges._u1A00 = $v, $.$stew.STU.UnicodeRange), /*\u1A00*/ 6656, /*\u1A1F*/ 6687);
            }
            //--TRIMMABLE-BOUNDARY-END(785980850233)
            
            //--TRIMMABLE-BOUNDARY-START(249109938233)
            /*UnicodeRange?*/ static _u1A00 = null;
            //--TRIMMABLE-BOUNDARY-END(249109938233)
            
            //--TRIMMABLE-BOUNDARY-START(2723011100729)
            static /*UnicodeRange */ get TaiTham()
            {
                return $.$stew.STU.UnicodeRanges._u1A20 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u1A20, ($v) => $.$stew.STU.UnicodeRanges._u1A20 = $v, $.$stew.STU.UnicodeRange), /*\u1A20*/ 6688, /*\u1AAF*/ 6831);
            }
            //--TRIMMABLE-BOUNDARY-END(2723011100729)
            
            //--TRIMMABLE-BOUNDARY-START(253404905529)
            /*UnicodeRange?*/ static _u1A20 = null;
            //--TRIMMABLE-BOUNDARY-END(253404905529)
            
            //--TRIMMABLE-BOUNDARY-START(846110392377)
            static /*UnicodeRange */ get CombiningDiacriticalMarksExtended()
            {
                return $.$stew.STU.UnicodeRanges._u1AB0 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u1AB0, ($v) => $.$stew.STU.UnicodeRanges._u1AB0 = $v, $.$stew.STU.UnicodeRange), /*\u1AB0*/ 6832, /*\u1AFF*/ 6911);
            }
            //--TRIMMABLE-BOUNDARY-END(846110392377)
            
            //--TRIMMABLE-BOUNDARY-START(257699872825)
            /*UnicodeRange?*/ static _u1AB0 = null;
            //--TRIMMABLE-BOUNDARY-END(257699872825)
            
            //--TRIMMABLE-BOUNDARY-START(743031177273)
            static /*UnicodeRange */ get Balinese()
            {
                return $.$stew.STU.UnicodeRanges._u1B00 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u1B00, ($v) => $.$stew.STU.UnicodeRanges._u1B00 = $v, $.$stew.STU.UnicodeRange), /*\u1B00*/ 6912, /*\u1B7F*/ 7039);
            }
            //--TRIMMABLE-BOUNDARY-END(743031177273)
            
            //--TRIMMABLE-BOUNDARY-START(261994840121)
            /*UnicodeRange?*/ static _u1B00 = null;
            //--TRIMMABLE-BOUNDARY-END(261994840121)
            
            //--TRIMMABLE-BOUNDARY-START(2667176525881)
            static /*UnicodeRange */ get Sundanese()
            {
                return $.$stew.STU.UnicodeRanges._u1B80 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u1B80, ($v) => $.$stew.STU.UnicodeRanges._u1B80 = $v, $.$stew.STU.UnicodeRange), /*\u1B80*/ 7040, /*\u1BBF*/ 7103);
            }
            //--TRIMMABLE-BOUNDARY-END(2667176525881)
            
            //--TRIMMABLE-BOUNDARY-START(266289807417)
            /*UnicodeRange?*/ static _u1B80 = null;
            //--TRIMMABLE-BOUNDARY-END(266289807417)
            
            //--TRIMMABLE-BOUNDARY-START(755916079161)
            static /*UnicodeRange */ get Batak()
            {
                return $.$stew.STU.UnicodeRanges._u1BC0 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u1BC0, ($v) => $.$stew.STU.UnicodeRanges._u1BC0 = $v, $.$stew.STU.UnicodeRange), /*\u1BC0*/ 7104, /*\u1BFF*/ 7167);
            }
            //--TRIMMABLE-BOUNDARY-END(755916079161)
            
            //--TRIMMABLE-BOUNDARY-START(270584774713)
            /*UnicodeRange?*/ static _u1BC0 = null;
            //--TRIMMABLE-BOUNDARY-END(270584774713)
            
            //--TRIMMABLE-BOUNDARY-START(2503967768633)
            static /*UnicodeRange */ get Lepcha()
            {
                return $.$stew.STU.UnicodeRanges._u1C00 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u1C00, ($v) => $.$stew.STU.UnicodeRanges._u1C00 = $v, $.$stew.STU.UnicodeRange), /*\u1C00*/ 7168, /*\u1C4F*/ 7247);
            }
            //--TRIMMABLE-BOUNDARY-END(2503967768633)
            
            //--TRIMMABLE-BOUNDARY-START(274879742009)
            /*UnicodeRange?*/ static _u1C00 = null;
            //--TRIMMABLE-BOUNDARY-END(274879742009)
            
            //--TRIMMABLE-BOUNDARY-START(2607046983737)
            static /*UnicodeRange */ get OlChiki()
            {
                return $.$stew.STU.UnicodeRanges._u1C50 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u1C50, ($v) => $.$stew.STU.UnicodeRanges._u1C50 = $v, $.$stew.STU.UnicodeRange), /*\u1C50*/ 7248, /*\u1C7F*/ 7295);
            }
            //--TRIMMABLE-BOUNDARY-END(2607046983737)
            
            //--TRIMMABLE-BOUNDARY-START(279174709305)
            /*UnicodeRange?*/ static _u1C50 = null;
            //--TRIMMABLE-BOUNDARY-END(279174709305)
            
            //--TRIMMABLE-BOUNDARY-START(901944967225)
            static /*UnicodeRange */ get CyrillicExtendedC()
            {
                return $.$stew.STU.UnicodeRanges._u1C80 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u1C80, ($v) => $.$stew.STU.UnicodeRanges._u1C80 = $v, $.$stew.STU.UnicodeRange), /*\u1C80*/ 7296, /*\u1C8F*/ 7311);
            }
            //--TRIMMABLE-BOUNDARY-END(901944967225)
            
            //--TRIMMABLE-BOUNDARY-START(283469676601)
            /*UnicodeRange?*/ static _u1C80 = null;
            //--TRIMMABLE-BOUNDARY-END(283469676601)
            
            //--TRIMMABLE-BOUNDARY-START(962074509369)
            static /*UnicodeRange */ get GeorgianExtended()
            {
                return $.$stew.STU.UnicodeRanges._u1C90 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u1C90, ($v) => $.$stew.STU.UnicodeRanges._u1C90 = $v, $.$stew.STU.UnicodeRange), /*\u1C90*/ 7312, /*\u1CBF*/ 7359);
            }
            //--TRIMMABLE-BOUNDARY-END(962074509369)
            
            //--TRIMMABLE-BOUNDARY-START(287764643897)
            /*UnicodeRange?*/ static _u1C90 = null;
            //--TRIMMABLE-BOUNDARY-END(287764643897)
            
            //--TRIMMABLE-BOUNDARY-START(2671471493177)
            static /*UnicodeRange */ get SundaneseSupplement()
            {
                return $.$stew.STU.UnicodeRanges._u1CC0 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u1CC0, ($v) => $.$stew.STU.UnicodeRanges._u1CC0 = $v, $.$stew.STU.UnicodeRange), /*\u1CC0*/ 7360, /*\u1CCF*/ 7375);
            }
            //--TRIMMABLE-BOUNDARY-END(2671471493177)
            
            //--TRIMMABLE-BOUNDARY-START(292059611193)
            /*UnicodeRange?*/ static _u1CC0 = null;
            //--TRIMMABLE-BOUNDARY-END(292059611193)
            
            //--TRIMMABLE-BOUNDARY-START(2774550708281)
            static /*UnicodeRange */ get VedicExtensions()
            {
                return $.$stew.STU.UnicodeRanges._u1CD0 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u1CD0, ($v) => $.$stew.STU.UnicodeRanges._u1CD0 = $v, $.$stew.STU.UnicodeRange), /*\u1CD0*/ 7376, /*\u1CFF*/ 7423);
            }
            //--TRIMMABLE-BOUNDARY-END(2774550708281)
            
            //--TRIMMABLE-BOUNDARY-START(296354578489)
            /*UnicodeRange?*/ static _u1CD0 = null;
            //--TRIMMABLE-BOUNDARY-END(296354578489)
            
            //--TRIMMABLE-BOUNDARY-START(2624226852921)
            static /*UnicodeRange */ get PhoneticExtensions()
            {
                return $.$stew.STU.UnicodeRanges._u1D00 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u1D00, ($v) => $.$stew.STU.UnicodeRanges._u1D00 = $v, $.$stew.STU.UnicodeRange), /*\u1D00*/ 7424, /*\u1D7F*/ 7551);
            }
            //--TRIMMABLE-BOUNDARY-END(2624226852921)
            
            //--TRIMMABLE-BOUNDARY-START(300649545785)
            /*UnicodeRange?*/ static _u1D00 = null;
            //--TRIMMABLE-BOUNDARY-END(300649545785)
            
            //--TRIMMABLE-BOUNDARY-START(2628521820217)
            static /*UnicodeRange */ get PhoneticExtensionsSupplement()
            {
                return $.$stew.STU.UnicodeRanges._u1D80 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u1D80, ($v) => $.$stew.STU.UnicodeRanges._u1D80 = $v, $.$stew.STU.UnicodeRange), /*\u1D80*/ 7552, /*\u1DBF*/ 7615);
            }
            //--TRIMMABLE-BOUNDARY-END(2628521820217)
            
            //--TRIMMABLE-BOUNDARY-START(304944513081)
            /*UnicodeRange?*/ static _u1D80 = null;
            //--TRIMMABLE-BOUNDARY-END(304944513081)
            
            //--TRIMMABLE-BOUNDARY-START(854700326969)
            static /*UnicodeRange */ get CombiningDiacriticalMarksSupplement()
            {
                return $.$stew.STU.UnicodeRanges._u1DC0 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u1DC0, ($v) => $.$stew.STU.UnicodeRanges._u1DC0 = $v, $.$stew.STU.UnicodeRange), /*\u1DC0*/ 7616, /*\u1DFF*/ 7679);
            }
            //--TRIMMABLE-BOUNDARY-END(854700326969)
            
            //--TRIMMABLE-BOUNDARY-START(309239480377)
            /*UnicodeRange?*/ static _u1DC0 = null;
            //--TRIMMABLE-BOUNDARY-END(309239480377)
            
            //--TRIMMABLE-BOUNDARY-START(2482492932153)
            static /*UnicodeRange */ get LatinExtendedAdditional()
            {
                return $.$stew.STU.UnicodeRanges._u1E00 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u1E00, ($v) => $.$stew.STU.UnicodeRanges._u1E00 = $v, $.$stew.STU.UnicodeRange), /*\u1E00*/ 7680, /*\u1EFF*/ 7935);
            }
            //--TRIMMABLE-BOUNDARY-END(2482492932153)
            
            //--TRIMMABLE-BOUNDARY-START(313534447673)
            /*UnicodeRange?*/ static _u1E00 = null;
            //--TRIMMABLE-BOUNDARY-END(313534447673)
            
            //--TRIMMABLE-BOUNDARY-START(2370823782457)
            static /*UnicodeRange */ get GreekExtended()
            {
                return $.$stew.STU.UnicodeRanges._u1F00 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u1F00, ($v) => $.$stew.STU.UnicodeRanges._u1F00 = $v, $.$stew.STU.UnicodeRange), /*\u1F00*/ 7936, /*\u1FFF*/ 8191);
            }
            //--TRIMMABLE-BOUNDARY-END(2370823782457)
            
            //--TRIMMABLE-BOUNDARY-START(317829414969)
            /*UnicodeRange?*/ static _u1F00 = null;
            //--TRIMMABLE-BOUNDARY-END(317829414969)
            
            //--TRIMMABLE-BOUNDARY-START(949189607481)
            static /*UnicodeRange */ get GeneralPunctuation()
            {
                return $.$stew.STU.UnicodeRanges._u2000 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u2000, ($v) => $.$stew.STU.UnicodeRanges._u2000 = $v, $.$stew.STU.UnicodeRange), /*\u2000*/ 8192, /*\u206F*/ 8303);
            }
            //--TRIMMABLE-BOUNDARY-END(949189607481)
            
            //--TRIMMABLE-BOUNDARY-START(322124382265)
            /*UnicodeRange?*/ static _u2000 = null;
            //--TRIMMABLE-BOUNDARY-END(322124382265)
            
            //--TRIMMABLE-BOUNDARY-START(2675766460473)
            static /*UnicodeRange */ get SuperscriptsandSubscripts()
            {
                return $.$stew.STU.UnicodeRanges._u2070 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u2070, ($v) => $.$stew.STU.UnicodeRanges._u2070 = $v, $.$stew.STU.UnicodeRange), /*\u2070*/ 8304, /*\u209F*/ 8351);
            }
            //--TRIMMABLE-BOUNDARY-END(2675766460473)
            
            //--TRIMMABLE-BOUNDARY-START(326419349561)
            /*UnicodeRange?*/ static _u2070 = null;
            //--TRIMMABLE-BOUNDARY-END(326419349561)
            
            //--TRIMMABLE-BOUNDARY-START(884765098041)
            static /*UnicodeRange */ get CurrencySymbols()
            {
                return $.$stew.STU.UnicodeRanges._u20A0 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u20A0, ($v) => $.$stew.STU.UnicodeRanges._u20A0 = $v, $.$stew.STU.UnicodeRange), /*\u20A0*/ 8352, /*\u20CF*/ 8399);
            }
            //--TRIMMABLE-BOUNDARY-END(884765098041)
            
            //--TRIMMABLE-BOUNDARY-START(330714316857)
            /*UnicodeRange?*/ static _u20A0 = null;
            //--TRIMMABLE-BOUNDARY-END(330714316857)
            
            //--TRIMMABLE-BOUNDARY-START(850405359673)
            static /*UnicodeRange */ get CombiningDiacriticalMarksforSymbols()
            {
                return $.$stew.STU.UnicodeRanges._u20D0 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u20D0, ($v) => $.$stew.STU.UnicodeRanges._u20D0 = $v, $.$stew.STU.UnicodeRange), /*\u20D0*/ 8400, /*\u20FF*/ 8447);
            }
            //--TRIMMABLE-BOUNDARY-END(850405359673)
            
            //--TRIMMABLE-BOUNDARY-START(335009284153)
            /*UnicodeRange?*/ static _u20D0 = null;
            //--TRIMMABLE-BOUNDARY-END(335009284153)
            
            //--TRIMMABLE-BOUNDARY-START(2508262735929)
            static /*UnicodeRange */ get LetterlikeSymbols()
            {
                return $.$stew.STU.UnicodeRanges._u2100 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u2100, ($v) => $.$stew.STU.UnicodeRanges._u2100 = $v, $.$stew.STU.UnicodeRange), /*\u2100*/ 8448, /*\u214F*/ 8527);
            }
            //--TRIMMABLE-BOUNDARY-END(2508262735929)
            
            //--TRIMMABLE-BOUNDARY-START(339304251449)
            /*UnicodeRange?*/ static _u2100 = null;
            //--TRIMMABLE-BOUNDARY-END(339304251449)
            
            //--TRIMMABLE-BOUNDARY-START(2598457049145)
            static /*UnicodeRange */ get NumberForms()
            {
                return $.$stew.STU.UnicodeRanges._u2150 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u2150, ($v) => $.$stew.STU.UnicodeRanges._u2150 = $v, $.$stew.STU.UnicodeRange), /*\u2150*/ 8528, /*\u218F*/ 8591);
            }
            //--TRIMMABLE-BOUNDARY-END(2598457049145)
            
            //--TRIMMABLE-BOUNDARY-START(343599218745)
            /*UnicodeRange?*/ static _u2150 = null;
            //--TRIMMABLE-BOUNDARY-END(343599218745)
            
            //--TRIMMABLE-BOUNDARY-START(738736209977)
            static /*UnicodeRange */ get Arrows()
            {
                return $.$stew.STU.UnicodeRanges._u2190 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u2190, ($v) => $.$stew.STU.UnicodeRanges._u2190 = $v, $.$stew.STU.UnicodeRange), /*\u2190*/ 8592, /*\u21FF*/ 8703);
            }
            //--TRIMMABLE-BOUNDARY-END(738736209977)
            
            //--TRIMMABLE-BOUNDARY-START(347894186041)
            /*UnicodeRange?*/ static _u2190 = null;
            //--TRIMMABLE-BOUNDARY-END(347894186041)
            
            //--TRIMMABLE-BOUNDARY-START(2529737572409)
            static /*UnicodeRange */ get MathematicalOperators()
            {
                return $.$stew.STU.UnicodeRanges._u2200 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u2200, ($v) => $.$stew.STU.UnicodeRanges._u2200 = $v, $.$stew.STU.UnicodeRange), /*\u2200*/ 8704, /*\u22FF*/ 8959);
            }
            //--TRIMMABLE-BOUNDARY-END(2529737572409)
            
            //--TRIMMABLE-BOUNDARY-START(352189153337)
            /*UnicodeRange?*/ static _u2200 = null;
            //--TRIMMABLE-BOUNDARY-END(352189153337)
            
            //--TRIMMABLE-BOUNDARY-START(2559802343481)
            static /*UnicodeRange */ get MiscellaneousTechnical()
            {
                return $.$stew.STU.UnicodeRanges._u2300 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u2300, ($v) => $.$stew.STU.UnicodeRanges._u2300 = $v, $.$stew.STU.UnicodeRange), /*\u2300*/ 8960, /*\u23FF*/ 9215);
            }
            //--TRIMMABLE-BOUNDARY-END(2559802343481)
            
            //--TRIMMABLE-BOUNDARY-START(356484120633)
            /*UnicodeRange?*/ static _u2300 = null;
            //--TRIMMABLE-BOUNDARY-END(356484120633)
            
            //--TRIMMABLE-BOUNDARY-START(867585228857)
            static /*UnicodeRange */ get ControlPictures()
            {
                return $.$stew.STU.UnicodeRanges._u2400 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u2400, ($v) => $.$stew.STU.UnicodeRanges._u2400 = $v, $.$stew.STU.UnicodeRange), /*\u2400*/ 9216, /*\u243F*/ 9279);
            }
            //--TRIMMABLE-BOUNDARY-END(867585228857)
            
            //--TRIMMABLE-BOUNDARY-START(360779087929)
            /*UnicodeRange?*/ static _u2400 = null;
            //--TRIMMABLE-BOUNDARY-END(360779087929)
            
            //--TRIMMABLE-BOUNDARY-START(2611341951033)
            static /*UnicodeRange */ get OpticalCharacterRecognition()
            {
                return $.$stew.STU.UnicodeRanges._u2440 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u2440, ($v) => $.$stew.STU.UnicodeRanges._u2440 = $v, $.$stew.STU.UnicodeRange), /*\u2440*/ 9280, /*\u245F*/ 9311);
            }
            //--TRIMMABLE-BOUNDARY-END(2611341951033)
            
            //--TRIMMABLE-BOUNDARY-START(365074055225)
            /*UnicodeRange?*/ static _u2440 = null;
            //--TRIMMABLE-BOUNDARY-END(365074055225)
            
            //--TRIMMABLE-BOUNDARY-START(923419803705)
            static /*UnicodeRange */ get EnclosedAlphanumerics()
            {
                return $.$stew.STU.UnicodeRanges._u2460 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u2460, ($v) => $.$stew.STU.UnicodeRanges._u2460 = $v, $.$stew.STU.UnicodeRange), /*\u2460*/ 9312, /*\u24FF*/ 9471);
            }
            //--TRIMMABLE-BOUNDARY-END(923419803705)
            
            //--TRIMMABLE-BOUNDARY-START(369369022521)
            /*UnicodeRange?*/ static _u2460 = null;
            //--TRIMMABLE-BOUNDARY-END(369369022521)
            
            //--TRIMMABLE-BOUNDARY-START(777390915641)
            static /*UnicodeRange */ get BoxDrawing()
            {
                return $.$stew.STU.UnicodeRanges._u2500 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u2500, ($v) => $.$stew.STU.UnicodeRanges._u2500 = $v, $.$stew.STU.UnicodeRange), /*\u2500*/ 9472, /*\u257F*/ 9599);
            }
            //--TRIMMABLE-BOUNDARY-END(777390915641)
            
            //--TRIMMABLE-BOUNDARY-START(373663989817)
            /*UnicodeRange?*/ static _u2500 = null;
            //--TRIMMABLE-BOUNDARY-END(373663989817)
            
            //--TRIMMABLE-BOUNDARY-START(764506013753)
            static /*UnicodeRange */ get BlockElements()
            {
                return $.$stew.STU.UnicodeRanges._u2580 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u2580, ($v) => $.$stew.STU.UnicodeRanges._u2580 = $v, $.$stew.STU.UnicodeRange), /*\u2580*/ 9600, /*\u259F*/ 9631);
            }
            //--TRIMMABLE-BOUNDARY-END(764506013753)
            
            //--TRIMMABLE-BOUNDARY-START(377958957113)
            /*UnicodeRange?*/ static _u2580 = null;
            //--TRIMMABLE-BOUNDARY-END(377958957113)
            
            //--TRIMMABLE-BOUNDARY-START(953484574777)
            static /*UnicodeRange */ get GeometricShapes()
            {
                return $.$stew.STU.UnicodeRanges._u25A0 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u25A0, ($v) => $.$stew.STU.UnicodeRanges._u25A0 = $v, $.$stew.STU.UnicodeRange), /*\u25A0*/ 9632, /*\u25FF*/ 9727);
            }
            //--TRIMMABLE-BOUNDARY-END(953484574777)
            
            //--TRIMMABLE-BOUNDARY-START(382253924409)
            /*UnicodeRange?*/ static _u25A0 = null;
            //--TRIMMABLE-BOUNDARY-END(382253924409)
            
            //--TRIMMABLE-BOUNDARY-START(2551212408889)
            static /*UnicodeRange */ get MiscellaneousSymbols()
            {
                return $.$stew.STU.UnicodeRanges._u2600 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u2600, ($v) => $.$stew.STU.UnicodeRanges._u2600 = $v, $.$stew.STU.UnicodeRange), /*\u2600*/ 9728, /*\u26FF*/ 9983);
            }
            //--TRIMMABLE-BOUNDARY-END(2551212408889)
            
            //--TRIMMABLE-BOUNDARY-START(386548891705)
            /*UnicodeRange?*/ static _u2600 = null;
            //--TRIMMABLE-BOUNDARY-END(386548891705)
            
            //--TRIMMABLE-BOUNDARY-START(919124836409)
            static /*UnicodeRange */ get Dingbats()
            {
                return $.$stew.STU.UnicodeRanges._u2700 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u2700, ($v) => $.$stew.STU.UnicodeRanges._u2700 = $v, $.$stew.STU.UnicodeRange), /*\u2700*/ 9984, /*\u27BF*/ 10175);
            }
            //--TRIMMABLE-BOUNDARY-END(919124836409)
            
            //--TRIMMABLE-BOUNDARY-START(390843859001)
            /*UnicodeRange?*/ static _u2700 = null;
            //--TRIMMABLE-BOUNDARY-END(390843859001)
            
            //--TRIMMABLE-BOUNDARY-START(2542622474297)
            static /*UnicodeRange */ get MiscellaneousMathematicalSymbolsA()
            {
                return $.$stew.STU.UnicodeRanges._u27C0 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u27C0, ($v) => $.$stew.STU.UnicodeRanges._u27C0 = $v, $.$stew.STU.UnicodeRange), /*\u27C0*/ 10176, /*\u27EF*/ 10223);
            }
            //--TRIMMABLE-BOUNDARY-END(2542622474297)
            
            //--TRIMMABLE-BOUNDARY-START(395138826297)
            /*UnicodeRange?*/ static _u27C0 = null;
            //--TRIMMABLE-BOUNDARY-END(395138826297)
            
            //--TRIMMABLE-BOUNDARY-START(2680061427769)
            static /*UnicodeRange */ get SupplementalArrowsA()
            {
                return $.$stew.STU.UnicodeRanges._u27F0 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u27F0, ($v) => $.$stew.STU.UnicodeRanges._u27F0 = $v, $.$stew.STU.UnicodeRange), /*\u27F0*/ 10224, /*\u27FF*/ 10239);
            }
            //--TRIMMABLE-BOUNDARY-END(2680061427769)
            
            //--TRIMMABLE-BOUNDARY-START(399433793593)
            /*UnicodeRange?*/ static _u27F0 = null;
            //--TRIMMABLE-BOUNDARY-END(399433793593)
            
            //--TRIMMABLE-BOUNDARY-START(781685882937)
            static /*UnicodeRange */ get BraillePatterns()
            {
                return $.$stew.STU.UnicodeRanges._u2800 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u2800, ($v) => $.$stew.STU.UnicodeRanges._u2800 = $v, $.$stew.STU.UnicodeRange), /*\u2800*/ 10240, /*\u28FF*/ 10495);
            }
            //--TRIMMABLE-BOUNDARY-END(781685882937)
            
            //--TRIMMABLE-BOUNDARY-START(403728760889)
            /*UnicodeRange?*/ static _u2800 = null;
            //--TRIMMABLE-BOUNDARY-END(403728760889)
            
            //--TRIMMABLE-BOUNDARY-START(2684356395065)
            static /*UnicodeRange */ get SupplementalArrowsB()
            {
                return $.$stew.STU.UnicodeRanges._u2900 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u2900, ($v) => $.$stew.STU.UnicodeRanges._u2900 = $v, $.$stew.STU.UnicodeRange), /*\u2900*/ 10496, /*\u297F*/ 10623);
            }
            //--TRIMMABLE-BOUNDARY-END(2684356395065)
            
            //--TRIMMABLE-BOUNDARY-START(408023728185)
            /*UnicodeRange?*/ static _u2900 = null;
            //--TRIMMABLE-BOUNDARY-END(408023728185)
            
            //--TRIMMABLE-BOUNDARY-START(2546917441593)
            static /*UnicodeRange */ get MiscellaneousMathematicalSymbolsB()
            {
                return $.$stew.STU.UnicodeRanges._u2980 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u2980, ($v) => $.$stew.STU.UnicodeRanges._u2980 = $v, $.$stew.STU.UnicodeRange), /*\u2980*/ 10624, /*\u29FF*/ 10751);
            }
            //--TRIMMABLE-BOUNDARY-END(2546917441593)
            
            //--TRIMMABLE-BOUNDARY-START(412318695481)
            /*UnicodeRange?*/ static _u2980 = null;
            //--TRIMMABLE-BOUNDARY-END(412318695481)
            
            //--TRIMMABLE-BOUNDARY-START(2688651362361)
            static /*UnicodeRange */ get SupplementalMathematicalOperators()
            {
                return $.$stew.STU.UnicodeRanges._u2A00 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u2A00, ($v) => $.$stew.STU.UnicodeRanges._u2A00 = $v, $.$stew.STU.UnicodeRange), /*\u2A00*/ 10752, /*\u2AFF*/ 11007);
            }
            //--TRIMMABLE-BOUNDARY-END(2688651362361)
            
            //--TRIMMABLE-BOUNDARY-START(416613662777)
            /*UnicodeRange?*/ static _u2A00 = null;
            //--TRIMMABLE-BOUNDARY-END(416613662777)
            
            //--TRIMMABLE-BOUNDARY-START(2555507376185)
            static /*UnicodeRange */ get MiscellaneousSymbolsandArrows()
            {
                return $.$stew.STU.UnicodeRanges._u2B00 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u2B00, ($v) => $.$stew.STU.UnicodeRanges._u2B00 = $v, $.$stew.STU.UnicodeRange), /*\u2B00*/ 11008, /*\u2BFF*/ 11263);
            }
            //--TRIMMABLE-BOUNDARY-END(2555507376185)
            
            //--TRIMMABLE-BOUNDARY-START(420908630073)
            /*UnicodeRange?*/ static _u2B00 = null;
            //--TRIMMABLE-BOUNDARY-END(420908630073)
            
            //--TRIMMABLE-BOUNDARY-START(2362233847865)
            static /*UnicodeRange */ get Glagolitic()
            {
                return $.$stew.STU.UnicodeRanges._u2C00 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u2C00, ($v) => $.$stew.STU.UnicodeRanges._u2C00 = $v, $.$stew.STU.UnicodeRange), /*\u2C00*/ 11264, /*\u2C5F*/ 11359);
            }
            //--TRIMMABLE-BOUNDARY-END(2362233847865)
            
            //--TRIMMABLE-BOUNDARY-START(425203597369)
            /*UnicodeRange?*/ static _u2C00 = null;
            //--TRIMMABLE-BOUNDARY-END(425203597369)
            
            //--TRIMMABLE-BOUNDARY-START(2491082866745)
            static /*UnicodeRange */ get LatinExtendedC()
            {
                return $.$stew.STU.UnicodeRanges._u2C60 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u2C60, ($v) => $.$stew.STU.UnicodeRanges._u2C60 = $v, $.$stew.STU.UnicodeRange), /*\u2C60*/ 11360, /*\u2C7F*/ 11391);
            }
            //--TRIMMABLE-BOUNDARY-END(2491082866745)
            
            //--TRIMMABLE-BOUNDARY-START(429498564665)
            /*UnicodeRange?*/ static _u2C60 = null;
            //--TRIMMABLE-BOUNDARY-END(429498564665)
            
            //--TRIMMABLE-BOUNDARY-START(871880196153)
            static /*UnicodeRange */ get Coptic()
            {
                return $.$stew.STU.UnicodeRanges._u2C80 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u2C80, ($v) => $.$stew.STU.UnicodeRanges._u2C80 = $v, $.$stew.STU.UnicodeRange), /*\u2C80*/ 11392, /*\u2CFF*/ 11519);
            }
            //--TRIMMABLE-BOUNDARY-END(871880196153)
            
            //--TRIMMABLE-BOUNDARY-START(433793531961)
            /*UnicodeRange?*/ static _u2C80 = null;
            //--TRIMMABLE-BOUNDARY-END(433793531961)
            
            //--TRIMMABLE-BOUNDARY-START(966369476665)
            static /*UnicodeRange */ get GeorgianSupplement()
            {
                return $.$stew.STU.UnicodeRanges._u2D00 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u2D00, ($v) => $.$stew.STU.UnicodeRanges._u2D00 = $v, $.$stew.STU.UnicodeRange), /*\u2D00*/ 11520, /*\u2D2F*/ 11567);
            }
            //--TRIMMABLE-BOUNDARY-END(966369476665)
            
            //--TRIMMABLE-BOUNDARY-START(438088499257)
            /*UnicodeRange?*/ static _u2D00 = null;
            //--TRIMMABLE-BOUNDARY-END(438088499257)
            
            //--TRIMMABLE-BOUNDARY-START(2753075871801)
            static /*UnicodeRange */ get Tifinagh()
            {
                return $.$stew.STU.UnicodeRanges._u2D30 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u2D30, ($v) => $.$stew.STU.UnicodeRanges._u2D30 = $v, $.$stew.STU.UnicodeRange), /*\u2D30*/ 11568, /*\u2D7F*/ 11647);
            }
            //--TRIMMABLE-BOUNDARY-END(2753075871801)
            
            //--TRIMMABLE-BOUNDARY-START(442383466553)
            /*UnicodeRange?*/ static _u2D30 = null;
            //--TRIMMABLE-BOUNDARY-END(442383466553)
            
            //--TRIMMABLE-BOUNDARY-START(936304705593)
            static /*UnicodeRange */ get EthiopicExtended()
            {
                return $.$stew.STU.UnicodeRanges._u2D80 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u2D80, ($v) => $.$stew.STU.UnicodeRanges._u2D80 = $v, $.$stew.STU.UnicodeRange), /*\u2D80*/ 11648, /*\u2DDF*/ 11743);
            }
            //--TRIMMABLE-BOUNDARY-END(936304705593)
            
            //--TRIMMABLE-BOUNDARY-START(446678433849)
            /*UnicodeRange?*/ static _u2D80 = null;
            //--TRIMMABLE-BOUNDARY-END(446678433849)
            
            //--TRIMMABLE-BOUNDARY-START(893355032633)
            static /*UnicodeRange */ get CyrillicExtendedA()
            {
                return $.$stew.STU.UnicodeRanges._u2DE0 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u2DE0, ($v) => $.$stew.STU.UnicodeRanges._u2DE0 = $v, $.$stew.STU.UnicodeRange), /*\u2DE0*/ 11744, /*\u2DFF*/ 11775);
            }
            //--TRIMMABLE-BOUNDARY-END(893355032633)
            
            //--TRIMMABLE-BOUNDARY-START(450973401145)
            /*UnicodeRange?*/ static _u2DE0 = null;
            //--TRIMMABLE-BOUNDARY-END(450973401145)
            
            //--TRIMMABLE-BOUNDARY-START(2692946329657)
            static /*UnicodeRange */ get SupplementalPunctuation()
            {
                return $.$stew.STU.UnicodeRanges._u2E00 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u2E00, ($v) => $.$stew.STU.UnicodeRanges._u2E00 = $v, $.$stew.STU.UnicodeRange), /*\u2E00*/ 11776, /*\u2E7F*/ 11903);
            }
            //--TRIMMABLE-BOUNDARY-END(2692946329657)
            
            //--TRIMMABLE-BOUNDARY-START(455268368441)
            /*UnicodeRange?*/ static _u2E00 = null;
            //--TRIMMABLE-BOUNDARY-END(455268368441)
            
            //--TRIMMABLE-BOUNDARY-START(820340588601)
            static /*UnicodeRange */ get CjkRadicalsSupplement()
            {
                return $.$stew.STU.UnicodeRanges._u2E80 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u2E80, ($v) => $.$stew.STU.UnicodeRanges._u2E80 = $v, $.$stew.STU.UnicodeRange), /*\u2E80*/ 11904, /*\u2EFF*/ 12031);
            }
            //--TRIMMABLE-BOUNDARY-END(820340588601)
            
            //--TRIMMABLE-BOUNDARY-START(459563335737)
            /*UnicodeRange?*/ static _u2E80 = null;
            //--TRIMMABLE-BOUNDARY-END(459563335737)
            
            //--TRIMMABLE-BOUNDARY-START(2439543259193)
            static /*UnicodeRange */ get KangxiRadicals()
            {
                return $.$stew.STU.UnicodeRanges._u2F00 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u2F00, ($v) => $.$stew.STU.UnicodeRanges._u2F00 = $v, $.$stew.STU.UnicodeRange), /*\u2F00*/ 12032, /*\u2FDF*/ 12255);
            }
            //--TRIMMABLE-BOUNDARY-END(2439543259193)
            
            //--TRIMMABLE-BOUNDARY-START(463858303033)
            /*UnicodeRange?*/ static _u2F00 = null;
            //--TRIMMABLE-BOUNDARY-END(463858303033)
            
            //--TRIMMABLE-BOUNDARY-START(2422363390009)
            static /*UnicodeRange */ get IdeographicDescriptionCharacters()
            {
                return $.$stew.STU.UnicodeRanges._u2FF0 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u2FF0, ($v) => $.$stew.STU.UnicodeRanges._u2FF0 = $v, $.$stew.STU.UnicodeRange), /*\u2FF0*/ 12272, /*\u2FFF*/ 12287);
            }
            //--TRIMMABLE-BOUNDARY-END(2422363390009)
            
            //--TRIMMABLE-BOUNDARY-START(468153270329)
            /*UnicodeRange?*/ static _u2FF0 = null;
            //--TRIMMABLE-BOUNDARY-END(468153270329)
            
            //--TRIMMABLE-BOUNDARY-START(828930523193)
            static /*UnicodeRange */ get CjkSymbolsandPunctuation()
            {
                return $.$stew.STU.UnicodeRanges._u3000 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u3000, ($v) => $.$stew.STU.UnicodeRanges._u3000 = $v, $.$stew.STU.UnicodeRange), /*\u3000*/ 12288, /*\u303F*/ 12351);
            }
            //--TRIMMABLE-BOUNDARY-END(828930523193)
            
            //--TRIMMABLE-BOUNDARY-START(472448237625)
            /*UnicodeRange?*/ static _u3000 = null;
            //--TRIMMABLE-BOUNDARY-END(472448237625)
            
            //--TRIMMABLE-BOUNDARY-START(2418068422713)
            static /*UnicodeRange */ get Hiragana()
            {
                return $.$stew.STU.UnicodeRanges._u3040 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u3040, ($v) => $.$stew.STU.UnicodeRanges._u3040 = $v, $.$stew.STU.UnicodeRange), /*\u3040*/ 12352, /*\u309F*/ 12447);
            }
            //--TRIMMABLE-BOUNDARY-END(2418068422713)
            
            //--TRIMMABLE-BOUNDARY-START(476743204921)
            /*UnicodeRange?*/ static _u3040 = null;
            //--TRIMMABLE-BOUNDARY-END(476743204921)
            
            //--TRIMMABLE-BOUNDARY-START(2448133193785)
            static /*UnicodeRange */ get Katakana()
            {
                return $.$stew.STU.UnicodeRanges._u30A0 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u30A0, ($v) => $.$stew.STU.UnicodeRanges._u30A0 = $v, $.$stew.STU.UnicodeRange), /*\u30A0*/ 12448, /*\u30FF*/ 12543);
            }
            //--TRIMMABLE-BOUNDARY-END(2448133193785)
            
            //--TRIMMABLE-BOUNDARY-START(481038172217)
            /*UnicodeRange?*/ static _u30A0 = null;
            //--TRIMMABLE-BOUNDARY-END(481038172217)
            
            //--TRIMMABLE-BOUNDARY-START(768800981049)
            static /*UnicodeRange */ get Bopomofo()
            {
                return $.$stew.STU.UnicodeRanges._u3100 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u3100, ($v) => $.$stew.STU.UnicodeRanges._u3100 = $v, $.$stew.STU.UnicodeRange), /*\u3100*/ 12544, /*\u312F*/ 12591);
            }
            //--TRIMMABLE-BOUNDARY-END(768800981049)
            
            //--TRIMMABLE-BOUNDARY-START(485333139513)
            /*UnicodeRange?*/ static _u3100 = null;
            //--TRIMMABLE-BOUNDARY-END(485333139513)
            
            //--TRIMMABLE-BOUNDARY-START(2388003651641)
            static /*UnicodeRange */ get HangulCompatibilityJamo()
            {
                return $.$stew.STU.UnicodeRanges._u3130 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u3130, ($v) => $.$stew.STU.UnicodeRanges._u3130 = $v, $.$stew.STU.UnicodeRange), /*\u3130*/ 12592, /*\u318F*/ 12687);
            }
            //--TRIMMABLE-BOUNDARY-END(2388003651641)
            
            //--TRIMMABLE-BOUNDARY-START(489628106809)
            /*UnicodeRange?*/ static _u3130 = null;
            //--TRIMMABLE-BOUNDARY-END(489628106809)
            
            //--TRIMMABLE-BOUNDARY-START(2435248291897)
            static /*UnicodeRange */ get Kanbun()
            {
                return $.$stew.STU.UnicodeRanges._u3190 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u3190, ($v) => $.$stew.STU.UnicodeRanges._u3190 = $v, $.$stew.STU.UnicodeRange), /*\u3190*/ 12688, /*\u319F*/ 12703);
            }
            //--TRIMMABLE-BOUNDARY-END(2435248291897)
            
            //--TRIMMABLE-BOUNDARY-START(493923074105)
            /*UnicodeRange?*/ static _u3190 = null;
            //--TRIMMABLE-BOUNDARY-END(493923074105)
            
            //--TRIMMABLE-BOUNDARY-START(773095948345)
            static /*UnicodeRange */ get BopomofoExtended()
            {
                return $.$stew.STU.UnicodeRanges._u31A0 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u31A0, ($v) => $.$stew.STU.UnicodeRanges._u31A0 = $v, $.$stew.STU.UnicodeRange), /*\u31A0*/ 12704, /*\u31BF*/ 12735);
            }
            //--TRIMMABLE-BOUNDARY-END(773095948345)
            
            //--TRIMMABLE-BOUNDARY-START(498218041401)
            /*UnicodeRange?*/ static _u31A0 = null;
            //--TRIMMABLE-BOUNDARY-END(498218041401)
            
            //--TRIMMABLE-BOUNDARY-START(824635555897)
            static /*UnicodeRange */ get CjkStrokes()
            {
                return $.$stew.STU.UnicodeRanges._u31C0 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u31C0, ($v) => $.$stew.STU.UnicodeRanges._u31C0 = $v, $.$stew.STU.UnicodeRange), /*\u31C0*/ 12736, /*\u31EF*/ 12783);
            }
            //--TRIMMABLE-BOUNDARY-END(824635555897)
            
            //--TRIMMABLE-BOUNDARY-START(502513008697)
            /*UnicodeRange?*/ static _u31C0 = null;
            //--TRIMMABLE-BOUNDARY-END(502513008697)
            
            //--TRIMMABLE-BOUNDARY-START(2452428161081)
            static /*UnicodeRange */ get KatakanaPhoneticExtensions()
            {
                return $.$stew.STU.UnicodeRanges._u31F0 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u31F0, ($v) => $.$stew.STU.UnicodeRanges._u31F0 = $v, $.$stew.STU.UnicodeRange), /*\u31F0*/ 12784, /*\u31FF*/ 12799);
            }
            //--TRIMMABLE-BOUNDARY-END(2452428161081)
            
            //--TRIMMABLE-BOUNDARY-START(506807975993)
            /*UnicodeRange?*/ static _u31F0 = null;
            //--TRIMMABLE-BOUNDARY-END(506807975993)
            
            //--TRIMMABLE-BOUNDARY-START(927714771001)
            static /*UnicodeRange */ get EnclosedCjkLettersandMonths()
            {
                return $.$stew.STU.UnicodeRanges._u3200 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u3200, ($v) => $.$stew.STU.UnicodeRanges._u3200 = $v, $.$stew.STU.UnicodeRange), /*\u3200*/ 12800, /*\u32FF*/ 13055);
            }
            //--TRIMMABLE-BOUNDARY-END(927714771001)
            
            //--TRIMMABLE-BOUNDARY-START(511102943289)
            /*UnicodeRange?*/ static _u3200 = null;
            //--TRIMMABLE-BOUNDARY-END(511102943289)
            
            //--TRIMMABLE-BOUNDARY-START(807455686713)
            static /*UnicodeRange */ get CjkCompatibility()
            {
                return $.$stew.STU.UnicodeRanges._u3300 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u3300, ($v) => $.$stew.STU.UnicodeRanges._u3300 = $v, $.$stew.STU.UnicodeRange), /*\u3300*/ 13056, /*\u33FF*/ 13311);
            }
            //--TRIMMABLE-BOUNDARY-END(807455686713)
            
            //--TRIMMABLE-BOUNDARY-START(515397910585)
            /*UnicodeRange?*/ static _u3300 = null;
            //--TRIMMABLE-BOUNDARY-END(515397910585)
            
            //--TRIMMABLE-BOUNDARY-START(837520457785)
            static /*UnicodeRange */ get CjkUnifiedIdeographsExtensionA()
            {
                return $.$stew.STU.UnicodeRanges._u3400 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u3400, ($v) => $.$stew.STU.UnicodeRanges._u3400 = $v, $.$stew.STU.UnicodeRange), /*\u3400*/ 13312, /*\u4DBF*/ 19903);
            }
            //--TRIMMABLE-BOUNDARY-END(837520457785)
            
            //--TRIMMABLE-BOUNDARY-START(519692877881)
            /*UnicodeRange?*/ static _u3400 = null;
            //--TRIMMABLE-BOUNDARY-END(519692877881)
            
            //--TRIMMABLE-BOUNDARY-START(2783140642873)
            static /*UnicodeRange */ get YijingHexagramSymbols()
            {
                return $.$stew.STU.UnicodeRanges._u4DC0 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u4DC0, ($v) => $.$stew.STU.UnicodeRanges._u4DC0 = $v, $.$stew.STU.UnicodeRange), /*\u4DC0*/ 19904, /*\u4DFF*/ 19967);
            }
            //--TRIMMABLE-BOUNDARY-END(2783140642873)
            
            //--TRIMMABLE-BOUNDARY-START(523987845177)
            /*UnicodeRange?*/ static _u4DC0 = null;
            //--TRIMMABLE-BOUNDARY-END(523987845177)
            
            //--TRIMMABLE-BOUNDARY-START(833225490489)
            static /*UnicodeRange */ get CjkUnifiedIdeographs()
            {
                return $.$stew.STU.UnicodeRanges._u4E00 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._u4E00, ($v) => $.$stew.STU.UnicodeRanges._u4E00 = $v, $.$stew.STU.UnicodeRange), /*\u4E00*/ 19968, /*\u9FFF*/ 40959);
            }
            //--TRIMMABLE-BOUNDARY-END(833225490489)
            
            //--TRIMMABLE-BOUNDARY-START(528282812473)
            /*UnicodeRange?*/ static _u4E00 = null;
            //--TRIMMABLE-BOUNDARY-END(528282812473)
            
            //--TRIMMABLE-BOUNDARY-START(2791730577465)
            static /*UnicodeRange */ get YiSyllables()
            {
                return $.$stew.STU.UnicodeRanges._uA000 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._uA000, ($v) => $.$stew.STU.UnicodeRanges._uA000 = $v, $.$stew.STU.UnicodeRange), /*\uA000*/ 40960, /*\uA48F*/ 42127);
            }
            //--TRIMMABLE-BOUNDARY-END(2791730577465)
            
            //--TRIMMABLE-BOUNDARY-START(532577779769)
            /*UnicodeRange?*/ static _uA000 = null;
            //--TRIMMABLE-BOUNDARY-END(532577779769)
            
            //--TRIMMABLE-BOUNDARY-START(2787435610169)
            static /*UnicodeRange */ get YiRadicals()
            {
                return $.$stew.STU.UnicodeRanges._uA490 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._uA490, ($v) => $.$stew.STU.UnicodeRanges._uA490 = $v, $.$stew.STU.UnicodeRange), /*\uA490*/ 42128, /*\uA4CF*/ 42191);
            }
            //--TRIMMABLE-BOUNDARY-END(2787435610169)
            
            //--TRIMMABLE-BOUNDARY-START(536872747065)
            /*UnicodeRange?*/ static _uA490 = null;
            //--TRIMMABLE-BOUNDARY-END(536872747065)
            
            //--TRIMMABLE-BOUNDARY-START(2516852670521)
            static /*UnicodeRange */ get Lisu()
            {
                return $.$stew.STU.UnicodeRanges._uA4D0 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._uA4D0, ($v) => $.$stew.STU.UnicodeRanges._uA4D0 = $v, $.$stew.STU.UnicodeRange), /*\uA4D0*/ 42192, /*\uA4FF*/ 42239);
            }
            //--TRIMMABLE-BOUNDARY-END(2516852670521)
            
            //--TRIMMABLE-BOUNDARY-START(541167714361)
            /*UnicodeRange?*/ static _uA4D0 = null;
            //--TRIMMABLE-BOUNDARY-END(541167714361)
            
            //--TRIMMABLE-BOUNDARY-START(2765960773689)
            static /*UnicodeRange */ get Vai()
            {
                return $.$stew.STU.UnicodeRanges._uA500 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._uA500, ($v) => $.$stew.STU.UnicodeRanges._uA500 = $v, $.$stew.STU.UnicodeRange), /*\uA500*/ 42240, /*\uA63F*/ 42559);
            }
            //--TRIMMABLE-BOUNDARY-END(2765960773689)
            
            //--TRIMMABLE-BOUNDARY-START(545462681657)
            /*UnicodeRange?*/ static _uA500 = null;
            //--TRIMMABLE-BOUNDARY-END(545462681657)
            
            //--TRIMMABLE-BOUNDARY-START(897649999929)
            static /*UnicodeRange */ get CyrillicExtendedB()
            {
                return $.$stew.STU.UnicodeRanges._uA640 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._uA640, ($v) => $.$stew.STU.UnicodeRanges._uA640 = $v, $.$stew.STU.UnicodeRange), /*\uA640*/ 42560, /*\uA69F*/ 42655);
            }
            //--TRIMMABLE-BOUNDARY-END(897649999929)
            
            //--TRIMMABLE-BOUNDARY-START(549757648953)
            /*UnicodeRange?*/ static _uA640 = null;
            //--TRIMMABLE-BOUNDARY-END(549757648953)
            
            //--TRIMMABLE-BOUNDARY-START(747326144569)
            static /*UnicodeRange */ get Bamum()
            {
                return $.$stew.STU.UnicodeRanges._uA6A0 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._uA6A0, ($v) => $.$stew.STU.UnicodeRanges._uA6A0 = $v, $.$stew.STU.UnicodeRange), /*\uA6A0*/ 42656, /*\uA6FF*/ 42751);
            }
            //--TRIMMABLE-BOUNDARY-END(747326144569)
            
            //--TRIMMABLE-BOUNDARY-START(554052616249)
            /*UnicodeRange?*/ static _uA6A0 = null;
            //--TRIMMABLE-BOUNDARY-END(554052616249)
            
            //--TRIMMABLE-BOUNDARY-START(2564097310777)
            static /*UnicodeRange */ get ModifierToneLetters()
            {
                return $.$stew.STU.UnicodeRanges._uA700 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._uA700, ($v) => $.$stew.STU.UnicodeRanges._uA700 = $v, $.$stew.STU.UnicodeRange), /*\uA700*/ 42752, /*\uA71F*/ 42783);
            }
            //--TRIMMABLE-BOUNDARY-END(2564097310777)
            
            //--TRIMMABLE-BOUNDARY-START(558347583545)
            /*UnicodeRange?*/ static _uA700 = null;
            //--TRIMMABLE-BOUNDARY-END(558347583545)
            
            //--TRIMMABLE-BOUNDARY-START(2495377834041)
            static /*UnicodeRange */ get LatinExtendedD()
            {
                return $.$stew.STU.UnicodeRanges._uA720 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._uA720, ($v) => $.$stew.STU.UnicodeRanges._uA720 = $v, $.$stew.STU.UnicodeRange), /*\uA720*/ 42784, /*\uA7FF*/ 43007);
            }
            //--TRIMMABLE-BOUNDARY-END(2495377834041)
            
            //--TRIMMABLE-BOUNDARY-START(562642550841)
            /*UnicodeRange?*/ static _uA720 = null;
            //--TRIMMABLE-BOUNDARY-END(562642550841)
            
            //--TRIMMABLE-BOUNDARY-START(2697241296953)
            static /*UnicodeRange */ get SylotiNagri()
            {
                return $.$stew.STU.UnicodeRanges._uA800 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._uA800, ($v) => $.$stew.STU.UnicodeRanges._uA800 = $v, $.$stew.STU.UnicodeRange), /*\uA800*/ 43008, /*\uA82F*/ 43055);
            }
            //--TRIMMABLE-BOUNDARY-END(2697241296953)
            
            //--TRIMMABLE-BOUNDARY-START(566937518137)
            /*UnicodeRange?*/ static _uA800 = null;
            //--TRIMMABLE-BOUNDARY-END(566937518137)
            
            //--TRIMMABLE-BOUNDARY-START(863290261561)
            static /*UnicodeRange */ get CommonIndicNumberForms()
            {
                return $.$stew.STU.UnicodeRanges._uA830 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._uA830, ($v) => $.$stew.STU.UnicodeRanges._uA830 = $v, $.$stew.STU.UnicodeRange), /*\uA830*/ 43056, /*\uA83F*/ 43071);
            }
            //--TRIMMABLE-BOUNDARY-END(863290261561)
            
            //--TRIMMABLE-BOUNDARY-START(571232485433)
            /*UnicodeRange?*/ static _uA830 = null;
            //--TRIMMABLE-BOUNDARY-END(571232485433)
            
            //--TRIMMABLE-BOUNDARY-START(2619931885625)
            static /*UnicodeRange */ get Phagspa()
            {
                return $.$stew.STU.UnicodeRanges._uA840 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._uA840, ($v) => $.$stew.STU.UnicodeRanges._uA840 = $v, $.$stew.STU.UnicodeRange), /*\uA840*/ 43072, /*\uA87F*/ 43135);
            }
            //--TRIMMABLE-BOUNDARY-END(2619931885625)
            
            //--TRIMMABLE-BOUNDARY-START(575527452729)
            /*UnicodeRange?*/ static _uA840 = null;
            //--TRIMMABLE-BOUNDARY-END(575527452729)
            
            //--TRIMMABLE-BOUNDARY-START(2645701689401)
            static /*UnicodeRange */ get Saurashtra()
            {
                return $.$stew.STU.UnicodeRanges._uA880 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._uA880, ($v) => $.$stew.STU.UnicodeRanges._uA880 = $v, $.$stew.STU.UnicodeRange), /*\uA880*/ 43136, /*\uA8DF*/ 43231);
            }
            //--TRIMMABLE-BOUNDARY-END(2645701689401)
            
            //--TRIMMABLE-BOUNDARY-START(579822420025)
            /*UnicodeRange?*/ static _uA880 = null;
            //--TRIMMABLE-BOUNDARY-END(579822420025)
            
            //--TRIMMABLE-BOUNDARY-START(914829869113)
            static /*UnicodeRange */ get DevanagariExtended()
            {
                return $.$stew.STU.UnicodeRanges._uA8E0 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._uA8E0, ($v) => $.$stew.STU.UnicodeRanges._uA8E0 = $v, $.$stew.STU.UnicodeRange), /*\uA8E0*/ 43232, /*\uA8FF*/ 43263);
            }
            //--TRIMMABLE-BOUNDARY-END(914829869113)
            
            //--TRIMMABLE-BOUNDARY-START(584117387321)
            /*UnicodeRange?*/ static _uA8E0 = null;
            //--TRIMMABLE-BOUNDARY-END(584117387321)
            
            //--TRIMMABLE-BOUNDARY-START(2456723128377)
            static /*UnicodeRange */ get KayahLi()
            {
                return $.$stew.STU.UnicodeRanges._uA900 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._uA900, ($v) => $.$stew.STU.UnicodeRanges._uA900 = $v, $.$stew.STU.UnicodeRange), /*\uA900*/ 43264, /*\uA92F*/ 43311);
            }
            //--TRIMMABLE-BOUNDARY-END(2456723128377)
            
            //--TRIMMABLE-BOUNDARY-START(588412354617)
            /*UnicodeRange?*/ static _uA900 = null;
            //--TRIMMABLE-BOUNDARY-END(588412354617)
            
            //--TRIMMABLE-BOUNDARY-START(2632816787513)
            static /*UnicodeRange */ get Rejang()
            {
                return $.$stew.STU.UnicodeRanges._uA930 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._uA930, ($v) => $.$stew.STU.UnicodeRanges._uA930 = $v, $.$stew.STU.UnicodeRange), /*\uA930*/ 43312, /*\uA95F*/ 43359);
            }
            //--TRIMMABLE-BOUNDARY-END(2632816787513)
            
            //--TRIMMABLE-BOUNDARY-START(592707321913)
            /*UnicodeRange?*/ static _uA930 = null;
            //--TRIMMABLE-BOUNDARY-END(592707321913)
            
            //--TRIMMABLE-BOUNDARY-START(2396593586233)
            static /*UnicodeRange */ get HangulJamoExtendedA()
            {
                return $.$stew.STU.UnicodeRanges._uA960 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._uA960, ($v) => $.$stew.STU.UnicodeRanges._uA960 = $v, $.$stew.STU.UnicodeRange), /*\uA960*/ 43360, /*\uA97F*/ 43391);
            }
            //--TRIMMABLE-BOUNDARY-END(2396593586233)
            
            //--TRIMMABLE-BOUNDARY-START(597002289209)
            /*UnicodeRange?*/ static _uA960 = null;
            //--TRIMMABLE-BOUNDARY-END(597002289209)
            
            //--TRIMMABLE-BOUNDARY-START(2430953324601)
            static /*UnicodeRange */ get Javanese()
            {
                return $.$stew.STU.UnicodeRanges._uA980 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._uA980, ($v) => $.$stew.STU.UnicodeRanges._uA980 = $v, $.$stew.STU.UnicodeRange), /*\uA980*/ 43392, /*\uA9DF*/ 43487);
            }
            //--TRIMMABLE-BOUNDARY-END(2430953324601)
            
            //--TRIMMABLE-BOUNDARY-START(601297256505)
            /*UnicodeRange?*/ static _uA980 = null;
            //--TRIMMABLE-BOUNDARY-END(601297256505)
            
            //--TRIMMABLE-BOUNDARY-START(2581277179961)
            static /*UnicodeRange */ get MyanmarExtendedB()
            {
                return $.$stew.STU.UnicodeRanges._uA9E0 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._uA9E0, ($v) => $.$stew.STU.UnicodeRanges._uA9E0 = $v, $.$stew.STU.UnicodeRange), /*\uA9E0*/ 43488, /*\uA9FF*/ 43519);
            }
            //--TRIMMABLE-BOUNDARY-END(2581277179961)
            
            //--TRIMMABLE-BOUNDARY-START(605592223801)
            /*UnicodeRange?*/ static _uA9E0 = null;
            //--TRIMMABLE-BOUNDARY-END(605592223801)
            
            //--TRIMMABLE-BOUNDARY-START(794570784825)
            static /*UnicodeRange */ get Cham()
            {
                return $.$stew.STU.UnicodeRanges._uAA00 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._uAA00, ($v) => $.$stew.STU.UnicodeRanges._uAA00 = $v, $.$stew.STU.UnicodeRange), /*\uAA00*/ 43520, /*\uAA5F*/ 43615);
            }
            //--TRIMMABLE-BOUNDARY-END(794570784825)
            
            //--TRIMMABLE-BOUNDARY-START(609887191097)
            /*UnicodeRange?*/ static _uAA00 = null;
            //--TRIMMABLE-BOUNDARY-END(609887191097)
            
            //--TRIMMABLE-BOUNDARY-START(2576982212665)
            static /*UnicodeRange */ get MyanmarExtendedA()
            {
                return $.$stew.STU.UnicodeRanges._uAA60 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._uAA60, ($v) => $.$stew.STU.UnicodeRanges._uAA60 = $v, $.$stew.STU.UnicodeRange), /*\uAA60*/ 43616, /*\uAA7F*/ 43647);
            }
            //--TRIMMABLE-BOUNDARY-END(2576982212665)
            
            //--TRIMMABLE-BOUNDARY-START(614182158393)
            /*UnicodeRange?*/ static _uAA60 = null;
            //--TRIMMABLE-BOUNDARY-END(614182158393)
            
            //--TRIMMABLE-BOUNDARY-START(2727306068025)
            static /*UnicodeRange */ get TaiViet()
            {
                return $.$stew.STU.UnicodeRanges._uAA80 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._uAA80, ($v) => $.$stew.STU.UnicodeRanges._uAA80 = $v, $.$stew.STU.UnicodeRange), /*\uAA80*/ 43648, /*\uAADF*/ 43743);
            }
            //--TRIMMABLE-BOUNDARY-END(2727306068025)
            
            //--TRIMMABLE-BOUNDARY-START(618477125689)
            /*UnicodeRange?*/ static _uAA80 = null;
            //--TRIMMABLE-BOUNDARY-END(618477125689)
            
            //--TRIMMABLE-BOUNDARY-START(2538327507001)
            static /*UnicodeRange */ get MeeteiMayekExtensions()
            {
                return $.$stew.STU.UnicodeRanges._uAAE0 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._uAAE0, ($v) => $.$stew.STU.UnicodeRanges._uAAE0 = $v, $.$stew.STU.UnicodeRange), /*\uAAE0*/ 43744, /*\uAAFF*/ 43775);
            }
            //--TRIMMABLE-BOUNDARY-END(2538327507001)
            
            //--TRIMMABLE-BOUNDARY-START(622772092985)
            /*UnicodeRange?*/ static _uAAE0 = null;
            //--TRIMMABLE-BOUNDARY-END(622772092985)
            
            //--TRIMMABLE-BOUNDARY-START(940599672889)
            static /*UnicodeRange */ get EthiopicExtendedA()
            {
                return $.$stew.STU.UnicodeRanges._uAB00 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._uAB00, ($v) => $.$stew.STU.UnicodeRanges._uAB00 = $v, $.$stew.STU.UnicodeRange), /*\uAB00*/ 43776, /*\uAB2F*/ 43823);
            }
            //--TRIMMABLE-BOUNDARY-END(940599672889)
            
            //--TRIMMABLE-BOUNDARY-START(627067060281)
            /*UnicodeRange?*/ static _uAB00 = null;
            //--TRIMMABLE-BOUNDARY-END(627067060281)
            
            //--TRIMMABLE-BOUNDARY-START(2499672801337)
            static /*UnicodeRange */ get LatinExtendedE()
            {
                return $.$stew.STU.UnicodeRanges._uAB30 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._uAB30, ($v) => $.$stew.STU.UnicodeRanges._uAB30 = $v, $.$stew.STU.UnicodeRange), /*\uAB30*/ 43824, /*\uAB6F*/ 43887);
            }
            //--TRIMMABLE-BOUNDARY-END(2499672801337)
            
            //--TRIMMABLE-BOUNDARY-START(631362027577)
            /*UnicodeRange?*/ static _uAB30 = null;
            //--TRIMMABLE-BOUNDARY-END(631362027577)
            
            //--TRIMMABLE-BOUNDARY-START(803160719417)
            static /*UnicodeRange */ get CherokeeSupplement()
            {
                return $.$stew.STU.UnicodeRanges._uAB70 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._uAB70, ($v) => $.$stew.STU.UnicodeRanges._uAB70 = $v, $.$stew.STU.UnicodeRange), /*\uAB70*/ 43888, /*\uABBF*/ 43967);
            }
            //--TRIMMABLE-BOUNDARY-END(803160719417)
            
            //--TRIMMABLE-BOUNDARY-START(635656994873)
            /*UnicodeRange?*/ static _uAB70 = null;
            //--TRIMMABLE-BOUNDARY-END(635656994873)
            
            //--TRIMMABLE-BOUNDARY-START(2534032539705)
            static /*UnicodeRange */ get MeeteiMayek()
            {
                return $.$stew.STU.UnicodeRanges._uABC0 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._uABC0, ($v) => $.$stew.STU.UnicodeRanges._uABC0 = $v, $.$stew.STU.UnicodeRange), /*\uABC0*/ 43968, /*\uABFF*/ 44031);
            }
            //--TRIMMABLE-BOUNDARY-END(2534032539705)
            
            //--TRIMMABLE-BOUNDARY-START(639951962169)
            /*UnicodeRange?*/ static _uABC0 = null;
            //--TRIMMABLE-BOUNDARY-END(639951962169)
            
            //--TRIMMABLE-BOUNDARY-START(2405183520825)
            static /*UnicodeRange */ get HangulSyllables()
            {
                return $.$stew.STU.UnicodeRanges._uAC00 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._uAC00, ($v) => $.$stew.STU.UnicodeRanges._uAC00 = $v, $.$stew.STU.UnicodeRange), /*\uAC00*/ 44032, /*\uD7AF*/ 55215);
            }
            //--TRIMMABLE-BOUNDARY-END(2405183520825)
            
            //--TRIMMABLE-BOUNDARY-START(644246929465)
            /*UnicodeRange?*/ static _uAC00 = null;
            //--TRIMMABLE-BOUNDARY-END(644246929465)
            
            //--TRIMMABLE-BOUNDARY-START(2400888553529)
            static /*UnicodeRange */ get HangulJamoExtendedB()
            {
                return $.$stew.STU.UnicodeRanges._uD7B0 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._uD7B0, ($v) => $.$stew.STU.UnicodeRanges._uD7B0 = $v, $.$stew.STU.UnicodeRange), /*\uD7B0*/ 55216, /*\uD7FF*/ 55295);
            }
            //--TRIMMABLE-BOUNDARY-END(2400888553529)
            
            //--TRIMMABLE-BOUNDARY-START(648541896761)
            /*UnicodeRange?*/ static _uD7B0 = null;
            //--TRIMMABLE-BOUNDARY-END(648541896761)
            
            //--TRIMMABLE-BOUNDARY-START(816045621305)
            static /*UnicodeRange */ get CjkCompatibilityIdeographs()
            {
                return $.$stew.STU.UnicodeRanges._uF900 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._uF900, ($v) => $.$stew.STU.UnicodeRanges._uF900 = $v, $.$stew.STU.UnicodeRange), /*\uF900*/ 63744, /*\uFAFF*/ 64255);
            }
            //--TRIMMABLE-BOUNDARY-END(816045621305)
            
            //--TRIMMABLE-BOUNDARY-START(652836864057)
            /*UnicodeRange?*/ static _uF900 = null;
            //--TRIMMABLE-BOUNDARY-END(652836864057)
            
            //--TRIMMABLE-BOUNDARY-START(704376471609)
            static /*UnicodeRange */ get AlphabeticPresentationForms()
            {
                return $.$stew.STU.UnicodeRanges._uFB00 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._uFB00, ($v) => $.$stew.STU.UnicodeRanges._uFB00 = $v, $.$stew.STU.UnicodeRange), /*\uFB00*/ 64256, /*\uFB4F*/ 64335);
            }
            //--TRIMMABLE-BOUNDARY-END(704376471609)
            
            //--TRIMMABLE-BOUNDARY-START(657131831353)
            /*UnicodeRange?*/ static _uFB00 = null;
            //--TRIMMABLE-BOUNDARY-END(657131831353)
            
            //--TRIMMABLE-BOUNDARY-START(721556340793)
            static /*UnicodeRange */ get ArabicPresentationFormsA()
            {
                return $.$stew.STU.UnicodeRanges._uFB50 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._uFB50, ($v) => $.$stew.STU.UnicodeRanges._uFB50 = $v, $.$stew.STU.UnicodeRange), /*\uFB50*/ 64336, /*\uFDFF*/ 65023);
            }
            //--TRIMMABLE-BOUNDARY-END(721556340793)
            
            //--TRIMMABLE-BOUNDARY-START(661426798649)
            /*UnicodeRange?*/ static _uFB50 = null;
            //--TRIMMABLE-BOUNDARY-END(661426798649)
            
            //--TRIMMABLE-BOUNDARY-START(2770255740985)
            static /*UnicodeRange */ get VariationSelectors()
            {
                return $.$stew.STU.UnicodeRanges._uFE00 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._uFE00, ($v) => $.$stew.STU.UnicodeRanges._uFE00 = $v, $.$stew.STU.UnicodeRange), /*\uFE00*/ 65024, /*\uFE0F*/ 65039);
            }
            //--TRIMMABLE-BOUNDARY-END(2770255740985)
            
            //--TRIMMABLE-BOUNDARY-START(665721765945)
            /*UnicodeRange?*/ static _uFE00 = null;
            //--TRIMMABLE-BOUNDARY-END(665721765945)
            
            //--TRIMMABLE-BOUNDARY-START(2778845675577)
            static /*UnicodeRange */ get VerticalForms()
            {
                return $.$stew.STU.UnicodeRanges._uFE10 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._uFE10, ($v) => $.$stew.STU.UnicodeRanges._uFE10 = $v, $.$stew.STU.UnicodeRange), /*\uFE10*/ 65040, /*\uFE1F*/ 65055);
            }
            //--TRIMMABLE-BOUNDARY-END(2778845675577)
            
            //--TRIMMABLE-BOUNDARY-START(670016733241)
            /*UnicodeRange?*/ static _uFE10 = null;
            //--TRIMMABLE-BOUNDARY-END(670016733241)
            
            //--TRIMMABLE-BOUNDARY-START(858995294265)
            static /*UnicodeRange */ get CombiningHalfMarks()
            {
                return $.$stew.STU.UnicodeRanges._uFE20 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._uFE20, ($v) => $.$stew.STU.UnicodeRanges._uFE20 = $v, $.$stew.STU.UnicodeRange), /*\uFE20*/ 65056, /*\uFE2F*/ 65071);
            }
            //--TRIMMABLE-BOUNDARY-END(858995294265)
            
            //--TRIMMABLE-BOUNDARY-START(674311700537)
            /*UnicodeRange?*/ static _uFE20 = null;
            //--TRIMMABLE-BOUNDARY-END(674311700537)
            
            //--TRIMMABLE-BOUNDARY-START(811750654009)
            static /*UnicodeRange */ get CjkCompatibilityForms()
            {
                return $.$stew.STU.UnicodeRanges._uFE30 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._uFE30, ($v) => $.$stew.STU.UnicodeRanges._uFE30 = $v, $.$stew.STU.UnicodeRange), /*\uFE30*/ 65072, /*\uFE4F*/ 65103);
            }
            //--TRIMMABLE-BOUNDARY-END(811750654009)
            
            //--TRIMMABLE-BOUNDARY-START(678606667833)
            /*UnicodeRange?*/ static _uFE30 = null;
            //--TRIMMABLE-BOUNDARY-END(678606667833)
            
            //--TRIMMABLE-BOUNDARY-START(2654291623993)
            static /*UnicodeRange */ get SmallFormVariants()
            {
                return $.$stew.STU.UnicodeRanges._uFE50 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._uFE50, ($v) => $.$stew.STU.UnicodeRanges._uFE50 = $v, $.$stew.STU.UnicodeRange), /*\uFE50*/ 65104, /*\uFE6F*/ 65135);
            }
            //--TRIMMABLE-BOUNDARY-END(2654291623993)
            
            //--TRIMMABLE-BOUNDARY-START(682901635129)
            /*UnicodeRange?*/ static _uFE50 = null;
            //--TRIMMABLE-BOUNDARY-END(682901635129)
            
            //--TRIMMABLE-BOUNDARY-START(725851308089)
            static /*UnicodeRange */ get ArabicPresentationFormsB()
            {
                return $.$stew.STU.UnicodeRanges._uFE70 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._uFE70, ($v) => $.$stew.STU.UnicodeRanges._uFE70 = $v, $.$stew.STU.UnicodeRange), /*\uFE70*/ 65136, /*\uFEFF*/ 65279);
            }
            //--TRIMMABLE-BOUNDARY-END(725851308089)
            
            //--TRIMMABLE-BOUNDARY-START(687196602425)
            /*UnicodeRange?*/ static _uFE70 = null;
            //--TRIMMABLE-BOUNDARY-END(687196602425)
            
            //--TRIMMABLE-BOUNDARY-START(2383708684345)
            static /*UnicodeRange */ get HalfwidthandFullwidthForms()
            {
                return $.$stew.STU.UnicodeRanges._uFF00 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._uFF00, ($v) => $.$stew.STU.UnicodeRanges._uFF00 = $v, $.$stew.STU.UnicodeRange), /*\uFF00*/ 65280, /*\uFFEF*/ 65519);
            }
            //--TRIMMABLE-BOUNDARY-END(2383708684345)
            
            //--TRIMMABLE-BOUNDARY-START(691491569721)
            /*UnicodeRange?*/ static _uFF00 = null;
            //--TRIMMABLE-BOUNDARY-END(691491569721)
            
            //--TRIMMABLE-BOUNDARY-START(2662881558585)
            static /*UnicodeRange */ get Specials()
            {
                return $.$stew.STU.UnicodeRanges._uFFF0 ?? $.$stew.STU.UnicodeRanges.CreateRange($.$ref(() => $.$stew.STU.UnicodeRanges._uFFF0, ($v) => $.$stew.STU.UnicodeRanges._uFFF0 = $v, $.$stew.STU.UnicodeRange), /*\uFFF0*/ 65520, /*\uFFFF*/ 65535);
            }
            //--TRIMMABLE-BOUNDARY-END(2662881558585)
            
            //--TRIMMABLE-BOUNDARY-START(695786537017)
            /*UnicodeRange?*/ static _uFFF0 = null;
            //--TRIMMABLE-BOUNDARY-END(695786537017)
            
            static $h = 1835065;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(2594162081849),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1962801889337,
        "f": 50331681
      },
      "n": "None",
      "d": 1835065,
      "h": 2594162081849,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2594162081849),
//--TRIMMABLE-BOUNDARY-START(700081504313),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 974959411257,
        "f": 50331681
      },
      "n": "All",
      "d": 1835065,
      "h": 700081504313,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(700081504313),
//--TRIMMABLE-BOUNDARY-START(751621111865),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1078038626361,
        "f": 50331681
      },
      "n": "BasicLatin",
      "d": 1835065,
      "h": 751621111865,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(751621111865),
//--TRIMMABLE-BOUNDARY-START(2473902997561),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1722283720761,
        "f": 50331681
      },
      "n": "Latin1Supplement",
      "d": 1835065,
      "h": 2473902997561,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2473902997561),
//--TRIMMABLE-BOUNDARY-START(2478197964857),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1730873655353,
        "f": 50331681
      },
      "n": "LatinExtendedA",
      "d": 1835065,
      "h": 2478197964857,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2478197964857),
//--TRIMMABLE-BOUNDARY-START(2486787899449),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1748053524537,
        "f": 50331681
      },
      "n": "LatinExtendedB",
      "d": 1835065,
      "h": 2486787899449,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2486787899449),
//--TRIMMABLE-BOUNDARY-START(2426658357305),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1627794440249,
        "f": 50331681
      },
      "n": "IpaExtensions",
      "d": 1835065,
      "h": 2426658357305,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2426658357305),
//--TRIMMABLE-BOUNDARY-START(2658586591289),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 2091650908217,
        "f": 50331681
      },
      "n": "SpacingModifierLetters",
      "d": 1835065,
      "h": 2658586591289,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2658586591289),
//--TRIMMABLE-BOUNDARY-START(841815425081),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1258427252793,
        "f": 50331681
      },
      "n": "CombiningDiacriticalMarks",
      "d": 1835065,
      "h": 841815425081,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(841815425081),
//--TRIMMABLE-BOUNDARY-START(2366528815161),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1507535355961,
        "f": 50331681
      },
      "n": "GreekandCoptic",
      "d": 1835065,
      "h": 2366528815161,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2366528815161),
//--TRIMMABLE-BOUNDARY-START(889060065337),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1335736664121,
        "f": 50331681
      },
      "n": "Cyrillic",
      "d": 1835065,
      "h": 889060065337,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(889060065337),
//--TRIMMABLE-BOUNDARY-START(906239934521),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1370096402489,
        "f": 50331681
      },
      "n": "CyrillicSupplement",
      "d": 1835065,
      "h": 906239934521,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(906239934521),
//--TRIMMABLE-BOUNDARY-START(734441242681),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1043678887993,
        "f": 50331681
      },
      "n": "Armenian",
      "d": 1835065,
      "h": 734441242681,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(734441242681),
//--TRIMMABLE-BOUNDARY-START(2413773455417),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1602024636473,
        "f": 50331681
      },
      "n": "Hebrew",
      "d": 1835065,
      "h": 2413773455417,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2413773455417),
//--TRIMMABLE-BOUNDARY-START(708671438905),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 992139280441,
        "f": 50331681
      },
      "n": "Arabic",
      "d": 1835065,
      "h": 708671438905,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(708671438905),
//--TRIMMABLE-BOUNDARY-START(2701536264249),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 2177550254137,
        "f": 50331681
      },
      "n": "Syriac",
      "d": 1835065,
      "h": 2701536264249,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2701536264249),
//--TRIMMABLE-BOUNDARY-START(730146275385),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1035088953401,
        "f": 50331681
      },
      "n": "ArabicSupplement",
      "d": 1835065,
      "h": 730146275385,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(730146275385),
//--TRIMMABLE-BOUNDARY-START(2740190969913),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 2254859665465,
        "f": 50331681
      },
      "n": "Thaana",
      "d": 1835065,
      "h": 2740190969913,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2740190969913),
//--TRIMMABLE-BOUNDARY-START(2589867114553),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1954211954745,
        "f": 50331681
      },
      "n": "NKo",
      "d": 1835065,
      "h": 2589867114553,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2589867114553),
//--TRIMMABLE-BOUNDARY-START(2641406722105),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 2057291169849,
        "f": 50331681
      },
      "n": "Samaritan",
      "d": 1835065,
      "h": 2641406722105,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2641406722105),
//--TRIMMABLE-BOUNDARY-START(2525442605113),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1825362935865,
        "f": 50331681
      },
      "n": "Mandaic",
      "d": 1835065,
      "h": 2525442605113,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2525442605113),
//--TRIMMABLE-BOUNDARY-START(2705831231545),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 2186140188729,
        "f": 50331681
      },
      "n": "SyriacSupplement",
      "d": 1835065,
      "h": 2705831231545,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2705831231545),
//--TRIMMABLE-BOUNDARY-START(717261373497),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1009319149625,
        "f": 50331681
      },
      "n": "ArabicExtendedB",
      "d": 1835065,
      "h": 717261373497,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(717261373497),
//--TRIMMABLE-BOUNDARY-START(712966406201),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1000729215033,
        "f": 50331681
      },
      "n": "ArabicExtendedA",
      "d": 1835065,
      "h": 712966406201,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(712966406201),
//--TRIMMABLE-BOUNDARY-START(910534901817),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1378686337081,
        "f": 50331681
      },
      "n": "Devanagari",
      "d": 1835065,
      "h": 910534901817,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(910534901817),
//--TRIMMABLE-BOUNDARY-START(760211046457),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1095218495545,
        "f": 50331681
      },
      "n": "Bengali",
      "d": 1835065,
      "h": 760211046457,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(760211046457),
//--TRIMMABLE-BOUNDARY-START(2379413717049),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1533305159737,
        "f": 50331681
      },
      "n": "Gurmukhi",
      "d": 1835065,
      "h": 2379413717049,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2379413717049),
//--TRIMMABLE-BOUNDARY-START(2375118749753),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1524715225145,
        "f": 50331681
      },
      "n": "Gujarati",
      "d": 1835065,
      "h": 2375118749753,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2375118749753),
//--TRIMMABLE-BOUNDARY-START(2615636918329),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 2005751562297,
        "f": 50331681
      },
      "n": "Oriya",
      "d": 1835065,
      "h": 2615636918329,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2615636918329),
//--TRIMMABLE-BOUNDARY-START(2731601035321),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 2237679796281,
        "f": 50331681
      },
      "n": "Tamil",
      "d": 1835065,
      "h": 2731601035321,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2731601035321),
//--TRIMMABLE-BOUNDARY-START(2735896002617),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 2246269730873,
        "f": 50331681
      },
      "n": "Telugu",
      "d": 1835065,
      "h": 2735896002617,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2735896002617),
//--TRIMMABLE-BOUNDARY-START(2443838226489),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1662154178617,
        "f": 50331681
      },
      "n": "Kannada",
      "d": 1835065,
      "h": 2443838226489,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2443838226489),
//--TRIMMABLE-BOUNDARY-START(2521147637817),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1816773001273,
        "f": 50331681
      },
      "n": "Malayalam",
      "d": 1835065,
      "h": 2521147637817,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2521147637817),
//--TRIMMABLE-BOUNDARY-START(2649996656697),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 2074471039033,
        "f": 50331681
      },
      "n": "Sinhala",
      "d": 1835065,
      "h": 2649996656697,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2649996656697),
//--TRIMMABLE-BOUNDARY-START(2744485937209),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 2263449600057,
        "f": 50331681
      },
      "n": "Thai",
      "d": 1835065,
      "h": 2744485937209,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2744485937209),
//--TRIMMABLE-BOUNDARY-START(2469608030265),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1713693786169,
        "f": 50331681
      },
      "n": "Lao",
      "d": 1835065,
      "h": 2469608030265,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2469608030265),
//--TRIMMABLE-BOUNDARY-START(2748780904505),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 2272039534649,
        "f": 50331681
      },
      "n": "Tibetan",
      "d": 1835065,
      "h": 2748780904505,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2748780904505),
//--TRIMMABLE-BOUNDARY-START(2572687245369),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1919852216377,
        "f": 50331681
      },
      "n": "Myanmar",
      "d": 1835065,
      "h": 2572687245369,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2572687245369),
//--TRIMMABLE-BOUNDARY-START(957779542073),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1473175617593,
        "f": 50331681
      },
      "n": "Georgian",
      "d": 1835065,
      "h": 957779542073,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(957779542073),
//--TRIMMABLE-BOUNDARY-START(2392298618937),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1559074963513,
        "f": 50331681
      },
      "n": "HangulJamo",
      "d": 1835065,
      "h": 2392298618937,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2392298618937),
//--TRIMMABLE-BOUNDARY-START(932009738297),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1421636010041,
        "f": 50331681
      },
      "n": "Ethiopic",
      "d": 1835065,
      "h": 932009738297,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(932009738297),
//--TRIMMABLE-BOUNDARY-START(944894640185),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1447405813817,
        "f": 50331681
      },
      "n": "EthiopicSupplement",
      "d": 1835065,
      "h": 944894640185,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(944894640185),
//--TRIMMABLE-BOUNDARY-START(798865752121),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1172527906873,
        "f": 50331681
      },
      "n": "Cherokee",
      "d": 1835065,
      "h": 798865752121,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(798865752121),
//--TRIMMABLE-BOUNDARY-START(2757370839097),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 2289219403833,
        "f": 50331681
      },
      "n": "UnifiedCanadianAboriginalSyllabics",
      "d": 1835065,
      "h": 2757370839097,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2757370839097),
//--TRIMMABLE-BOUNDARY-START(2602752016441),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1979981758521,
        "f": 50331681
      },
      "n": "Ogham",
      "d": 1835065,
      "h": 2602752016441,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2602752016441),
//--TRIMMABLE-BOUNDARY-START(2637111754809),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 2048701235257,
        "f": 50331681
      },
      "n": "Runic",
      "d": 1835065,
      "h": 2637111754809,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2637111754809),
//--TRIMMABLE-BOUNDARY-START(2710126198841),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 2194730123321,
        "f": 50331681
      },
      "n": "Tagalog",
      "d": 1835065,
      "h": 2710126198841,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2710126198841),
//--TRIMMABLE-BOUNDARY-START(2409478488121),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1593434701881,
        "f": 50331681
      },
      "n": "Hanunoo",
      "d": 1835065,
      "h": 2409478488121,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2409478488121),
//--TRIMMABLE-BOUNDARY-START(790275817529),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1155348037689,
        "f": 50331681
      },
      "n": "Buhid",
      "d": 1835065,
      "h": 790275817529,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(790275817529),
//--TRIMMABLE-BOUNDARY-START(2714421166137),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 2203320057913,
        "f": 50331681
      },
      "n": "Tagbanwa",
      "d": 1835065,
      "h": 2714421166137,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2714421166137),
//--TRIMMABLE-BOUNDARY-START(2461018095673),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1696513916985,
        "f": 50331681
      },
      "n": "Khmer",
      "d": 1835065,
      "h": 2461018095673,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2461018095673),
//--TRIMMABLE-BOUNDARY-START(2568392278073),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1911262281785,
        "f": 50331681
      },
      "n": "Mongolian",
      "d": 1835065,
      "h": 2568392278073,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2568392278073),
//--TRIMMABLE-BOUNDARY-START(2761665806393),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 2297809338425,
        "f": 50331681
      },
      "n": "UnifiedCanadianAboriginalSyllabicsExtended",
      "d": 1835065,
      "h": 2761665806393,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2761665806393),
//--TRIMMABLE-BOUNDARY-START(2512557703225),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1799593132089,
        "f": 50331681
      },
      "n": "Limbu",
      "d": 1835065,
      "h": 2512557703225,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2512557703225),
//--TRIMMABLE-BOUNDARY-START(2718716133433),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 2211909992505,
        "f": 50331681
      },
      "n": "TaiLe",
      "d": 1835065,
      "h": 2718716133433,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2718716133433),
//--TRIMMABLE-BOUNDARY-START(2585572147257),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1945622020153,
        "f": 50331681
      },
      "n": "NewTaiLue",
      "d": 1835065,
      "h": 2585572147257,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2585572147257),
//--TRIMMABLE-BOUNDARY-START(2465313062969),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1705103851577,
        "f": 50331681
      },
      "n": "KhmerSymbols",
      "d": 1835065,
      "h": 2465313062969,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2465313062969),
//--TRIMMABLE-BOUNDARY-START(785980850233),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1146758103097,
        "f": 50331681
      },
      "n": "Buginese",
      "d": 1835065,
      "h": 785980850233,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(785980850233),
//--TRIMMABLE-BOUNDARY-START(2723011100729),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 2220499927097,
        "f": 50331681
      },
      "n": "TaiTham",
      "d": 1835065,
      "h": 2723011100729,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2723011100729),
//--TRIMMABLE-BOUNDARY-START(846110392377),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1267017187385,
        "f": 50331681
      },
      "n": "CombiningDiacriticalMarksExtended",
      "d": 1835065,
      "h": 846110392377,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(846110392377),
//--TRIMMABLE-BOUNDARY-START(743031177273),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1060858757177,
        "f": 50331681
      },
      "n": "Balinese",
      "d": 1835065,
      "h": 743031177273,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(743031177273),
//--TRIMMABLE-BOUNDARY-START(2667176525881),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 2108830777401,
        "f": 50331681
      },
      "n": "Sundanese",
      "d": 1835065,
      "h": 2667176525881,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2667176525881),
//--TRIMMABLE-BOUNDARY-START(755916079161),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1086628560953,
        "f": 50331681
      },
      "n": "Batak",
      "d": 1835065,
      "h": 755916079161,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(755916079161),
//--TRIMMABLE-BOUNDARY-START(2503967768633),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1782413262905,
        "f": 50331681
      },
      "n": "Lepcha",
      "d": 1835065,
      "h": 2503967768633,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2503967768633),
//--TRIMMABLE-BOUNDARY-START(2607046983737),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1988571693113,
        "f": 50331681
      },
      "n": "OlChiki",
      "d": 1835065,
      "h": 2607046983737,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2607046983737),
//--TRIMMABLE-BOUNDARY-START(901944967225),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1361506467897,
        "f": 50331681
      },
      "n": "CyrillicExtendedC",
      "d": 1835065,
      "h": 901944967225,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(901944967225),
//--TRIMMABLE-BOUNDARY-START(962074509369),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1481765552185,
        "f": 50331681
      },
      "n": "GeorgianExtended",
      "d": 1835065,
      "h": 962074509369,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(962074509369),
//--TRIMMABLE-BOUNDARY-START(2671471493177),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 2117420711993,
        "f": 50331681
      },
      "n": "SundaneseSupplement",
      "d": 1835065,
      "h": 2671471493177,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2671471493177),
//--TRIMMABLE-BOUNDARY-START(2774550708281),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 2323579142201,
        "f": 50331681
      },
      "n": "VedicExtensions",
      "d": 1835065,
      "h": 2774550708281,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2774550708281),
//--TRIMMABLE-BOUNDARY-START(2624226852921),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 2022931431481,
        "f": 50331681
      },
      "n": "PhoneticExtensions",
      "d": 1835065,
      "h": 2624226852921,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2624226852921),
//--TRIMMABLE-BOUNDARY-START(2628521820217),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 2031521366073,
        "f": 50331681
      },
      "n": "PhoneticExtensionsSupplement",
      "d": 1835065,
      "h": 2628521820217,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2628521820217),
//--TRIMMABLE-BOUNDARY-START(854700326969),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1284197056569,
        "f": 50331681
      },
      "n": "CombiningDiacriticalMarksSupplement",
      "d": 1835065,
      "h": 854700326969,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(854700326969),
//--TRIMMABLE-BOUNDARY-START(2482492932153),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1739463589945,
        "f": 50331681
      },
      "n": "LatinExtendedAdditional",
      "d": 1835065,
      "h": 2482492932153,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2482492932153),
//--TRIMMABLE-BOUNDARY-START(2370823782457),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1516125290553,
        "f": 50331681
      },
      "n": "GreekExtended",
      "d": 1835065,
      "h": 2370823782457,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2370823782457),
//--TRIMMABLE-BOUNDARY-START(949189607481),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1455995748409,
        "f": 50331681
      },
      "n": "GeneralPunctuation",
      "d": 1835065,
      "h": 949189607481,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(949189607481),
//--TRIMMABLE-BOUNDARY-START(2675766460473),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 2126010646585,
        "f": 50331681
      },
      "n": "SuperscriptsandSubscripts",
      "d": 1835065,
      "h": 2675766460473,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2675766460473),
//--TRIMMABLE-BOUNDARY-START(884765098041),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1327146729529,
        "f": 50331681
      },
      "n": "CurrencySymbols",
      "d": 1835065,
      "h": 884765098041,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(884765098041),
//--TRIMMABLE-BOUNDARY-START(850405359673),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1275607121977,
        "f": 50331681
      },
      "n": "CombiningDiacriticalMarksforSymbols",
      "d": 1835065,
      "h": 850405359673,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(850405359673),
//--TRIMMABLE-BOUNDARY-START(2508262735929),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1791003197497,
        "f": 50331681
      },
      "n": "LetterlikeSymbols",
      "d": 1835065,
      "h": 2508262735929,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2508262735929),
//--TRIMMABLE-BOUNDARY-START(2598457049145),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1971391823929,
        "f": 50331681
      },
      "n": "NumberForms",
      "d": 1835065,
      "h": 2598457049145,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2598457049145),
//--TRIMMABLE-BOUNDARY-START(738736209977),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1052268822585,
        "f": 50331681
      },
      "n": "Arrows",
      "d": 1835065,
      "h": 738736209977,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(738736209977),
//--TRIMMABLE-BOUNDARY-START(2529737572409),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1833952870457,
        "f": 50331681
      },
      "n": "MathematicalOperators",
      "d": 1835065,
      "h": 2529737572409,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2529737572409),
//--TRIMMABLE-BOUNDARY-START(2559802343481),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1894082412601,
        "f": 50331681
      },
      "n": "MiscellaneousTechnical",
      "d": 1835065,
      "h": 2559802343481,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2559802343481),
//--TRIMMABLE-BOUNDARY-START(867585228857),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1309966860345,
        "f": 50331681
      },
      "n": "ControlPictures",
      "d": 1835065,
      "h": 867585228857,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(867585228857),
//--TRIMMABLE-BOUNDARY-START(2611341951033),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1997161627705,
        "f": 50331681
      },
      "n": "OpticalCharacterRecognition",
      "d": 1835065,
      "h": 2611341951033,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2611341951033),
//--TRIMMABLE-BOUNDARY-START(923419803705),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1404456140857,
        "f": 50331681
      },
      "n": "EnclosedAlphanumerics",
      "d": 1835065,
      "h": 923419803705,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(923419803705),
//--TRIMMABLE-BOUNDARY-START(777390915641),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1129578233913,
        "f": 50331681
      },
      "n": "BoxDrawing",
      "d": 1835065,
      "h": 777390915641,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(777390915641),
//--TRIMMABLE-BOUNDARY-START(764506013753),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1103808430137,
        "f": 50331681
      },
      "n": "BlockElements",
      "d": 1835065,
      "h": 764506013753,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(764506013753),
//--TRIMMABLE-BOUNDARY-START(953484574777),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1464585683001,
        "f": 50331681
      },
      "n": "GeometricShapes",
      "d": 1835065,
      "h": 953484574777,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(953484574777),
//--TRIMMABLE-BOUNDARY-START(2551212408889),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1876902543417,
        "f": 50331681
      },
      "n": "MiscellaneousSymbols",
      "d": 1835065,
      "h": 2551212408889,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2551212408889),
//--TRIMMABLE-BOUNDARY-START(919124836409),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1395866206265,
        "f": 50331681
      },
      "n": "Dingbats",
      "d": 1835065,
      "h": 919124836409,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(919124836409),
//--TRIMMABLE-BOUNDARY-START(2542622474297),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1859722674233,
        "f": 50331681
      },
      "n": "MiscellaneousMathematicalSymbolsA",
      "d": 1835065,
      "h": 2542622474297,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2542622474297),
//--TRIMMABLE-BOUNDARY-START(2680061427769),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 2134600581177,
        "f": 50331681
      },
      "n": "SupplementalArrowsA",
      "d": 1835065,
      "h": 2680061427769,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2680061427769),
//--TRIMMABLE-BOUNDARY-START(781685882937),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1138168168505,
        "f": 50331681
      },
      "n": "BraillePatterns",
      "d": 1835065,
      "h": 781685882937,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(781685882937),
//--TRIMMABLE-BOUNDARY-START(2684356395065),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 2143190515769,
        "f": 50331681
      },
      "n": "SupplementalArrowsB",
      "d": 1835065,
      "h": 2684356395065,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2684356395065),
//--TRIMMABLE-BOUNDARY-START(2546917441593),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1868312608825,
        "f": 50331681
      },
      "n": "MiscellaneousMathematicalSymbolsB",
      "d": 1835065,
      "h": 2546917441593,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2546917441593),
//--TRIMMABLE-BOUNDARY-START(2688651362361),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 2151780450361,
        "f": 50331681
      },
      "n": "SupplementalMathematicalOperators",
      "d": 1835065,
      "h": 2688651362361,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2688651362361),
//--TRIMMABLE-BOUNDARY-START(2555507376185),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1885492478009,
        "f": 50331681
      },
      "n": "MiscellaneousSymbolsandArrows",
      "d": 1835065,
      "h": 2555507376185,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2555507376185),
//--TRIMMABLE-BOUNDARY-START(2362233847865),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1498945421369,
        "f": 50331681
      },
      "n": "Glagolitic",
      "d": 1835065,
      "h": 2362233847865,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2362233847865),
//--TRIMMABLE-BOUNDARY-START(2491082866745),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1756643459129,
        "f": 50331681
      },
      "n": "LatinExtendedC",
      "d": 1835065,
      "h": 2491082866745,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2491082866745),
//--TRIMMABLE-BOUNDARY-START(871880196153),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1318556794937,
        "f": 50331681
      },
      "n": "Coptic",
      "d": 1835065,
      "h": 871880196153,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(871880196153),
//--TRIMMABLE-BOUNDARY-START(966369476665),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1490355486777,
        "f": 50331681
      },
      "n": "GeorgianSupplement",
      "d": 1835065,
      "h": 966369476665,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(966369476665),
//--TRIMMABLE-BOUNDARY-START(2753075871801),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 2280629469241,
        "f": 50331681
      },
      "n": "Tifinagh",
      "d": 1835065,
      "h": 2753075871801,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2753075871801),
//--TRIMMABLE-BOUNDARY-START(936304705593),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1430225944633,
        "f": 50331681
      },
      "n": "EthiopicExtended",
      "d": 1835065,
      "h": 936304705593,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(936304705593),
//--TRIMMABLE-BOUNDARY-START(893355032633),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1344326598713,
        "f": 50331681
      },
      "n": "CyrillicExtendedA",
      "d": 1835065,
      "h": 893355032633,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(893355032633),
//--TRIMMABLE-BOUNDARY-START(2692946329657),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 2160370384953,
        "f": 50331681
      },
      "n": "SupplementalPunctuation",
      "d": 1835065,
      "h": 2692946329657,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2692946329657),
//--TRIMMABLE-BOUNDARY-START(820340588601),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1215477579833,
        "f": 50331681
      },
      "n": "CjkRadicalsSupplement",
      "d": 1835065,
      "h": 820340588601,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(820340588601),
//--TRIMMABLE-BOUNDARY-START(2439543259193),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1653564244025,
        "f": 50331681
      },
      "n": "KangxiRadicals",
      "d": 1835065,
      "h": 2439543259193,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2439543259193),
//--TRIMMABLE-BOUNDARY-START(2422363390009),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1619204505657,
        "f": 50331681
      },
      "n": "IdeographicDescriptionCharacters",
      "d": 1835065,
      "h": 2422363390009,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2422363390009),
//--TRIMMABLE-BOUNDARY-START(828930523193),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1232657449017,
        "f": 50331681
      },
      "n": "CjkSymbolsandPunctuation",
      "d": 1835065,
      "h": 828930523193,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(828930523193),
//--TRIMMABLE-BOUNDARY-START(2418068422713),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1610614571065,
        "f": 50331681
      },
      "n": "Hiragana",
      "d": 1835065,
      "h": 2418068422713,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2418068422713),
//--TRIMMABLE-BOUNDARY-START(2448133193785),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1670744113209,
        "f": 50331681
      },
      "n": "Katakana",
      "d": 1835065,
      "h": 2448133193785,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2448133193785),
//--TRIMMABLE-BOUNDARY-START(768800981049),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1112398364729,
        "f": 50331681
      },
      "n": "Bopomofo",
      "d": 1835065,
      "h": 768800981049,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(768800981049),
//--TRIMMABLE-BOUNDARY-START(2388003651641),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1550485028921,
        "f": 50331681
      },
      "n": "HangulCompatibilityJamo",
      "d": 1835065,
      "h": 2388003651641,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2388003651641),
//--TRIMMABLE-BOUNDARY-START(2435248291897),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1644974309433,
        "f": 50331681
      },
      "n": "Kanbun",
      "d": 1835065,
      "h": 2435248291897,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2435248291897),
//--TRIMMABLE-BOUNDARY-START(773095948345),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1120988299321,
        "f": 50331681
      },
      "n": "BopomofoExtended",
      "d": 1835065,
      "h": 773095948345,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(773095948345),
//--TRIMMABLE-BOUNDARY-START(824635555897),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1224067514425,
        "f": 50331681
      },
      "n": "CjkStrokes",
      "d": 1835065,
      "h": 824635555897,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(824635555897),
//--TRIMMABLE-BOUNDARY-START(2452428161081),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1679334047801,
        "f": 50331681
      },
      "n": "KatakanaPhoneticExtensions",
      "d": 1835065,
      "h": 2452428161081,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2452428161081),
//--TRIMMABLE-BOUNDARY-START(927714771001),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1413046075449,
        "f": 50331681
      },
      "n": "EnclosedCjkLettersandMonths",
      "d": 1835065,
      "h": 927714771001,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(927714771001),
//--TRIMMABLE-BOUNDARY-START(807455686713),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1189707776057,
        "f": 50331681
      },
      "n": "CjkCompatibility",
      "d": 1835065,
      "h": 807455686713,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(807455686713),
//--TRIMMABLE-BOUNDARY-START(837520457785),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1249837318201,
        "f": 50331681
      },
      "n": "CjkUnifiedIdeographsExtensionA",
      "d": 1835065,
      "h": 837520457785,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(837520457785),
//--TRIMMABLE-BOUNDARY-START(2783140642873),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 2340759011385,
        "f": 50331681
      },
      "n": "YijingHexagramSymbols",
      "d": 1835065,
      "h": 2783140642873,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2783140642873),
//--TRIMMABLE-BOUNDARY-START(833225490489),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1241247383609,
        "f": 50331681
      },
      "n": "CjkUnifiedIdeographs",
      "d": 1835065,
      "h": 833225490489,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(833225490489),
//--TRIMMABLE-BOUNDARY-START(2791730577465),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 2357938880569,
        "f": 50331681
      },
      "n": "YiSyllables",
      "d": 1835065,
      "h": 2791730577465,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2791730577465),
//--TRIMMABLE-BOUNDARY-START(2787435610169),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 2349348945977,
        "f": 50331681
      },
      "n": "YiRadicals",
      "d": 1835065,
      "h": 2787435610169,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2787435610169),
//--TRIMMABLE-BOUNDARY-START(2516852670521),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1808183066681,
        "f": 50331681
      },
      "n": "Lisu",
      "d": 1835065,
      "h": 2516852670521,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2516852670521),
//--TRIMMABLE-BOUNDARY-START(2765960773689),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 2306399273017,
        "f": 50331681
      },
      "n": "Vai",
      "d": 1835065,
      "h": 2765960773689,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2765960773689),
//--TRIMMABLE-BOUNDARY-START(897649999929),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1352916533305,
        "f": 50331681
      },
      "n": "CyrillicExtendedB",
      "d": 1835065,
      "h": 897649999929,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(897649999929),
//--TRIMMABLE-BOUNDARY-START(747326144569),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1069448691769,
        "f": 50331681
      },
      "n": "Bamum",
      "d": 1835065,
      "h": 747326144569,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(747326144569),
//--TRIMMABLE-BOUNDARY-START(2564097310777),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1902672347193,
        "f": 50331681
      },
      "n": "ModifierToneLetters",
      "d": 1835065,
      "h": 2564097310777,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2564097310777),
//--TRIMMABLE-BOUNDARY-START(2495377834041),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1765233393721,
        "f": 50331681
      },
      "n": "LatinExtendedD",
      "d": 1835065,
      "h": 2495377834041,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2495377834041),
//--TRIMMABLE-BOUNDARY-START(2697241296953),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 2168960319545,
        "f": 50331681
      },
      "n": "SylotiNagri",
      "d": 1835065,
      "h": 2697241296953,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2697241296953),
//--TRIMMABLE-BOUNDARY-START(863290261561),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1301376925753,
        "f": 50331681
      },
      "n": "CommonIndicNumberForms",
      "d": 1835065,
      "h": 863290261561,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(863290261561),
//--TRIMMABLE-BOUNDARY-START(2619931885625),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 2014341496889,
        "f": 50331681
      },
      "n": "Phagspa",
      "d": 1835065,
      "h": 2619931885625,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2619931885625),
//--TRIMMABLE-BOUNDARY-START(2645701689401),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 2065881104441,
        "f": 50331681
      },
      "n": "Saurashtra",
      "d": 1835065,
      "h": 2645701689401,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2645701689401),
//--TRIMMABLE-BOUNDARY-START(914829869113),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1387276271673,
        "f": 50331681
      },
      "n": "DevanagariExtended",
      "d": 1835065,
      "h": 914829869113,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(914829869113),
//--TRIMMABLE-BOUNDARY-START(2456723128377),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1687923982393,
        "f": 50331681
      },
      "n": "KayahLi",
      "d": 1835065,
      "h": 2456723128377,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2456723128377),
//--TRIMMABLE-BOUNDARY-START(2632816787513),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 2040111300665,
        "f": 50331681
      },
      "n": "Rejang",
      "d": 1835065,
      "h": 2632816787513,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2632816787513),
//--TRIMMABLE-BOUNDARY-START(2396593586233),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1567664898105,
        "f": 50331681
      },
      "n": "HangulJamoExtendedA",
      "d": 1835065,
      "h": 2396593586233,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2396593586233),
//--TRIMMABLE-BOUNDARY-START(2430953324601),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1636384374841,
        "f": 50331681
      },
      "n": "Javanese",
      "d": 1835065,
      "h": 2430953324601,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2430953324601),
//--TRIMMABLE-BOUNDARY-START(2581277179961),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1937032085561,
        "f": 50331681
      },
      "n": "MyanmarExtendedB",
      "d": 1835065,
      "h": 2581277179961,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2581277179961),
//--TRIMMABLE-BOUNDARY-START(794570784825),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1163937972281,
        "f": 50331681
      },
      "n": "Cham",
      "d": 1835065,
      "h": 794570784825,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(794570784825),
//--TRIMMABLE-BOUNDARY-START(2576982212665),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1928442150969,
        "f": 50331681
      },
      "n": "MyanmarExtendedA",
      "d": 1835065,
      "h": 2576982212665,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2576982212665),
//--TRIMMABLE-BOUNDARY-START(2727306068025),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 2229089861689,
        "f": 50331681
      },
      "n": "TaiViet",
      "d": 1835065,
      "h": 2727306068025,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2727306068025),
//--TRIMMABLE-BOUNDARY-START(2538327507001),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1851132739641,
        "f": 50331681
      },
      "n": "MeeteiMayekExtensions",
      "d": 1835065,
      "h": 2538327507001,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2538327507001),
//--TRIMMABLE-BOUNDARY-START(940599672889),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1438815879225,
        "f": 50331681
      },
      "n": "EthiopicExtendedA",
      "d": 1835065,
      "h": 940599672889,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(940599672889),
//--TRIMMABLE-BOUNDARY-START(2499672801337),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1773823328313,
        "f": 50331681
      },
      "n": "LatinExtendedE",
      "d": 1835065,
      "h": 2499672801337,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2499672801337),
//--TRIMMABLE-BOUNDARY-START(803160719417),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1181117841465,
        "f": 50331681
      },
      "n": "CherokeeSupplement",
      "d": 1835065,
      "h": 803160719417,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(803160719417),
//--TRIMMABLE-BOUNDARY-START(2534032539705),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1842542805049,
        "f": 50331681
      },
      "n": "MeeteiMayek",
      "d": 1835065,
      "h": 2534032539705,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2534032539705),
//--TRIMMABLE-BOUNDARY-START(2405183520825),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1584844767289,
        "f": 50331681
      },
      "n": "HangulSyllables",
      "d": 1835065,
      "h": 2405183520825,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2405183520825),
//--TRIMMABLE-BOUNDARY-START(2400888553529),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1576254832697,
        "f": 50331681
      },
      "n": "HangulJamoExtendedB",
      "d": 1835065,
      "h": 2400888553529,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2400888553529),
//--TRIMMABLE-BOUNDARY-START(816045621305),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1206887645241,
        "f": 50331681
      },
      "n": "CjkCompatibilityIdeographs",
      "d": 1835065,
      "h": 816045621305,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(816045621305),
//--TRIMMABLE-BOUNDARY-START(704376471609),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 983549345849,
        "f": 50331681
      },
      "n": "AlphabeticPresentationForms",
      "d": 1835065,
      "h": 704376471609,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(704376471609),
//--TRIMMABLE-BOUNDARY-START(721556340793),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1017909084217,
        "f": 50331681
      },
      "n": "ArabicPresentationFormsA",
      "d": 1835065,
      "h": 721556340793,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(721556340793),
//--TRIMMABLE-BOUNDARY-START(2770255740985),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 2314989207609,
        "f": 50331681
      },
      "n": "VariationSelectors",
      "d": 1835065,
      "h": 2770255740985,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2770255740985),
//--TRIMMABLE-BOUNDARY-START(2778845675577),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 2332169076793,
        "f": 50331681
      },
      "n": "VerticalForms",
      "d": 1835065,
      "h": 2778845675577,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2778845675577),
//--TRIMMABLE-BOUNDARY-START(858995294265),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1292786991161,
        "f": 50331681
      },
      "n": "CombiningHalfMarks",
      "d": 1835065,
      "h": 858995294265,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(858995294265),
//--TRIMMABLE-BOUNDARY-START(811750654009),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1198297710649,
        "f": 50331681
      },
      "n": "CjkCompatibilityForms",
      "d": 1835065,
      "h": 811750654009,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(811750654009),
//--TRIMMABLE-BOUNDARY-START(2654291623993),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 2083060973625,
        "f": 50331681
      },
      "n": "SmallFormVariants",
      "d": 1835065,
      "h": 2654291623993,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2654291623993),
//--TRIMMABLE-BOUNDARY-START(725851308089),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1026499018809,
        "f": 50331681
      },
      "n": "ArabicPresentationFormsB",
      "d": 1835065,
      "h": 725851308089,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(725851308089),
//--TRIMMABLE-BOUNDARY-START(2383708684345),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1541895094329,
        "f": 50331681
      },
      "n": "HalfwidthandFullwidthForms",
      "d": 1835065,
      "h": 2383708684345,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2383708684345),
//--TRIMMABLE-BOUNDARY-START(2662881558585),
    {
      "p": 1769529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 2100240842809,
        "f": 50331681
      },
      "n": "Specials",
      "d": 1835065,
      "h": 2662881558585,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2662881558585)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(876175163449),
    {
      "r": 1769529,
      "p": [
        {
          "n": "range",
          "p": 1769529,
          "f": 4
        }
      ],
      "n": "CreateEmptyRange",
      "d": 1835065,
      "h": 876175163449,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(876175163449),
//--TRIMMABLE-BOUNDARY-START(880470130745),
    {
      "r": 1769529,
      "p": [
        {
          "n": "range",
          "p": 1769529,
          "f": 4
        },
        {
          "n": "first",
          "p": 458753
        },
        {
          "n": "last",
          "p": 458753
        }
      ],
      "n": "CreateRange",
      "d": 1835065,
      "h": 880470130745,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(880470130745)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591769657),
    {
      "t": 1769529,
      "n": "_none",
      "d": 1835065,
      "h": 8591769657,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(8591769657),
//--TRIMMABLE-BOUNDARY-START(4296802361),
    {
      "t": 1769529,
      "n": "_all",
      "d": 1835065,
      "h": 4296802361,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296802361),
//--TRIMMABLE-BOUNDARY-START(12886736953),
    {
      "t": 1769529,
      "n": "_u0000",
      "d": 1835065,
      "h": 12886736953,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12886736953),
//--TRIMMABLE-BOUNDARY-START(17181704249),
    {
      "t": 1769529,
      "n": "_u0080",
      "d": 1835065,
      "h": 17181704249,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(17181704249),
//--TRIMMABLE-BOUNDARY-START(21476671545),
    {
      "t": 1769529,
      "n": "_u0100",
      "d": 1835065,
      "h": 21476671545,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(21476671545),
//--TRIMMABLE-BOUNDARY-START(25771638841),
    {
      "t": 1769529,
      "n": "_u0180",
      "d": 1835065,
      "h": 25771638841,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(25771638841),
//--TRIMMABLE-BOUNDARY-START(30066606137),
    {
      "t": 1769529,
      "n": "_u0250",
      "d": 1835065,
      "h": 30066606137,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(30066606137),
//--TRIMMABLE-BOUNDARY-START(34361573433),
    {
      "t": 1769529,
      "n": "_u02B0",
      "d": 1835065,
      "h": 34361573433,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(34361573433),
//--TRIMMABLE-BOUNDARY-START(38656540729),
    {
      "t": 1769529,
      "n": "_u0300",
      "d": 1835065,
      "h": 38656540729,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(38656540729),
//--TRIMMABLE-BOUNDARY-START(42951508025),
    {
      "t": 1769529,
      "n": "_u0370",
      "d": 1835065,
      "h": 42951508025,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(42951508025),
//--TRIMMABLE-BOUNDARY-START(47246475321),
    {
      "t": 1769529,
      "n": "_u0400",
      "d": 1835065,
      "h": 47246475321,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(47246475321),
//--TRIMMABLE-BOUNDARY-START(51541442617),
    {
      "t": 1769529,
      "n": "_u0500",
      "d": 1835065,
      "h": 51541442617,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(51541442617),
//--TRIMMABLE-BOUNDARY-START(55836409913),
    {
      "t": 1769529,
      "n": "_u0530",
      "d": 1835065,
      "h": 55836409913,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(55836409913),
//--TRIMMABLE-BOUNDARY-START(60131377209),
    {
      "t": 1769529,
      "n": "_u0590",
      "d": 1835065,
      "h": 60131377209,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(60131377209),
//--TRIMMABLE-BOUNDARY-START(64426344505),
    {
      "t": 1769529,
      "n": "_u0600",
      "d": 1835065,
      "h": 64426344505,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(64426344505),
//--TRIMMABLE-BOUNDARY-START(68721311801),
    {
      "t": 1769529,
      "n": "_u0700",
      "d": 1835065,
      "h": 68721311801,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(68721311801),
//--TRIMMABLE-BOUNDARY-START(73016279097),
    {
      "t": 1769529,
      "n": "_u0750",
      "d": 1835065,
      "h": 73016279097,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(73016279097),
//--TRIMMABLE-BOUNDARY-START(77311246393),
    {
      "t": 1769529,
      "n": "_u0780",
      "d": 1835065,
      "h": 77311246393,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(77311246393),
//--TRIMMABLE-BOUNDARY-START(81606213689),
    {
      "t": 1769529,
      "n": "_u07C0",
      "d": 1835065,
      "h": 81606213689,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(81606213689),
//--TRIMMABLE-BOUNDARY-START(85901180985),
    {
      "t": 1769529,
      "n": "_u0800",
      "d": 1835065,
      "h": 85901180985,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(85901180985),
//--TRIMMABLE-BOUNDARY-START(90196148281),
    {
      "t": 1769529,
      "n": "_u0840",
      "d": 1835065,
      "h": 90196148281,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(90196148281),
//--TRIMMABLE-BOUNDARY-START(94491115577),
    {
      "t": 1769529,
      "n": "_u0860",
      "d": 1835065,
      "h": 94491115577,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(94491115577),
//--TRIMMABLE-BOUNDARY-START(98786082873),
    {
      "t": 1769529,
      "n": "_u0870",
      "d": 1835065,
      "h": 98786082873,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(98786082873),
//--TRIMMABLE-BOUNDARY-START(103081050169),
    {
      "t": 1769529,
      "n": "_u08A0",
      "d": 1835065,
      "h": 103081050169,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(103081050169),
//--TRIMMABLE-BOUNDARY-START(107376017465),
    {
      "t": 1769529,
      "n": "_u0900",
      "d": 1835065,
      "h": 107376017465,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(107376017465),
//--TRIMMABLE-BOUNDARY-START(111670984761),
    {
      "t": 1769529,
      "n": "_u0980",
      "d": 1835065,
      "h": 111670984761,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(111670984761),
//--TRIMMABLE-BOUNDARY-START(115965952057),
    {
      "t": 1769529,
      "n": "_u0A00",
      "d": 1835065,
      "h": 115965952057,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(115965952057),
//--TRIMMABLE-BOUNDARY-START(120260919353),
    {
      "t": 1769529,
      "n": "_u0A80",
      "d": 1835065,
      "h": 120260919353,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(120260919353),
//--TRIMMABLE-BOUNDARY-START(124555886649),
    {
      "t": 1769529,
      "n": "_u0B00",
      "d": 1835065,
      "h": 124555886649,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(124555886649),
//--TRIMMABLE-BOUNDARY-START(128850853945),
    {
      "t": 1769529,
      "n": "_u0B80",
      "d": 1835065,
      "h": 128850853945,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(128850853945),
//--TRIMMABLE-BOUNDARY-START(133145821241),
    {
      "t": 1769529,
      "n": "_u0C00",
      "d": 1835065,
      "h": 133145821241,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(133145821241),
//--TRIMMABLE-BOUNDARY-START(137440788537),
    {
      "t": 1769529,
      "n": "_u0C80",
      "d": 1835065,
      "h": 137440788537,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(137440788537),
//--TRIMMABLE-BOUNDARY-START(141735755833),
    {
      "t": 1769529,
      "n": "_u0D00",
      "d": 1835065,
      "h": 141735755833,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(141735755833),
//--TRIMMABLE-BOUNDARY-START(146030723129),
    {
      "t": 1769529,
      "n": "_u0D80",
      "d": 1835065,
      "h": 146030723129,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(146030723129),
//--TRIMMABLE-BOUNDARY-START(150325690425),
    {
      "t": 1769529,
      "n": "_u0E00",
      "d": 1835065,
      "h": 150325690425,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(150325690425),
//--TRIMMABLE-BOUNDARY-START(154620657721),
    {
      "t": 1769529,
      "n": "_u0E80",
      "d": 1835065,
      "h": 154620657721,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(154620657721),
//--TRIMMABLE-BOUNDARY-START(158915625017),
    {
      "t": 1769529,
      "n": "_u0F00",
      "d": 1835065,
      "h": 158915625017,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(158915625017),
//--TRIMMABLE-BOUNDARY-START(163210592313),
    {
      "t": 1769529,
      "n": "_u1000",
      "d": 1835065,
      "h": 163210592313,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(163210592313),
//--TRIMMABLE-BOUNDARY-START(167505559609),
    {
      "t": 1769529,
      "n": "_u10A0",
      "d": 1835065,
      "h": 167505559609,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(167505559609),
//--TRIMMABLE-BOUNDARY-START(171800526905),
    {
      "t": 1769529,
      "n": "_u1100",
      "d": 1835065,
      "h": 171800526905,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(171800526905),
//--TRIMMABLE-BOUNDARY-START(176095494201),
    {
      "t": 1769529,
      "n": "_u1200",
      "d": 1835065,
      "h": 176095494201,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(176095494201),
//--TRIMMABLE-BOUNDARY-START(180390461497),
    {
      "t": 1769529,
      "n": "_u1380",
      "d": 1835065,
      "h": 180390461497,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(180390461497),
//--TRIMMABLE-BOUNDARY-START(184685428793),
    {
      "t": 1769529,
      "n": "_u13A0",
      "d": 1835065,
      "h": 184685428793,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(184685428793),
//--TRIMMABLE-BOUNDARY-START(188980396089),
    {
      "t": 1769529,
      "n": "_u1400",
      "d": 1835065,
      "h": 188980396089,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(188980396089),
//--TRIMMABLE-BOUNDARY-START(193275363385),
    {
      "t": 1769529,
      "n": "_u1680",
      "d": 1835065,
      "h": 193275363385,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(193275363385),
//--TRIMMABLE-BOUNDARY-START(197570330681),
    {
      "t": 1769529,
      "n": "_u16A0",
      "d": 1835065,
      "h": 197570330681,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(197570330681),
//--TRIMMABLE-BOUNDARY-START(201865297977),
    {
      "t": 1769529,
      "n": "_u1700",
      "d": 1835065,
      "h": 201865297977,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(201865297977),
//--TRIMMABLE-BOUNDARY-START(206160265273),
    {
      "t": 1769529,
      "n": "_u1720",
      "d": 1835065,
      "h": 206160265273,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(206160265273),
//--TRIMMABLE-BOUNDARY-START(210455232569),
    {
      "t": 1769529,
      "n": "_u1740",
      "d": 1835065,
      "h": 210455232569,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(210455232569),
//--TRIMMABLE-BOUNDARY-START(214750199865),
    {
      "t": 1769529,
      "n": "_u1760",
      "d": 1835065,
      "h": 214750199865,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(214750199865),
//--TRIMMABLE-BOUNDARY-START(219045167161),
    {
      "t": 1769529,
      "n": "_u1780",
      "d": 1835065,
      "h": 219045167161,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(219045167161),
//--TRIMMABLE-BOUNDARY-START(223340134457),
    {
      "t": 1769529,
      "n": "_u1800",
      "d": 1835065,
      "h": 223340134457,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(223340134457),
//--TRIMMABLE-BOUNDARY-START(227635101753),
    {
      "t": 1769529,
      "n": "_u18B0",
      "d": 1835065,
      "h": 227635101753,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(227635101753),
//--TRIMMABLE-BOUNDARY-START(231930069049),
    {
      "t": 1769529,
      "n": "_u1900",
      "d": 1835065,
      "h": 231930069049,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(231930069049),
//--TRIMMABLE-BOUNDARY-START(236225036345),
    {
      "t": 1769529,
      "n": "_u1950",
      "d": 1835065,
      "h": 236225036345,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(236225036345),
//--TRIMMABLE-BOUNDARY-START(240520003641),
    {
      "t": 1769529,
      "n": "_u1980",
      "d": 1835065,
      "h": 240520003641,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(240520003641),
//--TRIMMABLE-BOUNDARY-START(244814970937),
    {
      "t": 1769529,
      "n": "_u19E0",
      "d": 1835065,
      "h": 244814970937,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(244814970937),
//--TRIMMABLE-BOUNDARY-START(249109938233),
    {
      "t": 1769529,
      "n": "_u1A00",
      "d": 1835065,
      "h": 249109938233,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(249109938233),
//--TRIMMABLE-BOUNDARY-START(253404905529),
    {
      "t": 1769529,
      "n": "_u1A20",
      "d": 1835065,
      "h": 253404905529,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(253404905529),
//--TRIMMABLE-BOUNDARY-START(257699872825),
    {
      "t": 1769529,
      "n": "_u1AB0",
      "d": 1835065,
      "h": 257699872825,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(257699872825),
//--TRIMMABLE-BOUNDARY-START(261994840121),
    {
      "t": 1769529,
      "n": "_u1B00",
      "d": 1835065,
      "h": 261994840121,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(261994840121),
//--TRIMMABLE-BOUNDARY-START(266289807417),
    {
      "t": 1769529,
      "n": "_u1B80",
      "d": 1835065,
      "h": 266289807417,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(266289807417),
//--TRIMMABLE-BOUNDARY-START(270584774713),
    {
      "t": 1769529,
      "n": "_u1BC0",
      "d": 1835065,
      "h": 270584774713,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(270584774713),
//--TRIMMABLE-BOUNDARY-START(274879742009),
    {
      "t": 1769529,
      "n": "_u1C00",
      "d": 1835065,
      "h": 274879742009,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(274879742009),
//--TRIMMABLE-BOUNDARY-START(279174709305),
    {
      "t": 1769529,
      "n": "_u1C50",
      "d": 1835065,
      "h": 279174709305,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(279174709305),
//--TRIMMABLE-BOUNDARY-START(283469676601),
    {
      "t": 1769529,
      "n": "_u1C80",
      "d": 1835065,
      "h": 283469676601,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(283469676601),
//--TRIMMABLE-BOUNDARY-START(287764643897),
    {
      "t": 1769529,
      "n": "_u1C90",
      "d": 1835065,
      "h": 287764643897,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(287764643897),
//--TRIMMABLE-BOUNDARY-START(292059611193),
    {
      "t": 1769529,
      "n": "_u1CC0",
      "d": 1835065,
      "h": 292059611193,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(292059611193),
//--TRIMMABLE-BOUNDARY-START(296354578489),
    {
      "t": 1769529,
      "n": "_u1CD0",
      "d": 1835065,
      "h": 296354578489,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(296354578489),
//--TRIMMABLE-BOUNDARY-START(300649545785),
    {
      "t": 1769529,
      "n": "_u1D00",
      "d": 1835065,
      "h": 300649545785,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(300649545785),
//--TRIMMABLE-BOUNDARY-START(304944513081),
    {
      "t": 1769529,
      "n": "_u1D80",
      "d": 1835065,
      "h": 304944513081,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(304944513081),
//--TRIMMABLE-BOUNDARY-START(309239480377),
    {
      "t": 1769529,
      "n": "_u1DC0",
      "d": 1835065,
      "h": 309239480377,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(309239480377),
//--TRIMMABLE-BOUNDARY-START(313534447673),
    {
      "t": 1769529,
      "n": "_u1E00",
      "d": 1835065,
      "h": 313534447673,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(313534447673),
//--TRIMMABLE-BOUNDARY-START(317829414969),
    {
      "t": 1769529,
      "n": "_u1F00",
      "d": 1835065,
      "h": 317829414969,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(317829414969),
//--TRIMMABLE-BOUNDARY-START(322124382265),
    {
      "t": 1769529,
      "n": "_u2000",
      "d": 1835065,
      "h": 322124382265,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(322124382265),
//--TRIMMABLE-BOUNDARY-START(326419349561),
    {
      "t": 1769529,
      "n": "_u2070",
      "d": 1835065,
      "h": 326419349561,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(326419349561),
//--TRIMMABLE-BOUNDARY-START(330714316857),
    {
      "t": 1769529,
      "n": "_u20A0",
      "d": 1835065,
      "h": 330714316857,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(330714316857),
//--TRIMMABLE-BOUNDARY-START(335009284153),
    {
      "t": 1769529,
      "n": "_u20D0",
      "d": 1835065,
      "h": 335009284153,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(335009284153),
//--TRIMMABLE-BOUNDARY-START(339304251449),
    {
      "t": 1769529,
      "n": "_u2100",
      "d": 1835065,
      "h": 339304251449,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(339304251449),
//--TRIMMABLE-BOUNDARY-START(343599218745),
    {
      "t": 1769529,
      "n": "_u2150",
      "d": 1835065,
      "h": 343599218745,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(343599218745),
//--TRIMMABLE-BOUNDARY-START(347894186041),
    {
      "t": 1769529,
      "n": "_u2190",
      "d": 1835065,
      "h": 347894186041,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(347894186041),
//--TRIMMABLE-BOUNDARY-START(352189153337),
    {
      "t": 1769529,
      "n": "_u2200",
      "d": 1835065,
      "h": 352189153337,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(352189153337),
//--TRIMMABLE-BOUNDARY-START(356484120633),
    {
      "t": 1769529,
      "n": "_u2300",
      "d": 1835065,
      "h": 356484120633,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(356484120633),
//--TRIMMABLE-BOUNDARY-START(360779087929),
    {
      "t": 1769529,
      "n": "_u2400",
      "d": 1835065,
      "h": 360779087929,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(360779087929),
//--TRIMMABLE-BOUNDARY-START(365074055225),
    {
      "t": 1769529,
      "n": "_u2440",
      "d": 1835065,
      "h": 365074055225,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(365074055225),
//--TRIMMABLE-BOUNDARY-START(369369022521),
    {
      "t": 1769529,
      "n": "_u2460",
      "d": 1835065,
      "h": 369369022521,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(369369022521),
//--TRIMMABLE-BOUNDARY-START(373663989817),
    {
      "t": 1769529,
      "n": "_u2500",
      "d": 1835065,
      "h": 373663989817,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(373663989817),
//--TRIMMABLE-BOUNDARY-START(377958957113),
    {
      "t": 1769529,
      "n": "_u2580",
      "d": 1835065,
      "h": 377958957113,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(377958957113),
//--TRIMMABLE-BOUNDARY-START(382253924409),
    {
      "t": 1769529,
      "n": "_u25A0",
      "d": 1835065,
      "h": 382253924409,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(382253924409),
//--TRIMMABLE-BOUNDARY-START(386548891705),
    {
      "t": 1769529,
      "n": "_u2600",
      "d": 1835065,
      "h": 386548891705,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(386548891705),
//--TRIMMABLE-BOUNDARY-START(390843859001),
    {
      "t": 1769529,
      "n": "_u2700",
      "d": 1835065,
      "h": 390843859001,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(390843859001),
//--TRIMMABLE-BOUNDARY-START(395138826297),
    {
      "t": 1769529,
      "n": "_u27C0",
      "d": 1835065,
      "h": 395138826297,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(395138826297),
//--TRIMMABLE-BOUNDARY-START(399433793593),
    {
      "t": 1769529,
      "n": "_u27F0",
      "d": 1835065,
      "h": 399433793593,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(399433793593),
//--TRIMMABLE-BOUNDARY-START(403728760889),
    {
      "t": 1769529,
      "n": "_u2800",
      "d": 1835065,
      "h": 403728760889,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(403728760889),
//--TRIMMABLE-BOUNDARY-START(408023728185),
    {
      "t": 1769529,
      "n": "_u2900",
      "d": 1835065,
      "h": 408023728185,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(408023728185),
//--TRIMMABLE-BOUNDARY-START(412318695481),
    {
      "t": 1769529,
      "n": "_u2980",
      "d": 1835065,
      "h": 412318695481,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(412318695481),
//--TRIMMABLE-BOUNDARY-START(416613662777),
    {
      "t": 1769529,
      "n": "_u2A00",
      "d": 1835065,
      "h": 416613662777,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(416613662777),
//--TRIMMABLE-BOUNDARY-START(420908630073),
    {
      "t": 1769529,
      "n": "_u2B00",
      "d": 1835065,
      "h": 420908630073,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(420908630073),
//--TRIMMABLE-BOUNDARY-START(425203597369),
    {
      "t": 1769529,
      "n": "_u2C00",
      "d": 1835065,
      "h": 425203597369,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(425203597369),
//--TRIMMABLE-BOUNDARY-START(429498564665),
    {
      "t": 1769529,
      "n": "_u2C60",
      "d": 1835065,
      "h": 429498564665,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(429498564665),
//--TRIMMABLE-BOUNDARY-START(433793531961),
    {
      "t": 1769529,
      "n": "_u2C80",
      "d": 1835065,
      "h": 433793531961,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(433793531961),
//--TRIMMABLE-BOUNDARY-START(438088499257),
    {
      "t": 1769529,
      "n": "_u2D00",
      "d": 1835065,
      "h": 438088499257,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(438088499257),
//--TRIMMABLE-BOUNDARY-START(442383466553),
    {
      "t": 1769529,
      "n": "_u2D30",
      "d": 1835065,
      "h": 442383466553,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(442383466553),
//--TRIMMABLE-BOUNDARY-START(446678433849),
    {
      "t": 1769529,
      "n": "_u2D80",
      "d": 1835065,
      "h": 446678433849,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(446678433849),
//--TRIMMABLE-BOUNDARY-START(450973401145),
    {
      "t": 1769529,
      "n": "_u2DE0",
      "d": 1835065,
      "h": 450973401145,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(450973401145),
//--TRIMMABLE-BOUNDARY-START(455268368441),
    {
      "t": 1769529,
      "n": "_u2E00",
      "d": 1835065,
      "h": 455268368441,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(455268368441),
//--TRIMMABLE-BOUNDARY-START(459563335737),
    {
      "t": 1769529,
      "n": "_u2E80",
      "d": 1835065,
      "h": 459563335737,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(459563335737),
//--TRIMMABLE-BOUNDARY-START(463858303033),
    {
      "t": 1769529,
      "n": "_u2F00",
      "d": 1835065,
      "h": 463858303033,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(463858303033),
//--TRIMMABLE-BOUNDARY-START(468153270329),
    {
      "t": 1769529,
      "n": "_u2FF0",
      "d": 1835065,
      "h": 468153270329,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(468153270329),
//--TRIMMABLE-BOUNDARY-START(472448237625),
    {
      "t": 1769529,
      "n": "_u3000",
      "d": 1835065,
      "h": 472448237625,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(472448237625),
//--TRIMMABLE-BOUNDARY-START(476743204921),
    {
      "t": 1769529,
      "n": "_u3040",
      "d": 1835065,
      "h": 476743204921,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(476743204921),
//--TRIMMABLE-BOUNDARY-START(481038172217),
    {
      "t": 1769529,
      "n": "_u30A0",
      "d": 1835065,
      "h": 481038172217,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(481038172217),
//--TRIMMABLE-BOUNDARY-START(485333139513),
    {
      "t": 1769529,
      "n": "_u3100",
      "d": 1835065,
      "h": 485333139513,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(485333139513),
//--TRIMMABLE-BOUNDARY-START(489628106809),
    {
      "t": 1769529,
      "n": "_u3130",
      "d": 1835065,
      "h": 489628106809,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(489628106809),
//--TRIMMABLE-BOUNDARY-START(493923074105),
    {
      "t": 1769529,
      "n": "_u3190",
      "d": 1835065,
      "h": 493923074105,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(493923074105),
//--TRIMMABLE-BOUNDARY-START(498218041401),
    {
      "t": 1769529,
      "n": "_u31A0",
      "d": 1835065,
      "h": 498218041401,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(498218041401),
//--TRIMMABLE-BOUNDARY-START(502513008697),
    {
      "t": 1769529,
      "n": "_u31C0",
      "d": 1835065,
      "h": 502513008697,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(502513008697),
//--TRIMMABLE-BOUNDARY-START(506807975993),
    {
      "t": 1769529,
      "n": "_u31F0",
      "d": 1835065,
      "h": 506807975993,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(506807975993),
//--TRIMMABLE-BOUNDARY-START(511102943289),
    {
      "t": 1769529,
      "n": "_u3200",
      "d": 1835065,
      "h": 511102943289,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(511102943289),
//--TRIMMABLE-BOUNDARY-START(515397910585),
    {
      "t": 1769529,
      "n": "_u3300",
      "d": 1835065,
      "h": 515397910585,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(515397910585),
//--TRIMMABLE-BOUNDARY-START(519692877881),
    {
      "t": 1769529,
      "n": "_u3400",
      "d": 1835065,
      "h": 519692877881,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(519692877881),
//--TRIMMABLE-BOUNDARY-START(523987845177),
    {
      "t": 1769529,
      "n": "_u4DC0",
      "d": 1835065,
      "h": 523987845177,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(523987845177),
//--TRIMMABLE-BOUNDARY-START(528282812473),
    {
      "t": 1769529,
      "n": "_u4E00",
      "d": 1835065,
      "h": 528282812473,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(528282812473),
//--TRIMMABLE-BOUNDARY-START(532577779769),
    {
      "t": 1769529,
      "n": "_uA000",
      "d": 1835065,
      "h": 532577779769,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(532577779769),
//--TRIMMABLE-BOUNDARY-START(536872747065),
    {
      "t": 1769529,
      "n": "_uA490",
      "d": 1835065,
      "h": 536872747065,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(536872747065),
//--TRIMMABLE-BOUNDARY-START(541167714361),
    {
      "t": 1769529,
      "n": "_uA4D0",
      "d": 1835065,
      "h": 541167714361,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(541167714361),
//--TRIMMABLE-BOUNDARY-START(545462681657),
    {
      "t": 1769529,
      "n": "_uA500",
      "d": 1835065,
      "h": 545462681657,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(545462681657),
//--TRIMMABLE-BOUNDARY-START(549757648953),
    {
      "t": 1769529,
      "n": "_uA640",
      "d": 1835065,
      "h": 549757648953,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(549757648953),
//--TRIMMABLE-BOUNDARY-START(554052616249),
    {
      "t": 1769529,
      "n": "_uA6A0",
      "d": 1835065,
      "h": 554052616249,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(554052616249),
//--TRIMMABLE-BOUNDARY-START(558347583545),
    {
      "t": 1769529,
      "n": "_uA700",
      "d": 1835065,
      "h": 558347583545,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(558347583545),
//--TRIMMABLE-BOUNDARY-START(562642550841),
    {
      "t": 1769529,
      "n": "_uA720",
      "d": 1835065,
      "h": 562642550841,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(562642550841),
//--TRIMMABLE-BOUNDARY-START(566937518137),
    {
      "t": 1769529,
      "n": "_uA800",
      "d": 1835065,
      "h": 566937518137,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(566937518137),
//--TRIMMABLE-BOUNDARY-START(571232485433),
    {
      "t": 1769529,
      "n": "_uA830",
      "d": 1835065,
      "h": 571232485433,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(571232485433),
//--TRIMMABLE-BOUNDARY-START(575527452729),
    {
      "t": 1769529,
      "n": "_uA840",
      "d": 1835065,
      "h": 575527452729,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(575527452729),
//--TRIMMABLE-BOUNDARY-START(579822420025),
    {
      "t": 1769529,
      "n": "_uA880",
      "d": 1835065,
      "h": 579822420025,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(579822420025),
//--TRIMMABLE-BOUNDARY-START(584117387321),
    {
      "t": 1769529,
      "n": "_uA8E0",
      "d": 1835065,
      "h": 584117387321,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(584117387321),
//--TRIMMABLE-BOUNDARY-START(588412354617),
    {
      "t": 1769529,
      "n": "_uA900",
      "d": 1835065,
      "h": 588412354617,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(588412354617),
//--TRIMMABLE-BOUNDARY-START(592707321913),
    {
      "t": 1769529,
      "n": "_uA930",
      "d": 1835065,
      "h": 592707321913,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(592707321913),
//--TRIMMABLE-BOUNDARY-START(597002289209),
    {
      "t": 1769529,
      "n": "_uA960",
      "d": 1835065,
      "h": 597002289209,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(597002289209),
//--TRIMMABLE-BOUNDARY-START(601297256505),
    {
      "t": 1769529,
      "n": "_uA980",
      "d": 1835065,
      "h": 601297256505,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(601297256505),
//--TRIMMABLE-BOUNDARY-START(605592223801),
    {
      "t": 1769529,
      "n": "_uA9E0",
      "d": 1835065,
      "h": 605592223801,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(605592223801),
//--TRIMMABLE-BOUNDARY-START(609887191097),
    {
      "t": 1769529,
      "n": "_uAA00",
      "d": 1835065,
      "h": 609887191097,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(609887191097),
//--TRIMMABLE-BOUNDARY-START(614182158393),
    {
      "t": 1769529,
      "n": "_uAA60",
      "d": 1835065,
      "h": 614182158393,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(614182158393),
//--TRIMMABLE-BOUNDARY-START(618477125689),
    {
      "t": 1769529,
      "n": "_uAA80",
      "d": 1835065,
      "h": 618477125689,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(618477125689),
//--TRIMMABLE-BOUNDARY-START(622772092985),
    {
      "t": 1769529,
      "n": "_uAAE0",
      "d": 1835065,
      "h": 622772092985,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(622772092985),
//--TRIMMABLE-BOUNDARY-START(627067060281),
    {
      "t": 1769529,
      "n": "_uAB00",
      "d": 1835065,
      "h": 627067060281,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(627067060281),
//--TRIMMABLE-BOUNDARY-START(631362027577),
    {
      "t": 1769529,
      "n": "_uAB30",
      "d": 1835065,
      "h": 631362027577,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(631362027577),
//--TRIMMABLE-BOUNDARY-START(635656994873),
    {
      "t": 1769529,
      "n": "_uAB70",
      "d": 1835065,
      "h": 635656994873,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(635656994873),
//--TRIMMABLE-BOUNDARY-START(639951962169),
    {
      "t": 1769529,
      "n": "_uABC0",
      "d": 1835065,
      "h": 639951962169,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(639951962169),
//--TRIMMABLE-BOUNDARY-START(644246929465),
    {
      "t": 1769529,
      "n": "_uAC00",
      "d": 1835065,
      "h": 644246929465,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(644246929465),
//--TRIMMABLE-BOUNDARY-START(648541896761),
    {
      "t": 1769529,
      "n": "_uD7B0",
      "d": 1835065,
      "h": 648541896761,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(648541896761),
//--TRIMMABLE-BOUNDARY-START(652836864057),
    {
      "t": 1769529,
      "n": "_uF900",
      "d": 1835065,
      "h": 652836864057,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(652836864057),
//--TRIMMABLE-BOUNDARY-START(657131831353),
    {
      "t": 1769529,
      "n": "_uFB00",
      "d": 1835065,
      "h": 657131831353,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(657131831353),
//--TRIMMABLE-BOUNDARY-START(661426798649),
    {
      "t": 1769529,
      "n": "_uFB50",
      "d": 1835065,
      "h": 661426798649,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(661426798649),
//--TRIMMABLE-BOUNDARY-START(665721765945),
    {
      "t": 1769529,
      "n": "_uFE00",
      "d": 1835065,
      "h": 665721765945,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(665721765945),
//--TRIMMABLE-BOUNDARY-START(670016733241),
    {
      "t": 1769529,
      "n": "_uFE10",
      "d": 1835065,
      "h": 670016733241,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(670016733241),
//--TRIMMABLE-BOUNDARY-START(674311700537),
    {
      "t": 1769529,
      "n": "_uFE20",
      "d": 1835065,
      "h": 674311700537,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(674311700537),
//--TRIMMABLE-BOUNDARY-START(678606667833),
    {
      "t": 1769529,
      "n": "_uFE30",
      "d": 1835065,
      "h": 678606667833,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(678606667833),
//--TRIMMABLE-BOUNDARY-START(682901635129),
    {
      "t": 1769529,
      "n": "_uFE50",
      "d": 1835065,
      "h": 682901635129,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(682901635129),
//--TRIMMABLE-BOUNDARY-START(687196602425),
    {
      "t": 1769529,
      "n": "_uFE70",
      "d": 1835065,
      "h": 687196602425,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(687196602425),
//--TRIMMABLE-BOUNDARY-START(691491569721),
    {
      "t": 1769529,
      "n": "_uFF00",
      "d": 1835065,
      "h": 691491569721,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(691491569721),
//--TRIMMABLE-BOUNDARY-START(695786537017),
    {
      "t": 1769529,
      "n": "_uFFF0",
      "d": 1835065,
      "h": 695786537017,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(695786537017)
  ],
  "h": 1835065
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Text.Unicode.UnicodeRanges`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Text${separator}Unicode${separator}UnicodeRanges`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1835065)
        
        

        //--TRIMMABLE-BOUNDARY-START(1245241)
        $asm.$cls(`$stew.STEW.OptimizedInboxTextEncoder`, ($self) => class OptimizedInboxTextEncoder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(1310777)
            static $_AsciiPreescapedData;
            static get AsciiPreescapedData()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1310777);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$stew.STEW.OptimizedInboxTextEncoder;
                return $cls.$_AsciiPreescapedData ??= $asm.$nstr(`$stew.STEW.OptimizedInboxTextEncoder.AsciiPreescapedData`, ($self) => class AsciiPreescapedData extends $.$$.S.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(8591245369)
                    /*ulong[128]*/ Data = [];
                    //--TRIMMABLE-BOUNDARY-END(8591245369)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886212665)
                    /*void */ PopulatePreescapedData(/*in AllowedBmpCodePointsBitmap*/ allowedCodePointsBmp, /*ScalarEscaperBase*/ innerEncoder)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12886212665);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        new $.$stew.STEW.OptimizedInboxTextEncoder.AsciiPreescapedData().$clone(this);
                        /*Span<char>*/ let tempBuffer = $.$$.SRC.RuntimeHelpers.StackAllocSpan($.$$.S.Char, 8, [/*\u0000*/ 0, /*\u0000*/ 0, /*\u0000*/ 0, /*\u0000*/ 0, /*\u0000*/ 0, /*\u0000*/ 0, /*\u0000*/ 0, /*\u0000*/ 0]);
                        for(/*int*/ let i = 0; i < 128; i++)
                        {
                            /*ulong*/ let thisPreescapedData;
                            /*int*/ let encodedCharCount;
                            /*Rune*/ let rune = new $.$$.ST.Rune().$ctor$5(i);
                            if (!$.$$.ST.Rune.IsControl(rune) && allowedCodePointsBmp.$v.IsCharAllowed($.$cast(i, $.$$.S.Char)))
                            {
                                thisPreescapedData = BigInt((i >>> 0));
                                encodedCharCount = 1;
                            }
                            else 
                            {
                                encodedCharCount = innerEncoder.EncodeUtf16(rune, tempBuffer.Slice(0, 6));
                                $.$$.SD.Debug.Assert$4(encodedCharCount > 0 && encodedCharCount <= 6, "Inner encoder returned bad length.");
                                thisPreescapedData = 0n;
                                tempBuffer.Slice$1(encodedCharCount).Clear();
                                for(/*int*/ let j = ((encodedCharCount - 1) | 0); j >= 0; j--)
                                {
                                    /*uint*/ let thisChar = tempBuffer._reference.GetAt(j);
                                    $.$$.SD.Debug.Assert$4(thisChar <= 127, "Inner encoder returned non-ASCII data.");
                                    thisPreescapedData = (BigInt.asUintN(64, thisPreescapedData << 8n)) | BigInt(thisChar);
                                }
                            }
                            this.Data[i] = thisPreescapedData | (BigInt.asUintN(64, $.$cast((encodedCharCount >>> 0), $.$$.S.UInt64) << 56n));
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(12886212665)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181179961)
                    /*bool */ TryGetPreescapedData(/*uint*/ codePoint, /*out ulong*/ preescapedData)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17181179961);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (codePoint <= 127)
                        {
                            preescapedData.$v = this.Data[codePoint];
                            return true;
                        }
                        else 
                        {
                            preescapedData.$v = 0n;
                            return false;
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(17181179961)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296278073)
                    //default constructor overload
                    $ctor$2()
                    {
                        super.$ctor$1();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4296278073);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296278073)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296278073)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296278073)
                    
                    $clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        //FixedSizeArray(ulong, 128)
                        copy.Data = [...this.Data];
                        $.$$.S.Array.CopyMetadata(copy.Data, this.Data)
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(8591245369)
                        //FixedSizeArray(ulong*, 128)
                        let $t1 = this.Data;
                        $.$$.S.Array.AddMetadata($t1, $.$$.S.UInt64.$type, null, null);
                        for (let $i = 0; $i < 128; $i++)
                        {
                            $t1[$i] = [];
                        }
                        //--TRIMMABLE-BOUNDARY-END(8591245369)
                        
                    }
                    static $h = 1310777;
                    static $z = 1024;
                    static $f = 0b10000010000001010000000;
                    static $k = 2;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.ValueType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886212665),
    {
      "r": 65537,
      "p": [
        {
          "n": "allowedCodePointsBmp",
          "p": 524345,
          "f": 8
        },
        {
          "n": "innerEncoder",
          "p": 1376313
        }
      ],
      "n": "PopulatePreescapedData",
      "d": 1310777,
      "h": 12886212665,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(12886212665),
//--TRIMMABLE-BOUNDARY-START(17181179961),
    {
      "r": 262145,
      "p": [
        {
          "n": "codePoint",
          "p": 720897
        },
        {
          "n": "preescapedData",
          "p": 983041,
          "f": 2
        }
      ],
      "n": "TryGetPreescapedData",
      "d": 1310777,
      "h": 17181179961,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(17181179961)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591245369),
    {
      "t": $.$typePointer($.$$.S.UInt64).$h,
      "n": "Data",
      "d": 1310777,
      "h": 8591245369,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591245369)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296278073),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1310777,
      "h": 4296278073,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296278073)
  ],
  "d": 1245241,
  "h": 1310777
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Text.Encodings.Web.OptimizedInboxTextEncoder+AsciiPreescapedData`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Text${separator}Encodings${separator}Web${separator}OptimizedInboxTextEncoder${separator}AsciiPreescapedData`; }
                }, $cls, ($v) => $cls.$_AsciiPreescapedData = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1310777)
            
            //--TRIMMABLE-BOUNDARY-START(17181114425)
            /*AsciiPreescapedData*/ _asciiPreescapedData;
            //--TRIMMABLE-BOUNDARY-END(17181114425)
            
            //--TRIMMABLE-BOUNDARY-START(12886147129)
            /*AllowedBmpCodePointsBitmap*/ _allowedBmpCodePoints;
            //--TRIMMABLE-BOUNDARY-END(12886147129)
            
            //--TRIMMABLE-BOUNDARY-START(25771049017)
            /*ScalarEscaperBase*/ _scalarEscaper = null;
            //--TRIMMABLE-BOUNDARY-END(25771049017)
            
            //--TRIMMABLE-BOUNDARY-START(4296212537)
            /*SearchValues<byte>*/ _allowedAsciiBytes = null;
            //--TRIMMABLE-BOUNDARY-END(4296212537)
            
            //--TRIMMABLE-BOUNDARY-START(8591179833)
            /*SearchValues<char>*/ _allowedAsciiChars = null;
            //--TRIMMABLE-BOUNDARY-END(8591179833)
            
            //--TRIMMABLE-BOUNDARY-START(30066016313)
            $ctor$1(/*ScalarEscaperBase*/ scalarEscaper, /*in AllowedBmpCodePointsBitmap*/ allowedCodePointsBmp, /*bool*/ forbidHtmlSensitiveCharacters, /*ReadOnlySpan<char>*/ extraCharactersToEscape)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30066016313);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.SD.Debug.Assert$4(scalarEscaper !== null, "scalarEscaper != null");
                    this._scalarEscaper = scalarEscaper;
                    this._allowedBmpCodePoints = $.$clone(allowedCodePointsBmp.$v);
                    allowedCodePointsBmp = $.$$.SRC.Unsafe.NullRef($.$stew.STEW.AllowedBmpCodePointsBitmap);
                    this._allowedBmpCodePoints.ForbidUndefinedCharacters();
                    if (forbidHtmlSensitiveCharacters)
                    {
                        this._allowedBmpCodePoints.ForbidHtmlCharacters();
                    }
                    let $en2 = extraCharactersToEscape.GetEnumerator();
                    while ($en2.MoveNext())
                    {
                        let ch = $en2.Current.$v;
                        {
                            this._allowedBmpCodePoints.ForbidChar(ch);
                        }
                    }
                    this._asciiPreescapedData.PopulatePreescapedData($.$ref(() => this._allowedBmpCodePoints, ), scalarEscaper);
                    /*Span<byte>*/ let allowedAsciiBytes = $.$$.SRC.RuntimeHelpers.StackAllocSpan($.$$.S.Byte, 128, null);
                    /*Span<char>*/ let allowedAsciiChars = $.$$.SRC.RuntimeHelpers.StackAllocSpan($.$$.S.Char, 128, null);
                    /*int*/ let allowedAsciiCount = 0;
                    for(/*int*/ let i = 0; i < 128; i++)
                    {
                        if (this._allowedBmpCodePoints.IsCharAllowed($.$cast(i, $.$$.S.Char)))
                        {
                            allowedAsciiBytes._reference.SetAt($.$cast(i, $.$$.S.Byte), allowedAsciiCount);
                            allowedAsciiChars._reference.SetAt($.$cast(i, $.$$.S.Char), allowedAsciiCount);
                            allowedAsciiCount++;
                        }
                    }
                    this._allowedAsciiBytes = $.$$.SB.SearchValues.Create($.$$.S.Span$$($.$$.S.Byte).op_Implicit(allowedAsciiBytes.Slice(0, allowedAsciiCount)));
                    this._allowedAsciiChars = $.$$.SB.SearchValues.Create$1($.$$.S.Span$$($.$$.S.Char).op_Implicit(allowedAsciiChars.Slice(0, allowedAsciiCount)));
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30066016313)
            
            //--TRIMMABLE-BOUNDARY-START(42950918201)
            /*int */ FindFirstCharacterToEncode(/*char**/ text, /*int*/ textLength)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950918201);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetIndexOfFirstCharToEncode(new ($.$$.S.ReadOnlySpan$$($.$$.S.Char))().$ctor$4(text, textLength));
            }
            //--TRIMMABLE-BOUNDARY-END(42950918201)
            
            //--TRIMMABLE-BOUNDARY-START(60130787385)
            /*bool */ TryEncodeUnicodeScalar(/*int*/ unicodeScalar, /*char**/ buffer, /*int*/ bufferLength, /*out int*/ numberOfCharactersWritten)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130787385);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Span<char>*/ let destination = new ($.$$.S.Span$$($.$$.S.Char))().$ctor$5(buffer, bufferLength);
                if (this._allowedBmpCodePoints.IsCodePointAllowed((unicodeScalar >>> 0)))
                {
                    $.$stew.ST.UnicodeDebug.AssertIsBmpCodePoint((unicodeScalar >>> 0));
                    $.$stew.ST.UnicodeDebug.AssertIsValidScalar((unicodeScalar >>> 0));
                    if (!destination.IsEmpty)
                    {
                        destination._reference.SetAt($.$cast(unicodeScalar, $.$$.S.Char), 0);
                        numberOfCharactersWritten.$v = 1;
                        return true;
                    }
                }
                else 
                {
                    /*int*/ let innerCharsWritten = this._scalarEscaper.EncodeUtf16(new $.$$.ST.Rune().$ctor$5(unicodeScalar), destination);
                    $.$$.SD.Debug.Assert$4(innerCharsWritten <= bufferLength, "Mustn't overflow the buffer.");
                    $.$$.SD.Debug.Assert$4(innerCharsWritten !== 0, "Inner escaper succeeded with 0-char output?");
                    if (innerCharsWritten >= 0)
                    {
                        numberOfCharactersWritten.$v = innerCharsWritten;
                        return true;
                    }
                }
                numberOfCharactersWritten.$v = 0;
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(60130787385)
            
            //--TRIMMABLE-BOUNDARY-START(34360983609)
            /*OperationStatus */ Encode(/*ReadOnlySpan<char>*/ source, /*Span<char>*/ destination, /*out int*/ charsConsumed, /*out int*/ charsWritten, /*bool*/ isFinalBlock)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360983609);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let srcIdx;
                /*int*/ let dstIdx;
                /*OperationStatus*/ let retVal;
                let $gotoJumpState3 = 0;
                $gotoJumpStart3: while(true)
                {
                    switch($gotoJumpState3)
                    {
                        case 0:
                        {
                            this._AssertThisNotNull();
                            srcIdx = 0;
                            dstIdx = 0;
                            $whileJumpStart4: while(true)
                            {
                                /*char*/ let thisChar;
                                /*int*/ let dstIdxTemp;
                                /*int*/ let charsWrittenJustNow;
                                let $gotoJumpState5 = 0;
                                $gotoJumpStart5: while(true)
                                {
                                    /*Rune*/ var scalarValue;
                                    switch($gotoJumpState5)
                                    {
                                        case 0:
                                        {
                                            /*ulong*/ var preescapedEntry;
                                            if ((source.Length >>> 0) <= (srcIdx >>> 0))
                                            {
                                                break $whileJumpStart4;
                                            }
                                            thisChar = source._reference.GetAt(srcIdx);
                                            if (!this._asciiPreescapedData.TryGetPreescapedData(thisChar, $.$ref(() => preescapedEntry, ($v) => preescapedEntry = $v, $.$$.S.UInt64)))
                                            {
                                                $gotoJumpState5 = 1; /*goto NotAscii*/
                                                continue $gotoJumpStart5;
                                            }
                                            if ((destination.Length >>> 0) <= (dstIdx >>> 0))
                                            {
                                                $gotoJumpState3 = 2; /*goto DestTooSmall*/
                                                continue $gotoJumpStart3;
                                            }
                                            destination._reference.SetAt($.$cast(preescapedEntry, $.$$.S.Byte), dstIdx);
                                            if (($.$cast(preescapedEntry, $.$$.S.UInt32) & 65280) === 0)
                                            {
                                                dstIdx++;
                                                srcIdx++;
                                                continue $whileJumpStart4;
                                            }
                                            preescapedEntry >>= 8n;
                                            dstIdxTemp = ((dstIdx + 1) | 0);
                                            do
                                            {
                                                if ((destination.Length >>> 0) <= (dstIdxTemp >>> 0))
                                                {
                                                    $gotoJumpState3 = 2; /*goto DestTooSmall*/
                                                    continue $gotoJumpStart3;
                                                }
                                                destination._reference.SetAt($.$cast(preescapedEntry, $.$$.S.Byte), dstIdxTemp++);
                                            }
                                            while($.$cast((preescapedEntry >>= 8n), $.$$.S.Byte) !== 0);
                                            dstIdx = dstIdxTemp;
                                            srcIdx++;
                                            continue $whileJumpStart4;
                                        }
                                        case 1: /*NotAscii*/
                                        if (!$.$$.ST.Rune.TryCreate(thisChar, $.$ref(() => scalarValue, ($v) => scalarValue = $v, $.$$.ST.Rune)))
                                        {
                                            /*int*/ var srcIdxTemp = ((srcIdx + 1) | 0);
                                            if ((source.Length >>> 0) > (srcIdxTemp >>> 0))
                                            {
                                                if ($.$$.ST.Rune.TryCreate$1(thisChar, source._reference.GetAt(srcIdxTemp), $.$ref(() => scalarValue, ($v) => scalarValue = $v, $.$$.ST.Rune)))
                                                {
                                                    $gotoJumpState5 = 2; /*goto CheckWhetherScalarValueAllowed*/
                                                    continue $gotoJumpStart5;
                                                }
                                            }
                                            else if (!isFinalBlock && $.$$.S.Char.IsHighSurrogate$1(thisChar))
                                            {
                                                $gotoJumpState3 = 3; /*goto NeedMoreData*/
                                                continue $gotoJumpStart3;
                                            }
                                            scalarValue = $.$$.ST.Rune.ReplacementChar;
                                            $gotoJumpState5 = 3; /*goto MustEncodeNonAscii*/
                                            continue $gotoJumpStart5;
                                        }
                                        case 2: /*CheckWhetherScalarValueAllowed*/
                                        if (this.IsScalarValueAllowed(scalarValue))
                                        {
                                            /*int*/ var utf16CodeUnitCount;
                                            if (!scalarValue.TryEncodeToUtf16(destination.Slice$1(dstIdx), $.$ref(() => utf16CodeUnitCount, ($v) => utf16CodeUnitCount = $v, $.$$.S.Int32)))
                                            {
                                                $gotoJumpState3 = 2; /*goto DestTooSmall*/
                                                continue $gotoJumpStart3;
                                            }
                                            dstIdx += utf16CodeUnitCount;
                                            srcIdx += utf16CodeUnitCount;
                                            continue $whileJumpStart4;
                                        }
                                        case 3: /*MustEncodeNonAscii*/
                                        charsWrittenJustNow = this._scalarEscaper.EncodeUtf16(scalarValue, destination.Slice$1(dstIdx));
                                        if (charsWrittenJustNow < 0)
                                        {
                                            $gotoJumpState3 = 2; /*goto DestTooSmall*/
                                            continue $gotoJumpStart3;
                                        }
                                        dstIdx += charsWrittenJustNow;
                                        srcIdx += scalarValue.Utf16SequenceLength;
                                    }
                                    break;
                                }
                            }
                            retVal = 0/*OperationStatus.Done*/;
                        }
                        case 1: /*CommonReturn*/
                        charsConsumed.$v = srcIdx;
                        charsWritten.$v = dstIdx;
                        return retVal;
                        case 2: /*DestTooSmall*/
                        retVal = 1/*OperationStatus.DestinationTooSmall*/;
                        $gotoJumpState3 = 1; /*goto CommonReturn*/
                        continue $gotoJumpStart3;
                        case 3: /*NeedMoreData*/
                        retVal = 2/*OperationStatus.NeedMoreData*/;
                        $gotoJumpState3 = 1; /*goto CommonReturn*/
                        continue $gotoJumpStart3;
                    }
                    break;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360983609)
            
            //--TRIMMABLE-BOUNDARY-START(38655950905)
            /*OperationStatus */ EncodeUtf8(/*ReadOnlySpan<byte>*/ source, /*Span<byte>*/ destination, /*out int*/ bytesConsumed, /*out int*/ bytesWritten, /*bool*/ isFinalBlock)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655950905);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let srcIdx;
                /*int*/ let dstIdx;
                /*OperationStatus*/ let retVal;
                let $gotoJumpState10 = 0;
                $gotoJumpStart10: while(true)
                {
                    switch($gotoJumpState10)
                    {
                        case 0:
                        {
                            this._AssertThisNotNull();
                            srcIdx = 0;
                            dstIdx = 0;
                            $whileJumpStart11: while(true)
                            {
                                /*uint*/ let thisByte;
                                /*int*/ let dstIdxTemp;
                                /*OperationStatus*/ let runeDecodeStatus;
                                /*int*/ let bytesWrittenJustNow;
                                let $gotoJumpState12 = 0;
                                $gotoJumpStart12: while(true)
                                {
                                    /*Rune*/ var scalarValue;
                                    /*int*/ var bytesConsumedJustNow;
                                    switch($gotoJumpState12)
                                    {
                                        case 0:
                                        {
                                            /*ulong*/ var preescapedEntry;
                                            if ((source.Length >>> 0) <= (srcIdx >>> 0))
                                            {
                                                break $whileJumpStart11;
                                            }
                                            thisByte = source._reference.GetAt(srcIdx);
                                            if (!this._asciiPreescapedData.TryGetPreescapedData(thisByte, $.$ref(() => preescapedEntry, ($v) => preescapedEntry = $v, $.$$.S.UInt64)))
                                            {
                                                $gotoJumpState12 = 1; /*goto NotAscii*/
                                                continue $gotoJumpStart12;
                                            }
                                            if ($.$$.SBB.BinaryPrimitives.TryWriteUInt64LittleEndian(destination.Slice$1(dstIdx), preescapedEntry))
                                            {
                                                dstIdx += $.$cast((preescapedEntry >> 56n), $.$$.S.Int32);
                                                srcIdx++;
                                                continue $whileJumpStart11;
                                            }
                                            dstIdxTemp = dstIdx;
                                            do
                                            {
                                                if ((destination.Length >>> 0) <= (dstIdxTemp >>> 0))
                                                {
                                                    $gotoJumpState10 = 2; /*goto DestTooSmall*/
                                                    continue $gotoJumpStart10;
                                                }
                                                destination._reference.SetAt($.$cast(preescapedEntry, $.$$.S.Byte), dstIdxTemp++);
                                            }
                                            while($.$cast((preescapedEntry >>= 8n), $.$$.S.Byte) !== 0);
                                            dstIdx = dstIdxTemp;
                                            srcIdx++;
                                            continue $whileJumpStart11;
                                        }
                                        case 1: /*NotAscii*/
                                        runeDecodeStatus = $.$$.ST.Rune.DecodeFromUtf8(source.Slice$1(srcIdx), $.$ref(() => scalarValue, ($v) => scalarValue = $v, $.$$.ST.Rune), $.$ref(() => bytesConsumedJustNow, ($v) => bytesConsumedJustNow = $v, $.$$.S.Int32));
                                        if (runeDecodeStatus !== 0/*OperationStatus.Done*/)
                                        {
                                            if (!isFinalBlock && runeDecodeStatus === 2/*OperationStatus.NeedMoreData*/)
                                            {
                                                $gotoJumpState10 = 3; /*goto NeedMoreData*/
                                                continue $gotoJumpStart10;
                                            }
                                            $.$$.SD.Debug.Assert$4($.$$.ST.Rune.op_Equality(scalarValue, $.$$.ST.Rune.ReplacementChar), "scalarValue == Rune.ReplacementChar");
                                            $gotoJumpState12 = 2; /*goto MustEncodeNonAscii*/
                                            continue $gotoJumpStart12;
                                        }
                                        if (this.IsScalarValueAllowed(scalarValue))
                                        {
                                            /*int*/ var utf8CodeUnitCount;
                                            if (!scalarValue.TryEncodeToUtf8(destination.Slice$1(dstIdx), $.$ref(() => utf8CodeUnitCount, ($v) => utf8CodeUnitCount = $v, $.$$.S.Int32)))
                                            {
                                                $gotoJumpState10 = 2; /*goto DestTooSmall*/
                                                continue $gotoJumpStart10;
                                            }
                                            dstIdx += utf8CodeUnitCount;
                                            srcIdx += utf8CodeUnitCount;
                                            continue $whileJumpStart11;
                                        }
                                        case 2: /*MustEncodeNonAscii*/
                                        bytesWrittenJustNow = this._scalarEscaper.EncodeUtf8(scalarValue, destination.Slice$1(dstIdx));
                                        if (bytesWrittenJustNow < 0)
                                        {
                                            $gotoJumpState10 = 2; /*goto DestTooSmall*/
                                            continue $gotoJumpStart10;
                                        }
                                        dstIdx += bytesWrittenJustNow;
                                        srcIdx += bytesConsumedJustNow;
                                    }
                                    break;
                                }
                            }
                            retVal = 0/*OperationStatus.Done*/;
                        }
                        case 1: /*CommonReturn*/
                        bytesConsumed.$v = srcIdx;
                        bytesWritten.$v = dstIdx;
                        return retVal;
                        case 2: /*DestTooSmall*/
                        retVal = 1/*OperationStatus.DestinationTooSmall*/;
                        $gotoJumpState10 = 1; /*goto CommonReturn*/
                        continue $gotoJumpStart10;
                        case 3: /*NeedMoreData*/
                        retVal = 2/*OperationStatus.NeedMoreData*/;
                        $gotoJumpState10 = 1; /*goto CommonReturn*/
                        continue $gotoJumpStart10;
                    }
                    break;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38655950905)
            
            //--TRIMMABLE-BOUNDARY-START(47245885497)
            /*int */ GetIndexOfFirstByteToEncode(/*ReadOnlySpan<byte>*/ data)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245885497);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let asciiBytesSkipped = 0;
                asciiBytesSkipped = $.$$.S.MemoryExtensions.IndexOfAnyExcept($.$$.S.Byte, data, this._allowedAsciiBytes);
                if ((asciiBytesSkipped >>> 0) >= (data.Length >>> 0) || $.$stew.ST.UnicodeUtility.IsAsciiCodePoint(data._reference.GetAt(asciiBytesSkipped)))
                {
                    return asciiBytesSkipped;
                }
                /*int*/ let dataOriginalLength = data.Length;
                data = data.Slice$1(asciiBytesSkipped);
                while(!data.IsEmpty)
                {
                    /*Rune*/ let scalarValue;
                    /*int*/ let bytesConsumed;
                    /*OperationStatus*/ let opStatus = $.$$.ST.Rune.DecodeFromUtf8(data, $.$ref(() => scalarValue, ($v) => scalarValue = $v, $.$$.ST.Rune), $.$ref(() => bytesConsumed, ($v) => bytesConsumed = $v, $.$$.S.Int32));
                    if (opStatus !== 0/*OperationStatus.Done*/)
                    {
                        break;
                    }
                    if (bytesConsumed >= 4)
                    {
                        break;
                    }
                    $.$stew.ST.UnicodeDebug.AssertIsBmpCodePoint((scalarValue.Value >>> 0));
                    if (!this._allowedBmpCodePoints.IsCharAllowed($.$cast(scalarValue.Value, $.$$.S.Char)))
                    {
                        break;
                    }
                    data = data.Slice$1(bytesConsumed);
                }
                return (data.IsEmpty) ? -1 : ((dataOriginalLength - data.Length) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(47245885497)
            
            //--TRIMMABLE-BOUNDARY-START(51540852793)
            /*int */ GetIndexOfFirstCharToEncode(/*ReadOnlySpan<char>*/ data)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540852793);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let asciiCharsSkipped = 0;
                if (data.Length >= 8)
                {
                    asciiCharsSkipped = $.$$.S.MemoryExtensions.IndexOfAnyExcept($.$$.S.Char, data, this._allowedAsciiChars);
                    if ((asciiCharsSkipped >>> 0) >= (data.Length >>> 0) || $.$$.S.Char.IsAscii(data._reference.GetAt(asciiCharsSkipped)))
                    {
                        return asciiCharsSkipped;
                    }
                }
                /*fixed*/ 
                {
                    /*char**/ let pData = data.GetPinnableReference();
                    /*nuint*/ let lengthInChars;
                    /*nuint*/ let idx;
                    /*int*/ let idx32;
                    let $gotoJumpState19 = 0;
                    $gotoJumpStart19: while(true)
                    {
                        switch($gotoJumpState19)
                        {
                            case 0:
                            {
                                lengthInChars = (data.Length >>> 0);
                                idx = (asciiCharsSkipped >>> 0);
                                if (idx < lengthInChars)
                                {
                                    /*nint*/ let loopIter;
                                    let $gotoJumpState20 = 0;
                                    $gotoJumpStart20: while(true)
                                    {
                                        switch($gotoJumpState20)
                                        {
                                            case 0:
                                            {
                                                this._AssertThisNotNull();
                                                loopIter = 0;
                                                for(; ((lengthInChars - idx) >>> 0) >= 8; idx += 8)
                                                {
                                                    loopIter = -1;
                                                    if (!this._allowedBmpCodePoints.IsCharAllowed(pData.GetAt(((idx + $.$cast((++loopIter), $.$$.S.UIntPtr)) >>> 0))))
                                                    {
                                                        $gotoJumpState20 = 1; /*goto BrokeInUnrolledLoop*/
                                                        continue $gotoJumpStart20;
                                                    }
                                                    if (!this._allowedBmpCodePoints.IsCharAllowed(pData.GetAt(((idx + $.$cast((++loopIter), $.$$.S.UIntPtr)) >>> 0))))
                                                    {
                                                        $gotoJumpState20 = 1; /*goto BrokeInUnrolledLoop*/
                                                        continue $gotoJumpStart20;
                                                    }
                                                    if (!this._allowedBmpCodePoints.IsCharAllowed(pData.GetAt(((idx + $.$cast((++loopIter), $.$$.S.UIntPtr)) >>> 0))))
                                                    {
                                                        $gotoJumpState20 = 1; /*goto BrokeInUnrolledLoop*/
                                                        continue $gotoJumpStart20;
                                                    }
                                                    if (!this._allowedBmpCodePoints.IsCharAllowed(pData.GetAt(((idx + $.$cast((++loopIter), $.$$.S.UIntPtr)) >>> 0))))
                                                    {
                                                        $gotoJumpState20 = 1; /*goto BrokeInUnrolledLoop*/
                                                        continue $gotoJumpStart20;
                                                    }
                                                    if (!this._allowedBmpCodePoints.IsCharAllowed(pData.GetAt(((idx + $.$cast((++loopIter), $.$$.S.UIntPtr)) >>> 0))))
                                                    {
                                                        $gotoJumpState20 = 1; /*goto BrokeInUnrolledLoop*/
                                                        continue $gotoJumpStart20;
                                                    }
                                                    if (!this._allowedBmpCodePoints.IsCharAllowed(pData.GetAt(((idx + $.$cast((++loopIter), $.$$.S.UIntPtr)) >>> 0))))
                                                    {
                                                        $gotoJumpState20 = 1; /*goto BrokeInUnrolledLoop*/
                                                        continue $gotoJumpStart20;
                                                    }
                                                    if (!this._allowedBmpCodePoints.IsCharAllowed(pData.GetAt(((idx + $.$cast((++loopIter), $.$$.S.UIntPtr)) >>> 0))))
                                                    {
                                                        $gotoJumpState20 = 1; /*goto BrokeInUnrolledLoop*/
                                                        continue $gotoJumpStart20;
                                                    }
                                                    if (!this._allowedBmpCodePoints.IsCharAllowed(pData.GetAt(((idx + $.$cast((++loopIter), $.$$.S.UIntPtr)) >>> 0))))
                                                    {
                                                        $gotoJumpState20 = 1; /*goto BrokeInUnrolledLoop*/
                                                        continue $gotoJumpStart20;
                                                    }
                                                }
                                                for(; idx < lengthInChars; idx++)
                                                {
                                                    if (!this._allowedBmpCodePoints.IsCharAllowed(pData.GetAt(idx)))
                                                    {
                                                        break;
                                                    }
                                                }
                                                $gotoJumpState19 = 1; /*goto Return*/
                                                continue $gotoJumpStart19;
                                            }
                                            case 1: /*BrokeInUnrolledLoop*/
                                            idx += $.$cast(loopIter, $.$$.S.UIntPtr);
                                        }
                                        break;
                                    }
                                }
                            }
                            case 1: /*Return*/
                            $.$$.SD.Debug.Assert$4(0 <= idx && idx <= lengthInChars, "0 <= idx && idx <= lengthInChars");
                            idx32 = (idx | 0);
                            if (idx32 === (lengthInChars | 0))
                            {
                                idx32 = -1;
                            }
                            return idx32;
                        }
                        break;
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51540852793)
            
            //--TRIMMABLE-BOUNDARY-START(55835820089)
            /*bool */ IsScalarValueAllowed(/*Rune*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835820089);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._allowedBmpCodePoints.IsCodePointAllowed((value.Value >>> 0));
            }
            //--TRIMMABLE-BOUNDARY-END(55835820089)
            
            //--TRIMMABLE-BOUNDARY-START(21476081721)
            /*void */ _AssertThisNotNull()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476081721);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Object.GetType.call(this) === $.$stew.STEW.OptimizedInboxTextEncoder.$type)
                {
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21476081721)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(17181114425)
                this._asciiPreescapedData = $.$default($.$stew.STEW.OptimizedInboxTextEncoder.AsciiPreescapedData);
                //--TRIMMABLE-BOUNDARY-END(17181114425)
                
                //--TRIMMABLE-BOUNDARY-START(12886147129)
                this._allowedBmpCodePoints = $.$default($.$stew.STEW.AllowedBmpCodePointsBitmap);
                //--TRIMMABLE-BOUNDARY-END(12886147129)
                
            }
            static $h = 1245241;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(42950918201),
    {
      "r": 655361,
      "p": [
        {
          "n": "text",
          "p": $.$typePointer($.$$.S.Char).$h
        },
        {
          "n": "textLength",
          "p": 655361
        }
      ],
      "n": "FindFirstCharacterToEncode",
      "d": 1245241,
      "h": 42950918201,
      "f": 16777217,
      "a": [
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "FindFirstCharacterToEncode has been deprecated. It should only be used by the TextEncoder adapter.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42950918201),
//--TRIMMABLE-BOUNDARY-START(60130787385),
    {
      "r": 262145,
      "p": [
        {
          "n": "unicodeScalar",
          "p": 655361
        },
        {
          "n": "buffer",
          "p": $.$typePointer($.$$.S.Char).$h
        },
        {
          "n": "bufferLength",
          "p": 655361
        },
        {
          "n": "numberOfCharactersWritten",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryEncodeUnicodeScalar",
      "d": 1245241,
      "h": 60130787385,
      "f": 16777217,
      "a": [
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "TryEncodeUnicodeScalar has been deprecated. It should only be used by the TextEncoder adapter.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(60130787385),
//--TRIMMABLE-BOUNDARY-START(34360983609),
    {
      "r": 50200577,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Char).$h
        },
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Char).$h
        },
        {
          "n": "charsConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "charsWritten",
          "p": 655361,
          "f": 2
        },
        {
          "n": "isFinalBlock",
          "p": 262145
        }
      ],
      "n": "Encode",
      "d": 1245241,
      "h": 34360983609,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360983609),
//--TRIMMABLE-BOUNDARY-START(38655950905),
    {
      "r": 50200577,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "bytesWritten",
          "p": 655361,
          "f": 2
        },
        {
          "n": "isFinalBlock",
          "p": 262145
        }
      ],
      "n": "EncodeUtf8",
      "d": 1245241,
      "h": 38655950905,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655950905),
//--TRIMMABLE-BOUNDARY-START(47245885497),
    {
      "r": 655361,
      "p": [
        {
          "n": "data",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        }
      ],
      "n": "GetIndexOfFirstByteToEncode",
      "d": 1245241,
      "h": 47245885497,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47245885497),
//--TRIMMABLE-BOUNDARY-START(51540852793),
    {
      "r": 655361,
      "p": [
        {
          "n": "data",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Char).$h
        }
      ],
      "n": "GetIndexOfFirstCharToEncode",
      "d": 1245241,
      "h": 51540852793,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51540852793),
//--TRIMMABLE-BOUNDARY-START(55835820089),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 167641089
        }
      ],
      "n": "IsScalarValueAllowed",
      "d": 1245241,
      "h": 55835820089,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55835820089),
//--TRIMMABLE-BOUNDARY-START(21476081721),
    {
      "r": 65537,
      "n": "_AssertThisNotNull",
      "d": 1245241,
      "h": 21476081721,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(21476081721)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17181114425),
    {
      "t": 1310777,
      "n": "_asciiPreescapedData",
      "d": 1245241,
      "h": 17181114425,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181114425),
//--TRIMMABLE-BOUNDARY-START(12886147129),
    {
      "t": 524345,
      "n": "_allowedBmpCodePoints",
      "d": 1245241,
      "h": 12886147129,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886147129),
//--TRIMMABLE-BOUNDARY-START(25771049017),
    {
      "t": 1376313,
      "n": "_scalarEscaper",
      "d": 1245241,
      "h": 25771049017,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25771049017),
//--TRIMMABLE-BOUNDARY-START(4296212537),
    {
      "t": $.$$.SB.SearchValues$$($.$$.S.Byte).$h,
      "n": "_allowedAsciiBytes",
      "d": 1245241,
      "h": 4296212537,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296212537),
//--TRIMMABLE-BOUNDARY-START(8591179833),
    {
      "t": $.$$.SB.SearchValues$$($.$$.S.Char).$h,
      "n": "_allowedAsciiChars",
      "d": 1245241,
      "h": 8591179833,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591179833)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30066016313),
    {
      "p": [
        {
          "n": "scalarEscaper",
          "p": 1376313
        },
        {
          "n": "allowedCodePointsBmp",
          "p": 524345,
          "f": 8
        },
        {
          "n": "forbidHtmlSensitiveCharacters",
          "p": 262145,
          "f": 65,
          "v": true
        },
        {
          "n": "extraCharactersToEscape",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Char).$h,
          "f": 65
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1245241,
      "h": 30066016313,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(30066016313)
  ],
  "h": 1245241
}; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$stew.STEW.OptimizedInboxTextEncoder.AsciiPreescapedData ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Text.Encodings.Web.OptimizedInboxTextEncoder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Text${separator}Encodings${separator}Web${separator}OptimizedInboxTextEncoder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1245241)
        
        

        //--TRIMMABLE-BOUNDARY-START(2097209)
        $asm.$cls(`$stew.S.ThrowHelper`, ($self) => class ThrowHelper
        {
            //--TRIMMABLE-BOUNDARY-START(38656802873)
            static /*void */ ThrowArgumentOutOfRangeException()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656802873);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.ArgumentOutOfRangeException().$ctor$15();
            }
            //--TRIMMABLE-BOUNDARY-END(38656802873)
            
            //--TRIMMABLE-BOUNDARY-START(25771900985)
            static /*void */ ThrowArgumentException_DestinationTooShort()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771900985);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.ArgumentException().$ctor$13($.$stew.S.SR.Argument_DestinationTooShort, "destination");
            }
            //--TRIMMABLE-BOUNDARY-END(25771900985)
            
            //--TRIMMABLE-BOUNDARY-START(21476933689)
            static /*void */ ThrowArgumentException_CannotExtractScalar(/*ExceptionArgument*/ argument)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476933689);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw $.$stew.S.ThrowHelper.GetArgumentException(0/*ExceptionResource.Argument_CannotExtractScalar*/, argument);
            }
            //--TRIMMABLE-BOUNDARY-END(21476933689)
            
            //--TRIMMABLE-BOUNDARY-START(34361835577)
            static /*void */ ThrowArgumentOutOfRange_IndexMustBeLessException()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361835577);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw $.$stew.S.ThrowHelper.GetArgumentOutOfRangeException(2/*ExceptionArgument.index*/, 1/*ExceptionResource.ArgumentOutOfRange_IndexMustBeLess*/);
            }
            //--TRIMMABLE-BOUNDARY-END(34361835577)
            
            //--TRIMMABLE-BOUNDARY-START(30066868281)
            static /*void */ ThrowArgumentNullException(/*ExceptionArgument*/ argument)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066868281);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.ArgumentNullException().$ctor$19($.$stew.S.ThrowHelper.GetArgumentName(argument));
            }
            //--TRIMMABLE-BOUNDARY-END(30066868281)
            
            //--TRIMMABLE-BOUNDARY-START(42951770169)
            static /*void */ ThrowArgumentOutOfRangeException$1(/*ExceptionArgument*/ argument)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951770169);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.ArgumentOutOfRangeException().$ctor$20($.$stew.S.ThrowHelper.GetArgumentName(argument));
            }
            //--TRIMMABLE-BOUNDARY-END(42951770169)
            
            //--TRIMMABLE-BOUNDARY-START(12886999097)
            static /*ArgumentOutOfRangeException */ GetArgumentOutOfRangeException(/*ExceptionArgument*/ argument, /*ExceptionResource*/ resource)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886999097);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$$.S.ArgumentOutOfRangeException().$ctor$19($.$stew.S.ThrowHelper.GetArgumentName(argument), $.$stew.S.ThrowHelper.GetResourceString(resource));
            }
            //--TRIMMABLE-BOUNDARY-END(12886999097)
            
            //--TRIMMABLE-BOUNDARY-START(4297064505)
            static /*ArgumentException */ GetArgumentException(/*ExceptionResource*/ resource, /*ExceptionArgument*/ argument)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297064505);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$$.S.ArgumentException().$ctor$13($.$stew.S.ThrowHelper.GetResourceString(resource), $.$stew.S.ThrowHelper.GetArgumentName(argument));
            }
            //--TRIMMABLE-BOUNDARY-END(4297064505)
            
            //--TRIMMABLE-BOUNDARY-START(8592031801)
            static /*string */ GetArgumentName(/*ExceptionArgument*/ argument)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592031801);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                switch(argument)
                {
                    case 0/*ExceptionArgument.ch*/:
                    return "ch";
                    case 1/*ExceptionArgument.culture*/:
                    return "culture";
                    case 2/*ExceptionArgument.index*/:
                    return "index";
                    case 3/*ExceptionArgument.input*/:
                    return "input";
                    case 4/*ExceptionArgument.value*/:
                    return "value";
                    default:
                    $.$$.SD.Debug.Fail$1("The enum value is not defined, please check the ExceptionArgument Enum.");
                    return "";
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8592031801)
            
            //--TRIMMABLE-BOUNDARY-START(17181966393)
            static /*string */ GetResourceString(/*ExceptionResource*/ resource)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181966393);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                switch(resource)
                {
                    case 1/*ExceptionResource.ArgumentOutOfRange_IndexMustBeLess*/:
                    return $.$stew.S.SR.ArgumentOutOfRange_IndexMustBeLess;
                    case 0/*ExceptionResource.Argument_CannotExtractScalar*/:
                    return $.$stew.S.SR.Argument_CannotExtractScalar;
                    default:
                    $.$$.SD.Debug.Fail$1("The enum value is not defined, please check the ExceptionResource Enum.");
                    return "";
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17181966393)
            
            static $h = 2097209;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(38656802873),
    {
      "r": 65537,
      "n": "ThrowArgumentOutOfRangeException",
      "d": 2097209,
      "h": 38656802873,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(38656802873),
//--TRIMMABLE-BOUNDARY-START(25771900985),
    {
      "r": 65537,
      "n": "ThrowArgumentException_DestinationTooShort",
      "d": 2097209,
      "h": 25771900985,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(25771900985),
//--TRIMMABLE-BOUNDARY-START(21476933689),
    {
      "r": 65537,
      "p": [
        {
          "n": "argument",
          "p": 65593
        }
      ],
      "n": "ThrowArgumentException_CannotExtractScalar",
      "d": 2097209,
      "h": 21476933689,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(21476933689),
//--TRIMMABLE-BOUNDARY-START(34361835577),
    {
      "r": 65537,
      "n": "ThrowArgumentOutOfRange_IndexMustBeLessException",
      "d": 2097209,
      "h": 34361835577,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(34361835577),
//--TRIMMABLE-BOUNDARY-START(30066868281),
    {
      "r": 65537,
      "p": [
        {
          "n": "argument",
          "p": 65593
        }
      ],
      "n": "ThrowArgumentNullException",
      "d": 2097209,
      "h": 30066868281,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(30066868281),
//--TRIMMABLE-BOUNDARY-START(42951770169),
    {
      "r": 65537,
      "p": [
        {
          "n": "argument",
          "p": 65593
        }
      ],
      "n": "ThrowArgumentOutOfRangeException",
      "o": "@$1",
      "d": 2097209,
      "h": 42951770169,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(42951770169),
//--TRIMMABLE-BOUNDARY-START(12886999097),
    {
      "r": 45088769,
      "p": [
        {
          "n": "argument",
          "p": 65593
        },
        {
          "n": "resource",
          "p": 131129
        }
      ],
      "n": "GetArgumentOutOfRangeException",
      "d": 2097209,
      "h": 12886999097,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(12886999097),
//--TRIMMABLE-BOUNDARY-START(4297064505),
    {
      "r": 44957697,
      "p": [
        {
          "n": "resource",
          "p": 131129
        },
        {
          "n": "argument",
          "p": 65593
        }
      ],
      "n": "GetArgumentException",
      "d": 2097209,
      "h": 4297064505,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(4297064505),
//--TRIMMABLE-BOUNDARY-START(8592031801),
    {
      "r": 1310721,
      "p": [
        {
          "n": "argument",
          "p": 65593
        }
      ],
      "n": "GetArgumentName",
      "d": 2097209,
      "h": 8592031801,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(8592031801),
//--TRIMMABLE-BOUNDARY-START(17181966393),
    {
      "r": 1310721,
      "p": [
        {
          "n": "resource",
          "p": 131129
        }
      ],
      "n": "GetResourceString",
      "d": 2097209,
      "h": 17181966393,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(17181966393)
  ],
  "h": 2097209
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.ThrowHelper`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}ThrowHelper`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2097209)
        
        

        //--TRIMMABLE-BOUNDARY-START(1900601)
        $asm.$cls(`$stew.ST.UnicodeDebug`, ($self) => class UnicodeDebug
        {
            //--TRIMMABLE-BOUNDARY-START(4296867897)
            static /*void */ AssertIsBmpCodePoint(/*uint*/ codePoint)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296867897);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$stew.ST.UnicodeUtility.IsBmpCodePoint(codePoint))
                {
                    $.$$.SD.Debug.Fail$1(`The value ${$.$strNN($.$stew.ST.UnicodeDebug.ToHexString(codePoint))} is not a valid BMP code point.`);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296867897)
            
            //--TRIMMABLE-BOUNDARY-START(8591835193)
            static /*void */ AssertIsHighSurrogateCodePoint(/*uint*/ codePoint)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591835193);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$stew.ST.UnicodeUtility.IsHighSurrogateCodePoint(codePoint))
                {
                    $.$$.SD.Debug.Fail$1(`The value ${$.$strNN($.$stew.ST.UnicodeDebug.ToHexString(codePoint))} is not a valid UTF-16 high surrogate code point.`);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8591835193)
            
            //--TRIMMABLE-BOUNDARY-START(12886802489)
            static /*void */ AssertIsLowSurrogateCodePoint(/*uint*/ codePoint)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886802489);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$stew.ST.UnicodeUtility.IsLowSurrogateCodePoint(codePoint))
                {
                    $.$$.SD.Debug.Fail$1(`The value ${$.$strNN($.$stew.ST.UnicodeDebug.ToHexString(codePoint))} is not a valid UTF-16 low surrogate code point.`);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886802489)
            
            //--TRIMMABLE-BOUNDARY-START(17181769785)
            static /*void */ AssertIsValidCodePoint(/*uint*/ codePoint)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181769785);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$stew.ST.UnicodeUtility.IsValidCodePoint(codePoint))
                {
                    $.$$.SD.Debug.Fail$1(`The value ${$.$strNN($.$stew.ST.UnicodeDebug.ToHexString(codePoint))} is not a valid Unicode code point.`);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17181769785)
            
            //--TRIMMABLE-BOUNDARY-START(21476737081)
            static /*void */ AssertIsValidScalar(/*uint*/ scalarValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476737081);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$stew.ST.UnicodeUtility.IsValidUnicodeScalar(scalarValue))
                {
                    $.$$.SD.Debug.Fail$1(`The value ${$.$strNN($.$stew.ST.UnicodeDebug.ToHexString(scalarValue))} is not a valid Unicode scalar value.`);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21476737081)
            
            //--TRIMMABLE-BOUNDARY-START(25771704377)
            static /*void */ AssertIsValidSupplementaryPlaneScalar(/*uint*/ scalarValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771704377);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$stew.ST.UnicodeUtility.IsValidUnicodeScalar(scalarValue) || $.$stew.ST.UnicodeUtility.IsBmpCodePoint(scalarValue))
                {
                    $.$$.SD.Debug.Fail$1(`The value ${$.$strNN($.$stew.ST.UnicodeDebug.ToHexString(scalarValue))} is not a valid supplementary plane Unicode scalar value.`);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25771704377)
            
            //--TRIMMABLE-BOUNDARY-START(30066671673)
            static /*string */ ToHexString(/*uint*/ codePoint)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066671673);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.FormattableString.Invariant((() =>
                {
                    var $handler = new $.$$.SRC.DefaultInterpolatedStringHandler().$ctor$5(1, 1);
                    $handler.AppendLiteral("U+");
                    $handler.AppendFormatted($.$box(codePoint, $.$$.S.UInt32), null, "X4");
                    return $handler.ToStringAndClear            ();
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(30066671673)
            
            static $h = 1900601;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296867897),
    {
      "r": 65537,
      "p": [
        {
          "n": "codePoint",
          "p": 720897
        }
      ],
      "n": "AssertIsBmpCodePoint",
      "d": 1900601,
      "h": 4296867897,
      "f": 16777256,
      "a": [
        {
          "t": 69468161,
          "c": 8659402753,
          "a": [
            {
              "v": "DEBUG",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(4296867897),
//--TRIMMABLE-BOUNDARY-START(8591835193),
    {
      "r": 65537,
      "p": [
        {
          "n": "codePoint",
          "p": 720897
        }
      ],
      "n": "AssertIsHighSurrogateCodePoint",
      "d": 1900601,
      "h": 8591835193,
      "f": 16777256,
      "a": [
        {
          "t": 69468161,
          "c": 8659402753,
          "a": [
            {
              "v": "DEBUG",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8591835193),
//--TRIMMABLE-BOUNDARY-START(12886802489),
    {
      "r": 65537,
      "p": [
        {
          "n": "codePoint",
          "p": 720897
        }
      ],
      "n": "AssertIsLowSurrogateCodePoint",
      "d": 1900601,
      "h": 12886802489,
      "f": 16777256,
      "a": [
        {
          "t": 69468161,
          "c": 8659402753,
          "a": [
            {
              "v": "DEBUG",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12886802489),
//--TRIMMABLE-BOUNDARY-START(17181769785),
    {
      "r": 65537,
      "p": [
        {
          "n": "codePoint",
          "p": 720897
        }
      ],
      "n": "AssertIsValidCodePoint",
      "d": 1900601,
      "h": 17181769785,
      "f": 16777256,
      "a": [
        {
          "t": 69468161,
          "c": 8659402753,
          "a": [
            {
              "v": "DEBUG",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17181769785),
//--TRIMMABLE-BOUNDARY-START(21476737081),
    {
      "r": 65537,
      "p": [
        {
          "n": "scalarValue",
          "p": 720897
        }
      ],
      "n": "AssertIsValidScalar",
      "d": 1900601,
      "h": 21476737081,
      "f": 16777256,
      "a": [
        {
          "t": 69468161,
          "c": 8659402753,
          "a": [
            {
              "v": "DEBUG",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21476737081),
//--TRIMMABLE-BOUNDARY-START(25771704377),
    {
      "r": 65537,
      "p": [
        {
          "n": "scalarValue",
          "p": 720897
        }
      ],
      "n": "AssertIsValidSupplementaryPlaneScalar",
      "d": 1900601,
      "h": 25771704377,
      "f": 16777256,
      "a": [
        {
          "t": 69468161,
          "c": 8659402753,
          "a": [
            {
              "v": "DEBUG",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25771704377),
//--TRIMMABLE-BOUNDARY-START(30066671673),
    {
      "r": 1310721,
      "p": [
        {
          "n": "codePoint",
          "p": 720897
        }
      ],
      "n": "ToHexString",
      "d": 1900601,
      "h": 30066671673,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(30066671673)
  ],
  "h": 1900601
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Text.UnicodeDebug`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Text${separator}UnicodeDebug`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1900601)
        
        

        //--TRIMMABLE-BOUNDARY-START(196665)
        $asm.$cls(`$stew.S.HexConverter`, ($self) => class HexConverter
        {
            //--TRIMMABLE-BOUNDARY-START(262201)
            static $_Casing;
            static get Casing()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(262201);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$stew.S.HexConverter;
                return $cls.$_Casing ??= $asm.$nstr(`$stew.S.HexConverter.Casing`, ($self) => class Casing extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
                {
                    static Upper = 0;
                    static Lower = 8224;
                    static $map;
                    static get Map()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(262201);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.$map ??= 
                        {
                            "Upper": 0n,
                            "Lower": 8224n
                        };
                    }
                    //--TRIMMABLE-BOUNDARY-START(4295229497)
                    //default constructor overload
                    $ctor$3()
                    {
                        super.$ctor$2();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4295229497);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295229497)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295229497)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$3();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295229497)
                    
                    static $h = 262201;
                    static $z = 4;
                    static $f = 0b110000011010001001;
                    static $k = 4;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Enum; }
                    static get $eut() { return $.$$.S.UInt32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "u": 720897,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885164089),
    {
      "t": 262201,
      "n": "Upper",
      "d": 262201,
      "h": 12885164089,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885164089),
//--TRIMMABLE-BOUNDARY-START(8590196793),
    {
      "t": 262201,
      "n": "Lower",
      "d": 262201,
      "h": 8590196793,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590196793)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295229497),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 262201,
      "h": 4295229497,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295229497)
  ],
  "d": 196665,
  "h": 262201
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.HexConverter+Casing`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}HexConverter${separator}Casing`; }
                }, $cls, ($v) => $cls.$_Casing = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(262201)
            
            //--TRIMMABLE-BOUNDARY-START(51539804217)
            static /*void */ ToBytesBuffer(/*byte*/ value, /*Span<byte>*/ buffer, /*int*/ startingIndex, /*Casing*/ casing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539804217);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*uint*/ let difference = (((((((value & 240) << 4) >>> 0) + (value & 15)) >>> 0) - 35209) >>> 0);
                /*uint*/ let packedResult = (((((((((-(difference | 0)) >>> 0) & 28784) >>> 4) + difference) >>> 0) + 47545) >>> 0)) | casing;
                buffer._reference.SetAt(((packedResult & 0xFF) >>> 0), ((startingIndex + 1) | 0));
                buffer._reference.SetAt((((packedResult >>> 8) & 0xFF) >>> 0), startingIndex);
            }
            //--TRIMMABLE-BOUNDARY-END(51539804217)
            
            //--TRIMMABLE-BOUNDARY-START(60129738809)
            static /*void */ ToCharsBuffer(/*byte*/ value, /*Span<char>*/ buffer, /*int*/ startingIndex, /*Casing*/ casing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129738809);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*uint*/ let difference = (((((((value & 240) << 4) >>> 0) + (value & 15)) >>> 0) - 35209) >>> 0);
                /*uint*/ let packedResult = (((((((((-(difference | 0)) >>> 0) & 28784) >>> 4) + difference) >>> 0) + 47545) >>> 0)) | casing;
                buffer._reference.SetAt((((packedResult & 255) & 0xFFFF) >>> 0), ((startingIndex + 1) | 0));
                buffer._reference.SetAt((((packedResult >>> 8) & 0xFFFF) >>> 0), startingIndex);
            }
            //--TRIMMABLE-BOUNDARY-END(60129738809)
            
            //--TRIMMABLE-BOUNDARY-START(12885098553)
            static /*void */ EncodeToUtf8(/*ReadOnlySpan<byte>*/ source, /*Span<byte>*/ utf8Destination, /*Casing*/ casing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885098553);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(utf8Destination.Length >= (((source.Length * 2) | 0)), "utf8Destination.Length >= (source.Length * 2)");
                for(/*int*/ let pos = 0; pos < source.Length; pos++)
                {
                    $.$stew.S.HexConverter.ToBytesBuffer(source._reference.GetAt(pos), utf8Destination, ((pos * 2) | 0), casing);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885098553)
            
            //--TRIMMABLE-BOUNDARY-START(8590131257)
            static /*void */ EncodeToUtf16(/*ReadOnlySpan<byte>*/ source, /*Span<char>*/ destination, /*Casing*/ casing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590131257);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(destination.Length >= (((source.Length * 2) | 0)), "destination.Length >= (source.Length * 2)");
                for(/*int*/ let pos = 0; pos < source.Length; pos++)
                {
                    $.$stew.S.HexConverter.ToCharsBuffer(source._reference.GetAt(pos), destination, ((pos * 2) | 0), casing);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590131257)
            
            //--TRIMMABLE-BOUNDARY-START(68719673401)
            static /*string */ ToString$1(/*ReadOnlySpan<byte>*/ bytes, /*Casing*/ casing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719673401);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*SpanCasingPair*/ let args = (() =>
                {
                    //new $.$stew.S.HexConverter.SpanCasingPair()
                    const $t1 = $.$stew.S.HexConverter.SpanCasingPair;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Bytes = bytes;
                    $i1.Casing = casing;
                    return $i1;
                })();
                return $.$$.S.String.Create$10($.$stew.S.HexConverter.SpanCasingPair, ((bytes.Length * 2) | 0), $.$clone(args), new ($.$$.SB.SpanAction$$$($.$$.S.Char, $.$stew.S.HexConverter.SpanCasingPair))().$ctor($.$stew.S.HexConverter, /*static*/ (/*chars*/ chars, /*args*/ args) =>
                {
                    return $.$stew.S.HexConverter.EncodeToUtf16(args.Bytes, chars, args.Casing);
                }, $vrAaHg ??= {"r":65537,"p":[{"n":"chars","p":$.$$.S.Span$$($.$$.S.Char).$h},{"n":"args","p":327737}],"n":"","d":196665,"h":0,"f":17825826}));
            }
            //--TRIMMABLE-BOUNDARY-END(68719673401)
            
            //--TRIMMABLE-BOUNDARY-START(327737)
            static $_SpanCasingPair;
            static get SpanCasingPair()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(327737);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$stew.S.HexConverter;
                return $cls.$_SpanCasingPair ??= $asm.$nstr(`$stew.S.HexConverter.SpanCasingPair`, ($self) => class SpanCasingPair extends $.$$.S.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(17180196921)
                    /*ReadOnlySpan<byte>*/ Bytes;
                    //--TRIMMABLE-BOUNDARY-END(17180196921)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475164217)
                    /*Casing*/ Casing = 0;
                    //--TRIMMABLE-BOUNDARY-END(21475164217)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885229625)
                    //default constructor overload
                    $ctor$2()
                    {
                        super.$ctor$1();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12885229625);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885229625)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885229625)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885229625)
                    
                    $clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Bytes = this.Bytes.$clone();
                        copy.Casing = this.Casing;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(17180196921)
                        this.Bytes = $.$default($.$$.S.ReadOnlySpan$$($.$$.S.Byte));
                        //--TRIMMABLE-BOUNDARY-END(17180196921)
                        
                    }
                    static $h = 327737;
                    static $z = 9;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.ValueType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180196921),
    {
      "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065098809,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47244967993,
        "f": 83886081
      },
      "n": "Bytes",
      "d": 327737,
      "h": 17180196921,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180196921),
//--TRIMMABLE-BOUNDARY-START(21475164217),
    {
      "p": 262201,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655033401,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55834902585,
        "f": 83886081
      },
      "n": "Casing",
      "d": 327737,
      "h": 21475164217,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475164217)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885229625),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 327737,
      "h": 12885229625,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885229625)
  ],
  "d": 196665,
  "h": 327737
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.HexConverter+SpanCasingPair`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}HexConverter${separator}SpanCasingPair`; }
                }, $cls, ($v) => $cls.$_SpanCasingPair = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(327737)
            
            //--TRIMMABLE-BOUNDARY-START(64424706105)
            static /*char */ ToCharUpper(/*int*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424706105);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                value &= 15;
                value += /*0*/ 48;
                if (value > /*9*/ 57)
                {
                    value += (((/*A*/ 65 - (((/*9*/ 57 + 1) | 0))) | 0));
                }
                return $.$cast(value, $.$$.S.Char);
            }
            //--TRIMMABLE-BOUNDARY-END(64424706105)
            
            //--TRIMMABLE-BOUNDARY-START(55834771513)
            static /*char */ ToCharLower(/*int*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834771513);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                value &= 15;
                value += /*0*/ 48;
                if (value > /*9*/ 57)
                {
                    value += (((/*a*/ 97 - (((/*9*/ 57 + 1) | 0))) | 0));
                }
                return $.$cast(value, $.$$.S.Char);
            }
            //--TRIMMABLE-BOUNDARY-END(55834771513)
            
            //--TRIMMABLE-BOUNDARY-START(85899542585)
            static /*bool */ TryDecodeFromUtf8(/*ReadOnlySpan<byte>*/ utf8Source, /*Span<byte>*/ destination, /*out int*/ bytesProcessed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899542585);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$stew.S.HexConverter.TryDecodeFromUtf8_Scalar(utf8Source, destination, bytesProcessed);
            }
            //--TRIMMABLE-BOUNDARY-END(85899542585)
            
            //--TRIMMABLE-BOUNDARY-START(77309607993)
            static /*bool */ TryDecodeFromUtf16(/*ReadOnlySpan<char>*/ source, /*Span<byte>*/ destination, /*out int*/ charsProcessed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309607993);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$stew.S.HexConverter.TryDecodeFromUtf16_Scalar(source, destination, charsProcessed);
            }
            //--TRIMMABLE-BOUNDARY-END(77309607993)
            
            //--TRIMMABLE-BOUNDARY-START(81604575289)
            static /*bool */ TryDecodeFromUtf8_Scalar(/*ReadOnlySpan<byte>*/ utf8Source, /*Span<byte>*/ destination, /*out int*/ bytesProcessed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604575289);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4((utf8Source.Length % 2) === 0, "Un-even number of characters provided");
                $.$$.SD.Debug.Assert$4(($.trunc(utf8Source.Length / 2)) === destination.Length, "Target buffer not right-sized for provided characters");
                /*int*/ let i = 0;
                /*int*/ let j = 0;
                /*int*/ let byteLo = 0;
                /*int*/ let byteHi = 0;
                while(j < destination.Length)
                {
                    byteLo = $.$stew.S.HexConverter.FromChar(utf8Source._reference.GetAt(((i + 1) | 0)));
                    byteHi = $.$stew.S.HexConverter.FromChar(utf8Source._reference.GetAt(i));
                    if ((byteLo | byteHi) === 255)
                    {
                        break;
                    }
                    destination._reference.SetAt($.$cast(((byteHi << 4) | byteLo), $.$$.S.Byte), j++);
                    i += 2;
                }
                if (byteLo === 255)
                {
                    i++;
                }
                bytesProcessed.$v = i;
                return (byteLo | byteHi) !== 255;
            }
            //--TRIMMABLE-BOUNDARY-END(81604575289)
            
            //--TRIMMABLE-BOUNDARY-START(73014640697)
            static /*bool */ TryDecodeFromUtf16_Scalar(/*ReadOnlySpan<char>*/ source, /*Span<byte>*/ destination, /*out int*/ charsProcessed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014640697);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4((source.Length % 2) === 0, "Un-even number of characters provided");
                $.$$.SD.Debug.Assert$4(($.trunc(source.Length / 2)) === destination.Length, "Target buffer not right-sized for provided characters");
                /*int*/ let i = 0;
                /*int*/ let j = 0;
                /*int*/ let byteLo = 0;
                /*int*/ let byteHi = 0;
                while(j < destination.Length)
                {
                    byteLo = $.$stew.S.HexConverter.FromChar(source._reference.GetAt(((i + 1) | 0)));
                    byteHi = $.$stew.S.HexConverter.FromChar(source._reference.GetAt(i));
                    if ((byteLo | byteHi) === 255)
                    {
                        break;
                    }
                    destination._reference.SetAt($.$cast(((byteHi << 4) | byteLo), $.$$.S.Byte), j++);
                    i += 2;
                }
                if (byteLo === 255)
                {
                    i++;
                }
                charsProcessed.$v = i;
                return (byteLo | byteHi) !== 255;
            }
            //--TRIMMABLE-BOUNDARY-END(73014640697)
            
            //--TRIMMABLE-BOUNDARY-START(17180065849)
            static /*int */ FromChar(/*int*/ c)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180065849);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (c >= $.$stew.S.HexConverter.CharToHexLookup.Length) ? 255 : $.$stew.S.HexConverter.CharToHexLookup._reference.GetAt(c);
            }
            //--TRIMMABLE-BOUNDARY-END(17180065849)
            
            //--TRIMMABLE-BOUNDARY-START(25770000441)
            static /*int */ FromUpperChar(/*int*/ c)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770000441);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (c > 71) ? 255 : $.$stew.S.HexConverter.CharToHexLookup._reference.GetAt(c);
            }
            //--TRIMMABLE-BOUNDARY-END(25770000441)
            
            //--TRIMMABLE-BOUNDARY-START(21475033145)
            static /*int */ FromLowerChar(/*int*/ c)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475033145);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (((((c - /*0*/ 48) | 0)) >>> 0) <= (/*9*/ 57 - /*0*/ 48))
                {
                    return ((c - /*0*/ 48) | 0);
                }
                if (((((c - /*a*/ 97) | 0)) >>> 0) <= (/*f*/ 102 - /*a*/ 97))
                {
                    return ((((c - /*a*/ 97) | 0) + 10) | 0);
                }
                return 255;
            }
            //--TRIMMABLE-BOUNDARY-END(21475033145)
            
            //--TRIMMABLE-BOUNDARY-START(38654902329)
            static /*bool */ IsHexChar(/*int*/ c)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654902329);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //if (IntPtr.Size == 8) { ... }
                return $.$stew.S.HexConverter.FromChar(c) !== 255;
            }
            //--TRIMMABLE-BOUNDARY-END(38654902329)
            
            //--TRIMMABLE-BOUNDARY-START(47244836921)
            static /*bool */ IsHexUpperChar(/*int*/ c)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244836921);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (((((c - /*0*/ 48) | 0)) >>> 0) <= 9) || (((((c - /*A*/ 65) | 0)) >>> 0) <= (/*F*/ 70 - /*A*/ 65));
            }
            //--TRIMMABLE-BOUNDARY-END(47244836921)
            
            //--TRIMMABLE-BOUNDARY-START(42949869625)
            static /*bool */ IsHexLowerChar(/*int*/ c)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949869625);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (((((c - /*0*/ 48) | 0)) >>> 0) <= 9) || (((((c - /*a*/ 97) | 0)) >>> 0) <= (/*f*/ 102 - /*a*/ 97));
            }
            //--TRIMMABLE-BOUNDARY-END(42949869625)
            
            //--TRIMMABLE-BOUNDARY-START(4295163961)
            static /*ReadOnlySpan<byte> */ get CharToHexLookup()
            {
                return this.$cacheCharToHexLookup ??= new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7([ 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 255, 255, 255, 255, 255, 255, 255, 10, 11, 12, 13, 14, 15, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 10, 11, 12, 13, 14, 15, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255 ]);
            }
            //--TRIMMABLE-BOUNDARY-END(4295163961)
            
            static $h = 196665;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(4295163961),
    {
      "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34359935033,
        "f": 50331681
      },
      "n": "CharToHexLookup",
      "d": 196665,
      "h": 4295163961,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(4295163961)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(51539804217),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 393217
        },
        {
          "n": "buffer",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "startingIndex",
          "p": 655361,
          "f": 65,
          "v": 0
        },
        {
          "n": "casing",
          "p": 262201,
          "f": 65,
          "v": 0
        }
      ],
      "n": "ToBytesBuffer",
      "d": 196665,
      "h": 51539804217,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(51539804217),
//--TRIMMABLE-BOUNDARY-START(60129738809),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 393217
        },
        {
          "n": "buffer",
          "p": $.$$.S.Span$$($.$$.S.Char).$h
        },
        {
          "n": "startingIndex",
          "p": 655361,
          "f": 65,
          "v": 0
        },
        {
          "n": "casing",
          "p": 262201,
          "f": 65,
          "v": 0
        }
      ],
      "n": "ToCharsBuffer",
      "d": 196665,
      "h": 60129738809,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(60129738809),
//--TRIMMABLE-BOUNDARY-START(12885098553),
    {
      "r": 65537,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "utf8Destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "casing",
          "p": 262201,
          "f": 65,
          "v": 0
        }
      ],
      "n": "EncodeToUtf8",
      "d": 196665,
      "h": 12885098553,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12885098553),
//--TRIMMABLE-BOUNDARY-START(8590131257),
    {
      "r": 65537,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Char).$h
        },
        {
          "n": "casing",
          "p": 262201,
          "f": 65,
          "v": 0
        }
      ],
      "n": "EncodeToUtf16",
      "d": 196665,
      "h": 8590131257,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590131257),
//--TRIMMABLE-BOUNDARY-START(68719673401),
    {
      "r": 1310721,
      "p": [
        {
          "n": "bytes",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "casing",
          "p": 262201,
          "f": 65,
          "v": 0
        }
      ],
      "n": "ToString",
      "o": "@$1",
      "d": 196665,
      "h": 68719673401,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(68719673401),
//--TRIMMABLE-BOUNDARY-START(64424706105),
    {
      "r": 458753,
      "p": [
        {
          "n": "value",
          "p": 655361
        }
      ],
      "n": "ToCharUpper",
      "d": 196665,
      "h": 64424706105,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(64424706105),
//--TRIMMABLE-BOUNDARY-START(55834771513),
    {
      "r": 458753,
      "p": [
        {
          "n": "value",
          "p": 655361
        }
      ],
      "n": "ToCharLower",
      "d": 196665,
      "h": 55834771513,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(55834771513),
//--TRIMMABLE-BOUNDARY-START(85899542585),
    {
      "r": 262145,
      "p": [
        {
          "n": "utf8Source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "bytesProcessed",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryDecodeFromUtf8",
      "d": 196665,
      "h": 85899542585,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(85899542585),
//--TRIMMABLE-BOUNDARY-START(77309607993),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Char).$h
        },
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "charsProcessed",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryDecodeFromUtf16",
      "d": 196665,
      "h": 77309607993,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(77309607993),
//--TRIMMABLE-BOUNDARY-START(81604575289),
    {
      "r": 262145,
      "p": [
        {
          "n": "utf8Source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "bytesProcessed",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryDecodeFromUtf8_Scalar",
      "d": 196665,
      "h": 81604575289,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(81604575289),
//--TRIMMABLE-BOUNDARY-START(73014640697),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Char).$h
        },
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "charsProcessed",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryDecodeFromUtf16_Scalar",
      "d": 196665,
      "h": 73014640697,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(73014640697),
//--TRIMMABLE-BOUNDARY-START(17180065849),
    {
      "r": 655361,
      "p": [
        {
          "n": "c",
          "p": 655361
        }
      ],
      "n": "FromChar",
      "d": 196665,
      "h": 17180065849,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17180065849),
//--TRIMMABLE-BOUNDARY-START(25770000441),
    {
      "r": 655361,
      "p": [
        {
          "n": "c",
          "p": 655361
        }
      ],
      "n": "FromUpperChar",
      "d": 196665,
      "h": 25770000441,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25770000441),
//--TRIMMABLE-BOUNDARY-START(21475033145),
    {
      "r": 655361,
      "p": [
        {
          "n": "c",
          "p": 655361
        }
      ],
      "n": "FromLowerChar",
      "d": 196665,
      "h": 21475033145,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21475033145),
//--TRIMMABLE-BOUNDARY-START(38654902329),
    {
      "r": 262145,
      "p": [
        {
          "n": "c",
          "p": 655361
        }
      ],
      "n": "IsHexChar",
      "d": 196665,
      "h": 38654902329,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38654902329),
//--TRIMMABLE-BOUNDARY-START(47244836921),
    {
      "r": 262145,
      "p": [
        {
          "n": "c",
          "p": 655361
        }
      ],
      "n": "IsHexUpperChar",
      "d": 196665,
      "h": 47244836921,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(47244836921),
//--TRIMMABLE-BOUNDARY-START(42949869625),
    {
      "r": 262145,
      "p": [
        {
          "n": "c",
          "p": 655361
        }
      ],
      "n": "IsHexLowerChar",
      "d": 196665,
      "h": 42949869625,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(42949869625)
  ],
  "h": 196665
}; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$stew.S.HexConverter.Casing, $.$stew.S.HexConverter.SpanCasingPair ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.HexConverter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}HexConverter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196665)
        
        

        //--TRIMMABLE-BOUNDARY-START(1966137)
        $asm.$cls(`$stew.ST.UnicodeUtility`, ($self) => class UnicodeUtility
        {
            //--TRIMMABLE-BOUNDARY-START(60131508281)
            /*uint*/ static ReplacementChar = 65533;
            //--TRIMMABLE-BOUNDARY-END(60131508281)
            
            //--TRIMMABLE-BOUNDARY-START(4296933433)
            static /*int */ GetPlane(/*uint*/ codePoint)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296933433);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$stew.ST.UnicodeDebug.AssertIsValidCodePoint(codePoint);
                return ((codePoint >>> 16) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(4296933433)
            
            //--TRIMMABLE-BOUNDARY-START(8591900729)
            static /*uint */ GetScalarFromUtf16SurrogatePair(/*uint*/ highSurrogateCodePoint, /*uint*/ lowSurrogateCodePoint)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591900729);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$stew.ST.UnicodeDebug.AssertIsHighSurrogateCodePoint(highSurrogateCodePoint);
                $.$stew.ST.UnicodeDebug.AssertIsLowSurrogateCodePoint(lowSurrogateCodePoint);
                return ((((((highSurrogateCodePoint << 10) >>> 0) + lowSurrogateCodePoint) >>> 0) - (((((55296 << 10) >>> 0) + 56320) >>> 0) - (1 << 16))) >>> 0);
            }
            //--TRIMMABLE-BOUNDARY-END(8591900729)
            
            //--TRIMMABLE-BOUNDARY-START(12886868025)
            static /*int */ GetUtf16SequenceLength(/*uint*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886868025);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$stew.ST.UnicodeDebug.AssertIsValidScalar(value);
                value -= 65536;
                value += (2 << 24);
                value >>= 24;
                return (value | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(12886868025)
            
            //--TRIMMABLE-BOUNDARY-START(17181835321)
            static /*void */ GetUtf16SurrogatesFromSupplementaryPlaneScalar(/*uint*/ value, /*out char*/ highSurrogateCodePoint, /*out char*/ lowSurrogateCodePoint)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181835321);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$stew.ST.UnicodeDebug.AssertIsValidSupplementaryPlaneScalar(value);
                highSurrogateCodePoint.$v = ((((((value + (((((55296 - 64) >>> 0)) << 10) >>> 0)) >>> 0)) >>> 10) & 0xFFFF) >>> 0);
                lowSurrogateCodePoint.$v = ((((((value & 1023) + 56320) >>> 0)) & 0xFFFF) >>> 0);
            }
            //--TRIMMABLE-BOUNDARY-END(17181835321)
            
            //--TRIMMABLE-BOUNDARY-START(21476802617)
            static /*int */ GetUtf8SequenceLength(/*uint*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476802617);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$stew.ST.UnicodeDebug.AssertIsValidScalar(value);
                /*int*/ let a = ((((value | 0) - 2048) | 0)) >> 31;
                value ^= 63488;
                value -= 63616;
                value += (4 << 24);
                value >>= 24;
                return (((value | 0) + (((a * 2) | 0))) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(21476802617)
            
            //--TRIMMABLE-BOUNDARY-START(25771769913)
            static /*bool */ IsAsciiCodePoint(/*uint*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25771769913);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return value <= 127;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25771769913)
            
            //--TRIMMABLE-BOUNDARY-START(30066737209)
            static /*bool */ IsBmpCodePoint(/*uint*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30066737209);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return value <= 65535;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30066737209)
            
            //--TRIMMABLE-BOUNDARY-START(34361704505)
            static /*bool */ IsHighSurrogateCodePoint(/*uint*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34361704505);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$stew.ST.UnicodeUtility.IsInRangeInclusive(value, 55296, 56319);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34361704505)
            
            //--TRIMMABLE-BOUNDARY-START(38656671801)
            static /*bool */ IsInRangeInclusive(/*uint*/ value, /*uint*/ lowerBound, /*uint*/ upperBound)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38656671801);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return ((((value - lowerBound) >>> 0)) >>> 0) <= ((((upperBound - lowerBound) >>> 0)) >>> 0);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38656671801)
            
            //--TRIMMABLE-BOUNDARY-START(42951639097)
            static /*bool */ IsLowSurrogateCodePoint(/*uint*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42951639097);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$stew.ST.UnicodeUtility.IsInRangeInclusive(value, 56320, 57343);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42951639097)
            
            //--TRIMMABLE-BOUNDARY-START(47246606393)
            static /*bool */ IsSurrogateCodePoint(/*uint*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47246606393);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$stew.ST.UnicodeUtility.IsInRangeInclusive(value, 55296, 57343);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47246606393)
            
            //--TRIMMABLE-BOUNDARY-START(51541573689)
            static /*bool */ IsValidCodePoint(/*uint*/ codePoint)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51541573689);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return codePoint <= 1114111;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51541573689)
            
            //--TRIMMABLE-BOUNDARY-START(55836540985)
            static /*bool */ IsValidUnicodeScalar(/*uint*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836540985);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (((((value - 1114112) >>> 0)) ^ 55296) >>> 0) >= 4293855232;
            }
            //--TRIMMABLE-BOUNDARY-END(55836540985)
            
            static $h = 1966137;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296933433),
    {
      "r": 655361,
      "p": [
        {
          "n": "codePoint",
          "p": 720897
        }
      ],
      "n": "GetPlane",
      "d": 1966137,
      "h": 4296933433,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296933433),
//--TRIMMABLE-BOUNDARY-START(8591900729),
    {
      "r": 720897,
      "p": [
        {
          "n": "highSurrogateCodePoint",
          "p": 720897
        },
        {
          "n": "lowSurrogateCodePoint",
          "p": 720897
        }
      ],
      "n": "GetScalarFromUtf16SurrogatePair",
      "d": 1966137,
      "h": 8591900729,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591900729),
//--TRIMMABLE-BOUNDARY-START(12886868025),
    {
      "r": 655361,
      "p": [
        {
          "n": "value",
          "p": 720897
        }
      ],
      "n": "GetUtf16SequenceLength",
      "d": 1966137,
      "h": 12886868025,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12886868025),
//--TRIMMABLE-BOUNDARY-START(17181835321),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 720897
        },
        {
          "n": "highSurrogateCodePoint",
          "p": 458753,
          "f": 2
        },
        {
          "n": "lowSurrogateCodePoint",
          "p": 458753,
          "f": 2
        }
      ],
      "n": "GetUtf16SurrogatesFromSupplementaryPlaneScalar",
      "d": 1966137,
      "h": 17181835321,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17181835321),
//--TRIMMABLE-BOUNDARY-START(21476802617),
    {
      "r": 655361,
      "p": [
        {
          "n": "value",
          "p": 720897
        }
      ],
      "n": "GetUtf8SequenceLength",
      "d": 1966137,
      "h": 21476802617,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21476802617),
//--TRIMMABLE-BOUNDARY-START(25771769913),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 720897
        }
      ],
      "n": "IsAsciiCodePoint",
      "d": 1966137,
      "h": 25771769913,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25771769913),
//--TRIMMABLE-BOUNDARY-START(30066737209),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 720897
        }
      ],
      "n": "IsBmpCodePoint",
      "d": 1966137,
      "h": 30066737209,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30066737209),
//--TRIMMABLE-BOUNDARY-START(34361704505),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 720897
        }
      ],
      "n": "IsHighSurrogateCodePoint",
      "d": 1966137,
      "h": 34361704505,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34361704505),
//--TRIMMABLE-BOUNDARY-START(38656671801),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 720897
        },
        {
          "n": "lowerBound",
          "p": 720897
        },
        {
          "n": "upperBound",
          "p": 720897
        }
      ],
      "n": "IsInRangeInclusive",
      "d": 1966137,
      "h": 38656671801,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38656671801),
//--TRIMMABLE-BOUNDARY-START(42951639097),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 720897
        }
      ],
      "n": "IsLowSurrogateCodePoint",
      "d": 1966137,
      "h": 42951639097,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(42951639097),
//--TRIMMABLE-BOUNDARY-START(47246606393),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 720897
        }
      ],
      "n": "IsSurrogateCodePoint",
      "d": 1966137,
      "h": 47246606393,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(47246606393),
//--TRIMMABLE-BOUNDARY-START(51541573689),
    {
      "r": 262145,
      "p": [
        {
          "n": "codePoint",
          "p": 720897
        }
      ],
      "n": "IsValidCodePoint",
      "d": 1966137,
      "h": 51541573689,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(51541573689),
//--TRIMMABLE-BOUNDARY-START(55836540985),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 720897
        }
      ],
      "n": "IsValidUnicodeScalar",
      "d": 1966137,
      "h": 55836540985,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(55836540985)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(60131508281),
    {
      "t": 720897,
      "n": "ReplacementChar",
      "d": 1966137,
      "h": 60131508281,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60131508281)
  ],
  "h": 1966137
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Text.UnicodeUtility`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Text${separator}UnicodeUtility`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1966137)
        
        

        //--TRIMMABLE-BOUNDARY-START(589881)
        $asm.$str(`$stew.STEW.AsciiByteMap`, ($self) => class AsciiByteMap extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(12885491769)
            /*int*/ static BufferSize = 128;
            //--TRIMMABLE-BOUNDARY-END(12885491769)
            
            //--TRIMMABLE-BOUNDARY-START(8590524473)
            /*byte[128]*/ Buffer = [];
            //--TRIMMABLE-BOUNDARY-END(8590524473)
            
            //--TRIMMABLE-BOUNDARY-START(17180459065)
            /*void */ InsertAsciiChar(/*char*/ key, /*byte*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180459065);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(key < 128/*BufferSize*/, "key < BufferSize");
                $.$$.SD.Debug.Assert$4(value !== 0, "value != 0");
                if (key < 128/*BufferSize*/)
                {
                    this.Buffer[key] = value;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180459065)
            
            //--TRIMMABLE-BOUNDARY-START(21475426361)
            /*bool */ TryLookup(/*Rune*/ key, /*out byte*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475426361);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (key.IsAscii)
                {
                    /*byte*/ let entry = this.Buffer[(key.Value >>> 0)];
                    if (entry !== 0)
                    {
                        value.$v = entry;
                        return true;
                    }
                }
                value.$v = 0;
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(21475426361)
            
            //--TRIMMABLE-BOUNDARY-START(4295557177)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295557177);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295557177)
            
            //--TRIMMABLE-BOUNDARY-START(4295557177)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295557177)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                //FixedSizeArray(byte, 128)
                copy.Buffer = [...this.Buffer];
                $.$$.S.Array.CopyMetadata(copy.Buffer, this.Buffer)
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(8590524473)
                //FixedSizeArray(byte*, 128)
                let $t1 = this.Buffer;
                $.$$.S.Array.AddMetadata($t1, $.$$.S.Byte.$type, null, null);
                for (let $i = 0; $i < 128; $i++)
                {
                    $t1[$i] = [];
                }
                //--TRIMMABLE-BOUNDARY-END(8590524473)
                
            }
            static $h = 589881;
            static $z = 128;
            static $f = 0b10000000000001010000000;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180459065),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 458753
        },
        {
          "n": "value",
          "p": 393217
        }
      ],
      "n": "InsertAsciiChar",
      "d": 589881,
      "h": 17180459065,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(17180459065),
//--TRIMMABLE-BOUNDARY-START(21475426361),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": 167641089
        },
        {
          "n": "value",
          "p": 393217,
          "f": 2
        }
      ],
      "n": "TryLookup",
      "d": 589881,
      "h": 21475426361,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(21475426361)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885491769),
    {
      "t": 655361,
      "n": "BufferSize",
      "d": 589881,
      "h": 12885491769,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12885491769),
//--TRIMMABLE-BOUNDARY-START(8590524473),
    {
      "t": $.$typePointer($.$$.S.Byte).$h,
      "n": "Buffer",
      "d": 589881,
      "h": 8590524473,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590524473)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295557177),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 589881,
      "h": 4295557177,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295557177)
  ],
  "h": 589881
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Text.Encodings.Web.AsciiByteMap`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Text${separator}Encodings${separator}Web${separator}AsciiByteMap`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589881)
        
        

        //--TRIMMABLE-BOUNDARY-START(524345)
        $asm.$str(`$stew.STEW.AllowedBmpCodePointsBitmap`, ($self) => class AllowedBmpCodePointsBitmap extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(21475360825)
            /*int*/ static BitmapLengthInDWords = 2048;
            //--TRIMMABLE-BOUNDARY-END(21475360825)
            
            //--TRIMMABLE-BOUNDARY-START(17180393529)
            /*uint[2048]*/ Bitmap = [];
            //--TRIMMABLE-BOUNDARY-END(17180393529)
            
            //--TRIMMABLE-BOUNDARY-START(12885426233)
            /*void */ AllowChar(/*char*/ value)
            {
                /*nuint*/ let index;
                /*int*/ let offset;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885426233);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$stew.STEW.AllowedBmpCodePointsBitmap._GetIndexAndOffset(value, $.$ref(() => index, ($v) => index = $v, $.$$.S.UIntPtr), $.$ref(() => offset, ($v) => offset = $v, $.$$.S.Int32));
                this.Bitmap[index] |= (1 << offset) >>> 0;
            }
            //--TRIMMABLE-BOUNDARY-END(12885426233)
            
            //--TRIMMABLE-BOUNDARY-START(25770328121)
            /*void */ ForbidChar(/*char*/ value)
            {
                /*nuint*/ let index;
                /*int*/ let offset;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770328121);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$stew.STEW.AllowedBmpCodePointsBitmap._GetIndexAndOffset(value, $.$ref(() => index, ($v) => index = $v, $.$$.S.UIntPtr), $.$ref(() => offset, ($v) => offset = $v, $.$$.S.Int32));
                this.Bitmap[index] &= ~((1 << offset) >>> 0);
            }
            //--TRIMMABLE-BOUNDARY-END(25770328121)
            
            //--TRIMMABLE-BOUNDARY-START(30065295417)
            /*void */ ForbidHtmlCharacters()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065295417);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ForbidChar(/*<*/ 60);
                this.ForbidChar(/*>*/ 62);
                this.ForbidChar(/*&*/ 38);
                this.ForbidChar(/*'*/ 39);
                this.ForbidChar(/*\"*/ 34);
                this.ForbidChar(/*+*/ 43);
            }
            //--TRIMMABLE-BOUNDARY-END(30065295417)
            
            //--TRIMMABLE-BOUNDARY-START(34360262713)
            /*void */ ForbidUndefinedCharacters()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360262713);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*fixed*/ 
                {
                    /*uint**/ let pBitmap = $.$$.SRC.RuntimeHelpers.CreateArrayReferenceT($.$$.S.UInt32, this.Bitmap, null, false, true);
                    /*ReadOnlySpan<byte>*/ let definedCharsBitmapAsLittleEndian = $.$stew.STU.UnicodeHelpers.GetDefinedBmpCodePointsBitmapLittleEndian();
                    /*Span<uint>*/ let thisAllowedCharactersBitmap = new ($.$$.S.Span$$($.$$.S.UInt32))().$ctor$5(pBitmap, 2048/*BitmapLengthInDWords*/);
                    $.$$.SD.Debug.Assert$4(definedCharsBitmapAsLittleEndian.Length === ((thisAllowedCharactersBitmap.Length * 4) | 0), "definedCharsBitmapAsLittleEndian.Length == thisAllowedCharactersBitmap.Length * sizeof(uint)");
                    //if (Vector.IsHardwareAccelerated && BitConverter.IsLittleEndian) { ... }
                    for(/*int*/ let i = 0; i < thisAllowedCharactersBitmap.Length; i++)
                    {
                        thisAllowedCharactersBitmap._reference.SetAt($.$$.SBB.BinaryPrimitives.ReadUInt32LittleEndian(definedCharsBitmapAsLittleEndian.Slice$1(((i * 4) | 0))), i);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360262713)
            
            //--TRIMMABLE-BOUNDARY-START(38655230009)
            /*bool */ IsCharAllowed(/*char*/ value)
            {
                /*nuint*/ let index;
                /*int*/ let offset;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655230009);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$stew.STEW.AllowedBmpCodePointsBitmap._GetIndexAndOffset(value, $.$ref(() => index, ($v) => index = $v, $.$$.S.UIntPtr), $.$ref(() => offset, ($v) => offset = $v, $.$$.S.Int32));
                if ((this.Bitmap[index] & ((1 << offset) >>> 0)) !== 0)
                {
                    return true;
                }
                else 
                {
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38655230009)
            
            //--TRIMMABLE-BOUNDARY-START(42950197305)
            /*bool */ IsCodePointAllowed(/*uint*/ value)
            {
                /*nuint*/ let index;
                /*int*/ let offset;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950197305);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$stew.ST.UnicodeUtility.IsBmpCodePoint(value))
                {
                    return false;
                }
                $.$stew.STEW.AllowedBmpCodePointsBitmap._GetIndexAndOffset(value, $.$ref(() => index, ($v) => index = $v, $.$$.S.UIntPtr), $.$ref(() => offset, ($v) => offset = $v, $.$$.S.Int32));
                if ((this.Bitmap[index] & ((1 << offset) >>> 0)) !== 0)
                {
                    return true;
                }
                else 
                {
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950197305)
            
            //--TRIMMABLE-BOUNDARY-START(4295491641)
            static /*void */ _GetIndexAndOffset(/*uint*/ value, /*out nuint*/ index, /*out int*/ offset)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295491641);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$stew.ST.UnicodeDebug.AssertIsBmpCodePoint(value);
                index.$v = value >>> 5;
                offset.$v = (value | 0) & 31;
            }
            //--TRIMMABLE-BOUNDARY-END(4295491641)
            
            //--TRIMMABLE-BOUNDARY-START(8590458937)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590458937);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590458937)
            
            //--TRIMMABLE-BOUNDARY-START(8590458937)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(8590458937)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                //FixedSizeArray(uint, 2048)
                copy.Bitmap = [...this.Bitmap];
                $.$$.S.Array.CopyMetadata(copy.Bitmap, this.Bitmap)
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(17180393529)
                //FixedSizeArray(uint*, 2048)
                let $t9 = this.Bitmap;
                $.$$.S.Array.AddMetadata($t9, $.$$.S.UInt32.$type, null, null);
                for (let $i = 0; $i < 2048; $i++)
                {
                    $t9[$i] = [];
                }
                //--TRIMMABLE-BOUNDARY-END(17180393529)
                
            }
            static $h = 524345;
            static $z = 8192;
            static $f = 0b10000000000001010000000;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885426233),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 458753
        }
      ],
      "n": "AllowChar",
      "d": 524345,
      "h": 12885426233,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885426233),
//--TRIMMABLE-BOUNDARY-START(25770328121),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 458753
        }
      ],
      "n": "ForbidChar",
      "d": 524345,
      "h": 25770328121,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770328121),
//--TRIMMABLE-BOUNDARY-START(30065295417),
    {
      "r": 65537,
      "n": "ForbidHtmlCharacters",
      "d": 524345,
      "h": 30065295417,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065295417),
//--TRIMMABLE-BOUNDARY-START(34360262713),
    {
      "r": 65537,
      "n": "ForbidUndefinedCharacters",
      "d": 524345,
      "h": 34360262713,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360262713),
//--TRIMMABLE-BOUNDARY-START(38655230009),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 458753
        }
      ],
      "n": "IsCharAllowed",
      "d": 524345,
      "h": 38655230009,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655230009),
//--TRIMMABLE-BOUNDARY-START(42950197305),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 720897
        }
      ],
      "n": "IsCodePointAllowed",
      "d": 524345,
      "h": 42950197305,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950197305),
//--TRIMMABLE-BOUNDARY-START(4295491641),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 720897
        },
        {
          "n": "index",
          "p": 851969,
          "f": 2
        },
        {
          "n": "offset",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "_GetIndexAndOffset",
      "d": 524345,
      "h": 4295491641,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(4295491641)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(21475360825),
    {
      "t": 655361,
      "n": "BitmapLengthInDWords",
      "d": 524345,
      "h": 21475360825,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(21475360825),
//--TRIMMABLE-BOUNDARY-START(17180393529),
    {
      "t": $.$typePointer($.$$.S.UInt32).$h,
      "n": "Bitmap",
      "d": 524345,
      "h": 17180393529,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180393529)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590458937),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 524345,
      "h": 8590458937,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590458937)
  ],
  "h": 524345
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Text.Encodings.Web.AllowedBmpCodePointsBitmap`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Text${separator}Encodings${separator}Web${separator}AllowedBmpCodePointsBitmap`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524345)
        
        

        //--TRIMMABLE-BOUNDARY-START(2031673)
        $asm.$str(`$stew.ST.ValueStringBuilder`, ($self) => class ValueStringBuilder extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(4296998969)
            /*char[]?*/ _arrayToReturnToPool = null;
            //--TRIMMABLE-BOUNDARY-END(4296998969)
            
            //--TRIMMABLE-BOUNDARY-START(8591966265)
            /*Span<char>*/ _chars;
            //--TRIMMABLE-BOUNDARY-END(8591966265)
            
            //--TRIMMABLE-BOUNDARY-START(12886933561)
            /*int*/ _pos = 0;
            //--TRIMMABLE-BOUNDARY-END(12886933561)
            
            //--TRIMMABLE-BOUNDARY-START(25771835449)
            $ctor$4(/*Span<char>*/ initialBuffer)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25771835449);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._arrayToReturnToPool = null;
                    this._chars = initialBuffer;
                    this._pos = 0;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25771835449)
            
            //--TRIMMABLE-BOUNDARY-START(21476868153)
            $ctor$3(/*int*/ initialCapacity)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476868153);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._arrayToReturnToPool = $.$$.SB.ArrayPool$$($.$$.S.Char).Shared.Rent(initialCapacity);
                    this._chars = $.$$.S.Span$$($.$$.S.Char).op_Implicit$2(this._arrayToReturnToPool);
                    this._pos = 0;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476868153)
            
            //--TRIMMABLE-BOUNDARY-START(146030919737)
            /*int */ get Length()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107376214073);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._pos;
            }
            /*int */ set Length(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158915821625);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(value >= 0, "value >= 0");
                $.$$.SD.Debug.Assert$4(value <= this._chars.Length, "value <= _chars.Length");
                this._pos = value;
            }
            //--TRIMMABLE-BOUNDARY-END(146030919737)
            
            //--TRIMMABLE-BOUNDARY-START(73016475705)
            /*int */ get Capacity()
            {
                return this._chars.Length;
            }
            //--TRIMMABLE-BOUNDARY-END(73016475705)
            
            //--TRIMMABLE-BOUNDARY-START(81606410297)
            /*void */ EnsureCapacity(/*int*/ capacity)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81606410297);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(capacity >= 0, "capacity >= 0");
                if ((capacity >>> 0) > (this._chars.Length >>> 0))
                {
                    this.Grow(((capacity - this._pos) | 0));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(81606410297)
            
            //--TRIMMABLE-BOUNDARY-START(120261115961)
            /*ref char */ GetPinnableReference()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120261115961);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.SRI.MemoryMarshal.GetReference$1($.$$.S.Char, this._chars);
            }
            //--TRIMMABLE-BOUNDARY-END(120261115961)
            
            //--TRIMMABLE-BOUNDARY-START(124556083257)
            /*ref char */ GetPinnableReference$1(/*bool*/ terminate)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124556083257);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (terminate)
                {
                    this.EnsureCapacity(((this.Length + 1) | 0));
                    this._chars._reference.SetAt(/*\u0000*/ 0, this.Length);
                }
                return $.$$.SRI.MemoryMarshal.GetReference$1($.$$.S.Char, this._chars);
            }
            //--TRIMMABLE-BOUNDARY-END(124556083257)
            
            //--TRIMMABLE-BOUNDARY-START(163210788921)
            /*ref char*/ get_Item$1(/*int*/ index)
            {
                $.$$.SD.Debug.Assert$4(index < this._pos, "index < _pos");
                return this._chars.get_Item(index);
            }
            //--TRIMMABLE-BOUNDARY-END(163210788921)
            
            //--TRIMMABLE-BOUNDARY-START(167505756217)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167505756217);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let s = this._chars.Slice(0, this._pos).ToString();
                this.Dispose();
                return s;
            }
            //--TRIMMABLE-BOUNDARY-END(167505756217)
            
            //--TRIMMABLE-BOUNDARY-START(150325887033)
            /*Span<char> */ get RawChars()
            {
                return this._chars;
            }
            //--TRIMMABLE-BOUNDARY-END(150325887033)
            
            //--TRIMMABLE-BOUNDARY-START(60131573817)
            /*ReadOnlySpan<char> */ AsSpan$1(/*bool*/ terminate)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131573817);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (terminate)
                {
                    this.EnsureCapacity(((this.Length + 1) | 0));
                    this._chars._reference.SetAt(/*\u0000*/ 0, this.Length);
                }
                return $.$$.S.Span$$($.$$.S.Char).op_Implicit(this._chars.Slice(0, this._pos));
            }
            //--TRIMMABLE-BOUNDARY-END(60131573817)
            
            //--TRIMMABLE-BOUNDARY-START(55836606521)
            /*ReadOnlySpan<char> */ AsSpan()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55836606521);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.Span$$($.$$.S.Char).op_Implicit(this._chars.Slice(0, this._pos));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55836606521)
            
            //--TRIMMABLE-BOUNDARY-START(68721508409)
            /*ReadOnlySpan<char> */ AsSpan$3(/*int*/ start)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68721508409);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.Span$$($.$$.S.Char).op_Implicit(this._chars.Slice(start, ((this._pos - start) | 0)));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68721508409)
            
            //--TRIMMABLE-BOUNDARY-START(64426541113)
            /*ReadOnlySpan<char> */ AsSpan$2(/*int*/ start, /*int*/ length)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64426541113);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.Span$$($.$$.S.Char).op_Implicit(this._chars.Slice(start, length));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64426541113)
            
            //--TRIMMABLE-BOUNDARY-START(171800723513)
            /*bool */ TryCopyTo(/*Span<char>*/ destination, /*out int*/ charsWritten)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171800723513);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._chars.Slice(0, this._pos).TryCopyTo(destination))
                {
                    charsWritten.$v = this._pos;
                    this.Dispose();
                    return true;
                }
                else 
                {
                    charsWritten.$v = 0;
                    this.Dispose();
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(171800723513)
            
            //--TRIMMABLE-BOUNDARY-START(137440985145)
            /*void */ Insert(/*int*/ index, /*char*/ value, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137440985145);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._pos > ((this._chars.Length - count) | 0))
                {
                    this.Grow(count);
                }
                /*int*/ let remaining = ((this._pos - index) | 0);
                this._chars.Slice(index, remaining).CopyTo(this._chars.Slice$1(((index + count) | 0)));
                this._chars.Slice(index, count).Fill(value);
                this._pos += count;
            }
            //--TRIMMABLE-BOUNDARY-END(137440985145)
            
            //--TRIMMABLE-BOUNDARY-START(141735952441)
            /*void */ Insert$1(/*int*/ index, /*string?*/ s)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141735952441);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (s === null)
                {
                    return;
                }
                /*int*/ let count = s.length;
                if (this._pos > (((this._chars.Length - count) | 0)))
                {
                    this.Grow(count);
                }
                /*int*/ let remaining = ((this._pos - index) | 0);
                this._chars.Slice(index, remaining).CopyTo(this._chars.Slice$1(((index + count) | 0)));
                $.$$.S.String.CopyTo$1.call(s, this._chars.Slice$1(index));
                this._pos += count;
            }
            //--TRIMMABLE-BOUNDARY-END(141735952441)
            
            //--TRIMMABLE-BOUNDARY-START(34361770041)
            /*void */ Append$1(/*char*/ c)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361770041);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let pos = this._pos;
                /*Span<char>*/ let chars = this._chars;
                if ((pos >>> 0) < (chars.Length >>> 0))
                {
                    chars._reference.SetAt(c, pos);
                    this._pos = ((pos + 1) | 0);
                }
                else 
                {
                    this.GrowAndAppend(c);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34361770041)
            
            //--TRIMMABLE-BOUNDARY-START(42951704633)
            /*void */ Append$3(/*string?*/ s)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951704633);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (s === null)
                {
                    return;
                }
                /*int*/ let pos = this._pos;
                if (s.length === 1 && (pos >>> 0) < (this._chars.Length >>> 0))
                {
                    this._chars._reference.SetAt($.$$.S.String.get_Chars.call(s, 0), pos);
                    this._pos = ((pos + 1) | 0);
                }
                else 
                {
                    this.AppendSlow(s);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42951704633)
            
            //--TRIMMABLE-BOUNDARY-START(47246671929)
            /*void */ AppendSlow(/*string*/ s)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246671929);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let pos = this._pos;
                if (pos > ((this._chars.Length - s.length) | 0))
                {
                    this.Grow(s.length);
                }
                $.$$.S.String.CopyTo$1.call(s, this._chars.Slice$1(pos));
                this._pos += s.length;
            }
            //--TRIMMABLE-BOUNDARY-END(47246671929)
            
            //--TRIMMABLE-BOUNDARY-START(30066802745)
            /*void */ Append(/*char*/ c, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066802745);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._pos > ((this._chars.Length - count) | 0))
                {
                    this.Grow(count);
                }
                /*Span<char>*/ let dst = this._chars.Slice(this._pos, count);
                for(/*int*/ let i = 0; i < dst.Length; i++)
                {
                    dst._reference.SetAt(c, i);
                }
                this._pos += count;
            }
            //--TRIMMABLE-BOUNDARY-END(30066802745)
            
            //--TRIMMABLE-BOUNDARY-START(38656737337)
            /*void */ Append$2(/*scoped ReadOnlySpan<char>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656737337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let pos = this._pos;
                if (pos > ((this._chars.Length - value.Length) | 0))
                {
                    this.Grow(value.Length);
                }
                value.CopyTo(this._chars.Slice$1(this._pos));
                this._pos += value.Length;
            }
            //--TRIMMABLE-BOUNDARY-END(38656737337)
            
            //--TRIMMABLE-BOUNDARY-START(51541639225)
            /*Span<char> */ AppendSpan(/*int*/ length)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541639225);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let origPos = this._pos;
                if (origPos > ((this._chars.Length - length) | 0))
                {
                    this.Grow(length);
                }
                this._pos = ((origPos + length) | 0);
                return this._chars.Slice(origPos, length);
            }
            //--TRIMMABLE-BOUNDARY-END(51541639225)
            
            //--TRIMMABLE-BOUNDARY-START(133146017849)
            /*void */ GrowAndAppend(/*char*/ c)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133146017849);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Grow(1);
                this.Append$1(c);
            }
            //--TRIMMABLE-BOUNDARY-END(133146017849)
            
            //--TRIMMABLE-BOUNDARY-START(128851050553)
            /*void */ Grow(/*int*/ additionalCapacityBeyondPos)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128851050553);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(additionalCapacityBeyondPos > 0, "additionalCapacityBeyondPos > 0");
                $.$$.SD.Debug.Assert$4(this._pos > ((this._chars.Length - additionalCapacityBeyondPos) | 0), "Grow called incorrectly, no resize is needed.");
                /*uint*/ let ArrayMaxLength = 2147483591;
                /*int*/ let newCapacity = ($.$$.S.Math.Max$10(((((this._pos + additionalCapacityBeyondPos) | 0)) >>> 0), $.$$.S.Math.Min$10((((this._chars.Length >>> 0) * 2) >>> 0), ArrayMaxLength)) | 0);
                /*char[]*/ let poolArray = $.$$.SB.ArrayPool$$($.$$.S.Char).Shared.Rent(newCapacity);
                this._chars.Slice(0, this._pos).CopyTo($.$$.S.Span$$($.$$.S.Char).op_Implicit$2(poolArray));
                /*char[]?*/ let toReturn = this._arrayToReturnToPool;
                this._chars = $.$$.S.Span$$($.$$.S.Char).op_Implicit$2(this._arrayToReturnToPool = poolArray);
                if (toReturn !== null)
                {
                    $.$$.SB.ArrayPool$$($.$$.S.Char).Shared.Return(toReturn, false);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(128851050553)
            
            //--TRIMMABLE-BOUNDARY-START(77311443001)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77311443001);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*char[]?*/ let toReturn = this._arrayToReturnToPool;
                new $.$stew.ST.ValueStringBuilder().$clone(this);
                if (toReturn !== null)
                {
                    $.$$.SB.ArrayPool$$($.$$.S.Char).Shared.Return(toReturn, false);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77311443001)
            
            //--TRIMMABLE-BOUNDARY-START(17181900857)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181900857);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181900857)
            
            //--TRIMMABLE-BOUNDARY-START(17181900857)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(17181900857)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._arrayToReturnToPool = this._arrayToReturnToPool;
                copy._chars = this._chars.$clone();
                copy._pos = this._pos;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(8591966265)
                this._chars = $.$default($.$$.S.Span$$($.$$.S.Char));
                //--TRIMMABLE-BOUNDARY-END(8591966265)
                
            }
            static $h = 2031673;
            static $z = 14;
            static $f = 0b1010000000;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(146030919737),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107376214073,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 158915821625,
        "f": 83886081
      },
      "n": "Length",
      "d": 2031673,
      "h": 146030919737,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(146030919737),
//--TRIMMABLE-BOUNDARY-START(73016475705),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90196344889,
        "f": 50331649
      },
      "n": "Capacity",
      "d": 2031673,
      "h": 73016475705,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73016475705),
//--TRIMMABLE-BOUNDARY-START(163210788921),
    {
      "p": 458753,
      "i": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 98786279481,
        "f": 50331649
      },
      "n": "Item",
      "o": "@$1",
      "d": 2031673,
      "h": 163210788921,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(163210788921),
//--TRIMMABLE-BOUNDARY-START(150325887033),
    {
      "p": $.$$.S.Span$$($.$$.S.Char).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115966148665,
        "f": 50331649
      },
      "n": "RawChars",
      "d": 2031673,
      "h": 150325887033,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(150325887033)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(81606410297),
    {
      "r": 65537,
      "p": [
        {
          "n": "capacity",
          "p": 655361
        }
      ],
      "n": "EnsureCapacity",
      "d": 2031673,
      "h": 81606410297,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(81606410297),
//--TRIMMABLE-BOUNDARY-START(120261115961),
    {
      "r": 458753,
      "n": "GetPinnableReference",
      "d": 2031673,
      "h": 120261115961,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(120261115961),
//--TRIMMABLE-BOUNDARY-START(124556083257),
    {
      "r": 458753,
      "p": [
        {
          "n": "terminate",
          "p": 262145
        }
      ],
      "n": "GetPinnableReference",
      "o": "@$1",
      "d": 2031673,
      "h": 124556083257,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(124556083257),
//--TRIMMABLE-BOUNDARY-START(167505756217),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 2031673,
      "h": 167505756217,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(167505756217),
//--TRIMMABLE-BOUNDARY-START(60131573817),
    {
      "r": $.$$.S.ReadOnlySpan$$($.$$.S.Char).$h,
      "p": [
        {
          "n": "terminate",
          "p": 262145
        }
      ],
      "n": "AsSpan",
      "o": "@$1",
      "d": 2031673,
      "h": 60131573817,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60131573817),
//--TRIMMABLE-BOUNDARY-START(55836606521),
    {
      "r": $.$$.S.ReadOnlySpan$$($.$$.S.Char).$h,
      "n": "AsSpan",
      "d": 2031673,
      "h": 55836606521,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55836606521),
//--TRIMMABLE-BOUNDARY-START(68721508409),
    {
      "r": $.$$.S.ReadOnlySpan$$($.$$.S.Char).$h,
      "p": [
        {
          "n": "start",
          "p": 655361
        }
      ],
      "n": "AsSpan",
      "o": "@$3",
      "d": 2031673,
      "h": 68721508409,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68721508409),
//--TRIMMABLE-BOUNDARY-START(64426541113),
    {
      "r": $.$$.S.ReadOnlySpan$$($.$$.S.Char).$h,
      "p": [
        {
          "n": "start",
          "p": 655361
        },
        {
          "n": "length",
          "p": 655361
        }
      ],
      "n": "AsSpan",
      "o": "@$2",
      "d": 2031673,
      "h": 64426541113,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64426541113),
//--TRIMMABLE-BOUNDARY-START(171800723513),
    {
      "r": 262145,
      "p": [
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Char).$h
        },
        {
          "n": "charsWritten",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryCopyTo",
      "d": 2031673,
      "h": 171800723513,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(171800723513),
//--TRIMMABLE-BOUNDARY-START(137440985145),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "value",
          "p": 458753
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Insert",
      "d": 2031673,
      "h": 137440985145,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(137440985145),
//--TRIMMABLE-BOUNDARY-START(141735952441),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "s",
          "p": 1310721
        }
      ],
      "n": "Insert",
      "o": "@$1",
      "d": 2031673,
      "h": 141735952441,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(141735952441),
//--TRIMMABLE-BOUNDARY-START(34361770041),
    {
      "r": 65537,
      "p": [
        {
          "n": "c",
          "p": 458753
        }
      ],
      "n": "Append",
      "o": "@$1",
      "d": 2031673,
      "h": 34361770041,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34361770041),
//--TRIMMABLE-BOUNDARY-START(42951704633),
    {
      "r": 65537,
      "p": [
        {
          "n": "s",
          "p": 1310721
        }
      ],
      "n": "Append",
      "o": "@$3",
      "d": 2031673,
      "h": 42951704633,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42951704633),
//--TRIMMABLE-BOUNDARY-START(47246671929),
    {
      "r": 65537,
      "p": [
        {
          "n": "s",
          "p": 1310721
        }
      ],
      "n": "AppendSlow",
      "d": 2031673,
      "h": 47246671929,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(47246671929),
//--TRIMMABLE-BOUNDARY-START(30066802745),
    {
      "r": 65537,
      "p": [
        {
          "n": "c",
          "p": 458753
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Append",
      "d": 2031673,
      "h": 30066802745,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066802745),
//--TRIMMABLE-BOUNDARY-START(38656737337),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Char).$h
        }
      ],
      "n": "Append",
      "o": "@$2",
      "d": 2031673,
      "h": 38656737337,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38656737337),
//--TRIMMABLE-BOUNDARY-START(51541639225),
    {
      "r": $.$$.S.Span$$($.$$.S.Char).$h,
      "p": [
        {
          "n": "length",
          "p": 655361
        }
      ],
      "n": "AppendSpan",
      "d": 2031673,
      "h": 51541639225,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51541639225),
//--TRIMMABLE-BOUNDARY-START(133146017849),
    {
      "r": 65537,
      "p": [
        {
          "n": "c",
          "p": 458753
        }
      ],
      "n": "GrowAndAppend",
      "d": 2031673,
      "h": 133146017849,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(133146017849),
//--TRIMMABLE-BOUNDARY-START(128851050553),
    {
      "r": 65537,
      "p": [
        {
          "n": "additionalCapacityBeyondPos",
          "p": 655361
        }
      ],
      "n": "Grow",
      "d": 2031673,
      "h": 128851050553,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(128851050553),
//--TRIMMABLE-BOUNDARY-START(77311443001),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 2031673,
      "h": 77311443001,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77311443001)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296998969),
    {
      "t": $.$typeArray($.$$.S.Char).$h,
      "n": "_arrayToReturnToPool",
      "d": 2031673,
      "h": 4296998969,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296998969),
//--TRIMMABLE-BOUNDARY-START(8591966265),
    {
      "t": $.$$.S.Span$$($.$$.S.Char).$h,
      "n": "_chars",
      "d": 2031673,
      "h": 8591966265,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591966265),
//--TRIMMABLE-BOUNDARY-START(12886933561),
    {
      "t": 655361,
      "n": "_pos",
      "d": 2031673,
      "h": 12886933561,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886933561)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25771835449),
    {
      "p": [
        {
          "n": "initialBuffer",
          "p": $.$$.S.Span$$($.$$.S.Char).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 2031673,
      "h": 25771835449,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771835449),
//--TRIMMABLE-BOUNDARY-START(21476868153),
    {
      "p": [
        {
          "n": "initialCapacity",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2031673,
      "h": 21476868153,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476868153),
//--TRIMMABLE-BOUNDARY-START(17181900857),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2031673,
      "h": 17181900857,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181900857)
  ],
  "h": 2031673
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Text.ValueStringBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Text${separator}ValueStringBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2031673)
        
        

        //--TRIMMABLE-BOUNDARY-START(917561)
        $asm.$cls(`$stew.STEW.DefaultUrlEncoder`, ($self) => class DefaultUrlEncoder extends $.$stew.STEW.UrlEncoder
        {
            //--TRIMMABLE-BOUNDARY-START(17180786745)
            /*DefaultUrlEncoder*/ static BasicLatinSingleton = null;
            //--TRIMMABLE-BOUNDARY-END(17180786745)
            
            //--TRIMMABLE-BOUNDARY-START(4295884857)
            /*OptimizedInboxTextEncoder*/ _innerEncoder = null;
            //--TRIMMABLE-BOUNDARY-END(4295884857)
            
            //--TRIMMABLE-BOUNDARY-START(12885819449)
            $ctor$3(/*TextEncoderSettings*/ settings)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885819449);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (settings === null)
                    {
                        $.$stew.STEW.ThrowHelper.ThrowArgumentNullException(1/*ExceptionArgument.settings*/);
                    }
                    this._innerEncoder = new $.$stew.STEW.OptimizedInboxTextEncoder().$ctor$1($.$stew.STEW.DefaultUrlEncoder.EscaperImplementation.Singleton, settings.GetAllowedCodePointsBitmap(), true, $.$$.S.ReadOnlySpan$$($.$$.S.Char).op_Implicit$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Char), [/* */ 32, /*#*/ 35, /*%*/ 37, /*/*/ 47, /*:*/ 58, /*=*/ 61, /*?*/ 63, /*[*/ 91, /*\\*/ 92, /*]*/ 93, /*^*/ 94, /*`*/ 96, /*{*/ 123, /*|*/ 124, /*}*/ 125, /*\uFFF0*/ 65520, /*\uFFF1*/ 65521, /*\uFFF2*/ 65522, /*\uFFF3*/ 65523, /*\uFFF4*/ 65524, /*\uFFF5*/ 65525, /*\uFFF6*/ 65526, /*\uFFF7*/ 65527, /*\uFFF8*/ 65528, /*\uFFF9*/ 65529, /*\uFFFA*/ 65530, /*\uFFFB*/ 65531, /*\uFFFC*/ 65532, /*\uFFFD*/ 65533, /*\uFFFE*/ 65534, /*\uFFFF*/ 65535], null, null)));
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885819449)
            
            //--TRIMMABLE-BOUNDARY-START(51540525113)
            /*int */ get MaxOutputCharactersPerInputCharacter()
            {
                return 9;
            }
            //--TRIMMABLE-BOUNDARY-END(51540525113)
            
            //--TRIMMABLE-BOUNDARY-START(21475754041)
            /*OperationStatus */ EncodeCore$1(/*ReadOnlySpan<char>*/ source, /*Span<char>*/ destination, /*out int*/ charsConsumed, /*out int*/ charsWritten, /*bool*/ isFinalBlock)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475754041);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._innerEncoder.Encode(source, destination, charsConsumed, charsWritten, isFinalBlock);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475754041)
            
            //--TRIMMABLE-BOUNDARY-START(25770721337)
            /*OperationStatus */ EncodeUtf8Core(/*ReadOnlySpan<byte>*/ utf8Source, /*Span<byte>*/ utf8Destination, /*out int*/ bytesConsumed, /*out int*/ bytesWritten, /*bool*/ isFinalBlock)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770721337);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._innerEncoder.EncodeUtf8(utf8Source, utf8Destination, bytesConsumed, bytesWritten, isFinalBlock);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770721337)
            
            //--TRIMMABLE-BOUNDARY-START(34360655929)
            /*int */ FindFirstCharacterToEncode$1(/*ReadOnlySpan<char>*/ text)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360655929);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._innerEncoder.GetIndexOfFirstCharToEncode(text);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360655929)
            
            //--TRIMMABLE-BOUNDARY-START(30065688633)
            /*int */ FindFirstCharacterToEncode(/*char**/ text, /*int*/ textLength)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065688633);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._innerEncoder.FindFirstCharacterToEncode(text, textLength);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065688633)
            
            //--TRIMMABLE-BOUNDARY-START(38655623225)
            /*int */ FindFirstCharacterToEncodeUtf8(/*ReadOnlySpan<byte>*/ utf8Text)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655623225);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._innerEncoder.GetIndexOfFirstByteToEncode(utf8Text);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38655623225)
            
            //--TRIMMABLE-BOUNDARY-START(55835492409)
            /*bool */ TryEncodeUnicodeScalar(/*int*/ unicodeScalar, /*char**/ buffer, /*int*/ bufferLength, /*out int*/ numberOfCharactersWritten)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55835492409);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._innerEncoder.TryEncodeUnicodeScalar(unicodeScalar, buffer, bufferLength, numberOfCharactersWritten);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55835492409)
            
            //--TRIMMABLE-BOUNDARY-START(60130459705)
            /*bool */ WillEncode(/*int*/ unicodeScalar)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60130459705);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return !this._innerEncoder.IsScalarValueAllowed(new $.$$.ST.Rune().$ctor$5(unicodeScalar));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60130459705)
            
            //--TRIMMABLE-BOUNDARY-START(983097)
            static $_EscaperImplementation;
            static get EscaperImplementation()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(983097);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$stew.STEW.DefaultUrlEncoder;
                return $cls.$_EscaperImplementation ??= $asm.$ncls(`$stew.STEW.DefaultUrlEncoder.EscaperImplementation`, ($self) => class EscaperImplementation extends $.$stew.STEW.ScalarEscaperBase
                {
                    //--TRIMMABLE-BOUNDARY-START(21475819577)
                    /*EscaperImplementation*/ static Singleton = null;
                    //--TRIMMABLE-BOUNDARY-END(21475819577)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590917689)
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8590917689);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590917689)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180852281)
                    /*int */ EncodeUtf8(/*Rune*/ value, /*Span<byte>*/ destination)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17180852281);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*uint*/ let utf8lsb;
                        let $gotoJumpState6 = 0;
                        $gotoJumpStart6: while(true)
                        {
                            switch($gotoJumpState6)
                            {
                                case 0:
                                {
                                    utf8lsb = ($.$stew.STU.UnicodeHelpers.GetUtf8RepresentationForScalarValue((value.Value >>> 0)) >>> 0);
                                    if ((destination.Length >>> 0) <= 2)
                                    {
                                        $gotoJumpState6 = 1; /*goto OutOfSpace*/
                                        continue $gotoJumpStart6;
                                    }
                                    destination._reference.SetAt(/*%*/ 37, 0);
                                    $.$stew.S.HexConverter.ToBytesBuffer(((utf8lsb & 0xFF) >>> 0), destination, 1, 0);
                                    if ((utf8lsb >>= 8) === 0)
                                    {
                                        return 3;
                                    }
                                    if ((destination.Length >>> 0) <= 5)
                                    {
                                        $gotoJumpState6 = 1; /*goto OutOfSpace*/
                                        continue $gotoJumpStart6;
                                    }
                                    destination._reference.SetAt(/*%*/ 37, 3);
                                    $.$stew.S.HexConverter.ToBytesBuffer(((utf8lsb & 0xFF) >>> 0), destination, 4, 0);
                                    if ((utf8lsb >>= 8) === 0)
                                    {
                                        return 6;
                                    }
                                    if ((destination.Length >>> 0) <= 8)
                                    {
                                        $gotoJumpState6 = 1; /*goto OutOfSpace*/
                                        continue $gotoJumpStart6;
                                    }
                                    destination._reference.SetAt(/*%*/ 37, 6);
                                    $.$stew.S.HexConverter.ToBytesBuffer(((utf8lsb & 0xFF) >>> 0), destination, 7, 0);
                                    if ((utf8lsb >>= 8) === 0)
                                    {
                                        return 9;
                                    }
                                    if ((destination.Length >>> 0) <= 11)
                                    {
                                        $gotoJumpState6 = 1; /*goto OutOfSpace*/
                                        continue $gotoJumpStart6;
                                    }
                                    destination._reference.SetAt(/*%*/ 37, 9);
                                    $.$stew.S.HexConverter.ToBytesBuffer(((utf8lsb & 0xFF) >>> 0), destination, 10, 0);
                                    return 12;
                                }
                                case 1: /*OutOfSpace*/
                                return -1;
                            }
                            break;
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180852281)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885884985)
                    /*int */ EncodeUtf16(/*Rune*/ value, /*Span<char>*/ destination)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12885884985);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*uint*/ let utf8lsb;
                        let $gotoJumpState7 = 0;
                        $gotoJumpStart7: while(true)
                        {
                            switch($gotoJumpState7)
                            {
                                case 0:
                                {
                                    utf8lsb = ($.$stew.STU.UnicodeHelpers.GetUtf8RepresentationForScalarValue((value.Value >>> 0)) >>> 0);
                                    if ((destination.Length >>> 0) <= 2)
                                    {
                                        $gotoJumpState7 = 1; /*goto OutOfSpace*/
                                        continue $gotoJumpStart7;
                                    }
                                    destination._reference.SetAt(/*%*/ 37, 0);
                                    $.$stew.S.HexConverter.ToCharsBuffer(((utf8lsb & 0xFF) >>> 0), destination, 1, 0);
                                    if ((utf8lsb >>= 8) === 0)
                                    {
                                        return 3;
                                    }
                                    if ((destination.Length >>> 0) <= 5)
                                    {
                                        $gotoJumpState7 = 1; /*goto OutOfSpace*/
                                        continue $gotoJumpStart7;
                                    }
                                    destination._reference.SetAt(/*%*/ 37, 3);
                                    $.$stew.S.HexConverter.ToCharsBuffer(((utf8lsb & 0xFF) >>> 0), destination, 4, 0);
                                    if ((utf8lsb >>= 8) === 0)
                                    {
                                        return 6;
                                    }
                                    if ((destination.Length >>> 0) <= 8)
                                    {
                                        $gotoJumpState7 = 1; /*goto OutOfSpace*/
                                        continue $gotoJumpStart7;
                                    }
                                    destination._reference.SetAt(/*%*/ 37, 6);
                                    $.$stew.S.HexConverter.ToCharsBuffer(((utf8lsb & 0xFF) >>> 0), destination, 7, 0);
                                    if ((utf8lsb >>= 8) === 0)
                                    {
                                        return 9;
                                    }
                                    if ((destination.Length >>> 0) <= 11)
                                    {
                                        $gotoJumpState7 = 1; /*goto OutOfSpace*/
                                        continue $gotoJumpStart7;
                                    }
                                    destination._reference.SetAt(/*%*/ 37, 9);
                                    $.$stew.S.HexConverter.ToCharsBuffer(((utf8lsb & 0xFF) >>> 0), destination, 10, 0);
                                    return 12;
                                }
                                case 1: /*OutOfSpace*/
                                return -1;
                            }
                            break;
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885884985)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590917689)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590917689)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295950393)
                    //Static Initializer
                    static $sinit()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4295950393);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        {
                            //--TRIMMABLE-BOUNDARY-START(21475819577)
                            this.Singleton = new $.$stew.STEW.DefaultUrlEncoder.EscaperImplementation().$ctor$2();
                            //--TRIMMABLE-BOUNDARY-END(21475819577)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295950393)
                    
                    static $h = 983097;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$stew.STEW.ScalarEscaperBase; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180852281),
    {
      "r": 655361,
      "p": [
        {
          "n": "value",
          "p": 167641089
        },
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        }
      ],
      "n": "EncodeUtf8",
      "d": 983097,
      "h": 17180852281,
      "f": 16809992
    },
//--TRIMMABLE-BOUNDARY-END(17180852281),
//--TRIMMABLE-BOUNDARY-START(12885884985),
    {
      "r": 655361,
      "p": [
        {
          "n": "value",
          "p": 167641089
        },
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Char).$h
        }
      ],
      "n": "EncodeUtf16",
      "d": 983097,
      "h": 12885884985,
      "f": 16809992
    },
//--TRIMMABLE-BOUNDARY-END(12885884985)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(21475819577),
    {
      "t": 983097,
      "n": "Singleton",
      "d": 983097,
      "h": 21475819577,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(21475819577)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590917689),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 983097,
      "h": 8590917689,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(8590917689)
  ],
  "d": 917561,
  "h": 983097
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Text.Encodings.Web.DefaultUrlEncoder+EscaperImplementation`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Text${separator}Encodings${separator}Web${separator}DefaultUrlEncoder${separator}EscaperImplementation`; }
                }, $cls, ($v) => $cls.$_EscaperImplementation = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(983097)
            
            //--TRIMMABLE-BOUNDARY-START(8590852153)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590852153);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(17180786745)
                    this.BasicLatinSingleton = new $.$stew.STEW.DefaultUrlEncoder().$ctor$3(new $.$stew.STEW.TextEncoderSettings().$ctor$2($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stew.STU.UnicodeRange), [ $.$stew.STU.UnicodeRanges.BasicLatin ], null, null)));
                    //--TRIMMABLE-BOUNDARY-END(17180786745)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590852153)
            
            static $h = 917561;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$stew.STEW.UrlEncoder; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51540525113),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245557817,
        "f": 50364417
      },
      "n": "MaxOutputCharactersPerInputCharacter",
      "d": 917561,
      "h": 51540525113,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(51540525113)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21475754041),
    {
      "r": 50200577,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Char).$h
        },
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Char).$h
        },
        {
          "n": "charsConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "charsWritten",
          "p": 655361,
          "f": 2
        },
        {
          "n": "isFinalBlock",
          "p": 262145
        }
      ],
      "n": "EncodeCore",
      "o": "@$1",
      "d": 917561,
      "h": 21475754041,
      "f": 16809984
    },
//--TRIMMABLE-BOUNDARY-END(21475754041),
//--TRIMMABLE-BOUNDARY-START(25770721337),
    {
      "r": 50200577,
      "p": [
        {
          "n": "utf8Source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "utf8Destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "bytesWritten",
          "p": 655361,
          "f": 2
        },
        {
          "n": "isFinalBlock",
          "p": 262145
        }
      ],
      "n": "EncodeUtf8Core",
      "d": 917561,
      "h": 25770721337,
      "f": 16809984
    },
//--TRIMMABLE-BOUNDARY-END(25770721337),
//--TRIMMABLE-BOUNDARY-START(34360655929),
    {
      "r": 655361,
      "p": [
        {
          "n": "text",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Char).$h
        }
      ],
      "n": "FindFirstCharacterToEncode",
      "o": "@$1",
      "d": 917561,
      "h": 34360655929,
      "f": 16809984
    },
//--TRIMMABLE-BOUNDARY-END(34360655929),
//--TRIMMABLE-BOUNDARY-START(30065688633),
    {
      "r": 655361,
      "p": [
        {
          "n": "text",
          "p": $.$typePointer($.$$.S.Char).$h
        },
        {
          "n": "textLength",
          "p": 655361
        }
      ],
      "n": "FindFirstCharacterToEncode",
      "d": 917561,
      "h": 30065688633,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30065688633),
//--TRIMMABLE-BOUNDARY-START(38655623225),
    {
      "r": 655361,
      "p": [
        {
          "n": "utf8Text",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        }
      ],
      "n": "FindFirstCharacterToEncodeUtf8",
      "d": 917561,
      "h": 38655623225,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38655623225),
//--TRIMMABLE-BOUNDARY-START(55835492409),
    {
      "r": 262145,
      "p": [
        {
          "n": "unicodeScalar",
          "p": 655361
        },
        {
          "n": "buffer",
          "p": $.$typePointer($.$$.S.Char).$h
        },
        {
          "n": "bufferLength",
          "p": 655361
        },
        {
          "n": "numberOfCharactersWritten",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryEncodeUnicodeScalar",
      "d": 917561,
      "h": 55835492409,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(55835492409),
//--TRIMMABLE-BOUNDARY-START(60130459705),
    {
      "r": 262145,
      "p": [
        {
          "n": "unicodeScalar",
          "p": 655361
        }
      ],
      "n": "WillEncode",
      "d": 917561,
      "h": 60130459705,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(60130459705)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180786745),
    {
      "t": 917561,
      "n": "BasicLatinSingleton",
      "d": 917561,
      "h": 17180786745,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(17180786745),
//--TRIMMABLE-BOUNDARY-START(4295884857),
    {
      "t": 1245241,
      "n": "_innerEncoder",
      "d": 917561,
      "h": 4295884857,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295884857)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885819449),
    {
      "p": [
        {
          "n": "settings",
          "p": 1507385
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 917561,
      "h": 12885819449,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(12885819449)
  ],
  "h": 917561
}; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$stew.STEW.DefaultUrlEncoder.EscaperImplementation ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Text.Encodings.Web.DefaultUrlEncoder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Text${separator}Encodings${separator}Web${separator}DefaultUrlEncoder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(917561)
        
        

        //--TRIMMABLE-BOUNDARY-START(786489)
        $asm.$cls(`$stew.STEW.DefaultJavaScriptEncoder`, ($self) => class DefaultJavaScriptEncoder extends $.$stew.STEW.JavaScriptEncoder
        {
            //--TRIMMABLE-BOUNDARY-START(21475622969)
            /*DefaultJavaScriptEncoder*/ static BasicLatinSingleton = null;
            //--TRIMMABLE-BOUNDARY-END(21475622969)
            
            //--TRIMMABLE-BOUNDARY-START(64425295929)
            /*DefaultJavaScriptEncoder*/ static UnsafeRelaxedEscapingSingleton = null;
            //--TRIMMABLE-BOUNDARY-END(64425295929)
            
            //--TRIMMABLE-BOUNDARY-START(4295753785)
            /*OptimizedInboxTextEncoder*/ _innerEncoder = null;
            //--TRIMMABLE-BOUNDARY-END(4295753785)
            
            //--TRIMMABLE-BOUNDARY-START(17180655673)
            $ctor$4(/*TextEncoderSettings*/ settings)
            {
                this.$ctor$3(settings, false);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180655673);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180655673)
            
            //--TRIMMABLE-BOUNDARY-START(12885688377)
            $ctor$3(/*TextEncoderSettings*/ settings, /*bool*/ allowMinimalJsonEscaping)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885688377);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (settings === null)
                    {
                        $.$stew.STEW.ThrowHelper.ThrowArgumentNullException(1/*ExceptionArgument.settings*/);
                    }
                    this._innerEncoder = allowMinimalJsonEscaping ? new $.$stew.STEW.OptimizedInboxTextEncoder().$ctor$1($.$stew.STEW.DefaultJavaScriptEncoder.EscaperImplementation.SingletonMinimallyEscaped, settings.GetAllowedCodePointsBitmap(), false, $.$$.S.ReadOnlySpan$$($.$$.S.Char).op_Implicit$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Char), [/*\"*/ 34, /*\\*/ 92], null, null))) : new $.$stew.STEW.OptimizedInboxTextEncoder().$ctor$1($.$stew.STEW.DefaultJavaScriptEncoder.EscaperImplementation.Singleton, settings.GetAllowedCodePointsBitmap(), true, $.$$.S.ReadOnlySpan$$($.$$.S.Char).op_Implicit$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Char), [/*\\*/ 92, /*`*/ 96], null, null)));
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885688377)
            
            //--TRIMMABLE-BOUNDARY-START(55835361337)
            /*int */ get MaxOutputCharactersPerInputCharacter()
            {
                return 6;
            }
            //--TRIMMABLE-BOUNDARY-END(55835361337)
            
            //--TRIMMABLE-BOUNDARY-START(25770590265)
            /*OperationStatus */ EncodeCore$1(/*ReadOnlySpan<char>*/ source, /*Span<char>*/ destination, /*out int*/ charsConsumed, /*out int*/ charsWritten, /*bool*/ isFinalBlock)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770590265);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._innerEncoder.Encode(source, destination, charsConsumed, charsWritten, isFinalBlock);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770590265)
            
            //--TRIMMABLE-BOUNDARY-START(30065557561)
            /*OperationStatus */ EncodeUtf8Core(/*ReadOnlySpan<byte>*/ utf8Source, /*Span<byte>*/ utf8Destination, /*out int*/ bytesConsumed, /*out int*/ bytesWritten, /*bool*/ isFinalBlock)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065557561);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._innerEncoder.EncodeUtf8(utf8Source, utf8Destination, bytesConsumed, bytesWritten, isFinalBlock);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065557561)
            
            //--TRIMMABLE-BOUNDARY-START(38655492153)
            /*int */ FindFirstCharacterToEncode$1(/*ReadOnlySpan<char>*/ text)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655492153);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._innerEncoder.GetIndexOfFirstCharToEncode(text);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38655492153)
            
            //--TRIMMABLE-BOUNDARY-START(34360524857)
            /*int */ FindFirstCharacterToEncode(/*char**/ text, /*int*/ textLength)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360524857);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._innerEncoder.FindFirstCharacterToEncode(text, textLength);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360524857)
            
            //--TRIMMABLE-BOUNDARY-START(42950459449)
            /*int */ FindFirstCharacterToEncodeUtf8(/*ReadOnlySpan<byte>*/ utf8Text)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950459449);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._innerEncoder.GetIndexOfFirstByteToEncode(utf8Text);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950459449)
            
            //--TRIMMABLE-BOUNDARY-START(60130328633)
            /*bool */ TryEncodeUnicodeScalar(/*int*/ unicodeScalar, /*char**/ buffer, /*int*/ bufferLength, /*out int*/ numberOfCharactersWritten)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60130328633);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._innerEncoder.TryEncodeUnicodeScalar(unicodeScalar, buffer, bufferLength, numberOfCharactersWritten);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60130328633)
            
            //--TRIMMABLE-BOUNDARY-START(68720263225)
            /*bool */ WillEncode(/*int*/ unicodeScalar)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68720263225);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return !this._innerEncoder.IsScalarValueAllowed(new $.$$.ST.Rune().$ctor$5(unicodeScalar));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68720263225)
            
            //--TRIMMABLE-BOUNDARY-START(852025)
            static $_EscaperImplementation;
            static get EscaperImplementation()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(852025);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$stew.STEW.DefaultJavaScriptEncoder;
                return $cls.$_EscaperImplementation ??= $asm.$ncls(`$stew.STEW.DefaultJavaScriptEncoder.EscaperImplementation`, ($self) => class EscaperImplementation extends $.$stew.STEW.ScalarEscaperBase
                {
                    //--TRIMMABLE-BOUNDARY-START(25770655801)
                    /*EscaperImplementation*/ static Singleton = null;
                    //--TRIMMABLE-BOUNDARY-END(25770655801)
                    
                    //--TRIMMABLE-BOUNDARY-START(30065623097)
                    /*EscaperImplementation*/ static SingletonMinimallyEscaped = null;
                    //--TRIMMABLE-BOUNDARY-END(30065623097)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295819321)
                    /*AsciiByteMap*/ _preescapedMap;
                    //--TRIMMABLE-BOUNDARY-END(4295819321)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885753913)
                    $ctor$2(/*bool*/ allowMinimalEscaping)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(12885753913);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._preescapedMap.InsertAsciiChar(/*\u0008*/ 8, /*b*/ 98);
                            this._preescapedMap.InsertAsciiChar(/*\t*/ 9, /*t*/ 116);
                            this._preescapedMap.InsertAsciiChar(/*\n*/ 10, /*n*/ 110);
                            this._preescapedMap.InsertAsciiChar(/*\u000C*/ 12, /*f*/ 102);
                            this._preescapedMap.InsertAsciiChar(/*\r*/ 13, /*r*/ 114);
                            this._preescapedMap.InsertAsciiChar(/*\\*/ 92, /*\\*/ 92);
                            if (allowMinimalEscaping)
                            {
                                this._preescapedMap.InsertAsciiChar(/*\"*/ 34, /*\"*/ 34);
                            }
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885753913)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475688505)
                    /*int */ EncodeUtf8(/*Rune*/ value, /*Span<byte>*/ destination)
                    {
                        /*byte*/ let preescapedForm;
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21475688505);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._preescapedMap.TryLookup(value, $.$ref(() => preescapedForm, ($v) => preescapedForm = $v, $.$$.S.Byte)))
                        {
                            let $gotoJumpState7 = 0;
                            $gotoJumpStart7: while(true)
                            {
                                switch($gotoJumpState7)
                                {
                                    case 0:
                                    {
                                        if ((destination.Length >>> 0) <= 1)
                                        {
                                            $gotoJumpState7 = 1; /*goto OutOfSpace*/
                                            continue $gotoJumpStart7;
                                        }
                                        destination._reference.SetAt(/*\\*/ 92, 0);
                                        destination._reference.SetAt(preescapedForm, 1);
                                        return 2;
                                    }
                                    case 1: /*OutOfSpace*/
                                    return -1;
                                }
                                break;
                            }
                        }
                        return TryEncodeScalarAsHex(this, value, destination);
                        /*static int*/  function TryEncodeScalarAsHex(/*object*/ $this, /*Rune*/ value, /*Span<byte>*/ destination)
                        {
                            let $gotoJumpState8 = 0;
                            $gotoJumpStart8: while(true)
                            {
                                switch($gotoJumpState8)
                                {
                                    case 0:
                                    {
                                        if (value.IsBmp)
                                        {
                                            if ((destination.Length >>> 0) <= 5)
                                            {
                                                $gotoJumpState8 = 1; /*goto OutOfSpaceInner*/
                                                continue $gotoJumpStart8;
                                            }
                                            destination._reference.SetAt(/*\\*/ 92, 0);
                                            destination._reference.SetAt(/*u*/ 117, 1);
                                            $.$stew.S.HexConverter.ToBytesBuffer($.$cast(value.Value, $.$$.S.Byte), destination, 4, 0);
                                            $.$stew.S.HexConverter.ToBytesBuffer(((((value.Value >>> 0) >>> 8) & 0xFF) >>> 0), destination, 2, 0);
                                            return 6;
                                        }
                                        else 
                                        {
                                            /*char*/ var highSurrogate;
                                            /*char*/ var lowSurrogate;
                                            $.$stew.STU.UnicodeHelpers.GetUtf16SurrogatePairFromAstralScalarValue((value.Value >>> 0), $.$ref(() => highSurrogate, ($v) => highSurrogate = $v, $.$$.S.Char), $.$ref(() => lowSurrogate, ($v) => lowSurrogate = $v, $.$$.S.Char));
                                            if ((destination.Length >>> 0) <= 11)
                                            {
                                                $gotoJumpState8 = 1; /*goto OutOfSpaceInner*/
                                                continue $gotoJumpStart8;
                                            }
                                            destination._reference.SetAt(/*\\*/ 92, 0);
                                            destination._reference.SetAt(/*u*/ 117, 1);
                                            $.$stew.S.HexConverter.ToBytesBuffer(((highSurrogate & 0xFF) >>> 0), destination, 4, 0);
                                            $.$stew.S.HexConverter.ToBytesBuffer((((highSurrogate >>> 8) & 0xFF) >>> 0), destination, 2, 0);
                                            destination._reference.SetAt(/*\\*/ 92, 6);
                                            destination._reference.SetAt(/*u*/ 117, 7);
                                            $.$stew.S.HexConverter.ToBytesBuffer(((lowSurrogate & 0xFF) >>> 0), destination, 10, 0);
                                            $.$stew.S.HexConverter.ToBytesBuffer((((lowSurrogate >>> 8) & 0xFF) >>> 0), destination, 8, 0);
                                            return 12;
                                        }
                                    }
                                    case 1: /*OutOfSpaceInner*/
                                    return -1;
                                }
                                break;
                            }
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(21475688505)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180721209)
                    /*int */ EncodeUtf16(/*Rune*/ value, /*Span<char>*/ destination)
                    {
                        /*byte*/ let preescapedForm;
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17180721209);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._preescapedMap.TryLookup(value, $.$ref(() => preescapedForm, ($v) => preescapedForm = $v, $.$$.S.Byte)))
                        {
                            let $gotoJumpState12 = 0;
                            $gotoJumpStart12: while(true)
                            {
                                switch($gotoJumpState12)
                                {
                                    case 0:
                                    {
                                        if ((destination.Length >>> 0) <= 1)
                                        {
                                            $gotoJumpState12 = 1; /*goto OutOfSpace*/
                                            continue $gotoJumpStart12;
                                        }
                                        destination._reference.SetAt(/*\\*/ 92, 0);
                                        destination._reference.SetAt(preescapedForm, 1);
                                        return 2;
                                    }
                                    case 1: /*OutOfSpace*/
                                    return -1;
                                }
                                break;
                            }
                        }
                        return TryEncodeScalarAsHex(this, value, destination);
                        /*static int*/  function TryEncodeScalarAsHex(/*object*/ $this, /*Rune*/ value, /*Span<char>*/ destination)
                        {
                            let $gotoJumpState13 = 0;
                            $gotoJumpStart13: while(true)
                            {
                                switch($gotoJumpState13)
                                {
                                    case 0:
                                    {
                                        if (value.IsBmp)
                                        {
                                            if ((destination.Length >>> 0) <= 5)
                                            {
                                                $gotoJumpState13 = 1; /*goto OutOfSpaceInner*/
                                                continue $gotoJumpStart13;
                                            }
                                            destination._reference.SetAt(/*\\*/ 92, 0);
                                            destination._reference.SetAt(/*u*/ 117, 1);
                                            $.$stew.S.HexConverter.ToCharsBuffer($.$cast(value.Value, $.$$.S.Byte), destination, 4, 0);
                                            $.$stew.S.HexConverter.ToCharsBuffer(((((value.Value >>> 0) >>> 8) & 0xFF) >>> 0), destination, 2, 0);
                                            return 6;
                                        }
                                        else 
                                        {
                                            /*char*/ var highSurrogate;
                                            /*char*/ var lowSurrogate;
                                            $.$stew.STU.UnicodeHelpers.GetUtf16SurrogatePairFromAstralScalarValue((value.Value >>> 0), $.$ref(() => highSurrogate, ($v) => highSurrogate = $v, $.$$.S.Char), $.$ref(() => lowSurrogate, ($v) => lowSurrogate = $v, $.$$.S.Char));
                                            if ((destination.Length >>> 0) <= 11)
                                            {
                                                $gotoJumpState13 = 1; /*goto OutOfSpaceInner*/
                                                continue $gotoJumpStart13;
                                            }
                                            destination._reference.SetAt(/*\\*/ 92, 0);
                                            destination._reference.SetAt(/*u*/ 117, 1);
                                            $.$stew.S.HexConverter.ToCharsBuffer(((highSurrogate & 0xFF) >>> 0), destination, 4, 0);
                                            $.$stew.S.HexConverter.ToCharsBuffer((((highSurrogate >>> 8) & 0xFF) >>> 0), destination, 2, 0);
                                            destination._reference.SetAt(/*\\*/ 92, 6);
                                            destination._reference.SetAt(/*u*/ 117, 7);
                                            $.$stew.S.HexConverter.ToCharsBuffer(((lowSurrogate & 0xFF) >>> 0), destination, 10, 0);
                                            $.$stew.S.HexConverter.ToCharsBuffer((((lowSurrogate >>> 8) & 0xFF) >>> 0), destination, 8, 0);
                                            return 12;
                                        }
                                    }
                                    case 1: /*OutOfSpaceInner*/
                                    return -1;
                                }
                                break;
                            }
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180721209)
                    
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(4295819321)
                        this._preescapedMap = $.$default($.$stew.STEW.AsciiByteMap);
                        //--TRIMMABLE-BOUNDARY-END(4295819321)
                        
                    }
                    //--TRIMMABLE-BOUNDARY-START(8590786617)
                    //Static Initializer
                    static $sinit()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8590786617);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        {
                            //--TRIMMABLE-BOUNDARY-START(25770655801)
                            this.Singleton = new $.$stew.STEW.DefaultJavaScriptEncoder.EscaperImplementation().$ctor$2(false);
                            //--TRIMMABLE-BOUNDARY-END(25770655801)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(30065623097)
                            this.SingletonMinimallyEscaped = new $.$stew.STEW.DefaultJavaScriptEncoder.EscaperImplementation().$ctor$2(true);
                            //--TRIMMABLE-BOUNDARY-END(30065623097)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590786617)
                    
                    static $h = 852025;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$stew.STEW.ScalarEscaperBase; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(21475688505),
    {
      "r": 655361,
      "p": [
        {
          "n": "value",
          "p": 167641089
        },
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        }
      ],
      "n": "EncodeUtf8",
      "d": 852025,
      "h": 21475688505,
      "f": 16809992
    },
//--TRIMMABLE-BOUNDARY-END(21475688505),
//--TRIMMABLE-BOUNDARY-START(17180721209),
    {
      "r": 655361,
      "p": [
        {
          "n": "value",
          "p": 167641089
        },
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Char).$h
        }
      ],
      "n": "EncodeUtf16",
      "d": 852025,
      "h": 17180721209,
      "f": 16809992
    },
//--TRIMMABLE-BOUNDARY-END(17180721209)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(25770655801),
    {
      "t": 852025,
      "n": "Singleton",
      "d": 852025,
      "h": 25770655801,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(25770655801),
//--TRIMMABLE-BOUNDARY-START(30065623097),
    {
      "t": 852025,
      "n": "SingletonMinimallyEscaped",
      "d": 852025,
      "h": 30065623097,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(30065623097),
//--TRIMMABLE-BOUNDARY-START(4295819321),
    {
      "t": 589881,
      "n": "_preescapedMap",
      "d": 852025,
      "h": 4295819321,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295819321)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885753913),
    {
      "p": [
        {
          "n": "allowMinimalEscaping",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 852025,
      "h": 12885753913,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(12885753913)
  ],
  "d": 786489,
  "h": 852025
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Text.Encodings.Web.DefaultJavaScriptEncoder+EscaperImplementation`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Text${separator}Encodings${separator}Web${separator}DefaultJavaScriptEncoder${separator}EscaperImplementation`; }
                }, $cls, ($v) => $cls.$_EscaperImplementation = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(852025)
            
            //--TRIMMABLE-BOUNDARY-START(8590721081)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590721081);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(21475622969)
                    this.BasicLatinSingleton = new $.$stew.STEW.DefaultJavaScriptEncoder().$ctor$4(new $.$stew.STEW.TextEncoderSettings().$ctor$2($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stew.STU.UnicodeRange), [ $.$stew.STU.UnicodeRanges.BasicLatin ], null, null)));
                    //--TRIMMABLE-BOUNDARY-END(21475622969)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(64425295929)
                    this.UnsafeRelaxedEscapingSingleton = new $.$stew.STEW.DefaultJavaScriptEncoder().$ctor$3(new $.$stew.STEW.TextEncoderSettings().$ctor$2($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stew.STU.UnicodeRange), [ $.$stew.STU.UnicodeRanges.All ], null, null)), true);
                    //--TRIMMABLE-BOUNDARY-END(64425295929)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590721081)
            
            static $h = 786489;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$stew.STEW.JavaScriptEncoder; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55835361337),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540394041,
        "f": 50364417
      },
      "n": "MaxOutputCharactersPerInputCharacter",
      "d": 786489,
      "h": 55835361337,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(55835361337)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770590265),
    {
      "r": 50200577,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Char).$h
        },
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Char).$h
        },
        {
          "n": "charsConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "charsWritten",
          "p": 655361,
          "f": 2
        },
        {
          "n": "isFinalBlock",
          "p": 262145
        }
      ],
      "n": "EncodeCore",
      "o": "@$1",
      "d": 786489,
      "h": 25770590265,
      "f": 16809984
    },
//--TRIMMABLE-BOUNDARY-END(25770590265),
//--TRIMMABLE-BOUNDARY-START(30065557561),
    {
      "r": 50200577,
      "p": [
        {
          "n": "utf8Source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "utf8Destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "bytesWritten",
          "p": 655361,
          "f": 2
        },
        {
          "n": "isFinalBlock",
          "p": 262145
        }
      ],
      "n": "EncodeUtf8Core",
      "d": 786489,
      "h": 30065557561,
      "f": 16809984
    },
//--TRIMMABLE-BOUNDARY-END(30065557561),
//--TRIMMABLE-BOUNDARY-START(38655492153),
    {
      "r": 655361,
      "p": [
        {
          "n": "text",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Char).$h
        }
      ],
      "n": "FindFirstCharacterToEncode",
      "o": "@$1",
      "d": 786489,
      "h": 38655492153,
      "f": 16809984
    },
//--TRIMMABLE-BOUNDARY-END(38655492153),
//--TRIMMABLE-BOUNDARY-START(34360524857),
    {
      "r": 655361,
      "p": [
        {
          "n": "text",
          "p": $.$typePointer($.$$.S.Char).$h
        },
        {
          "n": "textLength",
          "p": 655361
        }
      ],
      "n": "FindFirstCharacterToEncode",
      "d": 786489,
      "h": 34360524857,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34360524857),
//--TRIMMABLE-BOUNDARY-START(42950459449),
    {
      "r": 655361,
      "p": [
        {
          "n": "utf8Text",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        }
      ],
      "n": "FindFirstCharacterToEncodeUtf8",
      "d": 786489,
      "h": 42950459449,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(42950459449),
//--TRIMMABLE-BOUNDARY-START(60130328633),
    {
      "r": 262145,
      "p": [
        {
          "n": "unicodeScalar",
          "p": 655361
        },
        {
          "n": "buffer",
          "p": $.$typePointer($.$$.S.Char).$h
        },
        {
          "n": "bufferLength",
          "p": 655361
        },
        {
          "n": "numberOfCharactersWritten",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryEncodeUnicodeScalar",
      "d": 786489,
      "h": 60130328633,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(60130328633),
//--TRIMMABLE-BOUNDARY-START(68720263225),
    {
      "r": 262145,
      "p": [
        {
          "n": "unicodeScalar",
          "p": 655361
        }
      ],
      "n": "WillEncode",
      "d": 786489,
      "h": 68720263225,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(68720263225)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(21475622969),
    {
      "t": 786489,
      "n": "BasicLatinSingleton",
      "d": 786489,
      "h": 21475622969,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(21475622969),
//--TRIMMABLE-BOUNDARY-START(64425295929),
    {
      "t": 786489,
      "n": "UnsafeRelaxedEscapingSingleton",
      "d": 786489,
      "h": 64425295929,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(64425295929),
//--TRIMMABLE-BOUNDARY-START(4295753785),
    {
      "t": 1245241,
      "n": "_innerEncoder",
      "d": 786489,
      "h": 4295753785,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295753785)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180655673),
    {
      "p": [
        {
          "n": "settings",
          "p": 1507385
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 786489,
      "h": 17180655673,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(17180655673),
//--TRIMMABLE-BOUNDARY-START(12885688377),
    {
      "p": [
        {
          "n": "settings",
          "p": 1507385
        },
        {
          "n": "allowMinimalJsonEscaping",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 786489,
      "h": 12885688377,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(12885688377)
  ],
  "h": 786489
}; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$stew.STEW.DefaultJavaScriptEncoder.EscaperImplementation ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Text.Encodings.Web.DefaultJavaScriptEncoder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Text${separator}Encodings${separator}Web${separator}DefaultJavaScriptEncoder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786489)
        
        

        //--TRIMMABLE-BOUNDARY-START(655417)
        $asm.$cls(`$stew.STEW.DefaultHtmlEncoder`, ($self) => class DefaultHtmlEncoder extends $.$stew.STEW.HtmlEncoder
        {
            //--TRIMMABLE-BOUNDARY-START(17180524601)
            /*DefaultHtmlEncoder*/ static BasicLatinSingleton = null;
            //--TRIMMABLE-BOUNDARY-END(17180524601)
            
            //--TRIMMABLE-BOUNDARY-START(4295622713)
            /*OptimizedInboxTextEncoder*/ _innerEncoder = null;
            //--TRIMMABLE-BOUNDARY-END(4295622713)
            
            //--TRIMMABLE-BOUNDARY-START(12885557305)
            $ctor$3(/*TextEncoderSettings*/ settings)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885557305);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (settings === null)
                    {
                        $.$stew.STEW.ThrowHelper.ThrowArgumentNullException(1/*ExceptionArgument.settings*/);
                    }
                    this._innerEncoder = new $.$stew.STEW.OptimizedInboxTextEncoder().$ctor$1($.$stew.STEW.DefaultHtmlEncoder.EscaperImplementation.Singleton, settings.GetAllowedCodePointsBitmap(), true, new ($.$$.S.ReadOnlySpan$$($.$$.S.Char))());
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885557305)
            
            //--TRIMMABLE-BOUNDARY-START(51540262969)
            /*int */ get MaxOutputCharactersPerInputCharacter()
            {
                return 8;
            }
            //--TRIMMABLE-BOUNDARY-END(51540262969)
            
            //--TRIMMABLE-BOUNDARY-START(21475491897)
            /*OperationStatus */ EncodeCore$1(/*ReadOnlySpan<char>*/ source, /*Span<char>*/ destination, /*out int*/ charsConsumed, /*out int*/ charsWritten, /*bool*/ isFinalBlock)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475491897);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._innerEncoder.Encode(source, destination, charsConsumed, charsWritten, isFinalBlock);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475491897)
            
            //--TRIMMABLE-BOUNDARY-START(25770459193)
            /*OperationStatus */ EncodeUtf8Core(/*ReadOnlySpan<byte>*/ utf8Source, /*Span<byte>*/ utf8Destination, /*out int*/ bytesConsumed, /*out int*/ bytesWritten, /*bool*/ isFinalBlock)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770459193);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._innerEncoder.EncodeUtf8(utf8Source, utf8Destination, bytesConsumed, bytesWritten, isFinalBlock);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770459193)
            
            //--TRIMMABLE-BOUNDARY-START(34360393785)
            /*int */ FindFirstCharacterToEncode$1(/*ReadOnlySpan<char>*/ text)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360393785);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._innerEncoder.GetIndexOfFirstCharToEncode(text);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360393785)
            
            //--TRIMMABLE-BOUNDARY-START(30065426489)
            /*int */ FindFirstCharacterToEncode(/*char**/ text, /*int*/ textLength)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065426489);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._innerEncoder.FindFirstCharacterToEncode(text, textLength);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065426489)
            
            //--TRIMMABLE-BOUNDARY-START(38655361081)
            /*int */ FindFirstCharacterToEncodeUtf8(/*ReadOnlySpan<byte>*/ utf8Text)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655361081);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._innerEncoder.GetIndexOfFirstByteToEncode(utf8Text);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38655361081)
            
            //--TRIMMABLE-BOUNDARY-START(55835230265)
            /*bool */ TryEncodeUnicodeScalar(/*int*/ unicodeScalar, /*char**/ buffer, /*int*/ bufferLength, /*out int*/ numberOfCharactersWritten)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55835230265);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._innerEncoder.TryEncodeUnicodeScalar(unicodeScalar, buffer, bufferLength, numberOfCharactersWritten);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55835230265)
            
            //--TRIMMABLE-BOUNDARY-START(60130197561)
            /*bool */ WillEncode(/*int*/ unicodeScalar)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60130197561);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return !this._innerEncoder.IsScalarValueAllowed(new $.$$.ST.Rune().$ctor$5(unicodeScalar));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60130197561)
            
            //--TRIMMABLE-BOUNDARY-START(720953)
            static $_EscaperImplementation;
            static get EscaperImplementation()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(720953);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$stew.STEW.DefaultHtmlEncoder;
                return $cls.$_EscaperImplementation ??= $asm.$ncls(`$stew.STEW.DefaultHtmlEncoder.EscaperImplementation`, ($self) => class EscaperImplementation extends $.$stew.STEW.ScalarEscaperBase
                {
                    //--TRIMMABLE-BOUNDARY-START(21475557433)
                    /*EscaperImplementation*/ static Singleton = null;
                    //--TRIMMABLE-BOUNDARY-END(21475557433)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590655545)
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8590655545);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590655545)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180590137)
                    /*int */ EncodeUtf8(/*Rune*/ value, /*Span<byte>*/ destination)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17180590137);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        let $gotoJumpState6 = 0;
                        $gotoJumpStart6: while(true)
                        {
                            switch($gotoJumpState6)
                            {
                                case 0:
                                {
                                    if (value.Value === /*<*/ 60)
                                    {
                                        if (!new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7([38, 108, 116, 59]).TryCopyTo(destination))
                                        {
                                            $gotoJumpState6 = 1; /*goto OutOfSpace*/
                                            continue $gotoJumpStart6;
                                        }
                                        return 4;
                                    }
                                    else if (value.Value === /*>*/ 62)
                                    {
                                        if (!new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7([38, 103, 116, 59]).TryCopyTo(destination))
                                        {
                                            $gotoJumpState6 = 1; /*goto OutOfSpace*/
                                            continue $gotoJumpStart6;
                                        }
                                        return 4;
                                    }
                                    else if (value.Value === /*&*/ 38)
                                    {
                                        if (!new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7([38, 97, 109, 112, 59]).TryCopyTo(destination))
                                        {
                                            $gotoJumpState6 = 1; /*goto OutOfSpace*/
                                            continue $gotoJumpStart6;
                                        }
                                        return 5;
                                    }
                                    else if (value.Value === /*\"*/ 34)
                                    {
                                        if (!new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7([38, 113, 117, 111, 116, 59]).TryCopyTo(destination))
                                        {
                                            $gotoJumpState6 = 1; /*goto OutOfSpace*/
                                            continue $gotoJumpStart6;
                                        }
                                        return 6;
                                    }
                                    else 
                                    {
                                        return TryEncodeScalarAsHex(this, (value.Value >>> 0), destination);
                                    }
                                }
                                case 1: /*OutOfSpace*/
                                return -1;
                                /*static int*/  function TryEncodeScalarAsHex(/*object*/ $this, /*uint*/ scalarValue, /*Span<byte>*/ destination)
                                {
                                    /*int*/ let idxOfSemicolon;
                                    let $gotoJumpState7 = 0;
                                    $gotoJumpStart7: while(true)
                                    {
                                        switch($gotoJumpState7)
                                        {
                                            case 0:
                                            {
                                                $.$stew.ST.UnicodeDebug.AssertIsValidScalar(scalarValue);
                                                idxOfSemicolon = (((($.trunc(($.$$.SN$1.BitOperations.Log2(scalarValue) >>> 0) / 4)) | 0) + 4) | 0);
                                                $.$$.SD.Debug.Assert$4(4 <= idxOfSemicolon && idxOfSemicolon <= 9, "Expected '&#x0;'..'&#x10FFFF;'.");
                                                if ((destination.Length >>> 0) <= (idxOfSemicolon >>> 0))
                                                {
                                                    $gotoJumpState7 = 1; /*goto OutOfSpaceInner*/
                                                    continue $gotoJumpStart7;
                                                }
                                                destination._reference.SetAt(/*;*/ 59, idxOfSemicolon);
                                                if (!new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7([38, 35, 120, 48]).TryCopyTo(destination))
                                                {
                                                    $.$$.SD.Debug.Fail$1("We should've had enough room to write 4 bytes.");
                                                }
                                                destination = destination.Slice(3, ((idxOfSemicolon - 3) | 0));
                                                for(/*int*/ var i = ((destination.Length - 1) | 0); (destination.Length >>> 0) > (i >>> 0); i--)
                                                {
                                                    /*char*/ var asUpperHex = $.$stew.S.HexConverter.ToCharUpper((scalarValue | 0));
                                                    destination._reference.SetAt(((asUpperHex & 0xFF) >>> 0), i);
                                                    scalarValue >>= 4;
                                                }
                                                return ((destination.Length + 4) | 0);
                                            }
                                            case 1: /*OutOfSpaceInner*/
                                            return -1;
                                        }
                                        break;
                                    }
                                }
                            }
                            break;
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180590137)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885622841)
                    /*int */ EncodeUtf16(/*Rune*/ value, /*Span<char>*/ destination)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12885622841);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        let $gotoJumpState8 = 0;
                        $gotoJumpStart8: while(true)
                        {
                            switch($gotoJumpState8)
                            {
                                case 0:
                                {
                                    if (value.Value === /*<*/ 60)
                                    {
                                        if (!$.$$.S.MemoryExtensions.AsSpan$4("&lt;").TryCopyTo(destination))
                                        {
                                            $gotoJumpState8 = 1; /*goto OutOfSpace*/
                                            continue $gotoJumpStart8;
                                        }
                                        return 4;
                                    }
                                    else if (value.Value === /*>*/ 62)
                                    {
                                        if (!$.$$.S.MemoryExtensions.AsSpan$4("&gt;").TryCopyTo(destination))
                                        {
                                            $gotoJumpState8 = 1; /*goto OutOfSpace*/
                                            continue $gotoJumpStart8;
                                        }
                                        return 4;
                                    }
                                    else if (value.Value === /*&*/ 38)
                                    {
                                        if (!$.$$.S.MemoryExtensions.AsSpan$4("&amp;").TryCopyTo(destination))
                                        {
                                            $gotoJumpState8 = 1; /*goto OutOfSpace*/
                                            continue $gotoJumpStart8;
                                        }
                                        return 5;
                                    }
                                    else if (value.Value === /*\"*/ 34)
                                    {
                                        if (!$.$$.S.MemoryExtensions.AsSpan$4("&quot;").TryCopyTo(destination))
                                        {
                                            $gotoJumpState8 = 1; /*goto OutOfSpace*/
                                            continue $gotoJumpStart8;
                                        }
                                        return 6;
                                    }
                                    else 
                                    {
                                        return TryEncodeScalarAsHex(this, (value.Value >>> 0), destination);
                                    }
                                }
                                case 1: /*OutOfSpace*/
                                return -1;
                                /*static int*/  function TryEncodeScalarAsHex(/*object*/ $this, /*uint*/ scalarValue, /*Span<char>*/ destination)
                                {
                                    /*int*/ let idxOfSemicolon;
                                    let $gotoJumpState9 = 0;
                                    $gotoJumpStart9: while(true)
                                    {
                                        switch($gotoJumpState9)
                                        {
                                            case 0:
                                            {
                                                $.$stew.ST.UnicodeDebug.AssertIsValidScalar(scalarValue);
                                                idxOfSemicolon = (((($.trunc(($.$$.SN$1.BitOperations.Log2(scalarValue) >>> 0) / 4)) | 0) + 4) | 0);
                                                $.$$.SD.Debug.Assert$4(4 <= idxOfSemicolon && idxOfSemicolon <= 9, "Expected '&#x0;'..'&#x10FFFF;'.");
                                                if ((destination.Length >>> 0) <= (idxOfSemicolon >>> 0))
                                                {
                                                    $gotoJumpState9 = 1; /*goto OutOfSpaceInner*/
                                                    continue $gotoJumpStart9;
                                                }
                                                destination._reference.SetAt(/*;*/ 59, idxOfSemicolon);
                                                if (!$.$$.S.MemoryExtensions.AsSpan$4("&#x0").TryCopyTo(destination))
                                                {
                                                    $.$$.SD.Debug.Fail$1("We should've had enough room to write 4 chars.");
                                                }
                                                destination = destination.Slice(3, ((idxOfSemicolon - 3) | 0));
                                                for(/*int*/ var i = ((destination.Length - 1) | 0); (destination.Length >>> 0) > (i >>> 0); i--)
                                                {
                                                    /*char*/ var asUpperHex = $.$stew.S.HexConverter.ToCharUpper((scalarValue | 0));
                                                    destination._reference.SetAt(asUpperHex, i);
                                                    scalarValue >>= 4;
                                                }
                                                return ((destination.Length + 4) | 0);
                                            }
                                            case 1: /*OutOfSpaceInner*/
                                            return -1;
                                        }
                                        break;
                                    }
                                }
                            }
                            break;
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885622841)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590655545)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590655545)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295688249)
                    //Static Initializer
                    static $sinit()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4295688249);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        {
                            //--TRIMMABLE-BOUNDARY-START(21475557433)
                            this.Singleton = new $.$stew.STEW.DefaultHtmlEncoder.EscaperImplementation().$ctor$2();
                            //--TRIMMABLE-BOUNDARY-END(21475557433)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295688249)
                    
                    static $h = 720953;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$stew.STEW.ScalarEscaperBase; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180590137),
    {
      "r": 655361,
      "p": [
        {
          "n": "value",
          "p": 167641089
        },
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        }
      ],
      "n": "EncodeUtf8",
      "d": 720953,
      "h": 17180590137,
      "f": 16809992
    },
//--TRIMMABLE-BOUNDARY-END(17180590137),
//--TRIMMABLE-BOUNDARY-START(12885622841),
    {
      "r": 655361,
      "p": [
        {
          "n": "value",
          "p": 167641089
        },
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Char).$h
        }
      ],
      "n": "EncodeUtf16",
      "d": 720953,
      "h": 12885622841,
      "f": 16809992
    },
//--TRIMMABLE-BOUNDARY-END(12885622841)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(21475557433),
    {
      "t": 720953,
      "n": "Singleton",
      "d": 720953,
      "h": 21475557433,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(21475557433)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590655545),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 720953,
      "h": 8590655545,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(8590655545)
  ],
  "d": 655417,
  "h": 720953
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Text.Encodings.Web.DefaultHtmlEncoder+EscaperImplementation`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Text${separator}Encodings${separator}Web${separator}DefaultHtmlEncoder${separator}EscaperImplementation`; }
                }, $cls, ($v) => $cls.$_EscaperImplementation = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(720953)
            
            //--TRIMMABLE-BOUNDARY-START(8590590009)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590590009);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(17180524601)
                    this.BasicLatinSingleton = new $.$stew.STEW.DefaultHtmlEncoder().$ctor$3(new $.$stew.STEW.TextEncoderSettings().$ctor$2($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stew.STU.UnicodeRange), [ $.$stew.STU.UnicodeRanges.BasicLatin ], null, null)));
                    //--TRIMMABLE-BOUNDARY-END(17180524601)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590590009)
            
            static $h = 655417;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$stew.STEW.HtmlEncoder; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51540262969),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245295673,
        "f": 50364417
      },
      "n": "MaxOutputCharactersPerInputCharacter",
      "d": 655417,
      "h": 51540262969,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(51540262969)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21475491897),
    {
      "r": 50200577,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Char).$h
        },
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Char).$h
        },
        {
          "n": "charsConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "charsWritten",
          "p": 655361,
          "f": 2
        },
        {
          "n": "isFinalBlock",
          "p": 262145
        }
      ],
      "n": "EncodeCore",
      "o": "@$1",
      "d": 655417,
      "h": 21475491897,
      "f": 16809984
    },
//--TRIMMABLE-BOUNDARY-END(21475491897),
//--TRIMMABLE-BOUNDARY-START(25770459193),
    {
      "r": 50200577,
      "p": [
        {
          "n": "utf8Source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "utf8Destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "bytesWritten",
          "p": 655361,
          "f": 2
        },
        {
          "n": "isFinalBlock",
          "p": 262145
        }
      ],
      "n": "EncodeUtf8Core",
      "d": 655417,
      "h": 25770459193,
      "f": 16809984
    },
//--TRIMMABLE-BOUNDARY-END(25770459193),
//--TRIMMABLE-BOUNDARY-START(34360393785),
    {
      "r": 655361,
      "p": [
        {
          "n": "text",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Char).$h
        }
      ],
      "n": "FindFirstCharacterToEncode",
      "o": "@$1",
      "d": 655417,
      "h": 34360393785,
      "f": 16809984
    },
//--TRIMMABLE-BOUNDARY-END(34360393785),
//--TRIMMABLE-BOUNDARY-START(30065426489),
    {
      "r": 655361,
      "p": [
        {
          "n": "text",
          "p": $.$typePointer($.$$.S.Char).$h
        },
        {
          "n": "textLength",
          "p": 655361
        }
      ],
      "n": "FindFirstCharacterToEncode",
      "d": 655417,
      "h": 30065426489,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30065426489),
//--TRIMMABLE-BOUNDARY-START(38655361081),
    {
      "r": 655361,
      "p": [
        {
          "n": "utf8Text",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        }
      ],
      "n": "FindFirstCharacterToEncodeUtf8",
      "d": 655417,
      "h": 38655361081,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38655361081),
//--TRIMMABLE-BOUNDARY-START(55835230265),
    {
      "r": 262145,
      "p": [
        {
          "n": "unicodeScalar",
          "p": 655361
        },
        {
          "n": "buffer",
          "p": $.$typePointer($.$$.S.Char).$h
        },
        {
          "n": "bufferLength",
          "p": 655361
        },
        {
          "n": "numberOfCharactersWritten",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryEncodeUnicodeScalar",
      "d": 655417,
      "h": 55835230265,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(55835230265),
//--TRIMMABLE-BOUNDARY-START(60130197561),
    {
      "r": 262145,
      "p": [
        {
          "n": "unicodeScalar",
          "p": 655361
        }
      ],
      "n": "WillEncode",
      "d": 655417,
      "h": 60130197561,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(60130197561)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180524601),
    {
      "t": 655417,
      "n": "BasicLatinSingleton",
      "d": 655417,
      "h": 17180524601,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(17180524601),
//--TRIMMABLE-BOUNDARY-START(4295622713),
    {
      "t": 1245241,
      "n": "_innerEncoder",
      "d": 655417,
      "h": 4295622713,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295622713)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885557305),
    {
      "p": [
        {
          "n": "settings",
          "p": 1507385
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 655417,
      "h": 12885557305,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(12885557305)
  ],
  "h": 655417
}; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$stew.STEW.DefaultHtmlEncoder.EscaperImplementation ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Text.Encodings.Web.DefaultHtmlEncoder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Text${separator}Encodings${separator}Web${separator}DefaultHtmlEncoder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655417)
        
        

        //--TRIMMABLE-BOUNDARY-START(1048633)
        $asm.$str(`$stew.STEW.ExceptionArgument`, ($self) => class ExceptionArgument extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static value = 0;
            static settings = 1;
            static output = 2;
            static other = 3;
            static allowedRanges = 4;
            static characters = 5;
            static codePoints = 6;
            static range = 7;
            static ranges = 8;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1048633);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "value": 0n,
                    "settings": 1n,
                    "output": 2n,
                    "other": 3n,
                    "allowedRanges": 4n,
                    "characters": 5n,
                    "codePoints": 6n,
                    "range": 7n,
                    "ranges": 8n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296015929)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296015929);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296015929)
            
            //--TRIMMABLE-BOUNDARY-START(4296015929)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296015929)
            
            static $h = 1048633;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(42950721593),
    {
      "t": 1048633,
      "n": "value",
      "d": 1048633,
      "h": 42950721593,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42950721593),
//--TRIMMABLE-BOUNDARY-START(38655754297),
    {
      "t": 1048633,
      "n": "settings",
      "d": 1048633,
      "h": 38655754297,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38655754297),
//--TRIMMABLE-BOUNDARY-START(25770852409),
    {
      "t": 1048633,
      "n": "output",
      "d": 1048633,
      "h": 25770852409,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770852409),
//--TRIMMABLE-BOUNDARY-START(21475885113),
    {
      "t": 1048633,
      "n": "other",
      "d": 1048633,
      "h": 21475885113,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475885113),
//--TRIMMABLE-BOUNDARY-START(8590983225),
    {
      "t": 1048633,
      "n": "allowedRanges",
      "d": 1048633,
      "h": 8590983225,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590983225),
//--TRIMMABLE-BOUNDARY-START(12885950521),
    {
      "t": 1048633,
      "n": "characters",
      "d": 1048633,
      "h": 12885950521,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885950521),
//--TRIMMABLE-BOUNDARY-START(17180917817),
    {
      "t": 1048633,
      "n": "codePoints",
      "d": 1048633,
      "h": 17180917817,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180917817),
//--TRIMMABLE-BOUNDARY-START(30065819705),
    {
      "t": 1048633,
      "n": "range",
      "d": 1048633,
      "h": 30065819705,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065819705),
//--TRIMMABLE-BOUNDARY-START(34360787001),
    {
      "t": 1048633,
      "n": "ranges",
      "d": 1048633,
      "h": 34360787001,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360787001)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296015929),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1048633,
      "h": 4296015929,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296015929)
  ],
  "h": 1048633
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Text.Encodings.Web.ExceptionArgument`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Text${separator}Encodings${separator}Web${separator}ExceptionArgument`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1048633)
        
        

        //--TRIMMABLE-BOUNDARY-START(65593)
        $asm.$str(`$stew.S.ExceptionArgument`, ($self) => class ExceptionArgument extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static ch = 0;
            static culture = 1;
            static index = 2;
            static input = 3;
            static value = 4;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(65593);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "ch": 0n,
                    "culture": 1n,
                    "index": 2n,
                    "input": 3n,
                    "value": 4n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295032889)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295032889);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295032889)
            
            //--TRIMMABLE-BOUNDARY-START(4295032889)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295032889)
            
            static $h = 65593;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590000185),
    {
      "t": 65593,
      "n": "ch",
      "d": 65593,
      "h": 8590000185,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590000185),
//--TRIMMABLE-BOUNDARY-START(12884967481),
    {
      "t": 65593,
      "n": "culture",
      "d": 65593,
      "h": 12884967481,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12884967481),
//--TRIMMABLE-BOUNDARY-START(17179934777),
    {
      "t": 65593,
      "n": "index",
      "d": 65593,
      "h": 17179934777,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17179934777),
//--TRIMMABLE-BOUNDARY-START(21474902073),
    {
      "t": 65593,
      "n": "input",
      "d": 65593,
      "h": 21474902073,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21474902073),
//--TRIMMABLE-BOUNDARY-START(25769869369),
    {
      "t": 65593,
      "n": "value",
      "d": 65593,
      "h": 25769869369,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25769869369)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295032889),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 65593,
      "h": 4295032889,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295032889)
  ],
  "h": 65593
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.ExceptionArgument`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}ExceptionArgument`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65593)
        
        

        //--TRIMMABLE-BOUNDARY-START(131129)
        $asm.$str(`$stew.S.ExceptionResource`, ($self) => class ExceptionResource extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Argument_CannotExtractScalar = 0;
            static ArgumentOutOfRange_IndexMustBeLess = 1;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(131129);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Argument_CannotExtractScalar": 0n,
                    "ArgumentOutOfRange_IndexMustBeLess": 1n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295098425)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295098425);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295098425)
            
            //--TRIMMABLE-BOUNDARY-START(4295098425)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295098425)
            
            static $h = 131129;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590065721),
    {
      "t": 131129,
      "n": "Argument_CannotExtractScalar",
      "d": 131129,
      "h": 8590065721,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590065721),
//--TRIMMABLE-BOUNDARY-START(12885033017),
    {
      "t": 131129,
      "n": "ArgumentOutOfRange_IndexMustBeLess",
      "d": 131129,
      "h": 12885033017,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885033017)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295098425),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 131129,
      "h": 4295098425,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295098425)
  ],
  "h": 131129
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.ExceptionResource`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}ExceptionResource`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131129)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Threading"));
})();
//--TRIMMABLE-BOUNDARY-END(57)
