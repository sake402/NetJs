
//--TRIMMABLE-BOUNDARY-START(21)
(function ($global, $, $$, $sc, $sdt, $st, $scc, $sm, $spu, $sr, $sttp) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Threading.Channels", 
    {
  "h": 21,
  "f": "System.Threading.Channels",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 159252481,
      "c": 13044154369,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106430465,
      "c": 8696365057,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106496001,
      "c": 8696430593,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 8696889345,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107085825,
      "c": 8697020417,
      "a": [
        {
          "v": "1.0.35\u002Bdf6f45b09d58f65c84d384efc8772929a0c6464b",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 8697872385,
      "a": [
        {
          "v": "NetJs.System.Threading.Channels",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 8698003457,
      "a": [
        {
          "v": "NetJs.System.Threading.Channels",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108199937,
      "c": 8698134529,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159318017,
      "c": 4454285313,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159055873,
      "c": 4454023169,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(2097173)
        $asm.$cls("$stc.System.Threading.Channels.IDebugEnumerable<>", (T) => $asm.$gt("$stc.System.Threading.Channels.IDebugEnumerable<>", [T], ($self) => class IDebugEnumerable$$
        {
            static $h = 2097173;
            static $g = 1;
            static $f = 0b1100100;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297064469),
    {
      "r": $.$$.System.Collections.Generic.IEnumerator$$(T).$h,
      "n": "GetEnumerator",
      "o": "System$Threading$Channels$IDebugEnumerable$$$GetEnumerator",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4297064469)
  ],
  "g": [T?.$h??1507328
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $fullName() { return `System.Threading.Channels.IDebugEnumerable<${T?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2097173)
        
        
        //--TRIMMABLE-BOUNDARY-START(196629)
        $asm.$cls("$stc.System.Collections.Concurrent.IProducerConsumerQueue<>", (T) => $asm.$gt("$stc.System.Collections.Concurrent.IProducerConsumerQueue<>", [T], ($self) => class IProducerConsumerQueue$$
        {
            static $h = 196629;
            static $g = 1;
            static $f = 0b1100100;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34359934997),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x600000000n),
        "f": 50331905
      },
      "n": "IsEmpty",
      "o": "System$Collections$Concurrent$IProducerConsumerQueue$$$IsEmpty",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(34359934997),
//--TRIMMABLE-BOUNDARY-START(4295163925),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x400000000n),
        "f": 50331905
      },
      "n": "Count",
      "o": "System$Collections$Concurrent$IProducerConsumerQueue$$$Count",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4295163925)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590131221),
    {
      "r": 65537,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1507328
        }
      ],
      "n": "Enqueue",
      "o": "System$Collections$Concurrent$IProducerConsumerQueue$$$Enqueue",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590131221),
//--TRIMMABLE-BOUNDARY-START(38654902293),
    {
      "r": 262145,
      "p": [
        {
          "n": "result",
          "p": T?.$h??1507328,
          "f": 2
        }
      ],
      "n": "TryDequeue",
      "o": "System$Collections$Concurrent$IProducerConsumerQueue$$$TryDequeue",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(38654902293),
//--TRIMMABLE-BOUNDARY-START(30064967701),
    {
      "r": 655361,
      "p": [
        {
          "n": "syncObj",
          "p": 131073
        }
      ],
      "n": "GetCountSafe",
      "o": "System$Collections$Concurrent$IProducerConsumerQueue$$$GetCountSafe",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(30064967701)
  ],
  "i": [$.$$.System.Collections.Generic.IEnumerable$$(T).$h,62652417
  ],
  "g": [T?.$h??1507328
  ],
  "r": 1,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IEnumerable$$(T), $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Collections.Concurrent.IProducerConsumerQueue<${T?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(196629)
        
        
        //--TRIMMABLE-BOUNDARY-START(1769493)
        $asm.$cls("$stc.System.Threading.Channels.ChannelOptions", ($self) => class ChannelOptions extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(81606148117)
            /*bool*/ SingleWriter = false;
            //--TRIMMABLE-BOUNDARY-END(81606148117)
            
            //--TRIMMABLE-BOUNDARY-START(77311180821)
            /*bool*/ SingleReader = false;
            //--TRIMMABLE-BOUNDARY-END(77311180821)
            
            //--TRIMMABLE-BOUNDARY-START(21476605973)
            /*bool*/ AllowSynchronousContinuations = false;
            //--TRIMMABLE-BOUNDARY-END(21476605973)
            
            //--TRIMMABLE-BOUNDARY-START(17181638677)
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181638677)
            
            static $h = 1769493;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(81606148117),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246409749,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73016213525,
        "f": 83886081
      },
      "n": "SingleWriter",
      "d": 1769493,
      "h": 81606148117,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81606148117),
//--TRIMMABLE-BOUNDARY-START(77311180821),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656475157,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64426278933,
        "f": 83886081
      },
      "n": "SingleReader",
      "d": 1769493,
      "h": 77311180821,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77311180821),
//--TRIMMABLE-BOUNDARY-START(21476605973),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066540565,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55836344341,
        "f": 83886081
      },
      "n": "AllowSynchronousContinuations",
      "d": 1769493,
      "h": 21476605973,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476605973)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181638677),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1769493,
      "h": 17181638677,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(17181638677)
  ],
  "h": 1769493
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Threading.Channels.ChannelOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1769493)
        
        
        //--TRIMMABLE-BOUNDARY-START(1835029)
        $asm.$cls("$stc.System.Threading.Channels.ChannelReader<>", (T) => $asm.$gt("$stc.System.Threading.Channels.ChannelReader<>", [T], ($self) => class ChannelReader$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17181704213)
            /*Task */ get Completion()
            {
                return $.$stc.System.Threading.Channels.ChannelUtilities.s_neverCompletingTask;
            }
            //--TRIMMABLE-BOUNDARY-END(17181704213)
            
            //--TRIMMABLE-BOUNDARY-START(8591769621)
            /*bool */ get CanCount()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(8591769621)
            
            //--TRIMMABLE-BOUNDARY-START(12886736917)
            /*bool */ get CanPeek()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(12886736917)
            
            //--TRIMMABLE-BOUNDARY-START(21476671509)
            /*int */ get Count()
            {
                throw new $.$$.System.NotSupportedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(21476671509)
            
            //--TRIMMABLE-BOUNDARY-START(68721311765)
            /*bool */ TryPeek(/*out T*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68721311765);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                item.$v = $.$default(T);
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(68721311765)
            
            //--TRIMMABLE-BOUNDARY-START(64426344469)
            /*ValueTask<T> */ ReadAsync(/*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426344469);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (cancellationToken.IsCancellationRequested)
                {
                    return new ($.$$.System.Threading.Tasks.ValueTask$$(T))().$ctor$5($.$$.System.Threading.Tasks.Task.FromCanceled$3(T, cancellationToken));
                }
                try
                {
                    /*T?*/ let fastItem;
                    if (this.TryRead($.$ref(() => fastItem, ($v) => fastItem = $v, T)))
                    {
                        return new ($.$$.System.Threading.Tasks.ValueTask$$(T))().$ctor$6(fastItem);
                    }
                }
                catch(exc)
                {
                    return new ($.$$.System.Threading.Tasks.ValueTask$$(T))().$ctor$5($.$$.System.Threading.Tasks.Task.FromException$1(T, exc));
                }
                return ReadAsyncCore.call(this, cancellationToken);
                /*ValueTask<T>*/ /*async*/  function ReadAsyncCore(/*CancellationToken*/ ct)
                {
                    return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask$$(T), T, async () => 
                    {
                        while(true)
                        {
                            if (!await this.WaitToReadAsync(ct).ConfigureAwait(false))
                            {
                                throw new $.$stc.System.Threading.Channels.ChannelClosedException().$ctor$13();
                            }
                            /*T?*/ let item;
                            if (this.TryRead($.$ref(() => item, ($v) => item = $v, T)))
                            {
                                return item;
                            }
                        }
                    });
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64426344469)
            
            //--TRIMMABLE-BOUNDARY-START(60131377173)
            /*IAsyncEnumerable<T> *//*async*/  ReadAllAsync(/*CancellationToken*/ cancellationToken)
            {
                return new ($.$$.NetJs.YieldToIterator$$(T))().$ctor$1(async function*()
                {
                    while(await this.WaitToReadAsync(cancellationToken).ConfigureAwait(false))
                    {
                        /*T?*/ let item;
                        while(this.TryRead($.$ref(() => item, ($v) => item = $v, T)))
                        {
                            yield item;
                        }
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(60131377173)
            
            //--TRIMMABLE-BOUNDARY-START(4296802325)
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296802325)
            
            static $h = 1835029;
            static $g = 1;
            static $f = 0b1110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(17181704213),
    {
      "p": 177668097,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xB00000000n),
        "f": 50331777
      },
      "n": "Completion",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(17181704213),
//--TRIMMABLE-BOUNDARY-START(8591769621),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x700000000n),
        "f": 50331777
      },
      "n": "CanCount",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(8591769621),
//--TRIMMABLE-BOUNDARY-START(12886736917),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x900000000n),
        "f": 50331777
      },
      "n": "CanPeek",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(12886736917),
//--TRIMMABLE-BOUNDARY-START(21476671509),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xD00000000n),
        "f": 50331777
      },
      "n": "Count",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(21476671509)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(73016279061),
    {
      "r": 262145,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1507328,
          "f": 2
        }
      ],
      "n": "TryRead",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1100000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(73016279061),
//--TRIMMABLE-BOUNDARY-START(68721311765),
    {
      "r": 262145,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1507328,
          "f": 2
        }
      ],
      "n": "TryPeek",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1000000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(68721311765),
//--TRIMMABLE-BOUNDARY-START(77311246357),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Boolean).$h,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170065921,
          "f": 65
        }
      ],
      "n": "WaitToReadAsync",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1200000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(77311246357),
//--TRIMMABLE-BOUNDARY-START(64426344469),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$(T).$h,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170065921,
          "f": 65
        }
      ],
      "n": "ReadAsync",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xF00000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(64426344469),
//--TRIMMABLE-BOUNDARY-START(60131377173),
    {
      "r": $.$$.System.Collections.Generic.IAsyncEnumerable$$(T).$h,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170065921,
          "f": 65,
          "a": [
            {
              "t": 127795201,
              "c": 4422762497
            }
          ]
        }
      ],
      "n": "ReadAllAsync",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 16781441
    },
//--TRIMMABLE-BOUNDARY-END(60131377173)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296802325),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4296802325)
  ],
  "g": [T?.$h??1507328
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Threading.Channels.ChannelReader<${T?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1835029)
        
        
        //--TRIMMABLE-BOUNDARY-START(1572885)
        $asm.$cls("$stc.System.Threading.Channels.Channel<,>", (TWrite, TRead) => $asm.$gt("$stc.System.Threading.Channels.Channel<,>", [TWrite, TRead], ($self) => class Channel$$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(42951245845)
            /*ChannelReader<TRead>*/ Reader = null;
            //--TRIMMABLE-BOUNDARY-END(42951245845)
            
            //--TRIMMABLE-BOUNDARY-START(64426082325)
            /*ChannelWriter<TWrite>*/ Writer = null;
            //--TRIMMABLE-BOUNDARY-END(64426082325)
            
            //--TRIMMABLE-BOUNDARY-START(12886474773)
            static /*ChannelReader<TRead> */ op_Implicit(/*Channel<TWrite, TRead>*/ channel)
            {
                {
                    return channel.Reader;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886474773)
            
            //--TRIMMABLE-BOUNDARY-START(17181442069)
            static /*ChannelWriter<TWrite> */ op_Implicit$1(/*Channel<TWrite, TRead>*/ channel)
            {
                {
                    return channel.Writer;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17181442069)
            
            //--TRIMMABLE-BOUNDARY-START(21476409365)
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476409365)
            
            //default member initializer
            constructor()
            {
                super();
                this.Reader = null;
                this.Writer = null;
            }
            static $h = 1572885;
            static $g = 2;
            static $f = 0b1110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(42951245845),
    {
      "p": $.$stc.System.Threading.Channels.ChannelReader$$(TRead).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x700000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xC00000000n),
        "f": 83886084
      },
      "n": "Reader",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42951245845),
//--TRIMMABLE-BOUNDARY-START(64426082325),
    {
      "p": $.$stc.System.Threading.Channels.ChannelWriter$$(TWrite).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x900000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xE00000000n),
        "f": 83886084
      },
      "n": "Writer",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xF00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64426082325)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476409365),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(21476409365)
  ],
  "g": [TWrite?.$h??1507328,TRead?.$h??1572864
  ],
  "r": 2,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Threading.Channels.Channel<${TWrite?.$fullName},${TRead?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1572885)
        
        
        //--TRIMMABLE-BOUNDARY-START(1966101)
        $asm.$cls("$stc.System.Threading.Channels.ChannelWriter<>", (T) => $asm.$gt("$stc.System.Threading.Channels.ChannelWriter<>", [T], ($self) => class ChannelWriter$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12886867989)
            /*bool */ TryComplete(/*Exception?*/ error)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886867989);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886867989)
            
            //--TRIMMABLE-BOUNDARY-START(25771769877)
            /*ValueTask */ WriteAsync(/*T*/ item, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771769877);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                try
                {
                    return cancellationToken.IsCancellationRequested ? new $.$$.System.Threading.Tasks.ValueTask().$ctor$5($.$$.System.Threading.Tasks.Task.FromCanceled$3(T, cancellationToken)) : this.TryWrite(item) ? new $.$$.System.Threading.Tasks.ValueTask() : this.WriteAsyncCore(item, cancellationToken);
                }
                catch(e)
                {
                    return new $.$$.System.Threading.Tasks.ValueTask().$ctor$5($.$$.System.Threading.Tasks.Task.FromException(e));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25771769877)
            
            //--TRIMMABLE-BOUNDARY-START(30066737173)
            /*ValueTask *//*async*/  WriteAsyncCore(/*T*/ innerItem, /*CancellationToken*/ ct)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30066737173);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    while(await this.WaitToWriteAsync(ct).ConfigureAwait(false))
                    {
                        if (this.TryWrite(innerItem))
                        {
                            return;
                        }
                    }
                    throw $.$stc.System.Threading.Channels.ChannelUtilities.CreateInvalidCompletionException(null);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(30066737173)
            
            //--TRIMMABLE-BOUNDARY-START(8591900693)
            /*void */ Complete(/*Exception?*/ error)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591900693);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.TryComplete(error))
                {
                    throw $.$stc.System.Threading.Channels.ChannelUtilities.CreateInvalidCompletionException(null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8591900693)
            
            //--TRIMMABLE-BOUNDARY-START(4296933397)
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296933397)
            
            static $h = 1966101;
            static $g = 1;
            static $f = 0b1110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886867989),
    {
      "r": 262145,
      "p": [
        {
          "n": "error",
          "p": 80019457,
          "f": 65
        }
      ],
      "n": "TryComplete",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12886867989),
//--TRIMMABLE-BOUNDARY-START(17181835285),
    {
      "r": 262145,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1507328
        }
      ],
      "n": "TryWrite",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17181835285),
//--TRIMMABLE-BOUNDARY-START(21476802581),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Boolean).$h,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170065921,
          "f": 65
        }
      ],
      "n": "WaitToWriteAsync",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(21476802581),
//--TRIMMABLE-BOUNDARY-START(25771769877),
    {
      "r": 180551681,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1507328
        },
        {
          "n": "cancellationToken",
          "p": 170065921,
          "f": 65
        }
      ],
      "n": "WriteAsync",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(25771769877),
//--TRIMMABLE-BOUNDARY-START(30066737173),
    {
      "r": 180551681,
      "p": [
        {
          "n": "innerItem",
          "p": T?.$h??1507328
        },
        {
          "n": "ct",
          "p": 170065921
        }
      ],
      "n": "WriteAsyncCore",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(30066737173),
//--TRIMMABLE-BOUNDARY-START(8591900693),
    {
      "r": 65537,
      "p": [
        {
          "n": "error",
          "p": 80019457,
          "f": 65
        }
      ],
      "n": "Complete",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591900693)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296933397),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4296933397)
  ],
  "g": [T?.$h??1507328
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Threading.Channels.ChannelWriter<${T?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1966101)
        
        
        //--TRIMMABLE-BOUNDARY-START(786453)
        $asm.$cls("$stc.System.Threading.Channels.AsyncOperation", ($self) => class AsyncOperation extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(124554838037)
            /*void */ System$Threading$IThreadPoolWorkItem$Execute()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(124554838037);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.SetCompletionAndInvokeContinuation();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(124554838037)
            
            //--TRIMMABLE-BOUNDARY-START(158914576405)
            /*void */ UnsafeQueueSetCompletionAndInvokeContinuation()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(158914576405);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.Threading.ThreadPool.UnsafeQueueUserWorkItem(this, false);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(158914576405)
            
            //--TRIMMABLE-BOUNDARY-START(154619609109)
            static /*void */ Unregister(/*CancellationTokenRegistration*/ registration)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(154619609109);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return registration.Unregister();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(154619609109)
            
            //--TRIMMABLE-BOUNDARY-START(107374968853)
            /*Action<object?>*/ static s_availableSentinel = null;
            //--TRIMMABLE-BOUNDARY-END(107374968853)
            
            //--TRIMMABLE-BOUNDARY-START(55835361301)
            static /*void */ AvailableSentinel(/*object?*/ s)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55835361301);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.Diagnostics.Debug.Fail$1(`${"AsyncOperation"}.${"AvailableSentinel"} invoked with ${$.$$.System.Object.ToString.call(s)}`);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55835361301)
            
            //--TRIMMABLE-BOUNDARY-START(111669936149)
            /*Action<object?>*/ static s_completedSentinel = null;
            //--TRIMMABLE-BOUNDARY-END(111669936149)
            
            //--TRIMMABLE-BOUNDARY-START(64425295893)
            static /*void */ CompletedSentinel(/*object?*/ s)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64425295893);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.Diagnostics.Debug.Fail$1(`${"AsyncOperation"}.${"CompletedSentinel"} invoked with ${$.$$.System.Object.ToString.call(s)}`);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64425295893)
            
            //--TRIMMABLE-BOUNDARY-START(128849805333)
            static /*void */ ThrowIncompleteOperationException()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(128849805333);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$stc.System.SR.InvalidOperation_IncompleteAsyncOperation);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(128849805333)
            
            //--TRIMMABLE-BOUNDARY-START(137439739925)
            static /*void */ ThrowMultipleContinuations()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(137439739925);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$stc.System.SR.InvalidOperation_MultipleContinuations);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(137439739925)
            
            //--TRIMMABLE-BOUNDARY-START(133144772629)
            static /*void */ ThrowIncorrectCurrentIdException()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(133144772629);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$stc.System.SR.InvalidOperation_IncorrectToken);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(133144772629)
            
            //--TRIMMABLE-BOUNDARY-START(4295753749)
            /*CancellationTokenRegistration*/ _cancellationRegistration;
            //--TRIMMABLE-BOUNDARY-END(4295753749)
            
            //--TRIMMABLE-BOUNDARY-START(34360524821)
            /*bool*/ _pooled = false;
            //--TRIMMABLE-BOUNDARY-END(34360524821)
            
            //--TRIMMABLE-BOUNDARY-START(12885688341)
            /*bool*/ _completionReserved = false;
            //--TRIMMABLE-BOUNDARY-END(12885688341)
            
            //--TRIMMABLE-BOUNDARY-START(30065557525)
            /*ExceptionDispatchInfo?*/ _error = null;
            //--TRIMMABLE-BOUNDARY-END(30065557525)
            
            //--TRIMMABLE-BOUNDARY-START(17180655637)
            /*Action<object?>?*/ _continuation = null;
            //--TRIMMABLE-BOUNDARY-END(17180655637)
            
            //--TRIMMABLE-BOUNDARY-START(21475622933)
            /*object?*/ _continuationState = null;
            //--TRIMMABLE-BOUNDARY-END(21475622933)
            
            //--TRIMMABLE-BOUNDARY-START(8590721045)
            /*object?*/ _capturedContext = null;
            //--TRIMMABLE-BOUNDARY-END(8590721045)
            
            //--TRIMMABLE-BOUNDARY-START(25770590229)
            /*short*/ _currentId = 0;
            //--TRIMMABLE-BOUNDARY-END(25770590229)
            
            //--TRIMMABLE-BOUNDARY-START(51540394005)
            $ctor$1(/*bool*/ runContinuationsAsynchronously, /*CancellationToken*/ cancellationToken, /*bool*/ pooled, /*Action<object?, CancellationToken>?*/ cancellationCallback)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51540394005);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.Diagnostics.Debug.Assert$2(!pooled || !cancellationToken.CanBeCanceled, "!pooled || !cancellationToken.CanBeCanceled");
                    this._continuation = pooled ? $.$stc.System.Threading.Channels.AsyncOperation.s_availableSentinel : null;
                    this._pooled = pooled;
                    this.RunContinuationsAsynchronously = runContinuationsAsynchronously;
                    if (cancellationToken.CanBeCanceled)
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(!(cancellationCallback === null), "Expected a non-null cancellation callback when the token is cancelable");
                        $.$$.System.Diagnostics.Debug.Assert$2(!this._pooled, "Cancelable operations can't be pooled");
                        this._cancellationRegistration = cancellationToken.UnsafeRegister(cancellationCallback, this);
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(51540394005)
            
            //--TRIMMABLE-BOUNDARY-START(103080001557)
            /*bool*/ RunContinuationsAsynchronously = false;
            //--TRIMMABLE-BOUNDARY-END(103080001557)
            
            //--TRIMMABLE-BOUNDARY-START(60130328597)
            /*CancellationToken */ get CancellationToken()
            {
                return this._cancellationRegistration.Token;
            }
            //--TRIMMABLE-BOUNDARY-END(60130328597)
            
            //--TRIMMABLE-BOUNDARY-START(94490066965)
            /*bool */ get IsCompleted()
            {
                return $.$$.System.Object.ReferenceEquals(this._continuation, $.$stc.System.Threading.Channels.AsyncOperation.s_completedSentinel);
            }
            //--TRIMMABLE-BOUNDARY-END(94490066965)
            
            //--TRIMMABLE-BOUNDARY-START(150324641813)
            /*bool */ TrySetException(/*Exception*/ exception)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324641813);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.TryReserveCompletionIfCancelable())
                {
                    this._error = $.$$.System.Runtime.ExceptionServices.ExceptionDispatchInfo.Capture(exception);
                    this.SignalCompletion();
                    return true;
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(150324641813)
            
            //--TRIMMABLE-BOUNDARY-START(146029674517)
            /*bool */ TrySetCanceled(/*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029674517);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.TryReserveCompletionIfCancelable())
                {
                    this._error = $.$$.System.Runtime.ExceptionServices.ExceptionDispatchInfo.Capture(new $.$$.System.OperationCanceledException().$ctor$15(cancellationToken));
                    this.SignalCompletion();
                    return true;
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(146029674517)
            
            //--TRIMMABLE-BOUNDARY-START(141734707221)
            /*bool */ TryReserveCompletionIfCancelable()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(141734707221);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return !this.CancellationToken.CanBeCanceled || $.$$.System.Threading.Interlocked.Exchange$14($.$$.System.Boolean, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => this._completionReserved, ($v) => this._completionReserved = $v, null), true) === false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(141734707221)
            
            //--TRIMMABLE-BOUNDARY-START(120259870741)
            /*void */ SignalCompletion()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259870741);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(!this.CancellationToken.CanBeCanceled || this._completionReserved, "!CancellationToken.CanBeCanceled ||\r\n#if NET9_0_OR_GREATER\r\n                _completionReserved");
                $.$stc.System.Threading.Channels.AsyncOperation.Unregister(this._cancellationRegistration);
                if (!(this._continuation === null) || !($.$$.System.Threading.Interlocked.CompareExchange$14($.$$.System.Action$$($.$$.System.Object), $.$ref(() => this._continuation, ($v) => this._continuation = $v, $.$$.System.Action$$($.$$.System.Object)), $.$stc.System.Threading.Channels.AsyncOperation.s_completedSentinel, null) === null))
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(this._continuation !== $.$stc.System.Threading.Channels.AsyncOperation.s_completedSentinel, `The continuation was the completion sentinel.`);
                    $.$$.System.Diagnostics.Debug.Assert$2(this._continuation !== $.$stc.System.Threading.Channels.AsyncOperation.s_availableSentinel, `The continuation was the available sentinel.`);
                    /*object?*/ let ctx = this._capturedContext;
                    let $t2;
                    if ((ctx === null) || (($.$is(ctx, $.$$.System.Threading.ExecutionContext, { set $v(v){ $t2 = v } }) && $t2 === $.$$.System.Threading.ExecutionContext)))
                    {
                        if (this.RunContinuationsAsynchronously)
                        {
                            this.UnsafeQueueSetCompletionAndInvokeContinuation();
                            return;
                        }
                    }
                    else 
                    {
                        /*SynchronizationContext?*/ let sc = $.$as(ctx, $.$$.System.Threading.SynchronizationContext) ?? $.$as((($.$as(ctx, $.$stc.System.Threading.Channels.AsyncOperation.CapturedSchedulerAndExecutionContext))?._scheduler ?? null), $.$$.System.Threading.SynchronizationContext);
                        if (!(sc === null))
                        {
                            if (this.RunContinuationsAsynchronously || sc !== $.$$.System.Threading.SynchronizationContext.Current)
                            {
                                sc.Post(new $.$$.System.Threading.SendOrPostCallback().$ctor($.$stc.System.Threading.Channels.AsyncOperation, /*static*/ (/*s*/ s) =>
                                {
                                    return ($.$cast(s, $.$stc.System.Threading.Channels.AsyncOperation)).SetCompletionAndInvokeContinuation();
                                }, {
  "r": 65537,
  "p": [
    {
      "n": "s",
      "p": 131073
    }
  ],
  "n": "",
  "d": 786453,
  "h": 0,
  "f": 17825826
}), this);
                                return;
                            }
                        }
                        else 
                        {
                            /*TaskScheduler?*/ let ts = $.$as(ctx, $.$$.System.Threading.Tasks.TaskScheduler) ?? $.$as((($.$as(ctx, $.$stc.System.Threading.Channels.AsyncOperation.CapturedSchedulerAndExecutionContext))?._scheduler ?? null), $.$$.System.Threading.Tasks.TaskScheduler);
                            $.$$.System.Diagnostics.Debug.Assert$2(!(ts === null), "Expected a TaskScheduler");
                            if (this.RunContinuationsAsynchronously || ts !== $.$$.System.Threading.Tasks.TaskScheduler.Current)
                            {
                                $.$$.System.Threading.Tasks.Task.Factory.StartNew$4(new ($.$$.System.Action$$($.$$.System.Object))().$ctor($.$stc.System.Threading.Channels.AsyncOperation, /*static*/ (/*s*/ s) =>
                                {
                                    return ($.$cast(s, $.$stc.System.Threading.Channels.AsyncOperation)).SetCompletionAndInvokeContinuation();
                                }, {
  "r": 65537,
  "p": [
    {
      "n": "s",
      "p": 131073
    }
  ],
  "n": "",
  "d": 786453,
  "h": 0,
  "f": 17825826
}), this, $.$$.System.Threading.CancellationToken.None, 8/*TaskCreationOptions.DenyChildAttach*/, ts);
                                return;
                            }
                        }
                    }
                    this.SetCompletionAndInvokeContinuation();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(120259870741)
            
            //--TRIMMABLE-BOUNDARY-START(115964903445)
            /*void */ SetCompletionAndInvokeContinuation()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964903445);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object?*/ let ctx = this._capturedContext;
                /*ExecutionContext?*/ let ec = ctx === null ? null : $.$as(ctx, $.$$.System.Threading.ExecutionContext) ?? (($.$as(ctx, $.$stc.System.Threading.Channels.AsyncOperation.CapturedSchedulerAndExecutionContext))?._executionContext ?? null);
                if (ec === null)
                {
                    /*Action<object?>*/ let c = this._continuation;
                    this._continuation = $.$stc.System.Threading.Channels.AsyncOperation.s_completedSentinel;
                    c.Invoke(this._continuationState);
                }
                else 
                {
                    $.$$.System.Threading.ExecutionContext.Run(ec, new $.$$.System.Threading.ContextCallback().$ctor($.$stc.System.Threading.Channels.AsyncOperation, /*static*/ (/*s*/ s) =>
                    {
                        /*var*/ let thisRef = $.$cast(s, $.$stc.System.Threading.Channels.AsyncOperation);
                        /*Action<object?>*/ let c = thisRef._continuation;
                        thisRef._continuation = $.$stc.System.Threading.Channels.AsyncOperation.s_completedSentinel;
                        c.Invoke(thisRef._continuationState);
                    }, {
  "r": 65537,
  "p": [
    {
      "n": "s",
      "p": 131073
    }
  ],
  "n": "",
  "d": 786453,
  "h": 0,
  "f": 17825826
}), this);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(115964903445)
            
            //--TRIMMABLE-BOUNDARY-START(98785034261)
            /*void */ OnCompleted(/*Action<object?>*/ continuation, /*object?*/ state, /*short*/ token, /*ValueTaskSourceOnCompletedFlags*/ flags)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785034261);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._currentId !== token)
                {
                    $.$stc.System.Threading.Channels.AsyncOperation.ThrowIncorrectCurrentIdException();
                }
                if (!(this._continuationState === null))
                {
                    $.$stc.System.Threading.Channels.AsyncOperation.ThrowMultipleContinuations();
                }
                this._continuationState = state;
                $.$$.System.Diagnostics.Debug.Assert$2(this._capturedContext === null, "_capturedContext is null");
                if ((flags & 2/*ValueTaskSourceOnCompletedFlags.FlowExecutionContext*/) !== 0)
                {
                    this._capturedContext = $.$$.System.Threading.ExecutionContext.Capture();
                }
                /*SynchronizationContext?*/ let sc = null;
                /*TaskScheduler?*/ let ts = null;
                if ((flags & 1/*ValueTaskSourceOnCompletedFlags.UseSchedulingContext*/) !== 0)
                {
                    sc = $.$$.System.Threading.SynchronizationContext.Current;
                    if (!(sc === null) && $.$$.System.Type.op_Inequality$1($.$$.System.Object.GetType.call(sc), $.$$.System.Threading.SynchronizationContext.$type))
                    {
                        this._capturedContext = this._capturedContext === null ? sc : new $.$stc.System.Threading.Channels.AsyncOperation.CapturedSchedulerAndExecutionContext().$ctor$1(sc, $.$cast(this._capturedContext, $.$$.System.Threading.ExecutionContext));
                    }
                    else 
                    {
                        sc = null;
                        ts = $.$$.System.Threading.Tasks.TaskScheduler.Current;
                        if (ts !== $.$$.System.Threading.Tasks.TaskScheduler.Default)
                        {
                            this._capturedContext = this._capturedContext === null ? ts : new $.$stc.System.Threading.Channels.AsyncOperation.CapturedSchedulerAndExecutionContext().$ctor$1(ts, $.$cast(this._capturedContext, $.$$.System.Threading.ExecutionContext));
                        }
                        else 
                        {
                            ts = null;
                        }
                    }
                }
                /*Action<object?>?*/ let prevContinuation = $.$$.System.Threading.Interlocked.CompareExchange$14($.$$.System.Action$$($.$$.System.Object), $.$ref(() => this._continuation, ($v) => this._continuation = $v, $.$$.System.Action$$($.$$.System.Object)), continuation, null);
                if (!(prevContinuation === null))
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(this.IsCompleted, `Expected IsCompleted`);
                    if (!$.$$.System.Object.ReferenceEquals(prevContinuation, $.$stc.System.Threading.Channels.AsyncOperation.s_completedSentinel))
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(prevContinuation !== $.$stc.System.Threading.Channels.AsyncOperation.s_availableSentinel, "Continuation was the available sentinel.");
                        $.$stc.System.Threading.Channels.AsyncOperation.ThrowMultipleContinuations();
                    }
                    if (this._capturedContext === null)
                    {
                        $.$stc.System.Threading.Channels.ChannelUtilities.UnsafeQueueUserWorkItem($.$$.System.Object, continuation, state);
                    }
                    else if (!(sc === null))
                    {
                        sc.Post(new $.$$.System.Threading.SendOrPostCallback().$ctor($.$stc.System.Threading.Channels.AsyncOperation, /*static*/ (/*s*/ s) =>
                        {
                            /*var*/ let t = $.$cast(s, $.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Action$$($.$$.System.Object), $.$$.System.Object));
                            t.Key.Invoke(t.Value);
                        }, {
  "r": 65537,
  "p": [
    {
      "n": "s",
      "p": 131073
    }
  ],
  "n": "",
  "d": 786453,
  "h": 0,
  "f": 17825826
}), new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Action$$($.$$.System.Object), $.$$.System.Object))().$ctor$3(continuation, state));
                    }
                    else if (!(ts === null))
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(!(ts === null), "ts is not null");
                        $.$$.System.Threading.Tasks.Task.Factory.StartNew$4(continuation, state, $.$$.System.Threading.CancellationToken.None, 8/*TaskCreationOptions.DenyChildAttach*/, ts);
                    }
                    else 
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2($.$is(this._capturedContext, $.$$.System.Threading.ExecutionContext), "_capturedContext is ExecutionContext");
                        $.$stc.System.Threading.Channels.ChannelUtilities.QueueUserWorkItem(continuation, state);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(98785034261)
            
            //--TRIMMABLE-BOUNDARY-START(851989)
            static $_CapturedSchedulerAndExecutionContext;
            static get CapturedSchedulerAndExecutionContext()
            {
                let $cls = $.$stc.System.Threading.Channels.AsyncOperation;
                return $cls.$_CapturedSchedulerAndExecutionContext ??= $asm.$ncls("$stc.System.Threading.Channels.AsyncOperation.CapturedSchedulerAndExecutionContext", ($self) => class CapturedSchedulerAndExecutionContext extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(8590786581)
                    /*object*/ _scheduler = null;
                    //--TRIMMABLE-BOUNDARY-END(8590786581)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295819285)
                    /*ExecutionContext*/ _executionContext = null;
                    //--TRIMMABLE-BOUNDARY-END(4295819285)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885753877)
                    $ctor$1(/*object*/ scheduler, /*ExecutionContext*/ executionContext)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(12885753877);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            let $t1;
                            let $t2;
                            $.$$.System.Diagnostics.Debug.Assert$4(scheduler !== null && ((($.$is(scheduler, $.$$.System.Threading.SynchronizationContext, { set $v(v){ $t1 = v } }) && $t1 === $.$$.System.Threading.SynchronizationContext)) || (($.$is(scheduler, $.$$.System.Threading.Tasks.TaskScheduler, { set $v(v){ $t2 = v } }) && $t2 === $.$$.System.Threading.Tasks.TaskScheduler))), `${"scheduler"} is ${$.$$.System.Object.ToString.call(scheduler)}`);
                            $.$$.System.Diagnostics.Debug.Assert$2(!(executionContext === null), `${"executionContext"} is null`);
                            this._scheduler = scheduler;
                            this._executionContext = executionContext;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885753877)
                    
                    static $h = 851989;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590786581),
    {
      "t": 131073,
      "n": "_scheduler",
      "d": 851989,
      "h": 8590786581,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(8590786581),
//--TRIMMABLE-BOUNDARY-START(4295819285),
    {
      "t": 171048961,
      "n": "_executionContext",
      "d": 851989,
      "h": 4295819285,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(4295819285)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885753877),
    {
      "p": [
        {
          "n": "scheduler",
          "p": 131073
        },
        {
          "n": "executionContext",
          "p": 171048961
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 851989,
      "h": 12885753877,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885753877)
  ],
  "d": 786453,
  "h": 851989
}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Threading.Channels.AsyncOperation.CapturedSchedulerAndExecutionContext`; }
                }, $cls, ($v) => $cls.$_CapturedSchedulerAndExecutionContext = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(851989)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4295753749)
                this._cancellationRegistration = $.$default($.$$.System.Threading.CancellationTokenRegistration);
                //--TRIMMABLE-BOUNDARY-END(4295753749)
                
            }
            //--TRIMMABLE-BOUNDARY-START(47245426709)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(107374968853)
                    this.s_availableSentinel = new ($.$$.System.Action$$($.$$.System.Object))().$ctor($.$stc.System.Threading.Channels.AsyncOperation, $.$stc.System.Threading.Channels.AsyncOperation.AvailableSentinel);
                    //--TRIMMABLE-BOUNDARY-END(107374968853)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(111669936149)
                    this.s_completedSentinel = new ($.$$.System.Action$$($.$$.System.Object))().$ctor($.$stc.System.Threading.Channels.AsyncOperation, $.$stc.System.Threading.Channels.AsyncOperation.CompletedSentinel);
                    //--TRIMMABLE-BOUNDARY-END(111669936149)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47245426709)
            
            static $h = 786453;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(103080001557),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195099669,
        "f": 50331649
      },
      "n": "RunContinuationsAsynchronously",
      "d": 786453,
      "h": 103080001557,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103080001557),
//--TRIMMABLE-BOUNDARY-START(60130328597),
    {
      "p": 170065921,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015230485,
        "f": 50331650
      },
      "n": "CancellationToken",
      "d": 786453,
      "h": 60130328597,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(60130328597),
//--TRIMMABLE-BOUNDARY-START(94490066965),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605165077,
        "f": 50331656
      },
      "n": "IsCompleted",
      "d": 786453,
      "h": 94490066965,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(94490066965)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(158914576405),
    {
      "r": 65537,
      "n": "UnsafeQueueSetCompletionAndInvokeContinuation",
      "d": 786453,
      "h": 158914576405,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(158914576405),
//--TRIMMABLE-BOUNDARY-START(154619609109),
    {
      "r": 65537,
      "p": [
        {
          "n": "registration",
          "p": 170131457
        }
      ],
      "n": "Unregister",
      "d": 786453,
      "h": 154619609109,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(154619609109),
//--TRIMMABLE-BOUNDARY-START(55835361301),
    {
      "r": 65537,
      "p": [
        {
          "n": "s",
          "p": 131073
        }
      ],
      "n": "AvailableSentinel",
      "d": 786453,
      "h": 55835361301,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(55835361301),
//--TRIMMABLE-BOUNDARY-START(64425295893),
    {
      "r": 65537,
      "p": [
        {
          "n": "s",
          "p": 131073
        }
      ],
      "n": "CompletedSentinel",
      "d": 786453,
      "h": 64425295893,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(64425295893),
//--TRIMMABLE-BOUNDARY-START(128849805333),
    {
      "r": 65537,
      "n": "ThrowIncompleteOperationException",
      "d": 786453,
      "h": 128849805333,
      "f": 16777252
    },
//--TRIMMABLE-BOUNDARY-END(128849805333),
//--TRIMMABLE-BOUNDARY-START(137439739925),
    {
      "r": 65537,
      "n": "ThrowMultipleContinuations",
      "d": 786453,
      "h": 137439739925,
      "f": 16777252
    },
//--TRIMMABLE-BOUNDARY-END(137439739925),
//--TRIMMABLE-BOUNDARY-START(133144772629),
    {
      "r": 65537,
      "n": "ThrowIncorrectCurrentIdException",
      "d": 786453,
      "h": 133144772629,
      "f": 16777252
    },
//--TRIMMABLE-BOUNDARY-END(133144772629),
//--TRIMMABLE-BOUNDARY-START(150324641813),
    {
      "r": 262145,
      "p": [
        {
          "n": "exception",
          "p": 80019457
        }
      ],
      "n": "TrySetException",
      "d": 786453,
      "h": 150324641813,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(150324641813),
//--TRIMMABLE-BOUNDARY-START(146029674517),
    {
      "r": 262145,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170065921,
          "f": 65
        }
      ],
      "n": "TrySetCanceled",
      "d": 786453,
      "h": 146029674517,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(146029674517),
//--TRIMMABLE-BOUNDARY-START(141734707221),
    {
      "r": 262145,
      "n": "TryReserveCompletionIfCancelable",
      "d": 786453,
      "h": 141734707221,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(141734707221),
//--TRIMMABLE-BOUNDARY-START(120259870741),
    {
      "r": 65537,
      "n": "SignalCompletion",
      "d": 786453,
      "h": 120259870741,
      "f": 16777216
    },
//--TRIMMABLE-BOUNDARY-END(120259870741),
//--TRIMMABLE-BOUNDARY-START(115964903445),
    {
      "r": 65537,
      "n": "SetCompletionAndInvokeContinuation",
      "d": 786453,
      "h": 115964903445,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(115964903445),
//--TRIMMABLE-BOUNDARY-START(98785034261),
    {
      "r": 65537,
      "p": [
        {
          "n": "continuation",
          "p": $.$$.System.Action$$($.$$.System.Object).$h
        },
        {
          "n": "state",
          "p": 131073
        },
        {
          "n": "token",
          "p": 524289
        },
        {
          "n": "flags",
          "p": 177274881
        }
      ],
      "n": "OnCompleted",
      "d": 786453,
      "h": 98785034261,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(98785034261)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(107374968853),
    {
      "t": $.$$.System.Action$$($.$$.System.Object).$h,
      "n": "s_availableSentinel",
      "d": 786453,
      "h": 107374968853,
      "f": 4194340
    },
//--TRIMMABLE-BOUNDARY-END(107374968853),
//--TRIMMABLE-BOUNDARY-START(111669936149),
    {
      "t": $.$$.System.Action$$($.$$.System.Object).$h,
      "n": "s_completedSentinel",
      "d": 786453,
      "h": 111669936149,
      "f": 4194340
    },
//--TRIMMABLE-BOUNDARY-END(111669936149),
//--TRIMMABLE-BOUNDARY-START(4295753749),
    {
      "t": 170131457,
      "n": "_cancellationRegistration",
      "d": 786453,
      "h": 4295753749,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295753749),
//--TRIMMABLE-BOUNDARY-START(34360524821),
    {
      "t": 262145,
      "n": "_pooled",
      "d": 786453,
      "h": 34360524821,
      "f": 4194304
    },
//--TRIMMABLE-BOUNDARY-END(34360524821),
//--TRIMMABLE-BOUNDARY-START(12885688341),
    {
      "t": 262145,
      "n": "_completionReserved",
      "d": 786453,
      "h": 12885688341,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885688341),
//--TRIMMABLE-BOUNDARY-START(30065557525),
    {
      "t": 135004161,
      "n": "_error",
      "d": 786453,
      "h": 30065557525,
      "f": 4194304
    },
//--TRIMMABLE-BOUNDARY-END(30065557525),
//--TRIMMABLE-BOUNDARY-START(17180655637),
    {
      "t": $.$$.System.Action$$($.$$.System.Object).$h,
      "n": "_continuation",
      "d": 786453,
      "h": 17180655637,
      "f": 4194304
    },
//--TRIMMABLE-BOUNDARY-END(17180655637),
//--TRIMMABLE-BOUNDARY-START(21475622933),
    {
      "t": 131073,
      "n": "_continuationState",
      "d": 786453,
      "h": 21475622933,
      "f": 4194304
    },
//--TRIMMABLE-BOUNDARY-END(21475622933),
//--TRIMMABLE-BOUNDARY-START(8590721045),
    {
      "t": 131073,
      "n": "_capturedContext",
      "d": 786453,
      "h": 8590721045,
      "f": 4194304
    },
//--TRIMMABLE-BOUNDARY-END(8590721045),
//--TRIMMABLE-BOUNDARY-START(25770590229),
    {
      "t": 524289,
      "n": "_currentId",
      "d": 786453,
      "h": 25770590229,
      "f": 4194304
    },
//--TRIMMABLE-BOUNDARY-END(25770590229)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(51540394005),
    {
      "p": [
        {
          "n": "runContinuationsAsynchronously",
          "p": 262145
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        },
        {
          "n": "pooled",
          "p": 262145
        },
        {
          "n": "cancellationCallback",
          "p": $.$$.System.Action$$$($.$$.System.Object, $.$$.System.Threading.CancellationToken).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 786453,
      "h": 51540394005,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(51540394005)
  ],
  "i": [171507713
  ],
  "j": [851989
  ],
  "h": 786453
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Threading.IThreadPoolWorkItem ]; }
            static get $fullName() { return `System.Threading.Channels.AsyncOperation`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786453)
        
        
        //--TRIMMABLE-BOUNDARY-START(1638421)
        $asm.$cls("$stc.System.Threading.Channels.Channel<>", (T) => $asm.$gt("$stc.System.Threading.Channels.Channel<>", [T], ($self) => class Channel$$ extends $.$stc.System.Threading.Channels.Channel$$$(T, T)
        {
            //--TRIMMABLE-BOUNDARY-START(4296605717)
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296605717)
            
            static $h = 1638421;
            static $g = 1;
            static $f = 0b1110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296605717),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4296605717)
  ],
  "g": [T?.$h??1507328
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$stc.System.Threading.Channels.Channel$$$(T, T); }
            static get $fullName() { return `System.Threading.Channels.Channel<${T?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1638421)
        
        
        //--TRIMMABLE-BOUNDARY-START(983061)
        $asm.$cls("$stc.System.Threading.Channels.AsyncOperation<>", (TSelf) => $asm.$gt("$stc.System.Threading.Channels.AsyncOperation<>", [TSelf], ($self) => class AsyncOperation$$ extends $.$stc.System.Threading.Channels.AsyncOperation
        {
            //--TRIMMABLE-BOUNDARY-START(12885884949)
            $ctor$2(/*bool*/ runContinuationsAsynchronously, /*CancellationToken*/ cancellationToken, /*bool*/ pooled, /*Action<object?, CancellationToken>?*/ cancellationCallback)
            {
                super.$ctor$1(runContinuationsAsynchronously, cancellationToken, pooled, cancellationCallback);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885884949);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885884949)
            
            //--TRIMMABLE-BOUNDARY-START(47245623317)
            /*TSelf?*/ Next = null;
            //--TRIMMABLE-BOUNDARY-END(47245623317)
            
            //--TRIMMABLE-BOUNDARY-START(51540590613)
            /*TSelf?*/ Previous = null;
            //--TRIMMABLE-BOUNDARY-END(51540590613)
            
            //--TRIMMABLE-BOUNDARY-START(77310394389)
            /*ValueTask */ get ValueTask()
            {
                return new $.$$.System.Threading.Tasks.ValueTask().$ctor$4(this, this._currentId);
            }
            //--TRIMMABLE-BOUNDARY-END(77310394389)
            
            //--TRIMMABLE-BOUNDARY-START(42950656021)
            /*ValueTaskSourceStatus */ GetStatus(/*short*/ token)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950656021);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._currentId !== token)
                {
                    $.$stc.System.Threading.Channels.AsyncOperation.ThrowIncorrectCurrentIdException();
                }
                return !this.IsCompleted ? 0/*ValueTaskSourceStatus.Pending*/ : this._error === null ? 1/*ValueTaskSourceStatus.Succeeded*/ : $.$is(this._error.SourceException, $.$$.System.OperationCanceledException) ? 3/*ValueTaskSourceStatus.Canceled*/ : 2/*ValueTaskSourceStatus.Faulted*/;
            }
            //--TRIMMABLE-BOUNDARY-END(42950656021)
            
            //--TRIMMABLE-BOUNDARY-START(73015427093)
            /*void */ System$Threading$Tasks$Sources$IValueTaskSource$GetResult(/*short*/ token)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015427093);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._currentId !== token)
                {
                    $.$stc.System.Threading.Channels.AsyncOperation.ThrowIncorrectCurrentIdException();
                }
                if (!this.IsCompleted)
                {
                    $.$stc.System.Threading.Channels.AsyncOperation.ThrowIncompleteOperationException();
                }
                /*ExceptionDispatchInfo?*/ let error = this._error;
                this._currentId++;
                if (this._pooled)
                {
                    $.$ref(() => this._continuation, ($v) => this._continuation = $v, $.$$.System.Action$$($.$$.System.Object)).$v = $.$stc.System.Threading.Channels.AsyncOperation.s_availableSentinel;
                }
                error?.Throw();
            }
            //--TRIMMABLE-BOUNDARY-END(73015427093)
            
            //--TRIMMABLE-BOUNDARY-START(8766947329)
            //Generated interface implemetation for System.Threading.Tasks.Sources.IValueTaskSource.GetStatus(short)
            System$Threading$Tasks$Sources$IValueTaskSource$GetStatus()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8766947329);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetStatus(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8766947329)
            
            //--TRIMMABLE-BOUNDARY-START(13061914625)
            //Generated interface implemetation for System.Threading.Tasks.Sources.IValueTaskSource.OnCompleted(System.Action<object?>, object?, short, System.Threading.Tasks.Sources.ValueTaskSourceOnCompletedFlags)
            System$Threading$Tasks$Sources$IValueTaskSource$OnCompleted()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(13061914625);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnCompleted(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(13061914625)
            
            static $h = 983061;
            static $g = 1;
            static $f = 0b1110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 786453,
  "p": [
//--TRIMMABLE-BOUNDARY-START(47245623317),
    {
      "p": TSelf?.$h??1507328,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x500000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xE00000000n),
        "f": 83886081
      },
      "n": "Next",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47245623317),
//--TRIMMABLE-BOUNDARY-START(51540590613),
    {
      "p": TSelf?.$h??1507328,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x700000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1000000000n),
        "f": 83886081
      },
      "n": "Previous",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540590613),
//--TRIMMABLE-BOUNDARY-START(77310394389),
    {
      "p": 180551681,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x900000000n),
        "f": 50331649
      },
      "n": "ValueTask",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1200000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77310394389)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(42950656021),
    {
      "r": 177340417,
      "p": [
        {
          "n": "token",
          "p": 524289
        }
      ],
      "n": "GetStatus",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950656021)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885884949),
    {
      "p": [
        {
          "n": "runContinuationsAsynchronously",
          "p": 262145
        },
        {
          "n": "cancellationToken",
          "p": 170065921,
          "f": 65
        },
        {
          "n": "pooled",
          "p": 262145,
          "f": 65,
          "v": false
        },
        {
          "n": "cancellationCallback",
          "p": $.$$.System.Action$$$($.$$.System.Object, $.$$.System.Threading.CancellationToken).$h,
          "f": 65
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(12885884949)
  ],
  "i": [171507713,177012737
  ],
  "g": [TSelf?.$h??1507328
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$stc.System.Threading.Channels.AsyncOperation; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Threading.IThreadPoolWorkItem, $.$$.System.Threading.Tasks.Sources.IValueTaskSource ]; }
            static get $fullName() { return `System.Threading.Channels.AsyncOperation<${TSelf?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(983061)
        
        
        //--TRIMMABLE-BOUNDARY-START(917525)
        $asm.$cls("$stc.System.Threading.Channels.AsyncOperation<,>", (TSelf, TResult) => $asm.$gt("$stc.System.Threading.Channels.AsyncOperation<,>", [TSelf, TResult], ($self) => class AsyncOperation$$$ extends $.$stc.System.Threading.Channels.AsyncOperation$$(TSelf)
        {
            //--TRIMMABLE-BOUNDARY-START(4295884821)
            /*TResult?*/ _result = null;
            //--TRIMMABLE-BOUNDARY-END(4295884821)
            
            //--TRIMMABLE-BOUNDARY-START(8590852117)
            $ctor$3(/*bool*/ runContinuationsAsynchronously, /*CancellationToken*/ cancellationToken, /*bool*/ pooled, /*Action<object?, CancellationToken>?*/ cancellationCallback)
            {
                super.$ctor$2(runContinuationsAsynchronously, cancellationToken, pooled, cancellationCallback);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590852117);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590852117)
            
            //--TRIMMABLE-BOUNDARY-START(38655623189)
            /*ValueTask<TResult> */ get ValueTaskOfT()
            {
                return new ($.$$.System.Threading.Tasks.ValueTask$$(TResult))().$ctor$4(this, this._currentId);
            }
            //--TRIMMABLE-BOUNDARY-END(38655623189)
            
            //--TRIMMABLE-BOUNDARY-START(25770721301)
            /*TResult */ GetResult(/*short*/ token)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770721301);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._currentId !== token)
                {
                    $.$stc.System.Threading.Channels.AsyncOperation.ThrowIncorrectCurrentIdException();
                }
                if (!this.IsCompleted)
                {
                    $.$stc.System.Threading.Channels.AsyncOperation.ThrowIncompleteOperationException();
                }
                /*ExceptionDispatchInfo?*/ let error = this._error;
                /*TResult?*/ let result = this._result;
                this._currentId++;
                if (this._pooled)
                {
                    $.$ref(() => this._continuation, ($v) => this._continuation = $v, $.$$.System.Action$$($.$$.System.Object)).$v = $.$stc.System.Threading.Channels.AsyncOperation.s_availableSentinel;
                }
                error?.Throw();
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(25770721301)
            
            //--TRIMMABLE-BOUNDARY-START(30065688597)
            /*bool */ TryOwnAndReset()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065688597);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(this._pooled, "Should only be used for pooled objects");
                if ($.$$.System.Object.ReferenceEquals($.$$.System.Threading.Interlocked.CompareExchange$14($.$$.System.Action$$($.$$.System.Object), $.$ref(() => this._continuation, ($v) => this._continuation = $v, $.$$.System.Action$$($.$$.System.Object)), null, $.$stc.System.Threading.Channels.AsyncOperation.s_availableSentinel), $.$stc.System.Threading.Channels.AsyncOperation.s_availableSentinel))
                {
                    this._continuationState = null;
                    this._result = $.$default(TResult);
                    this._error = null;
                    this._capturedContext = null;
                    return true;
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(30065688597)
            
            //--TRIMMABLE-BOUNDARY-START(34360655893)
            /*bool */ TrySetResult(/*TResult*/ result)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360655893);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.TryReserveCompletionIfCancelable())
                {
                    this.DangerousSetResult(result);
                    return true;
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(34360655893)
            
            //--TRIMMABLE-BOUNDARY-START(12885819413)
            /*void */ DangerousSetResult(/*TResult*/ result)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885819413);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._result = result;
                this.SignalCompletion();
            }
            //--TRIMMABLE-BOUNDARY-END(12885819413)
            
            //--TRIMMABLE-BOUNDARY-START(8767012865)
            //Generated interface implemetation for System.Threading.Tasks.Sources.IValueTaskSource<TResult>.GetStatus(short)
            System$Threading$Tasks$Sources$IValueTaskSource$$$GetStatus()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8767012865);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetStatus(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8767012865)
            
            //--TRIMMABLE-BOUNDARY-START(13061980161)
            //Generated interface implemetation for System.Threading.Tasks.Sources.IValueTaskSource<TResult>.OnCompleted(System.Action<object?>, object?, short, System.Threading.Tasks.Sources.ValueTaskSourceOnCompletedFlags)
            System$Threading$Tasks$Sources$IValueTaskSource$$$OnCompleted()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(13061980161);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnCompleted(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(13061980161)
            
            //--TRIMMABLE-BOUNDARY-START(4472045569)
            //Generated interface implemetation for System.Threading.Tasks.Sources.IValueTaskSource<TResult>.GetResult(short)
            System$Threading$Tasks$Sources$IValueTaskSource$$$GetResult()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4472045569);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetResult(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4472045569)
            
            static $h = 917525;
            static $g = 2;
            static $f = 0b1110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38655623189),
    {
      "p": $.$$.System.Threading.Tasks.ValueTask$$(TResult).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x500000000n),
        "f": 50331649
      },
      "n": "ValueTaskOfT",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655623189)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770721301),
    {
      "r": TResult?.$h??1572864,
      "p": [
        {
          "n": "token",
          "p": 524289
        }
      ],
      "n": "GetResult",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770721301),
//--TRIMMABLE-BOUNDARY-START(30065688597),
    {
      "r": 262145,
      "n": "TryOwnAndReset",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065688597),
//--TRIMMABLE-BOUNDARY-START(34360655893),
    {
      "r": 262145,
      "p": [
        {
          "n": "result",
          "p": TResult?.$h??1572864
        }
      ],
      "n": "TrySetResult",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360655893),
//--TRIMMABLE-BOUNDARY-START(12885819413),
    {
      "r": 65537,
      "p": [
        {
          "n": "result",
          "p": TResult?.$h??1572864
        }
      ],
      "n": "DangerousSetResult",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885819413)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295884821),
    {
      "t": TResult?.$h??1572864,
      "n": "_result",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295884821)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590852117),
    {
      "p": [
        {
          "n": "runContinuationsAsynchronously",
          "p": 262145
        },
        {
          "n": "cancellationToken",
          "p": 170065921,
          "f": 65
        },
        {
          "n": "pooled",
          "p": 262145,
          "f": 65,
          "v": false
        },
        {
          "n": "cancellationCallback",
          "p": $.$$.System.Action$$$($.$$.System.Object, $.$$.System.Threading.CancellationToken).$h,
          "f": 65
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590852117)
  ],
  "i": [171507713,177012737,$.$$.System.Threading.Tasks.Sources.IValueTaskSource$$(TResult).$h
  ],
  "g": [TSelf?.$h??1507328,TResult?.$h??1572864
  ],
  "r": 2,
  "h": this.$h
}; }
            static get $b() { return $.$stc.System.Threading.Channels.AsyncOperation$$(TSelf); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Threading.IThreadPoolWorkItem, $.$$.System.Threading.Tasks.Sources.IValueTaskSource, $.$$.System.Threading.Tasks.Sources.IValueTaskSource$$(TResult) ]; }
            static get $fullName() { return `System.Threading.Channels.AsyncOperation<${TSelf?.$fullName},${TResult?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(917525)
        
        
        //--TRIMMABLE-BOUNDARY-START(720917)
        $asm.$cls("$stc.System.SR", ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(137439674389)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(137439674389)
            
            //--TRIMMABLE-BOUNDARY-START(128849739797)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(128849739797)
            
            //--TRIMMABLE-BOUNDARY-START(133144707093)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784968725);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Object.ReferenceEquals($.$stc.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("System.Threading.Channels", $.$stc.System.SR.$type.Assembly);
                    $.$stc.System.SR.s_resourceManager = temp;
                }
                return $.$stc.System.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(133144707093)
            
            //--TRIMMABLE-BOUNDARY-START(12885622805)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425230357);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$stc.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324576277);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$stc.System.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(12885622805)
            
            //--TRIMMABLE-BOUNDARY-START(8590655509)
            static /*string */ get ChannelClosedException_DefaultMessage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835295765);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The channel has been closed.";
            }
            //--TRIMMABLE-BOUNDARY-END(8590655509)
            
            //--TRIMMABLE-BOUNDARY-START(115964837909)
            static /*string */ get InvalidOperation_IncompleteAsyncOperation()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015164949);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The asynchronous operation has not completed.";
            }
            //--TRIMMABLE-BOUNDARY-END(115964837909)
            
            //--TRIMMABLE-BOUNDARY-START(124554772501)
            static /*string */ get InvalidOperation_MultipleContinuations()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195034133);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Another continuation was already registered.";
            }
            //--TRIMMABLE-BOUNDARY-END(124554772501)
            
            //--TRIMMABLE-BOUNDARY-START(120259805205)
            static /*string */ get InvalidOperation_IncorrectToken()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605099541);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The result of the operation was already consumed and may not be used again.";
            }
            //--TRIMMABLE-BOUNDARY-END(120259805205)
            
            //--TRIMMABLE-BOUNDARY-START(141734641685)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(141734641685)
            
            //--TRIMMABLE-BOUNDARY-START(111669870613)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(111669870613);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*bool*/ let usingResourceKeys;
                    return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(111669870613)
            
            //--TRIMMABLE-BOUNDARY-START(154619543573)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(154619543573);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$stc.System.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(154619543573)
            
            //--TRIMMABLE-BOUNDARY-START(107374903317)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374903317);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$stc.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$stc.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(107374903317)
            
            //--TRIMMABLE-BOUNDARY-START(103079936021)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079936021);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$stc.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(103079936021)
            
            //--TRIMMABLE-BOUNDARY-START(42950393877)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950393877);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$stc.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(42950393877)
            
            //--TRIMMABLE-BOUNDARY-START(38655426581)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655426581);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$stc.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(38655426581)
            
            //--TRIMMABLE-BOUNDARY-START(34360459285)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360459285);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$stc.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(34360459285)
            
            //--TRIMMABLE-BOUNDARY-START(47245361173)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245361173);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$stc.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(47245361173)
            
            //--TRIMMABLE-BOUNDARY-START(25770524693)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770524693);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$stc.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(25770524693)
            
            //--TRIMMABLE-BOUNDARY-START(21475557397)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475557397);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$stc.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(21475557397)
            
            //--TRIMMABLE-BOUNDARY-START(17180590101)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180590101);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$stc.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(17180590101)
            
            //--TRIMMABLE-BOUNDARY-START(30065491989)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065491989);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$stc.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(30065491989)
            
            //--TRIMMABLE-BOUNDARY-START(4295688213)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(141734641685)
                    this.s_usingResourceKeys = $.$stc.System.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(141734641685)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295688213)
            
            static $h = 720917;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "h": 720917
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(720917)
        
        
        //--TRIMMABLE-BOUNDARY-START(1507349)
        $asm.$cls("$stc.System.Threading.Channels.Channel", ($self) => class Channel
        {
            //--TRIMMABLE-BOUNDARY-START(17181376533)
            static /*Channel<T> */ CreateUnbounded(T)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181376533);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new ($.$stc.System.Threading.Channels.UnboundedChannel$$(T))().$ctor$3(true);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17181376533)
            
            //--TRIMMABLE-BOUNDARY-START(21476343829)
            static /*Channel<T> */ CreateUnbounded$1(T, /*UnboundedChannelOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476343829);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(options, "options");
                if (options.SingleReader)
                {
                    return new ($.$stc.System.Threading.Channels.SingleConsumerUnboundedChannel$$(T))().$ctor$3(!options.AllowSynchronousContinuations);
                }
                return new ($.$stc.System.Threading.Channels.UnboundedChannel$$(T))().$ctor$3(!options.AllowSynchronousContinuations);
            }
            //--TRIMMABLE-BOUNDARY-END(21476343829)
            
            //--TRIMMABLE-BOUNDARY-START(4296474645)
            static /*Channel<T> */ CreateBounded(T, /*int*/ capacity)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296474645);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return capacity > 0 ? new ($.$stc.System.Threading.Channels.BoundedChannel$$(T))().$ctor$3(capacity, 0/*BoundedChannelFullMode.Wait*/, true, null) : capacity === 0 ? new ($.$stc.System.Threading.Channels.RendezvousChannel$$(T))().$ctor$3(0/*BoundedChannelFullMode.Wait*/, true, null) : (() =>
                    {
        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("capacity")            })();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296474645)
            
            //--TRIMMABLE-BOUNDARY-START(12886409237)
            static /*Channel<T> */ CreateBounded$2(T, /*BoundedChannelOptions*/ options)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886409237);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$stc.System.Threading.Channels.Channel.CreateBounded$1(T, options, null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886409237)
            
            //--TRIMMABLE-BOUNDARY-START(8591441941)
            static /*Channel<T> */ CreateBounded$1(T, /*BoundedChannelOptions*/ options, /*Action<T>?*/ itemDropped)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591441941);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(options, "options");
                return options.Capacity > 0 ? new ($.$stc.System.Threading.Channels.BoundedChannel$$(T))().$ctor$3(options.Capacity, options.FullMode, !options.AllowSynchronousContinuations, itemDropped) : new ($.$stc.System.Threading.Channels.RendezvousChannel$$(T))().$ctor$3(options.FullMode, !options.AllowSynchronousContinuations, itemDropped);
            }
            //--TRIMMABLE-BOUNDARY-END(8591441941)
            
            //--TRIMMABLE-BOUNDARY-START(25771311125)
            static /*Channel<T> */ CreateUnboundedPrioritized(T)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25771311125);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new ($.$stc.System.Threading.Channels.UnboundedPrioritizedChannel$$(T))().$ctor$3(true, null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25771311125)
            
            //--TRIMMABLE-BOUNDARY-START(30066278421)
            static /*Channel<T> */ CreateUnboundedPrioritized$1(T, /*UnboundedPrioritizedChannelOptions<T>*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066278421);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(options, "options");
                return new ($.$stc.System.Threading.Channels.UnboundedPrioritizedChannel$$(T))().$ctor$3(!options.AllowSynchronousContinuations, options.Comparer);
            }
            //--TRIMMABLE-BOUNDARY-END(30066278421)
            
            static $h = 1507349;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181376533),
    {
      "r": (T) => $.$stc.System.Threading.Channels.Channel$$(T).$h,
      "g": [
        "T"
      ],
      "n": "CreateUnbounded",
      "d": 1507349,
      "h": 17181376533,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181376533),
//--TRIMMABLE-BOUNDARY-START(21476343829),
    {
      "r": (T) => $.$stc.System.Threading.Channels.Channel$$(T).$h,
      "p": [
        {
          "n": "options",
          "p": 2752533
        }
      ],
      "g": [
        "T"
      ],
      "n": "CreateUnbounded",
      "o": "@$1",
      "d": 1507349,
      "h": 21476343829,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(21476343829),
//--TRIMMABLE-BOUNDARY-START(4296474645),
    {
      "r": (T) => $.$stc.System.Threading.Channels.Channel$$(T).$h,
      "p": [
        {
          "n": "capacity",
          "p": 655361
        }
      ],
      "g": [
        "T"
      ],
      "n": "CreateBounded",
      "d": 1507349,
      "h": 4296474645,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4296474645),
//--TRIMMABLE-BOUNDARY-START(12886409237),
    {
      "r": (T) => $.$stc.System.Threading.Channels.Channel$$(T).$h,
      "p": [
        {
          "n": "options",
          "p": 1441813
        }
      ],
      "g": [
        "T"
      ],
      "n": "CreateBounded",
      "o": "@$2",
      "d": 1507349,
      "h": 12886409237,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886409237),
//--TRIMMABLE-BOUNDARY-START(8591441941),
    {
      "r": (T) => $.$stc.System.Threading.Channels.Channel$$(T).$h,
      "p": [
        {
          "n": "options",
          "p": 1441813
        },
        {
          "n": "itemDropped",
          "p": (T) => $.$$.System.Action$$(T).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "CreateBounded",
      "o": "@$1",
      "d": 1507349,
      "h": 8591441941,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(8591441941),
//--TRIMMABLE-BOUNDARY-START(25771311125),
    {
      "r": (T) => $.$stc.System.Threading.Channels.Channel$$(T).$h,
      "g": [
        "T"
      ],
      "n": "CreateUnboundedPrioritized",
      "d": 1507349,
      "h": 25771311125,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(25771311125),
//--TRIMMABLE-BOUNDARY-START(30066278421),
    {
      "r": (T) => $.$stc.System.Threading.Channels.Channel$$(T).$h,
      "p": [
        {
          "n": "options",
          "p": (T) => $.$stc.System.Threading.Channels.UnboundedPrioritizedChannelOptions$$(T).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "CreateUnboundedPrioritized",
      "o": "@$1",
      "d": 1507349,
      "h": 30066278421,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(30066278421)
  ],
  "h": 1507349
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Threading.Channels.Channel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1507349)
        
        
        //--TRIMMABLE-BOUNDARY-START(2031637)
        $asm.$cls("$stc.System.Threading.Channels.DebugEnumeratorDebugView<>", (T) => $asm.$gt("$stc.System.Threading.Channels.DebugEnumeratorDebugView<>", [T], ($self) => class DebugEnumeratorDebugView$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(21476868117)
            /*T[]*/ Items = null;
            //--TRIMMABLE-BOUNDARY-END(21476868117)
            
            //Begin primary constructor
            /*IDebugEnumerable<T>*/ enumerable = null;
            $ctor$1(/*IDebugEnumerable<T>*/enumerable)
            {
                this.enumerable = enumerable;
                //depends on primary constructor parameter
                this.Items = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray(T.$type, [ ...this.enumerable ], null, null);
                return this
            }
            //End primary constructor
            static $h = 2031637;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(21476868117),
    {
      "p": $.$typeArray(T).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x400000000n),
        "f": 50331649
      },
      "n": "Items",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 2097153,
      "a": [
        {
          "t": 70189057,
          "c": 8660123649,
          "a": [
            {
              "v": 3,
              "t": 70254593
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21476868117)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591966229),
    {
      "p": [
        {
          "n": "enumerable",
          "p": $.$stc.System.Threading.Channels.IDebugEnumerable$$(T).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591966229)
  ],
  "g": [T?.$h??1507328
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Threading.Channels.DebugEnumeratorDebugView<${T?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2031637)
        
        
        //--TRIMMABLE-BOUNDARY-START(589845)
        $asm.$cls("$stc.System.Collections.Generic.Deque<>", (T) => $asm.$gt("$stc.System.Collections.Generic.Deque<>", [T], ($self) => class Deque$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295557141)
            /*T[]*/ _array = null;
            //--TRIMMABLE-BOUNDARY-END(4295557141)
            
            //--TRIMMABLE-BOUNDARY-START(8590524437)
            /*int*/ _head = 0;
            //--TRIMMABLE-BOUNDARY-END(8590524437)
            
            //--TRIMMABLE-BOUNDARY-START(17180459029)
            /*int*/ _tail = 0;
            //--TRIMMABLE-BOUNDARY-END(17180459029)
            
            //--TRIMMABLE-BOUNDARY-START(12885491733)
            /*int*/ _size = 0;
            //--TRIMMABLE-BOUNDARY-END(12885491733)
            
            //--TRIMMABLE-BOUNDARY-START(25770393621)
            /*int */ get Count()
            {
                return this._size;
            }
            //--TRIMMABLE-BOUNDARY-END(25770393621)
            
            //--TRIMMABLE-BOUNDARY-START(68720066581)
            /*bool */ get IsEmpty()
            {
                return this._size === 0;
            }
            //--TRIMMABLE-BOUNDARY-END(68720066581)
            
            //--TRIMMABLE-BOUNDARY-START(38655295509)
            /*void */ EnqueueTail(/*T*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655295509);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._size === this._array.length)
                {
                    this.Grow();
                }
                $.$$.System.Array.$WriteT1.call(this._array, item, this._tail);
                if (++this._tail === this._array.length)
                {
                    this._tail = 0;
                }
                this._size++;
            }
            //--TRIMMABLE-BOUNDARY-END(38655295509)
            
            //--TRIMMABLE-BOUNDARY-START(30065360917)
            /*T */ DequeueHead()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065360917);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(!this.IsEmpty, "!IsEmpty");
                /*T*/ let item = $.$$.System.Array.$ReadT1.call(this._array, this._head);
                $.$$.System.Array.$WriteT1.call(this._array, $.$default(T), this._head);
                if (++this._head === this._array.length)
                {
                    this._head = 0;
                }
                this._size--;
                return item;
            }
            //--TRIMMABLE-BOUNDARY-END(30065360917)
            
            //--TRIMMABLE-BOUNDARY-START(73015033877)
            /*T */ PeekHead()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015033877);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(!this.IsEmpty, "!IsEmpty");
                return $.$$.System.Array.$ReadT1.call(this._array, this._head);
            }
            //--TRIMMABLE-BOUNDARY-END(73015033877)
            
            //--TRIMMABLE-BOUNDARY-START(77310001173)
            /*T */ PeekTail()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310001173);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(!this.IsEmpty, "!IsEmpty");
                /*int*/ let index = ((this._tail - 1) | 0);
                if (index === -1)
                {
                    index = ((this._array.length - 1) | 0);
                }
                return $.$$.System.Array.$ReadT1.call(this._array, index);
            }
            //--TRIMMABLE-BOUNDARY-END(77310001173)
            
            //--TRIMMABLE-BOUNDARY-START(34360328213)
            /*T */ DequeueTail()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360328213);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(!this.IsEmpty, "!IsEmpty");
                if (--this._tail === -1)
                {
                    this._tail = ((this._array.length - 1) | 0);
                }
                /*T*/ let item = $.$$.System.Array.$ReadT1.call(this._array, this._tail);
                $.$$.System.Array.$WriteT1.call(this._array, $.$default(T), this._tail);
                this._size--;
                return item;
            }
            //--TRIMMABLE-BOUNDARY-END(34360328213)
            
            //--TRIMMABLE-BOUNDARY-START(60130131989)
            /*IEnumerator<T> */ GetEnumerator()
            {
                return new ($.$$.NetJs.YieldToIterator$$(T))().$ctor$1(function*()
                {
                    /*int*/ let pos = this._head;
                    /*int*/ let count = this._size;
                    while(count-- > 0)
                    {
                        yield $.$$.System.Array.$ReadT1.call(this._array, pos);
                        pos = (((pos + 1) | 0)) % this._array.length;
                    }
                }.bind(this)).GetEnumerator();
            }
            //--TRIMMABLE-BOUNDARY-END(60130131989)
            
            //--TRIMMABLE-BOUNDARY-START(64425099285)
            /*void */ Grow()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425099285);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(this._size === this._array.length, "_size == _array.Length");
                $.$$.System.Diagnostics.Debug.Assert$2(this._head === this._tail, "_head == _tail");
                /*int*/ let MinimumGrow = 4;
                /*int*/ let capacity = $.$cast((BigInt(this._array.length) * 2n), $.$$.System.Int32);
                if (capacity < ((this._array.length + MinimumGrow) | 0))
                {
                    capacity = ((this._array.length + MinimumGrow) | 0);
                }
                /*T[]*/ let newArray = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(T), null, [capacity], null);
                if (this._head === 0)
                {
                    $.$$.System.Array.Copy(this._array, newArray, this._size);
                }
                else 
                {
                    $.$$.System.Array.Copy$2(this._array, this._head, newArray, 0, ((this._array.length - this._head) | 0));
                    $.$$.System.Array.Copy$2(this._array, 0, newArray, ((this._array.length - this._head) | 0), this._tail);
                }
                this._array = newArray;
                this._head = 0;
                this._tail = this._size;
            }
            //--TRIMMABLE-BOUNDARY-END(64425099285)
            
            //--TRIMMABLE-BOUNDARY-START(21475426325)
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475426325)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4295557141)
                this._array = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray(T.$type, [  ], null, null);
                //--TRIMMABLE-BOUNDARY-END(4295557141)
                
            }
            static $h = 589845;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770393621),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xB00000000n),
        "f": 50331649
      },
      "n": "Count",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770393621),
//--TRIMMABLE-BOUNDARY-START(68720066581),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xD00000000n),
        "f": 50331649
      },
      "n": "IsEmpty",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1000000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68720066581)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38655295509),
    {
      "r": 65537,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1507328
        }
      ],
      "n": "EnqueueTail",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655295509),
//--TRIMMABLE-BOUNDARY-START(30065360917),
    {
      "r": T?.$h??1507328,
      "n": "DequeueHead",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065360917),
//--TRIMMABLE-BOUNDARY-START(73015033877),
    {
      "r": T?.$h??1507328,
      "n": "PeekHead",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73015033877),
//--TRIMMABLE-BOUNDARY-START(77310001173),
    {
      "r": T?.$h??1507328,
      "n": "PeekTail",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77310001173),
//--TRIMMABLE-BOUNDARY-START(34360328213),
    {
      "r": T?.$h??1507328,
      "n": "DequeueTail",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360328213),
//--TRIMMABLE-BOUNDARY-START(60130131989),
    {
      "r": $.$$.System.Collections.Generic.IEnumerator$$(T).$h,
      "n": "GetEnumerator",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60130131989),
//--TRIMMABLE-BOUNDARY-START(64425099285),
    {
      "r": 65537,
      "n": "Grow",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xF00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(64425099285)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295557141),
    {
      "t": $.$typeArray(T).$h,
      "n": "_array",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295557141),
//--TRIMMABLE-BOUNDARY-START(8590524437),
    {
      "t": 655361,
      "n": "_head",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590524437),
//--TRIMMABLE-BOUNDARY-START(17180459029),
    {
      "t": 655361,
      "n": "_tail",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180459029),
//--TRIMMABLE-BOUNDARY-START(12885491733),
    {
      "t": 655361,
      "n": "_size",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885491733)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475426325),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475426325)
  ],
  "g": [T?.$h??1507328
  ],
  "r": 1,
  "h": this.$h,
  "a": [
    {
      "t": 70385665,
      "c": 25840189441,
      "a": [
        {
          "v": "Count = {_size}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Collections.Generic.Deque<${T?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(589845)
        
        
        //--TRIMMABLE-BOUNDARY-START(1900565)
        $asm.$cls("$stc.System.Threading.Channels.ChannelUtilities", ($self) => class ChannelUtilities
        {
            //--TRIMMABLE-BOUNDARY-START(51541508117)
            /*Exception*/ static s_doneWritingSentinel = null;
            //--TRIMMABLE-BOUNDARY-END(51541508117)
            
            //--TRIMMABLE-BOUNDARY-START(64426410005)
            /*Task<bool>*/ static s_trueTask = null;
            //--TRIMMABLE-BOUNDARY-END(64426410005)
            
            //--TRIMMABLE-BOUNDARY-START(55836475413)
            /*Task<bool>*/ static s_falseTask = null;
            //--TRIMMABLE-BOUNDARY-END(55836475413)
            
            //--TRIMMABLE-BOUNDARY-START(60131442709)
            /*Task*/ static s_neverCompletingTask = null;
            //--TRIMMABLE-BOUNDARY-END(60131442709)
            
            //--TRIMMABLE-BOUNDARY-START(12886802453)
            static /*void */ Complete(/*TaskCompletionSource*/ tcs, /*Exception?*/ error)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886802453);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let oce;
                if ($.$is(error, $.$$.System.OperationCanceledException, { set $v(v){ oce = v; } }))
                {
                    tcs.TrySetCanceled$1(oce.CancellationToken);
                }
                else if (!(error === null) && error !== $.$stc.System.Threading.Channels.ChannelUtilities.s_doneWritingSentinel)
                {
                    if (tcs.TrySetException$1(error))
                    {
                        _ = tcs.Task.Exception;
                    }
                }
                else 
                {
                    tcs.TrySetResult();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886802453)
            
            //--TRIMMABLE-BOUNDARY-START(38656606229)
            static /*ValueTask<T> */ GetInvalidCompletionValueTask(T, /*Exception*/ error)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656606229);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(!(error === null), "error is not null");
                let oce;
                /*Task<T>*/ let t = error === $.$stc.System.Threading.Channels.ChannelUtilities.s_doneWritingSentinel ? $.$$.System.Threading.Tasks.Task.FromException$1(T, $.$stc.System.Threading.Channels.ChannelUtilities.CreateInvalidCompletionException(null)) : $.$is(error, $.$$.System.OperationCanceledException, { set $v(v){ oce = v; } }) ? $.$$.System.Threading.Tasks.Task.FromCanceled$3(T, oce.CancellationToken.IsCancellationRequested ? oce.CancellationToken : new $.$$.System.Threading.CancellationToken().$ctor$3(true)) : $.$$.System.Threading.Tasks.Task.FromException$1(T, $.$stc.System.Threading.Channels.ChannelUtilities.CreateInvalidCompletionException(error));
                return new ($.$$.System.Threading.Tasks.ValueTask$$(T))().$ctor$5(t);
            }
            //--TRIMMABLE-BOUNDARY-END(38656606229)
            
            //--TRIMMABLE-BOUNDARY-START(81606279189)
            static /*TAsyncOp? */ TryDequeueAndReserveCompletionIfCancelable(TAsyncOp, /*ref TAsyncOp?*/ head)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81606279189);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let op;
                while($.$stc.System.Threading.Channels.ChannelUtilities.TryDequeue(TAsyncOp, head, $.$ref(() => op, ($v) => op = $v, TAsyncOp)))
                {
                    if ($.$dsp(op, TAsyncOp, ($t) => $t.TryReserveCompletionIfCancelable,))
                    {
                        return op;
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(81606279189)
            
            //--TRIMMABLE-BOUNDARY-START(77311311893)
            static /*bool */ TryDequeue(TAsyncOp, /*ref TAsyncOp?*/ head, /*out TAsyncOp?*/ op)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77311311893);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                op.$v = head.$v;
                if (head.$v === null)
                {
                    return false;
                }
                $.$$.System.Diagnostics.Debug.Assert$2(!(head.$v.Previous === null), "head.Previous is not null");
                $.$$.System.Diagnostics.Debug.Assert$2(!(head.$v.Next === null), "head.Next is not null");
                if ($.$box(head.$v.Next, TAsyncOp) === $.$box(head, TAsyncOp).$v)
                {
                    head.$v = null;
                }
                else 
                {
                    /*TAsyncOp*/ let last = head.$v.Previous;
                    head.$v = head.$v.Next;
                    head.$v.Previous = last;
                    last.Next = head.$v;
                }
                $.$$.System.Diagnostics.Debug.Assert$2(!(op.$v === null), "op is not null");
                op.$v.Next = op.$v.Previous = null;
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(77311311893)
            
            //--TRIMMABLE-BOUNDARY-START(30066671637)
            static /*void */ Enqueue(TAsyncOp, /*ref TAsyncOp?*/ head, /*TAsyncOp*/ op)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066671637);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(op.Next === null && op.Previous === null, "op.Next is null && op.Previous is null");
                if (head.$v === null)
                {
                    head.$v = op.Next = op.Previous = op;
                }
                else 
                {
                    /*TAsyncOp*/ let last = head.$v.Previous;
                    $.$$.System.Diagnostics.Debug.Assert$2(!(last === null), "last is not null");
                    op.Next = head.$v;
                    op.Previous = last;
                    last.Next = op;
                    head.$v.Previous = op;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30066671637)
            
            //--TRIMMABLE-BOUNDARY-START(47246540821)
            static /*void */ Remove(TAsyncOp, /*ref TAsyncOp?*/ head, /*TAsyncOp*/ op)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246540821);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(!(op === null), "op is not null");
                $.$$.System.Diagnostics.Debug.Assert$2(op.Next === null === op.Previous === null, "op.Next is null == op.Previous is null");
                if (head.$v === null || op.Next === null)
                {
                    return;
                }
                $.$$.System.Diagnostics.Debug.Assert$2(!(op.Previous === null), "op.Previous is not null");
                if ($.$box(op.Next, TAsyncOp) === $.$box(op, TAsyncOp))
                {
                    $.$$.System.Diagnostics.Debug.Assert$2($.$box(op.Previous, TAsyncOp) === $.$box(op, TAsyncOp), "op.Previous == op");
                    $.$$.System.Diagnostics.Debug.Assert$2($.$box(head, TAsyncOp).$v === $.$box(op, TAsyncOp), "head == op");
                    head.$v = null;
                }
                else 
                {
                    op.Previous.Next = op.Next;
                    op.Next.Previous = op.Previous;
                    if ($.$box(head, TAsyncOp).$v === $.$box(op, TAsyncOp))
                    {
                        head.$v = op.Next;
                    }
                }
                op.Next = op.Previous = null;
            }
            //--TRIMMABLE-BOUNDARY-END(47246540821)
            
            //--TRIMMABLE-BOUNDARY-START(73016344597)
            static /*void */ SetOrFailOperations(TAsyncOp, T, /*TAsyncOp?*/ head, /*T*/ result, /*Exception?*/ error)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016344597);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!(error === null))
                {
                    $.$stc.System.Threading.Channels.ChannelUtilities.FailOperations(TAsyncOp, head, error);
                }
                else 
                {
                    $.$stc.System.Threading.Channels.ChannelUtilities.SetOperations(TAsyncOp, T, $.$ref(() => head, ($v) => head = $v, TAsyncOp), result);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(73016344597)
            
            //--TRIMMABLE-BOUNDARY-START(68721377301)
            static /*void */ SetOperations(TAsyncOp, TResult, /*ref TAsyncOp?*/ head, /*TResult*/ result)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68721377301);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*TAsyncOp?*/ let current = head.$v;
                if (!(current === null))
                {
                    do
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(!(current === null), "current is not null");
                        /*TAsyncOp?*/ let next = current.Next;
                        $.$$.System.Diagnostics.Debug.Assert$2(!(next === null), "next is not null");
                        current.Next = current.Previous = null;
                        $.$dsp(current, TAsyncOp, ($t) => $t.TrySetResult, result);
                        current = next;
                    }
                    while($.$box(current, TAsyncOp) !== $.$box(head, TAsyncOp).$v);
                    head.$v = null;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68721377301)
            
            //--TRIMMABLE-BOUNDARY-START(25771704341)
            static /*void */ DangerousSetOperations(TAsyncOp, TResult, /*TAsyncOp?*/ head, /*TResult*/ result)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771704341);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*TAsyncOp?*/ let current = head;
                if (!(current === null))
                {
                    do
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(!(current === null), "current is not null");
                        /*TAsyncOp?*/ let next = current.Next;
                        $.$$.System.Diagnostics.Debug.Assert$2(!(next === null), "next is not null");
                        current.Next = current.Previous = null;
                        $.$dsp(current, TAsyncOp, ($t) => $t.DangerousSetResult, result);
                        current = next;
                    }
                    while($.$box(current, TAsyncOp) !== $.$box(head, TAsyncOp));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25771704341)
            
            //--TRIMMABLE-BOUNDARY-START(85901246485)
            static /*TAsyncOp? */ TryReserveCompletionIfCancelable(TAsyncOp, /*ref TAsyncOp?*/ head)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85901246485);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*TAsyncOp?*/ let reserved = null;
                /*TAsyncOp?*/ let current = head.$v;
                if (!(current === null))
                {
                    do
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(!(current === null), "current is not null");
                        /*TAsyncOp?*/ let next = current.Next;
                        $.$$.System.Diagnostics.Debug.Assert$2(!(next === null), "next is not null");
                        current.Next = current.Previous = null;
                        if ($.$dsp(current, TAsyncOp, ($t) => $t.TryReserveCompletionIfCancelable,))
                        {
                            $.$stc.System.Threading.Channels.ChannelUtilities.Enqueue(TAsyncOp, $.$ref(() => reserved, ($v) => reserved = $v, TAsyncOp), current);
                        }
                        current = next;
                    }
                    while($.$box(current, TAsyncOp) !== $.$box(head, TAsyncOp).$v);
                    head.$v = null;
                }
                return reserved;
            }
            //--TRIMMABLE-BOUNDARY-END(85901246485)
            
            //--TRIMMABLE-BOUNDARY-START(34361638933)
            static /*void */ FailOperations(TAsyncOp, /*TAsyncOp?*/ head, /*Exception*/ error)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361638933);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(!(error === null), "error is not null");
                /*TAsyncOp?*/ let current = head;
                if (!(current === null))
                {
                    do
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(!(current === null), "current is not null");
                        /*TAsyncOp?*/ let next = current.Next;
                        $.$$.System.Diagnostics.Debug.Assert$2(!(next === null), "next is not null");
                        current.Next = current.Previous = null;
                        $.$dsp(current, TAsyncOp, ($t) => $t.TrySetException, error);
                        current = next;
                    }
                    while($.$box(current, TAsyncOp) !== $.$box(head, TAsyncOp));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34361638933)
            
            //--TRIMMABLE-BOUNDARY-START(8591835157)
            static /*void */ AssertAll(TAsyncOp, /*TAsyncOp?*/ head, /*Func<TAsyncOp, bool>*/ condition, /*string*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591835157);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*TAsyncOp?*/ let current = head;
                if (!(current === null))
                {
                    do
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(!(current === null), "current is not null");
                        $.$$.System.Diagnostics.Debug.Assert$2(condition.Invoke(current), message);
                        current = current.Next;
                    }
                    while($.$box(current, TAsyncOp) !== $.$box(head, TAsyncOp));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8591835157)
            
            //--TRIMMABLE-BOUNDARY-START(17181769749)
            static /*long */ CountOperations(TAsyncOp, /*TAsyncOp?*/ head)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181769749);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*TAsyncOp?*/ let current = head;
                /*long*/ let count = 0n;
                if (!(current === null))
                {
                    do
                    {
                        count++;
                        $.$$.System.Diagnostics.Debug.Assert$2(!(current === null), "current is not null");
                        current = current.Next;
                    }
                    while($.$box(current, TAsyncOp) !== $.$box(head, TAsyncOp));
                }
                return count;
            }
            //--TRIMMABLE-BOUNDARY-END(17181769749)
            
            //--TRIMMABLE-BOUNDARY-START(21476737045)
            static /*Exception */ CreateInvalidCompletionException(/*Exception?*/ inner)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476737045);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$is(inner, $.$$.System.OperationCanceledException) ? inner : !(inner === null) && inner !== $.$stc.System.Threading.Channels.ChannelUtilities.s_doneWritingSentinel ? new $.$stc.System.Threading.Channels.ChannelClosedException().$ctor$14(inner) : new $.$stc.System.Threading.Channels.ChannelClosedException().$ctor$13();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21476737045)
            
            //--TRIMMABLE-BOUNDARY-START(90196213781)
            static /*void */ UnsafeQueueUserWorkItem(TState, /*Action<TState>*/ action, /*TState*/ state)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(90196213781);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.Threading.ThreadPool.UnsafeQueueUserWorkItem$2(TState, action, state, false);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(90196213781)
            
            //--TRIMMABLE-BOUNDARY-START(42951573525)
            static /*void */ QueueUserWorkItem(/*Action<object?>*/ action, /*object?*/ state)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42951573525);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.Threading.ThreadPool.QueueUserWorkItem$2($.$$.System.Object, action, state, false);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42951573525)
            
            //--TRIMMABLE-BOUNDARY-START(4296867861)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(51541508117)
                    this.s_doneWritingSentinel = new $.$$.System.Exception().$ctor$4("s_doneWritingSentinel");
                    //--TRIMMABLE-BOUNDARY-END(51541508117)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(64426410005)
                    this.s_trueTask = $.$$.System.Threading.Tasks.Task.FromResult($.$$.System.Boolean, true);
                    //--TRIMMABLE-BOUNDARY-END(64426410005)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(55836475413)
                    this.s_falseTask = $.$$.System.Threading.Tasks.Task.FromResult($.$$.System.Boolean, false);
                    //--TRIMMABLE-BOUNDARY-END(55836475413)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(60131442709)
                    this.s_neverCompletingTask = new ($.$$.System.Threading.Tasks.TaskCompletionSource$$($.$$.System.Boolean))().$ctor$1().Task;
                    //--TRIMMABLE-BOUNDARY-END(60131442709)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296867861)
            
            static $h = 1900565;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886802453),
    {
      "r": 65537,
      "p": [
        {
          "n": "tcs",
          "p": 178782209
        },
        {
          "n": "error",
          "p": 80019457,
          "f": 65
        }
      ],
      "n": "Complete",
      "d": 1900565,
      "h": 12886802453,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12886802453),
//--TRIMMABLE-BOUNDARY-START(38656606229),
    {
      "r": (T) => $.$$.System.Threading.Tasks.ValueTask$$(T).$h,
      "p": [
        {
          "n": "error",
          "p": 80019457
        }
      ],
      "g": [
        "T"
      ],
      "n": "GetInvalidCompletionValueTask",
      "d": 1900565,
      "h": 38656606229,
      "f": 16908328
    },
//--TRIMMABLE-BOUNDARY-END(38656606229),
//--TRIMMABLE-BOUNDARY-START(81606279189),
    {
      "r": (TAsyncOp) => TAsyncOp.$h,
      "p": [
        {
          "n": "head",
          "p": (TAsyncOp) => TAsyncOp.$h,
          "f": 4
        }
      ],
      "g": [
        "TAsyncOp"
      ],
      "n": "TryDequeueAndReserveCompletionIfCancelable",
      "d": 1900565,
      "h": 81606279189,
      "f": 16908328
    },
//--TRIMMABLE-BOUNDARY-END(81606279189),
//--TRIMMABLE-BOUNDARY-START(77311311893),
    {
      "r": 262145,
      "p": [
        {
          "n": "head",
          "p": (TAsyncOp) => TAsyncOp.$h,
          "f": 4
        },
        {
          "n": "op",
          "p": (TAsyncOp) => TAsyncOp.$h,
          "f": 2
        }
      ],
      "g": [
        "TAsyncOp"
      ],
      "n": "TryDequeue",
      "d": 1900565,
      "h": 77311311893,
      "f": 16908328
    },
//--TRIMMABLE-BOUNDARY-END(77311311893),
//--TRIMMABLE-BOUNDARY-START(30066671637),
    {
      "r": 65537,
      "p": [
        {
          "n": "head",
          "p": (TAsyncOp) => TAsyncOp.$h,
          "f": 4
        },
        {
          "n": "op",
          "p": (TAsyncOp) => TAsyncOp.$h
        }
      ],
      "g": [
        "TAsyncOp"
      ],
      "n": "Enqueue",
      "d": 1900565,
      "h": 30066671637,
      "f": 16908328
    },
//--TRIMMABLE-BOUNDARY-END(30066671637),
//--TRIMMABLE-BOUNDARY-START(47246540821),
    {
      "r": 65537,
      "p": [
        {
          "n": "head",
          "p": (TAsyncOp) => TAsyncOp.$h,
          "f": 4
        },
        {
          "n": "op",
          "p": (TAsyncOp) => TAsyncOp.$h
        }
      ],
      "g": [
        "TAsyncOp"
      ],
      "n": "Remove",
      "d": 1900565,
      "h": 47246540821,
      "f": 16908328
    },
//--TRIMMABLE-BOUNDARY-END(47246540821),
//--TRIMMABLE-BOUNDARY-START(73016344597),
    {
      "r": 65537,
      "p": [
        {
          "n": "head",
          "p": (TAsyncOp, T) => TAsyncOp.$h
        },
        {
          "n": "result",
          "p": (TAsyncOp, T) => T.$h
        },
        {
          "n": "error",
          "p": 80019457,
          "f": 65
        }
      ],
      "g": [
        "TAsyncOp",
        "T"
      ],
      "n": "SetOrFailOperations",
      "d": 1900565,
      "h": 73016344597,
      "f": 16908328
    },
//--TRIMMABLE-BOUNDARY-END(73016344597),
//--TRIMMABLE-BOUNDARY-START(68721377301),
    {
      "r": 65537,
      "p": [
        {
          "n": "head",
          "p": (TAsyncOp, TResult) => TAsyncOp.$h,
          "f": 4
        },
        {
          "n": "result",
          "p": (TAsyncOp, TResult) => TResult.$h
        }
      ],
      "g": [
        "TAsyncOp",
        "TResult"
      ],
      "n": "SetOperations",
      "d": 1900565,
      "h": 68721377301,
      "f": 16908328
    },
//--TRIMMABLE-BOUNDARY-END(68721377301),
//--TRIMMABLE-BOUNDARY-START(25771704341),
    {
      "r": 65537,
      "p": [
        {
          "n": "head",
          "p": (TAsyncOp, TResult) => TAsyncOp.$h
        },
        {
          "n": "result",
          "p": (TAsyncOp, TResult) => TResult.$h
        }
      ],
      "g": [
        "TAsyncOp",
        "TResult"
      ],
      "n": "DangerousSetOperations",
      "d": 1900565,
      "h": 25771704341,
      "f": 16908328
    },
//--TRIMMABLE-BOUNDARY-END(25771704341),
//--TRIMMABLE-BOUNDARY-START(85901246485),
    {
      "r": (TAsyncOp) => TAsyncOp.$h,
      "p": [
        {
          "n": "head",
          "p": (TAsyncOp) => TAsyncOp.$h,
          "f": 4
        }
      ],
      "g": [
        "TAsyncOp"
      ],
      "n": "TryReserveCompletionIfCancelable",
      "d": 1900565,
      "h": 85901246485,
      "f": 16908328
    },
//--TRIMMABLE-BOUNDARY-END(85901246485),
//--TRIMMABLE-BOUNDARY-START(34361638933),
    {
      "r": 65537,
      "p": [
        {
          "n": "head",
          "p": (TAsyncOp) => TAsyncOp.$h
        },
        {
          "n": "error",
          "p": 80019457
        }
      ],
      "g": [
        "TAsyncOp"
      ],
      "n": "FailOperations",
      "d": 1900565,
      "h": 34361638933,
      "f": 16908328
    },
//--TRIMMABLE-BOUNDARY-END(34361638933),
//--TRIMMABLE-BOUNDARY-START(8591835157),
    {
      "r": 65537,
      "p": [
        {
          "n": "head",
          "p": (TAsyncOp) => TAsyncOp.$h
        },
        {
          "n": "condition",
          "p": (TAsyncOp) => $.$$.System.Func$$$(TAsyncOp, $.$$.System.Boolean).$h
        },
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "g": [
        "TAsyncOp"
      ],
      "n": "AssertAll",
      "d": 1900565,
      "h": 8591835157,
      "f": 16908328,
      "a": [
        {
          "t": 68747265,
          "c": 8658681857,
          "a": [
            {
              "v": "DEBUG",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8591835157),
//--TRIMMABLE-BOUNDARY-START(17181769749),
    {
      "r": 917505,
      "p": [
        {
          "n": "head",
          "p": (TAsyncOp) => TAsyncOp.$h
        }
      ],
      "g": [
        "TAsyncOp"
      ],
      "n": "CountOperations",
      "d": 1900565,
      "h": 17181769749,
      "f": 16908328
    },
//--TRIMMABLE-BOUNDARY-END(17181769749),
//--TRIMMABLE-BOUNDARY-START(21476737045),
    {
      "r": 80019457,
      "p": [
        {
          "n": "inner",
          "p": 80019457,
          "f": 65
        }
      ],
      "n": "CreateInvalidCompletionException",
      "d": 1900565,
      "h": 21476737045,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(21476737045),
//--TRIMMABLE-BOUNDARY-START(90196213781),
    {
      "r": 65537,
      "p": [
        {
          "n": "action",
          "p": (TState) => $.$$.System.Action$$(TState).$h
        },
        {
          "n": "state",
          "p": (TState) => TState.$h
        }
      ],
      "g": [
        "TState"
      ],
      "n": "UnsafeQueueUserWorkItem",
      "d": 1900565,
      "h": 90196213781,
      "f": 16908328
    },
//--TRIMMABLE-BOUNDARY-END(90196213781),
//--TRIMMABLE-BOUNDARY-START(42951573525),
    {
      "r": 65537,
      "p": [
        {
          "n": "action",
          "p": $.$$.System.Action$$($.$$.System.Object).$h
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "QueueUserWorkItem",
      "d": 1900565,
      "h": 42951573525,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(42951573525)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(51541508117),
    {
      "t": 80019457,
      "n": "s_doneWritingSentinel",
      "d": 1900565,
      "h": 51541508117,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(51541508117),
//--TRIMMABLE-BOUNDARY-START(64426410005),
    {
      "t": $.$$.System.Threading.Tasks.Task$$($.$$.System.Boolean).$h,
      "n": "s_trueTask",
      "d": 1900565,
      "h": 64426410005,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(64426410005),
//--TRIMMABLE-BOUNDARY-START(55836475413),
    {
      "t": $.$$.System.Threading.Tasks.Task$$($.$$.System.Boolean).$h,
      "n": "s_falseTask",
      "d": 1900565,
      "h": 55836475413,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(55836475413),
//--TRIMMABLE-BOUNDARY-START(60131442709),
    {
      "t": 177668097,
      "n": "s_neverCompletingTask",
      "d": 1900565,
      "h": 60131442709,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(60131442709)
  ],
  "h": 1900565
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Threading.Channels.ChannelUtilities`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1900565)
        
        
        //--TRIMMABLE-BOUNDARY-START(655381)
        $asm.$cls("$stc.System.Obsoletions", ($self) => class Obsoletions
        {
            //--TRIMMABLE-BOUNDARY-START(382252744725)
            /*string*/ static SharedUrlFormat = null;
            //--TRIMMABLE-BOUNDARY-END(382252744725)
            
            //--TRIMMABLE-BOUNDARY-START(433792352277)
            /*string*/ static SystemTextEncodingUTF7Message = null;
            //--TRIMMABLE-BOUNDARY-END(433792352277)
            
            //--TRIMMABLE-BOUNDARY-START(429497384981)
            /*string*/ static SystemTextEncodingUTF7DiagId = null;
            //--TRIMMABLE-BOUNDARY-END(429497384981)
            
            //--TRIMMABLE-BOUNDARY-START(266288627733)
            /*string*/ static PrincipalPermissionAttributeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(266288627733)
            
            //--TRIMMABLE-BOUNDARY-START(261993660437)
            /*string*/ static PrincipalPermissionAttributeDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(261993660437)
            
            //--TRIMMABLE-BOUNDARY-START(77310066709)
            /*string*/ static CodeAccessSecurityMessage = null;
            //--TRIMMABLE-BOUNDARY-END(77310066709)
            
            //--TRIMMABLE-BOUNDARY-START(73015099413)
            /*string*/ static CodeAccessSecurityDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(73015099413)
            
            //--TRIMMABLE-BOUNDARY-START(94489935893)
            /*string*/ static ConstrainedExecutionRegionMessage = null;
            //--TRIMMABLE-BOUNDARY-END(94489935893)
            
            //--TRIMMABLE-BOUNDARY-START(90194968597)
            /*string*/ static ConstrainedExecutionRegionDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(90194968597)
            
            //--TRIMMABLE-BOUNDARY-START(214749020181)
            /*string*/ static GlobalAssemblyCacheMessage = null;
            //--TRIMMABLE-BOUNDARY-END(214749020181)
            
            //--TRIMMABLE-BOUNDARY-START(210454052885)
            /*string*/ static GlobalAssemblyCacheDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(210454052885)
            
            //--TRIMMABLE-BOUNDARY-START(442382286869)
            /*string*/ static ThreadAbortMessage = null;
            //--TRIMMABLE-BOUNDARY-END(442382286869)
            
            //--TRIMMABLE-BOUNDARY-START(446677254165)
            /*string*/ static ThreadResetAbortMessage = null;
            //--TRIMMABLE-BOUNDARY-END(446677254165)
            
            //--TRIMMABLE-BOUNDARY-START(438087319573)
            /*string*/ static ThreadAbortDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(438087319573)
            
            //--TRIMMABLE-BOUNDARY-START(146029543445)
            /*string*/ static DefaultCryptoAlgorithmsMessage = null;
            //--TRIMMABLE-BOUNDARY-END(146029543445)
            
            //--TRIMMABLE-BOUNDARY-START(141734576149)
            /*string*/ static DefaultCryptoAlgorithmsDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(141734576149)
            
            //--TRIMMABLE-BOUNDARY-START(120259739669)
            /*string*/ static CreatePdbGeneratorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(120259739669)
            
            //--TRIMMABLE-BOUNDARY-START(115964772373)
            /*string*/ static CreatePdbGeneratorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(115964772373)
            
            //--TRIMMABLE-BOUNDARY-START(51540262933)
            /*string*/ static AuthenticationManagerMessage = null;
            //--TRIMMABLE-BOUNDARY-END(51540262933)
            
            //--TRIMMABLE-BOUNDARY-START(47245295637)
            /*string*/ static AuthenticationManagerDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(47245295637)
            
            //--TRIMMABLE-BOUNDARY-START(326418169877)
            /*string*/ static RemotingApisMessage = null;
            //--TRIMMABLE-BOUNDARY-END(326418169877)
            
            //--TRIMMABLE-BOUNDARY-START(322123202581)
            /*string*/ static RemotingApisDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(322123202581)
            
            //--TRIMMABLE-BOUNDARY-START(60130197525)
            /*string*/ static BinaryFormatterMessage = null;
            //--TRIMMABLE-BOUNDARY-END(60130197525)
            
            //--TRIMMABLE-BOUNDARY-START(55835230229)
            /*string*/ static BinaryFormatterDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(55835230229)
            
            //--TRIMMABLE-BOUNDARY-START(85900001301)
            /*string*/ static CodeBaseMessage = null;
            //--TRIMMABLE-BOUNDARY-END(85900001301)
            
            //--TRIMMABLE-BOUNDARY-START(81605034005)
            /*string*/ static CodeBaseDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(81605034005)
            
            //--TRIMMABLE-BOUNDARY-START(197569150997)
            /*string*/ static EscapeUriStringMessage = null;
            //--TRIMMABLE-BOUNDARY-END(197569150997)
            
            //--TRIMMABLE-BOUNDARY-START(193274183701)
            /*string*/ static EscapeUriStringDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(193274183701)
            
            //--TRIMMABLE-BOUNDARY-START(489626927125)
            /*string*/ static WebRequestMessage = null;
            //--TRIMMABLE-BOUNDARY-END(489626927125)
            
            //--TRIMMABLE-BOUNDARY-START(485331959829)
            /*string*/ static WebRequestDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(485331959829)
            
            //--TRIMMABLE-BOUNDARY-START(163209412629)
            /*string*/ static DisablePrivateReflectionAttributeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(163209412629)
            
            //--TRIMMABLE-BOUNDARY-START(158914445333)
            /*string*/ static DisablePrivateReflectionAttributeDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(158914445333)
            
            //--TRIMMABLE-BOUNDARY-START(206159085589)
            /*string*/ static GetContextInfoMessage = null;
            //--TRIMMABLE-BOUNDARY-END(206159085589)
            
            //--TRIMMABLE-BOUNDARY-START(201864118293)
            /*string*/ static GetContextInfoDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(201864118293)
            
            //--TRIMMABLE-BOUNDARY-START(399432613909)
            /*string*/ static StrongNameKeyPairMessage = null;
            //--TRIMMABLE-BOUNDARY-END(399432613909)
            
            //--TRIMMABLE-BOUNDARY-START(395137646613)
            /*string*/ static StrongNameKeyPairDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(395137646613)
            
            //--TRIMMABLE-BOUNDARY-START(300648366101)
            /*string*/ static ReflectionOnlyLoadingMessage = null;
            //--TRIMMABLE-BOUNDARY-END(300648366101)
            
            //--TRIMMABLE-BOUNDARY-START(296353398805)
            /*string*/ static ReflectionOnlyLoadingDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(296353398805)
            
            //--TRIMMABLE-BOUNDARY-START(377957777429)
            /*string*/ static RuntimeEnvironmentMessage = null;
            //--TRIMMABLE-BOUNDARY-END(377957777429)
            
            //--TRIMMABLE-BOUNDARY-START(373662810133)
            /*string*/ static RuntimeEnvironmentDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(373662810133)
            
            //--TRIMMABLE-BOUNDARY-START(231928889365)
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesMessage = null;
            //--TRIMMABLE-BOUNDARY-END(231928889365)
            
            //--TRIMMABLE-BOUNDARY-START(227633922069)
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(227633922069)
            
            //--TRIMMABLE-BOUNDARY-START(154619478037)
            /*string*/ static DerivedCryptographicTypesMessage = null;
            //--TRIMMABLE-BOUNDARY-END(154619478037)
            
            //--TRIMMABLE-BOUNDARY-START(150324510741)
            /*string*/ static DerivedCryptographicTypesDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(150324510741)
            
            //--TRIMMABLE-BOUNDARY-START(352187973653)
            /*string*/ static RijndaelMessage = null;
            //--TRIMMABLE-BOUNDARY-END(352187973653)
            
            //--TRIMMABLE-BOUNDARY-START(347893006357)
            /*string*/ static RijndaelDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(347893006357)
            
            //--TRIMMABLE-BOUNDARY-START(360777908245)
            /*string*/ static RNGCryptoServiceProviderMessage = null;
            //--TRIMMABLE-BOUNDARY-END(360777908245)
            
            //--TRIMMABLE-BOUNDARY-START(356482940949)
            /*string*/ static RNGCryptoServiceProviderDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(356482940949)
            
            //--TRIMMABLE-BOUNDARY-START(17180524565)
            /*string*/ static AppDomainCreateUnloadMessage = null;
            //--TRIMMABLE-BOUNDARY-END(17180524565)
            
            //--TRIMMABLE-BOUNDARY-START(12885557269)
            /*string*/ static AppDomainCreateUnloadDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(12885557269)
            
            //--TRIMMABLE-BOUNDARY-START(408022548501)
            /*string*/ static SuppressIldasmAttributeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(408022548501)
            
            //--TRIMMABLE-BOUNDARY-START(403727581205)
            /*string*/ static SuppressIldasmAttributeDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(403727581205)
            
            //--TRIMMABLE-BOUNDARY-START(498216861717)
            /*string*/ static X509CertificateImmutableMessage = null;
            //--TRIMMABLE-BOUNDARY-END(498216861717)
            
            //--TRIMMABLE-BOUNDARY-START(493921894421)
            /*string*/ static X509CertificateImmutableDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(493921894421)
            
            //--TRIMMABLE-BOUNDARY-START(283468496917)
            /*string*/ static PublicKeyPropertyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(283468496917)
            
            //--TRIMMABLE-BOUNDARY-START(279173529621)
            /*string*/ static PublicKeyPropertyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(279173529621)
            
            //--TRIMMABLE-BOUNDARY-START(506806796309)
            /*string*/ static X509CertificatePrivateKeyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(506806796309)
            
            //--TRIMMABLE-BOUNDARY-START(502511829013)
            /*string*/ static X509CertificatePrivateKeyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(502511829013)
            
            //--TRIMMABLE-BOUNDARY-START(274878562325)
            /*string*/ static ProduceLegacyHmacValuesMessage = null;
            //--TRIMMABLE-BOUNDARY-END(274878562325)
            
            //--TRIMMABLE-BOUNDARY-START(270583595029)
            /*string*/ static ProduceLegacyHmacValuesDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(270583595029)
            
            //--TRIMMABLE-BOUNDARY-START(481036992533)
            /*string*/ static UseManagedSha1Message = null;
            //--TRIMMABLE-BOUNDARY-END(481036992533)
            
            //--TRIMMABLE-BOUNDARY-START(476742025237)
            /*string*/ static UseManagedSha1DiagId = null;
            //--TRIMMABLE-BOUNDARY-END(476742025237)
            
            //--TRIMMABLE-BOUNDARY-START(128849674261)
            /*string*/ static CryptoConfigEncodeOIDMessage = null;
            //--TRIMMABLE-BOUNDARY-END(128849674261)
            
            //--TRIMMABLE-BOUNDARY-START(124554706965)
            /*string*/ static CryptoConfigEncodeOIDDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(124554706965)
            
            //--TRIMMABLE-BOUNDARY-START(111669805077)
            /*string*/ static CorruptedStateRecoveryMessage = null;
            //--TRIMMABLE-BOUNDARY-END(111669805077)
            
            //--TRIMMABLE-BOUNDARY-START(107374837781)
            /*string*/ static CorruptedStateRecoveryDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(107374837781)
            
            //--TRIMMABLE-BOUNDARY-START(335008104469)
            /*string*/ static Rfc2898CryptDeriveKeyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(335008104469)
            
            //--TRIMMABLE-BOUNDARY-START(330713137173)
            /*string*/ static Rfc2898CryptDeriveKeyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(330713137173)
            
            //--TRIMMABLE-BOUNDARY-START(68720132117)
            /*string*/ static CmsSignerCspParamsCtorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(68720132117)
            
            //--TRIMMABLE-BOUNDARY-START(64425164821)
            /*string*/ static CmsSignerCspParamsCtorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(64425164821)
            
            //--TRIMMABLE-BOUNDARY-START(390842679317)
            /*string*/ static SignerInfoCounterSigMessage = null;
            //--TRIMMABLE-BOUNDARY-END(390842679317)
            
            //--TRIMMABLE-BOUNDARY-START(386547712021)
            /*string*/ static SignerInfoCounterSigDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(386547712021)
            
            //--TRIMMABLE-BOUNDARY-START(309238300693)
            /*string*/ static RegexCompileToAssemblyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(309238300693)
            
            //--TRIMMABLE-BOUNDARY-START(304943333397)
            /*string*/ static RegexCompileToAssemblyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(304943333397)
            
            //--TRIMMABLE-BOUNDARY-START(42950328341)
            /*string*/ static AssemblyNameMembersMessage = null;
            //--TRIMMABLE-BOUNDARY-END(42950328341)
            
            //--TRIMMABLE-BOUNDARY-START(38655361045)
            /*string*/ static AssemblyNameMembersDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(38655361045)
            
            //--TRIMMABLE-BOUNDARY-START(416612483093)
            /*string*/ static SystemDataSerializationFormatBinaryMessage = null;
            //--TRIMMABLE-BOUNDARY-END(416612483093)
            
            //--TRIMMABLE-BOUNDARY-START(412317515797)
            /*string*/ static SystemDataSerializationFormatBinaryDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(412317515797)
            
            //--TRIMMABLE-BOUNDARY-START(472447057941)
            /*string*/ static TlsVersion10and11Message = null;
            //--TRIMMABLE-BOUNDARY-END(472447057941)
            
            //--TRIMMABLE-BOUNDARY-START(468152090645)
            /*string*/ static TlsVersion10and11DiagId = null;
            //--TRIMMABLE-BOUNDARY-END(468152090645)
            
            //--TRIMMABLE-BOUNDARY-START(188979216405)
            /*string*/ static EncryptionPolicyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(188979216405)
            
            //--TRIMMABLE-BOUNDARY-START(184684249109)
            /*string*/ static EncryptionPolicyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(184684249109)
            
            //--TRIMMABLE-BOUNDARY-START(171799347221)
            /*string*/ static EccXmlExportImportMessage = null;
            //--TRIMMABLE-BOUNDARY-END(171799347221)
            
            //--TRIMMABLE-BOUNDARY-START(167504379925)
            /*string*/ static EccXmlExportImportDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(167504379925)
            
            //--TRIMMABLE-BOUNDARY-START(180389281813)
            /*string*/ static EcDhPublicKeyBlobMessage = null;
            //--TRIMMABLE-BOUNDARY-END(180389281813)
            
            //--TRIMMABLE-BOUNDARY-START(176094314517)
            /*string*/ static EcDhPublicKeyBlobDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(176094314517)
            
            //--TRIMMABLE-BOUNDARY-START(34360393749)
            /*string*/ static AssemblyNameCodeBaseMessage = null;
            //--TRIMMABLE-BOUNDARY-END(34360393749)
            
            //--TRIMMABLE-BOUNDARY-START(30065426453)
            /*string*/ static AssemblyNameCodeBaseDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(30065426453)
            
            //--TRIMMABLE-BOUNDARY-START(137439608853)
            /*string*/ static CryptoStringFactoryMessage = null;
            //--TRIMMABLE-BOUNDARY-END(137439608853)
            
            //--TRIMMABLE-BOUNDARY-START(133144641557)
            /*string*/ static CryptoStringFactoryDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(133144641557)
            
            //--TRIMMABLE-BOUNDARY-START(103079870485)
            /*string*/ static ControlledExecutionRunMessage = null;
            //--TRIMMABLE-BOUNDARY-END(103079870485)
            
            //--TRIMMABLE-BOUNDARY-START(98784903189)
            /*string*/ static ControlledExecutionRunDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(98784903189)
            
            //--TRIMMABLE-BOUNDARY-START(523986665493)
            /*string*/ static XmlSecureResolverMessage = null;
            //--TRIMMABLE-BOUNDARY-END(523986665493)
            
            //--TRIMMABLE-BOUNDARY-START(519691698197)
            /*string*/ static XmlSecureResolverDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(519691698197)
            
            //--TRIMMABLE-BOUNDARY-START(369367842837)
            /*string*/ static RsaEncryptDecryptValueMessage = null;
            //--TRIMMABLE-BOUNDARY-END(369367842837)
            
            //--TRIMMABLE-BOUNDARY-START(365072875541)
            /*string*/ static RsaEncryptDecryptDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(365072875541)
            
            //--TRIMMABLE-BOUNDARY-START(223338954773)
            /*string*/ static JsonSerializerOptionsAddContextMessage = null;
            //--TRIMMABLE-BOUNDARY-END(223338954773)
            
            //--TRIMMABLE-BOUNDARY-START(219043987477)
            /*string*/ static JsonSerializerOptionsAddContextDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(219043987477)
            
            //--TRIMMABLE-BOUNDARY-START(249108758549)
            /*string*/ static LegacyFormatterMessage = null;
            //--TRIMMABLE-BOUNDARY-END(249108758549)
            
            //--TRIMMABLE-BOUNDARY-START(236223856661)
            /*string*/ static LegacyFormatterDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(236223856661)
            
            //--TRIMMABLE-BOUNDARY-START(244813791253)
            /*string*/ static LegacyFormatterImplMessage = null;
            //--TRIMMABLE-BOUNDARY-END(244813791253)
            
            //--TRIMMABLE-BOUNDARY-START(240518823957)
            /*string*/ static LegacyFormatterImplDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(240518823957)
            
            //--TRIMMABLE-BOUNDARY-START(317828235285)
            /*string*/ static RegexExtensibilityImplMessage = null;
            //--TRIMMABLE-BOUNDARY-END(317828235285)
            
            //--TRIMMABLE-BOUNDARY-START(313533267989)
            /*string*/ static RegexExtensibilityDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(313533267989)
            
            //--TRIMMABLE-BOUNDARY-START(8590589973)
            /*string*/ static AesGcmTagConstructorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(8590589973)
            
            //--TRIMMABLE-BOUNDARY-START(4295622677)
            /*string*/ static AesGcmTagConstructorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(4295622677)
            
            //--TRIMMABLE-BOUNDARY-START(455267188757)
            /*string*/ static ThreadVolatileReadWriteMessage = null;
            //--TRIMMABLE-BOUNDARY-END(455267188757)
            
            //--TRIMMABLE-BOUNDARY-START(450972221461)
            /*string*/ static ThreadVolatileReadWriteDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(450972221461)
            
            //--TRIMMABLE-BOUNDARY-START(25770459157)
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationMessage = null;
            //--TRIMMABLE-BOUNDARY-END(25770459157)
            
            //--TRIMMABLE-BOUNDARY-START(21475491861)
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(21475491861)
            
            //--TRIMMABLE-BOUNDARY-START(257698693141)
            /*string*/ static LoadFromHashAlgorithmMessage = null;
            //--TRIMMABLE-BOUNDARY-END(257698693141)
            
            //--TRIMMABLE-BOUNDARY-START(253403725845)
            /*string*/ static LoadFromHashAlgorithmDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(253403725845)
            
            //--TRIMMABLE-BOUNDARY-START(515396730901)
            /*string*/ static X509CtorCertDataObsoleteMessage = null;
            //--TRIMMABLE-BOUNDARY-END(515396730901)
            
            //--TRIMMABLE-BOUNDARY-START(511101763605)
            /*string*/ static X509CtorCertDataObsoleteDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(511101763605)
            
            //--TRIMMABLE-BOUNDARY-START(463857123349)
            /*string*/ static TlsCipherAlgorithmEnumsMessage = null;
            //--TRIMMABLE-BOUNDARY-END(463857123349)
            
            //--TRIMMABLE-BOUNDARY-START(459562156053)
            /*string*/ static TlsCipherAlgorithmEnumsDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(459562156053)
            
            //--TRIMMABLE-BOUNDARY-START(425202417685)
            /*string*/ static SystemEventsEventsThreadShutdownMessage = null;
            //--TRIMMABLE-BOUNDARY-END(425202417685)
            
            //--TRIMMABLE-BOUNDARY-START(420907450389)
            /*string*/ static SystemEventsEventsThreadShutdownDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(420907450389)
            
            //--TRIMMABLE-BOUNDARY-START(343598039061)
            /*string*/ static Rfc2898DeriveBytesCtorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(343598039061)
            
            //--TRIMMABLE-BOUNDARY-START(339303071765)
            /*string*/ static Rfc2898DeriveBytesCtorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(339303071765)
            
            //--TRIMMABLE-BOUNDARY-START(292058431509)
            /*string*/ static QueryableMinByMaxByTSourceObsoleteMessage = null;
            //--TRIMMABLE-BOUNDARY-END(292058431509)
            
            //--TRIMMABLE-BOUNDARY-START(287763464213)
            /*string*/ static QueryableMinByMaxByTSourceObsoleteDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(287763464213)
            
            //--TRIMMABLE-BOUNDARY-START(532576600085)
            /*string*/ static XsltSettingsEnableScriptMessage = null;
            //--TRIMMABLE-BOUNDARY-END(532576600085)
            
            //--TRIMMABLE-BOUNDARY-START(528281632789)
            /*string*/ static XsltSettingsEnableScriptDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(528281632789)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(382252744725)
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                    //--TRIMMABLE-BOUNDARY-END(382252744725)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(433792352277)
                    this.SystemTextEncodingUTF7Message = "The UTF-7 encoding is insecure and should not be used. Consider using UTF-8 instead.";
                    //--TRIMMABLE-BOUNDARY-END(433792352277)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(429497384981)
                    this.SystemTextEncodingUTF7DiagId = "SYSLIB0001";
                    //--TRIMMABLE-BOUNDARY-END(429497384981)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(266288627733)
                    this.PrincipalPermissionAttributeMessage = "PrincipalPermissionAttribute is not honored by the runtime and must not be used.";
                    //--TRIMMABLE-BOUNDARY-END(266288627733)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(261993660437)
                    this.PrincipalPermissionAttributeDiagId = "SYSLIB0002";
                    //--TRIMMABLE-BOUNDARY-END(261993660437)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(77310066709)
                    this.CodeAccessSecurityMessage = "Code Access Security is not supported or honored by the runtime.";
                    //--TRIMMABLE-BOUNDARY-END(77310066709)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(73015099413)
                    this.CodeAccessSecurityDiagId = "SYSLIB0003";
                    //--TRIMMABLE-BOUNDARY-END(73015099413)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(94489935893)
                    this.ConstrainedExecutionRegionMessage = "The Constrained Execution Region (CER) feature is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(94489935893)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(90194968597)
                    this.ConstrainedExecutionRegionDiagId = "SYSLIB0004";
                    //--TRIMMABLE-BOUNDARY-END(90194968597)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(214749020181)
                    this.GlobalAssemblyCacheMessage = "The Global Assembly Cache is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(214749020181)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(210454052885)
                    this.GlobalAssemblyCacheDiagId = "SYSLIB0005";
                    //--TRIMMABLE-BOUNDARY-END(210454052885)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(442382286869)
                    this.ThreadAbortMessage = "Thread.Abort is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(442382286869)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(446677254165)
                    this.ThreadResetAbortMessage = "Thread.ResetAbort is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(446677254165)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(438087319573)
                    this.ThreadAbortDiagId = "SYSLIB0006";
                    //--TRIMMABLE-BOUNDARY-END(438087319573)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(146029543445)
                    this.DefaultCryptoAlgorithmsMessage = "The default implementation of this cryptography algorithm is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(146029543445)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(141734576149)
                    this.DefaultCryptoAlgorithmsDiagId = "SYSLIB0007";
                    //--TRIMMABLE-BOUNDARY-END(141734576149)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(120259739669)
                    this.CreatePdbGeneratorMessage = "The CreatePdbGenerator API is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(120259739669)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(115964772373)
                    this.CreatePdbGeneratorDiagId = "SYSLIB0008";
                    //--TRIMMABLE-BOUNDARY-END(115964772373)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(51540262933)
                    this.AuthenticationManagerMessage = "AuthenticationManager is not supported. Methods will no-op or throw PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(51540262933)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47245295637)
                    this.AuthenticationManagerDiagId = "SYSLIB0009";
                    //--TRIMMABLE-BOUNDARY-END(47245295637)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(326418169877)
                    this.RemotingApisMessage = "This Remoting API is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(326418169877)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(322123202581)
                    this.RemotingApisDiagId = "SYSLIB0010";
                    //--TRIMMABLE-BOUNDARY-END(322123202581)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(60130197525)
                    this.BinaryFormatterMessage = "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.";
                    //--TRIMMABLE-BOUNDARY-END(60130197525)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(55835230229)
                    this.BinaryFormatterDiagId = "SYSLIB0011";
                    //--TRIMMABLE-BOUNDARY-END(55835230229)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(85900001301)
                    this.CodeBaseMessage = "Assembly.CodeBase and Assembly.EscapedCodeBase are only included for .NET Framework compatibility. Use Assembly.Location instead.";
                    //--TRIMMABLE-BOUNDARY-END(85900001301)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(81605034005)
                    this.CodeBaseDiagId = "SYSLIB0012";
                    //--TRIMMABLE-BOUNDARY-END(81605034005)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(197569150997)
                    this.EscapeUriStringMessage = "Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.";
                    //--TRIMMABLE-BOUNDARY-END(197569150997)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(193274183701)
                    this.EscapeUriStringDiagId = "SYSLIB0013";
                    //--TRIMMABLE-BOUNDARY-END(193274183701)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(489626927125)
                    this.WebRequestMessage = "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.";
                    //--TRIMMABLE-BOUNDARY-END(489626927125)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(485331959829)
                    this.WebRequestDiagId = "SYSLIB0014";
                    //--TRIMMABLE-BOUNDARY-END(485331959829)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(163209412629)
                    this.DisablePrivateReflectionAttributeMessage = "DisablePrivateReflectionAttribute has no effect in .NET 6.0+.";
                    //--TRIMMABLE-BOUNDARY-END(163209412629)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(158914445333)
                    this.DisablePrivateReflectionAttributeDiagId = "SYSLIB0015";
                    //--TRIMMABLE-BOUNDARY-END(158914445333)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(206159085589)
                    this.GetContextInfoMessage = "Use the Graphics.GetContextInfo overloads that accept arguments for better performance and fewer allocations.";
                    //--TRIMMABLE-BOUNDARY-END(206159085589)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(201864118293)
                    this.GetContextInfoDiagId = "SYSLIB0016";
                    //--TRIMMABLE-BOUNDARY-END(201864118293)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(399432613909)
                    this.StrongNameKeyPairMessage = "Strong name signing is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(399432613909)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(395137646613)
                    this.StrongNameKeyPairDiagId = "SYSLIB0017";
                    //--TRIMMABLE-BOUNDARY-END(395137646613)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(300648366101)
                    this.ReflectionOnlyLoadingMessage = "ReflectionOnly loading is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(300648366101)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(296353398805)
                    this.ReflectionOnlyLoadingDiagId = "SYSLIB0018";
                    //--TRIMMABLE-BOUNDARY-END(296353398805)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(377957777429)
                    this.RuntimeEnvironmentMessage = "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(377957777429)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(373662810133)
                    this.RuntimeEnvironmentDiagId = "SYSLIB0019";
                    //--TRIMMABLE-BOUNDARY-END(373662810133)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(231928889365)
                    this.JsonSerializerOptionsIgnoreNullValuesMessage = "JsonSerializerOptions.IgnoreNullValues is obsolete. To ignore null values when serializing, set DefaultIgnoreCondition to JsonIgnoreCondition.WhenWritingNull.";
                    //--TRIMMABLE-BOUNDARY-END(231928889365)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(227633922069)
                    this.JsonSerializerOptionsIgnoreNullValuesDiagId = "SYSLIB0020";
                    //--TRIMMABLE-BOUNDARY-END(227633922069)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(154619478037)
                    this.DerivedCryptographicTypesMessage = "Derived cryptographic types are obsolete. Use the Create method on the base type instead.";
                    //--TRIMMABLE-BOUNDARY-END(154619478037)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(150324510741)
                    this.DerivedCryptographicTypesDiagId = "SYSLIB0021";
                    //--TRIMMABLE-BOUNDARY-END(150324510741)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(352187973653)
                    this.RijndaelMessage = "The Rijndael and RijndaelManaged types are obsolete. Use Aes instead.";
                    //--TRIMMABLE-BOUNDARY-END(352187973653)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(347893006357)
                    this.RijndaelDiagId = "SYSLIB0022";
                    //--TRIMMABLE-BOUNDARY-END(347893006357)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(360777908245)
                    this.RNGCryptoServiceProviderMessage = "RNGCryptoServiceProvider is obsolete. To generate a random number, use one of the RandomNumberGenerator static methods instead.";
                    //--TRIMMABLE-BOUNDARY-END(360777908245)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(356482940949)
                    this.RNGCryptoServiceProviderDiagId = "SYSLIB0023";
                    //--TRIMMABLE-BOUNDARY-END(356482940949)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17180524565)
                    this.AppDomainCreateUnloadMessage = "Creating and unloading AppDomains is not supported and throws an exception.";
                    //--TRIMMABLE-BOUNDARY-END(17180524565)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12885557269)
                    this.AppDomainCreateUnloadDiagId = "SYSLIB0024";
                    //--TRIMMABLE-BOUNDARY-END(12885557269)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(408022548501)
                    this.SuppressIldasmAttributeMessage = "SuppressIldasmAttribute has no effect in .NET 6.0+.";
                    //--TRIMMABLE-BOUNDARY-END(408022548501)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(403727581205)
                    this.SuppressIldasmAttributeDiagId = "SYSLIB0025";
                    //--TRIMMABLE-BOUNDARY-END(403727581205)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(498216861717)
                    this.X509CertificateImmutableMessage = "X509Certificate and X509Certificate2 are immutable. Use X509CertificateLoader to create a new certificate.";
                    //--TRIMMABLE-BOUNDARY-END(498216861717)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(493921894421)
                    this.X509CertificateImmutableDiagId = "SYSLIB0026";
                    //--TRIMMABLE-BOUNDARY-END(493921894421)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(283468496917)
                    this.PublicKeyPropertyMessage = "PublicKey.Key is obsolete. Use the appropriate method to get the public key, such as GetRSAPublicKey.";
                    //--TRIMMABLE-BOUNDARY-END(283468496917)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(279173529621)
                    this.PublicKeyPropertyDiagId = "SYSLIB0027";
                    //--TRIMMABLE-BOUNDARY-END(279173529621)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(506806796309)
                    this.X509CertificatePrivateKeyMessage = "X509Certificate2.PrivateKey is obsolete. Use the appropriate method to get the private key, such as GetRSAPrivateKey, or use the CopyWithPrivateKey method to create a new instance with a private key.";
                    //--TRIMMABLE-BOUNDARY-END(506806796309)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(502511829013)
                    this.X509CertificatePrivateKeyDiagId = "SYSLIB0028";
                    //--TRIMMABLE-BOUNDARY-END(502511829013)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(274878562325)
                    this.ProduceLegacyHmacValuesMessage = "ProduceLegacyHmacValues is obsolete. Producing legacy HMAC values is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(274878562325)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(270583595029)
                    this.ProduceLegacyHmacValuesDiagId = "SYSLIB0029";
                    //--TRIMMABLE-BOUNDARY-END(270583595029)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(481036992533)
                    this.UseManagedSha1Message = "HMACSHA1 always uses the algorithm implementation provided by the platform. Use a constructor without the useManagedSha1 parameter.";
                    //--TRIMMABLE-BOUNDARY-END(481036992533)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(476742025237)
                    this.UseManagedSha1DiagId = "SYSLIB0030";
                    //--TRIMMABLE-BOUNDARY-END(476742025237)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(128849674261)
                    this.CryptoConfigEncodeOIDMessage = "EncodeOID is obsolete. Use the ASN.1 functionality provided in System.Formats.Asn1.";
                    //--TRIMMABLE-BOUNDARY-END(128849674261)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(124554706965)
                    this.CryptoConfigEncodeOIDDiagId = "SYSLIB0031";
                    //--TRIMMABLE-BOUNDARY-END(124554706965)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(111669805077)
                    this.CorruptedStateRecoveryMessage = "Recovery from corrupted process state exceptions is not supported; HandleProcessCorruptedStateExceptionsAttribute is ignored.";
                    //--TRIMMABLE-BOUNDARY-END(111669805077)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(107374837781)
                    this.CorruptedStateRecoveryDiagId = "SYSLIB0032";
                    //--TRIMMABLE-BOUNDARY-END(107374837781)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(335008104469)
                    this.Rfc2898CryptDeriveKeyMessage = "Rfc2898DeriveBytes.CryptDeriveKey is obsolete and is not supported. Use PasswordDeriveBytes.CryptDeriveKey instead.";
                    //--TRIMMABLE-BOUNDARY-END(335008104469)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(330713137173)
                    this.Rfc2898CryptDeriveKeyDiagId = "SYSLIB0033";
                    //--TRIMMABLE-BOUNDARY-END(330713137173)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(68720132117)
                    this.CmsSignerCspParamsCtorMessage = "CmsSigner(CspParameters) is obsolete and is not supported. Use an alternative constructor instead.";
                    //--TRIMMABLE-BOUNDARY-END(68720132117)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(64425164821)
                    this.CmsSignerCspParamsCtorDiagId = "SYSLIB0034";
                    //--TRIMMABLE-BOUNDARY-END(64425164821)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(390842679317)
                    this.SignerInfoCounterSigMessage = "ComputeCounterSignature without specifying a CmsSigner is obsolete and is not supported. Use the overload that accepts a CmsSigner.";
                    //--TRIMMABLE-BOUNDARY-END(390842679317)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(386547712021)
                    this.SignerInfoCounterSigDiagId = "SYSLIB0035";
                    //--TRIMMABLE-BOUNDARY-END(386547712021)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(309238300693)
                    this.RegexCompileToAssemblyMessage = "Regex.CompileToAssembly is obsolete and not supported. Use the GeneratedRegexAttribute with the regular expression source generator instead.";
                    //--TRIMMABLE-BOUNDARY-END(309238300693)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(304943333397)
                    this.RegexCompileToAssemblyDiagId = "SYSLIB0036";
                    //--TRIMMABLE-BOUNDARY-END(304943333397)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(42950328341)
                    this.AssemblyNameMembersMessage = "AssemblyName members HashAlgorithm, ProcessorArchitecture, and VersionCompatibility are obsolete and not supported.";
                    //--TRIMMABLE-BOUNDARY-END(42950328341)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(38655361045)
                    this.AssemblyNameMembersDiagId = "SYSLIB0037";
                    //--TRIMMABLE-BOUNDARY-END(38655361045)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(416612483093)
                    this.SystemDataSerializationFormatBinaryMessage = "SerializationFormat.Binary is obsolete and should not be used. See https://aka.ms/serializationformat-binary-obsolete for more information.";
                    //--TRIMMABLE-BOUNDARY-END(416612483093)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(412317515797)
                    this.SystemDataSerializationFormatBinaryDiagId = "SYSLIB0038";
                    //--TRIMMABLE-BOUNDARY-END(412317515797)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(472447057941)
                    this.TlsVersion10and11Message = "TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.";
                    //--TRIMMABLE-BOUNDARY-END(472447057941)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(468152090645)
                    this.TlsVersion10and11DiagId = "SYSLIB0039";
                    //--TRIMMABLE-BOUNDARY-END(468152090645)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(188979216405)
                    this.EncryptionPolicyMessage = "EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.";
                    //--TRIMMABLE-BOUNDARY-END(188979216405)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(184684249109)
                    this.EncryptionPolicyDiagId = "SYSLIB0040";
                    //--TRIMMABLE-BOUNDARY-END(184684249109)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(171799347221)
                    this.EccXmlExportImportMessage = "ToXmlString and FromXmlString have no implementation for ECC types, and are obsolete. Use a standard import and export format such as ExportSubjectPublicKeyInfo or ImportSubjectPublicKeyInfo for public keys and ExportPkcs8PrivateKey or ImportPkcs8PrivateKey for private keys.";
                    //--TRIMMABLE-BOUNDARY-END(171799347221)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(167504379925)
                    this.EccXmlExportImportDiagId = "SYSLIB0042";
                    //--TRIMMABLE-BOUNDARY-END(167504379925)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(180389281813)
                    this.EcDhPublicKeyBlobMessage = "ECDiffieHellmanPublicKey.ToByteArray() and the associated constructor do not have a consistent and interoperable implementation on all platforms. Use ECDiffieHellmanPublicKey.ExportSubjectPublicKeyInfo() instead.";
                    //--TRIMMABLE-BOUNDARY-END(180389281813)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(176094314517)
                    this.EcDhPublicKeyBlobDiagId = "SYSLIB0043";
                    //--TRIMMABLE-BOUNDARY-END(176094314517)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(34360393749)
                    this.AssemblyNameCodeBaseMessage = "AssemblyName.CodeBase and AssemblyName.EscapedCodeBase are obsolete. Using them for loading an assembly is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(34360393749)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(30065426453)
                    this.AssemblyNameCodeBaseDiagId = "SYSLIB0044";
                    //--TRIMMABLE-BOUNDARY-END(30065426453)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(137439608853)
                    this.CryptoStringFactoryMessage = "Cryptographic factory methods accepting an algorithm name are obsolete. Use the parameterless Create factory method on the algorithm type instead.";
                    //--TRIMMABLE-BOUNDARY-END(137439608853)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(133144641557)
                    this.CryptoStringFactoryDiagId = "SYSLIB0045";
                    //--TRIMMABLE-BOUNDARY-END(133144641557)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(103079870485)
                    this.ControlledExecutionRunMessage = "ControlledExecution.Run method may corrupt the process and should not be used in production code.";
                    //--TRIMMABLE-BOUNDARY-END(103079870485)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(98784903189)
                    this.ControlledExecutionRunDiagId = "SYSLIB0046";
                    //--TRIMMABLE-BOUNDARY-END(98784903189)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(523986665493)
                    this.XmlSecureResolverMessage = "XmlSecureResolver is obsolete. Use XmlResolver.ThrowingResolver instead when attempting to forbid XML external entity resolution.";
                    //--TRIMMABLE-BOUNDARY-END(523986665493)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(519691698197)
                    this.XmlSecureResolverDiagId = "SYSLIB0047";
                    //--TRIMMABLE-BOUNDARY-END(519691698197)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(369367842837)
                    this.RsaEncryptDecryptValueMessage = "RSA.EncryptValue and DecryptValue are not supported and throw NotSupportedException. Use RSA.Encrypt and RSA.Decrypt instead.";
                    //--TRIMMABLE-BOUNDARY-END(369367842837)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(365072875541)
                    this.RsaEncryptDecryptDiagId = "SYSLIB0048";
                    //--TRIMMABLE-BOUNDARY-END(365072875541)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(223338954773)
                    this.JsonSerializerOptionsAddContextMessage = "JsonSerializerOptions.AddContext is obsolete. To register a JsonSerializerContext, use either the TypeInfoResolver or TypeInfoResolverChain properties.";
                    //--TRIMMABLE-BOUNDARY-END(223338954773)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(219043987477)
                    this.JsonSerializerOptionsAddContextDiagId = "SYSLIB0049";
                    //--TRIMMABLE-BOUNDARY-END(219043987477)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(249108758549)
                    this.LegacyFormatterMessage = "Formatter-based serialization is obsolete and should not be used.";
                    //--TRIMMABLE-BOUNDARY-END(249108758549)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(236223856661)
                    this.LegacyFormatterDiagId = "SYSLIB0050";
                    //--TRIMMABLE-BOUNDARY-END(236223856661)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(244813791253)
                    this.LegacyFormatterImplMessage = "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.";
                    //--TRIMMABLE-BOUNDARY-END(244813791253)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(240518823957)
                    this.LegacyFormatterImplDiagId = "SYSLIB0051";
                    //--TRIMMABLE-BOUNDARY-END(240518823957)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(317828235285)
                    this.RegexExtensibilityImplMessage = "This API supports obsolete mechanisms for Regex extensibility. It is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(317828235285)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(313533267989)
                    this.RegexExtensibilityDiagId = "SYSLIB0052";
                    //--TRIMMABLE-BOUNDARY-END(313533267989)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8590589973)
                    this.AesGcmTagConstructorMessage = "AesGcm should indicate the required tag size for encryption and decryption. Use a constructor that accepts the tag size.";
                    //--TRIMMABLE-BOUNDARY-END(8590589973)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(4295622677)
                    this.AesGcmTagConstructorDiagId = "SYSLIB0053";
                    //--TRIMMABLE-BOUNDARY-END(4295622677)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(455267188757)
                    this.ThreadVolatileReadWriteMessage = "Thread.VolatileRead and Thread.VolatileWrite are obsolete. Use Volatile.Read or Volatile.Write respectively instead.";
                    //--TRIMMABLE-BOUNDARY-END(455267188757)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(450972221461)
                    this.ThreadVolatileReadWriteDiagId = "SYSLIB0054";
                    //--TRIMMABLE-BOUNDARY-END(450972221461)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25770459157)
                    this.ArmIntrinsicPerformsUnsignedOperationMessage = "The underlying hardware instruction does not perform a signed saturate narrowing operation, and it always returns an unsigned result. Use the unsigned overload instead.";
                    //--TRIMMABLE-BOUNDARY-END(25770459157)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21475491861)
                    this.ArmIntrinsicPerformsUnsignedOperationDiagId = "SYSLIB0055";
                    //--TRIMMABLE-BOUNDARY-END(21475491861)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(257698693141)
                    this.LoadFromHashAlgorithmMessage = "LoadFrom with a custom AssemblyHashAlgorithm is obsolete. Use overloads without an AssemblyHashAlgorithm.";
                    //--TRIMMABLE-BOUNDARY-END(257698693141)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(253403725845)
                    this.LoadFromHashAlgorithmDiagId = "SYSLIB0056";
                    //--TRIMMABLE-BOUNDARY-END(253403725845)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(515396730901)
                    this.X509CtorCertDataObsoleteMessage = "Loading certificate data through the constructor or Import is obsolete. Use X509CertificateLoader instead to load certificates.";
                    //--TRIMMABLE-BOUNDARY-END(515396730901)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(511101763605)
                    this.X509CtorCertDataObsoleteDiagId = "SYSLIB0057";
                    //--TRIMMABLE-BOUNDARY-END(511101763605)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(463857123349)
                    this.TlsCipherAlgorithmEnumsMessage = "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.";
                    //--TRIMMABLE-BOUNDARY-END(463857123349)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(459562156053)
                    this.TlsCipherAlgorithmEnumsDiagId = "SYSLIB0058";
                    //--TRIMMABLE-BOUNDARY-END(459562156053)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(425202417685)
                    this.SystemEventsEventsThreadShutdownMessage = "SystemEvents.EventsThreadShutdown callbacks are not run before the process exits. Use AppDomain.ProcessExit instead.";
                    //--TRIMMABLE-BOUNDARY-END(425202417685)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(420907450389)
                    this.SystemEventsEventsThreadShutdownDiagId = "SYSLIB0059";
                    //--TRIMMABLE-BOUNDARY-END(420907450389)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(343598039061)
                    this.Rfc2898DeriveBytesCtorMessage = "The constructors on Rfc2898DeriveBytes are obsolete. Use the static Pbkdf2 method instead.";
                    //--TRIMMABLE-BOUNDARY-END(343598039061)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(339303071765)
                    this.Rfc2898DeriveBytesCtorDiagId = "SYSLIB0060";
                    //--TRIMMABLE-BOUNDARY-END(339303071765)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(292058431509)
                    this.QueryableMinByMaxByTSourceObsoleteMessage = "The Queryable MinBy and MaxBy taking an IComparer<TSource> are obsolete. Use the new ones that take an IComparer<TKey>.";
                    //--TRIMMABLE-BOUNDARY-END(292058431509)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(287763464213)
                    this.QueryableMinByMaxByTSourceObsoleteDiagId = "SYSLIB0061";
                    //--TRIMMABLE-BOUNDARY-END(287763464213)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(532576600085)
                    this.XsltSettingsEnableScriptMessage = "XSLT Script blocks are not supported.";
                    //--TRIMMABLE-BOUNDARY-END(532576600085)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(528281632789)
                    this.XsltSettingsEnableScriptDiagId = "SYSLIB0062";
                    //--TRIMMABLE-BOUNDARY-END(528281632789)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 655381;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(382252744725),
    {
      "t": 1310721,
      "n": "SharedUrlFormat",
      "d": 655381,
      "h": 382252744725,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(382252744725),
//--TRIMMABLE-BOUNDARY-START(433792352277),
    {
      "t": 1310721,
      "n": "SystemTextEncodingUTF7Message",
      "d": 655381,
      "h": 433792352277,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(433792352277),
//--TRIMMABLE-BOUNDARY-START(429497384981),
    {
      "t": 1310721,
      "n": "SystemTextEncodingUTF7DiagId",
      "d": 655381,
      "h": 429497384981,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(429497384981),
//--TRIMMABLE-BOUNDARY-START(266288627733),
    {
      "t": 1310721,
      "n": "PrincipalPermissionAttributeMessage",
      "d": 655381,
      "h": 266288627733,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(266288627733),
//--TRIMMABLE-BOUNDARY-START(261993660437),
    {
      "t": 1310721,
      "n": "PrincipalPermissionAttributeDiagId",
      "d": 655381,
      "h": 261993660437,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(261993660437),
//--TRIMMABLE-BOUNDARY-START(77310066709),
    {
      "t": 1310721,
      "n": "CodeAccessSecurityMessage",
      "d": 655381,
      "h": 77310066709,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(77310066709),
//--TRIMMABLE-BOUNDARY-START(73015099413),
    {
      "t": 1310721,
      "n": "CodeAccessSecurityDiagId",
      "d": 655381,
      "h": 73015099413,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(73015099413),
//--TRIMMABLE-BOUNDARY-START(94489935893),
    {
      "t": 1310721,
      "n": "ConstrainedExecutionRegionMessage",
      "d": 655381,
      "h": 94489935893,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(94489935893),
//--TRIMMABLE-BOUNDARY-START(90194968597),
    {
      "t": 1310721,
      "n": "ConstrainedExecutionRegionDiagId",
      "d": 655381,
      "h": 90194968597,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(90194968597),
//--TRIMMABLE-BOUNDARY-START(214749020181),
    {
      "t": 1310721,
      "n": "GlobalAssemblyCacheMessage",
      "d": 655381,
      "h": 214749020181,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(214749020181),
//--TRIMMABLE-BOUNDARY-START(210454052885),
    {
      "t": 1310721,
      "n": "GlobalAssemblyCacheDiagId",
      "d": 655381,
      "h": 210454052885,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(210454052885),
//--TRIMMABLE-BOUNDARY-START(442382286869),
    {
      "t": 1310721,
      "n": "ThreadAbortMessage",
      "d": 655381,
      "h": 442382286869,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(442382286869),
//--TRIMMABLE-BOUNDARY-START(446677254165),
    {
      "t": 1310721,
      "n": "ThreadResetAbortMessage",
      "d": 655381,
      "h": 446677254165,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(446677254165),
//--TRIMMABLE-BOUNDARY-START(438087319573),
    {
      "t": 1310721,
      "n": "ThreadAbortDiagId",
      "d": 655381,
      "h": 438087319573,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(438087319573),
//--TRIMMABLE-BOUNDARY-START(146029543445),
    {
      "t": 1310721,
      "n": "DefaultCryptoAlgorithmsMessage",
      "d": 655381,
      "h": 146029543445,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(146029543445),
//--TRIMMABLE-BOUNDARY-START(141734576149),
    {
      "t": 1310721,
      "n": "DefaultCryptoAlgorithmsDiagId",
      "d": 655381,
      "h": 141734576149,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(141734576149),
//--TRIMMABLE-BOUNDARY-START(120259739669),
    {
      "t": 1310721,
      "n": "CreatePdbGeneratorMessage",
      "d": 655381,
      "h": 120259739669,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(120259739669),
//--TRIMMABLE-BOUNDARY-START(115964772373),
    {
      "t": 1310721,
      "n": "CreatePdbGeneratorDiagId",
      "d": 655381,
      "h": 115964772373,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(115964772373),
//--TRIMMABLE-BOUNDARY-START(51540262933),
    {
      "t": 1310721,
      "n": "AuthenticationManagerMessage",
      "d": 655381,
      "h": 51540262933,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(51540262933),
//--TRIMMABLE-BOUNDARY-START(47245295637),
    {
      "t": 1310721,
      "n": "AuthenticationManagerDiagId",
      "d": 655381,
      "h": 47245295637,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(47245295637),
//--TRIMMABLE-BOUNDARY-START(326418169877),
    {
      "t": 1310721,
      "n": "RemotingApisMessage",
      "d": 655381,
      "h": 326418169877,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(326418169877),
//--TRIMMABLE-BOUNDARY-START(322123202581),
    {
      "t": 1310721,
      "n": "RemotingApisDiagId",
      "d": 655381,
      "h": 322123202581,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(322123202581),
//--TRIMMABLE-BOUNDARY-START(60130197525),
    {
      "t": 1310721,
      "n": "BinaryFormatterMessage",
      "d": 655381,
      "h": 60130197525,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(60130197525),
//--TRIMMABLE-BOUNDARY-START(55835230229),
    {
      "t": 1310721,
      "n": "BinaryFormatterDiagId",
      "d": 655381,
      "h": 55835230229,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(55835230229),
//--TRIMMABLE-BOUNDARY-START(85900001301),
    {
      "t": 1310721,
      "n": "CodeBaseMessage",
      "d": 655381,
      "h": 85900001301,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(85900001301),
//--TRIMMABLE-BOUNDARY-START(81605034005),
    {
      "t": 1310721,
      "n": "CodeBaseDiagId",
      "d": 655381,
      "h": 81605034005,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(81605034005),
//--TRIMMABLE-BOUNDARY-START(197569150997),
    {
      "t": 1310721,
      "n": "EscapeUriStringMessage",
      "d": 655381,
      "h": 197569150997,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(197569150997),
//--TRIMMABLE-BOUNDARY-START(193274183701),
    {
      "t": 1310721,
      "n": "EscapeUriStringDiagId",
      "d": 655381,
      "h": 193274183701,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(193274183701),
//--TRIMMABLE-BOUNDARY-START(489626927125),
    {
      "t": 1310721,
      "n": "WebRequestMessage",
      "d": 655381,
      "h": 489626927125,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(489626927125),
//--TRIMMABLE-BOUNDARY-START(485331959829),
    {
      "t": 1310721,
      "n": "WebRequestDiagId",
      "d": 655381,
      "h": 485331959829,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(485331959829),
//--TRIMMABLE-BOUNDARY-START(163209412629),
    {
      "t": 1310721,
      "n": "DisablePrivateReflectionAttributeMessage",
      "d": 655381,
      "h": 163209412629,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(163209412629),
//--TRIMMABLE-BOUNDARY-START(158914445333),
    {
      "t": 1310721,
      "n": "DisablePrivateReflectionAttributeDiagId",
      "d": 655381,
      "h": 158914445333,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(158914445333),
//--TRIMMABLE-BOUNDARY-START(206159085589),
    {
      "t": 1310721,
      "n": "GetContextInfoMessage",
      "d": 655381,
      "h": 206159085589,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(206159085589),
//--TRIMMABLE-BOUNDARY-START(201864118293),
    {
      "t": 1310721,
      "n": "GetContextInfoDiagId",
      "d": 655381,
      "h": 201864118293,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(201864118293),
//--TRIMMABLE-BOUNDARY-START(399432613909),
    {
      "t": 1310721,
      "n": "StrongNameKeyPairMessage",
      "d": 655381,
      "h": 399432613909,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(399432613909),
//--TRIMMABLE-BOUNDARY-START(395137646613),
    {
      "t": 1310721,
      "n": "StrongNameKeyPairDiagId",
      "d": 655381,
      "h": 395137646613,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(395137646613),
//--TRIMMABLE-BOUNDARY-START(300648366101),
    {
      "t": 1310721,
      "n": "ReflectionOnlyLoadingMessage",
      "d": 655381,
      "h": 300648366101,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(300648366101),
//--TRIMMABLE-BOUNDARY-START(296353398805),
    {
      "t": 1310721,
      "n": "ReflectionOnlyLoadingDiagId",
      "d": 655381,
      "h": 296353398805,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(296353398805),
//--TRIMMABLE-BOUNDARY-START(377957777429),
    {
      "t": 1310721,
      "n": "RuntimeEnvironmentMessage",
      "d": 655381,
      "h": 377957777429,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(377957777429),
//--TRIMMABLE-BOUNDARY-START(373662810133),
    {
      "t": 1310721,
      "n": "RuntimeEnvironmentDiagId",
      "d": 655381,
      "h": 373662810133,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(373662810133),
//--TRIMMABLE-BOUNDARY-START(231928889365),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsIgnoreNullValuesMessage",
      "d": 655381,
      "h": 231928889365,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(231928889365),
//--TRIMMABLE-BOUNDARY-START(227633922069),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsIgnoreNullValuesDiagId",
      "d": 655381,
      "h": 227633922069,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(227633922069),
//--TRIMMABLE-BOUNDARY-START(154619478037),
    {
      "t": 1310721,
      "n": "DerivedCryptographicTypesMessage",
      "d": 655381,
      "h": 154619478037,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(154619478037),
//--TRIMMABLE-BOUNDARY-START(150324510741),
    {
      "t": 1310721,
      "n": "DerivedCryptographicTypesDiagId",
      "d": 655381,
      "h": 150324510741,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(150324510741),
//--TRIMMABLE-BOUNDARY-START(352187973653),
    {
      "t": 1310721,
      "n": "RijndaelMessage",
      "d": 655381,
      "h": 352187973653,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(352187973653),
//--TRIMMABLE-BOUNDARY-START(347893006357),
    {
      "t": 1310721,
      "n": "RijndaelDiagId",
      "d": 655381,
      "h": 347893006357,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(347893006357),
//--TRIMMABLE-BOUNDARY-START(360777908245),
    {
      "t": 1310721,
      "n": "RNGCryptoServiceProviderMessage",
      "d": 655381,
      "h": 360777908245,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(360777908245),
//--TRIMMABLE-BOUNDARY-START(356482940949),
    {
      "t": 1310721,
      "n": "RNGCryptoServiceProviderDiagId",
      "d": 655381,
      "h": 356482940949,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(356482940949),
//--TRIMMABLE-BOUNDARY-START(17180524565),
    {
      "t": 1310721,
      "n": "AppDomainCreateUnloadMessage",
      "d": 655381,
      "h": 17180524565,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(17180524565),
//--TRIMMABLE-BOUNDARY-START(12885557269),
    {
      "t": 1310721,
      "n": "AppDomainCreateUnloadDiagId",
      "d": 655381,
      "h": 12885557269,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(12885557269),
//--TRIMMABLE-BOUNDARY-START(408022548501),
    {
      "t": 1310721,
      "n": "SuppressIldasmAttributeMessage",
      "d": 655381,
      "h": 408022548501,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(408022548501),
//--TRIMMABLE-BOUNDARY-START(403727581205),
    {
      "t": 1310721,
      "n": "SuppressIldasmAttributeDiagId",
      "d": 655381,
      "h": 403727581205,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(403727581205),
//--TRIMMABLE-BOUNDARY-START(498216861717),
    {
      "t": 1310721,
      "n": "X509CertificateImmutableMessage",
      "d": 655381,
      "h": 498216861717,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(498216861717),
//--TRIMMABLE-BOUNDARY-START(493921894421),
    {
      "t": 1310721,
      "n": "X509CertificateImmutableDiagId",
      "d": 655381,
      "h": 493921894421,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(493921894421),
//--TRIMMABLE-BOUNDARY-START(283468496917),
    {
      "t": 1310721,
      "n": "PublicKeyPropertyMessage",
      "d": 655381,
      "h": 283468496917,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(283468496917),
//--TRIMMABLE-BOUNDARY-START(279173529621),
    {
      "t": 1310721,
      "n": "PublicKeyPropertyDiagId",
      "d": 655381,
      "h": 279173529621,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(279173529621),
//--TRIMMABLE-BOUNDARY-START(506806796309),
    {
      "t": 1310721,
      "n": "X509CertificatePrivateKeyMessage",
      "d": 655381,
      "h": 506806796309,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(506806796309),
//--TRIMMABLE-BOUNDARY-START(502511829013),
    {
      "t": 1310721,
      "n": "X509CertificatePrivateKeyDiagId",
      "d": 655381,
      "h": 502511829013,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(502511829013),
//--TRIMMABLE-BOUNDARY-START(274878562325),
    {
      "t": 1310721,
      "n": "ProduceLegacyHmacValuesMessage",
      "d": 655381,
      "h": 274878562325,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(274878562325),
//--TRIMMABLE-BOUNDARY-START(270583595029),
    {
      "t": 1310721,
      "n": "ProduceLegacyHmacValuesDiagId",
      "d": 655381,
      "h": 270583595029,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(270583595029),
//--TRIMMABLE-BOUNDARY-START(481036992533),
    {
      "t": 1310721,
      "n": "UseManagedSha1Message",
      "d": 655381,
      "h": 481036992533,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(481036992533),
//--TRIMMABLE-BOUNDARY-START(476742025237),
    {
      "t": 1310721,
      "n": "UseManagedSha1DiagId",
      "d": 655381,
      "h": 476742025237,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(476742025237),
//--TRIMMABLE-BOUNDARY-START(128849674261),
    {
      "t": 1310721,
      "n": "CryptoConfigEncodeOIDMessage",
      "d": 655381,
      "h": 128849674261,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(128849674261),
//--TRIMMABLE-BOUNDARY-START(124554706965),
    {
      "t": 1310721,
      "n": "CryptoConfigEncodeOIDDiagId",
      "d": 655381,
      "h": 124554706965,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(124554706965),
//--TRIMMABLE-BOUNDARY-START(111669805077),
    {
      "t": 1310721,
      "n": "CorruptedStateRecoveryMessage",
      "d": 655381,
      "h": 111669805077,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(111669805077),
//--TRIMMABLE-BOUNDARY-START(107374837781),
    {
      "t": 1310721,
      "n": "CorruptedStateRecoveryDiagId",
      "d": 655381,
      "h": 107374837781,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(107374837781),
//--TRIMMABLE-BOUNDARY-START(335008104469),
    {
      "t": 1310721,
      "n": "Rfc2898CryptDeriveKeyMessage",
      "d": 655381,
      "h": 335008104469,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(335008104469),
//--TRIMMABLE-BOUNDARY-START(330713137173),
    {
      "t": 1310721,
      "n": "Rfc2898CryptDeriveKeyDiagId",
      "d": 655381,
      "h": 330713137173,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(330713137173),
//--TRIMMABLE-BOUNDARY-START(68720132117),
    {
      "t": 1310721,
      "n": "CmsSignerCspParamsCtorMessage",
      "d": 655381,
      "h": 68720132117,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(68720132117),
//--TRIMMABLE-BOUNDARY-START(64425164821),
    {
      "t": 1310721,
      "n": "CmsSignerCspParamsCtorDiagId",
      "d": 655381,
      "h": 64425164821,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(64425164821),
//--TRIMMABLE-BOUNDARY-START(390842679317),
    {
      "t": 1310721,
      "n": "SignerInfoCounterSigMessage",
      "d": 655381,
      "h": 390842679317,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(390842679317),
//--TRIMMABLE-BOUNDARY-START(386547712021),
    {
      "t": 1310721,
      "n": "SignerInfoCounterSigDiagId",
      "d": 655381,
      "h": 386547712021,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(386547712021),
//--TRIMMABLE-BOUNDARY-START(309238300693),
    {
      "t": 1310721,
      "n": "RegexCompileToAssemblyMessage",
      "d": 655381,
      "h": 309238300693,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(309238300693),
//--TRIMMABLE-BOUNDARY-START(304943333397),
    {
      "t": 1310721,
      "n": "RegexCompileToAssemblyDiagId",
      "d": 655381,
      "h": 304943333397,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(304943333397),
//--TRIMMABLE-BOUNDARY-START(42950328341),
    {
      "t": 1310721,
      "n": "AssemblyNameMembersMessage",
      "d": 655381,
      "h": 42950328341,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(42950328341),
//--TRIMMABLE-BOUNDARY-START(38655361045),
    {
      "t": 1310721,
      "n": "AssemblyNameMembersDiagId",
      "d": 655381,
      "h": 38655361045,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(38655361045),
//--TRIMMABLE-BOUNDARY-START(416612483093),
    {
      "t": 1310721,
      "n": "SystemDataSerializationFormatBinaryMessage",
      "d": 655381,
      "h": 416612483093,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(416612483093),
//--TRIMMABLE-BOUNDARY-START(412317515797),
    {
      "t": 1310721,
      "n": "SystemDataSerializationFormatBinaryDiagId",
      "d": 655381,
      "h": 412317515797,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(412317515797),
//--TRIMMABLE-BOUNDARY-START(472447057941),
    {
      "t": 1310721,
      "n": "TlsVersion10and11Message",
      "d": 655381,
      "h": 472447057941,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(472447057941),
//--TRIMMABLE-BOUNDARY-START(468152090645),
    {
      "t": 1310721,
      "n": "TlsVersion10and11DiagId",
      "d": 655381,
      "h": 468152090645,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(468152090645),
//--TRIMMABLE-BOUNDARY-START(188979216405),
    {
      "t": 1310721,
      "n": "EncryptionPolicyMessage",
      "d": 655381,
      "h": 188979216405,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(188979216405),
//--TRIMMABLE-BOUNDARY-START(184684249109),
    {
      "t": 1310721,
      "n": "EncryptionPolicyDiagId",
      "d": 655381,
      "h": 184684249109,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(184684249109),
//--TRIMMABLE-BOUNDARY-START(171799347221),
    {
      "t": 1310721,
      "n": "EccXmlExportImportMessage",
      "d": 655381,
      "h": 171799347221,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(171799347221),
//--TRIMMABLE-BOUNDARY-START(167504379925),
    {
      "t": 1310721,
      "n": "EccXmlExportImportDiagId",
      "d": 655381,
      "h": 167504379925,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(167504379925),
//--TRIMMABLE-BOUNDARY-START(180389281813),
    {
      "t": 1310721,
      "n": "EcDhPublicKeyBlobMessage",
      "d": 655381,
      "h": 180389281813,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(180389281813),
//--TRIMMABLE-BOUNDARY-START(176094314517),
    {
      "t": 1310721,
      "n": "EcDhPublicKeyBlobDiagId",
      "d": 655381,
      "h": 176094314517,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(176094314517),
//--TRIMMABLE-BOUNDARY-START(34360393749),
    {
      "t": 1310721,
      "n": "AssemblyNameCodeBaseMessage",
      "d": 655381,
      "h": 34360393749,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(34360393749),
//--TRIMMABLE-BOUNDARY-START(30065426453),
    {
      "t": 1310721,
      "n": "AssemblyNameCodeBaseDiagId",
      "d": 655381,
      "h": 30065426453,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(30065426453),
//--TRIMMABLE-BOUNDARY-START(137439608853),
    {
      "t": 1310721,
      "n": "CryptoStringFactoryMessage",
      "d": 655381,
      "h": 137439608853,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(137439608853),
//--TRIMMABLE-BOUNDARY-START(133144641557),
    {
      "t": 1310721,
      "n": "CryptoStringFactoryDiagId",
      "d": 655381,
      "h": 133144641557,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(133144641557),
//--TRIMMABLE-BOUNDARY-START(103079870485),
    {
      "t": 1310721,
      "n": "ControlledExecutionRunMessage",
      "d": 655381,
      "h": 103079870485,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(103079870485),
//--TRIMMABLE-BOUNDARY-START(98784903189),
    {
      "t": 1310721,
      "n": "ControlledExecutionRunDiagId",
      "d": 655381,
      "h": 98784903189,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(98784903189),
//--TRIMMABLE-BOUNDARY-START(523986665493),
    {
      "t": 1310721,
      "n": "XmlSecureResolverMessage",
      "d": 655381,
      "h": 523986665493,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(523986665493),
//--TRIMMABLE-BOUNDARY-START(519691698197),
    {
      "t": 1310721,
      "n": "XmlSecureResolverDiagId",
      "d": 655381,
      "h": 519691698197,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(519691698197),
//--TRIMMABLE-BOUNDARY-START(369367842837),
    {
      "t": 1310721,
      "n": "RsaEncryptDecryptValueMessage",
      "d": 655381,
      "h": 369367842837,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(369367842837),
//--TRIMMABLE-BOUNDARY-START(365072875541),
    {
      "t": 1310721,
      "n": "RsaEncryptDecryptDiagId",
      "d": 655381,
      "h": 365072875541,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(365072875541),
//--TRIMMABLE-BOUNDARY-START(223338954773),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsAddContextMessage",
      "d": 655381,
      "h": 223338954773,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(223338954773),
//--TRIMMABLE-BOUNDARY-START(219043987477),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsAddContextDiagId",
      "d": 655381,
      "h": 219043987477,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(219043987477),
//--TRIMMABLE-BOUNDARY-START(249108758549),
    {
      "t": 1310721,
      "n": "LegacyFormatterMessage",
      "d": 655381,
      "h": 249108758549,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(249108758549),
//--TRIMMABLE-BOUNDARY-START(236223856661),
    {
      "t": 1310721,
      "n": "LegacyFormatterDiagId",
      "d": 655381,
      "h": 236223856661,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(236223856661),
//--TRIMMABLE-BOUNDARY-START(244813791253),
    {
      "t": 1310721,
      "n": "LegacyFormatterImplMessage",
      "d": 655381,
      "h": 244813791253,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(244813791253),
//--TRIMMABLE-BOUNDARY-START(240518823957),
    {
      "t": 1310721,
      "n": "LegacyFormatterImplDiagId",
      "d": 655381,
      "h": 240518823957,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(240518823957),
//--TRIMMABLE-BOUNDARY-START(317828235285),
    {
      "t": 1310721,
      "n": "RegexExtensibilityImplMessage",
      "d": 655381,
      "h": 317828235285,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(317828235285),
//--TRIMMABLE-BOUNDARY-START(313533267989),
    {
      "t": 1310721,
      "n": "RegexExtensibilityDiagId",
      "d": 655381,
      "h": 313533267989,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(313533267989),
//--TRIMMABLE-BOUNDARY-START(8590589973),
    {
      "t": 1310721,
      "n": "AesGcmTagConstructorMessage",
      "d": 655381,
      "h": 8590589973,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(8590589973),
//--TRIMMABLE-BOUNDARY-START(4295622677),
    {
      "t": 1310721,
      "n": "AesGcmTagConstructorDiagId",
      "d": 655381,
      "h": 4295622677,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(4295622677),
//--TRIMMABLE-BOUNDARY-START(455267188757),
    {
      "t": 1310721,
      "n": "ThreadVolatileReadWriteMessage",
      "d": 655381,
      "h": 455267188757,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(455267188757),
//--TRIMMABLE-BOUNDARY-START(450972221461),
    {
      "t": 1310721,
      "n": "ThreadVolatileReadWriteDiagId",
      "d": 655381,
      "h": 450972221461,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(450972221461),
//--TRIMMABLE-BOUNDARY-START(25770459157),
    {
      "t": 1310721,
      "n": "ArmIntrinsicPerformsUnsignedOperationMessage",
      "d": 655381,
      "h": 25770459157,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(25770459157),
//--TRIMMABLE-BOUNDARY-START(21475491861),
    {
      "t": 1310721,
      "n": "ArmIntrinsicPerformsUnsignedOperationDiagId",
      "d": 655381,
      "h": 21475491861,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(21475491861),
//--TRIMMABLE-BOUNDARY-START(257698693141),
    {
      "t": 1310721,
      "n": "LoadFromHashAlgorithmMessage",
      "d": 655381,
      "h": 257698693141,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(257698693141),
//--TRIMMABLE-BOUNDARY-START(253403725845),
    {
      "t": 1310721,
      "n": "LoadFromHashAlgorithmDiagId",
      "d": 655381,
      "h": 253403725845,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(253403725845),
//--TRIMMABLE-BOUNDARY-START(515396730901),
    {
      "t": 1310721,
      "n": "X509CtorCertDataObsoleteMessage",
      "d": 655381,
      "h": 515396730901,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(515396730901),
//--TRIMMABLE-BOUNDARY-START(511101763605),
    {
      "t": 1310721,
      "n": "X509CtorCertDataObsoleteDiagId",
      "d": 655381,
      "h": 511101763605,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(511101763605),
//--TRIMMABLE-BOUNDARY-START(463857123349),
    {
      "t": 1310721,
      "n": "TlsCipherAlgorithmEnumsMessage",
      "d": 655381,
      "h": 463857123349,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(463857123349),
//--TRIMMABLE-BOUNDARY-START(459562156053),
    {
      "t": 1310721,
      "n": "TlsCipherAlgorithmEnumsDiagId",
      "d": 655381,
      "h": 459562156053,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(459562156053),
//--TRIMMABLE-BOUNDARY-START(425202417685),
    {
      "t": 1310721,
      "n": "SystemEventsEventsThreadShutdownMessage",
      "d": 655381,
      "h": 425202417685,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(425202417685),
//--TRIMMABLE-BOUNDARY-START(420907450389),
    {
      "t": 1310721,
      "n": "SystemEventsEventsThreadShutdownDiagId",
      "d": 655381,
      "h": 420907450389,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(420907450389),
//--TRIMMABLE-BOUNDARY-START(343598039061),
    {
      "t": 1310721,
      "n": "Rfc2898DeriveBytesCtorMessage",
      "d": 655381,
      "h": 343598039061,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(343598039061),
//--TRIMMABLE-BOUNDARY-START(339303071765),
    {
      "t": 1310721,
      "n": "Rfc2898DeriveBytesCtorDiagId",
      "d": 655381,
      "h": 339303071765,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(339303071765),
//--TRIMMABLE-BOUNDARY-START(292058431509),
    {
      "t": 1310721,
      "n": "QueryableMinByMaxByTSourceObsoleteMessage",
      "d": 655381,
      "h": 292058431509,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(292058431509),
//--TRIMMABLE-BOUNDARY-START(287763464213),
    {
      "t": 1310721,
      "n": "QueryableMinByMaxByTSourceObsoleteDiagId",
      "d": 655381,
      "h": 287763464213,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(287763464213),
//--TRIMMABLE-BOUNDARY-START(532576600085),
    {
      "t": 1310721,
      "n": "XsltSettingsEnableScriptMessage",
      "d": 655381,
      "h": 532576600085,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(532576600085),
//--TRIMMABLE-BOUNDARY-START(528281632789),
    {
      "t": 1310721,
      "n": "XsltSettingsEnableScriptDiagId",
      "d": 655381,
      "h": 528281632789,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(528281632789)
  ],
  "h": 655381
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Obsoletions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655381)
        
        
        //--TRIMMABLE-BOUNDARY-START(131093)
        $asm.$cls("$stc.Internal.PaddingHelpers", ($self) => class PaddingHelpers
        {
            //--TRIMMABLE-BOUNDARY-START(4295098389)
            /*int*/ static CACHE_LINE_SIZE = 128;
            //--TRIMMABLE-BOUNDARY-END(4295098389)
            
            static $h = 131093;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295098389),
    {
      "t": 655361,
      "n": "CACHE_LINE_SIZE",
      "d": 131093,
      "h": 4295098389,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(4295098389)
  ],
  "h": 131093
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Internal.PaddingHelpers`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131093)
        
        
        //--TRIMMABLE-BOUNDARY-START(327701)
        $asm.$cls("$stc.System.Collections.Concurrent.SingleProducerSingleConsumerQueue<>", (T) => $asm.$gt("$stc.System.Collections.Concurrent.SingleProducerSingleConsumerQueue<>", [T], ($self) => class SingleProducerSingleConsumerQueue$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(68719804437)
            /*int*/ static InitialSegmentSize = 32;
            //--TRIMMABLE-BOUNDARY-END(68719804437)
            
            //--TRIMMABLE-BOUNDARY-START(77309739029)
            /*int*/ static MaxSegmentSize = 16777216;
            //--TRIMMABLE-BOUNDARY-END(77309739029)
            
            //--TRIMMABLE-BOUNDARY-START(4295294997)
            /*Segment*/ _head = null;
            //--TRIMMABLE-BOUNDARY-END(4295294997)
            
            //--TRIMMABLE-BOUNDARY-START(8590262293)
            /*Segment*/ _tail = null;
            //--TRIMMABLE-BOUNDARY-END(8590262293)
            
            //--TRIMMABLE-BOUNDARY-START(25770131477)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770131477);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.Diagnostics.Debug.Assert$2(32/*InitialSegmentSize*/ > 0, "Initial segment size must be > 0.");
                    $.$$.System.Diagnostics.Debug.Assert$2((32/*InitialSegmentSize*/ & (((32/*InitialSegmentSize*/ - 1) | 0))) === 0, "Initial segment size must be a power of 2");
                    $.$$.System.Diagnostics.Debug.Assert$2(32/*InitialSegmentSize*/ <= 16777216/*MaxSegmentSize*/, "Initial segment size should be <= maximum.");
                    $.$$.System.Diagnostics.Debug.Assert$2(16777216/*MaxSegmentSize*/ < $.trunc(2147483647/*int.MaxValue*/ / 2), "Max segment size * 2 must be < int.MaxValue, or else overflow could occur.");
                    this._head = this._tail = new ($.$stc.System.Collections.Concurrent.SingleProducerSingleConsumerQueue$$(T).Segment)().$ctor$1(32/*InitialSegmentSize*/);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770131477)
            
            //--TRIMMABLE-BOUNDARY-START(38655033365)
            /*void */ Enqueue(/*T*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655033365);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Segment*/ let segment = this._tail;
                /*T[]*/ let array = segment._array;
                /*int*/ let last = segment._state._last;
                /*int*/ let tail2 = (((last + 1) | 0)) & (((array.length - 1) | 0));
                if (tail2 !== segment._state._firstCopy)
                {
                    $.$$.System.Array.$WriteT1.call(array, item, last);
                    segment._state._last = tail2;
                    return;
                }
                this.EnqueueSlow(item, $.$ref(() => segment, ($v) => segment = $v, $.$stc.System.Collections.Concurrent.SingleProducerSingleConsumerQueue$$(T).Segment));
            }
            //--TRIMMABLE-BOUNDARY-END(38655033365)
            
            //--TRIMMABLE-BOUNDARY-START(42950000661)
            /*void */ EnqueueSlow(/*T*/ item, /*ref Segment*/ segment)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950000661);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(!(segment.$v === null), "Expected a non-null segment.");
                if (segment.$v._state._firstCopy !== segment.$v._state._first)
                {
                    segment.$v._state._firstCopy = segment.$v._state._first;
                    this.Enqueue(item);
                    return;
                }
                /*int*/ let newSegmentSize = $.$$.System.Math.Min$4(((this._tail._array.length * 2) | 0), 16777216/*MaxSegmentSize*/);
                $.$$.System.Diagnostics.Debug.Assert$2(newSegmentSize > 0, "The max size should always be small enough that we don't overflow.");
                /*var*/ let newSegment = new ($.$stc.System.Collections.Concurrent.SingleProducerSingleConsumerQueue$$(T).Segment)().$ctor$1(newSegmentSize);
                $.$$.System.Array.$WriteT1.call(newSegment._array, item, 0);
                newSegment._state._last = 1;
                newSegment._state._lastCopy = 1;
                try
                {
                }
                finally
                {
                    {
                        $.$ref(() => this._tail._next, ($v) => this._tail._next = $v, $.$stc.System.Collections.Concurrent.SingleProducerSingleConsumerQueue$$(T).Segment).$v = newSegment;
                        this._tail = newSegment;
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950000661)
            
            //--TRIMMABLE-BOUNDARY-START(90194640917)
            /*bool */ TryDequeue(/*out T*/ result)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194640917);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Segment*/ let segment = this._head;
                /*T[]*/ let array = segment._array;
                /*int*/ let first = segment._state._first;
                if (first !== segment._state._lastCopy)
                {
                    result.$v = $.$$.System.Array.$ReadT1.call(array, first);
                    $.$$.System.Array.$WriteT1.call(array, $.$default(T), first);
                    segment._state._first = (((first + 1) | 0)) & (((array.length - 1) | 0));
                    return true;
                }
                return this.TryDequeueSlow(segment, array, false, result);
            }
            //--TRIMMABLE-BOUNDARY-END(90194640917)
            
            //--TRIMMABLE-BOUNDARY-START(107374510101)
            /*bool */ TryPeek(/*out T*/ result)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374510101);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Segment*/ let segment = this._head;
                /*T[]*/ let array = segment._array;
                /*int*/ let first = segment._state._first;
                if (first !== segment._state._lastCopy)
                {
                    result.$v = $.$$.System.Array.$ReadT1.call(array, first);
                    return true;
                }
                return this.TryDequeueSlow(segment, array, true, result);
            }
            //--TRIMMABLE-BOUNDARY-END(107374510101)
            
            //--TRIMMABLE-BOUNDARY-START(103079542805)
            /*bool */ TryDequeueSlow(/*Segment*/ segment, /*T[]*/ array, /*bool*/ peek, /*out T*/ result)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079542805);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(!(segment === null), "Expected a non-null segment.");
                $.$$.System.Diagnostics.Debug.Assert$2(!(array === null), "Expected a non-null item array.");
                if (segment._state._last !== segment._state._lastCopy)
                {
                    segment._state._lastCopy = segment._state._last;
                    return peek ? this.TryPeek(result) : this.TryDequeue(result);
                }
                if (!(segment._next === null) && segment._state._first === segment._state._last)
                {
                    segment = segment._next;
                    array = segment._array;
                    this._head = segment;
                }
                /*int*/ let first = segment._state._first;
                if (first === segment._state._last)
                {
                    result.$v = $.$default(T);
                    return false;
                }
                result.$v = $.$$.System.Array.$ReadT1.call(array, first);
                if (!peek)
                {
                    $.$$.System.Array.$WriteT1.call(array, $.$default(T), first);
                    segment._state._first = (((first + 1) | 0)) & (((segment._array.length - 1) | 0));
                    segment._state._lastCopy = segment._state._last;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(103079542805)
            
            //--TRIMMABLE-BOUNDARY-START(94489608213)
            /*bool */ TryDequeueIf(/*Predicate<T>?*/ predicate, /*out T*/ result)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489608213);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Segment*/ let segment = this._head;
                /*T[]*/ let array = segment._array;
                /*int*/ let first = segment._state._first;
                if (first !== segment._state._lastCopy)
                {
                    result.$v = $.$$.System.Array.$ReadT1.call(array, first);
                    if (predicate === null || predicate.Invoke(result.$v))
                    {
                        $.$$.System.Array.$WriteT1.call(array, $.$default(T), first);
                        segment._state._first = (((first + 1) | 0)) & (((array.length - 1) | 0));
                        return true;
                    }
                    result.$v = $.$default(T);
                    return false;
                }
                return this.TryDequeueIfSlow(predicate, segment, array, result);
            }
            //--TRIMMABLE-BOUNDARY-END(94489608213)
            
            //--TRIMMABLE-BOUNDARY-START(98784575509)
            /*bool */ TryDequeueIfSlow(/*Predicate<T>?*/ predicate, /*Segment*/ segment, /*T[]*/ array, /*out T*/ result)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784575509);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(!(segment === null), "Expected a non-null segment.");
                $.$$.System.Diagnostics.Debug.Assert$2(!(array === null), "Expected a non-null item array.");
                if (segment._state._last !== segment._state._lastCopy)
                {
                    segment._state._lastCopy = segment._state._last;
                    return this.TryDequeueIf(predicate, result);
                }
                if (!(segment._next === null) && segment._state._first === segment._state._last)
                {
                    segment = segment._next;
                    array = segment._array;
                    this._head = segment;
                }
                /*int*/ let first = segment._state._first;
                if (first === segment._state._last)
                {
                    result.$v = $.$default(T);
                    return false;
                }
                result.$v = $.$$.System.Array.$ReadT1.call(array, first);
                if (predicate === null || predicate.Invoke(result.$v))
                {
                    $.$$.System.Array.$WriteT1.call(array, $.$default(T), first);
                    segment._state._first = (((first + 1) | 0)) & (((segment._array.length - 1) | 0));
                    segment._state._lastCopy = segment._state._last;
                    return true;
                }
                result.$v = $.$default(T);
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(98784575509)
            
            //--TRIMMABLE-BOUNDARY-START(30065098773)
            /*void */ Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065098773);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                while(this.TryDequeue($.$discardRef()))
                {
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065098773)
            
            //--TRIMMABLE-BOUNDARY-START(73014771733)
            /*bool */ get IsEmpty()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129869845);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Segment*/ let head = this._head;
                if (head._state._first !== head._state._lastCopy)
                {
                    return false;
                }
                if (head._state._first !== head._state._last)
                {
                    return false;
                }
                return head._next === null;
            }
            //--TRIMMABLE-BOUNDARY-END(73014771733)
            
            //--TRIMMABLE-BOUNDARY-START(64424837141)
            /*IEnumerator<T> */ GetEnumerator()
            {
                return new ($.$$.NetJs.YieldToIterator$$(T))().$ctor$1(function*()
                {
                    for(/*Segment?*/ let segment = this._head; !(segment === null); segment = segment._next)
                    {
                        for(/*int*/ let pt = segment._state._first; pt !== segment._state._last; pt = (((pt + 1) | 0)) & (((segment._array.length - 1) | 0)))
                        {
                            yield $.$$.System.Array.$ReadT1.call(segment._array, pt);
                        }
                    }
                }.bind(this)).GetEnumerator();
            }
            //--TRIMMABLE-BOUNDARY-END(64424837141)
            
            //--TRIMMABLE-BOUNDARY-START(85899673621)
            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899673621);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetEnumerator();
            }
            //--TRIMMABLE-BOUNDARY-END(85899673621)
            
            //--TRIMMABLE-BOUNDARY-START(34360066069)
            /*int */ get Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539935253);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let count = 0;
                for(/*Segment?*/ let segment = this._head; !(segment === null); segment = segment._next)
                {
                    /*int*/ let arraySize = segment._array.length;
                    /*int*/ let first, last;
                    while(true)
                    {
                        first = segment._state._first;
                        last = segment._state._last;
                        if (first === segment._state._first)
                        {
                            break;
                        }
                    }
                    count += (((last - first) | 0)) & (((arraySize - 1) | 0));
                }
                return count;
            }
            //--TRIMMABLE-BOUNDARY-END(34360066069)
            
            //--TRIMMABLE-BOUNDARY-START(81604706325)
            /*int */ System$Collections$Concurrent$IProducerConsumerQueue$$$GetCountSafe(/*object*/ syncObj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604706325);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(!(syncObj === null), "The syncObj parameter is null.");
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(syncObj)
                    {
                        return this.Count;
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(syncObj)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(81604706325)
            
            //--TRIMMABLE-BOUNDARY-START(393237)
            static $_Segment;
            static get Segment()
            {
                let $cls = $.$stc.System.Collections.Concurrent.SingleProducerSingleConsumerQueue$$(T);
                return $cls.$_Segment ??= $asm.$ncls("$stc.System.Collections.Concurrent.SingleProducerSingleConsumerQueue$$.Segment", ($self) => class Segment extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(8590327829)
                    /*Segment?*/  get _next() { return this.$getField(0, 4); }
                    /*Segment?*/  set _next(value) { this.$setField(0, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(8590327829)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295360533)
                    /*T[]*/  get _array() { return this.$getField(4, 4); }
                    /*T[]*/  set _array(value) { this.$setField(4, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(4295360533)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885295125)
                    /*SegmentState*/  get _state() { return this.$getField(8, 388); }
                    /*SegmentState*/  set _state(value) { this.$setField(8, 388, value); }
                    //--TRIMMABLE-BOUNDARY-END(12885295125)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180262421)
                    $ctor$1(/*int*/ size)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(17180262421);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            $.$$.System.Diagnostics.Debug.Assert$2((size & (((size - 1) | 0))) === 0, "Size must be a power of 2");
                            this._array = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(T), null, [size], null);
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180262421)
                    
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(8590327829)
                        this._next = null;
                        //--TRIMMABLE-BOUNDARY-END(8590327829)
                        
                        //--TRIMMABLE-BOUNDARY-START(4295360533)
                        this._array = null;
                        //--TRIMMABLE-BOUNDARY-END(4295360533)
                        
                        //--TRIMMABLE-BOUNDARY-START(12885295125)
                        this._state = $.$default($.$stc.System.Collections.Concurrent.SingleProducerSingleConsumerQueue$$(T).SegmentState);
                        //--TRIMMABLE-BOUNDARY-END(12885295125)
                        
                    }
                    static $h = 393237;
                    static $f = 0b100010000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590327829),
    {
      "t": 393237,
      "n": "_next",
      "d": 393237,
      "h": Number(BigInt(393237)|0x200000000n),
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(8590327829),
//--TRIMMABLE-BOUNDARY-START(4295360533),
    {
      "t": $.$typeArray(T).$h,
      "n": "_array",
      "d": 393237,
      "h": Number(BigInt(393237)|0x100000000n),
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(4295360533),
//--TRIMMABLE-BOUNDARY-START(12885295125),
    {
      "t": 458773,
      "n": "_state",
      "d": 393237,
      "h": Number(BigInt(393237)|0x300000000n),
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(12885295125)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180262421),
    {
      "p": [
        {
          "n": "size",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 393237,
      "h": Number(BigInt(393237)|0x400000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(17180262421)
  ],
  "d": $.$stc.System.Collections.Concurrent.SingleProducerSingleConsumerQueue$$(T).$h,
  "h": 393237,
  "a": [
    {
      "t": 147390465,
      "c": 13032292353,
      "a": [
        {
          "v": 0,
          "t": 142868481
        }
      ]
    }
  ]
}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Collections.Concurrent.SingleProducerSingleConsumerQueue<${T?.$fullName}>.Segment`; }
                }, $cls, ($v) => $cls.$_Segment = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(393237)
            
            //--TRIMMABLE-BOUNDARY-START(458773)
            static $_SegmentState;
            static get SegmentState()
            {
                let $cls = $.$stc.System.Collections.Concurrent.SingleProducerSingleConsumerQueue$$(T);
                return $cls.$_SegmentState ??= $asm.$nstr("$stc.System.Collections.Concurrent.SingleProducerSingleConsumerQueue$$.SegmentState", ($self) => class SegmentState extends $.$$.System.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(21475295253)
                    /*PaddingFor32*/  get _pad0() { return this.$getField(0, 124); }
                    /*PaddingFor32*/  set _pad0(value) { this.$setField(0, 124, value); }
                    //--TRIMMABLE-BOUNDARY-END(21475295253)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295426069)
                    /*int*/  get _first() { return this.$getField(124, 4); }
                    /*int*/  set _first(value) { this.$setField(124, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(4295426069)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180327957)
                    /*int*/  get _lastCopy() { return this.$getField(128, 4); }
                    /*int*/  set _lastCopy(value) { this.$setField(128, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(17180327957)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770262549)
                    /*PaddingFor32*/  get _pad1() { return this.$getField(132, 124); }
                    /*PaddingFor32*/  set _pad1(value) { this.$setField(132, 124, value); }
                    //--TRIMMABLE-BOUNDARY-END(25770262549)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590393365)
                    /*int*/  get _firstCopy() { return this.$getField(256, 4); }
                    /*int*/  set _firstCopy(value) { this.$setField(256, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(8590393365)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885360661)
                    /*int*/  get _last() { return this.$getField(260, 4); }
                    /*int*/  set _last(value) { this.$setField(260, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(12885360661)
                    
                    //--TRIMMABLE-BOUNDARY-START(30065229845)
                    /*PaddingFor32*/  get _pad2() { return this.$getField(264, 124); }
                    /*PaddingFor32*/  set _pad2(value) { this.$setField(264, 124, value); }
                    //--TRIMMABLE-BOUNDARY-END(30065229845)
                    
                    //--TRIMMABLE-BOUNDARY-START(34360197141)
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(34360197141)
                    
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._pad0 = this._pad0.Clone();
                        copy._first = this._first;
                        copy._lastCopy = this._lastCopy;
                        copy._pad1 = this._pad1.Clone();
                        copy._firstCopy = this._firstCopy;
                        copy._last = this._last;
                        copy._pad2 = this._pad2.Clone();
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(21475295253)
                        this._pad0 = $.$default($.$stc.Internal.PaddingFor32);
                        //--TRIMMABLE-BOUNDARY-END(21475295253)
                        
                        //--TRIMMABLE-BOUNDARY-START(4295426069)
                        this._first = 0;
                        //--TRIMMABLE-BOUNDARY-END(4295426069)
                        
                        //--TRIMMABLE-BOUNDARY-START(17180327957)
                        this._lastCopy = 0;
                        //--TRIMMABLE-BOUNDARY-END(17180327957)
                        
                        //--TRIMMABLE-BOUNDARY-START(25770262549)
                        this._pad1 = $.$default($.$stc.Internal.PaddingFor32);
                        //--TRIMMABLE-BOUNDARY-END(25770262549)
                        
                        //--TRIMMABLE-BOUNDARY-START(8590393365)
                        this._firstCopy = 0;
                        //--TRIMMABLE-BOUNDARY-END(8590393365)
                        
                        //--TRIMMABLE-BOUNDARY-START(12885360661)
                        this._last = 0;
                        //--TRIMMABLE-BOUNDARY-END(12885360661)
                        
                        //--TRIMMABLE-BOUNDARY-START(30065229845)
                        this._pad2 = $.$default($.$stc.Internal.PaddingFor32);
                        //--TRIMMABLE-BOUNDARY-END(30065229845)
                        
                    }
                    static $h = 458773;
                    static $z = 388;
                    static $f = 0b100010000001011000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 196609,
  "l": [
//--TRIMMABLE-BOUNDARY-START(21475295253),
    {
      "t": 65557,
      "n": "_pad0",
      "d": 458773,
      "h": Number(BigInt(458773)|0x500000000n),
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(21475295253),
//--TRIMMABLE-BOUNDARY-START(4295426069),
    {
      "t": 655361,
      "n": "_first",
      "d": 458773,
      "h": Number(BigInt(458773)|0x100000000n),
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(4295426069),
//--TRIMMABLE-BOUNDARY-START(17180327957),
    {
      "t": 655361,
      "n": "_lastCopy",
      "d": 458773,
      "h": Number(BigInt(458773)|0x400000000n),
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(17180327957),
//--TRIMMABLE-BOUNDARY-START(25770262549),
    {
      "t": 65557,
      "n": "_pad1",
      "d": 458773,
      "h": Number(BigInt(458773)|0x600000000n),
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(25770262549),
//--TRIMMABLE-BOUNDARY-START(8590393365),
    {
      "t": 655361,
      "n": "_firstCopy",
      "d": 458773,
      "h": Number(BigInt(458773)|0x200000000n),
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(8590393365),
//--TRIMMABLE-BOUNDARY-START(12885360661),
    {
      "t": 655361,
      "n": "_last",
      "d": 458773,
      "h": Number(BigInt(458773)|0x300000000n),
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(12885360661),
//--TRIMMABLE-BOUNDARY-START(30065229845),
    {
      "t": 65557,
      "n": "_pad2",
      "d": 458773,
      "h": Number(BigInt(458773)|0x700000000n),
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(30065229845)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(34360197141),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 458773,
      "h": Number(BigInt(458773)|0x800000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360197141)
  ],
  "d": $.$stc.System.Collections.Concurrent.SingleProducerSingleConsumerQueue$$(T).$h,
  "h": 458773,
  "a": [
    {
      "t": 147390465,
      "c": 13032292353,
      "a": [
        {
          "v": 0,
          "t": 142868481
        }
      ]
    }
  ]
}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `System.Collections.Concurrent.SingleProducerSingleConsumerQueue<${T?.$fullName}>.SegmentState`; }
                }, $cls, ($v) => $cls.$_SegmentState = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(458773)
            
            //--TRIMMABLE-BOUNDARY-START(8590131221)
            //Generated interface implemetation for System.Collections.Concurrent.IProducerConsumerQueue<T>.Enqueue(T)
            System$Collections$Concurrent$IProducerConsumerQueue$$$Enqueue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590131221);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Enqueue(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590131221)
            
            //--TRIMMABLE-BOUNDARY-START(38654902293)
            //Generated interface implemetation for System.Collections.Concurrent.IProducerConsumerQueue<T>.TryDequeue(out T)
            System$Collections$Concurrent$IProducerConsumerQueue$$$TryDequeue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654902293);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.TryDequeue(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(38654902293)
            
            //--TRIMMABLE-BOUNDARY-START(25770000405)
            //Generated interface implemetation for System.Collections.Concurrent.IProducerConsumerQueue<T>.IsEmpty.get
            get System$Collections$Concurrent$IProducerConsumerQueue$$$IsEmpty()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359934997);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsEmpty;
            }
            //--TRIMMABLE-BOUNDARY-END(25770000405)
            
            //--TRIMMABLE-BOUNDARY-START(17180065813)
            //Generated interface implemetation for System.Collections.Concurrent.IProducerConsumerQueue<T>.Count.get
            get System$Collections$Concurrent$IProducerConsumerQueue$$$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295163925);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(17180065813)
            
            //--TRIMMABLE-BOUNDARY-START(4354605057)
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<T>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4354605057);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetEnumerator(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4354605057)
            
            static $h = 327701;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(73014771733),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xE00000000n),
        "f": 50331649
      },
      "n": "IsEmpty",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1100000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73014771733),
//--TRIMMABLE-BOUNDARY-START(34360066069),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xC00000000n),
        "f": 50331649
      },
      "n": "Count",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360066069)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38655033365),
    {
      "r": 65537,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1507328
        }
      ],
      "n": "Enqueue",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655033365),
//--TRIMMABLE-BOUNDARY-START(42950000661),
    {
      "r": 65537,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1507328
        },
        {
          "n": "segment",
          "p": 393237,
          "f": 4
        }
      ],
      "n": "EnqueueSlow",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(42950000661),
//--TRIMMABLE-BOUNDARY-START(90194640917),
    {
      "r": 262145,
      "p": [
        {
          "n": "result",
          "p": T?.$h??1507328,
          "f": 2
        }
      ],
      "n": "TryDequeue",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(90194640917),
//--TRIMMABLE-BOUNDARY-START(107374510101),
    {
      "r": 262145,
      "p": [
        {
          "n": "result",
          "p": T?.$h??1507328,
          "f": 2
        }
      ],
      "n": "TryPeek",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1900000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(107374510101),
//--TRIMMABLE-BOUNDARY-START(103079542805),
    {
      "r": 262145,
      "p": [
        {
          "n": "segment",
          "p": 393237
        },
        {
          "n": "array",
          "p": $.$typeArray(T).$h
        },
        {
          "n": "peek",
          "p": 262145
        },
        {
          "n": "result",
          "p": T?.$h??1507328,
          "f": 2
        }
      ],
      "n": "TryDequeueSlow",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1800000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(103079542805),
//--TRIMMABLE-BOUNDARY-START(94489608213),
    {
      "r": 262145,
      "p": [
        {
          "n": "predicate",
          "p": $.$$.System.Predicate$$(T).$h
        },
        {
          "n": "result",
          "p": T?.$h??1507328,
          "f": 2
        }
      ],
      "n": "TryDequeueIf",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(94489608213),
//--TRIMMABLE-BOUNDARY-START(98784575509),
    {
      "r": 262145,
      "p": [
        {
          "n": "predicate",
          "p": $.$$.System.Predicate$$(T).$h
        },
        {
          "n": "segment",
          "p": 393237
        },
        {
          "n": "array",
          "p": $.$typeArray(T).$h
        },
        {
          "n": "result",
          "p": T?.$h??1507328,
          "f": 2
        }
      ],
      "n": "TryDequeueIfSlow",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1700000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(98784575509),
//--TRIMMABLE-BOUNDARY-START(30065098773),
    {
      "r": 65537,
      "n": "Clear",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065098773),
//--TRIMMABLE-BOUNDARY-START(64424837141),
    {
      "r": $.$$.System.Collections.Generic.IEnumerator$$(T).$h,
      "n": "GetEnumerator",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xF00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64424837141)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(68719804437),
    {
      "t": 655361,
      "n": "InitialSegmentSize",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1000000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(68719804437),
//--TRIMMABLE-BOUNDARY-START(77309739029),
    {
      "t": 655361,
      "n": "MaxSegmentSize",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1200000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(77309739029),
//--TRIMMABLE-BOUNDARY-START(4295294997),
    {
      "t": 393237,
      "n": "_head",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295294997),
//--TRIMMABLE-BOUNDARY-START(8590262293),
    {
      "t": 393237,
      "n": "_tail",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590262293)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770131477),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770131477)
  ],
  "i": [$.$stc.System.Collections.Concurrent.IProducerConsumerQueue$$(T).$h,$.$$.System.Collections.Generic.IEnumerable$$(T).$h,62652417
  ],
  "g": [T?.$h??1507328
  ],
  "j": [393237,458773
  ],
  "r": 1,
  "h": this.$h,
  "a": [
    {
      "t": 70385665,
      "c": 25840189441,
      "a": [
        {
          "v": "Count = {Count}",
          "t": 1310721
        }
      ]
    },
    {
      "t": 70713345,
      "c": 21545549825,
      "a": [
        {
          "v": null,
          "t": 187760641
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stc.System.Collections.Concurrent.IProducerConsumerQueue$$(T), $.$$.System.Collections.Generic.IEnumerable$$(T), $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Collections.Concurrent.SingleProducerSingleConsumerQueue<${T?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(327701)
        
        
        //--TRIMMABLE-BOUNDARY-START(3211285)
        $asm.$str("$stc.System.VoidResult", ($self) => class VoidResult extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(4298178581)
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298178581)
            
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                return copy;
            }
            static $h = 3211285;
            static $z = 0;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298178581),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3211285,
      "h": 4298178581,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298178581)
  ],
  "h": 3211285
}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.VoidResult`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3211285)
        
        
        //--TRIMMABLE-BOUNDARY-START(1441813)
        $asm.$cls("$stc.System.Threading.Channels.BoundedChannelOptions", ($self) => class BoundedChannelOptions extends $.$stc.System.Threading.Channels.ChannelOptions
        {
            //--TRIMMABLE-BOUNDARY-START(4296409109)
            /*int*/ _capacity = 0;
            //--TRIMMABLE-BOUNDARY-END(4296409109)
            
            //--TRIMMABLE-BOUNDARY-START(8591376405)
            /*BoundedChannelFullMode*/ _mode = 0;
            //--TRIMMABLE-BOUNDARY-END(8591376405)
            
            //--TRIMMABLE-BOUNDARY-START(12886343701)
            $ctor$2(/*int*/ capacity)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886343701);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (capacity < 0)
                    {
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("capacity");
                    }
                    this._capacity = capacity;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886343701)
            
            //--TRIMMABLE-BOUNDARY-START(17181310997)
            /*int */ get Capacity()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066212885);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._capacity;
            }
            /*int */ set Capacity(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246082069);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value < 0)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("value");
                }
                this._capacity = value;
            }
            //--TRIMMABLE-BOUNDARY-END(17181310997)
            
            //--TRIMMABLE-BOUNDARY-START(21476278293)
            /*BoundedChannelFullMode */ get FullMode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656147477);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._mode;
            }
            /*BoundedChannelFullMode */ set FullMode(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836016661);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                switch(value)
                {
                    case 0/*BoundedChannelFullMode.Wait*/:
                    case 1/*BoundedChannelFullMode.DropNewest*/:
                    case 2/*BoundedChannelFullMode.DropOldest*/:
                    case 3/*BoundedChannelFullMode.DropWrite*/:
                    this._mode = value;
                    break;
                    default:
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("value");
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21476278293)
            
            static $h = 1441813;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1769493,
  "p": [
//--TRIMMABLE-BOUNDARY-START(17181310997),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066212885,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47246082069,
        "f": 83886081
      },
      "n": "Capacity",
      "d": 1441813,
      "h": 17181310997,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17181310997),
//--TRIMMABLE-BOUNDARY-START(21476278293),
    {
      "p": 1376277,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656147477,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55836016661,
        "f": 83886081
      },
      "n": "FullMode",
      "d": 1441813,
      "h": 21476278293,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476278293)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296409109),
    {
      "t": 655361,
      "n": "_capacity",
      "d": 1441813,
      "h": 4296409109,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296409109),
//--TRIMMABLE-BOUNDARY-START(8591376405),
    {
      "t": 1376277,
      "n": "_mode",
      "d": 1441813,
      "h": 8591376405,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591376405)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886343701),
    {
      "p": [
        {
          "n": "capacity",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1441813,
      "h": 12886343701,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886343701)
  ],
  "h": 1441813
}; }
            static get $b() { return $.$stc.System.Threading.Channels.ChannelOptions; }
            static get $fullName() { return `System.Threading.Channels.BoundedChannelOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1441813)
        
        
        //--TRIMMABLE-BOUNDARY-START(3014677)
        $asm.$cls("$stc.System.Threading.Channels.UnboundedPrioritizedChannelOptions<>", (T) => $asm.$gt("$stc.System.Threading.Channels.UnboundedPrioritizedChannelOptions<>", [T], ($self) => class UnboundedPrioritizedChannelOptions$$ extends $.$stc.System.Threading.Channels.ChannelOptions
        {
            //--TRIMMABLE-BOUNDARY-START(12887916565)
            /*IComparer<T>?*/ Comparer = null;
            //--TRIMMABLE-BOUNDARY-END(12887916565)
            
            //--TRIMMABLE-BOUNDARY-START(8592949269)
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592949269)
            
            static $h = 3014677;
            static $g = 1;
            static $f = 0b11010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1769493,
  "p": [
//--TRIMMABLE-BOUNDARY-START(12887916565),
    {
      "p": $.$$.System.Collections.Generic.IComparer$$(T).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x500000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x700000000n),
        "f": 83886081
      },
      "n": "Comparer",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12887916565)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592949269),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592949269)
  ],
  "g": [T?.$h??1507328
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$stc.System.Threading.Channels.ChannelOptions; }
            static get $fullName() { return `System.Threading.Channels.UnboundedPrioritizedChannelOptions<${T?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(3014677)
        
        
        //--TRIMMABLE-BOUNDARY-START(65557)
        $asm.$str("$stc.Internal.PaddingFor32", ($self) => class PaddingFor32 extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(4295032853)
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295032853)
            
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                return copy;
            }
            static $h = 65557;
            static $z = 124;
            static $f = 0b100000000001010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295032853),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 65557,
      "h": 4295032853,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295032853)
  ],
  "h": 65557,
  "a": [
    {
      "t": 147390465,
      "c": 13032292353,
      "a": [
        {
          "v": 2,
          "t": 142868481
        }
      ],
      "n": [
        {
          "n": "Size",
          "v": 124,
          "t": 655361
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `Internal.PaddingFor32`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65557)
        
        
        //--TRIMMABLE-BOUNDARY-START(2752533)
        $asm.$cls("$stc.System.Threading.Channels.UnboundedChannelOptions", ($self) => class UnboundedChannelOptions extends $.$stc.System.Threading.Channels.ChannelOptions
        {
            //--TRIMMABLE-BOUNDARY-START(4297719829)
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297719829)
            
            static $h = 2752533;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1769493,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297719829),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2752533,
      "h": 4297719829,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297719829)
  ],
  "h": 2752533
}; }
            static get $b() { return $.$stc.System.Threading.Channels.ChannelOptions; }
            static get $fullName() { return `System.Threading.Channels.UnboundedChannelOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2752533)
        
        
        //--TRIMMABLE-BOUNDARY-START(2162709)
        $asm.$cls("$stc.System.Threading.Channels.RendezvousChannel<>", (T) => $asm.$gt("$stc.System.Threading.Channels.RendezvousChannel<>", [T], ($self) => class RendezvousChannel$$ extends $.$stc.System.Threading.Channels.Channel$$(T)
        {
            //--TRIMMABLE-BOUNDARY-START(21476999189)
            /*bool*/ _dropWrites = false;
            //--TRIMMABLE-BOUNDARY-END(21476999189)
            
            //--TRIMMABLE-BOUNDARY-START(25771966485)
            /*Action<T>?*/ _itemDropped = null;
            //--TRIMMABLE-BOUNDARY-END(25771966485)
            
            //--TRIMMABLE-BOUNDARY-START(12887064597)
            /*TaskCompletionSource*/ _completion = null;
            //--TRIMMABLE-BOUNDARY-END(12887064597)
            
            //--TRIMMABLE-BOUNDARY-START(4297130005)
            /*BlockedReadAsyncOperation<T>?*/ _blockedReadersHead = null;
            //--TRIMMABLE-BOUNDARY-END(4297130005)
            
            //--TRIMMABLE-BOUNDARY-START(8592097301)
            /*BlockedWriteAsyncOperation<T>?*/ _blockedWritersHead = null;
            //--TRIMMABLE-BOUNDARY-END(8592097301)
            
            //--TRIMMABLE-BOUNDARY-START(34361901077)
            /*WaitingReadAsyncOperation?*/ _waitingReadersHead = null;
            //--TRIMMABLE-BOUNDARY-END(34361901077)
            
            //--TRIMMABLE-BOUNDARY-START(38656868373)
            /*WaitingWriteAsyncOperation?*/ _waitingWritersHead = null;
            //--TRIMMABLE-BOUNDARY-END(38656868373)
            
            //--TRIMMABLE-BOUNDARY-START(30066933781)
            /*bool*/ _runContinuationsAsynchronously = false;
            //--TRIMMABLE-BOUNDARY-END(30066933781)
            
            //--TRIMMABLE-BOUNDARY-START(17182031893)
            /*Exception?*/ _doneWriting = null;
            //--TRIMMABLE-BOUNDARY-END(17182031893)
            
            //--TRIMMABLE-BOUNDARY-START(55836737557)
            $ctor$3(/*BoundedChannelFullMode*/ mode, /*bool*/ runContinuationsAsynchronously, /*Action<T>?*/ itemDropped)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55836737557);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._dropWrites = !(mode === 0/*BoundedChannelFullMode.Wait*/);
                    this._runContinuationsAsynchronously = runContinuationsAsynchronously;
                    this._itemDropped = itemDropped;
                    this._completion = new $.$$.System.Threading.Tasks.TaskCompletionSource().$ctor$4(runContinuationsAsynchronously ? 64/*TaskCreationOptions.RunContinuationsAsynchronously*/ : 0/*TaskCreationOptions.None*/);
                    this.Reader = new ($.$stc.System.Threading.Channels.RendezvousChannel$$(T).RendezvousChannelReader)().$ctor$2(this);
                    this.Writer = new ($.$stc.System.Threading.Channels.RendezvousChannel$$(T).RendezvousChannelWriter)().$ctor$2(this);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(55836737557)
            
            //--TRIMMABLE-BOUNDARY-START(2228245)
            static $_RendezvousChannelReader;
            static get RendezvousChannelReader()
            {
                let $cls = $.$stc.System.Threading.Channels.RendezvousChannel$$(T);
                return $cls.$_RendezvousChannelReader ??= $asm.$ncls("$stc.System.Threading.Channels.RendezvousChannel$$.RendezvousChannelReader", ($self) => class RendezvousChannelReader extends $.$stc.System.Threading.Channels.ChannelReader$$(T)
                {
                    //--TRIMMABLE-BOUNDARY-START(4297195541)
                    /*RendezvousChannel<T>*/ _parent = null;
                    //--TRIMMABLE-BOUNDARY-END(4297195541)
                    
                    //--TRIMMABLE-BOUNDARY-START(8592162837)
                    /*BlockedReadAsyncOperation<T>*/ _readerSingleton = null;
                    //--TRIMMABLE-BOUNDARY-END(8592162837)
                    
                    //--TRIMMABLE-BOUNDARY-START(12887130133)
                    /*WaitingReadAsyncOperation*/ _waiterSingleton = null;
                    //--TRIMMABLE-BOUNDARY-END(12887130133)
                    
                    //--TRIMMABLE-BOUNDARY-START(17182097429)
                    $ctor$2(/*RendezvousChannel<T>*/ parent)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(17182097429);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._parent = parent;
                            this._readerSingleton = new ($.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T))().$ctor$4(parent._runContinuationsAsynchronously, new $.$$.System.Threading.CancellationToken(), true, null);
                            this._waiterSingleton = new $.$stc.System.Threading.Channels.WaitingReadAsyncOperation().$ctor$4(parent._runContinuationsAsynchronously, new $.$$.System.Threading.CancellationToken(), true, null);
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17182097429)
                    
                    //--TRIMMABLE-BOUNDARY-START(30066999317)
                    /*Task */ get Completion()
                    {
                        return this._parent._completion.Task;
                    }
                    //--TRIMMABLE-BOUNDARY-END(30066999317)
                    
                    //--TRIMMABLE-BOUNDARY-START(21477064725)
                    /*bool */ get CanCount()
                    {
                        return true;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21477064725)
                    
                    //--TRIMMABLE-BOUNDARY-START(25772032021)
                    /*bool */ get CanPeek()
                    {
                        return true;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25772032021)
                    
                    //--TRIMMABLE-BOUNDARY-START(34361966613)
                    /*int */ get Count()
                    {
                        return 0;
                    }
                    //--TRIMMABLE-BOUNDARY-END(34361966613)
                    
                    //--TRIMMABLE-BOUNDARY-START(94491508757)
                    /*bool */ TryRead(/*out T*/ item)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(94491508757);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*RendezvousChannel<T>*/ let parent = this._parent;
                        /*BlockedWriteAsyncOperation<T>?*/ let blockedWriter = null;
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(parent.SyncObj)
                            {
                                parent.AssertInvariants();
                                if (parent._doneWriting === null)
                                {
                                    blockedWriter = $.$stc.System.Threading.Channels.ChannelUtilities.TryDequeueAndReserveCompletionIfCancelable($.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T), $.$ref(() => parent._blockedWritersHead, ($v) => parent._blockedWritersHead = $v, $.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T)));
                                }
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(parent.SyncObj)
                        }
                        if (!(blockedWriter === null))
                        {
                            item.$v = blockedWriter.Item$1;
                            blockedWriter.DangerousSetResult(new $.$stc.System.VoidResult());
                            return true;
                        }
                        item.$v = $.$default(T);
                        return false;
                    }
                    //--TRIMMABLE-BOUNDARY-END(94491508757)
                    
                    //--TRIMMABLE-BOUNDARY-START(90196541461)
                    /*bool */ TryPeek(/*out T*/ item)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(90196541461);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*RendezvousChannel<T>*/ let parent = this._parent;
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(parent.SyncObj)
                            {
                                parent.AssertInvariants();
                                let blockedWriter;
                                if (parent._doneWriting === null && parent._blockedWritersHead !== null && ((blockedWriter = parent._blockedWritersHead, blockedWriter != null && true)))
                                {
                                    item.$v = blockedWriter.Item$1;
                                    return true;
                                }
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(parent.SyncObj)
                        }
                        item.$v = $.$default(T);
                        return false;
                    }
                    //--TRIMMABLE-BOUNDARY-END(90196541461)
                    
                    //--TRIMMABLE-BOUNDARY-START(85901574165)
                    /*ValueTask<T> */ ReadAsync(/*CancellationToken*/ cancellationToken)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(85901574165);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*RendezvousChannel<T>*/ let parent = this._parent;
                        if (cancellationToken.IsCancellationRequested)
                        {
                            return new ($.$$.System.Threading.Tasks.ValueTask$$(T))().$ctor$5($.$$.System.Threading.Tasks.Task.FromCanceled$3(T, cancellationToken));
                        }
                        /*BlockedReadAsyncOperation<T>?*/ let reader = null;
                        /*WaitingWriteAsyncOperation?*/ let waitingWriters = null;
                        /*BlockedWriteAsyncOperation<T>?*/ let blockedWriter = null;
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(parent.SyncObj)
                            {
                                parent.AssertInvariants();
                                if (!(parent._doneWriting === null))
                                {
                                    return $.$stc.System.Threading.Channels.ChannelUtilities.GetInvalidCompletionValueTask(T, parent._doneWriting);
                                }
                                blockedWriter = $.$stc.System.Threading.Channels.ChannelUtilities.TryDequeueAndReserveCompletionIfCancelable($.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T), $.$ref(() => parent._blockedWritersHead, ($v) => parent._blockedWritersHead = $v, $.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T)));
                                if (blockedWriter === null)
                                {
                                    reader = !cancellationToken.CanBeCanceled && this._readerSingleton.TryOwnAndReset() ? this._readerSingleton : new ($.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T))().$ctor$4(parent._runContinuationsAsynchronously, new $.$$.System.Threading.CancellationToken(), false, this._parent.CancellationCallbackDelegate);
                                    $.$stc.System.Threading.Channels.ChannelUtilities.Enqueue($.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T), $.$ref(() => parent._blockedReadersHead, ($v) => parent._blockedReadersHead = $v, $.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T)), reader);
                                    waitingWriters = $.$stc.System.Threading.Channels.ChannelUtilities.TryReserveCompletionIfCancelable($.$stc.System.Threading.Channels.WaitingWriteAsyncOperation, $.$ref(() => parent._waitingWritersHead, ($v) => parent._waitingWritersHead = $v, $.$stc.System.Threading.Channels.WaitingWriteAsyncOperation));
                                }
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(parent.SyncObj)
                        }
                        /*ValueTask<T>*/ let result;
                        if (!(blockedWriter === null))
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(reader === null, "reader is null");
                            $.$$.System.Diagnostics.Debug.Assert$2(waitingWriters === null, "waitingWriters is null");
                            result = new ($.$$.System.Threading.Tasks.ValueTask$$(T))().$ctor$6(blockedWriter.Item$1);
                            blockedWriter.DangerousSetResult(new $.$stc.System.VoidResult());
                        }
                        else 
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(!(reader === null), "reader is not null");
                            $.$stc.System.Threading.Channels.ChannelUtilities.DangerousSetOperations($.$stc.System.Threading.Channels.WaitingWriteAsyncOperation, $.$$.System.Boolean, waitingWriters, true);
                            result = reader.ValueTaskOfT;
                        }
                        return result;
                    }
                    //--TRIMMABLE-BOUNDARY-END(85901574165)
                    
                    //--TRIMMABLE-BOUNDARY-START(98786476053)
                    /*ValueTask<bool> */ WaitToReadAsync(/*CancellationToken*/ cancellationToken)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(98786476053);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (cancellationToken.IsCancellationRequested)
                        {
                            return new ($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Boolean))().$ctor$5($.$$.System.Threading.Tasks.Task.FromCanceled$3($.$$.System.Boolean, cancellationToken));
                        }
                        /*RendezvousChannel<T>*/ let parent = this._parent;
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(parent.SyncObj)
                            {
                                parent.AssertInvariants();
                                if (!(parent._doneWriting === null))
                                {
                                    return parent._doneWriting !== $.$stc.System.Threading.Channels.ChannelUtilities.s_doneWritingSentinel ? new ($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Boolean))().$ctor$5($.$$.System.Threading.Tasks.Task.FromException$1($.$$.System.Boolean, parent._doneWriting)) : new ($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Boolean))();
                                }
                                if (!(parent._blockedWritersHead === null))
                                {
                                    return new ($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Boolean))().$ctor$6(true);
                                }
                                /*WaitingReadAsyncOperation*/ let waiter = !cancellationToken.CanBeCanceled && this._waiterSingleton.TryOwnAndReset() ? this._waiterSingleton : new $.$stc.System.Threading.Channels.WaitingReadAsyncOperation().$ctor$4(parent._runContinuationsAsynchronously, new $.$$.System.Threading.CancellationToken(), false, this._parent.CancellationCallbackDelegate);
                                $.$stc.System.Threading.Channels.ChannelUtilities.Enqueue($.$stc.System.Threading.Channels.WaitingReadAsyncOperation, $.$ref(() => parent._waitingReadersHead, ($v) => parent._waitingReadersHead = $v, $.$stc.System.Threading.Channels.WaitingReadAsyncOperation), waiter);
                                return waiter.ValueTaskOfT;
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(parent.SyncObj)
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(98786476053)
                    
                    //--TRIMMABLE-BOUNDARY-START(38656933909)
                    /*string */ get DebuggerDisplay()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(81606606869);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*long*/ let blockedReaderCount, waitingReaderCount;
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(this._parent.SyncObj)
                            {
                                blockedReaderCount = $.$stc.System.Threading.Channels.ChannelUtilities.CountOperations($.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T), this._parent._blockedReadersHead);
                                waitingReaderCount = $.$stc.System.Threading.Channels.ChannelUtilities.CountOperations($.$stc.System.Threading.Channels.WaitingReadAsyncOperation, this._parent._waitingReadersHead);
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(this._parent.SyncObj)
                        }
                        return `ReadAsync=${blockedReaderCount}, WaitToReadAsync=${waitingReaderCount}`;
                    }
                    //--TRIMMABLE-BOUNDARY-END(38656933909)
                    
                    static $h = 2228245;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30066999317),
    {
      "p": 177668097,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(2228245)|0xF00000000n),
        "f": 50364417
      },
      "n": "Completion",
      "d": 2228245,
      "h": Number(BigInt(2228245)|0x700000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(30066999317),
//--TRIMMABLE-BOUNDARY-START(21477064725),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(2228245)|0xB00000000n),
        "f": 50364417
      },
      "n": "CanCount",
      "d": 2228245,
      "h": Number(BigInt(2228245)|0x500000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21477064725),
//--TRIMMABLE-BOUNDARY-START(25772032021),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(2228245)|0xD00000000n),
        "f": 50364417
      },
      "n": "CanPeek",
      "d": 2228245,
      "h": Number(BigInt(2228245)|0x600000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(25772032021),
//--TRIMMABLE-BOUNDARY-START(34361966613),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(2228245)|0x1100000000n),
        "f": 50364417
      },
      "n": "Count",
      "d": 2228245,
      "h": Number(BigInt(2228245)|0x800000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34361966613),
//--TRIMMABLE-BOUNDARY-START(38656933909),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(2228245)|0x1300000000n),
        "f": 50331656
      },
      "n": "DebuggerDisplay",
      "d": 2228245,
      "h": Number(BigInt(2228245)|0x900000000n),
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(38656933909)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(94491508757),
    {
      "r": 262145,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1507328,
          "f": 2
        }
      ],
      "n": "TryRead",
      "d": 2228245,
      "h": Number(BigInt(2228245)|0x1600000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(94491508757),
//--TRIMMABLE-BOUNDARY-START(90196541461),
    {
      "r": 262145,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1507328,
          "f": 2
        }
      ],
      "n": "TryPeek",
      "d": 2228245,
      "h": Number(BigInt(2228245)|0x1500000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(90196541461),
//--TRIMMABLE-BOUNDARY-START(85901574165),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$(T).$h,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "ReadAsync",
      "d": 2228245,
      "h": Number(BigInt(2228245)|0x1400000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(85901574165),
//--TRIMMABLE-BOUNDARY-START(98786476053),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Boolean).$h,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "WaitToReadAsync",
      "d": 2228245,
      "h": Number(BigInt(2228245)|0x1700000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(98786476053)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297195541),
    {
      "t": $.$stc.System.Threading.Channels.RendezvousChannel$$(T).$h,
      "n": "_parent",
      "d": 2228245,
      "h": Number(BigInt(2228245)|0x100000000n),
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(4297195541),
//--TRIMMABLE-BOUNDARY-START(8592162837),
    {
      "t": $.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T).$h,
      "n": "_readerSingleton",
      "d": 2228245,
      "h": Number(BigInt(2228245)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8592162837),
//--TRIMMABLE-BOUNDARY-START(12887130133),
    {
      "t": 3080213,
      "n": "_waiterSingleton",
      "d": 2228245,
      "h": Number(BigInt(2228245)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12887130133)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17182097429),
    {
      "p": [
        {
          "n": "parent",
          "p": $.$stc.System.Threading.Channels.RendezvousChannel$$(T).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2228245,
      "h": Number(BigInt(2228245)|0x400000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(17182097429)
  ],
  "d": $.$stc.System.Threading.Channels.RendezvousChannel$$(T).$h,
  "h": 2228245,
  "a": [
    {
      "t": 70385665,
      "c": 25840189441,
      "a": [
        {
          "v": "{DebuggerDisplay,nq}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
                    static get $b() { return $.$stc.System.Threading.Channels.ChannelReader$$(T); }
                    static get $fullName() { return `System.Threading.Channels.RendezvousChannel<${T?.$fullName}>.RendezvousChannelReader`; }
                }, $cls, ($v) => $cls.$_RendezvousChannelReader = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2228245)
            
            //--TRIMMABLE-BOUNDARY-START(2293781)
            static $_RendezvousChannelWriter;
            static get RendezvousChannelWriter()
            {
                let $cls = $.$stc.System.Threading.Channels.RendezvousChannel$$(T);
                return $cls.$_RendezvousChannelWriter ??= $asm.$ncls("$stc.System.Threading.Channels.RendezvousChannel$$.RendezvousChannelWriter", ($self) => class RendezvousChannelWriter extends $.$stc.System.Threading.Channels.ChannelWriter$$(T)
                {
                    //--TRIMMABLE-BOUNDARY-START(4297261077)
                    /*RendezvousChannel<T>*/ _parent = null;
                    //--TRIMMABLE-BOUNDARY-END(4297261077)
                    
                    //--TRIMMABLE-BOUNDARY-START(12887195669)
                    /*BlockedWriteAsyncOperation<T>*/ _writerSingleton = null;
                    //--TRIMMABLE-BOUNDARY-END(12887195669)
                    
                    //--TRIMMABLE-BOUNDARY-START(8592228373)
                    /*WaitingWriteAsyncOperation*/ _waiterSingleton = null;
                    //--TRIMMABLE-BOUNDARY-END(8592228373)
                    
                    //--TRIMMABLE-BOUNDARY-START(17182162965)
                    $ctor$2(/*RendezvousChannel<T>*/ parent)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(17182162965);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._parent = parent;
                            this._writerSingleton = new ($.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T))().$ctor$4(true, new $.$$.System.Threading.CancellationToken(), true, null);
                            this._waiterSingleton = new $.$stc.System.Threading.Channels.WaitingWriteAsyncOperation().$ctor$4(true, new $.$$.System.Threading.CancellationToken(), true, null);
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17182162965)
                    
                    //--TRIMMABLE-BOUNDARY-START(34362032149)
                    /*bool */ TryComplete(/*Exception?*/ error)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34362032149);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*RendezvousChannel<T>*/ let parent = this._parent;
                        /*BlockedReadAsyncOperation<T>?*/ let blockedReadersHead;
                        /*BlockedWriteAsyncOperation<T>?*/ let blockedWritersHead;
                        /*WaitingReadAsyncOperation?*/ let waitingReadersHead;
                        /*WaitingWriteAsyncOperation?*/ let waitingWritersHead;
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(parent.SyncObj)
                            {
                                parent.AssertInvariants();
                                if (!(parent._doneWriting === null))
                                {
                                    return false;
                                }
                                parent._doneWriting = error ?? $.$stc.System.Threading.Channels.ChannelUtilities.s_doneWritingSentinel;
                                blockedReadersHead = parent._blockedReadersHead;
                                blockedWritersHead = parent._blockedWritersHead;
                                waitingReadersHead = parent._waitingReadersHead;
                                waitingWritersHead = parent._waitingWritersHead;
                                parent._blockedReadersHead = null;
                                parent._blockedWritersHead = null;
                                parent._waitingReadersHead = null;
                                parent._waitingWritersHead = null;
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(parent.SyncObj)
                        }
                        $.$stc.System.Threading.Channels.ChannelUtilities.Complete(parent._completion, error);
                        $.$stc.System.Threading.Channels.ChannelUtilities.FailOperations($.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T), blockedReadersHead, $.$stc.System.Threading.Channels.ChannelUtilities.CreateInvalidCompletionException(error));
                        $.$stc.System.Threading.Channels.ChannelUtilities.FailOperations($.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T), blockedWritersHead, $.$stc.System.Threading.Channels.ChannelUtilities.CreateInvalidCompletionException(error));
                        $.$stc.System.Threading.Channels.ChannelUtilities.SetOrFailOperations($.$stc.System.Threading.Channels.WaitingReadAsyncOperation, $.$$.System.Boolean, waitingReadersHead, false, error);
                        $.$stc.System.Threading.Channels.ChannelUtilities.SetOrFailOperations($.$stc.System.Threading.Channels.WaitingWriteAsyncOperation, $.$$.System.Boolean, waitingWritersHead, false, error);
                        return true;
                    }
                    //--TRIMMABLE-BOUNDARY-END(34362032149)
                    
                    //--TRIMMABLE-BOUNDARY-START(38656999445)
                    /*bool */ TryWrite(/*T*/ item)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(38656999445);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*RendezvousChannel<T>*/ let parent = this._parent;
                        /*BlockedReadAsyncOperation<T>?*/ let blockedReader = null;
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(parent.SyncObj)
                            {
                                parent.AssertInvariants();
                                if (parent._doneWriting === null)
                                {
                                    blockedReader = $.$stc.System.Threading.Channels.ChannelUtilities.TryDequeueAndReserveCompletionIfCancelable($.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T), $.$ref(() => parent._blockedReadersHead, ($v) => parent._blockedReadersHead = $v, $.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T)));
                                }
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(parent.SyncObj)
                        }
                        if (!(blockedReader === null))
                        {
                            blockedReader.DangerousSetResult(item);
                            return true;
                        }
                        if (parent._dropWrites)
                        {
                            parent._itemDropped?.Invoke(item);
                            return true;
                        }
                        return false;
                    }
                    //--TRIMMABLE-BOUNDARY-END(38656999445)
                    
                    //--TRIMMABLE-BOUNDARY-START(42951966741)
                    /*ValueTask<bool> */ WaitToWriteAsync(/*CancellationToken*/ cancellationToken)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(42951966741);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (cancellationToken.IsCancellationRequested)
                        {
                            return new ($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Boolean))().$ctor$5($.$$.System.Threading.Tasks.Task.FromCanceled$3($.$$.System.Boolean, cancellationToken));
                        }
                        /*RendezvousChannel<T>*/ let parent = this._parent;
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(parent.SyncObj)
                            {
                                parent.AssertInvariants();
                                if (!(parent._doneWriting === null))
                                {
                                    return parent._doneWriting !== $.$stc.System.Threading.Channels.ChannelUtilities.s_doneWritingSentinel ? new ($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Boolean))().$ctor$5($.$$.System.Threading.Tasks.Task.FromException$1($.$$.System.Boolean, parent._doneWriting)) : new ($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Boolean))();
                                }
                                if (!(parent._blockedReadersHead === null) || parent._dropWrites)
                                {
                                    return new ($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Boolean))().$ctor$6(true);
                                }
                                /*WaitingWriteAsyncOperation*/ let waiter = !cancellationToken.CanBeCanceled && this._waiterSingleton.TryOwnAndReset() ? this._waiterSingleton : new $.$stc.System.Threading.Channels.WaitingWriteAsyncOperation().$ctor$4(parent._runContinuationsAsynchronously, new $.$$.System.Threading.CancellationToken(), false, this._parent.CancellationCallbackDelegate);
                                $.$stc.System.Threading.Channels.ChannelUtilities.Enqueue($.$stc.System.Threading.Channels.WaitingWriteAsyncOperation, $.$ref(() => parent._waitingWritersHead, ($v) => parent._waitingWritersHead = $v, $.$stc.System.Threading.Channels.WaitingWriteAsyncOperation), waiter);
                                return waiter.ValueTaskOfT;
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(parent.SyncObj)
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(42951966741)
                    
                    //--TRIMMABLE-BOUNDARY-START(47246934037)
                    /*ValueTask */ WriteAsync(/*T*/ item, /*CancellationToken*/ cancellationToken)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(47246934037);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*RendezvousChannel<T>*/ let parent = this._parent;
                        if (cancellationToken.IsCancellationRequested)
                        {
                            return new $.$$.System.Threading.Tasks.ValueTask().$ctor$5($.$$.System.Threading.Tasks.Task.FromCanceled$3(T, cancellationToken));
                        }
                        /*BlockedWriteAsyncOperation<T>?*/ let writer = null;
                        /*WaitingReadAsyncOperation?*/ let waitingReaders = null;
                        /*BlockedReadAsyncOperation<T>?*/ let blockedReader = null;
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(parent.SyncObj)
                            {
                                parent.AssertInvariants();
                                if (!(parent._doneWriting === null))
                                {
                                    return new $.$$.System.Threading.Tasks.ValueTask().$ctor$5($.$$.System.Threading.Tasks.Task.FromException($.$stc.System.Threading.Channels.ChannelUtilities.CreateInvalidCompletionException(parent._doneWriting)));
                                }
                                blockedReader = $.$stc.System.Threading.Channels.ChannelUtilities.TryDequeueAndReserveCompletionIfCancelable($.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T), $.$ref(() => parent._blockedReadersHead, ($v) => parent._blockedReadersHead = $v, $.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T)));
                                if (blockedReader === null && !parent._dropWrites)
                                {
                                    writer = !cancellationToken.CanBeCanceled && this._writerSingleton.TryOwnAndReset() ? this._writerSingleton : new ($.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T))().$ctor$4(parent._runContinuationsAsynchronously, new $.$$.System.Threading.CancellationToken(), false, this._parent.CancellationCallbackDelegate);
                                    writer.Item$1 = item;
                                    $.$stc.System.Threading.Channels.ChannelUtilities.Enqueue($.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T), $.$ref(() => parent._blockedWritersHead, ($v) => parent._blockedWritersHead = $v, $.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T)), writer);
                                    waitingReaders = $.$stc.System.Threading.Channels.ChannelUtilities.TryReserveCompletionIfCancelable($.$stc.System.Threading.Channels.WaitingReadAsyncOperation, $.$ref(() => parent._waitingReadersHead, ($v) => parent._waitingReadersHead = $v, $.$stc.System.Threading.Channels.WaitingReadAsyncOperation));
                                }
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(parent.SyncObj)
                        }
                        if (!(writer === null))
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(blockedReader === null, "blockedReader is null");
                            $.$stc.System.Threading.Channels.ChannelUtilities.DangerousSetOperations($.$stc.System.Threading.Channels.WaitingReadAsyncOperation, $.$$.System.Boolean, waitingReaders, true);
                            return writer.ValueTask;
                        }
                        if (!(blockedReader === null))
                        {
                            blockedReader.DangerousSetResult(item);
                        }
                        else 
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(parent._dropWrites, "parent._dropWrites");
                            parent._itemDropped?.Invoke(item);
                        }
                        return new $.$$.System.Threading.Tasks.ValueTask();
                    }
                    //--TRIMMABLE-BOUNDARY-END(47246934037)
                    
                    //--TRIMMABLE-BOUNDARY-START(21477130261)
                    /*string */ get DebuggerDisplay()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(30067064853);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*long*/ let blockedWriterCount, waitingWriterCount;
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(this._parent.SyncObj)
                            {
                                blockedWriterCount = $.$stc.System.Threading.Channels.ChannelUtilities.CountOperations($.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T), this._parent._blockedWritersHead);
                                waitingWriterCount = $.$stc.System.Threading.Channels.ChannelUtilities.CountOperations($.$stc.System.Threading.Channels.WaitingWriteAsyncOperation, this._parent._waitingWritersHead);
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(this._parent.SyncObj)
                        }
                        return `WriteAsync=${blockedWriterCount}, WaitToWriteAsync=${waitingWriterCount}`;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21477130261)
                    
                    static $h = 2293781;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21477130261),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(2293781)|0x700000000n),
        "f": 50331656
      },
      "n": "DebuggerDisplay",
      "d": 2293781,
      "h": Number(BigInt(2293781)|0x500000000n),
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(21477130261)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34362032149),
    {
      "r": 262145,
      "p": [
        {
          "n": "error",
          "p": 80019457
        }
      ],
      "n": "TryComplete",
      "d": 2293781,
      "h": Number(BigInt(2293781)|0x800000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34362032149),
//--TRIMMABLE-BOUNDARY-START(38656999445),
    {
      "r": 262145,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1507328
        }
      ],
      "n": "TryWrite",
      "d": 2293781,
      "h": Number(BigInt(2293781)|0x900000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38656999445),
//--TRIMMABLE-BOUNDARY-START(42951966741),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Boolean).$h,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "WaitToWriteAsync",
      "d": 2293781,
      "h": Number(BigInt(2293781)|0xA00000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(42951966741),
//--TRIMMABLE-BOUNDARY-START(47246934037),
    {
      "r": 180551681,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1507328
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "WriteAsync",
      "d": 2293781,
      "h": Number(BigInt(2293781)|0xB00000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47246934037)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297261077),
    {
      "t": $.$stc.System.Threading.Channels.RendezvousChannel$$(T).$h,
      "n": "_parent",
      "d": 2293781,
      "h": Number(BigInt(2293781)|0x100000000n),
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(4297261077),
//--TRIMMABLE-BOUNDARY-START(12887195669),
    {
      "t": $.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T).$h,
      "n": "_writerSingleton",
      "d": 2293781,
      "h": Number(BigInt(2293781)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12887195669),
//--TRIMMABLE-BOUNDARY-START(8592228373),
    {
      "t": 3145749,
      "n": "_waiterSingleton",
      "d": 2293781,
      "h": Number(BigInt(2293781)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8592228373)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17182162965),
    {
      "p": [
        {
          "n": "parent",
          "p": $.$stc.System.Threading.Channels.RendezvousChannel$$(T).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2293781,
      "h": Number(BigInt(2293781)|0x400000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(17182162965)
  ],
  "d": $.$stc.System.Threading.Channels.RendezvousChannel$$(T).$h,
  "h": 2293781,
  "a": [
    {
      "t": 70385665,
      "c": 25840189441,
      "a": [
        {
          "v": "{DebuggerDisplay,nq}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
                    static get $b() { return $.$stc.System.Threading.Channels.ChannelWriter$$(T); }
                    static get $fullName() { return `System.Threading.Channels.RendezvousChannel<${T?.$fullName}>.RendezvousChannelWriter`; }
                }, $cls, ($v) => $cls.$_RendezvousChannelWriter = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2293781)
            
            //--TRIMMABLE-BOUNDARY-START(98786410517)
            /*object */ get SyncObj()
            {
                return this._completion;
            }
            //--TRIMMABLE-BOUNDARY-END(98786410517)
            
            //--TRIMMABLE-BOUNDARY-START(64426672149)
            /*Action<object?, CancellationToken>*/ CancellationCallbackDelegate$ = null;
            /*Action<object?, CancellationToken> */ get CancellationCallbackDelegate()
            {
                return this.CancellationCallbackDelegate$ ??= new ($.$$.System.Action$$$($.$$.System.Object, $.$$.System.Threading.CancellationToken))().$ctor(this,  (/*state*/ state, /*cancellationToken*/ cancellationToken) =>
                {
                    /*AsyncOperation*/ let op = $.$cast(state, $.$stc.System.Threading.Channels.AsyncOperation);
                    if (op.TrySetCanceled(cancellationToken))
                    {
                        $.$stc.System.Threading.Channels.ChannelUtilities.UnsafeQueueUserWorkItem($.$$.System.Collections.Generic.KeyValuePair$$$($.$stc.System.Threading.Channels.RendezvousChannel$$(T), $.$stc.System.Threading.Channels.AsyncOperation), new ($.$$.System.Action$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$stc.System.Threading.Channels.RendezvousChannel$$(T), $.$stc.System.Threading.Channels.AsyncOperation)))().$ctor($.$stc.System.Threading.Channels.RendezvousChannel$$(T), /*static*/ (/*state*/ state) =>
                        {
                            //lock
                            try
                            {
                                $.$$.System.Threading.Monitor.Enter$1(state.Key.SyncObj)
                                {
                                    //switch (state.Value)
                                    let $switch1 = state.Value;
                                    {
                                        let blockedReader;
                                        let blockedWriter;
                                        let waitingReader;
                                        let waitingWriter;
                                        $switchJumpStart1: 
                                        //case BlockedReadAsyncOperation<T> blockedReader:
                                        if ($.$is($switch1, $.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T), { set $v(v){ blockedReader = v; } }))
                                        {
                                            $.$stc.System.Threading.Channels.ChannelUtilities.Remove($.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T), $.$ref(() => state.Key._blockedReadersHead, ($v) => state.Key._blockedReadersHead = $v, $.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T)), blockedReader);
                                        }
                                        //case BlockedWriteAsyncOperation<T> blockedWriter:
                                        else if ($.$is($switch1, $.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T), { set $v(v){ blockedWriter = v; } }))
                                        {
                                            $.$stc.System.Threading.Channels.ChannelUtilities.Remove($.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T), $.$ref(() => state.Key._blockedWritersHead, ($v) => state.Key._blockedWritersHead = $v, $.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T)), blockedWriter);
                                        }
                                        //case WaitingReadAsyncOperation waitingReader:
                                        else if ($.$is($switch1, $.$stc.System.Threading.Channels.WaitingReadAsyncOperation, { set $v(v){ waitingReader = v; } }))
                                        {
                                            $.$stc.System.Threading.Channels.ChannelUtilities.Remove($.$stc.System.Threading.Channels.WaitingReadAsyncOperation, $.$ref(() => state.Key._waitingReadersHead, ($v) => state.Key._waitingReadersHead = $v, $.$stc.System.Threading.Channels.WaitingReadAsyncOperation), waitingReader);
                                        }
                                        //case WaitingWriteAsyncOperation waitingWriter:
                                        else if ($.$is($switch1, $.$stc.System.Threading.Channels.WaitingWriteAsyncOperation, { set $v(v){ waitingWriter = v; } }))
                                        {
                                            $.$stc.System.Threading.Channels.ChannelUtilities.Remove($.$stc.System.Threading.Channels.WaitingWriteAsyncOperation, $.$ref(() => state.Key._waitingWritersHead, ($v) => state.Key._waitingWritersHead = $v, $.$stc.System.Threading.Channels.WaitingWriteAsyncOperation), waitingWriter);
                                        }
                                        //default
                                        else
                                        {
                                            $.$$.System.Diagnostics.Debug.Fail$1(`Unexpected operation: ${$.$$.System.Object.ToString.call(state.Value)}`);
                                        }
                                    }
                                }
                            }
                            finally
                            {
                                $.$$.System.Threading.Monitor.Exit(state.Key.SyncObj)
                            }
                        }, {
  "r": 65537,
  "p": [
    {
      "n": "state",
      "p": $.$$.System.Collections.Generic.KeyValuePair$$$($.$stc.System.Threading.Channels.RendezvousChannel$$(T), $.$stc.System.Threading.Channels.AsyncOperation).$h
    }
  ],
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825826
}), new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$stc.System.Threading.Channels.RendezvousChannel$$(T), $.$stc.System.Threading.Channels.AsyncOperation))().$ctor$3(this, op));
                    }
                }, {
  "r": 65537,
  "p": [
    {
      "n": "state",
      "p": 131073
    },
    {
      "n": "cancellationToken",
      "p": 170065921
    }
  ],
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825794
});
            }
            //--TRIMMABLE-BOUNDARY-END(64426672149)
            
            //--TRIMMABLE-BOUNDARY-START(68721639445)
            /*string */ get DebuggerDisplay()
            {
                return `${($.$cast(this.Reader, $.$stc.System.Threading.Channels.RendezvousChannel$$(T).RendezvousChannelReader)).DebuggerDisplay}, ${($.$cast(this.Writer, $.$stc.System.Threading.Channels.RendezvousChannel$$(T).RendezvousChannelWriter)).DebuggerDisplay}`;
            }
            //--TRIMMABLE-BOUNDARY-END(68721639445)
            
            //--TRIMMABLE-BOUNDARY-START(60131704853)
            /*void */ AssertInvariants()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131704853);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(!(this.SyncObj === null), "The sync obj must not be null.");
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Threading.Monitor.IsEntered(this.SyncObj), "Invariants can only be validated while holding the lock.");
                if (!(this._blockedReadersHead === null))
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(this._blockedWritersHead === null, "There shouldn't be any blocked writer if there's a blocked reader.");
                    $.$$.System.Diagnostics.Debug.Assert$2(this._waitingWritersHead === null, "There shouldn't be any waiting writers if there's a blocked reader.");
                }
                if (!(this._blockedWritersHead === null))
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(this._blockedReadersHead === null, "There shouldn't be any blocked readers if there's a blocked writer.");
                    $.$$.System.Diagnostics.Debug.Assert$2(this._waitingReadersHead === null, "There shouldn't be any waiting readers if there's a blocked writer.");
                }
                if (this._completion.Task.IsCompleted)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(!(this._doneWriting === null), "We can only complete if we're done writing.");
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60131704853)
            
            static $h = 2162709;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(98786410517),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1600000000n),
        "f": 50331650
      },
      "n": "SyncObj",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1700000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(98786410517),
//--TRIMMABLE-BOUNDARY-START(64426672149),
    {
      "p": $.$$.System.Action$$$($.$$.System.Object, $.$$.System.Threading.CancellationToken).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1200000000n),
        "f": 50331650
      },
      "n": "CancellationCallbackDelegate",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xF00000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(64426672149),
//--TRIMMABLE-BOUNDARY-START(68721639445),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1400000000n),
        "f": 50331650
      },
      "n": "DebuggerDisplay",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1000000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(68721639445)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(60131704853),
    {
      "r": 65537,
      "n": "AssertInvariants",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 16777218,
      "a": [
        {
          "t": 68747265,
          "c": 8658681857,
          "a": [
            {
              "v": "DEBUG",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(60131704853)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(21476999189),
    {
      "t": 262145,
      "n": "_dropWrites",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21476999189),
//--TRIMMABLE-BOUNDARY-START(25771966485),
    {
      "t": $.$$.System.Action$$(T).$h,
      "n": "_itemDropped",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25771966485),
//--TRIMMABLE-BOUNDARY-START(12887064597),
    {
      "t": 178782209,
      "n": "_completion",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12887064597),
//--TRIMMABLE-BOUNDARY-START(4297130005),
    {
      "t": $.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T).$h,
      "n": "_blockedReadersHead",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297130005),
//--TRIMMABLE-BOUNDARY-START(8592097301),
    {
      "t": $.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T).$h,
      "n": "_blockedWritersHead",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8592097301),
//--TRIMMABLE-BOUNDARY-START(34361901077),
    {
      "t": 3080213,
      "n": "_waitingReadersHead",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34361901077),
//--TRIMMABLE-BOUNDARY-START(38656868373),
    {
      "t": 3145749,
      "n": "_waitingWritersHead",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38656868373),
//--TRIMMABLE-BOUNDARY-START(30066933781),
    {
      "t": 262145,
      "n": "_runContinuationsAsynchronously",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30066933781),
//--TRIMMABLE-BOUNDARY-START(17182031893),
    {
      "t": 80019457,
      "n": "_doneWriting",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17182031893)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(55836737557),
    {
      "p": [
        {
          "n": "mode",
          "p": 1376277
        },
        {
          "n": "runContinuationsAsynchronously",
          "p": 262145
        },
        {
          "n": "itemDropped",
          "p": $.$$.System.Action$$(T).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(55836737557)
  ],
  "g": [T?.$h??1507328
  ],
  "j": [2228245,2293781
  ],
  "r": 1,
  "h": this.$h,
  "a": [
    {
      "t": 70385665,
      "c": 25840189441,
      "a": [
        {
          "v": "{DebuggerDisplay,nq}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$stc.System.Threading.Channels.Channel$$(T); }
            static get $fullName() { return `System.Threading.Channels.RendezvousChannel<${T?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2162709)
        
        
        //--TRIMMABLE-BOUNDARY-START(2818069)
        $asm.$cls("$stc.System.Threading.Channels.UnboundedPrioritizedChannel<>", (T) => $asm.$gt("$stc.System.Threading.Channels.UnboundedPrioritizedChannel<>", [T], ($self) => class UnboundedPrioritizedChannel$$ extends $.$stc.System.Threading.Channels.Channel$$(T)
        {
            //--TRIMMABLE-BOUNDARY-START(8592752661)
            /*TaskCompletionSource*/ _completion = null;
            //--TRIMMABLE-BOUNDARY-END(8592752661)
            
            //--TRIMMABLE-BOUNDARY-START(17182687253)
            /*PriorityQueue<bool, T>*/ _items = null;
            //--TRIMMABLE-BOUNDARY-END(17182687253)
            
            //--TRIMMABLE-BOUNDARY-START(21477654549)
            /*bool*/ _runContinuationsAsynchronously = false;
            //--TRIMMABLE-BOUNDARY-END(21477654549)
            
            //--TRIMMABLE-BOUNDARY-START(4297785365)
            /*BlockedReadAsyncOperation<T>?*/ _blockedReadersHead = null;
            //--TRIMMABLE-BOUNDARY-END(4297785365)
            
            //--TRIMMABLE-BOUNDARY-START(25772621845)
            /*WaitingReadAsyncOperation?*/ _waitingReadersHead = null;
            //--TRIMMABLE-BOUNDARY-END(25772621845)
            
            //--TRIMMABLE-BOUNDARY-START(12887719957)
            /*Exception?*/ _doneWriting = null;
            //--TRIMMABLE-BOUNDARY-END(12887719957)
            
            //--TRIMMABLE-BOUNDARY-START(42952491029)
            $ctor$3(/*bool*/ runContinuationsAsynchronously, /*IComparer<T>?*/ comparer)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42952491029);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._runContinuationsAsynchronously = runContinuationsAsynchronously;
                    this._completion = new $.$$.System.Threading.Tasks.TaskCompletionSource().$ctor$4(runContinuationsAsynchronously ? 64/*TaskCreationOptions.RunContinuationsAsynchronously*/ : 0/*TaskCreationOptions.None*/);
                    this._items = new ($.$sc.System.Collections.Generic.PriorityQueue$$$($.$$.System.Boolean, T))().$ctor$2(comparer);
                    this.Reader = new ($.$stc.System.Threading.Channels.UnboundedPrioritizedChannel$$(T).UnboundedPrioritizedChannelReader)().$ctor$2(this);
                    this.Writer = new ($.$stc.System.Threading.Channels.UnboundedPrioritizedChannel$$(T).UnboundedPrioritizedChannelWriter)().$ctor$2(this);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42952491029)
            
            //--TRIMMABLE-BOUNDARY-START(2883605)
            static $_UnboundedPrioritizedChannelReader;
            static get UnboundedPrioritizedChannelReader()
            {
                let $cls = $.$stc.System.Threading.Channels.UnboundedPrioritizedChannel$$(T);
                return $cls.$_UnboundedPrioritizedChannelReader ??= $asm.$ncls("$stc.System.Threading.Channels.UnboundedPrioritizedChannel$$.UnboundedPrioritizedChannelReader", ($self) => class UnboundedPrioritizedChannelReader extends $.$stc.System.Threading.Channels.ChannelReader$$(T)
                {
                    //--TRIMMABLE-BOUNDARY-START(4297850901)
                    /*UnboundedPrioritizedChannel<T>*/ _parent = null;
                    //--TRIMMABLE-BOUNDARY-END(4297850901)
                    
                    //--TRIMMABLE-BOUNDARY-START(8592818197)
                    /*BlockedReadAsyncOperation<T>*/ _readerSingleton = null;
                    //--TRIMMABLE-BOUNDARY-END(8592818197)
                    
                    //--TRIMMABLE-BOUNDARY-START(12887785493)
                    /*WaitingReadAsyncOperation*/ _waiterSingleton = null;
                    //--TRIMMABLE-BOUNDARY-END(12887785493)
                    
                    //--TRIMMABLE-BOUNDARY-START(17182752789)
                    $ctor$2(/*UnboundedPrioritizedChannel<T>*/ parent)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(17182752789);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._parent = parent;
                            this._readerSingleton = new ($.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T))().$ctor$4(parent._runContinuationsAsynchronously, new $.$$.System.Threading.CancellationToken(), true, null);
                            this._waiterSingleton = new $.$stc.System.Threading.Channels.WaitingReadAsyncOperation().$ctor$4(parent._runContinuationsAsynchronously, new $.$$.System.Threading.CancellationToken(), true, null);
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17182752789)
                    
                    //--TRIMMABLE-BOUNDARY-START(34362621973)
                    /*Task */ get Completion()
                    {
                        return this._parent._completion.Task;
                    }
                    //--TRIMMABLE-BOUNDARY-END(34362621973)
                    
                    //--TRIMMABLE-BOUNDARY-START(21477720085)
                    /*bool */ get CanCount()
                    {
                        return true;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21477720085)
                    
                    //--TRIMMABLE-BOUNDARY-START(25772687381)
                    /*bool */ get CanPeek()
                    {
                        return true;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25772687381)
                    
                    //--TRIMMABLE-BOUNDARY-START(38657589269)
                    /*int */ get Count()
                    {
                        return this._parent._items.Count;
                    }
                    //--TRIMMABLE-BOUNDARY-END(38657589269)
                    
                    //--TRIMMABLE-BOUNDARY-START(77312294933)
                    /*ValueTask<T> */ ReadAsync(/*CancellationToken*/ cancellationToken)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(77312294933);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (cancellationToken.IsCancellationRequested)
                        {
                            return $.$$.System.Threading.Tasks.ValueTask.FromCanceled$1(T, cancellationToken);
                        }
                        /*UnboundedPrioritizedChannel<T>*/ let parent = this._parent;
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(parent.SyncObj)
                            {
                                parent.AssertInvariants();
                                /*T?*/ let item;
                                if (parent._items.TryDequeue($.$discardRef(), $.$ref(() => item, ($v) => item = $v, T)))
                                {
                                    $.$stc.System.Threading.Channels.UnboundedPrioritizedChannel$$(T).UnboundedPrioritizedChannelReader.CompleteIfDone(parent);
                                    return new ($.$$.System.Threading.Tasks.ValueTask$$(T))().$ctor$6(item);
                                }
                                if (!(parent._doneWriting === null))
                                {
                                    return $.$stc.System.Threading.Channels.ChannelUtilities.GetInvalidCompletionValueTask(T, parent._doneWriting);
                                }
                                /*BlockedReadAsyncOperation<T>*/ let reader = !cancellationToken.CanBeCanceled && this._readerSingleton.TryOwnAndReset() ? this._readerSingleton : new ($.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T))().$ctor$4(parent._runContinuationsAsynchronously, new $.$$.System.Threading.CancellationToken(), false, this._parent.CancellationCallbackDelegate);
                                $.$stc.System.Threading.Channels.ChannelUtilities.Enqueue($.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T), $.$ref(() => parent._blockedReadersHead, ($v) => parent._blockedReadersHead = $v, $.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T)), reader);
                                return reader.ValueTaskOfT;
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(parent.SyncObj)
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(77312294933)
                    
                    //--TRIMMABLE-BOUNDARY-START(90197196821)
                    /*bool */ TryRead(/*out T*/ item)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(90197196821);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*UnboundedPrioritizedChannel<T>*/ let parent = this._parent;
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(parent.SyncObj)
                            {
                                if (parent._items.TryDequeue($.$discardRef(), item))
                                {
                                    $.$stc.System.Threading.Channels.UnboundedPrioritizedChannel$$(T).UnboundedPrioritizedChannelReader.CompleteIfDone(parent);
                                    return true;
                                }
                                item.$v = $.$default(T);
                                return false;
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(parent.SyncObj)
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(90197196821)
                    
                    //--TRIMMABLE-BOUNDARY-START(85902229525)
                    /*bool */ TryPeek(/*out T*/ item)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(85902229525);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*UnboundedPrioritizedChannel<T>*/ let parent = this._parent;
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(parent.SyncObj)
                            {
                                return parent._items.TryPeek($.$discardRef(), item);
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(parent.SyncObj)
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(85902229525)
                    
                    //--TRIMMABLE-BOUNDARY-START(30067654677)
                    static /*void */ CompleteIfDone(/*UnboundedPrioritizedChannel<T>*/ parent)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(30067654677);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Threading.Monitor.IsEntered(parent.SyncObj), "Monitor.IsEntered(parent.SyncObj)");
                        if (!(parent._doneWriting === null) && parent._items.Count === 0)
                        {
                            $.$stc.System.Threading.Channels.ChannelUtilities.Complete(parent._completion, parent._doneWriting);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(30067654677)
                    
                    //--TRIMMABLE-BOUNDARY-START(94492164117)
                    /*ValueTask<bool> */ WaitToReadAsync(/*CancellationToken*/ cancellationToken)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(94492164117);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (cancellationToken.IsCancellationRequested)
                        {
                            return $.$$.System.Threading.Tasks.ValueTask.FromCanceled$1($.$$.System.Boolean, cancellationToken);
                        }
                        /*UnboundedPrioritizedChannel<T>*/ let parent = this._parent;
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(parent.SyncObj)
                            {
                                parent.AssertInvariants();
                                if (parent._items.Count !== 0)
                                {
                                    return new ($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Boolean))().$ctor$6(true);
                                }
                                if (!(parent._doneWriting === null))
                                {
                                    return parent._doneWriting !== $.$stc.System.Threading.Channels.ChannelUtilities.s_doneWritingSentinel ? $.$$.System.Threading.Tasks.ValueTask.FromException$1($.$$.System.Boolean, parent._doneWriting) : new ($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Boolean))();
                                }
                                /*WaitingReadAsyncOperation*/ let waiter = !cancellationToken.CanBeCanceled && this._waiterSingleton.TryOwnAndReset() ? this._waiterSingleton : new $.$stc.System.Threading.Channels.WaitingReadAsyncOperation().$ctor$4(parent._runContinuationsAsynchronously, new $.$$.System.Threading.CancellationToken(), false, this._parent.CancellationCallbackDelegate);
                                $.$stc.System.Threading.Channels.ChannelUtilities.Enqueue($.$stc.System.Threading.Channels.WaitingReadAsyncOperation, $.$ref(() => parent._waitingReadersHead, ($v) => parent._waitingReadersHead = $v, $.$stc.System.Threading.Channels.WaitingReadAsyncOperation), waiter);
                                return waiter.ValueTaskOfT;
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(parent.SyncObj)
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(94492164117)
                    
                    //--TRIMMABLE-BOUNDARY-START(81607262229)
                    /*IEnumerator<T> */ System$Threading$Channels$IDebugEnumerable$$$GetEnumerator()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(81607262229);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._parent.GetEnumerator();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(81607262229)
                    
                    static $h = 2883605;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34362621973),
    {
      "p": 177668097,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(2883605)|0xF00000000n),
        "f": 50364417
      },
      "n": "Completion",
      "d": 2883605,
      "h": Number(BigInt(2883605)|0x800000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34362621973),
//--TRIMMABLE-BOUNDARY-START(21477720085),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(2883605)|0xB00000000n),
        "f": 50364417
      },
      "n": "CanCount",
      "d": 2883605,
      "h": Number(BigInt(2883605)|0x500000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21477720085),
//--TRIMMABLE-BOUNDARY-START(25772687381),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(2883605)|0xD00000000n),
        "f": 50364417
      },
      "n": "CanPeek",
      "d": 2883605,
      "h": Number(BigInt(2883605)|0x600000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(25772687381),
//--TRIMMABLE-BOUNDARY-START(38657589269),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(2883605)|0x1100000000n),
        "f": 50364417
      },
      "n": "Count",
      "d": 2883605,
      "h": Number(BigInt(2883605)|0x900000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(38657589269)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(77312294933),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$(T).$h,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "ReadAsync",
      "d": 2883605,
      "h": Number(BigInt(2883605)|0x1200000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(77312294933),
//--TRIMMABLE-BOUNDARY-START(90197196821),
    {
      "r": 262145,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1507328,
          "f": 2
        }
      ],
      "n": "TryRead",
      "d": 2883605,
      "h": Number(BigInt(2883605)|0x1500000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(90197196821),
//--TRIMMABLE-BOUNDARY-START(85902229525),
    {
      "r": 262145,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1507328,
          "f": 2
        }
      ],
      "n": "TryPeek",
      "d": 2883605,
      "h": Number(BigInt(2883605)|0x1400000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(85902229525),
//--TRIMMABLE-BOUNDARY-START(30067654677),
    {
      "r": 65537,
      "p": [
        {
          "n": "parent",
          "p": $.$stc.System.Threading.Channels.UnboundedPrioritizedChannel$$(T).$h
        }
      ],
      "n": "CompleteIfDone",
      "d": 2883605,
      "h": Number(BigInt(2883605)|0x700000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(30067654677),
//--TRIMMABLE-BOUNDARY-START(94492164117),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Boolean).$h,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "WaitToReadAsync",
      "d": 2883605,
      "h": Number(BigInt(2883605)|0x1600000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(94492164117)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297850901),
    {
      "t": $.$stc.System.Threading.Channels.UnboundedPrioritizedChannel$$(T).$h,
      "n": "_parent",
      "d": 2883605,
      "h": Number(BigInt(2883605)|0x100000000n),
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(4297850901),
//--TRIMMABLE-BOUNDARY-START(8592818197),
    {
      "t": $.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T).$h,
      "n": "_readerSingleton",
      "d": 2883605,
      "h": Number(BigInt(2883605)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8592818197),
//--TRIMMABLE-BOUNDARY-START(12887785493),
    {
      "t": 3080213,
      "n": "_waiterSingleton",
      "d": 2883605,
      "h": Number(BigInt(2883605)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12887785493)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17182752789),
    {
      "p": [
        {
          "n": "parent",
          "p": $.$stc.System.Threading.Channels.UnboundedPrioritizedChannel$$(T).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2883605,
      "h": Number(BigInt(2883605)|0x400000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(17182752789)
  ],
  "i": [$.$stc.System.Threading.Channels.IDebugEnumerable$$(T).$h
  ],
  "d": $.$stc.System.Threading.Channels.UnboundedPrioritizedChannel$$(T).$h,
  "h": 2883605,
  "a": [
    {
      "t": 70385665,
      "c": 25840189441,
      "a": [
        {
          "v": "Items = {Count}",
          "t": 1310721
        }
      ]
    },
    {
      "t": 70713345,
      "c": 21545549825,
      "a": [
        {
          "v": $.$stc.System.Threading.Channels.DebugEnumeratorDebugView$$().$h,
          "t": 187760641
        }
      ]
    }
  ]
}; }
                    static get $b() { return $.$stc.System.Threading.Channels.ChannelReader$$(T); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$stc.System.Threading.Channels.IDebugEnumerable$$(T) ]; }
                    static get $fullName() { return `System.Threading.Channels.UnboundedPrioritizedChannel<${T?.$fullName}>.UnboundedPrioritizedChannelReader`; }
                }, $cls, ($v) => $cls.$_UnboundedPrioritizedChannelReader = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2883605)
            
            //--TRIMMABLE-BOUNDARY-START(2949141)
            static $_UnboundedPrioritizedChannelWriter;
            static get UnboundedPrioritizedChannelWriter()
            {
                let $cls = $.$stc.System.Threading.Channels.UnboundedPrioritizedChannel$$(T);
                return $cls.$_UnboundedPrioritizedChannelWriter ??= $asm.$ncls("$stc.System.Threading.Channels.UnboundedPrioritizedChannel$$.UnboundedPrioritizedChannelWriter", ($self) => class UnboundedPrioritizedChannelWriter extends $.$stc.System.Threading.Channels.ChannelWriter$$(T)
                {
                    //--TRIMMABLE-BOUNDARY-START(4297916437)
                    /*UnboundedPrioritizedChannel<T>*/ _parent = null;
                    //--TRIMMABLE-BOUNDARY-END(4297916437)
                    
                    //--TRIMMABLE-BOUNDARY-START(8592883733)
                    $ctor$2(/*UnboundedPrioritizedChannel<T>*/ parent)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8592883733);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._parent = parent;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8592883733)
                    
                    //--TRIMMABLE-BOUNDARY-START(30067720213)
                    /*bool */ TryComplete(/*Exception?*/ error)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(30067720213);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*UnboundedPrioritizedChannel<T>*/ let parent = this._parent;
                        /*BlockedReadAsyncOperation<T>?*/ let blockedReadersHead;
                        /*WaitingReadAsyncOperation?*/ let waitingReadersHead;
                        /*bool*/ let completeTask;
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(parent.SyncObj)
                            {
                                parent.AssertInvariants();
                                if (!(parent._doneWriting === null))
                                {
                                    return false;
                                }
                                parent._doneWriting = error ?? $.$stc.System.Threading.Channels.ChannelUtilities.s_doneWritingSentinel;
                                completeTask = parent._items.Count === 0;
                                blockedReadersHead = parent._blockedReadersHead;
                                waitingReadersHead = parent._waitingReadersHead;
                                parent._blockedReadersHead = null;
                                parent._waitingReadersHead = null;
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(parent.SyncObj)
                        }
                        if (completeTask)
                        {
                            $.$stc.System.Threading.Channels.ChannelUtilities.Complete(parent._completion, error);
                        }
                        $.$stc.System.Threading.Channels.ChannelUtilities.FailOperations($.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T), blockedReadersHead, $.$stc.System.Threading.Channels.ChannelUtilities.CreateInvalidCompletionException(error));
                        $.$stc.System.Threading.Channels.ChannelUtilities.SetOrFailOperations($.$stc.System.Threading.Channels.WaitingReadAsyncOperation, $.$$.System.Boolean, waitingReadersHead, false, error);
                        return true;
                    }
                    //--TRIMMABLE-BOUNDARY-END(30067720213)
                    
                    //--TRIMMABLE-BOUNDARY-START(34362687509)
                    /*bool */ TryWrite(/*T*/ item)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34362687509);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*UnboundedPrioritizedChannel<T>*/ let parent = this._parent;
                        /*BlockedReadAsyncOperation<T>?*/ let blockedReader = null;
                        /*WaitingReadAsyncOperation?*/ let waitingReadersHead = null;
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(parent.SyncObj)
                            {
                                parent.AssertInvariants();
                                if (!(parent._doneWriting === null))
                                {
                                    return false;
                                }
                                blockedReader = $.$stc.System.Threading.Channels.ChannelUtilities.TryDequeueAndReserveCompletionIfCancelable($.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T), $.$ref(() => parent._blockedReadersHead, ($v) => parent._blockedReadersHead = $v, $.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T)));
                                if (blockedReader === null)
                                {
                                    parent._items.Enqueue(true, item);
                                    waitingReadersHead = $.$stc.System.Threading.Channels.ChannelUtilities.TryReserveCompletionIfCancelable($.$stc.System.Threading.Channels.WaitingReadAsyncOperation, $.$ref(() => parent._waitingReadersHead, ($v) => parent._waitingReadersHead = $v, $.$stc.System.Threading.Channels.WaitingReadAsyncOperation));
                                }
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(parent.SyncObj)
                        }
                        if (!(blockedReader === null))
                        {
                            blockedReader.DangerousSetResult(item);
                        }
                        else if (!(waitingReadersHead === null))
                        {
                            $.$stc.System.Threading.Channels.ChannelUtilities.DangerousSetOperations($.$stc.System.Threading.Channels.WaitingReadAsyncOperation, $.$$.System.Boolean, waitingReadersHead, true);
                        }
                        return true;
                    }
                    //--TRIMMABLE-BOUNDARY-END(34362687509)
                    
                    //--TRIMMABLE-BOUNDARY-START(38657654805)
                    /*ValueTask<bool> */ WaitToWriteAsync(/*CancellationToken*/ cancellationToken)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(38657654805);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*Exception?*/ let doneWriting = this._parent._doneWriting;
                        return cancellationToken.IsCancellationRequested ? $.$$.System.Threading.Tasks.ValueTask.FromCanceled$1($.$$.System.Boolean, cancellationToken) : doneWriting === null ? new ($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Boolean))().$ctor$6(true) : doneWriting !== $.$stc.System.Threading.Channels.ChannelUtilities.s_doneWritingSentinel ? $.$$.System.Threading.Tasks.ValueTask.FromException$1($.$$.System.Boolean, doneWriting) : new ($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Boolean))();
                    }
                    //--TRIMMABLE-BOUNDARY-END(38657654805)
                    
                    //--TRIMMABLE-BOUNDARY-START(42952622101)
                    /*ValueTask */ WriteAsync(/*T*/ item, /*CancellationToken*/ cancellationToken)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(42952622101);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return cancellationToken.IsCancellationRequested ? $.$$.System.Threading.Tasks.ValueTask.FromCanceled(cancellationToken) : this.TryWrite(item) ? new $.$$.System.Threading.Tasks.ValueTask() : $.$$.System.Threading.Tasks.ValueTask.FromException($.$stc.System.Threading.Channels.ChannelUtilities.CreateInvalidCompletionException(this._parent._doneWriting));
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(42952622101)
                    
                    //--TRIMMABLE-BOUNDARY-START(21477785621)
                    /*int */ get ItemsCountForDebugger()
                    {
                        return this._parent._items.Count;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21477785621)
                    
                    //--TRIMMABLE-BOUNDARY-START(25772752917)
                    /*IEnumerator<T> */ System$Threading$Channels$IDebugEnumerable$$$GetEnumerator()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(25772752917);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._parent.GetEnumerator();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(25772752917)
                    
                    static $h = 2949141;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21477785621),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(2949141)|0x400000000n),
        "f": 50331650
      },
      "n": "ItemsCountForDebugger",
      "d": 2949141,
      "h": Number(BigInt(2949141)|0x500000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(21477785621)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30067720213),
    {
      "r": 262145,
      "p": [
        {
          "n": "error",
          "p": 80019457
        }
      ],
      "n": "TryComplete",
      "d": 2949141,
      "h": Number(BigInt(2949141)|0x700000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30067720213),
//--TRIMMABLE-BOUNDARY-START(34362687509),
    {
      "r": 262145,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1507328
        }
      ],
      "n": "TryWrite",
      "d": 2949141,
      "h": Number(BigInt(2949141)|0x800000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34362687509),
//--TRIMMABLE-BOUNDARY-START(38657654805),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Boolean).$h,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "WaitToWriteAsync",
      "d": 2949141,
      "h": Number(BigInt(2949141)|0x900000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38657654805),
//--TRIMMABLE-BOUNDARY-START(42952622101),
    {
      "r": 180551681,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1507328
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "WriteAsync",
      "d": 2949141,
      "h": Number(BigInt(2949141)|0xA00000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(42952622101)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297916437),
    {
      "t": $.$stc.System.Threading.Channels.UnboundedPrioritizedChannel$$(T).$h,
      "n": "_parent",
      "d": 2949141,
      "h": Number(BigInt(2949141)|0x100000000n),
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(4297916437)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592883733),
    {
      "p": [
        {
          "n": "parent",
          "p": $.$stc.System.Threading.Channels.UnboundedPrioritizedChannel$$(T).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2949141,
      "h": Number(BigInt(2949141)|0x200000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(8592883733)
  ],
  "i": [$.$stc.System.Threading.Channels.IDebugEnumerable$$(T).$h
  ],
  "d": $.$stc.System.Threading.Channels.UnboundedPrioritizedChannel$$(T).$h,
  "h": 2949141,
  "a": [
    {
      "t": 70385665,
      "c": 25840189441,
      "a": [
        {
          "v": "Items = {ItemsCountForDebugger}",
          "t": 1310721
        }
      ]
    },
    {
      "t": 70713345,
      "c": 21545549825,
      "a": [
        {
          "v": $.$stc.System.Threading.Channels.DebugEnumeratorDebugView$$().$h,
          "t": 187760641
        }
      ]
    }
  ]
}; }
                    static get $b() { return $.$stc.System.Threading.Channels.ChannelWriter$$(T); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$stc.System.Threading.Channels.IDebugEnumerable$$(T) ]; }
                    static get $fullName() { return `System.Threading.Channels.UnboundedPrioritizedChannel<${T?.$fullName}>.UnboundedPrioritizedChannelWriter`; }
                }, $cls, ($v) => $cls.$_UnboundedPrioritizedChannelWriter = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2949141)
            
            //--TRIMMABLE-BOUNDARY-START(103082033173)
            /*object */ get SyncObj()
            {
                return this._items;
            }
            //--TRIMMABLE-BOUNDARY-END(103082033173)
            
            //--TRIMMABLE-BOUNDARY-START(51542425621)
            /*Action<object?, CancellationToken>*/ CancellationCallbackDelegate$ = null;
            /*Action<object?, CancellationToken> */ get CancellationCallbackDelegate()
            {
                return this.CancellationCallbackDelegate$ ??= new ($.$$.System.Action$$$($.$$.System.Object, $.$$.System.Threading.CancellationToken))().$ctor(this,  (/*state*/ state, /*cancellationToken*/ cancellationToken) =>
                {
                    /*AsyncOperation*/ let op = $.$cast(state, $.$stc.System.Threading.Channels.AsyncOperation);
                    if (op.TrySetCanceled(cancellationToken))
                    {
                        $.$stc.System.Threading.Channels.ChannelUtilities.UnsafeQueueUserWorkItem($.$$.System.Collections.Generic.KeyValuePair$$$($.$stc.System.Threading.Channels.UnboundedPrioritizedChannel$$(T), $.$stc.System.Threading.Channels.AsyncOperation), new ($.$$.System.Action$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$stc.System.Threading.Channels.UnboundedPrioritizedChannel$$(T), $.$stc.System.Threading.Channels.AsyncOperation)))().$ctor($.$stc.System.Threading.Channels.UnboundedPrioritizedChannel$$(T), /*static*/ (/*state*/ state) =>
                        {
                            //lock
                            try
                            {
                                $.$$.System.Threading.Monitor.Enter$1(state.Key.SyncObj)
                                {
                                    //switch (state.Value)
                                    let $switch1 = state.Value;
                                    {
                                        let blockedReader;
                                        let waitingReader;
                                        $switchJumpStart1: 
                                        //case BlockedReadAsyncOperation<T> blockedReader:
                                        if ($.$is($switch1, $.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T), { set $v(v){ blockedReader = v; } }))
                                        {
                                            $.$stc.System.Threading.Channels.ChannelUtilities.Remove($.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T), $.$ref(() => state.Key._blockedReadersHead, ($v) => state.Key._blockedReadersHead = $v, $.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T)), blockedReader);
                                        }
                                        //case WaitingReadAsyncOperation waitingReader:
                                        else if ($.$is($switch1, $.$stc.System.Threading.Channels.WaitingReadAsyncOperation, { set $v(v){ waitingReader = v; } }))
                                        {
                                            $.$stc.System.Threading.Channels.ChannelUtilities.Remove($.$stc.System.Threading.Channels.WaitingReadAsyncOperation, $.$ref(() => state.Key._waitingReadersHead, ($v) => state.Key._waitingReadersHead = $v, $.$stc.System.Threading.Channels.WaitingReadAsyncOperation), waitingReader);
                                        }
                                        //default
                                        else
                                        {
                                            $.$$.System.Diagnostics.Debug.Fail$1(`Unexpected operation: ${$.$$.System.Object.ToString.call(state.Value)}`);
                                        }
                                    }
                                }
                            }
                            finally
                            {
                                $.$$.System.Threading.Monitor.Exit(state.Key.SyncObj)
                            }
                        }, {
  "r": 65537,
  "p": [
    {
      "n": "state",
      "p": $.$$.System.Collections.Generic.KeyValuePair$$$($.$stc.System.Threading.Channels.UnboundedPrioritizedChannel$$(T), $.$stc.System.Threading.Channels.AsyncOperation).$h
    }
  ],
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825826
}), new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$stc.System.Threading.Channels.UnboundedPrioritizedChannel$$(T), $.$stc.System.Threading.Channels.AsyncOperation))().$ctor$3(this, op));
                    }
                }, {
  "r": 65537,
  "p": [
    {
      "n": "state",
      "p": 131073
    },
    {
      "n": "cancellationToken",
      "p": 170065921
    }
  ],
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825794
});
            }
            //--TRIMMABLE-BOUNDARY-END(51542425621)
            
            //--TRIMMABLE-BOUNDARY-START(47247458325)
            /*void */ AssertInvariants()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47247458325);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(!(this.SyncObj === null), "The sync obj must not be null.");
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Threading.Monitor.IsEntered(this.SyncObj), "Invariants can only be validated while holding the lock.");
                if (this._items.Count !== 0)
                {
                    if (this._runContinuationsAsynchronously)
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(this._blockedReadersHead === null, "There's data available, so there shouldn't be any blocked readers.");
                        $.$$.System.Diagnostics.Debug.Assert$2(this._waitingReadersHead === null, "There's data available, so there shouldn't be any waiting readers.");
                    }
                    $.$$.System.Diagnostics.Debug.Assert$2(!this._completion.Task.IsCompleted, "We still have data available, so shouldn't be completed.");
                }
                if ((!(this._blockedReadersHead === null) || !(this._waitingReadersHead === null)) && this._runContinuationsAsynchronously)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(this._items.Count === 0, "There are blocked/waiting readers, so there shouldn't be any data available.");
                }
                if (this._completion.Task.IsCompleted)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(!(this._doneWriting === null), "We're completed, so we must be done writing.");
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47247458325)
            
            //--TRIMMABLE-BOUNDARY-START(98787065877)
            /*int */ get ItemsCountForDebugger()
            {
                return this._items.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(98787065877)
            
            //--TRIMMABLE-BOUNDARY-START(55837392917)
            /*bool */ get ChannelIsClosedForDebugger()
            {
                return !(this._doneWriting === null);
            }
            //--TRIMMABLE-BOUNDARY-END(55837392917)
            
            //--TRIMMABLE-BOUNDARY-START(94492098581)
            /*IEnumerator<T> */ GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94492098581);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*List<T>*/ let list = (() =>
                {
                    let $t1 = new ($.$$.System.Collections.Generic.List$$(T))().$ctor$1();
                    return $t1;
                })();
                var $en2 = this._items.UnorderedItems.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var item = $en2.Current;
                    {
                        list.Add(item.Item2);
                    }
                }
                list.Sort$1(this._items.Comparer);
                return list.GetEnumerator();
            }
            //--TRIMMABLE-BOUNDARY-END(94492098581)
            
            //--TRIMMABLE-BOUNDARY-START(4297064469)
            //Generated interface implemetation for System.Threading.Channels.IDebugEnumerable<T>.GetEnumerator()
            System$Threading$Channels$IDebugEnumerable$$$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297064469);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetEnumerator(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4297064469)
            
            static $h = 2818069;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(103082033173),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1500000000n),
        "f": 50331650
      },
      "n": "SyncObj",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1800000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(103082033173),
//--TRIMMABLE-BOUNDARY-START(51542425621),
    {
      "p": $.$$.System.Action$$$($.$$.System.Object, $.$$.System.Threading.CancellationToken).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xF00000000n),
        "f": 50331650
      },
      "n": "CancellationCallbackDelegate",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(51542425621),
//--TRIMMABLE-BOUNDARY-START(98787065877),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1300000000n),
        "f": 50331650
      },
      "n": "ItemsCountForDebugger",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1700000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(98787065877),
//--TRIMMABLE-BOUNDARY-START(55837392917),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1100000000n),
        "f": 50331650
      },
      "n": "ChannelIsClosedForDebugger",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(55837392917)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(47247458325),
    {
      "r": 65537,
      "n": "AssertInvariants",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 16777218,
      "a": [
        {
          "t": 68747265,
          "c": 8658681857,
          "a": [
            {
              "v": "DEBUG",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47247458325),
//--TRIMMABLE-BOUNDARY-START(94492098581),
    {
      "r": $.$$.System.Collections.Generic.IEnumerator$$(T).$h,
      "n": "GetEnumerator",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(94492098581)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8592752661),
    {
      "t": 178782209,
      "n": "_completion",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8592752661),
//--TRIMMABLE-BOUNDARY-START(17182687253),
    {
      "t": $.$sc.System.Collections.Generic.PriorityQueue$$$($.$$.System.Boolean, T).$h,
      "n": "_items",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17182687253),
//--TRIMMABLE-BOUNDARY-START(21477654549),
    {
      "t": 262145,
      "n": "_runContinuationsAsynchronously",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21477654549),
//--TRIMMABLE-BOUNDARY-START(4297785365),
    {
      "t": $.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T).$h,
      "n": "_blockedReadersHead",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297785365),
//--TRIMMABLE-BOUNDARY-START(25772621845),
    {
      "t": 3080213,
      "n": "_waitingReadersHead",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25772621845),
//--TRIMMABLE-BOUNDARY-START(12887719957),
    {
      "t": 80019457,
      "n": "_doneWriting",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12887719957)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(42952491029),
    {
      "p": [
        {
          "n": "runContinuationsAsynchronously",
          "p": 262145
        },
        {
          "n": "comparer",
          "p": $.$$.System.Collections.Generic.IComparer$$(T).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(42952491029)
  ],
  "i": [$.$stc.System.Threading.Channels.IDebugEnumerable$$(T).$h
  ],
  "g": [T?.$h??1507328
  ],
  "j": [2883605,2949141
  ],
  "r": 1,
  "h": this.$h,
  "a": [
    {
      "t": 70385665,
      "c": 25840189441,
      "a": [
        {
          "v": "Items = {ItemsCountForDebugger}, Closed = {ChannelIsClosedForDebugger}",
          "t": 1310721
        }
      ]
    },
    {
      "t": 70713345,
      "c": 21545549825,
      "a": [
        {
          "v": $.$stc.System.Threading.Channels.DebugEnumeratorDebugView$$().$h,
          "t": 187760641
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$stc.System.Threading.Channels.Channel$$(T); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stc.System.Threading.Channels.IDebugEnumerable$$(T) ]; }
            static get $fullName() { return `System.Threading.Channels.UnboundedPrioritizedChannel<${T?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2818069)
        
        
        //--TRIMMABLE-BOUNDARY-START(2359317)
        $asm.$cls("$stc.System.Threading.Channels.SingleConsumerUnboundedChannel<>", (T) => $asm.$gt("$stc.System.Threading.Channels.SingleConsumerUnboundedChannel<>", [T], ($self) => class SingleConsumerUnboundedChannel$$ extends $.$stc.System.Threading.Channels.Channel$$(T)
        {
            //--TRIMMABLE-BOUNDARY-START(8592293909)
            /*TaskCompletionSource*/ _completion = null;
            //--TRIMMABLE-BOUNDARY-END(8592293909)
            
            //--TRIMMABLE-BOUNDARY-START(17182228501)
            /*SingleProducerSingleConsumerQueue<T>*/ _items = null;
            //--TRIMMABLE-BOUNDARY-END(17182228501)
            
            //--TRIMMABLE-BOUNDARY-START(21477195797)
            /*bool*/ _runContinuationsAsynchronously = false;
            //--TRIMMABLE-BOUNDARY-END(21477195797)
            
            //--TRIMMABLE-BOUNDARY-START(12887261205)
            /*Exception?*/ _doneWriting = null;
            //--TRIMMABLE-BOUNDARY-END(12887261205)
            
            //--TRIMMABLE-BOUNDARY-START(4297326613)
            /*BlockedReadAsyncOperation<T>?*/ _blockedReader = null;
            //--TRIMMABLE-BOUNDARY-END(4297326613)
            
            //--TRIMMABLE-BOUNDARY-START(25772163093)
            /*WaitingReadAsyncOperation?*/ _waitingReader = null;
            //--TRIMMABLE-BOUNDARY-END(25772163093)
            
            //--TRIMMABLE-BOUNDARY-START(42952032277)
            $ctor$3(/*bool*/ runContinuationsAsynchronously)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42952032277);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._runContinuationsAsynchronously = runContinuationsAsynchronously;
                    this._completion = new $.$$.System.Threading.Tasks.TaskCompletionSource().$ctor$4(runContinuationsAsynchronously ? 64/*TaskCreationOptions.RunContinuationsAsynchronously*/ : 0/*TaskCreationOptions.None*/);
                    this.Reader = new ($.$stc.System.Threading.Channels.SingleConsumerUnboundedChannel$$(T).UnboundedChannelReader)().$ctor$2(this);
                    this.Writer = new ($.$stc.System.Threading.Channels.SingleConsumerUnboundedChannel$$(T).UnboundedChannelWriter)().$ctor$2(this);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42952032277)
            
            //--TRIMMABLE-BOUNDARY-START(2424853)
            static $_UnboundedChannelReader;
            static get UnboundedChannelReader()
            {
                let $cls = $.$stc.System.Threading.Channels.SingleConsumerUnboundedChannel$$(T);
                return $cls.$_UnboundedChannelReader ??= $asm.$ncls("$stc.System.Threading.Channels.SingleConsumerUnboundedChannel$$.UnboundedChannelReader", ($self) => class UnboundedChannelReader extends $.$stc.System.Threading.Channels.ChannelReader$$(T)
                {
                    //--TRIMMABLE-BOUNDARY-START(4297392149)
                    /*SingleConsumerUnboundedChannel<T>*/ _parent = null;
                    //--TRIMMABLE-BOUNDARY-END(4297392149)
                    
                    //--TRIMMABLE-BOUNDARY-START(8592359445)
                    /*BlockedReadAsyncOperation<T>*/ _readerSingleton = null;
                    //--TRIMMABLE-BOUNDARY-END(8592359445)
                    
                    //--TRIMMABLE-BOUNDARY-START(12887326741)
                    /*WaitingReadAsyncOperation*/ _waiterSingleton = null;
                    //--TRIMMABLE-BOUNDARY-END(12887326741)
                    
                    //--TRIMMABLE-BOUNDARY-START(17182294037)
                    $ctor$2(/*SingleConsumerUnboundedChannel<T>*/ parent)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(17182294037);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._parent = parent;
                            this._readerSingleton = new ($.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T))().$ctor$4(parent._runContinuationsAsynchronously, new $.$$.System.Threading.CancellationToken(), true, null);
                            this._waiterSingleton = new $.$stc.System.Threading.Channels.WaitingReadAsyncOperation().$ctor$4(parent._runContinuationsAsynchronously, new $.$$.System.Threading.CancellationToken(), true, null);
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17182294037)
                    
                    //--TRIMMABLE-BOUNDARY-START(25772228629)
                    /*Task */ get Completion()
                    {
                        return this._parent._completion.Task;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25772228629)
                    
                    //--TRIMMABLE-BOUNDARY-START(21477261333)
                    /*bool */ get CanPeek()
                    {
                        return true;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21477261333)
                    
                    //--TRIMMABLE-BOUNDARY-START(60131966997)
                    /*ValueTask<T> */ ReadAsync(/*CancellationToken*/ cancellationToken)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(60131966997);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (cancellationToken.IsCancellationRequested)
                        {
                            return new ($.$$.System.Threading.Tasks.ValueTask$$(T))().$ctor$5($.$$.System.Threading.Tasks.Task.FromCanceled$3(T, cancellationToken));
                        }
                        /*T?*/ let item;
                        if (this.TryRead($.$ref(() => item, ($v) => item = $v, T)))
                        {
                            return new ($.$$.System.Threading.Tasks.ValueTask$$(T))().$ctor$6(item);
                        }
                        /*SingleConsumerUnboundedChannel<T>*/ let parent = this._parent;
                        /*BlockedReadAsyncOperation<T>?*/ let oldBlockedReader, newBlockedReader;
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(parent.SyncObj)
                            {
                                if (this.TryRead($.$ref(() => item, ($v) => item = $v, T)))
                                {
                                    return new ($.$$.System.Threading.Tasks.ValueTask$$(T))().$ctor$6(item);
                                }
                                if (!(parent._doneWriting === null))
                                {
                                    return $.$stc.System.Threading.Channels.ChannelUtilities.GetInvalidCompletionValueTask(T, parent._doneWriting);
                                }
                                oldBlockedReader = parent._blockedReader;
                                if (!cancellationToken.CanBeCanceled && this._readerSingleton.TryOwnAndReset())
                                {
                                    newBlockedReader = this._readerSingleton;
                                    if (newBlockedReader === oldBlockedReader)
                                    {
                                        oldBlockedReader = null;
                                    }
                                }
                                else 
                                {
                                    newBlockedReader = new ($.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T))().$ctor$4(this._parent._runContinuationsAsynchronously, new $.$$.System.Threading.CancellationToken(), false, this._parent.CancellationCallbackDelegate);
                                }
                                parent._blockedReader = newBlockedReader;
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(parent.SyncObj)
                        }
                        oldBlockedReader?.TrySetCanceled(new $.$$.System.Threading.CancellationToken());
                        return newBlockedReader.ValueTaskOfT;
                    }
                    //--TRIMMABLE-BOUNDARY-END(60131966997)
                    
                    //--TRIMMABLE-BOUNDARY-START(73016868885)
                    /*bool */ TryRead(/*out T*/ item)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(73016868885);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*SingleConsumerUnboundedChannel<T>*/ let parent = this._parent;
                        if (parent._items.TryDequeue(item))
                        {
                            if (!(parent._doneWriting === null) && parent._items.IsEmpty)
                            {
                                $.$stc.System.Threading.Channels.ChannelUtilities.Complete(parent._completion, parent._doneWriting);
                            }
                            return true;
                        }
                        return false;
                    }
                    //--TRIMMABLE-BOUNDARY-END(73016868885)
                    
                    //--TRIMMABLE-BOUNDARY-START(68721901589)
                    /*bool */ TryPeek(/*out T*/ item)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(68721901589);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._parent._items.TryPeek(item);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(68721901589)
                    
                    //--TRIMMABLE-BOUNDARY-START(77311836181)
                    /*ValueTask<bool> */ WaitToReadAsync(/*CancellationToken*/ cancellationToken)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(77311836181);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (cancellationToken.IsCancellationRequested)
                        {
                            return new ($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Boolean))().$ctor$5($.$$.System.Threading.Tasks.Task.FromCanceled$3($.$$.System.Boolean, cancellationToken));
                        }
                        if (!this._parent._items.IsEmpty)
                        {
                            return new ($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Boolean))().$ctor$6(true);
                        }
                        /*SingleConsumerUnboundedChannel<T>*/ let parent = this._parent;
                        /*WaitingReadAsyncOperation?*/ let oldWaitingReader = null, newWaitingReader;
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(parent.SyncObj)
                            {
                                if (!parent._items.IsEmpty)
                                {
                                    return new ($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Boolean))().$ctor$6(true);
                                }
                                if (!(parent._doneWriting === null))
                                {
                                    return parent._doneWriting !== $.$stc.System.Threading.Channels.ChannelUtilities.s_doneWritingSentinel ? new ($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Boolean))().$ctor$5($.$$.System.Threading.Tasks.Task.FromException$1($.$$.System.Boolean, parent._doneWriting)) : new ($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Boolean))();
                                }
                                oldWaitingReader = parent._waitingReader;
                                if (!cancellationToken.CanBeCanceled && this._waiterSingleton.TryOwnAndReset())
                                {
                                    newWaitingReader = this._waiterSingleton;
                                    if (newWaitingReader === oldWaitingReader)
                                    {
                                        oldWaitingReader = null;
                                    }
                                }
                                else 
                                {
                                    newWaitingReader = new $.$stc.System.Threading.Channels.WaitingReadAsyncOperation().$ctor$4(this._parent._runContinuationsAsynchronously, new $.$$.System.Threading.CancellationToken(), false, this._parent.CancellationCallbackDelegate);
                                }
                                parent._waitingReader = newWaitingReader;
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(parent.SyncObj)
                        }
                        oldWaitingReader?.TrySetCanceled(new $.$$.System.Threading.CancellationToken());
                        return newWaitingReader.ValueTaskOfT;
                    }
                    //--TRIMMABLE-BOUNDARY-END(77311836181)
                    
                    //--TRIMMABLE-BOUNDARY-START(55836999701)
                    /*int */ get ItemsCountForDebugger()
                    {
                        return this._parent._items.Count;
                    }
                    //--TRIMMABLE-BOUNDARY-END(55836999701)
                    
                    //--TRIMMABLE-BOUNDARY-START(64426934293)
                    /*IEnumerator<T> */ System$Threading$Channels$IDebugEnumerable$$$GetEnumerator()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(64426934293);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._parent._items.GetEnumerator();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(64426934293)
                    
                    static $h = 2424853;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25772228629),
    {
      "p": 177668097,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(2424853)|0xA00000000n),
        "f": 50364417
      },
      "n": "Completion",
      "d": 2424853,
      "h": Number(BigInt(2424853)|0x600000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(25772228629),
//--TRIMMABLE-BOUNDARY-START(21477261333),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(2424853)|0x800000000n),
        "f": 50364417
      },
      "n": "CanPeek",
      "d": 2424853,
      "h": Number(BigInt(2424853)|0x500000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21477261333),
//--TRIMMABLE-BOUNDARY-START(55836999701),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(2424853)|0xC00000000n),
        "f": 50331650
      },
      "n": "ItemsCountForDebugger",
      "d": 2424853,
      "h": Number(BigInt(2424853)|0xD00000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(55836999701)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(60131966997),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$(T).$h,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "ReadAsync",
      "d": 2424853,
      "h": Number(BigInt(2424853)|0xE00000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(60131966997),
//--TRIMMABLE-BOUNDARY-START(73016868885),
    {
      "r": 262145,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1507328,
          "f": 2
        }
      ],
      "n": "TryRead",
      "d": 2424853,
      "h": Number(BigInt(2424853)|0x1100000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(73016868885),
//--TRIMMABLE-BOUNDARY-START(68721901589),
    {
      "r": 262145,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1507328,
          "f": 2
        }
      ],
      "n": "TryPeek",
      "d": 2424853,
      "h": Number(BigInt(2424853)|0x1000000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(68721901589),
//--TRIMMABLE-BOUNDARY-START(77311836181),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Boolean).$h,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "WaitToReadAsync",
      "d": 2424853,
      "h": Number(BigInt(2424853)|0x1200000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(77311836181)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297392149),
    {
      "t": $.$stc.System.Threading.Channels.SingleConsumerUnboundedChannel$$(T).$h,
      "n": "_parent",
      "d": 2424853,
      "h": Number(BigInt(2424853)|0x100000000n),
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(4297392149),
//--TRIMMABLE-BOUNDARY-START(8592359445),
    {
      "t": $.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T).$h,
      "n": "_readerSingleton",
      "d": 2424853,
      "h": Number(BigInt(2424853)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8592359445),
//--TRIMMABLE-BOUNDARY-START(12887326741),
    {
      "t": 3080213,
      "n": "_waiterSingleton",
      "d": 2424853,
      "h": Number(BigInt(2424853)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12887326741)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17182294037),
    {
      "p": [
        {
          "n": "parent",
          "p": $.$stc.System.Threading.Channels.SingleConsumerUnboundedChannel$$(T).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2424853,
      "h": Number(BigInt(2424853)|0x400000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(17182294037)
  ],
  "i": [$.$stc.System.Threading.Channels.IDebugEnumerable$$(T).$h
  ],
  "d": $.$stc.System.Threading.Channels.SingleConsumerUnboundedChannel$$(T).$h,
  "h": 2424853,
  "a": [
    {
      "t": 70385665,
      "c": 25840189441,
      "a": [
        {
          "v": "Items = {ItemsCountForDebugger}",
          "t": 1310721
        }
      ]
    },
    {
      "t": 70713345,
      "c": 21545549825,
      "a": [
        {
          "v": $.$stc.System.Threading.Channels.DebugEnumeratorDebugView$$().$h,
          "t": 187760641
        }
      ]
    }
  ]
}; }
                    static get $b() { return $.$stc.System.Threading.Channels.ChannelReader$$(T); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$stc.System.Threading.Channels.IDebugEnumerable$$(T) ]; }
                    static get $fullName() { return `System.Threading.Channels.SingleConsumerUnboundedChannel<${T?.$fullName}>.UnboundedChannelReader`; }
                }, $cls, ($v) => $cls.$_UnboundedChannelReader = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2424853)
            
            //--TRIMMABLE-BOUNDARY-START(2490389)
            static $_UnboundedChannelWriter;
            static get UnboundedChannelWriter()
            {
                let $cls = $.$stc.System.Threading.Channels.SingleConsumerUnboundedChannel$$(T);
                return $cls.$_UnboundedChannelWriter ??= $asm.$ncls("$stc.System.Threading.Channels.SingleConsumerUnboundedChannel$$.UnboundedChannelWriter", ($self) => class UnboundedChannelWriter extends $.$stc.System.Threading.Channels.ChannelWriter$$(T)
                {
                    //--TRIMMABLE-BOUNDARY-START(4297457685)
                    /*SingleConsumerUnboundedChannel<T>*/ _parent = null;
                    //--TRIMMABLE-BOUNDARY-END(4297457685)
                    
                    //--TRIMMABLE-BOUNDARY-START(8592424981)
                    $ctor$2(/*SingleConsumerUnboundedChannel<T>*/ parent)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8592424981);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._parent = parent;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8592424981)
                    
                    //--TRIMMABLE-BOUNDARY-START(30067261461)
                    /*bool */ TryComplete(/*Exception?*/ error)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(30067261461);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*BlockedReadAsyncOperation<T>?*/ let blockedReader = null;
                        /*WaitingReadAsyncOperation?*/ let waitingReader = null;
                        /*bool*/ let completeTask = false;
                        /*SingleConsumerUnboundedChannel<T>*/ let parent = this._parent;
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(parent.SyncObj)
                            {
                                if (!(parent._doneWriting === null))
                                {
                                    return false;
                                }
                                parent._doneWriting = error ?? $.$stc.System.Threading.Channels.ChannelUtilities.s_doneWritingSentinel;
                                if (parent._items.IsEmpty)
                                {
                                    completeTask = true;
                                    if (!(parent._blockedReader === null))
                                    {
                                        blockedReader = parent._blockedReader;
                                        parent._blockedReader = null;
                                    }
                                    if (!(parent._waitingReader === null))
                                    {
                                        waitingReader = parent._waitingReader;
                                        parent._waitingReader = null;
                                    }
                                }
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(parent.SyncObj)
                        }
                        if (completeTask)
                        {
                            $.$stc.System.Threading.Channels.ChannelUtilities.Complete(parent._completion, error);
                        }
                        if (!(blockedReader === null))
                        {
                            error = $.$stc.System.Threading.Channels.ChannelUtilities.CreateInvalidCompletionException(error);
                            blockedReader.TrySetException(error);
                        }
                        if (!(waitingReader === null))
                        {
                            if (!(error === null))
                            {
                                waitingReader.TrySetException(error);
                            }
                            else 
                            {
                                waitingReader.TrySetResult(false);
                            }
                        }
                        return true;
                    }
                    //--TRIMMABLE-BOUNDARY-END(30067261461)
                    
                    //--TRIMMABLE-BOUNDARY-START(34362228757)
                    /*bool */ TryWrite(/*T*/ item)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34362228757);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*SingleConsumerUnboundedChannel<T>*/ let parent = this._parent;
                        while(true)
                        {
                            /*BlockedReadAsyncOperation<T>?*/ let blockedReader = null;
                            /*WaitingReadAsyncOperation?*/ let waitingReader = null;
                            //lock
                            try
                            {
                                $.$$.System.Threading.Monitor.Enter$1(parent.SyncObj)
                                {
                                    if (!(parent._doneWriting === null))
                                    {
                                        return false;
                                    }
                                    blockedReader = parent._blockedReader;
                                    if (!(blockedReader === null))
                                    {
                                        parent._blockedReader = null;
                                    }
                                    else 
                                    {
                                        parent._items.Enqueue(item);
                                        waitingReader = parent._waitingReader;
                                        if (waitingReader === null)
                                        {
                                            return true;
                                        }
                                        parent._waitingReader = null;
                                    }
                                }
                            }
                            finally
                            {
                                $.$$.System.Threading.Monitor.Exit(parent.SyncObj)
                            }
                            $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Boolean.op_ExclusiveOr((!(blockedReader === null)), (!(waitingReader === null))), "Expected either a blocked or waiting reader, but not both");
                            if (!(waitingReader === null))
                            {
                                waitingReader.TrySetResult(true);
                                return true;
                            }
                            $.$$.System.Diagnostics.Debug.Assert$2(!(blockedReader === null), "blockedReader is not null");
                            if (blockedReader.TrySetResult(item))
                            {
                                return true;
                            }
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(34362228757)
                    
                    //--TRIMMABLE-BOUNDARY-START(38657196053)
                    /*ValueTask<bool> */ WaitToWriteAsync(/*CancellationToken*/ cancellationToken)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(38657196053);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*Exception?*/ let doneWriting = this._parent._doneWriting;
                        return cancellationToken.IsCancellationRequested ? new ($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Boolean))().$ctor$5($.$$.System.Threading.Tasks.Task.FromCanceled$3($.$$.System.Boolean, cancellationToken)) : doneWriting === null ? new ($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Boolean))().$ctor$6(true) : doneWriting !== $.$stc.System.Threading.Channels.ChannelUtilities.s_doneWritingSentinel ? new ($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Boolean))().$ctor$5($.$$.System.Threading.Tasks.Task.FromException$1($.$$.System.Boolean, doneWriting)) : new ($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Boolean))();
                    }
                    //--TRIMMABLE-BOUNDARY-END(38657196053)
                    
                    //--TRIMMABLE-BOUNDARY-START(42952163349)
                    /*ValueTask */ WriteAsync(/*T*/ item, /*CancellationToken*/ cancellationToken)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(42952163349);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return cancellationToken.IsCancellationRequested ? new $.$$.System.Threading.Tasks.ValueTask().$ctor$5($.$$.System.Threading.Tasks.Task.FromCanceled$1(cancellationToken)) : this.TryWrite(item) ? new $.$$.System.Threading.Tasks.ValueTask() : new $.$$.System.Threading.Tasks.ValueTask().$ctor$5($.$$.System.Threading.Tasks.Task.FromException($.$stc.System.Threading.Channels.ChannelUtilities.CreateInvalidCompletionException(this._parent._doneWriting)));
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(42952163349)
                    
                    //--TRIMMABLE-BOUNDARY-START(21477326869)
                    /*int */ get ItemsCountForDebugger()
                    {
                        return this._parent._items.Count;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21477326869)
                    
                    //--TRIMMABLE-BOUNDARY-START(25772294165)
                    /*IEnumerator<T> */ System$Threading$Channels$IDebugEnumerable$$$GetEnumerator()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(25772294165);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._parent._items.GetEnumerator();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(25772294165)
                    
                    static $h = 2490389;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21477326869),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(2490389)|0x400000000n),
        "f": 50331650
      },
      "n": "ItemsCountForDebugger",
      "d": 2490389,
      "h": Number(BigInt(2490389)|0x500000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(21477326869)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30067261461),
    {
      "r": 262145,
      "p": [
        {
          "n": "error",
          "p": 80019457
        }
      ],
      "n": "TryComplete",
      "d": 2490389,
      "h": Number(BigInt(2490389)|0x700000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30067261461),
//--TRIMMABLE-BOUNDARY-START(34362228757),
    {
      "r": 262145,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1507328
        }
      ],
      "n": "TryWrite",
      "d": 2490389,
      "h": Number(BigInt(2490389)|0x800000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34362228757),
//--TRIMMABLE-BOUNDARY-START(38657196053),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Boolean).$h,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "WaitToWriteAsync",
      "d": 2490389,
      "h": Number(BigInt(2490389)|0x900000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38657196053),
//--TRIMMABLE-BOUNDARY-START(42952163349),
    {
      "r": 180551681,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1507328
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "WriteAsync",
      "d": 2490389,
      "h": Number(BigInt(2490389)|0xA00000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(42952163349)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297457685),
    {
      "t": $.$stc.System.Threading.Channels.SingleConsumerUnboundedChannel$$(T).$h,
      "n": "_parent",
      "d": 2490389,
      "h": Number(BigInt(2490389)|0x100000000n),
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(4297457685)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592424981),
    {
      "p": [
        {
          "n": "parent",
          "p": $.$stc.System.Threading.Channels.SingleConsumerUnboundedChannel$$(T).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2490389,
      "h": Number(BigInt(2490389)|0x200000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(8592424981)
  ],
  "i": [$.$stc.System.Threading.Channels.IDebugEnumerable$$(T).$h
  ],
  "d": $.$stc.System.Threading.Channels.SingleConsumerUnboundedChannel$$(T).$h,
  "h": 2490389,
  "a": [
    {
      "t": 70385665,
      "c": 25840189441,
      "a": [
        {
          "v": "Items = {ItemsCountForDebugger}",
          "t": 1310721
        }
      ]
    },
    {
      "t": 70713345,
      "c": 21545549825,
      "a": [
        {
          "v": $.$stc.System.Threading.Channels.DebugEnumeratorDebugView$$().$h,
          "t": 187760641
        }
      ]
    }
  ]
}; }
                    static get $b() { return $.$stc.System.Threading.Channels.ChannelWriter$$(T); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$stc.System.Threading.Channels.IDebugEnumerable$$(T) ]; }
                    static get $fullName() { return `System.Threading.Channels.SingleConsumerUnboundedChannel<${T?.$fullName}>.UnboundedChannelWriter`; }
                }, $cls, ($v) => $cls.$_UnboundedChannelWriter = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2490389)
            
            //--TRIMMABLE-BOUNDARY-START(94491639829)
            /*object */ get SyncObj()
            {
                return this._items;
            }
            //--TRIMMABLE-BOUNDARY-END(94491639829)
            
            //--TRIMMABLE-BOUNDARY-START(47246999573)
            /*Action<object?, CancellationToken>*/ CancellationCallbackDelegate$ = null;
            /*Action<object?, CancellationToken> */ get CancellationCallbackDelegate()
            {
                return this.CancellationCallbackDelegate$ ??= new ($.$$.System.Action$$$($.$$.System.Object, $.$$.System.Threading.CancellationToken))().$ctor(this,  (/*state*/ state, /*cancellationToken*/ cancellationToken) =>
                {
                    /*AsyncOperation*/ let op = $.$cast(state, $.$stc.System.Threading.Channels.AsyncOperation);
                    if (op.TrySetCanceled(cancellationToken))
                    {
                        $.$stc.System.Threading.Channels.ChannelUtilities.UnsafeQueueUserWorkItem($.$$.System.Collections.Generic.KeyValuePair$$$($.$stc.System.Threading.Channels.SingleConsumerUnboundedChannel$$(T), $.$stc.System.Threading.Channels.AsyncOperation), new ($.$$.System.Action$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$stc.System.Threading.Channels.SingleConsumerUnboundedChannel$$(T), $.$stc.System.Threading.Channels.AsyncOperation)))().$ctor($.$stc.System.Threading.Channels.SingleConsumerUnboundedChannel$$(T), /*static*/ (/*state*/ state) =>
                        {
                            //lock
                            try
                            {
                                $.$$.System.Threading.Monitor.Enter$1(state.Key.SyncObj)
                                {
                                    //switch (state.Value)
                                    let $switch1 = state.Value;
                                    {
                                        let blockedReader;
                                        let waitingReader;
                                        $switchJumpStart1: 
                                        //case BlockedReadAsyncOperation<T> blockedReader:
                                        if ($.$is($switch1, $.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T), { set $v(v){ blockedReader = v; } }))
                                        {
                                            if (state.Key._blockedReader === blockedReader)
                                            {
                                                state.Key._blockedReader = null;
                                            }
                                        }
                                        //case WaitingReadAsyncOperation waitingReader:
                                        else if ($.$is($switch1, $.$stc.System.Threading.Channels.WaitingReadAsyncOperation, { set $v(v){ waitingReader = v; } }))
                                        {
                                            if (state.Key._waitingReader === waitingReader)
                                            {
                                                state.Key._waitingReader = null;
                                            }
                                        }
                                        //default
                                        else
                                        {
                                            $.$$.System.Diagnostics.Debug.Fail$1(`Unexpected operation: ${$.$$.System.Object.ToString.call(state.Value)}`);
                                        }
                                    }
                                }
                            }
                            finally
                            {
                                $.$$.System.Threading.Monitor.Exit(state.Key.SyncObj)
                            }
                        }, {
  "r": 65537,
  "p": [
    {
      "n": "state",
      "p": $.$$.System.Collections.Generic.KeyValuePair$$$($.$stc.System.Threading.Channels.SingleConsumerUnboundedChannel$$(T), $.$stc.System.Threading.Channels.AsyncOperation).$h
    }
  ],
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825826
}), new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$stc.System.Threading.Channels.SingleConsumerUnboundedChannel$$(T), $.$stc.System.Threading.Channels.AsyncOperation))().$ctor$3(this, op));
                    }
                }, {
  "r": 65537,
  "p": [
    {
      "n": "state",
      "p": 131073
    },
    {
      "n": "cancellationToken",
      "p": 170065921
    }
  ],
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825794
});
            }
            //--TRIMMABLE-BOUNDARY-END(47246999573)
            
            //--TRIMMABLE-BOUNDARY-START(90196672533)
            /*int */ get ItemsCountForDebugger()
            {
                return this._items.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(90196672533)
            
            //--TRIMMABLE-BOUNDARY-START(51541966869)
            /*bool */ get ChannelIsClosedForDebugger()
            {
                return !(this._doneWriting === null);
            }
            //--TRIMMABLE-BOUNDARY-END(51541966869)
            
            //--TRIMMABLE-BOUNDARY-START(98786607125)
            /*IEnumerator<T> */ System$Threading$Channels$IDebugEnumerable$$$GetEnumerator()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(98786607125);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._items.GetEnumerator();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(98786607125)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(17182228501)
                this._items = new ($.$stc.System.Collections.Concurrent.SingleProducerSingleConsumerQueue$$(T))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(17182228501)
                
            }
            static $h = 2359317;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(94491639829),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1400000000n),
        "f": 50331650
      },
      "n": "SyncObj",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1600000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(94491639829),
//--TRIMMABLE-BOUNDARY-START(47246999573),
    {
      "p": $.$$.System.Action$$$($.$$.System.Object, $.$$.System.Threading.CancellationToken).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xE00000000n),
        "f": 50331650
      },
      "n": "CancellationCallbackDelegate",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(47246999573),
//--TRIMMABLE-BOUNDARY-START(90196672533),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1200000000n),
        "f": 50331650
      },
      "n": "ItemsCountForDebugger",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1500000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(90196672533),
//--TRIMMABLE-BOUNDARY-START(51541966869),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1000000000n),
        "f": 50331650
      },
      "n": "ChannelIsClosedForDebugger",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(51541966869)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8592293909),
    {
      "t": 178782209,
      "n": "_completion",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8592293909),
//--TRIMMABLE-BOUNDARY-START(17182228501),
    {
      "t": $.$stc.System.Collections.Concurrent.SingleProducerSingleConsumerQueue$$(T).$h,
      "n": "_items",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17182228501),
//--TRIMMABLE-BOUNDARY-START(21477195797),
    {
      "t": 262145,
      "n": "_runContinuationsAsynchronously",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21477195797),
//--TRIMMABLE-BOUNDARY-START(12887261205),
    {
      "t": 80019457,
      "n": "_doneWriting",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12887261205),
//--TRIMMABLE-BOUNDARY-START(4297326613),
    {
      "t": $.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T).$h,
      "n": "_blockedReader",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297326613),
//--TRIMMABLE-BOUNDARY-START(25772163093),
    {
      "t": 3080213,
      "n": "_waitingReader",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25772163093)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(42952032277),
    {
      "p": [
        {
          "n": "runContinuationsAsynchronously",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(42952032277)
  ],
  "i": [$.$stc.System.Threading.Channels.IDebugEnumerable$$(T).$h
  ],
  "g": [T?.$h??1507328
  ],
  "j": [2424853,2490389
  ],
  "r": 1,
  "h": this.$h,
  "a": [
    {
      "t": 70385665,
      "c": 25840189441,
      "a": [
        {
          "v": "Items = {ItemsCountForDebugger}, Closed = {ChannelIsClosedForDebugger}",
          "t": 1310721
        }
      ]
    },
    {
      "t": 70713345,
      "c": 21545549825,
      "a": [
        {
          "v": $.$stc.System.Threading.Channels.DebugEnumeratorDebugView$$().$h,
          "t": 187760641
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$stc.System.Threading.Channels.Channel$$(T); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stc.System.Threading.Channels.IDebugEnumerable$$(T) ]; }
            static get $fullName() { return `System.Threading.Channels.SingleConsumerUnboundedChannel<${T?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2359317)
        
        
        //--TRIMMABLE-BOUNDARY-START(1179669)
        $asm.$cls("$stc.System.Threading.Channels.BoundedChannel<>", (T) => $asm.$gt("$stc.System.Threading.Channels.BoundedChannel<>", [T], ($self) => class BoundedChannel$$ extends $.$stc.System.Threading.Channels.Channel$$(T)
        {
            //--TRIMMABLE-BOUNDARY-START(34360918037)
            /*BoundedChannelFullMode*/ _mode = 0;
            //--TRIMMABLE-BOUNDARY-END(34360918037)
            
            //--TRIMMABLE-BOUNDARY-START(25770983445)
            /*Action<T>?*/ _itemDropped = null;
            //--TRIMMABLE-BOUNDARY-END(25770983445)
            
            //--TRIMMABLE-BOUNDARY-START(17181048853)
            /*TaskCompletionSource*/ _completion = null;
            //--TRIMMABLE-BOUNDARY-END(17181048853)
            
            //--TRIMMABLE-BOUNDARY-START(12886081557)
            /*int*/ _bufferedCapacity = 0;
            //--TRIMMABLE-BOUNDARY-END(12886081557)
            
            //--TRIMMABLE-BOUNDARY-START(30065950741)
            /*Deque<T>*/ _items = null;
            //--TRIMMABLE-BOUNDARY-END(30065950741)
            
            //--TRIMMABLE-BOUNDARY-START(4296146965)
            /*BlockedReadAsyncOperation<T>?*/ _blockedReadersHead = null;
            //--TRIMMABLE-BOUNDARY-END(4296146965)
            
            //--TRIMMABLE-BOUNDARY-START(8591114261)
            /*BlockedWriteAsyncOperation<T>?*/ _blockedWritersHead = null;
            //--TRIMMABLE-BOUNDARY-END(8591114261)
            
            //--TRIMMABLE-BOUNDARY-START(42950852629)
            /*WaitingReadAsyncOperation?*/ _waitingReadersHead = null;
            //--TRIMMABLE-BOUNDARY-END(42950852629)
            
            //--TRIMMABLE-BOUNDARY-START(47245819925)
            /*WaitingWriteAsyncOperation?*/ _waitingWritersHead = null;
            //--TRIMMABLE-BOUNDARY-END(47245819925)
            
            //--TRIMMABLE-BOUNDARY-START(38655885333)
            /*bool*/ _runContinuationsAsynchronously = false;
            //--TRIMMABLE-BOUNDARY-END(38655885333)
            
            //--TRIMMABLE-BOUNDARY-START(21476016149)
            /*Exception?*/ _doneWriting = null;
            //--TRIMMABLE-BOUNDARY-END(21476016149)
            
            //--TRIMMABLE-BOUNDARY-START(64425689109)
            $ctor$3(/*int*/ bufferedCapacity, /*BoundedChannelFullMode*/ mode, /*bool*/ runContinuationsAsynchronously, /*Action<T>?*/ itemDropped)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64425689109);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.Diagnostics.Debug.Assert$2(bufferedCapacity > 0, "bufferedCapacity > 0");
                    this._bufferedCapacity = bufferedCapacity;
                    this._mode = mode;
                    this._runContinuationsAsynchronously = runContinuationsAsynchronously;
                    this._itemDropped = itemDropped;
                    this._completion = new $.$$.System.Threading.Tasks.TaskCompletionSource().$ctor$4(runContinuationsAsynchronously ? 64/*TaskCreationOptions.RunContinuationsAsynchronously*/ : 0/*TaskCreationOptions.None*/);
                    this.Reader = new ($.$stc.System.Threading.Channels.BoundedChannel$$(T).BoundedChannelReader)().$ctor$2(this);
                    this.Writer = new ($.$stc.System.Threading.Channels.BoundedChannel$$(T).BoundedChannelWriter)().$ctor$2(this);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(64425689109)
            
            //--TRIMMABLE-BOUNDARY-START(1245205)
            static $_BoundedChannelReader;
            static get BoundedChannelReader()
            {
                let $cls = $.$stc.System.Threading.Channels.BoundedChannel$$(T);
                return $cls.$_BoundedChannelReader ??= $asm.$ncls("$stc.System.Threading.Channels.BoundedChannel$$.BoundedChannelReader", ($self) => class BoundedChannelReader extends $.$stc.System.Threading.Channels.ChannelReader$$(T)
                {
                    //--TRIMMABLE-BOUNDARY-START(4296212501)
                    /*BoundedChannel<T>*/ _parent = null;
                    //--TRIMMABLE-BOUNDARY-END(4296212501)
                    
                    //--TRIMMABLE-BOUNDARY-START(8591179797)
                    /*BlockedReadAsyncOperation<T>*/ _readerSingleton = null;
                    //--TRIMMABLE-BOUNDARY-END(8591179797)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886147093)
                    /*WaitingReadAsyncOperation*/ _waiterSingleton = null;
                    //--TRIMMABLE-BOUNDARY-END(12886147093)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181114389)
                    $ctor$2(/*BoundedChannel<T>*/ parent)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(17181114389);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._parent = parent;
                            this._readerSingleton = new ($.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T))().$ctor$4(parent._runContinuationsAsynchronously, new $.$$.System.Threading.CancellationToken(), true, null);
                            this._waiterSingleton = new $.$stc.System.Threading.Channels.WaitingReadAsyncOperation().$ctor$4(parent._runContinuationsAsynchronously, new $.$$.System.Threading.CancellationToken(), true, null);
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17181114389)
                    
                    //--TRIMMABLE-BOUNDARY-START(30066016277)
                    /*Task */ get Completion()
                    {
                        return this._parent._completion.Task;
                    }
                    //--TRIMMABLE-BOUNDARY-END(30066016277)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476081685)
                    /*bool */ get CanCount()
                    {
                        return true;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21476081685)
                    
                    //--TRIMMABLE-BOUNDARY-START(25771048981)
                    /*bool */ get CanPeek()
                    {
                        return true;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25771048981)
                    
                    //--TRIMMABLE-BOUNDARY-START(34360983573)
                    /*int */ get Count()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(73015689237);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*BoundedChannel<T>*/ let parent = this._parent;
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(parent.SyncObj)
                            {
                                parent.AssertInvariants();
                                return parent._items.Count;
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(parent.SyncObj)
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(34360983573)
                    
                    //--TRIMMABLE-BOUNDARY-START(85900591125)
                    /*int */ get ItemsCountForDebugger()
                    {
                        return this._parent._items.Count;
                    }
                    //--TRIMMABLE-BOUNDARY-END(85900591125)
                    
                    //--TRIMMABLE-BOUNDARY-START(103080460309)
                    /*bool */ TryRead(/*out T*/ item)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(103080460309);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*BoundedChannel<T>*/ let parent = this._parent;
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(parent.SyncObj)
                            {
                                parent.AssertInvariants();
                                if (!parent._items.IsEmpty)
                                {
                                    item.$v = this.DequeueItemAndPostProcess();
                                    return true;
                                }
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(parent.SyncObj)
                        }
                        item.$v = $.$default(T);
                        return false;
                    }
                    //--TRIMMABLE-BOUNDARY-END(103080460309)
                    
                    //--TRIMMABLE-BOUNDARY-START(98785493013)
                    /*bool */ TryPeek(/*out T*/ item)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(98785493013);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*BoundedChannel<T>*/ let parent = this._parent;
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(parent.SyncObj)
                            {
                                parent.AssertInvariants();
                                if (!parent._items.IsEmpty)
                                {
                                    item.$v = parent._items.PeekHead();
                                    return true;
                                }
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(parent.SyncObj)
                        }
                        item.$v = $.$default(T);
                        return false;
                    }
                    //--TRIMMABLE-BOUNDARY-END(98785493013)
                    
                    //--TRIMMABLE-BOUNDARY-START(90195558421)
                    /*ValueTask<T> */ ReadAsync(/*CancellationToken*/ cancellationToken)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(90195558421);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (cancellationToken.IsCancellationRequested)
                        {
                            return new ($.$$.System.Threading.Tasks.ValueTask$$(T))().$ctor$5($.$$.System.Threading.Tasks.Task.FromCanceled$3(T, cancellationToken));
                        }
                        /*BoundedChannel<T>*/ let parent = this._parent;
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(parent.SyncObj)
                            {
                                parent.AssertInvariants();
                                if (!parent._items.IsEmpty)
                                {
                                    return new ($.$$.System.Threading.Tasks.ValueTask$$(T))().$ctor$6(this.DequeueItemAndPostProcess());
                                }
                                if (!(parent._doneWriting === null))
                                {
                                    return $.$stc.System.Threading.Channels.ChannelUtilities.GetInvalidCompletionValueTask(T, parent._doneWriting);
                                }
                                if (!cancellationToken.CanBeCanceled)
                                {
                                    /*BlockedReadAsyncOperation<T>*/ let singleton = this._readerSingleton;
                                    if (singleton.TryOwnAndReset())
                                    {
                                        $.$stc.System.Threading.Channels.ChannelUtilities.Enqueue($.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T), $.$ref(() => parent._blockedReadersHead, ($v) => parent._blockedReadersHead = $v, $.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T)), singleton);
                                        return singleton.ValueTaskOfT;
                                    }
                                }
                                /*var*/ let reader = new ($.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T))().$ctor$4(parent._runContinuationsAsynchronously, new $.$$.System.Threading.CancellationToken(), false, this._parent.CancellationCallbackDelegate);
                                $.$stc.System.Threading.Channels.ChannelUtilities.Enqueue($.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T), $.$ref(() => parent._blockedReadersHead, ($v) => parent._blockedReadersHead = $v, $.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T)), reader);
                                return reader.ValueTaskOfT;
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(parent.SyncObj)
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(90195558421)
                    
                    //--TRIMMABLE-BOUNDARY-START(107375427605)
                    /*ValueTask<bool> */ WaitToReadAsync(/*CancellationToken*/ cancellationToken)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(107375427605);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (cancellationToken.IsCancellationRequested)
                        {
                            return new ($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Boolean))().$ctor$5($.$$.System.Threading.Tasks.Task.FromCanceled$3($.$$.System.Boolean, cancellationToken));
                        }
                        /*BoundedChannel<T>*/ let parent = this._parent;
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(parent.SyncObj)
                            {
                                parent.AssertInvariants();
                                if (!parent._items.IsEmpty)
                                {
                                    return new ($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Boolean))().$ctor$6(true);
                                }
                                if (!(parent._doneWriting === null))
                                {
                                    return parent._doneWriting !== $.$stc.System.Threading.Channels.ChannelUtilities.s_doneWritingSentinel ? new ($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Boolean))().$ctor$5($.$$.System.Threading.Tasks.Task.FromException$1($.$$.System.Boolean, parent._doneWriting)) : new ($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Boolean))();
                                }
                                if (!cancellationToken.CanBeCanceled)
                                {
                                    /*WaitingReadAsyncOperation*/ let singleton = this._waiterSingleton;
                                    if (singleton.TryOwnAndReset())
                                    {
                                        $.$stc.System.Threading.Channels.ChannelUtilities.Enqueue($.$stc.System.Threading.Channels.WaitingReadAsyncOperation, $.$ref(() => parent._waitingReadersHead, ($v) => parent._waitingReadersHead = $v, $.$stc.System.Threading.Channels.WaitingReadAsyncOperation), singleton);
                                        return singleton.ValueTaskOfT;
                                    }
                                }
                                /*var*/ let waiter = new $.$stc.System.Threading.Channels.WaitingReadAsyncOperation().$ctor$4(parent._runContinuationsAsynchronously, new $.$$.System.Threading.CancellationToken(), false, this._parent.CancellationCallbackDelegate);
                                $.$stc.System.Threading.Channels.ChannelUtilities.Enqueue($.$stc.System.Threading.Channels.WaitingReadAsyncOperation, $.$ref(() => parent._waitingReadersHead, ($v) => parent._waitingReadersHead = $v, $.$stc.System.Threading.Channels.WaitingReadAsyncOperation), waiter);
                                return waiter.ValueTaskOfT;
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(parent.SyncObj)
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(107375427605)
                    
                    //--TRIMMABLE-BOUNDARY-START(38655950869)
                    /*T */ DequeueItemAndPostProcess()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(38655950869);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*BoundedChannel<T>*/ let parent = this._parent;
                        $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Threading.Monitor.IsEntered(parent.SyncObj), "Monitor.IsEntered(parent.SyncObj)");
                        /*T*/ let item = parent._items.DequeueHead();
                        if (!(parent._doneWriting === null))
                        {
                            if (parent._items.IsEmpty)
                            {
                                $.$stc.System.Threading.Channels.ChannelUtilities.Complete(parent._completion, parent._doneWriting);
                            }
                        }
                        else 
                        {
                            /*BlockedWriteAsyncOperation<T>?*/ let w;
                            while($.$stc.System.Threading.Channels.ChannelUtilities.TryDequeue($.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T), $.$ref(() => parent._blockedWritersHead, ($v) => parent._blockedWritersHead = $v, $.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T)), $.$ref(() => w, ($v) => w = $v, $.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T))))
                            {
                                if (w.TrySetResult(new $.$stc.System.VoidResult()))
                                {
                                    parent._items.EnqueueTail(w.Item$1);
                                    return item;
                                }
                            }
                            $.$stc.System.Threading.Channels.ChannelUtilities.AssertAll($.$stc.System.Threading.Channels.WaitingWriteAsyncOperation, parent._waitingWritersHead, new ($.$$.System.Func$$$($.$stc.System.Threading.Channels.WaitingWriteAsyncOperation, $.$$.System.Boolean))().$ctor($.$stc.System.Threading.Channels.BoundedChannel$$(T).BoundedChannelReader, /*static*/ (/*writer*/ writer) =>
                            {
                                return writer.RunContinuationsAsynchronously;
                            }, {
  "r": 262145,
  "p": [
    {
      "n": "writer",
      "p": 3145749
    }
  ],
  "n": "",
  "d": 1245205,
  "h": 0,
  "f": 17825826
}), "All WaitToWriteAsync waiters should have been asynchronous.");
                            $.$stc.System.Threading.Channels.ChannelUtilities.SetOperations($.$stc.System.Threading.Channels.WaitingWriteAsyncOperation, $.$$.System.Boolean, $.$ref(() => parent._waitingWritersHead, ($v) => parent._waitingWritersHead = $v, $.$stc.System.Threading.Channels.WaitingWriteAsyncOperation), true);
                        }
                        return item;
                    }
                    //--TRIMMABLE-BOUNDARY-END(38655950869)
                    
                    //--TRIMMABLE-BOUNDARY-START(94490525717)
                    /*IEnumerator<T> */ System$Threading$Channels$IDebugEnumerable$$$GetEnumerator()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(94490525717);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._parent._items.GetEnumerator();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(94490525717)
                    
                    static $h = 1245205;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30066016277),
    {
      "p": 177668097,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(1245205)|0xF00000000n),
        "f": 50364417
      },
      "n": "Completion",
      "d": 1245205,
      "h": Number(BigInt(1245205)|0x700000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(30066016277),
//--TRIMMABLE-BOUNDARY-START(21476081685),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(1245205)|0xB00000000n),
        "f": 50364417
      },
      "n": "CanCount",
      "d": 1245205,
      "h": Number(BigInt(1245205)|0x500000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21476081685),
//--TRIMMABLE-BOUNDARY-START(25771048981),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(1245205)|0xD00000000n),
        "f": 50364417
      },
      "n": "CanPeek",
      "d": 1245205,
      "h": Number(BigInt(1245205)|0x600000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(25771048981),
//--TRIMMABLE-BOUNDARY-START(34360983573),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(1245205)|0x1100000000n),
        "f": 50364417
      },
      "n": "Count",
      "d": 1245205,
      "h": Number(BigInt(1245205)|0x800000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34360983573),
//--TRIMMABLE-BOUNDARY-START(85900591125),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(1245205)|0x1300000000n),
        "f": 50331650
      },
      "n": "ItemsCountForDebugger",
      "d": 1245205,
      "h": Number(BigInt(1245205)|0x1400000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(85900591125)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(103080460309),
    {
      "r": 262145,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1507328,
          "f": 2
        }
      ],
      "n": "TryRead",
      "d": 1245205,
      "h": Number(BigInt(1245205)|0x1800000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(103080460309),
//--TRIMMABLE-BOUNDARY-START(98785493013),
    {
      "r": 262145,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1507328,
          "f": 2
        }
      ],
      "n": "TryPeek",
      "d": 1245205,
      "h": Number(BigInt(1245205)|0x1700000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(98785493013),
//--TRIMMABLE-BOUNDARY-START(90195558421),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$(T).$h,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "ReadAsync",
      "d": 1245205,
      "h": Number(BigInt(1245205)|0x1500000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(90195558421),
//--TRIMMABLE-BOUNDARY-START(107375427605),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Boolean).$h,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "WaitToReadAsync",
      "d": 1245205,
      "h": Number(BigInt(1245205)|0x1900000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(107375427605),
//--TRIMMABLE-BOUNDARY-START(38655950869),
    {
      "r": T?.$h??1507328,
      "n": "DequeueItemAndPostProcess",
      "d": 1245205,
      "h": Number(BigInt(1245205)|0x900000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(38655950869)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296212501),
    {
      "t": $.$stc.System.Threading.Channels.BoundedChannel$$(T).$h,
      "n": "_parent",
      "d": 1245205,
      "h": Number(BigInt(1245205)|0x100000000n),
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(4296212501),
//--TRIMMABLE-BOUNDARY-START(8591179797),
    {
      "t": $.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T).$h,
      "n": "_readerSingleton",
      "d": 1245205,
      "h": Number(BigInt(1245205)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591179797),
//--TRIMMABLE-BOUNDARY-START(12886147093),
    {
      "t": 3080213,
      "n": "_waiterSingleton",
      "d": 1245205,
      "h": Number(BigInt(1245205)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886147093)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181114389),
    {
      "p": [
        {
          "n": "parent",
          "p": $.$stc.System.Threading.Channels.BoundedChannel$$(T).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1245205,
      "h": Number(BigInt(1245205)|0x400000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(17181114389)
  ],
  "i": [$.$stc.System.Threading.Channels.IDebugEnumerable$$(T).$h
  ],
  "d": $.$stc.System.Threading.Channels.BoundedChannel$$(T).$h,
  "h": 1245205,
  "a": [
    {
      "t": 70385665,
      "c": 25840189441,
      "a": [
        {
          "v": "Items = {ItemsCountForDebugger}",
          "t": 1310721
        }
      ]
    },
    {
      "t": 70713345,
      "c": 21545549825,
      "a": [
        {
          "v": $.$stc.System.Threading.Channels.DebugEnumeratorDebugView$$().$h,
          "t": 187760641
        }
      ]
    }
  ]
}; }
                    static get $b() { return $.$stc.System.Threading.Channels.ChannelReader$$(T); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$stc.System.Threading.Channels.IDebugEnumerable$$(T) ]; }
                    static get $fullName() { return `System.Threading.Channels.BoundedChannel<${T?.$fullName}>.BoundedChannelReader`; }
                }, $cls, ($v) => $cls.$_BoundedChannelReader = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1245205)
            
            //--TRIMMABLE-BOUNDARY-START(1310741)
            static $_BoundedChannelWriter;
            static get BoundedChannelWriter()
            {
                let $cls = $.$stc.System.Threading.Channels.BoundedChannel$$(T);
                return $cls.$_BoundedChannelWriter ??= $asm.$ncls("$stc.System.Threading.Channels.BoundedChannel$$.BoundedChannelWriter", ($self) => class BoundedChannelWriter extends $.$stc.System.Threading.Channels.ChannelWriter$$(T)
                {
                    //--TRIMMABLE-BOUNDARY-START(4296278037)
                    /*BoundedChannel<T>*/ _parent = null;
                    //--TRIMMABLE-BOUNDARY-END(4296278037)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886212629)
                    /*BlockedWriteAsyncOperation<T>*/ _writerSingleton = null;
                    //--TRIMMABLE-BOUNDARY-END(12886212629)
                    
                    //--TRIMMABLE-BOUNDARY-START(8591245333)
                    /*WaitingWriteAsyncOperation*/ _waiterSingleton = null;
                    //--TRIMMABLE-BOUNDARY-END(8591245333)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181179925)
                    $ctor$2(/*BoundedChannel<T>*/ parent)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(17181179925);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._parent = parent;
                            this._writerSingleton = new ($.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T))().$ctor$4(true, new $.$$.System.Threading.CancellationToken(), true, null);
                            this._waiterSingleton = new $.$stc.System.Threading.Channels.WaitingWriteAsyncOperation().$ctor$4(true, new $.$$.System.Threading.CancellationToken(), true, null);
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17181179925)
                    
                    //--TRIMMABLE-BOUNDARY-START(51540918293)
                    /*bool */ TryComplete(/*Exception?*/ error)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(51540918293);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*BoundedChannel<T>*/ let parent = this._parent;
                        /*BlockedReadAsyncOperation<T>?*/ let blockedReadersHead;
                        /*BlockedWriteAsyncOperation<T>?*/ let blockedWritersHead;
                        /*WaitingReadAsyncOperation?*/ let waitingReadersHead;
                        /*WaitingWriteAsyncOperation?*/ let waitingWritersHead;
                        /*bool*/ let completeTask;
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(parent.SyncObj)
                            {
                                parent.AssertInvariants();
                                if (!(parent._doneWriting === null))
                                {
                                    return false;
                                }
                                parent._doneWriting = error ?? $.$stc.System.Threading.Channels.ChannelUtilities.s_doneWritingSentinel;
                                completeTask = parent._items.IsEmpty;
                                blockedReadersHead = parent._blockedReadersHead;
                                blockedWritersHead = parent._blockedWritersHead;
                                waitingReadersHead = parent._waitingReadersHead;
                                waitingWritersHead = parent._waitingWritersHead;
                                parent._blockedReadersHead = null;
                                parent._blockedWritersHead = null;
                                parent._waitingReadersHead = null;
                                parent._waitingWritersHead = null;
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(parent.SyncObj)
                        }
                        if (completeTask)
                        {
                            $.$stc.System.Threading.Channels.ChannelUtilities.Complete(parent._completion, error);
                        }
                        $.$stc.System.Threading.Channels.ChannelUtilities.FailOperations($.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T), blockedReadersHead, $.$stc.System.Threading.Channels.ChannelUtilities.CreateInvalidCompletionException(error));
                        $.$stc.System.Threading.Channels.ChannelUtilities.FailOperations($.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T), blockedWritersHead, $.$stc.System.Threading.Channels.ChannelUtilities.CreateInvalidCompletionException(error));
                        $.$stc.System.Threading.Channels.ChannelUtilities.SetOrFailOperations($.$stc.System.Threading.Channels.WaitingReadAsyncOperation, $.$$.System.Boolean, waitingReadersHead, false, error);
                        $.$stc.System.Threading.Channels.ChannelUtilities.SetOrFailOperations($.$stc.System.Threading.Channels.WaitingWriteAsyncOperation, $.$$.System.Boolean, waitingWritersHead, false, error);
                        return true;
                    }
                    //--TRIMMABLE-BOUNDARY-END(51540918293)
                    
                    //--TRIMMABLE-BOUNDARY-START(55835885589)
                    /*bool */ TryWrite(/*T*/ item)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(55835885589);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*BlockedReadAsyncOperation<T>?*/ let blockedReader = null;
                        /*WaitingReadAsyncOperation?*/ let waitingReadersHead = null;
                        /*BoundedChannel<T>*/ let parent = this._parent;
                        /*bool*/ let releaseLock = false;
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter(parent.SyncObj, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => releaseLock, ($v) => releaseLock = $v, null));
                            parent.AssertInvariants();
                            if (!(parent._doneWriting === null))
                            {
                                return false;
                            }
                            /*int*/ let count = parent._items.Count;
                            if (count === 0)
                            {
                                blockedReader = $.$stc.System.Threading.Channels.ChannelUtilities.TryDequeueAndReserveCompletionIfCancelable($.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T), $.$ref(() => parent._blockedReadersHead, ($v) => parent._blockedReadersHead = $v, $.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T)));
                                if (blockedReader === null)
                                {
                                    parent._items.EnqueueTail(item);
                                    waitingReadersHead = $.$stc.System.Threading.Channels.ChannelUtilities.TryReserveCompletionIfCancelable($.$stc.System.Threading.Channels.WaitingReadAsyncOperation, $.$ref(() => parent._waitingReadersHead, ($v) => parent._waitingReadersHead = $v, $.$stc.System.Threading.Channels.WaitingReadAsyncOperation));
                                    if (waitingReadersHead === null)
                                    {
                                        return true;
                                    }
                                }
                            }
                            else if (count < parent._bufferedCapacity)
                            {
                                parent._items.EnqueueTail(item);
                                return true;
                            }
                            else if (parent._mode === 0/*BoundedChannelFullMode.Wait*/)
                            {
                                return false;
                            }
                            else if (parent._mode === 3/*BoundedChannelFullMode.DropWrite*/)
                            {
                                $.$$.System.Threading.Monitor.Exit(parent.SyncObj);
                                releaseLock = false;
                                parent._itemDropped?.Invoke(item);
                                return true;
                            }
                            else 
                            {
                                /*T*/ let droppedItem = parent._mode === 1/*BoundedChannelFullMode.DropNewest*/ ? parent._items.DequeueTail() : parent._items.DequeueHead();
                                parent._items.EnqueueTail(item);
                                $.$$.System.Threading.Monitor.Exit(parent.SyncObj);
                                releaseLock = false;
                                parent._itemDropped?.Invoke(droppedItem);
                                return true;
                            }
                        }
                        finally
                        {
                            {
                                if (releaseLock)
                                {
                                    $.$$.System.Threading.Monitor.Exit(parent.SyncObj);
                                }
                            }
                        }
                        if (!(blockedReader === null))
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(waitingReadersHead === null, "waitingReadersHead is null");
                            blockedReader.DangerousSetResult(item);
                        }
                        else 
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(!(waitingReadersHead === null), "waitingReadersHead is not null");
                            $.$stc.System.Threading.Channels.ChannelUtilities.DangerousSetOperations($.$stc.System.Threading.Channels.WaitingReadAsyncOperation, $.$$.System.Boolean, waitingReadersHead, true);
                        }
                        return true;
                    }
                    //--TRIMMABLE-BOUNDARY-END(55835885589)
                    
                    //--TRIMMABLE-BOUNDARY-START(60130852885)
                    /*ValueTask<bool> */ WaitToWriteAsync(/*CancellationToken*/ cancellationToken)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(60130852885);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (cancellationToken.IsCancellationRequested)
                        {
                            return new ($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Boolean))().$ctor$5($.$$.System.Threading.Tasks.Task.FromCanceled$3($.$$.System.Boolean, cancellationToken));
                        }
                        /*BoundedChannel<T>*/ let parent = this._parent;
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(parent.SyncObj)
                            {
                                parent.AssertInvariants();
                                if (!(parent._doneWriting === null))
                                {
                                    return parent._doneWriting !== $.$stc.System.Threading.Channels.ChannelUtilities.s_doneWritingSentinel ? new ($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Boolean))().$ctor$5($.$$.System.Threading.Tasks.Task.FromException$1($.$$.System.Boolean, parent._doneWriting)) : new ($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Boolean))();
                                }
                                if (parent._items.Count < parent._bufferedCapacity || parent._mode !== 0/*BoundedChannelFullMode.Wait*/)
                                {
                                    return new ($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Boolean))().$ctor$6(true);
                                }
                                if (!cancellationToken.CanBeCanceled)
                                {
                                    /*WaitingWriteAsyncOperation*/ let singleton = this._waiterSingleton;
                                    if (singleton.TryOwnAndReset())
                                    {
                                        $.$stc.System.Threading.Channels.ChannelUtilities.Enqueue($.$stc.System.Threading.Channels.WaitingWriteAsyncOperation, $.$ref(() => parent._waitingWritersHead, ($v) => parent._waitingWritersHead = $v, $.$stc.System.Threading.Channels.WaitingWriteAsyncOperation), singleton);
                                        return singleton.ValueTaskOfT;
                                    }
                                }
                                /*var*/ let waiter = new $.$stc.System.Threading.Channels.WaitingWriteAsyncOperation().$ctor$4(true, new $.$$.System.Threading.CancellationToken(), false, this._parent.CancellationCallbackDelegate);
                                $.$stc.System.Threading.Channels.ChannelUtilities.Enqueue($.$stc.System.Threading.Channels.WaitingWriteAsyncOperation, $.$ref(() => parent._waitingWritersHead, ($v) => parent._waitingWritersHead = $v, $.$stc.System.Threading.Channels.WaitingWriteAsyncOperation), waiter);
                                return waiter.ValueTaskOfT;
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(parent.SyncObj)
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(60130852885)
                    
                    //--TRIMMABLE-BOUNDARY-START(64425820181)
                    /*ValueTask */ WriteAsync(/*T*/ item, /*CancellationToken*/ cancellationToken)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(64425820181);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (cancellationToken.IsCancellationRequested)
                        {
                            return new $.$$.System.Threading.Tasks.ValueTask().$ctor$5($.$$.System.Threading.Tasks.Task.FromCanceled$1(cancellationToken));
                        }
                        /*BlockedReadAsyncOperation<T>?*/ let blockedReader = null;
                        /*WaitingReadAsyncOperation?*/ let waitingReadersHead = null;
                        /*BoundedChannel<T>*/ let parent = this._parent;
                        /*bool*/ let releaseLock = false;
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter(parent.SyncObj, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => releaseLock, ($v) => releaseLock = $v, null));
                            parent.AssertInvariants();
                            if (!(parent._doneWriting === null))
                            {
                                return new $.$$.System.Threading.Tasks.ValueTask().$ctor$5($.$$.System.Threading.Tasks.Task.FromException($.$stc.System.Threading.Channels.ChannelUtilities.CreateInvalidCompletionException(parent._doneWriting)));
                            }
                            /*int*/ let count = parent._items.Count;
                            if (count === 0)
                            {
                                blockedReader = $.$stc.System.Threading.Channels.ChannelUtilities.TryDequeueAndReserveCompletionIfCancelable($.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T), $.$ref(() => parent._blockedReadersHead, ($v) => parent._blockedReadersHead = $v, $.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T)));
                                if (blockedReader === null)
                                {
                                    parent._items.EnqueueTail(item);
                                    waitingReadersHead = $.$stc.System.Threading.Channels.ChannelUtilities.TryReserveCompletionIfCancelable($.$stc.System.Threading.Channels.WaitingReadAsyncOperation, $.$ref(() => parent._waitingReadersHead, ($v) => parent._waitingReadersHead = $v, $.$stc.System.Threading.Channels.WaitingReadAsyncOperation));
                                    if (waitingReadersHead === null)
                                    {
                                        return new $.$$.System.Threading.Tasks.ValueTask();
                                    }
                                }
                            }
                            else if (count < parent._bufferedCapacity)
                            {
                                parent._items.EnqueueTail(item);
                                return new $.$$.System.Threading.Tasks.ValueTask();
                            }
                            else if (parent._mode === 0/*BoundedChannelFullMode.Wait*/)
                            {
                                if (!cancellationToken.CanBeCanceled)
                                {
                                    /*BlockedWriteAsyncOperation<T>*/ let singleton = this._writerSingleton;
                                    if (singleton.TryOwnAndReset())
                                    {
                                        singleton.Item$1 = item;
                                        $.$stc.System.Threading.Channels.ChannelUtilities.Enqueue($.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T), $.$ref(() => parent._blockedWritersHead, ($v) => parent._blockedWritersHead = $v, $.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T)), singleton);
                                        return singleton.ValueTask;
                                    }
                                }
                                /*var*/ let writer = (() =>
                                {
                                    //new $.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T)()
                                    const $t2 = $.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T);
                                    const $i2 = new $t2();
                                    $i2.$ctor$4(true, new $.$$.System.Threading.CancellationToken(), false, this._parent.CancellationCallbackDelegate);
                                    $i2.Item$1 = item;
                                    return $i2;
                                })();
                                $.$stc.System.Threading.Channels.ChannelUtilities.Enqueue($.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T), $.$ref(() => parent._blockedWritersHead, ($v) => parent._blockedWritersHead = $v, $.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T)), writer);
                                return writer.ValueTask;
                            }
                            else if (parent._mode === 3/*BoundedChannelFullMode.DropWrite*/)
                            {
                                $.$$.System.Threading.Monitor.Exit(parent.SyncObj);
                                releaseLock = false;
                                parent._itemDropped?.Invoke(item);
                                return new $.$$.System.Threading.Tasks.ValueTask();
                            }
                            else 
                            {
                                /*T*/ let droppedItem = parent._mode === 1/*BoundedChannelFullMode.DropNewest*/ ? parent._items.DequeueTail() : parent._items.DequeueHead();
                                parent._items.EnqueueTail(item);
                                $.$$.System.Threading.Monitor.Exit(parent.SyncObj);
                                releaseLock = false;
                                parent._itemDropped?.Invoke(droppedItem);
                                return new $.$$.System.Threading.Tasks.ValueTask();
                            }
                        }
                        finally
                        {
                            {
                                if (releaseLock)
                                {
                                    $.$$.System.Threading.Monitor.Exit(parent.SyncObj);
                                }
                            }
                        }
                        if (!(blockedReader === null))
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(waitingReadersHead === null, "waitingReadersHead is null");
                            blockedReader.DangerousSetResult(item);
                        }
                        else 
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(!(waitingReadersHead === null), "waitingReadersHead is not null");
                            $.$stc.System.Threading.Channels.ChannelUtilities.DangerousSetOperations($.$stc.System.Threading.Channels.WaitingReadAsyncOperation, $.$$.System.Boolean, waitingReadersHead, true);
                        }
                        return new $.$$.System.Threading.Tasks.ValueTask();
                    }
                    //--TRIMMABLE-BOUNDARY-END(64425820181)
                    
                    //--TRIMMABLE-BOUNDARY-START(42950983701)
                    /*int */ get ItemsCountForDebugger()
                    {
                        return this._parent._items.Count;
                    }
                    //--TRIMMABLE-BOUNDARY-END(42950983701)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476147221)
                    /*int */ get CapacityForDebugger()
                    {
                        return this._parent._bufferedCapacity;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21476147221)
                    
                    //--TRIMMABLE-BOUNDARY-START(47245950997)
                    /*IEnumerator<T> */ System$Threading$Channels$IDebugEnumerable$$$GetEnumerator()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(47245950997);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._parent._items.GetEnumerator();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(47245950997)
                    
                    static $h = 1310741;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42950983701),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(1310741)|0x900000000n),
        "f": 50331650
      },
      "n": "ItemsCountForDebugger",
      "d": 1310741,
      "h": Number(BigInt(1310741)|0xA00000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(42950983701),
//--TRIMMABLE-BOUNDARY-START(21476147221),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(1310741)|0x700000000n),
        "f": 50331650
      },
      "n": "CapacityForDebugger",
      "d": 1310741,
      "h": Number(BigInt(1310741)|0x500000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(21476147221)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(51540918293),
    {
      "r": 262145,
      "p": [
        {
          "n": "error",
          "p": 80019457
        }
      ],
      "n": "TryComplete",
      "d": 1310741,
      "h": Number(BigInt(1310741)|0xC00000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(51540918293),
//--TRIMMABLE-BOUNDARY-START(55835885589),
    {
      "r": 262145,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1507328
        }
      ],
      "n": "TryWrite",
      "d": 1310741,
      "h": Number(BigInt(1310741)|0xD00000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(55835885589),
//--TRIMMABLE-BOUNDARY-START(60130852885),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Boolean).$h,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "WaitToWriteAsync",
      "d": 1310741,
      "h": Number(BigInt(1310741)|0xE00000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(60130852885),
//--TRIMMABLE-BOUNDARY-START(64425820181),
    {
      "r": 180551681,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1507328
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "WriteAsync",
      "d": 1310741,
      "h": Number(BigInt(1310741)|0xF00000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(64425820181)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296278037),
    {
      "t": $.$stc.System.Threading.Channels.BoundedChannel$$(T).$h,
      "n": "_parent",
      "d": 1310741,
      "h": Number(BigInt(1310741)|0x100000000n),
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(4296278037),
//--TRIMMABLE-BOUNDARY-START(12886212629),
    {
      "t": $.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T).$h,
      "n": "_writerSingleton",
      "d": 1310741,
      "h": Number(BigInt(1310741)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886212629),
//--TRIMMABLE-BOUNDARY-START(8591245333),
    {
      "t": 3145749,
      "n": "_waiterSingleton",
      "d": 1310741,
      "h": Number(BigInt(1310741)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591245333)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181179925),
    {
      "p": [
        {
          "n": "parent",
          "p": $.$stc.System.Threading.Channels.BoundedChannel$$(T).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1310741,
      "h": Number(BigInt(1310741)|0x400000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(17181179925)
  ],
  "i": [$.$stc.System.Threading.Channels.IDebugEnumerable$$(T).$h
  ],
  "d": $.$stc.System.Threading.Channels.BoundedChannel$$(T).$h,
  "h": 1310741,
  "a": [
    {
      "t": 70385665,
      "c": 25840189441,
      "a": [
        {
          "v": "Items = {ItemsCountForDebugger}, Capacity = {CapacityForDebugger}",
          "t": 1310721
        }
      ]
    },
    {
      "t": 70713345,
      "c": 21545549825,
      "a": [
        {
          "v": $.$stc.System.Threading.Channels.DebugEnumeratorDebugView$$().$h,
          "t": 187760641
        }
      ]
    }
  ]
}; }
                    static get $b() { return $.$stc.System.Threading.Channels.ChannelWriter$$(T); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$stc.System.Threading.Channels.IDebugEnumerable$$(T) ]; }
                    static get $fullName() { return `System.Threading.Channels.BoundedChannel<${T?.$fullName}>.BoundedChannelWriter`; }
                }, $cls, ($v) => $cls.$_BoundedChannelWriter = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1310741)
            
            //--TRIMMABLE-BOUNDARY-START(120260263957)
            /*object */ get SyncObj()
            {
                return this._items;
            }
            //--TRIMMABLE-BOUNDARY-END(120260263957)
            
            //--TRIMMABLE-BOUNDARY-START(73015623701)
            /*Action<object?, CancellationToken>*/ CancellationCallbackDelegate$ = null;
            /*Action<object?, CancellationToken> */ get CancellationCallbackDelegate()
            {
                return this.CancellationCallbackDelegate$ ??= new ($.$$.System.Action$$$($.$$.System.Object, $.$$.System.Threading.CancellationToken))().$ctor(this,  (/*state*/ state, /*cancellationToken*/ cancellationToken) =>
                {
                    /*AsyncOperation*/ let op = $.$cast(state, $.$stc.System.Threading.Channels.AsyncOperation);
                    if (op.TrySetCanceled(cancellationToken))
                    {
                        $.$stc.System.Threading.Channels.ChannelUtilities.UnsafeQueueUserWorkItem($.$$.System.Collections.Generic.KeyValuePair$$$($.$stc.System.Threading.Channels.BoundedChannel$$(T), $.$stc.System.Threading.Channels.AsyncOperation), new ($.$$.System.Action$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$stc.System.Threading.Channels.BoundedChannel$$(T), $.$stc.System.Threading.Channels.AsyncOperation)))().$ctor($.$stc.System.Threading.Channels.BoundedChannel$$(T), /*static*/ (/*state*/ state) =>
                        {
                            //lock
                            try
                            {
                                $.$$.System.Threading.Monitor.Enter$1(state.Key.SyncObj)
                                {
                                    //switch (state.Value)
                                    let $switch1 = state.Value;
                                    {
                                        let blockedReader;
                                        let blockedWriter;
                                        let waitingReader;
                                        let waitingWriter;
                                        $switchJumpStart1: 
                                        //case BlockedReadAsyncOperation<T> blockedReader:
                                        if ($.$is($switch1, $.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T), { set $v(v){ blockedReader = v; } }))
                                        {
                                            $.$stc.System.Threading.Channels.ChannelUtilities.Remove($.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T), $.$ref(() => state.Key._blockedReadersHead, ($v) => state.Key._blockedReadersHead = $v, $.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T)), blockedReader);
                                        }
                                        //case BlockedWriteAsyncOperation<T> blockedWriter:
                                        else if ($.$is($switch1, $.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T), { set $v(v){ blockedWriter = v; } }))
                                        {
                                            $.$stc.System.Threading.Channels.ChannelUtilities.Remove($.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T), $.$ref(() => state.Key._blockedWritersHead, ($v) => state.Key._blockedWritersHead = $v, $.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T)), blockedWriter);
                                        }
                                        //case WaitingReadAsyncOperation waitingReader:
                                        else if ($.$is($switch1, $.$stc.System.Threading.Channels.WaitingReadAsyncOperation, { set $v(v){ waitingReader = v; } }))
                                        {
                                            $.$stc.System.Threading.Channels.ChannelUtilities.Remove($.$stc.System.Threading.Channels.WaitingReadAsyncOperation, $.$ref(() => state.Key._waitingReadersHead, ($v) => state.Key._waitingReadersHead = $v, $.$stc.System.Threading.Channels.WaitingReadAsyncOperation), waitingReader);
                                        }
                                        //case WaitingWriteAsyncOperation waitingWriter:
                                        else if ($.$is($switch1, $.$stc.System.Threading.Channels.WaitingWriteAsyncOperation, { set $v(v){ waitingWriter = v; } }))
                                        {
                                            $.$stc.System.Threading.Channels.ChannelUtilities.Remove($.$stc.System.Threading.Channels.WaitingWriteAsyncOperation, $.$ref(() => state.Key._waitingWritersHead, ($v) => state.Key._waitingWritersHead = $v, $.$stc.System.Threading.Channels.WaitingWriteAsyncOperation), waitingWriter);
                                        }
                                        //default
                                        else
                                        {
                                            $.$$.System.Diagnostics.Debug.Fail$1(`Unexpected operation: ${$.$$.System.Object.ToString.call(state.Value)}`);
                                        }
                                    }
                                }
                            }
                            finally
                            {
                                $.$$.System.Threading.Monitor.Exit(state.Key.SyncObj)
                            }
                        }, {
  "r": 65537,
  "p": [
    {
      "n": "state",
      "p": $.$$.System.Collections.Generic.KeyValuePair$$$($.$stc.System.Threading.Channels.BoundedChannel$$(T), $.$stc.System.Threading.Channels.AsyncOperation).$h
    }
  ],
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825826
}), new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$stc.System.Threading.Channels.BoundedChannel$$(T), $.$stc.System.Threading.Channels.AsyncOperation))().$ctor$3(this, op));
                    }
                }, {
  "r": 65537,
  "p": [
    {
      "n": "state",
      "p": 131073
    },
    {
      "n": "cancellationToken",
      "p": 170065921
    }
  ],
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825794
});
            }
            //--TRIMMABLE-BOUNDARY-END(73015623701)
            
            //--TRIMMABLE-BOUNDARY-START(68720656405)
            /*void */ AssertInvariants()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720656405);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(!(this.SyncObj === null), "The sync obj must not be null.");
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Threading.Monitor.IsEntered(this.SyncObj), "Invariants can only be validated while holding the lock.");
                if (!this._items.IsEmpty)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(this._blockedReadersHead === null, "There are items available, so there shouldn't be any blocked readers.");
                    $.$$.System.Diagnostics.Debug.Assert$2(this._waitingReadersHead === null, "There are items available, so there shouldn't be any waiting readers.");
                }
                if (this._items.Count < this._bufferedCapacity)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(this._blockedWritersHead === null, "There's space available, so there shouldn't be any blocked writers.");
                    $.$$.System.Diagnostics.Debug.Assert$2(this._waitingWritersHead === null, "There's space available, so there shouldn't be any waiting writers.");
                }
                if (!(this._blockedReadersHead === null))
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(this._items.IsEmpty, "There shouldn't be queued items if there's a blocked reader.");
                    $.$$.System.Diagnostics.Debug.Assert$2(this._blockedWritersHead === null, "There shouldn't be any blocked writer if there's a blocked reader.");
                }
                if (!(this._blockedWritersHead === null))
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(this._items.Count === this._bufferedCapacity, "We should have a full buffer if there's a blocked writer.");
                    $.$$.System.Diagnostics.Debug.Assert$2(this._blockedReadersHead === null, "There shouldn't be any blocked readers if there's a blocked writer.");
                }
                if (this._completion.Task.IsCompleted)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(!(this._doneWriting === null), "We can only complete if we're done writing.");
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68720656405)
            
            //--TRIMMABLE-BOUNDARY-START(115965296661)
            /*int */ get ItemsCountForDebugger()
            {
                return this._items.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(115965296661)
            
            //--TRIMMABLE-BOUNDARY-START(77310590997)
            /*bool */ get ChannelIsClosedForDebugger()
            {
                return !(this._doneWriting === null);
            }
            //--TRIMMABLE-BOUNDARY-END(77310590997)
            
            //--TRIMMABLE-BOUNDARY-START(124555231253)
            /*IEnumerator<T> */ System$Threading$Channels$IDebugEnumerable$$$GetEnumerator()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(124555231253);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._items.GetEnumerator();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(124555231253)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(30065950741)
                this._items = new ($.$stc.System.Collections.Generic.Deque$$(T))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(30065950741)
                
            }
            static $h = 1179669;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(120260263957),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1A00000000n),
        "f": 50331650
      },
      "n": "SyncObj",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1C00000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(120260263957),
//--TRIMMABLE-BOUNDARY-START(73015623701),
    {
      "p": $.$$.System.Action$$$($.$$.System.Object, $.$$.System.Threading.CancellationToken).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1400000000n),
        "f": 50331650
      },
      "n": "CancellationCallbackDelegate",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1100000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(73015623701),
//--TRIMMABLE-BOUNDARY-START(115965296661),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1800000000n),
        "f": 50331650
      },
      "n": "ItemsCountForDebugger",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1B00000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(115965296661),
//--TRIMMABLE-BOUNDARY-START(77310590997),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1600000000n),
        "f": 50331650
      },
      "n": "ChannelIsClosedForDebugger",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1200000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(77310590997)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(68720656405),
    {
      "r": 65537,
      "n": "AssertInvariants",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1000000000n),
      "f": 16777218,
      "a": [
        {
          "t": 68747265,
          "c": 8658681857,
          "a": [
            {
              "v": "DEBUG",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(68720656405)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(34360918037),
    {
      "t": 1376277,
      "n": "_mode",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34360918037),
//--TRIMMABLE-BOUNDARY-START(25770983445),
    {
      "t": $.$$.System.Action$$(T).$h,
      "n": "_itemDropped",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770983445),
//--TRIMMABLE-BOUNDARY-START(17181048853),
    {
      "t": 178782209,
      "n": "_completion",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181048853),
//--TRIMMABLE-BOUNDARY-START(12886081557),
    {
      "t": 655361,
      "n": "_bufferedCapacity",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886081557),
//--TRIMMABLE-BOUNDARY-START(30065950741),
    {
      "t": $.$stc.System.Collections.Generic.Deque$$(T).$h,
      "n": "_items",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30065950741),
//--TRIMMABLE-BOUNDARY-START(4296146965),
    {
      "t": $.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T).$h,
      "n": "_blockedReadersHead",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296146965),
//--TRIMMABLE-BOUNDARY-START(8591114261),
    {
      "t": $.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T).$h,
      "n": "_blockedWritersHead",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591114261),
//--TRIMMABLE-BOUNDARY-START(42950852629),
    {
      "t": 3080213,
      "n": "_waitingReadersHead",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(42950852629),
//--TRIMMABLE-BOUNDARY-START(47245819925),
    {
      "t": 3145749,
      "n": "_waitingWritersHead",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(47245819925),
//--TRIMMABLE-BOUNDARY-START(38655885333),
    {
      "t": 262145,
      "n": "_runContinuationsAsynchronously",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38655885333),
//--TRIMMABLE-BOUNDARY-START(21476016149),
    {
      "t": 80019457,
      "n": "_doneWriting",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21476016149)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(64425689109),
    {
      "p": [
        {
          "n": "bufferedCapacity",
          "p": 655361
        },
        {
          "n": "mode",
          "p": 1376277
        },
        {
          "n": "runContinuationsAsynchronously",
          "p": 262145
        },
        {
          "n": "itemDropped",
          "p": $.$$.System.Action$$(T).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xF00000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(64425689109)
  ],
  "i": [$.$stc.System.Threading.Channels.IDebugEnumerable$$(T).$h
  ],
  "g": [T?.$h??1507328
  ],
  "j": [1245205,1310741
  ],
  "r": 1,
  "h": this.$h,
  "a": [
    {
      "t": 70385665,
      "c": 25840189441,
      "a": [
        {
          "v": "Items = {ItemsCountForDebugger}, Capacity = {_bufferedCapacity}, Mode = {_mode}, Closed = {ChannelIsClosedForDebugger}",
          "t": 1310721
        }
      ]
    },
    {
      "t": 70713345,
      "c": 21545549825,
      "a": [
        {
          "v": $.$stc.System.Threading.Channels.DebugEnumeratorDebugView$$().$h,
          "t": 187760641
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$stc.System.Threading.Channels.Channel$$(T); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stc.System.Threading.Channels.IDebugEnumerable$$(T) ]; }
            static get $fullName() { return `System.Threading.Channels.BoundedChannel<${T?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1179669)
        
        
        //--TRIMMABLE-BOUNDARY-START(2555925)
        $asm.$cls("$stc.System.Threading.Channels.UnboundedChannel<>", (T) => $asm.$gt("$stc.System.Threading.Channels.UnboundedChannel<>", [T], ($self) => class UnboundedChannel$$ extends $.$stc.System.Threading.Channels.Channel$$(T)
        {
            //--TRIMMABLE-BOUNDARY-START(8592490517)
            /*TaskCompletionSource*/ _completion = null;
            //--TRIMMABLE-BOUNDARY-END(8592490517)
            
            //--TRIMMABLE-BOUNDARY-START(17182425109)
            /*ConcurrentQueue<T>*/ _items = null;
            //--TRIMMABLE-BOUNDARY-END(17182425109)
            
            //--TRIMMABLE-BOUNDARY-START(21477392405)
            /*bool*/ _runContinuationsAsynchronously = false;
            //--TRIMMABLE-BOUNDARY-END(21477392405)
            
            //--TRIMMABLE-BOUNDARY-START(4297523221)
            /*BlockedReadAsyncOperation<T>?*/ _blockedReadersHead = null;
            //--TRIMMABLE-BOUNDARY-END(4297523221)
            
            //--TRIMMABLE-BOUNDARY-START(25772359701)
            /*WaitingReadAsyncOperation?*/ _waitingReadersHead = null;
            //--TRIMMABLE-BOUNDARY-END(25772359701)
            
            //--TRIMMABLE-BOUNDARY-START(12887457813)
            /*Exception?*/ _doneWriting = null;
            //--TRIMMABLE-BOUNDARY-END(12887457813)
            
            //--TRIMMABLE-BOUNDARY-START(42952228885)
            $ctor$3(/*bool*/ runContinuationsAsynchronously)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42952228885);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._runContinuationsAsynchronously = runContinuationsAsynchronously;
                    this._completion = new $.$$.System.Threading.Tasks.TaskCompletionSource().$ctor$4(runContinuationsAsynchronously ? 64/*TaskCreationOptions.RunContinuationsAsynchronously*/ : 0/*TaskCreationOptions.None*/);
                    this.Reader = new ($.$stc.System.Threading.Channels.UnboundedChannel$$(T).UnboundedChannelReader)().$ctor$2(this);
                    this.Writer = new ($.$stc.System.Threading.Channels.UnboundedChannel$$(T).UnboundedChannelWriter)().$ctor$2(this);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42952228885)
            
            //--TRIMMABLE-BOUNDARY-START(2621461)
            static $_UnboundedChannelReader;
            static get UnboundedChannelReader()
            {
                let $cls = $.$stc.System.Threading.Channels.UnboundedChannel$$(T);
                return $cls.$_UnboundedChannelReader ??= $asm.$ncls("$stc.System.Threading.Channels.UnboundedChannel$$.UnboundedChannelReader", ($self) => class UnboundedChannelReader extends $.$stc.System.Threading.Channels.ChannelReader$$(T)
                {
                    //--TRIMMABLE-BOUNDARY-START(4297588757)
                    /*UnboundedChannel<T>*/ _parent = null;
                    //--TRIMMABLE-BOUNDARY-END(4297588757)
                    
                    //--TRIMMABLE-BOUNDARY-START(8592556053)
                    /*BlockedReadAsyncOperation<T>*/ _readerSingleton = null;
                    //--TRIMMABLE-BOUNDARY-END(8592556053)
                    
                    //--TRIMMABLE-BOUNDARY-START(12887523349)
                    /*WaitingReadAsyncOperation*/ _waiterSingleton = null;
                    //--TRIMMABLE-BOUNDARY-END(12887523349)
                    
                    //--TRIMMABLE-BOUNDARY-START(17182490645)
                    $ctor$2(/*UnboundedChannel<T>*/ parent)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(17182490645);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._parent = parent;
                            this._readerSingleton = new ($.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T))().$ctor$4(parent._runContinuationsAsynchronously, new $.$$.System.Threading.CancellationToken(), true, null);
                            this._waiterSingleton = new $.$stc.System.Threading.Channels.WaitingReadAsyncOperation().$ctor$4(parent._runContinuationsAsynchronously, new $.$$.System.Threading.CancellationToken(), true, null);
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17182490645)
                    
                    //--TRIMMABLE-BOUNDARY-START(34362359829)
                    /*Task */ get Completion()
                    {
                        return this._parent._completion.Task;
                    }
                    //--TRIMMABLE-BOUNDARY-END(34362359829)
                    
                    //--TRIMMABLE-BOUNDARY-START(21477457941)
                    /*bool */ get CanCount()
                    {
                        return true;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21477457941)
                    
                    //--TRIMMABLE-BOUNDARY-START(25772425237)
                    /*bool */ get CanPeek()
                    {
                        return true;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25772425237)
                    
                    //--TRIMMABLE-BOUNDARY-START(38657327125)
                    /*int */ get Count()
                    {
                        return this._parent._items.Count;
                    }
                    //--TRIMMABLE-BOUNDARY-END(38657327125)
                    
                    //--TRIMMABLE-BOUNDARY-START(77312032789)
                    /*ValueTask<T> */ ReadAsync(/*CancellationToken*/ cancellationToken)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(77312032789);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (cancellationToken.IsCancellationRequested)
                        {
                            return new ($.$$.System.Threading.Tasks.ValueTask$$(T))().$ctor$5($.$$.System.Threading.Tasks.Task.FromCanceled$3(T, cancellationToken));
                        }
                        /*UnboundedChannel<T>*/ let parent = this._parent;
                        /*T?*/ let item;
                        if (parent._items.TryDequeue($.$ref(() => item, ($v) => item = $v, T)))
                        {
                            $.$stc.System.Threading.Channels.UnboundedChannel$$(T).UnboundedChannelReader.CompleteIfDone(parent);
                            return new ($.$$.System.Threading.Tasks.ValueTask$$(T))().$ctor$6(item);
                        }
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(parent.SyncObj)
                            {
                                parent.AssertInvariants();
                                if (parent._items.TryDequeue($.$ref(() => item, ($v) => item = $v, T)))
                                {
                                    $.$stc.System.Threading.Channels.UnboundedChannel$$(T).UnboundedChannelReader.CompleteIfDone(parent);
                                    return new ($.$$.System.Threading.Tasks.ValueTask$$(T))().$ctor$6(item);
                                }
                                if (!(parent._doneWriting === null))
                                {
                                    return $.$stc.System.Threading.Channels.ChannelUtilities.GetInvalidCompletionValueTask(T, parent._doneWriting);
                                }
                                /*BlockedReadAsyncOperation<T>*/ let reader = !cancellationToken.CanBeCanceled && this._readerSingleton.TryOwnAndReset() ? this._readerSingleton : new ($.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T))().$ctor$4(parent._runContinuationsAsynchronously, new $.$$.System.Threading.CancellationToken(), false, this._parent.CancellationCallbackDelegate);
                                $.$stc.System.Threading.Channels.ChannelUtilities.Enqueue($.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T), $.$ref(() => parent._blockedReadersHead, ($v) => parent._blockedReadersHead = $v, $.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T)), reader);
                                return reader.ValueTaskOfT;
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(parent.SyncObj)
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(77312032789)
                    
                    //--TRIMMABLE-BOUNDARY-START(90196934677)
                    /*bool */ TryRead(/*out T*/ item)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(90196934677);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*UnboundedChannel<T>*/ let parent = this._parent;
                        if (parent._items.TryDequeue(item))
                        {
                            $.$stc.System.Threading.Channels.UnboundedChannel$$(T).UnboundedChannelReader.CompleteIfDone(parent);
                            return true;
                        }
                        item.$v = $.$default(T);
                        return false;
                    }
                    //--TRIMMABLE-BOUNDARY-END(90196934677)
                    
                    //--TRIMMABLE-BOUNDARY-START(85901967381)
                    /*bool */ TryPeek(/*out T*/ item)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(85901967381);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._parent._items.TryPeek$1(item);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(85901967381)
                    
                    //--TRIMMABLE-BOUNDARY-START(30067392533)
                    static /*void */ CompleteIfDone(/*UnboundedChannel<T>*/ parent)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(30067392533);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (!(parent._doneWriting === null) && parent._items.IsEmpty)
                        {
                            $.$stc.System.Threading.Channels.ChannelUtilities.Complete(parent._completion, parent._doneWriting);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(30067392533)
                    
                    //--TRIMMABLE-BOUNDARY-START(94491901973)
                    /*ValueTask<bool> */ WaitToReadAsync(/*CancellationToken*/ cancellationToken)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(94491901973);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (cancellationToken.IsCancellationRequested)
                        {
                            return new ($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Boolean))().$ctor$5($.$$.System.Threading.Tasks.Task.FromCanceled$3($.$$.System.Boolean, cancellationToken));
                        }
                        if (!this._parent._items.IsEmpty)
                        {
                            return new ($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Boolean))().$ctor$6(true);
                        }
                        /*UnboundedChannel<T>*/ let parent = this._parent;
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(parent.SyncObj)
                            {
                                parent.AssertInvariants();
                                if (!parent._items.IsEmpty)
                                {
                                    return new ($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Boolean))().$ctor$6(true);
                                }
                                if (!(parent._doneWriting === null))
                                {
                                    return parent._doneWriting !== $.$stc.System.Threading.Channels.ChannelUtilities.s_doneWritingSentinel ? new ($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Boolean))().$ctor$5($.$$.System.Threading.Tasks.Task.FromException$1($.$$.System.Boolean, parent._doneWriting)) : new ($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Boolean))();
                                }
                                /*WaitingReadAsyncOperation*/ let waiter = !cancellationToken.CanBeCanceled && this._waiterSingleton.TryOwnAndReset() ? this._waiterSingleton : new $.$stc.System.Threading.Channels.WaitingReadAsyncOperation().$ctor$4(parent._runContinuationsAsynchronously, new $.$$.System.Threading.CancellationToken(), false, this._parent.CancellationCallbackDelegate);
                                $.$stc.System.Threading.Channels.ChannelUtilities.Enqueue($.$stc.System.Threading.Channels.WaitingReadAsyncOperation, $.$ref(() => parent._waitingReadersHead, ($v) => parent._waitingReadersHead = $v, $.$stc.System.Threading.Channels.WaitingReadAsyncOperation), waiter);
                                return waiter.ValueTaskOfT;
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(parent.SyncObj)
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(94491901973)
                    
                    //--TRIMMABLE-BOUNDARY-START(81607000085)
                    /*IEnumerator<T> */ System$Threading$Channels$IDebugEnumerable$$$GetEnumerator()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(81607000085);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._parent._items.GetEnumerator();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(81607000085)
                    
                    static $h = 2621461;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34362359829),
    {
      "p": 177668097,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(2621461)|0xF00000000n),
        "f": 50364417
      },
      "n": "Completion",
      "d": 2621461,
      "h": Number(BigInt(2621461)|0x800000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34362359829),
//--TRIMMABLE-BOUNDARY-START(21477457941),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(2621461)|0xB00000000n),
        "f": 50364417
      },
      "n": "CanCount",
      "d": 2621461,
      "h": Number(BigInt(2621461)|0x500000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21477457941),
//--TRIMMABLE-BOUNDARY-START(25772425237),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(2621461)|0xD00000000n),
        "f": 50364417
      },
      "n": "CanPeek",
      "d": 2621461,
      "h": Number(BigInt(2621461)|0x600000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(25772425237),
//--TRIMMABLE-BOUNDARY-START(38657327125),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(2621461)|0x1100000000n),
        "f": 50364417
      },
      "n": "Count",
      "d": 2621461,
      "h": Number(BigInt(2621461)|0x900000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(38657327125)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(77312032789),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$(T).$h,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "ReadAsync",
      "d": 2621461,
      "h": Number(BigInt(2621461)|0x1200000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(77312032789),
//--TRIMMABLE-BOUNDARY-START(90196934677),
    {
      "r": 262145,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1507328,
          "f": 2
        }
      ],
      "n": "TryRead",
      "d": 2621461,
      "h": Number(BigInt(2621461)|0x1500000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(90196934677),
//--TRIMMABLE-BOUNDARY-START(85901967381),
    {
      "r": 262145,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1507328,
          "f": 2
        }
      ],
      "n": "TryPeek",
      "d": 2621461,
      "h": Number(BigInt(2621461)|0x1400000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(85901967381),
//--TRIMMABLE-BOUNDARY-START(30067392533),
    {
      "r": 65537,
      "p": [
        {
          "n": "parent",
          "p": $.$stc.System.Threading.Channels.UnboundedChannel$$(T).$h
        }
      ],
      "n": "CompleteIfDone",
      "d": 2621461,
      "h": Number(BigInt(2621461)|0x700000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(30067392533),
//--TRIMMABLE-BOUNDARY-START(94491901973),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Boolean).$h,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "WaitToReadAsync",
      "d": 2621461,
      "h": Number(BigInt(2621461)|0x1600000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(94491901973)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297588757),
    {
      "t": $.$stc.System.Threading.Channels.UnboundedChannel$$(T).$h,
      "n": "_parent",
      "d": 2621461,
      "h": Number(BigInt(2621461)|0x100000000n),
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(4297588757),
//--TRIMMABLE-BOUNDARY-START(8592556053),
    {
      "t": $.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T).$h,
      "n": "_readerSingleton",
      "d": 2621461,
      "h": Number(BigInt(2621461)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8592556053),
//--TRIMMABLE-BOUNDARY-START(12887523349),
    {
      "t": 3080213,
      "n": "_waiterSingleton",
      "d": 2621461,
      "h": Number(BigInt(2621461)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12887523349)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17182490645),
    {
      "p": [
        {
          "n": "parent",
          "p": $.$stc.System.Threading.Channels.UnboundedChannel$$(T).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2621461,
      "h": Number(BigInt(2621461)|0x400000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(17182490645)
  ],
  "i": [$.$stc.System.Threading.Channels.IDebugEnumerable$$(T).$h
  ],
  "d": $.$stc.System.Threading.Channels.UnboundedChannel$$(T).$h,
  "h": 2621461,
  "a": [
    {
      "t": 70385665,
      "c": 25840189441,
      "a": [
        {
          "v": "Items = {Count}",
          "t": 1310721
        }
      ]
    },
    {
      "t": 70713345,
      "c": 21545549825,
      "a": [
        {
          "v": $.$stc.System.Threading.Channels.DebugEnumeratorDebugView$$().$h,
          "t": 187760641
        }
      ]
    }
  ]
}; }
                    static get $b() { return $.$stc.System.Threading.Channels.ChannelReader$$(T); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$stc.System.Threading.Channels.IDebugEnumerable$$(T) ]; }
                    static get $fullName() { return `System.Threading.Channels.UnboundedChannel<${T?.$fullName}>.UnboundedChannelReader`; }
                }, $cls, ($v) => $cls.$_UnboundedChannelReader = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2621461)
            
            //--TRIMMABLE-BOUNDARY-START(2686997)
            static $_UnboundedChannelWriter;
            static get UnboundedChannelWriter()
            {
                let $cls = $.$stc.System.Threading.Channels.UnboundedChannel$$(T);
                return $cls.$_UnboundedChannelWriter ??= $asm.$ncls("$stc.System.Threading.Channels.UnboundedChannel$$.UnboundedChannelWriter", ($self) => class UnboundedChannelWriter extends $.$stc.System.Threading.Channels.ChannelWriter$$(T)
                {
                    //--TRIMMABLE-BOUNDARY-START(4297654293)
                    /*UnboundedChannel<T>*/ _parent = null;
                    //--TRIMMABLE-BOUNDARY-END(4297654293)
                    
                    //--TRIMMABLE-BOUNDARY-START(8592621589)
                    $ctor$2(/*UnboundedChannel<T>*/ parent)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8592621589);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._parent = parent;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8592621589)
                    
                    //--TRIMMABLE-BOUNDARY-START(30067458069)
                    /*bool */ TryComplete(/*Exception?*/ error)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(30067458069);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*UnboundedChannel<T>*/ let parent = this._parent;
                        /*BlockedReadAsyncOperation<T>?*/ let blockedReadersHead;
                        /*WaitingReadAsyncOperation?*/ let waitingReadersHead;
                        /*bool*/ let completeTask;
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(parent.SyncObj)
                            {
                                parent.AssertInvariants();
                                if (!(parent._doneWriting === null))
                                {
                                    return false;
                                }
                                parent._doneWriting = error ?? $.$stc.System.Threading.Channels.ChannelUtilities.s_doneWritingSentinel;
                                completeTask = parent._items.IsEmpty;
                                blockedReadersHead = parent._blockedReadersHead;
                                waitingReadersHead = parent._waitingReadersHead;
                                parent._blockedReadersHead = null;
                                parent._waitingReadersHead = null;
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(parent.SyncObj)
                        }
                        if (completeTask)
                        {
                            $.$stc.System.Threading.Channels.ChannelUtilities.Complete(parent._completion, error);
                        }
                        $.$stc.System.Threading.Channels.ChannelUtilities.FailOperations($.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T), blockedReadersHead, $.$stc.System.Threading.Channels.ChannelUtilities.CreateInvalidCompletionException(error));
                        $.$stc.System.Threading.Channels.ChannelUtilities.SetOrFailOperations($.$stc.System.Threading.Channels.WaitingReadAsyncOperation, $.$$.System.Boolean, waitingReadersHead, false, error);
                        return true;
                    }
                    //--TRIMMABLE-BOUNDARY-END(30067458069)
                    
                    //--TRIMMABLE-BOUNDARY-START(34362425365)
                    /*bool */ TryWrite(/*T*/ item)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34362425365);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*UnboundedChannel<T>*/ let parent = this._parent;
                        /*BlockedReadAsyncOperation<T>?*/ let blockedReader = null;
                        /*WaitingReadAsyncOperation?*/ let waitingReadersHead = null;
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(parent.SyncObj)
                            {
                                parent.AssertInvariants();
                                if (!(parent._doneWriting === null))
                                {
                                    return false;
                                }
                                blockedReader = $.$stc.System.Threading.Channels.ChannelUtilities.TryDequeueAndReserveCompletionIfCancelable($.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T), $.$ref(() => parent._blockedReadersHead, ($v) => parent._blockedReadersHead = $v, $.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T)));
                                if (blockedReader === null)
                                {
                                    parent._items.Enqueue(item);
                                    waitingReadersHead = $.$stc.System.Threading.Channels.ChannelUtilities.TryReserveCompletionIfCancelable($.$stc.System.Threading.Channels.WaitingReadAsyncOperation, $.$ref(() => parent._waitingReadersHead, ($v) => parent._waitingReadersHead = $v, $.$stc.System.Threading.Channels.WaitingReadAsyncOperation));
                                }
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(parent.SyncObj)
                        }
                        if (!(blockedReader === null))
                        {
                            blockedReader.DangerousSetResult(item);
                        }
                        else if (!(waitingReadersHead === null))
                        {
                            $.$stc.System.Threading.Channels.ChannelUtilities.DangerousSetOperations($.$stc.System.Threading.Channels.WaitingReadAsyncOperation, $.$$.System.Boolean, waitingReadersHead, true);
                        }
                        return true;
                    }
                    //--TRIMMABLE-BOUNDARY-END(34362425365)
                    
                    //--TRIMMABLE-BOUNDARY-START(38657392661)
                    /*ValueTask<bool> */ WaitToWriteAsync(/*CancellationToken*/ cancellationToken)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(38657392661);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*Exception?*/ let doneWriting = this._parent._doneWriting;
                        return cancellationToken.IsCancellationRequested ? new ($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Boolean))().$ctor$5($.$$.System.Threading.Tasks.Task.FromCanceled$3($.$$.System.Boolean, cancellationToken)) : doneWriting === null ? new ($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Boolean))().$ctor$6(true) : doneWriting !== $.$stc.System.Threading.Channels.ChannelUtilities.s_doneWritingSentinel ? new ($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Boolean))().$ctor$5($.$$.System.Threading.Tasks.Task.FromException$1($.$$.System.Boolean, doneWriting)) : new ($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Boolean))();
                    }
                    //--TRIMMABLE-BOUNDARY-END(38657392661)
                    
                    //--TRIMMABLE-BOUNDARY-START(42952359957)
                    /*ValueTask */ WriteAsync(/*T*/ item, /*CancellationToken*/ cancellationToken)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(42952359957);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return cancellationToken.IsCancellationRequested ? new $.$$.System.Threading.Tasks.ValueTask().$ctor$5($.$$.System.Threading.Tasks.Task.FromCanceled$1(cancellationToken)) : this.TryWrite(item) ? new $.$$.System.Threading.Tasks.ValueTask() : new $.$$.System.Threading.Tasks.ValueTask().$ctor$5($.$$.System.Threading.Tasks.Task.FromException($.$stc.System.Threading.Channels.ChannelUtilities.CreateInvalidCompletionException(this._parent._doneWriting)));
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(42952359957)
                    
                    //--TRIMMABLE-BOUNDARY-START(21477523477)
                    /*int */ get ItemsCountForDebugger()
                    {
                        return this._parent._items.Count;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21477523477)
                    
                    //--TRIMMABLE-BOUNDARY-START(25772490773)
                    /*IEnumerator<T> */ System$Threading$Channels$IDebugEnumerable$$$GetEnumerator()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(25772490773);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._parent._items.GetEnumerator();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(25772490773)
                    
                    static $h = 2686997;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21477523477),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(2686997)|0x400000000n),
        "f": 50331650
      },
      "n": "ItemsCountForDebugger",
      "d": 2686997,
      "h": Number(BigInt(2686997)|0x500000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(21477523477)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30067458069),
    {
      "r": 262145,
      "p": [
        {
          "n": "error",
          "p": 80019457
        }
      ],
      "n": "TryComplete",
      "d": 2686997,
      "h": Number(BigInt(2686997)|0x700000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30067458069),
//--TRIMMABLE-BOUNDARY-START(34362425365),
    {
      "r": 262145,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1507328
        }
      ],
      "n": "TryWrite",
      "d": 2686997,
      "h": Number(BigInt(2686997)|0x800000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34362425365),
//--TRIMMABLE-BOUNDARY-START(38657392661),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Boolean).$h,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "WaitToWriteAsync",
      "d": 2686997,
      "h": Number(BigInt(2686997)|0x900000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38657392661),
//--TRIMMABLE-BOUNDARY-START(42952359957),
    {
      "r": 180551681,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1507328
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "WriteAsync",
      "d": 2686997,
      "h": Number(BigInt(2686997)|0xA00000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(42952359957)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297654293),
    {
      "t": $.$stc.System.Threading.Channels.UnboundedChannel$$(T).$h,
      "n": "_parent",
      "d": 2686997,
      "h": Number(BigInt(2686997)|0x100000000n),
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(4297654293)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592621589),
    {
      "p": [
        {
          "n": "parent",
          "p": $.$stc.System.Threading.Channels.UnboundedChannel$$(T).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2686997,
      "h": Number(BigInt(2686997)|0x200000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(8592621589)
  ],
  "i": [$.$stc.System.Threading.Channels.IDebugEnumerable$$(T).$h
  ],
  "d": $.$stc.System.Threading.Channels.UnboundedChannel$$(T).$h,
  "h": 2686997,
  "a": [
    {
      "t": 70385665,
      "c": 25840189441,
      "a": [
        {
          "v": "Items = {ItemsCountForDebugger}",
          "t": 1310721
        }
      ]
    },
    {
      "t": 70713345,
      "c": 21545549825,
      "a": [
        {
          "v": $.$stc.System.Threading.Channels.DebugEnumeratorDebugView$$().$h,
          "t": 187760641
        }
      ]
    }
  ]
}; }
                    static get $b() { return $.$stc.System.Threading.Channels.ChannelWriter$$(T); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$stc.System.Threading.Channels.IDebugEnumerable$$(T) ]; }
                    static get $fullName() { return `System.Threading.Channels.UnboundedChannel<${T?.$fullName}>.UnboundedChannelWriter`; }
                }, $cls, ($v) => $cls.$_UnboundedChannelWriter = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2686997)
            
            //--TRIMMABLE-BOUNDARY-START(98786803733)
            /*object */ get SyncObj()
            {
                return this._items;
            }
            //--TRIMMABLE-BOUNDARY-END(98786803733)
            
            //--TRIMMABLE-BOUNDARY-START(51542163477)
            /*Action<object?, CancellationToken>*/ CancellationCallbackDelegate$ = null;
            /*Action<object?, CancellationToken> */ get CancellationCallbackDelegate()
            {
                return this.CancellationCallbackDelegate$ ??= new ($.$$.System.Action$$$($.$$.System.Object, $.$$.System.Threading.CancellationToken))().$ctor(this,  (/*state*/ state, /*cancellationToken*/ cancellationToken) =>
                {
                    /*AsyncOperation*/ let op = $.$cast(state, $.$stc.System.Threading.Channels.AsyncOperation);
                    if (op.TrySetCanceled(cancellationToken))
                    {
                        $.$stc.System.Threading.Channels.ChannelUtilities.UnsafeQueueUserWorkItem($.$$.System.Collections.Generic.KeyValuePair$$$($.$stc.System.Threading.Channels.UnboundedChannel$$(T), $.$stc.System.Threading.Channels.AsyncOperation), new ($.$$.System.Action$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$stc.System.Threading.Channels.UnboundedChannel$$(T), $.$stc.System.Threading.Channels.AsyncOperation)))().$ctor($.$stc.System.Threading.Channels.UnboundedChannel$$(T), /*static*/ (/**/ state) =>
                        {
                            //lock
                            try
                            {
                                $.$$.System.Threading.Monitor.Enter$1(state.Key.SyncObj)
                                {
                                    //switch (state.Value)
                                    let $switch1 = state.Value;
                                    {
                                        let blockedReader;
                                        let waitingReader;
                                        $switchJumpStart1: 
                                        //case BlockedReadAsyncOperation<T> blockedReader:
                                        if ($.$is($switch1, $.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T), { set $v(v){ blockedReader = v; } }))
                                        {
                                            $.$stc.System.Threading.Channels.ChannelUtilities.Remove($.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T), $.$ref(() => state.Key._blockedReadersHead, ($v) => state.Key._blockedReadersHead = $v, $.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T)), blockedReader);
                                        }
                                        //case WaitingReadAsyncOperation waitingReader:
                                        else if ($.$is($switch1, $.$stc.System.Threading.Channels.WaitingReadAsyncOperation, { set $v(v){ waitingReader = v; } }))
                                        {
                                            $.$stc.System.Threading.Channels.ChannelUtilities.Remove($.$stc.System.Threading.Channels.WaitingReadAsyncOperation, $.$ref(() => state.Key._waitingReadersHead, ($v) => state.Key._waitingReadersHead = $v, $.$stc.System.Threading.Channels.WaitingReadAsyncOperation), waitingReader);
                                        }
                                        //default
                                        else
                                        {
                                            $.$$.System.Diagnostics.Debug.Fail$1(`Unexpected operation: ${$.$$.System.Object.ToString.call(state.Value)}`);
                                        }
                                    }
                                }
                            }
                            finally
                            {
                                $.$$.System.Threading.Monitor.Exit(state.Key.SyncObj)
                            }
                        }, {
  "r": 65537,
  "p": [
    {
      "n": "state",
      "p": $.$$.System.Collections.Generic.KeyValuePair$$$($.$stc.System.Threading.Channels.UnboundedChannel$$(T), $.$stc.System.Threading.Channels.AsyncOperation).$h
    }
  ],
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825826
}), new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$stc.System.Threading.Channels.UnboundedChannel$$(T), $.$stc.System.Threading.Channels.AsyncOperation))().$ctor$3(this, op));
                    }
                }, {
  "r": 65537,
  "p": [
    {
      "n": "state",
      "p": 131073
    },
    {
      "n": "cancellationToken",
      "p": 170065921
    }
  ],
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825794
});
            }
            //--TRIMMABLE-BOUNDARY-END(51542163477)
            
            //--TRIMMABLE-BOUNDARY-START(47247196181)
            /*void */ AssertInvariants()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47247196181);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(!(this.SyncObj === null), "The sync obj must not be null.");
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Threading.Monitor.IsEntered(this.SyncObj), "Invariants can only be validated while holding the lock.");
                if (!this._items.IsEmpty)
                {
                    if (this._runContinuationsAsynchronously)
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(this._blockedReadersHead === null, "There's data available, so there shouldn't be any blocked readers.");
                        $.$$.System.Diagnostics.Debug.Assert$2(this._waitingReadersHead === null, "There's data available, so there shouldn't be any waiting readers.");
                    }
                    $.$$.System.Diagnostics.Debug.Assert$2(!this._completion.Task.IsCompleted, "We still have data available, so shouldn't be completed.");
                }
                if ((!(this._blockedReadersHead === null) || !(this._waitingReadersHead === null)) && this._runContinuationsAsynchronously)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(this._items.IsEmpty, "There are blocked/waiting readers, so there shouldn't be any data available.");
                }
                if (this._completion.Task.IsCompleted)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(!(this._doneWriting === null), "We're completed, so we must be done writing.");
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47247196181)
            
            //--TRIMMABLE-BOUNDARY-START(94491836437)
            /*int */ get ItemsCountForDebugger()
            {
                return this._items.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(94491836437)
            
            //--TRIMMABLE-BOUNDARY-START(55837130773)
            /*bool */ get ChannelIsClosedForDebugger()
            {
                return !(this._doneWriting === null);
            }
            //--TRIMMABLE-BOUNDARY-END(55837130773)
            
            //--TRIMMABLE-BOUNDARY-START(103081771029)
            /*IEnumerator<T> */ System$Threading$Channels$IDebugEnumerable$$$GetEnumerator()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(103081771029);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._items.GetEnumerator();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103081771029)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(17182425109)
                this._items = new ($.$$.System.Collections.Concurrent.ConcurrentQueue$$(T))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(17182425109)
                
            }
            static $h = 2555925;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(98786803733),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1500000000n),
        "f": 50331650
      },
      "n": "SyncObj",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1700000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(98786803733),
//--TRIMMABLE-BOUNDARY-START(51542163477),
    {
      "p": $.$$.System.Action$$$($.$$.System.Object, $.$$.System.Threading.CancellationToken).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xF00000000n),
        "f": 50331650
      },
      "n": "CancellationCallbackDelegate",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(51542163477),
//--TRIMMABLE-BOUNDARY-START(94491836437),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1300000000n),
        "f": 50331650
      },
      "n": "ItemsCountForDebugger",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1600000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(94491836437),
//--TRIMMABLE-BOUNDARY-START(55837130773),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1100000000n),
        "f": 50331650
      },
      "n": "ChannelIsClosedForDebugger",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(55837130773)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(47247196181),
    {
      "r": 65537,
      "n": "AssertInvariants",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 16777218,
      "a": [
        {
          "t": 68747265,
          "c": 8658681857,
          "a": [
            {
              "v": "DEBUG",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47247196181)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8592490517),
    {
      "t": 178782209,
      "n": "_completion",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8592490517),
//--TRIMMABLE-BOUNDARY-START(17182425109),
    {
      "t": $.$$.System.Collections.Concurrent.ConcurrentQueue$$(T).$h,
      "n": "_items",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17182425109),
//--TRIMMABLE-BOUNDARY-START(21477392405),
    {
      "t": 262145,
      "n": "_runContinuationsAsynchronously",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21477392405),
//--TRIMMABLE-BOUNDARY-START(4297523221),
    {
      "t": $.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T).$h,
      "n": "_blockedReadersHead",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297523221),
//--TRIMMABLE-BOUNDARY-START(25772359701),
    {
      "t": 3080213,
      "n": "_waitingReadersHead",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25772359701),
//--TRIMMABLE-BOUNDARY-START(12887457813),
    {
      "t": 80019457,
      "n": "_doneWriting",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12887457813)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(42952228885),
    {
      "p": [
        {
          "n": "runContinuationsAsynchronously",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(42952228885)
  ],
  "i": [$.$stc.System.Threading.Channels.IDebugEnumerable$$(T).$h
  ],
  "g": [T?.$h??1507328
  ],
  "j": [2621461,2686997
  ],
  "r": 1,
  "h": this.$h,
  "a": [
    {
      "t": 70385665,
      "c": 25840189441,
      "a": [
        {
          "v": "Items = {ItemsCountForDebugger}, Closed = {ChannelIsClosedForDebugger}",
          "t": 1310721
        }
      ]
    },
    {
      "t": 70713345,
      "c": 21545549825,
      "a": [
        {
          "v": $.$stc.System.Threading.Channels.DebugEnumeratorDebugView$$().$h,
          "t": 187760641
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$stc.System.Threading.Channels.Channel$$(T); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stc.System.Threading.Channels.IDebugEnumerable$$(T) ]; }
            static get $fullName() { return `System.Threading.Channels.UnboundedChannel<${T?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2555925)
        
        
        //--TRIMMABLE-BOUNDARY-START(1376277)
        $asm.$str("$stc.System.Threading.Channels.BoundedChannelFullMode", ($self) => class BoundedChannelFullMode extends $.$$.System.Enum
        {
            static Wait = 0;
            static DropNewest = 1;
            static DropOldest = 2;
            static DropWrite = 3;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1376277);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Wait": 0n,
                    "DropNewest": 1n,
                    "DropOldest": 2n,
                    "DropWrite": 3n
                };
            }
            static $h = 1376277;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(21476212757),
    {
      "t": 1376277,
      "n": "Wait",
      "d": 1376277,
      "h": 21476212757,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476212757),
//--TRIMMABLE-BOUNDARY-START(8591310869),
    {
      "t": 1376277,
      "n": "DropNewest",
      "d": 1376277,
      "h": 8591310869,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591310869),
//--TRIMMABLE-BOUNDARY-START(12886278165),
    {
      "t": 1376277,
      "n": "DropOldest",
      "d": 1376277,
      "h": 12886278165,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886278165),
//--TRIMMABLE-BOUNDARY-START(17181245461),
    {
      "t": 1376277,
      "n": "DropWrite",
      "d": 1376277,
      "h": 17181245461,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181245461)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296343573),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1376277,
      "h": 4296343573,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296343573)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "h": 1376277
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Threading.Channels.BoundedChannelFullMode`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1376277)
        
        
        //--TRIMMABLE-BOUNDARY-START(1048597)
        $asm.$cls("$stc.System.Threading.Channels.BlockedReadAsyncOperation<>", (TResult) => $asm.$gt("$stc.System.Threading.Channels.BlockedReadAsyncOperation<>", [TResult], ($self) => class BlockedReadAsyncOperation$$ extends $.$stc.System.Threading.Channels.AsyncOperation$$$($self, TResult)
        {
            //--TRIMMABLE-BOUNDARY-START(4296015893)
            $ctor$4(/*bool*/ runContinuationsAsynchronously, /*CancellationToken*/ cancellationToken, /*bool*/ pooled, /*Action<object?, CancellationToken>?*/ cancellationCallback)
            {
                super.$ctor$3(runContinuationsAsynchronously, cancellationToken, pooled, cancellationCallback);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296015893);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296015893)
            
            static $h = 1048597;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296015893),
    {
      "p": [
        {
          "n": "runContinuationsAsynchronously",
          "p": 262145
        },
        {
          "n": "cancellationToken",
          "p": 170065921,
          "f": 65
        },
        {
          "n": "pooled",
          "p": 262145,
          "f": 65,
          "v": false
        },
        {
          "n": "cancellationCallback",
          "p": $.$$.System.Action$$$($.$$.System.Object, $.$$.System.Threading.CancellationToken).$h,
          "f": 65
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296015893)
  ],
  "i": [171507713,177012737,$.$$.System.Threading.Tasks.Sources.IValueTaskSource$$(TResult).$h
  ],
  "g": [TResult?.$h??1507328
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$stc.System.Threading.Channels.AsyncOperation$$$($.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(TResult), TResult); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Threading.IThreadPoolWorkItem, $.$$.System.Threading.Tasks.Sources.IValueTaskSource, $.$$.System.Threading.Tasks.Sources.IValueTaskSource$$(TResult) ]; }
            static get $fullName() { return `System.Threading.Channels.BlockedReadAsyncOperation<${TResult?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1048597)
        
        
        //--TRIMMABLE-BOUNDARY-START(1114133)
        $asm.$cls("$stc.System.Threading.Channels.BlockedWriteAsyncOperation<>", (T) => $asm.$gt("$stc.System.Threading.Channels.BlockedWriteAsyncOperation<>", [T], ($self) => class BlockedWriteAsyncOperation$$ extends $.$stc.System.Threading.Channels.AsyncOperation$$$($self, $.$stc.System.VoidResult)
        {
            //--TRIMMABLE-BOUNDARY-START(8591048725)
            $ctor$4(/*bool*/ runContinuationsAsynchronously, /*CancellationToken*/ cancellationToken, /*bool*/ pooled, /*Action<object?, CancellationToken>?*/ cancellationCallback)
            {
                super.$ctor$3(runContinuationsAsynchronously, cancellationToken, pooled, cancellationCallback);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591048725);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591048725)
            
            //--TRIMMABLE-BOUNDARY-START(21475950613)
            /*T?*/ Item$1 = null;
            //--TRIMMABLE-BOUNDARY-END(21475950613)
            
            static $h = 1114133;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475950613),
    {
      "p": T?.$h??1507328,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x400000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x700000000n),
        "f": 83886081
      },
      "n": "Item",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475950613)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591048725),
    {
      "p": [
        {
          "n": "runContinuationsAsynchronously",
          "p": 262145
        },
        {
          "n": "cancellationToken",
          "p": 170065921,
          "f": 65
        },
        {
          "n": "pooled",
          "p": 262145,
          "f": 65,
          "v": false
        },
        {
          "n": "cancellationCallback",
          "p": $.$$.System.Action$$$($.$$.System.Object, $.$$.System.Threading.CancellationToken).$h,
          "f": 65
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591048725)
  ],
  "i": [171507713,177012737,$.$$.System.Threading.Tasks.Sources.IValueTaskSource$$($.$stc.System.VoidResult).$h
  ],
  "g": [T?.$h??1507328
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$stc.System.Threading.Channels.AsyncOperation$$$($.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T), $.$stc.System.VoidResult); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Threading.IThreadPoolWorkItem, $.$$.System.Threading.Tasks.Sources.IValueTaskSource, $.$$.System.Threading.Tasks.Sources.IValueTaskSource$$($.$stc.System.VoidResult) ]; }
            static get $fullName() { return `System.Threading.Channels.BlockedWriteAsyncOperation<${T?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1114133)
        
        
        //--TRIMMABLE-BOUNDARY-START(3080213)
        $asm.$cls("$stc.System.Threading.Channels.WaitingReadAsyncOperation", ($self) => class WaitingReadAsyncOperation extends $.$stc.System.Threading.Channels.AsyncOperation$$$($self, $.$$.System.Boolean)
        {
            //--TRIMMABLE-BOUNDARY-START(4298047509)
            $ctor$4(/*bool*/ runContinuationsAsynchronously, /*CancellationToken*/ cancellationToken, /*bool*/ pooled, /*Action<object?, CancellationToken>?*/ cancellationCallback)
            {
                super.$ctor$3(runContinuationsAsynchronously, cancellationToken, pooled, cancellationCallback);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298047509);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298047509)
            
            static $h = 3080213;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298047509),
    {
      "p": [
        {
          "n": "runContinuationsAsynchronously",
          "p": 262145
        },
        {
          "n": "cancellationToken",
          "p": 170065921,
          "f": 65
        },
        {
          "n": "pooled",
          "p": 262145,
          "f": 65,
          "v": false
        },
        {
          "n": "cancellationCallback",
          "p": $.$$.System.Action$$$($.$$.System.Object, $.$$.System.Threading.CancellationToken).$h,
          "f": 65
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 3080213,
      "h": 4298047509,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298047509)
  ],
  "i": [171507713,177012737,$.$$.System.Threading.Tasks.Sources.IValueTaskSource$$($.$$.System.Boolean).$h
  ],
  "h": 3080213
}; }
            static get $b() { return $.$stc.System.Threading.Channels.AsyncOperation$$$($.$stc.System.Threading.Channels.WaitingReadAsyncOperation, $.$$.System.Boolean); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Threading.IThreadPoolWorkItem, $.$$.System.Threading.Tasks.Sources.IValueTaskSource, $.$$.System.Threading.Tasks.Sources.IValueTaskSource$$($.$$.System.Boolean) ]; }
            static get $fullName() { return `System.Threading.Channels.WaitingReadAsyncOperation`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3080213)
        
        
        //--TRIMMABLE-BOUNDARY-START(3145749)
        $asm.$cls("$stc.System.Threading.Channels.WaitingWriteAsyncOperation", ($self) => class WaitingWriteAsyncOperation extends $.$stc.System.Threading.Channels.AsyncOperation$$$($self, $.$$.System.Boolean)
        {
            //--TRIMMABLE-BOUNDARY-START(4298113045)
            $ctor$4(/*bool*/ runContinuationsAsynchronously, /*CancellationToken*/ cancellationToken, /*bool*/ pooled, /*Action<object?, CancellationToken>?*/ cancellationCallback)
            {
                super.$ctor$3(runContinuationsAsynchronously, cancellationToken, pooled, cancellationCallback);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298113045);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298113045)
            
            static $h = 3145749;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298113045),
    {
      "p": [
        {
          "n": "runContinuationsAsynchronously",
          "p": 262145
        },
        {
          "n": "cancellationToken",
          "p": 170065921,
          "f": 65
        },
        {
          "n": "pooled",
          "p": 262145,
          "f": 65,
          "v": false
        },
        {
          "n": "cancellationCallback",
          "p": $.$$.System.Action$$$($.$$.System.Object, $.$$.System.Threading.CancellationToken).$h,
          "f": 65
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 3145749,
      "h": 4298113045,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298113045)
  ],
  "i": [171507713,177012737,$.$$.System.Threading.Tasks.Sources.IValueTaskSource$$($.$$.System.Boolean).$h
  ],
  "h": 3145749
}; }
            static get $b() { return $.$stc.System.Threading.Channels.AsyncOperation$$$($.$stc.System.Threading.Channels.WaitingWriteAsyncOperation, $.$$.System.Boolean); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Threading.IThreadPoolWorkItem, $.$$.System.Threading.Tasks.Sources.IValueTaskSource, $.$$.System.Threading.Tasks.Sources.IValueTaskSource$$($.$$.System.Boolean) ]; }
            static get $fullName() { return `System.Threading.Channels.WaitingWriteAsyncOperation`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3145749)
        
        
        //--TRIMMABLE-BOUNDARY-START(262165)
        $asm.$cls("$stc.System.Collections.Concurrent.MultiProducerMultiConsumerQueue<>", (T) => $asm.$gt("$stc.System.Collections.Concurrent.MultiProducerMultiConsumerQueue<>", [T], ($self) => class MultiProducerMultiConsumerQueue$$ extends $.$$.System.Collections.Concurrent.ConcurrentQueue$$(T)
        {
            //--TRIMMABLE-BOUNDARY-START(12885164053)
            /*void */ System$Collections$Concurrent$IProducerConsumerQueue$$$Enqueue(/*T*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885164053);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Enqueue(item);
            }
            //--TRIMMABLE-BOUNDARY-END(12885164053)
            
            //--TRIMMABLE-BOUNDARY-START(42949935125)
            /*bool */ System$Collections$Concurrent$IProducerConsumerQueue$$$TryDequeue(/*out T*/ result)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949935125);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.TryDequeue(result);
            }
            //--TRIMMABLE-BOUNDARY-END(42949935125)
            
            //--TRIMMABLE-BOUNDARY-START(38654967829)
            /*bool */ get System$Collections$Concurrent$IProducerConsumerQueue$$$IsEmpty()
            {
                return this.IsEmpty;
            }
            //--TRIMMABLE-BOUNDARY-END(38654967829)
            
            //--TRIMMABLE-BOUNDARY-START(8590196757)
            /*int */ get System$Collections$Concurrent$IProducerConsumerQueue$$$Count()
            {
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(8590196757)
            
            //--TRIMMABLE-BOUNDARY-START(34360000533)
            /*int */ System$Collections$Concurrent$IProducerConsumerQueue$$$GetCountSafe(/*object*/ syncObj)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360000533);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Count;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360000533)
            
            //--TRIMMABLE-BOUNDARY-START(4295229461)
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$1();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295229461)
            
            static $h = 262165;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38654967829),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x700000000n),
        "f": 50331650
      },
      "n": "{$.$stc.System.Collections.Concurrent.IProducerConsumerQueue$$(T).$h}.IsEmpty",
      "o": "System$Collections$Concurrent$IProducerConsumerQueue$$$IsEmpty",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(38654967829),
//--TRIMMABLE-BOUNDARY-START(8590196757),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x500000000n),
        "f": 50331650
      },
      "n": "{$.$stc.System.Collections.Concurrent.IProducerConsumerQueue$$(T).$h}.Count",
      "o": "System$Collections$Concurrent$IProducerConsumerQueue$$$Count",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(8590196757)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295229461),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295229461)
  ],
  "i": [$.$$.System.Collections.Concurrent.IProducerConsumerCollection$$(T).$h,62390273,$.$$.System.Collections.Generic.IReadOnlyCollection$$(T).$h,$.$stc.System.Collections.Concurrent.IProducerConsumerQueue$$(T).$h,$.$$.System.Collections.Generic.IEnumerable$$(T).$h,62652417
  ],
  "g": [T?.$h??1507328
  ],
  "r": 1,
  "h": this.$h,
  "a": [
    {
      "t": 70385665,
      "c": 25840189441,
      "a": [
        {
          "v": "Count = {Count}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Collections.Concurrent.ConcurrentQueue$$(T); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Concurrent.IProducerConsumerCollection$$(T), $.$$.System.Collections.ICollection, $.$$.System.Collections.Generic.IReadOnlyCollection$$(T), $.$stc.System.Collections.Concurrent.IProducerConsumerQueue$$(T), $.$$.System.Collections.Generic.IEnumerable$$(T), $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Collections.Concurrent.MultiProducerMultiConsumerQueue<${T?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(262165)
        
        
        //--TRIMMABLE-BOUNDARY-START(1703957)
        $asm.$cls("$stc.System.Threading.Channels.ChannelClosedException", ($self) => class ChannelClosedException extends $.$$.System.InvalidOperationException
        {
            //--TRIMMABLE-BOUNDARY-START(4296671253)
            $ctor$13()
            {
                super.$ctor$12($.$stc.System.SR.ChannelClosedException_DefaultMessage);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296671253);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296671253)
            
            //--TRIMMABLE-BOUNDARY-START(21476540437)
            $ctor$17(/*string?*/ message)
            {
                super.$ctor$12(message ?? $.$stc.System.SR.ChannelClosedException_DefaultMessage);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476540437);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476540437)
            
            //--TRIMMABLE-BOUNDARY-START(8591638549)
            $ctor$14(/*Exception?*/ innerException)
            {
                super.$ctor$11($.$stc.System.SR.ChannelClosedException_DefaultMessage, innerException);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591638549);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591638549)
            
            //--TRIMMABLE-BOUNDARY-START(17181573141)
            $ctor$16(/*string?*/ message, /*Exception?*/ innerException)
            {
                super.$ctor$11(message ?? $.$stc.System.SR.ChannelClosedException_DefaultMessage, innerException);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181573141);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181573141)
            
            //--TRIMMABLE-BOUNDARY-START(12886605845)
            $ctor$15(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor$10(info, context);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886605845);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886605845)
            
            static $h = 1703957;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 91029505,
  "h": 1703957
}; }
            static get $b() { return $.$$.System.InvalidOperationException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Threading.Channels.ChannelClosedException`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1703957)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Threading.ThreadPool"))
//--TRIMMABLE-BOUNDARY-END(21)
