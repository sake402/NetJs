
(function ($global, $, $spc, $sc, $sdt, $st, $scc, $sm, $spu, $sr, $sttp) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Threading.Channels", 
    {"h":45344,"f":"System.Threading.Channels","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bf7a34a6f78fee11131301a9f55ca16a968616013","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Threading.Channels","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Threading.Channels","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$stc.System.Threading.Channels.IDebugEnumerable<>", (T) => $asm.$gt("$stc.System.Threading.Channels.IDebugEnumerable<>", [T], ($self) => class IDebugEnumerable$$
        {
            static $h = 2076960;
            static $g = 1;
            static $f = 0b1100100;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":$.$spc.System.Collections.Generic.IEnumerator$$(T).$h,"n":"GetEnumerator","o":"System$Threading$Channels$IDebugEnumerable$$$GetEnumerator","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":257}],"g":[T?.$h??1507328],"r":1,"h":this.$h}; }
            static get $fullName() { return `System.Threading.Channels.IDebugEnumerable<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$stc.System.Collections.Concurrent.IProducerConsumerQueue<>", (T) => $asm.$gt("$stc.System.Collections.Concurrent.IProducerConsumerQueue<>", [T], ($self) => class IProducerConsumerQueue$$
        {
            static $h = 241952;
            static $g = 1;
            static $f = 0b1100100;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":262145,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":257},"n":"IsEmpty","o":"System$Collections$Concurrent$IProducerConsumerQueue$$$IsEmpty","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":257},{"p":655361,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x600000000n),"f":257},"n":"Count","o":"System$Collections$Concurrent$IProducerConsumerQueue$$$Count","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":257}],"m":[{"r":65537,"p":[{"n":"item","p":T?.$h??1507328}],"n":"Enqueue","o":"System$Collections$Concurrent$IProducerConsumerQueue$$$Enqueue","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":257},{"r":262145,"p":[{"n":"result","p":T?.$h??1507328,"f":2}],"n":"TryDequeue","o":"System$Collections$Concurrent$IProducerConsumerQueue$$$TryDequeue","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":257},{"r":655361,"p":[{"n":"syncObj","p":131073}],"n":"GetCountSafe","o":"System$Collections$Concurrent$IProducerConsumerQueue$$$GetCountSafe","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":257}],"i":[$.$spc.System.Collections.Generic.IEnumerable$$(T).$h,31653889],"g":[T?.$h??1507328],"r":1,"h":this.$h}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEnumerable$$(T), $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Collections.Concurrent.IProducerConsumerQueue<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$stc.System.Threading.Channels.ChannelWriter<>", (T) => $asm.$gt("$stc.System.Threading.Channels.ChannelWriter<>", [T], ($self) => class ChannelWriter$$ extends $.$spc.System.Object
        {
            /*bool */ TryComplete(/*Exception?*/ error)
            {
                return false;
            }
            /*ValueTask */ WriteAsync(/*T*/ item, /*CancellationToken*/ cancellationToken)
            {
                try
                {
                    return cancellationToken.IsCancellationRequested ? new $.$spc.System.Threading.Tasks.ValueTask().$ctor$2($.$spc.System.Threading.Tasks.Task.FromCanceled$1(T, cancellationToken)) : this.TryWrite(item) ? new $.$spc.System.Threading.Tasks.ValueTask() : this.WriteAsyncCore(item, cancellationToken);
                }
                catch(e)
                {
                    return new $.$spc.System.Threading.Tasks.ValueTask().$ctor$2($.$spc.System.Threading.Tasks.Task.FromException(e));
                }
            }
            /*ValueTask *//*async*/  WriteAsyncCore(/*T*/ innerItem, /*CancellationToken*/ ct)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask, $.$spc.System.Void, async () => 
                {
                    while(await this.WaitToWriteAsync(ct).ConfigureAwait(false))
                    {
                        if (this.TryWrite(innerItem))
                        {
                            return;
                        }
                    }
                    throw $.$stc.System.Threading.Channels.ChannelUtilities.CreateInvalidCompletionException(null);
                });
            }
            /*void */ Complete(/*Exception?*/ error)
            {
                if (!this.TryComplete(error))
                {
                    throw $.$stc.System.Threading.Channels.ChannelUtilities.CreateInvalidCompletionException(null);
                }
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 1945888;
            static $g = 1;
            static $f = 0b1110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"error","p":47251457,"f":65}],"n":"TryComplete","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":129},{"r":262145,"p":[{"n":"item","p":T?.$h??1507328}],"n":"TryWrite","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":257},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Boolean).$h,"p":[{"n":"cancellationToken","p":125960193,"f":65}],"n":"WaitToWriteAsync","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":257},{"r":136118273,"p":[{"n":"item","p":T?.$h??1507328},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":129},{"r":136118273,"p":[{"n":"innerItem","p":T?.$h??1507328},{"n":"ct","p":125960193}],"n":"WriteAsyncCore","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":4098},{"r":65537,"p":[{"n":"error","p":47251457,"f":65}],"n":"Complete","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":4}],"g":[T?.$h??1507328],"r":1,"h":this.$h}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Threading.Channels.ChannelWriter<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$stc.System.Threading.Channels.ChannelReader<>", (T) => $asm.$gt("$stc.System.Threading.Channels.ChannelReader<>", [T], ($self) => class ChannelReader$$ extends $.$spc.System.Object
        {
            /*Task */ get Completion()
            {
                return $.$stc.System.Threading.Channels.ChannelUtilities.s_neverCompletingTask;
            }
            /*bool */ get CanCount()
            {
                return false;
            }
            /*bool */ get CanPeek()
            {
                return false;
            }
            /*int */ get Count()
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*bool */ TryPeek(/*out T*/ item)
            {
                item.$v = $.$default(T);
                return false;
            }
            /*ValueTask<T> */ ReadAsync(/*CancellationToken*/ cancellationToken)
            {
                if (cancellationToken.IsCancellationRequested)
                {
                    return new ($.$spc.System.Threading.Tasks.ValueTask$$(T))().$ctor$3($.$spc.System.Threading.Tasks.Task.FromCanceled$1(T, cancellationToken));
                }
                try
                {
                    /*T?*/ let fastItem;
                    if (this.TryRead($.$ref(() => fastItem, ($v) => fastItem = $v, T)))
                    {
                        return new ($.$spc.System.Threading.Tasks.ValueTask$$(T))().$ctor$2(fastItem);
                    }
                }
                catch(exc)
                {
                    return new ($.$spc.System.Threading.Tasks.ValueTask$$(T))().$ctor$3($.$spc.System.Threading.Tasks.Task.FromException$1(T, exc));
                }
                return ReadAsyncCore.call(this, cancellationToken);
                /*ValueTask<T>*/ /*async*/  function ReadAsyncCore(/*CancellationToken*/ ct)
                {
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask$$(T), T, async () => 
                    {
                        while(true)
                        {
                            if (!await this.WaitToReadAsync(ct).ConfigureAwait(false))
                            {
                                throw new $.$stc.System.Threading.Channels.ChannelClosedException().$ctor$13();
                            }
                            /*T?*/ let item;
                            if (this.TryRead($.$ref(() => item, ($v) => item = $v, T)))
                            {
                                return item;
                            }
                        }
                    });
                }
            }
            /*IAsyncEnumerable<T> *//*async*/  ReadAllAsync(/*CancellationToken*/ cancellationToken)
            {
                return new ($.$spc.NetJs.YieldToIterator$$(T))().$ctor$1(async function*()
                {
                    while(await this.WaitToReadAsync(cancellationToken).ConfigureAwait(false))
                    {
                        /*T?*/ let item;
                        while(this.TryRead($.$ref(() => item, ($v) => item = $v, T)))
                        {
                            yield item;
                        }
                    }
                }.bind(this));
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 1814816;
            static $g = 1;
            static $f = 0b1110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":133300225,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x200000000n),"f":129},"n":"Completion","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":129},{"p":262145,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":129},"n":"CanCount","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":129},{"p":262145,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x600000000n),"f":129},"n":"CanPeek","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":129},{"p":655361,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x800000000n),"f":129},"n":"Count","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":129}],"m":[{"r":262145,"p":[{"n":"item","p":T?.$h??1507328,"f":2}],"n":"TryRead","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":257},{"r":262145,"p":[{"n":"item","p":T?.$h??1507328,"f":2}],"n":"TryPeek","d":this.$h,"h":Number(BigInt(this.$h)|0xA00000000n),"f":129},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Boolean).$h,"p":[{"n":"cancellationToken","p":125960193,"f":65}],"n":"WaitToReadAsync","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":257},{"r":$.$spc.System.Threading.Tasks.ValueTask$$(T).$h,"p":[{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":129},{"r":$.$spc.System.Collections.Generic.IAsyncEnumerable$$(T).$h,"p":[{"n":"cancellationToken","p":125960193,"f":65,"a":[{"t":90505217,"c":4385472513}]}],"n":"ReadAllAsync","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":4225}],"c":[{"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0xE00000000n),"f":4}],"g":[T?.$h??1507328],"r":1,"h":this.$h}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Threading.Channels.ChannelReader<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$stc.System.Threading.Channels.ChannelOptions", ($self) => class ChannelOptions extends $.$spc.System.Object
        {
            /*bool*/ SingleWriter = false;
            /*bool*/ SingleReader = false;
            /*bool*/ AllowSynchronousContinuations = false;
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.SingleWriter = false;
                this.SingleReader = false;
                this.AllowSynchronousContinuations = false;
            }
            static $h = 1749280;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":12886651168,"f":1},"s":{"r":0,"d":0,"h":17181618464,"f":1},"n":"SingleWriter","d":1749280,"h":8591683872,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":30066520352,"f":1},"s":{"r":0,"d":0,"h":34361487648,"f":1},"n":"SingleReader","d":1749280,"h":25771553056,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":47246389536,"f":1},"s":{"r":0,"d":0,"h":51541356832,"f":1},"n":"AllowSynchronousContinuations","d":1749280,"h":42951422240,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":1749280,"h":55836324128,"f":4}],"h":1749280}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Threading.Channels.ChannelOptions`; }
        });
        
        $asm.$cls("$stc.System.Threading.Channels.Channel<,>", (TWrite, TRead) => $asm.$gt("$stc.System.Threading.Channels.Channel<,>", [TWrite, TRead], ($self) => class Channel$$$ extends $.$spc.System.Object
        {
            /*ChannelReader<TRead>*/ Reader = null;
            /*ChannelWriter<TWrite>*/ Writer = null;
            static /*ChannelReader<TRead> */ op_Implicit(/*Channel<TWrite, TRead>*/ channel)
            {
                return channel.Reader;
            }
            static /*ChannelWriter<TWrite> */ op_Implicit$1(/*Channel<TWrite, TRead>*/ channel)
            {
                return channel.Writer;
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Reader = null;
                this.Writer = null;
            }
            static $h = 1552672;
            static $g = 2;
            static $f = 0b1110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$stc.System.Threading.Channels.ChannelReader$$(TRead).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x300000000n),"f":1},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":4},"n":"Reader","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":1},{"p":$.$stc.System.Threading.Channels.ChannelWriter$$(TWrite).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x700000000n),"f":1},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x800000000n),"f":4},"n":"Writer","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":4}],"g":[TWrite?.$h??1507328,TRead?.$h??1572864],"r":2,"h":this.$h}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Threading.Channels.Channel<${TWrite?.$fullName},${TRead?.$fullName}>`; }
        }));
        
        $asm.$cls("$stc.System.Threading.Channels.AsyncOperation", ($self) => class AsyncOperation extends $.$spc.System.Object
        {
            /*void */ System$Threading$IThreadPoolWorkItem$Execute()
            {
                return this.SetCompletionAndInvokeContinuation();
            }
            /*void */ UnsafeQueueSetCompletionAndInvokeContinuation()
            {
                return $.$spc.System.Threading.ThreadPool.UnsafeQueueUserWorkItem$2(this, false);
            }
            static /*void */ Unregister(/*CancellationTokenRegistration*/ registration)
            {
                return registration.Unregister();
            }
            /*Action<object?>*/ static s_availableSentinel = null;
            static /*void */ AvailableSentinel(/*object?*/ s)
            {
                return $.$spc.System.Diagnostics.Debug.Fail(`${"AsyncOperation"}.${"AvailableSentinel"} invoked with ${$.$spc.System.Object.ToString.call(s)}`);
            }
            /*Action<object?>*/ static s_completedSentinel = null;
            static /*void */ CompletedSentinel(/*object?*/ s)
            {
                return $.$spc.System.Diagnostics.Debug.Fail(`${"AsyncOperation"}.${"CompletedSentinel"} invoked with ${$.$spc.System.Object.ToString.call(s)}`);
            }
            static /*void */ ThrowIncompleteOperationException()
            {
                throw new $.$spc.System.InvalidOperationException().$ctor$10($.$stc.System.SR.InvalidOperation_IncompleteAsyncOperation);
            }
            static /*void */ ThrowMultipleContinuations()
            {
                throw new $.$spc.System.InvalidOperationException().$ctor$10($.$stc.System.SR.InvalidOperation_MultipleContinuations);
            }
            static /*void */ ThrowIncorrectCurrentIdException()
            {
                throw new $.$spc.System.InvalidOperationException().$ctor$10($.$stc.System.SR.InvalidOperation_IncorrectToken);
            }
            /*CancellationTokenRegistration*/ _cancellationRegistration;
            /*bool*/ _pooled = false;
            /*bool*/ _completionReserved = false;
            /*ExceptionDispatchInfo?*/ _error = null;
            /*Action<object?>?*/ _continuation = null;
            /*object?*/ _continuationState = null;
            /*object?*/ _capturedContext = null;
            /*short*/ _currentId = 0;
            $ctor$1(/*bool*/ runContinuationsAsynchronously, /*CancellationToken*/ cancellationToken, /*bool*/ pooled, /*Action<object?, CancellationToken>?*/ cancellationCallback)
            {
                super.$ctor();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(!pooled || !cancellationToken.CanBeCanceled, "!pooled || !cancellationToken.CanBeCanceled");
                    this._continuation = pooled ? $.$stc.System.Threading.Channels.AsyncOperation.s_availableSentinel : null;
                    this._pooled = pooled;
                    this.RunContinuationsAsynchronously = runContinuationsAsynchronously;
                    if (cancellationToken.CanBeCanceled)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(!(cancellationCallback === null), "Expected a non-null cancellation callback when the token is cancelable");
                        $.$spc.System.Diagnostics.Debug.Assert$1(!this._pooled, "Cancelable operations can't be pooled");
                        this._cancellationRegistration = cancellationToken.UnsafeRegister$1(cancellationCallback, this);
                    }
                }
                return this;
            }
            /*bool*/ RunContinuationsAsynchronously = false;
            /*CancellationToken */ get CancellationToken()
            {
                return this._cancellationRegistration.Token;
            }
            /*bool */ get IsCompleted()
            {
                return $.$spc.System.Object.ReferenceEquals(this._continuation, $.$stc.System.Threading.Channels.AsyncOperation.s_completedSentinel);
            }
            /*bool */ TrySetException(/*Exception*/ exception)
            {
                if (this.TryReserveCompletionIfCancelable())
                {
                    this._error = $.$spc.System.Runtime.ExceptionServices.ExceptionDispatchInfo.Capture(exception);
                    this.SignalCompletion();
                    return true;
                }
                return false;
            }
            /*bool */ TrySetCanceled(/*CancellationToken*/ cancellationToken)
            {
                if (this.TryReserveCompletionIfCancelable())
                {
                    this._error = $.$spc.System.Runtime.ExceptionServices.ExceptionDispatchInfo.Capture(new $.$spc.System.OperationCanceledException().$ctor$12(cancellationToken));
                    this.SignalCompletion();
                    return true;
                }
                return false;
            }
            /*bool */ TryReserveCompletionIfCancelable()
            {
                return !this.CancellationToken.CanBeCanceled || $.$spc.System.Threading.Interlocked.Exchange$14($.$spc.System.Boolean, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Boolean, () => this._completionReserved, ($v) => this._completionReserved = $v, null), true) === false;
            }
            /*void */ SignalCompletion()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(!this.CancellationToken.CanBeCanceled || this._completionReserved, "!CancellationToken.CanBeCanceled ||\r\n#if NET9_0_OR_GREATER\r\n                _completionReserved");
                $.$stc.System.Threading.Channels.AsyncOperation.Unregister(this._cancellationRegistration);
                if (!(this._continuation === null) || !($.$spc.System.Threading.Interlocked.CompareExchange$14($.$spc.System.Action$$($.$spc.System.Object), $.$ref(() => this._continuation, ($v) => this._continuation = $v, $.$spc.System.Action$$($.$spc.System.Object)), $.$stc.System.Threading.Channels.AsyncOperation.s_completedSentinel, null) === null))
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._continuation !== $.$stc.System.Threading.Channels.AsyncOperation.s_completedSentinel, `The continuation was the completion sentinel.`);
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._continuation !== $.$stc.System.Threading.Channels.AsyncOperation.s_availableSentinel, `The continuation was the available sentinel.`);
                    /*object?*/ let ctx = this._capturedContext;
                    let $t2;
                    if ((ctx === null) || (($.$is(ctx, $.$spc.System.Threading.ExecutionContext, { set $v(v){ $t2 = v } }) && $t2 === $.$spc.System.Threading.ExecutionContext)))
                    {
                        if (this.RunContinuationsAsynchronously)
                        {
                            this.UnsafeQueueSetCompletionAndInvokeContinuation();
                            return;
                        }
                    }
                    else 
                    {
                        /*SynchronizationContext?*/ let sc = $.$as(ctx, $.$spc.System.Threading.SynchronizationContext) ?? $.$as((($.$as(ctx, $.$stc.System.Threading.Channels.AsyncOperation.CapturedSchedulerAndExecutionContext))?._scheduler ?? null), $.$spc.System.Threading.SynchronizationContext);
                        if (!(sc === null))
                        {
                            if (this.RunContinuationsAsynchronously || sc !== $.$spc.System.Threading.SynchronizationContext.Current)
                            {
                                sc.Post(new $.$spc.System.Threading.SendOrPostCallback().$ctor($.$stc.System.Threading.Channels.AsyncOperation, /*static*/ (/*s*/ s) =>
                                {
                                    return ($.$cast(s, $.$stc.System.Threading.Channels.AsyncOperation)).SetCompletionAndInvokeContinuation();
                                }, {"r":65537,"p":[{"n":"s","p":131073}],"n":"","d":766240,"h":0,"f":1048610}), this);
                                return;
                            }
                        }
                        else 
                        {
                            /*TaskScheduler?*/ let ts = $.$as(ctx, $.$spc.System.Threading.Tasks.TaskScheduler) ?? $.$as((($.$as(ctx, $.$stc.System.Threading.Channels.AsyncOperation.CapturedSchedulerAndExecutionContext))?._scheduler ?? null), $.$spc.System.Threading.Tasks.TaskScheduler);
                            $.$spc.System.Diagnostics.Debug.Assert$1(!(ts === null), "Expected a TaskScheduler");
                            if (this.RunContinuationsAsynchronously || ts !== $.$spc.System.Threading.Tasks.TaskScheduler.Current)
                            {
                                $.$spc.System.Threading.Tasks.Task.Factory.StartNew$7(new ($.$spc.System.Action$$($.$spc.System.Object))().$ctor($.$stc.System.Threading.Channels.AsyncOperation, /*static*/ (/*s*/ s) =>
                                {
                                    return ($.$cast(s, $.$stc.System.Threading.Channels.AsyncOperation)).SetCompletionAndInvokeContinuation();
                                }, {"r":65537,"p":[{"n":"s","p":131073}],"n":"","d":766240,"h":0,"f":1048610}), this, $.$spc.System.Threading.CancellationToken.None, 8/*TaskCreationOptions.DenyChildAttach*/, ts);
                                return;
                            }
                        }
                    }
                    this.SetCompletionAndInvokeContinuation();
                }
            }
            /*void */ SetCompletionAndInvokeContinuation()
            {
                /*object?*/ let ctx = this._capturedContext;
                /*ExecutionContext?*/ let ec = ctx === null ? null : $.$as(ctx, $.$spc.System.Threading.ExecutionContext) ?? (($.$as(ctx, $.$stc.System.Threading.Channels.AsyncOperation.CapturedSchedulerAndExecutionContext))?._executionContext ?? null);
                if (ec === null)
                {
                    /*Action<object?>*/ let c = this._continuation;
                    this._continuation = $.$stc.System.Threading.Channels.AsyncOperation.s_completedSentinel;
                    c.Invoke(this._continuationState);
                }
                else 
                {
                    $.$spc.System.Threading.ExecutionContext.Run(ec, new $.$spc.System.Threading.ContextCallback().$ctor($.$stc.System.Threading.Channels.AsyncOperation, /*static*/ (/*s*/ s) =>
                    {
                        /*var*/ let thisRef = $.$cast(s, $.$stc.System.Threading.Channels.AsyncOperation);
                        /*Action<object?>*/ let c = thisRef._continuation;
                        thisRef._continuation = $.$stc.System.Threading.Channels.AsyncOperation.s_completedSentinel;
                        c.Invoke(thisRef._continuationState);
                    }, {"r":65537,"p":[{"n":"s","p":131073}],"n":"","d":766240,"h":0,"f":1048610}), this);
                }
            }
            /*void */ OnCompleted(/*Action<object?>*/ continuation, /*object?*/ state, /*short*/ token, /*ValueTaskSourceOnCompletedFlags*/ flags)
            {
                if (this._currentId !== token)
                {
                    $.$stc.System.Threading.Channels.AsyncOperation.ThrowIncorrectCurrentIdException();
                }
                if (!(this._continuationState === null))
                {
                    $.$stc.System.Threading.Channels.AsyncOperation.ThrowMultipleContinuations();
                }
                this._continuationState = state;
                $.$spc.System.Diagnostics.Debug.Assert$1(this._capturedContext === null, "_capturedContext is null");
                if ((flags & 2/*ValueTaskSourceOnCompletedFlags.FlowExecutionContext*/) !== 0)
                {
                    this._capturedContext = $.$spc.System.Threading.ExecutionContext.Capture();
                }
                /*SynchronizationContext?*/ let sc = null;
                /*TaskScheduler?*/ let ts = null;
                if ((flags & 1/*ValueTaskSourceOnCompletedFlags.UseSchedulingContext*/) !== 0)
                {
                    sc = $.$spc.System.Threading.SynchronizationContext.Current;
                    if (!(sc === null) && $.$spc.System.Type.op_Inequality$1($.$spc.System.Object.GetType.call(sc), $.$spc.System.Threading.SynchronizationContext.$type))
                    {
                        this._capturedContext = this._capturedContext === null ? sc : new $.$stc.System.Threading.Channels.AsyncOperation.CapturedSchedulerAndExecutionContext().$ctor$1(sc, $.$cast(this._capturedContext, $.$spc.System.Threading.ExecutionContext));
                    }
                    else 
                    {
                        sc = null;
                        ts = $.$spc.System.Threading.Tasks.TaskScheduler.Current;
                        if (ts !== $.$spc.System.Threading.Tasks.TaskScheduler.Default)
                        {
                            this._capturedContext = this._capturedContext === null ? ts : new $.$stc.System.Threading.Channels.AsyncOperation.CapturedSchedulerAndExecutionContext().$ctor$1(ts, $.$cast(this._capturedContext, $.$spc.System.Threading.ExecutionContext));
                        }
                        else 
                        {
                            ts = null;
                        }
                    }
                }
                /*Action<object?>?*/ let prevContinuation = $.$spc.System.Threading.Interlocked.CompareExchange$14($.$spc.System.Action$$($.$spc.System.Object), $.$ref(() => this._continuation, ($v) => this._continuation = $v, $.$spc.System.Action$$($.$spc.System.Object)), continuation, null);
                if (!(prevContinuation === null))
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(this.IsCompleted, `Expected IsCompleted`);
                    if (!$.$spc.System.Object.ReferenceEquals(prevContinuation, $.$stc.System.Threading.Channels.AsyncOperation.s_completedSentinel))
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(prevContinuation !== $.$stc.System.Threading.Channels.AsyncOperation.s_availableSentinel, "Continuation was the available sentinel.");
                        $.$stc.System.Threading.Channels.AsyncOperation.ThrowMultipleContinuations();
                    }
                    if (this._capturedContext === null)
                    {
                        $.$stc.System.Threading.Channels.ChannelUtilities.UnsafeQueueUserWorkItem($.$spc.System.Object, continuation, state);
                    }
                    else if (!(sc === null))
                    {
                        sc.Post(new $.$spc.System.Threading.SendOrPostCallback().$ctor($.$stc.System.Threading.Channels.AsyncOperation, /*static*/ (/*s*/ s) =>
                        {
                            /*var*/ let t = $.$cast(s, $.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.Action$$($.$spc.System.Object), $.$spc.System.Object));
                            t.Key.Invoke(t.Value);
                        }, {"r":65537,"p":[{"n":"s","p":131073}],"n":"","d":766240,"h":0,"f":1048610}), new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.Action$$($.$spc.System.Object), $.$spc.System.Object))().$ctor$2(continuation, state));
                    }
                    else if (!(ts === null))
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(!(ts === null), "ts is not null");
                        $.$spc.System.Threading.Tasks.Task.Factory.StartNew$7(continuation, state, $.$spc.System.Threading.CancellationToken.None, 8/*TaskCreationOptions.DenyChildAttach*/, ts);
                    }
                    else 
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1($.$is(this._capturedContext, $.$spc.System.Threading.ExecutionContext), "_capturedContext is ExecutionContext");
                        $.$stc.System.Threading.Channels.ChannelUtilities.QueueUserWorkItem(continuation, state);
                    }
                }
            }
            static $_CapturedSchedulerAndExecutionContext;
            static get CapturedSchedulerAndExecutionContext()
            {
                let $cls = $.$stc.System.Threading.Channels.AsyncOperation;
                return $cls.$_CapturedSchedulerAndExecutionContext ??= $asm.$ncls("$stc.System.Threading.Channels.AsyncOperation.CapturedSchedulerAndExecutionContext", ($self) => class CapturedSchedulerAndExecutionContext extends $.$spc.System.Object
                {
                    /*object*/ _scheduler = null;
                    /*ExecutionContext*/ _executionContext = null;
                    $ctor$1(/*object*/ scheduler, /*ExecutionContext*/ executionContext)
                    {
                        super.$ctor();
                        {
                            let $t1;
                            let $t2;
                            $.$spc.System.Diagnostics.Debug.Assert$2(scheduler !== null && ((($.$is(scheduler, $.$spc.System.Threading.SynchronizationContext, { set $v(v){ $t1 = v } }) && $t1 === $.$spc.System.Threading.SynchronizationContext)) || (($.$is(scheduler, $.$spc.System.Threading.Tasks.TaskScheduler, { set $v(v){ $t2 = v } }) && $t2 === $.$spc.System.Threading.Tasks.TaskScheduler))), `${"scheduler"} is ${$.$spc.System.Object.ToString.call(scheduler)}`);
                            $.$spc.System.Diagnostics.Debug.Assert$1(!(executionContext === null), `${"executionContext"} is null`);
                            this._scheduler = scheduler;
                            this._executionContext = executionContext;
                        }
                        return this;
                    }
                    static $h = 831776;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":131073,"n":"_scheduler","d":831776,"h":4295799072,"f":8},{"t":126943233,"n":"_executionContext","d":831776,"h":8590766368,"f":8}],"c":[{"p":[{"n":"scheduler","p":131073},{"n":"executionContext","p":126943233}],"n":".ctor","o":"$ctor$1","d":831776,"h":12885733664,"f":1}],"d":766240,"h":831776}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Threading.Channels.AsyncOperation.CapturedSchedulerAndExecutionContext`; }
                }, $cls, ($v) => $cls.$_CapturedSchedulerAndExecutionContext = $v);
            }
            //default member initializer
            constructor()
            {
                super();
                this._cancellationRegistration = $.$default($.$spc.System.Threading.CancellationTokenRegistration);
                this.RunContinuationsAsynchronously = false;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_availableSentinel = new ($.$spc.System.Action$$($.$spc.System.Object))().$ctor($.$stc.System.Threading.Channels.AsyncOperation, $.$stc.System.Threading.Channels.AsyncOperation.AvailableSentinel);
                }
                {
                    this.s_completedSentinel = new ($.$spc.System.Action$$($.$spc.System.Object))().$ctor($.$stc.System.Threading.Channels.AsyncOperation, $.$stc.System.Threading.Channels.AsyncOperation.CompletedSentinel);
                }
            }
            static $h = 766240;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":94490046752,"f":1},"n":"RunContinuationsAsynchronously","d":766240,"h":90195079456,"f":1},{"p":125960193,"g":{"r":0,"d":0,"h":103079981344,"f":2},"n":"CancellationToken","d":766240,"h":98785014048,"f":2},{"p":262145,"g":{"r":0,"d":0,"h":111669915936,"f":8},"n":"IsCompleted","d":766240,"h":107374948640,"f":8}],"m":[{"r":65537,"n":"UnsafeQueueSetCompletionAndInvokeContinuation","d":766240,"h":8590700832,"f":2},{"r":65537,"p":[{"n":"registration","p":126025729}],"n":"Unregister","d":766240,"h":12885668128,"f":34},{"r":65537,"p":[{"n":"s","p":131073}],"n":"AvailableSentinel","d":766240,"h":21475602720,"f":34},{"r":65537,"p":[{"n":"s","p":131073}],"n":"CompletedSentinel","d":766240,"h":30065537312,"f":34},{"r":65537,"n":"ThrowIncompleteOperationException","d":766240,"h":34360504608,"f":36},{"r":65537,"n":"ThrowMultipleContinuations","d":766240,"h":38655471904,"f":36},{"r":65537,"n":"ThrowIncorrectCurrentIdException","d":766240,"h":42950439200,"f":36},{"r":262145,"p":[{"n":"exception","p":47251457}],"n":"TrySetException","d":766240,"h":115964883232,"f":1},{"r":262145,"p":[{"n":"cancellationToken","p":125960193,"f":65}],"n":"TrySetCanceled","d":766240,"h":120259850528,"f":1},{"r":262145,"n":"TryReserveCompletionIfCancelable","d":766240,"h":124554817824,"f":1},{"r":65537,"n":"SignalCompletion","d":766240,"h":128849785120},{"r":65537,"n":"SetCompletionAndInvokeContinuation","d":766240,"h":133144752416,"f":2},{"r":65537,"p":[{"n":"continuation","p":$.$spc.System.Action$$($.$spc.System.Object).$h},{"n":"state","p":131073},{"n":"token","p":524289},{"n":"flags","p":132972545}],"n":"OnCompleted","d":766240,"h":137439719712,"f":1}],"l":[{"t":$.$spc.System.Action$$($.$spc.System.Object).$h,"n":"s_availableSentinel","d":766240,"h":17180635424,"f":36},{"t":$.$spc.System.Action$$($.$spc.System.Object).$h,"n":"s_completedSentinel","d":766240,"h":25770570016,"f":36},{"t":126025729,"n":"_cancellationRegistration","d":766240,"h":47245406496,"f":2},{"t":262145,"n":"_pooled","d":766240,"h":51540373792},{"t":262145,"n":"_completionReserved","d":766240,"h":55835341088,"f":2},{"t":97517569,"n":"_error","d":766240,"h":60130308384},{"t":$.$spc.System.Action$$($.$spc.System.Object).$h,"n":"_continuation","d":766240,"h":64425275680},{"t":131073,"n":"_continuationState","d":766240,"h":68720242976},{"t":131073,"n":"_capturedContext","d":766240,"h":73015210272},{"t":524289,"n":"_currentId","d":766240,"h":77310177568}],"c":[{"p":[{"n":"runContinuationsAsynchronously","p":262145},{"n":"cancellationToken","p":125960193},{"n":"pooled","p":262145},{"n":"cancellationCallback","p":$.$spc.System.Action$$$($.$spc.System.Object, $.$spc.System.Threading.CancellationToken).$h}],"n":".ctor","o":"$ctor$1","d":766240,"h":81605144864,"f":4}],"i":[127401985],"j":[831776],"h":766240}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Threading.IThreadPoolWorkItem ]; }
            static get $fullName() { return `System.Threading.Channels.AsyncOperation`; }
        });
        
        $asm.$cls("$stc.System.Threading.Channels.Channel<>", (T) => $asm.$gt("$stc.System.Threading.Channels.Channel<>", [T], ($self) => class Channel$$ extends $.$stc.System.Threading.Channels.Channel$$$(T, T)
        {
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 1618208;
            static $g = 1;
            static $f = 0b1110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"c":[{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4}],"g":[T?.$h??1507328],"r":1,"h":this.$h}; }
            static get $b() { return $.$stc.System.Threading.Channels.Channel$$$(T, T); }
            static get $fullName() { return `System.Threading.Channels.Channel<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$stc.System.Threading.Channels.AsyncOperation<>", (TSelf) => $asm.$gt("$stc.System.Threading.Channels.AsyncOperation<>", [TSelf], ($self) => class AsyncOperation$$ extends $.$stc.System.Threading.Channels.AsyncOperation
        {
            $ctor$2(/*bool*/ runContinuationsAsynchronously, /*CancellationToken*/ cancellationToken, /*bool*/ pooled, /*Action<object?, CancellationToken>?*/ cancellationCallback)
            {
                super.$ctor$1(runContinuationsAsynchronously, cancellationToken, pooled, cancellationCallback);
                {
                }
                return this;
            }
            /*TSelf?*/ Next = null;
            /*TSelf?*/ Previous = null;
            /*ValueTask */ get ValueTask()
            {
                return new $.$spc.System.Threading.Tasks.ValueTask().$ctor$3(this, this._currentId);
            }
            /*ValueTaskSourceStatus */ GetStatus(/*short*/ token)
            {
                if (this._currentId !== token)
                {
                    $.$stc.System.Threading.Channels.AsyncOperation.ThrowIncorrectCurrentIdException();
                }
                return !this.IsCompleted ? 0/*ValueTaskSourceStatus.Pending*/ : this._error === null ? 1/*ValueTaskSourceStatus.Succeeded*/ : $.$is(this._error.SourceException, $.$spc.System.OperationCanceledException) ? 3/*ValueTaskSourceStatus.Canceled*/ : 2/*ValueTaskSourceStatus.Faulted*/;
            }
            /*void */ System$Threading$Tasks$Sources$IValueTaskSource$GetResult(/*short*/ token)
            {
                if (this._currentId !== token)
                {
                    $.$stc.System.Threading.Channels.AsyncOperation.ThrowIncorrectCurrentIdException();
                }
                if (!this.IsCompleted)
                {
                    $.$stc.System.Threading.Channels.AsyncOperation.ThrowIncompleteOperationException();
                }
                /*ExceptionDispatchInfo?*/ let error = this._error;
                this._currentId++;
                if (this._pooled)
                {
                    $.$ref(() => this._continuation, ($v) => this._continuation = $v, $.$spc.System.Action$$($.$spc.System.Object)).$v = $.$stc.System.Threading.Channels.AsyncOperation.s_availableSentinel;
                }
                error?.Throw();
            }
            //Generated interface implemetation for System.Threading.Tasks.Sources.IValueTaskSource.GetStatus(short)
            System$Threading$Tasks$Sources$IValueTaskSource$GetStatus()
            {
                return this.GetStatus(...arguments);
            }
            //Generated interface implemetation for System.Threading.Tasks.Sources.IValueTaskSource.OnCompleted(System.Action<object?>, object?, short, System.Threading.Tasks.Sources.ValueTaskSourceOnCompletedFlags)
            System$Threading$Tasks$Sources$IValueTaskSource$OnCompleted()
            {
                return this.OnCompleted(...arguments);
            }
            static $h = 962848;
            static $g = 1;
            static $f = 0b1110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":766240,"p":[{"p":TSelf?.$h??1507328,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":1},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x500000000n),"f":1},"n":"Next","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":1},{"p":TSelf?.$h??1507328,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x800000000n),"f":1},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x900000000n),"f":1},"n":"Previous","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":1},{"p":136118273,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xB00000000n),"f":1},"n":"ValueTask","d":this.$h,"h":Number(BigInt(this.$h)|0xA00000000n),"f":1}],"m":[{"r":133038081,"p":[{"n":"token","p":524289}],"n":"GetStatus","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":1}],"c":[{"p":[{"n":"runContinuationsAsynchronously","p":262145},{"n":"cancellationToken","p":125960193,"f":65},{"n":"pooled","p":262145,"f":65,"v":false},{"n":"cancellationCallback","p":$.$spc.System.Action$$$($.$spc.System.Object, $.$spc.System.Threading.CancellationToken).$h,"f":65}],"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4}],"i":[127401985,132710401],"g":[TSelf?.$h??1507328],"r":1,"h":this.$h}; }
            static get $b() { return $.$stc.System.Threading.Channels.AsyncOperation; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Threading.IThreadPoolWorkItem, $.$spc.System.Threading.Tasks.Sources.IValueTaskSource ]; }
            static get $fullName() { return `System.Threading.Channels.AsyncOperation<${TSelf?.$fullName}>`; }
        }));
        
        $asm.$cls("$stc.System.Threading.Channels.AsyncOperation<,>", (TSelf, TResult) => $asm.$gt("$stc.System.Threading.Channels.AsyncOperation<,>", [TSelf, TResult], ($self) => class AsyncOperation$$$ extends $.$stc.System.Threading.Channels.AsyncOperation$$(TSelf)
        {
            /*TResult?*/ _result = null;
            $ctor$3(/*bool*/ runContinuationsAsynchronously, /*CancellationToken*/ cancellationToken, /*bool*/ pooled, /*Action<object?, CancellationToken>?*/ cancellationCallback)
            {
                super.$ctor$2(runContinuationsAsynchronously, cancellationToken, pooled, cancellationCallback);
                {
                }
                return this;
            }
            /*ValueTask<TResult> */ get ValueTaskOfT()
            {
                return new ($.$spc.System.Threading.Tasks.ValueTask$$(TResult))().$ctor$4(this, this._currentId);
            }
            /*TResult */ GetResult(/*short*/ token)
            {
                if (this._currentId !== token)
                {
                    $.$stc.System.Threading.Channels.AsyncOperation.ThrowIncorrectCurrentIdException();
                }
                if (!this.IsCompleted)
                {
                    $.$stc.System.Threading.Channels.AsyncOperation.ThrowIncompleteOperationException();
                }
                /*ExceptionDispatchInfo?*/ let error = this._error;
                /*TResult?*/ let result = this._result;
                this._currentId++;
                if (this._pooled)
                {
                    $.$ref(() => this._continuation, ($v) => this._continuation = $v, $.$spc.System.Action$$($.$spc.System.Object)).$v = $.$stc.System.Threading.Channels.AsyncOperation.s_availableSentinel;
                }
                error?.Throw();
                return result;
            }
            /*bool */ TryOwnAndReset()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._pooled, "Should only be used for pooled objects");
                if ($.$spc.System.Object.ReferenceEquals($.$spc.System.Threading.Interlocked.CompareExchange$14($.$spc.System.Action$$($.$spc.System.Object), $.$ref(() => this._continuation, ($v) => this._continuation = $v, $.$spc.System.Action$$($.$spc.System.Object)), null, $.$stc.System.Threading.Channels.AsyncOperation.s_availableSentinel), $.$stc.System.Threading.Channels.AsyncOperation.s_availableSentinel))
                {
                    this._continuationState = null;
                    this._result = $.$default(TResult);
                    this._error = null;
                    this._capturedContext = null;
                    return true;
                }
                return false;
            }
            /*bool */ TrySetResult(/*TResult*/ result)
            {
                if (this.TryReserveCompletionIfCancelable())
                {
                    this.DangerousSetResult(result);
                    return true;
                }
                return false;
            }
            /*void */ DangerousSetResult(/*TResult*/ result)
            {
                this._result = result;
                this.SignalCompletion();
            }
            //Generated interface implemetation for System.Threading.Tasks.Sources.IValueTaskSource<TResult>.GetStatus(short)
            System$Threading$Tasks$Sources$IValueTaskSource$$$GetStatus()
            {
                return this.GetStatus(...arguments);
            }
            //Generated interface implemetation for System.Threading.Tasks.Sources.IValueTaskSource<TResult>.OnCompleted(System.Action<object?>, object?, short, System.Threading.Tasks.Sources.ValueTaskSourceOnCompletedFlags)
            System$Threading$Tasks$Sources$IValueTaskSource$$$OnCompleted()
            {
                return this.OnCompleted(...arguments);
            }
            //Generated interface implemetation for System.Threading.Tasks.Sources.IValueTaskSource<TResult>.GetResult(short)
            System$Threading$Tasks$Sources$IValueTaskSource$$$GetResult()
            {
                return this.GetResult(...arguments);
            }
            static $h = 897312;
            static $g = 2;
            static $f = 0b1110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":$.$spc.System.Threading.Tasks.ValueTask$$(TResult).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":1},"n":"ValueTaskOfT","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":1}],"m":[{"r":TResult?.$h??1572864,"p":[{"n":"token","p":524289}],"n":"GetResult","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":1},{"r":262145,"n":"TryOwnAndReset","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":1},{"r":262145,"p":[{"n":"result","p":TResult?.$h??1572864}],"n":"TrySetResult","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":1},{"r":65537,"p":[{"n":"result","p":TResult?.$h??1572864}],"n":"DangerousSetResult","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":1}],"l":[{"t":TResult?.$h??1572864,"n":"_result","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":2}],"c":[{"p":[{"n":"runContinuationsAsynchronously","p":262145},{"n":"cancellationToken","p":125960193,"f":65},{"n":"pooled","p":262145,"f":65,"v":false},{"n":"cancellationCallback","p":$.$spc.System.Action$$$($.$spc.System.Object, $.$spc.System.Threading.CancellationToken).$h,"f":65}],"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":1}],"i":[127401985,132710401,$.$spc.System.Threading.Tasks.Sources.IValueTaskSource$$(TResult).$h],"g":[TSelf?.$h??1507328,TResult?.$h??1572864],"r":2,"h":this.$h}; }
            static get $b() { return $.$stc.System.Threading.Channels.AsyncOperation$$(TSelf); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Threading.IThreadPoolWorkItem, $.$spc.System.Threading.Tasks.Sources.IValueTaskSource, $.$spc.System.Threading.Tasks.Sources.IValueTaskSource$$(TResult) ]; }
            static get $fullName() { return `System.Threading.Channels.AsyncOperation<${TSelf?.$fullName},${TResult?.$fullName}>`; }
        }));
        
        $asm.$cls("$stc.System.Threading.Channels.Channel", ($self) => class Channel
        {
            static /*Channel<T> */ CreateUnbounded(T)
            {
                return new ($.$stc.System.Threading.Channels.UnboundedChannel$$(T))().$ctor$3(true);
            }
            static /*Channel<T> */ CreateUnbounded$1(T, /*UnboundedChannelOptions*/ options)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(options, "options");
                if (options.SingleReader)
                {
                    return new ($.$stc.System.Threading.Channels.SingleConsumerUnboundedChannel$$(T))().$ctor$3(!options.AllowSynchronousContinuations);
                }
                return new ($.$stc.System.Threading.Channels.UnboundedChannel$$(T))().$ctor$3(!options.AllowSynchronousContinuations);
            }
            static /*Channel<T> */ CreateBounded(T, /*int*/ capacity)
            {
                return capacity > 0 ? new ($.$stc.System.Threading.Channels.BoundedChannel$$(T))().$ctor$3(capacity, 0/*BoundedChannelFullMode.Wait*/, true, null) : capacity === 0 ? new ($.$stc.System.Threading.Channels.RendezvousChannel$$(T))().$ctor$3(0/*BoundedChannelFullMode.Wait*/, true, null) : (() =>
                {
        throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("capacity")        })();
            }
            static /*Channel<T> */ CreateBounded$1(T, /*BoundedChannelOptions*/ options)
            {
                return $.$stc.System.Threading.Channels.Channel.CreateBounded$2(T, options, null);
            }
            static /*Channel<T> */ CreateBounded$2(T, /*BoundedChannelOptions*/ options, /*Action<T>?*/ itemDropped)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(options, "options");
                return options.Capacity > 0 ? new ($.$stc.System.Threading.Channels.BoundedChannel$$(T))().$ctor$3(options.Capacity, options.FullMode, !options.AllowSynchronousContinuations, itemDropped) : new ($.$stc.System.Threading.Channels.RendezvousChannel$$(T))().$ctor$3(options.FullMode, !options.AllowSynchronousContinuations, itemDropped);
            }
            static /*Channel<T> */ CreateUnboundedPrioritized(T)
            {
                return new ($.$stc.System.Threading.Channels.UnboundedPrioritizedChannel$$(T))().$ctor$3(true, null);
            }
            static /*Channel<T> */ CreateUnboundedPrioritized$1(T, /*UnboundedPrioritizedChannelOptions<T>*/ options)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(options, "options");
                return new ($.$stc.System.Threading.Channels.UnboundedPrioritizedChannel$$(T))().$ctor$3(!options.AllowSynchronousContinuations, options.Comparer);
            }
            static $h = 1487136;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":(T) => $.$stc.System.Threading.Channels.Channel$$(T).$h,"g":["T"],"n":"CreateUnbounded","d":1487136,"h":4296454432,"f":131105},{"r":(T) => $.$stc.System.Threading.Channels.Channel$$(T).$h,"p":[{"n":"options","p":2732320}],"g":["T"],"n":"CreateUnbounded","o":"@$1","d":1487136,"h":8591421728,"f":131105},{"r":(T) => $.$stc.System.Threading.Channels.Channel$$(T).$h,"p":[{"n":"capacity","p":655361}],"g":["T"],"n":"CreateBounded","d":1487136,"h":12886389024,"f":131105},{"r":(T) => $.$stc.System.Threading.Channels.Channel$$(T).$h,"p":[{"n":"options","p":1421600}],"g":["T"],"n":"CreateBounded","o":"@$1","d":1487136,"h":17181356320,"f":131105},{"r":(T) => $.$stc.System.Threading.Channels.Channel$$(T).$h,"p":[{"n":"options","p":1421600},{"n":"itemDropped","p":(T) => $.$spc.System.Action$$(T).$h}],"g":["T"],"n":"CreateBounded","o":"@$2","d":1487136,"h":21476323616,"f":131105},{"r":(T) => $.$stc.System.Threading.Channels.Channel$$(T).$h,"g":["T"],"n":"CreateUnboundedPrioritized","d":1487136,"h":25771290912,"f":131105},{"r":(T) => $.$stc.System.Threading.Channels.Channel$$(T).$h,"p":[{"n":"options","p":(T) => $.$stc.System.Threading.Channels.UnboundedPrioritizedChannelOptions$$(T).$h}],"g":["T"],"n":"CreateUnboundedPrioritized","o":"@$1","d":1487136,"h":30066258208,"f":131105}],"h":1487136}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Threading.Channels.Channel`; }
        });
        
        $asm.$cls("$stc.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$stc.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("System.Threading.Channels", $.$stc.System.SR.$type.Assembly);
                    $.$stc.System.SR.s_resourceManager = temp;
                }
                return $.$stc.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$stc.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$stc.System.SR.resourceCulture = value;
            }
            static /*string */ get ChannelClosedException_DefaultMessage()
            {
                return "The channel has been closed.";
            }
            static /*string */ get InvalidOperation_IncompleteAsyncOperation()
            {
                return "The asynchronous operation has not completed.";
            }
            static /*string */ get InvalidOperation_MultipleContinuations()
            {
                return "Another continuation was already registered.";
            }
            static /*string */ get InvalidOperation_IncorrectToken()
            {
                return "The result of the operation was already consumed and may not be used again.";
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$stc.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$stc.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$stc.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$stc.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$stc.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$stc.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$stc.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$stc.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$stc.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$stc.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$stc.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$stc.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$stc.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 700704;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":700704}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$stc.System.Threading.Channels.DebugEnumeratorDebugView<>", (T) => $asm.$gt("$stc.System.Threading.Channels.DebugEnumeratorDebugView<>", [T], ($self) => class DebugEnumeratorDebugView$$ extends $.$spc.System.Object
        {
            /*T[]*/ Items = null;
            //Begin primary constructor
            /*IDebugEnumerable<T>*/ enumerable = null;
            $ctor$1(/*IDebugEnumerable<T>*/$enumerable)
            {
                this.enumerable = $enumerable;
                //depends on primary constructor parameter
                this.Items = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray(T.$type, [ ...this.enumerable ], null, null);
                return this
            }
            //End primary constructor
            static $h = 2011424;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":0,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":1},"n":"Items","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":1,"a":[{"t":37421057,"c":4332388353,"a":[{"v":3,"t":37486593}]}]}],"c":[{"p":[{"n":"enumerable","p":$.$stc.System.Threading.Channels.IDebugEnumerable$$(T).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":1}],"g":[T?.$h??1507328],"r":1,"h":this.$h}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Threading.Channels.DebugEnumeratorDebugView<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$stc.System.Threading.Channels.ChannelUtilities", ($self) => class ChannelUtilities
        {
            /*Exception*/ static s_doneWritingSentinel = null;
            /*Task<bool>*/ static s_trueTask = null;
            /*Task<bool>*/ static s_falseTask = null;
            /*Task*/ static s_neverCompletingTask = null;
            static /*void */ Complete(/*TaskCompletionSource*/ tcs, /*Exception?*/ error)
            {
                let oce;
                if ($.$is(error, $.$spc.System.OperationCanceledException, { set $v(v){ oce = v; } }))
                {
                    tcs.TrySetCanceled$1(oce.CancellationToken);
                }
                else if (!(error === null) && error !== $.$stc.System.Threading.Channels.ChannelUtilities.s_doneWritingSentinel)
                {
                    if (tcs.TrySetException(error))
                    {
                        _ = tcs.Task.Exception;
                    }
                }
                else 
                {
                    tcs.TrySetResult();
                }
            }
            static /*ValueTask<T> */ GetInvalidCompletionValueTask(T, /*Exception*/ error)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(!(error === null), "error is not null");
                let oce;
                /*Task<T>*/ let t = error === $.$stc.System.Threading.Channels.ChannelUtilities.s_doneWritingSentinel ? $.$spc.System.Threading.Tasks.Task.FromException$1(T, $.$stc.System.Threading.Channels.ChannelUtilities.CreateInvalidCompletionException(null)) : $.$is(error, $.$spc.System.OperationCanceledException, { set $v(v){ oce = v; } }) ? $.$spc.System.Threading.Tasks.Task.FromCanceled$1(T, oce.CancellationToken.IsCancellationRequested ? oce.CancellationToken : new $.$spc.System.Threading.CancellationToken().$ctor$3(true)) : $.$spc.System.Threading.Tasks.Task.FromException$1(T, $.$stc.System.Threading.Channels.ChannelUtilities.CreateInvalidCompletionException(error));
                return new ($.$spc.System.Threading.Tasks.ValueTask$$(T))().$ctor$3(t);
            }
            static /*TAsyncOp? */ TryDequeueAndReserveCompletionIfCancelable(TAsyncOp, /*ref TAsyncOp?*/ head)
            {
                /*var*/ let op;
                while($.$stc.System.Threading.Channels.ChannelUtilities.TryDequeue(TAsyncOp, head, $.$ref(() => op, ($v) => op = $v, TAsyncOp)))
                {
                    if ($.$dsp(op, TAsyncOp, ($t) => $t.TryReserveCompletionIfCancelable,))
                    {
                        return op;
                    }
                }
                return null;
            }
            static /*bool */ TryDequeue(TAsyncOp, /*ref TAsyncOp?*/ head, /*out TAsyncOp?*/ op)
            {
                op.$v = head.$v;
                if (head.$v === null)
                {
                    return false;
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(!(head.$v.Previous === null), "head.Previous is not null");
                $.$spc.System.Diagnostics.Debug.Assert$1(!(head.$v.Next === null), "head.Next is not null");
                if ($.$box(head.$v.Next, TAsyncOp) === $.$box(head, TAsyncOp).$v)
                {
                    head.$v = null;
                }
                else 
                {
                    /*TAsyncOp*/ let last = head.$v.Previous;
                    head.$v = head.$v.Next;
                    head.$v.Previous = last;
                    last.Next = head.$v;
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(!(op.$v === null), "op is not null");
                op.$v.Next = op.$v.Previous = null;
                return true;
            }
            static /*void */ Enqueue(TAsyncOp, /*ref TAsyncOp?*/ head, /*TAsyncOp*/ op)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(op.Next === null && op.Previous === null, "op.Next is null && op.Previous is null");
                if (head.$v === null)
                {
                    head.$v = op.Next = op.Previous = op;
                }
                else 
                {
                    /*TAsyncOp*/ let last = head.$v.Previous;
                    $.$spc.System.Diagnostics.Debug.Assert$1(!(last === null), "last is not null");
                    op.Next = head.$v;
                    op.Previous = last;
                    last.Next = op;
                    head.$v.Previous = op;
                }
            }
            static /*void */ Remove(TAsyncOp, /*ref TAsyncOp?*/ head, /*TAsyncOp*/ op)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(!(op === null), "op is not null");
                $.$spc.System.Diagnostics.Debug.Assert$1(op.Next === null === op.Previous === null, "op.Next is null == op.Previous is null");
                if (head.$v === null || op.Next === null)
                {
                    return;
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(!(op.Previous === null), "op.Previous is not null");
                if ($.$box(op.Next, TAsyncOp) === $.$box(op, TAsyncOp))
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1($.$box(op.Previous, TAsyncOp) === $.$box(op, TAsyncOp), "op.Previous == op");
                    $.$spc.System.Diagnostics.Debug.Assert$1($.$box(head, TAsyncOp).$v === $.$box(op, TAsyncOp), "head == op");
                    head.$v = null;
                }
                else 
                {
                    op.Previous.Next = op.Next;
                    op.Next.Previous = op.Previous;
                    if ($.$box(head, TAsyncOp).$v === $.$box(op, TAsyncOp))
                    {
                        head.$v = op.Next;
                    }
                }
                op.Next = op.Previous = null;
            }
            static /*void */ SetOrFailOperations(TAsyncOp, T, /*TAsyncOp?*/ head, /*T*/ result, /*Exception?*/ error)
            {
                if (!(error === null))
                {
                    $.$stc.System.Threading.Channels.ChannelUtilities.FailOperations(TAsyncOp, head, error);
                }
                else 
                {
                    $.$stc.System.Threading.Channels.ChannelUtilities.SetOperations(TAsyncOp, T, $.$ref(() => head, ($v) => head = $v, TAsyncOp), result);
                }
            }
            static /*void */ SetOperations(TAsyncOp, TResult, /*ref TAsyncOp?*/ head, /*TResult*/ result)
            {
                /*TAsyncOp?*/ let current = head.$v;
                if (!(current === null))
                {
                    do
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(!(current === null), "current is not null");
                        /*TAsyncOp?*/ let next = current.Next;
                        $.$spc.System.Diagnostics.Debug.Assert$1(!(next === null), "next is not null");
                        current.Next = current.Previous = null;
                        $.$dsp(current, TAsyncOp, ($t) => $t.TrySetResult, result);
                        current = next;
                    }
                    while($.$box(current, TAsyncOp) !== $.$box(head, TAsyncOp).$v);
                    head.$v = null;
                }
            }
            static /*void */ DangerousSetOperations(TAsyncOp, TResult, /*TAsyncOp?*/ head, /*TResult*/ result)
            {
                /*TAsyncOp?*/ let current = head;
                if (!(current === null))
                {
                    do
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(!(current === null), "current is not null");
                        /*TAsyncOp?*/ let next = current.Next;
                        $.$spc.System.Diagnostics.Debug.Assert$1(!(next === null), "next is not null");
                        current.Next = current.Previous = null;
                        $.$dsp(current, TAsyncOp, ($t) => $t.DangerousSetResult, result);
                        current = next;
                    }
                    while($.$box(current, TAsyncOp) !== $.$box(head, TAsyncOp));
                }
            }
            static /*TAsyncOp? */ TryReserveCompletionIfCancelable(TAsyncOp, /*ref TAsyncOp?*/ head)
            {
                /*TAsyncOp?*/ let reserved = null;
                /*TAsyncOp?*/ let current = head.$v;
                if (!(current === null))
                {
                    do
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(!(current === null), "current is not null");
                        /*TAsyncOp?*/ let next = current.Next;
                        $.$spc.System.Diagnostics.Debug.Assert$1(!(next === null), "next is not null");
                        current.Next = current.Previous = null;
                        if ($.$dsp(current, TAsyncOp, ($t) => $t.TryReserveCompletionIfCancelable,))
                        {
                            $.$stc.System.Threading.Channels.ChannelUtilities.Enqueue(TAsyncOp, $.$ref(() => reserved, ($v) => reserved = $v, TAsyncOp), current);
                        }
                        current = next;
                    }
                    while($.$box(current, TAsyncOp) !== $.$box(head, TAsyncOp).$v);
                    head.$v = null;
                }
                return reserved;
            }
            static /*void */ FailOperations(TAsyncOp, /*TAsyncOp?*/ head, /*Exception*/ error)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(!(error === null), "error is not null");
                /*TAsyncOp?*/ let current = head;
                if (!(current === null))
                {
                    do
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(!(current === null), "current is not null");
                        /*TAsyncOp?*/ let next = current.Next;
                        $.$spc.System.Diagnostics.Debug.Assert$1(!(next === null), "next is not null");
                        current.Next = current.Previous = null;
                        $.$dsp(current, TAsyncOp, ($t) => $t.TrySetException, error);
                        current = next;
                    }
                    while($.$box(current, TAsyncOp) !== $.$box(head, TAsyncOp));
                }
            }
            static /*void */ AssertAll(TAsyncOp, /*TAsyncOp?*/ head, /*Func<TAsyncOp, bool>*/ condition, /*string*/ message)
            {
                /*TAsyncOp?*/ let current = head;
                if (!(current === null))
                {
                    do
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(!(current === null), "current is not null");
                        $.$spc.System.Diagnostics.Debug.Assert$1(condition.Invoke(current), message);
                        current = current.Next;
                    }
                    while($.$box(current, TAsyncOp) !== $.$box(head, TAsyncOp));
                }
            }
            static /*long */ CountOperations(TAsyncOp, /*TAsyncOp?*/ head)
            {
                /*TAsyncOp?*/ let current = head;
                /*long*/ let count = 0n;
                if (!(current === null))
                {
                    do
                    {
                        count++;
                        $.$spc.System.Diagnostics.Debug.Assert$1(!(current === null), "current is not null");
                        current = current.Next;
                    }
                    while($.$box(current, TAsyncOp) !== $.$box(head, TAsyncOp));
                }
                return count;
            }
            static /*Exception */ CreateInvalidCompletionException(/*Exception?*/ inner)
            {
                return $.$is(inner, $.$spc.System.OperationCanceledException) ? inner : !(inner === null) && inner !== $.$stc.System.Threading.Channels.ChannelUtilities.s_doneWritingSentinel ? new $.$stc.System.Threading.Channels.ChannelClosedException().$ctor$15(inner) : new $.$stc.System.Threading.Channels.ChannelClosedException().$ctor$13();
            }
            static /*void */ UnsafeQueueUserWorkItem(TState, /*Action<TState>*/ action, /*TState*/ state)
            {
                return $.$spc.System.Threading.ThreadPool.UnsafeQueueUserWorkItem(TState, action, state, false);
            }
            static /*void */ QueueUserWorkItem(/*Action<object?>*/ action, /*object?*/ state)
            {
                return $.$spc.System.Threading.ThreadPool.QueueUserWorkItem$2($.$spc.System.Object, action, state, false);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_doneWritingSentinel = new $.$spc.System.Exception().$ctor$2("s_doneWritingSentinel");
                }
                {
                    this.s_trueTask = $.$spc.System.Threading.Tasks.Task.FromResult($.$spc.System.Boolean, true);
                }
                {
                    this.s_falseTask = $.$spc.System.Threading.Tasks.Task.FromResult($.$spc.System.Boolean, false);
                }
                {
                    this.s_neverCompletingTask = new ($.$spc.System.Threading.Tasks.TaskCompletionSource$$($.$spc.System.Boolean))().$ctor$1().Task;
                }
            }
            static $h = 1880352;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"tcs","p":134414337},{"n":"error","p":47251457,"f":65}],"n":"Complete","d":1880352,"h":21476716832,"f":40},{"r":(T) => $.$spc.System.Threading.Tasks.ValueTask$$(T).$h,"p":[{"n":"error","p":47251457}],"g":["T"],"n":"GetInvalidCompletionValueTask","d":1880352,"h":25771684128,"f":131112},{"r":(TAsyncOp) => TAsyncOp.$h,"p":[{"n":"head","p":(TAsyncOp) => TAsyncOp.$h,"f":4}],"g":["TAsyncOp"],"n":"TryDequeueAndReserveCompletionIfCancelable","d":1880352,"h":30066651424,"f":131112},{"r":262145,"p":[{"n":"head","p":(TAsyncOp) => TAsyncOp.$h,"f":4},{"n":"op","p":(TAsyncOp) => TAsyncOp.$h,"f":2}],"g":["TAsyncOp"],"n":"TryDequeue","d":1880352,"h":34361618720,"f":131112},{"r":65537,"p":[{"n":"head","p":(TAsyncOp) => TAsyncOp.$h,"f":4},{"n":"op","p":(TAsyncOp) => TAsyncOp.$h}],"g":["TAsyncOp"],"n":"Enqueue","d":1880352,"h":38656586016,"f":131112},{"r":65537,"p":[{"n":"head","p":(TAsyncOp) => TAsyncOp.$h,"f":4},{"n":"op","p":(TAsyncOp) => TAsyncOp.$h}],"g":["TAsyncOp"],"n":"Remove","d":1880352,"h":42951553312,"f":131112},{"r":65537,"p":[{"n":"head","p":(TAsyncOp, T) => TAsyncOp.$h},{"n":"result","p":(TAsyncOp, T) => T.$h},{"n":"error","p":47251457,"f":65}],"g":["TAsyncOp","T"],"n":"SetOrFailOperations","d":1880352,"h":47246520608,"f":131112},{"r":65537,"p":[{"n":"head","p":(TAsyncOp, TResult) => TAsyncOp.$h,"f":4},{"n":"result","p":(TAsyncOp, TResult) => TResult.$h}],"g":["TAsyncOp","TResult"],"n":"SetOperations","d":1880352,"h":51541487904,"f":131112},{"r":65537,"p":[{"n":"head","p":(TAsyncOp, TResult) => TAsyncOp.$h},{"n":"result","p":(TAsyncOp, TResult) => TResult.$h}],"g":["TAsyncOp","TResult"],"n":"DangerousSetOperations","d":1880352,"h":55836455200,"f":131112},{"r":(TAsyncOp) => TAsyncOp.$h,"p":[{"n":"head","p":(TAsyncOp) => TAsyncOp.$h,"f":4}],"g":["TAsyncOp"],"n":"TryReserveCompletionIfCancelable","d":1880352,"h":60131422496,"f":131112},{"r":65537,"p":[{"n":"head","p":(TAsyncOp) => TAsyncOp.$h},{"n":"error","p":47251457}],"g":["TAsyncOp"],"n":"FailOperations","d":1880352,"h":64426389792,"f":131112},{"r":65537,"p":[{"n":"head","p":(TAsyncOp) => TAsyncOp.$h},{"n":"condition","p":(TAsyncOp) => $.$spc.System.Func$$$(TAsyncOp, $.$spc.System.Boolean).$h},{"n":"message","p":1310721}],"g":["TAsyncOp"],"n":"AssertAll","d":1880352,"h":68721357088,"f":131112,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"DEBUG","t":1310721}]}]},{"r":917505,"p":[{"n":"head","p":(TAsyncOp) => TAsyncOp.$h}],"g":["TAsyncOp"],"n":"CountOperations","d":1880352,"h":73016324384,"f":131112},{"r":47251457,"p":[{"n":"inner","p":47251457,"f":65}],"n":"CreateInvalidCompletionException","d":1880352,"h":77311291680,"f":40},{"r":65537,"p":[{"n":"action","p":(TState) => $.$spc.System.Action$$(TState).$h},{"n":"state","p":(TState) => TState.$h}],"g":["TState"],"n":"UnsafeQueueUserWorkItem","d":1880352,"h":81606258976,"f":131112},{"r":65537,"p":[{"n":"action","p":$.$spc.System.Action$$($.$spc.System.Object).$h},{"n":"state","p":131073}],"n":"QueueUserWorkItem","d":1880352,"h":85901226272,"f":40}],"l":[{"t":47251457,"n":"s_doneWritingSentinel","d":1880352,"h":4296847648,"f":40},{"t":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Boolean).$h,"n":"s_trueTask","d":1880352,"h":8591814944,"f":40},{"t":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Boolean).$h,"n":"s_falseTask","d":1880352,"h":12886782240,"f":40},{"t":133300225,"n":"s_neverCompletingTask","d":1880352,"h":17181749536,"f":40}],"h":1880352}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Threading.Channels.ChannelUtilities`; }
        });
        
        $asm.$cls("$stc.System.Collections.Generic.Deque<>", (T) => $asm.$gt("$stc.System.Collections.Generic.Deque<>", [T], ($self) => class Deque$$ extends $.$spc.System.Object
        {
            /*T[]*/ _array = null;
            /*int*/ _head = 0;
            /*int*/ _tail = 0;
            /*int*/ _size = 0;
            /*int */ get Count()
            {
                return this._size;
            }
            /*bool */ get IsEmpty()
            {
                return this._size === 0;
            }
            /*void */ EnqueueTail(/*T*/ item)
            {
                if (this._size === this._array.length)
                {
                    this.Grow();
                }
                $.$spc.System.Array.$WriteT1.call(this._array, item, this._tail);
                if (++this._tail === this._array.length)
                {
                    this._tail = 0;
                }
                this._size++;
            }
            /*T */ DequeueHead()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(!this.IsEmpty, "!IsEmpty");
                /*T*/ let item = $.$spc.System.Array.$ReadT1.call(this._array, this._head);
                $.$spc.System.Array.$WriteT1.call(this._array, $.$default(T), this._head);
                if (++this._head === this._array.length)
                {
                    this._head = 0;
                }
                this._size--;
                return item;
            }
            /*T */ PeekHead()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(!this.IsEmpty, "!IsEmpty");
                return $.$spc.System.Array.$ReadT1.call(this._array, this._head);
            }
            /*T */ PeekTail()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(!this.IsEmpty, "!IsEmpty");
                /*int*/ let index = ((this._tail - 1) | 0);
                if (index === -1)
                {
                    index = ((this._array.length - 1) | 0);
                }
                return $.$spc.System.Array.$ReadT1.call(this._array, index);
            }
            /*T */ DequeueTail()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(!this.IsEmpty, "!IsEmpty");
                if (--this._tail === -1)
                {
                    this._tail = ((this._array.length - 1) | 0);
                }
                /*T*/ let item = $.$spc.System.Array.$ReadT1.call(this._array, this._tail);
                $.$spc.System.Array.$WriteT1.call(this._array, $.$default(T), this._tail);
                this._size--;
                return item;
            }
            /*IEnumerator<T> */ GetEnumerator()
            {
                return new ($.$spc.NetJs.YieldToIterator$$(T))().$ctor$1(function*()
                {
                    /*int*/ let pos = this._head;
                    /*int*/ let count = this._size;
                    while(count-- > 0)
                    {
                        yield $.$spc.System.Array.$ReadT1.call(this._array, pos);
                        pos = (((pos + 1) | 0)) % this._array.length;
                    }
                }.bind(this)).GetEnumerator();
            }
            /*void */ Grow()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._size === this._array.length, "_size == _array.Length");
                $.$spc.System.Diagnostics.Debug.Assert$1(this._head === this._tail, "_head == _tail");
                /*int*/ let MinimumGrow = 4;
                /*int*/ let capacity = $.$cast((BigInt(this._array.length) * 2n), $.$spc.System.Int32);
                if (capacity < ((this._array.length + MinimumGrow) | 0))
                {
                    capacity = ((this._array.length + MinimumGrow) | 0);
                }
                /*T[]*/ let newArray = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(T), null, [capacity], null);
                if (this._head === 0)
                {
                    $.$spc.System.Array.Copy(this._array, newArray, this._size);
                }
                else 
                {
                    $.$spc.System.Array.Copy$1(this._array, this._head, newArray, 0, ((this._array.length - this._head) | 0));
                    $.$spc.System.Array.Copy$1(this._array, 0, newArray, ((this._array.length - this._head) | 0), this._tail);
                }
                this._array = newArray;
                this._head = 0;
                this._tail = this._size;
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this._array = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray(T.$type, [  ], null, null);
            }
            static $h = 569632;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x600000000n),"f":1},"n":"Count","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":1},{"p":262145,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x800000000n),"f":1},"n":"IsEmpty","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":1}],"m":[{"r":65537,"p":[{"n":"item","p":T?.$h??1507328}],"n":"EnqueueTail","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":1},{"r":T?.$h??1507328,"n":"DequeueHead","d":this.$h,"h":Number(BigInt(this.$h)|0xA00000000n),"f":1},{"r":T?.$h??1507328,"n":"PeekHead","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":1},{"r":T?.$h??1507328,"n":"PeekTail","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":1},{"r":T?.$h??1507328,"n":"DequeueTail","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":1},{"r":$.$spc.System.Collections.Generic.IEnumerator$$(T).$h,"n":"GetEnumerator","d":this.$h,"h":Number(BigInt(this.$h)|0xE00000000n),"f":1},{"r":65537,"n":"Grow","d":this.$h,"h":Number(BigInt(this.$h)|0xF00000000n),"f":2}],"l":[{"t":0,"n":"_array","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":2},{"t":655361,"n":"_head","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2},{"t":655361,"n":"_tail","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2},{"t":655361,"n":"_size","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1000000000n),"f":1}],"g":[T?.$h??1507328],"r":1,"h":this.$h,"a":[{"t":37617665,"c":8627552257,"a":[{"v":"Count = {_size}","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Collections.Generic.Deque<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$stc.System.Obsoletions", ($self) => class Obsoletions
        {
            /*string*/ static SharedUrlFormat = null;
            /*string*/ static SystemTextEncodingUTF7Message = null;
            /*string*/ static SystemTextEncodingUTF7DiagId = null;
            /*string*/ static PrincipalPermissionAttributeMessage = null;
            /*string*/ static PrincipalPermissionAttributeDiagId = null;
            /*string*/ static CodeAccessSecurityMessage = null;
            /*string*/ static CodeAccessSecurityDiagId = null;
            /*string*/ static ConstrainedExecutionRegionMessage = null;
            /*string*/ static ConstrainedExecutionRegionDiagId = null;
            /*string*/ static GlobalAssemblyCacheMessage = null;
            /*string*/ static GlobalAssemblyCacheDiagId = null;
            /*string*/ static ThreadAbortMessage = null;
            /*string*/ static ThreadResetAbortMessage = null;
            /*string*/ static ThreadAbortDiagId = null;
            /*string*/ static DefaultCryptoAlgorithmsMessage = null;
            /*string*/ static DefaultCryptoAlgorithmsDiagId = null;
            /*string*/ static CreatePdbGeneratorMessage = null;
            /*string*/ static CreatePdbGeneratorDiagId = null;
            /*string*/ static AuthenticationManagerMessage = null;
            /*string*/ static AuthenticationManagerDiagId = null;
            /*string*/ static RemotingApisMessage = null;
            /*string*/ static RemotingApisDiagId = null;
            /*string*/ static BinaryFormatterMessage = null;
            /*string*/ static BinaryFormatterDiagId = null;
            /*string*/ static CodeBaseMessage = null;
            /*string*/ static CodeBaseDiagId = null;
            /*string*/ static EscapeUriStringMessage = null;
            /*string*/ static EscapeUriStringDiagId = null;
            /*string*/ static WebRequestMessage = null;
            /*string*/ static WebRequestDiagId = null;
            /*string*/ static DisablePrivateReflectionAttributeMessage = null;
            /*string*/ static DisablePrivateReflectionAttributeDiagId = null;
            /*string*/ static GetContextInfoMessage = null;
            /*string*/ static GetContextInfoDiagId = null;
            /*string*/ static StrongNameKeyPairMessage = null;
            /*string*/ static StrongNameKeyPairDiagId = null;
            /*string*/ static ReflectionOnlyLoadingMessage = null;
            /*string*/ static ReflectionOnlyLoadingDiagId = null;
            /*string*/ static RuntimeEnvironmentMessage = null;
            /*string*/ static RuntimeEnvironmentDiagId = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesMessage = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesDiagId = null;
            /*string*/ static DerivedCryptographicTypesMessage = null;
            /*string*/ static DerivedCryptographicTypesDiagId = null;
            /*string*/ static RijndaelMessage = null;
            /*string*/ static RijndaelDiagId = null;
            /*string*/ static RNGCryptoServiceProviderMessage = null;
            /*string*/ static RNGCryptoServiceProviderDiagId = null;
            /*string*/ static AppDomainCreateUnloadMessage = null;
            /*string*/ static AppDomainCreateUnloadDiagId = null;
            /*string*/ static SuppressIldasmAttributeMessage = null;
            /*string*/ static SuppressIldasmAttributeDiagId = null;
            /*string*/ static X509CertificateImmutableMessage = null;
            /*string*/ static X509CertificateImmutableDiagId = null;
            /*string*/ static PublicKeyPropertyMessage = null;
            /*string*/ static PublicKeyPropertyDiagId = null;
            /*string*/ static X509CertificatePrivateKeyMessage = null;
            /*string*/ static X509CertificatePrivateKeyDiagId = null;
            /*string*/ static ProduceLegacyHmacValuesMessage = null;
            /*string*/ static ProduceLegacyHmacValuesDiagId = null;
            /*string*/ static UseManagedSha1Message = null;
            /*string*/ static UseManagedSha1DiagId = null;
            /*string*/ static CryptoConfigEncodeOIDMessage = null;
            /*string*/ static CryptoConfigEncodeOIDDiagId = null;
            /*string*/ static CorruptedStateRecoveryMessage = null;
            /*string*/ static CorruptedStateRecoveryDiagId = null;
            /*string*/ static Rfc2898CryptDeriveKeyMessage = null;
            /*string*/ static Rfc2898CryptDeriveKeyDiagId = null;
            /*string*/ static CmsSignerCspParamsCtorMessage = null;
            /*string*/ static CmsSignerCspParamsCtorDiagId = null;
            /*string*/ static SignerInfoCounterSigMessage = null;
            /*string*/ static SignerInfoCounterSigDiagId = null;
            /*string*/ static RegexCompileToAssemblyMessage = null;
            /*string*/ static RegexCompileToAssemblyDiagId = null;
            /*string*/ static AssemblyNameMembersMessage = null;
            /*string*/ static AssemblyNameMembersDiagId = null;
            /*string*/ static SystemDataSerializationFormatBinaryMessage = null;
            /*string*/ static SystemDataSerializationFormatBinaryDiagId = null;
            /*string*/ static TlsVersion10and11Message = null;
            /*string*/ static TlsVersion10and11DiagId = null;
            /*string*/ static EncryptionPolicyMessage = null;
            /*string*/ static EncryptionPolicyDiagId = null;
            /*string*/ static EccXmlExportImportMessage = null;
            /*string*/ static EccXmlExportImportDiagId = null;
            /*string*/ static EcDhPublicKeyBlobMessage = null;
            /*string*/ static EcDhPublicKeyBlobDiagId = null;
            /*string*/ static AssemblyNameCodeBaseMessage = null;
            /*string*/ static AssemblyNameCodeBaseDiagId = null;
            /*string*/ static CryptoStringFactoryMessage = null;
            /*string*/ static CryptoStringFactoryDiagId = null;
            /*string*/ static ControlledExecutionRunMessage = null;
            /*string*/ static ControlledExecutionRunDiagId = null;
            /*string*/ static XmlSecureResolverMessage = null;
            /*string*/ static XmlSecureResolverDiagId = null;
            /*string*/ static RsaEncryptDecryptValueMessage = null;
            /*string*/ static RsaEncryptDecryptDiagId = null;
            /*string*/ static JsonSerializerOptionsAddContextMessage = null;
            /*string*/ static JsonSerializerOptionsAddContextDiagId = null;
            /*string*/ static LegacyFormatterMessage = null;
            /*string*/ static LegacyFormatterDiagId = null;
            /*string*/ static LegacyFormatterImplMessage = null;
            /*string*/ static LegacyFormatterImplDiagId = null;
            /*string*/ static RegexExtensibilityImplMessage = null;
            /*string*/ static RegexExtensibilityDiagId = null;
            /*string*/ static AesGcmTagConstructorMessage = null;
            /*string*/ static AesGcmTagConstructorDiagId = null;
            /*string*/ static ThreadVolatileReadWriteMessage = null;
            /*string*/ static ThreadVolatileReadWriteDiagId = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationMessage = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationDiagId = null;
            /*string*/ static LoadFromHashAlgorithmMessage = null;
            /*string*/ static LoadFromHashAlgorithmDiagId = null;
            /*string*/ static X509CtorCertDataObsoleteMessage = null;
            /*string*/ static X509CtorCertDataObsoleteDiagId = null;
            /*string*/ static TlsCipherAlgorithmEnumsMessage = null;
            /*string*/ static TlsCipherAlgorithmEnumsDiagId = null;
            /*string*/ static SystemEventsEventsThreadShutdownMessage = null;
            /*string*/ static SystemEventsEventsThreadShutdownDiagId = null;
            /*string*/ static Rfc2898DeriveBytesCtorMessage = null;
            /*string*/ static Rfc2898DeriveBytesCtorDiagId = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteMessage = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteDiagId = null;
            /*string*/ static XsltSettingsEnableScriptMessage = null;
            /*string*/ static XsltSettingsEnableScriptDiagId = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                }
                {
                    this.SystemTextEncodingUTF7Message = "The UTF-7 encoding is insecure and should not be used. Consider using UTF-8 instead.";
                }
                {
                    this.SystemTextEncodingUTF7DiagId = "SYSLIB0001";
                }
                {
                    this.PrincipalPermissionAttributeMessage = "PrincipalPermissionAttribute is not honored by the runtime and must not be used.";
                }
                {
                    this.PrincipalPermissionAttributeDiagId = "SYSLIB0002";
                }
                {
                    this.CodeAccessSecurityMessage = "Code Access Security is not supported or honored by the runtime.";
                }
                {
                    this.CodeAccessSecurityDiagId = "SYSLIB0003";
                }
                {
                    this.ConstrainedExecutionRegionMessage = "The Constrained Execution Region (CER) feature is not supported.";
                }
                {
                    this.ConstrainedExecutionRegionDiagId = "SYSLIB0004";
                }
                {
                    this.GlobalAssemblyCacheMessage = "The Global Assembly Cache is not supported.";
                }
                {
                    this.GlobalAssemblyCacheDiagId = "SYSLIB0005";
                }
                {
                    this.ThreadAbortMessage = "Thread.Abort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadResetAbortMessage = "Thread.ResetAbort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadAbortDiagId = "SYSLIB0006";
                }
                {
                    this.DefaultCryptoAlgorithmsMessage = "The default implementation of this cryptography algorithm is not supported.";
                }
                {
                    this.DefaultCryptoAlgorithmsDiagId = "SYSLIB0007";
                }
                {
                    this.CreatePdbGeneratorMessage = "The CreatePdbGenerator API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.CreatePdbGeneratorDiagId = "SYSLIB0008";
                }
                {
                    this.AuthenticationManagerMessage = "AuthenticationManager is not supported. Methods will no-op or throw PlatformNotSupportedException.";
                }
                {
                    this.AuthenticationManagerDiagId = "SYSLIB0009";
                }
                {
                    this.RemotingApisMessage = "This Remoting API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.RemotingApisDiagId = "SYSLIB0010";
                }
                {
                    this.BinaryFormatterMessage = "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.";
                }
                {
                    this.BinaryFormatterDiagId = "SYSLIB0011";
                }
                {
                    this.CodeBaseMessage = "Assembly.CodeBase and Assembly.EscapedCodeBase are only included for .NET Framework compatibility. Use Assembly.Location instead.";
                }
                {
                    this.CodeBaseDiagId = "SYSLIB0012";
                }
                {
                    this.EscapeUriStringMessage = "Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.";
                }
                {
                    this.EscapeUriStringDiagId = "SYSLIB0013";
                }
                {
                    this.WebRequestMessage = "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.";
                }
                {
                    this.WebRequestDiagId = "SYSLIB0014";
                }
                {
                    this.DisablePrivateReflectionAttributeMessage = "DisablePrivateReflectionAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.DisablePrivateReflectionAttributeDiagId = "SYSLIB0015";
                }
                {
                    this.GetContextInfoMessage = "Use the Graphics.GetContextInfo overloads that accept arguments for better performance and fewer allocations.";
                }
                {
                    this.GetContextInfoDiagId = "SYSLIB0016";
                }
                {
                    this.StrongNameKeyPairMessage = "Strong name signing is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.StrongNameKeyPairDiagId = "SYSLIB0017";
                }
                {
                    this.ReflectionOnlyLoadingMessage = "ReflectionOnly loading is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ReflectionOnlyLoadingDiagId = "SYSLIB0018";
                }
                {
                    this.RuntimeEnvironmentMessage = "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.";
                }
                {
                    this.RuntimeEnvironmentDiagId = "SYSLIB0019";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesMessage = "JsonSerializerOptions.IgnoreNullValues is obsolete. To ignore null values when serializing, set DefaultIgnoreCondition to JsonIgnoreCondition.WhenWritingNull.";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesDiagId = "SYSLIB0020";
                }
                {
                    this.DerivedCryptographicTypesMessage = "Derived cryptographic types are obsolete. Use the Create method on the base type instead.";
                }
                {
                    this.DerivedCryptographicTypesDiagId = "SYSLIB0021";
                }
                {
                    this.RijndaelMessage = "The Rijndael and RijndaelManaged types are obsolete. Use Aes instead.";
                }
                {
                    this.RijndaelDiagId = "SYSLIB0022";
                }
                {
                    this.RNGCryptoServiceProviderMessage = "RNGCryptoServiceProvider is obsolete. To generate a random number, use one of the RandomNumberGenerator static methods instead.";
                }
                {
                    this.RNGCryptoServiceProviderDiagId = "SYSLIB0023";
                }
                {
                    this.AppDomainCreateUnloadMessage = "Creating and unloading AppDomains is not supported and throws an exception.";
                }
                {
                    this.AppDomainCreateUnloadDiagId = "SYSLIB0024";
                }
                {
                    this.SuppressIldasmAttributeMessage = "SuppressIldasmAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.SuppressIldasmAttributeDiagId = "SYSLIB0025";
                }
                {
                    this.X509CertificateImmutableMessage = "X509Certificate and X509Certificate2 are immutable. Use X509CertificateLoader to create a new certificate.";
                }
                {
                    this.X509CertificateImmutableDiagId = "SYSLIB0026";
                }
                {
                    this.PublicKeyPropertyMessage = "PublicKey.Key is obsolete. Use the appropriate method to get the public key, such as GetRSAPublicKey.";
                }
                {
                    this.PublicKeyPropertyDiagId = "SYSLIB0027";
                }
                {
                    this.X509CertificatePrivateKeyMessage = "X509Certificate2.PrivateKey is obsolete. Use the appropriate method to get the private key, such as GetRSAPrivateKey, or use the CopyWithPrivateKey method to create a new instance with a private key.";
                }
                {
                    this.X509CertificatePrivateKeyDiagId = "SYSLIB0028";
                }
                {
                    this.ProduceLegacyHmacValuesMessage = "ProduceLegacyHmacValues is obsolete. Producing legacy HMAC values is not supported.";
                }
                {
                    this.ProduceLegacyHmacValuesDiagId = "SYSLIB0029";
                }
                {
                    this.UseManagedSha1Message = "HMACSHA1 always uses the algorithm implementation provided by the platform. Use a constructor without the useManagedSha1 parameter.";
                }
                {
                    this.UseManagedSha1DiagId = "SYSLIB0030";
                }
                {
                    this.CryptoConfigEncodeOIDMessage = "EncodeOID is obsolete. Use the ASN.1 functionality provided in System.Formats.Asn1.";
                }
                {
                    this.CryptoConfigEncodeOIDDiagId = "SYSLIB0031";
                }
                {
                    this.CorruptedStateRecoveryMessage = "Recovery from corrupted process state exceptions is not supported; HandleProcessCorruptedStateExceptionsAttribute is ignored.";
                }
                {
                    this.CorruptedStateRecoveryDiagId = "SYSLIB0032";
                }
                {
                    this.Rfc2898CryptDeriveKeyMessage = "Rfc2898DeriveBytes.CryptDeriveKey is obsolete and is not supported. Use PasswordDeriveBytes.CryptDeriveKey instead.";
                }
                {
                    this.Rfc2898CryptDeriveKeyDiagId = "SYSLIB0033";
                }
                {
                    this.CmsSignerCspParamsCtorMessage = "CmsSigner(CspParameters) is obsolete and is not supported. Use an alternative constructor instead.";
                }
                {
                    this.CmsSignerCspParamsCtorDiagId = "SYSLIB0034";
                }
                {
                    this.SignerInfoCounterSigMessage = "ComputeCounterSignature without specifying a CmsSigner is obsolete and is not supported. Use the overload that accepts a CmsSigner.";
                }
                {
                    this.SignerInfoCounterSigDiagId = "SYSLIB0035";
                }
                {
                    this.RegexCompileToAssemblyMessage = "Regex.CompileToAssembly is obsolete and not supported. Use the GeneratedRegexAttribute with the regular expression source generator instead.";
                }
                {
                    this.RegexCompileToAssemblyDiagId = "SYSLIB0036";
                }
                {
                    this.AssemblyNameMembersMessage = "AssemblyName members HashAlgorithm, ProcessorArchitecture, and VersionCompatibility are obsolete and not supported.";
                }
                {
                    this.AssemblyNameMembersDiagId = "SYSLIB0037";
                }
                {
                    this.SystemDataSerializationFormatBinaryMessage = "SerializationFormat.Binary is obsolete and should not be used. See https://aka.ms/serializationformat-binary-obsolete for more information.";
                }
                {
                    this.SystemDataSerializationFormatBinaryDiagId = "SYSLIB0038";
                }
                {
                    this.TlsVersion10and11Message = "TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.";
                }
                {
                    this.TlsVersion10and11DiagId = "SYSLIB0039";
                }
                {
                    this.EncryptionPolicyMessage = "EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.";
                }
                {
                    this.EncryptionPolicyDiagId = "SYSLIB0040";
                }
                {
                    this.EccXmlExportImportMessage = "ToXmlString and FromXmlString have no implementation for ECC types, and are obsolete. Use a standard import and export format such as ExportSubjectPublicKeyInfo or ImportSubjectPublicKeyInfo for public keys and ExportPkcs8PrivateKey or ImportPkcs8PrivateKey for private keys.";
                }
                {
                    this.EccXmlExportImportDiagId = "SYSLIB0042";
                }
                {
                    this.EcDhPublicKeyBlobMessage = "ECDiffieHellmanPublicKey.ToByteArray() and the associated constructor do not have a consistent and interoperable implementation on all platforms. Use ECDiffieHellmanPublicKey.ExportSubjectPublicKeyInfo() instead.";
                }
                {
                    this.EcDhPublicKeyBlobDiagId = "SYSLIB0043";
                }
                {
                    this.AssemblyNameCodeBaseMessage = "AssemblyName.CodeBase and AssemblyName.EscapedCodeBase are obsolete. Using them for loading an assembly is not supported.";
                }
                {
                    this.AssemblyNameCodeBaseDiagId = "SYSLIB0044";
                }
                {
                    this.CryptoStringFactoryMessage = "Cryptographic factory methods accepting an algorithm name are obsolete. Use the parameterless Create factory method on the algorithm type instead.";
                }
                {
                    this.CryptoStringFactoryDiagId = "SYSLIB0045";
                }
                {
                    this.ControlledExecutionRunMessage = "ControlledExecution.Run method may corrupt the process and should not be used in production code.";
                }
                {
                    this.ControlledExecutionRunDiagId = "SYSLIB0046";
                }
                {
                    this.XmlSecureResolverMessage = "XmlSecureResolver is obsolete. Use XmlResolver.ThrowingResolver instead when attempting to forbid XML external entity resolution.";
                }
                {
                    this.XmlSecureResolverDiagId = "SYSLIB0047";
                }
                {
                    this.RsaEncryptDecryptValueMessage = "RSA.EncryptValue and DecryptValue are not supported and throw NotSupportedException. Use RSA.Encrypt and RSA.Decrypt instead.";
                }
                {
                    this.RsaEncryptDecryptDiagId = "SYSLIB0048";
                }
                {
                    this.JsonSerializerOptionsAddContextMessage = "JsonSerializerOptions.AddContext is obsolete. To register a JsonSerializerContext, use either the TypeInfoResolver or TypeInfoResolverChain properties.";
                }
                {
                    this.JsonSerializerOptionsAddContextDiagId = "SYSLIB0049";
                }
                {
                    this.LegacyFormatterMessage = "Formatter-based serialization is obsolete and should not be used.";
                }
                {
                    this.LegacyFormatterDiagId = "SYSLIB0050";
                }
                {
                    this.LegacyFormatterImplMessage = "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.";
                }
                {
                    this.LegacyFormatterImplDiagId = "SYSLIB0051";
                }
                {
                    this.RegexExtensibilityImplMessage = "This API supports obsolete mechanisms for Regex extensibility. It is not supported.";
                }
                {
                    this.RegexExtensibilityDiagId = "SYSLIB0052";
                }
                {
                    this.AesGcmTagConstructorMessage = "AesGcm should indicate the required tag size for encryption and decryption. Use a constructor that accepts the tag size.";
                }
                {
                    this.AesGcmTagConstructorDiagId = "SYSLIB0053";
                }
                {
                    this.ThreadVolatileReadWriteMessage = "Thread.VolatileRead and Thread.VolatileWrite are obsolete. Use Volatile.Read or Volatile.Write respectively instead.";
                }
                {
                    this.ThreadVolatileReadWriteDiagId = "SYSLIB0054";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationMessage = "The underlying hardware instruction does not perform a signed saturate narrowing operation, and it always returns an unsigned result. Use the unsigned overload instead.";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationDiagId = "SYSLIB0055";
                }
                {
                    this.LoadFromHashAlgorithmMessage = "LoadFrom with a custom AssemblyHashAlgorithm is obsolete. Use overloads without an AssemblyHashAlgorithm.";
                }
                {
                    this.LoadFromHashAlgorithmDiagId = "SYSLIB0056";
                }
                {
                    this.X509CtorCertDataObsoleteMessage = "Loading certificate data through the constructor or Import is obsolete. Use X509CertificateLoader instead to load certificates.";
                }
                {
                    this.X509CtorCertDataObsoleteDiagId = "SYSLIB0057";
                }
                {
                    this.TlsCipherAlgorithmEnumsMessage = "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.";
                }
                {
                    this.TlsCipherAlgorithmEnumsDiagId = "SYSLIB0058";
                }
                {
                    this.SystemEventsEventsThreadShutdownMessage = "SystemEvents.EventsThreadShutdown callbacks are not run before the process exits. Use AppDomain.ProcessExit instead.";
                }
                {
                    this.SystemEventsEventsThreadShutdownDiagId = "SYSLIB0059";
                }
                {
                    this.Rfc2898DeriveBytesCtorMessage = "The constructors on Rfc2898DeriveBytes are obsolete. Use the static Pbkdf2 method instead.";
                }
                {
                    this.Rfc2898DeriveBytesCtorDiagId = "SYSLIB0060";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteMessage = "The Queryable MinBy and MaxBy taking an IComparer<TSource> are obsolete. Use the new ones that take an IComparer<TKey>.";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteDiagId = "SYSLIB0061";
                }
                {
                    this.XsltSettingsEnableScriptMessage = "XSLT Script blocks are not supported.";
                }
                {
                    this.XsltSettingsEnableScriptDiagId = "SYSLIB0062";
                }
            }
            static $h = 635168;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"SharedUrlFormat","d":635168,"h":4295602464,"f":40},{"t":1310721,"n":"SystemTextEncodingUTF7Message","d":635168,"h":8590569760,"f":40},{"t":1310721,"n":"SystemTextEncodingUTF7DiagId","d":635168,"h":12885537056,"f":40},{"t":1310721,"n":"PrincipalPermissionAttributeMessage","d":635168,"h":17180504352,"f":40},{"t":1310721,"n":"PrincipalPermissionAttributeDiagId","d":635168,"h":21475471648,"f":40},{"t":1310721,"n":"CodeAccessSecurityMessage","d":635168,"h":25770438944,"f":40},{"t":1310721,"n":"CodeAccessSecurityDiagId","d":635168,"h":30065406240,"f":40},{"t":1310721,"n":"ConstrainedExecutionRegionMessage","d":635168,"h":34360373536,"f":40},{"t":1310721,"n":"ConstrainedExecutionRegionDiagId","d":635168,"h":38655340832,"f":40},{"t":1310721,"n":"GlobalAssemblyCacheMessage","d":635168,"h":42950308128,"f":40},{"t":1310721,"n":"GlobalAssemblyCacheDiagId","d":635168,"h":47245275424,"f":40},{"t":1310721,"n":"ThreadAbortMessage","d":635168,"h":51540242720,"f":40},{"t":1310721,"n":"ThreadResetAbortMessage","d":635168,"h":55835210016,"f":40},{"t":1310721,"n":"ThreadAbortDiagId","d":635168,"h":60130177312,"f":40},{"t":1310721,"n":"DefaultCryptoAlgorithmsMessage","d":635168,"h":64425144608,"f":40},{"t":1310721,"n":"DefaultCryptoAlgorithmsDiagId","d":635168,"h":68720111904,"f":40},{"t":1310721,"n":"CreatePdbGeneratorMessage","d":635168,"h":73015079200,"f":40},{"t":1310721,"n":"CreatePdbGeneratorDiagId","d":635168,"h":77310046496,"f":40},{"t":1310721,"n":"AuthenticationManagerMessage","d":635168,"h":81605013792,"f":40},{"t":1310721,"n":"AuthenticationManagerDiagId","d":635168,"h":85899981088,"f":40},{"t":1310721,"n":"RemotingApisMessage","d":635168,"h":90194948384,"f":40},{"t":1310721,"n":"RemotingApisDiagId","d":635168,"h":94489915680,"f":40},{"t":1310721,"n":"BinaryFormatterMessage","d":635168,"h":98784882976,"f":40},{"t":1310721,"n":"BinaryFormatterDiagId","d":635168,"h":103079850272,"f":40},{"t":1310721,"n":"CodeBaseMessage","d":635168,"h":107374817568,"f":40},{"t":1310721,"n":"CodeBaseDiagId","d":635168,"h":111669784864,"f":40},{"t":1310721,"n":"EscapeUriStringMessage","d":635168,"h":115964752160,"f":40},{"t":1310721,"n":"EscapeUriStringDiagId","d":635168,"h":120259719456,"f":40},{"t":1310721,"n":"WebRequestMessage","d":635168,"h":124554686752,"f":40},{"t":1310721,"n":"WebRequestDiagId","d":635168,"h":128849654048,"f":40},{"t":1310721,"n":"DisablePrivateReflectionAttributeMessage","d":635168,"h":133144621344,"f":40},{"t":1310721,"n":"DisablePrivateReflectionAttributeDiagId","d":635168,"h":137439588640,"f":40},{"t":1310721,"n":"GetContextInfoMessage","d":635168,"h":141734555936,"f":40},{"t":1310721,"n":"GetContextInfoDiagId","d":635168,"h":146029523232,"f":40},{"t":1310721,"n":"StrongNameKeyPairMessage","d":635168,"h":150324490528,"f":40},{"t":1310721,"n":"StrongNameKeyPairDiagId","d":635168,"h":154619457824,"f":40},{"t":1310721,"n":"ReflectionOnlyLoadingMessage","d":635168,"h":158914425120,"f":40},{"t":1310721,"n":"ReflectionOnlyLoadingDiagId","d":635168,"h":163209392416,"f":40},{"t":1310721,"n":"RuntimeEnvironmentMessage","d":635168,"h":167504359712,"f":40},{"t":1310721,"n":"RuntimeEnvironmentDiagId","d":635168,"h":171799327008,"f":40},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesMessage","d":635168,"h":176094294304,"f":40},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesDiagId","d":635168,"h":180389261600,"f":40},{"t":1310721,"n":"DerivedCryptographicTypesMessage","d":635168,"h":184684228896,"f":40},{"t":1310721,"n":"DerivedCryptographicTypesDiagId","d":635168,"h":188979196192,"f":40},{"t":1310721,"n":"RijndaelMessage","d":635168,"h":193274163488,"f":40},{"t":1310721,"n":"RijndaelDiagId","d":635168,"h":197569130784,"f":40},{"t":1310721,"n":"RNGCryptoServiceProviderMessage","d":635168,"h":201864098080,"f":40},{"t":1310721,"n":"RNGCryptoServiceProviderDiagId","d":635168,"h":206159065376,"f":40},{"t":1310721,"n":"AppDomainCreateUnloadMessage","d":635168,"h":210454032672,"f":40},{"t":1310721,"n":"AppDomainCreateUnloadDiagId","d":635168,"h":214748999968,"f":40},{"t":1310721,"n":"SuppressIldasmAttributeMessage","d":635168,"h":219043967264,"f":40},{"t":1310721,"n":"SuppressIldasmAttributeDiagId","d":635168,"h":223338934560,"f":40},{"t":1310721,"n":"X509CertificateImmutableMessage","d":635168,"h":227633901856,"f":40},{"t":1310721,"n":"X509CertificateImmutableDiagId","d":635168,"h":231928869152,"f":40},{"t":1310721,"n":"PublicKeyPropertyMessage","d":635168,"h":236223836448,"f":40},{"t":1310721,"n":"PublicKeyPropertyDiagId","d":635168,"h":240518803744,"f":40},{"t":1310721,"n":"X509CertificatePrivateKeyMessage","d":635168,"h":244813771040,"f":40},{"t":1310721,"n":"X509CertificatePrivateKeyDiagId","d":635168,"h":249108738336,"f":40},{"t":1310721,"n":"ProduceLegacyHmacValuesMessage","d":635168,"h":253403705632,"f":40},{"t":1310721,"n":"ProduceLegacyHmacValuesDiagId","d":635168,"h":257698672928,"f":40},{"t":1310721,"n":"UseManagedSha1Message","d":635168,"h":261993640224,"f":40},{"t":1310721,"n":"UseManagedSha1DiagId","d":635168,"h":266288607520,"f":40},{"t":1310721,"n":"CryptoConfigEncodeOIDMessage","d":635168,"h":270583574816,"f":40},{"t":1310721,"n":"CryptoConfigEncodeOIDDiagId","d":635168,"h":274878542112,"f":40},{"t":1310721,"n":"CorruptedStateRecoveryMessage","d":635168,"h":279173509408,"f":40},{"t":1310721,"n":"CorruptedStateRecoveryDiagId","d":635168,"h":283468476704,"f":40},{"t":1310721,"n":"Rfc2898CryptDeriveKeyMessage","d":635168,"h":287763444000,"f":40},{"t":1310721,"n":"Rfc2898CryptDeriveKeyDiagId","d":635168,"h":292058411296,"f":40},{"t":1310721,"n":"CmsSignerCspParamsCtorMessage","d":635168,"h":296353378592,"f":40},{"t":1310721,"n":"CmsSignerCspParamsCtorDiagId","d":635168,"h":300648345888,"f":40},{"t":1310721,"n":"SignerInfoCounterSigMessage","d":635168,"h":304943313184,"f":40},{"t":1310721,"n":"SignerInfoCounterSigDiagId","d":635168,"h":309238280480,"f":40},{"t":1310721,"n":"RegexCompileToAssemblyMessage","d":635168,"h":313533247776,"f":40},{"t":1310721,"n":"RegexCompileToAssemblyDiagId","d":635168,"h":317828215072,"f":40},{"t":1310721,"n":"AssemblyNameMembersMessage","d":635168,"h":322123182368,"f":40},{"t":1310721,"n":"AssemblyNameMembersDiagId","d":635168,"h":326418149664,"f":40},{"t":1310721,"n":"SystemDataSerializationFormatBinaryMessage","d":635168,"h":330713116960,"f":40},{"t":1310721,"n":"SystemDataSerializationFormatBinaryDiagId","d":635168,"h":335008084256,"f":40},{"t":1310721,"n":"TlsVersion10and11Message","d":635168,"h":339303051552,"f":40},{"t":1310721,"n":"TlsVersion10and11DiagId","d":635168,"h":343598018848,"f":40},{"t":1310721,"n":"EncryptionPolicyMessage","d":635168,"h":347892986144,"f":40},{"t":1310721,"n":"EncryptionPolicyDiagId","d":635168,"h":352187953440,"f":40},{"t":1310721,"n":"EccXmlExportImportMessage","d":635168,"h":356482920736,"f":40},{"t":1310721,"n":"EccXmlExportImportDiagId","d":635168,"h":360777888032,"f":40},{"t":1310721,"n":"EcDhPublicKeyBlobMessage","d":635168,"h":365072855328,"f":40},{"t":1310721,"n":"EcDhPublicKeyBlobDiagId","d":635168,"h":369367822624,"f":40},{"t":1310721,"n":"AssemblyNameCodeBaseMessage","d":635168,"h":373662789920,"f":40},{"t":1310721,"n":"AssemblyNameCodeBaseDiagId","d":635168,"h":377957757216,"f":40},{"t":1310721,"n":"CryptoStringFactoryMessage","d":635168,"h":382252724512,"f":40},{"t":1310721,"n":"CryptoStringFactoryDiagId","d":635168,"h":386547691808,"f":40},{"t":1310721,"n":"ControlledExecutionRunMessage","d":635168,"h":390842659104,"f":40},{"t":1310721,"n":"ControlledExecutionRunDiagId","d":635168,"h":395137626400,"f":40},{"t":1310721,"n":"XmlSecureResolverMessage","d":635168,"h":399432593696,"f":40},{"t":1310721,"n":"XmlSecureResolverDiagId","d":635168,"h":403727560992,"f":40},{"t":1310721,"n":"RsaEncryptDecryptValueMessage","d":635168,"h":408022528288,"f":40},{"t":1310721,"n":"RsaEncryptDecryptDiagId","d":635168,"h":412317495584,"f":40},{"t":1310721,"n":"JsonSerializerOptionsAddContextMessage","d":635168,"h":416612462880,"f":40},{"t":1310721,"n":"JsonSerializerOptionsAddContextDiagId","d":635168,"h":420907430176,"f":40},{"t":1310721,"n":"LegacyFormatterMessage","d":635168,"h":425202397472,"f":40},{"t":1310721,"n":"LegacyFormatterDiagId","d":635168,"h":429497364768,"f":40},{"t":1310721,"n":"LegacyFormatterImplMessage","d":635168,"h":433792332064,"f":40},{"t":1310721,"n":"LegacyFormatterImplDiagId","d":635168,"h":438087299360,"f":40},{"t":1310721,"n":"RegexExtensibilityImplMessage","d":635168,"h":442382266656,"f":40},{"t":1310721,"n":"RegexExtensibilityDiagId","d":635168,"h":446677233952,"f":40},{"t":1310721,"n":"AesGcmTagConstructorMessage","d":635168,"h":450972201248,"f":40},{"t":1310721,"n":"AesGcmTagConstructorDiagId","d":635168,"h":455267168544,"f":40},{"t":1310721,"n":"ThreadVolatileReadWriteMessage","d":635168,"h":459562135840,"f":40},{"t":1310721,"n":"ThreadVolatileReadWriteDiagId","d":635168,"h":463857103136,"f":40},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationMessage","d":635168,"h":468152070432,"f":40},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationDiagId","d":635168,"h":472447037728,"f":40},{"t":1310721,"n":"LoadFromHashAlgorithmMessage","d":635168,"h":476742005024,"f":40},{"t":1310721,"n":"LoadFromHashAlgorithmDiagId","d":635168,"h":481036972320,"f":40},{"t":1310721,"n":"X509CtorCertDataObsoleteMessage","d":635168,"h":485331939616,"f":40},{"t":1310721,"n":"X509CtorCertDataObsoleteDiagId","d":635168,"h":489626906912,"f":40},{"t":1310721,"n":"TlsCipherAlgorithmEnumsMessage","d":635168,"h":493921874208,"f":40},{"t":1310721,"n":"TlsCipherAlgorithmEnumsDiagId","d":635168,"h":498216841504,"f":40},{"t":1310721,"n":"SystemEventsEventsThreadShutdownMessage","d":635168,"h":502511808800,"f":40},{"t":1310721,"n":"SystemEventsEventsThreadShutdownDiagId","d":635168,"h":506806776096,"f":40},{"t":1310721,"n":"Rfc2898DeriveBytesCtorMessage","d":635168,"h":511101743392,"f":40},{"t":1310721,"n":"Rfc2898DeriveBytesCtorDiagId","d":635168,"h":515396710688,"f":40},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteMessage","d":635168,"h":519691677984,"f":40},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteDiagId","d":635168,"h":523986645280,"f":40},{"t":1310721,"n":"XsltSettingsEnableScriptMessage","d":635168,"h":528281612576,"f":40},{"t":1310721,"n":"XsltSettingsEnableScriptDiagId","d":635168,"h":532576579872,"f":40}],"h":635168}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Obsoletions`; }
        });
        
        $asm.$cls("$stc.Internal.PaddingHelpers", ($self) => class PaddingHelpers
        {
            /*int*/ static CACHE_LINE_SIZE = 128;
            static $h = 176416;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"CACHE_LINE_SIZE","d":176416,"h":4295143712,"f":40}],"h":176416}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Internal.PaddingHelpers`; }
        });
        
        $asm.$cls("$stc.System.Collections.Concurrent.SingleProducerSingleConsumerQueue<>", (T) => $asm.$gt("$stc.System.Collections.Concurrent.SingleProducerSingleConsumerQueue<>", [T], ($self) => class SingleProducerSingleConsumerQueue$$ extends $.$spc.System.Object
        {
            /*int*/ static InitialSegmentSize = 32;
            /*int*/ static MaxSegmentSize = 16777216;
            /*Segment*/ _head = null;
            /*Segment*/ _tail = null;
            $ctor$1()
            {
                super.$ctor();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(32/*InitialSegmentSize*/ > 0, "Initial segment size must be > 0.");
                    $.$spc.System.Diagnostics.Debug.Assert$1((32/*InitialSegmentSize*/ & (((32/*InitialSegmentSize*/ - 1) | 0))) === 0, "Initial segment size must be a power of 2");
                    $.$spc.System.Diagnostics.Debug.Assert$1(32/*InitialSegmentSize*/ <= 16777216/*MaxSegmentSize*/, "Initial segment size should be <= maximum.");
                    $.$spc.System.Diagnostics.Debug.Assert$1(16777216/*MaxSegmentSize*/ < $.trunc(2147483647/*int.MaxValue*/ / 2), "Max segment size * 2 must be < int.MaxValue, or else overflow could occur.");
                    this._head = this._tail = new ($.$stc.System.Collections.Concurrent.SingleProducerSingleConsumerQueue$$(T).Segment)().$ctor$1(32/*InitialSegmentSize*/);
                }
                return this;
            }
            /*void */ Enqueue(/*T*/ item)
            {
                /*Segment*/ let segment = this._tail;
                /*T[]*/ let array = segment._array;
                /*int*/ let last = segment._state._last;
                /*int*/ let tail2 = (((last + 1) | 0)) & (((array.length - 1) | 0));
                if (tail2 !== segment._state._firstCopy)
                {
                    $.$spc.System.Array.$WriteT1.call(array, item, last);
                    segment._state._last = tail2;
                    return;
                }
                this.EnqueueSlow(item, $.$ref(() => segment, ($v) => segment = $v, $.$stc.System.Collections.Concurrent.SingleProducerSingleConsumerQueue$$(T).Segment));
            }
            /*void */ EnqueueSlow(/*T*/ item, /*ref Segment*/ segment)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(!(segment.$v === null), "Expected a non-null segment.");
                if (segment.$v._state._firstCopy !== segment.$v._state._first)
                {
                    segment.$v._state._firstCopy = segment.$v._state._first;
                    this.Enqueue(item);
                    return;
                }
                /*int*/ let newSegmentSize = $.$spc.System.Math.Min$4(((this._tail._array.length * 2) | 0), 16777216/*MaxSegmentSize*/);
                $.$spc.System.Diagnostics.Debug.Assert$1(newSegmentSize > 0, "The max size should always be small enough that we don't overflow.");
                /*var*/ let newSegment = new ($.$stc.System.Collections.Concurrent.SingleProducerSingleConsumerQueue$$(T).Segment)().$ctor$1(newSegmentSize);
                $.$spc.System.Array.$WriteT1.call(newSegment._array, item, 0);
                newSegment._state._last = 1;
                newSegment._state._lastCopy = 1;
                try
                {
                }
                finally
                {
                    {
                        $.$ref(() => this._tail._next, ($v) => this._tail._next = $v, $.$stc.System.Collections.Concurrent.SingleProducerSingleConsumerQueue$$(T).Segment).$v = newSegment;
                        this._tail = newSegment;
                    }
                }
            }
            /*bool */ TryDequeue(/*out T*/ result)
            {
                /*Segment*/ let segment = this._head;
                /*T[]*/ let array = segment._array;
                /*int*/ let first = segment._state._first;
                if (first !== segment._state._lastCopy)
                {
                    result.$v = $.$spc.System.Array.$ReadT1.call(array, first);
                    $.$spc.System.Array.$WriteT1.call(array, $.$default(T), first);
                    segment._state._first = (((first + 1) | 0)) & (((array.length - 1) | 0));
                    return true;
                }
                return this.TryDequeueSlow(segment, array, false, result);
            }
            /*bool */ TryPeek(/*out T*/ result)
            {
                /*Segment*/ let segment = this._head;
                /*T[]*/ let array = segment._array;
                /*int*/ let first = segment._state._first;
                if (first !== segment._state._lastCopy)
                {
                    result.$v = $.$spc.System.Array.$ReadT1.call(array, first);
                    return true;
                }
                return this.TryDequeueSlow(segment, array, true, result);
            }
            /*bool */ TryDequeueSlow(/*Segment*/ segment, /*T[]*/ array, /*bool*/ peek, /*out T*/ result)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(!(segment === null), "Expected a non-null segment.");
                $.$spc.System.Diagnostics.Debug.Assert$1(!(array === null), "Expected a non-null item array.");
                if (segment._state._last !== segment._state._lastCopy)
                {
                    segment._state._lastCopy = segment._state._last;
                    return peek ? this.TryPeek(result) : this.TryDequeue(result);
                }
                if (!(segment._next === null) && segment._state._first === segment._state._last)
                {
                    segment = segment._next;
                    array = segment._array;
                    this._head = segment;
                }
                /*int*/ let first = segment._state._first;
                if (first === segment._state._last)
                {
                    result.$v = $.$default(T);
                    return false;
                }
                result.$v = $.$spc.System.Array.$ReadT1.call(array, first);
                if (!peek)
                {
                    $.$spc.System.Array.$WriteT1.call(array, $.$default(T), first);
                    segment._state._first = (((first + 1) | 0)) & (((segment._array.length - 1) | 0));
                    segment._state._lastCopy = segment._state._last;
                }
                return true;
            }
            /*bool */ TryDequeueIf(/*Predicate<T>?*/ predicate, /*out T*/ result)
            {
                /*Segment*/ let segment = this._head;
                /*T[]*/ let array = segment._array;
                /*int*/ let first = segment._state._first;
                if (first !== segment._state._lastCopy)
                {
                    result.$v = $.$spc.System.Array.$ReadT1.call(array, first);
                    if (predicate === null || predicate.Invoke(result.$v))
                    {
                        $.$spc.System.Array.$WriteT1.call(array, $.$default(T), first);
                        segment._state._first = (((first + 1) | 0)) & (((array.length - 1) | 0));
                        return true;
                    }
                    result.$v = $.$default(T);
                    return false;
                }
                return this.TryDequeueIfSlow(predicate, segment, array, result);
            }
            /*bool */ TryDequeueIfSlow(/*Predicate<T>?*/ predicate, /*Segment*/ segment, /*T[]*/ array, /*out T*/ result)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(!(segment === null), "Expected a non-null segment.");
                $.$spc.System.Diagnostics.Debug.Assert$1(!(array === null), "Expected a non-null item array.");
                if (segment._state._last !== segment._state._lastCopy)
                {
                    segment._state._lastCopy = segment._state._last;
                    return this.TryDequeueIf(predicate, result);
                }
                if (!(segment._next === null) && segment._state._first === segment._state._last)
                {
                    segment = segment._next;
                    array = segment._array;
                    this._head = segment;
                }
                /*int*/ let first = segment._state._first;
                if (first === segment._state._last)
                {
                    result.$v = $.$default(T);
                    return false;
                }
                result.$v = $.$spc.System.Array.$ReadT1.call(array, first);
                if (predicate === null || predicate.Invoke(result.$v))
                {
                    $.$spc.System.Array.$WriteT1.call(array, $.$default(T), first);
                    segment._state._first = (((first + 1) | 0)) & (((segment._array.length - 1) | 0));
                    segment._state._lastCopy = segment._state._last;
                    return true;
                }
                result.$v = $.$default(T);
                return false;
            }
            /*void */ Clear()
            {
                while(this.TryDequeue($.$discardRef()))
                {
                }
            }
            /*bool */ get IsEmpty()
            {
                /*Segment*/ let head = this._head;
                if (head._state._first !== head._state._lastCopy)
                {
                    return false;
                }
                if (head._state._first !== head._state._last)
                {
                    return false;
                }
                return head._next === null;
            }
            /*IEnumerator<T> */ GetEnumerator()
            {
                return new ($.$spc.NetJs.YieldToIterator$$(T))().$ctor$1(function*()
                {
                    for(/*Segment?*/ let segment = this._head; !(segment === null); segment = segment._next)
                    {
                        for(/*int*/ let pt = segment._state._first; pt !== segment._state._last; pt = (((pt + 1) | 0)) & (((segment._array.length - 1) | 0)))
                        {
                            yield $.$spc.System.Array.$ReadT1.call(segment._array, pt);
                        }
                    }
                }.bind(this)).GetEnumerator();
            }
            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                return this.GetEnumerator();
            }
            /*int */ get Count()
            {
                /*int*/ let count = 0;
                for(/*Segment?*/ let segment = this._head; !(segment === null); segment = segment._next)
                {
                    /*int*/ let arraySize = segment._array.length;
                    /*int*/ let first, last;
                    while(true)
                    {
                        first = segment._state._first;
                        last = segment._state._last;
                        if (first === segment._state._first)
                        {
                            break;
                        }
                    }
                    count += (((last - first) | 0)) & (((arraySize - 1) | 0));
                }
                return count;
            }
            /*int */ System$Collections$Concurrent$IProducerConsumerQueue$$$GetCountSafe(/*object*/ syncObj)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(!(syncObj === null), "The syncObj parameter is null.");
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(syncObj)
                    {
                        return this.Count;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(syncObj)
                }
            }
            static $_Segment;
            static get Segment()
            {
                let $cls = $.$stc.System.Collections.Concurrent.SingleProducerSingleConsumerQueue$$(T);
                return $cls.$_Segment ??= $asm.$ncls("$stc.System.Collections.Concurrent.SingleProducerSingleConsumerQueue$$.Segment", ($self) => class Segment extends $.$spc.System.Object
                {
                    /*Segment?*/  get _next() { return this.$getField(0, 4); }
                    /*Segment?*/  set _next(value) { this.$setField(0, 4, value); }
                    /*T[]*/  get _array() { return this.$getField(4, 4); }
                    /*T[]*/  set _array(value) { this.$setField(4, 4, value); }
                    /*SegmentState*/  get _state() { return this.$getField(8, 388); }
                    /*SegmentState*/  set _state(value) { this.$setField(8, 388, value); }
                    $ctor$1(/*int*/ size)
                    {
                        super.$ctor();
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1((size & (((size - 1) | 0))) === 0, "Size must be a power of 2");
                            this._array = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(T), null, [size], null);
                        }
                        return this;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._next = null;
                        this._array = null;
                        this._state = $.$default($.$stc.System.Collections.Concurrent.SingleProducerSingleConsumerQueue$$(T).SegmentState);
                    }
                    static $h = 438560;
                    static $f = 0b100010000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":this.$h,"n":"_next","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":8},{"t":0,"n":"_array","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":8},{"t":$.$stc.System.Collections.Concurrent.SingleProducerSingleConsumerQueue$$(T).SegmentState.$h,"n":"_state","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":8}],"c":[{"p":[{"n":"size","p":655361}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":8}],"d":$.$stc.System.Collections.Concurrent.SingleProducerSingleConsumerQueue$$(T).$h,"h":this.$h,"a":[{"t":109903873,"c":4404871169,"a":[{"v":0,"t":105381889}]}]}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Collections.Concurrent.SingleProducerSingleConsumerQueue<${T?.$fullName}>.Segment`; }
                }, $cls, ($v) => $cls.$_Segment = $v);
            }
            static $_SegmentState;
            static get SegmentState()
            {
                let $cls = $.$stc.System.Collections.Concurrent.SingleProducerSingleConsumerQueue$$(T);
                return $cls.$_SegmentState ??= $asm.$nstr("$stc.System.Collections.Concurrent.SingleProducerSingleConsumerQueue$$.SegmentState", ($self) => class SegmentState extends $.$spc.System.ValueType
                {
                    /*PaddingFor32*/  get _pad0() { return this.$getField(0, 124); }
                    /*PaddingFor32*/  set _pad0(value) { this.$setField(0, 124, value); }
                    /*int*/  get _first() { return this.$getField(124, 4); }
                    /*int*/  set _first(value) { this.$setField(124, 4, value); }
                    /*int*/  get _lastCopy() { return this.$getField(128, 4); }
                    /*int*/  set _lastCopy(value) { this.$setField(128, 4, value); }
                    /*PaddingFor32*/  get _pad1() { return this.$getField(132, 124); }
                    /*PaddingFor32*/  set _pad1(value) { this.$setField(132, 124, value); }
                    /*int*/  get _firstCopy() { return this.$getField(256, 4); }
                    /*int*/  set _firstCopy(value) { this.$setField(256, 4, value); }
                    /*int*/  get _last() { return this.$getField(260, 4); }
                    /*int*/  set _last(value) { this.$setField(260, 4, value); }
                    /*PaddingFor32*/  get _pad2() { return this.$getField(264, 124); }
                    /*PaddingFor32*/  set _pad2(value) { this.$setField(264, 124, value); }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._pad0 = this._pad0.Clone();
                        copy._first = this._first;
                        copy._lastCopy = this._lastCopy;
                        copy._pad1 = this._pad1.Clone();
                        copy._firstCopy = this._firstCopy;
                        copy._last = this._last;
                        copy._pad2 = this._pad2.Clone();
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._pad0 = $.$default($.$stc.Internal.PaddingFor32);
                        this._first = 0;
                        this._lastCopy = 0;
                        this._pad1 = $.$default($.$stc.Internal.PaddingFor32);
                        this._firstCopy = 0;
                        this._last = 0;
                        this._pad2 = $.$default($.$stc.Internal.PaddingFor32);
                    }
                    static $h = 504096;
                    static $z = 388;
                    static $f = 0b100010000001011000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":110880,"n":"_pad0","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":8},{"t":655361,"n":"_first","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":8},{"t":655361,"n":"_lastCopy","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":8},{"t":110880,"n":"_pad1","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":8},{"t":655361,"n":"_firstCopy","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":8},{"t":655361,"n":"_last","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":8},{"t":110880,"n":"_pad2","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":8}],"c":[{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":1}],"d":$.$stc.System.Collections.Concurrent.SingleProducerSingleConsumerQueue$$(T).$h,"h":this.$h,"a":[{"t":109903873,"c":4404871169,"a":[{"v":0,"t":105381889}]}]}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `System.Collections.Concurrent.SingleProducerSingleConsumerQueue<${T?.$fullName}>.SegmentState`; }
                }, $cls, ($v) => $cls.$_SegmentState = $v);
            }
            //Generated interface implemetation for System.Collections.Concurrent.IProducerConsumerQueue<T>.Enqueue(T)
            System$Collections$Concurrent$IProducerConsumerQueue$$$Enqueue()
            {
                return this.Enqueue(...arguments);
            }
            //Generated interface implemetation for System.Collections.Concurrent.IProducerConsumerQueue<T>.TryDequeue(out T)
            System$Collections$Concurrent$IProducerConsumerQueue$$$TryDequeue()
            {
                return this.TryDequeue(...arguments);
            }
            //Generated interface implemetation for System.Collections.Concurrent.IProducerConsumerQueue<T>.IsEmpty.get
            get System$Collections$Concurrent$IProducerConsumerQueue$$$IsEmpty()
            {
                return this.IsEmpty;
            }
            //Generated interface implemetation for System.Collections.Concurrent.IProducerConsumerQueue<T>.Count.get
            get System$Collections$Concurrent$IProducerConsumerQueue$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<T>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 373024;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xF00000000n),"f":1},"n":"IsEmpty","d":this.$h,"h":Number(BigInt(this.$h)|0xE00000000n),"f":1},{"p":655361,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1300000000n),"f":1},"n":"Count","d":this.$h,"h":Number(BigInt(this.$h)|0x1200000000n),"f":1}],"m":[{"r":65537,"p":[{"n":"item","p":T?.$h??1507328}],"n":"Enqueue","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":1},{"r":65537,"p":[{"n":"item","p":T?.$h??1507328},{"n":"segment","p":$.$stc.System.Collections.Concurrent.SingleProducerSingleConsumerQueue$$(T).Segment.$h,"f":4}],"n":"EnqueueSlow","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":2},{"r":262145,"p":[{"n":"result","p":T?.$h??1507328,"f":2}],"n":"TryDequeue","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":1},{"r":262145,"p":[{"n":"result","p":T?.$h??1507328,"f":2}],"n":"TryPeek","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":1},{"r":262145,"p":[{"n":"segment","p":$.$stc.System.Collections.Concurrent.SingleProducerSingleConsumerQueue$$(T).Segment.$h},{"n":"array","p":0},{"n":"peek","p":262145},{"n":"result","p":T?.$h??1507328,"f":2}],"n":"TryDequeueSlow","d":this.$h,"h":Number(BigInt(this.$h)|0xA00000000n),"f":2},{"r":262145,"p":[{"n":"predicate","p":$.$spc.System.Predicate$$(T).$h},{"n":"result","p":T?.$h??1507328,"f":2}],"n":"TryDequeueIf","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":1},{"r":262145,"p":[{"n":"predicate","p":$.$spc.System.Predicate$$(T).$h},{"n":"segment","p":$.$stc.System.Collections.Concurrent.SingleProducerSingleConsumerQueue$$(T).Segment.$h},{"n":"array","p":0},{"n":"result","p":T?.$h??1507328,"f":2}],"n":"TryDequeueIfSlow","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":2},{"r":65537,"n":"Clear","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":1},{"r":$.$spc.System.Collections.Generic.IEnumerator$$(T).$h,"n":"GetEnumerator","d":this.$h,"h":Number(BigInt(this.$h)|0x1000000000n),"f":1}],"l":[{"t":655361,"n":"InitialSegmentSize","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":34},{"t":655361,"n":"MaxSegmentSize","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":34},{"t":$.$stc.System.Collections.Concurrent.SingleProducerSingleConsumerQueue$$(T).Segment.$h,"n":"_head","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2},{"t":$.$stc.System.Collections.Concurrent.SingleProducerSingleConsumerQueue$$(T).Segment.$h,"n":"_tail","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":1}],"i":[$.$stc.System.Collections.Concurrent.IProducerConsumerQueue$$(T).$h,$.$spc.System.Collections.Generic.IEnumerable$$(T).$h,31653889],"g":[T?.$h??1507328],"j":[$.$stc.System.Collections.Concurrent.SingleProducerSingleConsumerQueue$$(T).Segment.$h,$.$stc.System.Collections.Concurrent.SingleProducerSingleConsumerQueue$$(T).SegmentState.$h],"r":1,"h":this.$h,"a":[{"t":37617665,"c":8627552257,"a":[{"v":"Count = {Count}","t":1310721}]},{"t":37945345,"c":8627879937,"a":[{"v":null,"t":142606337}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stc.System.Collections.Concurrent.IProducerConsumerQueue$$(T), $.$spc.System.Collections.Generic.IEnumerable$$(T), $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Collections.Concurrent.SingleProducerSingleConsumerQueue<${T?.$fullName}>`; }
        }));
        
        $asm.$str("$stc.System.VoidResult", ($self) => class VoidResult extends $.$spc.System.ValueType
        {
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                return copy;
            }
            static $h = 3191072;
            static $z = 0;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"c":[{"n":".ctor","o":"$ctor$2","d":3191072,"h":4298158368,"f":1}],"h":3191072}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.VoidResult`; }
        });
        
        $asm.$cls("$stc.System.Threading.Channels.BoundedChannelOptions", ($self) => class BoundedChannelOptions extends $.$stc.System.Threading.Channels.ChannelOptions
        {
            /*int*/ _capacity = 0;
            /*BoundedChannelFullMode*/ _mode = 0;
            $ctor$2(/*int*/ capacity)
            {
                super.$ctor$1();
                {
                    if (capacity < 0)
                    {
                        throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("capacity");
                    }
                    this._capacity = capacity;
                }
                return this;
            }
            /*int */ get Capacity()
            {
                return this._capacity;
            }
            /*int */ set Capacity(value)
            {
                if (value < 0)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("value");
                }
                this._capacity = value;
            }
            /*BoundedChannelFullMode */ get FullMode()
            {
                return this._mode;
            }
            /*BoundedChannelFullMode */ set FullMode(value)
            {
                switch(value)
                {
                    case 0/*BoundedChannelFullMode.Wait*/:
                    case 1/*BoundedChannelFullMode.DropNewest*/:
                    case 2/*BoundedChannelFullMode.DropOldest*/:
                    case 3/*BoundedChannelFullMode.DropWrite*/:
                    this._mode = value;
                    break;
                    default:
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("value");
                }
            }
            static $h = 1421600;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1749280,"p":[{"p":655361,"g":{"r":0,"d":0,"h":21476258080,"f":1},"s":{"r":0,"d":0,"h":25771225376,"f":1},"n":"Capacity","d":1421600,"h":17181290784,"f":1},{"p":1356064,"g":{"r":0,"d":0,"h":34361159968,"f":1},"s":{"r":0,"d":0,"h":38656127264,"f":1},"n":"FullMode","d":1421600,"h":30066192672,"f":1}],"l":[{"t":655361,"n":"_capacity","d":1421600,"h":4296388896,"f":2},{"t":1356064,"n":"_mode","d":1421600,"h":8591356192,"f":2}],"c":[{"p":[{"n":"capacity","p":655361}],"n":".ctor","o":"$ctor$2","d":1421600,"h":12886323488,"f":1}],"h":1421600}; }
            static get $b() { return $.$stc.System.Threading.Channels.ChannelOptions; }
            static get $fullName() { return `System.Threading.Channels.BoundedChannelOptions`; }
        });
        
        $asm.$cls("$stc.System.Threading.Channels.UnboundedPrioritizedChannelOptions<>", (T) => $asm.$gt("$stc.System.Threading.Channels.UnboundedPrioritizedChannelOptions<>", [T], ($self) => class UnboundedPrioritizedChannelOptions$$ extends $.$stc.System.Threading.Channels.ChannelOptions
        {
            /*IComparer<T>?*/ Comparer = null;
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 2994464;
            static $g = 1;
            static $f = 0b11010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1749280,"p":[{"p":$.$spc.System.Collections.Generic.IComparer$$(T).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x300000000n),"f":1},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":1},"n":"Comparer","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":1}],"g":[T?.$h??1507328],"r":1,"h":this.$h}; }
            static get $b() { return $.$stc.System.Threading.Channels.ChannelOptions; }
            static get $fullName() { return `System.Threading.Channels.UnboundedPrioritizedChannelOptions<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$stc.System.Threading.Channels.UnboundedChannelOptions", ($self) => class UnboundedChannelOptions extends $.$stc.System.Threading.Channels.ChannelOptions
        {
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 2732320;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1749280,"c":[{"n":".ctor","o":"$ctor$2","d":2732320,"h":4297699616,"f":1}],"h":2732320}; }
            static get $b() { return $.$stc.System.Threading.Channels.ChannelOptions; }
            static get $fullName() { return `System.Threading.Channels.UnboundedChannelOptions`; }
        });
        
        $asm.$str("$stc.Internal.PaddingFor32", ($self) => class PaddingFor32 extends $.$spc.System.ValueType
        {
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                return copy;
            }
            static $h = 110880;
            static $z = 124;
            static $f = 0b100000000001010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"c":[{"n":".ctor","o":"$ctor$2","d":110880,"h":4295078176,"f":1}],"h":110880,"a":[{"t":109903873,"c":4404871169,"a":[{"v":2,"t":105381889}],"n":[{"n":"Size","v":124,"t":655361}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `Internal.PaddingFor32`; }
        });
        
        $asm.$cls("$stc.System.Threading.Channels.RendezvousChannel<>", (T) => $asm.$gt("$stc.System.Threading.Channels.RendezvousChannel<>", [T], ($self) => class RendezvousChannel$$ extends $.$stc.System.Threading.Channels.Channel$$(T)
        {
            /*bool*/ _dropWrites = false;
            /*Action<T>?*/ _itemDropped = null;
            /*TaskCompletionSource*/ _completion = null;
            /*BlockedReadAsyncOperation<T>?*/ _blockedReadersHead = null;
            /*BlockedWriteAsyncOperation<T>?*/ _blockedWritersHead = null;
            /*WaitingReadAsyncOperation?*/ _waitingReadersHead = null;
            /*WaitingWriteAsyncOperation?*/ _waitingWritersHead = null;
            /*bool*/ _runContinuationsAsynchronously = false;
            /*Exception?*/ _doneWriting = null;
            $ctor$3(/*BoundedChannelFullMode*/ mode, /*bool*/ runContinuationsAsynchronously, /*Action<T>?*/ itemDropped)
            {
                super.$ctor$2();
                {
                    this._dropWrites = !(mode === 0/*BoundedChannelFullMode.Wait*/);
                    this._runContinuationsAsynchronously = runContinuationsAsynchronously;
                    this._itemDropped = itemDropped;
                    this._completion = new $.$spc.System.Threading.Tasks.TaskCompletionSource().$ctor$2(runContinuationsAsynchronously ? 64/*TaskCreationOptions.RunContinuationsAsynchronously*/ : 0/*TaskCreationOptions.None*/);
                    this.Reader = new ($.$stc.System.Threading.Channels.RendezvousChannel$$(T).RendezvousChannelReader)().$ctor$2(this);
                    this.Writer = new ($.$stc.System.Threading.Channels.RendezvousChannel$$(T).RendezvousChannelWriter)().$ctor$2(this);
                }
                return this;
            }
            static $_RendezvousChannelReader;
            static get RendezvousChannelReader()
            {
                let $cls = $.$stc.System.Threading.Channels.RendezvousChannel$$(T);
                return $cls.$_RendezvousChannelReader ??= $asm.$ncls("$stc.System.Threading.Channels.RendezvousChannel$$.RendezvousChannelReader", ($self) => class RendezvousChannelReader extends $.$stc.System.Threading.Channels.ChannelReader$$(T)
                {
                    /*RendezvousChannel<T>*/ _parent = null;
                    /*BlockedReadAsyncOperation<T>*/ _readerSingleton = null;
                    /*WaitingReadAsyncOperation*/ _waiterSingleton = null;
                    $ctor$2(/*RendezvousChannel<T>*/ parent)
                    {
                        super.$ctor$1();
                        {
                            this._parent = parent;
                            this._readerSingleton = new ($.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T))().$ctor$4(parent._runContinuationsAsynchronously, new $.$spc.System.Threading.CancellationToken(), true, null);
                            this._waiterSingleton = new $.$stc.System.Threading.Channels.WaitingReadAsyncOperation().$ctor$4(parent._runContinuationsAsynchronously, new $.$spc.System.Threading.CancellationToken(), true, null);
                        }
                        return this;
                    }
                    /*Task */ get Completion()
                    {
                        return this._parent._completion.Task;
                    }
                    /*bool */ get CanCount()
                    {
                        return true;
                    }
                    /*bool */ get CanPeek()
                    {
                        return true;
                    }
                    /*int */ get Count()
                    {
                        return 0;
                    }
                    /*bool */ TryRead(/*out T*/ item)
                    {
                        /*RendezvousChannel<T>*/ let parent = this._parent;
                        /*BlockedWriteAsyncOperation<T>?*/ let blockedWriter = null;
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(parent.SyncObj)
                            {
                                parent.AssertInvariants();
                                if (parent._doneWriting === null)
                                {
                                    blockedWriter = $.$stc.System.Threading.Channels.ChannelUtilities.TryDequeueAndReserveCompletionIfCancelable($.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T), $.$ref(() => parent._blockedWritersHead, ($v) => parent._blockedWritersHead = $v, $.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T)));
                                }
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(parent.SyncObj)
                        }
                        if (!(blockedWriter === null))
                        {
                            item.$v = blockedWriter.Item$2;
                            blockedWriter.DangerousSetResult(new $.$stc.System.VoidResult());
                            return true;
                        }
                        item.$v = $.$default(T);
                        return false;
                    }
                    /*bool */ TryPeek(/*out T*/ item)
                    {
                        /*RendezvousChannel<T>*/ let parent = this._parent;
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(parent.SyncObj)
                            {
                                parent.AssertInvariants();
                                let blockedWriter;
                                if (parent._doneWriting === null && parent._blockedWritersHead !== null && ((blockedWriter = parent._blockedWritersHead, blockedWriter != null && true)))
                                {
                                    item.$v = blockedWriter.Item$2;
                                    return true;
                                }
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(parent.SyncObj)
                        }
                        item.$v = $.$default(T);
                        return false;
                    }
                    /*ValueTask<T> */ ReadAsync(/*CancellationToken*/ cancellationToken)
                    {
                        /*RendezvousChannel<T>*/ let parent = this._parent;
                        if (cancellationToken.IsCancellationRequested)
                        {
                            return new ($.$spc.System.Threading.Tasks.ValueTask$$(T))().$ctor$3($.$spc.System.Threading.Tasks.Task.FromCanceled$1(T, cancellationToken));
                        }
                        /*BlockedReadAsyncOperation<T>?*/ let reader = null;
                        /*WaitingWriteAsyncOperation?*/ let waitingWriters = null;
                        /*BlockedWriteAsyncOperation<T>?*/ let blockedWriter = null;
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(parent.SyncObj)
                            {
                                parent.AssertInvariants();
                                if (!(parent._doneWriting === null))
                                {
                                    return $.$stc.System.Threading.Channels.ChannelUtilities.GetInvalidCompletionValueTask(T, parent._doneWriting);
                                }
                                blockedWriter = $.$stc.System.Threading.Channels.ChannelUtilities.TryDequeueAndReserveCompletionIfCancelable($.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T), $.$ref(() => parent._blockedWritersHead, ($v) => parent._blockedWritersHead = $v, $.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T)));
                                if (blockedWriter === null)
                                {
                                    reader = !cancellationToken.CanBeCanceled && this._readerSingleton.TryOwnAndReset() ? this._readerSingleton : new ($.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T))().$ctor$4(parent._runContinuationsAsynchronously, new $.$spc.System.Threading.CancellationToken(), false, this._parent.CancellationCallbackDelegate);
                                    $.$stc.System.Threading.Channels.ChannelUtilities.Enqueue($.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T), $.$ref(() => parent._blockedReadersHead, ($v) => parent._blockedReadersHead = $v, $.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T)), reader);
                                    waitingWriters = $.$stc.System.Threading.Channels.ChannelUtilities.TryReserveCompletionIfCancelable($.$stc.System.Threading.Channels.WaitingWriteAsyncOperation, $.$ref(() => parent._waitingWritersHead, ($v) => parent._waitingWritersHead = $v, $.$stc.System.Threading.Channels.WaitingWriteAsyncOperation));
                                }
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(parent.SyncObj)
                        }
                        /*ValueTask<T>*/ let result;
                        if (!(blockedWriter === null))
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(reader === null, "reader is null");
                            $.$spc.System.Diagnostics.Debug.Assert$1(waitingWriters === null, "waitingWriters is null");
                            result = new ($.$spc.System.Threading.Tasks.ValueTask$$(T))().$ctor$2(blockedWriter.Item$2);
                            blockedWriter.DangerousSetResult(new $.$stc.System.VoidResult());
                        }
                        else 
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(!(reader === null), "reader is not null");
                            $.$stc.System.Threading.Channels.ChannelUtilities.DangerousSetOperations($.$stc.System.Threading.Channels.WaitingWriteAsyncOperation, $.$spc.System.Boolean, waitingWriters, true);
                            result = reader.ValueTaskOfT;
                        }
                        return result;
                    }
                    /*ValueTask<bool> */ WaitToReadAsync(/*CancellationToken*/ cancellationToken)
                    {
                        if (cancellationToken.IsCancellationRequested)
                        {
                            return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Boolean))().$ctor$3($.$spc.System.Threading.Tasks.Task.FromCanceled$1($.$spc.System.Boolean, cancellationToken));
                        }
                        /*RendezvousChannel<T>*/ let parent = this._parent;
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(parent.SyncObj)
                            {
                                parent.AssertInvariants();
                                if (!(parent._doneWriting === null))
                                {
                                    return parent._doneWriting !== $.$stc.System.Threading.Channels.ChannelUtilities.s_doneWritingSentinel ? new ($.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Boolean))().$ctor$3($.$spc.System.Threading.Tasks.Task.FromException$1($.$spc.System.Boolean, parent._doneWriting)) : new ($.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Boolean))();
                                }
                                if (!(parent._blockedWritersHead === null))
                                {
                                    return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Boolean))().$ctor$2(true);
                                }
                                /*WaitingReadAsyncOperation*/ let waiter = !cancellationToken.CanBeCanceled && this._waiterSingleton.TryOwnAndReset() ? this._waiterSingleton : new $.$stc.System.Threading.Channels.WaitingReadAsyncOperation().$ctor$4(parent._runContinuationsAsynchronously, new $.$spc.System.Threading.CancellationToken(), false, this._parent.CancellationCallbackDelegate);
                                $.$stc.System.Threading.Channels.ChannelUtilities.Enqueue($.$stc.System.Threading.Channels.WaitingReadAsyncOperation, $.$ref(() => parent._waitingReadersHead, ($v) => parent._waitingReadersHead = $v, $.$stc.System.Threading.Channels.WaitingReadAsyncOperation), waiter);
                                return waiter.ValueTaskOfT;
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(parent.SyncObj)
                        }
                    }
                    /*string */ get DebuggerDisplay()
                    {
                        /*long*/ let blockedReaderCount, waitingReaderCount;
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(this._parent.SyncObj)
                            {
                                blockedReaderCount = $.$stc.System.Threading.Channels.ChannelUtilities.CountOperations($.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T), this._parent._blockedReadersHead);
                                waitingReaderCount = $.$stc.System.Threading.Channels.ChannelUtilities.CountOperations($.$stc.System.Threading.Channels.WaitingReadAsyncOperation, this._parent._waitingReadersHead);
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(this._parent.SyncObj)
                        }
                        return `ReadAsync=${blockedReaderCount}, WaitToReadAsync=${waitingReaderCount}`;
                    }
                    static $h = 2208032;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"p":[{"p":133300225,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x600000000n),"f":32769},"n":"Completion","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x800000000n),"f":32769},"n":"CanCount","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xA00000000n),"f":32769},"n":"CanPeek","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":32769},{"p":655361,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xC00000000n),"f":32769},"n":"Count","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":32769},{"p":1310721,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1200000000n),"f":8},"n":"DebuggerDisplay","d":this.$h,"h":Number(BigInt(this.$h)|0x1100000000n),"f":8}],"m":[{"r":262145,"p":[{"n":"item","p":T?.$h??1507328,"f":2}],"n":"TryRead","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":32769},{"r":262145,"p":[{"n":"item","p":T?.$h??1507328,"f":2}],"n":"TryPeek","d":this.$h,"h":Number(BigInt(this.$h)|0xE00000000n),"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$(T).$h,"p":[{"n":"cancellationToken","p":125960193}],"n":"ReadAsync","d":this.$h,"h":Number(BigInt(this.$h)|0xF00000000n),"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Boolean).$h,"p":[{"n":"cancellationToken","p":125960193}],"n":"WaitToReadAsync","d":this.$h,"h":Number(BigInt(this.$h)|0x1000000000n),"f":32769}],"l":[{"t":$.$stc.System.Threading.Channels.RendezvousChannel$$(T).$h,"n":"_parent","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":8},{"t":$.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T).$h,"n":"_readerSingleton","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2},{"t":3060000,"n":"_waiterSingleton","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2}],"c":[{"p":[{"n":"parent","p":$.$stc.System.Threading.Channels.RendezvousChannel$$(T).$h}],"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":8}],"d":$.$stc.System.Threading.Channels.RendezvousChannel$$(T).$h,"h":this.$h,"a":[{"t":37617665,"c":8627552257,"a":[{"v":"{DebuggerDisplay,nq}","t":1310721}]}]}; }
                    static get $b() { return $.$stc.System.Threading.Channels.ChannelReader$$(T); }
                    static get $fullName() { return `System.Threading.Channels.RendezvousChannel<${T?.$fullName}>.RendezvousChannelReader`; }
                }, $cls, ($v) => $cls.$_RendezvousChannelReader = $v);
            }
            static $_RendezvousChannelWriter;
            static get RendezvousChannelWriter()
            {
                let $cls = $.$stc.System.Threading.Channels.RendezvousChannel$$(T);
                return $cls.$_RendezvousChannelWriter ??= $asm.$ncls("$stc.System.Threading.Channels.RendezvousChannel$$.RendezvousChannelWriter", ($self) => class RendezvousChannelWriter extends $.$stc.System.Threading.Channels.ChannelWriter$$(T)
                {
                    /*RendezvousChannel<T>*/ _parent = null;
                    /*BlockedWriteAsyncOperation<T>*/ _writerSingleton = null;
                    /*WaitingWriteAsyncOperation*/ _waiterSingleton = null;
                    $ctor$2(/*RendezvousChannel<T>*/ parent)
                    {
                        super.$ctor$1();
                        {
                            this._parent = parent;
                            this._writerSingleton = new ($.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T))().$ctor$4(true, new $.$spc.System.Threading.CancellationToken(), true, null);
                            this._waiterSingleton = new $.$stc.System.Threading.Channels.WaitingWriteAsyncOperation().$ctor$4(true, new $.$spc.System.Threading.CancellationToken(), true, null);
                        }
                        return this;
                    }
                    /*bool */ TryComplete(/*Exception?*/ error)
                    {
                        /*RendezvousChannel<T>*/ let parent = this._parent;
                        /*BlockedReadAsyncOperation<T>?*/ let blockedReadersHead;
                        /*BlockedWriteAsyncOperation<T>?*/ let blockedWritersHead;
                        /*WaitingReadAsyncOperation?*/ let waitingReadersHead;
                        /*WaitingWriteAsyncOperation?*/ let waitingWritersHead;
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(parent.SyncObj)
                            {
                                parent.AssertInvariants();
                                if (!(parent._doneWriting === null))
                                {
                                    return false;
                                }
                                parent._doneWriting = error ?? $.$stc.System.Threading.Channels.ChannelUtilities.s_doneWritingSentinel;
                                blockedReadersHead = parent._blockedReadersHead;
                                blockedWritersHead = parent._blockedWritersHead;
                                waitingReadersHead = parent._waitingReadersHead;
                                waitingWritersHead = parent._waitingWritersHead;
                                parent._blockedReadersHead = null;
                                parent._blockedWritersHead = null;
                                parent._waitingReadersHead = null;
                                parent._waitingWritersHead = null;
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(parent.SyncObj)
                        }
                        $.$stc.System.Threading.Channels.ChannelUtilities.Complete(parent._completion, error);
                        $.$stc.System.Threading.Channels.ChannelUtilities.FailOperations($.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T), blockedReadersHead, $.$stc.System.Threading.Channels.ChannelUtilities.CreateInvalidCompletionException(error));
                        $.$stc.System.Threading.Channels.ChannelUtilities.FailOperations($.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T), blockedWritersHead, $.$stc.System.Threading.Channels.ChannelUtilities.CreateInvalidCompletionException(error));
                        $.$stc.System.Threading.Channels.ChannelUtilities.SetOrFailOperations($.$stc.System.Threading.Channels.WaitingReadAsyncOperation, $.$spc.System.Boolean, waitingReadersHead, false, error);
                        $.$stc.System.Threading.Channels.ChannelUtilities.SetOrFailOperations($.$stc.System.Threading.Channels.WaitingWriteAsyncOperation, $.$spc.System.Boolean, waitingWritersHead, false, error);
                        return true;
                    }
                    /*bool */ TryWrite(/*T*/ item)
                    {
                        /*RendezvousChannel<T>*/ let parent = this._parent;
                        /*BlockedReadAsyncOperation<T>?*/ let blockedReader = null;
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(parent.SyncObj)
                            {
                                parent.AssertInvariants();
                                if (parent._doneWriting === null)
                                {
                                    blockedReader = $.$stc.System.Threading.Channels.ChannelUtilities.TryDequeueAndReserveCompletionIfCancelable($.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T), $.$ref(() => parent._blockedReadersHead, ($v) => parent._blockedReadersHead = $v, $.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T)));
                                }
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(parent.SyncObj)
                        }
                        if (!(blockedReader === null))
                        {
                            blockedReader.DangerousSetResult(item);
                            return true;
                        }
                        if (parent._dropWrites)
                        {
                            parent._itemDropped?.Invoke(item);
                            return true;
                        }
                        return false;
                    }
                    /*ValueTask<bool> */ WaitToWriteAsync(/*CancellationToken*/ cancellationToken)
                    {
                        if (cancellationToken.IsCancellationRequested)
                        {
                            return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Boolean))().$ctor$3($.$spc.System.Threading.Tasks.Task.FromCanceled$1($.$spc.System.Boolean, cancellationToken));
                        }
                        /*RendezvousChannel<T>*/ let parent = this._parent;
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(parent.SyncObj)
                            {
                                parent.AssertInvariants();
                                if (!(parent._doneWriting === null))
                                {
                                    return parent._doneWriting !== $.$stc.System.Threading.Channels.ChannelUtilities.s_doneWritingSentinel ? new ($.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Boolean))().$ctor$3($.$spc.System.Threading.Tasks.Task.FromException$1($.$spc.System.Boolean, parent._doneWriting)) : new ($.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Boolean))();
                                }
                                if (!(parent._blockedReadersHead === null) || parent._dropWrites)
                                {
                                    return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Boolean))().$ctor$2(true);
                                }
                                /*WaitingWriteAsyncOperation*/ let waiter = !cancellationToken.CanBeCanceled && this._waiterSingleton.TryOwnAndReset() ? this._waiterSingleton : new $.$stc.System.Threading.Channels.WaitingWriteAsyncOperation().$ctor$4(parent._runContinuationsAsynchronously, new $.$spc.System.Threading.CancellationToken(), false, this._parent.CancellationCallbackDelegate);
                                $.$stc.System.Threading.Channels.ChannelUtilities.Enqueue($.$stc.System.Threading.Channels.WaitingWriteAsyncOperation, $.$ref(() => parent._waitingWritersHead, ($v) => parent._waitingWritersHead = $v, $.$stc.System.Threading.Channels.WaitingWriteAsyncOperation), waiter);
                                return waiter.ValueTaskOfT;
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(parent.SyncObj)
                        }
                    }
                    /*ValueTask */ WriteAsync(/*T*/ item, /*CancellationToken*/ cancellationToken)
                    {
                        /*RendezvousChannel<T>*/ let parent = this._parent;
                        if (cancellationToken.IsCancellationRequested)
                        {
                            return new $.$spc.System.Threading.Tasks.ValueTask().$ctor$2($.$spc.System.Threading.Tasks.Task.FromCanceled$1(T, cancellationToken));
                        }
                        /*BlockedWriteAsyncOperation<T>?*/ let writer = null;
                        /*WaitingReadAsyncOperation?*/ let waitingReaders = null;
                        /*BlockedReadAsyncOperation<T>?*/ let blockedReader = null;
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(parent.SyncObj)
                            {
                                parent.AssertInvariants();
                                if (!(parent._doneWriting === null))
                                {
                                    return new $.$spc.System.Threading.Tasks.ValueTask().$ctor$2($.$spc.System.Threading.Tasks.Task.FromException($.$stc.System.Threading.Channels.ChannelUtilities.CreateInvalidCompletionException(parent._doneWriting)));
                                }
                                blockedReader = $.$stc.System.Threading.Channels.ChannelUtilities.TryDequeueAndReserveCompletionIfCancelable($.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T), $.$ref(() => parent._blockedReadersHead, ($v) => parent._blockedReadersHead = $v, $.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T)));
                                if (blockedReader === null && !parent._dropWrites)
                                {
                                    writer = !cancellationToken.CanBeCanceled && this._writerSingleton.TryOwnAndReset() ? this._writerSingleton : new ($.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T))().$ctor$4(parent._runContinuationsAsynchronously, new $.$spc.System.Threading.CancellationToken(), false, this._parent.CancellationCallbackDelegate);
                                    writer.Item$2 = item;
                                    $.$stc.System.Threading.Channels.ChannelUtilities.Enqueue($.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T), $.$ref(() => parent._blockedWritersHead, ($v) => parent._blockedWritersHead = $v, $.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T)), writer);
                                    waitingReaders = $.$stc.System.Threading.Channels.ChannelUtilities.TryReserveCompletionIfCancelable($.$stc.System.Threading.Channels.WaitingReadAsyncOperation, $.$ref(() => parent._waitingReadersHead, ($v) => parent._waitingReadersHead = $v, $.$stc.System.Threading.Channels.WaitingReadAsyncOperation));
                                }
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(parent.SyncObj)
                        }
                        if (!(writer === null))
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(blockedReader === null, "blockedReader is null");
                            $.$stc.System.Threading.Channels.ChannelUtilities.DangerousSetOperations($.$stc.System.Threading.Channels.WaitingReadAsyncOperation, $.$spc.System.Boolean, waitingReaders, true);
                            return writer.ValueTask;
                        }
                        if (!(blockedReader === null))
                        {
                            blockedReader.DangerousSetResult(item);
                        }
                        else 
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(parent._dropWrites, "parent._dropWrites");
                            parent._itemDropped?.Invoke(item);
                        }
                        return new $.$spc.System.Threading.Tasks.ValueTask();
                    }
                    /*string */ get DebuggerDisplay()
                    {
                        /*long*/ let blockedWriterCount, waitingWriterCount;
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(this._parent.SyncObj)
                            {
                                blockedWriterCount = $.$stc.System.Threading.Channels.ChannelUtilities.CountOperations($.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T), this._parent._blockedWritersHead);
                                waitingWriterCount = $.$stc.System.Threading.Channels.ChannelUtilities.CountOperations($.$stc.System.Threading.Channels.WaitingWriteAsyncOperation, this._parent._waitingWritersHead);
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(this._parent.SyncObj)
                        }
                        return `WriteAsync=${blockedWriterCount}, WaitToWriteAsync=${waitingWriterCount}`;
                    }
                    static $h = 2273568;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"p":[{"p":1310721,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xA00000000n),"f":8},"n":"DebuggerDisplay","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":8}],"m":[{"r":262145,"p":[{"n":"error","p":47251457}],"n":"TryComplete","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":32769},{"r":262145,"p":[{"n":"item","p":T?.$h??1507328}],"n":"TryWrite","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Boolean).$h,"p":[{"n":"cancellationToken","p":125960193}],"n":"WaitToWriteAsync","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":32769},{"r":136118273,"p":[{"n":"item","p":T?.$h??1507328},{"n":"cancellationToken","p":125960193}],"n":"WriteAsync","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":32769}],"l":[{"t":$.$stc.System.Threading.Channels.RendezvousChannel$$(T).$h,"n":"_parent","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":8},{"t":$.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T).$h,"n":"_writerSingleton","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2},{"t":3125536,"n":"_waiterSingleton","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2}],"c":[{"p":[{"n":"parent","p":$.$stc.System.Threading.Channels.RendezvousChannel$$(T).$h}],"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":8}],"d":$.$stc.System.Threading.Channels.RendezvousChannel$$(T).$h,"h":this.$h,"a":[{"t":37617665,"c":8627552257,"a":[{"v":"{DebuggerDisplay,nq}","t":1310721}]}]}; }
                    static get $b() { return $.$stc.System.Threading.Channels.ChannelWriter$$(T); }
                    static get $fullName() { return `System.Threading.Channels.RendezvousChannel<${T?.$fullName}>.RendezvousChannelWriter`; }
                }, $cls, ($v) => $cls.$_RendezvousChannelWriter = $v);
            }
            /*object */ get SyncObj()
            {
                return this._completion;
            }
            /*Action<object?, CancellationToken>*/ CancellationCallbackDelegate$ = null;
            /*Action<object?, CancellationToken> */ get CancellationCallbackDelegate()
            {
                return this.CancellationCallbackDelegate$ ??= new ($.$spc.System.Action$$$($.$spc.System.Object, $.$spc.System.Threading.CancellationToken))().$ctor(this,  (/*state*/ state, /*cancellationToken*/ cancellationToken) =>
                {
                    /*AsyncOperation*/ let op = $.$cast(state, $.$stc.System.Threading.Channels.AsyncOperation);
                    if (op.TrySetCanceled(cancellationToken))
                    {
                        $.$stc.System.Threading.Channels.ChannelUtilities.UnsafeQueueUserWorkItem($.$spc.System.Collections.Generic.KeyValuePair$$$($.$stc.System.Threading.Channels.RendezvousChannel$$(T), $.$stc.System.Threading.Channels.AsyncOperation), new ($.$spc.System.Action$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$stc.System.Threading.Channels.RendezvousChannel$$(T), $.$stc.System.Threading.Channels.AsyncOperation)))().$ctor($.$stc.System.Threading.Channels.RendezvousChannel$$(T), /*static*/ (/*state*/ state) =>
                        {
                            //lock
                            try
                            {
                                $.$spc.System.Threading.Monitor.Enter(state.Key.SyncObj)
                                {
                                    //switch (state.Value)
                                    let $switch1 = state.Value;
                                    {
                                        let blockedReader;
                                        let blockedWriter;
                                        let waitingReader;
                                        let waitingWriter;
                                        $switchJumpStart1: 
                                        //case BlockedReadAsyncOperation<T> blockedReader:
                                        if ($.$is($switch1, $.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T), { set $v(v){ blockedReader = v; } }))
                                        {
                                            $.$stc.System.Threading.Channels.ChannelUtilities.Remove($.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T), $.$ref(() => state.Key._blockedReadersHead, ($v) => state.Key._blockedReadersHead = $v, $.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T)), blockedReader);
                                        }
                                        //case BlockedWriteAsyncOperation<T> blockedWriter:
                                        else if ($.$is($switch1, $.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T), { set $v(v){ blockedWriter = v; } }))
                                        {
                                            $.$stc.System.Threading.Channels.ChannelUtilities.Remove($.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T), $.$ref(() => state.Key._blockedWritersHead, ($v) => state.Key._blockedWritersHead = $v, $.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T)), blockedWriter);
                                        }
                                        //case WaitingReadAsyncOperation waitingReader:
                                        else if ($.$is($switch1, $.$stc.System.Threading.Channels.WaitingReadAsyncOperation, { set $v(v){ waitingReader = v; } }))
                                        {
                                            $.$stc.System.Threading.Channels.ChannelUtilities.Remove($.$stc.System.Threading.Channels.WaitingReadAsyncOperation, $.$ref(() => state.Key._waitingReadersHead, ($v) => state.Key._waitingReadersHead = $v, $.$stc.System.Threading.Channels.WaitingReadAsyncOperation), waitingReader);
                                        }
                                        //case WaitingWriteAsyncOperation waitingWriter:
                                        else if ($.$is($switch1, $.$stc.System.Threading.Channels.WaitingWriteAsyncOperation, { set $v(v){ waitingWriter = v; } }))
                                        {
                                            $.$stc.System.Threading.Channels.ChannelUtilities.Remove($.$stc.System.Threading.Channels.WaitingWriteAsyncOperation, $.$ref(() => state.Key._waitingWritersHead, ($v) => state.Key._waitingWritersHead = $v, $.$stc.System.Threading.Channels.WaitingWriteAsyncOperation), waitingWriter);
                                        }
                                        //default
                                        else
                                        {
                                            $.$spc.System.Diagnostics.Debug.Fail(`Unexpected operation: ${$.$spc.System.Object.ToString.call(state.Value)}`);
                                        }
                                    }
                                }
                            }
                            finally
                            {
                                $.$spc.System.Threading.Monitor.Exit(state.Key.SyncObj)
                            }
                        }, {"r":65537,"p":[{"n":"state","p":$.$spc.System.Collections.Generic.KeyValuePair$$$($.$stc.System.Threading.Channels.RendezvousChannel$$(T), $.$stc.System.Threading.Channels.AsyncOperation).$h}],"n":"","d":this.$h,"h":0,"f":1048610}), new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$stc.System.Threading.Channels.RendezvousChannel$$(T), $.$stc.System.Threading.Channels.AsyncOperation))().$ctor$2(this, op));
                    }
                }, {"r":65537,"p":[{"n":"state","p":131073},{"n":"cancellationToken","p":125960193}],"n":"","d":this.$h,"h":0,"f":1048578});
            }
            /*string */ get DebuggerDisplay()
            {
                return `${($.$cast(this.Reader, $.$stc.System.Threading.Channels.RendezvousChannel$$(T).RendezvousChannelReader)).DebuggerDisplay}, ${($.$cast(this.Writer, $.$stc.System.Threading.Channels.RendezvousChannel$$(T).RendezvousChannelWriter)).DebuggerDisplay}`;
            }
            /*void */ AssertInvariants()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(!(this.SyncObj === null), "The sync obj must not be null.");
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Threading.Monitor.IsEntered(this.SyncObj), "Invariants can only be validated while holding the lock.");
                if (!(this._blockedReadersHead === null))
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._blockedWritersHead === null, "There shouldn't be any blocked writer if there's a blocked reader.");
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._waitingWritersHead === null, "There shouldn't be any waiting writers if there's a blocked reader.");
                }
                if (!(this._blockedWritersHead === null))
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._blockedReadersHead === null, "There shouldn't be any blocked readers if there's a blocked writer.");
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._waitingReadersHead === null, "There shouldn't be any waiting readers if there's a blocked writer.");
                }
                if (this._completion.Task.IsCompleted)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(!(this._doneWriting === null), "We can only complete if we're done writing.");
                }
            }
            static $h = 2142496;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":131073,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xE00000000n),"f":2},"n":"SyncObj","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":2},{"p":$.$spc.System.Action$$$($.$spc.System.Object, $.$spc.System.Threading.CancellationToken).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1100000000n),"f":2},"n":"CancellationCallbackDelegate","d":this.$h,"h":Number(BigInt(this.$h)|0x1000000000n),"f":2},{"p":1310721,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1300000000n),"f":2},"n":"DebuggerDisplay","d":this.$h,"h":Number(BigInt(this.$h)|0x1200000000n),"f":2}],"m":[{"r":65537,"n":"AssertInvariants","d":this.$h,"h":Number(BigInt(this.$h)|0x1400000000n),"f":2,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"DEBUG","t":1310721}]}]}],"l":[{"t":262145,"n":"_dropWrites","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":2},{"t":$.$spc.System.Action$$(T).$h,"n":"_itemDropped","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2},{"t":134414337,"n":"_completion","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2},{"t":$.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T).$h,"n":"_blockedReadersHead","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":2},{"t":$.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T).$h,"n":"_blockedWritersHead","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":2},{"t":3060000,"n":"_waitingReadersHead","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":2},{"t":3125536,"n":"_waitingWritersHead","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":2},{"t":262145,"n":"_runContinuationsAsynchronously","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":2},{"t":47251457,"n":"_doneWriting","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":2}],"c":[{"p":[{"n":"mode","p":1356064},{"n":"runContinuationsAsynchronously","p":262145},{"n":"itemDropped","p":$.$spc.System.Action$$(T).$h}],"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0xA00000000n),"f":8}],"g":[T?.$h??1507328],"j":[$.$stc.System.Threading.Channels.RendezvousChannel$$(T).RendezvousChannelReader.$h,$.$stc.System.Threading.Channels.RendezvousChannel$$(T).RendezvousChannelWriter.$h],"r":1,"h":this.$h,"a":[{"t":37617665,"c":8627552257,"a":[{"v":"{DebuggerDisplay,nq}","t":1310721}]}]}; }
            static get $b() { return $.$stc.System.Threading.Channels.Channel$$(T); }
            static get $fullName() { return `System.Threading.Channels.RendezvousChannel<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$stc.System.Threading.Channels.UnboundedPrioritizedChannel<>", (T) => $asm.$gt("$stc.System.Threading.Channels.UnboundedPrioritizedChannel<>", [T], ($self) => class UnboundedPrioritizedChannel$$ extends $.$stc.System.Threading.Channels.Channel$$(T)
        {
            /*TaskCompletionSource*/ _completion = null;
            /*PriorityQueue<bool, T>*/ _items = null;
            /*bool*/ _runContinuationsAsynchronously = false;
            /*BlockedReadAsyncOperation<T>?*/ _blockedReadersHead = null;
            /*WaitingReadAsyncOperation?*/ _waitingReadersHead = null;
            /*Exception?*/ _doneWriting = null;
            $ctor$3(/*bool*/ runContinuationsAsynchronously, /*IComparer<T>?*/ comparer)
            {
                super.$ctor$2();
                {
                    this._runContinuationsAsynchronously = runContinuationsAsynchronously;
                    this._completion = new $.$spc.System.Threading.Tasks.TaskCompletionSource().$ctor$2(runContinuationsAsynchronously ? 64/*TaskCreationOptions.RunContinuationsAsynchronously*/ : 0/*TaskCreationOptions.None*/);
                    this._items = new ($.$sc.System.Collections.Generic.PriorityQueue$$$($.$spc.System.Boolean, T))().$ctor$3(comparer);
                    this.Reader = new ($.$stc.System.Threading.Channels.UnboundedPrioritizedChannel$$(T).UnboundedPrioritizedChannelReader)().$ctor$2(this);
                    this.Writer = new ($.$stc.System.Threading.Channels.UnboundedPrioritizedChannel$$(T).UnboundedPrioritizedChannelWriter)().$ctor$2(this);
                }
                return this;
            }
            static $_UnboundedPrioritizedChannelReader;
            static get UnboundedPrioritizedChannelReader()
            {
                let $cls = $.$stc.System.Threading.Channels.UnboundedPrioritizedChannel$$(T);
                return $cls.$_UnboundedPrioritizedChannelReader ??= $asm.$ncls("$stc.System.Threading.Channels.UnboundedPrioritizedChannel$$.UnboundedPrioritizedChannelReader", ($self) => class UnboundedPrioritizedChannelReader extends $.$stc.System.Threading.Channels.ChannelReader$$(T)
                {
                    /*UnboundedPrioritizedChannel<T>*/ _parent = null;
                    /*BlockedReadAsyncOperation<T>*/ _readerSingleton = null;
                    /*WaitingReadAsyncOperation*/ _waiterSingleton = null;
                    $ctor$2(/*UnboundedPrioritizedChannel<T>*/ parent)
                    {
                        super.$ctor$1();
                        {
                            this._parent = parent;
                            this._readerSingleton = new ($.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T))().$ctor$4(parent._runContinuationsAsynchronously, new $.$spc.System.Threading.CancellationToken(), true, null);
                            this._waiterSingleton = new $.$stc.System.Threading.Channels.WaitingReadAsyncOperation().$ctor$4(parent._runContinuationsAsynchronously, new $.$spc.System.Threading.CancellationToken(), true, null);
                        }
                        return this;
                    }
                    /*Task */ get Completion()
                    {
                        return this._parent._completion.Task;
                    }
                    /*bool */ get CanCount()
                    {
                        return true;
                    }
                    /*bool */ get CanPeek()
                    {
                        return true;
                    }
                    /*int */ get Count()
                    {
                        return this._parent._items.Count;
                    }
                    /*ValueTask<T> */ ReadAsync(/*CancellationToken*/ cancellationToken)
                    {
                        if (cancellationToken.IsCancellationRequested)
                        {
                            return $.$spc.System.Threading.Tasks.ValueTask.FromCanceled$1(T, cancellationToken);
                        }
                        /*UnboundedPrioritizedChannel<T>*/ let parent = this._parent;
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(parent.SyncObj)
                            {
                                parent.AssertInvariants();
                                /*T?*/ let item;
                                if (parent._items.TryDequeue($.$discardRef(), $.$ref(() => item, ($v) => item = $v, T)))
                                {
                                    $.$stc.System.Threading.Channels.UnboundedPrioritizedChannel$$(T).UnboundedPrioritizedChannelReader.CompleteIfDone(parent);
                                    return new ($.$spc.System.Threading.Tasks.ValueTask$$(T))().$ctor$2(item);
                                }
                                if (!(parent._doneWriting === null))
                                {
                                    return $.$stc.System.Threading.Channels.ChannelUtilities.GetInvalidCompletionValueTask(T, parent._doneWriting);
                                }
                                /*BlockedReadAsyncOperation<T>*/ let reader = !cancellationToken.CanBeCanceled && this._readerSingleton.TryOwnAndReset() ? this._readerSingleton : new ($.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T))().$ctor$4(parent._runContinuationsAsynchronously, new $.$spc.System.Threading.CancellationToken(), false, this._parent.CancellationCallbackDelegate);
                                $.$stc.System.Threading.Channels.ChannelUtilities.Enqueue($.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T), $.$ref(() => parent._blockedReadersHead, ($v) => parent._blockedReadersHead = $v, $.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T)), reader);
                                return reader.ValueTaskOfT;
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(parent.SyncObj)
                        }
                    }
                    /*bool */ TryRead(/*out T*/ item)
                    {
                        /*UnboundedPrioritizedChannel<T>*/ let parent = this._parent;
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(parent.SyncObj)
                            {
                                if (parent._items.TryDequeue($.$discardRef(), item))
                                {
                                    $.$stc.System.Threading.Channels.UnboundedPrioritizedChannel$$(T).UnboundedPrioritizedChannelReader.CompleteIfDone(parent);
                                    return true;
                                }
                                item.$v = $.$default(T);
                                return false;
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(parent.SyncObj)
                        }
                    }
                    /*bool */ TryPeek(/*out T*/ item)
                    {
                        /*UnboundedPrioritizedChannel<T>*/ let parent = this._parent;
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(parent.SyncObj)
                            {
                                return parent._items.TryPeek($.$discardRef(), item);
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(parent.SyncObj)
                        }
                    }
                    static /*void */ CompleteIfDone(/*UnboundedPrioritizedChannel<T>*/ parent)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Threading.Monitor.IsEntered(parent.SyncObj), "Monitor.IsEntered(parent.SyncObj)");
                        if (!(parent._doneWriting === null) && parent._items.Count === 0)
                        {
                            $.$stc.System.Threading.Channels.ChannelUtilities.Complete(parent._completion, parent._doneWriting);
                        }
                    }
                    /*ValueTask<bool> */ WaitToReadAsync(/*CancellationToken*/ cancellationToken)
                    {
                        if (cancellationToken.IsCancellationRequested)
                        {
                            return $.$spc.System.Threading.Tasks.ValueTask.FromCanceled$1($.$spc.System.Boolean, cancellationToken);
                        }
                        /*UnboundedPrioritizedChannel<T>*/ let parent = this._parent;
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(parent.SyncObj)
                            {
                                parent.AssertInvariants();
                                if (parent._items.Count !== 0)
                                {
                                    return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Boolean))().$ctor$2(true);
                                }
                                if (!(parent._doneWriting === null))
                                {
                                    return parent._doneWriting !== $.$stc.System.Threading.Channels.ChannelUtilities.s_doneWritingSentinel ? $.$spc.System.Threading.Tasks.ValueTask.FromException$1($.$spc.System.Boolean, parent._doneWriting) : new ($.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Boolean))();
                                }
                                /*WaitingReadAsyncOperation*/ let waiter = !cancellationToken.CanBeCanceled && this._waiterSingleton.TryOwnAndReset() ? this._waiterSingleton : new $.$stc.System.Threading.Channels.WaitingReadAsyncOperation().$ctor$4(parent._runContinuationsAsynchronously, new $.$spc.System.Threading.CancellationToken(), false, this._parent.CancellationCallbackDelegate);
                                $.$stc.System.Threading.Channels.ChannelUtilities.Enqueue($.$stc.System.Threading.Channels.WaitingReadAsyncOperation, $.$ref(() => parent._waitingReadersHead, ($v) => parent._waitingReadersHead = $v, $.$stc.System.Threading.Channels.WaitingReadAsyncOperation), waiter);
                                return waiter.ValueTaskOfT;
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(parent.SyncObj)
                        }
                    }
                    /*IEnumerator<T> */ System$Threading$Channels$IDebugEnumerable$$$GetEnumerator()
                    {
                        return this._parent.GetEnumerator();
                    }
                    static $h = 2863392;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"p":[{"p":133300225,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x600000000n),"f":32769},"n":"Completion","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x800000000n),"f":32769},"n":"CanCount","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xA00000000n),"f":32769},"n":"CanPeek","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":32769},{"p":655361,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xC00000000n),"f":32769},"n":"Count","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":32769}],"m":[{"r":$.$spc.System.Threading.Tasks.ValueTask$$(T).$h,"p":[{"n":"cancellationToken","p":125960193}],"n":"ReadAsync","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":32769},{"r":262145,"p":[{"n":"item","p":T?.$h??1507328,"f":2}],"n":"TryRead","d":this.$h,"h":Number(BigInt(this.$h)|0xE00000000n),"f":32769},{"r":262145,"p":[{"n":"item","p":T?.$h??1507328,"f":2}],"n":"TryPeek","d":this.$h,"h":Number(BigInt(this.$h)|0xF00000000n),"f":32769},{"r":65537,"p":[{"n":"parent","p":$.$stc.System.Threading.Channels.UnboundedPrioritizedChannel$$(T).$h}],"n":"CompleteIfDone","d":this.$h,"h":Number(BigInt(this.$h)|0x1000000000n),"f":34},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Boolean).$h,"p":[{"n":"cancellationToken","p":125960193}],"n":"WaitToReadAsync","d":this.$h,"h":Number(BigInt(this.$h)|0x1100000000n),"f":32769}],"l":[{"t":$.$stc.System.Threading.Channels.UnboundedPrioritizedChannel$$(T).$h,"n":"_parent","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":8},{"t":$.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T).$h,"n":"_readerSingleton","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2},{"t":3060000,"n":"_waiterSingleton","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2}],"c":[{"p":[{"n":"parent","p":$.$stc.System.Threading.Channels.UnboundedPrioritizedChannel$$(T).$h}],"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":8}],"i":[$.$stc.System.Threading.Channels.IDebugEnumerable$$(T).$h],"d":$.$stc.System.Threading.Channels.UnboundedPrioritizedChannel$$(T).$h,"h":this.$h,"a":[{"t":37617665,"c":8627552257,"a":[{"v":"Items = {Count}","t":1310721}]},{"t":37945345,"c":8627879937,"a":[{"v":$.$stc.System.Threading.Channels.DebugEnumeratorDebugView$$().$h,"t":142606337}]}]}; }
                    static get $b() { return $.$stc.System.Threading.Channels.ChannelReader$$(T); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$stc.System.Threading.Channels.IDebugEnumerable$$(T) ]; }
                    static get $fullName() { return `System.Threading.Channels.UnboundedPrioritizedChannel<${T?.$fullName}>.UnboundedPrioritizedChannelReader`; }
                }, $cls, ($v) => $cls.$_UnboundedPrioritizedChannelReader = $v);
            }
            static $_UnboundedPrioritizedChannelWriter;
            static get UnboundedPrioritizedChannelWriter()
            {
                let $cls = $.$stc.System.Threading.Channels.UnboundedPrioritizedChannel$$(T);
                return $cls.$_UnboundedPrioritizedChannelWriter ??= $asm.$ncls("$stc.System.Threading.Channels.UnboundedPrioritizedChannel$$.UnboundedPrioritizedChannelWriter", ($self) => class UnboundedPrioritizedChannelWriter extends $.$stc.System.Threading.Channels.ChannelWriter$$(T)
                {
                    /*UnboundedPrioritizedChannel<T>*/ _parent = null;
                    $ctor$2(/*UnboundedPrioritizedChannel<T>*/ parent)
                    {
                        super.$ctor$1();
                        this._parent = parent;
                        return this;
                    }
                    /*bool */ TryComplete(/*Exception?*/ error)
                    {
                        /*UnboundedPrioritizedChannel<T>*/ let parent = this._parent;
                        /*BlockedReadAsyncOperation<T>?*/ let blockedReadersHead;
                        /*WaitingReadAsyncOperation?*/ let waitingReadersHead;
                        /*bool*/ let completeTask;
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(parent.SyncObj)
                            {
                                parent.AssertInvariants();
                                if (!(parent._doneWriting === null))
                                {
                                    return false;
                                }
                                parent._doneWriting = error ?? $.$stc.System.Threading.Channels.ChannelUtilities.s_doneWritingSentinel;
                                completeTask = parent._items.Count === 0;
                                blockedReadersHead = parent._blockedReadersHead;
                                waitingReadersHead = parent._waitingReadersHead;
                                parent._blockedReadersHead = null;
                                parent._waitingReadersHead = null;
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(parent.SyncObj)
                        }
                        if (completeTask)
                        {
                            $.$stc.System.Threading.Channels.ChannelUtilities.Complete(parent._completion, error);
                        }
                        $.$stc.System.Threading.Channels.ChannelUtilities.FailOperations($.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T), blockedReadersHead, $.$stc.System.Threading.Channels.ChannelUtilities.CreateInvalidCompletionException(error));
                        $.$stc.System.Threading.Channels.ChannelUtilities.SetOrFailOperations($.$stc.System.Threading.Channels.WaitingReadAsyncOperation, $.$spc.System.Boolean, waitingReadersHead, false, error);
                        return true;
                    }
                    /*bool */ TryWrite(/*T*/ item)
                    {
                        /*UnboundedPrioritizedChannel<T>*/ let parent = this._parent;
                        /*BlockedReadAsyncOperation<T>?*/ let blockedReader = null;
                        /*WaitingReadAsyncOperation?*/ let waitingReadersHead = null;
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(parent.SyncObj)
                            {
                                parent.AssertInvariants();
                                if (!(parent._doneWriting === null))
                                {
                                    return false;
                                }
                                blockedReader = $.$stc.System.Threading.Channels.ChannelUtilities.TryDequeueAndReserveCompletionIfCancelable($.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T), $.$ref(() => parent._blockedReadersHead, ($v) => parent._blockedReadersHead = $v, $.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T)));
                                if (blockedReader === null)
                                {
                                    parent._items.Enqueue(true, item);
                                    waitingReadersHead = $.$stc.System.Threading.Channels.ChannelUtilities.TryReserveCompletionIfCancelable($.$stc.System.Threading.Channels.WaitingReadAsyncOperation, $.$ref(() => parent._waitingReadersHead, ($v) => parent._waitingReadersHead = $v, $.$stc.System.Threading.Channels.WaitingReadAsyncOperation));
                                }
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(parent.SyncObj)
                        }
                        if (!(blockedReader === null))
                        {
                            blockedReader.DangerousSetResult(item);
                        }
                        else if (!(waitingReadersHead === null))
                        {
                            $.$stc.System.Threading.Channels.ChannelUtilities.DangerousSetOperations($.$stc.System.Threading.Channels.WaitingReadAsyncOperation, $.$spc.System.Boolean, waitingReadersHead, true);
                        }
                        return true;
                    }
                    /*ValueTask<bool> */ WaitToWriteAsync(/*CancellationToken*/ cancellationToken)
                    {
                        /*Exception?*/ let doneWriting = this._parent._doneWriting;
                        return cancellationToken.IsCancellationRequested ? $.$spc.System.Threading.Tasks.ValueTask.FromCanceled$1($.$spc.System.Boolean, cancellationToken) : doneWriting === null ? new ($.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Boolean))().$ctor$2(true) : doneWriting !== $.$stc.System.Threading.Channels.ChannelUtilities.s_doneWritingSentinel ? $.$spc.System.Threading.Tasks.ValueTask.FromException$1($.$spc.System.Boolean, doneWriting) : new ($.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Boolean))();
                    }
                    /*ValueTask */ WriteAsync(/*T*/ item, /*CancellationToken*/ cancellationToken)
                    {
                        return cancellationToken.IsCancellationRequested ? $.$spc.System.Threading.Tasks.ValueTask.FromCanceled(cancellationToken) : this.TryWrite(item) ? new $.$spc.System.Threading.Tasks.ValueTask() : $.$spc.System.Threading.Tasks.ValueTask.FromException($.$stc.System.Threading.Channels.ChannelUtilities.CreateInvalidCompletionException(this._parent._doneWriting));
                    }
                    /*int */ get ItemsCountForDebugger()
                    {
                        return this._parent._items.Count;
                    }
                    /*IEnumerator<T> */ System$Threading$Channels$IDebugEnumerable$$$GetEnumerator()
                    {
                        return this._parent.GetEnumerator();
                    }
                    static $h = 2928928;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"p":[{"p":655361,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x800000000n),"f":2},"n":"ItemsCountForDebugger","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":2}],"m":[{"r":262145,"p":[{"n":"error","p":47251457}],"n":"TryComplete","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":32769},{"r":262145,"p":[{"n":"item","p":T?.$h??1507328}],"n":"TryWrite","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Boolean).$h,"p":[{"n":"cancellationToken","p":125960193}],"n":"WaitToWriteAsync","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":32769},{"r":136118273,"p":[{"n":"item","p":T?.$h??1507328},{"n":"cancellationToken","p":125960193}],"n":"WriteAsync","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":32769}],"l":[{"t":$.$stc.System.Threading.Channels.UnboundedPrioritizedChannel$$(T).$h,"n":"_parent","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":8}],"c":[{"p":[{"n":"parent","p":$.$stc.System.Threading.Channels.UnboundedPrioritizedChannel$$(T).$h}],"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":8}],"i":[$.$stc.System.Threading.Channels.IDebugEnumerable$$(T).$h],"d":$.$stc.System.Threading.Channels.UnboundedPrioritizedChannel$$(T).$h,"h":this.$h,"a":[{"t":37617665,"c":8627552257,"a":[{"v":"Items = {ItemsCountForDebugger}","t":1310721}]},{"t":37945345,"c":8627879937,"a":[{"v":$.$stc.System.Threading.Channels.DebugEnumeratorDebugView$$().$h,"t":142606337}]}]}; }
                    static get $b() { return $.$stc.System.Threading.Channels.ChannelWriter$$(T); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$stc.System.Threading.Channels.IDebugEnumerable$$(T) ]; }
                    static get $fullName() { return `System.Threading.Channels.UnboundedPrioritizedChannel<${T?.$fullName}>.UnboundedPrioritizedChannelWriter`; }
                }, $cls, ($v) => $cls.$_UnboundedPrioritizedChannelWriter = $v);
            }
            /*object */ get SyncObj()
            {
                return this._items;
            }
            /*Action<object?, CancellationToken>*/ CancellationCallbackDelegate$ = null;
            /*Action<object?, CancellationToken> */ get CancellationCallbackDelegate()
            {
                return this.CancellationCallbackDelegate$ ??= new ($.$spc.System.Action$$$($.$spc.System.Object, $.$spc.System.Threading.CancellationToken))().$ctor(this,  (/*state*/ state, /*cancellationToken*/ cancellationToken) =>
                {
                    /*AsyncOperation*/ let op = $.$cast(state, $.$stc.System.Threading.Channels.AsyncOperation);
                    if (op.TrySetCanceled(cancellationToken))
                    {
                        $.$stc.System.Threading.Channels.ChannelUtilities.UnsafeQueueUserWorkItem($.$spc.System.Collections.Generic.KeyValuePair$$$($.$stc.System.Threading.Channels.UnboundedPrioritizedChannel$$(T), $.$stc.System.Threading.Channels.AsyncOperation), new ($.$spc.System.Action$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$stc.System.Threading.Channels.UnboundedPrioritizedChannel$$(T), $.$stc.System.Threading.Channels.AsyncOperation)))().$ctor($.$stc.System.Threading.Channels.UnboundedPrioritizedChannel$$(T), /*static*/ (/*state*/ state) =>
                        {
                            //lock
                            try
                            {
                                $.$spc.System.Threading.Monitor.Enter(state.Key.SyncObj)
                                {
                                    //switch (state.Value)
                                    let $switch1 = state.Value;
                                    {
                                        let blockedReader;
                                        let waitingReader;
                                        $switchJumpStart1: 
                                        //case BlockedReadAsyncOperation<T> blockedReader:
                                        if ($.$is($switch1, $.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T), { set $v(v){ blockedReader = v; } }))
                                        {
                                            $.$stc.System.Threading.Channels.ChannelUtilities.Remove($.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T), $.$ref(() => state.Key._blockedReadersHead, ($v) => state.Key._blockedReadersHead = $v, $.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T)), blockedReader);
                                        }
                                        //case WaitingReadAsyncOperation waitingReader:
                                        else if ($.$is($switch1, $.$stc.System.Threading.Channels.WaitingReadAsyncOperation, { set $v(v){ waitingReader = v; } }))
                                        {
                                            $.$stc.System.Threading.Channels.ChannelUtilities.Remove($.$stc.System.Threading.Channels.WaitingReadAsyncOperation, $.$ref(() => state.Key._waitingReadersHead, ($v) => state.Key._waitingReadersHead = $v, $.$stc.System.Threading.Channels.WaitingReadAsyncOperation), waitingReader);
                                        }
                                        //default
                                        else
                                        {
                                            $.$spc.System.Diagnostics.Debug.Fail(`Unexpected operation: ${$.$spc.System.Object.ToString.call(state.Value)}`);
                                        }
                                    }
                                }
                            }
                            finally
                            {
                                $.$spc.System.Threading.Monitor.Exit(state.Key.SyncObj)
                            }
                        }, {"r":65537,"p":[{"n":"state","p":$.$spc.System.Collections.Generic.KeyValuePair$$$($.$stc.System.Threading.Channels.UnboundedPrioritizedChannel$$(T), $.$stc.System.Threading.Channels.AsyncOperation).$h}],"n":"","d":this.$h,"h":0,"f":1048610}), new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$stc.System.Threading.Channels.UnboundedPrioritizedChannel$$(T), $.$stc.System.Threading.Channels.AsyncOperation))().$ctor$2(this, op));
                    }
                }, {"r":65537,"p":[{"n":"state","p":131073},{"n":"cancellationToken","p":125960193}],"n":"","d":this.$h,"h":0,"f":1048578});
            }
            /*void */ AssertInvariants()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(!(this.SyncObj === null), "The sync obj must not be null.");
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Threading.Monitor.IsEntered(this.SyncObj), "Invariants can only be validated while holding the lock.");
                if (this._items.Count !== 0)
                {
                    if (this._runContinuationsAsynchronously)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._blockedReadersHead === null, "There's data available, so there shouldn't be any blocked readers.");
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._waitingReadersHead === null, "There's data available, so there shouldn't be any waiting readers.");
                    }
                    $.$spc.System.Diagnostics.Debug.Assert$1(!this._completion.Task.IsCompleted, "We still have data available, so shouldn't be completed.");
                }
                if ((!(this._blockedReadersHead === null) || !(this._waitingReadersHead === null)) && this._runContinuationsAsynchronously)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._items.Count === 0, "There are blocked/waiting readers, so there shouldn't be any data available.");
                }
                if (this._completion.Task.IsCompleted)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(!(this._doneWriting === null), "We're completed, so we must be done writing.");
                }
            }
            /*int */ get ItemsCountForDebugger()
            {
                return this._items.Count;
            }
            /*bool */ get ChannelIsClosedForDebugger()
            {
                return !(this._doneWriting === null);
            }
            /*IEnumerator<T> */ GetEnumerator()
            {
                /*List<T>*/ let list = (() =>
                {
                    let $t1 = new ($.$spc.System.Collections.Generic.List$$(T))().$ctor$1();
                    return $t1;
                })();
                var $en2 = this._items.UnorderedItems.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var item = $en2.Current;
                    {
                        list.Add(item.Item2);
                    }
                }
                list.Sort$1(this._items.Comparer);
                return list.GetEnumerator();
            }
            //Generated interface implemetation for System.Threading.Channels.IDebugEnumerable<T>.GetEnumerator()
            System$Threading$Channels$IDebugEnumerable$$$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 2797856;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":131073,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xB00000000n),"f":2},"n":"SyncObj","d":this.$h,"h":Number(BigInt(this.$h)|0xA00000000n),"f":2},{"p":$.$spc.System.Action$$$($.$spc.System.Object, $.$spc.System.Threading.CancellationToken).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xE00000000n),"f":2},"n":"CancellationCallbackDelegate","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":2},{"p":655361,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1100000000n),"f":2},"n":"ItemsCountForDebugger","d":this.$h,"h":Number(BigInt(this.$h)|0x1000000000n),"f":2},{"p":262145,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1300000000n),"f":2},"n":"ChannelIsClosedForDebugger","d":this.$h,"h":Number(BigInt(this.$h)|0x1200000000n),"f":2}],"m":[{"r":65537,"n":"AssertInvariants","d":this.$h,"h":Number(BigInt(this.$h)|0xF00000000n),"f":2,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"DEBUG","t":1310721}]}]},{"r":$.$spc.System.Collections.Generic.IEnumerator$$(T).$h,"n":"GetEnumerator","d":this.$h,"h":Number(BigInt(this.$h)|0x1400000000n),"f":1}],"l":[{"t":134414337,"n":"_completion","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":2},{"t":$.$sc.System.Collections.Generic.PriorityQueue$$$($.$spc.System.Boolean, T).$h,"n":"_items","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2},{"t":262145,"n":"_runContinuationsAsynchronously","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2},{"t":$.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T).$h,"n":"_blockedReadersHead","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":2},{"t":3060000,"n":"_waitingReadersHead","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":2},{"t":47251457,"n":"_doneWriting","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":2}],"c":[{"p":[{"n":"runContinuationsAsynchronously","p":262145},{"n":"comparer","p":$.$spc.System.Collections.Generic.IComparer$$(T).$h}],"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":8}],"i":[$.$stc.System.Threading.Channels.IDebugEnumerable$$(T).$h],"g":[T?.$h??1507328],"j":[$.$stc.System.Threading.Channels.UnboundedPrioritizedChannel$$(T).UnboundedPrioritizedChannelReader.$h,$.$stc.System.Threading.Channels.UnboundedPrioritizedChannel$$(T).UnboundedPrioritizedChannelWriter.$h],"r":1,"h":this.$h,"a":[{"t":37617665,"c":8627552257,"a":[{"v":"Items = {ItemsCountForDebugger}, Closed = {ChannelIsClosedForDebugger}","t":1310721}]},{"t":37945345,"c":8627879937,"a":[{"v":$.$stc.System.Threading.Channels.DebugEnumeratorDebugView$$().$h,"t":142606337}]}]}; }
            static get $b() { return $.$stc.System.Threading.Channels.Channel$$(T); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stc.System.Threading.Channels.IDebugEnumerable$$(T) ]; }
            static get $fullName() { return `System.Threading.Channels.UnboundedPrioritizedChannel<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$stc.System.Threading.Channels.SingleConsumerUnboundedChannel<>", (T) => $asm.$gt("$stc.System.Threading.Channels.SingleConsumerUnboundedChannel<>", [T], ($self) => class SingleConsumerUnboundedChannel$$ extends $.$stc.System.Threading.Channels.Channel$$(T)
        {
            /*TaskCompletionSource*/ _completion = null;
            /*SingleProducerSingleConsumerQueue<T>*/ _items = null;
            /*bool*/ _runContinuationsAsynchronously = false;
            /*Exception?*/ _doneWriting = null;
            /*BlockedReadAsyncOperation<T>?*/ _blockedReader = null;
            /*WaitingReadAsyncOperation?*/ _waitingReader = null;
            $ctor$3(/*bool*/ runContinuationsAsynchronously)
            {
                super.$ctor$2();
                {
                    this._runContinuationsAsynchronously = runContinuationsAsynchronously;
                    this._completion = new $.$spc.System.Threading.Tasks.TaskCompletionSource().$ctor$2(runContinuationsAsynchronously ? 64/*TaskCreationOptions.RunContinuationsAsynchronously*/ : 0/*TaskCreationOptions.None*/);
                    this.Reader = new ($.$stc.System.Threading.Channels.SingleConsumerUnboundedChannel$$(T).UnboundedChannelReader)().$ctor$2(this);
                    this.Writer = new ($.$stc.System.Threading.Channels.SingleConsumerUnboundedChannel$$(T).UnboundedChannelWriter)().$ctor$2(this);
                }
                return this;
            }
            static $_UnboundedChannelReader;
            static get UnboundedChannelReader()
            {
                let $cls = $.$stc.System.Threading.Channels.SingleConsumerUnboundedChannel$$(T);
                return $cls.$_UnboundedChannelReader ??= $asm.$ncls("$stc.System.Threading.Channels.SingleConsumerUnboundedChannel$$.UnboundedChannelReader", ($self) => class UnboundedChannelReader extends $.$stc.System.Threading.Channels.ChannelReader$$(T)
                {
                    /*SingleConsumerUnboundedChannel<T>*/ _parent = null;
                    /*BlockedReadAsyncOperation<T>*/ _readerSingleton = null;
                    /*WaitingReadAsyncOperation*/ _waiterSingleton = null;
                    $ctor$2(/*SingleConsumerUnboundedChannel<T>*/ parent)
                    {
                        super.$ctor$1();
                        {
                            this._parent = parent;
                            this._readerSingleton = new ($.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T))().$ctor$4(parent._runContinuationsAsynchronously, new $.$spc.System.Threading.CancellationToken(), true, null);
                            this._waiterSingleton = new $.$stc.System.Threading.Channels.WaitingReadAsyncOperation().$ctor$4(parent._runContinuationsAsynchronously, new $.$spc.System.Threading.CancellationToken(), true, null);
                        }
                        return this;
                    }
                    /*Task */ get Completion()
                    {
                        return this._parent._completion.Task;
                    }
                    /*bool */ get CanPeek()
                    {
                        return true;
                    }
                    /*ValueTask<T> */ ReadAsync(/*CancellationToken*/ cancellationToken)
                    {
                        if (cancellationToken.IsCancellationRequested)
                        {
                            return new ($.$spc.System.Threading.Tasks.ValueTask$$(T))().$ctor$3($.$spc.System.Threading.Tasks.Task.FromCanceled$1(T, cancellationToken));
                        }
                        /*T?*/ let item;
                        if (this.TryRead($.$ref(() => item, ($v) => item = $v, T)))
                        {
                            return new ($.$spc.System.Threading.Tasks.ValueTask$$(T))().$ctor$2(item);
                        }
                        /*SingleConsumerUnboundedChannel<T>*/ let parent = this._parent;
                        /*BlockedReadAsyncOperation<T>?*/ let oldBlockedReader, newBlockedReader;
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(parent.SyncObj)
                            {
                                if (this.TryRead($.$ref(() => item, ($v) => item = $v, T)))
                                {
                                    return new ($.$spc.System.Threading.Tasks.ValueTask$$(T))().$ctor$2(item);
                                }
                                if (!(parent._doneWriting === null))
                                {
                                    return $.$stc.System.Threading.Channels.ChannelUtilities.GetInvalidCompletionValueTask(T, parent._doneWriting);
                                }
                                oldBlockedReader = parent._blockedReader;
                                if (!cancellationToken.CanBeCanceled && this._readerSingleton.TryOwnAndReset())
                                {
                                    newBlockedReader = this._readerSingleton;
                                    if (newBlockedReader === oldBlockedReader)
                                    {
                                        oldBlockedReader = null;
                                    }
                                }
                                else 
                                {
                                    newBlockedReader = new ($.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T))().$ctor$4(this._parent._runContinuationsAsynchronously, new $.$spc.System.Threading.CancellationToken(), false, this._parent.CancellationCallbackDelegate);
                                }
                                parent._blockedReader = newBlockedReader;
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(parent.SyncObj)
                        }
                        oldBlockedReader?.TrySetCanceled(new $.$spc.System.Threading.CancellationToken());
                        return newBlockedReader.ValueTaskOfT;
                    }
                    /*bool */ TryRead(/*out T*/ item)
                    {
                        /*SingleConsumerUnboundedChannel<T>*/ let parent = this._parent;
                        if (parent._items.TryDequeue(item))
                        {
                            if (!(parent._doneWriting === null) && parent._items.IsEmpty)
                            {
                                $.$stc.System.Threading.Channels.ChannelUtilities.Complete(parent._completion, parent._doneWriting);
                            }
                            return true;
                        }
                        return false;
                    }
                    /*bool */ TryPeek(/*out T*/ item)
                    {
                        return this._parent._items.TryPeek(item);
                    }
                    /*ValueTask<bool> */ WaitToReadAsync(/*CancellationToken*/ cancellationToken)
                    {
                        if (cancellationToken.IsCancellationRequested)
                        {
                            return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Boolean))().$ctor$3($.$spc.System.Threading.Tasks.Task.FromCanceled$1($.$spc.System.Boolean, cancellationToken));
                        }
                        if (!this._parent._items.IsEmpty)
                        {
                            return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Boolean))().$ctor$2(true);
                        }
                        /*SingleConsumerUnboundedChannel<T>*/ let parent = this._parent;
                        /*WaitingReadAsyncOperation?*/ let oldWaitingReader = null, newWaitingReader;
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(parent.SyncObj)
                            {
                                if (!parent._items.IsEmpty)
                                {
                                    return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Boolean))().$ctor$2(true);
                                }
                                if (!(parent._doneWriting === null))
                                {
                                    return parent._doneWriting !== $.$stc.System.Threading.Channels.ChannelUtilities.s_doneWritingSentinel ? new ($.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Boolean))().$ctor$3($.$spc.System.Threading.Tasks.Task.FromException$1($.$spc.System.Boolean, parent._doneWriting)) : new ($.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Boolean))();
                                }
                                oldWaitingReader = parent._waitingReader;
                                if (!cancellationToken.CanBeCanceled && this._waiterSingleton.TryOwnAndReset())
                                {
                                    newWaitingReader = this._waiterSingleton;
                                    if (newWaitingReader === oldWaitingReader)
                                    {
                                        oldWaitingReader = null;
                                    }
                                }
                                else 
                                {
                                    newWaitingReader = new $.$stc.System.Threading.Channels.WaitingReadAsyncOperation().$ctor$4(this._parent._runContinuationsAsynchronously, new $.$spc.System.Threading.CancellationToken(), false, this._parent.CancellationCallbackDelegate);
                                }
                                parent._waitingReader = newWaitingReader;
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(parent.SyncObj)
                        }
                        oldWaitingReader?.TrySetCanceled(new $.$spc.System.Threading.CancellationToken());
                        return newWaitingReader.ValueTaskOfT;
                    }
                    /*int */ get ItemsCountForDebugger()
                    {
                        return this._parent._items.Count;
                    }
                    /*IEnumerator<T> */ System$Threading$Channels$IDebugEnumerable$$$GetEnumerator()
                    {
                        return this._parent._items.GetEnumerator();
                    }
                    static $h = 2404640;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"p":[{"p":133300225,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x600000000n),"f":32769},"n":"Completion","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x800000000n),"f":32769},"n":"CanPeek","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":32769},{"p":655361,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xE00000000n),"f":2},"n":"ItemsCountForDebugger","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":2}],"m":[{"r":$.$spc.System.Threading.Tasks.ValueTask$$(T).$h,"p":[{"n":"cancellationToken","p":125960193}],"n":"ReadAsync","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":32769},{"r":262145,"p":[{"n":"item","p":T?.$h??1507328,"f":2}],"n":"TryRead","d":this.$h,"h":Number(BigInt(this.$h)|0xA00000000n),"f":32769},{"r":262145,"p":[{"n":"item","p":T?.$h??1507328,"f":2}],"n":"TryPeek","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Boolean).$h,"p":[{"n":"cancellationToken","p":125960193}],"n":"WaitToReadAsync","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":32769}],"l":[{"t":$.$stc.System.Threading.Channels.SingleConsumerUnboundedChannel$$(T).$h,"n":"_parent","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":8},{"t":$.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T).$h,"n":"_readerSingleton","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2},{"t":3060000,"n":"_waiterSingleton","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2}],"c":[{"p":[{"n":"parent","p":$.$stc.System.Threading.Channels.SingleConsumerUnboundedChannel$$(T).$h}],"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":8}],"i":[$.$stc.System.Threading.Channels.IDebugEnumerable$$(T).$h],"d":$.$stc.System.Threading.Channels.SingleConsumerUnboundedChannel$$(T).$h,"h":this.$h,"a":[{"t":37617665,"c":8627552257,"a":[{"v":"Items = {ItemsCountForDebugger}","t":1310721}]},{"t":37945345,"c":8627879937,"a":[{"v":$.$stc.System.Threading.Channels.DebugEnumeratorDebugView$$().$h,"t":142606337}]}]}; }
                    static get $b() { return $.$stc.System.Threading.Channels.ChannelReader$$(T); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$stc.System.Threading.Channels.IDebugEnumerable$$(T) ]; }
                    static get $fullName() { return `System.Threading.Channels.SingleConsumerUnboundedChannel<${T?.$fullName}>.UnboundedChannelReader`; }
                }, $cls, ($v) => $cls.$_UnboundedChannelReader = $v);
            }
            static $_UnboundedChannelWriter;
            static get UnboundedChannelWriter()
            {
                let $cls = $.$stc.System.Threading.Channels.SingleConsumerUnboundedChannel$$(T);
                return $cls.$_UnboundedChannelWriter ??= $asm.$ncls("$stc.System.Threading.Channels.SingleConsumerUnboundedChannel$$.UnboundedChannelWriter", ($self) => class UnboundedChannelWriter extends $.$stc.System.Threading.Channels.ChannelWriter$$(T)
                {
                    /*SingleConsumerUnboundedChannel<T>*/ _parent = null;
                    $ctor$2(/*SingleConsumerUnboundedChannel<T>*/ parent)
                    {
                        super.$ctor$1();
                        this._parent = parent;
                        return this;
                    }
                    /*bool */ TryComplete(/*Exception?*/ error)
                    {
                        /*BlockedReadAsyncOperation<T>?*/ let blockedReader = null;
                        /*WaitingReadAsyncOperation?*/ let waitingReader = null;
                        /*bool*/ let completeTask = false;
                        /*SingleConsumerUnboundedChannel<T>*/ let parent = this._parent;
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(parent.SyncObj)
                            {
                                if (!(parent._doneWriting === null))
                                {
                                    return false;
                                }
                                parent._doneWriting = error ?? $.$stc.System.Threading.Channels.ChannelUtilities.s_doneWritingSentinel;
                                if (parent._items.IsEmpty)
                                {
                                    completeTask = true;
                                    if (!(parent._blockedReader === null))
                                    {
                                        blockedReader = parent._blockedReader;
                                        parent._blockedReader = null;
                                    }
                                    if (!(parent._waitingReader === null))
                                    {
                                        waitingReader = parent._waitingReader;
                                        parent._waitingReader = null;
                                    }
                                }
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(parent.SyncObj)
                        }
                        if (completeTask)
                        {
                            $.$stc.System.Threading.Channels.ChannelUtilities.Complete(parent._completion, error);
                        }
                        if (!(blockedReader === null))
                        {
                            error = $.$stc.System.Threading.Channels.ChannelUtilities.CreateInvalidCompletionException(error);
                            blockedReader.TrySetException(error);
                        }
                        if (!(waitingReader === null))
                        {
                            if (!(error === null))
                            {
                                waitingReader.TrySetException(error);
                            }
                            else 
                            {
                                waitingReader.TrySetResult(false);
                            }
                        }
                        return true;
                    }
                    /*bool */ TryWrite(/*T*/ item)
                    {
                        /*SingleConsumerUnboundedChannel<T>*/ let parent = this._parent;
                        while(true)
                        {
                            /*BlockedReadAsyncOperation<T>?*/ let blockedReader = null;
                            /*WaitingReadAsyncOperation?*/ let waitingReader = null;
                            //lock
                            try
                            {
                                $.$spc.System.Threading.Monitor.Enter(parent.SyncObj)
                                {
                                    if (!(parent._doneWriting === null))
                                    {
                                        return false;
                                    }
                                    blockedReader = parent._blockedReader;
                                    if (!(blockedReader === null))
                                    {
                                        parent._blockedReader = null;
                                    }
                                    else 
                                    {
                                        parent._items.Enqueue(item);
                                        waitingReader = parent._waitingReader;
                                        if (waitingReader === null)
                                        {
                                            return true;
                                        }
                                        parent._waitingReader = null;
                                    }
                                }
                            }
                            finally
                            {
                                $.$spc.System.Threading.Monitor.Exit(parent.SyncObj)
                            }
                            $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Boolean.op_ExclusiveOr$1((!(blockedReader === null)), (!(waitingReader === null))), "Expected either a blocked or waiting reader, but not both");
                            if (!(waitingReader === null))
                            {
                                waitingReader.TrySetResult(true);
                                return true;
                            }
                            $.$spc.System.Diagnostics.Debug.Assert$1(!(blockedReader === null), "blockedReader is not null");
                            if (blockedReader.TrySetResult(item))
                            {
                                return true;
                            }
                        }
                    }
                    /*ValueTask<bool> */ WaitToWriteAsync(/*CancellationToken*/ cancellationToken)
                    {
                        /*Exception?*/ let doneWriting = this._parent._doneWriting;
                        return cancellationToken.IsCancellationRequested ? new ($.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Boolean))().$ctor$3($.$spc.System.Threading.Tasks.Task.FromCanceled$1($.$spc.System.Boolean, cancellationToken)) : doneWriting === null ? new ($.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Boolean))().$ctor$2(true) : doneWriting !== $.$stc.System.Threading.Channels.ChannelUtilities.s_doneWritingSentinel ? new ($.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Boolean))().$ctor$3($.$spc.System.Threading.Tasks.Task.FromException$1($.$spc.System.Boolean, doneWriting)) : new ($.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Boolean))();
                    }
                    /*ValueTask */ WriteAsync(/*T*/ item, /*CancellationToken*/ cancellationToken)
                    {
                        return cancellationToken.IsCancellationRequested ? new $.$spc.System.Threading.Tasks.ValueTask().$ctor$2($.$spc.System.Threading.Tasks.Task.FromCanceled(cancellationToken)) : this.TryWrite(item) ? new $.$spc.System.Threading.Tasks.ValueTask() : new $.$spc.System.Threading.Tasks.ValueTask().$ctor$2($.$spc.System.Threading.Tasks.Task.FromException($.$stc.System.Threading.Channels.ChannelUtilities.CreateInvalidCompletionException(this._parent._doneWriting)));
                    }
                    /*int */ get ItemsCountForDebugger()
                    {
                        return this._parent._items.Count;
                    }
                    /*IEnumerator<T> */ System$Threading$Channels$IDebugEnumerable$$$GetEnumerator()
                    {
                        return this._parent._items.GetEnumerator();
                    }
                    static $h = 2470176;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"p":[{"p":655361,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x800000000n),"f":2},"n":"ItemsCountForDebugger","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":2}],"m":[{"r":262145,"p":[{"n":"error","p":47251457}],"n":"TryComplete","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":32769},{"r":262145,"p":[{"n":"item","p":T?.$h??1507328}],"n":"TryWrite","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Boolean).$h,"p":[{"n":"cancellationToken","p":125960193}],"n":"WaitToWriteAsync","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":32769},{"r":136118273,"p":[{"n":"item","p":T?.$h??1507328},{"n":"cancellationToken","p":125960193}],"n":"WriteAsync","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":32769}],"l":[{"t":$.$stc.System.Threading.Channels.SingleConsumerUnboundedChannel$$(T).$h,"n":"_parent","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":8}],"c":[{"p":[{"n":"parent","p":$.$stc.System.Threading.Channels.SingleConsumerUnboundedChannel$$(T).$h}],"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":8}],"i":[$.$stc.System.Threading.Channels.IDebugEnumerable$$(T).$h],"d":$.$stc.System.Threading.Channels.SingleConsumerUnboundedChannel$$(T).$h,"h":this.$h,"a":[{"t":37617665,"c":8627552257,"a":[{"v":"Items = {ItemsCountForDebugger}","t":1310721}]},{"t":37945345,"c":8627879937,"a":[{"v":$.$stc.System.Threading.Channels.DebugEnumeratorDebugView$$().$h,"t":142606337}]}]}; }
                    static get $b() { return $.$stc.System.Threading.Channels.ChannelWriter$$(T); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$stc.System.Threading.Channels.IDebugEnumerable$$(T) ]; }
                    static get $fullName() { return `System.Threading.Channels.SingleConsumerUnboundedChannel<${T?.$fullName}>.UnboundedChannelWriter`; }
                }, $cls, ($v) => $cls.$_UnboundedChannelWriter = $v);
            }
            /*object */ get SyncObj()
            {
                return this._items;
            }
            /*Action<object?, CancellationToken>*/ CancellationCallbackDelegate$ = null;
            /*Action<object?, CancellationToken> */ get CancellationCallbackDelegate()
            {
                return this.CancellationCallbackDelegate$ ??= new ($.$spc.System.Action$$$($.$spc.System.Object, $.$spc.System.Threading.CancellationToken))().$ctor(this,  (/**/ state, /**/ cancellationToken) =>
                {
                    /*AsyncOperation*/ let op = $.$cast(state, $.$stc.System.Threading.Channels.AsyncOperation);
                    if (op.TrySetCanceled(cancellationToken))
                    {
                        $.$stc.System.Threading.Channels.ChannelUtilities.UnsafeQueueUserWorkItem($.$spc.System.Collections.Generic.KeyValuePair$$$($.$stc.System.Threading.Channels.SingleConsumerUnboundedChannel$$(T), $.$stc.System.Threading.Channels.AsyncOperation), new ($.$spc.System.Action$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$stc.System.Threading.Channels.SingleConsumerUnboundedChannel$$(T), $.$stc.System.Threading.Channels.AsyncOperation)))().$ctor($.$stc.System.Threading.Channels.SingleConsumerUnboundedChannel$$(T), /*static*/ (/**/ state) =>
                        {
                            //lock
                            try
                            {
                                $.$spc.System.Threading.Monitor.Enter(state.Key.SyncObj)
                                {
                                    //switch (state.Value)
                                    let $switch1 = state.Value;
                                    {
                                        let blockedReader;
                                        let waitingReader;
                                        $switchJumpStart1: 
                                        //case BlockedReadAsyncOperation<T> blockedReader:
                                        if ($.$is($switch1, $.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T), { set $v(v){ blockedReader = v; } }))
                                        {
                                            if (state.Key._blockedReader === blockedReader)
                                            {
                                                state.Key._blockedReader = null;
                                            }
                                        }
                                        //case WaitingReadAsyncOperation waitingReader:
                                        else if ($.$is($switch1, $.$stc.System.Threading.Channels.WaitingReadAsyncOperation, { set $v(v){ waitingReader = v; } }))
                                        {
                                            if (state.Key._waitingReader === waitingReader)
                                            {
                                                state.Key._waitingReader = null;
                                            }
                                        }
                                        //default
                                        else
                                        {
                                            $.$spc.System.Diagnostics.Debug.Fail(`Unexpected operation: ${$.$spc.System.Object.ToString.call(state.Value)}`);
                                        }
                                    }
                                }
                            }
                            finally
                            {
                                $.$spc.System.Threading.Monitor.Exit(state.Key.SyncObj)
                            }
                        }, {"r":65537,"p":[{"n":"state","p":$.$spc.System.Collections.Generic.KeyValuePair$$$($.$stc.System.Threading.Channels.SingleConsumerUnboundedChannel$$(T), $.$stc.System.Threading.Channels.AsyncOperation).$h}],"n":"","d":this.$h,"h":0,"f":1048610}), new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$stc.System.Threading.Channels.SingleConsumerUnboundedChannel$$(T), $.$stc.System.Threading.Channels.AsyncOperation))().$ctor$2(this, op));
                    }
                }, {"r":65537,"p":[{"n":"state","p":131073},{"n":"cancellationToken","p":125960193}],"n":"","d":this.$h,"h":0,"f":1048578});
            }
            /*int */ get ItemsCountForDebugger()
            {
                return this._items.Count;
            }
            /*bool */ get ChannelIsClosedForDebugger()
            {
                return !(this._doneWriting === null);
            }
            /*IEnumerator<T> */ System$Threading$Channels$IDebugEnumerable$$$GetEnumerator()
            {
                return this._items.GetEnumerator();
            }
            //default member initializer
            constructor()
            {
                super();
                this._items = new ($.$stc.System.Collections.Concurrent.SingleProducerSingleConsumerQueue$$(T))().$ctor$1();
            }
            static $h = 2339104;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":131073,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xB00000000n),"f":2},"n":"SyncObj","d":this.$h,"h":Number(BigInt(this.$h)|0xA00000000n),"f":2},{"p":$.$spc.System.Action$$$($.$spc.System.Object, $.$spc.System.Threading.CancellationToken).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xE00000000n),"f":2},"n":"CancellationCallbackDelegate","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":2},{"p":655361,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1000000000n),"f":2},"n":"ItemsCountForDebugger","d":this.$h,"h":Number(BigInt(this.$h)|0xF00000000n),"f":2},{"p":262145,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1200000000n),"f":2},"n":"ChannelIsClosedForDebugger","d":this.$h,"h":Number(BigInt(this.$h)|0x1100000000n),"f":2}],"l":[{"t":134414337,"n":"_completion","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":2},{"t":$.$stc.System.Collections.Concurrent.SingleProducerSingleConsumerQueue$$(T).$h,"n":"_items","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2},{"t":262145,"n":"_runContinuationsAsynchronously","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2},{"t":47251457,"n":"_doneWriting","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":2},{"t":$.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T).$h,"n":"_blockedReader","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":2},{"t":3060000,"n":"_waitingReader","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":2}],"c":[{"p":[{"n":"runContinuationsAsynchronously","p":262145}],"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":8}],"i":[$.$stc.System.Threading.Channels.IDebugEnumerable$$(T).$h],"g":[T?.$h??1507328],"j":[$.$stc.System.Threading.Channels.SingleConsumerUnboundedChannel$$(T).UnboundedChannelReader.$h,$.$stc.System.Threading.Channels.SingleConsumerUnboundedChannel$$(T).UnboundedChannelWriter.$h],"r":1,"h":this.$h,"a":[{"t":37617665,"c":8627552257,"a":[{"v":"Items = {ItemsCountForDebugger}, Closed = {ChannelIsClosedForDebugger}","t":1310721}]},{"t":37945345,"c":8627879937,"a":[{"v":$.$stc.System.Threading.Channels.DebugEnumeratorDebugView$$().$h,"t":142606337}]}]}; }
            static get $b() { return $.$stc.System.Threading.Channels.Channel$$(T); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stc.System.Threading.Channels.IDebugEnumerable$$(T) ]; }
            static get $fullName() { return `System.Threading.Channels.SingleConsumerUnboundedChannel<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$stc.System.Threading.Channels.BoundedChannel<>", (T) => $asm.$gt("$stc.System.Threading.Channels.BoundedChannel<>", [T], ($self) => class BoundedChannel$$ extends $.$stc.System.Threading.Channels.Channel$$(T)
        {
            /*BoundedChannelFullMode*/ _mode = 0;
            /*Action<T>?*/ _itemDropped = null;
            /*TaskCompletionSource*/ _completion = null;
            /*int*/ _bufferedCapacity = 0;
            /*Deque<T>*/ _items = null;
            /*BlockedReadAsyncOperation<T>?*/ _blockedReadersHead = null;
            /*BlockedWriteAsyncOperation<T>?*/ _blockedWritersHead = null;
            /*WaitingReadAsyncOperation?*/ _waitingReadersHead = null;
            /*WaitingWriteAsyncOperation?*/ _waitingWritersHead = null;
            /*bool*/ _runContinuationsAsynchronously = false;
            /*Exception?*/ _doneWriting = null;
            $ctor$3(/*int*/ bufferedCapacity, /*BoundedChannelFullMode*/ mode, /*bool*/ runContinuationsAsynchronously, /*Action<T>?*/ itemDropped)
            {
                super.$ctor$2();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(bufferedCapacity > 0, "bufferedCapacity > 0");
                    this._bufferedCapacity = bufferedCapacity;
                    this._mode = mode;
                    this._runContinuationsAsynchronously = runContinuationsAsynchronously;
                    this._itemDropped = itemDropped;
                    this._completion = new $.$spc.System.Threading.Tasks.TaskCompletionSource().$ctor$2(runContinuationsAsynchronously ? 64/*TaskCreationOptions.RunContinuationsAsynchronously*/ : 0/*TaskCreationOptions.None*/);
                    this.Reader = new ($.$stc.System.Threading.Channels.BoundedChannel$$(T).BoundedChannelReader)().$ctor$2(this);
                    this.Writer = new ($.$stc.System.Threading.Channels.BoundedChannel$$(T).BoundedChannelWriter)().$ctor$2(this);
                }
                return this;
            }
            static $_BoundedChannelReader;
            static get BoundedChannelReader()
            {
                let $cls = $.$stc.System.Threading.Channels.BoundedChannel$$(T);
                return $cls.$_BoundedChannelReader ??= $asm.$ncls("$stc.System.Threading.Channels.BoundedChannel$$.BoundedChannelReader", ($self) => class BoundedChannelReader extends $.$stc.System.Threading.Channels.ChannelReader$$(T)
                {
                    /*BoundedChannel<T>*/ _parent = null;
                    /*BlockedReadAsyncOperation<T>*/ _readerSingleton = null;
                    /*WaitingReadAsyncOperation*/ _waiterSingleton = null;
                    $ctor$2(/*BoundedChannel<T>*/ parent)
                    {
                        super.$ctor$1();
                        {
                            this._parent = parent;
                            this._readerSingleton = new ($.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T))().$ctor$4(parent._runContinuationsAsynchronously, new $.$spc.System.Threading.CancellationToken(), true, null);
                            this._waiterSingleton = new $.$stc.System.Threading.Channels.WaitingReadAsyncOperation().$ctor$4(parent._runContinuationsAsynchronously, new $.$spc.System.Threading.CancellationToken(), true, null);
                        }
                        return this;
                    }
                    /*Task */ get Completion()
                    {
                        return this._parent._completion.Task;
                    }
                    /*bool */ get CanCount()
                    {
                        return true;
                    }
                    /*bool */ get CanPeek()
                    {
                        return true;
                    }
                    /*int */ get Count()
                    {
                        /*BoundedChannel<T>*/ let parent = this._parent;
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(parent.SyncObj)
                            {
                                parent.AssertInvariants();
                                return parent._items.Count;
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(parent.SyncObj)
                        }
                    }
                    /*int */ get ItemsCountForDebugger()
                    {
                        return this._parent._items.Count;
                    }
                    /*bool */ TryRead(/*out T*/ item)
                    {
                        /*BoundedChannel<T>*/ let parent = this._parent;
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(parent.SyncObj)
                            {
                                parent.AssertInvariants();
                                if (!parent._items.IsEmpty)
                                {
                                    item.$v = this.DequeueItemAndPostProcess();
                                    return true;
                                }
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(parent.SyncObj)
                        }
                        item.$v = $.$default(T);
                        return false;
                    }
                    /*bool */ TryPeek(/*out T*/ item)
                    {
                        /*BoundedChannel<T>*/ let parent = this._parent;
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(parent.SyncObj)
                            {
                                parent.AssertInvariants();
                                if (!parent._items.IsEmpty)
                                {
                                    item.$v = parent._items.PeekHead();
                                    return true;
                                }
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(parent.SyncObj)
                        }
                        item.$v = $.$default(T);
                        return false;
                    }
                    /*ValueTask<T> */ ReadAsync(/*CancellationToken*/ cancellationToken)
                    {
                        if (cancellationToken.IsCancellationRequested)
                        {
                            return new ($.$spc.System.Threading.Tasks.ValueTask$$(T))().$ctor$3($.$spc.System.Threading.Tasks.Task.FromCanceled$1(T, cancellationToken));
                        }
                        /*BoundedChannel<T>*/ let parent = this._parent;
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(parent.SyncObj)
                            {
                                parent.AssertInvariants();
                                if (!parent._items.IsEmpty)
                                {
                                    return new ($.$spc.System.Threading.Tasks.ValueTask$$(T))().$ctor$2(this.DequeueItemAndPostProcess());
                                }
                                if (!(parent._doneWriting === null))
                                {
                                    return $.$stc.System.Threading.Channels.ChannelUtilities.GetInvalidCompletionValueTask(T, parent._doneWriting);
                                }
                                if (!cancellationToken.CanBeCanceled)
                                {
                                    /*BlockedReadAsyncOperation<T>*/ let singleton = this._readerSingleton;
                                    if (singleton.TryOwnAndReset())
                                    {
                                        $.$stc.System.Threading.Channels.ChannelUtilities.Enqueue($.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T), $.$ref(() => parent._blockedReadersHead, ($v) => parent._blockedReadersHead = $v, $.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T)), singleton);
                                        return singleton.ValueTaskOfT;
                                    }
                                }
                                /*var*/ let reader = new ($.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T))().$ctor$4(parent._runContinuationsAsynchronously, new $.$spc.System.Threading.CancellationToken(), false, this._parent.CancellationCallbackDelegate);
                                $.$stc.System.Threading.Channels.ChannelUtilities.Enqueue($.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T), $.$ref(() => parent._blockedReadersHead, ($v) => parent._blockedReadersHead = $v, $.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T)), reader);
                                return reader.ValueTaskOfT;
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(parent.SyncObj)
                        }
                    }
                    /*ValueTask<bool> */ WaitToReadAsync(/*CancellationToken*/ cancellationToken)
                    {
                        if (cancellationToken.IsCancellationRequested)
                        {
                            return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Boolean))().$ctor$3($.$spc.System.Threading.Tasks.Task.FromCanceled$1($.$spc.System.Boolean, cancellationToken));
                        }
                        /*BoundedChannel<T>*/ let parent = this._parent;
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(parent.SyncObj)
                            {
                                parent.AssertInvariants();
                                if (!parent._items.IsEmpty)
                                {
                                    return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Boolean))().$ctor$2(true);
                                }
                                if (!(parent._doneWriting === null))
                                {
                                    return parent._doneWriting !== $.$stc.System.Threading.Channels.ChannelUtilities.s_doneWritingSentinel ? new ($.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Boolean))().$ctor$3($.$spc.System.Threading.Tasks.Task.FromException$1($.$spc.System.Boolean, parent._doneWriting)) : new ($.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Boolean))();
                                }
                                if (!cancellationToken.CanBeCanceled)
                                {
                                    /*WaitingReadAsyncOperation*/ let singleton = this._waiterSingleton;
                                    if (singleton.TryOwnAndReset())
                                    {
                                        $.$stc.System.Threading.Channels.ChannelUtilities.Enqueue($.$stc.System.Threading.Channels.WaitingReadAsyncOperation, $.$ref(() => parent._waitingReadersHead, ($v) => parent._waitingReadersHead = $v, $.$stc.System.Threading.Channels.WaitingReadAsyncOperation), singleton);
                                        return singleton.ValueTaskOfT;
                                    }
                                }
                                /*var*/ let waiter = new $.$stc.System.Threading.Channels.WaitingReadAsyncOperation().$ctor$4(parent._runContinuationsAsynchronously, new $.$spc.System.Threading.CancellationToken(), false, this._parent.CancellationCallbackDelegate);
                                $.$stc.System.Threading.Channels.ChannelUtilities.Enqueue($.$stc.System.Threading.Channels.WaitingReadAsyncOperation, $.$ref(() => parent._waitingReadersHead, ($v) => parent._waitingReadersHead = $v, $.$stc.System.Threading.Channels.WaitingReadAsyncOperation), waiter);
                                return waiter.ValueTaskOfT;
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(parent.SyncObj)
                        }
                    }
                    /*T */ DequeueItemAndPostProcess()
                    {
                        /*BoundedChannel<T>*/ let parent = this._parent;
                        $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Threading.Monitor.IsEntered(parent.SyncObj), "Monitor.IsEntered(parent.SyncObj)");
                        /*T*/ let item = parent._items.DequeueHead();
                        if (!(parent._doneWriting === null))
                        {
                            if (parent._items.IsEmpty)
                            {
                                $.$stc.System.Threading.Channels.ChannelUtilities.Complete(parent._completion, parent._doneWriting);
                            }
                        }
                        else 
                        {
                            /*BlockedWriteAsyncOperation<T>?*/ let w;
                            while($.$stc.System.Threading.Channels.ChannelUtilities.TryDequeue($.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T), $.$ref(() => parent._blockedWritersHead, ($v) => parent._blockedWritersHead = $v, $.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T)), $.$ref(() => w, ($v) => w = $v, $.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T))))
                            {
                                if (w.TrySetResult(new $.$stc.System.VoidResult()))
                                {
                                    parent._items.EnqueueTail(w.Item$2);
                                    return item;
                                }
                            }
                            $.$stc.System.Threading.Channels.ChannelUtilities.AssertAll($.$stc.System.Threading.Channels.WaitingWriteAsyncOperation, parent._waitingWritersHead, new ($.$spc.System.Func$$$($.$stc.System.Threading.Channels.WaitingWriteAsyncOperation, $.$spc.System.Boolean))().$ctor($.$stc.System.Threading.Channels.BoundedChannel$$(T).BoundedChannelReader, /*static*/ (/**/ writer) =>
                            {
                                return writer.RunContinuationsAsynchronously;
                            }, {"r":262145,"p":[{"n":"writer","p":3125536}],"n":"","d":this.$h,"h":0,"f":1048610}), "All WaitToWriteAsync waiters should have been asynchronous.");
                            $.$stc.System.Threading.Channels.ChannelUtilities.SetOperations($.$stc.System.Threading.Channels.WaitingWriteAsyncOperation, $.$spc.System.Boolean, $.$ref(() => parent._waitingWritersHead, ($v) => parent._waitingWritersHead = $v, $.$stc.System.Threading.Channels.WaitingWriteAsyncOperation), true);
                        }
                        return item;
                    }
                    /*IEnumerator<T> */ System$Threading$Channels$IDebugEnumerable$$$GetEnumerator()
                    {
                        return this._parent._items.GetEnumerator();
                    }
                    static $h = 1224992;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"p":[{"p":133300225,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x600000000n),"f":32769},"n":"Completion","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x800000000n),"f":32769},"n":"CanCount","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xA00000000n),"f":32769},"n":"CanPeek","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":32769},{"p":655361,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xC00000000n),"f":32769},"n":"Count","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":32769},{"p":655361,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xE00000000n),"f":2},"n":"ItemsCountForDebugger","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":2}],"m":[{"r":262145,"p":[{"n":"item","p":T?.$h??1507328,"f":2}],"n":"TryRead","d":this.$h,"h":Number(BigInt(this.$h)|0xF00000000n),"f":32769},{"r":262145,"p":[{"n":"item","p":T?.$h??1507328,"f":2}],"n":"TryPeek","d":this.$h,"h":Number(BigInt(this.$h)|0x1000000000n),"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$(T).$h,"p":[{"n":"cancellationToken","p":125960193}],"n":"ReadAsync","d":this.$h,"h":Number(BigInt(this.$h)|0x1100000000n),"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Boolean).$h,"p":[{"n":"cancellationToken","p":125960193}],"n":"WaitToReadAsync","d":this.$h,"h":Number(BigInt(this.$h)|0x1200000000n),"f":32769},{"r":T?.$h??1507328,"n":"DequeueItemAndPostProcess","d":this.$h,"h":Number(BigInt(this.$h)|0x1300000000n),"f":2}],"l":[{"t":$.$stc.System.Threading.Channels.BoundedChannel$$(T).$h,"n":"_parent","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":8},{"t":$.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T).$h,"n":"_readerSingleton","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2},{"t":3060000,"n":"_waiterSingleton","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2}],"c":[{"p":[{"n":"parent","p":$.$stc.System.Threading.Channels.BoundedChannel$$(T).$h}],"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":8}],"i":[$.$stc.System.Threading.Channels.IDebugEnumerable$$(T).$h],"d":$.$stc.System.Threading.Channels.BoundedChannel$$(T).$h,"h":this.$h,"a":[{"t":37617665,"c":8627552257,"a":[{"v":"Items = {ItemsCountForDebugger}","t":1310721}]},{"t":37945345,"c":8627879937,"a":[{"v":$.$stc.System.Threading.Channels.DebugEnumeratorDebugView$$().$h,"t":142606337}]}]}; }
                    static get $b() { return $.$stc.System.Threading.Channels.ChannelReader$$(T); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$stc.System.Threading.Channels.IDebugEnumerable$$(T) ]; }
                    static get $fullName() { return `System.Threading.Channels.BoundedChannel<${T?.$fullName}>.BoundedChannelReader`; }
                }, $cls, ($v) => $cls.$_BoundedChannelReader = $v);
            }
            static $_BoundedChannelWriter;
            static get BoundedChannelWriter()
            {
                let $cls = $.$stc.System.Threading.Channels.BoundedChannel$$(T);
                return $cls.$_BoundedChannelWriter ??= $asm.$ncls("$stc.System.Threading.Channels.BoundedChannel$$.BoundedChannelWriter", ($self) => class BoundedChannelWriter extends $.$stc.System.Threading.Channels.ChannelWriter$$(T)
                {
                    /*BoundedChannel<T>*/ _parent = null;
                    /*BlockedWriteAsyncOperation<T>*/ _writerSingleton = null;
                    /*WaitingWriteAsyncOperation*/ _waiterSingleton = null;
                    $ctor$2(/*BoundedChannel<T>*/ parent)
                    {
                        super.$ctor$1();
                        {
                            this._parent = parent;
                            this._writerSingleton = new ($.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T))().$ctor$4(true, new $.$spc.System.Threading.CancellationToken(), true, null);
                            this._waiterSingleton = new $.$stc.System.Threading.Channels.WaitingWriteAsyncOperation().$ctor$4(true, new $.$spc.System.Threading.CancellationToken(), true, null);
                        }
                        return this;
                    }
                    /*bool */ TryComplete(/*Exception?*/ error)
                    {
                        /*BoundedChannel<T>*/ let parent = this._parent;
                        /*BlockedReadAsyncOperation<T>?*/ let blockedReadersHead;
                        /*BlockedWriteAsyncOperation<T>?*/ let blockedWritersHead;
                        /*WaitingReadAsyncOperation?*/ let waitingReadersHead;
                        /*WaitingWriteAsyncOperation?*/ let waitingWritersHead;
                        /*bool*/ let completeTask;
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(parent.SyncObj)
                            {
                                parent.AssertInvariants();
                                if (!(parent._doneWriting === null))
                                {
                                    return false;
                                }
                                parent._doneWriting = error ?? $.$stc.System.Threading.Channels.ChannelUtilities.s_doneWritingSentinel;
                                completeTask = parent._items.IsEmpty;
                                blockedReadersHead = parent._blockedReadersHead;
                                blockedWritersHead = parent._blockedWritersHead;
                                waitingReadersHead = parent._waitingReadersHead;
                                waitingWritersHead = parent._waitingWritersHead;
                                parent._blockedReadersHead = null;
                                parent._blockedWritersHead = null;
                                parent._waitingReadersHead = null;
                                parent._waitingWritersHead = null;
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(parent.SyncObj)
                        }
                        if (completeTask)
                        {
                            $.$stc.System.Threading.Channels.ChannelUtilities.Complete(parent._completion, error);
                        }
                        $.$stc.System.Threading.Channels.ChannelUtilities.FailOperations($.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T), blockedReadersHead, $.$stc.System.Threading.Channels.ChannelUtilities.CreateInvalidCompletionException(error));
                        $.$stc.System.Threading.Channels.ChannelUtilities.FailOperations($.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T), blockedWritersHead, $.$stc.System.Threading.Channels.ChannelUtilities.CreateInvalidCompletionException(error));
                        $.$stc.System.Threading.Channels.ChannelUtilities.SetOrFailOperations($.$stc.System.Threading.Channels.WaitingReadAsyncOperation, $.$spc.System.Boolean, waitingReadersHead, false, error);
                        $.$stc.System.Threading.Channels.ChannelUtilities.SetOrFailOperations($.$stc.System.Threading.Channels.WaitingWriteAsyncOperation, $.$spc.System.Boolean, waitingWritersHead, false, error);
                        return true;
                    }
                    /*bool */ TryWrite(/*T*/ item)
                    {
                        /*BlockedReadAsyncOperation<T>?*/ let blockedReader = null;
                        /*WaitingReadAsyncOperation?*/ let waitingReadersHead = null;
                        /*BoundedChannel<T>*/ let parent = this._parent;
                        /*bool*/ let releaseLock = false;
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter$1(parent.SyncObj, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Boolean, () => releaseLock, ($v) => releaseLock = $v, null));
                            parent.AssertInvariants();
                            if (!(parent._doneWriting === null))
                            {
                                return false;
                            }
                            /*int*/ let count = parent._items.Count;
                            if (count === 0)
                            {
                                blockedReader = $.$stc.System.Threading.Channels.ChannelUtilities.TryDequeueAndReserveCompletionIfCancelable($.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T), $.$ref(() => parent._blockedReadersHead, ($v) => parent._blockedReadersHead = $v, $.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T)));
                                if (blockedReader === null)
                                {
                                    parent._items.EnqueueTail(item);
                                    waitingReadersHead = $.$stc.System.Threading.Channels.ChannelUtilities.TryReserveCompletionIfCancelable($.$stc.System.Threading.Channels.WaitingReadAsyncOperation, $.$ref(() => parent._waitingReadersHead, ($v) => parent._waitingReadersHead = $v, $.$stc.System.Threading.Channels.WaitingReadAsyncOperation));
                                    if (waitingReadersHead === null)
                                    {
                                        return true;
                                    }
                                }
                            }
                            else if (count < parent._bufferedCapacity)
                            {
                                parent._items.EnqueueTail(item);
                                return true;
                            }
                            else if (parent._mode === 0/*BoundedChannelFullMode.Wait*/)
                            {
                                return false;
                            }
                            else if (parent._mode === 3/*BoundedChannelFullMode.DropWrite*/)
                            {
                                $.$spc.System.Threading.Monitor.Exit(parent.SyncObj);
                                releaseLock = false;
                                parent._itemDropped?.Invoke(item);
                                return true;
                            }
                            else 
                            {
                                /*T*/ let droppedItem = parent._mode === 1/*BoundedChannelFullMode.DropNewest*/ ? parent._items.DequeueTail() : parent._items.DequeueHead();
                                parent._items.EnqueueTail(item);
                                $.$spc.System.Threading.Monitor.Exit(parent.SyncObj);
                                releaseLock = false;
                                parent._itemDropped?.Invoke(droppedItem);
                                return true;
                            }
                        }
                        finally
                        {
                            {
                                if (releaseLock)
                                {
                                    $.$spc.System.Threading.Monitor.Exit(parent.SyncObj);
                                }
                            }
                        }
                        if (!(blockedReader === null))
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(waitingReadersHead === null, "waitingReadersHead is null");
                            blockedReader.DangerousSetResult(item);
                        }
                        else 
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(!(waitingReadersHead === null), "waitingReadersHead is not null");
                            $.$stc.System.Threading.Channels.ChannelUtilities.DangerousSetOperations($.$stc.System.Threading.Channels.WaitingReadAsyncOperation, $.$spc.System.Boolean, waitingReadersHead, true);
                        }
                        return true;
                    }
                    /*ValueTask<bool> */ WaitToWriteAsync(/*CancellationToken*/ cancellationToken)
                    {
                        if (cancellationToken.IsCancellationRequested)
                        {
                            return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Boolean))().$ctor$3($.$spc.System.Threading.Tasks.Task.FromCanceled$1($.$spc.System.Boolean, cancellationToken));
                        }
                        /*BoundedChannel<T>*/ let parent = this._parent;
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(parent.SyncObj)
                            {
                                parent.AssertInvariants();
                                if (!(parent._doneWriting === null))
                                {
                                    return parent._doneWriting !== $.$stc.System.Threading.Channels.ChannelUtilities.s_doneWritingSentinel ? new ($.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Boolean))().$ctor$3($.$spc.System.Threading.Tasks.Task.FromException$1($.$spc.System.Boolean, parent._doneWriting)) : new ($.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Boolean))();
                                }
                                if (parent._items.Count < parent._bufferedCapacity || parent._mode !== 0/*BoundedChannelFullMode.Wait*/)
                                {
                                    return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Boolean))().$ctor$2(true);
                                }
                                if (!cancellationToken.CanBeCanceled)
                                {
                                    /*WaitingWriteAsyncOperation*/ let singleton = this._waiterSingleton;
                                    if (singleton.TryOwnAndReset())
                                    {
                                        $.$stc.System.Threading.Channels.ChannelUtilities.Enqueue($.$stc.System.Threading.Channels.WaitingWriteAsyncOperation, $.$ref(() => parent._waitingWritersHead, ($v) => parent._waitingWritersHead = $v, $.$stc.System.Threading.Channels.WaitingWriteAsyncOperation), singleton);
                                        return singleton.ValueTaskOfT;
                                    }
                                }
                                /*var*/ let waiter = new $.$stc.System.Threading.Channels.WaitingWriteAsyncOperation().$ctor$4(true, new $.$spc.System.Threading.CancellationToken(), false, this._parent.CancellationCallbackDelegate);
                                $.$stc.System.Threading.Channels.ChannelUtilities.Enqueue($.$stc.System.Threading.Channels.WaitingWriteAsyncOperation, $.$ref(() => parent._waitingWritersHead, ($v) => parent._waitingWritersHead = $v, $.$stc.System.Threading.Channels.WaitingWriteAsyncOperation), waiter);
                                return waiter.ValueTaskOfT;
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(parent.SyncObj)
                        }
                    }
                    /*ValueTask */ WriteAsync(/*T*/ item, /*CancellationToken*/ cancellationToken)
                    {
                        if (cancellationToken.IsCancellationRequested)
                        {
                            return new $.$spc.System.Threading.Tasks.ValueTask().$ctor$2($.$spc.System.Threading.Tasks.Task.FromCanceled(cancellationToken));
                        }
                        /*BlockedReadAsyncOperation<T>?*/ let blockedReader = null;
                        /*WaitingReadAsyncOperation?*/ let waitingReadersHead = null;
                        /*BoundedChannel<T>*/ let parent = this._parent;
                        /*bool*/ let releaseLock = false;
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter$1(parent.SyncObj, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Boolean, () => releaseLock, ($v) => releaseLock = $v, null));
                            parent.AssertInvariants();
                            if (!(parent._doneWriting === null))
                            {
                                return new $.$spc.System.Threading.Tasks.ValueTask().$ctor$2($.$spc.System.Threading.Tasks.Task.FromException($.$stc.System.Threading.Channels.ChannelUtilities.CreateInvalidCompletionException(parent._doneWriting)));
                            }
                            /*int*/ let count = parent._items.Count;
                            if (count === 0)
                            {
                                blockedReader = $.$stc.System.Threading.Channels.ChannelUtilities.TryDequeueAndReserveCompletionIfCancelable($.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T), $.$ref(() => parent._blockedReadersHead, ($v) => parent._blockedReadersHead = $v, $.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T)));
                                if (blockedReader === null)
                                {
                                    parent._items.EnqueueTail(item);
                                    waitingReadersHead = $.$stc.System.Threading.Channels.ChannelUtilities.TryReserveCompletionIfCancelable($.$stc.System.Threading.Channels.WaitingReadAsyncOperation, $.$ref(() => parent._waitingReadersHead, ($v) => parent._waitingReadersHead = $v, $.$stc.System.Threading.Channels.WaitingReadAsyncOperation));
                                    if (waitingReadersHead === null)
                                    {
                                        return new $.$spc.System.Threading.Tasks.ValueTask();
                                    }
                                }
                            }
                            else if (count < parent._bufferedCapacity)
                            {
                                parent._items.EnqueueTail(item);
                                return new $.$spc.System.Threading.Tasks.ValueTask();
                            }
                            else if (parent._mode === 0/*BoundedChannelFullMode.Wait*/)
                            {
                                if (!cancellationToken.CanBeCanceled)
                                {
                                    /*BlockedWriteAsyncOperation<T>*/ let singleton = this._writerSingleton;
                                    if (singleton.TryOwnAndReset())
                                    {
                                        singleton.Item$2 = item;
                                        $.$stc.System.Threading.Channels.ChannelUtilities.Enqueue($.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T), $.$ref(() => parent._blockedWritersHead, ($v) => parent._blockedWritersHead = $v, $.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T)), singleton);
                                        return singleton.ValueTask;
                                    }
                                }
                                /*var*/ let writer = (() =>
                                {
                                    //new $.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T)()
                                    const $t2 = $.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T);
                                    const $i2 = new $t2();
                                    $i2.$ctor$4(true, new $.$spc.System.Threading.CancellationToken(), false, this._parent.CancellationCallbackDelegate);
                                    $i2.Item$2 = item;
                                    return $i2;
                                })();
                                $.$stc.System.Threading.Channels.ChannelUtilities.Enqueue($.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T), $.$ref(() => parent._blockedWritersHead, ($v) => parent._blockedWritersHead = $v, $.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T)), writer);
                                return writer.ValueTask;
                            }
                            else if (parent._mode === 3/*BoundedChannelFullMode.DropWrite*/)
                            {
                                $.$spc.System.Threading.Monitor.Exit(parent.SyncObj);
                                releaseLock = false;
                                parent._itemDropped?.Invoke(item);
                                return new $.$spc.System.Threading.Tasks.ValueTask();
                            }
                            else 
                            {
                                /*T*/ let droppedItem = parent._mode === 1/*BoundedChannelFullMode.DropNewest*/ ? parent._items.DequeueTail() : parent._items.DequeueHead();
                                parent._items.EnqueueTail(item);
                                $.$spc.System.Threading.Monitor.Exit(parent.SyncObj);
                                releaseLock = false;
                                parent._itemDropped?.Invoke(droppedItem);
                                return new $.$spc.System.Threading.Tasks.ValueTask();
                            }
                        }
                        finally
                        {
                            {
                                if (releaseLock)
                                {
                                    $.$spc.System.Threading.Monitor.Exit(parent.SyncObj);
                                }
                            }
                        }
                        if (!(blockedReader === null))
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(waitingReadersHead === null, "waitingReadersHead is null");
                            blockedReader.DangerousSetResult(item);
                        }
                        else 
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(!(waitingReadersHead === null), "waitingReadersHead is not null");
                            $.$stc.System.Threading.Channels.ChannelUtilities.DangerousSetOperations($.$stc.System.Threading.Channels.WaitingReadAsyncOperation, $.$spc.System.Boolean, waitingReadersHead, true);
                        }
                        return new $.$spc.System.Threading.Tasks.ValueTask();
                    }
                    /*int */ get ItemsCountForDebugger()
                    {
                        return this._parent._items.Count;
                    }
                    /*int */ get CapacityForDebugger()
                    {
                        return this._parent._bufferedCapacity;
                    }
                    /*IEnumerator<T> */ System$Threading$Channels$IDebugEnumerable$$$GetEnumerator()
                    {
                        return this._parent._items.GetEnumerator();
                    }
                    static $h = 1290528;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"p":[{"p":655361,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xA00000000n),"f":2},"n":"ItemsCountForDebugger","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":2},{"p":655361,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xC00000000n),"f":2},"n":"CapacityForDebugger","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":2}],"m":[{"r":262145,"p":[{"n":"error","p":47251457}],"n":"TryComplete","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":32769},{"r":262145,"p":[{"n":"item","p":T?.$h??1507328}],"n":"TryWrite","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Boolean).$h,"p":[{"n":"cancellationToken","p":125960193}],"n":"WaitToWriteAsync","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":32769},{"r":136118273,"p":[{"n":"item","p":T?.$h??1507328},{"n":"cancellationToken","p":125960193}],"n":"WriteAsync","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":32769}],"l":[{"t":$.$stc.System.Threading.Channels.BoundedChannel$$(T).$h,"n":"_parent","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":8},{"t":$.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T).$h,"n":"_writerSingleton","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2},{"t":3125536,"n":"_waiterSingleton","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2}],"c":[{"p":[{"n":"parent","p":$.$stc.System.Threading.Channels.BoundedChannel$$(T).$h}],"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":8}],"i":[$.$stc.System.Threading.Channels.IDebugEnumerable$$(T).$h],"d":$.$stc.System.Threading.Channels.BoundedChannel$$(T).$h,"h":this.$h,"a":[{"t":37617665,"c":8627552257,"a":[{"v":"Items = {ItemsCountForDebugger}, Capacity = {CapacityForDebugger}","t":1310721}]},{"t":37945345,"c":8627879937,"a":[{"v":$.$stc.System.Threading.Channels.DebugEnumeratorDebugView$$().$h,"t":142606337}]}]}; }
                    static get $b() { return $.$stc.System.Threading.Channels.ChannelWriter$$(T); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$stc.System.Threading.Channels.IDebugEnumerable$$(T) ]; }
                    static get $fullName() { return `System.Threading.Channels.BoundedChannel<${T?.$fullName}>.BoundedChannelWriter`; }
                }, $cls, ($v) => $cls.$_BoundedChannelWriter = $v);
            }
            /*object */ get SyncObj()
            {
                return this._items;
            }
            /*Action<object?, CancellationToken>*/ CancellationCallbackDelegate$ = null;
            /*Action<object?, CancellationToken> */ get CancellationCallbackDelegate()
            {
                return this.CancellationCallbackDelegate$ ??= new ($.$spc.System.Action$$$($.$spc.System.Object, $.$spc.System.Threading.CancellationToken))().$ctor(this,  (/*state*/ state, /*cancellationToken*/ cancellationToken) =>
                {
                    /*AsyncOperation*/ let op = $.$cast(state, $.$stc.System.Threading.Channels.AsyncOperation);
                    if (op.TrySetCanceled(cancellationToken))
                    {
                        $.$stc.System.Threading.Channels.ChannelUtilities.UnsafeQueueUserWorkItem($.$spc.System.Collections.Generic.KeyValuePair$$$($.$stc.System.Threading.Channels.BoundedChannel$$(T), $.$stc.System.Threading.Channels.AsyncOperation), new ($.$spc.System.Action$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$stc.System.Threading.Channels.BoundedChannel$$(T), $.$stc.System.Threading.Channels.AsyncOperation)))().$ctor($.$stc.System.Threading.Channels.BoundedChannel$$(T), /*static*/ (/*state*/ state) =>
                        {
                            //lock
                            try
                            {
                                $.$spc.System.Threading.Monitor.Enter(state.Key.SyncObj)
                                {
                                    //switch (state.Value)
                                    let $switch1 = state.Value;
                                    {
                                        let blockedReader;
                                        let blockedWriter;
                                        let waitingReader;
                                        let waitingWriter;
                                        $switchJumpStart1: 
                                        //case BlockedReadAsyncOperation<T> blockedReader:
                                        if ($.$is($switch1, $.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T), { set $v(v){ blockedReader = v; } }))
                                        {
                                            $.$stc.System.Threading.Channels.ChannelUtilities.Remove($.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T), $.$ref(() => state.Key._blockedReadersHead, ($v) => state.Key._blockedReadersHead = $v, $.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T)), blockedReader);
                                        }
                                        //case BlockedWriteAsyncOperation<T> blockedWriter:
                                        else if ($.$is($switch1, $.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T), { set $v(v){ blockedWriter = v; } }))
                                        {
                                            $.$stc.System.Threading.Channels.ChannelUtilities.Remove($.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T), $.$ref(() => state.Key._blockedWritersHead, ($v) => state.Key._blockedWritersHead = $v, $.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T)), blockedWriter);
                                        }
                                        //case WaitingReadAsyncOperation waitingReader:
                                        else if ($.$is($switch1, $.$stc.System.Threading.Channels.WaitingReadAsyncOperation, { set $v(v){ waitingReader = v; } }))
                                        {
                                            $.$stc.System.Threading.Channels.ChannelUtilities.Remove($.$stc.System.Threading.Channels.WaitingReadAsyncOperation, $.$ref(() => state.Key._waitingReadersHead, ($v) => state.Key._waitingReadersHead = $v, $.$stc.System.Threading.Channels.WaitingReadAsyncOperation), waitingReader);
                                        }
                                        //case WaitingWriteAsyncOperation waitingWriter:
                                        else if ($.$is($switch1, $.$stc.System.Threading.Channels.WaitingWriteAsyncOperation, { set $v(v){ waitingWriter = v; } }))
                                        {
                                            $.$stc.System.Threading.Channels.ChannelUtilities.Remove($.$stc.System.Threading.Channels.WaitingWriteAsyncOperation, $.$ref(() => state.Key._waitingWritersHead, ($v) => state.Key._waitingWritersHead = $v, $.$stc.System.Threading.Channels.WaitingWriteAsyncOperation), waitingWriter);
                                        }
                                        //default
                                        else
                                        {
                                            $.$spc.System.Diagnostics.Debug.Fail(`Unexpected operation: ${$.$spc.System.Object.ToString.call(state.Value)}`);
                                        }
                                    }
                                }
                            }
                            finally
                            {
                                $.$spc.System.Threading.Monitor.Exit(state.Key.SyncObj)
                            }
                        }, {"r":65537,"p":[{"n":"state","p":$.$spc.System.Collections.Generic.KeyValuePair$$$($.$stc.System.Threading.Channels.BoundedChannel$$(T), $.$stc.System.Threading.Channels.AsyncOperation).$h}],"n":"","d":this.$h,"h":0,"f":1048610}), new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$stc.System.Threading.Channels.BoundedChannel$$(T), $.$stc.System.Threading.Channels.AsyncOperation))().$ctor$2(this, op));
                    }
                }, {"r":65537,"p":[{"n":"state","p":131073},{"n":"cancellationToken","p":125960193}],"n":"","d":this.$h,"h":0,"f":1048578});
            }
            /*void */ AssertInvariants()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(!(this.SyncObj === null), "The sync obj must not be null.");
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Threading.Monitor.IsEntered(this.SyncObj), "Invariants can only be validated while holding the lock.");
                if (!this._items.IsEmpty)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._blockedReadersHead === null, "There are items available, so there shouldn't be any blocked readers.");
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._waitingReadersHead === null, "There are items available, so there shouldn't be any waiting readers.");
                }
                if (this._items.Count < this._bufferedCapacity)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._blockedWritersHead === null, "There's space available, so there shouldn't be any blocked writers.");
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._waitingWritersHead === null, "There's space available, so there shouldn't be any waiting writers.");
                }
                if (!(this._blockedReadersHead === null))
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._items.IsEmpty, "There shouldn't be queued items if there's a blocked reader.");
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._blockedWritersHead === null, "There shouldn't be any blocked writer if there's a blocked reader.");
                }
                if (!(this._blockedWritersHead === null))
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._items.Count === this._bufferedCapacity, "We should have a full buffer if there's a blocked writer.");
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._blockedReadersHead === null, "There shouldn't be any blocked readers if there's a blocked writer.");
                }
                if (this._completion.Task.IsCompleted)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(!(this._doneWriting === null), "We can only complete if we're done writing.");
                }
            }
            /*int */ get ItemsCountForDebugger()
            {
                return this._items.Count;
            }
            /*bool */ get ChannelIsClosedForDebugger()
            {
                return !(this._doneWriting === null);
            }
            /*IEnumerator<T> */ System$Threading$Channels$IDebugEnumerable$$$GetEnumerator()
            {
                return this._items.GetEnumerator();
            }
            //default member initializer
            constructor()
            {
                super();
                this._items = new ($.$stc.System.Collections.Generic.Deque$$(T))().$ctor$1();
            }
            static $h = 1159456;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":131073,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1000000000n),"f":2},"n":"SyncObj","d":this.$h,"h":Number(BigInt(this.$h)|0xF00000000n),"f":2},{"p":$.$spc.System.Action$$$($.$spc.System.Object, $.$spc.System.Threading.CancellationToken).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1300000000n),"f":2},"n":"CancellationCallbackDelegate","d":this.$h,"h":Number(BigInt(this.$h)|0x1200000000n),"f":2},{"p":655361,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1600000000n),"f":2},"n":"ItemsCountForDebugger","d":this.$h,"h":Number(BigInt(this.$h)|0x1500000000n),"f":2},{"p":262145,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1800000000n),"f":2},"n":"ChannelIsClosedForDebugger","d":this.$h,"h":Number(BigInt(this.$h)|0x1700000000n),"f":2}],"m":[{"r":65537,"n":"AssertInvariants","d":this.$h,"h":Number(BigInt(this.$h)|0x1400000000n),"f":2,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"DEBUG","t":1310721}]}]}],"l":[{"t":1356064,"n":"_mode","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":2},{"t":$.$spc.System.Action$$(T).$h,"n":"_itemDropped","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2},{"t":134414337,"n":"_completion","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2},{"t":655361,"n":"_bufferedCapacity","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":2},{"t":$.$stc.System.Collections.Generic.Deque$$(T).$h,"n":"_items","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":2},{"t":$.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T).$h,"n":"_blockedReadersHead","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":2},{"t":$.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T).$h,"n":"_blockedWritersHead","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":2},{"t":3060000,"n":"_waitingReadersHead","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":2},{"t":3125536,"n":"_waitingWritersHead","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":2},{"t":262145,"n":"_runContinuationsAsynchronously","d":this.$h,"h":Number(BigInt(this.$h)|0xA00000000n),"f":2},{"t":47251457,"n":"_doneWriting","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":2}],"c":[{"p":[{"n":"bufferedCapacity","p":655361},{"n":"mode","p":1356064},{"n":"runContinuationsAsynchronously","p":262145},{"n":"itemDropped","p":$.$spc.System.Action$$(T).$h}],"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":8}],"i":[$.$stc.System.Threading.Channels.IDebugEnumerable$$(T).$h],"g":[T?.$h??1507328],"j":[$.$stc.System.Threading.Channels.BoundedChannel$$(T).BoundedChannelReader.$h,$.$stc.System.Threading.Channels.BoundedChannel$$(T).BoundedChannelWriter.$h],"r":1,"h":this.$h,"a":[{"t":37617665,"c":8627552257,"a":[{"v":"Items = {ItemsCountForDebugger}, Capacity = {_bufferedCapacity}, Mode = {_mode}, Closed = {ChannelIsClosedForDebugger}","t":1310721}]},{"t":37945345,"c":8627879937,"a":[{"v":$.$stc.System.Threading.Channels.DebugEnumeratorDebugView$$().$h,"t":142606337}]}]}; }
            static get $b() { return $.$stc.System.Threading.Channels.Channel$$(T); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stc.System.Threading.Channels.IDebugEnumerable$$(T) ]; }
            static get $fullName() { return `System.Threading.Channels.BoundedChannel<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$stc.System.Threading.Channels.UnboundedChannel<>", (T) => $asm.$gt("$stc.System.Threading.Channels.UnboundedChannel<>", [T], ($self) => class UnboundedChannel$$ extends $.$stc.System.Threading.Channels.Channel$$(T)
        {
            /*TaskCompletionSource*/ _completion = null;
            /*ConcurrentQueue<T>*/ _items = null;
            /*bool*/ _runContinuationsAsynchronously = false;
            /*BlockedReadAsyncOperation<T>?*/ _blockedReadersHead = null;
            /*WaitingReadAsyncOperation?*/ _waitingReadersHead = null;
            /*Exception?*/ _doneWriting = null;
            $ctor$3(/*bool*/ runContinuationsAsynchronously)
            {
                super.$ctor$2();
                {
                    this._runContinuationsAsynchronously = runContinuationsAsynchronously;
                    this._completion = new $.$spc.System.Threading.Tasks.TaskCompletionSource().$ctor$2(runContinuationsAsynchronously ? 64/*TaskCreationOptions.RunContinuationsAsynchronously*/ : 0/*TaskCreationOptions.None*/);
                    this.Reader = new ($.$stc.System.Threading.Channels.UnboundedChannel$$(T).UnboundedChannelReader)().$ctor$2(this);
                    this.Writer = new ($.$stc.System.Threading.Channels.UnboundedChannel$$(T).UnboundedChannelWriter)().$ctor$2(this);
                }
                return this;
            }
            static $_UnboundedChannelReader;
            static get UnboundedChannelReader()
            {
                let $cls = $.$stc.System.Threading.Channels.UnboundedChannel$$(T);
                return $cls.$_UnboundedChannelReader ??= $asm.$ncls("$stc.System.Threading.Channels.UnboundedChannel$$.UnboundedChannelReader", ($self) => class UnboundedChannelReader extends $.$stc.System.Threading.Channels.ChannelReader$$(T)
                {
                    /*UnboundedChannel<T>*/ _parent = null;
                    /*BlockedReadAsyncOperation<T>*/ _readerSingleton = null;
                    /*WaitingReadAsyncOperation*/ _waiterSingleton = null;
                    $ctor$2(/*UnboundedChannel<T>*/ parent)
                    {
                        super.$ctor$1();
                        {
                            this._parent = parent;
                            this._readerSingleton = new ($.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T))().$ctor$4(parent._runContinuationsAsynchronously, new $.$spc.System.Threading.CancellationToken(), true, null);
                            this._waiterSingleton = new $.$stc.System.Threading.Channels.WaitingReadAsyncOperation().$ctor$4(parent._runContinuationsAsynchronously, new $.$spc.System.Threading.CancellationToken(), true, null);
                        }
                        return this;
                    }
                    /*Task */ get Completion()
                    {
                        return this._parent._completion.Task;
                    }
                    /*bool */ get CanCount()
                    {
                        return true;
                    }
                    /*bool */ get CanPeek()
                    {
                        return true;
                    }
                    /*int */ get Count()
                    {
                        return this._parent._items.Count;
                    }
                    /*ValueTask<T> */ ReadAsync(/*CancellationToken*/ cancellationToken)
                    {
                        if (cancellationToken.IsCancellationRequested)
                        {
                            return new ($.$spc.System.Threading.Tasks.ValueTask$$(T))().$ctor$3($.$spc.System.Threading.Tasks.Task.FromCanceled$1(T, cancellationToken));
                        }
                        /*UnboundedChannel<T>*/ let parent = this._parent;
                        /*T?*/ let item;
                        if (parent._items.TryDequeue($.$ref(() => item, ($v) => item = $v, T)))
                        {
                            $.$stc.System.Threading.Channels.UnboundedChannel$$(T).UnboundedChannelReader.CompleteIfDone(parent);
                            return new ($.$spc.System.Threading.Tasks.ValueTask$$(T))().$ctor$2(item);
                        }
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(parent.SyncObj)
                            {
                                parent.AssertInvariants();
                                if (parent._items.TryDequeue($.$ref(() => item, ($v) => item = $v, T)))
                                {
                                    $.$stc.System.Threading.Channels.UnboundedChannel$$(T).UnboundedChannelReader.CompleteIfDone(parent);
                                    return new ($.$spc.System.Threading.Tasks.ValueTask$$(T))().$ctor$2(item);
                                }
                                if (!(parent._doneWriting === null))
                                {
                                    return $.$stc.System.Threading.Channels.ChannelUtilities.GetInvalidCompletionValueTask(T, parent._doneWriting);
                                }
                                /*BlockedReadAsyncOperation<T>*/ let reader = !cancellationToken.CanBeCanceled && this._readerSingleton.TryOwnAndReset() ? this._readerSingleton : new ($.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T))().$ctor$4(parent._runContinuationsAsynchronously, new $.$spc.System.Threading.CancellationToken(), false, this._parent.CancellationCallbackDelegate);
                                $.$stc.System.Threading.Channels.ChannelUtilities.Enqueue($.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T), $.$ref(() => parent._blockedReadersHead, ($v) => parent._blockedReadersHead = $v, $.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T)), reader);
                                return reader.ValueTaskOfT;
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(parent.SyncObj)
                        }
                    }
                    /*bool */ TryRead(/*out T*/ item)
                    {
                        /*UnboundedChannel<T>*/ let parent = this._parent;
                        if (parent._items.TryDequeue(item))
                        {
                            $.$stc.System.Threading.Channels.UnboundedChannel$$(T).UnboundedChannelReader.CompleteIfDone(parent);
                            return true;
                        }
                        item.$v = $.$default(T);
                        return false;
                    }
                    /*bool */ TryPeek(/*out T*/ item)
                    {
                        return this._parent._items.TryPeek(item);
                    }
                    static /*void */ CompleteIfDone(/*UnboundedChannel<T>*/ parent)
                    {
                        if (!(parent._doneWriting === null) && parent._items.IsEmpty)
                        {
                            $.$stc.System.Threading.Channels.ChannelUtilities.Complete(parent._completion, parent._doneWriting);
                        }
                    }
                    /*ValueTask<bool> */ WaitToReadAsync(/*CancellationToken*/ cancellationToken)
                    {
                        if (cancellationToken.IsCancellationRequested)
                        {
                            return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Boolean))().$ctor$3($.$spc.System.Threading.Tasks.Task.FromCanceled$1($.$spc.System.Boolean, cancellationToken));
                        }
                        if (!this._parent._items.IsEmpty)
                        {
                            return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Boolean))().$ctor$2(true);
                        }
                        /*UnboundedChannel<T>*/ let parent = this._parent;
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(parent.SyncObj)
                            {
                                parent.AssertInvariants();
                                if (!parent._items.IsEmpty)
                                {
                                    return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Boolean))().$ctor$2(true);
                                }
                                if (!(parent._doneWriting === null))
                                {
                                    return parent._doneWriting !== $.$stc.System.Threading.Channels.ChannelUtilities.s_doneWritingSentinel ? new ($.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Boolean))().$ctor$3($.$spc.System.Threading.Tasks.Task.FromException$1($.$spc.System.Boolean, parent._doneWriting)) : new ($.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Boolean))();
                                }
                                /*WaitingReadAsyncOperation*/ let waiter = !cancellationToken.CanBeCanceled && this._waiterSingleton.TryOwnAndReset() ? this._waiterSingleton : new $.$stc.System.Threading.Channels.WaitingReadAsyncOperation().$ctor$4(parent._runContinuationsAsynchronously, new $.$spc.System.Threading.CancellationToken(), false, this._parent.CancellationCallbackDelegate);
                                $.$stc.System.Threading.Channels.ChannelUtilities.Enqueue($.$stc.System.Threading.Channels.WaitingReadAsyncOperation, $.$ref(() => parent._waitingReadersHead, ($v) => parent._waitingReadersHead = $v, $.$stc.System.Threading.Channels.WaitingReadAsyncOperation), waiter);
                                return waiter.ValueTaskOfT;
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(parent.SyncObj)
                        }
                    }
                    /*IEnumerator<T> */ System$Threading$Channels$IDebugEnumerable$$$GetEnumerator()
                    {
                        return this._parent._items.GetEnumerator();
                    }
                    static $h = 2601248;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"p":[{"p":133300225,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x600000000n),"f":32769},"n":"Completion","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x800000000n),"f":32769},"n":"CanCount","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xA00000000n),"f":32769},"n":"CanPeek","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":32769},{"p":655361,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xC00000000n),"f":32769},"n":"Count","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":32769}],"m":[{"r":$.$spc.System.Threading.Tasks.ValueTask$$(T).$h,"p":[{"n":"cancellationToken","p":125960193}],"n":"ReadAsync","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":32769},{"r":262145,"p":[{"n":"item","p":T?.$h??1507328,"f":2}],"n":"TryRead","d":this.$h,"h":Number(BigInt(this.$h)|0xE00000000n),"f":32769},{"r":262145,"p":[{"n":"item","p":T?.$h??1507328,"f":2}],"n":"TryPeek","d":this.$h,"h":Number(BigInt(this.$h)|0xF00000000n),"f":32769},{"r":65537,"p":[{"n":"parent","p":$.$stc.System.Threading.Channels.UnboundedChannel$$(T).$h}],"n":"CompleteIfDone","d":this.$h,"h":Number(BigInt(this.$h)|0x1000000000n),"f":34},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Boolean).$h,"p":[{"n":"cancellationToken","p":125960193}],"n":"WaitToReadAsync","d":this.$h,"h":Number(BigInt(this.$h)|0x1100000000n),"f":32769}],"l":[{"t":$.$stc.System.Threading.Channels.UnboundedChannel$$(T).$h,"n":"_parent","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":8},{"t":$.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T).$h,"n":"_readerSingleton","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2},{"t":3060000,"n":"_waiterSingleton","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2}],"c":[{"p":[{"n":"parent","p":$.$stc.System.Threading.Channels.UnboundedChannel$$(T).$h}],"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":8}],"i":[$.$stc.System.Threading.Channels.IDebugEnumerable$$(T).$h],"d":$.$stc.System.Threading.Channels.UnboundedChannel$$(T).$h,"h":this.$h,"a":[{"t":37617665,"c":8627552257,"a":[{"v":"Items = {Count}","t":1310721}]},{"t":37945345,"c":8627879937,"a":[{"v":$.$stc.System.Threading.Channels.DebugEnumeratorDebugView$$().$h,"t":142606337}]}]}; }
                    static get $b() { return $.$stc.System.Threading.Channels.ChannelReader$$(T); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$stc.System.Threading.Channels.IDebugEnumerable$$(T) ]; }
                    static get $fullName() { return `System.Threading.Channels.UnboundedChannel<${T?.$fullName}>.UnboundedChannelReader`; }
                }, $cls, ($v) => $cls.$_UnboundedChannelReader = $v);
            }
            static $_UnboundedChannelWriter;
            static get UnboundedChannelWriter()
            {
                let $cls = $.$stc.System.Threading.Channels.UnboundedChannel$$(T);
                return $cls.$_UnboundedChannelWriter ??= $asm.$ncls("$stc.System.Threading.Channels.UnboundedChannel$$.UnboundedChannelWriter", ($self) => class UnboundedChannelWriter extends $.$stc.System.Threading.Channels.ChannelWriter$$(T)
                {
                    /*UnboundedChannel<T>*/ _parent = null;
                    $ctor$2(/*UnboundedChannel<T>*/ parent)
                    {
                        super.$ctor$1();
                        this._parent = parent;
                        return this;
                    }
                    /*bool */ TryComplete(/*Exception?*/ error)
                    {
                        /*UnboundedChannel<T>*/ let parent = this._parent;
                        /*BlockedReadAsyncOperation<T>?*/ let blockedReadersHead;
                        /*WaitingReadAsyncOperation?*/ let waitingReadersHead;
                        /*bool*/ let completeTask;
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(parent.SyncObj)
                            {
                                parent.AssertInvariants();
                                if (!(parent._doneWriting === null))
                                {
                                    return false;
                                }
                                parent._doneWriting = error ?? $.$stc.System.Threading.Channels.ChannelUtilities.s_doneWritingSentinel;
                                completeTask = parent._items.IsEmpty;
                                blockedReadersHead = parent._blockedReadersHead;
                                waitingReadersHead = parent._waitingReadersHead;
                                parent._blockedReadersHead = null;
                                parent._waitingReadersHead = null;
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(parent.SyncObj)
                        }
                        if (completeTask)
                        {
                            $.$stc.System.Threading.Channels.ChannelUtilities.Complete(parent._completion, error);
                        }
                        $.$stc.System.Threading.Channels.ChannelUtilities.FailOperations($.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T), blockedReadersHead, $.$stc.System.Threading.Channels.ChannelUtilities.CreateInvalidCompletionException(error));
                        $.$stc.System.Threading.Channels.ChannelUtilities.SetOrFailOperations($.$stc.System.Threading.Channels.WaitingReadAsyncOperation, $.$spc.System.Boolean, waitingReadersHead, false, error);
                        return true;
                    }
                    /*bool */ TryWrite(/*T*/ item)
                    {
                        /*UnboundedChannel<T>*/ let parent = this._parent;
                        /*BlockedReadAsyncOperation<T>?*/ let blockedReader = null;
                        /*WaitingReadAsyncOperation?*/ let waitingReadersHead = null;
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(parent.SyncObj)
                            {
                                parent.AssertInvariants();
                                if (!(parent._doneWriting === null))
                                {
                                    return false;
                                }
                                blockedReader = $.$stc.System.Threading.Channels.ChannelUtilities.TryDequeueAndReserveCompletionIfCancelable($.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T), $.$ref(() => parent._blockedReadersHead, ($v) => parent._blockedReadersHead = $v, $.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T)));
                                if (blockedReader === null)
                                {
                                    parent._items.Enqueue(item);
                                    waitingReadersHead = $.$stc.System.Threading.Channels.ChannelUtilities.TryReserveCompletionIfCancelable($.$stc.System.Threading.Channels.WaitingReadAsyncOperation, $.$ref(() => parent._waitingReadersHead, ($v) => parent._waitingReadersHead = $v, $.$stc.System.Threading.Channels.WaitingReadAsyncOperation));
                                }
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(parent.SyncObj)
                        }
                        if (!(blockedReader === null))
                        {
                            blockedReader.DangerousSetResult(item);
                        }
                        else if (!(waitingReadersHead === null))
                        {
                            $.$stc.System.Threading.Channels.ChannelUtilities.DangerousSetOperations($.$stc.System.Threading.Channels.WaitingReadAsyncOperation, $.$spc.System.Boolean, waitingReadersHead, true);
                        }
                        return true;
                    }
                    /*ValueTask<bool> */ WaitToWriteAsync(/*CancellationToken*/ cancellationToken)
                    {
                        /*Exception?*/ let doneWriting = this._parent._doneWriting;
                        return cancellationToken.IsCancellationRequested ? new ($.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Boolean))().$ctor$3($.$spc.System.Threading.Tasks.Task.FromCanceled$1($.$spc.System.Boolean, cancellationToken)) : doneWriting === null ? new ($.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Boolean))().$ctor$2(true) : doneWriting !== $.$stc.System.Threading.Channels.ChannelUtilities.s_doneWritingSentinel ? new ($.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Boolean))().$ctor$3($.$spc.System.Threading.Tasks.Task.FromException$1($.$spc.System.Boolean, doneWriting)) : new ($.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Boolean))();
                    }
                    /*ValueTask */ WriteAsync(/*T*/ item, /*CancellationToken*/ cancellationToken)
                    {
                        return cancellationToken.IsCancellationRequested ? new $.$spc.System.Threading.Tasks.ValueTask().$ctor$2($.$spc.System.Threading.Tasks.Task.FromCanceled(cancellationToken)) : this.TryWrite(item) ? new $.$spc.System.Threading.Tasks.ValueTask() : new $.$spc.System.Threading.Tasks.ValueTask().$ctor$2($.$spc.System.Threading.Tasks.Task.FromException($.$stc.System.Threading.Channels.ChannelUtilities.CreateInvalidCompletionException(this._parent._doneWriting)));
                    }
                    /*int */ get ItemsCountForDebugger()
                    {
                        return this._parent._items.Count;
                    }
                    /*IEnumerator<T> */ System$Threading$Channels$IDebugEnumerable$$$GetEnumerator()
                    {
                        return this._parent._items.GetEnumerator();
                    }
                    static $h = 2666784;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"p":[{"p":655361,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x800000000n),"f":2},"n":"ItemsCountForDebugger","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":2}],"m":[{"r":262145,"p":[{"n":"error","p":47251457}],"n":"TryComplete","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":32769},{"r":262145,"p":[{"n":"item","p":T?.$h??1507328}],"n":"TryWrite","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Boolean).$h,"p":[{"n":"cancellationToken","p":125960193}],"n":"WaitToWriteAsync","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":32769},{"r":136118273,"p":[{"n":"item","p":T?.$h??1507328},{"n":"cancellationToken","p":125960193}],"n":"WriteAsync","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":32769}],"l":[{"t":$.$stc.System.Threading.Channels.UnboundedChannel$$(T).$h,"n":"_parent","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":8}],"c":[{"p":[{"n":"parent","p":$.$stc.System.Threading.Channels.UnboundedChannel$$(T).$h}],"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":8}],"i":[$.$stc.System.Threading.Channels.IDebugEnumerable$$(T).$h],"d":$.$stc.System.Threading.Channels.UnboundedChannel$$(T).$h,"h":this.$h,"a":[{"t":37617665,"c":8627552257,"a":[{"v":"Items = {ItemsCountForDebugger}","t":1310721}]},{"t":37945345,"c":8627879937,"a":[{"v":$.$stc.System.Threading.Channels.DebugEnumeratorDebugView$$().$h,"t":142606337}]}]}; }
                    static get $b() { return $.$stc.System.Threading.Channels.ChannelWriter$$(T); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$stc.System.Threading.Channels.IDebugEnumerable$$(T) ]; }
                    static get $fullName() { return `System.Threading.Channels.UnboundedChannel<${T?.$fullName}>.UnboundedChannelWriter`; }
                }, $cls, ($v) => $cls.$_UnboundedChannelWriter = $v);
            }
            /*object */ get SyncObj()
            {
                return this._items;
            }
            /*Action<object?, CancellationToken>*/ CancellationCallbackDelegate$ = null;
            /*Action<object?, CancellationToken> */ get CancellationCallbackDelegate()
            {
                return this.CancellationCallbackDelegate$ ??= new ($.$spc.System.Action$$$($.$spc.System.Object, $.$spc.System.Threading.CancellationToken))().$ctor(this,  (/**/ state, /*cancellationToken*/ cancellationToken) =>
                {
                    /*AsyncOperation*/ let op = $.$cast(state, $.$stc.System.Threading.Channels.AsyncOperation);
                    if (op.TrySetCanceled(cancellationToken))
                    {
                        $.$stc.System.Threading.Channels.ChannelUtilities.UnsafeQueueUserWorkItem($.$spc.System.Collections.Generic.KeyValuePair$$$($.$stc.System.Threading.Channels.UnboundedChannel$$(T), $.$stc.System.Threading.Channels.AsyncOperation), new ($.$spc.System.Action$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$stc.System.Threading.Channels.UnboundedChannel$$(T), $.$stc.System.Threading.Channels.AsyncOperation)))().$ctor($.$stc.System.Threading.Channels.UnboundedChannel$$(T), /*static*/ (/*state*/ state) =>
                        {
                            //lock
                            try
                            {
                                $.$spc.System.Threading.Monitor.Enter(state.Key.SyncObj)
                                {
                                    //switch (state.Value)
                                    let $switch1 = state.Value;
                                    {
                                        let blockedReader;
                                        let waitingReader;
                                        $switchJumpStart1: 
                                        //case BlockedReadAsyncOperation<T> blockedReader:
                                        if ($.$is($switch1, $.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T), { set $v(v){ blockedReader = v; } }))
                                        {
                                            $.$stc.System.Threading.Channels.ChannelUtilities.Remove($.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T), $.$ref(() => state.Key._blockedReadersHead, ($v) => state.Key._blockedReadersHead = $v, $.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T)), blockedReader);
                                        }
                                        //case WaitingReadAsyncOperation waitingReader:
                                        else if ($.$is($switch1, $.$stc.System.Threading.Channels.WaitingReadAsyncOperation, { set $v(v){ waitingReader = v; } }))
                                        {
                                            $.$stc.System.Threading.Channels.ChannelUtilities.Remove($.$stc.System.Threading.Channels.WaitingReadAsyncOperation, $.$ref(() => state.Key._waitingReadersHead, ($v) => state.Key._waitingReadersHead = $v, $.$stc.System.Threading.Channels.WaitingReadAsyncOperation), waitingReader);
                                        }
                                        //default
                                        else
                                        {
                                            $.$spc.System.Diagnostics.Debug.Fail(`Unexpected operation: ${$.$spc.System.Object.ToString.call(state.Value)}`);
                                        }
                                    }
                                }
                            }
                            finally
                            {
                                $.$spc.System.Threading.Monitor.Exit(state.Key.SyncObj)
                            }
                        }, {"r":65537,"p":[{"n":"state","p":$.$spc.System.Collections.Generic.KeyValuePair$$$($.$stc.System.Threading.Channels.UnboundedChannel$$(T), $.$stc.System.Threading.Channels.AsyncOperation).$h}],"n":"","d":this.$h,"h":0,"f":1048610}), new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$stc.System.Threading.Channels.UnboundedChannel$$(T), $.$stc.System.Threading.Channels.AsyncOperation))().$ctor$2(this, op));
                    }
                }, {"r":65537,"p":[{"n":"state","p":131073},{"n":"cancellationToken","p":125960193}],"n":"","d":this.$h,"h":0,"f":1048578});
            }
            /*void */ AssertInvariants()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(!(this.SyncObj === null), "The sync obj must not be null.");
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Threading.Monitor.IsEntered(this.SyncObj), "Invariants can only be validated while holding the lock.");
                if (!this._items.IsEmpty)
                {
                    if (this._runContinuationsAsynchronously)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._blockedReadersHead === null, "There's data available, so there shouldn't be any blocked readers.");
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._waitingReadersHead === null, "There's data available, so there shouldn't be any waiting readers.");
                    }
                    $.$spc.System.Diagnostics.Debug.Assert$1(!this._completion.Task.IsCompleted, "We still have data available, so shouldn't be completed.");
                }
                if ((!(this._blockedReadersHead === null) || !(this._waitingReadersHead === null)) && this._runContinuationsAsynchronously)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._items.IsEmpty, "There are blocked/waiting readers, so there shouldn't be any data available.");
                }
                if (this._completion.Task.IsCompleted)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(!(this._doneWriting === null), "We're completed, so we must be done writing.");
                }
            }
            /*int */ get ItemsCountForDebugger()
            {
                return this._items.Count;
            }
            /*bool */ get ChannelIsClosedForDebugger()
            {
                return !(this._doneWriting === null);
            }
            /*IEnumerator<T> */ System$Threading$Channels$IDebugEnumerable$$$GetEnumerator()
            {
                return this._items.GetEnumerator();
            }
            //default member initializer
            constructor()
            {
                super();
                this._items = new ($.$spc.System.Collections.Concurrent.ConcurrentQueue$$(T))().$ctor$1();
            }
            static $h = 2535712;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":131073,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xB00000000n),"f":2},"n":"SyncObj","d":this.$h,"h":Number(BigInt(this.$h)|0xA00000000n),"f":2},{"p":$.$spc.System.Action$$$($.$spc.System.Object, $.$spc.System.Threading.CancellationToken).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xE00000000n),"f":2},"n":"CancellationCallbackDelegate","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":2},{"p":655361,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1100000000n),"f":2},"n":"ItemsCountForDebugger","d":this.$h,"h":Number(BigInt(this.$h)|0x1000000000n),"f":2},{"p":262145,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1300000000n),"f":2},"n":"ChannelIsClosedForDebugger","d":this.$h,"h":Number(BigInt(this.$h)|0x1200000000n),"f":2}],"m":[{"r":65537,"n":"AssertInvariants","d":this.$h,"h":Number(BigInt(this.$h)|0xF00000000n),"f":2,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"DEBUG","t":1310721}]}]}],"l":[{"t":134414337,"n":"_completion","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":2},{"t":$.$spc.System.Collections.Concurrent.ConcurrentQueue$$(T).$h,"n":"_items","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2},{"t":262145,"n":"_runContinuationsAsynchronously","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2},{"t":$.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(T).$h,"n":"_blockedReadersHead","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":2},{"t":3060000,"n":"_waitingReadersHead","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":2},{"t":47251457,"n":"_doneWriting","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":2}],"c":[{"p":[{"n":"runContinuationsAsynchronously","p":262145}],"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":8}],"i":[$.$stc.System.Threading.Channels.IDebugEnumerable$$(T).$h],"g":[T?.$h??1507328],"j":[$.$stc.System.Threading.Channels.UnboundedChannel$$(T).UnboundedChannelReader.$h,$.$stc.System.Threading.Channels.UnboundedChannel$$(T).UnboundedChannelWriter.$h],"r":1,"h":this.$h,"a":[{"t":37617665,"c":8627552257,"a":[{"v":"Items = {ItemsCountForDebugger}, Closed = {ChannelIsClosedForDebugger}","t":1310721}]},{"t":37945345,"c":8627879937,"a":[{"v":$.$stc.System.Threading.Channels.DebugEnumeratorDebugView$$().$h,"t":142606337}]}]}; }
            static get $b() { return $.$stc.System.Threading.Channels.Channel$$(T); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stc.System.Threading.Channels.IDebugEnumerable$$(T) ]; }
            static get $fullName() { return `System.Threading.Channels.UnboundedChannel<${T?.$fullName}>`; }
        }));
        
        $asm.$str("$stc.System.Threading.Channels.BoundedChannelFullMode", ($self) => class BoundedChannelFullMode extends $.$spc.System.Enum
        {
            static Wait = 0;
            static DropNewest = 1;
            static DropOldest = 2;
            static DropWrite = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Wait": 0n,
                    "DropNewest": 1n,
                    "DropOldest": 2n,
                    "DropWrite": 3n
                };
            }
            static $h = 1356064;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1356064,"n":"Wait","d":1356064,"h":4296323360,"f":33},{"t":1356064,"n":"DropNewest","d":1356064,"h":8591290656,"f":33},{"t":1356064,"n":"DropOldest","d":1356064,"h":12886257952,"f":33},{"t":1356064,"n":"DropWrite","d":1356064,"h":17181225248,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1356064,"h":21476192544,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1356064}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Threading.Channels.BoundedChannelFullMode`; }
        });
        
        $asm.$cls("$stc.System.Threading.Channels.BlockedReadAsyncOperation<>", (TResult) => $asm.$gt("$stc.System.Threading.Channels.BlockedReadAsyncOperation<>", [TResult], ($self) => class BlockedReadAsyncOperation$$ extends $.$stc.System.Threading.Channels.AsyncOperation$$$($self, TResult)
        {
            $ctor$4(/*bool*/ runContinuationsAsynchronously, /*CancellationToken*/ cancellationToken, /*bool*/ pooled, /*Action<object?, CancellationToken>?*/ cancellationCallback)
            {
                super.$ctor$3(runContinuationsAsynchronously, cancellationToken, pooled, cancellationCallback);
                {
                }
                return this;
            }
            static $h = 1028384;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"c":[{"p":[{"n":"runContinuationsAsynchronously","p":262145},{"n":"cancellationToken","p":125960193,"f":65},{"n":"pooled","p":262145,"f":65,"v":false},{"n":"cancellationCallback","p":$.$spc.System.Action$$$($.$spc.System.Object, $.$spc.System.Threading.CancellationToken).$h,"f":65}],"n":".ctor","o":"$ctor$4","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":1}],"i":[127401985,132710401,$.$spc.System.Threading.Tasks.Sources.IValueTaskSource$$(TResult).$h],"g":[TResult?.$h??1507328],"r":1,"h":this.$h}; }
            static get $b() { return $.$stc.System.Threading.Channels.AsyncOperation$$$($.$stc.System.Threading.Channels.BlockedReadAsyncOperation$$(TResult), TResult); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Threading.IThreadPoolWorkItem, $.$spc.System.Threading.Tasks.Sources.IValueTaskSource, $.$spc.System.Threading.Tasks.Sources.IValueTaskSource$$(TResult) ]; }
            static get $fullName() { return `System.Threading.Channels.BlockedReadAsyncOperation<${TResult?.$fullName}>`; }
        }));
        
        $asm.$cls("$stc.System.Threading.Channels.BlockedWriteAsyncOperation<>", (T) => $asm.$gt("$stc.System.Threading.Channels.BlockedWriteAsyncOperation<>", [T], ($self) => class BlockedWriteAsyncOperation$$ extends $.$stc.System.Threading.Channels.AsyncOperation$$$($self, $.$stc.System.VoidResult)
        {
            $ctor$4(/*bool*/ runContinuationsAsynchronously, /*CancellationToken*/ cancellationToken, /*bool*/ pooled, /*Action<object?, CancellationToken>?*/ cancellationCallback)
            {
                super.$ctor$3(runContinuationsAsynchronously, cancellationToken, pooled, cancellationCallback);
                {
                }
                return this;
            }
            /*T?*/ Item$2 = null;
            static $h = 1093920;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":T?.$h??1507328,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":1},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x500000000n),"f":1},"n":"Item","o":"@$2","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":1}],"c":[{"p":[{"n":"runContinuationsAsynchronously","p":262145},{"n":"cancellationToken","p":125960193,"f":65},{"n":"pooled","p":262145,"f":65,"v":false},{"n":"cancellationCallback","p":$.$spc.System.Action$$$($.$spc.System.Object, $.$spc.System.Threading.CancellationToken).$h,"f":65}],"n":".ctor","o":"$ctor$4","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":1}],"i":[127401985,132710401,$.$spc.System.Threading.Tasks.Sources.IValueTaskSource$$($.$stc.System.VoidResult).$h],"g":[T?.$h??1507328],"r":1,"h":this.$h}; }
            static get $b() { return $.$stc.System.Threading.Channels.AsyncOperation$$$($.$stc.System.Threading.Channels.BlockedWriteAsyncOperation$$(T), $.$stc.System.VoidResult); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Threading.IThreadPoolWorkItem, $.$spc.System.Threading.Tasks.Sources.IValueTaskSource, $.$spc.System.Threading.Tasks.Sources.IValueTaskSource$$($.$stc.System.VoidResult) ]; }
            static get $fullName() { return `System.Threading.Channels.BlockedWriteAsyncOperation<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$stc.System.Threading.Channels.WaitingReadAsyncOperation", ($self) => class WaitingReadAsyncOperation extends $.$stc.System.Threading.Channels.AsyncOperation$$$($self, $.$spc.System.Boolean)
        {
            $ctor$4(/*bool*/ runContinuationsAsynchronously, /*CancellationToken*/ cancellationToken, /*bool*/ pooled, /*Action<object?, CancellationToken>?*/ cancellationCallback)
            {
                super.$ctor$3(runContinuationsAsynchronously, cancellationToken, pooled, cancellationCallback);
                {
                }
                return this;
            }
            static $h = 3060000;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"c":[{"p":[{"n":"runContinuationsAsynchronously","p":262145},{"n":"cancellationToken","p":125960193,"f":65},{"n":"pooled","p":262145,"f":65,"v":false},{"n":"cancellationCallback","p":$.$spc.System.Action$$$($.$spc.System.Object, $.$spc.System.Threading.CancellationToken).$h,"f":65}],"n":".ctor","o":"$ctor$4","d":3060000,"h":4298027296,"f":1}],"i":[127401985,132710401,$.$spc.System.Threading.Tasks.Sources.IValueTaskSource$$($.$spc.System.Boolean).$h],"h":3060000}; }
            static get $b() { return $.$stc.System.Threading.Channels.AsyncOperation$$$($.$stc.System.Threading.Channels.WaitingReadAsyncOperation, $.$spc.System.Boolean); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Threading.IThreadPoolWorkItem, $.$spc.System.Threading.Tasks.Sources.IValueTaskSource, $.$spc.System.Threading.Tasks.Sources.IValueTaskSource$$($.$spc.System.Boolean) ]; }
            static get $fullName() { return `System.Threading.Channels.WaitingReadAsyncOperation`; }
        });
        
        $asm.$cls("$stc.System.Threading.Channels.WaitingWriteAsyncOperation", ($self) => class WaitingWriteAsyncOperation extends $.$stc.System.Threading.Channels.AsyncOperation$$$($self, $.$spc.System.Boolean)
        {
            $ctor$4(/*bool*/ runContinuationsAsynchronously, /*CancellationToken*/ cancellationToken, /*bool*/ pooled, /*Action<object?, CancellationToken>?*/ cancellationCallback)
            {
                super.$ctor$3(runContinuationsAsynchronously, cancellationToken, pooled, cancellationCallback);
                {
                }
                return this;
            }
            static $h = 3125536;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"c":[{"p":[{"n":"runContinuationsAsynchronously","p":262145},{"n":"cancellationToken","p":125960193,"f":65},{"n":"pooled","p":262145,"f":65,"v":false},{"n":"cancellationCallback","p":$.$spc.System.Action$$$($.$spc.System.Object, $.$spc.System.Threading.CancellationToken).$h,"f":65}],"n":".ctor","o":"$ctor$4","d":3125536,"h":4298092832,"f":1}],"i":[127401985,132710401,$.$spc.System.Threading.Tasks.Sources.IValueTaskSource$$($.$spc.System.Boolean).$h],"h":3125536}; }
            static get $b() { return $.$stc.System.Threading.Channels.AsyncOperation$$$($.$stc.System.Threading.Channels.WaitingWriteAsyncOperation, $.$spc.System.Boolean); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Threading.IThreadPoolWorkItem, $.$spc.System.Threading.Tasks.Sources.IValueTaskSource, $.$spc.System.Threading.Tasks.Sources.IValueTaskSource$$($.$spc.System.Boolean) ]; }
            static get $fullName() { return `System.Threading.Channels.WaitingWriteAsyncOperation`; }
        });
        
        $asm.$cls("$stc.System.Collections.Concurrent.MultiProducerMultiConsumerQueue<>", (T) => $asm.$gt("$stc.System.Collections.Concurrent.MultiProducerMultiConsumerQueue<>", [T], ($self) => class MultiProducerMultiConsumerQueue$$ extends $.$spc.System.Collections.Concurrent.ConcurrentQueue$$(T)
        {
            /*void */ System$Collections$Concurrent$IProducerConsumerQueue$$$Enqueue(/*T*/ item)
            {
                this.Enqueue(item);
            }
            /*bool */ System$Collections$Concurrent$IProducerConsumerQueue$$$TryDequeue(/*out T*/ result)
            {
                return this.TryDequeue(result);
            }
            /*bool */ get System$Collections$Concurrent$IProducerConsumerQueue$$$IsEmpty()
            {
                return this.IsEmpty;
            }
            /*int */ get System$Collections$Concurrent$IProducerConsumerQueue$$$Count()
            {
                return this.Count;
            }
            /*int */ System$Collections$Concurrent$IProducerConsumerQueue$$$GetCountSafe(/*object*/ syncObj)
            {
                return this.Count;
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 307488;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":262145,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":2},"n":"{$.$stc.System.Collections.Concurrent.IProducerConsumerQueue$$(T).$h}.IsEmpty","o":"System$Collections$Concurrent$IProducerConsumerQueue$$$IsEmpty","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2},{"p":655361,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x600000000n),"f":2},"n":"{$.$stc.System.Collections.Concurrent.IProducerConsumerQueue$$(T).$h}.Count","o":"System$Collections$Concurrent$IProducerConsumerQueue$$$Count","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":2}],"c":[{"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":1}],"i":[$.$spc.System.Collections.Concurrent.IProducerConsumerCollection$$(T).$h,31391745,$.$spc.System.Collections.Generic.IReadOnlyCollection$$(T).$h,$.$stc.System.Collections.Concurrent.IProducerConsumerQueue$$(T).$h,$.$spc.System.Collections.Generic.IEnumerable$$(T).$h,31653889],"g":[T?.$h??1507328],"r":1,"h":this.$h,"a":[{"t":37617665,"c":8627552257,"a":[{"v":"Count = {Count}","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Collections.Concurrent.ConcurrentQueue$$(T); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Concurrent.IProducerConsumerCollection$$(T), $.$spc.System.Collections.ICollection, $.$spc.System.Collections.Generic.IReadOnlyCollection$$(T), $.$stc.System.Collections.Concurrent.IProducerConsumerQueue$$(T), $.$spc.System.Collections.Generic.IEnumerable$$(T), $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Collections.Concurrent.MultiProducerMultiConsumerQueue<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$stc.System.Threading.Channels.ChannelClosedException", ($self) => class ChannelClosedException extends $.$spc.System.InvalidOperationException
        {
            $ctor$13()
            {
                super.$ctor$10($.$stc.System.SR.ChannelClosedException_DefaultMessage);
                {
                }
                return this;
            }
            $ctor$14(/*string?*/ message)
            {
                super.$ctor$10(message ?? $.$stc.System.SR.ChannelClosedException_DefaultMessage);
                {
                }
                return this;
            }
            $ctor$15(/*Exception?*/ innerException)
            {
                super.$ctor$11($.$stc.System.SR.ChannelClosedException_DefaultMessage, innerException);
                {
                }
                return this;
            }
            $ctor$16(/*string?*/ message, /*Exception?*/ innerException)
            {
                super.$ctor$11(message ?? $.$stc.System.SR.ChannelClosedException_DefaultMessage, innerException);
                {
                }
                return this;
            }
            $ctor$17(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor$12(info, context);
                {
                }
                return this;
            }
            static $h = 1683744;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":58261505,"h":1683744}; }
            static get $b() { return $.$spc.System.InvalidOperationException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Threading.Channels.ChannelClosedException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Threading.ThreadPool"))