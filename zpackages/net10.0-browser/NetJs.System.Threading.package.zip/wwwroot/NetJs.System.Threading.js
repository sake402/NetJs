
//--TRIMMABLE-BOUNDARY-START(20)
(function ($global, $, $$) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Threading", 
    {
  "h": 20,
  "f": "System.Threading",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 159121409,
      "c": 13044023297,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106299393,
      "c": 4401266689,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106364929,
      "c": 4401332225,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106823681,
      "c": 4401790977,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 4401922049,
      "a": [
        {
          "v": "1.0.35\u002B39e7ca3e4bf1d7d75afdb3a3db320b6c1a1b2fcf",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 4402774017,
      "a": [
        {
          "v": "NetJs.System.Threading",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 4402905089,
      "a": [
        {
          "v": "NetJs.System.Threading",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 4403036161,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159186945,
      "c": 4454154241,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 158924801,
      "c": 4453892097,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(196628)
        $asm.$cls("$st.System.SR", ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(498216402964)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(498216402964)
            
            //--TRIMMABLE-BOUNDARY-START(489626468372)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(489626468372)
            
            //--TRIMMABLE-BOUNDARY-START(493921435668)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(373662351380);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Object.ReferenceEquals($.$st.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("System.Threading", $.$st.System.SR.$type.Assembly);
                    $.$st.System.SR.s_resourceManager = temp;
                }
                return $.$st.System.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(493921435668)
            
            //--TRIMMABLE-BOUNDARY-START(60129738772)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227633463316);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$st.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(511101304852);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$st.System.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(60129738772)
            
            //--TRIMMABLE-BOUNDARY-START(55834771476)
            static /*string */ get CountdownEvent_Increment_AlreadyZero()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219043528724);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The event is already signaled and cannot be incremented.";
            }
            //--TRIMMABLE-BOUNDARY-END(55834771476)
            
            //--TRIMMABLE-BOUNDARY-START(51539804180)
            static /*string */ get CountdownEvent_Increment_AlreadyMax()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210453594132);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The increment operation would cause the CurrentCount to overflow.";
            }
            //--TRIMMABLE-BOUNDARY-END(51539804180)
            
            //--TRIMMABLE-BOUNDARY-START(47244836884)
            static /*string */ get CountdownEvent_Decrement_BelowZero()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201863659540);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Invalid attempt made to decrement the event's count below zero.";
            }
            //--TRIMMABLE-BOUNDARY-END(47244836884)
            
            //--TRIMMABLE-BOUNDARY-START(42949869588)
            static /*string */ get Common_OperationCanceled()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193273724948);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The operation was canceled.";
            }
            //--TRIMMABLE-BOUNDARY-END(42949869588)
            
            //--TRIMMABLE-BOUNDARY-START(34359934996)
            static /*string */ get Barrier_SignalAndWait_InvalidOperation_ZeroTotal()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176093855764);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The barrier has no registered participants.";
            }
            //--TRIMMABLE-BOUNDARY-END(34359934996)
            
            //--TRIMMABLE-BOUNDARY-START(25770000404)
            static /*string */ get Barrier_SignalAndWait_ArgumentOutOfRange()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158913986580);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The specified timeout must represent a value between -1 and Int32.MaxValue, inclusive.";
            }
            //--TRIMMABLE-BOUNDARY-END(25770000404)
            
            //--TRIMMABLE-BOUNDARY-START(21475033108)
            static /*string */ get Barrier_RemoveParticipants_InvalidOperation()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324051988);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The participantCount argument is greater than the number of participants that haven't yet arrived at the barrier in this phase.";
            }
            //--TRIMMABLE-BOUNDARY-END(21475033108)
            
            //--TRIMMABLE-BOUNDARY-START(17180065812)
            static /*string */ get Barrier_RemoveParticipants_ArgumentOutOfRange()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734117396);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The participantCount argument must be less than or equal the number of participants.";
            }
            //--TRIMMABLE-BOUNDARY-END(17180065812)
            
            //--TRIMMABLE-BOUNDARY-START(12885098516)
            static /*string */ get Barrier_InvalidOperation_CalledFromPHA()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144182804);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "This method may not be called from within the postPhaseAction.";
            }
            //--TRIMMABLE-BOUNDARY-END(12885098516)
            
            //--TRIMMABLE-BOUNDARY-START(30064967700)
            static /*string */ get Barrier_SignalAndWait_InvalidOperation_ThreadsExceeded()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167503921172);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The number of threads using the barrier exceeded the total number of registered participants.";
            }
            //--TRIMMABLE-BOUNDARY-END(30064967700)
            
            //--TRIMMABLE-BOUNDARY-START(38654902292)
            static /*string */ get BarrierPostPhaseException()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184683790356);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The postPhaseAction failed with an exception.";
            }
            //--TRIMMABLE-BOUNDARY-END(38654902292)
            
            //--TRIMMABLE-BOUNDARY-START(8590131220)
            static /*string */ get Barrier_AddParticipants_Overflow_ArgumentOutOfRange()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554248212);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Adding participantCount participants would result in the number of participants exceeding the maximum number allowed.";
            }
            //--TRIMMABLE-BOUNDARY-END(8590131220)
            
            //--TRIMMABLE-BOUNDARY-START(515396272148)
            static /*string */ get SynchronizationLockException_IncorrectDispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(382252285972);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The lock is being disposed while still being used. It either is being held by a thread and/or has active waiters waiting to acquire the lock.";
            }
            //--TRIMMABLE-BOUNDARY-END(515396272148)
            
            //--TRIMMABLE-BOUNDARY-START(528281174036)
            static /*string */ get SynchronizationLockException_MisMatchedWrite()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(408022089748);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The write lock is being released without being held.";
            }
            //--TRIMMABLE-BOUNDARY-END(528281174036)
            
            //--TRIMMABLE-BOUNDARY-START(455266730004)
            static /*string */ get LockRecursionException_UpgradeAfterReadNotAllowed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(304942874644);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Upgradeable lock may not be acquired with read lock held.";
            }
            //--TRIMMABLE-BOUNDARY-END(455266730004)
            
            //--TRIMMABLE-BOUNDARY-START(459561697300)
            static /*string */ get LockRecursionException_UpgradeAfterWriteNotAllowed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(313532809236);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Upgradeable lock may not be acquired with write lock held in this mode. Acquiring Upgradeable lock gives the ability to read along with an option to upgrade to a writer.";
            }
            //--TRIMMABLE-BOUNDARY-END(459561697300)
            
            //--TRIMMABLE-BOUNDARY-START(523986206740)
            static /*string */ get SynchronizationLockException_MisMatchedUpgrade()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(399432155156);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The upgradeable lock is being released without being held.";
            }
            //--TRIMMABLE-BOUNDARY-END(523986206740)
            
            //--TRIMMABLE-BOUNDARY-START(519691239444)
            static /*string */ get SynchronizationLockException_MisMatchedRead()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(390842220564);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The read lock is being released without being held.";
            }
            //--TRIMMABLE-BOUNDARY-END(519691239444)
            
            //--TRIMMABLE-BOUNDARY-START(463856664596)
            static /*string */ get LockRecursionException_WriteAfterReadNotAllowed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(322122743828);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Write lock may not be acquired with read lock held. This pattern is prone to deadlocks. Please ensure that read locks are released before taking a write lock. If an upgrade is necessary, use an upgrade lock in place of the read lock.";
            }
            //--TRIMMABLE-BOUNDARY-END(463856664596)
            
            //--TRIMMABLE-BOUNDARY-START(450971762708)
            static /*string */ get LockRecursionException_RecursiveWriteNotAllowed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296352940052);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Recursive write lock acquisitions not allowed in this mode.";
            }
            //--TRIMMABLE-BOUNDARY-END(450971762708)
            
            //--TRIMMABLE-BOUNDARY-START(438086860820)
            static /*string */ get LockRecursionException_ReadAfterWriteNotAllowed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270583136276);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "A read lock may not be acquired with the write lock held in this mode.";
            }
            //--TRIMMABLE-BOUNDARY-END(438086860820)
            
            //--TRIMMABLE-BOUNDARY-START(446676795412)
            static /*string */ get LockRecursionException_RecursiveUpgradeNotAllowed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287763005460);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Recursive upgradeable lock acquisitions not allowed in this mode.";
            }
            //--TRIMMABLE-BOUNDARY-END(446676795412)
            
            //--TRIMMABLE-BOUNDARY-START(442381828116)
            static /*string */ get LockRecursionException_RecursiveReadNotAllowed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279173070868);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Recursive read lock acquisitions not allowed in this mode.";
            }
            //--TRIMMABLE-BOUNDARY-END(442381828116)
            
            //--TRIMMABLE-BOUNDARY-START(468151631892)
            static /*string */ get Overflow_UInt16()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(330712678420);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Value was either too large or too small for a UInt16.";
            }
            //--TRIMMABLE-BOUNDARY-END(468151631892)
            
            //--TRIMMABLE-BOUNDARY-START(485331501076)
            static /*string */ get ReaderWriterLock_Timeout()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(365072416788);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The operation has timed out. {0}";
            }
            //--TRIMMABLE-BOUNDARY-END(485331501076)
            
            //--TRIMMABLE-BOUNDARY-START(115964313620)
            static /*string */ FormatReaderWriterLock_Timeout(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964313620);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("The operation has timed out. {0}", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(115964313620)
            
            //--TRIMMABLE-BOUNDARY-START(476741566484)
            static /*string */ get ReaderWriterLock_NotOwner()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(347892547604);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Attempt to release a lock that is not owned by the calling thread. {0}";
            }
            //--TRIMMABLE-BOUNDARY-END(476741566484)
            
            //--TRIMMABLE-BOUNDARY-START(111669346324)
            static /*string */ FormatReaderWriterLock_NotOwner(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669346324);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Attempt to release a lock that is not owned by the calling thread. {0}", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(111669346324)
            
            //--TRIMMABLE-BOUNDARY-START(64424706068)
            static /*string */ get ExceptionFromHResult()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236223397908);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "(Exception from HRESULT: 0x{0:X})";
            }
            //--TRIMMABLE-BOUNDARY-END(64424706068)
            
            //--TRIMMABLE-BOUNDARY-START(103079411732)
            static /*string */ FormatExceptionFromHResult(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079411732);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("(Exception from HRESULT: 0x{0:X})", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(103079411732)
            
            //--TRIMMABLE-BOUNDARY-START(472446599188)
            static /*string */ get ReaderWriterLock_InvalidLockCookie()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(339302613012);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The specified lock cookie is invalid for this operation. {0}";
            }
            //--TRIMMABLE-BOUNDARY-END(472446599188)
            
            //--TRIMMABLE-BOUNDARY-START(107374379028)
            static /*string */ FormatReaderWriterLock_InvalidLockCookie(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374379028);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("The specified lock cookie is invalid for this operation. {0}", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(107374379028)
            
            //--TRIMMABLE-BOUNDARY-START(481036533780)
            static /*string */ get ReaderWriterLock_RestoreLockWithOwnedLocks()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(356482482196);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "ReaderWriterLock.RestoreLock was called without releasing all locks acquired since the call to ReleaseLock.";
            }
            //--TRIMMABLE-BOUNDARY-END(481036533780)
            
            //--TRIMMABLE-BOUNDARY-START(433791893524)
            static /*string */ get HostExecutionContextManager_InvalidOperation_NotNewCaptureContext()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261993201684);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot apply a context that has been marshaled across AppDomains, that was not acquired through a Capture operation or that has already been the argument to a Set call.";
            }
            //--TRIMMABLE-BOUNDARY-END(433791893524)
            
            //--TRIMMABLE-BOUNDARY-START(425201958932)
            static /*string */ get HostExecutionContextManager_InvalidOperation_CannotOverrideSetWithoutRevert()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244813332500);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Must override both HostExecutionContextManager.SetHostExecutionContext and HostExecutionContextManager.Revert.";
            }
            //--TRIMMABLE-BOUNDARY-END(425201958932)
            
            //--TRIMMABLE-BOUNDARY-START(429496926228)
            static /*string */ get HostExecutionContextManager_InvalidOperation_CannotUseSwitcherOtherThread()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253403267092);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Undo operation must be performed on the thread where the corresponding context was Set.";
            }
            //--TRIMMABLE-BOUNDARY-END(429496926228)
            
            //--TRIMMABLE-BOUNDARY-START(502511370260)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(502511370260)
            
            //--TRIMMABLE-BOUNDARY-START(420906991636)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(420906991636);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*bool*/ let usingResourceKeys;
                    return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(420906991636)
            
            //--TRIMMABLE-BOUNDARY-START(532576141332)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(532576141332);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$st.System.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(532576141332)
            
            //--TRIMMABLE-BOUNDARY-START(412317057044)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(412317057044);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$st.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$st.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(412317057044)
            
            //--TRIMMABLE-BOUNDARY-START(416612024340)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(416612024340);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$st.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(416612024340)
            
            //--TRIMMABLE-BOUNDARY-START(68719673364)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719673364);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$st.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(68719673364)
            
            //--TRIMMABLE-BOUNDARY-START(73014640660)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014640660);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$st.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(73014640660)
            
            //--TRIMMABLE-BOUNDARY-START(77309607956)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309607956);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$st.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(77309607956)
            
            //--TRIMMABLE-BOUNDARY-START(81604575252)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604575252);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$st.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(81604575252)
            
            //--TRIMMABLE-BOUNDARY-START(85899542548)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899542548);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$st.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(85899542548)
            
            //--TRIMMABLE-BOUNDARY-START(90194509844)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194509844);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$st.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(90194509844)
            
            //--TRIMMABLE-BOUNDARY-START(94489477140)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489477140);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$st.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(94489477140)
            
            //--TRIMMABLE-BOUNDARY-START(98784444436)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784444436);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$st.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(98784444436)
            
            //--TRIMMABLE-BOUNDARY-START(4295163924)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(502511370260)
                    this.s_usingResourceKeys = $.$st.System.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(502511370260)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295163924)
            
            static $h = 196628;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "h": 196628
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196628)
        
        
        //--TRIMMABLE-BOUNDARY-START(589844)
        $asm.$cls("$st.System.Threading.HostExecutionContextManager", ($self) => class HostExecutionContextManager extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(25770393620)
            /*HostExecutionContext?*/ static t_currentContext = null;
            //--TRIMMABLE-BOUNDARY-END(25770393620)
            
            //--TRIMMABLE-BOUNDARY-START(8590524436)
            /*HostExecutionContext? */ Capture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590524436);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(8590524436)
            
            //--TRIMMABLE-BOUNDARY-START(21475426324)
            /*object */ SetHostExecutionContext(/*HostExecutionContext*/ hostExecutionContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475426324);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (hostExecutionContext === null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$st.System.SR.HostExecutionContextManager_InvalidOperation_NotNewCaptureContext);
                }
                /*var*/ let switcher = new $.$st.System.Threading.HostExecutionContextManager.HostExecutionContextSwitcher().$ctor$1(hostExecutionContext);
                $.$st.System.Threading.HostExecutionContextManager.t_currentContext = hostExecutionContext;
                return switcher;
            }
            //--TRIMMABLE-BOUNDARY-END(21475426324)
            
            //--TRIMMABLE-BOUNDARY-START(17180459028)
            /*void */ Revert(/*object*/ previousState)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180459028);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let switcher = $.$as(previousState, $.$st.System.Threading.HostExecutionContextManager.HostExecutionContextSwitcher);
                if (switcher === null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$st.System.SR.HostExecutionContextManager_InvalidOperation_CannotOverrideSetWithoutRevert);
                }
                if ($.$st.System.Threading.HostExecutionContextManager.t_currentContext !== switcher._currentContext || switcher._asyncLocal === null || !switcher._asyncLocal.Value)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$st.System.SR.HostExecutionContextManager_InvalidOperation_CannotUseSwitcherOtherThread);
                }
                switcher._asyncLocal = null;
                $.$st.System.Threading.HostExecutionContextManager.t_currentContext = null;
            }
            //--TRIMMABLE-BOUNDARY-END(17180459028)
            
            //--TRIMMABLE-BOUNDARY-START(655380)
            static $_HostExecutionContextSwitcher;
            static get HostExecutionContextSwitcher()
            {
                let $cls = $.$st.System.Threading.HostExecutionContextManager;
                return $cls.$_HostExecutionContextSwitcher ??= $asm.$ncls("$st.System.Threading.HostExecutionContextManager.HostExecutionContextSwitcher", ($self) => class HostExecutionContextSwitcher extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(8590589972)
                    /*HostExecutionContext*/ _currentContext = null;
                    //--TRIMMABLE-BOUNDARY-END(8590589972)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295622676)
                    /*AsyncLocal<bool>?*/ _asyncLocal = null;
                    //--TRIMMABLE-BOUNDARY-END(4295622676)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885557268)
                    $ctor$1(/*HostExecutionContext*/ currentContext)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(12885557268);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._currentContext = currentContext;
                            this._asyncLocal = new ($.$$.System.Threading.AsyncLocal$$($.$$.System.Boolean))().$ctor$1();
                            this._asyncLocal.Value = true;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885557268)
                    
                    static $h = 655380;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590589972),
    {
      "t": 524308,
      "n": "_currentContext",
      "d": 655380,
      "h": 8590589972,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(8590589972),
//--TRIMMABLE-BOUNDARY-START(4295622676),
    {
      "t": $.$$.System.Threading.AsyncLocal$$($.$$.System.Boolean).$h,
      "n": "_asyncLocal",
      "d": 655380,
      "h": 4295622676,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(4295622676)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885557268),
    {
      "p": [
        {
          "n": "currentContext",
          "p": 524308
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 655380,
      "h": 12885557268,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885557268)
  ],
  "d": 589844,
  "h": 655380
}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Threading.HostExecutionContextManager.HostExecutionContextSwitcher`; }
                }, $cls, ($v) => $cls.$_HostExecutionContextSwitcher = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(655380)
            
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 589844;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590524436),
    {
      "r": 524308,
      "n": "Capture",
      "d": 589844,
      "h": 8590524436,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8590524436),
//--TRIMMABLE-BOUNDARY-START(21475426324),
    {
      "r": 131073,
      "p": [
        {
          "n": "hostExecutionContext",
          "p": 524308
        }
      ],
      "n": "SetHostExecutionContext",
      "d": 589844,
      "h": 21475426324,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(21475426324),
//--TRIMMABLE-BOUNDARY-START(17180459028),
    {
      "r": 65537,
      "p": [
        {
          "n": "previousState",
          "p": 131073
        }
      ],
      "n": "Revert",
      "d": 589844,
      "h": 17180459028,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17180459028)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(25770393620),
    {
      "t": 524308,
      "n": "t_currentContext",
      "d": 589844,
      "h": 25770393620,
      "f": 4194338,
      "a": [
        {
          "t": 185204737,
          "c": 4480172033
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25770393620)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295557140),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 589844,
      "h": 4295557140,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295557140)
  ],
  "j": [655380
  ],
  "h": 589844
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Threading.HostExecutionContextManager`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589844)
        
        
        //--TRIMMABLE-BOUNDARY-START(65556)
        $asm.$cls("$st.System.HResults", ($self) => class HResults
        {
            //--TRIMMABLE-BOUNDARY-START(498216271892)
            /*int*/ static S_OK = 0;
            //--TRIMMABLE-BOUNDARY-END(498216271892)
            
            //--TRIMMABLE-BOUNDARY-START(493921304596)
            /*int*/ static S_FALSE = 1;
            //--TRIMMABLE-BOUNDARY-END(493921304596)
            
            //--TRIMMABLE-BOUNDARY-START(8590000148)
            /*int*/ static COR_E_ABANDONEDMUTEX = -2146233043;
            //--TRIMMABLE-BOUNDARY-END(8590000148)
            
            //--TRIMMABLE-BOUNDARY-START(12884967444)
            /*int*/ static COR_E_AMBIGUOUSIMPLEMENTATION = -2146234262;
            //--TRIMMABLE-BOUNDARY-END(12884967444)
            
            //--TRIMMABLE-BOUNDARY-START(17179934740)
            /*int*/ static COR_E_AMBIGUOUSMATCH = -2147475171;
            //--TRIMMABLE-BOUNDARY-END(17179934740)
            
            //--TRIMMABLE-BOUNDARY-START(21474902036)
            /*int*/ static COR_E_APPDOMAINUNLOADED = -2146234348;
            //--TRIMMABLE-BOUNDARY-END(21474902036)
            
            //--TRIMMABLE-BOUNDARY-START(25769869332)
            /*int*/ static COR_E_APPLICATION = -2146232832;
            //--TRIMMABLE-BOUNDARY-END(25769869332)
            
            //--TRIMMABLE-BOUNDARY-START(30064836628)
            /*int*/ static COR_E_ARGUMENT = -2147024809;
            //--TRIMMABLE-BOUNDARY-END(30064836628)
            
            //--TRIMMABLE-BOUNDARY-START(34359803924)
            /*int*/ static COR_E_ARGUMENTOUTOFRANGE = -2146233086;
            //--TRIMMABLE-BOUNDARY-END(34359803924)
            
            //--TRIMMABLE-BOUNDARY-START(38654771220)
            /*int*/ static COR_E_ARITHMETIC = -2147024362;
            //--TRIMMABLE-BOUNDARY-END(38654771220)
            
            //--TRIMMABLE-BOUNDARY-START(42949738516)
            /*int*/ static COR_E_ARRAYTYPEMISMATCH = -2146233085;
            //--TRIMMABLE-BOUNDARY-END(42949738516)
            
            //--TRIMMABLE-BOUNDARY-START(47244705812)
            /*int*/ static COR_E_BADEXEFORMAT = -2147024703;
            //--TRIMMABLE-BOUNDARY-END(47244705812)
            
            //--TRIMMABLE-BOUNDARY-START(51539673108)
            /*int*/ static COR_E_BADIMAGEFORMAT = -2147024885;
            //--TRIMMABLE-BOUNDARY-END(51539673108)
            
            //--TRIMMABLE-BOUNDARY-START(55834640404)
            /*int*/ static COR_E_CANNOTUNLOADAPPDOMAIN = -2146234347;
            //--TRIMMABLE-BOUNDARY-END(55834640404)
            
            //--TRIMMABLE-BOUNDARY-START(60129607700)
            /*int*/ static COR_E_CODECONTRACTFAILED = -2146233022;
            //--TRIMMABLE-BOUNDARY-END(60129607700)
            
            //--TRIMMABLE-BOUNDARY-START(64424574996)
            /*int*/ static COR_E_CONTEXTMARSHAL = -2146233084;
            //--TRIMMABLE-BOUNDARY-END(64424574996)
            
            //--TRIMMABLE-BOUNDARY-START(68719542292)
            /*int*/ static COR_E_CUSTOMATTRIBUTEFORMAT = -2146232827;
            //--TRIMMABLE-BOUNDARY-END(68719542292)
            
            //--TRIMMABLE-BOUNDARY-START(73014509588)
            /*int*/ static COR_E_DATAMISALIGNED = -2146233023;
            //--TRIMMABLE-BOUNDARY-END(73014509588)
            
            //--TRIMMABLE-BOUNDARY-START(77309476884)
            /*int*/ static COR_E_DIRECTORYNOTFOUND = -2147024893;
            //--TRIMMABLE-BOUNDARY-END(77309476884)
            
            //--TRIMMABLE-BOUNDARY-START(81604444180)
            /*int*/ static COR_E_DIVIDEBYZERO = -2147352558;
            //--TRIMMABLE-BOUNDARY-END(81604444180)
            
            //--TRIMMABLE-BOUNDARY-START(85899411476)
            /*int*/ static COR_E_DLLNOTFOUND = -2146233052;
            //--TRIMMABLE-BOUNDARY-END(85899411476)
            
            //--TRIMMABLE-BOUNDARY-START(90194378772)
            /*int*/ static COR_E_DUPLICATEWAITOBJECT = -2146233047;
            //--TRIMMABLE-BOUNDARY-END(90194378772)
            
            //--TRIMMABLE-BOUNDARY-START(94489346068)
            /*int*/ static COR_E_ENDOFSTREAM = -2147024858;
            //--TRIMMABLE-BOUNDARY-END(94489346068)
            
            //--TRIMMABLE-BOUNDARY-START(98784313364)
            /*int*/ static COR_E_ENTRYPOINTNOTFOUND = -2146233053;
            //--TRIMMABLE-BOUNDARY-END(98784313364)
            
            //--TRIMMABLE-BOUNDARY-START(103079280660)
            /*int*/ static COR_E_EXCEPTION = -2146233088;
            //--TRIMMABLE-BOUNDARY-END(103079280660)
            
            //--TRIMMABLE-BOUNDARY-START(107374247956)
            /*int*/ static COR_E_EXECUTIONENGINE = -2146233082;
            //--TRIMMABLE-BOUNDARY-END(107374247956)
            
            //--TRIMMABLE-BOUNDARY-START(111669215252)
            /*int*/ static COR_E_FAILFAST = -2146232797;
            //--TRIMMABLE-BOUNDARY-END(111669215252)
            
            //--TRIMMABLE-BOUNDARY-START(115964182548)
            /*int*/ static COR_E_FIELDACCESS = -2146233081;
            //--TRIMMABLE-BOUNDARY-END(115964182548)
            
            //--TRIMMABLE-BOUNDARY-START(120259149844)
            /*int*/ static COR_E_FILELOAD = -2146232799;
            //--TRIMMABLE-BOUNDARY-END(120259149844)
            
            //--TRIMMABLE-BOUNDARY-START(124554117140)
            /*int*/ static COR_E_FILENOTFOUND = -2147024894;
            //--TRIMMABLE-BOUNDARY-END(124554117140)
            
            //--TRIMMABLE-BOUNDARY-START(128849084436)
            /*int*/ static COR_E_FORMAT = -2146233033;
            //--TRIMMABLE-BOUNDARY-END(128849084436)
            
            //--TRIMMABLE-BOUNDARY-START(133144051732)
            /*int*/ static COR_E_INDEXOUTOFRANGE = -2146233080;
            //--TRIMMABLE-BOUNDARY-END(133144051732)
            
            //--TRIMMABLE-BOUNDARY-START(137439019028)
            /*int*/ static COR_E_INSUFFICIENTEXECUTIONSTACK = -2146232968;
            //--TRIMMABLE-BOUNDARY-END(137439019028)
            
            //--TRIMMABLE-BOUNDARY-START(141733986324)
            /*int*/ static COR_E_INSUFFICIENTMEMORY = -2146233027;
            //--TRIMMABLE-BOUNDARY-END(141733986324)
            
            //--TRIMMABLE-BOUNDARY-START(146028953620)
            /*int*/ static COR_E_INVALIDCAST = -2147467262;
            //--TRIMMABLE-BOUNDARY-END(146028953620)
            
            //--TRIMMABLE-BOUNDARY-START(150323920916)
            /*int*/ static COR_E_INVALIDCOMOBJECT = -2146233049;
            //--TRIMMABLE-BOUNDARY-END(150323920916)
            
            //--TRIMMABLE-BOUNDARY-START(154618888212)
            /*int*/ static COR_E_INVALIDFILTERCRITERIA = -2146232831;
            //--TRIMMABLE-BOUNDARY-END(154618888212)
            
            //--TRIMMABLE-BOUNDARY-START(158913855508)
            /*int*/ static COR_E_INVALIDOLEVARIANTTYPE = -2146233039;
            //--TRIMMABLE-BOUNDARY-END(158913855508)
            
            //--TRIMMABLE-BOUNDARY-START(163208822804)
            /*int*/ static COR_E_INVALIDOPERATION = -2146233079;
            //--TRIMMABLE-BOUNDARY-END(163208822804)
            
            //--TRIMMABLE-BOUNDARY-START(167503790100)
            /*int*/ static COR_E_INVALIDPROGRAM = -2146233030;
            //--TRIMMABLE-BOUNDARY-END(167503790100)
            
            //--TRIMMABLE-BOUNDARY-START(171798757396)
            /*int*/ static COR_E_IO = -2146232800;
            //--TRIMMABLE-BOUNDARY-END(171798757396)
            
            //--TRIMMABLE-BOUNDARY-START(176093724692)
            /*int*/ static COR_E_KEYNOTFOUND = -2146232969;
            //--TRIMMABLE-BOUNDARY-END(176093724692)
            
            //--TRIMMABLE-BOUNDARY-START(180388691988)
            /*int*/ static COR_E_MARSHALDIRECTIVE = -2146233035;
            //--TRIMMABLE-BOUNDARY-END(180388691988)
            
            //--TRIMMABLE-BOUNDARY-START(184683659284)
            /*int*/ static COR_E_MEMBERACCESS = -2146233062;
            //--TRIMMABLE-BOUNDARY-END(184683659284)
            
            //--TRIMMABLE-BOUNDARY-START(188978626580)
            /*int*/ static COR_E_METHODACCESS = -2146233072;
            //--TRIMMABLE-BOUNDARY-END(188978626580)
            
            //--TRIMMABLE-BOUNDARY-START(193273593876)
            /*int*/ static COR_E_MISSINGFIELD = -2146233071;
            //--TRIMMABLE-BOUNDARY-END(193273593876)
            
            //--TRIMMABLE-BOUNDARY-START(197568561172)
            /*int*/ static COR_E_MISSINGMANIFESTRESOURCE = -2146233038;
            //--TRIMMABLE-BOUNDARY-END(197568561172)
            
            //--TRIMMABLE-BOUNDARY-START(201863528468)
            /*int*/ static COR_E_MISSINGMEMBER = -2146233070;
            //--TRIMMABLE-BOUNDARY-END(201863528468)
            
            //--TRIMMABLE-BOUNDARY-START(206158495764)
            /*int*/ static COR_E_MISSINGMETHOD = -2146233069;
            //--TRIMMABLE-BOUNDARY-END(206158495764)
            
            //--TRIMMABLE-BOUNDARY-START(210453463060)
            /*int*/ static COR_E_MISSINGSATELLITEASSEMBLY = -2146233034;
            //--TRIMMABLE-BOUNDARY-END(210453463060)
            
            //--TRIMMABLE-BOUNDARY-START(214748430356)
            /*int*/ static COR_E_MULTICASTNOTSUPPORTED = -2146233068;
            //--TRIMMABLE-BOUNDARY-END(214748430356)
            
            //--TRIMMABLE-BOUNDARY-START(219043397652)
            /*int*/ static COR_E_NOTFINITENUMBER = -2146233048;
            //--TRIMMABLE-BOUNDARY-END(219043397652)
            
            //--TRIMMABLE-BOUNDARY-START(223338364948)
            /*int*/ static COR_E_NOTSUPPORTED = -2146233067;
            //--TRIMMABLE-BOUNDARY-END(223338364948)
            
            //--TRIMMABLE-BOUNDARY-START(227633332244)
            /*int*/ static COR_E_OBJECTDISPOSED = -2146232798;
            //--TRIMMABLE-BOUNDARY-END(227633332244)
            
            //--TRIMMABLE-BOUNDARY-START(231928299540)
            /*int*/ static COR_E_OPERATIONCANCELED = -2146233029;
            //--TRIMMABLE-BOUNDARY-END(231928299540)
            
            //--TRIMMABLE-BOUNDARY-START(236223266836)
            /*int*/ static COR_E_OUTOFMEMORY = -2147024882;
            //--TRIMMABLE-BOUNDARY-END(236223266836)
            
            //--TRIMMABLE-BOUNDARY-START(240518234132)
            /*int*/ static COR_E_OVERFLOW = -2146233066;
            //--TRIMMABLE-BOUNDARY-END(240518234132)
            
            //--TRIMMABLE-BOUNDARY-START(244813201428)
            /*int*/ static COR_E_PATHTOOLONG = -2147024690;
            //--TRIMMABLE-BOUNDARY-END(244813201428)
            
            //--TRIMMABLE-BOUNDARY-START(249108168724)
            /*int*/ static COR_E_PLATFORMNOTSUPPORTED = -2146233031;
            //--TRIMMABLE-BOUNDARY-END(249108168724)
            
            //--TRIMMABLE-BOUNDARY-START(253403136020)
            /*int*/ static COR_E_RANK = -2146233065;
            //--TRIMMABLE-BOUNDARY-END(253403136020)
            
            //--TRIMMABLE-BOUNDARY-START(257698103316)
            /*int*/ static COR_E_REFLECTIONTYPELOAD = -2146232830;
            //--TRIMMABLE-BOUNDARY-END(257698103316)
            
            //--TRIMMABLE-BOUNDARY-START(261993070612)
            /*int*/ static COR_E_RUNTIMEWRAPPED = -2146233026;
            //--TRIMMABLE-BOUNDARY-END(261993070612)
            
            //--TRIMMABLE-BOUNDARY-START(266288037908)
            /*int*/ static COR_E_SAFEARRAYRANKMISMATCH = -2146233032;
            //--TRIMMABLE-BOUNDARY-END(266288037908)
            
            //--TRIMMABLE-BOUNDARY-START(270583005204)
            /*int*/ static COR_E_SAFEARRAYTYPEMISMATCH = -2146233037;
            //--TRIMMABLE-BOUNDARY-END(270583005204)
            
            //--TRIMMABLE-BOUNDARY-START(274877972500)
            /*int*/ static COR_E_SECURITY = -2146233078;
            //--TRIMMABLE-BOUNDARY-END(274877972500)
            
            //--TRIMMABLE-BOUNDARY-START(279172939796)
            /*int*/ static COR_E_SERIALIZATION = -2146233076;
            //--TRIMMABLE-BOUNDARY-END(279172939796)
            
            //--TRIMMABLE-BOUNDARY-START(283467907092)
            /*int*/ static COR_E_STACKOVERFLOW = -2147023895;
            //--TRIMMABLE-BOUNDARY-END(283467907092)
            
            //--TRIMMABLE-BOUNDARY-START(287762874388)
            /*int*/ static COR_E_SYNCHRONIZATIONLOCK = -2146233064;
            //--TRIMMABLE-BOUNDARY-END(287762874388)
            
            //--TRIMMABLE-BOUNDARY-START(292057841684)
            /*int*/ static COR_E_SYSTEM = -2146233087;
            //--TRIMMABLE-BOUNDARY-END(292057841684)
            
            //--TRIMMABLE-BOUNDARY-START(296352808980)
            /*int*/ static COR_E_TARGET = -2146232829;
            //--TRIMMABLE-BOUNDARY-END(296352808980)
            
            //--TRIMMABLE-BOUNDARY-START(300647776276)
            /*int*/ static COR_E_TARGETINVOCATION = -2146232828;
            //--TRIMMABLE-BOUNDARY-END(300647776276)
            
            //--TRIMMABLE-BOUNDARY-START(304942743572)
            /*int*/ static COR_E_TARGETPARAMCOUNT = -2147352562;
            //--TRIMMABLE-BOUNDARY-END(304942743572)
            
            //--TRIMMABLE-BOUNDARY-START(309237710868)
            /*int*/ static COR_E_THREADABORTED = -2146233040;
            //--TRIMMABLE-BOUNDARY-END(309237710868)
            
            //--TRIMMABLE-BOUNDARY-START(313532678164)
            /*int*/ static COR_E_THREADINTERRUPTED = -2146233063;
            //--TRIMMABLE-BOUNDARY-END(313532678164)
            
            //--TRIMMABLE-BOUNDARY-START(317827645460)
            /*int*/ static COR_E_THREADSTART = -2146233051;
            //--TRIMMABLE-BOUNDARY-END(317827645460)
            
            //--TRIMMABLE-BOUNDARY-START(322122612756)
            /*int*/ static COR_E_THREADSTATE = -2146233056;
            //--TRIMMABLE-BOUNDARY-END(322122612756)
            
            //--TRIMMABLE-BOUNDARY-START(326417580052)
            /*int*/ static COR_E_TIMEOUT = -2146233083;
            //--TRIMMABLE-BOUNDARY-END(326417580052)
            
            //--TRIMMABLE-BOUNDARY-START(330712547348)
            /*int*/ static COR_E_TYPEACCESS = -2146233021;
            //--TRIMMABLE-BOUNDARY-END(330712547348)
            
            //--TRIMMABLE-BOUNDARY-START(335007514644)
            /*int*/ static COR_E_TYPEINITIALIZATION = -2146233036;
            //--TRIMMABLE-BOUNDARY-END(335007514644)
            
            //--TRIMMABLE-BOUNDARY-START(339302481940)
            /*int*/ static COR_E_TYPELOAD = -2146233054;
            //--TRIMMABLE-BOUNDARY-END(339302481940)
            
            //--TRIMMABLE-BOUNDARY-START(343597449236)
            /*int*/ static COR_E_TYPEUNLOADED = -2146234349;
            //--TRIMMABLE-BOUNDARY-END(343597449236)
            
            //--TRIMMABLE-BOUNDARY-START(347892416532)
            /*int*/ static COR_E_UNAUTHORIZEDACCESS = -2147024891;
            //--TRIMMABLE-BOUNDARY-END(347892416532)
            
            //--TRIMMABLE-BOUNDARY-START(352187383828)
            /*int*/ static COR_E_VERIFICATION = -2146233075;
            //--TRIMMABLE-BOUNDARY-END(352187383828)
            
            //--TRIMMABLE-BOUNDARY-START(356482351124)
            /*int*/ static COR_E_WAITHANDLECANNOTBEOPENED = -2146233044;
            //--TRIMMABLE-BOUNDARY-END(356482351124)
            
            //--TRIMMABLE-BOUNDARY-START(4295032852)
            /*int*/ static CO_E_NOTINITIALIZED = -2147221008;
            //--TRIMMABLE-BOUNDARY-END(4295032852)
            
            //--TRIMMABLE-BOUNDARY-START(382252154900)
            /*int*/ static DISP_E_PARAMNOTFOUND = -2147352572;
            //--TRIMMABLE-BOUNDARY-END(382252154900)
            
            //--TRIMMABLE-BOUNDARY-START(386547122196)
            /*int*/ static DISP_E_TYPEMISMATCH = -2147352571;
            //--TRIMMABLE-BOUNDARY-END(386547122196)
            
            //--TRIMMABLE-BOUNDARY-START(369367253012)
            /*int*/ static DISP_E_BADVARTYPE = -2147352568;
            //--TRIMMABLE-BOUNDARY-END(369367253012)
            
            //--TRIMMABLE-BOUNDARY-START(377957187604)
            /*int*/ static DISP_E_OVERFLOW = -2147352566;
            //--TRIMMABLE-BOUNDARY-END(377957187604)
            
            //--TRIMMABLE-BOUNDARY-START(373662220308)
            /*int*/ static DISP_E_DIVBYZERO = -2147352558;
            //--TRIMMABLE-BOUNDARY-END(373662220308)
            
            //--TRIMMABLE-BOUNDARY-START(390842089492)
            /*int*/ static E_BOUNDS = -2147483637;
            //--TRIMMABLE-BOUNDARY-END(390842089492)
            
            //--TRIMMABLE-BOUNDARY-START(395137056788)
            /*int*/ static E_CHANGED_STATE = -2147483636;
            //--TRIMMABLE-BOUNDARY-END(395137056788)
            
            //--TRIMMABLE-BOUNDARY-START(403726991380)
            /*int*/ static E_FILENOTFOUND = -2147024894;
            //--TRIMMABLE-BOUNDARY-END(403726991380)
            
            //--TRIMMABLE-BOUNDARY-START(399432024084)
            /*int*/ static E_FAIL = -2147467259;
            //--TRIMMABLE-BOUNDARY-END(399432024084)
            
            //--TRIMMABLE-BOUNDARY-START(408021958676)
            /*int*/ static E_HANDLE = -2147024890;
            //--TRIMMABLE-BOUNDARY-END(408021958676)
            
            //--TRIMMABLE-BOUNDARY-START(412316925972)
            /*int*/ static E_INVALIDARG = -2147024809;
            //--TRIMMABLE-BOUNDARY-END(412316925972)
            
            //--TRIMMABLE-BOUNDARY-START(416611893268)
            /*int*/ static E_NOTIMPL = -2147467263;
            //--TRIMMABLE-BOUNDARY-END(416611893268)
            
            //--TRIMMABLE-BOUNDARY-START(420906860564)
            /*int*/ static E_OUTOFMEMORY = -2147024882;
            //--TRIMMABLE-BOUNDARY-END(420906860564)
            
            //--TRIMMABLE-BOUNDARY-START(425201827860)
            /*int*/ static E_POINTER = -2147467261;
            //--TRIMMABLE-BOUNDARY-END(425201827860)
            
            //--TRIMMABLE-BOUNDARY-START(446676664340)
            /*int*/ static ERROR_MRM_MAP_NOT_FOUND = -2147009761;
            //--TRIMMABLE-BOUNDARY-END(446676664340)
            
            //--TRIMMABLE-BOUNDARY-START(459561566228)
            /*int*/ static ERROR_TIMEOUT = -2147023436;
            //--TRIMMABLE-BOUNDARY-END(459561566228)
            
            //--TRIMMABLE-BOUNDARY-START(485331370004)
            /*int*/ static RO_E_CLOSED = -2147483629;
            //--TRIMMABLE-BOUNDARY-END(485331370004)
            
            //--TRIMMABLE-BOUNDARY-START(489626337300)
            /*int*/ static RPC_E_CHANGED_MODE = -2147417850;
            //--TRIMMABLE-BOUNDARY-END(489626337300)
            
            //--TRIMMABLE-BOUNDARY-START(506806206484)
            /*int*/ static TYPE_E_TYPEMISMATCH = -2147316576;
            //--TRIMMABLE-BOUNDARY-END(506806206484)
            
            //--TRIMMABLE-BOUNDARY-START(502511239188)
            /*int*/ static STG_E_PATHNOTFOUND = -2147287037;
            //--TRIMMABLE-BOUNDARY-END(502511239188)
            
            //--TRIMMABLE-BOUNDARY-START(365072285716)
            /*int*/ static CTL_E_PATHNOTFOUND = -2146828212;
            //--TRIMMABLE-BOUNDARY-END(365072285716)
            
            //--TRIMMABLE-BOUNDARY-START(360777318420)
            /*int*/ static CTL_E_FILENOTFOUND = -2146828235;
            //--TRIMMABLE-BOUNDARY-END(360777318420)
            
            //--TRIMMABLE-BOUNDARY-START(472446468116)
            /*int*/ static FUSION_E_INVALID_NAME = -2146234297;
            //--TRIMMABLE-BOUNDARY-END(472446468116)
            
            //--TRIMMABLE-BOUNDARY-START(476741435412)
            /*int*/ static FUSION_E_REF_DEF_MISMATCH = -2146234304;
            //--TRIMMABLE-BOUNDARY-END(476741435412)
            
            //--TRIMMABLE-BOUNDARY-START(463856533524)
            /*int*/ static ERROR_TOO_MANY_OPEN_FILES = -2147024892;
            //--TRIMMABLE-BOUNDARY-END(463856533524)
            
            //--TRIMMABLE-BOUNDARY-START(455266598932)
            /*int*/ static ERROR_SHARING_VIOLATION = -2147024864;
            //--TRIMMABLE-BOUNDARY-END(455266598932)
            
            //--TRIMMABLE-BOUNDARY-START(442381697044)
            /*int*/ static ERROR_LOCK_VIOLATION = -2147024863;
            //--TRIMMABLE-BOUNDARY-END(442381697044)
            
            //--TRIMMABLE-BOUNDARY-START(450971631636)
            /*int*/ static ERROR_OPEN_FAILED = -2147024786;
            //--TRIMMABLE-BOUNDARY-END(450971631636)
            
            //--TRIMMABLE-BOUNDARY-START(429496795156)
            /*int*/ static ERROR_DISK_CORRUPT = -2147023503;
            //--TRIMMABLE-BOUNDARY-END(429496795156)
            
            //--TRIMMABLE-BOUNDARY-START(468151500820)
            /*int*/ static ERROR_UNRECOGNIZED_VOLUME = -2147023891;
            //--TRIMMABLE-BOUNDARY-END(468151500820)
            
            //--TRIMMABLE-BOUNDARY-START(433791762452)
            /*int*/ static ERROR_DLL_INIT_FAILED = -2147023782;
            //--TRIMMABLE-BOUNDARY-END(433791762452)
            
            //--TRIMMABLE-BOUNDARY-START(481036402708)
            /*int*/ static MSEE_E_ASSEMBLYLOADINPROGRESS = -2146234346;
            //--TRIMMABLE-BOUNDARY-END(481036402708)
            
            //--TRIMMABLE-BOUNDARY-START(438086729748)
            /*int*/ static ERROR_FILE_INVALID = -2147023890;
            //--TRIMMABLE-BOUNDARY-END(438086729748)
            
            static $h = 65556;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(498216271892),
    {
      "t": 655361,
      "n": "S_OK",
      "d": 65556,
      "h": 498216271892,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(498216271892),
//--TRIMMABLE-BOUNDARY-START(493921304596),
    {
      "t": 655361,
      "n": "S_FALSE",
      "d": 65556,
      "h": 493921304596,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(493921304596),
//--TRIMMABLE-BOUNDARY-START(8590000148),
    {
      "t": 655361,
      "n": "COR_E_ABANDONEDMUTEX",
      "d": 65556,
      "h": 8590000148,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(8590000148),
//--TRIMMABLE-BOUNDARY-START(12884967444),
    {
      "t": 655361,
      "n": "COR_E_AMBIGUOUSIMPLEMENTATION",
      "d": 65556,
      "h": 12884967444,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(12884967444),
//--TRIMMABLE-BOUNDARY-START(17179934740),
    {
      "t": 655361,
      "n": "COR_E_AMBIGUOUSMATCH",
      "d": 65556,
      "h": 17179934740,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(17179934740),
//--TRIMMABLE-BOUNDARY-START(21474902036),
    {
      "t": 655361,
      "n": "COR_E_APPDOMAINUNLOADED",
      "d": 65556,
      "h": 21474902036,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(21474902036),
//--TRIMMABLE-BOUNDARY-START(25769869332),
    {
      "t": 655361,
      "n": "COR_E_APPLICATION",
      "d": 65556,
      "h": 25769869332,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(25769869332),
//--TRIMMABLE-BOUNDARY-START(30064836628),
    {
      "t": 655361,
      "n": "COR_E_ARGUMENT",
      "d": 65556,
      "h": 30064836628,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(30064836628),
//--TRIMMABLE-BOUNDARY-START(34359803924),
    {
      "t": 655361,
      "n": "COR_E_ARGUMENTOUTOFRANGE",
      "d": 65556,
      "h": 34359803924,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(34359803924),
//--TRIMMABLE-BOUNDARY-START(38654771220),
    {
      "t": 655361,
      "n": "COR_E_ARITHMETIC",
      "d": 65556,
      "h": 38654771220,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(38654771220),
//--TRIMMABLE-BOUNDARY-START(42949738516),
    {
      "t": 655361,
      "n": "COR_E_ARRAYTYPEMISMATCH",
      "d": 65556,
      "h": 42949738516,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(42949738516),
//--TRIMMABLE-BOUNDARY-START(47244705812),
    {
      "t": 655361,
      "n": "COR_E_BADEXEFORMAT",
      "d": 65556,
      "h": 47244705812,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(47244705812),
//--TRIMMABLE-BOUNDARY-START(51539673108),
    {
      "t": 655361,
      "n": "COR_E_BADIMAGEFORMAT",
      "d": 65556,
      "h": 51539673108,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(51539673108),
//--TRIMMABLE-BOUNDARY-START(55834640404),
    {
      "t": 655361,
      "n": "COR_E_CANNOTUNLOADAPPDOMAIN",
      "d": 65556,
      "h": 55834640404,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(55834640404),
//--TRIMMABLE-BOUNDARY-START(60129607700),
    {
      "t": 655361,
      "n": "COR_E_CODECONTRACTFAILED",
      "d": 65556,
      "h": 60129607700,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(60129607700),
//--TRIMMABLE-BOUNDARY-START(64424574996),
    {
      "t": 655361,
      "n": "COR_E_CONTEXTMARSHAL",
      "d": 65556,
      "h": 64424574996,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(64424574996),
//--TRIMMABLE-BOUNDARY-START(68719542292),
    {
      "t": 655361,
      "n": "COR_E_CUSTOMATTRIBUTEFORMAT",
      "d": 65556,
      "h": 68719542292,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(68719542292),
//--TRIMMABLE-BOUNDARY-START(73014509588),
    {
      "t": 655361,
      "n": "COR_E_DATAMISALIGNED",
      "d": 65556,
      "h": 73014509588,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(73014509588),
//--TRIMMABLE-BOUNDARY-START(77309476884),
    {
      "t": 655361,
      "n": "COR_E_DIRECTORYNOTFOUND",
      "d": 65556,
      "h": 77309476884,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(77309476884),
//--TRIMMABLE-BOUNDARY-START(81604444180),
    {
      "t": 655361,
      "n": "COR_E_DIVIDEBYZERO",
      "d": 65556,
      "h": 81604444180,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(81604444180),
//--TRIMMABLE-BOUNDARY-START(85899411476),
    {
      "t": 655361,
      "n": "COR_E_DLLNOTFOUND",
      "d": 65556,
      "h": 85899411476,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(85899411476),
//--TRIMMABLE-BOUNDARY-START(90194378772),
    {
      "t": 655361,
      "n": "COR_E_DUPLICATEWAITOBJECT",
      "d": 65556,
      "h": 90194378772,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(90194378772),
//--TRIMMABLE-BOUNDARY-START(94489346068),
    {
      "t": 655361,
      "n": "COR_E_ENDOFSTREAM",
      "d": 65556,
      "h": 94489346068,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(94489346068),
//--TRIMMABLE-BOUNDARY-START(98784313364),
    {
      "t": 655361,
      "n": "COR_E_ENTRYPOINTNOTFOUND",
      "d": 65556,
      "h": 98784313364,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(98784313364),
//--TRIMMABLE-BOUNDARY-START(103079280660),
    {
      "t": 655361,
      "n": "COR_E_EXCEPTION",
      "d": 65556,
      "h": 103079280660,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(103079280660),
//--TRIMMABLE-BOUNDARY-START(107374247956),
    {
      "t": 655361,
      "n": "COR_E_EXECUTIONENGINE",
      "d": 65556,
      "h": 107374247956,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(107374247956),
//--TRIMMABLE-BOUNDARY-START(111669215252),
    {
      "t": 655361,
      "n": "COR_E_FAILFAST",
      "d": 65556,
      "h": 111669215252,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(111669215252),
//--TRIMMABLE-BOUNDARY-START(115964182548),
    {
      "t": 655361,
      "n": "COR_E_FIELDACCESS",
      "d": 65556,
      "h": 115964182548,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(115964182548),
//--TRIMMABLE-BOUNDARY-START(120259149844),
    {
      "t": 655361,
      "n": "COR_E_FILELOAD",
      "d": 65556,
      "h": 120259149844,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(120259149844),
//--TRIMMABLE-BOUNDARY-START(124554117140),
    {
      "t": 655361,
      "n": "COR_E_FILENOTFOUND",
      "d": 65556,
      "h": 124554117140,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(124554117140),
//--TRIMMABLE-BOUNDARY-START(128849084436),
    {
      "t": 655361,
      "n": "COR_E_FORMAT",
      "d": 65556,
      "h": 128849084436,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(128849084436),
//--TRIMMABLE-BOUNDARY-START(133144051732),
    {
      "t": 655361,
      "n": "COR_E_INDEXOUTOFRANGE",
      "d": 65556,
      "h": 133144051732,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(133144051732),
//--TRIMMABLE-BOUNDARY-START(137439019028),
    {
      "t": 655361,
      "n": "COR_E_INSUFFICIENTEXECUTIONSTACK",
      "d": 65556,
      "h": 137439019028,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(137439019028),
//--TRIMMABLE-BOUNDARY-START(141733986324),
    {
      "t": 655361,
      "n": "COR_E_INSUFFICIENTMEMORY",
      "d": 65556,
      "h": 141733986324,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(141733986324),
//--TRIMMABLE-BOUNDARY-START(146028953620),
    {
      "t": 655361,
      "n": "COR_E_INVALIDCAST",
      "d": 65556,
      "h": 146028953620,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(146028953620),
//--TRIMMABLE-BOUNDARY-START(150323920916),
    {
      "t": 655361,
      "n": "COR_E_INVALIDCOMOBJECT",
      "d": 65556,
      "h": 150323920916,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(150323920916),
//--TRIMMABLE-BOUNDARY-START(154618888212),
    {
      "t": 655361,
      "n": "COR_E_INVALIDFILTERCRITERIA",
      "d": 65556,
      "h": 154618888212,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(154618888212),
//--TRIMMABLE-BOUNDARY-START(158913855508),
    {
      "t": 655361,
      "n": "COR_E_INVALIDOLEVARIANTTYPE",
      "d": 65556,
      "h": 158913855508,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(158913855508),
//--TRIMMABLE-BOUNDARY-START(163208822804),
    {
      "t": 655361,
      "n": "COR_E_INVALIDOPERATION",
      "d": 65556,
      "h": 163208822804,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(163208822804),
//--TRIMMABLE-BOUNDARY-START(167503790100),
    {
      "t": 655361,
      "n": "COR_E_INVALIDPROGRAM",
      "d": 65556,
      "h": 167503790100,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(167503790100),
//--TRIMMABLE-BOUNDARY-START(171798757396),
    {
      "t": 655361,
      "n": "COR_E_IO",
      "d": 65556,
      "h": 171798757396,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(171798757396),
//--TRIMMABLE-BOUNDARY-START(176093724692),
    {
      "t": 655361,
      "n": "COR_E_KEYNOTFOUND",
      "d": 65556,
      "h": 176093724692,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(176093724692),
//--TRIMMABLE-BOUNDARY-START(180388691988),
    {
      "t": 655361,
      "n": "COR_E_MARSHALDIRECTIVE",
      "d": 65556,
      "h": 180388691988,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(180388691988),
//--TRIMMABLE-BOUNDARY-START(184683659284),
    {
      "t": 655361,
      "n": "COR_E_MEMBERACCESS",
      "d": 65556,
      "h": 184683659284,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(184683659284),
//--TRIMMABLE-BOUNDARY-START(188978626580),
    {
      "t": 655361,
      "n": "COR_E_METHODACCESS",
      "d": 65556,
      "h": 188978626580,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(188978626580),
//--TRIMMABLE-BOUNDARY-START(193273593876),
    {
      "t": 655361,
      "n": "COR_E_MISSINGFIELD",
      "d": 65556,
      "h": 193273593876,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(193273593876),
//--TRIMMABLE-BOUNDARY-START(197568561172),
    {
      "t": 655361,
      "n": "COR_E_MISSINGMANIFESTRESOURCE",
      "d": 65556,
      "h": 197568561172,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(197568561172),
//--TRIMMABLE-BOUNDARY-START(201863528468),
    {
      "t": 655361,
      "n": "COR_E_MISSINGMEMBER",
      "d": 65556,
      "h": 201863528468,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(201863528468),
//--TRIMMABLE-BOUNDARY-START(206158495764),
    {
      "t": 655361,
      "n": "COR_E_MISSINGMETHOD",
      "d": 65556,
      "h": 206158495764,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(206158495764),
//--TRIMMABLE-BOUNDARY-START(210453463060),
    {
      "t": 655361,
      "n": "COR_E_MISSINGSATELLITEASSEMBLY",
      "d": 65556,
      "h": 210453463060,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(210453463060),
//--TRIMMABLE-BOUNDARY-START(214748430356),
    {
      "t": 655361,
      "n": "COR_E_MULTICASTNOTSUPPORTED",
      "d": 65556,
      "h": 214748430356,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(214748430356),
//--TRIMMABLE-BOUNDARY-START(219043397652),
    {
      "t": 655361,
      "n": "COR_E_NOTFINITENUMBER",
      "d": 65556,
      "h": 219043397652,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(219043397652),
//--TRIMMABLE-BOUNDARY-START(223338364948),
    {
      "t": 655361,
      "n": "COR_E_NOTSUPPORTED",
      "d": 65556,
      "h": 223338364948,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(223338364948),
//--TRIMMABLE-BOUNDARY-START(227633332244),
    {
      "t": 655361,
      "n": "COR_E_OBJECTDISPOSED",
      "d": 65556,
      "h": 227633332244,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(227633332244),
//--TRIMMABLE-BOUNDARY-START(231928299540),
    {
      "t": 655361,
      "n": "COR_E_OPERATIONCANCELED",
      "d": 65556,
      "h": 231928299540,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(231928299540),
//--TRIMMABLE-BOUNDARY-START(236223266836),
    {
      "t": 655361,
      "n": "COR_E_OUTOFMEMORY",
      "d": 65556,
      "h": 236223266836,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(236223266836),
//--TRIMMABLE-BOUNDARY-START(240518234132),
    {
      "t": 655361,
      "n": "COR_E_OVERFLOW",
      "d": 65556,
      "h": 240518234132,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(240518234132),
//--TRIMMABLE-BOUNDARY-START(244813201428),
    {
      "t": 655361,
      "n": "COR_E_PATHTOOLONG",
      "d": 65556,
      "h": 244813201428,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(244813201428),
//--TRIMMABLE-BOUNDARY-START(249108168724),
    {
      "t": 655361,
      "n": "COR_E_PLATFORMNOTSUPPORTED",
      "d": 65556,
      "h": 249108168724,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(249108168724),
//--TRIMMABLE-BOUNDARY-START(253403136020),
    {
      "t": 655361,
      "n": "COR_E_RANK",
      "d": 65556,
      "h": 253403136020,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(253403136020),
//--TRIMMABLE-BOUNDARY-START(257698103316),
    {
      "t": 655361,
      "n": "COR_E_REFLECTIONTYPELOAD",
      "d": 65556,
      "h": 257698103316,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(257698103316),
//--TRIMMABLE-BOUNDARY-START(261993070612),
    {
      "t": 655361,
      "n": "COR_E_RUNTIMEWRAPPED",
      "d": 65556,
      "h": 261993070612,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(261993070612),
//--TRIMMABLE-BOUNDARY-START(266288037908),
    {
      "t": 655361,
      "n": "COR_E_SAFEARRAYRANKMISMATCH",
      "d": 65556,
      "h": 266288037908,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(266288037908),
//--TRIMMABLE-BOUNDARY-START(270583005204),
    {
      "t": 655361,
      "n": "COR_E_SAFEARRAYTYPEMISMATCH",
      "d": 65556,
      "h": 270583005204,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(270583005204),
//--TRIMMABLE-BOUNDARY-START(274877972500),
    {
      "t": 655361,
      "n": "COR_E_SECURITY",
      "d": 65556,
      "h": 274877972500,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(274877972500),
//--TRIMMABLE-BOUNDARY-START(279172939796),
    {
      "t": 655361,
      "n": "COR_E_SERIALIZATION",
      "d": 65556,
      "h": 279172939796,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(279172939796),
//--TRIMMABLE-BOUNDARY-START(283467907092),
    {
      "t": 655361,
      "n": "COR_E_STACKOVERFLOW",
      "d": 65556,
      "h": 283467907092,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(283467907092),
//--TRIMMABLE-BOUNDARY-START(287762874388),
    {
      "t": 655361,
      "n": "COR_E_SYNCHRONIZATIONLOCK",
      "d": 65556,
      "h": 287762874388,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(287762874388),
//--TRIMMABLE-BOUNDARY-START(292057841684),
    {
      "t": 655361,
      "n": "COR_E_SYSTEM",
      "d": 65556,
      "h": 292057841684,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(292057841684),
//--TRIMMABLE-BOUNDARY-START(296352808980),
    {
      "t": 655361,
      "n": "COR_E_TARGET",
      "d": 65556,
      "h": 296352808980,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(296352808980),
//--TRIMMABLE-BOUNDARY-START(300647776276),
    {
      "t": 655361,
      "n": "COR_E_TARGETINVOCATION",
      "d": 65556,
      "h": 300647776276,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(300647776276),
//--TRIMMABLE-BOUNDARY-START(304942743572),
    {
      "t": 655361,
      "n": "COR_E_TARGETPARAMCOUNT",
      "d": 65556,
      "h": 304942743572,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(304942743572),
//--TRIMMABLE-BOUNDARY-START(309237710868),
    {
      "t": 655361,
      "n": "COR_E_THREADABORTED",
      "d": 65556,
      "h": 309237710868,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(309237710868),
//--TRIMMABLE-BOUNDARY-START(313532678164),
    {
      "t": 655361,
      "n": "COR_E_THREADINTERRUPTED",
      "d": 65556,
      "h": 313532678164,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(313532678164),
//--TRIMMABLE-BOUNDARY-START(317827645460),
    {
      "t": 655361,
      "n": "COR_E_THREADSTART",
      "d": 65556,
      "h": 317827645460,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(317827645460),
//--TRIMMABLE-BOUNDARY-START(322122612756),
    {
      "t": 655361,
      "n": "COR_E_THREADSTATE",
      "d": 65556,
      "h": 322122612756,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(322122612756),
//--TRIMMABLE-BOUNDARY-START(326417580052),
    {
      "t": 655361,
      "n": "COR_E_TIMEOUT",
      "d": 65556,
      "h": 326417580052,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(326417580052),
//--TRIMMABLE-BOUNDARY-START(330712547348),
    {
      "t": 655361,
      "n": "COR_E_TYPEACCESS",
      "d": 65556,
      "h": 330712547348,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(330712547348),
//--TRIMMABLE-BOUNDARY-START(335007514644),
    {
      "t": 655361,
      "n": "COR_E_TYPEINITIALIZATION",
      "d": 65556,
      "h": 335007514644,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(335007514644),
//--TRIMMABLE-BOUNDARY-START(339302481940),
    {
      "t": 655361,
      "n": "COR_E_TYPELOAD",
      "d": 65556,
      "h": 339302481940,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(339302481940),
//--TRIMMABLE-BOUNDARY-START(343597449236),
    {
      "t": 655361,
      "n": "COR_E_TYPEUNLOADED",
      "d": 65556,
      "h": 343597449236,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(343597449236),
//--TRIMMABLE-BOUNDARY-START(347892416532),
    {
      "t": 655361,
      "n": "COR_E_UNAUTHORIZEDACCESS",
      "d": 65556,
      "h": 347892416532,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(347892416532),
//--TRIMMABLE-BOUNDARY-START(352187383828),
    {
      "t": 655361,
      "n": "COR_E_VERIFICATION",
      "d": 65556,
      "h": 352187383828,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(352187383828),
//--TRIMMABLE-BOUNDARY-START(356482351124),
    {
      "t": 655361,
      "n": "COR_E_WAITHANDLECANNOTBEOPENED",
      "d": 65556,
      "h": 356482351124,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(356482351124),
//--TRIMMABLE-BOUNDARY-START(4295032852),
    {
      "t": 655361,
      "n": "CO_E_NOTINITIALIZED",
      "d": 65556,
      "h": 4295032852,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(4295032852),
//--TRIMMABLE-BOUNDARY-START(382252154900),
    {
      "t": 655361,
      "n": "DISP_E_PARAMNOTFOUND",
      "d": 65556,
      "h": 382252154900,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(382252154900),
//--TRIMMABLE-BOUNDARY-START(386547122196),
    {
      "t": 655361,
      "n": "DISP_E_TYPEMISMATCH",
      "d": 65556,
      "h": 386547122196,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(386547122196),
//--TRIMMABLE-BOUNDARY-START(369367253012),
    {
      "t": 655361,
      "n": "DISP_E_BADVARTYPE",
      "d": 65556,
      "h": 369367253012,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(369367253012),
//--TRIMMABLE-BOUNDARY-START(377957187604),
    {
      "t": 655361,
      "n": "DISP_E_OVERFLOW",
      "d": 65556,
      "h": 377957187604,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(377957187604),
//--TRIMMABLE-BOUNDARY-START(373662220308),
    {
      "t": 655361,
      "n": "DISP_E_DIVBYZERO",
      "d": 65556,
      "h": 373662220308,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(373662220308),
//--TRIMMABLE-BOUNDARY-START(390842089492),
    {
      "t": 655361,
      "n": "E_BOUNDS",
      "d": 65556,
      "h": 390842089492,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(390842089492),
//--TRIMMABLE-BOUNDARY-START(395137056788),
    {
      "t": 655361,
      "n": "E_CHANGED_STATE",
      "d": 65556,
      "h": 395137056788,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(395137056788),
//--TRIMMABLE-BOUNDARY-START(403726991380),
    {
      "t": 655361,
      "n": "E_FILENOTFOUND",
      "d": 65556,
      "h": 403726991380,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(403726991380),
//--TRIMMABLE-BOUNDARY-START(399432024084),
    {
      "t": 655361,
      "n": "E_FAIL",
      "d": 65556,
      "h": 399432024084,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(399432024084),
//--TRIMMABLE-BOUNDARY-START(408021958676),
    {
      "t": 655361,
      "n": "E_HANDLE",
      "d": 65556,
      "h": 408021958676,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(408021958676),
//--TRIMMABLE-BOUNDARY-START(412316925972),
    {
      "t": 655361,
      "n": "E_INVALIDARG",
      "d": 65556,
      "h": 412316925972,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(412316925972),
//--TRIMMABLE-BOUNDARY-START(416611893268),
    {
      "t": 655361,
      "n": "E_NOTIMPL",
      "d": 65556,
      "h": 416611893268,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(416611893268),
//--TRIMMABLE-BOUNDARY-START(420906860564),
    {
      "t": 655361,
      "n": "E_OUTOFMEMORY",
      "d": 65556,
      "h": 420906860564,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(420906860564),
//--TRIMMABLE-BOUNDARY-START(425201827860),
    {
      "t": 655361,
      "n": "E_POINTER",
      "d": 65556,
      "h": 425201827860,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(425201827860),
//--TRIMMABLE-BOUNDARY-START(446676664340),
    {
      "t": 655361,
      "n": "ERROR_MRM_MAP_NOT_FOUND",
      "d": 65556,
      "h": 446676664340,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(446676664340),
//--TRIMMABLE-BOUNDARY-START(459561566228),
    {
      "t": 655361,
      "n": "ERROR_TIMEOUT",
      "d": 65556,
      "h": 459561566228,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(459561566228),
//--TRIMMABLE-BOUNDARY-START(485331370004),
    {
      "t": 655361,
      "n": "RO_E_CLOSED",
      "d": 65556,
      "h": 485331370004,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(485331370004),
//--TRIMMABLE-BOUNDARY-START(489626337300),
    {
      "t": 655361,
      "n": "RPC_E_CHANGED_MODE",
      "d": 65556,
      "h": 489626337300,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(489626337300),
//--TRIMMABLE-BOUNDARY-START(506806206484),
    {
      "t": 655361,
      "n": "TYPE_E_TYPEMISMATCH",
      "d": 65556,
      "h": 506806206484,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(506806206484),
//--TRIMMABLE-BOUNDARY-START(502511239188),
    {
      "t": 655361,
      "n": "STG_E_PATHNOTFOUND",
      "d": 65556,
      "h": 502511239188,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(502511239188),
//--TRIMMABLE-BOUNDARY-START(365072285716),
    {
      "t": 655361,
      "n": "CTL_E_PATHNOTFOUND",
      "d": 65556,
      "h": 365072285716,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(365072285716),
//--TRIMMABLE-BOUNDARY-START(360777318420),
    {
      "t": 655361,
      "n": "CTL_E_FILENOTFOUND",
      "d": 65556,
      "h": 360777318420,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(360777318420),
//--TRIMMABLE-BOUNDARY-START(472446468116),
    {
      "t": 655361,
      "n": "FUSION_E_INVALID_NAME",
      "d": 65556,
      "h": 472446468116,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(472446468116),
//--TRIMMABLE-BOUNDARY-START(476741435412),
    {
      "t": 655361,
      "n": "FUSION_E_REF_DEF_MISMATCH",
      "d": 65556,
      "h": 476741435412,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(476741435412),
//--TRIMMABLE-BOUNDARY-START(463856533524),
    {
      "t": 655361,
      "n": "ERROR_TOO_MANY_OPEN_FILES",
      "d": 65556,
      "h": 463856533524,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(463856533524),
//--TRIMMABLE-BOUNDARY-START(455266598932),
    {
      "t": 655361,
      "n": "ERROR_SHARING_VIOLATION",
      "d": 65556,
      "h": 455266598932,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(455266598932),
//--TRIMMABLE-BOUNDARY-START(442381697044),
    {
      "t": 655361,
      "n": "ERROR_LOCK_VIOLATION",
      "d": 65556,
      "h": 442381697044,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(442381697044),
//--TRIMMABLE-BOUNDARY-START(450971631636),
    {
      "t": 655361,
      "n": "ERROR_OPEN_FAILED",
      "d": 65556,
      "h": 450971631636,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(450971631636),
//--TRIMMABLE-BOUNDARY-START(429496795156),
    {
      "t": 655361,
      "n": "ERROR_DISK_CORRUPT",
      "d": 65556,
      "h": 429496795156,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(429496795156),
//--TRIMMABLE-BOUNDARY-START(468151500820),
    {
      "t": 655361,
      "n": "ERROR_UNRECOGNIZED_VOLUME",
      "d": 65556,
      "h": 468151500820,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(468151500820),
//--TRIMMABLE-BOUNDARY-START(433791762452),
    {
      "t": 655361,
      "n": "ERROR_DLL_INIT_FAILED",
      "d": 65556,
      "h": 433791762452,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(433791762452),
//--TRIMMABLE-BOUNDARY-START(481036402708),
    {
      "t": 655361,
      "n": "MSEE_E_ASSEMBLYLOADINPROGRESS",
      "d": 65556,
      "h": 481036402708,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(481036402708),
//--TRIMMABLE-BOUNDARY-START(438086729748),
    {
      "t": 655361,
      "n": "ERROR_FILE_INVALID",
      "d": 65556,
      "h": 438086729748,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(438086729748)
  ],
  "h": 65556
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.HResults`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65556)
        
        
        //--TRIMMABLE-BOUNDARY-START(131092)
        $asm.$cls("$st.System.Obsoletions", ($self) => class Obsoletions
        {
            //--TRIMMABLE-BOUNDARY-START(382252220436)
            /*string*/ static SharedUrlFormat = null;
            //--TRIMMABLE-BOUNDARY-END(382252220436)
            
            //--TRIMMABLE-BOUNDARY-START(433791827988)
            /*string*/ static SystemTextEncodingUTF7Message = null;
            //--TRIMMABLE-BOUNDARY-END(433791827988)
            
            //--TRIMMABLE-BOUNDARY-START(429496860692)
            /*string*/ static SystemTextEncodingUTF7DiagId = null;
            //--TRIMMABLE-BOUNDARY-END(429496860692)
            
            //--TRIMMABLE-BOUNDARY-START(266288103444)
            /*string*/ static PrincipalPermissionAttributeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(266288103444)
            
            //--TRIMMABLE-BOUNDARY-START(261993136148)
            /*string*/ static PrincipalPermissionAttributeDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(261993136148)
            
            //--TRIMMABLE-BOUNDARY-START(77309542420)
            /*string*/ static CodeAccessSecurityMessage = null;
            //--TRIMMABLE-BOUNDARY-END(77309542420)
            
            //--TRIMMABLE-BOUNDARY-START(73014575124)
            /*string*/ static CodeAccessSecurityDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(73014575124)
            
            //--TRIMMABLE-BOUNDARY-START(94489411604)
            /*string*/ static ConstrainedExecutionRegionMessage = null;
            //--TRIMMABLE-BOUNDARY-END(94489411604)
            
            //--TRIMMABLE-BOUNDARY-START(90194444308)
            /*string*/ static ConstrainedExecutionRegionDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(90194444308)
            
            //--TRIMMABLE-BOUNDARY-START(214748495892)
            /*string*/ static GlobalAssemblyCacheMessage = null;
            //--TRIMMABLE-BOUNDARY-END(214748495892)
            
            //--TRIMMABLE-BOUNDARY-START(210453528596)
            /*string*/ static GlobalAssemblyCacheDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(210453528596)
            
            //--TRIMMABLE-BOUNDARY-START(442381762580)
            /*string*/ static ThreadAbortMessage = null;
            //--TRIMMABLE-BOUNDARY-END(442381762580)
            
            //--TRIMMABLE-BOUNDARY-START(446676729876)
            /*string*/ static ThreadResetAbortMessage = null;
            //--TRIMMABLE-BOUNDARY-END(446676729876)
            
            //--TRIMMABLE-BOUNDARY-START(438086795284)
            /*string*/ static ThreadAbortDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(438086795284)
            
            //--TRIMMABLE-BOUNDARY-START(146029019156)
            /*string*/ static DefaultCryptoAlgorithmsMessage = null;
            //--TRIMMABLE-BOUNDARY-END(146029019156)
            
            //--TRIMMABLE-BOUNDARY-START(141734051860)
            /*string*/ static DefaultCryptoAlgorithmsDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(141734051860)
            
            //--TRIMMABLE-BOUNDARY-START(120259215380)
            /*string*/ static CreatePdbGeneratorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(120259215380)
            
            //--TRIMMABLE-BOUNDARY-START(115964248084)
            /*string*/ static CreatePdbGeneratorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(115964248084)
            
            //--TRIMMABLE-BOUNDARY-START(51539738644)
            /*string*/ static AuthenticationManagerMessage = null;
            //--TRIMMABLE-BOUNDARY-END(51539738644)
            
            //--TRIMMABLE-BOUNDARY-START(47244771348)
            /*string*/ static AuthenticationManagerDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(47244771348)
            
            //--TRIMMABLE-BOUNDARY-START(326417645588)
            /*string*/ static RemotingApisMessage = null;
            //--TRIMMABLE-BOUNDARY-END(326417645588)
            
            //--TRIMMABLE-BOUNDARY-START(322122678292)
            /*string*/ static RemotingApisDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(322122678292)
            
            //--TRIMMABLE-BOUNDARY-START(60129673236)
            /*string*/ static BinaryFormatterMessage = null;
            //--TRIMMABLE-BOUNDARY-END(60129673236)
            
            //--TRIMMABLE-BOUNDARY-START(55834705940)
            /*string*/ static BinaryFormatterDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(55834705940)
            
            //--TRIMMABLE-BOUNDARY-START(85899477012)
            /*string*/ static CodeBaseMessage = null;
            //--TRIMMABLE-BOUNDARY-END(85899477012)
            
            //--TRIMMABLE-BOUNDARY-START(81604509716)
            /*string*/ static CodeBaseDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(81604509716)
            
            //--TRIMMABLE-BOUNDARY-START(197568626708)
            /*string*/ static EscapeUriStringMessage = null;
            //--TRIMMABLE-BOUNDARY-END(197568626708)
            
            //--TRIMMABLE-BOUNDARY-START(193273659412)
            /*string*/ static EscapeUriStringDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(193273659412)
            
            //--TRIMMABLE-BOUNDARY-START(489626402836)
            /*string*/ static WebRequestMessage = null;
            //--TRIMMABLE-BOUNDARY-END(489626402836)
            
            //--TRIMMABLE-BOUNDARY-START(485331435540)
            /*string*/ static WebRequestDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(485331435540)
            
            //--TRIMMABLE-BOUNDARY-START(163208888340)
            /*string*/ static DisablePrivateReflectionAttributeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(163208888340)
            
            //--TRIMMABLE-BOUNDARY-START(158913921044)
            /*string*/ static DisablePrivateReflectionAttributeDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(158913921044)
            
            //--TRIMMABLE-BOUNDARY-START(206158561300)
            /*string*/ static GetContextInfoMessage = null;
            //--TRIMMABLE-BOUNDARY-END(206158561300)
            
            //--TRIMMABLE-BOUNDARY-START(201863594004)
            /*string*/ static GetContextInfoDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(201863594004)
            
            //--TRIMMABLE-BOUNDARY-START(399432089620)
            /*string*/ static StrongNameKeyPairMessage = null;
            //--TRIMMABLE-BOUNDARY-END(399432089620)
            
            //--TRIMMABLE-BOUNDARY-START(395137122324)
            /*string*/ static StrongNameKeyPairDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(395137122324)
            
            //--TRIMMABLE-BOUNDARY-START(300647841812)
            /*string*/ static ReflectionOnlyLoadingMessage = null;
            //--TRIMMABLE-BOUNDARY-END(300647841812)
            
            //--TRIMMABLE-BOUNDARY-START(296352874516)
            /*string*/ static ReflectionOnlyLoadingDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(296352874516)
            
            //--TRIMMABLE-BOUNDARY-START(377957253140)
            /*string*/ static RuntimeEnvironmentMessage = null;
            //--TRIMMABLE-BOUNDARY-END(377957253140)
            
            //--TRIMMABLE-BOUNDARY-START(373662285844)
            /*string*/ static RuntimeEnvironmentDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(373662285844)
            
            //--TRIMMABLE-BOUNDARY-START(231928365076)
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesMessage = null;
            //--TRIMMABLE-BOUNDARY-END(231928365076)
            
            //--TRIMMABLE-BOUNDARY-START(227633397780)
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(227633397780)
            
            //--TRIMMABLE-BOUNDARY-START(154618953748)
            /*string*/ static DerivedCryptographicTypesMessage = null;
            //--TRIMMABLE-BOUNDARY-END(154618953748)
            
            //--TRIMMABLE-BOUNDARY-START(150323986452)
            /*string*/ static DerivedCryptographicTypesDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(150323986452)
            
            //--TRIMMABLE-BOUNDARY-START(352187449364)
            /*string*/ static RijndaelMessage = null;
            //--TRIMMABLE-BOUNDARY-END(352187449364)
            
            //--TRIMMABLE-BOUNDARY-START(347892482068)
            /*string*/ static RijndaelDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(347892482068)
            
            //--TRIMMABLE-BOUNDARY-START(360777383956)
            /*string*/ static RNGCryptoServiceProviderMessage = null;
            //--TRIMMABLE-BOUNDARY-END(360777383956)
            
            //--TRIMMABLE-BOUNDARY-START(356482416660)
            /*string*/ static RNGCryptoServiceProviderDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(356482416660)
            
            //--TRIMMABLE-BOUNDARY-START(17180000276)
            /*string*/ static AppDomainCreateUnloadMessage = null;
            //--TRIMMABLE-BOUNDARY-END(17180000276)
            
            //--TRIMMABLE-BOUNDARY-START(12885032980)
            /*string*/ static AppDomainCreateUnloadDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(12885032980)
            
            //--TRIMMABLE-BOUNDARY-START(408022024212)
            /*string*/ static SuppressIldasmAttributeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(408022024212)
            
            //--TRIMMABLE-BOUNDARY-START(403727056916)
            /*string*/ static SuppressIldasmAttributeDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(403727056916)
            
            //--TRIMMABLE-BOUNDARY-START(498216337428)
            /*string*/ static X509CertificateImmutableMessage = null;
            //--TRIMMABLE-BOUNDARY-END(498216337428)
            
            //--TRIMMABLE-BOUNDARY-START(493921370132)
            /*string*/ static X509CertificateImmutableDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(493921370132)
            
            //--TRIMMABLE-BOUNDARY-START(283467972628)
            /*string*/ static PublicKeyPropertyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(283467972628)
            
            //--TRIMMABLE-BOUNDARY-START(279173005332)
            /*string*/ static PublicKeyPropertyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(279173005332)
            
            //--TRIMMABLE-BOUNDARY-START(506806272020)
            /*string*/ static X509CertificatePrivateKeyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(506806272020)
            
            //--TRIMMABLE-BOUNDARY-START(502511304724)
            /*string*/ static X509CertificatePrivateKeyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(502511304724)
            
            //--TRIMMABLE-BOUNDARY-START(274878038036)
            /*string*/ static ProduceLegacyHmacValuesMessage = null;
            //--TRIMMABLE-BOUNDARY-END(274878038036)
            
            //--TRIMMABLE-BOUNDARY-START(270583070740)
            /*string*/ static ProduceLegacyHmacValuesDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(270583070740)
            
            //--TRIMMABLE-BOUNDARY-START(481036468244)
            /*string*/ static UseManagedSha1Message = null;
            //--TRIMMABLE-BOUNDARY-END(481036468244)
            
            //--TRIMMABLE-BOUNDARY-START(476741500948)
            /*string*/ static UseManagedSha1DiagId = null;
            //--TRIMMABLE-BOUNDARY-END(476741500948)
            
            //--TRIMMABLE-BOUNDARY-START(128849149972)
            /*string*/ static CryptoConfigEncodeOIDMessage = null;
            //--TRIMMABLE-BOUNDARY-END(128849149972)
            
            //--TRIMMABLE-BOUNDARY-START(124554182676)
            /*string*/ static CryptoConfigEncodeOIDDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(124554182676)
            
            //--TRIMMABLE-BOUNDARY-START(111669280788)
            /*string*/ static CorruptedStateRecoveryMessage = null;
            //--TRIMMABLE-BOUNDARY-END(111669280788)
            
            //--TRIMMABLE-BOUNDARY-START(107374313492)
            /*string*/ static CorruptedStateRecoveryDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(107374313492)
            
            //--TRIMMABLE-BOUNDARY-START(335007580180)
            /*string*/ static Rfc2898CryptDeriveKeyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(335007580180)
            
            //--TRIMMABLE-BOUNDARY-START(330712612884)
            /*string*/ static Rfc2898CryptDeriveKeyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(330712612884)
            
            //--TRIMMABLE-BOUNDARY-START(68719607828)
            /*string*/ static CmsSignerCspParamsCtorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(68719607828)
            
            //--TRIMMABLE-BOUNDARY-START(64424640532)
            /*string*/ static CmsSignerCspParamsCtorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(64424640532)
            
            //--TRIMMABLE-BOUNDARY-START(390842155028)
            /*string*/ static SignerInfoCounterSigMessage = null;
            //--TRIMMABLE-BOUNDARY-END(390842155028)
            
            //--TRIMMABLE-BOUNDARY-START(386547187732)
            /*string*/ static SignerInfoCounterSigDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(386547187732)
            
            //--TRIMMABLE-BOUNDARY-START(309237776404)
            /*string*/ static RegexCompileToAssemblyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(309237776404)
            
            //--TRIMMABLE-BOUNDARY-START(304942809108)
            /*string*/ static RegexCompileToAssemblyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(304942809108)
            
            //--TRIMMABLE-BOUNDARY-START(42949804052)
            /*string*/ static AssemblyNameMembersMessage = null;
            //--TRIMMABLE-BOUNDARY-END(42949804052)
            
            //--TRIMMABLE-BOUNDARY-START(38654836756)
            /*string*/ static AssemblyNameMembersDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(38654836756)
            
            //--TRIMMABLE-BOUNDARY-START(416611958804)
            /*string*/ static SystemDataSerializationFormatBinaryMessage = null;
            //--TRIMMABLE-BOUNDARY-END(416611958804)
            
            //--TRIMMABLE-BOUNDARY-START(412316991508)
            /*string*/ static SystemDataSerializationFormatBinaryDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(412316991508)
            
            //--TRIMMABLE-BOUNDARY-START(472446533652)
            /*string*/ static TlsVersion10and11Message = null;
            //--TRIMMABLE-BOUNDARY-END(472446533652)
            
            //--TRIMMABLE-BOUNDARY-START(468151566356)
            /*string*/ static TlsVersion10and11DiagId = null;
            //--TRIMMABLE-BOUNDARY-END(468151566356)
            
            //--TRIMMABLE-BOUNDARY-START(188978692116)
            /*string*/ static EncryptionPolicyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(188978692116)
            
            //--TRIMMABLE-BOUNDARY-START(184683724820)
            /*string*/ static EncryptionPolicyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(184683724820)
            
            //--TRIMMABLE-BOUNDARY-START(171798822932)
            /*string*/ static EccXmlExportImportMessage = null;
            //--TRIMMABLE-BOUNDARY-END(171798822932)
            
            //--TRIMMABLE-BOUNDARY-START(167503855636)
            /*string*/ static EccXmlExportImportDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(167503855636)
            
            //--TRIMMABLE-BOUNDARY-START(180388757524)
            /*string*/ static EcDhPublicKeyBlobMessage = null;
            //--TRIMMABLE-BOUNDARY-END(180388757524)
            
            //--TRIMMABLE-BOUNDARY-START(176093790228)
            /*string*/ static EcDhPublicKeyBlobDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(176093790228)
            
            //--TRIMMABLE-BOUNDARY-START(34359869460)
            /*string*/ static AssemblyNameCodeBaseMessage = null;
            //--TRIMMABLE-BOUNDARY-END(34359869460)
            
            //--TRIMMABLE-BOUNDARY-START(30064902164)
            /*string*/ static AssemblyNameCodeBaseDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(30064902164)
            
            //--TRIMMABLE-BOUNDARY-START(137439084564)
            /*string*/ static CryptoStringFactoryMessage = null;
            //--TRIMMABLE-BOUNDARY-END(137439084564)
            
            //--TRIMMABLE-BOUNDARY-START(133144117268)
            /*string*/ static CryptoStringFactoryDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(133144117268)
            
            //--TRIMMABLE-BOUNDARY-START(103079346196)
            /*string*/ static ControlledExecutionRunMessage = null;
            //--TRIMMABLE-BOUNDARY-END(103079346196)
            
            //--TRIMMABLE-BOUNDARY-START(98784378900)
            /*string*/ static ControlledExecutionRunDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(98784378900)
            
            //--TRIMMABLE-BOUNDARY-START(523986141204)
            /*string*/ static XmlSecureResolverMessage = null;
            //--TRIMMABLE-BOUNDARY-END(523986141204)
            
            //--TRIMMABLE-BOUNDARY-START(519691173908)
            /*string*/ static XmlSecureResolverDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(519691173908)
            
            //--TRIMMABLE-BOUNDARY-START(369367318548)
            /*string*/ static RsaEncryptDecryptValueMessage = null;
            //--TRIMMABLE-BOUNDARY-END(369367318548)
            
            //--TRIMMABLE-BOUNDARY-START(365072351252)
            /*string*/ static RsaEncryptDecryptDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(365072351252)
            
            //--TRIMMABLE-BOUNDARY-START(223338430484)
            /*string*/ static JsonSerializerOptionsAddContextMessage = null;
            //--TRIMMABLE-BOUNDARY-END(223338430484)
            
            //--TRIMMABLE-BOUNDARY-START(219043463188)
            /*string*/ static JsonSerializerOptionsAddContextDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(219043463188)
            
            //--TRIMMABLE-BOUNDARY-START(249108234260)
            /*string*/ static LegacyFormatterMessage = null;
            //--TRIMMABLE-BOUNDARY-END(249108234260)
            
            //--TRIMMABLE-BOUNDARY-START(236223332372)
            /*string*/ static LegacyFormatterDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(236223332372)
            
            //--TRIMMABLE-BOUNDARY-START(244813266964)
            /*string*/ static LegacyFormatterImplMessage = null;
            //--TRIMMABLE-BOUNDARY-END(244813266964)
            
            //--TRIMMABLE-BOUNDARY-START(240518299668)
            /*string*/ static LegacyFormatterImplDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(240518299668)
            
            //--TRIMMABLE-BOUNDARY-START(317827710996)
            /*string*/ static RegexExtensibilityImplMessage = null;
            //--TRIMMABLE-BOUNDARY-END(317827710996)
            
            //--TRIMMABLE-BOUNDARY-START(313532743700)
            /*string*/ static RegexExtensibilityDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(313532743700)
            
            //--TRIMMABLE-BOUNDARY-START(8590065684)
            /*string*/ static AesGcmTagConstructorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(8590065684)
            
            //--TRIMMABLE-BOUNDARY-START(4295098388)
            /*string*/ static AesGcmTagConstructorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(4295098388)
            
            //--TRIMMABLE-BOUNDARY-START(455266664468)
            /*string*/ static ThreadVolatileReadWriteMessage = null;
            //--TRIMMABLE-BOUNDARY-END(455266664468)
            
            //--TRIMMABLE-BOUNDARY-START(450971697172)
            /*string*/ static ThreadVolatileReadWriteDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(450971697172)
            
            //--TRIMMABLE-BOUNDARY-START(25769934868)
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationMessage = null;
            //--TRIMMABLE-BOUNDARY-END(25769934868)
            
            //--TRIMMABLE-BOUNDARY-START(21474967572)
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(21474967572)
            
            //--TRIMMABLE-BOUNDARY-START(257698168852)
            /*string*/ static LoadFromHashAlgorithmMessage = null;
            //--TRIMMABLE-BOUNDARY-END(257698168852)
            
            //--TRIMMABLE-BOUNDARY-START(253403201556)
            /*string*/ static LoadFromHashAlgorithmDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(253403201556)
            
            //--TRIMMABLE-BOUNDARY-START(515396206612)
            /*string*/ static X509CtorCertDataObsoleteMessage = null;
            //--TRIMMABLE-BOUNDARY-END(515396206612)
            
            //--TRIMMABLE-BOUNDARY-START(511101239316)
            /*string*/ static X509CtorCertDataObsoleteDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(511101239316)
            
            //--TRIMMABLE-BOUNDARY-START(463856599060)
            /*string*/ static TlsCipherAlgorithmEnumsMessage = null;
            //--TRIMMABLE-BOUNDARY-END(463856599060)
            
            //--TRIMMABLE-BOUNDARY-START(459561631764)
            /*string*/ static TlsCipherAlgorithmEnumsDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(459561631764)
            
            //--TRIMMABLE-BOUNDARY-START(425201893396)
            /*string*/ static SystemEventsEventsThreadShutdownMessage = null;
            //--TRIMMABLE-BOUNDARY-END(425201893396)
            
            //--TRIMMABLE-BOUNDARY-START(420906926100)
            /*string*/ static SystemEventsEventsThreadShutdownDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(420906926100)
            
            //--TRIMMABLE-BOUNDARY-START(343597514772)
            /*string*/ static Rfc2898DeriveBytesCtorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(343597514772)
            
            //--TRIMMABLE-BOUNDARY-START(339302547476)
            /*string*/ static Rfc2898DeriveBytesCtorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(339302547476)
            
            //--TRIMMABLE-BOUNDARY-START(292057907220)
            /*string*/ static QueryableMinByMaxByTSourceObsoleteMessage = null;
            //--TRIMMABLE-BOUNDARY-END(292057907220)
            
            //--TRIMMABLE-BOUNDARY-START(287762939924)
            /*string*/ static QueryableMinByMaxByTSourceObsoleteDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(287762939924)
            
            //--TRIMMABLE-BOUNDARY-START(532576075796)
            /*string*/ static XsltSettingsEnableScriptMessage = null;
            //--TRIMMABLE-BOUNDARY-END(532576075796)
            
            //--TRIMMABLE-BOUNDARY-START(528281108500)
            /*string*/ static XsltSettingsEnableScriptDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(528281108500)
            
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(382252220436)
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                    //--TRIMMABLE-BOUNDARY-END(382252220436)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(433791827988)
                    this.SystemTextEncodingUTF7Message = "The UTF-7 encoding is insecure and should not be used. Consider using UTF-8 instead.";
                    //--TRIMMABLE-BOUNDARY-END(433791827988)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(429496860692)
                    this.SystemTextEncodingUTF7DiagId = "SYSLIB0001";
                    //--TRIMMABLE-BOUNDARY-END(429496860692)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(266288103444)
                    this.PrincipalPermissionAttributeMessage = "PrincipalPermissionAttribute is not honored by the runtime and must not be used.";
                    //--TRIMMABLE-BOUNDARY-END(266288103444)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(261993136148)
                    this.PrincipalPermissionAttributeDiagId = "SYSLIB0002";
                    //--TRIMMABLE-BOUNDARY-END(261993136148)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(77309542420)
                    this.CodeAccessSecurityMessage = "Code Access Security is not supported or honored by the runtime.";
                    //--TRIMMABLE-BOUNDARY-END(77309542420)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(73014575124)
                    this.CodeAccessSecurityDiagId = "SYSLIB0003";
                    //--TRIMMABLE-BOUNDARY-END(73014575124)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(94489411604)
                    this.ConstrainedExecutionRegionMessage = "The Constrained Execution Region (CER) feature is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(94489411604)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(90194444308)
                    this.ConstrainedExecutionRegionDiagId = "SYSLIB0004";
                    //--TRIMMABLE-BOUNDARY-END(90194444308)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(214748495892)
                    this.GlobalAssemblyCacheMessage = "The Global Assembly Cache is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(214748495892)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(210453528596)
                    this.GlobalAssemblyCacheDiagId = "SYSLIB0005";
                    //--TRIMMABLE-BOUNDARY-END(210453528596)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(442381762580)
                    this.ThreadAbortMessage = "Thread.Abort is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(442381762580)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(446676729876)
                    this.ThreadResetAbortMessage = "Thread.ResetAbort is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(446676729876)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(438086795284)
                    this.ThreadAbortDiagId = "SYSLIB0006";
                    //--TRIMMABLE-BOUNDARY-END(438086795284)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(146029019156)
                    this.DefaultCryptoAlgorithmsMessage = "The default implementation of this cryptography algorithm is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(146029019156)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(141734051860)
                    this.DefaultCryptoAlgorithmsDiagId = "SYSLIB0007";
                    //--TRIMMABLE-BOUNDARY-END(141734051860)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(120259215380)
                    this.CreatePdbGeneratorMessage = "The CreatePdbGenerator API is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(120259215380)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(115964248084)
                    this.CreatePdbGeneratorDiagId = "SYSLIB0008";
                    //--TRIMMABLE-BOUNDARY-END(115964248084)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(51539738644)
                    this.AuthenticationManagerMessage = "AuthenticationManager is not supported. Methods will no-op or throw PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(51539738644)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47244771348)
                    this.AuthenticationManagerDiagId = "SYSLIB0009";
                    //--TRIMMABLE-BOUNDARY-END(47244771348)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(326417645588)
                    this.RemotingApisMessage = "This Remoting API is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(326417645588)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(322122678292)
                    this.RemotingApisDiagId = "SYSLIB0010";
                    //--TRIMMABLE-BOUNDARY-END(322122678292)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(60129673236)
                    this.BinaryFormatterMessage = "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.";
                    //--TRIMMABLE-BOUNDARY-END(60129673236)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(55834705940)
                    this.BinaryFormatterDiagId = "SYSLIB0011";
                    //--TRIMMABLE-BOUNDARY-END(55834705940)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(85899477012)
                    this.CodeBaseMessage = "Assembly.CodeBase and Assembly.EscapedCodeBase are only included for .NET Framework compatibility. Use Assembly.Location instead.";
                    //--TRIMMABLE-BOUNDARY-END(85899477012)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(81604509716)
                    this.CodeBaseDiagId = "SYSLIB0012";
                    //--TRIMMABLE-BOUNDARY-END(81604509716)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(197568626708)
                    this.EscapeUriStringMessage = "Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.";
                    //--TRIMMABLE-BOUNDARY-END(197568626708)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(193273659412)
                    this.EscapeUriStringDiagId = "SYSLIB0013";
                    //--TRIMMABLE-BOUNDARY-END(193273659412)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(489626402836)
                    this.WebRequestMessage = "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.";
                    //--TRIMMABLE-BOUNDARY-END(489626402836)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(485331435540)
                    this.WebRequestDiagId = "SYSLIB0014";
                    //--TRIMMABLE-BOUNDARY-END(485331435540)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(163208888340)
                    this.DisablePrivateReflectionAttributeMessage = "DisablePrivateReflectionAttribute has no effect in .NET 6.0+.";
                    //--TRIMMABLE-BOUNDARY-END(163208888340)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(158913921044)
                    this.DisablePrivateReflectionAttributeDiagId = "SYSLIB0015";
                    //--TRIMMABLE-BOUNDARY-END(158913921044)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(206158561300)
                    this.GetContextInfoMessage = "Use the Graphics.GetContextInfo overloads that accept arguments for better performance and fewer allocations.";
                    //--TRIMMABLE-BOUNDARY-END(206158561300)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(201863594004)
                    this.GetContextInfoDiagId = "SYSLIB0016";
                    //--TRIMMABLE-BOUNDARY-END(201863594004)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(399432089620)
                    this.StrongNameKeyPairMessage = "Strong name signing is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(399432089620)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(395137122324)
                    this.StrongNameKeyPairDiagId = "SYSLIB0017";
                    //--TRIMMABLE-BOUNDARY-END(395137122324)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(300647841812)
                    this.ReflectionOnlyLoadingMessage = "ReflectionOnly loading is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(300647841812)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(296352874516)
                    this.ReflectionOnlyLoadingDiagId = "SYSLIB0018";
                    //--TRIMMABLE-BOUNDARY-END(296352874516)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(377957253140)
                    this.RuntimeEnvironmentMessage = "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(377957253140)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(373662285844)
                    this.RuntimeEnvironmentDiagId = "SYSLIB0019";
                    //--TRIMMABLE-BOUNDARY-END(373662285844)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(231928365076)
                    this.JsonSerializerOptionsIgnoreNullValuesMessage = "JsonSerializerOptions.IgnoreNullValues is obsolete. To ignore null values when serializing, set DefaultIgnoreCondition to JsonIgnoreCondition.WhenWritingNull.";
                    //--TRIMMABLE-BOUNDARY-END(231928365076)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(227633397780)
                    this.JsonSerializerOptionsIgnoreNullValuesDiagId = "SYSLIB0020";
                    //--TRIMMABLE-BOUNDARY-END(227633397780)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(154618953748)
                    this.DerivedCryptographicTypesMessage = "Derived cryptographic types are obsolete. Use the Create method on the base type instead.";
                    //--TRIMMABLE-BOUNDARY-END(154618953748)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(150323986452)
                    this.DerivedCryptographicTypesDiagId = "SYSLIB0021";
                    //--TRIMMABLE-BOUNDARY-END(150323986452)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(352187449364)
                    this.RijndaelMessage = "The Rijndael and RijndaelManaged types are obsolete. Use Aes instead.";
                    //--TRIMMABLE-BOUNDARY-END(352187449364)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(347892482068)
                    this.RijndaelDiagId = "SYSLIB0022";
                    //--TRIMMABLE-BOUNDARY-END(347892482068)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(360777383956)
                    this.RNGCryptoServiceProviderMessage = "RNGCryptoServiceProvider is obsolete. To generate a random number, use one of the RandomNumberGenerator static methods instead.";
                    //--TRIMMABLE-BOUNDARY-END(360777383956)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(356482416660)
                    this.RNGCryptoServiceProviderDiagId = "SYSLIB0023";
                    //--TRIMMABLE-BOUNDARY-END(356482416660)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17180000276)
                    this.AppDomainCreateUnloadMessage = "Creating and unloading AppDomains is not supported and throws an exception.";
                    //--TRIMMABLE-BOUNDARY-END(17180000276)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12885032980)
                    this.AppDomainCreateUnloadDiagId = "SYSLIB0024";
                    //--TRIMMABLE-BOUNDARY-END(12885032980)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(408022024212)
                    this.SuppressIldasmAttributeMessage = "SuppressIldasmAttribute has no effect in .NET 6.0+.";
                    //--TRIMMABLE-BOUNDARY-END(408022024212)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(403727056916)
                    this.SuppressIldasmAttributeDiagId = "SYSLIB0025";
                    //--TRIMMABLE-BOUNDARY-END(403727056916)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(498216337428)
                    this.X509CertificateImmutableMessage = "X509Certificate and X509Certificate2 are immutable. Use X509CertificateLoader to create a new certificate.";
                    //--TRIMMABLE-BOUNDARY-END(498216337428)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(493921370132)
                    this.X509CertificateImmutableDiagId = "SYSLIB0026";
                    //--TRIMMABLE-BOUNDARY-END(493921370132)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(283467972628)
                    this.PublicKeyPropertyMessage = "PublicKey.Key is obsolete. Use the appropriate method to get the public key, such as GetRSAPublicKey.";
                    //--TRIMMABLE-BOUNDARY-END(283467972628)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(279173005332)
                    this.PublicKeyPropertyDiagId = "SYSLIB0027";
                    //--TRIMMABLE-BOUNDARY-END(279173005332)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(506806272020)
                    this.X509CertificatePrivateKeyMessage = "X509Certificate2.PrivateKey is obsolete. Use the appropriate method to get the private key, such as GetRSAPrivateKey, or use the CopyWithPrivateKey method to create a new instance with a private key.";
                    //--TRIMMABLE-BOUNDARY-END(506806272020)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(502511304724)
                    this.X509CertificatePrivateKeyDiagId = "SYSLIB0028";
                    //--TRIMMABLE-BOUNDARY-END(502511304724)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(274878038036)
                    this.ProduceLegacyHmacValuesMessage = "ProduceLegacyHmacValues is obsolete. Producing legacy HMAC values is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(274878038036)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(270583070740)
                    this.ProduceLegacyHmacValuesDiagId = "SYSLIB0029";
                    //--TRIMMABLE-BOUNDARY-END(270583070740)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(481036468244)
                    this.UseManagedSha1Message = "HMACSHA1 always uses the algorithm implementation provided by the platform. Use a constructor without the useManagedSha1 parameter.";
                    //--TRIMMABLE-BOUNDARY-END(481036468244)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(476741500948)
                    this.UseManagedSha1DiagId = "SYSLIB0030";
                    //--TRIMMABLE-BOUNDARY-END(476741500948)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(128849149972)
                    this.CryptoConfigEncodeOIDMessage = "EncodeOID is obsolete. Use the ASN.1 functionality provided in System.Formats.Asn1.";
                    //--TRIMMABLE-BOUNDARY-END(128849149972)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(124554182676)
                    this.CryptoConfigEncodeOIDDiagId = "SYSLIB0031";
                    //--TRIMMABLE-BOUNDARY-END(124554182676)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(111669280788)
                    this.CorruptedStateRecoveryMessage = "Recovery from corrupted process state exceptions is not supported; HandleProcessCorruptedStateExceptionsAttribute is ignored.";
                    //--TRIMMABLE-BOUNDARY-END(111669280788)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(107374313492)
                    this.CorruptedStateRecoveryDiagId = "SYSLIB0032";
                    //--TRIMMABLE-BOUNDARY-END(107374313492)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(335007580180)
                    this.Rfc2898CryptDeriveKeyMessage = "Rfc2898DeriveBytes.CryptDeriveKey is obsolete and is not supported. Use PasswordDeriveBytes.CryptDeriveKey instead.";
                    //--TRIMMABLE-BOUNDARY-END(335007580180)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(330712612884)
                    this.Rfc2898CryptDeriveKeyDiagId = "SYSLIB0033";
                    //--TRIMMABLE-BOUNDARY-END(330712612884)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(68719607828)
                    this.CmsSignerCspParamsCtorMessage = "CmsSigner(CspParameters) is obsolete and is not supported. Use an alternative constructor instead.";
                    //--TRIMMABLE-BOUNDARY-END(68719607828)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(64424640532)
                    this.CmsSignerCspParamsCtorDiagId = "SYSLIB0034";
                    //--TRIMMABLE-BOUNDARY-END(64424640532)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(390842155028)
                    this.SignerInfoCounterSigMessage = "ComputeCounterSignature without specifying a CmsSigner is obsolete and is not supported. Use the overload that accepts a CmsSigner.";
                    //--TRIMMABLE-BOUNDARY-END(390842155028)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(386547187732)
                    this.SignerInfoCounterSigDiagId = "SYSLIB0035";
                    //--TRIMMABLE-BOUNDARY-END(386547187732)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(309237776404)
                    this.RegexCompileToAssemblyMessage = "Regex.CompileToAssembly is obsolete and not supported. Use the GeneratedRegexAttribute with the regular expression source generator instead.";
                    //--TRIMMABLE-BOUNDARY-END(309237776404)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(304942809108)
                    this.RegexCompileToAssemblyDiagId = "SYSLIB0036";
                    //--TRIMMABLE-BOUNDARY-END(304942809108)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(42949804052)
                    this.AssemblyNameMembersMessage = "AssemblyName members HashAlgorithm, ProcessorArchitecture, and VersionCompatibility are obsolete and not supported.";
                    //--TRIMMABLE-BOUNDARY-END(42949804052)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(38654836756)
                    this.AssemblyNameMembersDiagId = "SYSLIB0037";
                    //--TRIMMABLE-BOUNDARY-END(38654836756)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(416611958804)
                    this.SystemDataSerializationFormatBinaryMessage = "SerializationFormat.Binary is obsolete and should not be used. See https://aka.ms/serializationformat-binary-obsolete for more information.";
                    //--TRIMMABLE-BOUNDARY-END(416611958804)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(412316991508)
                    this.SystemDataSerializationFormatBinaryDiagId = "SYSLIB0038";
                    //--TRIMMABLE-BOUNDARY-END(412316991508)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(472446533652)
                    this.TlsVersion10and11Message = "TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.";
                    //--TRIMMABLE-BOUNDARY-END(472446533652)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(468151566356)
                    this.TlsVersion10and11DiagId = "SYSLIB0039";
                    //--TRIMMABLE-BOUNDARY-END(468151566356)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(188978692116)
                    this.EncryptionPolicyMessage = "EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.";
                    //--TRIMMABLE-BOUNDARY-END(188978692116)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(184683724820)
                    this.EncryptionPolicyDiagId = "SYSLIB0040";
                    //--TRIMMABLE-BOUNDARY-END(184683724820)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(171798822932)
                    this.EccXmlExportImportMessage = "ToXmlString and FromXmlString have no implementation for ECC types, and are obsolete. Use a standard import and export format such as ExportSubjectPublicKeyInfo or ImportSubjectPublicKeyInfo for public keys and ExportPkcs8PrivateKey or ImportPkcs8PrivateKey for private keys.";
                    //--TRIMMABLE-BOUNDARY-END(171798822932)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(167503855636)
                    this.EccXmlExportImportDiagId = "SYSLIB0042";
                    //--TRIMMABLE-BOUNDARY-END(167503855636)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(180388757524)
                    this.EcDhPublicKeyBlobMessage = "ECDiffieHellmanPublicKey.ToByteArray() and the associated constructor do not have a consistent and interoperable implementation on all platforms. Use ECDiffieHellmanPublicKey.ExportSubjectPublicKeyInfo() instead.";
                    //--TRIMMABLE-BOUNDARY-END(180388757524)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(176093790228)
                    this.EcDhPublicKeyBlobDiagId = "SYSLIB0043";
                    //--TRIMMABLE-BOUNDARY-END(176093790228)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(34359869460)
                    this.AssemblyNameCodeBaseMessage = "AssemblyName.CodeBase and AssemblyName.EscapedCodeBase are obsolete. Using them for loading an assembly is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(34359869460)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(30064902164)
                    this.AssemblyNameCodeBaseDiagId = "SYSLIB0044";
                    //--TRIMMABLE-BOUNDARY-END(30064902164)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(137439084564)
                    this.CryptoStringFactoryMessage = "Cryptographic factory methods accepting an algorithm name are obsolete. Use the parameterless Create factory method on the algorithm type instead.";
                    //--TRIMMABLE-BOUNDARY-END(137439084564)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(133144117268)
                    this.CryptoStringFactoryDiagId = "SYSLIB0045";
                    //--TRIMMABLE-BOUNDARY-END(133144117268)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(103079346196)
                    this.ControlledExecutionRunMessage = "ControlledExecution.Run method may corrupt the process and should not be used in production code.";
                    //--TRIMMABLE-BOUNDARY-END(103079346196)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(98784378900)
                    this.ControlledExecutionRunDiagId = "SYSLIB0046";
                    //--TRIMMABLE-BOUNDARY-END(98784378900)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(523986141204)
                    this.XmlSecureResolverMessage = "XmlSecureResolver is obsolete. Use XmlResolver.ThrowingResolver instead when attempting to forbid XML external entity resolution.";
                    //--TRIMMABLE-BOUNDARY-END(523986141204)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(519691173908)
                    this.XmlSecureResolverDiagId = "SYSLIB0047";
                    //--TRIMMABLE-BOUNDARY-END(519691173908)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(369367318548)
                    this.RsaEncryptDecryptValueMessage = "RSA.EncryptValue and DecryptValue are not supported and throw NotSupportedException. Use RSA.Encrypt and RSA.Decrypt instead.";
                    //--TRIMMABLE-BOUNDARY-END(369367318548)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(365072351252)
                    this.RsaEncryptDecryptDiagId = "SYSLIB0048";
                    //--TRIMMABLE-BOUNDARY-END(365072351252)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(223338430484)
                    this.JsonSerializerOptionsAddContextMessage = "JsonSerializerOptions.AddContext is obsolete. To register a JsonSerializerContext, use either the TypeInfoResolver or TypeInfoResolverChain properties.";
                    //--TRIMMABLE-BOUNDARY-END(223338430484)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(219043463188)
                    this.JsonSerializerOptionsAddContextDiagId = "SYSLIB0049";
                    //--TRIMMABLE-BOUNDARY-END(219043463188)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(249108234260)
                    this.LegacyFormatterMessage = "Formatter-based serialization is obsolete and should not be used.";
                    //--TRIMMABLE-BOUNDARY-END(249108234260)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(236223332372)
                    this.LegacyFormatterDiagId = "SYSLIB0050";
                    //--TRIMMABLE-BOUNDARY-END(236223332372)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(244813266964)
                    this.LegacyFormatterImplMessage = "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.";
                    //--TRIMMABLE-BOUNDARY-END(244813266964)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(240518299668)
                    this.LegacyFormatterImplDiagId = "SYSLIB0051";
                    //--TRIMMABLE-BOUNDARY-END(240518299668)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(317827710996)
                    this.RegexExtensibilityImplMessage = "This API supports obsolete mechanisms for Regex extensibility. It is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(317827710996)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(313532743700)
                    this.RegexExtensibilityDiagId = "SYSLIB0052";
                    //--TRIMMABLE-BOUNDARY-END(313532743700)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8590065684)
                    this.AesGcmTagConstructorMessage = "AesGcm should indicate the required tag size for encryption and decryption. Use a constructor that accepts the tag size.";
                    //--TRIMMABLE-BOUNDARY-END(8590065684)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(4295098388)
                    this.AesGcmTagConstructorDiagId = "SYSLIB0053";
                    //--TRIMMABLE-BOUNDARY-END(4295098388)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(455266664468)
                    this.ThreadVolatileReadWriteMessage = "Thread.VolatileRead and Thread.VolatileWrite are obsolete. Use Volatile.Read or Volatile.Write respectively instead.";
                    //--TRIMMABLE-BOUNDARY-END(455266664468)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(450971697172)
                    this.ThreadVolatileReadWriteDiagId = "SYSLIB0054";
                    //--TRIMMABLE-BOUNDARY-END(450971697172)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25769934868)
                    this.ArmIntrinsicPerformsUnsignedOperationMessage = "The underlying hardware instruction does not perform a signed saturate narrowing operation, and it always returns an unsigned result. Use the unsigned overload instead.";
                    //--TRIMMABLE-BOUNDARY-END(25769934868)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21474967572)
                    this.ArmIntrinsicPerformsUnsignedOperationDiagId = "SYSLIB0055";
                    //--TRIMMABLE-BOUNDARY-END(21474967572)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(257698168852)
                    this.LoadFromHashAlgorithmMessage = "LoadFrom with a custom AssemblyHashAlgorithm is obsolete. Use overloads without an AssemblyHashAlgorithm.";
                    //--TRIMMABLE-BOUNDARY-END(257698168852)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(253403201556)
                    this.LoadFromHashAlgorithmDiagId = "SYSLIB0056";
                    //--TRIMMABLE-BOUNDARY-END(253403201556)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(515396206612)
                    this.X509CtorCertDataObsoleteMessage = "Loading certificate data through the constructor or Import is obsolete. Use X509CertificateLoader instead to load certificates.";
                    //--TRIMMABLE-BOUNDARY-END(515396206612)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(511101239316)
                    this.X509CtorCertDataObsoleteDiagId = "SYSLIB0057";
                    //--TRIMMABLE-BOUNDARY-END(511101239316)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(463856599060)
                    this.TlsCipherAlgorithmEnumsMessage = "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.";
                    //--TRIMMABLE-BOUNDARY-END(463856599060)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(459561631764)
                    this.TlsCipherAlgorithmEnumsDiagId = "SYSLIB0058";
                    //--TRIMMABLE-BOUNDARY-END(459561631764)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(425201893396)
                    this.SystemEventsEventsThreadShutdownMessage = "SystemEvents.EventsThreadShutdown callbacks are not run before the process exits. Use AppDomain.ProcessExit instead.";
                    //--TRIMMABLE-BOUNDARY-END(425201893396)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(420906926100)
                    this.SystemEventsEventsThreadShutdownDiagId = "SYSLIB0059";
                    //--TRIMMABLE-BOUNDARY-END(420906926100)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(343597514772)
                    this.Rfc2898DeriveBytesCtorMessage = "The constructors on Rfc2898DeriveBytes are obsolete. Use the static Pbkdf2 method instead.";
                    //--TRIMMABLE-BOUNDARY-END(343597514772)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(339302547476)
                    this.Rfc2898DeriveBytesCtorDiagId = "SYSLIB0060";
                    //--TRIMMABLE-BOUNDARY-END(339302547476)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(292057907220)
                    this.QueryableMinByMaxByTSourceObsoleteMessage = "The Queryable MinBy and MaxBy taking an IComparer<TSource> are obsolete. Use the new ones that take an IComparer<TKey>.";
                    //--TRIMMABLE-BOUNDARY-END(292057907220)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(287762939924)
                    this.QueryableMinByMaxByTSourceObsoleteDiagId = "SYSLIB0061";
                    //--TRIMMABLE-BOUNDARY-END(287762939924)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(532576075796)
                    this.XsltSettingsEnableScriptMessage = "XSLT Script blocks are not supported.";
                    //--TRIMMABLE-BOUNDARY-END(532576075796)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(528281108500)
                    this.XsltSettingsEnableScriptDiagId = "SYSLIB0062";
                    //--TRIMMABLE-BOUNDARY-END(528281108500)
                    
                }
            }
            static $h = 131092;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(382252220436),
    {
      "t": 1310721,
      "n": "SharedUrlFormat",
      "d": 131092,
      "h": 382252220436,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(382252220436),
//--TRIMMABLE-BOUNDARY-START(433791827988),
    {
      "t": 1310721,
      "n": "SystemTextEncodingUTF7Message",
      "d": 131092,
      "h": 433791827988,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(433791827988),
//--TRIMMABLE-BOUNDARY-START(429496860692),
    {
      "t": 1310721,
      "n": "SystemTextEncodingUTF7DiagId",
      "d": 131092,
      "h": 429496860692,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(429496860692),
//--TRIMMABLE-BOUNDARY-START(266288103444),
    {
      "t": 1310721,
      "n": "PrincipalPermissionAttributeMessage",
      "d": 131092,
      "h": 266288103444,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(266288103444),
//--TRIMMABLE-BOUNDARY-START(261993136148),
    {
      "t": 1310721,
      "n": "PrincipalPermissionAttributeDiagId",
      "d": 131092,
      "h": 261993136148,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(261993136148),
//--TRIMMABLE-BOUNDARY-START(77309542420),
    {
      "t": 1310721,
      "n": "CodeAccessSecurityMessage",
      "d": 131092,
      "h": 77309542420,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(77309542420),
//--TRIMMABLE-BOUNDARY-START(73014575124),
    {
      "t": 1310721,
      "n": "CodeAccessSecurityDiagId",
      "d": 131092,
      "h": 73014575124,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(73014575124),
//--TRIMMABLE-BOUNDARY-START(94489411604),
    {
      "t": 1310721,
      "n": "ConstrainedExecutionRegionMessage",
      "d": 131092,
      "h": 94489411604,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(94489411604),
//--TRIMMABLE-BOUNDARY-START(90194444308),
    {
      "t": 1310721,
      "n": "ConstrainedExecutionRegionDiagId",
      "d": 131092,
      "h": 90194444308,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(90194444308),
//--TRIMMABLE-BOUNDARY-START(214748495892),
    {
      "t": 1310721,
      "n": "GlobalAssemblyCacheMessage",
      "d": 131092,
      "h": 214748495892,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(214748495892),
//--TRIMMABLE-BOUNDARY-START(210453528596),
    {
      "t": 1310721,
      "n": "GlobalAssemblyCacheDiagId",
      "d": 131092,
      "h": 210453528596,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(210453528596),
//--TRIMMABLE-BOUNDARY-START(442381762580),
    {
      "t": 1310721,
      "n": "ThreadAbortMessage",
      "d": 131092,
      "h": 442381762580,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(442381762580),
//--TRIMMABLE-BOUNDARY-START(446676729876),
    {
      "t": 1310721,
      "n": "ThreadResetAbortMessage",
      "d": 131092,
      "h": 446676729876,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(446676729876),
//--TRIMMABLE-BOUNDARY-START(438086795284),
    {
      "t": 1310721,
      "n": "ThreadAbortDiagId",
      "d": 131092,
      "h": 438086795284,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(438086795284),
//--TRIMMABLE-BOUNDARY-START(146029019156),
    {
      "t": 1310721,
      "n": "DefaultCryptoAlgorithmsMessage",
      "d": 131092,
      "h": 146029019156,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(146029019156),
//--TRIMMABLE-BOUNDARY-START(141734051860),
    {
      "t": 1310721,
      "n": "DefaultCryptoAlgorithmsDiagId",
      "d": 131092,
      "h": 141734051860,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(141734051860),
//--TRIMMABLE-BOUNDARY-START(120259215380),
    {
      "t": 1310721,
      "n": "CreatePdbGeneratorMessage",
      "d": 131092,
      "h": 120259215380,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(120259215380),
//--TRIMMABLE-BOUNDARY-START(115964248084),
    {
      "t": 1310721,
      "n": "CreatePdbGeneratorDiagId",
      "d": 131092,
      "h": 115964248084,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(115964248084),
//--TRIMMABLE-BOUNDARY-START(51539738644),
    {
      "t": 1310721,
      "n": "AuthenticationManagerMessage",
      "d": 131092,
      "h": 51539738644,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(51539738644),
//--TRIMMABLE-BOUNDARY-START(47244771348),
    {
      "t": 1310721,
      "n": "AuthenticationManagerDiagId",
      "d": 131092,
      "h": 47244771348,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(47244771348),
//--TRIMMABLE-BOUNDARY-START(326417645588),
    {
      "t": 1310721,
      "n": "RemotingApisMessage",
      "d": 131092,
      "h": 326417645588,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(326417645588),
//--TRIMMABLE-BOUNDARY-START(322122678292),
    {
      "t": 1310721,
      "n": "RemotingApisDiagId",
      "d": 131092,
      "h": 322122678292,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(322122678292),
//--TRIMMABLE-BOUNDARY-START(60129673236),
    {
      "t": 1310721,
      "n": "BinaryFormatterMessage",
      "d": 131092,
      "h": 60129673236,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(60129673236),
//--TRIMMABLE-BOUNDARY-START(55834705940),
    {
      "t": 1310721,
      "n": "BinaryFormatterDiagId",
      "d": 131092,
      "h": 55834705940,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(55834705940),
//--TRIMMABLE-BOUNDARY-START(85899477012),
    {
      "t": 1310721,
      "n": "CodeBaseMessage",
      "d": 131092,
      "h": 85899477012,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(85899477012),
//--TRIMMABLE-BOUNDARY-START(81604509716),
    {
      "t": 1310721,
      "n": "CodeBaseDiagId",
      "d": 131092,
      "h": 81604509716,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(81604509716),
//--TRIMMABLE-BOUNDARY-START(197568626708),
    {
      "t": 1310721,
      "n": "EscapeUriStringMessage",
      "d": 131092,
      "h": 197568626708,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(197568626708),
//--TRIMMABLE-BOUNDARY-START(193273659412),
    {
      "t": 1310721,
      "n": "EscapeUriStringDiagId",
      "d": 131092,
      "h": 193273659412,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(193273659412),
//--TRIMMABLE-BOUNDARY-START(489626402836),
    {
      "t": 1310721,
      "n": "WebRequestMessage",
      "d": 131092,
      "h": 489626402836,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(489626402836),
//--TRIMMABLE-BOUNDARY-START(485331435540),
    {
      "t": 1310721,
      "n": "WebRequestDiagId",
      "d": 131092,
      "h": 485331435540,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(485331435540),
//--TRIMMABLE-BOUNDARY-START(163208888340),
    {
      "t": 1310721,
      "n": "DisablePrivateReflectionAttributeMessage",
      "d": 131092,
      "h": 163208888340,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(163208888340),
//--TRIMMABLE-BOUNDARY-START(158913921044),
    {
      "t": 1310721,
      "n": "DisablePrivateReflectionAttributeDiagId",
      "d": 131092,
      "h": 158913921044,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(158913921044),
//--TRIMMABLE-BOUNDARY-START(206158561300),
    {
      "t": 1310721,
      "n": "GetContextInfoMessage",
      "d": 131092,
      "h": 206158561300,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(206158561300),
//--TRIMMABLE-BOUNDARY-START(201863594004),
    {
      "t": 1310721,
      "n": "GetContextInfoDiagId",
      "d": 131092,
      "h": 201863594004,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(201863594004),
//--TRIMMABLE-BOUNDARY-START(399432089620),
    {
      "t": 1310721,
      "n": "StrongNameKeyPairMessage",
      "d": 131092,
      "h": 399432089620,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(399432089620),
//--TRIMMABLE-BOUNDARY-START(395137122324),
    {
      "t": 1310721,
      "n": "StrongNameKeyPairDiagId",
      "d": 131092,
      "h": 395137122324,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(395137122324),
//--TRIMMABLE-BOUNDARY-START(300647841812),
    {
      "t": 1310721,
      "n": "ReflectionOnlyLoadingMessage",
      "d": 131092,
      "h": 300647841812,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(300647841812),
//--TRIMMABLE-BOUNDARY-START(296352874516),
    {
      "t": 1310721,
      "n": "ReflectionOnlyLoadingDiagId",
      "d": 131092,
      "h": 296352874516,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(296352874516),
//--TRIMMABLE-BOUNDARY-START(377957253140),
    {
      "t": 1310721,
      "n": "RuntimeEnvironmentMessage",
      "d": 131092,
      "h": 377957253140,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(377957253140),
//--TRIMMABLE-BOUNDARY-START(373662285844),
    {
      "t": 1310721,
      "n": "RuntimeEnvironmentDiagId",
      "d": 131092,
      "h": 373662285844,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(373662285844),
//--TRIMMABLE-BOUNDARY-START(231928365076),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsIgnoreNullValuesMessage",
      "d": 131092,
      "h": 231928365076,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(231928365076),
//--TRIMMABLE-BOUNDARY-START(227633397780),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsIgnoreNullValuesDiagId",
      "d": 131092,
      "h": 227633397780,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(227633397780),
//--TRIMMABLE-BOUNDARY-START(154618953748),
    {
      "t": 1310721,
      "n": "DerivedCryptographicTypesMessage",
      "d": 131092,
      "h": 154618953748,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(154618953748),
//--TRIMMABLE-BOUNDARY-START(150323986452),
    {
      "t": 1310721,
      "n": "DerivedCryptographicTypesDiagId",
      "d": 131092,
      "h": 150323986452,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(150323986452),
//--TRIMMABLE-BOUNDARY-START(352187449364),
    {
      "t": 1310721,
      "n": "RijndaelMessage",
      "d": 131092,
      "h": 352187449364,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(352187449364),
//--TRIMMABLE-BOUNDARY-START(347892482068),
    {
      "t": 1310721,
      "n": "RijndaelDiagId",
      "d": 131092,
      "h": 347892482068,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(347892482068),
//--TRIMMABLE-BOUNDARY-START(360777383956),
    {
      "t": 1310721,
      "n": "RNGCryptoServiceProviderMessage",
      "d": 131092,
      "h": 360777383956,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(360777383956),
//--TRIMMABLE-BOUNDARY-START(356482416660),
    {
      "t": 1310721,
      "n": "RNGCryptoServiceProviderDiagId",
      "d": 131092,
      "h": 356482416660,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(356482416660),
//--TRIMMABLE-BOUNDARY-START(17180000276),
    {
      "t": 1310721,
      "n": "AppDomainCreateUnloadMessage",
      "d": 131092,
      "h": 17180000276,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(17180000276),
//--TRIMMABLE-BOUNDARY-START(12885032980),
    {
      "t": 1310721,
      "n": "AppDomainCreateUnloadDiagId",
      "d": 131092,
      "h": 12885032980,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(12885032980),
//--TRIMMABLE-BOUNDARY-START(408022024212),
    {
      "t": 1310721,
      "n": "SuppressIldasmAttributeMessage",
      "d": 131092,
      "h": 408022024212,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(408022024212),
//--TRIMMABLE-BOUNDARY-START(403727056916),
    {
      "t": 1310721,
      "n": "SuppressIldasmAttributeDiagId",
      "d": 131092,
      "h": 403727056916,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(403727056916),
//--TRIMMABLE-BOUNDARY-START(498216337428),
    {
      "t": 1310721,
      "n": "X509CertificateImmutableMessage",
      "d": 131092,
      "h": 498216337428,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(498216337428),
//--TRIMMABLE-BOUNDARY-START(493921370132),
    {
      "t": 1310721,
      "n": "X509CertificateImmutableDiagId",
      "d": 131092,
      "h": 493921370132,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(493921370132),
//--TRIMMABLE-BOUNDARY-START(283467972628),
    {
      "t": 1310721,
      "n": "PublicKeyPropertyMessage",
      "d": 131092,
      "h": 283467972628,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(283467972628),
//--TRIMMABLE-BOUNDARY-START(279173005332),
    {
      "t": 1310721,
      "n": "PublicKeyPropertyDiagId",
      "d": 131092,
      "h": 279173005332,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(279173005332),
//--TRIMMABLE-BOUNDARY-START(506806272020),
    {
      "t": 1310721,
      "n": "X509CertificatePrivateKeyMessage",
      "d": 131092,
      "h": 506806272020,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(506806272020),
//--TRIMMABLE-BOUNDARY-START(502511304724),
    {
      "t": 1310721,
      "n": "X509CertificatePrivateKeyDiagId",
      "d": 131092,
      "h": 502511304724,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(502511304724),
//--TRIMMABLE-BOUNDARY-START(274878038036),
    {
      "t": 1310721,
      "n": "ProduceLegacyHmacValuesMessage",
      "d": 131092,
      "h": 274878038036,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(274878038036),
//--TRIMMABLE-BOUNDARY-START(270583070740),
    {
      "t": 1310721,
      "n": "ProduceLegacyHmacValuesDiagId",
      "d": 131092,
      "h": 270583070740,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(270583070740),
//--TRIMMABLE-BOUNDARY-START(481036468244),
    {
      "t": 1310721,
      "n": "UseManagedSha1Message",
      "d": 131092,
      "h": 481036468244,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(481036468244),
//--TRIMMABLE-BOUNDARY-START(476741500948),
    {
      "t": 1310721,
      "n": "UseManagedSha1DiagId",
      "d": 131092,
      "h": 476741500948,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(476741500948),
//--TRIMMABLE-BOUNDARY-START(128849149972),
    {
      "t": 1310721,
      "n": "CryptoConfigEncodeOIDMessage",
      "d": 131092,
      "h": 128849149972,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(128849149972),
//--TRIMMABLE-BOUNDARY-START(124554182676),
    {
      "t": 1310721,
      "n": "CryptoConfigEncodeOIDDiagId",
      "d": 131092,
      "h": 124554182676,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(124554182676),
//--TRIMMABLE-BOUNDARY-START(111669280788),
    {
      "t": 1310721,
      "n": "CorruptedStateRecoveryMessage",
      "d": 131092,
      "h": 111669280788,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(111669280788),
//--TRIMMABLE-BOUNDARY-START(107374313492),
    {
      "t": 1310721,
      "n": "CorruptedStateRecoveryDiagId",
      "d": 131092,
      "h": 107374313492,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(107374313492),
//--TRIMMABLE-BOUNDARY-START(335007580180),
    {
      "t": 1310721,
      "n": "Rfc2898CryptDeriveKeyMessage",
      "d": 131092,
      "h": 335007580180,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(335007580180),
//--TRIMMABLE-BOUNDARY-START(330712612884),
    {
      "t": 1310721,
      "n": "Rfc2898CryptDeriveKeyDiagId",
      "d": 131092,
      "h": 330712612884,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(330712612884),
//--TRIMMABLE-BOUNDARY-START(68719607828),
    {
      "t": 1310721,
      "n": "CmsSignerCspParamsCtorMessage",
      "d": 131092,
      "h": 68719607828,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(68719607828),
//--TRIMMABLE-BOUNDARY-START(64424640532),
    {
      "t": 1310721,
      "n": "CmsSignerCspParamsCtorDiagId",
      "d": 131092,
      "h": 64424640532,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(64424640532),
//--TRIMMABLE-BOUNDARY-START(390842155028),
    {
      "t": 1310721,
      "n": "SignerInfoCounterSigMessage",
      "d": 131092,
      "h": 390842155028,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(390842155028),
//--TRIMMABLE-BOUNDARY-START(386547187732),
    {
      "t": 1310721,
      "n": "SignerInfoCounterSigDiagId",
      "d": 131092,
      "h": 386547187732,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(386547187732),
//--TRIMMABLE-BOUNDARY-START(309237776404),
    {
      "t": 1310721,
      "n": "RegexCompileToAssemblyMessage",
      "d": 131092,
      "h": 309237776404,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(309237776404),
//--TRIMMABLE-BOUNDARY-START(304942809108),
    {
      "t": 1310721,
      "n": "RegexCompileToAssemblyDiagId",
      "d": 131092,
      "h": 304942809108,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(304942809108),
//--TRIMMABLE-BOUNDARY-START(42949804052),
    {
      "t": 1310721,
      "n": "AssemblyNameMembersMessage",
      "d": 131092,
      "h": 42949804052,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(42949804052),
//--TRIMMABLE-BOUNDARY-START(38654836756),
    {
      "t": 1310721,
      "n": "AssemblyNameMembersDiagId",
      "d": 131092,
      "h": 38654836756,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(38654836756),
//--TRIMMABLE-BOUNDARY-START(416611958804),
    {
      "t": 1310721,
      "n": "SystemDataSerializationFormatBinaryMessage",
      "d": 131092,
      "h": 416611958804,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(416611958804),
//--TRIMMABLE-BOUNDARY-START(412316991508),
    {
      "t": 1310721,
      "n": "SystemDataSerializationFormatBinaryDiagId",
      "d": 131092,
      "h": 412316991508,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(412316991508),
//--TRIMMABLE-BOUNDARY-START(472446533652),
    {
      "t": 1310721,
      "n": "TlsVersion10and11Message",
      "d": 131092,
      "h": 472446533652,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(472446533652),
//--TRIMMABLE-BOUNDARY-START(468151566356),
    {
      "t": 1310721,
      "n": "TlsVersion10and11DiagId",
      "d": 131092,
      "h": 468151566356,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(468151566356),
//--TRIMMABLE-BOUNDARY-START(188978692116),
    {
      "t": 1310721,
      "n": "EncryptionPolicyMessage",
      "d": 131092,
      "h": 188978692116,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(188978692116),
//--TRIMMABLE-BOUNDARY-START(184683724820),
    {
      "t": 1310721,
      "n": "EncryptionPolicyDiagId",
      "d": 131092,
      "h": 184683724820,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(184683724820),
//--TRIMMABLE-BOUNDARY-START(171798822932),
    {
      "t": 1310721,
      "n": "EccXmlExportImportMessage",
      "d": 131092,
      "h": 171798822932,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(171798822932),
//--TRIMMABLE-BOUNDARY-START(167503855636),
    {
      "t": 1310721,
      "n": "EccXmlExportImportDiagId",
      "d": 131092,
      "h": 167503855636,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(167503855636),
//--TRIMMABLE-BOUNDARY-START(180388757524),
    {
      "t": 1310721,
      "n": "EcDhPublicKeyBlobMessage",
      "d": 131092,
      "h": 180388757524,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(180388757524),
//--TRIMMABLE-BOUNDARY-START(176093790228),
    {
      "t": 1310721,
      "n": "EcDhPublicKeyBlobDiagId",
      "d": 131092,
      "h": 176093790228,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(176093790228),
//--TRIMMABLE-BOUNDARY-START(34359869460),
    {
      "t": 1310721,
      "n": "AssemblyNameCodeBaseMessage",
      "d": 131092,
      "h": 34359869460,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(34359869460),
//--TRIMMABLE-BOUNDARY-START(30064902164),
    {
      "t": 1310721,
      "n": "AssemblyNameCodeBaseDiagId",
      "d": 131092,
      "h": 30064902164,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(30064902164),
//--TRIMMABLE-BOUNDARY-START(137439084564),
    {
      "t": 1310721,
      "n": "CryptoStringFactoryMessage",
      "d": 131092,
      "h": 137439084564,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(137439084564),
//--TRIMMABLE-BOUNDARY-START(133144117268),
    {
      "t": 1310721,
      "n": "CryptoStringFactoryDiagId",
      "d": 131092,
      "h": 133144117268,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(133144117268),
//--TRIMMABLE-BOUNDARY-START(103079346196),
    {
      "t": 1310721,
      "n": "ControlledExecutionRunMessage",
      "d": 131092,
      "h": 103079346196,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(103079346196),
//--TRIMMABLE-BOUNDARY-START(98784378900),
    {
      "t": 1310721,
      "n": "ControlledExecutionRunDiagId",
      "d": 131092,
      "h": 98784378900,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(98784378900),
//--TRIMMABLE-BOUNDARY-START(523986141204),
    {
      "t": 1310721,
      "n": "XmlSecureResolverMessage",
      "d": 131092,
      "h": 523986141204,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(523986141204),
//--TRIMMABLE-BOUNDARY-START(519691173908),
    {
      "t": 1310721,
      "n": "XmlSecureResolverDiagId",
      "d": 131092,
      "h": 519691173908,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(519691173908),
//--TRIMMABLE-BOUNDARY-START(369367318548),
    {
      "t": 1310721,
      "n": "RsaEncryptDecryptValueMessage",
      "d": 131092,
      "h": 369367318548,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(369367318548),
//--TRIMMABLE-BOUNDARY-START(365072351252),
    {
      "t": 1310721,
      "n": "RsaEncryptDecryptDiagId",
      "d": 131092,
      "h": 365072351252,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(365072351252),
//--TRIMMABLE-BOUNDARY-START(223338430484),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsAddContextMessage",
      "d": 131092,
      "h": 223338430484,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(223338430484),
//--TRIMMABLE-BOUNDARY-START(219043463188),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsAddContextDiagId",
      "d": 131092,
      "h": 219043463188,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(219043463188),
//--TRIMMABLE-BOUNDARY-START(249108234260),
    {
      "t": 1310721,
      "n": "LegacyFormatterMessage",
      "d": 131092,
      "h": 249108234260,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(249108234260),
//--TRIMMABLE-BOUNDARY-START(236223332372),
    {
      "t": 1310721,
      "n": "LegacyFormatterDiagId",
      "d": 131092,
      "h": 236223332372,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(236223332372),
//--TRIMMABLE-BOUNDARY-START(244813266964),
    {
      "t": 1310721,
      "n": "LegacyFormatterImplMessage",
      "d": 131092,
      "h": 244813266964,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(244813266964),
//--TRIMMABLE-BOUNDARY-START(240518299668),
    {
      "t": 1310721,
      "n": "LegacyFormatterImplDiagId",
      "d": 131092,
      "h": 240518299668,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(240518299668),
//--TRIMMABLE-BOUNDARY-START(317827710996),
    {
      "t": 1310721,
      "n": "RegexExtensibilityImplMessage",
      "d": 131092,
      "h": 317827710996,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(317827710996),
//--TRIMMABLE-BOUNDARY-START(313532743700),
    {
      "t": 1310721,
      "n": "RegexExtensibilityDiagId",
      "d": 131092,
      "h": 313532743700,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(313532743700),
//--TRIMMABLE-BOUNDARY-START(8590065684),
    {
      "t": 1310721,
      "n": "AesGcmTagConstructorMessage",
      "d": 131092,
      "h": 8590065684,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(8590065684),
//--TRIMMABLE-BOUNDARY-START(4295098388),
    {
      "t": 1310721,
      "n": "AesGcmTagConstructorDiagId",
      "d": 131092,
      "h": 4295098388,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(4295098388),
//--TRIMMABLE-BOUNDARY-START(455266664468),
    {
      "t": 1310721,
      "n": "ThreadVolatileReadWriteMessage",
      "d": 131092,
      "h": 455266664468,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(455266664468),
//--TRIMMABLE-BOUNDARY-START(450971697172),
    {
      "t": 1310721,
      "n": "ThreadVolatileReadWriteDiagId",
      "d": 131092,
      "h": 450971697172,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(450971697172),
//--TRIMMABLE-BOUNDARY-START(25769934868),
    {
      "t": 1310721,
      "n": "ArmIntrinsicPerformsUnsignedOperationMessage",
      "d": 131092,
      "h": 25769934868,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(25769934868),
//--TRIMMABLE-BOUNDARY-START(21474967572),
    {
      "t": 1310721,
      "n": "ArmIntrinsicPerformsUnsignedOperationDiagId",
      "d": 131092,
      "h": 21474967572,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(21474967572),
//--TRIMMABLE-BOUNDARY-START(257698168852),
    {
      "t": 1310721,
      "n": "LoadFromHashAlgorithmMessage",
      "d": 131092,
      "h": 257698168852,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(257698168852),
//--TRIMMABLE-BOUNDARY-START(253403201556),
    {
      "t": 1310721,
      "n": "LoadFromHashAlgorithmDiagId",
      "d": 131092,
      "h": 253403201556,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(253403201556),
//--TRIMMABLE-BOUNDARY-START(515396206612),
    {
      "t": 1310721,
      "n": "X509CtorCertDataObsoleteMessage",
      "d": 131092,
      "h": 515396206612,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(515396206612),
//--TRIMMABLE-BOUNDARY-START(511101239316),
    {
      "t": 1310721,
      "n": "X509CtorCertDataObsoleteDiagId",
      "d": 131092,
      "h": 511101239316,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(511101239316),
//--TRIMMABLE-BOUNDARY-START(463856599060),
    {
      "t": 1310721,
      "n": "TlsCipherAlgorithmEnumsMessage",
      "d": 131092,
      "h": 463856599060,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(463856599060),
//--TRIMMABLE-BOUNDARY-START(459561631764),
    {
      "t": 1310721,
      "n": "TlsCipherAlgorithmEnumsDiagId",
      "d": 131092,
      "h": 459561631764,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(459561631764),
//--TRIMMABLE-BOUNDARY-START(425201893396),
    {
      "t": 1310721,
      "n": "SystemEventsEventsThreadShutdownMessage",
      "d": 131092,
      "h": 425201893396,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(425201893396),
//--TRIMMABLE-BOUNDARY-START(420906926100),
    {
      "t": 1310721,
      "n": "SystemEventsEventsThreadShutdownDiagId",
      "d": 131092,
      "h": 420906926100,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(420906926100),
//--TRIMMABLE-BOUNDARY-START(343597514772),
    {
      "t": 1310721,
      "n": "Rfc2898DeriveBytesCtorMessage",
      "d": 131092,
      "h": 343597514772,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(343597514772),
//--TRIMMABLE-BOUNDARY-START(339302547476),
    {
      "t": 1310721,
      "n": "Rfc2898DeriveBytesCtorDiagId",
      "d": 131092,
      "h": 339302547476,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(339302547476),
//--TRIMMABLE-BOUNDARY-START(292057907220),
    {
      "t": 1310721,
      "n": "QueryableMinByMaxByTSourceObsoleteMessage",
      "d": 131092,
      "h": 292057907220,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(292057907220),
//--TRIMMABLE-BOUNDARY-START(287762939924),
    {
      "t": 1310721,
      "n": "QueryableMinByMaxByTSourceObsoleteDiagId",
      "d": 131092,
      "h": 287762939924,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(287762939924),
//--TRIMMABLE-BOUNDARY-START(532576075796),
    {
      "t": 1310721,
      "n": "XsltSettingsEnableScriptMessage",
      "d": 131092,
      "h": 532576075796,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(532576075796),
//--TRIMMABLE-BOUNDARY-START(528281108500),
    {
      "t": 1310721,
      "n": "XsltSettingsEnableScriptDiagId",
      "d": 131092,
      "h": 528281108500,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(528281108500)
  ],
  "h": 131092
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Obsoletions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131092)
        
        
        //--TRIMMABLE-BOUNDARY-START(524308)
        $asm.$cls("$st.System.Threading.HostExecutionContext", ($self) => class HostExecutionContext extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295491604)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295491604);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295491604)
            
            //--TRIMMABLE-BOUNDARY-START(8590458900)
            $ctor$2(/*object?*/ state)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590458900);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.State = state;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590458900)
            
            //--TRIMMABLE-BOUNDARY-START(47245164564)
            /*object?*/ State = null;
            //--TRIMMABLE-BOUNDARY-END(47245164564)
            
            //--TRIMMABLE-BOUNDARY-START(17180393492)
            /*HostExecutionContext */ CreateCopy()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180393492);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$st.System.Threading.HostExecutionContext().$ctor$2(this.State);
            }
            //--TRIMMABLE-BOUNDARY-END(17180393492)
            
            //--TRIMMABLE-BOUNDARY-START(21475360788)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475360788);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Dispose$1(true);
            }
            //--TRIMMABLE-BOUNDARY-END(21475360788)
            
            //--TRIMMABLE-BOUNDARY-START(25770328084)
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770328084);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(25770328084)
            
            //--TRIMMABLE-BOUNDARY-START(4385144833)
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385144833);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385144833)
            
            static $h = 524308;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(47245164564),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360262676,
        "f": 50331664
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42950197268,
        "f": 83886096
      },
      "n": "State",
      "d": 524308,
      "h": 47245164564,
      "f": 2097168
    },
//--TRIMMABLE-BOUNDARY-END(47245164564)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180393492),
    {
      "r": 524308,
      "n": "CreateCopy",
      "d": 524308,
      "h": 17180393492,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17180393492),
//--TRIMMABLE-BOUNDARY-START(21475360788),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 524308,
      "h": 21475360788,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475360788),
//--TRIMMABLE-BOUNDARY-START(25770328084),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposing",
          "p": 262145
        }
      ],
      "n": "Dispose",
      "o": "@$1",
      "d": 524308,
      "h": 25770328084,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(25770328084)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295491604),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 524308,
      "h": 4295491604,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295491604),
//--TRIMMABLE-BOUNDARY-START(8590458900),
    {
      "p": [
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 524308,
      "h": 8590458900,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590458900)
  ],
  "i": [90177537
  ],
  "h": 524308
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.Threading.HostExecutionContext`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524308)
        
        
        //--TRIMMABLE-BOUNDARY-START(458772)
        $asm.$cls("$st.System.Threading.CountdownEvent", ($self) => class CountdownEvent extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180327956)
            /*int*/ _initialCount = 0;
            //--TRIMMABLE-BOUNDARY-END(17180327956)
            
            //--TRIMMABLE-BOUNDARY-START(4295426068)
            /*int*/ _currentCount = 0;
            //--TRIMMABLE-BOUNDARY-END(4295426068)
            
            //--TRIMMABLE-BOUNDARY-START(12885360660)
            /*ManualResetEventSlim*/ _event = null;
            //--TRIMMABLE-BOUNDARY-END(12885360660)
            
            //--TRIMMABLE-BOUNDARY-START(8590393364)
            /*bool*/ _disposed = false;
            //--TRIMMABLE-BOUNDARY-END(8590393364)
            
            //--TRIMMABLE-BOUNDARY-START(21475295252)
            $ctor$1(/*int*/ initialCount)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475295252);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, initialCount, "initialCount");
                    this._initialCount = initialCount;
                    this._currentCount = initialCount;
                    this._event = new $.$$.System.Threading.ManualResetEventSlim().$ctor$1();
                    if (initialCount === 0)
                    {
                        this._event.Set$1();
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475295252)
            
            //--TRIMMABLE-BOUNDARY-START(34360197140)
            /*int */ get CurrentCount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540066324);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let observedCount = this._currentCount;
                return observedCount < 0 ? 0 : observedCount;
            }
            //--TRIMMABLE-BOUNDARY-END(34360197140)
            
            //--TRIMMABLE-BOUNDARY-START(81604837396)
            /*int */ get InitialCount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130000916);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._initialCount;
            }
            //--TRIMMABLE-BOUNDARY-END(81604837396)
            
            //--TRIMMABLE-BOUNDARY-START(85899804692)
            /*bool */ get IsSet()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719935508);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (this._currentCount <= 0);
            }
            //--TRIMMABLE-BOUNDARY-END(85899804692)
            
            //--TRIMMABLE-BOUNDARY-START(141734379540)
            /*WaitHandle */ get WaitHandle()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309870100);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ObjectDisposedException.ThrowIf(this._disposed, this);
                return this._event.WaitHandle;
            }
            //--TRIMMABLE-BOUNDARY-END(141734379540)
            
            //--TRIMMABLE-BOUNDARY-START(38655164436)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655164436);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Dispose$1(true);
                $.$$.System.GC.SuppressFinalize(this);
            }
            //--TRIMMABLE-BOUNDARY-END(38655164436)
            
            //--TRIMMABLE-BOUNDARY-START(42950131732)
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950131732);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (disposing)
                {
                    this._event.Dispose();
                    this._disposed = true;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950131732)
            
            //--TRIMMABLE-BOUNDARY-START(98784706580)
            /*bool */ Signal()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784706580);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ObjectDisposedException.ThrowIf(this._disposed, this);
                $.$$.System.Diagnostics.Debug.Assert$2(this._event !== null, "_event != null");
                if (this._currentCount <= 0)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$st.System.SR.CountdownEvent_Decrement_BelowZero);
                }
                /*int*/ let newCount = $.$$.System.Threading.Interlocked.Decrement($.$ref(() => this._currentCount, ($v) => this._currentCount = $v, $.$$.System.Int32));
                if (newCount === 0)
                {
                    this._event.Set$1();
                    return true;
                }
                else if (newCount < 0)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$st.System.SR.CountdownEvent_Decrement_BelowZero);
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(98784706580)
            
            //--TRIMMABLE-BOUNDARY-START(103079673876)
            /*bool */ Signal$1(/*int*/ signalCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079673876);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$$.System.Int32, signalCount, "signalCount");
                $.$$.System.ObjectDisposedException.ThrowIf(this._disposed, this);
                $.$$.System.Diagnostics.Debug.Assert$2(this._event !== null, "_event != null");
                /*int*/ let observedCount;
                /*SpinWait*/ let spin = new $.$$.System.Threading.SpinWait();
                while(true)
                {
                    observedCount = this._currentCount;
                    if (observedCount < signalCount)
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$st.System.SR.CountdownEvent_Decrement_BelowZero);
                    }
                    if ($.$$.System.Threading.Interlocked.CompareExchange$3($.$ref(() => this._currentCount, ($v) => this._currentCount = $v, $.$$.System.Int32), ((observedCount - signalCount) | 0), observedCount) === observedCount)
                    {
                        break;
                    }
                    spin.SpinOnce$1(-1);
                }
                if (observedCount === signalCount)
                {
                    this._event.Set$1();
                    return true;
                }
                $.$$.System.Diagnostics.Debug.Assert$2(this._currentCount >= 0, "latch was decremented below zero");
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(103079673876)
            
            //--TRIMMABLE-BOUNDARY-START(25770262548)
            /*void */ AddCount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770262548);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AddCount$1(1);
            }
            //--TRIMMABLE-BOUNDARY-END(25770262548)
            
            //--TRIMMABLE-BOUNDARY-START(107374641172)
            /*bool */ TryAddCount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374641172);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.TryAddCount$1(1);
            }
            //--TRIMMABLE-BOUNDARY-END(107374641172)
            
            //--TRIMMABLE-BOUNDARY-START(30065229844)
            /*void */ AddCount$1(/*int*/ signalCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065229844);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.TryAddCount$1(signalCount))
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$st.System.SR.CountdownEvent_Increment_AlreadyZero);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065229844)
            
            //--TRIMMABLE-BOUNDARY-START(111669608468)
            /*bool */ TryAddCount$1(/*int*/ signalCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669608468);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$$.System.Int32, signalCount, "signalCount");
                $.$$.System.ObjectDisposedException.ThrowIf(this._disposed, this);
                /*int*/ let observedCount;
                /*SpinWait*/ let spin = new $.$$.System.Threading.SpinWait();
                while(true)
                {
                    observedCount = this._currentCount;
                    if (observedCount <= 0)
                    {
                        return false;
                    }
                    else if (observedCount > (((2147483647/*int.MaxValue*/ - signalCount) | 0)))
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$st.System.SR.CountdownEvent_Increment_AlreadyMax);
                    }
                    if ($.$$.System.Threading.Interlocked.CompareExchange$3($.$ref(() => this._currentCount, ($v) => this._currentCount = $v, $.$$.System.Int32), ((observedCount + signalCount) | 0), observedCount) === observedCount)
                    {
                        break;
                    }
                    spin.SpinOnce$1(-1);
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(111669608468)
            
            //--TRIMMABLE-BOUNDARY-START(90194771988)
            /*void */ Reset()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194771988);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Reset$1(this._initialCount);
            }
            //--TRIMMABLE-BOUNDARY-END(90194771988)
            
            //--TRIMMABLE-BOUNDARY-START(94489739284)
            /*void */ Reset$1(/*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489739284);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ObjectDisposedException.ThrowIf(this._disposed, this);
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, count, "count");
                this._currentCount = count;
                this._initialCount = count;
                if (count === 0)
                {
                    this._event.Set$1();
                }
                else 
                {
                    this._event.Reset();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(94489739284)
            
            //--TRIMMABLE-BOUNDARY-START(115964575764)
            /*void */ Wait()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964575764);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Wait$1(-1/*Timeout.Infinite*/, $.$$.System.Threading.CancellationToken.None);
            }
            //--TRIMMABLE-BOUNDARY-END(115964575764)
            
            //--TRIMMABLE-BOUNDARY-START(120259543060)
            /*void */ Wait$3(/*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259543060);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Wait$1(-1/*Timeout.Infinite*/, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(120259543060)
            
            //--TRIMMABLE-BOUNDARY-START(124554510356)
            /*bool */ Wait$5(/*TimeSpan*/ timeout)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554510356);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*long*/ let totalMilliseconds = $.$cast(timeout.TotalMilliseconds, $.$$.System.Int64);
                $.$$.System.ArgumentOutOfRangeException.ThrowIfLessThan($.$$.System.Int64, totalMilliseconds, BigInt(-1), "timeout");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$$.System.Int64, totalMilliseconds, BigInt(2147483647/*int.MaxValue*/), "timeout");
                return this.Wait$1($.$cast(totalMilliseconds, $.$$.System.Int32), $.$$.System.Threading.CancellationToken.None);
            }
            //--TRIMMABLE-BOUNDARY-END(124554510356)
            
            //--TRIMMABLE-BOUNDARY-START(128849477652)
            /*bool */ Wait$4(/*TimeSpan*/ timeout, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849477652);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*long*/ let totalMilliseconds = $.$cast(timeout.TotalMilliseconds, $.$$.System.Int64);
                $.$$.System.ArgumentOutOfRangeException.ThrowIfLessThan($.$$.System.Int64, totalMilliseconds, BigInt(-1), "timeout");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$$.System.Int64, totalMilliseconds, BigInt(2147483647/*int.MaxValue*/), "timeout");
                return this.Wait$1($.$cast(totalMilliseconds, $.$$.System.Int32), cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(128849477652)
            
            //--TRIMMABLE-BOUNDARY-START(133144444948)
            /*bool */ Wait$2(/*int*/ millisecondsTimeout)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144444948);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Wait$1(millisecondsTimeout, $.$$.System.Threading.CancellationToken.None);
            }
            //--TRIMMABLE-BOUNDARY-END(133144444948)
            
            //--TRIMMABLE-BOUNDARY-START(137439412244)
            /*bool */ Wait$1(/*int*/ millisecondsTimeout, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439412244);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentOutOfRangeException.ThrowIfLessThan($.$$.System.Int32, millisecondsTimeout, -1, "millisecondsTimeout");
                $.$$.System.ObjectDisposedException.ThrowIf(this._disposed, this);
                cancellationToken.ThrowIfCancellationRequested();
                /*bool*/ let returnValue = this._event.IsSet;
                if (!returnValue)
                {
                    returnValue = this._event.Wait$1(millisecondsTimeout, cancellationToken);
                }
                return returnValue;
            }
            //--TRIMMABLE-BOUNDARY-END(137439412244)
            
            //--TRIMMABLE-BOUNDARY-START(4385144833)
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385144833);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385144833)
            
            static $h = 458772;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360197140),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540066324,
        "f": 50331649
      },
      "n": "CurrentCount",
      "d": 458772,
      "h": 34360197140,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360197140),
//--TRIMMABLE-BOUNDARY-START(81604837396),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130000916,
        "f": 50331649
      },
      "n": "InitialCount",
      "d": 458772,
      "h": 81604837396,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81604837396),
//--TRIMMABLE-BOUNDARY-START(85899804692),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68719935508,
        "f": 50331649
      },
      "n": "IsSet",
      "d": 458772,
      "h": 85899804692,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85899804692),
//--TRIMMABLE-BOUNDARY-START(141734379540),
    {
      "p": 184156161,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77309870100,
        "f": 50331649
      },
      "n": "WaitHandle",
      "d": 458772,
      "h": 141734379540,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(141734379540)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38655164436),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 458772,
      "h": 38655164436,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655164436),
//--TRIMMABLE-BOUNDARY-START(42950131732),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposing",
          "p": 262145
        }
      ],
      "n": "Dispose",
      "o": "@$1",
      "d": 458772,
      "h": 42950131732,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(42950131732),
//--TRIMMABLE-BOUNDARY-START(98784706580),
    {
      "r": 262145,
      "n": "Signal",
      "d": 458772,
      "h": 98784706580,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(98784706580),
//--TRIMMABLE-BOUNDARY-START(103079673876),
    {
      "r": 262145,
      "p": [
        {
          "n": "signalCount",
          "p": 655361
        }
      ],
      "n": "Signal",
      "o": "@$1",
      "d": 458772,
      "h": 103079673876,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(103079673876),
//--TRIMMABLE-BOUNDARY-START(25770262548),
    {
      "r": 65537,
      "n": "AddCount",
      "d": 458772,
      "h": 25770262548,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770262548),
//--TRIMMABLE-BOUNDARY-START(107374641172),
    {
      "r": 262145,
      "n": "TryAddCount",
      "d": 458772,
      "h": 107374641172,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(107374641172),
//--TRIMMABLE-BOUNDARY-START(30065229844),
    {
      "r": 65537,
      "p": [
        {
          "n": "signalCount",
          "p": 655361
        }
      ],
      "n": "AddCount",
      "o": "@$1",
      "d": 458772,
      "h": 30065229844,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065229844),
//--TRIMMABLE-BOUNDARY-START(111669608468),
    {
      "r": 262145,
      "p": [
        {
          "n": "signalCount",
          "p": 655361
        }
      ],
      "n": "TryAddCount",
      "o": "@$1",
      "d": 458772,
      "h": 111669608468,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(111669608468),
//--TRIMMABLE-BOUNDARY-START(90194771988),
    {
      "r": 65537,
      "n": "Reset",
      "d": 458772,
      "h": 90194771988,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(90194771988),
//--TRIMMABLE-BOUNDARY-START(94489739284),
    {
      "r": 65537,
      "p": [
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Reset",
      "o": "@$1",
      "d": 458772,
      "h": 94489739284,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(94489739284),
//--TRIMMABLE-BOUNDARY-START(115964575764),
    {
      "r": 65537,
      "n": "Wait",
      "d": 458772,
      "h": 115964575764,
      "f": 16777217,
      "a": [
        {
          "t": 159252481,
          "c": 4454219777,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(115964575764),
//--TRIMMABLE-BOUNDARY-START(120259543060),
    {
      "r": 65537,
      "p": [
        {
          "n": "cancellationToken",
          "p": 169934849
        }
      ],
      "n": "Wait",
      "o": "@$3",
      "d": 458772,
      "h": 120259543060,
      "f": 16777217,
      "a": [
        {
          "t": 159252481,
          "c": 4454219777,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(120259543060),
//--TRIMMABLE-BOUNDARY-START(124554510356),
    {
      "r": 262145,
      "p": [
        {
          "n": "timeout",
          "p": 185729025
        }
      ],
      "n": "Wait",
      "o": "@$5",
      "d": 458772,
      "h": 124554510356,
      "f": 16777217,
      "a": [
        {
          "t": 159252481,
          "c": 4454219777,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(124554510356),
//--TRIMMABLE-BOUNDARY-START(128849477652),
    {
      "r": 262145,
      "p": [
        {
          "n": "timeout",
          "p": 185729025
        },
        {
          "n": "cancellationToken",
          "p": 169934849
        }
      ],
      "n": "Wait",
      "o": "@$4",
      "d": 458772,
      "h": 128849477652,
      "f": 16777217,
      "a": [
        {
          "t": 159252481,
          "c": 4454219777,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(128849477652),
//--TRIMMABLE-BOUNDARY-START(133144444948),
    {
      "r": 262145,
      "p": [
        {
          "n": "millisecondsTimeout",
          "p": 655361
        }
      ],
      "n": "Wait",
      "o": "@$2",
      "d": 458772,
      "h": 133144444948,
      "f": 16777217,
      "a": [
        {
          "t": 159252481,
          "c": 4454219777,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(133144444948),
//--TRIMMABLE-BOUNDARY-START(137439412244),
    {
      "r": 262145,
      "p": [
        {
          "n": "millisecondsTimeout",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 169934849
        }
      ],
      "n": "Wait",
      "o": "@$1",
      "d": 458772,
      "h": 137439412244,
      "f": 16777217,
      "a": [
        {
          "t": 159252481,
          "c": 4454219777,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(137439412244)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180327956),
    {
      "t": 655361,
      "n": "_initialCount",
      "d": 458772,
      "h": 17180327956,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180327956),
//--TRIMMABLE-BOUNDARY-START(4295426068),
    {
      "t": 655361,
      "n": "_currentCount",
      "d": 458772,
      "h": 4295426068,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295426068),
//--TRIMMABLE-BOUNDARY-START(12885360660),
    {
      "t": 172359681,
      "n": "_event",
      "d": 458772,
      "h": 12885360660,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885360660),
//--TRIMMABLE-BOUNDARY-START(8590393364),
    {
      "t": 262145,
      "n": "_disposed",
      "d": 458772,
      "h": 8590393364,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590393364)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475295252),
    {
      "p": [
        {
          "n": "initialCount",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 458772,
      "h": 21475295252,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475295252)
  ],
  "i": [90177537
  ],
  "h": 458772,
  "a": [
    {
      "t": 70254593,
      "c": 8660189185,
      "a": [
        {
          "v": "InitialCount = {InitialCount}, CurrentCount = {CurrentCount}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.Threading.CountdownEvent`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458772)
        
        
        //--TRIMMABLE-BOUNDARY-START(262164)
        $asm.$cls("$st.System.Threading.Barrier", ($self) => class Barrier extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12885164052)
            /*int*/ _currentTotalCount = 0;
            //--TRIMMABLE-BOUNDARY-END(12885164052)
            
            //--TRIMMABLE-BOUNDARY-START(60129804308)
            /*int*/ static CURRENT_MASK = 2147418112;
            //--TRIMMABLE-BOUNDARY-END(60129804308)
            
            //--TRIMMABLE-BOUNDARY-START(193273790484)
            /*int*/ static TOTAL_MASK = 32767;
            //--TRIMMABLE-BOUNDARY-END(193273790484)
            
            //--TRIMMABLE-BOUNDARY-START(146029150228)
            /*int*/ static SENSE_MASK = -2147483648;
            //--TRIMMABLE-BOUNDARY-END(146029150228)
            
            //--TRIMMABLE-BOUNDARY-START(120259346452)
            /*int*/ static MAX_PARTICIPANTS = 32767;
            //--TRIMMABLE-BOUNDARY-END(120259346452)
            
            //--TRIMMABLE-BOUNDARY-START(8590196756)
            /*long*/ _currentPhase = 0n;
            //--TRIMMABLE-BOUNDARY-END(8590196756)
            
            //--TRIMMABLE-BOUNDARY-START(17180131348)
            /*bool*/ _disposed = false;
            //--TRIMMABLE-BOUNDARY-END(17180131348)
            
            //--TRIMMABLE-BOUNDARY-START(30065033236)
            /*ManualResetEventSlim*/ _oddEvent = null;
            //--TRIMMABLE-BOUNDARY-END(30065033236)
            
            //--TRIMMABLE-BOUNDARY-START(21475098644)
            /*ManualResetEventSlim*/ _evenEvent = null;
            //--TRIMMABLE-BOUNDARY-END(21475098644)
            
            //--TRIMMABLE-BOUNDARY-START(34360000532)
            /*ExecutionContext?*/ _ownerThreadContext = null;
            //--TRIMMABLE-BOUNDARY-END(34360000532)
            
            //--TRIMMABLE-BOUNDARY-START(141734182932)
            /*ContextCallback?*/ static s_invokePostPhaseAction = null;
            //--TRIMMABLE-BOUNDARY-END(141734182932)
            
            //--TRIMMABLE-BOUNDARY-START(38654967828)
            /*Action<Barrier>?*/ _postPhaseAction = null;
            //--TRIMMABLE-BOUNDARY-END(38654967828)
            
            //--TRIMMABLE-BOUNDARY-START(25770065940)
            /*Exception?*/ _exception = null;
            //--TRIMMABLE-BOUNDARY-END(25770065940)
            
            //--TRIMMABLE-BOUNDARY-START(4295229460)
            /*int*/ _actionCallerID = 0;
            //--TRIMMABLE-BOUNDARY-END(4295229460)
            
            //--TRIMMABLE-BOUNDARY-START(128849281044)
            /*int */ get ParticipantsRemaining()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374444564);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let currentTotal = this._currentTotalCount;
                /*int*/ let total = (currentTotal & 32767/*TOTAL_MASK*/);
                /*int*/ let current = ((currentTotal & 2147418112/*CURRENT_MASK*/) >> 16);
                return ((total - current) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(128849281044)
            
            //--TRIMMABLE-BOUNDARY-START(124554313748)
            /*int */ get ParticipantCount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784509972);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (this._currentTotalCount & 32767/*TOTAL_MASK*/);
            }
            //--TRIMMABLE-BOUNDARY-END(124554313748)
            
            //--TRIMMABLE-BOUNDARY-START(64424771604)
            /*long */ get CurrentPhaseNumber()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194575380);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$ref(() => this._currentPhase, ($v) => this._currentPhase = $v, $.$$.System.Int64).$v;
            }
            /*long */ set CurrentPhaseNumber(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619084820);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$ref(() => this._currentPhase, ($v) => this._currentPhase = $v, $.$$.System.Int64).$v = value;
            }
            //--TRIMMABLE-BOUNDARY-END(64424771604)
            
            //--TRIMMABLE-BOUNDARY-START(42949935124)
            $ctor$2(/*int*/ participantCount)
            {
                this.$ctor$1(participantCount, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42949935124);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42949935124)
            
            //--TRIMMABLE-BOUNDARY-START(47244902420)
            $ctor$1(/*int*/ participantCount, /*Action<Barrier>?*/ postPhaseAction)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47244902420);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, participantCount, "participantCount");
                    $.$$.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$$.System.Int32, participantCount, 32767/*MAX_PARTICIPANTS*/, "participantCount");
                    this._currentTotalCount = participantCount;
                    this._postPhaseAction = postPhaseAction;
                    this._oddEvent = new $.$$.System.Threading.ManualResetEventSlim().$ctor$3(true);
                    this._evenEvent = new $.$$.System.Threading.ManualResetEventSlim().$ctor$3(false);
                    if (!(postPhaseAction === null))
                    {
                        this._ownerThreadContext = $.$$.System.Threading.ExecutionContext.Capture();
                    }
                    this._actionCallerID = 0;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(47244902420)
            
            //--TRIMMABLE-BOUNDARY-START(111669411860)
            static /*void */ GetCurrentTotal(/*int*/ currentTotal, /*out int*/ current, /*out int*/ total, /*out bool*/ sense)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669411860);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                total.$v = (currentTotal & 32767/*TOTAL_MASK*/);
                current.$v = ((currentTotal & 2147418112/*CURRENT_MASK*/) >> 16);
                sense.$v = (currentTotal & -2147483648/*SENSE_MASK*/) === 0 ? true : false;
            }
            //--TRIMMABLE-BOUNDARY-END(111669411860)
            
            //--TRIMMABLE-BOUNDARY-START(158914052116)
            /*bool */ SetCurrentTotal(/*int*/ currentTotal, /*int*/ current, /*int*/ total, /*bool*/ sense)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914052116);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let newCurrentTotal = (current << 16) | total;
                if (!sense)
                {
                    newCurrentTotal |= -2147483648/*SENSE_MASK*/;
                }
                return $.$$.System.Threading.Interlocked.CompareExchange$3($.$ref(() => this._currentTotalCount, ($v) => this._currentTotalCount = $v, $.$$.System.Int32), newCurrentTotal, currentTotal) === currentTotal;
            }
            //--TRIMMABLE-BOUNDARY-END(158914052116)
            
            //--TRIMMABLE-BOUNDARY-START(51539869716)
            /*long */ AddParticipant()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539869716);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                try
                {
                    return this.AddParticipants(1);
                }
                catch($e)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$st.System.SR.Barrier_AddParticipants_Overflow_ArgumentOutOfRange);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51539869716)
            
            //--TRIMMABLE-BOUNDARY-START(55834837012)
            /*long */ AddParticipants(/*int*/ participantCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834837012);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ObjectDisposedException.ThrowIf(this._disposed, this);
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$$.System.Int32, participantCount, "participantCount");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$$.System.Int32, participantCount, 32767/*MAX_PARTICIPANTS*/, "participantCount");
                if (this._actionCallerID !== 0 && $.$$.System.Environment.CurrentManagedThreadId === this._actionCallerID)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$st.System.SR.Barrier_InvalidOperation_CalledFromPHA);
                }
                /*SpinWait*/ let spinner = new $.$$.System.Threading.SpinWait();
                /*long*/ let newPhase;
                while(true)
                {
                    /*int*/ let currentTotal = this._currentTotalCount;
                    /*int*/ let total;
                    /*int*/ let current;
                    /*bool*/ let sense;
                    $.$st.System.Threading.Barrier.GetCurrentTotal(currentTotal, $.$ref(() => current, ($v) => current = $v, $.$$.System.Int32), $.$ref(() => total, ($v) => total = $v, $.$$.System.Int32), $.$ref(() => sense, ($v) => sense = $v, $.$$.System.Boolean));
                    if (((participantCount + total) | 0) > 32767/*MAX_PARTICIPANTS*/)
                    {
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$19("participantCount", $.$st.System.SR.Barrier_AddParticipants_Overflow_ArgumentOutOfRange);
                    }
                    if (this.SetCurrentTotal(currentTotal, current, ((total + participantCount) | 0), sense))
                    {
                        /*long*/ let currPhase = this.CurrentPhaseNumber;
                        newPhase = (sense !== (currPhase % 2n === 0n)) ? currPhase + 1n : currPhase;
                        if (newPhase !== currPhase)
                        {
                            if (sense)
                            {
                                this._oddEvent.Wait();
                            }
                            else 
                            {
                                this._evenEvent.Wait();
                            }
                        }
                        else 
                        {
                            if (sense && this._evenEvent.IsSet)
                            {
                                this._evenEvent.Reset();
                            }
                            else if (!sense && this._oddEvent.IsSet)
                            {
                                this._oddEvent.Reset();
                            }
                        }
                        break;
                    }
                    spinner.SpinOnce$1(-1);
                }
                return newPhase;
            }
            //--TRIMMABLE-BOUNDARY-END(55834837012)
            
            //--TRIMMABLE-BOUNDARY-START(133144248340)
            /*void */ RemoveParticipant()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144248340);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.RemoveParticipants(1);
            }
            //--TRIMMABLE-BOUNDARY-END(133144248340)
            
            //--TRIMMABLE-BOUNDARY-START(137439215636)
            /*void */ RemoveParticipants(/*int*/ participantCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439215636);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ObjectDisposedException.ThrowIf(this._disposed, this);
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$$.System.Int32, participantCount, "participantCount");
                if (this._actionCallerID !== 0 && $.$$.System.Environment.CurrentManagedThreadId === this._actionCallerID)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$st.System.SR.Barrier_InvalidOperation_CalledFromPHA);
                }
                /*SpinWait*/ let spinner = new $.$$.System.Threading.SpinWait();
                while(true)
                {
                    /*int*/ let currentTotal = this._currentTotalCount;
                    /*int*/ let total;
                    /*int*/ let current;
                    /*bool*/ let sense;
                    $.$st.System.Threading.Barrier.GetCurrentTotal(currentTotal, $.$ref(() => current, ($v) => current = $v, $.$$.System.Int32), $.$ref(() => total, ($v) => total = $v, $.$$.System.Int32), $.$ref(() => sense, ($v) => sense = $v, $.$$.System.Boolean));
                    if (total < participantCount)
                    {
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$19("participantCount", $.$st.System.SR.Barrier_RemoveParticipants_ArgumentOutOfRange);
                    }
                    if (((total - participantCount) | 0) < current)
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$st.System.SR.Barrier_RemoveParticipants_InvalidOperation);
                    }
                    /*int*/ let remaingParticipants = ((total - participantCount) | 0);
                    if (remaingParticipants > 0 && current === remaingParticipants)
                    {
                        if (this.SetCurrentTotal(currentTotal, 0, ((total - participantCount) | 0), !sense))
                        {
                            this.FinishPhase(sense);
                            break;
                        }
                    }
                    else 
                    {
                        if (this.SetCurrentTotal(currentTotal, current, ((total - participantCount) | 0), sense))
                        {
                            break;
                        }
                    }
                    spinner.SpinOnce$1(-1);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(137439215636)
            
            //--TRIMMABLE-BOUNDARY-START(167503986708)
            /*void */ SignalAndWait()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167503986708);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.SignalAndWait$3($.$$.System.Threading.CancellationToken.None);
            }
            //--TRIMMABLE-BOUNDARY-END(167503986708)
            
            //--TRIMMABLE-BOUNDARY-START(171798954004)
            /*void */ SignalAndWait$3(/*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171798954004);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let result = this.SignalAndWait$1(-1/*Timeout.Infinite*/, cancellationToken);
                $.$$.System.Diagnostics.Debug.Assert$2(result, "result");
            }
            //--TRIMMABLE-BOUNDARY-END(171798954004)
            
            //--TRIMMABLE-BOUNDARY-START(176093921300)
            /*bool */ SignalAndWait$5(/*TimeSpan*/ timeout)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176093921300);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SignalAndWait$4(timeout, $.$$.System.Threading.CancellationToken.None);
            }
            //--TRIMMABLE-BOUNDARY-END(176093921300)
            
            //--TRIMMABLE-BOUNDARY-START(180388888596)
            /*bool */ SignalAndWait$4(/*TimeSpan*/ timeout, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180388888596);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*long*/ let totalMilliseconds = $.$cast(timeout.TotalMilliseconds, $.$$.System.Int64);
                if (totalMilliseconds < BigInt(-1) || totalMilliseconds > BigInt(2147483647/*int.MaxValue*/))
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$18("timeout", timeout, $.$st.System.SR.Barrier_SignalAndWait_ArgumentOutOfRange);
                }
                return this.SignalAndWait$1($.$cast(timeout.TotalMilliseconds, $.$$.System.Int32), cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(180388888596)
            
            //--TRIMMABLE-BOUNDARY-START(184683855892)
            /*bool */ SignalAndWait$2(/*int*/ millisecondsTimeout)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184683855892);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SignalAndWait$1(millisecondsTimeout, $.$$.System.Threading.CancellationToken.None);
            }
            //--TRIMMABLE-BOUNDARY-END(184683855892)
            
            //--TRIMMABLE-BOUNDARY-START(188978823188)
            /*bool */ SignalAndWait$1(/*int*/ millisecondsTimeout, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188978823188);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ObjectDisposedException.ThrowIf(this._disposed, this);
                cancellationToken.ThrowIfCancellationRequested();
                if (millisecondsTimeout < -1)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$18("millisecondsTimeout", $.$box(millisecondsTimeout, $.$$.System.Int32), $.$st.System.SR.Barrier_SignalAndWait_ArgumentOutOfRange);
                }
                if (this._actionCallerID !== 0 && $.$$.System.Environment.CurrentManagedThreadId === this._actionCallerID)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$st.System.SR.Barrier_InvalidOperation_CalledFromPHA);
                }
                /*bool*/ let sense;
                /*int*/ let total;
                /*int*/ let current;
                /*int*/ let currentTotal;
                /*long*/ let phase;
                /*SpinWait*/ let spinner = new $.$$.System.Threading.SpinWait();
                while(true)
                {
                    currentTotal = this._currentTotalCount;
                    $.$st.System.Threading.Barrier.GetCurrentTotal(currentTotal, $.$ref(() => current, ($v) => current = $v, $.$$.System.Int32), $.$ref(() => total, ($v) => total = $v, $.$$.System.Int32), $.$ref(() => sense, ($v) => sense = $v, $.$$.System.Boolean));
                    phase = this.CurrentPhaseNumber;
                    if (total === 0)
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$st.System.SR.Barrier_SignalAndWait_InvalidOperation_ZeroTotal);
                    }
                    if (current === 0 && sense !== (this.CurrentPhaseNumber % 2n === 0n))
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$st.System.SR.Barrier_SignalAndWait_InvalidOperation_ThreadsExceeded);
                    }
                    if (((current + 1) | 0) === total)
                    {
                        if (this.SetCurrentTotal(currentTotal, 0, total, !sense))
                        {
                            if ($.$st.System.Threading.CdsSyncEtwBCLProvider.Log.IsEnabled())
                            {
                                $.$st.System.Threading.CdsSyncEtwBCLProvider.Log.Barrier_PhaseFinished(sense, this.CurrentPhaseNumber);
                            }
                            this.FinishPhase(sense);
                            return true;
                        }
                    }
                    else if (this.SetCurrentTotal(currentTotal, ((current + 1) | 0), total, sense))
                    {
                        break;
                    }
                    spinner.SpinOnce$1(-1);
                }
                /*ManualResetEventSlim*/ let eventToWaitOn = (sense) ? this._evenEvent : this._oddEvent;
                /*bool*/ let waitWasCanceled = false;
                /*bool*/ let waitResult = false;
                try
                {
                    waitResult = this.DiscontinuousWait(eventToWaitOn, millisecondsTimeout, cancellationToken, phase);
                }
                catch($e)
                {
                    if ($e instanceof $.$$.System.OperationCanceledException)
                    {
                        waitWasCanceled = true;
                    }
                    else if ($e instanceof $.$$.System.ObjectDisposedException)
                    {
                        if (phase < this.CurrentPhaseNumber)
                        {
                            waitResult = true;
                        }
                        else 
                        {
                            throw $e;
                        }
                    }
                    else
                    {
                        throw $e;
                    }
                }
                if (!waitResult)
                {
                    spinner.Reset();
                    while(true)
                    {
                        /*bool*/ let newSense;
                        currentTotal = this._currentTotalCount;
                        $.$st.System.Threading.Barrier.GetCurrentTotal(currentTotal, $.$ref(() => current, ($v) => current = $v, $.$$.System.Int32), $.$ref(() => total, ($v) => total = $v, $.$$.System.Int32), $.$ref(() => newSense, ($v) => newSense = $v, $.$$.System.Boolean));
                        if (phase < this.CurrentPhaseNumber || sense !== newSense)
                        {
                            this.WaitCurrentPhase(eventToWaitOn, phase);
                            $.$$.System.Diagnostics.Debug.Assert$2(phase < this.CurrentPhaseNumber, "phase < CurrentPhaseNumber");
                            break;
                        }
                        if (this.SetCurrentTotal(currentTotal, ((current - 1) | 0), total, sense))
                        {
                            if (waitWasCanceled)
                            {
                                throw new $.$$.System.OperationCanceledException().$ctor$13($.$st.System.SR.Common_OperationCanceled, cancellationToken);
                            }
                            else 
                            {
                                return false;
                            }
                        }
                        spinner.SpinOnce$1(-1);
                    }
                }
                if (!(this._exception === null))
                {
                    throw new $.$st.System.Threading.BarrierPostPhaseException().$ctor$6(this._exception);
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(188978823188)
            
            //--TRIMMABLE-BOUNDARY-START(81604640788)
            /*void */ FinishPhase(/*bool*/ observedSense)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604640788);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!(this._postPhaseAction === null))
                {
                    try
                    {
                        this._actionCallerID = $.$$.System.Environment.CurrentManagedThreadId;
                        if (!(this._ownerThreadContext === null))
                        {
                            /*ContextCallback?*/ let handler = $.$st.System.Threading.Barrier.s_invokePostPhaseAction ??= new $.$$.System.Threading.ContextCallback().$ctor($.$st.System.Threading.Barrier, $.$st.System.Threading.Barrier.InvokePostPhaseAction);
                            $.$$.System.Threading.ExecutionContext.Run(this._ownerThreadContext, handler, this);
                        }
                        else 
                        {
                            this._postPhaseAction.Invoke(this);
                        }
                        this._exception = null;
                    }
                    catch(ex)
                    {
                        this._exception = ex;
                    }
                    finally
                    {
                        {
                            this._actionCallerID = 0;
                            this.SetResetEvents(observedSense);
                            if (!(this._exception === null))
                            {
                                throw new $.$st.System.Threading.BarrierPostPhaseException().$ctor$6(this._exception);
                            }
                        }
                    }
                }
                else 
                {
                    this.SetResetEvents(observedSense);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(81604640788)
            
            //--TRIMMABLE-BOUNDARY-START(115964379156)
            static /*void */ InvokePostPhaseAction(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964379156);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let thisBarrier = $.$cast(obj, $.$st.System.Threading.Barrier);
                thisBarrier._postPhaseAction.Invoke(thisBarrier);
            }
            //--TRIMMABLE-BOUNDARY-END(115964379156)
            
            //--TRIMMABLE-BOUNDARY-START(163209019412)
            /*void */ SetResetEvents(/*bool*/ observedSense)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209019412);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CurrentPhaseNumber++;
                if (observedSense)
                {
                    this._oddEvent.Reset();
                    this._evenEvent.Set$1();
                }
                else 
                {
                    this._evenEvent.Reset();
                    this._oddEvent.Set$1();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(163209019412)
            
            //--TRIMMABLE-BOUNDARY-START(197568757780)
            /*void */ WaitCurrentPhase(/*ManualResetEventSlim*/ currentPhaseEvent, /*long*/ observedPhase)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197568757780);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*SpinWait*/ let spinner = new $.$$.System.Threading.SpinWait();
                while(!currentPhaseEvent.IsSet && this.CurrentPhaseNumber - observedPhase <= 1n)
                {
                    spinner.SpinOnce();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(197568757780)
            
            //--TRIMMABLE-BOUNDARY-START(68719738900)
            /*bool */ DiscontinuousWait(/*ManualResetEventSlim*/ currentPhaseEvent, /*int*/ totalTimeout, /*CancellationToken*/ token, /*long*/ observedPhase)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719738900);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let maxWait = 100;
                /*int*/ let waitTimeCeiling = 10000;
                while(observedPhase === this.CurrentPhaseNumber)
                {
                    /*int*/ let waitTime = totalTimeout === -1/*Timeout.Infinite*/ ? maxWait : $.$$.System.Math.Min$4(maxWait, totalTimeout);
                    if (currentPhaseEvent.Wait$1(waitTime, token))
                    {
                        return true;
                    }
                    if (totalTimeout !== -1/*Timeout.Infinite*/)
                    {
                        totalTimeout -= waitTime;
                        if (totalTimeout <= 0)
                        {
                            return false;
                        }
                    }
                    maxWait = maxWait >= waitTimeCeiling ? waitTimeCeiling : $.$$.System.Math.Min$4(maxWait << 1, waitTimeCeiling);
                }
                this.WaitCurrentPhase(currentPhaseEvent, observedPhase);
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(68719738900)
            
            //--TRIMMABLE-BOUNDARY-START(73014706196)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014706196);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._actionCallerID !== 0 && $.$$.System.Environment.CurrentManagedThreadId === this._actionCallerID)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$st.System.SR.Barrier_InvalidOperation_CalledFromPHA);
                }
                this.Dispose$1(true);
                $.$$.System.GC.SuppressFinalize(this);
            }
            //--TRIMMABLE-BOUNDARY-END(73014706196)
            
            //--TRIMMABLE-BOUNDARY-START(77309673492)
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309673492);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this._disposed)
                {
                    if (disposing)
                    {
                        this._oddEvent.Dispose();
                        this._evenEvent.Dispose();
                    }
                    this._disposed = true;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77309673492)
            
            //--TRIMMABLE-BOUNDARY-START(4385144833)
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385144833);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385144833)
            
            static $h = 262164;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(128849281044),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374444564,
        "f": 50331649
      },
      "n": "ParticipantsRemaining",
      "d": 262164,
      "h": 128849281044,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(128849281044),
//--TRIMMABLE-BOUNDARY-START(124554313748),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784509972,
        "f": 50331649
      },
      "n": "ParticipantCount",
      "d": 262164,
      "h": 124554313748,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(124554313748),
//--TRIMMABLE-BOUNDARY-START(64424771604),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194575380,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 154619084820,
        "f": 83886088
      },
      "n": "CurrentPhaseNumber",
      "d": 262164,
      "h": 64424771604,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64424771604)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(111669411860),
    {
      "r": 65537,
      "p": [
        {
          "n": "currentTotal",
          "p": 655361
        },
        {
          "n": "current",
          "p": 655361,
          "f": 2
        },
        {
          "n": "total",
          "p": 655361,
          "f": 2
        },
        {
          "n": "sense",
          "p": 262145,
          "f": 2
        }
      ],
      "n": "GetCurrentTotal",
      "d": 262164,
      "h": 111669411860,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(111669411860),
//--TRIMMABLE-BOUNDARY-START(158914052116),
    {
      "r": 262145,
      "p": [
        {
          "n": "currentTotal",
          "p": 655361
        },
        {
          "n": "current",
          "p": 655361
        },
        {
          "n": "total",
          "p": 655361
        },
        {
          "n": "sense",
          "p": 262145
        }
      ],
      "n": "SetCurrentTotal",
      "d": 262164,
      "h": 158914052116,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(158914052116),
//--TRIMMABLE-BOUNDARY-START(51539869716),
    {
      "r": 917505,
      "n": "AddParticipant",
      "d": 262164,
      "h": 51539869716,
      "f": 16777217,
      "a": [
        {
          "t": 159252481,
          "c": 4454219777,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51539869716),
//--TRIMMABLE-BOUNDARY-START(55834837012),
    {
      "r": 917505,
      "p": [
        {
          "n": "participantCount",
          "p": 655361
        }
      ],
      "n": "AddParticipants",
      "d": 262164,
      "h": 55834837012,
      "f": 16777217,
      "a": [
        {
          "t": 159252481,
          "c": 4454219777,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55834837012),
//--TRIMMABLE-BOUNDARY-START(133144248340),
    {
      "r": 65537,
      "n": "RemoveParticipant",
      "d": 262164,
      "h": 133144248340,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(133144248340),
//--TRIMMABLE-BOUNDARY-START(137439215636),
    {
      "r": 65537,
      "p": [
        {
          "n": "participantCount",
          "p": 655361
        }
      ],
      "n": "RemoveParticipants",
      "d": 262164,
      "h": 137439215636,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(137439215636),
//--TRIMMABLE-BOUNDARY-START(167503986708),
    {
      "r": 65537,
      "n": "SignalAndWait",
      "d": 262164,
      "h": 167503986708,
      "f": 16777217,
      "a": [
        {
          "t": 159252481,
          "c": 4454219777,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(167503986708),
//--TRIMMABLE-BOUNDARY-START(171798954004),
    {
      "r": 65537,
      "p": [
        {
          "n": "cancellationToken",
          "p": 169934849
        }
      ],
      "n": "SignalAndWait",
      "o": "@$3",
      "d": 262164,
      "h": 171798954004,
      "f": 16777217,
      "a": [
        {
          "t": 159252481,
          "c": 4454219777,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(171798954004),
//--TRIMMABLE-BOUNDARY-START(176093921300),
    {
      "r": 262145,
      "p": [
        {
          "n": "timeout",
          "p": 185729025
        }
      ],
      "n": "SignalAndWait",
      "o": "@$5",
      "d": 262164,
      "h": 176093921300,
      "f": 16777217,
      "a": [
        {
          "t": 159252481,
          "c": 4454219777,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(176093921300),
//--TRIMMABLE-BOUNDARY-START(180388888596),
    {
      "r": 262145,
      "p": [
        {
          "n": "timeout",
          "p": 185729025
        },
        {
          "n": "cancellationToken",
          "p": 169934849
        }
      ],
      "n": "SignalAndWait",
      "o": "@$4",
      "d": 262164,
      "h": 180388888596,
      "f": 16777217,
      "a": [
        {
          "t": 159252481,
          "c": 4454219777,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(180388888596),
//--TRIMMABLE-BOUNDARY-START(184683855892),
    {
      "r": 262145,
      "p": [
        {
          "n": "millisecondsTimeout",
          "p": 655361
        }
      ],
      "n": "SignalAndWait",
      "o": "@$2",
      "d": 262164,
      "h": 184683855892,
      "f": 16777217,
      "a": [
        {
          "t": 159252481,
          "c": 4454219777,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(184683855892),
//--TRIMMABLE-BOUNDARY-START(188978823188),
    {
      "r": 262145,
      "p": [
        {
          "n": "millisecondsTimeout",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 169934849
        }
      ],
      "n": "SignalAndWait",
      "o": "@$1",
      "d": 262164,
      "h": 188978823188,
      "f": 16777217,
      "a": [
        {
          "t": 159252481,
          "c": 4454219777,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(188978823188),
//--TRIMMABLE-BOUNDARY-START(81604640788),
    {
      "r": 65537,
      "p": [
        {
          "n": "observedSense",
          "p": 262145
        }
      ],
      "n": "FinishPhase",
      "d": 262164,
      "h": 81604640788,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(81604640788),
//--TRIMMABLE-BOUNDARY-START(115964379156),
    {
      "r": 65537,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "InvokePostPhaseAction",
      "d": 262164,
      "h": 115964379156,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(115964379156),
//--TRIMMABLE-BOUNDARY-START(163209019412),
    {
      "r": 65537,
      "p": [
        {
          "n": "observedSense",
          "p": 262145
        }
      ],
      "n": "SetResetEvents",
      "d": 262164,
      "h": 163209019412,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(163209019412),
//--TRIMMABLE-BOUNDARY-START(197568757780),
    {
      "r": 65537,
      "p": [
        {
          "n": "currentPhaseEvent",
          "p": 172359681
        },
        {
          "n": "observedPhase",
          "p": 917505
        }
      ],
      "n": "WaitCurrentPhase",
      "d": 262164,
      "h": 197568757780,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(197568757780),
//--TRIMMABLE-BOUNDARY-START(68719738900),
    {
      "r": 262145,
      "p": [
        {
          "n": "currentPhaseEvent",
          "p": 172359681
        },
        {
          "n": "totalTimeout",
          "p": 655361
        },
        {
          "n": "token",
          "p": 169934849
        },
        {
          "n": "observedPhase",
          "p": 917505
        }
      ],
      "n": "DiscontinuousWait",
      "d": 262164,
      "h": 68719738900,
      "f": 16777218,
      "a": [
        {
          "t": 159252481,
          "c": 4454219777,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(68719738900),
//--TRIMMABLE-BOUNDARY-START(73014706196),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 262164,
      "h": 73014706196,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73014706196),
//--TRIMMABLE-BOUNDARY-START(77309673492),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposing",
          "p": 262145
        }
      ],
      "n": "Dispose",
      "o": "@$1",
      "d": 262164,
      "h": 77309673492,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(77309673492)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885164052),
    {
      "t": 655361,
      "n": "_currentTotalCount",
      "d": 262164,
      "h": 12885164052,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885164052),
//--TRIMMABLE-BOUNDARY-START(60129804308),
    {
      "t": 655361,
      "n": "CURRENT_MASK",
      "d": 262164,
      "h": 60129804308,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(60129804308),
//--TRIMMABLE-BOUNDARY-START(193273790484),
    {
      "t": 655361,
      "n": "TOTAL_MASK",
      "d": 262164,
      "h": 193273790484,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(193273790484),
//--TRIMMABLE-BOUNDARY-START(146029150228),
    {
      "t": 655361,
      "n": "SENSE_MASK",
      "d": 262164,
      "h": 146029150228,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(146029150228),
//--TRIMMABLE-BOUNDARY-START(120259346452),
    {
      "t": 655361,
      "n": "MAX_PARTICIPANTS",
      "d": 262164,
      "h": 120259346452,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(120259346452),
//--TRIMMABLE-BOUNDARY-START(8590196756),
    {
      "t": 917505,
      "n": "_currentPhase",
      "d": 262164,
      "h": 8590196756,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590196756),
//--TRIMMABLE-BOUNDARY-START(17180131348),
    {
      "t": 262145,
      "n": "_disposed",
      "d": 262164,
      "h": 17180131348,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180131348),
//--TRIMMABLE-BOUNDARY-START(30065033236),
    {
      "t": 172359681,
      "n": "_oddEvent",
      "d": 262164,
      "h": 30065033236,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30065033236),
//--TRIMMABLE-BOUNDARY-START(21475098644),
    {
      "t": 172359681,
      "n": "_evenEvent",
      "d": 262164,
      "h": 21475098644,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475098644),
//--TRIMMABLE-BOUNDARY-START(34360000532),
    {
      "t": 170917889,
      "n": "_ownerThreadContext",
      "d": 262164,
      "h": 34360000532,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34360000532),
//--TRIMMABLE-BOUNDARY-START(141734182932),
    {
      "t": 170590209,
      "n": "s_invokePostPhaseAction",
      "d": 262164,
      "h": 141734182932,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(141734182932),
//--TRIMMABLE-BOUNDARY-START(38654967828),
    {
      "t": $.$$.System.Action$$($.$st.System.Threading.Barrier).$h,
      "n": "_postPhaseAction",
      "d": 262164,
      "h": 38654967828,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38654967828),
//--TRIMMABLE-BOUNDARY-START(25770065940),
    {
      "t": 79888385,
      "n": "_exception",
      "d": 262164,
      "h": 25770065940,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770065940),
//--TRIMMABLE-BOUNDARY-START(4295229460),
    {
      "t": 655361,
      "n": "_actionCallerID",
      "d": 262164,
      "h": 4295229460,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295229460)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(42949935124),
    {
      "p": [
        {
          "n": "participantCount",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 262164,
      "h": 42949935124,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42949935124),
//--TRIMMABLE-BOUNDARY-START(47244902420),
    {
      "p": [
        {
          "n": "participantCount",
          "p": 655361
        },
        {
          "n": "postPhaseAction",
          "p": $.$$.System.Action$$($.$st.System.Threading.Barrier).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 262164,
      "h": 47244902420,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47244902420)
  ],
  "i": [90177537
  ],
  "h": 262164,
  "a": [
    {
      "t": 70254593,
      "c": 8660189185,
      "a": [
        {
          "v": "ParticipantCount = {ParticipantCount}, ParticipantsRemaining = {ParticipantsRemaining}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.Threading.Barrier`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262164)
        
        
        //--TRIMMABLE-BOUNDARY-START(851988)
        $asm.$cls("$st.System.Threading.ReaderWriterLock", ($self) => class ReaderWriterLock extends $.$$.System.Runtime.ConstrainedExecution.CriticalFinalizerObject
        {
            //--TRIMMABLE-BOUNDARY-START(128849870868)
            /*int*/ static InvalidThreadID = -1;
            //--TRIMMABLE-BOUNDARY-END(128849870868)
            
            //--TRIMMABLE-BOUNDARY-START(146029740052)
            /*ushort*/ static MaxAcquireCount = 65535;
            //--TRIMMABLE-BOUNDARY-END(146029740052)
            
            //--TRIMMABLE-BOUNDARY-START(64425361428)
            /*int*/ static DefaultSpinCount = 0;
            //--TRIMMABLE-BOUNDARY-END(64425361428)
            
            //--TRIMMABLE-BOUNDARY-START(124554903572)
            /*int*/ static IncorrectButCompatibleNotOwnerExceptionHResult = 288;
            //--TRIMMABLE-BOUNDARY-END(124554903572)
            
            //--TRIMMABLE-BOUNDARY-START(180389478420)
            /*long*/ static s_mostRecentLockID = 0n;
            //--TRIMMABLE-BOUNDARY-END(180389478420)
            
            //--TRIMMABLE-BOUNDARY-START(8590786580)
            /*ManualResetEventSlim?*/ _readerEvent = null;
            //--TRIMMABLE-BOUNDARY-END(8590786580)
            
            //--TRIMMABLE-BOUNDARY-START(17180721172)
            /*AutoResetEvent?*/ _writerEvent = null;
            //--TRIMMABLE-BOUNDARY-END(17180721172)
            
            //--TRIMMABLE-BOUNDARY-START(4295819284)
            /*long*/ _lockID = 0n;
            //--TRIMMABLE-BOUNDARY-END(4295819284)
            
            //--TRIMMABLE-BOUNDARY-START(12885753876)
            /*int*/ _state = 0;
            //--TRIMMABLE-BOUNDARY-END(12885753876)
            
            //--TRIMMABLE-BOUNDARY-START(21475688468)
            /*int*/ _writerID = -1;
            //--TRIMMABLE-BOUNDARY-END(21475688468)
            
            //--TRIMMABLE-BOUNDARY-START(30065623060)
            /*int*/ _writerSeqNum = 1;
            //--TRIMMABLE-BOUNDARY-END(30065623060)
            
            //--TRIMMABLE-BOUNDARY-START(25770655764)
            /*ushort*/ _writerLevel = 0;
            //--TRIMMABLE-BOUNDARY-END(25770655764)
            
            //--TRIMMABLE-BOUNDARY-START(38655557652)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655557652);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._lockID = $.$$.System.Threading.Interlocked.Increment$1($.$ref(() => $.$st.System.Threading.ReaderWriterLock.s_mostRecentLockID, ($v) => $.$st.System.Threading.ReaderWriterLock.s_mostRecentLockID = $v, $.$$.System.Int64));
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38655557652)
            
            //--TRIMMABLE-BOUNDARY-START(133144838164)
            /*bool */ get IsReaderLockHeld()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310263316);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ThreadLocalLockEntry?*/ let threadLocalLockEntry = $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.GetCurrent(this._lockID);
                if (threadLocalLockEntry !== null)
                {
                    return threadLocalLockEntry._readerLevel > 0;
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(133144838164)
            
            //--TRIMMABLE-BOUNDARY-START(137439805460)
            /*bool */ get IsWriterLockHeld()
            {
                return this._writerID === $.$st.System.Threading.ReaderWriterLock.GetCurrentThreadID();
            }
            //--TRIMMABLE-BOUNDARY-END(137439805460)
            
            //--TRIMMABLE-BOUNDARY-START(210454249492)
            /*int */ get WriterSeqNum()
            {
                return this._writerSeqNum;
            }
            //--TRIMMABLE-BOUNDARY-END(210454249492)
            
            //--TRIMMABLE-BOUNDARY-START(60130394132)
            /*bool */ AnyWritersSince(/*int*/ seqNum)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130394132);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._writerID === $.$st.System.Threading.ReaderWriterLock.GetCurrentThreadID())
                {
                    ++seqNum;
                }
                return (this._writerSeqNum >>> 0) > (seqNum >>> 0);
            }
            //--TRIMMABLE-BOUNDARY-END(60130394132)
            
            //--TRIMMABLE-BOUNDARY-START(42950524948)
            /*void */ AcquireReaderLock(/*int*/ millisecondsTimeout)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950524948);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentOutOfRangeException.ThrowIfLessThan($.$$.System.Int32, millisecondsTimeout, -1, "millisecondsTimeout");
                /*ThreadLocalLockEntry*/ let threadLocalLockEntry = $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.GetOrCreateCurrent(this._lockID);
                if ($.$$.System.Threading.Interlocked.CompareExchange$3($.$ref(() => this._state, ($v) => this._state = $v, $.$$.System.Int32), 1/*LockStates.Reader*/, 0) === 0)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(threadLocalLockEntry._readerLevel === 0, "threadLocalLockEntry._readerLevel == 0");
                }
                else if (threadLocalLockEntry._readerLevel > 0)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2((this._state & 1023/*LockStates.ReadersMask*/) !== 0, "(_state & LockStates.ReadersMask) != 0");
                    if (threadLocalLockEntry._readerLevel === 65535/*MaxAcquireCount*/)
                    {
                        throw new $.$$.System.OverflowException().$ctor$16($.$st.System.SR.Overflow_UInt16);
                    }
                    ++threadLocalLockEntry._readerLevel;
                    return;
                }
                else if (this._writerID === $.$st.System.Threading.ReaderWriterLock.GetCurrentThreadID())
                {
                    this.AcquireWriterLock(millisecondsTimeout);
                    $.$$.System.Diagnostics.Debug.Assert$2(threadLocalLockEntry.IsFree, "threadLocalLockEntry.IsFree");
                    return;
                }
                else 
                {
                    /*int*/ let spinCount = 0;
                    /*int*/ let currentState = this._state;
                    do
                    {
                        /*int*/ let knownState = currentState;
                        if (knownState < 1023/*LockStates.ReadersMask*/ || ((knownState & 1024/*LockStates.ReaderSignaled*/) !== 0 && (knownState & 4096/*LockStates.Writer*/) === 0 && (((((knownState & 1023/*LockStates.ReadersMask*/) + ((knownState & 8380416/*LockStates.WaitingReadersMask*/) >> 13/*LockStates.WaitingReadersShift*/)) | 0)) <= ((1023/*LockStates.ReadersMask*/ - 2) | 0))))
                        {
                            currentState = $.$$.System.Threading.Interlocked.CompareExchange$3($.$ref(() => this._state, ($v) => this._state = $v, $.$$.System.Int32), ((knownState + 1/*LockStates.Reader*/) | 0), knownState);
                            if (currentState === knownState)
                            {
                                break;
                            }
                            continue;
                        }
                        if ((knownState & 1023/*LockStates.ReadersMask*/) === 1023/*LockStates.ReadersMask*/ || (knownState & 8380416/*LockStates.WaitingReadersMask*/) === 8380416/*LockStates.WaitingReadersMask*/ || (knownState & 3072/*LockStates.CachingEvents*/) === 1024/*LockStates.ReaderSignaled*/)
                        {
                            /*int*/ let sleepDurationMilliseconds = 100;
                            if ((knownState & 1023/*LockStates.ReadersMask*/) === 1023/*LockStates.ReadersMask*/ || (knownState & 8380416/*LockStates.WaitingReadersMask*/) === 8380416/*LockStates.WaitingReadersMask*/)
                            {
                                sleepDurationMilliseconds = 1000;
                            }
                            $.$$.System.Threading.Thread.Sleep(sleepDurationMilliseconds);
                            spinCount = 0;
                            currentState = this._state;
                            continue;
                        }
                        ++spinCount;
                        if ((knownState & 3072/*LockStates.CachingEvents*/) === 3072/*LockStates.CachingEvents*/)
                        {
                            if (spinCount > $.$st.System.Threading.ReaderWriterLock.DefaultSpinCount)
                            {
                                $.$$.System.Threading.Thread.Sleep(1);
                                spinCount = 0;
                            }
                            currentState = this._state;
                            continue;
                        }
                        if (spinCount <= $.$st.System.Threading.ReaderWriterLock.DefaultSpinCount)
                        {
                            currentState = this._state;
                            continue;
                        }
                        currentState = $.$$.System.Threading.Interlocked.CompareExchange$3($.$ref(() => this._state, ($v) => this._state = $v, $.$$.System.Int32), ((knownState + 8192/*LockStates.WaitingReader*/) | 0), knownState);
                        if (currentState !== knownState)
                        {
                            continue;
                        }
                        /*int*/ let modifyState = -8192/*LockStates.WaitingReader*/;
                        /*ManualResetEventSlim?*/ let readerEvent = null;
                        /*bool*/ let waitSucceeded = false;
                        try
                        {
                            readerEvent = this.GetOrCreateReaderEvent();
                            waitSucceeded = readerEvent.Wait$2(millisecondsTimeout);
                            $.$$.System.Diagnostics.Debug.Assert$2(threadLocalLockEntry.HasLockID(this._lockID), "threadLocalLockEntry.HasLockID(_lockID)");
                            if (waitSucceeded)
                            {
                                $.$$.System.Diagnostics.Debug.Assert$2((this._state & 1024/*LockStates.ReaderSignaled*/) !== 0, "(_state & LockStates.ReaderSignaled) != 0");
                                $.$$.System.Diagnostics.Debug.Assert$2((this._state & 1023/*LockStates.ReadersMask*/) < 1023/*LockStates.ReadersMask*/, "(_state & LockStates.ReadersMask) < LockStates.ReadersMask");
                                modifyState += 1/*LockStates.Reader*/;
                            }
                        }
                        finally
                        {
                            {
                                knownState = (($.$$.System.Threading.Interlocked.Add($.$ref(() => this._state, ($v) => this._state = $v, $.$$.System.Int32), modifyState) - modifyState) | 0);
                                if (!waitSucceeded)
                                {
                                    if ((knownState & 1024/*LockStates.ReaderSignaled*/) !== 0 && (knownState & 8380416/*LockStates.WaitingReadersMask*/) === 8192/*LockStates.WaitingReader*/)
                                    {
                                        if (readerEvent === null)
                                        {
                                            readerEvent = this._readerEvent;
                                            $.$$.System.Diagnostics.Debug.Assert$2(readerEvent !== null, "readerEvent != null");
                                        }
                                        readerEvent.Wait();
                                        $.$$.System.Diagnostics.Debug.Assert$2((this._state & 1023/*LockStates.ReadersMask*/) < 1023/*LockStates.ReadersMask*/, "(_state & LockStates.ReadersMask) < LockStates.ReadersMask");
                                        readerEvent.Reset();
                                        $.$$.System.Threading.Interlocked.Add($.$ref(() => this._state, ($v) => this._state = $v, $.$$.System.Int32), ((1/*LockStates.Reader*/ - 1024/*LockStates.ReaderSignaled*/) | 0));
                                        ++threadLocalLockEntry._readerLevel;
                                        this.ReleaseReaderLock();
                                    }
                                    $.$$.System.Diagnostics.Debug.Assert$2(threadLocalLockEntry.IsFree, "threadLocalLockEntry.IsFree");
                                }
                            }
                        }
                        if (!waitSucceeded)
                        {
                            throw $.$st.System.Threading.ReaderWriterLock.GetTimeoutException();
                        }
                        $.$$.System.Diagnostics.Debug.Assert$2((knownState & 1024/*LockStates.ReaderSignaled*/) !== 0, "(knownState & LockStates.ReaderSignaled) != 0");
                        $.$$.System.Diagnostics.Debug.Assert$2((knownState & 1023/*LockStates.ReadersMask*/) < 1023/*LockStates.ReadersMask*/, "(knownState & LockStates.ReadersMask) < LockStates.ReadersMask");
                        if ((knownState & 8380416/*LockStates.WaitingReadersMask*/) === 8192/*LockStates.WaitingReader*/)
                        {
                            readerEvent.Reset();
                            $.$$.System.Threading.Interlocked.Add($.$ref(() => this._state, ($v) => this._state = $v, $.$$.System.Int32), -1024/*LockStates.ReaderSignaled*/);
                        }
                        break;
                    }
                    while($.$st.System.Threading.ReaderWriterLock.YieldProcessor());
                }
                $.$$.System.Diagnostics.Debug.Assert$2((this._state & 4096/*LockStates.Writer*/) === 0, "(_state & LockStates.Writer) == 0");
                $.$$.System.Diagnostics.Debug.Assert$2((this._state & 1023/*LockStates.ReadersMask*/) !== 0, "(_state & LockStates.ReadersMask) != 0");
                ++threadLocalLockEntry._readerLevel;
            }
            //--TRIMMABLE-BOUNDARY-END(42950524948)
            
            //--TRIMMABLE-BOUNDARY-START(47245492244)
            /*void */ AcquireReaderLock$1(/*TimeSpan*/ timeout)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47245492244);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.AcquireReaderLock($.$st.System.Threading.ReaderWriterLock.ToTimeoutMilliseconds(timeout));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47245492244)
            
            //--TRIMMABLE-BOUNDARY-START(51540459540)
            /*void */ AcquireWriterLock(/*int*/ millisecondsTimeout)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540459540);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentOutOfRangeException.ThrowIfLessThan($.$$.System.Int32, millisecondsTimeout, -1, "millisecondsTimeout");
                /*int*/ let threadID = $.$st.System.Threading.ReaderWriterLock.GetCurrentThreadID();
                if ($.$$.System.Threading.Interlocked.CompareExchange$3($.$ref(() => this._state, ($v) => this._state = $v, $.$$.System.Int32), 4096/*LockStates.Writer*/, 0) === 0)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2((this._state & 1023/*LockStates.ReadersMask*/) === 0, "(_state & LockStates.ReadersMask) == 0");
                }
                else if (this._writerID === threadID)
                {
                    if (this._writerLevel === 65535/*MaxAcquireCount*/)
                    {
                        throw new $.$$.System.OverflowException().$ctor$16($.$st.System.SR.Overflow_UInt16);
                    }
                    ++this._writerLevel;
                    return;
                }
                else 
                {
                    /*int*/ let spinCount = 0;
                    /*int*/ let currentState = this._state;
                    do
                    {
                        /*int*/ let knownState = currentState;
                        if (knownState === 0 || knownState === 3072/*LockStates.CachingEvents*/)
                        {
                            currentState = $.$$.System.Threading.Interlocked.CompareExchange$3($.$ref(() => this._state, ($v) => this._state = $v, $.$$.System.Int32), ((knownState + 4096/*LockStates.Writer*/) | 0), knownState);
                            if (currentState === knownState)
                            {
                                break;
                            }
                            continue;
                        }
                        if ((knownState & -8388608/*LockStates.WaitingWritersMask*/) === -8388608/*LockStates.WaitingWritersMask*/)
                        {
                            $.$$.System.Threading.Thread.Sleep(1000);
                            spinCount = 0;
                            currentState = this._state;
                            continue;
                        }
                        ++spinCount;
                        if ((knownState & 3072/*LockStates.CachingEvents*/) === 3072/*LockStates.CachingEvents*/)
                        {
                            if (spinCount > $.$st.System.Threading.ReaderWriterLock.DefaultSpinCount)
                            {
                                $.$$.System.Threading.Thread.Sleep(1);
                                spinCount = 0;
                            }
                            currentState = this._state;
                            continue;
                        }
                        if (spinCount <= $.$st.System.Threading.ReaderWriterLock.DefaultSpinCount)
                        {
                            currentState = this._state;
                            continue;
                        }
                        currentState = $.$$.System.Threading.Interlocked.CompareExchange$3($.$ref(() => this._state, ($v) => this._state = $v, $.$$.System.Int32), ((knownState + 8388608/*LockStates.WaitingWriter*/) | 0), knownState);
                        if (currentState !== knownState)
                        {
                            continue;
                        }
                        /*int*/ let modifyState = -8388608/*LockStates.WaitingWriter*/;
                        /*AutoResetEvent?*/ let writerEvent = null;
                        /*bool*/ let waitSucceeded = false;
                        try
                        {
                            writerEvent = this.GetOrCreateWriterEvent();
                            waitSucceeded = writerEvent.WaitOne$2(millisecondsTimeout);
                            if (waitSucceeded)
                            {
                                $.$$.System.Diagnostics.Debug.Assert$2((this._state & 2048/*LockStates.WriterSignaled*/) !== 0, "(_state & LockStates.WriterSignaled) != 0");
                                modifyState += ((4096/*LockStates.Writer*/ - 2048/*LockStates.WriterSignaled*/) | 0);
                            }
                        }
                        finally
                        {
                            {
                                knownState = (($.$$.System.Threading.Interlocked.Add($.$ref(() => this._state, ($v) => this._state = $v, $.$$.System.Int32), modifyState) - modifyState) | 0);
                                if (!waitSucceeded && (knownState & 2048/*LockStates.WriterSignaled*/) !== 0 && (knownState & -8388608/*LockStates.WaitingWritersMask*/) === 8388608/*LockStates.WaitingWriter*/)
                                {
                                    if (writerEvent === null)
                                    {
                                        writerEvent = this._writerEvent;
                                        $.$$.System.Diagnostics.Debug.Assert$2(writerEvent !== null, "writerEvent != null");
                                    }
                                    while(true)
                                    {
                                        knownState = this._state;
                                        if ((knownState & 2048/*LockStates.WriterSignaled*/) === 0 || (knownState & -8388608/*LockStates.WaitingWritersMask*/) !== 0)
                                        {
                                            break;
                                        }
                                        if (!writerEvent.WaitOne$2(10))
                                        {
                                            continue;
                                        }
                                        modifyState = ((4096/*LockStates.Writer*/ - 2048/*LockStates.WriterSignaled*/) | 0);
                                        knownState = (($.$$.System.Threading.Interlocked.Add($.$ref(() => this._state, ($v) => this._state = $v, $.$$.System.Int32), modifyState) - modifyState) | 0);
                                        $.$$.System.Diagnostics.Debug.Assert$2((knownState & 2048/*LockStates.WriterSignaled*/) !== 0, "(knownState & LockStates.WriterSignaled) != 0");
                                        $.$$.System.Diagnostics.Debug.Assert$2((knownState & 4096/*LockStates.Writer*/) === 0, "(knownState & LockStates.Writer) == 0");
                                        this._writerID = threadID;
                                        $.$$.System.Diagnostics.Debug.Assert$2(this._writerLevel === 0, "_writerLevel == 0");
                                        this._writerLevel = 1;
                                        this.ReleaseWriterLock();
                                        break;
                                    }
                                }
                            }
                        }
                        if (!waitSucceeded)
                        {
                            throw $.$st.System.Threading.ReaderWriterLock.GetTimeoutException();
                        }
                        break;
                    }
                    while($.$st.System.Threading.ReaderWriterLock.YieldProcessor());
                }
                $.$$.System.Diagnostics.Debug.Assert$2((this._state & 4096/*LockStates.Writer*/) !== 0, "(_state & LockStates.Writer) != 0");
                $.$$.System.Diagnostics.Debug.Assert$2((this._state & 1023/*LockStates.ReadersMask*/) === 0, "(_state & LockStates.ReadersMask) == 0");
                $.$$.System.Diagnostics.Debug.Assert$2(this._writerID === -1/*InvalidThreadID*/, "_writerID == InvalidThreadID");
                this._writerID = threadID;
                this._writerLevel = 1;
                ++this._writerSeqNum;
                return;
            }
            //--TRIMMABLE-BOUNDARY-END(51540459540)
            
            //--TRIMMABLE-BOUNDARY-START(55835426836)
            /*void */ AcquireWriterLock$1(/*TimeSpan*/ timeout)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55835426836);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.AcquireWriterLock($.$st.System.Threading.ReaderWriterLock.ToTimeoutMilliseconds(timeout));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55835426836)
            
            //--TRIMMABLE-BOUNDARY-START(167504576532)
            /*void */ ReleaseReaderLock()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504576532);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._writerID === $.$st.System.Threading.ReaderWriterLock.GetCurrentThreadID())
                {
                    this.ReleaseWriterLock();
                    return;
                }
                /*ThreadLocalLockEntry?*/ let threadLocalLockEntry = $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.GetCurrent(this._lockID);
                if (threadLocalLockEntry === null)
                {
                    throw $.$st.System.Threading.ReaderWriterLock.GetNotOwnerException();
                }
                $.$$.System.Diagnostics.Debug.Assert$2((this._state & 4096/*LockStates.Writer*/) === 0, "(_state & LockStates.Writer) == 0");
                $.$$.System.Diagnostics.Debug.Assert$2((this._state & 1023/*LockStates.ReadersMask*/) !== 0, "(_state & LockStates.ReadersMask) != 0");
                $.$$.System.Diagnostics.Debug.Assert$2(threadLocalLockEntry._readerLevel > 0, "threadLocalLockEntry._readerLevel > 0");
                --threadLocalLockEntry._readerLevel;
                if (threadLocalLockEntry._readerLevel > 0)
                {
                    return;
                }
                /*bool*/ let isLastReader;
                /*bool*/ let cacheEvents;
                /*AutoResetEvent?*/ let writerEvent = null;
                /*ManualResetEventSlim?*/ let readerEvent = null;
                /*int*/ let currentState = this._state;
                /*int*/ let knownState;
                do
                {
                    isLastReader = false;
                    cacheEvents = false;
                    knownState = currentState;
                    /*int*/ let modifyState = -1/*LockStates.Reader*/;
                    if ((knownState & (1023/*LockStates.ReadersMask*/ | 1024/*LockStates.ReaderSignaled*/)) === 1/*LockStates.Reader*/)
                    {
                        isLastReader = true;
                        if ((knownState & -8388608/*LockStates.WaitingWritersMask*/) !== 0)
                        {
                            writerEvent = this.TryGetOrCreateWriterEvent();
                            if (writerEvent === null)
                            {
                                $.$$.System.Threading.Thread.Sleep(100);
                                currentState = this._state;
                                knownState = 0;
                                $.$$.System.Diagnostics.Debug.Assert$2(currentState !== knownState, "currentState != knownState");
                                continue;
                            }
                            modifyState += 2048/*LockStates.WriterSignaled*/;
                        }
                        else if ((knownState & 8380416/*LockStates.WaitingReadersMask*/) !== 0)
                        {
                            readerEvent = this.TryGetOrCreateReaderEvent();
                            if (readerEvent === null)
                            {
                                $.$$.System.Threading.Thread.Sleep(100);
                                currentState = this._state;
                                knownState = 0;
                                $.$$.System.Diagnostics.Debug.Assert$2(currentState !== knownState, "currentState != knownState");
                                continue;
                            }
                            modifyState += 1024/*LockStates.ReaderSignaled*/;
                        }
                        else if (knownState === 1/*LockStates.Reader*/ && (this._readerEvent !== null || this._writerEvent !== null))
                        {
                            cacheEvents = true;
                            modifyState += 3072/*LockStates.CachingEvents*/;
                        }
                    }
                    $.$$.System.Diagnostics.Debug.Assert$2((knownState & 4096/*LockStates.Writer*/) === 0, "(knownState & LockStates.Writer) == 0");
                    $.$$.System.Diagnostics.Debug.Assert$2((knownState & 1023/*LockStates.ReadersMask*/) !== 0, "(knownState & LockStates.ReadersMask) != 0");
                    currentState = $.$$.System.Threading.Interlocked.CompareExchange$3($.$ref(() => this._state, ($v) => this._state = $v, $.$$.System.Int32), ((knownState + modifyState) | 0), knownState);
                }
                while(currentState !== knownState);
                if (isLastReader)
                {
                    if ((knownState & -8388608/*LockStates.WaitingWritersMask*/) !== 0)
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2((this._state & 2048/*LockStates.WriterSignaled*/) !== 0, "(_state & LockStates.WriterSignaled) != 0");
                        $.$$.System.Diagnostics.Debug.Assert$2(writerEvent !== null, "writerEvent != null");
                        writerEvent.Set$1();
                    }
                    else if ((knownState & 8380416/*LockStates.WaitingReadersMask*/) !== 0)
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2((this._state & 1024/*LockStates.ReaderSignaled*/) !== 0, "(_state & LockStates.ReaderSignaled) != 0");
                        $.$$.System.Diagnostics.Debug.Assert$2(readerEvent !== null, "readerEvent != null");
                        readerEvent.Set$1();
                    }
                    else if (cacheEvents)
                    {
                        this.ReleaseEvents();
                    }
                }
                $.$$.System.Diagnostics.Debug.Assert$2(threadLocalLockEntry.IsFree, "threadLocalLockEntry.IsFree");
            }
            //--TRIMMABLE-BOUNDARY-END(167504576532)
            
            //--TRIMMABLE-BOUNDARY-START(171799543828)
            /*void */ ReleaseWriterLock()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799543828);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._writerID !== $.$st.System.Threading.ReaderWriterLock.GetCurrentThreadID())
                {
                    throw $.$st.System.Threading.ReaderWriterLock.GetNotOwnerException();
                }
                $.$$.System.Diagnostics.Debug.Assert$2((this._state & 1023/*LockStates.ReadersMask*/) === 0, "(_state & LockStates.ReadersMask) == 0");
                $.$$.System.Diagnostics.Debug.Assert$2((this._state & 4096/*LockStates.Writer*/) !== 0, "(_state & LockStates.Writer) != 0");
                $.$$.System.Diagnostics.Debug.Assert$2(this._writerLevel > 0, "_writerLevel > 0");
                --this._writerLevel;
                if (this._writerLevel > 0)
                {
                    return;
                }
                this._writerID = -1/*InvalidThreadID*/;
                /*bool*/ let cacheEvents;
                /*ManualResetEventSlim?*/ let readerEvent = null;
                /*AutoResetEvent?*/ let writerEvent = null;
                /*int*/ let currentState = this._state;
                /*int*/ let knownState;
                do
                {
                    cacheEvents = false;
                    knownState = currentState;
                    /*int*/ let modifyState = -4096/*LockStates.Writer*/;
                    if ((knownState & 8380416/*LockStates.WaitingReadersMask*/) !== 0)
                    {
                        readerEvent = this.TryGetOrCreateReaderEvent();
                        if (readerEvent === null)
                        {
                            $.$$.System.Threading.Thread.Sleep(100);
                            currentState = this._state;
                            knownState = 0;
                            $.$$.System.Diagnostics.Debug.Assert$2(currentState !== knownState, "currentState != knownState");
                            continue;
                        }
                        modifyState += 1024/*LockStates.ReaderSignaled*/;
                    }
                    else if ((knownState & -8388608/*LockStates.WaitingWritersMask*/) !== 0)
                    {
                        writerEvent = this.TryGetOrCreateWriterEvent();
                        if (writerEvent === null)
                        {
                            $.$$.System.Threading.Thread.Sleep(100);
                            currentState = this._state;
                            knownState = 0;
                            $.$$.System.Diagnostics.Debug.Assert$2(currentState !== knownState, "currentState != knownState");
                            continue;
                        }
                        modifyState += 2048/*LockStates.WriterSignaled*/;
                    }
                    else if (knownState === 4096/*LockStates.Writer*/ && (this._readerEvent !== null || this._writerEvent !== null))
                    {
                        cacheEvents = true;
                        modifyState += 3072/*LockStates.CachingEvents*/;
                    }
                    $.$$.System.Diagnostics.Debug.Assert$2((knownState & 1023/*LockStates.ReadersMask*/) === 0, "(knownState & LockStates.ReadersMask) == 0");
                    $.$$.System.Diagnostics.Debug.Assert$2((knownState & 4096/*LockStates.Writer*/) !== 0, "(knownState & LockStates.Writer) != 0");
                    currentState = $.$$.System.Threading.Interlocked.CompareExchange$3($.$ref(() => this._state, ($v) => this._state = $v, $.$$.System.Int32), ((knownState + modifyState) | 0), knownState);
                }
                while(currentState !== knownState);
                if ((knownState & 8380416/*LockStates.WaitingReadersMask*/) !== 0)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2((this._state & 1024/*LockStates.ReaderSignaled*/) !== 0, "(_state & LockStates.ReaderSignaled) != 0");
                    $.$$.System.Diagnostics.Debug.Assert$2(readerEvent !== null, "readerEvent != null");
                    readerEvent.Set$1();
                }
                else if ((knownState & -8388608/*LockStates.WaitingWritersMask*/) !== 0)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2((this._state & 2048/*LockStates.WriterSignaled*/) !== 0, "(_state & LockStates.WriterSignaled) != 0");
                    $.$$.System.Diagnostics.Debug.Assert$2(writerEvent !== null, "writerEvent != null");
                    writerEvent.Set$1();
                }
                else if (cacheEvents)
                {
                    this.ReleaseEvents();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(171799543828)
            
            //--TRIMMABLE-BOUNDARY-START(201864314900)
            /*LockCookie */ UpgradeToWriterLock(/*int*/ millisecondsTimeout)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201864314900);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentOutOfRangeException.ThrowIfLessThan($.$$.System.Int32, millisecondsTimeout, -1, "millisecondsTimeout");
                /*LockCookie*/ let lockCookie = new $.$st.System.Threading.LockCookie();
                /*int*/ let threadID = $.$st.System.Threading.ReaderWriterLock.GetCurrentThreadID();
                lockCookie._threadID = threadID;
                if (this._writerID === threadID)
                {
                    lockCookie._flags = 8192/*LockCookieFlags.Upgrade*/ | 131072/*LockCookieFlags.OwnedWriter*/;
                    lockCookie._writerLevel = this._writerLevel;
                    this.AcquireWriterLock(millisecondsTimeout);
                    return lockCookie;
                }
                /*ThreadLocalLockEntry?*/ let threadLocalLockEntry = $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.GetCurrent(this._lockID);
                if (threadLocalLockEntry === null)
                {
                    lockCookie._flags = 8192/*LockCookieFlags.Upgrade*/ | 65536/*LockCookieFlags.OwnedNone*/;
                }
                else 
                {
                    $.$$.System.Diagnostics.Debug.Assert$2((this._state & 1023/*LockStates.ReadersMask*/) !== 0, "(_state & LockStates.ReadersMask) != 0");
                    $.$$.System.Diagnostics.Debug.Assert$2(threadLocalLockEntry._readerLevel > 0, "threadLocalLockEntry._readerLevel > 0");
                    lockCookie._flags = 8192/*LockCookieFlags.Upgrade*/ | 262144/*LockCookieFlags.OwnedReader*/;
                    lockCookie._readerLevel = threadLocalLockEntry._readerLevel;
                    /*int*/ let knownState = $.$$.System.Threading.Interlocked.CompareExchange$3($.$ref(() => this._state, ($v) => this._state = $v, $.$$.System.Int32), 4096/*LockStates.Writer*/, 1/*LockStates.Reader*/);
                    if (knownState === 1/*LockStates.Reader*/)
                    {
                        threadLocalLockEntry._readerLevel = 0;
                        $.$$.System.Diagnostics.Debug.Assert$2(threadLocalLockEntry.IsFree, "threadLocalLockEntry.IsFree");
                        this._writerID = threadID;
                        this._writerLevel = 1;
                        ++this._writerSeqNum;
                        return lockCookie;
                    }
                    threadLocalLockEntry._readerLevel = 1;
                    this.ReleaseReaderLock();
                }
                /*bool*/ let acquired = false;
                try
                {
                    this.AcquireWriterLock(millisecondsTimeout);
                    acquired = true;
                    return lockCookie;
                }
                finally
                {
                    {
                        if (!acquired)
                        {
                            /*LockCookieFlags*/ let flags = lockCookie._flags;
                            lockCookie._flags = -483329/*LockCookieFlags.Invalid*/;
                            this.RecoverLock($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$st.System.Threading.LockCookie, () => lockCookie, ($v) => lockCookie = $v, null), flags & 262144/*LockCookieFlags.OwnedReader*/);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(201864314900)
            
            //--TRIMMABLE-BOUNDARY-START(206159282196)
            /*LockCookie */ UpgradeToWriterLock$1(/*TimeSpan*/ timeout)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(206159282196);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.UpgradeToWriterLock($.$st.System.Threading.ReaderWriterLock.ToTimeoutMilliseconds(timeout));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(206159282196)
            
            //--TRIMMABLE-BOUNDARY-START(68720328724)
            /*void */ DowngradeFromWriterLock(/*ref LockCookie*/ lockCookie)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720328724);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let threadID = $.$st.System.Threading.ReaderWriterLock.GetCurrentThreadID();
                if (this._writerID !== threadID)
                {
                    throw $.$st.System.Threading.ReaderWriterLock.GetNotOwnerException();
                }
                /*LockCookieFlags*/ let flags = lockCookie.$v._flags;
                /*ushort*/ let requestedWriterLevel = lockCookie.$v._writerLevel;
                if ((flags & -483329/*LockCookieFlags.Invalid*/) !== 0 || lockCookie.$v._threadID !== threadID || ((flags & (131072/*LockCookieFlags.OwnedWriter*/ | 65536/*LockCookieFlags.OwnedNone*/)) !== 0 && this._writerLevel <= requestedWriterLevel))
                {
                    throw $.$st.System.Threading.ReaderWriterLock.GetInvalidLockCookieException();
                }
                if ((flags & 262144/*LockCookieFlags.OwnedReader*/) !== 0)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(this._writerLevel > 0, "_writerLevel > 0");
                    /*ThreadLocalLockEntry*/ let threadLocalLockEntry = $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.GetOrCreateCurrent(this._lockID);
                    this._writerID = -1/*InvalidThreadID*/;
                    this._writerLevel = 0;
                    /*ManualResetEventSlim?*/ let readerEvent = null;
                    /*int*/ let currentState = this._state;
                    /*int*/ let knownState;
                    do
                    {
                        knownState = currentState;
                        /*int*/ let modifyState = ((1/*LockStates.Reader*/ - 4096/*LockStates.Writer*/) | 0);
                        if ((knownState & 8380416/*LockStates.WaitingReadersMask*/) !== 0)
                        {
                            readerEvent = this.TryGetOrCreateReaderEvent();
                            if (readerEvent === null)
                            {
                                $.$$.System.Threading.Thread.Sleep(100);
                                currentState = this._state;
                                knownState = 0;
                                $.$$.System.Diagnostics.Debug.Assert$2(currentState !== knownState, "currentState != knownState");
                                continue;
                            }
                            modifyState += 1024/*LockStates.ReaderSignaled*/;
                        }
                        $.$$.System.Diagnostics.Debug.Assert$2((knownState & 1023/*LockStates.ReadersMask*/) === 0, "(knownState & LockStates.ReadersMask) == 0");
                        currentState = $.$$.System.Threading.Interlocked.CompareExchange$3($.$ref(() => this._state, ($v) => this._state = $v, $.$$.System.Int32), ((knownState + modifyState) | 0), knownState);
                    }
                    while(currentState !== knownState);
                    if ((knownState & 8380416/*LockStates.WaitingReadersMask*/) !== 0)
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2((this._state & 1024/*LockStates.ReaderSignaled*/) !== 0, "(_state & LockStates.ReaderSignaled) != 0");
                        $.$$.System.Diagnostics.Debug.Assert$2(readerEvent !== null, "readerEvent != null");
                        readerEvent.Set$1();
                    }
                    threadLocalLockEntry._readerLevel = lockCookie.$v._readerLevel;
                }
                else if ((flags & (131072/*LockCookieFlags.OwnedWriter*/ | 65536/*LockCookieFlags.OwnedNone*/)) !== 0)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(this._writerLevel > 0, "_writerLevel > 0");
                    $.$$.System.Diagnostics.Debug.Assert$2(this._writerLevel > requestedWriterLevel, "_writerLevel > requestedWriterLevel");
                    if (requestedWriterLevel > 0)
                    {
                        this._writerLevel = requestedWriterLevel;
                    }
                    else 
                    {
                        if (this._writerLevel !== 1)
                        {
                            this._writerLevel = 1;
                        }
                        this.ReleaseWriterLock();
                    }
                    $.$$.System.Diagnostics.Debug.Assert$2((flags & 131072/*LockCookieFlags.OwnedWriter*/) !== 0 || this._writerID !== threadID, "(flags & LockCookieFlags.OwnedWriter) != 0 || _writerID != threadID");
                }
                lockCookie.$v._flags = -483329/*LockCookieFlags.Invalid*/;
            }
            //--TRIMMABLE-BOUNDARY-END(68720328724)
            
            //--TRIMMABLE-BOUNDARY-START(163209609236)
            /*LockCookie */ ReleaseLock()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209609236);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*LockCookie*/ let lockCookie = new $.$st.System.Threading.LockCookie();
                /*int*/ let threadID = $.$st.System.Threading.ReaderWriterLock.GetCurrentThreadID();
                lockCookie._threadID = threadID;
                if (this._writerID === threadID)
                {
                    lockCookie._flags = 16384/*LockCookieFlags.Release*/ | 131072/*LockCookieFlags.OwnedWriter*/;
                    lockCookie._writerLevel = this._writerLevel;
                    this._writerLevel = 1;
                    this.ReleaseWriterLock();
                    return lockCookie;
                }
                /*ThreadLocalLockEntry?*/ let threadLocalLockEntry = $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.GetCurrent(this._lockID);
                if (threadLocalLockEntry === null)
                {
                    lockCookie._flags = 16384/*LockCookieFlags.Release*/ | 65536/*LockCookieFlags.OwnedNone*/;
                    return lockCookie;
                }
                $.$$.System.Diagnostics.Debug.Assert$2((this._state & 1023/*LockStates.ReadersMask*/) !== 0, "(_state & LockStates.ReadersMask) != 0");
                $.$$.System.Diagnostics.Debug.Assert$2(threadLocalLockEntry._readerLevel > 0, "threadLocalLockEntry._readerLevel > 0");
                lockCookie._flags = 16384/*LockCookieFlags.Release*/ | 262144/*LockCookieFlags.OwnedReader*/;
                lockCookie._readerLevel = threadLocalLockEntry._readerLevel;
                threadLocalLockEntry._readerLevel = 1;
                this.ReleaseReaderLock();
                return lockCookie;
            }
            //--TRIMMABLE-BOUNDARY-END(163209609236)
            
            //--TRIMMABLE-BOUNDARY-START(176094511124)
            /*void */ RestoreLock(/*ref LockCookie*/ lockCookie)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094511124);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let threadID = $.$st.System.Threading.ReaderWriterLock.GetCurrentThreadID();
                if (lockCookie.$v._threadID !== threadID)
                {
                    throw $.$st.System.Threading.ReaderWriterLock.GetInvalidLockCookieException();
                }
                if (this._writerID === threadID || $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.GetCurrent(this._lockID) !== null)
                {
                    throw new $.$$.System.Threading.SynchronizationLockException().$ctor$12($.$st.System.SR.ReaderWriterLock_RestoreLockWithOwnedLocks);
                }
                /*LockCookieFlags*/ let flags = lockCookie.$v._flags;
                if ((flags & -483329/*LockCookieFlags.Invalid*/) !== 0)
                {
                    throw $.$st.System.Threading.ReaderWriterLock.GetInvalidLockCookieException();
                }
                do
                {
                    if ((flags & 65536/*LockCookieFlags.OwnedNone*/) !== 0)
                    {
                        break;
                    }
                    if ((flags & 131072/*LockCookieFlags.OwnedWriter*/) !== 0)
                    {
                        if ($.$$.System.Threading.Interlocked.CompareExchange$3($.$ref(() => this._state, ($v) => this._state = $v, $.$$.System.Int32), 4096/*LockStates.Writer*/, 0) === 0)
                        {
                            this._writerID = threadID;
                            this._writerLevel = lockCookie.$v._writerLevel;
                            ++this._writerSeqNum;
                            break;
                        }
                    }
                    else if ((flags & 262144/*LockCookieFlags.OwnedReader*/) !== 0)
                    {
                        /*ThreadLocalLockEntry*/ let threadLocalLockEntry = $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.GetOrCreateCurrent(this._lockID);
                        $.$$.System.Diagnostics.Debug.Assert$2(threadLocalLockEntry.IsFree, "threadLocalLockEntry.IsFree");
                        /*int*/ let knownState = this._state;
                        if (knownState < 1023/*LockStates.ReadersMask*/ && $.$$.System.Threading.Interlocked.CompareExchange$3($.$ref(() => this._state, ($v) => this._state = $v, $.$$.System.Int32), ((knownState + 1/*LockStates.Reader*/) | 0), knownState) === knownState)
                        {
                            threadLocalLockEntry._readerLevel = lockCookie.$v._readerLevel;
                            break;
                        }
                    }
                    this.RecoverLock(lockCookie, flags);
                }
                while(false);
                lockCookie.$v._flags = -483329/*LockCookieFlags.Invalid*/;
            }
            //--TRIMMABLE-BOUNDARY-END(176094511124)
            
            //--TRIMMABLE-BOUNDARY-START(154619674644)
            /*void */ RecoverLock(/*ref LockCookie*/ lockCookie, /*LockCookieFlags*/ flags)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619674644);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ((flags & 131072/*LockCookieFlags.OwnedWriter*/) !== 0)
                {
                    this.AcquireWriterLock(-1/*Timeout.Infinite*/);
                    this._writerLevel = lockCookie.$v._writerLevel;
                }
                else if ((flags & 262144/*LockCookieFlags.OwnedReader*/) !== 0)
                {
                    this.AcquireReaderLock(-1/*Timeout.Infinite*/);
                    /*ThreadLocalLockEntry?*/ let threadLocalLockEntry = $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.GetCurrent(this._lockID);
                    $.$$.System.Diagnostics.Debug.Assert$2(threadLocalLockEntry !== null, "threadLocalLockEntry != null");
                    threadLocalLockEntry._readerLevel = lockCookie.$v._readerLevel;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(154619674644)
            
            //--TRIMMABLE-BOUNDARY-START(98785099796)
            static /*int */ GetCurrentThreadID()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785099796);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let threadID = $.$$.System.Environment.CurrentManagedThreadId;
                $.$$.System.Diagnostics.Debug.Assert$2(threadID !== -1/*InvalidThreadID*/, "threadID != InvalidThreadID");
                return threadID;
            }
            //--TRIMMABLE-BOUNDARY-END(98785099796)
            
            //--TRIMMABLE-BOUNDARY-START(214749216788)
            static /*bool */ YieldProcessor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214749216788);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Threading.Thread.SpinWait(1);
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(214749216788)
            
            //--TRIMMABLE-BOUNDARY-START(111670001684)
            /*ManualResetEventSlim */ GetOrCreateReaderEvent()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670001684);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ManualResetEventSlim?*/ let currentEvent = this._readerEvent;
                if (currentEvent !== null)
                {
                    return currentEvent;
                }
                currentEvent = new $.$$.System.Threading.ManualResetEventSlim().$ctor$2(false, 0);
                /*ManualResetEventSlim?*/ let previousEvent = $.$$.System.Threading.Interlocked.CompareExchange$14($.$$.System.Threading.ManualResetEventSlim, $.$ref(() => this._readerEvent, ($v) => this._readerEvent = $v, $.$$.System.Threading.ManualResetEventSlim), currentEvent, null);
                if (previousEvent === null)
                {
                    return currentEvent;
                }
                currentEvent.Dispose();
                return previousEvent;
            }
            //--TRIMMABLE-BOUNDARY-END(111670001684)
            
            //--TRIMMABLE-BOUNDARY-START(115964968980)
            /*AutoResetEvent */ GetOrCreateWriterEvent()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964968980);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*AutoResetEvent?*/ let currentEvent = this._writerEvent;
                if (currentEvent !== null)
                {
                    return currentEvent;
                }
                currentEvent = new $.$$.System.Threading.AutoResetEvent().$ctor$8(false);
                /*AutoResetEvent?*/ let previousEvent = $.$$.System.Threading.Interlocked.CompareExchange$14($.$$.System.Threading.AutoResetEvent, $.$ref(() => this._writerEvent, ($v) => this._writerEvent = $v, $.$$.System.Threading.AutoResetEvent), currentEvent, null);
                if (previousEvent === null)
                {
                    return currentEvent;
                }
                currentEvent.Dispose();
                return previousEvent;
            }
            //--TRIMMABLE-BOUNDARY-END(115964968980)
            
            //--TRIMMABLE-BOUNDARY-START(193274380308)
            /*ManualResetEventSlim? */ TryGetOrCreateReaderEvent()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193274380308);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                try
                {
                    return this.GetOrCreateReaderEvent();
                }
                catch($e)
                {
                    return null;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(193274380308)
            
            //--TRIMMABLE-BOUNDARY-START(197569347604)
            /*AutoResetEvent? */ TryGetOrCreateWriterEvent()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197569347604);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                try
                {
                    return this.GetOrCreateWriterEvent();
                }
                catch($e)
                {
                    return null;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(197569347604)
            
            //--TRIMMABLE-BOUNDARY-START(158914641940)
            /*void */ ReleaseEvents()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914641940);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2((this._state & 3072/*LockStates.CachingEvents*/) === 3072/*LockStates.CachingEvents*/, "(_state & LockStates.CachingEvents) == LockStates.CachingEvents");
                /*AutoResetEvent?*/ let writerEvent = this._writerEvent;
                this._writerEvent = null;
                /*ManualResetEventSlim?*/ let readerEvent = this._readerEvent;
                this._readerEvent = null;
                $.$$.System.Threading.Interlocked.Add($.$ref(() => this._state, ($v) => this._state = $v, $.$$.System.Int32), -3072/*LockStates.CachingEvents*/);
                writerEvent?.Dispose();
                readerEvent?.Dispose();
            }
            //--TRIMMABLE-BOUNDARY-END(158914641940)
            
            //--TRIMMABLE-BOUNDARY-START(188979413012)
            static /*int */ ToTimeoutMilliseconds(/*TimeSpan*/ timeout)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188979413012);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let timeoutMilliseconds = $.$cast(timeout.TotalMilliseconds, $.$$.System.Int64);
                $.$$.System.ArgumentOutOfRangeException.ThrowIfLessThan($.$$.System.Int64, timeoutMilliseconds, BigInt(-1), "timeout");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$$.System.Int64, timeoutMilliseconds, BigInt(2147483647/*int.MaxValue*/), "timeout");
                return $.$cast(timeoutMilliseconds, $.$$.System.Int32);
            }
            //--TRIMMABLE-BOUNDARY-END(188979413012)
            
            //--TRIMMABLE-BOUNDARY-START(983060)
            static $_ReaderWriterLockApplicationException;
            static get ReaderWriterLockApplicationException()
            {
                let $cls = $.$st.System.Threading.ReaderWriterLock;
                return $cls.$_ReaderWriterLockApplicationException ??= $asm.$ncls("$st.System.Threading.ReaderWriterLock.ReaderWriterLockApplicationException", ($self) => class ReaderWriterLockApplicationException extends $.$$.System.ApplicationException
                {
                    //--TRIMMABLE-BOUNDARY-START(4295950356)
                    $ctor$9(/*int*/ errorHResult, /*string*/ message)
                    {
                        super.$ctor$8($.$st.System.SR.Format$6(message, $.$st.System.SR.Format$6($.$st.System.SR.ExceptionFromHResult, $.$box(errorHResult, $.$$.System.Int32))));
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4295950356);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.HResult = errorHResult;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295950356)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590917652)
                    $ctor$10(/*SerializationInfo*/ info, /*StreamingContext*/ context)
                    {
                        super.$ctor$6(info, context);
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8590917652);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590917652)
                    
                    static $h = 983060;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 43909121,
  "d": 851988,
  "h": 983060
}; }
                    static get $b() { return $.$$.System.ApplicationException; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Runtime.Serialization.ISerializable ]; }
                    static get $fullName() { return `System.Threading.ReaderWriterLock.ReaderWriterLockApplicationException`; }
                }, $cls, ($v) => $cls.$_ReaderWriterLockApplicationException = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(983060)
            
            //--TRIMMABLE-BOUNDARY-START(120259936276)
            static /*ReaderWriterLockApplicationException */ GetTimeoutException()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259936276);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$st.System.Threading.ReaderWriterLock.ReaderWriterLockApplicationException().$ctor$9(-2147023436/*HResults.ERROR_TIMEOUT*/, $.$st.System.SR.ReaderWriterLock_Timeout);
            }
            //--TRIMMABLE-BOUNDARY-END(120259936276)
            
            //--TRIMMABLE-BOUNDARY-START(107375034388)
            static /*ReaderWriterLockApplicationException */ GetNotOwnerException()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375034388);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$st.System.Threading.ReaderWriterLock.ReaderWriterLockApplicationException().$ctor$9(288/*IncorrectButCompatibleNotOwnerExceptionHResult*/, $.$st.System.SR.ReaderWriterLock_NotOwner);
            }
            //--TRIMMABLE-BOUNDARY-END(107375034388)
            
            //--TRIMMABLE-BOUNDARY-START(103080067092)
            static /*ReaderWriterLockApplicationException */ GetInvalidLockCookieException()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080067092);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$st.System.Threading.ReaderWriterLock.ReaderWriterLockApplicationException().$ctor$9(-2147024809/*HResults.E_INVALIDARG*/, $.$st.System.SR.ReaderWriterLock_InvalidLockCookie);
            }
            //--TRIMMABLE-BOUNDARY-END(103080067092)
            
            //--TRIMMABLE-BOUNDARY-START(917524)
            static $_LockStates;
            static get LockStates()
            {
                let $cls = $.$st.System.Threading.ReaderWriterLock;
                return $cls.$_LockStates ??= $asm.$ncls("$st.System.Threading.ReaderWriterLock.LockStates", ($self) => class LockStates
                {
                    //--TRIMMABLE-BOUNDARY-START(8590852116)
                    /*int*/ static Reader = 1;
                    //--TRIMMABLE-BOUNDARY-END(8590852116)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180786708)
                    /*int*/ static ReadersMask = 1023;
                    //--TRIMMABLE-BOUNDARY-END(17180786708)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885819412)
                    /*int*/ static ReaderSignaled = 1024;
                    //--TRIMMABLE-BOUNDARY-END(12885819412)
                    
                    //--TRIMMABLE-BOUNDARY-START(47245557780)
                    /*int*/ static WriterSignaled = 2048;
                    //--TRIMMABLE-BOUNDARY-END(47245557780)
                    
                    //--TRIMMABLE-BOUNDARY-START(42950590484)
                    /*int*/ static Writer = 4096;
                    //--TRIMMABLE-BOUNDARY-END(42950590484)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475754004)
                    /*int*/ static WaitingReader = 8192;
                    //--TRIMMABLE-BOUNDARY-END(21475754004)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770721300)
                    /*int*/ static WaitingReadersMask = 8380416;
                    //--TRIMMABLE-BOUNDARY-END(25770721300)
                    
                    //--TRIMMABLE-BOUNDARY-START(30065688596)
                    /*int*/ static WaitingReadersShift = 13;
                    //--TRIMMABLE-BOUNDARY-END(30065688596)
                    
                    //--TRIMMABLE-BOUNDARY-START(34360655892)
                    /*int*/ static WaitingWriter = 8388608;
                    //--TRIMMABLE-BOUNDARY-END(34360655892)
                    
                    //--TRIMMABLE-BOUNDARY-START(38655623188)
                    /*int*/ static WaitingWritersMask = -8388608;
                    //--TRIMMABLE-BOUNDARY-END(38655623188)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295884820)
                    /*int*/ static CachingEvents = 3072;
                    //--TRIMMABLE-BOUNDARY-END(4295884820)
                    
                    static $h = 917524;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590852116),
    {
      "t": 655361,
      "n": "Reader",
      "d": 917524,
      "h": 8590852116,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590852116),
//--TRIMMABLE-BOUNDARY-START(17180786708),
    {
      "t": 655361,
      "n": "ReadersMask",
      "d": 917524,
      "h": 17180786708,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180786708),
//--TRIMMABLE-BOUNDARY-START(12885819412),
    {
      "t": 655361,
      "n": "ReaderSignaled",
      "d": 917524,
      "h": 12885819412,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885819412),
//--TRIMMABLE-BOUNDARY-START(47245557780),
    {
      "t": 655361,
      "n": "WriterSignaled",
      "d": 917524,
      "h": 47245557780,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47245557780),
//--TRIMMABLE-BOUNDARY-START(42950590484),
    {
      "t": 655361,
      "n": "Writer",
      "d": 917524,
      "h": 42950590484,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42950590484),
//--TRIMMABLE-BOUNDARY-START(21475754004),
    {
      "t": 655361,
      "n": "WaitingReader",
      "d": 917524,
      "h": 21475754004,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475754004),
//--TRIMMABLE-BOUNDARY-START(25770721300),
    {
      "t": 655361,
      "n": "WaitingReadersMask",
      "d": 917524,
      "h": 25770721300,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770721300),
//--TRIMMABLE-BOUNDARY-START(30065688596),
    {
      "t": 655361,
      "n": "WaitingReadersShift",
      "d": 917524,
      "h": 30065688596,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065688596),
//--TRIMMABLE-BOUNDARY-START(34360655892),
    {
      "t": 655361,
      "n": "WaitingWriter",
      "d": 917524,
      "h": 34360655892,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360655892),
//--TRIMMABLE-BOUNDARY-START(38655623188),
    {
      "t": 655361,
      "n": "WaitingWritersMask",
      "d": 917524,
      "h": 38655623188,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38655623188),
//--TRIMMABLE-BOUNDARY-START(4295884820),
    {
      "t": 655361,
      "n": "CachingEvents",
      "d": 917524,
      "h": 4295884820,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(4295884820)
  ],
  "d": 851988,
  "h": 917524
}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Threading.ReaderWriterLock.LockStates`; }
                }, $cls, ($v) => $cls.$_LockStates = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(917524)
            
            //--TRIMMABLE-BOUNDARY-START(1048596)
            static $_ThreadLocalLockEntry;
            static get ThreadLocalLockEntry()
            {
                let $cls = $.$st.System.Threading.ReaderWriterLock;
                return $cls.$_ThreadLocalLockEntry ??= $asm.$ncls("$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry", ($self) => class ThreadLocalLockEntry extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(51540656148)
                    /*ThreadLocalLockEntry?*/ static t_lockEntryHead = null;
                    //--TRIMMABLE-BOUNDARY-END(51540656148)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296015892)
                    /*long*/ _lockID = 0n;
                    //--TRIMMABLE-BOUNDARY-END(4296015892)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590983188)
                    /*ThreadLocalLockEntry?*/ _next = null;
                    //--TRIMMABLE-BOUNDARY-END(8590983188)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885950484)
                    /*ushort*/ _readerLevel = 0;
                    //--TRIMMABLE-BOUNDARY-END(12885950484)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180917780)
                    $ctor$1(/*long*/ lockID)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(17180917780);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._lockID = lockID;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180917780)
                    
                    //--TRIMMABLE-BOUNDARY-START(42950721556)
                    /*bool */ HasLockID(/*long*/ lockID)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(42950721556);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._lockID === lockID;
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(42950721556)
                    
                    //--TRIMMABLE-BOUNDARY-START(47245688852)
                    /*bool */ get IsFree()
                    {
                        return this._readerLevel === 0;
                    }
                    //--TRIMMABLE-BOUNDARY-END(47245688852)
                    
                    //--TRIMMABLE-BOUNDARY-START(55835623444)
                    static /*void */ VerifyNoNonemptyEntryInListAfter(/*long*/ lockID, /*ThreadLocalLockEntry*/ afterEntry)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(55835623444);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.System.Diagnostics.Debug.Assert$2(lockID !== 0n, "lockID != 0");
                        $.$$.System.Diagnostics.Debug.Assert$2(afterEntry !== null, "afterEntry != null");
                        for(/*ThreadLocalLockEntry?*/ let currentEntry = afterEntry._next; currentEntry !== null; currentEntry = currentEntry._next)
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(currentEntry._lockID !== lockID || currentEntry.IsFree, "currentEntry._lockID != lockID || currentEntry.IsFree");
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(55835623444)
                    
                    //--TRIMMABLE-BOUNDARY-START(30065819668)
                    static /*ThreadLocalLockEntry? */ GetCurrent(/*long*/ lockID)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(30065819668);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.System.Diagnostics.Debug.Assert$2(lockID !== 0n, "lockID != 0");
                        /*ThreadLocalLockEntry?*/ let headEntry = $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.t_lockEntryHead;
                        for(/*ThreadLocalLockEntry?*/ let currentEntry = headEntry; currentEntry !== null; currentEntry = currentEntry._next)
                        {
                            if (currentEntry._lockID === lockID)
                            {
                                $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.VerifyNoNonemptyEntryInListAfter(lockID, currentEntry);
                                return currentEntry.IsFree ? null : currentEntry;
                            }
                        }
                        return null;
                    }
                    //--TRIMMABLE-BOUNDARY-END(30065819668)
                    
                    //--TRIMMABLE-BOUNDARY-START(34360786964)
                    static /*ThreadLocalLockEntry */ GetOrCreateCurrent(/*long*/ lockID)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34360786964);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.System.Diagnostics.Debug.Assert$2(lockID !== 0n, "lockID != 0");
                        /*ThreadLocalLockEntry?*/ let headEntry = $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.t_lockEntryHead;
                        if (headEntry !== null && headEntry._lockID === lockID)
                        {
                            $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.VerifyNoNonemptyEntryInListAfter(lockID, headEntry);
                            return headEntry;
                        }
                        return $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.GetOrCreateCurrentSlow(lockID, headEntry);
                    }
                    //--TRIMMABLE-BOUNDARY-END(34360786964)
                    
                    //--TRIMMABLE-BOUNDARY-START(38655754260)
                    static /*ThreadLocalLockEntry */ GetOrCreateCurrentSlow(/*long*/ lockID, /*ThreadLocalLockEntry?*/ headEntry)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(38655754260);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.System.Diagnostics.Debug.Assert$2(lockID !== 0n, "lockID != 0");
                        $.$$.System.Diagnostics.Debug.Assert$2(headEntry === $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.t_lockEntryHead, "headEntry == t_lockEntryHead");
                        $.$$.System.Diagnostics.Debug.Assert$2(headEntry === null || headEntry._lockID !== lockID, "headEntry == null || headEntry._lockID != lockID");
                        /*ThreadLocalLockEntry?*/ let entry = null;
                        /*ThreadLocalLockEntry?*/ let emptyEntryPrevious = null;
                        /*ThreadLocalLockEntry?*/ let emptyEntry = null;
                        if (headEntry !== null)
                        {
                            if (headEntry.IsFree)
                            {
                                emptyEntry = headEntry;
                            }
                            for(/*ThreadLocalLockEntry?*/ let previousEntry = headEntry, currentEntry = headEntry._next; currentEntry !== null; previousEntry = currentEntry, currentEntry = currentEntry._next)
                            {
                                if (currentEntry._lockID === lockID)
                                {
                                    $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.VerifyNoNonemptyEntryInListAfter(lockID, currentEntry);
                                    previousEntry._next = currentEntry._next;
                                    entry = currentEntry;
                                    break;
                                }
                                if (emptyEntry === null && currentEntry.IsFree)
                                {
                                    emptyEntryPrevious = previousEntry;
                                    emptyEntry = currentEntry;
                                }
                            }
                        }
                        if (entry === null)
                        {
                            if (emptyEntry !== null)
                            {
                                emptyEntry._lockID = lockID;
                                if (emptyEntryPrevious === null)
                                {
                                    $.$$.System.Diagnostics.Debug.Assert$2(emptyEntry === headEntry, "emptyEntry == headEntry");
                                    return emptyEntry;
                                }
                                emptyEntryPrevious._next = emptyEntry._next;
                                entry = emptyEntry;
                            }
                            else 
                            {
                                entry = new $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry().$ctor$1(lockID);
                            }
                        }
                        $.$$.System.Diagnostics.Debug.Assert$2(entry._lockID === lockID, "entry._lockID == lockID");
                        entry._next = headEntry;
                        $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.t_lockEntryHead = entry;
                        return entry;
                    }
                    //--TRIMMABLE-BOUNDARY-END(38655754260)
                    
                    static $h = 1048596;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(47245688852),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770852372,
        "f": 50331649
      },
      "n": "IsFree",
      "d": 1048596,
      "h": 47245688852,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47245688852)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(42950721556),
    {
      "r": 262145,
      "p": [
        {
          "n": "lockID",
          "p": 917505
        }
      ],
      "n": "HasLockID",
      "d": 1048596,
      "h": 42950721556,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950721556),
//--TRIMMABLE-BOUNDARY-START(55835623444),
    {
      "r": 65537,
      "p": [
        {
          "n": "lockID",
          "p": 917505
        },
        {
          "n": "afterEntry",
          "p": 1048596
        }
      ],
      "n": "VerifyNoNonemptyEntryInListAfter",
      "d": 1048596,
      "h": 55835623444,
      "f": 16777250,
      "a": [
        {
          "t": 68616193,
          "c": 4363583489,
          "a": [
            {
              "v": "DEBUG",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55835623444),
//--TRIMMABLE-BOUNDARY-START(30065819668),
    {
      "r": 1048596,
      "p": [
        {
          "n": "lockID",
          "p": 917505
        }
      ],
      "n": "GetCurrent",
      "d": 1048596,
      "h": 30065819668,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30065819668),
//--TRIMMABLE-BOUNDARY-START(34360786964),
    {
      "r": 1048596,
      "p": [
        {
          "n": "lockID",
          "p": 917505
        }
      ],
      "n": "GetOrCreateCurrent",
      "d": 1048596,
      "h": 34360786964,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34360786964),
//--TRIMMABLE-BOUNDARY-START(38655754260),
    {
      "r": 1048596,
      "p": [
        {
          "n": "lockID",
          "p": 917505
        },
        {
          "n": "headEntry",
          "p": 1048596
        }
      ],
      "n": "GetOrCreateCurrentSlow",
      "d": 1048596,
      "h": 38655754260,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(38655754260)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(51540656148),
    {
      "t": 1048596,
      "n": "t_lockEntryHead",
      "d": 1048596,
      "h": 51540656148,
      "f": 4194338,
      "a": [
        {
          "t": 185204737,
          "c": 4480172033
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51540656148),
//--TRIMMABLE-BOUNDARY-START(4296015892),
    {
      "t": 917505,
      "n": "_lockID",
      "d": 1048596,
      "h": 4296015892,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296015892),
//--TRIMMABLE-BOUNDARY-START(8590983188),
    {
      "t": 1048596,
      "n": "_next",
      "d": 1048596,
      "h": 8590983188,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590983188),
//--TRIMMABLE-BOUNDARY-START(12885950484),
    {
      "t": 589825,
      "n": "_readerLevel",
      "d": 1048596,
      "h": 12885950484,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(12885950484)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180917780),
    {
      "p": [
        {
          "n": "lockID",
          "p": 917505
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1048596,
      "h": 17180917780,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(17180917780)
  ],
  "d": 851988,
  "h": 1048596
}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Threading.ReaderWriterLock.ThreadLocalLockEntry`; }
                }, $cls, ($v) => $cls.$_ThreadLocalLockEntry = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1048596)
            
            //--TRIMMABLE-BOUNDARY-START(34360590356)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(64425361428)
                    this.DefaultSpinCount = /*Environment.ProcessorCount != 1 ? 500 : */ 0;
                    //--TRIMMABLE-BOUNDARY-END(64425361428)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360590356)
            
            static $h = 851988;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 134479873,
  "p": [
//--TRIMMABLE-BOUNDARY-START(133144838164),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310263316,
        "f": 50331649
      },
      "n": "IsReaderLockHeld",
      "d": 851988,
      "h": 133144838164,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(133144838164),
//--TRIMMABLE-BOUNDARY-START(137439805460),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900197908,
        "f": 50331649
      },
      "n": "IsWriterLockHeld",
      "d": 851988,
      "h": 137439805460,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(137439805460),
//--TRIMMABLE-BOUNDARY-START(210454249492),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94490132500,
        "f": 50331649
      },
      "n": "WriterSeqNum",
      "d": 851988,
      "h": 210454249492,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(210454249492)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(60130394132),
    {
      "r": 262145,
      "p": [
        {
          "n": "seqNum",
          "p": 655361
        }
      ],
      "n": "AnyWritersSince",
      "d": 851988,
      "h": 60130394132,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60130394132),
//--TRIMMABLE-BOUNDARY-START(42950524948),
    {
      "r": 65537,
      "p": [
        {
          "n": "millisecondsTimeout",
          "p": 655361
        }
      ],
      "n": "AcquireReaderLock",
      "d": 851988,
      "h": 42950524948,
      "f": 16777217,
      "a": [
        {
          "t": 159252481,
          "c": 4454219777,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42950524948),
//--TRIMMABLE-BOUNDARY-START(47245492244),
    {
      "r": 65537,
      "p": [
        {
          "n": "timeout",
          "p": 185729025
        }
      ],
      "n": "AcquireReaderLock",
      "o": "@$1",
      "d": 851988,
      "h": 47245492244,
      "f": 16777217,
      "a": [
        {
          "t": 159252481,
          "c": 4454219777,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47245492244),
//--TRIMMABLE-BOUNDARY-START(51540459540),
    {
      "r": 65537,
      "p": [
        {
          "n": "millisecondsTimeout",
          "p": 655361
        }
      ],
      "n": "AcquireWriterLock",
      "d": 851988,
      "h": 51540459540,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51540459540),
//--TRIMMABLE-BOUNDARY-START(55835426836),
    {
      "r": 65537,
      "p": [
        {
          "n": "timeout",
          "p": 185729025
        }
      ],
      "n": "AcquireWriterLock",
      "o": "@$1",
      "d": 851988,
      "h": 55835426836,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55835426836),
//--TRIMMABLE-BOUNDARY-START(167504576532),
    {
      "r": 65537,
      "n": "ReleaseReaderLock",
      "d": 851988,
      "h": 167504576532,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(167504576532),
//--TRIMMABLE-BOUNDARY-START(171799543828),
    {
      "r": 65537,
      "n": "ReleaseWriterLock",
      "d": 851988,
      "h": 171799543828,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(171799543828),
//--TRIMMABLE-BOUNDARY-START(201864314900),
    {
      "r": 720916,
      "p": [
        {
          "n": "millisecondsTimeout",
          "p": 655361
        }
      ],
      "n": "UpgradeToWriterLock",
      "d": 851988,
      "h": 201864314900,
      "f": 16777217,
      "a": [
        {
          "t": 159252481,
          "c": 4454219777,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(201864314900),
//--TRIMMABLE-BOUNDARY-START(206159282196),
    {
      "r": 720916,
      "p": [
        {
          "n": "timeout",
          "p": 185729025
        }
      ],
      "n": "UpgradeToWriterLock",
      "o": "@$1",
      "d": 851988,
      "h": 206159282196,
      "f": 16777217,
      "a": [
        {
          "t": 159252481,
          "c": 4454219777,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(206159282196),
//--TRIMMABLE-BOUNDARY-START(68720328724),
    {
      "r": 65537,
      "p": [
        {
          "n": "lockCookie",
          "p": 720916,
          "f": 4
        }
      ],
      "n": "DowngradeFromWriterLock",
      "d": 851988,
      "h": 68720328724,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68720328724),
//--TRIMMABLE-BOUNDARY-START(163209609236),
    {
      "r": 720916,
      "n": "ReleaseLock",
      "d": 851988,
      "h": 163209609236,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(163209609236),
//--TRIMMABLE-BOUNDARY-START(176094511124),
    {
      "r": 65537,
      "p": [
        {
          "n": "lockCookie",
          "p": 720916,
          "f": 4
        }
      ],
      "n": "RestoreLock",
      "d": 851988,
      "h": 176094511124,
      "f": 16777217,
      "a": [
        {
          "t": 159252481,
          "c": 4454219777,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(176094511124),
//--TRIMMABLE-BOUNDARY-START(154619674644),
    {
      "r": 65537,
      "p": [
        {
          "n": "lockCookie",
          "p": 720916,
          "f": 4
        },
        {
          "n": "flags",
          "p": 786452
        }
      ],
      "n": "RecoverLock",
      "d": 851988,
      "h": 154619674644,
      "f": 16777218,
      "a": [
        {
          "t": 159252481,
          "c": 4454219777,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(154619674644),
//--TRIMMABLE-BOUNDARY-START(98785099796),
    {
      "r": 655361,
      "n": "GetCurrentThreadID",
      "d": 851988,
      "h": 98785099796,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(98785099796),
//--TRIMMABLE-BOUNDARY-START(214749216788),
    {
      "r": 262145,
      "n": "YieldProcessor",
      "d": 851988,
      "h": 214749216788,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(214749216788),
//--TRIMMABLE-BOUNDARY-START(111670001684),
    {
      "r": 172359681,
      "n": "GetOrCreateReaderEvent",
      "d": 851988,
      "h": 111670001684,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(111670001684),
//--TRIMMABLE-BOUNDARY-START(115964968980),
    {
      "r": 169869313,
      "n": "GetOrCreateWriterEvent",
      "d": 851988,
      "h": 115964968980,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(115964968980),
//--TRIMMABLE-BOUNDARY-START(193274380308),
    {
      "r": 172359681,
      "n": "TryGetOrCreateReaderEvent",
      "d": 851988,
      "h": 193274380308,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(193274380308),
//--TRIMMABLE-BOUNDARY-START(197569347604),
    {
      "r": 169869313,
      "n": "TryGetOrCreateWriterEvent",
      "d": 851988,
      "h": 197569347604,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(197569347604),
//--TRIMMABLE-BOUNDARY-START(158914641940),
    {
      "r": 65537,
      "n": "ReleaseEvents",
      "d": 851988,
      "h": 158914641940,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(158914641940),
//--TRIMMABLE-BOUNDARY-START(188979413012),
    {
      "r": 655361,
      "p": [
        {
          "n": "timeout",
          "p": 185729025
        }
      ],
      "n": "ToTimeoutMilliseconds",
      "d": 851988,
      "h": 188979413012,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(188979413012),
//--TRIMMABLE-BOUNDARY-START(120259936276),
    {
      "r": 983060,
      "n": "GetTimeoutException",
      "d": 851988,
      "h": 120259936276,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(120259936276),
//--TRIMMABLE-BOUNDARY-START(107375034388),
    {
      "r": 983060,
      "n": "GetNotOwnerException",
      "d": 851988,
      "h": 107375034388,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(107375034388),
//--TRIMMABLE-BOUNDARY-START(103080067092),
    {
      "r": 983060,
      "n": "GetInvalidLockCookieException",
      "d": 851988,
      "h": 103080067092,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(103080067092)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(128849870868),
    {
      "t": 655361,
      "n": "InvalidThreadID",
      "d": 851988,
      "h": 128849870868,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(128849870868),
//--TRIMMABLE-BOUNDARY-START(146029740052),
    {
      "t": 589825,
      "n": "MaxAcquireCount",
      "d": 851988,
      "h": 146029740052,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(146029740052),
//--TRIMMABLE-BOUNDARY-START(64425361428),
    {
      "t": 655361,
      "n": "DefaultSpinCount",
      "d": 851988,
      "h": 64425361428,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(64425361428),
//--TRIMMABLE-BOUNDARY-START(124554903572),
    {
      "t": 655361,
      "n": "IncorrectButCompatibleNotOwnerExceptionHResult",
      "d": 851988,
      "h": 124554903572,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(124554903572),
//--TRIMMABLE-BOUNDARY-START(180389478420),
    {
      "t": 917505,
      "n": "s_mostRecentLockID",
      "d": 851988,
      "h": 180389478420,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(180389478420),
//--TRIMMABLE-BOUNDARY-START(8590786580),
    {
      "t": 172359681,
      "n": "_readerEvent",
      "d": 851988,
      "h": 8590786580,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590786580),
//--TRIMMABLE-BOUNDARY-START(17180721172),
    {
      "t": 169869313,
      "n": "_writerEvent",
      "d": 851988,
      "h": 17180721172,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180721172),
//--TRIMMABLE-BOUNDARY-START(4295819284),
    {
      "t": 917505,
      "n": "_lockID",
      "d": 851988,
      "h": 4295819284,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295819284),
//--TRIMMABLE-BOUNDARY-START(12885753876),
    {
      "t": 655361,
      "n": "_state",
      "d": 851988,
      "h": 12885753876,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885753876),
//--TRIMMABLE-BOUNDARY-START(21475688468),
    {
      "t": 655361,
      "n": "_writerID",
      "d": 851988,
      "h": 21475688468,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475688468),
//--TRIMMABLE-BOUNDARY-START(30065623060),
    {
      "t": 655361,
      "n": "_writerSeqNum",
      "d": 851988,
      "h": 30065623060,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30065623060),
//--TRIMMABLE-BOUNDARY-START(25770655764),
    {
      "t": 589825,
      "n": "_writerLevel",
      "d": 851988,
      "h": 25770655764,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770655764)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(38655557652),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 851988,
      "h": 38655557652,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655557652)
  ],
  "j": [917524,1048596
  ],
  "h": 851988
}; }
            static get $b() { return $.$$.System.Runtime.ConstrainedExecution.CriticalFinalizerObject; }
            static get $fullName() { return `System.Threading.ReaderWriterLock`; }
        });
        //--TRIMMABLE-BOUNDARY-END(851988)
        
        
        //--TRIMMABLE-BOUNDARY-START(720916)
        $asm.$str("$st.System.Threading.LockCookie", ($self) => class LockCookie extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(4295688212)
            /*LockCookieFlags*/  get _flags() { return this.$getField(0, $.$st.System.Threading.LockCookieFlags); }
            /*LockCookieFlags*/  set _flags(value) { this.$setField(0, $.$st.System.Threading.LockCookieFlags, value); }
            //--TRIMMABLE-BOUNDARY-END(4295688212)
            
            //--TRIMMABLE-BOUNDARY-START(8590655508)
            /*ushort*/  get _readerLevel() { return this.$getField(4, $.$$.System.UInt16); }
            /*ushort*/  set _readerLevel(value) { this.$setField(4, $.$$.System.UInt16, value); }
            //--TRIMMABLE-BOUNDARY-END(8590655508)
            
            //--TRIMMABLE-BOUNDARY-START(17180590100)
            /*ushort*/  get _writerLevel() { return this.$getField(6, $.$$.System.UInt16); }
            /*ushort*/  set _writerLevel(value) { this.$setField(6, $.$$.System.UInt16, value); }
            //--TRIMMABLE-BOUNDARY-END(17180590100)
            
            //--TRIMMABLE-BOUNDARY-START(12885622804)
            /*int*/  get _threadID() { return this.$getField(8, $.$$.System.Int32); }
            /*int*/  set _threadID(value) { this.$setField(8, $.$$.System.Int32, value); }
            //--TRIMMABLE-BOUNDARY-END(12885622804)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 34360459284, 184683724801)
            static/*conventional*/ /*int */ GetHashCode()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360459284);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return ((((((this._flags + this._readerLevel) | 0) + this._writerLevel) | 0) + this._threadID) | 0);
                }
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$st.System.Threading.LockCookie.GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(ALL, 34360459284, 184683724801)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 25770524692, 34359869441)
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770524692);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let other;
                    return $.$is(obj, $.$st.System.Threading.LockCookie, { set $v(v){ other = v; } }) && this.Equals$2(other.Clone());
                }
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$st.System.Threading.LockCookie.Equals$1.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(ALL, 25770524692, 34359869441)
            
            //--TRIMMABLE-BOUNDARY-START(30065491988)
            /*bool */ Equals$2(/*LockCookie*/ obj)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065491988);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._flags === obj._flags && this._readerLevel === obj._readerLevel && this._writerLevel === obj._writerLevel && this._threadID === obj._threadID;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065491988)
            
            //--TRIMMABLE-BOUNDARY-START(38655426580)
            static /*bool */ op_Equality(/*LockCookie*/ a, /*LockCookie*/ b)
            {
                {
                    return a.Equals$2(b.Clone());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38655426580)
            
            //--TRIMMABLE-BOUNDARY-START(42950393876)
            static /*bool */ op_Inequality(/*LockCookie*/ a, /*LockCookie*/ b)
            {
                {
                    return !a.Equals$2(b.Clone());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950393876)
            
            //--TRIMMABLE-BOUNDARY-START(4385210369)
            //Generated interface implemetation for System.IEquatable<System.Threading.LockCookie>.Equals(System.Threading.LockCookie)
            System$IEquatable$$$Equals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385210369);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385210369)
            
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._flags = this._flags;
                copy._readerLevel = this._readerLevel;
                copy._writerLevel = this._writerLevel;
                copy._threadID = this._threadID;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4295688212)
                this._flags = 0;
                //--TRIMMABLE-BOUNDARY-END(4295688212)
                
                //--TRIMMABLE-BOUNDARY-START(8590655508)
                this._readerLevel = 0;
                //--TRIMMABLE-BOUNDARY-END(8590655508)
                
                //--TRIMMABLE-BOUNDARY-START(17180590100)
                this._writerLevel = 0;
                //--TRIMMABLE-BOUNDARY-END(17180590100)
                
                //--TRIMMABLE-BOUNDARY-START(12885622804)
                this._threadID = 0;
                //--TRIMMABLE-BOUNDARY-END(12885622804)
                
            }
            static $h = 720916;
            static $z = 12;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 34360459284, 184683724801),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 720916,
      "h": 34360459284,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 34360459284, 184683724801),
//--TRIMMABLE-BOUNDARY-START(ALL, 25770524692, 34359869441),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 720916,
      "h": 25770524692,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 25770524692, 34359869441),
//--TRIMMABLE-BOUNDARY-START(30065491988),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 720916
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 720916,
      "h": 30065491988,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065491988)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295688212),
    {
      "t": 786452,
      "n": "_flags",
      "d": 720916,
      "h": 4295688212,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(4295688212),
//--TRIMMABLE-BOUNDARY-START(8590655508),
    {
      "t": 589825,
      "n": "_readerLevel",
      "d": 720916,
      "h": 8590655508,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(8590655508),
//--TRIMMABLE-BOUNDARY-START(17180590100),
    {
      "t": 589825,
      "n": "_writerLevel",
      "d": 720916,
      "h": 17180590100,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(17180590100),
//--TRIMMABLE-BOUNDARY-START(12885622804),
    {
      "t": 655361,
      "n": "_threadID",
      "d": 720916,
      "h": 12885622804,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(12885622804)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475557396),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 720916,
      "h": 21475557396,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475557396)
  ],
  "i": [$.$$.System.IEquatable$$($.$st.System.Threading.LockCookie).$h
  ],
  "h": 720916
}; }
            static get $b() { return $.$$.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IEquatable$$($.$st.System.Threading.LockCookie) ]; }
            static get $fullName() { return `System.Threading.LockCookie`; }
        });
        //--TRIMMABLE-BOUNDARY-END(720916)
        
        
        //--TRIMMABLE-BOUNDARY-START(786452)
        $asm.$str("$st.System.Threading.LockCookieFlags", ($self) => class LockCookieFlags extends $.$$.System.Enum
        {
            static Upgrade = 8192;
            static Release = 16384;
            static OwnedNone = 65536;
            static OwnedWriter = 131072;
            static OwnedReader = 262144;
            static Invalid = -483329;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(786452);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Upgrade": 8192n,
                    "Release": 16384n,
                    "OwnedNone": 65536n,
                    "OwnedWriter": 131072n,
                    "OwnedReader": 262144n,
                    "Invalid": -483329n
                };
            }
            static $h = 786452;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(30065557524),
    {
      "t": 786452,
      "n": "Upgrade",
      "d": 786452,
      "h": 30065557524,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065557524),
//--TRIMMABLE-BOUNDARY-START(25770590228),
    {
      "t": 786452,
      "n": "Release",
      "d": 786452,
      "h": 25770590228,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770590228),
//--TRIMMABLE-BOUNDARY-START(12885688340),
    {
      "t": 786452,
      "n": "OwnedNone",
      "d": 786452,
      "h": 12885688340,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885688340),
//--TRIMMABLE-BOUNDARY-START(21475622932),
    {
      "t": 786452,
      "n": "OwnedWriter",
      "d": 786452,
      "h": 21475622932,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475622932),
//--TRIMMABLE-BOUNDARY-START(17180655636),
    {
      "t": 786452,
      "n": "OwnedReader",
      "d": 786452,
      "h": 17180655636,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180655636),
//--TRIMMABLE-BOUNDARY-START(8590721044),
    {
      "t": 786452,
      "n": "Invalid",
      "d": 786452,
      "h": 8590721044,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590721044)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295753748),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 786452,
      "h": 4295753748,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295753748)
  ],
  "i": [89915393,96468993,90374145,90046465
  ],
  "h": 786452,
  "a": [
    {
      "t": 80347137,
      "c": 4375314433
    }
  ]
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Threading.LockCookieFlags`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786452)
        
        
        //--TRIMMABLE-BOUNDARY-START(393236)
        $asm.$cls("$st.System.Threading.CdsSyncEtwBCLProvider", ($self) => class CdsSyncEtwBCLProvider extends $.$$.System.Diagnostics.Tracing.EventSource
        {
            //--TRIMMABLE-BOUNDARY-START(25770197012)
            /*CdsSyncEtwBCLProvider*/ static Log = null;
            //--TRIMMABLE-BOUNDARY-END(25770197012)
            
            //--TRIMMABLE-BOUNDARY-START(8590327828)
            $ctor$10()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590327828);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590327828)
            
            //--TRIMMABLE-BOUNDARY-START(12885295124)
            /*EventKeywords*/ static ALL_KEYWORDS = -1n;
            //--TRIMMABLE-BOUNDARY-END(12885295124)
            
            //--TRIMMABLE-BOUNDARY-START(21475229716)
            /*int*/ static BARRIER_PHASEFINISHED_ID = 3;
            //--TRIMMABLE-BOUNDARY-END(21475229716)
            
            //--TRIMMABLE-BOUNDARY-START(17180262420)
            /*void */ Barrier_PhaseFinished(/*bool*/ currentSense, /*long*/ phaseNum)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180262420);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsEnabled$2(5/*EventLevel.Verbose*/, -1n))
                {
                    {
                        /*EventData**/ let eventPayload = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocPointer($.$$.System.Diagnostics.Tracing.EventSource.EventData, 2, null);
                        /*int*/ let senseAsInt32 = currentSense ? 1 : 0;
                        eventPayload.SetAt((() =>
                        {
                            //new $.$$.System.Diagnostics.Tracing.EventSource.EventData()
                            const $t1 = $.$$.System.Diagnostics.Tracing.EventSource.EventData;
                            const $i1 = new $t1();
                            $i1.Size = $.$$.System.Int32.$z;
                            $i1.DataPointer = ($.$cast(($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Int32, () => senseAsInt32, ($v) => senseAsInt32 = $v, null)), $.$$.System.IntPtr));
                            return $i1;
                        })(), 0);
                        eventPayload.SetAt((() =>
                        {
                            //new $.$$.System.Diagnostics.Tracing.EventSource.EventData()
                            const $t2 = $.$$.System.Diagnostics.Tracing.EventSource.EventData;
                            const $i2 = new $t2();
                            $i2.Size = $.$$.System.Int64.$z;
                            $i2.DataPointer = ($.$$.$interop.castObject2Address($.$box(phaseNum, $.$$.System.Int64), 0, false));
                            return $i2;
                        })(), 1);
                        this.WriteEventCore(3/*BARRIER_PHASEFINISHED_ID*/, 2, eventPayload);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180262420)
            
            //--TRIMMABLE-BOUNDARY-START(4295360532)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(25770197012)
                    this.Log = new $.$st.System.Threading.CdsSyncEtwBCLProvider().$ctor$10();
                    //--TRIMMABLE-BOUNDARY-END(25770197012)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295360532)
            
            static $h = 393236;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 74383361,
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180262420),
    {
      "r": 65537,
      "p": [
        {
          "n": "currentSense",
          "p": 262145
        },
        {
          "n": "phaseNum",
          "p": 917505
        }
      ],
      "n": "Barrier_PhaseFinished",
      "d": 393236,
      "h": 17180262420,
      "f": 16777217,
      "a": [
        {
          "t": 72613889,
          "c": 4367581185,
          "a": [
            {
              "v": 3,
              "t": 655361
            }
          ],
          "n": [
            {
              "n": "Level",
              "v": 5,
              "t": 73596929
            },
            {
              "n": "Version",
              "v": 1,
              "t": 393217
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17180262420)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(25770197012),
    {
      "t": 393236,
      "n": "Log",
      "d": 393236,
      "h": 25770197012,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770197012),
//--TRIMMABLE-BOUNDARY-START(12885295124),
    {
      "t": 73531393,
      "n": "ALL_KEYWORDS",
      "d": 393236,
      "h": 12885295124,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12885295124),
//--TRIMMABLE-BOUNDARY-START(21475229716),
    {
      "t": 655361,
      "n": "BARRIER_PHASEFINISHED_ID",
      "d": 393236,
      "h": 21475229716,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(21475229716)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590327828),
    {
      "n": ".ctor",
      "o": "$ctor$10",
      "d": 393236,
      "h": 8590327828,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(8590327828)
  ],
  "i": [90177537
  ],
  "h": 393236,
  "a": [
    {
      "t": 74711041,
      "c": 4369678337,
      "n": [
        {
          "n": "Name",
          "v": "System.Threading.SynchronizationEventSource",
          "t": 1310721
        },
        {
          "n": "Guid",
          "v": "EC631D38-466B-4290-9306-834971BA0217",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Diagnostics.Tracing.EventSource; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.Threading.CdsSyncEtwBCLProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393236)
        
        
        //--TRIMMABLE-BOUNDARY-START(327700)
        $asm.$cls("$st.System.Threading.BarrierPostPhaseException", ($self) => class BarrierPostPhaseException extends $.$$.System.Exception
        {
            //--TRIMMABLE-BOUNDARY-START(4295294996)
            $ctor$5()
            {
                this.$ctor$9(null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295294996);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295294996)
            
            //--TRIMMABLE-BOUNDARY-START(8590262292)
            $ctor$6(/*Exception?*/ innerException)
            {
                this.$ctor$8(null, innerException);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590262292);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590262292)
            
            //--TRIMMABLE-BOUNDARY-START(12885229588)
            $ctor$9(/*string?*/ message)
            {
                this.$ctor$8(message, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885229588);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885229588)
            
            //--TRIMMABLE-BOUNDARY-START(17180196884)
            $ctor$8(/*string?*/ message, /*Exception?*/ innerException)
            {
                super.$ctor$3(message === null ? $.$st.System.SR.BarrierPostPhaseException : message, innerException);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180196884);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180196884)
            
            //--TRIMMABLE-BOUNDARY-START(21475164180)
            $ctor$7(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor$2(info, context);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475164180);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475164180)
            
            static $h = 327700;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 79888385,
  "h": 327700
}; }
            static get $b() { return $.$$.System.Exception; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Threading.BarrierPostPhaseException`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327700)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib"))
//--TRIMMABLE-BOUNDARY-END(20)
