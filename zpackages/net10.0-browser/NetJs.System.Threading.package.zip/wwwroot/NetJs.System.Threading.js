
(function ($global, $, $$) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Threading", 
    {"h":62230,"f":"System.Threading","v":"1.0.35.0","a":[{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Beff628fa5ab8bd29ec37e9c13a50148694bea088","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Threading","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Threading","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115081217,"c":4410048513,"a":[{"v":"browser1.0","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$st.System.Threading.HostExecutionContextManager", ($self) => class HostExecutionContextManager extends $.$$.System.Object
        {
            /*HostExecutionContext?*/ static t_currentContext = null;
            /*HostExecutionContext? */ Capture()
            {
                return null;
            }
            /*object */ SetHostExecutionContext(/*HostExecutionContext*/ hostExecutionContext)
            {
                if (hostExecutionContext === null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$st.System.SR.HostExecutionContextManager_InvalidOperation_NotNewCaptureContext);
                }
                /*var*/ let switcher = new $.$st.System.Threading.HostExecutionContextManager.HostExecutionContextSwitcher().$ctor$1(hostExecutionContext);
                $.$st.System.Threading.HostExecutionContextManager.t_currentContext = hostExecutionContext;
                return switcher;
            }
            /*void */ Revert(/*object*/ previousState)
            {
                /*var*/ let switcher = $.$as(previousState, $.$st.System.Threading.HostExecutionContextManager.HostExecutionContextSwitcher);
                if (switcher === null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$st.System.SR.HostExecutionContextManager_InvalidOperation_CannotOverrideSetWithoutRevert);
                }
                if ($.$st.System.Threading.HostExecutionContextManager.t_currentContext !== switcher._currentContext || switcher._asyncLocal === null || !switcher._asyncLocal.Value)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$st.System.SR.HostExecutionContextManager_InvalidOperation_CannotUseSwitcherOtherThread);
                }
                switcher._asyncLocal = null;
                $.$st.System.Threading.HostExecutionContextManager.t_currentContext = null;
            }
            static $_HostExecutionContextSwitcher;
            static get HostExecutionContextSwitcher()
            {
                let $cls = $.$st.System.Threading.HostExecutionContextManager;
                return $cls.$_HostExecutionContextSwitcher ??= $asm.$ncls("$st.System.Threading.HostExecutionContextManager.HostExecutionContextSwitcher", ($self) => class HostExecutionContextSwitcher extends $.$$.System.Object
                {
                    /*HostExecutionContext*/ _currentContext = null;
                    /*AsyncLocal<bool>?*/ _asyncLocal = null;
                    $ctor$1(/*HostExecutionContext*/ currentContext)
                    {
                        super.$ctor();
                        {
                            this._currentContext = currentContext;
                            this._asyncLocal = new ($.$$.System.Threading.AsyncLocal$$($.$$.System.Boolean))().$ctor$1();
                            this._asyncLocal.Value = true;
                        }
                        return this;
                    }
                    static $h = 717590;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":586518,"n":"_currentContext","d":717590,"h":4295684886,"f":4194305},{"t":$.$$.System.Threading.AsyncLocal$$($.$$.System.Boolean).$h,"n":"_asyncLocal","d":717590,"h":8590652182,"f":4194305}],"c":[{"p":[{"n":"currentContext","p":586518}],"n":".ctor","o":"$ctor$1","d":717590,"h":12885619478,"f":16777217}],"d":652054,"h":717590}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Threading.HostExecutionContextManager.HostExecutionContextSwitcher`; }
                }, $cls, ($v) => $cls.$_HostExecutionContextSwitcher = $v);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 652054;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":586518,"n":"Capture","d":652054,"h":8590586646,"f":16777345},{"r":131073,"p":[{"n":"hostExecutionContext","p":586518}],"n":"SetHostExecutionContext","d":652054,"h":12885553942,"f":16777345},{"r":65537,"p":[{"n":"previousState","p":131073}],"n":"Revert","d":652054,"h":17180521238,"f":16777345}],"l":[{"t":586518,"n":"t_currentContext","d":652054,"h":4295619350,"f":4194338,"a":[{"t":140050433,"c":4435017729}]}],"c":[{"n":".ctor","o":"$ctor$1","d":652054,"h":25770455830,"f":16777217}],"j":[717590],"h":652054}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Threading.HostExecutionContextManager`; }
        });
        
        $asm.$cls("$st.System.Obsoletions", ($self) => class Obsoletions
        {
            /*string*/ static SharedUrlFormat = null;
            /*string*/ static SystemTextEncodingUTF7Message = null;
            /*string*/ static SystemTextEncodingUTF7DiagId = null;
            /*string*/ static PrincipalPermissionAttributeMessage = null;
            /*string*/ static PrincipalPermissionAttributeDiagId = null;
            /*string*/ static CodeAccessSecurityMessage = null;
            /*string*/ static CodeAccessSecurityDiagId = null;
            /*string*/ static ConstrainedExecutionRegionMessage = null;
            /*string*/ static ConstrainedExecutionRegionDiagId = null;
            /*string*/ static GlobalAssemblyCacheMessage = null;
            /*string*/ static GlobalAssemblyCacheDiagId = null;
            /*string*/ static ThreadAbortMessage = null;
            /*string*/ static ThreadResetAbortMessage = null;
            /*string*/ static ThreadAbortDiagId = null;
            /*string*/ static DefaultCryptoAlgorithmsMessage = null;
            /*string*/ static DefaultCryptoAlgorithmsDiagId = null;
            /*string*/ static CreatePdbGeneratorMessage = null;
            /*string*/ static CreatePdbGeneratorDiagId = null;
            /*string*/ static AuthenticationManagerMessage = null;
            /*string*/ static AuthenticationManagerDiagId = null;
            /*string*/ static RemotingApisMessage = null;
            /*string*/ static RemotingApisDiagId = null;
            /*string*/ static BinaryFormatterMessage = null;
            /*string*/ static BinaryFormatterDiagId = null;
            /*string*/ static CodeBaseMessage = null;
            /*string*/ static CodeBaseDiagId = null;
            /*string*/ static EscapeUriStringMessage = null;
            /*string*/ static EscapeUriStringDiagId = null;
            /*string*/ static WebRequestMessage = null;
            /*string*/ static WebRequestDiagId = null;
            /*string*/ static DisablePrivateReflectionAttributeMessage = null;
            /*string*/ static DisablePrivateReflectionAttributeDiagId = null;
            /*string*/ static GetContextInfoMessage = null;
            /*string*/ static GetContextInfoDiagId = null;
            /*string*/ static StrongNameKeyPairMessage = null;
            /*string*/ static StrongNameKeyPairDiagId = null;
            /*string*/ static ReflectionOnlyLoadingMessage = null;
            /*string*/ static ReflectionOnlyLoadingDiagId = null;
            /*string*/ static RuntimeEnvironmentMessage = null;
            /*string*/ static RuntimeEnvironmentDiagId = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesMessage = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesDiagId = null;
            /*string*/ static DerivedCryptographicTypesMessage = null;
            /*string*/ static DerivedCryptographicTypesDiagId = null;
            /*string*/ static RijndaelMessage = null;
            /*string*/ static RijndaelDiagId = null;
            /*string*/ static RNGCryptoServiceProviderMessage = null;
            /*string*/ static RNGCryptoServiceProviderDiagId = null;
            /*string*/ static AppDomainCreateUnloadMessage = null;
            /*string*/ static AppDomainCreateUnloadDiagId = null;
            /*string*/ static SuppressIldasmAttributeMessage = null;
            /*string*/ static SuppressIldasmAttributeDiagId = null;
            /*string*/ static X509CertificateImmutableMessage = null;
            /*string*/ static X509CertificateImmutableDiagId = null;
            /*string*/ static PublicKeyPropertyMessage = null;
            /*string*/ static PublicKeyPropertyDiagId = null;
            /*string*/ static X509CertificatePrivateKeyMessage = null;
            /*string*/ static X509CertificatePrivateKeyDiagId = null;
            /*string*/ static ProduceLegacyHmacValuesMessage = null;
            /*string*/ static ProduceLegacyHmacValuesDiagId = null;
            /*string*/ static UseManagedSha1Message = null;
            /*string*/ static UseManagedSha1DiagId = null;
            /*string*/ static CryptoConfigEncodeOIDMessage = null;
            /*string*/ static CryptoConfigEncodeOIDDiagId = null;
            /*string*/ static CorruptedStateRecoveryMessage = null;
            /*string*/ static CorruptedStateRecoveryDiagId = null;
            /*string*/ static Rfc2898CryptDeriveKeyMessage = null;
            /*string*/ static Rfc2898CryptDeriveKeyDiagId = null;
            /*string*/ static CmsSignerCspParamsCtorMessage = null;
            /*string*/ static CmsSignerCspParamsCtorDiagId = null;
            /*string*/ static SignerInfoCounterSigMessage = null;
            /*string*/ static SignerInfoCounterSigDiagId = null;
            /*string*/ static RegexCompileToAssemblyMessage = null;
            /*string*/ static RegexCompileToAssemblyDiagId = null;
            /*string*/ static AssemblyNameMembersMessage = null;
            /*string*/ static AssemblyNameMembersDiagId = null;
            /*string*/ static SystemDataSerializationFormatBinaryMessage = null;
            /*string*/ static SystemDataSerializationFormatBinaryDiagId = null;
            /*string*/ static TlsVersion10and11Message = null;
            /*string*/ static TlsVersion10and11DiagId = null;
            /*string*/ static EncryptionPolicyMessage = null;
            /*string*/ static EncryptionPolicyDiagId = null;
            /*string*/ static EccXmlExportImportMessage = null;
            /*string*/ static EccXmlExportImportDiagId = null;
            /*string*/ static EcDhPublicKeyBlobMessage = null;
            /*string*/ static EcDhPublicKeyBlobDiagId = null;
            /*string*/ static AssemblyNameCodeBaseMessage = null;
            /*string*/ static AssemblyNameCodeBaseDiagId = null;
            /*string*/ static CryptoStringFactoryMessage = null;
            /*string*/ static CryptoStringFactoryDiagId = null;
            /*string*/ static ControlledExecutionRunMessage = null;
            /*string*/ static ControlledExecutionRunDiagId = null;
            /*string*/ static XmlSecureResolverMessage = null;
            /*string*/ static XmlSecureResolverDiagId = null;
            /*string*/ static RsaEncryptDecryptValueMessage = null;
            /*string*/ static RsaEncryptDecryptDiagId = null;
            /*string*/ static JsonSerializerOptionsAddContextMessage = null;
            /*string*/ static JsonSerializerOptionsAddContextDiagId = null;
            /*string*/ static LegacyFormatterMessage = null;
            /*string*/ static LegacyFormatterDiagId = null;
            /*string*/ static LegacyFormatterImplMessage = null;
            /*string*/ static LegacyFormatterImplDiagId = null;
            /*string*/ static RegexExtensibilityImplMessage = null;
            /*string*/ static RegexExtensibilityDiagId = null;
            /*string*/ static AesGcmTagConstructorMessage = null;
            /*string*/ static AesGcmTagConstructorDiagId = null;
            /*string*/ static ThreadVolatileReadWriteMessage = null;
            /*string*/ static ThreadVolatileReadWriteDiagId = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationMessage = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationDiagId = null;
            /*string*/ static LoadFromHashAlgorithmMessage = null;
            /*string*/ static LoadFromHashAlgorithmDiagId = null;
            /*string*/ static X509CtorCertDataObsoleteMessage = null;
            /*string*/ static X509CtorCertDataObsoleteDiagId = null;
            /*string*/ static TlsCipherAlgorithmEnumsMessage = null;
            /*string*/ static TlsCipherAlgorithmEnumsDiagId = null;
            /*string*/ static SystemEventsEventsThreadShutdownMessage = null;
            /*string*/ static SystemEventsEventsThreadShutdownDiagId = null;
            /*string*/ static Rfc2898DeriveBytesCtorMessage = null;
            /*string*/ static Rfc2898DeriveBytesCtorDiagId = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteMessage = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteDiagId = null;
            /*string*/ static XsltSettingsEnableScriptMessage = null;
            /*string*/ static XsltSettingsEnableScriptDiagId = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                }
                {
                    this.SystemTextEncodingUTF7Message = "The UTF-7 encoding is insecure and should not be used. Consider using UTF-8 instead.";
                }
                {
                    this.SystemTextEncodingUTF7DiagId = "SYSLIB0001";
                }
                {
                    this.PrincipalPermissionAttributeMessage = "PrincipalPermissionAttribute is not honored by the runtime and must not be used.";
                }
                {
                    this.PrincipalPermissionAttributeDiagId = "SYSLIB0002";
                }
                {
                    this.CodeAccessSecurityMessage = "Code Access Security is not supported or honored by the runtime.";
                }
                {
                    this.CodeAccessSecurityDiagId = "SYSLIB0003";
                }
                {
                    this.ConstrainedExecutionRegionMessage = "The Constrained Execution Region (CER) feature is not supported.";
                }
                {
                    this.ConstrainedExecutionRegionDiagId = "SYSLIB0004";
                }
                {
                    this.GlobalAssemblyCacheMessage = "The Global Assembly Cache is not supported.";
                }
                {
                    this.GlobalAssemblyCacheDiagId = "SYSLIB0005";
                }
                {
                    this.ThreadAbortMessage = "Thread.Abort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadResetAbortMessage = "Thread.ResetAbort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadAbortDiagId = "SYSLIB0006";
                }
                {
                    this.DefaultCryptoAlgorithmsMessage = "The default implementation of this cryptography algorithm is not supported.";
                }
                {
                    this.DefaultCryptoAlgorithmsDiagId = "SYSLIB0007";
                }
                {
                    this.CreatePdbGeneratorMessage = "The CreatePdbGenerator API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.CreatePdbGeneratorDiagId = "SYSLIB0008";
                }
                {
                    this.AuthenticationManagerMessage = "AuthenticationManager is not supported. Methods will no-op or throw PlatformNotSupportedException.";
                }
                {
                    this.AuthenticationManagerDiagId = "SYSLIB0009";
                }
                {
                    this.RemotingApisMessage = "This Remoting API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.RemotingApisDiagId = "SYSLIB0010";
                }
                {
                    this.BinaryFormatterMessage = "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.";
                }
                {
                    this.BinaryFormatterDiagId = "SYSLIB0011";
                }
                {
                    this.CodeBaseMessage = "Assembly.CodeBase and Assembly.EscapedCodeBase are only included for .NET Framework compatibility. Use Assembly.Location instead.";
                }
                {
                    this.CodeBaseDiagId = "SYSLIB0012";
                }
                {
                    this.EscapeUriStringMessage = "Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.";
                }
                {
                    this.EscapeUriStringDiagId = "SYSLIB0013";
                }
                {
                    this.WebRequestMessage = "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.";
                }
                {
                    this.WebRequestDiagId = "SYSLIB0014";
                }
                {
                    this.DisablePrivateReflectionAttributeMessage = "DisablePrivateReflectionAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.DisablePrivateReflectionAttributeDiagId = "SYSLIB0015";
                }
                {
                    this.GetContextInfoMessage = "Use the Graphics.GetContextInfo overloads that accept arguments for better performance and fewer allocations.";
                }
                {
                    this.GetContextInfoDiagId = "SYSLIB0016";
                }
                {
                    this.StrongNameKeyPairMessage = "Strong name signing is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.StrongNameKeyPairDiagId = "SYSLIB0017";
                }
                {
                    this.ReflectionOnlyLoadingMessage = "ReflectionOnly loading is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ReflectionOnlyLoadingDiagId = "SYSLIB0018";
                }
                {
                    this.RuntimeEnvironmentMessage = "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.";
                }
                {
                    this.RuntimeEnvironmentDiagId = "SYSLIB0019";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesMessage = "JsonSerializerOptions.IgnoreNullValues is obsolete. To ignore null values when serializing, set DefaultIgnoreCondition to JsonIgnoreCondition.WhenWritingNull.";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesDiagId = "SYSLIB0020";
                }
                {
                    this.DerivedCryptographicTypesMessage = "Derived cryptographic types are obsolete. Use the Create method on the base type instead.";
                }
                {
                    this.DerivedCryptographicTypesDiagId = "SYSLIB0021";
                }
                {
                    this.RijndaelMessage = "The Rijndael and RijndaelManaged types are obsolete. Use Aes instead.";
                }
                {
                    this.RijndaelDiagId = "SYSLIB0022";
                }
                {
                    this.RNGCryptoServiceProviderMessage = "RNGCryptoServiceProvider is obsolete. To generate a random number, use one of the RandomNumberGenerator static methods instead.";
                }
                {
                    this.RNGCryptoServiceProviderDiagId = "SYSLIB0023";
                }
                {
                    this.AppDomainCreateUnloadMessage = "Creating and unloading AppDomains is not supported and throws an exception.";
                }
                {
                    this.AppDomainCreateUnloadDiagId = "SYSLIB0024";
                }
                {
                    this.SuppressIldasmAttributeMessage = "SuppressIldasmAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.SuppressIldasmAttributeDiagId = "SYSLIB0025";
                }
                {
                    this.X509CertificateImmutableMessage = "X509Certificate and X509Certificate2 are immutable. Use X509CertificateLoader to create a new certificate.";
                }
                {
                    this.X509CertificateImmutableDiagId = "SYSLIB0026";
                }
                {
                    this.PublicKeyPropertyMessage = "PublicKey.Key is obsolete. Use the appropriate method to get the public key, such as GetRSAPublicKey.";
                }
                {
                    this.PublicKeyPropertyDiagId = "SYSLIB0027";
                }
                {
                    this.X509CertificatePrivateKeyMessage = "X509Certificate2.PrivateKey is obsolete. Use the appropriate method to get the private key, such as GetRSAPrivateKey, or use the CopyWithPrivateKey method to create a new instance with a private key.";
                }
                {
                    this.X509CertificatePrivateKeyDiagId = "SYSLIB0028";
                }
                {
                    this.ProduceLegacyHmacValuesMessage = "ProduceLegacyHmacValues is obsolete. Producing legacy HMAC values is not supported.";
                }
                {
                    this.ProduceLegacyHmacValuesDiagId = "SYSLIB0029";
                }
                {
                    this.UseManagedSha1Message = "HMACSHA1 always uses the algorithm implementation provided by the platform. Use a constructor without the useManagedSha1 parameter.";
                }
                {
                    this.UseManagedSha1DiagId = "SYSLIB0030";
                }
                {
                    this.CryptoConfigEncodeOIDMessage = "EncodeOID is obsolete. Use the ASN.1 functionality provided in System.Formats.Asn1.";
                }
                {
                    this.CryptoConfigEncodeOIDDiagId = "SYSLIB0031";
                }
                {
                    this.CorruptedStateRecoveryMessage = "Recovery from corrupted process state exceptions is not supported; HandleProcessCorruptedStateExceptionsAttribute is ignored.";
                }
                {
                    this.CorruptedStateRecoveryDiagId = "SYSLIB0032";
                }
                {
                    this.Rfc2898CryptDeriveKeyMessage = "Rfc2898DeriveBytes.CryptDeriveKey is obsolete and is not supported. Use PasswordDeriveBytes.CryptDeriveKey instead.";
                }
                {
                    this.Rfc2898CryptDeriveKeyDiagId = "SYSLIB0033";
                }
                {
                    this.CmsSignerCspParamsCtorMessage = "CmsSigner(CspParameters) is obsolete and is not supported. Use an alternative constructor instead.";
                }
                {
                    this.CmsSignerCspParamsCtorDiagId = "SYSLIB0034";
                }
                {
                    this.SignerInfoCounterSigMessage = "ComputeCounterSignature without specifying a CmsSigner is obsolete and is not supported. Use the overload that accepts a CmsSigner.";
                }
                {
                    this.SignerInfoCounterSigDiagId = "SYSLIB0035";
                }
                {
                    this.RegexCompileToAssemblyMessage = "Regex.CompileToAssembly is obsolete and not supported. Use the GeneratedRegexAttribute with the regular expression source generator instead.";
                }
                {
                    this.RegexCompileToAssemblyDiagId = "SYSLIB0036";
                }
                {
                    this.AssemblyNameMembersMessage = "AssemblyName members HashAlgorithm, ProcessorArchitecture, and VersionCompatibility are obsolete and not supported.";
                }
                {
                    this.AssemblyNameMembersDiagId = "SYSLIB0037";
                }
                {
                    this.SystemDataSerializationFormatBinaryMessage = "SerializationFormat.Binary is obsolete and should not be used. See https://aka.ms/serializationformat-binary-obsolete for more information.";
                }
                {
                    this.SystemDataSerializationFormatBinaryDiagId = "SYSLIB0038";
                }
                {
                    this.TlsVersion10and11Message = "TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.";
                }
                {
                    this.TlsVersion10and11DiagId = "SYSLIB0039";
                }
                {
                    this.EncryptionPolicyMessage = "EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.";
                }
                {
                    this.EncryptionPolicyDiagId = "SYSLIB0040";
                }
                {
                    this.EccXmlExportImportMessage = "ToXmlString and FromXmlString have no implementation for ECC types, and are obsolete. Use a standard import and export format such as ExportSubjectPublicKeyInfo or ImportSubjectPublicKeyInfo for public keys and ExportPkcs8PrivateKey or ImportPkcs8PrivateKey for private keys.";
                }
                {
                    this.EccXmlExportImportDiagId = "SYSLIB0042";
                }
                {
                    this.EcDhPublicKeyBlobMessage = "ECDiffieHellmanPublicKey.ToByteArray() and the associated constructor do not have a consistent and interoperable implementation on all platforms. Use ECDiffieHellmanPublicKey.ExportSubjectPublicKeyInfo() instead.";
                }
                {
                    this.EcDhPublicKeyBlobDiagId = "SYSLIB0043";
                }
                {
                    this.AssemblyNameCodeBaseMessage = "AssemblyName.CodeBase and AssemblyName.EscapedCodeBase are obsolete. Using them for loading an assembly is not supported.";
                }
                {
                    this.AssemblyNameCodeBaseDiagId = "SYSLIB0044";
                }
                {
                    this.CryptoStringFactoryMessage = "Cryptographic factory methods accepting an algorithm name are obsolete. Use the parameterless Create factory method on the algorithm type instead.";
                }
                {
                    this.CryptoStringFactoryDiagId = "SYSLIB0045";
                }
                {
                    this.ControlledExecutionRunMessage = "ControlledExecution.Run method may corrupt the process and should not be used in production code.";
                }
                {
                    this.ControlledExecutionRunDiagId = "SYSLIB0046";
                }
                {
                    this.XmlSecureResolverMessage = "XmlSecureResolver is obsolete. Use XmlResolver.ThrowingResolver instead when attempting to forbid XML external entity resolution.";
                }
                {
                    this.XmlSecureResolverDiagId = "SYSLIB0047";
                }
                {
                    this.RsaEncryptDecryptValueMessage = "RSA.EncryptValue and DecryptValue are not supported and throw NotSupportedException. Use RSA.Encrypt and RSA.Decrypt instead.";
                }
                {
                    this.RsaEncryptDecryptDiagId = "SYSLIB0048";
                }
                {
                    this.JsonSerializerOptionsAddContextMessage = "JsonSerializerOptions.AddContext is obsolete. To register a JsonSerializerContext, use either the TypeInfoResolver or TypeInfoResolverChain properties.";
                }
                {
                    this.JsonSerializerOptionsAddContextDiagId = "SYSLIB0049";
                }
                {
                    this.LegacyFormatterMessage = "Formatter-based serialization is obsolete and should not be used.";
                }
                {
                    this.LegacyFormatterDiagId = "SYSLIB0050";
                }
                {
                    this.LegacyFormatterImplMessage = "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.";
                }
                {
                    this.LegacyFormatterImplDiagId = "SYSLIB0051";
                }
                {
                    this.RegexExtensibilityImplMessage = "This API supports obsolete mechanisms for Regex extensibility. It is not supported.";
                }
                {
                    this.RegexExtensibilityDiagId = "SYSLIB0052";
                }
                {
                    this.AesGcmTagConstructorMessage = "AesGcm should indicate the required tag size for encryption and decryption. Use a constructor that accepts the tag size.";
                }
                {
                    this.AesGcmTagConstructorDiagId = "SYSLIB0053";
                }
                {
                    this.ThreadVolatileReadWriteMessage = "Thread.VolatileRead and Thread.VolatileWrite are obsolete. Use Volatile.Read or Volatile.Write respectively instead.";
                }
                {
                    this.ThreadVolatileReadWriteDiagId = "SYSLIB0054";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationMessage = "The underlying hardware instruction does not perform a signed saturate narrowing operation, and it always returns an unsigned result. Use the unsigned overload instead.";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationDiagId = "SYSLIB0055";
                }
                {
                    this.LoadFromHashAlgorithmMessage = "LoadFrom with a custom AssemblyHashAlgorithm is obsolete. Use overloads without an AssemblyHashAlgorithm.";
                }
                {
                    this.LoadFromHashAlgorithmDiagId = "SYSLIB0056";
                }
                {
                    this.X509CtorCertDataObsoleteMessage = "Loading certificate data through the constructor or Import is obsolete. Use X509CertificateLoader instead to load certificates.";
                }
                {
                    this.X509CtorCertDataObsoleteDiagId = "SYSLIB0057";
                }
                {
                    this.TlsCipherAlgorithmEnumsMessage = "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.";
                }
                {
                    this.TlsCipherAlgorithmEnumsDiagId = "SYSLIB0058";
                }
                {
                    this.SystemEventsEventsThreadShutdownMessage = "SystemEvents.EventsThreadShutdown callbacks are not run before the process exits. Use AppDomain.ProcessExit instead.";
                }
                {
                    this.SystemEventsEventsThreadShutdownDiagId = "SYSLIB0059";
                }
                {
                    this.Rfc2898DeriveBytesCtorMessage = "The constructors on Rfc2898DeriveBytes are obsolete. Use the static Pbkdf2 method instead.";
                }
                {
                    this.Rfc2898DeriveBytesCtorDiagId = "SYSLIB0060";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteMessage = "The Queryable MinBy and MaxBy taking an IComparer<TSource> are obsolete. Use the new ones that take an IComparer<TKey>.";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteDiagId = "SYSLIB0061";
                }
                {
                    this.XsltSettingsEnableScriptMessage = "XSLT Script blocks are not supported.";
                }
                {
                    this.XsltSettingsEnableScriptDiagId = "SYSLIB0062";
                }
            }
            static $h = 193302;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"SharedUrlFormat","d":193302,"h":4295160598,"f":4194344},{"t":1310721,"n":"SystemTextEncodingUTF7Message","d":193302,"h":8590127894,"f":4194344},{"t":1310721,"n":"SystemTextEncodingUTF7DiagId","d":193302,"h":12885095190,"f":4194344},{"t":1310721,"n":"PrincipalPermissionAttributeMessage","d":193302,"h":17180062486,"f":4194344},{"t":1310721,"n":"PrincipalPermissionAttributeDiagId","d":193302,"h":21475029782,"f":4194344},{"t":1310721,"n":"CodeAccessSecurityMessage","d":193302,"h":25769997078,"f":4194344},{"t":1310721,"n":"CodeAccessSecurityDiagId","d":193302,"h":30064964374,"f":4194344},{"t":1310721,"n":"ConstrainedExecutionRegionMessage","d":193302,"h":34359931670,"f":4194344},{"t":1310721,"n":"ConstrainedExecutionRegionDiagId","d":193302,"h":38654898966,"f":4194344},{"t":1310721,"n":"GlobalAssemblyCacheMessage","d":193302,"h":42949866262,"f":4194344},{"t":1310721,"n":"GlobalAssemblyCacheDiagId","d":193302,"h":47244833558,"f":4194344},{"t":1310721,"n":"ThreadAbortMessage","d":193302,"h":51539800854,"f":4194344},{"t":1310721,"n":"ThreadResetAbortMessage","d":193302,"h":55834768150,"f":4194344},{"t":1310721,"n":"ThreadAbortDiagId","d":193302,"h":60129735446,"f":4194344},{"t":1310721,"n":"DefaultCryptoAlgorithmsMessage","d":193302,"h":64424702742,"f":4194344},{"t":1310721,"n":"DefaultCryptoAlgorithmsDiagId","d":193302,"h":68719670038,"f":4194344},{"t":1310721,"n":"CreatePdbGeneratorMessage","d":193302,"h":73014637334,"f":4194344},{"t":1310721,"n":"CreatePdbGeneratorDiagId","d":193302,"h":77309604630,"f":4194344},{"t":1310721,"n":"AuthenticationManagerMessage","d":193302,"h":81604571926,"f":4194344},{"t":1310721,"n":"AuthenticationManagerDiagId","d":193302,"h":85899539222,"f":4194344},{"t":1310721,"n":"RemotingApisMessage","d":193302,"h":90194506518,"f":4194344},{"t":1310721,"n":"RemotingApisDiagId","d":193302,"h":94489473814,"f":4194344},{"t":1310721,"n":"BinaryFormatterMessage","d":193302,"h":98784441110,"f":4194344},{"t":1310721,"n":"BinaryFormatterDiagId","d":193302,"h":103079408406,"f":4194344},{"t":1310721,"n":"CodeBaseMessage","d":193302,"h":107374375702,"f":4194344},{"t":1310721,"n":"CodeBaseDiagId","d":193302,"h":111669342998,"f":4194344},{"t":1310721,"n":"EscapeUriStringMessage","d":193302,"h":115964310294,"f":4194344},{"t":1310721,"n":"EscapeUriStringDiagId","d":193302,"h":120259277590,"f":4194344},{"t":1310721,"n":"WebRequestMessage","d":193302,"h":124554244886,"f":4194344},{"t":1310721,"n":"WebRequestDiagId","d":193302,"h":128849212182,"f":4194344},{"t":1310721,"n":"DisablePrivateReflectionAttributeMessage","d":193302,"h":133144179478,"f":4194344},{"t":1310721,"n":"DisablePrivateReflectionAttributeDiagId","d":193302,"h":137439146774,"f":4194344},{"t":1310721,"n":"GetContextInfoMessage","d":193302,"h":141734114070,"f":4194344},{"t":1310721,"n":"GetContextInfoDiagId","d":193302,"h":146029081366,"f":4194344},{"t":1310721,"n":"StrongNameKeyPairMessage","d":193302,"h":150324048662,"f":4194344},{"t":1310721,"n":"StrongNameKeyPairDiagId","d":193302,"h":154619015958,"f":4194344},{"t":1310721,"n":"ReflectionOnlyLoadingMessage","d":193302,"h":158913983254,"f":4194344},{"t":1310721,"n":"ReflectionOnlyLoadingDiagId","d":193302,"h":163208950550,"f":4194344},{"t":1310721,"n":"RuntimeEnvironmentMessage","d":193302,"h":167503917846,"f":4194344},{"t":1310721,"n":"RuntimeEnvironmentDiagId","d":193302,"h":171798885142,"f":4194344},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesMessage","d":193302,"h":176093852438,"f":4194344},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesDiagId","d":193302,"h":180388819734,"f":4194344},{"t":1310721,"n":"DerivedCryptographicTypesMessage","d":193302,"h":184683787030,"f":4194344},{"t":1310721,"n":"DerivedCryptographicTypesDiagId","d":193302,"h":188978754326,"f":4194344},{"t":1310721,"n":"RijndaelMessage","d":193302,"h":193273721622,"f":4194344},{"t":1310721,"n":"RijndaelDiagId","d":193302,"h":197568688918,"f":4194344},{"t":1310721,"n":"RNGCryptoServiceProviderMessage","d":193302,"h":201863656214,"f":4194344},{"t":1310721,"n":"RNGCryptoServiceProviderDiagId","d":193302,"h":206158623510,"f":4194344},{"t":1310721,"n":"AppDomainCreateUnloadMessage","d":193302,"h":210453590806,"f":4194344},{"t":1310721,"n":"AppDomainCreateUnloadDiagId","d":193302,"h":214748558102,"f":4194344},{"t":1310721,"n":"SuppressIldasmAttributeMessage","d":193302,"h":219043525398,"f":4194344},{"t":1310721,"n":"SuppressIldasmAttributeDiagId","d":193302,"h":223338492694,"f":4194344},{"t":1310721,"n":"X509CertificateImmutableMessage","d":193302,"h":227633459990,"f":4194344},{"t":1310721,"n":"X509CertificateImmutableDiagId","d":193302,"h":231928427286,"f":4194344},{"t":1310721,"n":"PublicKeyPropertyMessage","d":193302,"h":236223394582,"f":4194344},{"t":1310721,"n":"PublicKeyPropertyDiagId","d":193302,"h":240518361878,"f":4194344},{"t":1310721,"n":"X509CertificatePrivateKeyMessage","d":193302,"h":244813329174,"f":4194344},{"t":1310721,"n":"X509CertificatePrivateKeyDiagId","d":193302,"h":249108296470,"f":4194344},{"t":1310721,"n":"ProduceLegacyHmacValuesMessage","d":193302,"h":253403263766,"f":4194344},{"t":1310721,"n":"ProduceLegacyHmacValuesDiagId","d":193302,"h":257698231062,"f":4194344},{"t":1310721,"n":"UseManagedSha1Message","d":193302,"h":261993198358,"f":4194344},{"t":1310721,"n":"UseManagedSha1DiagId","d":193302,"h":266288165654,"f":4194344},{"t":1310721,"n":"CryptoConfigEncodeOIDMessage","d":193302,"h":270583132950,"f":4194344},{"t":1310721,"n":"CryptoConfigEncodeOIDDiagId","d":193302,"h":274878100246,"f":4194344},{"t":1310721,"n":"CorruptedStateRecoveryMessage","d":193302,"h":279173067542,"f":4194344},{"t":1310721,"n":"CorruptedStateRecoveryDiagId","d":193302,"h":283468034838,"f":4194344},{"t":1310721,"n":"Rfc2898CryptDeriveKeyMessage","d":193302,"h":287763002134,"f":4194344},{"t":1310721,"n":"Rfc2898CryptDeriveKeyDiagId","d":193302,"h":292057969430,"f":4194344},{"t":1310721,"n":"CmsSignerCspParamsCtorMessage","d":193302,"h":296352936726,"f":4194344},{"t":1310721,"n":"CmsSignerCspParamsCtorDiagId","d":193302,"h":300647904022,"f":4194344},{"t":1310721,"n":"SignerInfoCounterSigMessage","d":193302,"h":304942871318,"f":4194344},{"t":1310721,"n":"SignerInfoCounterSigDiagId","d":193302,"h":309237838614,"f":4194344},{"t":1310721,"n":"RegexCompileToAssemblyMessage","d":193302,"h":313532805910,"f":4194344},{"t":1310721,"n":"RegexCompileToAssemblyDiagId","d":193302,"h":317827773206,"f":4194344},{"t":1310721,"n":"AssemblyNameMembersMessage","d":193302,"h":322122740502,"f":4194344},{"t":1310721,"n":"AssemblyNameMembersDiagId","d":193302,"h":326417707798,"f":4194344},{"t":1310721,"n":"SystemDataSerializationFormatBinaryMessage","d":193302,"h":330712675094,"f":4194344},{"t":1310721,"n":"SystemDataSerializationFormatBinaryDiagId","d":193302,"h":335007642390,"f":4194344},{"t":1310721,"n":"TlsVersion10and11Message","d":193302,"h":339302609686,"f":4194344},{"t":1310721,"n":"TlsVersion10and11DiagId","d":193302,"h":343597576982,"f":4194344},{"t":1310721,"n":"EncryptionPolicyMessage","d":193302,"h":347892544278,"f":4194344},{"t":1310721,"n":"EncryptionPolicyDiagId","d":193302,"h":352187511574,"f":4194344},{"t":1310721,"n":"EccXmlExportImportMessage","d":193302,"h":356482478870,"f":4194344},{"t":1310721,"n":"EccXmlExportImportDiagId","d":193302,"h":360777446166,"f":4194344},{"t":1310721,"n":"EcDhPublicKeyBlobMessage","d":193302,"h":365072413462,"f":4194344},{"t":1310721,"n":"EcDhPublicKeyBlobDiagId","d":193302,"h":369367380758,"f":4194344},{"t":1310721,"n":"AssemblyNameCodeBaseMessage","d":193302,"h":373662348054,"f":4194344},{"t":1310721,"n":"AssemblyNameCodeBaseDiagId","d":193302,"h":377957315350,"f":4194344},{"t":1310721,"n":"CryptoStringFactoryMessage","d":193302,"h":382252282646,"f":4194344},{"t":1310721,"n":"CryptoStringFactoryDiagId","d":193302,"h":386547249942,"f":4194344},{"t":1310721,"n":"ControlledExecutionRunMessage","d":193302,"h":390842217238,"f":4194344},{"t":1310721,"n":"ControlledExecutionRunDiagId","d":193302,"h":395137184534,"f":4194344},{"t":1310721,"n":"XmlSecureResolverMessage","d":193302,"h":399432151830,"f":4194344},{"t":1310721,"n":"XmlSecureResolverDiagId","d":193302,"h":403727119126,"f":4194344},{"t":1310721,"n":"RsaEncryptDecryptValueMessage","d":193302,"h":408022086422,"f":4194344},{"t":1310721,"n":"RsaEncryptDecryptDiagId","d":193302,"h":412317053718,"f":4194344},{"t":1310721,"n":"JsonSerializerOptionsAddContextMessage","d":193302,"h":416612021014,"f":4194344},{"t":1310721,"n":"JsonSerializerOptionsAddContextDiagId","d":193302,"h":420906988310,"f":4194344},{"t":1310721,"n":"LegacyFormatterMessage","d":193302,"h":425201955606,"f":4194344},{"t":1310721,"n":"LegacyFormatterDiagId","d":193302,"h":429496922902,"f":4194344},{"t":1310721,"n":"LegacyFormatterImplMessage","d":193302,"h":433791890198,"f":4194344},{"t":1310721,"n":"LegacyFormatterImplDiagId","d":193302,"h":438086857494,"f":4194344},{"t":1310721,"n":"RegexExtensibilityImplMessage","d":193302,"h":442381824790,"f":4194344},{"t":1310721,"n":"RegexExtensibilityDiagId","d":193302,"h":446676792086,"f":4194344},{"t":1310721,"n":"AesGcmTagConstructorMessage","d":193302,"h":450971759382,"f":4194344},{"t":1310721,"n":"AesGcmTagConstructorDiagId","d":193302,"h":455266726678,"f":4194344},{"t":1310721,"n":"ThreadVolatileReadWriteMessage","d":193302,"h":459561693974,"f":4194344},{"t":1310721,"n":"ThreadVolatileReadWriteDiagId","d":193302,"h":463856661270,"f":4194344},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationMessage","d":193302,"h":468151628566,"f":4194344},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationDiagId","d":193302,"h":472446595862,"f":4194344},{"t":1310721,"n":"LoadFromHashAlgorithmMessage","d":193302,"h":476741563158,"f":4194344},{"t":1310721,"n":"LoadFromHashAlgorithmDiagId","d":193302,"h":481036530454,"f":4194344},{"t":1310721,"n":"X509CtorCertDataObsoleteMessage","d":193302,"h":485331497750,"f":4194344},{"t":1310721,"n":"X509CtorCertDataObsoleteDiagId","d":193302,"h":489626465046,"f":4194344},{"t":1310721,"n":"TlsCipherAlgorithmEnumsMessage","d":193302,"h":493921432342,"f":4194344},{"t":1310721,"n":"TlsCipherAlgorithmEnumsDiagId","d":193302,"h":498216399638,"f":4194344},{"t":1310721,"n":"SystemEventsEventsThreadShutdownMessage","d":193302,"h":502511366934,"f":4194344},{"t":1310721,"n":"SystemEventsEventsThreadShutdownDiagId","d":193302,"h":506806334230,"f":4194344},{"t":1310721,"n":"Rfc2898DeriveBytesCtorMessage","d":193302,"h":511101301526,"f":4194344},{"t":1310721,"n":"Rfc2898DeriveBytesCtorDiagId","d":193302,"h":515396268822,"f":4194344},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteMessage","d":193302,"h":519691236118,"f":4194344},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteDiagId","d":193302,"h":523986203414,"f":4194344},{"t":1310721,"n":"XsltSettingsEnableScriptMessage","d":193302,"h":528281170710,"f":4194344},{"t":1310721,"n":"XsltSettingsEnableScriptDiagId","d":193302,"h":532576138006,"f":4194344}],"h":193302}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Obsoletions`; }
        });
        
        $asm.$cls("$st.System.HResults", ($self) => class HResults
        {
            /*int*/ static S_OK = 0;
            /*int*/ static S_FALSE = 1;
            /*int*/ static COR_E_ABANDONEDMUTEX = -2146233043;
            /*int*/ static COR_E_AMBIGUOUSIMPLEMENTATION = -2146234262;
            /*int*/ static COR_E_AMBIGUOUSMATCH = -2147475171;
            /*int*/ static COR_E_APPDOMAINUNLOADED = -2146234348;
            /*int*/ static COR_E_APPLICATION = -2146232832;
            /*int*/ static COR_E_ARGUMENT = -2147024809;
            /*int*/ static COR_E_ARGUMENTOUTOFRANGE = -2146233086;
            /*int*/ static COR_E_ARITHMETIC = -2147024362;
            /*int*/ static COR_E_ARRAYTYPEMISMATCH = -2146233085;
            /*int*/ static COR_E_BADEXEFORMAT = -2147024703;
            /*int*/ static COR_E_BADIMAGEFORMAT = -2147024885;
            /*int*/ static COR_E_CANNOTUNLOADAPPDOMAIN = -2146234347;
            /*int*/ static COR_E_CODECONTRACTFAILED = -2146233022;
            /*int*/ static COR_E_CONTEXTMARSHAL = -2146233084;
            /*int*/ static COR_E_CUSTOMATTRIBUTEFORMAT = -2146232827;
            /*int*/ static COR_E_DATAMISALIGNED = -2146233023;
            /*int*/ static COR_E_DIRECTORYNOTFOUND = -2147024893;
            /*int*/ static COR_E_DIVIDEBYZERO = -2147352558;
            /*int*/ static COR_E_DLLNOTFOUND = -2146233052;
            /*int*/ static COR_E_DUPLICATEWAITOBJECT = -2146233047;
            /*int*/ static COR_E_ENDOFSTREAM = -2147024858;
            /*int*/ static COR_E_ENTRYPOINTNOTFOUND = -2146233053;
            /*int*/ static COR_E_EXCEPTION = -2146233088;
            /*int*/ static COR_E_EXECUTIONENGINE = -2146233082;
            /*int*/ static COR_E_FAILFAST = -2146232797;
            /*int*/ static COR_E_FIELDACCESS = -2146233081;
            /*int*/ static COR_E_FILELOAD = -2146232799;
            /*int*/ static COR_E_FILENOTFOUND = -2147024894;
            /*int*/ static COR_E_FORMAT = -2146233033;
            /*int*/ static COR_E_INDEXOUTOFRANGE = -2146233080;
            /*int*/ static COR_E_INSUFFICIENTEXECUTIONSTACK = -2146232968;
            /*int*/ static COR_E_INSUFFICIENTMEMORY = -2146233027;
            /*int*/ static COR_E_INVALIDCAST = -2147467262;
            /*int*/ static COR_E_INVALIDCOMOBJECT = -2146233049;
            /*int*/ static COR_E_INVALIDFILTERCRITERIA = -2146232831;
            /*int*/ static COR_E_INVALIDOLEVARIANTTYPE = -2146233039;
            /*int*/ static COR_E_INVALIDOPERATION = -2146233079;
            /*int*/ static COR_E_INVALIDPROGRAM = -2146233030;
            /*int*/ static COR_E_IO = -2146232800;
            /*int*/ static COR_E_KEYNOTFOUND = -2146232969;
            /*int*/ static COR_E_MARSHALDIRECTIVE = -2146233035;
            /*int*/ static COR_E_MEMBERACCESS = -2146233062;
            /*int*/ static COR_E_METHODACCESS = -2146233072;
            /*int*/ static COR_E_MISSINGFIELD = -2146233071;
            /*int*/ static COR_E_MISSINGMANIFESTRESOURCE = -2146233038;
            /*int*/ static COR_E_MISSINGMEMBER = -2146233070;
            /*int*/ static COR_E_MISSINGMETHOD = -2146233069;
            /*int*/ static COR_E_MISSINGSATELLITEASSEMBLY = -2146233034;
            /*int*/ static COR_E_MULTICASTNOTSUPPORTED = -2146233068;
            /*int*/ static COR_E_NOTFINITENUMBER = -2146233048;
            /*int*/ static COR_E_NOTSUPPORTED = -2146233067;
            /*int*/ static COR_E_OBJECTDISPOSED = -2146232798;
            /*int*/ static COR_E_OPERATIONCANCELED = -2146233029;
            /*int*/ static COR_E_OUTOFMEMORY = -2147024882;
            /*int*/ static COR_E_OVERFLOW = -2146233066;
            /*int*/ static COR_E_PATHTOOLONG = -2147024690;
            /*int*/ static COR_E_PLATFORMNOTSUPPORTED = -2146233031;
            /*int*/ static COR_E_RANK = -2146233065;
            /*int*/ static COR_E_REFLECTIONTYPELOAD = -2146232830;
            /*int*/ static COR_E_RUNTIMEWRAPPED = -2146233026;
            /*int*/ static COR_E_SAFEARRAYRANKMISMATCH = -2146233032;
            /*int*/ static COR_E_SAFEARRAYTYPEMISMATCH = -2146233037;
            /*int*/ static COR_E_SECURITY = -2146233078;
            /*int*/ static COR_E_SERIALIZATION = -2146233076;
            /*int*/ static COR_E_STACKOVERFLOW = -2147023895;
            /*int*/ static COR_E_SYNCHRONIZATIONLOCK = -2146233064;
            /*int*/ static COR_E_SYSTEM = -2146233087;
            /*int*/ static COR_E_TARGET = -2146232829;
            /*int*/ static COR_E_TARGETINVOCATION = -2146232828;
            /*int*/ static COR_E_TARGETPARAMCOUNT = -2147352562;
            /*int*/ static COR_E_THREADABORTED = -2146233040;
            /*int*/ static COR_E_THREADINTERRUPTED = -2146233063;
            /*int*/ static COR_E_THREADSTART = -2146233051;
            /*int*/ static COR_E_THREADSTATE = -2146233056;
            /*int*/ static COR_E_TIMEOUT = -2146233083;
            /*int*/ static COR_E_TYPEACCESS = -2146233021;
            /*int*/ static COR_E_TYPEINITIALIZATION = -2146233036;
            /*int*/ static COR_E_TYPELOAD = -2146233054;
            /*int*/ static COR_E_TYPEUNLOADED = -2146234349;
            /*int*/ static COR_E_UNAUTHORIZEDACCESS = -2147024891;
            /*int*/ static COR_E_VERIFICATION = -2146233075;
            /*int*/ static COR_E_WAITHANDLECANNOTBEOPENED = -2146233044;
            /*int*/ static CO_E_NOTINITIALIZED = -2147221008;
            /*int*/ static DISP_E_PARAMNOTFOUND = -2147352572;
            /*int*/ static DISP_E_TYPEMISMATCH = -2147352571;
            /*int*/ static DISP_E_BADVARTYPE = -2147352568;
            /*int*/ static DISP_E_OVERFLOW = -2147352566;
            /*int*/ static DISP_E_DIVBYZERO = -2147352558;
            /*int*/ static E_BOUNDS = -2147483637;
            /*int*/ static E_CHANGED_STATE = -2147483636;
            /*int*/ static E_FILENOTFOUND = -2147024894;
            /*int*/ static E_FAIL = -2147467259;
            /*int*/ static E_HANDLE = -2147024890;
            /*int*/ static E_INVALIDARG = -2147024809;
            /*int*/ static E_NOTIMPL = -2147467263;
            /*int*/ static E_OUTOFMEMORY = -2147024882;
            /*int*/ static E_POINTER = -2147467261;
            /*int*/ static ERROR_MRM_MAP_NOT_FOUND = -2147009761;
            /*int*/ static ERROR_TIMEOUT = -2147023436;
            /*int*/ static RO_E_CLOSED = -2147483629;
            /*int*/ static RPC_E_CHANGED_MODE = -2147417850;
            /*int*/ static TYPE_E_TYPEMISMATCH = -2147316576;
            /*int*/ static STG_E_PATHNOTFOUND = -2147287037;
            /*int*/ static CTL_E_PATHNOTFOUND = -2146828212;
            /*int*/ static CTL_E_FILENOTFOUND = -2146828235;
            /*int*/ static FUSION_E_INVALID_NAME = -2146234297;
            /*int*/ static FUSION_E_REF_DEF_MISMATCH = -2146234304;
            /*int*/ static ERROR_TOO_MANY_OPEN_FILES = -2147024892;
            /*int*/ static ERROR_SHARING_VIOLATION = -2147024864;
            /*int*/ static ERROR_LOCK_VIOLATION = -2147024863;
            /*int*/ static ERROR_OPEN_FAILED = -2147024786;
            /*int*/ static ERROR_DISK_CORRUPT = -2147023503;
            /*int*/ static ERROR_UNRECOGNIZED_VOLUME = -2147023891;
            /*int*/ static ERROR_DLL_INIT_FAILED = -2147023782;
            /*int*/ static MSEE_E_ASSEMBLYLOADINPROGRESS = -2146234346;
            /*int*/ static ERROR_FILE_INVALID = -2147023890;
            static $h = 127766;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"S_OK","d":127766,"h":4295095062,"f":4194344},{"t":655361,"n":"S_FALSE","d":127766,"h":8590062358,"f":4194344},{"t":655361,"n":"COR_E_ABANDONEDMUTEX","d":127766,"h":12885029654,"f":4194344},{"t":655361,"n":"COR_E_AMBIGUOUSIMPLEMENTATION","d":127766,"h":17179996950,"f":4194344},{"t":655361,"n":"COR_E_AMBIGUOUSMATCH","d":127766,"h":21474964246,"f":4194344},{"t":655361,"n":"COR_E_APPDOMAINUNLOADED","d":127766,"h":25769931542,"f":4194344},{"t":655361,"n":"COR_E_APPLICATION","d":127766,"h":30064898838,"f":4194344},{"t":655361,"n":"COR_E_ARGUMENT","d":127766,"h":34359866134,"f":4194344},{"t":655361,"n":"COR_E_ARGUMENTOUTOFRANGE","d":127766,"h":38654833430,"f":4194344},{"t":655361,"n":"COR_E_ARITHMETIC","d":127766,"h":42949800726,"f":4194344},{"t":655361,"n":"COR_E_ARRAYTYPEMISMATCH","d":127766,"h":47244768022,"f":4194344},{"t":655361,"n":"COR_E_BADEXEFORMAT","d":127766,"h":51539735318,"f":4194344},{"t":655361,"n":"COR_E_BADIMAGEFORMAT","d":127766,"h":55834702614,"f":4194344},{"t":655361,"n":"COR_E_CANNOTUNLOADAPPDOMAIN","d":127766,"h":60129669910,"f":4194344},{"t":655361,"n":"COR_E_CODECONTRACTFAILED","d":127766,"h":64424637206,"f":4194344},{"t":655361,"n":"COR_E_CONTEXTMARSHAL","d":127766,"h":68719604502,"f":4194344},{"t":655361,"n":"COR_E_CUSTOMATTRIBUTEFORMAT","d":127766,"h":73014571798,"f":4194344},{"t":655361,"n":"COR_E_DATAMISALIGNED","d":127766,"h":77309539094,"f":4194344},{"t":655361,"n":"COR_E_DIRECTORYNOTFOUND","d":127766,"h":81604506390,"f":4194344},{"t":655361,"n":"COR_E_DIVIDEBYZERO","d":127766,"h":85899473686,"f":4194344},{"t":655361,"n":"COR_E_DLLNOTFOUND","d":127766,"h":90194440982,"f":4194344},{"t":655361,"n":"COR_E_DUPLICATEWAITOBJECT","d":127766,"h":94489408278,"f":4194344},{"t":655361,"n":"COR_E_ENDOFSTREAM","d":127766,"h":98784375574,"f":4194344},{"t":655361,"n":"COR_E_ENTRYPOINTNOTFOUND","d":127766,"h":103079342870,"f":4194344},{"t":655361,"n":"COR_E_EXCEPTION","d":127766,"h":107374310166,"f":4194344},{"t":655361,"n":"COR_E_EXECUTIONENGINE","d":127766,"h":111669277462,"f":4194344},{"t":655361,"n":"COR_E_FAILFAST","d":127766,"h":115964244758,"f":4194344},{"t":655361,"n":"COR_E_FIELDACCESS","d":127766,"h":120259212054,"f":4194344},{"t":655361,"n":"COR_E_FILELOAD","d":127766,"h":124554179350,"f":4194344},{"t":655361,"n":"COR_E_FILENOTFOUND","d":127766,"h":128849146646,"f":4194344},{"t":655361,"n":"COR_E_FORMAT","d":127766,"h":133144113942,"f":4194344},{"t":655361,"n":"COR_E_INDEXOUTOFRANGE","d":127766,"h":137439081238,"f":4194344},{"t":655361,"n":"COR_E_INSUFFICIENTEXECUTIONSTACK","d":127766,"h":141734048534,"f":4194344},{"t":655361,"n":"COR_E_INSUFFICIENTMEMORY","d":127766,"h":146029015830,"f":4194344},{"t":655361,"n":"COR_E_INVALIDCAST","d":127766,"h":150323983126,"f":4194344},{"t":655361,"n":"COR_E_INVALIDCOMOBJECT","d":127766,"h":154618950422,"f":4194344},{"t":655361,"n":"COR_E_INVALIDFILTERCRITERIA","d":127766,"h":158913917718,"f":4194344},{"t":655361,"n":"COR_E_INVALIDOLEVARIANTTYPE","d":127766,"h":163208885014,"f":4194344},{"t":655361,"n":"COR_E_INVALIDOPERATION","d":127766,"h":167503852310,"f":4194344},{"t":655361,"n":"COR_E_INVALIDPROGRAM","d":127766,"h":171798819606,"f":4194344},{"t":655361,"n":"COR_E_IO","d":127766,"h":176093786902,"f":4194344},{"t":655361,"n":"COR_E_KEYNOTFOUND","d":127766,"h":180388754198,"f":4194344},{"t":655361,"n":"COR_E_MARSHALDIRECTIVE","d":127766,"h":184683721494,"f":4194344},{"t":655361,"n":"COR_E_MEMBERACCESS","d":127766,"h":188978688790,"f":4194344},{"t":655361,"n":"COR_E_METHODACCESS","d":127766,"h":193273656086,"f":4194344},{"t":655361,"n":"COR_E_MISSINGFIELD","d":127766,"h":197568623382,"f":4194344},{"t":655361,"n":"COR_E_MISSINGMANIFESTRESOURCE","d":127766,"h":201863590678,"f":4194344},{"t":655361,"n":"COR_E_MISSINGMEMBER","d":127766,"h":206158557974,"f":4194344},{"t":655361,"n":"COR_E_MISSINGMETHOD","d":127766,"h":210453525270,"f":4194344},{"t":655361,"n":"COR_E_MISSINGSATELLITEASSEMBLY","d":127766,"h":214748492566,"f":4194344},{"t":655361,"n":"COR_E_MULTICASTNOTSUPPORTED","d":127766,"h":219043459862,"f":4194344},{"t":655361,"n":"COR_E_NOTFINITENUMBER","d":127766,"h":223338427158,"f":4194344},{"t":655361,"n":"COR_E_NOTSUPPORTED","d":127766,"h":227633394454,"f":4194344},{"t":655361,"n":"COR_E_OBJECTDISPOSED","d":127766,"h":231928361750,"f":4194344},{"t":655361,"n":"COR_E_OPERATIONCANCELED","d":127766,"h":236223329046,"f":4194344},{"t":655361,"n":"COR_E_OUTOFMEMORY","d":127766,"h":240518296342,"f":4194344},{"t":655361,"n":"COR_E_OVERFLOW","d":127766,"h":244813263638,"f":4194344},{"t":655361,"n":"COR_E_PATHTOOLONG","d":127766,"h":249108230934,"f":4194344},{"t":655361,"n":"COR_E_PLATFORMNOTSUPPORTED","d":127766,"h":253403198230,"f":4194344},{"t":655361,"n":"COR_E_RANK","d":127766,"h":257698165526,"f":4194344},{"t":655361,"n":"COR_E_REFLECTIONTYPELOAD","d":127766,"h":261993132822,"f":4194344},{"t":655361,"n":"COR_E_RUNTIMEWRAPPED","d":127766,"h":266288100118,"f":4194344},{"t":655361,"n":"COR_E_SAFEARRAYRANKMISMATCH","d":127766,"h":270583067414,"f":4194344},{"t":655361,"n":"COR_E_SAFEARRAYTYPEMISMATCH","d":127766,"h":274878034710,"f":4194344},{"t":655361,"n":"COR_E_SECURITY","d":127766,"h":279173002006,"f":4194344},{"t":655361,"n":"COR_E_SERIALIZATION","d":127766,"h":283467969302,"f":4194344},{"t":655361,"n":"COR_E_STACKOVERFLOW","d":127766,"h":287762936598,"f":4194344},{"t":655361,"n":"COR_E_SYNCHRONIZATIONLOCK","d":127766,"h":292057903894,"f":4194344},{"t":655361,"n":"COR_E_SYSTEM","d":127766,"h":296352871190,"f":4194344},{"t":655361,"n":"COR_E_TARGET","d":127766,"h":300647838486,"f":4194344},{"t":655361,"n":"COR_E_TARGETINVOCATION","d":127766,"h":304942805782,"f":4194344},{"t":655361,"n":"COR_E_TARGETPARAMCOUNT","d":127766,"h":309237773078,"f":4194344},{"t":655361,"n":"COR_E_THREADABORTED","d":127766,"h":313532740374,"f":4194344},{"t":655361,"n":"COR_E_THREADINTERRUPTED","d":127766,"h":317827707670,"f":4194344},{"t":655361,"n":"COR_E_THREADSTART","d":127766,"h":322122674966,"f":4194344},{"t":655361,"n":"COR_E_THREADSTATE","d":127766,"h":326417642262,"f":4194344},{"t":655361,"n":"COR_E_TIMEOUT","d":127766,"h":330712609558,"f":4194344},{"t":655361,"n":"COR_E_TYPEACCESS","d":127766,"h":335007576854,"f":4194344},{"t":655361,"n":"COR_E_TYPEINITIALIZATION","d":127766,"h":339302544150,"f":4194344},{"t":655361,"n":"COR_E_TYPELOAD","d":127766,"h":343597511446,"f":4194344},{"t":655361,"n":"COR_E_TYPEUNLOADED","d":127766,"h":347892478742,"f":4194344},{"t":655361,"n":"COR_E_UNAUTHORIZEDACCESS","d":127766,"h":352187446038,"f":4194344},{"t":655361,"n":"COR_E_VERIFICATION","d":127766,"h":356482413334,"f":4194344},{"t":655361,"n":"COR_E_WAITHANDLECANNOTBEOPENED","d":127766,"h":360777380630,"f":4194344},{"t":655361,"n":"CO_E_NOTINITIALIZED","d":127766,"h":365072347926,"f":4194344},{"t":655361,"n":"DISP_E_PARAMNOTFOUND","d":127766,"h":369367315222,"f":4194344},{"t":655361,"n":"DISP_E_TYPEMISMATCH","d":127766,"h":373662282518,"f":4194344},{"t":655361,"n":"DISP_E_BADVARTYPE","d":127766,"h":377957249814,"f":4194344},{"t":655361,"n":"DISP_E_OVERFLOW","d":127766,"h":382252217110,"f":4194344},{"t":655361,"n":"DISP_E_DIVBYZERO","d":127766,"h":386547184406,"f":4194344},{"t":655361,"n":"E_BOUNDS","d":127766,"h":390842151702,"f":4194344},{"t":655361,"n":"E_CHANGED_STATE","d":127766,"h":395137118998,"f":4194344},{"t":655361,"n":"E_FILENOTFOUND","d":127766,"h":399432086294,"f":4194344},{"t":655361,"n":"E_FAIL","d":127766,"h":403727053590,"f":4194344},{"t":655361,"n":"E_HANDLE","d":127766,"h":408022020886,"f":4194344},{"t":655361,"n":"E_INVALIDARG","d":127766,"h":412316988182,"f":4194344},{"t":655361,"n":"E_NOTIMPL","d":127766,"h":416611955478,"f":4194344},{"t":655361,"n":"E_OUTOFMEMORY","d":127766,"h":420906922774,"f":4194344},{"t":655361,"n":"E_POINTER","d":127766,"h":425201890070,"f":4194344},{"t":655361,"n":"ERROR_MRM_MAP_NOT_FOUND","d":127766,"h":429496857366,"f":4194344},{"t":655361,"n":"ERROR_TIMEOUT","d":127766,"h":433791824662,"f":4194344},{"t":655361,"n":"RO_E_CLOSED","d":127766,"h":438086791958,"f":4194344},{"t":655361,"n":"RPC_E_CHANGED_MODE","d":127766,"h":442381759254,"f":4194344},{"t":655361,"n":"TYPE_E_TYPEMISMATCH","d":127766,"h":446676726550,"f":4194344},{"t":655361,"n":"STG_E_PATHNOTFOUND","d":127766,"h":450971693846,"f":4194344},{"t":655361,"n":"CTL_E_PATHNOTFOUND","d":127766,"h":455266661142,"f":4194344},{"t":655361,"n":"CTL_E_FILENOTFOUND","d":127766,"h":459561628438,"f":4194344},{"t":655361,"n":"FUSION_E_INVALID_NAME","d":127766,"h":463856595734,"f":4194344},{"t":655361,"n":"FUSION_E_REF_DEF_MISMATCH","d":127766,"h":468151563030,"f":4194344},{"t":655361,"n":"ERROR_TOO_MANY_OPEN_FILES","d":127766,"h":472446530326,"f":4194344},{"t":655361,"n":"ERROR_SHARING_VIOLATION","d":127766,"h":476741497622,"f":4194344},{"t":655361,"n":"ERROR_LOCK_VIOLATION","d":127766,"h":481036464918,"f":4194344},{"t":655361,"n":"ERROR_OPEN_FAILED","d":127766,"h":485331432214,"f":4194344},{"t":655361,"n":"ERROR_DISK_CORRUPT","d":127766,"h":489626399510,"f":4194344},{"t":655361,"n":"ERROR_UNRECOGNIZED_VOLUME","d":127766,"h":493921366806,"f":4194344},{"t":655361,"n":"ERROR_DLL_INIT_FAILED","d":127766,"h":498216334102,"f":4194344},{"t":655361,"n":"MSEE_E_ASSEMBLYLOADINPROGRESS","d":127766,"h":502511301398,"f":4194344},{"t":655361,"n":"ERROR_FILE_INVALID","d":127766,"h":506806268694,"f":4194344}],"h":127766}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.HResults`; }
        });
        
        $asm.$cls("$st.System.SR", ($self) => class SR
        {
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$st.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                if ($.$st.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$st.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$st.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$st.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$st.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$st.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$st.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$st.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$st.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$st.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$st.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$$.System.Object.ReferenceEquals($.$st.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("System.Threading", $.$st.System.SR.$type.Assembly);
                    $.$st.System.SR.s_resourceManager = temp;
                }
                return $.$st.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$st.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$st.System.SR.resourceCulture = value;
            }
            static /*string */ get CountdownEvent_Increment_AlreadyZero()
            {
                return "The event is already signaled and cannot be incremented.";
            }
            static /*string */ get CountdownEvent_Increment_AlreadyMax()
            {
                return "The increment operation would cause the CurrentCount to overflow.";
            }
            static /*string */ get CountdownEvent_Decrement_BelowZero()
            {
                return "Invalid attempt made to decrement the event's count below zero.";
            }
            static /*string */ get Common_OperationCanceled()
            {
                return "The operation was canceled.";
            }
            static /*string */ get Barrier_SignalAndWait_InvalidOperation_ZeroTotal()
            {
                return "The barrier has no registered participants.";
            }
            static /*string */ get Barrier_SignalAndWait_ArgumentOutOfRange()
            {
                return "The specified timeout must represent a value between -1 and Int32.MaxValue, inclusive.";
            }
            static /*string */ get Barrier_RemoveParticipants_InvalidOperation()
            {
                return "The participantCount argument is greater than the number of participants that haven't yet arrived at the barrier in this phase.";
            }
            static /*string */ get Barrier_RemoveParticipants_ArgumentOutOfRange()
            {
                return "The participantCount argument must be less than or equal the number of participants.";
            }
            static /*string */ get Barrier_InvalidOperation_CalledFromPHA()
            {
                return "This method may not be called from within the postPhaseAction.";
            }
            static /*string */ get Barrier_SignalAndWait_InvalidOperation_ThreadsExceeded()
            {
                return "The number of threads using the barrier exceeded the total number of registered participants.";
            }
            static /*string */ get BarrierPostPhaseException()
            {
                return "The postPhaseAction failed with an exception.";
            }
            static /*string */ get Barrier_AddParticipants_Overflow_ArgumentOutOfRange()
            {
                return "Adding participantCount participants would result in the number of participants exceeding the maximum number allowed.";
            }
            static /*string */ get SynchronizationLockException_IncorrectDispose()
            {
                return "The lock is being disposed while still being used. It either is being held by a thread and/or has active waiters waiting to acquire the lock.";
            }
            static /*string */ get SynchronizationLockException_MisMatchedWrite()
            {
                return "The write lock is being released without being held.";
            }
            static /*string */ get LockRecursionException_UpgradeAfterReadNotAllowed()
            {
                return "Upgradeable lock may not be acquired with read lock held.";
            }
            static /*string */ get LockRecursionException_UpgradeAfterWriteNotAllowed()
            {
                return "Upgradeable lock may not be acquired with write lock held in this mode. Acquiring Upgradeable lock gives the ability to read along with an option to upgrade to a writer.";
            }
            static /*string */ get SynchronizationLockException_MisMatchedUpgrade()
            {
                return "The upgradeable lock is being released without being held.";
            }
            static /*string */ get SynchronizationLockException_MisMatchedRead()
            {
                return "The read lock is being released without being held.";
            }
            static /*string */ get LockRecursionException_WriteAfterReadNotAllowed()
            {
                return "Write lock may not be acquired with read lock held. This pattern is prone to deadlocks. Please ensure that read locks are released before taking a write lock. If an upgrade is necessary, use an upgrade lock in place of the read lock.";
            }
            static /*string */ get LockRecursionException_RecursiveWriteNotAllowed()
            {
                return "Recursive write lock acquisitions not allowed in this mode.";
            }
            static /*string */ get LockRecursionException_ReadAfterWriteNotAllowed()
            {
                return "A read lock may not be acquired with the write lock held in this mode.";
            }
            static /*string */ get LockRecursionException_RecursiveUpgradeNotAllowed()
            {
                return "Recursive upgradeable lock acquisitions not allowed in this mode.";
            }
            static /*string */ get LockRecursionException_RecursiveReadNotAllowed()
            {
                return "Recursive read lock acquisitions not allowed in this mode.";
            }
            static /*string */ get Overflow_UInt16()
            {
                return "Value was either too large or too small for a UInt16.";
            }
            static /*string */ get ReaderWriterLock_Timeout()
            {
                return "The operation has timed out. {0}";
            }
            static /*string */ FormatReaderWriterLock_Timeout(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("The operation has timed out. {0}", arg1);
            }
            static /*string */ get ReaderWriterLock_NotOwner()
            {
                return "Attempt to release a lock that is not owned by the calling thread. {0}";
            }
            static /*string */ FormatReaderWriterLock_NotOwner(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Attempt to release a lock that is not owned by the calling thread. {0}", arg1);
            }
            static /*string */ get ExceptionFromHResult()
            {
                return "(Exception from HRESULT: 0x{0:X})";
            }
            static /*string */ FormatExceptionFromHResult(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("(Exception from HRESULT: 0x{0:X})", arg1);
            }
            static /*string */ get ReaderWriterLock_InvalidLockCookie()
            {
                return "The specified lock cookie is invalid for this operation. {0}";
            }
            static /*string */ FormatReaderWriterLock_InvalidLockCookie(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("The specified lock cookie is invalid for this operation. {0}", arg1);
            }
            static /*string */ get ReaderWriterLock_RestoreLockWithOwnedLocks()
            {
                return "ReaderWriterLock.RestoreLock was called without releasing all locks acquired since the call to ReleaseLock.";
            }
            static /*string */ get HostExecutionContextManager_InvalidOperation_NotNewCaptureContext()
            {
                return "Cannot apply a context that has been marshaled across AppDomains, that was not acquired through a Capture operation or that has already been the argument to a Set call.";
            }
            static /*string */ get HostExecutionContextManager_InvalidOperation_CannotOverrideSetWithoutRevert()
            {
                return "Must override both HostExecutionContextManager.SetHostExecutionContext and HostExecutionContextManager.Revert.";
            }
            static /*string */ get HostExecutionContextManager_InvalidOperation_CannotUseSwitcherOtherThread()
            {
                return "Undo operation must be performed on the thread where the corresponding context was Set.";
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$st.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 258838;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":258838}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$st.System.Threading.HostExecutionContext", ($self) => class HostExecutionContext extends $.$$.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*object?*/ state)
            {
                super.$ctor();
                {
                    this.State = state;
                }
                return this;
            }
            /*object?*/ State = null;
            /*HostExecutionContext */ CreateCopy()
            {
                return new $.$st.System.Threading.HostExecutionContext().$ctor$2(this.State);
            }
            /*void */ Dispose()
            {
                this.Dispose$1(true);
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            static $h = 586518;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":131073,"g":{"r":0,"d":0,"h":21475422998,"f":50331664},"s":{"r":0,"d":0,"h":25770390294,"f":83886096},"n":"State","d":586518,"h":17180455702,"f":2097168}],"m":[{"r":586518,"n":"CreateCopy","d":586518,"h":30065357590,"f":16777345},{"r":65537,"n":"Dispose","d":586518,"h":34360324886,"f":16777217},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":586518,"h":38655292182,"f":16777345}],"c":[{"n":".ctor","o":"$ctor$1","d":586518,"h":4295553814,"f":16777217},{"p":[{"n":"state","p":131073}],"n":".ctor","o":"$ctor$2","d":586518,"h":8590521110,"f":16777217}],"i":[57540609],"h":586518}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.Threading.HostExecutionContext`; }
        });
        
        $asm.$cls("$st.System.Threading.CountdownEvent", ($self) => class CountdownEvent extends $.$$.System.Object
        {
            /*int*/ _initialCount = 0;
            /*int*/ _currentCount = 0;
            /*ManualResetEventSlim*/ _event = null;
            /*bool*/ _disposed = false;
            $ctor$1(/*int*/ initialCount)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, initialCount, "initialCount");
                    this._initialCount = initialCount;
                    this._currentCount = initialCount;
                    this._event = new $.$$.System.Threading.ManualResetEventSlim().$ctor$1();
                    if (initialCount === 0)
                    {
                        this._event.Set$1();
                    }
                }
                return this;
            }
            /*int */ get CurrentCount()
            {
                /*int*/ let observedCount = this._currentCount;
                return observedCount < 0 ? 0 : observedCount;
            }
            /*int */ get InitialCount()
            {
                return this._initialCount;
            }
            /*bool */ get IsSet()
            {
                return (this._currentCount <= 0);
            }
            /*WaitHandle */ get WaitHandle()
            {
                $.$$.System.ObjectDisposedException.ThrowIf(this._disposed, this);
                return this._event.WaitHandle;
            }
            /*void */ Dispose()
            {
                this.Dispose$1(true);
                $.$$.System.GC.SuppressFinalize(this);
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                if (disposing)
                {
                    this._event.Dispose();
                    this._disposed = true;
                }
            }
            /*bool */ Signal()
            {
                $.$$.System.ObjectDisposedException.ThrowIf(this._disposed, this);
                $.$$.System.Diagnostics.Debug.Assert$2(this._event !== null, "_event != null");
                if (this._currentCount <= 0)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$st.System.SR.CountdownEvent_Decrement_BelowZero);
                }
                /*int*/ let newCount = $.$$.System.Threading.Interlocked.Decrement($.$ref(() => this._currentCount, ($v) => this._currentCount = $v, $.$$.System.Int32));
                if (newCount === 0)
                {
                    this._event.Set$1();
                    return true;
                }
                else if (newCount < 0)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$st.System.SR.CountdownEvent_Decrement_BelowZero);
                }
                return false;
            }
            /*bool */ Signal$1(/*int*/ signalCount)
            {
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$$.System.Int32, signalCount, "signalCount");
                $.$$.System.ObjectDisposedException.ThrowIf(this._disposed, this);
                $.$$.System.Diagnostics.Debug.Assert$2(this._event !== null, "_event != null");
                /*int*/ let observedCount;
                /*SpinWait*/ let spin = new $.$$.System.Threading.SpinWait();
                while(true)
                {
                    observedCount = this._currentCount;
                    if (observedCount < signalCount)
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$st.System.SR.CountdownEvent_Decrement_BelowZero);
                    }
                    if ($.$$.System.Threading.Interlocked.CompareExchange$3($.$ref(() => this._currentCount, ($v) => this._currentCount = $v, $.$$.System.Int32), ((observedCount - signalCount) | 0), observedCount) === observedCount)
                    {
                        break;
                    }
                    spin.SpinOnce$1(-1);
                }
                if (observedCount === signalCount)
                {
                    this._event.Set$1();
                    return true;
                }
                $.$$.System.Diagnostics.Debug.Assert$2(this._currentCount >= 0, "latch was decremented below zero");
                return false;
            }
            /*void */ AddCount()
            {
                this.AddCount$1(1);
            }
            /*bool */ TryAddCount()
            {
                return this.TryAddCount$1(1);
            }
            /*void */ AddCount$1(/*int*/ signalCount)
            {
                if (!this.TryAddCount$1(signalCount))
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$st.System.SR.CountdownEvent_Increment_AlreadyZero);
                }
            }
            /*bool */ TryAddCount$1(/*int*/ signalCount)
            {
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$$.System.Int32, signalCount, "signalCount");
                $.$$.System.ObjectDisposedException.ThrowIf(this._disposed, this);
                /*int*/ let observedCount;
                /*SpinWait*/ let spin = new $.$$.System.Threading.SpinWait();
                while(true)
                {
                    observedCount = this._currentCount;
                    if (observedCount <= 0)
                    {
                        return false;
                    }
                    else if (observedCount > (((2147483647/*int.MaxValue*/ - signalCount) | 0)))
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$st.System.SR.CountdownEvent_Increment_AlreadyMax);
                    }
                    if ($.$$.System.Threading.Interlocked.CompareExchange$3($.$ref(() => this._currentCount, ($v) => this._currentCount = $v, $.$$.System.Int32), ((observedCount + signalCount) | 0), observedCount) === observedCount)
                    {
                        break;
                    }
                    spin.SpinOnce$1(-1);
                }
                return true;
            }
            /*void */ Reset()
            {
                this.Reset$1(this._initialCount);
            }
            /*void */ Reset$1(/*int*/ count)
            {
                $.$$.System.ObjectDisposedException.ThrowIf(this._disposed, this);
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, count, "count");
                this._currentCount = count;
                this._initialCount = count;
                if (count === 0)
                {
                    this._event.Set$1();
                }
                else 
                {
                    this._event.Reset();
                }
            }
            /*void */ Wait()
            {
                this.Wait$1(-1/*Timeout.Infinite*/, $.$$.System.Threading.CancellationToken.None);
            }
            /*void */ Wait$3(/*CancellationToken*/ cancellationToken)
            {
                this.Wait$1(-1/*Timeout.Infinite*/, cancellationToken);
            }
            /*bool */ Wait$5(/*TimeSpan*/ timeout)
            {
                /*long*/ let totalMilliseconds = $.$cast(timeout.TotalMilliseconds, $.$$.System.Int64);
                $.$$.System.ArgumentOutOfRangeException.ThrowIfLessThan($.$$.System.Int64, totalMilliseconds, BigInt(-1), "timeout");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$$.System.Int64, totalMilliseconds, BigInt(2147483647/*int.MaxValue*/), "timeout");
                return this.Wait$1($.$cast(totalMilliseconds, $.$$.System.Int32), $.$$.System.Threading.CancellationToken.None);
            }
            /*bool */ Wait$4(/*TimeSpan*/ timeout, /*CancellationToken*/ cancellationToken)
            {
                /*long*/ let totalMilliseconds = $.$cast(timeout.TotalMilliseconds, $.$$.System.Int64);
                $.$$.System.ArgumentOutOfRangeException.ThrowIfLessThan($.$$.System.Int64, totalMilliseconds, BigInt(-1), "timeout");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$$.System.Int64, totalMilliseconds, BigInt(2147483647/*int.MaxValue*/), "timeout");
                return this.Wait$1($.$cast(totalMilliseconds, $.$$.System.Int32), cancellationToken);
            }
            /*bool */ Wait$2(/*int*/ millisecondsTimeout)
            {
                return this.Wait$1(millisecondsTimeout, $.$$.System.Threading.CancellationToken.None);
            }
            /*bool */ Wait$1(/*int*/ millisecondsTimeout, /*CancellationToken*/ cancellationToken)
            {
                $.$$.System.ArgumentOutOfRangeException.ThrowIfLessThan($.$$.System.Int32, millisecondsTimeout, -1, "millisecondsTimeout");
                $.$$.System.ObjectDisposedException.ThrowIf(this._disposed, this);
                cancellationToken.ThrowIfCancellationRequested();
                /*bool*/ let returnValue = this._event.IsSet;
                if (!returnValue)
                {
                    returnValue = this._event.Wait$1(millisecondsTimeout, cancellationToken);
                }
                return returnValue;
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            static $h = 520982;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":30065292054,"f":50331649},"n":"CurrentCount","d":520982,"h":25770324758,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":38655226646,"f":50331649},"n":"InitialCount","d":520982,"h":34360259350,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":47245161238,"f":50331649},"n":"IsSet","d":520982,"h":42950193942,"f":2097153},{"p":139001857,"g":{"r":0,"d":0,"h":55835095830,"f":50331649},"n":"WaitHandle","d":520982,"h":51540128534,"f":2097153}],"m":[{"r":65537,"n":"Dispose","d":520982,"h":60130063126,"f":16777217},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":520982,"h":64425030422,"f":16777348},{"r":262145,"n":"Signal","d":520982,"h":68719997718,"f":16777217},{"r":262145,"p":[{"n":"signalCount","p":655361}],"n":"Signal","o":"@$1","d":520982,"h":73014965014,"f":16777217},{"r":65537,"n":"AddCount","d":520982,"h":77309932310,"f":16777217},{"r":262145,"n":"TryAddCount","d":520982,"h":81604899606,"f":16777217},{"r":65537,"p":[{"n":"signalCount","p":655361}],"n":"AddCount","o":"@$1","d":520982,"h":85899866902,"f":16777217},{"r":262145,"p":[{"n":"signalCount","p":655361}],"n":"TryAddCount","o":"@$1","d":520982,"h":90194834198,"f":16777217},{"r":65537,"n":"Reset","d":520982,"h":94489801494,"f":16777217},{"r":65537,"p":[{"n":"count","p":655361}],"n":"Reset","o":"@$1","d":520982,"h":98784768790,"f":16777217},{"r":65537,"n":"Wait","d":520982,"h":103079736086,"f":16777217,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"browser","t":1310721}]}]},{"r":65537,"p":[{"n":"cancellationToken","p":125829121}],"n":"Wait","o":"@$3","d":520982,"h":107374703382,"f":16777217,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"browser","t":1310721}]}]},{"r":262145,"p":[{"n":"timeout","p":140574721}],"n":"Wait","o":"@$5","d":520982,"h":111669670678,"f":16777217,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"browser","t":1310721}]}]},{"r":262145,"p":[{"n":"timeout","p":140574721},{"n":"cancellationToken","p":125829121}],"n":"Wait","o":"@$4","d":520982,"h":115964637974,"f":16777217,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"browser","t":1310721}]}]},{"r":262145,"p":[{"n":"millisecondsTimeout","p":655361}],"n":"Wait","o":"@$2","d":520982,"h":120259605270,"f":16777217,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"browser","t":1310721}]}]},{"r":262145,"p":[{"n":"millisecondsTimeout","p":655361},{"n":"cancellationToken","p":125829121}],"n":"Wait","o":"@$1","d":520982,"h":124554572566,"f":16777217,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"browser","t":1310721}]}]}],"l":[{"t":655361,"n":"_initialCount","d":520982,"h":4295488278,"f":4194306},{"t":655361,"n":"_currentCount","d":520982,"h":8590455574,"f":4194306},{"t":128253953,"n":"_event","d":520982,"h":12885422870,"f":4194306},{"t":262145,"n":"_disposed","d":520982,"h":17180390166,"f":4194306}],"c":[{"p":[{"n":"initialCount","p":655361}],"n":".ctor","o":"$ctor$1","d":520982,"h":21475357462,"f":16777217}],"i":[57540609],"h":520982,"a":[{"t":37617665,"c":8627552257,"a":[{"v":"InitialCount = {InitialCount}, CurrentCount = {CurrentCount}","t":1310721}]}]}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.Threading.CountdownEvent`; }
        });
        
        $asm.$cls("$st.System.Threading.Barrier", ($self) => class Barrier extends $.$$.System.Object
        {
            /*int*/ _currentTotalCount = 0;
            /*int*/ static CURRENT_MASK = 2147418112;
            /*int*/ static TOTAL_MASK = 32767;
            /*int*/ static SENSE_MASK = -2147483648;
            /*int*/ static MAX_PARTICIPANTS = 32767;
            /*long*/ _currentPhase = 0n;
            /*bool*/ _disposed = false;
            /*ManualResetEventSlim*/ _oddEvent = null;
            /*ManualResetEventSlim*/ _evenEvent = null;
            /*ExecutionContext?*/ _ownerThreadContext = null;
            /*ContextCallback?*/ static s_invokePostPhaseAction = null;
            /*Action<Barrier>?*/ _postPhaseAction = null;
            /*Exception?*/ _exception = null;
            /*int*/ _actionCallerID = 0;
            /*int */ get ParticipantsRemaining()
            {
                /*int*/ let currentTotal = this._currentTotalCount;
                /*int*/ let total = (currentTotal & 32767/*TOTAL_MASK*/);
                /*int*/ let current = ((currentTotal & 2147418112/*CURRENT_MASK*/) >> 16);
                return ((total - current) | 0);
            }
            /*int */ get ParticipantCount()
            {
                return (this._currentTotalCount & 32767/*TOTAL_MASK*/);
            }
            /*long */ get CurrentPhaseNumber()
            {
                return $.$ref(() => this._currentPhase, ($v) => this._currentPhase = $v, $.$$.System.Int64).$v;
            }
            /*long */ set CurrentPhaseNumber(value)
            {
                $.$ref(() => this._currentPhase, ($v) => this._currentPhase = $v, $.$$.System.Int64).$v = value;
            }
            $ctor$2(/*int*/ participantCount)
            {
                this.$ctor$1(participantCount, null);
                {
                }
                return this;
            }
            $ctor$1(/*int*/ participantCount, /*Action<Barrier>?*/ postPhaseAction)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, participantCount, "participantCount");
                    $.$$.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$$.System.Int32, participantCount, 32767/*MAX_PARTICIPANTS*/, "participantCount");
                    this._currentTotalCount = participantCount;
                    this._postPhaseAction = postPhaseAction;
                    this._oddEvent = new $.$$.System.Threading.ManualResetEventSlim().$ctor$3(true);
                    this._evenEvent = new $.$$.System.Threading.ManualResetEventSlim().$ctor$3(false);
                    if (!(postPhaseAction === null))
                    {
                        this._ownerThreadContext = $.$$.System.Threading.ExecutionContext.Capture();
                    }
                    this._actionCallerID = 0;
                }
                return this;
            }
            static /*void */ GetCurrentTotal(/*int*/ currentTotal, /*out int*/ current, /*out int*/ total, /*out bool*/ sense)
            {
                total.$v = (currentTotal & 32767/*TOTAL_MASK*/);
                current.$v = ((currentTotal & 2147418112/*CURRENT_MASK*/) >> 16);
                sense.$v = (currentTotal & -2147483648/*SENSE_MASK*/) === 0 ? true : false;
            }
            /*bool */ SetCurrentTotal(/*int*/ currentTotal, /*int*/ current, /*int*/ total, /*bool*/ sense)
            {
                /*int*/ let newCurrentTotal = (current << 16) | total;
                if (!sense)
                {
                    newCurrentTotal |= -2147483648/*SENSE_MASK*/;
                }
                return $.$$.System.Threading.Interlocked.CompareExchange$3($.$ref(() => this._currentTotalCount, ($v) => this._currentTotalCount = $v, $.$$.System.Int32), newCurrentTotal, currentTotal) === currentTotal;
            }
            /*long */ AddParticipant()
            {
                try
                {
                    return this.AddParticipants(1);
                }
                catch($e)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$st.System.SR.Barrier_AddParticipants_Overflow_ArgumentOutOfRange);
                }
            }
            /*long */ AddParticipants(/*int*/ participantCount)
            {
                $.$$.System.ObjectDisposedException.ThrowIf(this._disposed, this);
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$$.System.Int32, participantCount, "participantCount");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$$.System.Int32, participantCount, 32767/*MAX_PARTICIPANTS*/, "participantCount");
                if (this._actionCallerID !== 0 && $.$$.System.Environment.CurrentManagedThreadId === this._actionCallerID)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$st.System.SR.Barrier_InvalidOperation_CalledFromPHA);
                }
                /*SpinWait*/ let spinner = new $.$$.System.Threading.SpinWait();
                /*long*/ let newPhase;
                while(true)
                {
                    /*int*/ let currentTotal = this._currentTotalCount;
                    /*int*/ let total;
                    /*int*/ let current;
                    /*bool*/ let sense;
                    $.$st.System.Threading.Barrier.GetCurrentTotal(currentTotal, $.$ref(() => current, ($v) => current = $v, $.$$.System.Int32), $.$ref(() => total, ($v) => total = $v, $.$$.System.Int32), $.$ref(() => sense, ($v) => sense = $v, $.$$.System.Boolean));
                    if (((participantCount + total) | 0) > 32767/*MAX_PARTICIPANTS*/)
                    {
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$19("participantCount", $.$st.System.SR.Barrier_AddParticipants_Overflow_ArgumentOutOfRange);
                    }
                    if (this.SetCurrentTotal(currentTotal, current, ((total + participantCount) | 0), sense))
                    {
                        /*long*/ let currPhase = this.CurrentPhaseNumber;
                        newPhase = (sense !== (currPhase % 2n === 0n)) ? currPhase + 1n : currPhase;
                        if (newPhase !== currPhase)
                        {
                            if (sense)
                            {
                                this._oddEvent.Wait();
                            }
                            else 
                            {
                                this._evenEvent.Wait();
                            }
                        }
                        else 
                        {
                            if (sense && this._evenEvent.IsSet)
                            {
                                this._evenEvent.Reset();
                            }
                            else if (!sense && this._oddEvent.IsSet)
                            {
                                this._oddEvent.Reset();
                            }
                        }
                        break;
                    }
                    spinner.SpinOnce$1(-1);
                }
                return newPhase;
            }
            /*void */ RemoveParticipant()
            {
                this.RemoveParticipants(1);
            }
            /*void */ RemoveParticipants(/*int*/ participantCount)
            {
                $.$$.System.ObjectDisposedException.ThrowIf(this._disposed, this);
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$$.System.Int32, participantCount, "participantCount");
                if (this._actionCallerID !== 0 && $.$$.System.Environment.CurrentManagedThreadId === this._actionCallerID)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$st.System.SR.Barrier_InvalidOperation_CalledFromPHA);
                }
                /*SpinWait*/ let spinner = new $.$$.System.Threading.SpinWait();
                while(true)
                {
                    /*int*/ let currentTotal = this._currentTotalCount;
                    /*int*/ let total;
                    /*int*/ let current;
                    /*bool*/ let sense;
                    $.$st.System.Threading.Barrier.GetCurrentTotal(currentTotal, $.$ref(() => current, ($v) => current = $v, $.$$.System.Int32), $.$ref(() => total, ($v) => total = $v, $.$$.System.Int32), $.$ref(() => sense, ($v) => sense = $v, $.$$.System.Boolean));
                    if (total < participantCount)
                    {
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$19("participantCount", $.$st.System.SR.Barrier_RemoveParticipants_ArgumentOutOfRange);
                    }
                    if (((total - participantCount) | 0) < current)
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$st.System.SR.Barrier_RemoveParticipants_InvalidOperation);
                    }
                    /*int*/ let remaingParticipants = ((total - participantCount) | 0);
                    if (remaingParticipants > 0 && current === remaingParticipants)
                    {
                        if (this.SetCurrentTotal(currentTotal, 0, ((total - participantCount) | 0), !sense))
                        {
                            this.FinishPhase(sense);
                            break;
                        }
                    }
                    else 
                    {
                        if (this.SetCurrentTotal(currentTotal, current, ((total - participantCount) | 0), sense))
                        {
                            break;
                        }
                    }
                    spinner.SpinOnce$1(-1);
                }
            }
            /*void */ SignalAndWait()
            {
                this.SignalAndWait$3($.$$.System.Threading.CancellationToken.None);
            }
            /*void */ SignalAndWait$3(/*CancellationToken*/ cancellationToken)
            {
                /*bool*/ let result = this.SignalAndWait$1(-1/*Timeout.Infinite*/, cancellationToken);
                $.$$.System.Diagnostics.Debug.Assert$2(result, "result");
            }
            /*bool */ SignalAndWait$5(/*TimeSpan*/ timeout)
            {
                return this.SignalAndWait$4(timeout, $.$$.System.Threading.CancellationToken.None);
            }
            /*bool */ SignalAndWait$4(/*TimeSpan*/ timeout, /*CancellationToken*/ cancellationToken)
            {
                /*long*/ let totalMilliseconds = $.$cast(timeout.TotalMilliseconds, $.$$.System.Int64);
                if (totalMilliseconds < BigInt(-1) || totalMilliseconds > BigInt(2147483647/*int.MaxValue*/))
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$18("timeout", timeout, $.$st.System.SR.Barrier_SignalAndWait_ArgumentOutOfRange);
                }
                return this.SignalAndWait$1($.$cast(timeout.TotalMilliseconds, $.$$.System.Int32), cancellationToken);
            }
            /*bool */ SignalAndWait$2(/*int*/ millisecondsTimeout)
            {
                return this.SignalAndWait$1(millisecondsTimeout, $.$$.System.Threading.CancellationToken.None);
            }
            /*bool */ SignalAndWait$1(/*int*/ millisecondsTimeout, /*CancellationToken*/ cancellationToken)
            {
                $.$$.System.ObjectDisposedException.ThrowIf(this._disposed, this);
                cancellationToken.ThrowIfCancellationRequested();
                if (millisecondsTimeout < -1)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$18("millisecondsTimeout", $.$box(millisecondsTimeout, $.$$.System.Int32), $.$st.System.SR.Barrier_SignalAndWait_ArgumentOutOfRange);
                }
                if (this._actionCallerID !== 0 && $.$$.System.Environment.CurrentManagedThreadId === this._actionCallerID)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$st.System.SR.Barrier_InvalidOperation_CalledFromPHA);
                }
                /*bool*/ let sense;
                /*int*/ let total;
                /*int*/ let current;
                /*int*/ let currentTotal;
                /*long*/ let phase;
                /*SpinWait*/ let spinner = new $.$$.System.Threading.SpinWait();
                while(true)
                {
                    currentTotal = this._currentTotalCount;
                    $.$st.System.Threading.Barrier.GetCurrentTotal(currentTotal, $.$ref(() => current, ($v) => current = $v, $.$$.System.Int32), $.$ref(() => total, ($v) => total = $v, $.$$.System.Int32), $.$ref(() => sense, ($v) => sense = $v, $.$$.System.Boolean));
                    phase = this.CurrentPhaseNumber;
                    if (total === 0)
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$st.System.SR.Barrier_SignalAndWait_InvalidOperation_ZeroTotal);
                    }
                    if (current === 0 && sense !== (this.CurrentPhaseNumber % 2n === 0n))
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$st.System.SR.Barrier_SignalAndWait_InvalidOperation_ThreadsExceeded);
                    }
                    if (((current + 1) | 0) === total)
                    {
                        if (this.SetCurrentTotal(currentTotal, 0, total, !sense))
                        {
                            if ($.$st.System.Threading.CdsSyncEtwBCLProvider.Log.IsEnabled())
                            {
                                $.$st.System.Threading.CdsSyncEtwBCLProvider.Log.Barrier_PhaseFinished(sense, this.CurrentPhaseNumber);
                            }
                            this.FinishPhase(sense);
                            return true;
                        }
                    }
                    else if (this.SetCurrentTotal(currentTotal, ((current + 1) | 0), total, sense))
                    {
                        break;
                    }
                    spinner.SpinOnce$1(-1);
                }
                /*ManualResetEventSlim*/ let eventToWaitOn = (sense) ? this._evenEvent : this._oddEvent;
                /*bool*/ let waitWasCanceled = false;
                /*bool*/ let waitResult = false;
                try
                {
                    waitResult = this.DiscontinuousWait(eventToWaitOn, millisecondsTimeout, cancellationToken, phase);
                }
                catch($e)
                {
                    if ($e instanceof $.$$.System.OperationCanceledException)
                    {
                        waitWasCanceled = true;
                    }
                    else if ($e instanceof $.$$.System.ObjectDisposedException)
                    {
                        if (phase < this.CurrentPhaseNumber)
                        {
                            waitResult = true;
                        }
                        else 
                        {
                            throw $e;
                        }
                    }
                    else
                    {
                        throw $e;
                    }
                }
                if (!waitResult)
                {
                    spinner.Reset();
                    while(true)
                    {
                        /*bool*/ let newSense;
                        currentTotal = this._currentTotalCount;
                        $.$st.System.Threading.Barrier.GetCurrentTotal(currentTotal, $.$ref(() => current, ($v) => current = $v, $.$$.System.Int32), $.$ref(() => total, ($v) => total = $v, $.$$.System.Int32), $.$ref(() => newSense, ($v) => newSense = $v, $.$$.System.Boolean));
                        if (phase < this.CurrentPhaseNumber || sense !== newSense)
                        {
                            this.WaitCurrentPhase(eventToWaitOn, phase);
                            $.$$.System.Diagnostics.Debug.Assert$2(phase < this.CurrentPhaseNumber, "phase < CurrentPhaseNumber");
                            break;
                        }
                        if (this.SetCurrentTotal(currentTotal, ((current - 1) | 0), total, sense))
                        {
                            if (waitWasCanceled)
                            {
                                throw new $.$$.System.OperationCanceledException().$ctor$13($.$st.System.SR.Common_OperationCanceled, cancellationToken);
                            }
                            else 
                            {
                                return false;
                            }
                        }
                        spinner.SpinOnce$1(-1);
                    }
                }
                if (!(this._exception === null))
                {
                    throw new $.$st.System.Threading.BarrierPostPhaseException().$ctor$6(this._exception);
                }
                return true;
            }
            /*void */ FinishPhase(/*bool*/ observedSense)
            {
                if (!(this._postPhaseAction === null))
                {
                    try
                    {
                        this._actionCallerID = $.$$.System.Environment.CurrentManagedThreadId;
                        if (!(this._ownerThreadContext === null))
                        {
                            /*ContextCallback?*/ let handler = $.$st.System.Threading.Barrier.s_invokePostPhaseAction ??= new $.$$.System.Threading.ContextCallback().$ctor($.$st.System.Threading.Barrier, $.$st.System.Threading.Barrier.InvokePostPhaseAction);
                            $.$$.System.Threading.ExecutionContext.Run(this._ownerThreadContext, handler, this);
                        }
                        else 
                        {
                            this._postPhaseAction.Invoke(this);
                        }
                        this._exception = null;
                    }
                    catch(ex)
                    {
                        this._exception = ex;
                    }
                    finally
                    {
                        {
                            this._actionCallerID = 0;
                            this.SetResetEvents(observedSense);
                            if (!(this._exception === null))
                            {
                                throw new $.$st.System.Threading.BarrierPostPhaseException().$ctor$6(this._exception);
                            }
                        }
                    }
                }
                else 
                {
                    this.SetResetEvents(observedSense);
                }
            }
            static /*void */ InvokePostPhaseAction(/*object?*/ obj)
            {
                /*var*/ let thisBarrier = $.$cast(obj, $.$st.System.Threading.Barrier);
                thisBarrier._postPhaseAction.Invoke(thisBarrier);
            }
            /*void */ SetResetEvents(/*bool*/ observedSense)
            {
                this.CurrentPhaseNumber++;
                if (observedSense)
                {
                    this._oddEvent.Reset();
                    this._evenEvent.Set$1();
                }
                else 
                {
                    this._evenEvent.Reset();
                    this._oddEvent.Set$1();
                }
            }
            /*void */ WaitCurrentPhase(/*ManualResetEventSlim*/ currentPhaseEvent, /*long*/ observedPhase)
            {
                /*SpinWait*/ let spinner = new $.$$.System.Threading.SpinWait();
                while(!currentPhaseEvent.IsSet && this.CurrentPhaseNumber - observedPhase <= 1n)
                {
                    spinner.SpinOnce();
                }
            }
            /*bool */ DiscontinuousWait(/*ManualResetEventSlim*/ currentPhaseEvent, /*int*/ totalTimeout, /*CancellationToken*/ token, /*long*/ observedPhase)
            {
                /*int*/ let maxWait = 100;
                /*int*/ let waitTimeCeiling = 10000;
                while(observedPhase === this.CurrentPhaseNumber)
                {
                    /*int*/ let waitTime = totalTimeout === -1/*Timeout.Infinite*/ ? maxWait : $.$$.System.Math.Min$4(maxWait, totalTimeout);
                    if (currentPhaseEvent.Wait$1(waitTime, token))
                    {
                        return true;
                    }
                    if (totalTimeout !== -1/*Timeout.Infinite*/)
                    {
                        totalTimeout -= waitTime;
                        if (totalTimeout <= 0)
                        {
                            return false;
                        }
                    }
                    maxWait = maxWait >= waitTimeCeiling ? waitTimeCeiling : $.$$.System.Math.Min$4(maxWait << 1, waitTimeCeiling);
                }
                this.WaitCurrentPhase(currentPhaseEvent, observedPhase);
                return true;
            }
            /*void */ Dispose()
            {
                if (this._actionCallerID !== 0 && $.$$.System.Environment.CurrentManagedThreadId === this._actionCallerID)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$st.System.SR.Barrier_InvalidOperation_CalledFromPHA);
                }
                this.Dispose$1(true);
                $.$$.System.GC.SuppressFinalize(this);
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                if (!this._disposed)
                {
                    if (disposing)
                    {
                        this._oddEvent.Dispose();
                        this._evenEvent.Dispose();
                    }
                    this._disposed = true;
                }
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            static $h = 324374;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":68719801110,"f":50331649},"n":"ParticipantsRemaining","d":324374,"h":64424833814,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":77309735702,"f":50331649},"n":"ParticipantCount","d":324374,"h":73014768406,"f":2097153},{"p":917505,"g":{"r":0,"d":0,"h":85899670294,"f":50331649},"s":{"r":0,"d":0,"h":90194637590,"f":83886088},"n":"CurrentPhaseNumber","d":324374,"h":81604702998,"f":2097153}],"m":[{"r":65537,"p":[{"n":"currentTotal","p":655361},{"n":"current","p":655361,"f":2},{"n":"total","p":655361,"f":2},{"n":"sense","p":262145,"f":2}],"n":"GetCurrentTotal","d":324374,"h":103079539478,"f":16777250},{"r":262145,"p":[{"n":"currentTotal","p":655361},{"n":"current","p":655361},{"n":"total","p":655361},{"n":"sense","p":262145}],"n":"SetCurrentTotal","d":324374,"h":107374506774,"f":16777218},{"r":917505,"n":"AddParticipant","d":324374,"h":111669474070,"f":16777217,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"browser","t":1310721}]}]},{"r":917505,"p":[{"n":"participantCount","p":655361}],"n":"AddParticipants","d":324374,"h":115964441366,"f":16777217,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"browser","t":1310721}]}]},{"r":65537,"n":"RemoveParticipant","d":324374,"h":120259408662,"f":16777217},{"r":65537,"p":[{"n":"participantCount","p":655361}],"n":"RemoveParticipants","d":324374,"h":124554375958,"f":16777217},{"r":65537,"n":"SignalAndWait","d":324374,"h":128849343254,"f":16777217,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"browser","t":1310721}]}]},{"r":65537,"p":[{"n":"cancellationToken","p":125829121}],"n":"SignalAndWait","o":"@$3","d":324374,"h":133144310550,"f":16777217,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"browser","t":1310721}]}]},{"r":262145,"p":[{"n":"timeout","p":140574721}],"n":"SignalAndWait","o":"@$5","d":324374,"h":137439277846,"f":16777217,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"browser","t":1310721}]}]},{"r":262145,"p":[{"n":"timeout","p":140574721},{"n":"cancellationToken","p":125829121}],"n":"SignalAndWait","o":"@$4","d":324374,"h":141734245142,"f":16777217,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"browser","t":1310721}]}]},{"r":262145,"p":[{"n":"millisecondsTimeout","p":655361}],"n":"SignalAndWait","o":"@$2","d":324374,"h":146029212438,"f":16777217,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"browser","t":1310721}]}]},{"r":262145,"p":[{"n":"millisecondsTimeout","p":655361},{"n":"cancellationToken","p":125829121}],"n":"SignalAndWait","o":"@$1","d":324374,"h":150324179734,"f":16777217,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"browser","t":1310721}]}]},{"r":65537,"p":[{"n":"observedSense","p":262145}],"n":"FinishPhase","d":324374,"h":154619147030,"f":16777218},{"r":65537,"p":[{"n":"obj","p":131073}],"n":"InvokePostPhaseAction","d":324374,"h":158914114326,"f":16777250},{"r":65537,"p":[{"n":"observedSense","p":262145}],"n":"SetResetEvents","d":324374,"h":163209081622,"f":16777218},{"r":65537,"p":[{"n":"currentPhaseEvent","p":128253953},{"n":"observedPhase","p":917505}],"n":"WaitCurrentPhase","d":324374,"h":167504048918,"f":16777218},{"r":262145,"p":[{"n":"currentPhaseEvent","p":128253953},{"n":"totalTimeout","p":655361},{"n":"token","p":125829121},{"n":"observedPhase","p":917505}],"n":"DiscontinuousWait","d":324374,"h":171799016214,"f":16777218,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"browser","t":1310721}]}]},{"r":65537,"n":"Dispose","d":324374,"h":176093983510,"f":16777217},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":324374,"h":180388950806,"f":16777348}],"l":[{"t":655361,"n":"_currentTotalCount","d":324374,"h":4295291670,"f":4194306},{"t":655361,"n":"CURRENT_MASK","d":324374,"h":8590258966,"f":4194338},{"t":655361,"n":"TOTAL_MASK","d":324374,"h":12885226262,"f":4194338},{"t":655361,"n":"SENSE_MASK","d":324374,"h":17180193558,"f":4194338},{"t":655361,"n":"MAX_PARTICIPANTS","d":324374,"h":21475160854,"f":4194338},{"t":917505,"n":"_currentPhase","d":324374,"h":25770128150,"f":4194306},{"t":262145,"n":"_disposed","d":324374,"h":30065095446,"f":4194306},{"t":128253953,"n":"_oddEvent","d":324374,"h":34360062742,"f":4194306},{"t":128253953,"n":"_evenEvent","d":324374,"h":38655030038,"f":4194306},{"t":126812161,"n":"_ownerThreadContext","d":324374,"h":42949997334,"f":4194306},{"t":126484481,"n":"s_invokePostPhaseAction","d":324374,"h":47244964630,"f":4194338},{"t":$.$$.System.Action$$($.$st.System.Threading.Barrier).$h,"n":"_postPhaseAction","d":324374,"h":51539931926,"f":4194306},{"t":47251457,"n":"_exception","d":324374,"h":55834899222,"f":4194306},{"t":655361,"n":"_actionCallerID","d":324374,"h":60129866518,"f":4194306}],"c":[{"p":[{"n":"participantCount","p":655361}],"n":".ctor","o":"$ctor$2","d":324374,"h":94489604886,"f":16777217},{"p":[{"n":"participantCount","p":655361},{"n":"postPhaseAction","p":$.$$.System.Action$$($.$st.System.Threading.Barrier).$h}],"n":".ctor","o":"$ctor$1","d":324374,"h":98784572182,"f":16777217}],"i":[57540609],"h":324374,"a":[{"t":37617665,"c":8627552257,"a":[{"v":"ParticipantCount = {ParticipantCount}, ParticipantsRemaining = {ParticipantsRemaining}","t":1310721}]}]}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.Threading.Barrier`; }
        });
        
        $asm.$cls("$st.System.Threading.ReaderWriterLock", ($self) => class ReaderWriterLock extends $.$$.System.Runtime.ConstrainedExecution.CriticalFinalizerObject
        {
            /*int*/ static InvalidThreadID = -1;
            /*ushort*/ static MaxAcquireCount = 65535;
            /*int*/ static DefaultSpinCount = 0;
            /*int*/ static IncorrectButCompatibleNotOwnerExceptionHResult = 288;
            /*long*/ static s_mostRecentLockID = 0n;
            /*ManualResetEventSlim?*/ _readerEvent = null;
            /*AutoResetEvent?*/ _writerEvent = null;
            /*long*/ _lockID = 0n;
            /*int*/ _state = 0;
            /*int*/ _writerID = -1;
            /*int*/ _writerSeqNum = 1;
            /*ushort*/ _writerLevel = 0;
            $ctor$2()
            {
                super.$ctor$1();
                {
                    this._lockID = $.$$.System.Threading.Interlocked.Increment$1($.$ref(() => $.$st.System.Threading.ReaderWriterLock.s_mostRecentLockID, ($v) => $.$st.System.Threading.ReaderWriterLock.s_mostRecentLockID = $v, $.$$.System.Int64));
                }
                return this;
            }
            /*bool */ get IsReaderLockHeld()
            {
                /*ThreadLocalLockEntry?*/ let threadLocalLockEntry = $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.GetCurrent(this._lockID);
                if (threadLocalLockEntry !== null)
                {
                    return threadLocalLockEntry._readerLevel > 0;
                }
                return false;
            }
            /*bool */ get IsWriterLockHeld()
            {
                return this._writerID === $.$st.System.Threading.ReaderWriterLock.GetCurrentThreadID();
            }
            /*int */ get WriterSeqNum()
            {
                return this._writerSeqNum;
            }
            /*bool */ AnyWritersSince(/*int*/ seqNum)
            {
                if (this._writerID === $.$st.System.Threading.ReaderWriterLock.GetCurrentThreadID())
                {
                    ++seqNum;
                }
                return (this._writerSeqNum >>> 0) > (seqNum >>> 0);
            }
            /*void */ AcquireReaderLock(/*int*/ millisecondsTimeout)
            {
                $.$$.System.ArgumentOutOfRangeException.ThrowIfLessThan($.$$.System.Int32, millisecondsTimeout, -1, "millisecondsTimeout");
                /*ThreadLocalLockEntry*/ let threadLocalLockEntry = $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.GetOrCreateCurrent(this._lockID);
                if ($.$$.System.Threading.Interlocked.CompareExchange$3($.$ref(() => this._state, ($v) => this._state = $v, $.$$.System.Int32), 1/*LockStates.Reader*/, 0) === 0)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(threadLocalLockEntry._readerLevel === 0, "threadLocalLockEntry._readerLevel == 0");
                }
                else if (threadLocalLockEntry._readerLevel > 0)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2((this._state & 1023/*LockStates.ReadersMask*/) !== 0, "(_state & LockStates.ReadersMask) != 0");
                    if (threadLocalLockEntry._readerLevel === 65535/*MaxAcquireCount*/)
                    {
                        throw new $.$$.System.OverflowException().$ctor$16($.$st.System.SR.Overflow_UInt16);
                    }
                    ++threadLocalLockEntry._readerLevel;
                    return;
                }
                else if (this._writerID === $.$st.System.Threading.ReaderWriterLock.GetCurrentThreadID())
                {
                    this.AcquireWriterLock(millisecondsTimeout);
                    $.$$.System.Diagnostics.Debug.Assert$2(threadLocalLockEntry.IsFree, "threadLocalLockEntry.IsFree");
                    return;
                }
                else 
                {
                    /*int*/ let spinCount = 0;
                    /*int*/ let currentState = this._state;
                    do
                    {
                        /*int*/ let knownState = currentState;
                        if (knownState < 1023/*LockStates.ReadersMask*/ || ((knownState & 1024/*LockStates.ReaderSignaled*/) !== 0 && (knownState & 4096/*LockStates.Writer*/) === 0 && (((((knownState & 1023/*LockStates.ReadersMask*/) + ((knownState & 8380416/*LockStates.WaitingReadersMask*/) >> 13/*LockStates.WaitingReadersShift*/)) | 0)) <= ((1023/*LockStates.ReadersMask*/ - 2) | 0))))
                        {
                            currentState = $.$$.System.Threading.Interlocked.CompareExchange$3($.$ref(() => this._state, ($v) => this._state = $v, $.$$.System.Int32), ((knownState + 1/*LockStates.Reader*/) | 0), knownState);
                            if (currentState === knownState)
                            {
                                break;
                            }
                            continue;
                        }
                        if ((knownState & 1023/*LockStates.ReadersMask*/) === 1023/*LockStates.ReadersMask*/ || (knownState & 8380416/*LockStates.WaitingReadersMask*/) === 8380416/*LockStates.WaitingReadersMask*/ || (knownState & 3072/*LockStates.CachingEvents*/) === 1024/*LockStates.ReaderSignaled*/)
                        {
                            /*int*/ let sleepDurationMilliseconds = 100;
                            if ((knownState & 1023/*LockStates.ReadersMask*/) === 1023/*LockStates.ReadersMask*/ || (knownState & 8380416/*LockStates.WaitingReadersMask*/) === 8380416/*LockStates.WaitingReadersMask*/)
                            {
                                sleepDurationMilliseconds = 1000;
                            }
                            $.$$.System.Threading.Thread.Sleep(sleepDurationMilliseconds);
                            spinCount = 0;
                            currentState = this._state;
                            continue;
                        }
                        ++spinCount;
                        if ((knownState & 3072/*LockStates.CachingEvents*/) === 3072/*LockStates.CachingEvents*/)
                        {
                            if (spinCount > $.$st.System.Threading.ReaderWriterLock.DefaultSpinCount)
                            {
                                $.$$.System.Threading.Thread.Sleep(1);
                                spinCount = 0;
                            }
                            currentState = this._state;
                            continue;
                        }
                        if (spinCount <= $.$st.System.Threading.ReaderWriterLock.DefaultSpinCount)
                        {
                            currentState = this._state;
                            continue;
                        }
                        currentState = $.$$.System.Threading.Interlocked.CompareExchange$3($.$ref(() => this._state, ($v) => this._state = $v, $.$$.System.Int32), ((knownState + 8192/*LockStates.WaitingReader*/) | 0), knownState);
                        if (currentState !== knownState)
                        {
                            continue;
                        }
                        /*int*/ let modifyState = -8192/*LockStates.WaitingReader*/;
                        /*ManualResetEventSlim?*/ let readerEvent = null;
                        /*bool*/ let waitSucceeded = false;
                        try
                        {
                            readerEvent = this.GetOrCreateReaderEvent();
                            waitSucceeded = readerEvent.Wait$2(millisecondsTimeout);
                            $.$$.System.Diagnostics.Debug.Assert$2(threadLocalLockEntry.HasLockID(this._lockID), "threadLocalLockEntry.HasLockID(_lockID)");
                            if (waitSucceeded)
                            {
                                $.$$.System.Diagnostics.Debug.Assert$2((this._state & 1024/*LockStates.ReaderSignaled*/) !== 0, "(_state & LockStates.ReaderSignaled) != 0");
                                $.$$.System.Diagnostics.Debug.Assert$2((this._state & 1023/*LockStates.ReadersMask*/) < 1023/*LockStates.ReadersMask*/, "(_state & LockStates.ReadersMask) < LockStates.ReadersMask");
                                modifyState += 1/*LockStates.Reader*/;
                            }
                        }
                        finally
                        {
                            {
                                knownState = (($.$$.System.Threading.Interlocked.Add($.$ref(() => this._state, ($v) => this._state = $v, $.$$.System.Int32), modifyState) - modifyState) | 0);
                                if (!waitSucceeded)
                                {
                                    if ((knownState & 1024/*LockStates.ReaderSignaled*/) !== 0 && (knownState & 8380416/*LockStates.WaitingReadersMask*/) === 8192/*LockStates.WaitingReader*/)
                                    {
                                        if (readerEvent === null)
                                        {
                                            readerEvent = this._readerEvent;
                                            $.$$.System.Diagnostics.Debug.Assert$2(readerEvent !== null, "readerEvent != null");
                                        }
                                        readerEvent.Wait();
                                        $.$$.System.Diagnostics.Debug.Assert$2((this._state & 1023/*LockStates.ReadersMask*/) < 1023/*LockStates.ReadersMask*/, "(_state & LockStates.ReadersMask) < LockStates.ReadersMask");
                                        readerEvent.Reset();
                                        $.$$.System.Threading.Interlocked.Add($.$ref(() => this._state, ($v) => this._state = $v, $.$$.System.Int32), ((1/*LockStates.Reader*/ - 1024/*LockStates.ReaderSignaled*/) | 0));
                                        ++threadLocalLockEntry._readerLevel;
                                        this.ReleaseReaderLock();
                                    }
                                    $.$$.System.Diagnostics.Debug.Assert$2(threadLocalLockEntry.IsFree, "threadLocalLockEntry.IsFree");
                                }
                            }
                        }
                        if (!waitSucceeded)
                        {
                            throw $.$st.System.Threading.ReaderWriterLock.GetTimeoutException();
                        }
                        $.$$.System.Diagnostics.Debug.Assert$2((knownState & 1024/*LockStates.ReaderSignaled*/) !== 0, "(knownState & LockStates.ReaderSignaled) != 0");
                        $.$$.System.Diagnostics.Debug.Assert$2((knownState & 1023/*LockStates.ReadersMask*/) < 1023/*LockStates.ReadersMask*/, "(knownState & LockStates.ReadersMask) < LockStates.ReadersMask");
                        if ((knownState & 8380416/*LockStates.WaitingReadersMask*/) === 8192/*LockStates.WaitingReader*/)
                        {
                            readerEvent.Reset();
                            $.$$.System.Threading.Interlocked.Add($.$ref(() => this._state, ($v) => this._state = $v, $.$$.System.Int32), -1024/*LockStates.ReaderSignaled*/);
                        }
                        break;
                    }
                    while($.$st.System.Threading.ReaderWriterLock.YieldProcessor());
                }
                $.$$.System.Diagnostics.Debug.Assert$2((this._state & 4096/*LockStates.Writer*/) === 0, "(_state & LockStates.Writer) == 0");
                $.$$.System.Diagnostics.Debug.Assert$2((this._state & 1023/*LockStates.ReadersMask*/) !== 0, "(_state & LockStates.ReadersMask) != 0");
                ++threadLocalLockEntry._readerLevel;
            }
            /*void */ AcquireReaderLock$1(/*TimeSpan*/ timeout)
            {
                return this.AcquireReaderLock($.$st.System.Threading.ReaderWriterLock.ToTimeoutMilliseconds(timeout));
            }
            /*void */ AcquireWriterLock(/*int*/ millisecondsTimeout)
            {
                $.$$.System.ArgumentOutOfRangeException.ThrowIfLessThan($.$$.System.Int32, millisecondsTimeout, -1, "millisecondsTimeout");
                /*int*/ let threadID = $.$st.System.Threading.ReaderWriterLock.GetCurrentThreadID();
                if ($.$$.System.Threading.Interlocked.CompareExchange$3($.$ref(() => this._state, ($v) => this._state = $v, $.$$.System.Int32), 4096/*LockStates.Writer*/, 0) === 0)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2((this._state & 1023/*LockStates.ReadersMask*/) === 0, "(_state & LockStates.ReadersMask) == 0");
                }
                else if (this._writerID === threadID)
                {
                    if (this._writerLevel === 65535/*MaxAcquireCount*/)
                    {
                        throw new $.$$.System.OverflowException().$ctor$16($.$st.System.SR.Overflow_UInt16);
                    }
                    ++this._writerLevel;
                    return;
                }
                else 
                {
                    /*int*/ let spinCount = 0;
                    /*int*/ let currentState = this._state;
                    do
                    {
                        /*int*/ let knownState = currentState;
                        if (knownState === 0 || knownState === 3072/*LockStates.CachingEvents*/)
                        {
                            currentState = $.$$.System.Threading.Interlocked.CompareExchange$3($.$ref(() => this._state, ($v) => this._state = $v, $.$$.System.Int32), ((knownState + 4096/*LockStates.Writer*/) | 0), knownState);
                            if (currentState === knownState)
                            {
                                break;
                            }
                            continue;
                        }
                        if ((knownState & -8388608/*LockStates.WaitingWritersMask*/) === -8388608/*LockStates.WaitingWritersMask*/)
                        {
                            $.$$.System.Threading.Thread.Sleep(1000);
                            spinCount = 0;
                            currentState = this._state;
                            continue;
                        }
                        ++spinCount;
                        if ((knownState & 3072/*LockStates.CachingEvents*/) === 3072/*LockStates.CachingEvents*/)
                        {
                            if (spinCount > $.$st.System.Threading.ReaderWriterLock.DefaultSpinCount)
                            {
                                $.$$.System.Threading.Thread.Sleep(1);
                                spinCount = 0;
                            }
                            currentState = this._state;
                            continue;
                        }
                        if (spinCount <= $.$st.System.Threading.ReaderWriterLock.DefaultSpinCount)
                        {
                            currentState = this._state;
                            continue;
                        }
                        currentState = $.$$.System.Threading.Interlocked.CompareExchange$3($.$ref(() => this._state, ($v) => this._state = $v, $.$$.System.Int32), ((knownState + 8388608/*LockStates.WaitingWriter*/) | 0), knownState);
                        if (currentState !== knownState)
                        {
                            continue;
                        }
                        /*int*/ let modifyState = -8388608/*LockStates.WaitingWriter*/;
                        /*AutoResetEvent?*/ let writerEvent = null;
                        /*bool*/ let waitSucceeded = false;
                        try
                        {
                            writerEvent = this.GetOrCreateWriterEvent();
                            waitSucceeded = writerEvent.WaitOne$2(millisecondsTimeout);
                            if (waitSucceeded)
                            {
                                $.$$.System.Diagnostics.Debug.Assert$2((this._state & 2048/*LockStates.WriterSignaled*/) !== 0, "(_state & LockStates.WriterSignaled) != 0");
                                modifyState += ((4096/*LockStates.Writer*/ - 2048/*LockStates.WriterSignaled*/) | 0);
                            }
                        }
                        finally
                        {
                            {
                                knownState = (($.$$.System.Threading.Interlocked.Add($.$ref(() => this._state, ($v) => this._state = $v, $.$$.System.Int32), modifyState) - modifyState) | 0);
                                if (!waitSucceeded && (knownState & 2048/*LockStates.WriterSignaled*/) !== 0 && (knownState & -8388608/*LockStates.WaitingWritersMask*/) === 8388608/*LockStates.WaitingWriter*/)
                                {
                                    if (writerEvent === null)
                                    {
                                        writerEvent = this._writerEvent;
                                        $.$$.System.Diagnostics.Debug.Assert$2(writerEvent !== null, "writerEvent != null");
                                    }
                                    while(true)
                                    {
                                        knownState = this._state;
                                        if ((knownState & 2048/*LockStates.WriterSignaled*/) === 0 || (knownState & -8388608/*LockStates.WaitingWritersMask*/) !== 0)
                                        {
                                            break;
                                        }
                                        if (!writerEvent.WaitOne$2(10))
                                        {
                                            continue;
                                        }
                                        modifyState = ((4096/*LockStates.Writer*/ - 2048/*LockStates.WriterSignaled*/) | 0);
                                        knownState = (($.$$.System.Threading.Interlocked.Add($.$ref(() => this._state, ($v) => this._state = $v, $.$$.System.Int32), modifyState) - modifyState) | 0);
                                        $.$$.System.Diagnostics.Debug.Assert$2((knownState & 2048/*LockStates.WriterSignaled*/) !== 0, "(knownState & LockStates.WriterSignaled) != 0");
                                        $.$$.System.Diagnostics.Debug.Assert$2((knownState & 4096/*LockStates.Writer*/) === 0, "(knownState & LockStates.Writer) == 0");
                                        this._writerID = threadID;
                                        $.$$.System.Diagnostics.Debug.Assert$2(this._writerLevel === 0, "_writerLevel == 0");
                                        this._writerLevel = 1;
                                        this.ReleaseWriterLock();
                                        break;
                                    }
                                }
                            }
                        }
                        if (!waitSucceeded)
                        {
                            throw $.$st.System.Threading.ReaderWriterLock.GetTimeoutException();
                        }
                        break;
                    }
                    while($.$st.System.Threading.ReaderWriterLock.YieldProcessor());
                }
                $.$$.System.Diagnostics.Debug.Assert$2((this._state & 4096/*LockStates.Writer*/) !== 0, "(_state & LockStates.Writer) != 0");
                $.$$.System.Diagnostics.Debug.Assert$2((this._state & 1023/*LockStates.ReadersMask*/) === 0, "(_state & LockStates.ReadersMask) == 0");
                $.$$.System.Diagnostics.Debug.Assert$2(this._writerID === -1/*InvalidThreadID*/, "_writerID == InvalidThreadID");
                this._writerID = threadID;
                this._writerLevel = 1;
                ++this._writerSeqNum;
                return;
            }
            /*void */ AcquireWriterLock$1(/*TimeSpan*/ timeout)
            {
                return this.AcquireWriterLock($.$st.System.Threading.ReaderWriterLock.ToTimeoutMilliseconds(timeout));
            }
            /*void */ ReleaseReaderLock()
            {
                if (this._writerID === $.$st.System.Threading.ReaderWriterLock.GetCurrentThreadID())
                {
                    this.ReleaseWriterLock();
                    return;
                }
                /*ThreadLocalLockEntry?*/ let threadLocalLockEntry = $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.GetCurrent(this._lockID);
                if (threadLocalLockEntry === null)
                {
                    throw $.$st.System.Threading.ReaderWriterLock.GetNotOwnerException();
                }
                $.$$.System.Diagnostics.Debug.Assert$2((this._state & 4096/*LockStates.Writer*/) === 0, "(_state & LockStates.Writer) == 0");
                $.$$.System.Diagnostics.Debug.Assert$2((this._state & 1023/*LockStates.ReadersMask*/) !== 0, "(_state & LockStates.ReadersMask) != 0");
                $.$$.System.Diagnostics.Debug.Assert$2(threadLocalLockEntry._readerLevel > 0, "threadLocalLockEntry._readerLevel > 0");
                --threadLocalLockEntry._readerLevel;
                if (threadLocalLockEntry._readerLevel > 0)
                {
                    return;
                }
                /*bool*/ let isLastReader;
                /*bool*/ let cacheEvents;
                /*AutoResetEvent?*/ let writerEvent = null;
                /*ManualResetEventSlim?*/ let readerEvent = null;
                /*int*/ let currentState = this._state;
                /*int*/ let knownState;
                do
                {
                    isLastReader = false;
                    cacheEvents = false;
                    knownState = currentState;
                    /*int*/ let modifyState = -1/*LockStates.Reader*/;
                    if ((knownState & (1023/*LockStates.ReadersMask*/ | 1024/*LockStates.ReaderSignaled*/)) === 1/*LockStates.Reader*/)
                    {
                        isLastReader = true;
                        if ((knownState & -8388608/*LockStates.WaitingWritersMask*/) !== 0)
                        {
                            writerEvent = this.TryGetOrCreateWriterEvent();
                            if (writerEvent === null)
                            {
                                $.$$.System.Threading.Thread.Sleep(100);
                                currentState = this._state;
                                knownState = 0;
                                $.$$.System.Diagnostics.Debug.Assert$2(currentState !== knownState, "currentState != knownState");
                                continue;
                            }
                            modifyState += 2048/*LockStates.WriterSignaled*/;
                        }
                        else if ((knownState & 8380416/*LockStates.WaitingReadersMask*/) !== 0)
                        {
                            readerEvent = this.TryGetOrCreateReaderEvent();
                            if (readerEvent === null)
                            {
                                $.$$.System.Threading.Thread.Sleep(100);
                                currentState = this._state;
                                knownState = 0;
                                $.$$.System.Diagnostics.Debug.Assert$2(currentState !== knownState, "currentState != knownState");
                                continue;
                            }
                            modifyState += 1024/*LockStates.ReaderSignaled*/;
                        }
                        else if (knownState === 1/*LockStates.Reader*/ && (this._readerEvent !== null || this._writerEvent !== null))
                        {
                            cacheEvents = true;
                            modifyState += 3072/*LockStates.CachingEvents*/;
                        }
                    }
                    $.$$.System.Diagnostics.Debug.Assert$2((knownState & 4096/*LockStates.Writer*/) === 0, "(knownState & LockStates.Writer) == 0");
                    $.$$.System.Diagnostics.Debug.Assert$2((knownState & 1023/*LockStates.ReadersMask*/) !== 0, "(knownState & LockStates.ReadersMask) != 0");
                    currentState = $.$$.System.Threading.Interlocked.CompareExchange$3($.$ref(() => this._state, ($v) => this._state = $v, $.$$.System.Int32), ((knownState + modifyState) | 0), knownState);
                }
                while(currentState !== knownState);
                if (isLastReader)
                {
                    if ((knownState & -8388608/*LockStates.WaitingWritersMask*/) !== 0)
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2((this._state & 2048/*LockStates.WriterSignaled*/) !== 0, "(_state & LockStates.WriterSignaled) != 0");
                        $.$$.System.Diagnostics.Debug.Assert$2(writerEvent !== null, "writerEvent != null");
                        writerEvent.Set$1();
                    }
                    else if ((knownState & 8380416/*LockStates.WaitingReadersMask*/) !== 0)
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2((this._state & 1024/*LockStates.ReaderSignaled*/) !== 0, "(_state & LockStates.ReaderSignaled) != 0");
                        $.$$.System.Diagnostics.Debug.Assert$2(readerEvent !== null, "readerEvent != null");
                        readerEvent.Set$1();
                    }
                    else if (cacheEvents)
                    {
                        this.ReleaseEvents();
                    }
                }
                $.$$.System.Diagnostics.Debug.Assert$2(threadLocalLockEntry.IsFree, "threadLocalLockEntry.IsFree");
            }
            /*void */ ReleaseWriterLock()
            {
                if (this._writerID !== $.$st.System.Threading.ReaderWriterLock.GetCurrentThreadID())
                {
                    throw $.$st.System.Threading.ReaderWriterLock.GetNotOwnerException();
                }
                $.$$.System.Diagnostics.Debug.Assert$2((this._state & 1023/*LockStates.ReadersMask*/) === 0, "(_state & LockStates.ReadersMask) == 0");
                $.$$.System.Diagnostics.Debug.Assert$2((this._state & 4096/*LockStates.Writer*/) !== 0, "(_state & LockStates.Writer) != 0");
                $.$$.System.Diagnostics.Debug.Assert$2(this._writerLevel > 0, "_writerLevel > 0");
                --this._writerLevel;
                if (this._writerLevel > 0)
                {
                    return;
                }
                this._writerID = -1/*InvalidThreadID*/;
                /*bool*/ let cacheEvents;
                /*ManualResetEventSlim?*/ let readerEvent = null;
                /*AutoResetEvent?*/ let writerEvent = null;
                /*int*/ let currentState = this._state;
                /*int*/ let knownState;
                do
                {
                    cacheEvents = false;
                    knownState = currentState;
                    /*int*/ let modifyState = -4096/*LockStates.Writer*/;
                    if ((knownState & 8380416/*LockStates.WaitingReadersMask*/) !== 0)
                    {
                        readerEvent = this.TryGetOrCreateReaderEvent();
                        if (readerEvent === null)
                        {
                            $.$$.System.Threading.Thread.Sleep(100);
                            currentState = this._state;
                            knownState = 0;
                            $.$$.System.Diagnostics.Debug.Assert$2(currentState !== knownState, "currentState != knownState");
                            continue;
                        }
                        modifyState += 1024/*LockStates.ReaderSignaled*/;
                    }
                    else if ((knownState & -8388608/*LockStates.WaitingWritersMask*/) !== 0)
                    {
                        writerEvent = this.TryGetOrCreateWriterEvent();
                        if (writerEvent === null)
                        {
                            $.$$.System.Threading.Thread.Sleep(100);
                            currentState = this._state;
                            knownState = 0;
                            $.$$.System.Diagnostics.Debug.Assert$2(currentState !== knownState, "currentState != knownState");
                            continue;
                        }
                        modifyState += 2048/*LockStates.WriterSignaled*/;
                    }
                    else if (knownState === 4096/*LockStates.Writer*/ && (this._readerEvent !== null || this._writerEvent !== null))
                    {
                        cacheEvents = true;
                        modifyState += 3072/*LockStates.CachingEvents*/;
                    }
                    $.$$.System.Diagnostics.Debug.Assert$2((knownState & 1023/*LockStates.ReadersMask*/) === 0, "(knownState & LockStates.ReadersMask) == 0");
                    $.$$.System.Diagnostics.Debug.Assert$2((knownState & 4096/*LockStates.Writer*/) !== 0, "(knownState & LockStates.Writer) != 0");
                    currentState = $.$$.System.Threading.Interlocked.CompareExchange$3($.$ref(() => this._state, ($v) => this._state = $v, $.$$.System.Int32), ((knownState + modifyState) | 0), knownState);
                }
                while(currentState !== knownState);
                if ((knownState & 8380416/*LockStates.WaitingReadersMask*/) !== 0)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2((this._state & 1024/*LockStates.ReaderSignaled*/) !== 0, "(_state & LockStates.ReaderSignaled) != 0");
                    $.$$.System.Diagnostics.Debug.Assert$2(readerEvent !== null, "readerEvent != null");
                    readerEvent.Set$1();
                }
                else if ((knownState & -8388608/*LockStates.WaitingWritersMask*/) !== 0)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2((this._state & 2048/*LockStates.WriterSignaled*/) !== 0, "(_state & LockStates.WriterSignaled) != 0");
                    $.$$.System.Diagnostics.Debug.Assert$2(writerEvent !== null, "writerEvent != null");
                    writerEvent.Set$1();
                }
                else if (cacheEvents)
                {
                    this.ReleaseEvents();
                }
            }
            /*LockCookie */ UpgradeToWriterLock(/*int*/ millisecondsTimeout)
            {
                $.$$.System.ArgumentOutOfRangeException.ThrowIfLessThan($.$$.System.Int32, millisecondsTimeout, -1, "millisecondsTimeout");
                /*LockCookie*/ let lockCookie = new $.$st.System.Threading.LockCookie();
                /*int*/ let threadID = $.$st.System.Threading.ReaderWriterLock.GetCurrentThreadID();
                lockCookie._threadID = threadID;
                if (this._writerID === threadID)
                {
                    lockCookie._flags = 8192/*LockCookieFlags.Upgrade*/ | 131072/*LockCookieFlags.OwnedWriter*/;
                    lockCookie._writerLevel = this._writerLevel;
                    this.AcquireWriterLock(millisecondsTimeout);
                    return lockCookie;
                }
                /*ThreadLocalLockEntry?*/ let threadLocalLockEntry = $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.GetCurrent(this._lockID);
                if (threadLocalLockEntry === null)
                {
                    lockCookie._flags = 8192/*LockCookieFlags.Upgrade*/ | 65536/*LockCookieFlags.OwnedNone*/;
                }
                else 
                {
                    $.$$.System.Diagnostics.Debug.Assert$2((this._state & 1023/*LockStates.ReadersMask*/) !== 0, "(_state & LockStates.ReadersMask) != 0");
                    $.$$.System.Diagnostics.Debug.Assert$2(threadLocalLockEntry._readerLevel > 0, "threadLocalLockEntry._readerLevel > 0");
                    lockCookie._flags = 8192/*LockCookieFlags.Upgrade*/ | 262144/*LockCookieFlags.OwnedReader*/;
                    lockCookie._readerLevel = threadLocalLockEntry._readerLevel;
                    /*int*/ let knownState = $.$$.System.Threading.Interlocked.CompareExchange$3($.$ref(() => this._state, ($v) => this._state = $v, $.$$.System.Int32), 4096/*LockStates.Writer*/, 1/*LockStates.Reader*/);
                    if (knownState === 1/*LockStates.Reader*/)
                    {
                        threadLocalLockEntry._readerLevel = 0;
                        $.$$.System.Diagnostics.Debug.Assert$2(threadLocalLockEntry.IsFree, "threadLocalLockEntry.IsFree");
                        this._writerID = threadID;
                        this._writerLevel = 1;
                        ++this._writerSeqNum;
                        return lockCookie;
                    }
                    threadLocalLockEntry._readerLevel = 1;
                    this.ReleaseReaderLock();
                }
                /*bool*/ let acquired = false;
                try
                {
                    this.AcquireWriterLock(millisecondsTimeout);
                    acquired = true;
                    return lockCookie;
                }
                finally
                {
                    {
                        if (!acquired)
                        {
                            /*LockCookieFlags*/ let flags = lockCookie._flags;
                            lockCookie._flags = -483329/*LockCookieFlags.Invalid*/;
                            this.RecoverLock($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$st.System.Threading.LockCookie, () => lockCookie, ($v) => lockCookie = $v, null), flags & 262144/*LockCookieFlags.OwnedReader*/);
                        }
                    }
                }
            }
            /*LockCookie */ UpgradeToWriterLock$1(/*TimeSpan*/ timeout)
            {
                return this.UpgradeToWriterLock($.$st.System.Threading.ReaderWriterLock.ToTimeoutMilliseconds(timeout));
            }
            /*void */ DowngradeFromWriterLock(/*ref LockCookie*/ lockCookie)
            {
                /*int*/ let threadID = $.$st.System.Threading.ReaderWriterLock.GetCurrentThreadID();
                if (this._writerID !== threadID)
                {
                    throw $.$st.System.Threading.ReaderWriterLock.GetNotOwnerException();
                }
                /*LockCookieFlags*/ let flags = lockCookie.$v._flags;
                /*ushort*/ let requestedWriterLevel = lockCookie.$v._writerLevel;
                if ((flags & -483329/*LockCookieFlags.Invalid*/) !== 0 || lockCookie.$v._threadID !== threadID || ((flags & (131072/*LockCookieFlags.OwnedWriter*/ | 65536/*LockCookieFlags.OwnedNone*/)) !== 0 && this._writerLevel <= requestedWriterLevel))
                {
                    throw $.$st.System.Threading.ReaderWriterLock.GetInvalidLockCookieException();
                }
                if ((flags & 262144/*LockCookieFlags.OwnedReader*/) !== 0)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(this._writerLevel > 0, "_writerLevel > 0");
                    /*ThreadLocalLockEntry*/ let threadLocalLockEntry = $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.GetOrCreateCurrent(this._lockID);
                    this._writerID = -1/*InvalidThreadID*/;
                    this._writerLevel = 0;
                    /*ManualResetEventSlim?*/ let readerEvent = null;
                    /*int*/ let currentState = this._state;
                    /*int*/ let knownState;
                    do
                    {
                        knownState = currentState;
                        /*int*/ let modifyState = ((1/*LockStates.Reader*/ - 4096/*LockStates.Writer*/) | 0);
                        if ((knownState & 8380416/*LockStates.WaitingReadersMask*/) !== 0)
                        {
                            readerEvent = this.TryGetOrCreateReaderEvent();
                            if (readerEvent === null)
                            {
                                $.$$.System.Threading.Thread.Sleep(100);
                                currentState = this._state;
                                knownState = 0;
                                $.$$.System.Diagnostics.Debug.Assert$2(currentState !== knownState, "currentState != knownState");
                                continue;
                            }
                            modifyState += 1024/*LockStates.ReaderSignaled*/;
                        }
                        $.$$.System.Diagnostics.Debug.Assert$2((knownState & 1023/*LockStates.ReadersMask*/) === 0, "(knownState & LockStates.ReadersMask) == 0");
                        currentState = $.$$.System.Threading.Interlocked.CompareExchange$3($.$ref(() => this._state, ($v) => this._state = $v, $.$$.System.Int32), ((knownState + modifyState) | 0), knownState);
                    }
                    while(currentState !== knownState);
                    if ((knownState & 8380416/*LockStates.WaitingReadersMask*/) !== 0)
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2((this._state & 1024/*LockStates.ReaderSignaled*/) !== 0, "(_state & LockStates.ReaderSignaled) != 0");
                        $.$$.System.Diagnostics.Debug.Assert$2(readerEvent !== null, "readerEvent != null");
                        readerEvent.Set$1();
                    }
                    threadLocalLockEntry._readerLevel = lockCookie.$v._readerLevel;
                }
                else if ((flags & (131072/*LockCookieFlags.OwnedWriter*/ | 65536/*LockCookieFlags.OwnedNone*/)) !== 0)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(this._writerLevel > 0, "_writerLevel > 0");
                    $.$$.System.Diagnostics.Debug.Assert$2(this._writerLevel > requestedWriterLevel, "_writerLevel > requestedWriterLevel");
                    if (requestedWriterLevel > 0)
                    {
                        this._writerLevel = requestedWriterLevel;
                    }
                    else 
                    {
                        if (this._writerLevel !== 1)
                        {
                            this._writerLevel = 1;
                        }
                        this.ReleaseWriterLock();
                    }
                    $.$$.System.Diagnostics.Debug.Assert$2((flags & 131072/*LockCookieFlags.OwnedWriter*/) !== 0 || this._writerID !== threadID, "(flags & LockCookieFlags.OwnedWriter) != 0 || _writerID != threadID");
                }
                lockCookie.$v._flags = -483329/*LockCookieFlags.Invalid*/;
            }
            /*LockCookie */ ReleaseLock()
            {
                /*LockCookie*/ let lockCookie = new $.$st.System.Threading.LockCookie();
                /*int*/ let threadID = $.$st.System.Threading.ReaderWriterLock.GetCurrentThreadID();
                lockCookie._threadID = threadID;
                if (this._writerID === threadID)
                {
                    lockCookie._flags = 16384/*LockCookieFlags.Release*/ | 131072/*LockCookieFlags.OwnedWriter*/;
                    lockCookie._writerLevel = this._writerLevel;
                    this._writerLevel = 1;
                    this.ReleaseWriterLock();
                    return lockCookie;
                }
                /*ThreadLocalLockEntry?*/ let threadLocalLockEntry = $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.GetCurrent(this._lockID);
                if (threadLocalLockEntry === null)
                {
                    lockCookie._flags = 16384/*LockCookieFlags.Release*/ | 65536/*LockCookieFlags.OwnedNone*/;
                    return lockCookie;
                }
                $.$$.System.Diagnostics.Debug.Assert$2((this._state & 1023/*LockStates.ReadersMask*/) !== 0, "(_state & LockStates.ReadersMask) != 0");
                $.$$.System.Diagnostics.Debug.Assert$2(threadLocalLockEntry._readerLevel > 0, "threadLocalLockEntry._readerLevel > 0");
                lockCookie._flags = 16384/*LockCookieFlags.Release*/ | 262144/*LockCookieFlags.OwnedReader*/;
                lockCookie._readerLevel = threadLocalLockEntry._readerLevel;
                threadLocalLockEntry._readerLevel = 1;
                this.ReleaseReaderLock();
                return lockCookie;
            }
            /*void */ RestoreLock(/*ref LockCookie*/ lockCookie)
            {
                /*int*/ let threadID = $.$st.System.Threading.ReaderWriterLock.GetCurrentThreadID();
                if (lockCookie.$v._threadID !== threadID)
                {
                    throw $.$st.System.Threading.ReaderWriterLock.GetInvalidLockCookieException();
                }
                if (this._writerID === threadID || $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.GetCurrent(this._lockID) !== null)
                {
                    throw new $.$$.System.Threading.SynchronizationLockException().$ctor$12($.$st.System.SR.ReaderWriterLock_RestoreLockWithOwnedLocks);
                }
                /*LockCookieFlags*/ let flags = lockCookie.$v._flags;
                if ((flags & -483329/*LockCookieFlags.Invalid*/) !== 0)
                {
                    throw $.$st.System.Threading.ReaderWriterLock.GetInvalidLockCookieException();
                }
                do
                {
                    if ((flags & 65536/*LockCookieFlags.OwnedNone*/) !== 0)
                    {
                        break;
                    }
                    if ((flags & 131072/*LockCookieFlags.OwnedWriter*/) !== 0)
                    {
                        if ($.$$.System.Threading.Interlocked.CompareExchange$3($.$ref(() => this._state, ($v) => this._state = $v, $.$$.System.Int32), 4096/*LockStates.Writer*/, 0) === 0)
                        {
                            this._writerID = threadID;
                            this._writerLevel = lockCookie.$v._writerLevel;
                            ++this._writerSeqNum;
                            break;
                        }
                    }
                    else if ((flags & 262144/*LockCookieFlags.OwnedReader*/) !== 0)
                    {
                        /*ThreadLocalLockEntry*/ let threadLocalLockEntry = $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.GetOrCreateCurrent(this._lockID);
                        $.$$.System.Diagnostics.Debug.Assert$2(threadLocalLockEntry.IsFree, "threadLocalLockEntry.IsFree");
                        /*int*/ let knownState = this._state;
                        if (knownState < 1023/*LockStates.ReadersMask*/ && $.$$.System.Threading.Interlocked.CompareExchange$3($.$ref(() => this._state, ($v) => this._state = $v, $.$$.System.Int32), ((knownState + 1/*LockStates.Reader*/) | 0), knownState) === knownState)
                        {
                            threadLocalLockEntry._readerLevel = lockCookie.$v._readerLevel;
                            break;
                        }
                    }
                    this.RecoverLock(lockCookie, flags);
                }
                while(false);
                lockCookie.$v._flags = -483329/*LockCookieFlags.Invalid*/;
            }
            /*void */ RecoverLock(/*ref LockCookie*/ lockCookie, /*LockCookieFlags*/ flags)
            {
                if ((flags & 131072/*LockCookieFlags.OwnedWriter*/) !== 0)
                {
                    this.AcquireWriterLock(-1/*Timeout.Infinite*/);
                    this._writerLevel = lockCookie.$v._writerLevel;
                }
                else if ((flags & 262144/*LockCookieFlags.OwnedReader*/) !== 0)
                {
                    this.AcquireReaderLock(-1/*Timeout.Infinite*/);
                    /*ThreadLocalLockEntry?*/ let threadLocalLockEntry = $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.GetCurrent(this._lockID);
                    $.$$.System.Diagnostics.Debug.Assert$2(threadLocalLockEntry !== null, "threadLocalLockEntry != null");
                    threadLocalLockEntry._readerLevel = lockCookie.$v._readerLevel;
                }
            }
            static /*int */ GetCurrentThreadID()
            {
                /*int*/ let threadID = $.$$.System.Environment.CurrentManagedThreadId;
                $.$$.System.Diagnostics.Debug.Assert$2(threadID !== -1/*InvalidThreadID*/, "threadID != InvalidThreadID");
                return threadID;
            }
            static /*bool */ YieldProcessor()
            {
                $.$$.System.Threading.Thread.SpinWait(1);
                return true;
            }
            /*ManualResetEventSlim */ GetOrCreateReaderEvent()
            {
                /*ManualResetEventSlim?*/ let currentEvent = this._readerEvent;
                if (currentEvent !== null)
                {
                    return currentEvent;
                }
                currentEvent = new $.$$.System.Threading.ManualResetEventSlim().$ctor$2(false, 0);
                /*ManualResetEventSlim?*/ let previousEvent = $.$$.System.Threading.Interlocked.CompareExchange$14($.$$.System.Threading.ManualResetEventSlim, $.$ref(() => this._readerEvent, ($v) => this._readerEvent = $v, $.$$.System.Threading.ManualResetEventSlim), currentEvent, null);
                if (previousEvent === null)
                {
                    return currentEvent;
                }
                currentEvent.Dispose();
                return previousEvent;
            }
            /*AutoResetEvent */ GetOrCreateWriterEvent()
            {
                /*AutoResetEvent?*/ let currentEvent = this._writerEvent;
                if (currentEvent !== null)
                {
                    return currentEvent;
                }
                currentEvent = new $.$$.System.Threading.AutoResetEvent().$ctor$8(false);
                /*AutoResetEvent?*/ let previousEvent = $.$$.System.Threading.Interlocked.CompareExchange$14($.$$.System.Threading.AutoResetEvent, $.$ref(() => this._writerEvent, ($v) => this._writerEvent = $v, $.$$.System.Threading.AutoResetEvent), currentEvent, null);
                if (previousEvent === null)
                {
                    return currentEvent;
                }
                currentEvent.Dispose();
                return previousEvent;
            }
            /*ManualResetEventSlim? */ TryGetOrCreateReaderEvent()
            {
                try
                {
                    return this.GetOrCreateReaderEvent();
                }
                catch($e)
                {
                    return null;
                }
            }
            /*AutoResetEvent? */ TryGetOrCreateWriterEvent()
            {
                try
                {
                    return this.GetOrCreateWriterEvent();
                }
                catch($e)
                {
                    return null;
                }
            }
            /*void */ ReleaseEvents()
            {
                $.$$.System.Diagnostics.Debug.Assert$2((this._state & 3072/*LockStates.CachingEvents*/) === 3072/*LockStates.CachingEvents*/, "(_state & LockStates.CachingEvents) == LockStates.CachingEvents");
                /*AutoResetEvent?*/ let writerEvent = this._writerEvent;
                this._writerEvent = null;
                /*ManualResetEventSlim?*/ let readerEvent = this._readerEvent;
                this._readerEvent = null;
                $.$$.System.Threading.Interlocked.Add($.$ref(() => this._state, ($v) => this._state = $v, $.$$.System.Int32), -3072/*LockStates.CachingEvents*/);
                writerEvent?.Dispose();
                readerEvent?.Dispose();
            }
            static /*int */ ToTimeoutMilliseconds(/*TimeSpan*/ timeout)
            {
                /*var*/ let timeoutMilliseconds = $.$cast(timeout.TotalMilliseconds, $.$$.System.Int64);
                $.$$.System.ArgumentOutOfRangeException.ThrowIfLessThan($.$$.System.Int64, timeoutMilliseconds, BigInt(-1), "timeout");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$$.System.Int64, timeoutMilliseconds, BigInt(2147483647/*int.MaxValue*/), "timeout");
                return $.$cast(timeoutMilliseconds, $.$$.System.Int32);
            }
            static $_ReaderWriterLockApplicationException;
            static get ReaderWriterLockApplicationException()
            {
                let $cls = $.$st.System.Threading.ReaderWriterLock;
                return $cls.$_ReaderWriterLockApplicationException ??= $asm.$ncls("$st.System.Threading.ReaderWriterLock.ReaderWriterLockApplicationException", ($self) => class ReaderWriterLockApplicationException extends $.$$.System.ApplicationException
                {
                    $ctor$9(/*int*/ errorHResult, /*string*/ message)
                    {
                        super.$ctor$8($.$st.System.SR.Format$6(message, $.$st.System.SR.Format$6($.$st.System.SR.ExceptionFromHResult, $.$box(errorHResult, $.$$.System.Int32))));
                        {
                            this.HResult = errorHResult;
                        }
                        return this;
                    }
                    $ctor$10(/*SerializationInfo*/ info, /*StreamingContext*/ context)
                    {
                        super.$ctor$6(info, context);
                        {
                        }
                        return this;
                    }
                    static $h = 1045270;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":13369345,"d":914198,"h":1045270}; }
                    static get $b() { return $.$$.System.ApplicationException; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Runtime.Serialization.ISerializable ]; }
                    static get $fullName() { return `System.Threading.ReaderWriterLock.ReaderWriterLockApplicationException`; }
                }, $cls, ($v) => $cls.$_ReaderWriterLockApplicationException = $v);
            }
            static /*ReaderWriterLockApplicationException */ GetTimeoutException()
            {
                return new $.$st.System.Threading.ReaderWriterLock.ReaderWriterLockApplicationException().$ctor$9(-2147023436/*HResults.ERROR_TIMEOUT*/, $.$st.System.SR.ReaderWriterLock_Timeout);
            }
            static /*ReaderWriterLockApplicationException */ GetNotOwnerException()
            {
                return new $.$st.System.Threading.ReaderWriterLock.ReaderWriterLockApplicationException().$ctor$9(288/*IncorrectButCompatibleNotOwnerExceptionHResult*/, $.$st.System.SR.ReaderWriterLock_NotOwner);
            }
            static /*ReaderWriterLockApplicationException */ GetInvalidLockCookieException()
            {
                return new $.$st.System.Threading.ReaderWriterLock.ReaderWriterLockApplicationException().$ctor$9(-2147024809/*HResults.E_INVALIDARG*/, $.$st.System.SR.ReaderWriterLock_InvalidLockCookie);
            }
            static $_LockStates;
            static get LockStates()
            {
                let $cls = $.$st.System.Threading.ReaderWriterLock;
                return $cls.$_LockStates ??= $asm.$ncls("$st.System.Threading.ReaderWriterLock.LockStates", ($self) => class LockStates
                {
                    /*int*/ static Reader = 1;
                    /*int*/ static ReadersMask = 1023;
                    /*int*/ static ReaderSignaled = 1024;
                    /*int*/ static WriterSignaled = 2048;
                    /*int*/ static Writer = 4096;
                    /*int*/ static WaitingReader = 8192;
                    /*int*/ static WaitingReadersMask = 8380416;
                    /*int*/ static WaitingReadersShift = 13;
                    /*int*/ static WaitingWriter = 8388608;
                    /*int*/ static WaitingWritersMask = -8388608;
                    /*int*/ static CachingEvents = 3072;
                    static $h = 979734;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"Reader","d":979734,"h":4295947030,"f":4194337},{"t":655361,"n":"ReadersMask","d":979734,"h":8590914326,"f":4194337},{"t":655361,"n":"ReaderSignaled","d":979734,"h":12885881622,"f":4194337},{"t":655361,"n":"WriterSignaled","d":979734,"h":17180848918,"f":4194337},{"t":655361,"n":"Writer","d":979734,"h":21475816214,"f":4194337},{"t":655361,"n":"WaitingReader","d":979734,"h":25770783510,"f":4194337},{"t":655361,"n":"WaitingReadersMask","d":979734,"h":30065750806,"f":4194337},{"t":655361,"n":"WaitingReadersShift","d":979734,"h":34360718102,"f":4194337},{"t":655361,"n":"WaitingWriter","d":979734,"h":38655685398,"f":4194337},{"t":655361,"n":"WaitingWritersMask","d":979734,"h":42950652694,"f":4194337},{"t":655361,"n":"CachingEvents","d":979734,"h":47245619990,"f":4194337}],"d":914198,"h":979734}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Threading.ReaderWriterLock.LockStates`; }
                }, $cls, ($v) => $cls.$_LockStates = $v);
            }
            static $_ThreadLocalLockEntry;
            static get ThreadLocalLockEntry()
            {
                let $cls = $.$st.System.Threading.ReaderWriterLock;
                return $cls.$_ThreadLocalLockEntry ??= $asm.$ncls("$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry", ($self) => class ThreadLocalLockEntry extends $.$$.System.Object
                {
                    /*ThreadLocalLockEntry?*/ static t_lockEntryHead = null;
                    /*long*/ _lockID = 0n;
                    /*ThreadLocalLockEntry?*/ _next = null;
                    /*ushort*/ _readerLevel = 0;
                    $ctor$1(/*long*/ lockID)
                    {
                        super.$ctor();
                        {
                            this._lockID = lockID;
                        }
                        return this;
                    }
                    /*bool */ HasLockID(/*long*/ lockID)
                    {
                        return this._lockID === lockID;
                    }
                    /*bool */ get IsFree()
                    {
                        return this._readerLevel === 0;
                    }
                    static /*void */ VerifyNoNonemptyEntryInListAfter(/*long*/ lockID, /*ThreadLocalLockEntry*/ afterEntry)
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(lockID !== 0n, "lockID != 0");
                        $.$$.System.Diagnostics.Debug.Assert$2(afterEntry !== null, "afterEntry != null");
                        for(/*ThreadLocalLockEntry?*/ let currentEntry = afterEntry._next; currentEntry !== null; currentEntry = currentEntry._next)
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(currentEntry._lockID !== lockID || currentEntry.IsFree, "currentEntry._lockID != lockID || currentEntry.IsFree");
                        }
                    }
                    static /*ThreadLocalLockEntry? */ GetCurrent(/*long*/ lockID)
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(lockID !== 0n, "lockID != 0");
                        /*ThreadLocalLockEntry?*/ let headEntry = $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.t_lockEntryHead;
                        for(/*ThreadLocalLockEntry?*/ let currentEntry = headEntry; currentEntry !== null; currentEntry = currentEntry._next)
                        {
                            if (currentEntry._lockID === lockID)
                            {
                                $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.VerifyNoNonemptyEntryInListAfter(lockID, currentEntry);
                                return currentEntry.IsFree ? null : currentEntry;
                            }
                        }
                        return null;
                    }
                    static /*ThreadLocalLockEntry */ GetOrCreateCurrent(/*long*/ lockID)
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(lockID !== 0n, "lockID != 0");
                        /*ThreadLocalLockEntry?*/ let headEntry = $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.t_lockEntryHead;
                        if (headEntry !== null && headEntry._lockID === lockID)
                        {
                            $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.VerifyNoNonemptyEntryInListAfter(lockID, headEntry);
                            return headEntry;
                        }
                        return $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.GetOrCreateCurrentSlow(lockID, headEntry);
                    }
                    static /*ThreadLocalLockEntry */ GetOrCreateCurrentSlow(/*long*/ lockID, /*ThreadLocalLockEntry?*/ headEntry)
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(lockID !== 0n, "lockID != 0");
                        $.$$.System.Diagnostics.Debug.Assert$2(headEntry === $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.t_lockEntryHead, "headEntry == t_lockEntryHead");
                        $.$$.System.Diagnostics.Debug.Assert$2(headEntry === null || headEntry._lockID !== lockID, "headEntry == null || headEntry._lockID != lockID");
                        /*ThreadLocalLockEntry?*/ let entry = null;
                        /*ThreadLocalLockEntry?*/ let emptyEntryPrevious = null;
                        /*ThreadLocalLockEntry?*/ let emptyEntry = null;
                        if (headEntry !== null)
                        {
                            if (headEntry.IsFree)
                            {
                                emptyEntry = headEntry;
                            }
                            for(/*ThreadLocalLockEntry?*/ let previousEntry = headEntry, currentEntry = headEntry._next; currentEntry !== null; previousEntry = currentEntry, currentEntry = currentEntry._next)
                            {
                                if (currentEntry._lockID === lockID)
                                {
                                    $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.VerifyNoNonemptyEntryInListAfter(lockID, currentEntry);
                                    previousEntry._next = currentEntry._next;
                                    entry = currentEntry;
                                    break;
                                }
                                if (emptyEntry === null && currentEntry.IsFree)
                                {
                                    emptyEntryPrevious = previousEntry;
                                    emptyEntry = currentEntry;
                                }
                            }
                        }
                        if (entry === null)
                        {
                            if (emptyEntry !== null)
                            {
                                emptyEntry._lockID = lockID;
                                if (emptyEntryPrevious === null)
                                {
                                    $.$$.System.Diagnostics.Debug.Assert$2(emptyEntry === headEntry, "emptyEntry == headEntry");
                                    return emptyEntry;
                                }
                                emptyEntryPrevious._next = emptyEntry._next;
                                entry = emptyEntry;
                            }
                            else 
                            {
                                entry = new $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry().$ctor$1(lockID);
                            }
                        }
                        $.$$.System.Diagnostics.Debug.Assert$2(entry._lockID === lockID, "entry._lockID == lockID");
                        entry._next = headEntry;
                        $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.t_lockEntryHead = entry;
                        return entry;
                    }
                    static $h = 1110806;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":34360849174,"f":50331649},"n":"IsFree","d":1110806,"h":30065881878,"f":2097153}],"m":[{"r":262145,"p":[{"n":"lockID","p":917505}],"n":"HasLockID","d":1110806,"h":25770914582,"f":16777217},{"r":65537,"p":[{"n":"lockID","p":917505},{"n":"afterEntry","p":1110806}],"n":"VerifyNoNonemptyEntryInListAfter","d":1110806,"h":38655816470,"f":16777250,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"DEBUG","t":1310721}]}]},{"r":1110806,"p":[{"n":"lockID","p":917505}],"n":"GetCurrent","d":1110806,"h":42950783766,"f":16777249},{"r":1110806,"p":[{"n":"lockID","p":917505}],"n":"GetOrCreateCurrent","d":1110806,"h":47245751062,"f":16777249},{"r":1110806,"p":[{"n":"lockID","p":917505},{"n":"headEntry","p":1110806}],"n":"GetOrCreateCurrentSlow","d":1110806,"h":51540718358,"f":16777250}],"l":[{"t":1110806,"n":"t_lockEntryHead","d":1110806,"h":4296078102,"f":4194338,"a":[{"t":140050433,"c":4435017729}]},{"t":917505,"n":"_lockID","d":1110806,"h":8591045398,"f":4194306},{"t":1110806,"n":"_next","d":1110806,"h":12886012694,"f":4194306},{"t":589825,"n":"_readerLevel","d":1110806,"h":17180979990,"f":4194305}],"c":[{"p":[{"n":"lockID","p":917505}],"n":".ctor","o":"$ctor$1","d":1110806,"h":21475947286,"f":16777218}],"d":914198,"h":1110806}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Threading.ReaderWriterLock.ThreadLocalLockEntry`; }
                }, $cls, ($v) => $cls.$_ThreadLocalLockEntry = $v);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.DefaultSpinCount = /*Environment.ProcessorCount != 1 ? 500 : */ 0;
                }
            }
            static $h = 914198;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":96993281,"p":[{"p":262145,"g":{"r":0,"d":0,"h":64425423638,"f":50331649},"n":"IsReaderLockHeld","d":914198,"h":60130456342,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":73015358230,"f":50331649},"n":"IsWriterLockHeld","d":914198,"h":68720390934,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":81605292822,"f":50331649},"n":"WriterSeqNum","d":914198,"h":77310325526,"f":2097153}],"m":[{"r":262145,"p":[{"n":"seqNum","p":655361}],"n":"AnyWritersSince","d":914198,"h":85900260118,"f":16777217},{"r":65537,"p":[{"n":"millisecondsTimeout","p":655361}],"n":"AcquireReaderLock","d":914198,"h":90195227414,"f":16777217,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"browser","t":1310721}]}]},{"r":65537,"p":[{"n":"timeout","p":140574721}],"n":"AcquireReaderLock","o":"@$1","d":914198,"h":94490194710,"f":16777217,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"browser","t":1310721}]}]},{"r":65537,"p":[{"n":"millisecondsTimeout","p":655361}],"n":"AcquireWriterLock","d":914198,"h":98785162006,"f":16777217},{"r":65537,"p":[{"n":"timeout","p":140574721}],"n":"AcquireWriterLock","o":"@$1","d":914198,"h":103080129302,"f":16777217},{"r":65537,"n":"ReleaseReaderLock","d":914198,"h":107375096598,"f":16777217},{"r":65537,"n":"ReleaseWriterLock","d":914198,"h":111670063894,"f":16777217},{"r":783126,"p":[{"n":"millisecondsTimeout","p":655361}],"n":"UpgradeToWriterLock","d":914198,"h":115965031190,"f":16777217,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"browser","t":1310721}]}]},{"r":783126,"p":[{"n":"timeout","p":140574721}],"n":"UpgradeToWriterLock","o":"@$1","d":914198,"h":120259998486,"f":16777217,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"browser","t":1310721}]}]},{"r":65537,"p":[{"n":"lockCookie","p":783126,"f":4}],"n":"DowngradeFromWriterLock","d":914198,"h":124554965782,"f":16777217},{"r":783126,"n":"ReleaseLock","d":914198,"h":128849933078,"f":16777217},{"r":65537,"p":[{"n":"lockCookie","p":783126,"f":4}],"n":"RestoreLock","d":914198,"h":133144900374,"f":16777217,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"browser","t":1310721}]}]},{"r":65537,"p":[{"n":"lockCookie","p":783126,"f":4},{"n":"flags","p":848662}],"n":"RecoverLock","d":914198,"h":137439867670,"f":16777218,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"browser","t":1310721}]}]},{"r":655361,"n":"GetCurrentThreadID","d":914198,"h":141734834966,"f":16777250},{"r":262145,"n":"YieldProcessor","d":914198,"h":146029802262,"f":16777250},{"r":128253953,"n":"GetOrCreateReaderEvent","d":914198,"h":150324769558,"f":16777218},{"r":125763585,"n":"GetOrCreateWriterEvent","d":914198,"h":154619736854,"f":16777218},{"r":128253953,"n":"TryGetOrCreateReaderEvent","d":914198,"h":158914704150,"f":16777218},{"r":125763585,"n":"TryGetOrCreateWriterEvent","d":914198,"h":163209671446,"f":16777218},{"r":65537,"n":"ReleaseEvents","d":914198,"h":167504638742,"f":16777218},{"r":655361,"p":[{"n":"timeout","p":140574721}],"n":"ToTimeoutMilliseconds","d":914198,"h":171799606038,"f":16777250},{"r":1045270,"n":"GetTimeoutException","d":914198,"h":180389540630,"f":16777250},{"r":1045270,"n":"GetNotOwnerException","d":914198,"h":184684507926,"f":16777250},{"r":1045270,"n":"GetInvalidLockCookieException","d":914198,"h":188979475222,"f":16777250}],"l":[{"t":655361,"n":"InvalidThreadID","d":914198,"h":4295881494,"f":4194338},{"t":589825,"n":"MaxAcquireCount","d":914198,"h":8590848790,"f":4194338},{"t":655361,"n":"DefaultSpinCount","d":914198,"h":12885816086,"f":4194338},{"t":655361,"n":"IncorrectButCompatibleNotOwnerExceptionHResult","d":914198,"h":17180783382,"f":4194338},{"t":917505,"n":"s_mostRecentLockID","d":914198,"h":21475750678,"f":4194338},{"t":128253953,"n":"_readerEvent","d":914198,"h":25770717974,"f":4194306},{"t":125763585,"n":"_writerEvent","d":914198,"h":30065685270,"f":4194306},{"t":917505,"n":"_lockID","d":914198,"h":34360652566,"f":4194306},{"t":655361,"n":"_state","d":914198,"h":38655619862,"f":4194306},{"t":655361,"n":"_writerID","d":914198,"h":42950587158,"f":4194306},{"t":655361,"n":"_writerSeqNum","d":914198,"h":47245554454,"f":4194306},{"t":589825,"n":"_writerLevel","d":914198,"h":51540521750,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$2","d":914198,"h":55835489046,"f":16777217}],"j":[979734,1110806],"h":914198}; }
            static get $b() { return $.$$.System.Runtime.ConstrainedExecution.CriticalFinalizerObject; }
            static get $fullName() { return `System.Threading.ReaderWriterLock`; }
        });
        
        $asm.$str("$st.System.Threading.LockCookie", ($self) => class LockCookie extends $.$$.System.ValueType
        {
            /*LockCookieFlags*/  get _flags() { return this.$getField(0, $.$st.System.Threading.LockCookieFlags); }
            /*LockCookieFlags*/  set _flags(value) { this.$setField(0, $.$st.System.Threading.LockCookieFlags, value); }
            /*ushort*/  get _readerLevel() { return this.$getField(4, $.$$.System.UInt16); }
            /*ushort*/  set _readerLevel(value) { this.$setField(4, $.$$.System.UInt16, value); }
            /*ushort*/  get _writerLevel() { return this.$getField(6, $.$$.System.UInt16); }
            /*ushort*/  set _writerLevel(value) { this.$setField(6, $.$$.System.UInt16, value); }
            /*int*/  get _threadID() { return this.$getField(8, $.$$.System.Int32); }
            /*int*/  set _threadID(value) { this.$setField(8, $.$$.System.Int32, value); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return ((((((this._flags + this._readerLevel) | 0) + this._writerLevel) | 0) + this._threadID) | 0);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$st.System.Threading.LockCookie.GetHashCode.apply(this, arguments); }
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                let other;
                return $.$is(obj, $.$st.System.Threading.LockCookie, { set $v(v){ other = v; } }) && this.Equals$2(other.Clone());
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$st.System.Threading.LockCookie.Equals$1.apply(this, arguments); }
            /*bool */ Equals$2(/*LockCookie*/ obj)
            {
                return this._flags === obj._flags && this._readerLevel === obj._readerLevel && this._writerLevel === obj._writerLevel && this._threadID === obj._threadID;
            }
            static /*bool */ op_Equality(/*LockCookie*/ a, /*LockCookie*/ b)
            {
                return a.Equals$2(b.Clone());
            }
            static /*bool */ op_Inequality(/*LockCookie*/ a, /*LockCookie*/ b)
            {
                return !a.Equals$2(b.Clone());
            }
            //Generated interface implemetation for System.IEquatable<System.Threading.LockCookie>.Equals(System.Threading.LockCookie)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._flags = this._flags;
                copy._readerLevel = this._readerLevel;
                copy._writerLevel = this._writerLevel;
                copy._threadID = this._threadID;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._flags = 0;
                this._readerLevel = 0;
                this._writerLevel = 0;
                this._threadID = 0;
            }
            static $h = 783126;
            static $z = 12;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"m":[{"r":655361,"n":"GetHashCode","d":783126,"h":21475619606,"f":16809985},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","o":"@$1","d":783126,"h":25770586902,"f":16809985},{"r":262145,"p":[{"n":"obj","p":783126}],"n":"Equals","o":"@$2","d":783126,"h":30065554198,"f":16777217}],"l":[{"t":848662,"n":"_flags","d":783126,"h":4295750422,"f":4194312},{"t":589825,"n":"_readerLevel","d":783126,"h":8590717718,"f":4194312},{"t":589825,"n":"_writerLevel","d":783126,"h":12885685014,"f":4194312},{"t":655361,"n":"_threadID","d":783126,"h":17180652310,"f":4194312}],"c":[{"n":".ctor","o":"$ctor$2","d":783126,"h":42950456086,"f":16777217}],"i":[$.$$.System.IEquatable$$($.$st.System.Threading.LockCookie).$h],"h":783126}; }
            static get $b() { return $.$$.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IEquatable$$($.$st.System.Threading.LockCookie) ]; }
            static get $fullName() { return `System.Threading.LockCookie`; }
        });
        
        $asm.$str("$st.System.Threading.LockCookieFlags", ($self) => class LockCookieFlags extends $.$$.System.Enum
        {
            static Upgrade = 8192;
            static Release = 16384;
            static OwnedNone = 65536;
            static OwnedWriter = 131072;
            static OwnedReader = 262144;
            static Invalid = -483329;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Upgrade": 8192n,
                    "Release": 16384n,
                    "OwnedNone": 65536n,
                    "OwnedWriter": 131072n,
                    "OwnedReader": 262144n,
                    "Invalid": -483329n
                };
            }
            static $h = 848662;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":848662,"n":"Upgrade","d":848662,"h":4295815958,"f":4194337},{"t":848662,"n":"Release","d":848662,"h":8590783254,"f":4194337},{"t":848662,"n":"OwnedNone","d":848662,"h":12885750550,"f":4194337},{"t":848662,"n":"OwnedWriter","d":848662,"h":17180717846,"f":4194337},{"t":848662,"n":"OwnedReader","d":848662,"h":21475685142,"f":4194337},{"t":848662,"n":"Invalid","d":848662,"h":25770652438,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":848662,"h":30065619734,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":848662,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Threading.LockCookieFlags`; }
        });
        
        $asm.$cls("$st.System.Threading.CdsSyncEtwBCLProvider", ($self) => class CdsSyncEtwBCLProvider extends $.$$.System.Diagnostics.Tracing.EventSource
        {
            /*CdsSyncEtwBCLProvider*/ static Log = null;
            $ctor$10()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*EventKeywords*/ static ALL_KEYWORDS = -1n;
            /*int*/ static BARRIER_PHASEFINISHED_ID = 3;
            /*void */ Barrier_PhaseFinished(/*bool*/ currentSense, /*long*/ phaseNum)
            {
                if (this.IsEnabled$2(5/*EventLevel.Verbose*/, -1n))
                {
                    {
                        /*EventData**/ let eventPayload = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocPointer($.$$.System.Diagnostics.Tracing.EventSource.EventData, 2, null);
                        /*int*/ let senseAsInt32 = currentSense ? 1 : 0;
                        eventPayload.SetAt((() =>
                        {
                            //new $.$$.System.Diagnostics.Tracing.EventSource.EventData()
                            const $t1 = $.$$.System.Diagnostics.Tracing.EventSource.EventData;
                            const $i1 = new $t1();
                            $i1.Size = $.$$.System.Int32.$z;
                            $i1.DataPointer = ($.$cast(($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Int32, () => senseAsInt32, ($v) => senseAsInt32 = $v, null)), $.$$.System.IntPtr));
                            return $i1;
                        })(), 0);
                        eventPayload.SetAt((() =>
                        {
                            //new $.$$.System.Diagnostics.Tracing.EventSource.EventData()
                            const $t2 = $.$$.System.Diagnostics.Tracing.EventSource.EventData;
                            const $i2 = new $t2();
                            $i2.Size = $.$$.System.Int64.$z;
                            $i2.DataPointer = ($.$$.$interop.castObject2Address($.$box(phaseNum, $.$$.System.Int64), 0, false));
                            return $i2;
                        })(), 1);
                        this.WriteEventCore(3/*BARRIER_PHASEFINISHED_ID*/, 2, eventPayload);
                    }
                }
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Log = new $.$st.System.Threading.CdsSyncEtwBCLProvider().$ctor$10();
                }
            }
            static $h = 455446;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":41746433,"m":[{"r":65537,"p":[{"n":"currentSense","p":262145},{"n":"phaseNum","p":917505}],"n":"Barrier_PhaseFinished","d":455446,"h":21475291926,"f":16777217,"a":[{"t":39976961,"c":4334944257,"a":[{"v":3,"t":655361}],"n":[{"n":"Level","v":5,"t":40960001},{"n":"Version","v":1,"t":393217}]}]}],"l":[{"t":455446,"n":"Log","d":455446,"h":4295422742,"f":4194337},{"t":40894465,"n":"ALL_KEYWORDS","d":455446,"h":12885357334,"f":4194338},{"t":655361,"n":"BARRIER_PHASEFINISHED_ID","d":455446,"h":17180324630,"f":4194338}],"c":[{"n":".ctor","o":"$ctor$10","d":455446,"h":8590390038,"f":16777218}],"i":[57540609],"h":455446,"a":[{"t":42074113,"c":55876648961,"n":[{"n":"Name","v":"System.Threading.SynchronizationEventSource","t":1310721},{"n":"Guid","v":"EC631D38-466B-4290-9306-834971BA0217","t":1310721}]}]}; }
            static get $b() { return $.$$.System.Diagnostics.Tracing.EventSource; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.Threading.CdsSyncEtwBCLProvider`; }
        });
        
        $asm.$cls("$st.System.Threading.BarrierPostPhaseException", ($self) => class BarrierPostPhaseException extends $.$$.System.Exception
        {
            $ctor$5()
            {
                this.$ctor$9(null);
                {
                }
                return this;
            }
            $ctor$6(/*Exception?*/ innerException)
            {
                this.$ctor$8(null, innerException);
                {
                }
                return this;
            }
            $ctor$9(/*string?*/ message)
            {
                this.$ctor$8(message, null);
                {
                }
                return this;
            }
            $ctor$8(/*string?*/ message, /*Exception?*/ innerException)
            {
                super.$ctor$3(message === null ? $.$st.System.SR.BarrierPostPhaseException : message, innerException);
                {
                }
                return this;
            }
            $ctor$7(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor$2(info, context);
                {
                }
                return this;
            }
            static $h = 389910;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":47251457,"h":389910}; }
            static get $b() { return $.$$.System.Exception; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Threading.BarrierPostPhaseException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib"))