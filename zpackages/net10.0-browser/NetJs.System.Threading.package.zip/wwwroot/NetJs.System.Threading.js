
(function ($global, $, $spc) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Threading", 
    {"h":51733,"f":"System.Threading","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B99807a3edea449997cda60d38046fed69821a2f6","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Threading","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Threading","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$st.System.Obsoletions", ($self) => class Obsoletions
        {
            /*string*/ static SharedUrlFormat = null;
            /*string*/ static SystemTextEncodingUTF7Message = null;
            /*string*/ static SystemTextEncodingUTF7DiagId = null;
            /*string*/ static PrincipalPermissionAttributeMessage = null;
            /*string*/ static PrincipalPermissionAttributeDiagId = null;
            /*string*/ static CodeAccessSecurityMessage = null;
            /*string*/ static CodeAccessSecurityDiagId = null;
            /*string*/ static ConstrainedExecutionRegionMessage = null;
            /*string*/ static ConstrainedExecutionRegionDiagId = null;
            /*string*/ static GlobalAssemblyCacheMessage = null;
            /*string*/ static GlobalAssemblyCacheDiagId = null;
            /*string*/ static ThreadAbortMessage = null;
            /*string*/ static ThreadResetAbortMessage = null;
            /*string*/ static ThreadAbortDiagId = null;
            /*string*/ static DefaultCryptoAlgorithmsMessage = null;
            /*string*/ static DefaultCryptoAlgorithmsDiagId = null;
            /*string*/ static CreatePdbGeneratorMessage = null;
            /*string*/ static CreatePdbGeneratorDiagId = null;
            /*string*/ static AuthenticationManagerMessage = null;
            /*string*/ static AuthenticationManagerDiagId = null;
            /*string*/ static RemotingApisMessage = null;
            /*string*/ static RemotingApisDiagId = null;
            /*string*/ static BinaryFormatterMessage = null;
            /*string*/ static BinaryFormatterDiagId = null;
            /*string*/ static CodeBaseMessage = null;
            /*string*/ static CodeBaseDiagId = null;
            /*string*/ static EscapeUriStringMessage = null;
            /*string*/ static EscapeUriStringDiagId = null;
            /*string*/ static WebRequestMessage = null;
            /*string*/ static WebRequestDiagId = null;
            /*string*/ static DisablePrivateReflectionAttributeMessage = null;
            /*string*/ static DisablePrivateReflectionAttributeDiagId = null;
            /*string*/ static GetContextInfoMessage = null;
            /*string*/ static GetContextInfoDiagId = null;
            /*string*/ static StrongNameKeyPairMessage = null;
            /*string*/ static StrongNameKeyPairDiagId = null;
            /*string*/ static ReflectionOnlyLoadingMessage = null;
            /*string*/ static ReflectionOnlyLoadingDiagId = null;
            /*string*/ static RuntimeEnvironmentMessage = null;
            /*string*/ static RuntimeEnvironmentDiagId = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesMessage = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesDiagId = null;
            /*string*/ static DerivedCryptographicTypesMessage = null;
            /*string*/ static DerivedCryptographicTypesDiagId = null;
            /*string*/ static RijndaelMessage = null;
            /*string*/ static RijndaelDiagId = null;
            /*string*/ static RNGCryptoServiceProviderMessage = null;
            /*string*/ static RNGCryptoServiceProviderDiagId = null;
            /*string*/ static AppDomainCreateUnloadMessage = null;
            /*string*/ static AppDomainCreateUnloadDiagId = null;
            /*string*/ static SuppressIldasmAttributeMessage = null;
            /*string*/ static SuppressIldasmAttributeDiagId = null;
            /*string*/ static X509CertificateImmutableMessage = null;
            /*string*/ static X509CertificateImmutableDiagId = null;
            /*string*/ static PublicKeyPropertyMessage = null;
            /*string*/ static PublicKeyPropertyDiagId = null;
            /*string*/ static X509CertificatePrivateKeyMessage = null;
            /*string*/ static X509CertificatePrivateKeyDiagId = null;
            /*string*/ static ProduceLegacyHmacValuesMessage = null;
            /*string*/ static ProduceLegacyHmacValuesDiagId = null;
            /*string*/ static UseManagedSha1Message = null;
            /*string*/ static UseManagedSha1DiagId = null;
            /*string*/ static CryptoConfigEncodeOIDMessage = null;
            /*string*/ static CryptoConfigEncodeOIDDiagId = null;
            /*string*/ static CorruptedStateRecoveryMessage = null;
            /*string*/ static CorruptedStateRecoveryDiagId = null;
            /*string*/ static Rfc2898CryptDeriveKeyMessage = null;
            /*string*/ static Rfc2898CryptDeriveKeyDiagId = null;
            /*string*/ static CmsSignerCspParamsCtorMessage = null;
            /*string*/ static CmsSignerCspParamsCtorDiagId = null;
            /*string*/ static SignerInfoCounterSigMessage = null;
            /*string*/ static SignerInfoCounterSigDiagId = null;
            /*string*/ static RegexCompileToAssemblyMessage = null;
            /*string*/ static RegexCompileToAssemblyDiagId = null;
            /*string*/ static AssemblyNameMembersMessage = null;
            /*string*/ static AssemblyNameMembersDiagId = null;
            /*string*/ static SystemDataSerializationFormatBinaryMessage = null;
            /*string*/ static SystemDataSerializationFormatBinaryDiagId = null;
            /*string*/ static TlsVersion10and11Message = null;
            /*string*/ static TlsVersion10and11DiagId = null;
            /*string*/ static EncryptionPolicyMessage = null;
            /*string*/ static EncryptionPolicyDiagId = null;
            /*string*/ static EccXmlExportImportMessage = null;
            /*string*/ static EccXmlExportImportDiagId = null;
            /*string*/ static EcDhPublicKeyBlobMessage = null;
            /*string*/ static EcDhPublicKeyBlobDiagId = null;
            /*string*/ static AssemblyNameCodeBaseMessage = null;
            /*string*/ static AssemblyNameCodeBaseDiagId = null;
            /*string*/ static CryptoStringFactoryMessage = null;
            /*string*/ static CryptoStringFactoryDiagId = null;
            /*string*/ static ControlledExecutionRunMessage = null;
            /*string*/ static ControlledExecutionRunDiagId = null;
            /*string*/ static XmlSecureResolverMessage = null;
            /*string*/ static XmlSecureResolverDiagId = null;
            /*string*/ static RsaEncryptDecryptValueMessage = null;
            /*string*/ static RsaEncryptDecryptDiagId = null;
            /*string*/ static JsonSerializerOptionsAddContextMessage = null;
            /*string*/ static JsonSerializerOptionsAddContextDiagId = null;
            /*string*/ static LegacyFormatterMessage = null;
            /*string*/ static LegacyFormatterDiagId = null;
            /*string*/ static LegacyFormatterImplMessage = null;
            /*string*/ static LegacyFormatterImplDiagId = null;
            /*string*/ static RegexExtensibilityImplMessage = null;
            /*string*/ static RegexExtensibilityDiagId = null;
            /*string*/ static AesGcmTagConstructorMessage = null;
            /*string*/ static AesGcmTagConstructorDiagId = null;
            /*string*/ static ThreadVolatileReadWriteMessage = null;
            /*string*/ static ThreadVolatileReadWriteDiagId = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationMessage = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationDiagId = null;
            /*string*/ static LoadFromHashAlgorithmMessage = null;
            /*string*/ static LoadFromHashAlgorithmDiagId = null;
            /*string*/ static X509CtorCertDataObsoleteMessage = null;
            /*string*/ static X509CtorCertDataObsoleteDiagId = null;
            /*string*/ static TlsCipherAlgorithmEnumsMessage = null;
            /*string*/ static TlsCipherAlgorithmEnumsDiagId = null;
            /*string*/ static SystemEventsEventsThreadShutdownMessage = null;
            /*string*/ static SystemEventsEventsThreadShutdownDiagId = null;
            /*string*/ static Rfc2898DeriveBytesCtorMessage = null;
            /*string*/ static Rfc2898DeriveBytesCtorDiagId = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteMessage = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteDiagId = null;
            /*string*/ static XsltSettingsEnableScriptMessage = null;
            /*string*/ static XsltSettingsEnableScriptDiagId = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                }
                {
                    this.SystemTextEncodingUTF7Message = "The UTF-7 encoding is insecure and should not be used. Consider using UTF-8 instead.";
                }
                {
                    this.SystemTextEncodingUTF7DiagId = "SYSLIB0001";
                }
                {
                    this.PrincipalPermissionAttributeMessage = "PrincipalPermissionAttribute is not honored by the runtime and must not be used.";
                }
                {
                    this.PrincipalPermissionAttributeDiagId = "SYSLIB0002";
                }
                {
                    this.CodeAccessSecurityMessage = "Code Access Security is not supported or honored by the runtime.";
                }
                {
                    this.CodeAccessSecurityDiagId = "SYSLIB0003";
                }
                {
                    this.ConstrainedExecutionRegionMessage = "The Constrained Execution Region (CER) feature is not supported.";
                }
                {
                    this.ConstrainedExecutionRegionDiagId = "SYSLIB0004";
                }
                {
                    this.GlobalAssemblyCacheMessage = "The Global Assembly Cache is not supported.";
                }
                {
                    this.GlobalAssemblyCacheDiagId = "SYSLIB0005";
                }
                {
                    this.ThreadAbortMessage = "Thread.Abort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadResetAbortMessage = "Thread.ResetAbort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadAbortDiagId = "SYSLIB0006";
                }
                {
                    this.DefaultCryptoAlgorithmsMessage = "The default implementation of this cryptography algorithm is not supported.";
                }
                {
                    this.DefaultCryptoAlgorithmsDiagId = "SYSLIB0007";
                }
                {
                    this.CreatePdbGeneratorMessage = "The CreatePdbGenerator API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.CreatePdbGeneratorDiagId = "SYSLIB0008";
                }
                {
                    this.AuthenticationManagerMessage = "AuthenticationManager is not supported. Methods will no-op or throw PlatformNotSupportedException.";
                }
                {
                    this.AuthenticationManagerDiagId = "SYSLIB0009";
                }
                {
                    this.RemotingApisMessage = "This Remoting API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.RemotingApisDiagId = "SYSLIB0010";
                }
                {
                    this.BinaryFormatterMessage = "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.";
                }
                {
                    this.BinaryFormatterDiagId = "SYSLIB0011";
                }
                {
                    this.CodeBaseMessage = "Assembly.CodeBase and Assembly.EscapedCodeBase are only included for .NET Framework compatibility. Use Assembly.Location instead.";
                }
                {
                    this.CodeBaseDiagId = "SYSLIB0012";
                }
                {
                    this.EscapeUriStringMessage = "Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.";
                }
                {
                    this.EscapeUriStringDiagId = "SYSLIB0013";
                }
                {
                    this.WebRequestMessage = "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.";
                }
                {
                    this.WebRequestDiagId = "SYSLIB0014";
                }
                {
                    this.DisablePrivateReflectionAttributeMessage = "DisablePrivateReflectionAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.DisablePrivateReflectionAttributeDiagId = "SYSLIB0015";
                }
                {
                    this.GetContextInfoMessage = "Use the Graphics.GetContextInfo overloads that accept arguments for better performance and fewer allocations.";
                }
                {
                    this.GetContextInfoDiagId = "SYSLIB0016";
                }
                {
                    this.StrongNameKeyPairMessage = "Strong name signing is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.StrongNameKeyPairDiagId = "SYSLIB0017";
                }
                {
                    this.ReflectionOnlyLoadingMessage = "ReflectionOnly loading is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ReflectionOnlyLoadingDiagId = "SYSLIB0018";
                }
                {
                    this.RuntimeEnvironmentMessage = "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.";
                }
                {
                    this.RuntimeEnvironmentDiagId = "SYSLIB0019";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesMessage = "JsonSerializerOptions.IgnoreNullValues is obsolete. To ignore null values when serializing, set DefaultIgnoreCondition to JsonIgnoreCondition.WhenWritingNull.";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesDiagId = "SYSLIB0020";
                }
                {
                    this.DerivedCryptographicTypesMessage = "Derived cryptographic types are obsolete. Use the Create method on the base type instead.";
                }
                {
                    this.DerivedCryptographicTypesDiagId = "SYSLIB0021";
                }
                {
                    this.RijndaelMessage = "The Rijndael and RijndaelManaged types are obsolete. Use Aes instead.";
                }
                {
                    this.RijndaelDiagId = "SYSLIB0022";
                }
                {
                    this.RNGCryptoServiceProviderMessage = "RNGCryptoServiceProvider is obsolete. To generate a random number, use one of the RandomNumberGenerator static methods instead.";
                }
                {
                    this.RNGCryptoServiceProviderDiagId = "SYSLIB0023";
                }
                {
                    this.AppDomainCreateUnloadMessage = "Creating and unloading AppDomains is not supported and throws an exception.";
                }
                {
                    this.AppDomainCreateUnloadDiagId = "SYSLIB0024";
                }
                {
                    this.SuppressIldasmAttributeMessage = "SuppressIldasmAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.SuppressIldasmAttributeDiagId = "SYSLIB0025";
                }
                {
                    this.X509CertificateImmutableMessage = "X509Certificate and X509Certificate2 are immutable. Use X509CertificateLoader to create a new certificate.";
                }
                {
                    this.X509CertificateImmutableDiagId = "SYSLIB0026";
                }
                {
                    this.PublicKeyPropertyMessage = "PublicKey.Key is obsolete. Use the appropriate method to get the public key, such as GetRSAPublicKey.";
                }
                {
                    this.PublicKeyPropertyDiagId = "SYSLIB0027";
                }
                {
                    this.X509CertificatePrivateKeyMessage = "X509Certificate2.PrivateKey is obsolete. Use the appropriate method to get the private key, such as GetRSAPrivateKey, or use the CopyWithPrivateKey method to create a new instance with a private key.";
                }
                {
                    this.X509CertificatePrivateKeyDiagId = "SYSLIB0028";
                }
                {
                    this.ProduceLegacyHmacValuesMessage = "ProduceLegacyHmacValues is obsolete. Producing legacy HMAC values is not supported.";
                }
                {
                    this.ProduceLegacyHmacValuesDiagId = "SYSLIB0029";
                }
                {
                    this.UseManagedSha1Message = "HMACSHA1 always uses the algorithm implementation provided by the platform. Use a constructor without the useManagedSha1 parameter.";
                }
                {
                    this.UseManagedSha1DiagId = "SYSLIB0030";
                }
                {
                    this.CryptoConfigEncodeOIDMessage = "EncodeOID is obsolete. Use the ASN.1 functionality provided in System.Formats.Asn1.";
                }
                {
                    this.CryptoConfigEncodeOIDDiagId = "SYSLIB0031";
                }
                {
                    this.CorruptedStateRecoveryMessage = "Recovery from corrupted process state exceptions is not supported; HandleProcessCorruptedStateExceptionsAttribute is ignored.";
                }
                {
                    this.CorruptedStateRecoveryDiagId = "SYSLIB0032";
                }
                {
                    this.Rfc2898CryptDeriveKeyMessage = "Rfc2898DeriveBytes.CryptDeriveKey is obsolete and is not supported. Use PasswordDeriveBytes.CryptDeriveKey instead.";
                }
                {
                    this.Rfc2898CryptDeriveKeyDiagId = "SYSLIB0033";
                }
                {
                    this.CmsSignerCspParamsCtorMessage = "CmsSigner(CspParameters) is obsolete and is not supported. Use an alternative constructor instead.";
                }
                {
                    this.CmsSignerCspParamsCtorDiagId = "SYSLIB0034";
                }
                {
                    this.SignerInfoCounterSigMessage = "ComputeCounterSignature without specifying a CmsSigner is obsolete and is not supported. Use the overload that accepts a CmsSigner.";
                }
                {
                    this.SignerInfoCounterSigDiagId = "SYSLIB0035";
                }
                {
                    this.RegexCompileToAssemblyMessage = "Regex.CompileToAssembly is obsolete and not supported. Use the GeneratedRegexAttribute with the regular expression source generator instead.";
                }
                {
                    this.RegexCompileToAssemblyDiagId = "SYSLIB0036";
                }
                {
                    this.AssemblyNameMembersMessage = "AssemblyName members HashAlgorithm, ProcessorArchitecture, and VersionCompatibility are obsolete and not supported.";
                }
                {
                    this.AssemblyNameMembersDiagId = "SYSLIB0037";
                }
                {
                    this.SystemDataSerializationFormatBinaryMessage = "SerializationFormat.Binary is obsolete and should not be used. See https://aka.ms/serializationformat-binary-obsolete for more information.";
                }
                {
                    this.SystemDataSerializationFormatBinaryDiagId = "SYSLIB0038";
                }
                {
                    this.TlsVersion10and11Message = "TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.";
                }
                {
                    this.TlsVersion10and11DiagId = "SYSLIB0039";
                }
                {
                    this.EncryptionPolicyMessage = "EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.";
                }
                {
                    this.EncryptionPolicyDiagId = "SYSLIB0040";
                }
                {
                    this.EccXmlExportImportMessage = "ToXmlString and FromXmlString have no implementation for ECC types, and are obsolete. Use a standard import and export format such as ExportSubjectPublicKeyInfo or ImportSubjectPublicKeyInfo for public keys and ExportPkcs8PrivateKey or ImportPkcs8PrivateKey for private keys.";
                }
                {
                    this.EccXmlExportImportDiagId = "SYSLIB0042";
                }
                {
                    this.EcDhPublicKeyBlobMessage = "ECDiffieHellmanPublicKey.ToByteArray() and the associated constructor do not have a consistent and interoperable implementation on all platforms. Use ECDiffieHellmanPublicKey.ExportSubjectPublicKeyInfo() instead.";
                }
                {
                    this.EcDhPublicKeyBlobDiagId = "SYSLIB0043";
                }
                {
                    this.AssemblyNameCodeBaseMessage = "AssemblyName.CodeBase and AssemblyName.EscapedCodeBase are obsolete. Using them for loading an assembly is not supported.";
                }
                {
                    this.AssemblyNameCodeBaseDiagId = "SYSLIB0044";
                }
                {
                    this.CryptoStringFactoryMessage = "Cryptographic factory methods accepting an algorithm name are obsolete. Use the parameterless Create factory method on the algorithm type instead.";
                }
                {
                    this.CryptoStringFactoryDiagId = "SYSLIB0045";
                }
                {
                    this.ControlledExecutionRunMessage = "ControlledExecution.Run method may corrupt the process and should not be used in production code.";
                }
                {
                    this.ControlledExecutionRunDiagId = "SYSLIB0046";
                }
                {
                    this.XmlSecureResolverMessage = "XmlSecureResolver is obsolete. Use XmlResolver.ThrowingResolver instead when attempting to forbid XML external entity resolution.";
                }
                {
                    this.XmlSecureResolverDiagId = "SYSLIB0047";
                }
                {
                    this.RsaEncryptDecryptValueMessage = "RSA.EncryptValue and DecryptValue are not supported and throw NotSupportedException. Use RSA.Encrypt and RSA.Decrypt instead.";
                }
                {
                    this.RsaEncryptDecryptDiagId = "SYSLIB0048";
                }
                {
                    this.JsonSerializerOptionsAddContextMessage = "JsonSerializerOptions.AddContext is obsolete. To register a JsonSerializerContext, use either the TypeInfoResolver or TypeInfoResolverChain properties.";
                }
                {
                    this.JsonSerializerOptionsAddContextDiagId = "SYSLIB0049";
                }
                {
                    this.LegacyFormatterMessage = "Formatter-based serialization is obsolete and should not be used.";
                }
                {
                    this.LegacyFormatterDiagId = "SYSLIB0050";
                }
                {
                    this.LegacyFormatterImplMessage = "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.";
                }
                {
                    this.LegacyFormatterImplDiagId = "SYSLIB0051";
                }
                {
                    this.RegexExtensibilityImplMessage = "This API supports obsolete mechanisms for Regex extensibility. It is not supported.";
                }
                {
                    this.RegexExtensibilityDiagId = "SYSLIB0052";
                }
                {
                    this.AesGcmTagConstructorMessage = "AesGcm should indicate the required tag size for encryption and decryption. Use a constructor that accepts the tag size.";
                }
                {
                    this.AesGcmTagConstructorDiagId = "SYSLIB0053";
                }
                {
                    this.ThreadVolatileReadWriteMessage = "Thread.VolatileRead and Thread.VolatileWrite are obsolete. Use Volatile.Read or Volatile.Write respectively instead.";
                }
                {
                    this.ThreadVolatileReadWriteDiagId = "SYSLIB0054";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationMessage = "The underlying hardware instruction does not perform a signed saturate narrowing operation, and it always returns an unsigned result. Use the unsigned overload instead.";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationDiagId = "SYSLIB0055";
                }
                {
                    this.LoadFromHashAlgorithmMessage = "LoadFrom with a custom AssemblyHashAlgorithm is obsolete. Use overloads without an AssemblyHashAlgorithm.";
                }
                {
                    this.LoadFromHashAlgorithmDiagId = "SYSLIB0056";
                }
                {
                    this.X509CtorCertDataObsoleteMessage = "Loading certificate data through the constructor or Import is obsolete. Use X509CertificateLoader instead to load certificates.";
                }
                {
                    this.X509CtorCertDataObsoleteDiagId = "SYSLIB0057";
                }
                {
                    this.TlsCipherAlgorithmEnumsMessage = "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.";
                }
                {
                    this.TlsCipherAlgorithmEnumsDiagId = "SYSLIB0058";
                }
                {
                    this.SystemEventsEventsThreadShutdownMessage = "SystemEvents.EventsThreadShutdown callbacks are not run before the process exits. Use AppDomain.ProcessExit instead.";
                }
                {
                    this.SystemEventsEventsThreadShutdownDiagId = "SYSLIB0059";
                }
                {
                    this.Rfc2898DeriveBytesCtorMessage = "The constructors on Rfc2898DeriveBytes are obsolete. Use the static Pbkdf2 method instead.";
                }
                {
                    this.Rfc2898DeriveBytesCtorDiagId = "SYSLIB0060";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteMessage = "The Queryable MinBy and MaxBy taking an IComparer<TSource> are obsolete. Use the new ones that take an IComparer<TKey>.";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteDiagId = "SYSLIB0061";
                }
                {
                    this.XsltSettingsEnableScriptMessage = "XSLT Script blocks are not supported.";
                }
                {
                    this.XsltSettingsEnableScriptDiagId = "SYSLIB0062";
                }
            }
            static $h = 182805;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"SharedUrlFormat","d":182805,"h":4295150101,"f":40},{"t":1310721,"n":"SystemTextEncodingUTF7Message","d":182805,"h":8590117397,"f":40},{"t":1310721,"n":"SystemTextEncodingUTF7DiagId","d":182805,"h":12885084693,"f":40},{"t":1310721,"n":"PrincipalPermissionAttributeMessage","d":182805,"h":17180051989,"f":40},{"t":1310721,"n":"PrincipalPermissionAttributeDiagId","d":182805,"h":21475019285,"f":40},{"t":1310721,"n":"CodeAccessSecurityMessage","d":182805,"h":25769986581,"f":40},{"t":1310721,"n":"CodeAccessSecurityDiagId","d":182805,"h":30064953877,"f":40},{"t":1310721,"n":"ConstrainedExecutionRegionMessage","d":182805,"h":34359921173,"f":40},{"t":1310721,"n":"ConstrainedExecutionRegionDiagId","d":182805,"h":38654888469,"f":40},{"t":1310721,"n":"GlobalAssemblyCacheMessage","d":182805,"h":42949855765,"f":40},{"t":1310721,"n":"GlobalAssemblyCacheDiagId","d":182805,"h":47244823061,"f":40},{"t":1310721,"n":"ThreadAbortMessage","d":182805,"h":51539790357,"f":40},{"t":1310721,"n":"ThreadResetAbortMessage","d":182805,"h":55834757653,"f":40},{"t":1310721,"n":"ThreadAbortDiagId","d":182805,"h":60129724949,"f":40},{"t":1310721,"n":"DefaultCryptoAlgorithmsMessage","d":182805,"h":64424692245,"f":40},{"t":1310721,"n":"DefaultCryptoAlgorithmsDiagId","d":182805,"h":68719659541,"f":40},{"t":1310721,"n":"CreatePdbGeneratorMessage","d":182805,"h":73014626837,"f":40},{"t":1310721,"n":"CreatePdbGeneratorDiagId","d":182805,"h":77309594133,"f":40},{"t":1310721,"n":"AuthenticationManagerMessage","d":182805,"h":81604561429,"f":40},{"t":1310721,"n":"AuthenticationManagerDiagId","d":182805,"h":85899528725,"f":40},{"t":1310721,"n":"RemotingApisMessage","d":182805,"h":90194496021,"f":40},{"t":1310721,"n":"RemotingApisDiagId","d":182805,"h":94489463317,"f":40},{"t":1310721,"n":"BinaryFormatterMessage","d":182805,"h":98784430613,"f":40},{"t":1310721,"n":"BinaryFormatterDiagId","d":182805,"h":103079397909,"f":40},{"t":1310721,"n":"CodeBaseMessage","d":182805,"h":107374365205,"f":40},{"t":1310721,"n":"CodeBaseDiagId","d":182805,"h":111669332501,"f":40},{"t":1310721,"n":"EscapeUriStringMessage","d":182805,"h":115964299797,"f":40},{"t":1310721,"n":"EscapeUriStringDiagId","d":182805,"h":120259267093,"f":40},{"t":1310721,"n":"WebRequestMessage","d":182805,"h":124554234389,"f":40},{"t":1310721,"n":"WebRequestDiagId","d":182805,"h":128849201685,"f":40},{"t":1310721,"n":"DisablePrivateReflectionAttributeMessage","d":182805,"h":133144168981,"f":40},{"t":1310721,"n":"DisablePrivateReflectionAttributeDiagId","d":182805,"h":137439136277,"f":40},{"t":1310721,"n":"GetContextInfoMessage","d":182805,"h":141734103573,"f":40},{"t":1310721,"n":"GetContextInfoDiagId","d":182805,"h":146029070869,"f":40},{"t":1310721,"n":"StrongNameKeyPairMessage","d":182805,"h":150324038165,"f":40},{"t":1310721,"n":"StrongNameKeyPairDiagId","d":182805,"h":154619005461,"f":40},{"t":1310721,"n":"ReflectionOnlyLoadingMessage","d":182805,"h":158913972757,"f":40},{"t":1310721,"n":"ReflectionOnlyLoadingDiagId","d":182805,"h":163208940053,"f":40},{"t":1310721,"n":"RuntimeEnvironmentMessage","d":182805,"h":167503907349,"f":40},{"t":1310721,"n":"RuntimeEnvironmentDiagId","d":182805,"h":171798874645,"f":40},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesMessage","d":182805,"h":176093841941,"f":40},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesDiagId","d":182805,"h":180388809237,"f":40},{"t":1310721,"n":"DerivedCryptographicTypesMessage","d":182805,"h":184683776533,"f":40},{"t":1310721,"n":"DerivedCryptographicTypesDiagId","d":182805,"h":188978743829,"f":40},{"t":1310721,"n":"RijndaelMessage","d":182805,"h":193273711125,"f":40},{"t":1310721,"n":"RijndaelDiagId","d":182805,"h":197568678421,"f":40},{"t":1310721,"n":"RNGCryptoServiceProviderMessage","d":182805,"h":201863645717,"f":40},{"t":1310721,"n":"RNGCryptoServiceProviderDiagId","d":182805,"h":206158613013,"f":40},{"t":1310721,"n":"AppDomainCreateUnloadMessage","d":182805,"h":210453580309,"f":40},{"t":1310721,"n":"AppDomainCreateUnloadDiagId","d":182805,"h":214748547605,"f":40},{"t":1310721,"n":"SuppressIldasmAttributeMessage","d":182805,"h":219043514901,"f":40},{"t":1310721,"n":"SuppressIldasmAttributeDiagId","d":182805,"h":223338482197,"f":40},{"t":1310721,"n":"X509CertificateImmutableMessage","d":182805,"h":227633449493,"f":40},{"t":1310721,"n":"X509CertificateImmutableDiagId","d":182805,"h":231928416789,"f":40},{"t":1310721,"n":"PublicKeyPropertyMessage","d":182805,"h":236223384085,"f":40},{"t":1310721,"n":"PublicKeyPropertyDiagId","d":182805,"h":240518351381,"f":40},{"t":1310721,"n":"X509CertificatePrivateKeyMessage","d":182805,"h":244813318677,"f":40},{"t":1310721,"n":"X509CertificatePrivateKeyDiagId","d":182805,"h":249108285973,"f":40},{"t":1310721,"n":"ProduceLegacyHmacValuesMessage","d":182805,"h":253403253269,"f":40},{"t":1310721,"n":"ProduceLegacyHmacValuesDiagId","d":182805,"h":257698220565,"f":40},{"t":1310721,"n":"UseManagedSha1Message","d":182805,"h":261993187861,"f":40},{"t":1310721,"n":"UseManagedSha1DiagId","d":182805,"h":266288155157,"f":40},{"t":1310721,"n":"CryptoConfigEncodeOIDMessage","d":182805,"h":270583122453,"f":40},{"t":1310721,"n":"CryptoConfigEncodeOIDDiagId","d":182805,"h":274878089749,"f":40},{"t":1310721,"n":"CorruptedStateRecoveryMessage","d":182805,"h":279173057045,"f":40},{"t":1310721,"n":"CorruptedStateRecoveryDiagId","d":182805,"h":283468024341,"f":40},{"t":1310721,"n":"Rfc2898CryptDeriveKeyMessage","d":182805,"h":287762991637,"f":40},{"t":1310721,"n":"Rfc2898CryptDeriveKeyDiagId","d":182805,"h":292057958933,"f":40},{"t":1310721,"n":"CmsSignerCspParamsCtorMessage","d":182805,"h":296352926229,"f":40},{"t":1310721,"n":"CmsSignerCspParamsCtorDiagId","d":182805,"h":300647893525,"f":40},{"t":1310721,"n":"SignerInfoCounterSigMessage","d":182805,"h":304942860821,"f":40},{"t":1310721,"n":"SignerInfoCounterSigDiagId","d":182805,"h":309237828117,"f":40},{"t":1310721,"n":"RegexCompileToAssemblyMessage","d":182805,"h":313532795413,"f":40},{"t":1310721,"n":"RegexCompileToAssemblyDiagId","d":182805,"h":317827762709,"f":40},{"t":1310721,"n":"AssemblyNameMembersMessage","d":182805,"h":322122730005,"f":40},{"t":1310721,"n":"AssemblyNameMembersDiagId","d":182805,"h":326417697301,"f":40},{"t":1310721,"n":"SystemDataSerializationFormatBinaryMessage","d":182805,"h":330712664597,"f":40},{"t":1310721,"n":"SystemDataSerializationFormatBinaryDiagId","d":182805,"h":335007631893,"f":40},{"t":1310721,"n":"TlsVersion10and11Message","d":182805,"h":339302599189,"f":40},{"t":1310721,"n":"TlsVersion10and11DiagId","d":182805,"h":343597566485,"f":40},{"t":1310721,"n":"EncryptionPolicyMessage","d":182805,"h":347892533781,"f":40},{"t":1310721,"n":"EncryptionPolicyDiagId","d":182805,"h":352187501077,"f":40},{"t":1310721,"n":"EccXmlExportImportMessage","d":182805,"h":356482468373,"f":40},{"t":1310721,"n":"EccXmlExportImportDiagId","d":182805,"h":360777435669,"f":40},{"t":1310721,"n":"EcDhPublicKeyBlobMessage","d":182805,"h":365072402965,"f":40},{"t":1310721,"n":"EcDhPublicKeyBlobDiagId","d":182805,"h":369367370261,"f":40},{"t":1310721,"n":"AssemblyNameCodeBaseMessage","d":182805,"h":373662337557,"f":40},{"t":1310721,"n":"AssemblyNameCodeBaseDiagId","d":182805,"h":377957304853,"f":40},{"t":1310721,"n":"CryptoStringFactoryMessage","d":182805,"h":382252272149,"f":40},{"t":1310721,"n":"CryptoStringFactoryDiagId","d":182805,"h":386547239445,"f":40},{"t":1310721,"n":"ControlledExecutionRunMessage","d":182805,"h":390842206741,"f":40},{"t":1310721,"n":"ControlledExecutionRunDiagId","d":182805,"h":395137174037,"f":40},{"t":1310721,"n":"XmlSecureResolverMessage","d":182805,"h":399432141333,"f":40},{"t":1310721,"n":"XmlSecureResolverDiagId","d":182805,"h":403727108629,"f":40},{"t":1310721,"n":"RsaEncryptDecryptValueMessage","d":182805,"h":408022075925,"f":40},{"t":1310721,"n":"RsaEncryptDecryptDiagId","d":182805,"h":412317043221,"f":40},{"t":1310721,"n":"JsonSerializerOptionsAddContextMessage","d":182805,"h":416612010517,"f":40},{"t":1310721,"n":"JsonSerializerOptionsAddContextDiagId","d":182805,"h":420906977813,"f":40},{"t":1310721,"n":"LegacyFormatterMessage","d":182805,"h":425201945109,"f":40},{"t":1310721,"n":"LegacyFormatterDiagId","d":182805,"h":429496912405,"f":40},{"t":1310721,"n":"LegacyFormatterImplMessage","d":182805,"h":433791879701,"f":40},{"t":1310721,"n":"LegacyFormatterImplDiagId","d":182805,"h":438086846997,"f":40},{"t":1310721,"n":"RegexExtensibilityImplMessage","d":182805,"h":442381814293,"f":40},{"t":1310721,"n":"RegexExtensibilityDiagId","d":182805,"h":446676781589,"f":40},{"t":1310721,"n":"AesGcmTagConstructorMessage","d":182805,"h":450971748885,"f":40},{"t":1310721,"n":"AesGcmTagConstructorDiagId","d":182805,"h":455266716181,"f":40},{"t":1310721,"n":"ThreadVolatileReadWriteMessage","d":182805,"h":459561683477,"f":40},{"t":1310721,"n":"ThreadVolatileReadWriteDiagId","d":182805,"h":463856650773,"f":40},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationMessage","d":182805,"h":468151618069,"f":40},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationDiagId","d":182805,"h":472446585365,"f":40},{"t":1310721,"n":"LoadFromHashAlgorithmMessage","d":182805,"h":476741552661,"f":40},{"t":1310721,"n":"LoadFromHashAlgorithmDiagId","d":182805,"h":481036519957,"f":40},{"t":1310721,"n":"X509CtorCertDataObsoleteMessage","d":182805,"h":485331487253,"f":40},{"t":1310721,"n":"X509CtorCertDataObsoleteDiagId","d":182805,"h":489626454549,"f":40},{"t":1310721,"n":"TlsCipherAlgorithmEnumsMessage","d":182805,"h":493921421845,"f":40},{"t":1310721,"n":"TlsCipherAlgorithmEnumsDiagId","d":182805,"h":498216389141,"f":40},{"t":1310721,"n":"SystemEventsEventsThreadShutdownMessage","d":182805,"h":502511356437,"f":40},{"t":1310721,"n":"SystemEventsEventsThreadShutdownDiagId","d":182805,"h":506806323733,"f":40},{"t":1310721,"n":"Rfc2898DeriveBytesCtorMessage","d":182805,"h":511101291029,"f":40},{"t":1310721,"n":"Rfc2898DeriveBytesCtorDiagId","d":182805,"h":515396258325,"f":40},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteMessage","d":182805,"h":519691225621,"f":40},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteDiagId","d":182805,"h":523986192917,"f":40},{"t":1310721,"n":"XsltSettingsEnableScriptMessage","d":182805,"h":528281160213,"f":40},{"t":1310721,"n":"XsltSettingsEnableScriptDiagId","d":182805,"h":532576127509,"f":40}],"h":182805}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Obsoletions`; }
        });
        
        $asm.$cls("$st.System.HResults", ($self) => class HResults
        {
            /*int*/ static S_OK = 0;
            /*int*/ static S_FALSE = 1;
            /*int*/ static COR_E_ABANDONEDMUTEX = -2146233043;
            /*int*/ static COR_E_AMBIGUOUSIMPLEMENTATION = -2146234262;
            /*int*/ static COR_E_AMBIGUOUSMATCH = -2147475171;
            /*int*/ static COR_E_APPDOMAINUNLOADED = -2146234348;
            /*int*/ static COR_E_APPLICATION = -2146232832;
            /*int*/ static COR_E_ARGUMENT = -2147024809;
            /*int*/ static COR_E_ARGUMENTOUTOFRANGE = -2146233086;
            /*int*/ static COR_E_ARITHMETIC = -2147024362;
            /*int*/ static COR_E_ARRAYTYPEMISMATCH = -2146233085;
            /*int*/ static COR_E_BADEXEFORMAT = -2147024703;
            /*int*/ static COR_E_BADIMAGEFORMAT = -2147024885;
            /*int*/ static COR_E_CANNOTUNLOADAPPDOMAIN = -2146234347;
            /*int*/ static COR_E_CODECONTRACTFAILED = -2146233022;
            /*int*/ static COR_E_CONTEXTMARSHAL = -2146233084;
            /*int*/ static COR_E_CUSTOMATTRIBUTEFORMAT = -2146232827;
            /*int*/ static COR_E_DATAMISALIGNED = -2146233023;
            /*int*/ static COR_E_DIRECTORYNOTFOUND = -2147024893;
            /*int*/ static COR_E_DIVIDEBYZERO = -2147352558;
            /*int*/ static COR_E_DLLNOTFOUND = -2146233052;
            /*int*/ static COR_E_DUPLICATEWAITOBJECT = -2146233047;
            /*int*/ static COR_E_ENDOFSTREAM = -2147024858;
            /*int*/ static COR_E_ENTRYPOINTNOTFOUND = -2146233053;
            /*int*/ static COR_E_EXCEPTION = -2146233088;
            /*int*/ static COR_E_EXECUTIONENGINE = -2146233082;
            /*int*/ static COR_E_FAILFAST = -2146232797;
            /*int*/ static COR_E_FIELDACCESS = -2146233081;
            /*int*/ static COR_E_FILELOAD = -2146232799;
            /*int*/ static COR_E_FILENOTFOUND = -2147024894;
            /*int*/ static COR_E_FORMAT = -2146233033;
            /*int*/ static COR_E_INDEXOUTOFRANGE = -2146233080;
            /*int*/ static COR_E_INSUFFICIENTEXECUTIONSTACK = -2146232968;
            /*int*/ static COR_E_INSUFFICIENTMEMORY = -2146233027;
            /*int*/ static COR_E_INVALIDCAST = -2147467262;
            /*int*/ static COR_E_INVALIDCOMOBJECT = -2146233049;
            /*int*/ static COR_E_INVALIDFILTERCRITERIA = -2146232831;
            /*int*/ static COR_E_INVALIDOLEVARIANTTYPE = -2146233039;
            /*int*/ static COR_E_INVALIDOPERATION = -2146233079;
            /*int*/ static COR_E_INVALIDPROGRAM = -2146233030;
            /*int*/ static COR_E_IO = -2146232800;
            /*int*/ static COR_E_KEYNOTFOUND = -2146232969;
            /*int*/ static COR_E_MARSHALDIRECTIVE = -2146233035;
            /*int*/ static COR_E_MEMBERACCESS = -2146233062;
            /*int*/ static COR_E_METHODACCESS = -2146233072;
            /*int*/ static COR_E_MISSINGFIELD = -2146233071;
            /*int*/ static COR_E_MISSINGMANIFESTRESOURCE = -2146233038;
            /*int*/ static COR_E_MISSINGMEMBER = -2146233070;
            /*int*/ static COR_E_MISSINGMETHOD = -2146233069;
            /*int*/ static COR_E_MISSINGSATELLITEASSEMBLY = -2146233034;
            /*int*/ static COR_E_MULTICASTNOTSUPPORTED = -2146233068;
            /*int*/ static COR_E_NOTFINITENUMBER = -2146233048;
            /*int*/ static COR_E_NOTSUPPORTED = -2146233067;
            /*int*/ static COR_E_OBJECTDISPOSED = -2146232798;
            /*int*/ static COR_E_OPERATIONCANCELED = -2146233029;
            /*int*/ static COR_E_OUTOFMEMORY = -2147024882;
            /*int*/ static COR_E_OVERFLOW = -2146233066;
            /*int*/ static COR_E_PATHTOOLONG = -2147024690;
            /*int*/ static COR_E_PLATFORMNOTSUPPORTED = -2146233031;
            /*int*/ static COR_E_RANK = -2146233065;
            /*int*/ static COR_E_REFLECTIONTYPELOAD = -2146232830;
            /*int*/ static COR_E_RUNTIMEWRAPPED = -2146233026;
            /*int*/ static COR_E_SAFEARRAYRANKMISMATCH = -2146233032;
            /*int*/ static COR_E_SAFEARRAYTYPEMISMATCH = -2146233037;
            /*int*/ static COR_E_SECURITY = -2146233078;
            /*int*/ static COR_E_SERIALIZATION = -2146233076;
            /*int*/ static COR_E_STACKOVERFLOW = -2147023895;
            /*int*/ static COR_E_SYNCHRONIZATIONLOCK = -2146233064;
            /*int*/ static COR_E_SYSTEM = -2146233087;
            /*int*/ static COR_E_TARGET = -2146232829;
            /*int*/ static COR_E_TARGETINVOCATION = -2146232828;
            /*int*/ static COR_E_TARGETPARAMCOUNT = -2147352562;
            /*int*/ static COR_E_THREADABORTED = -2146233040;
            /*int*/ static COR_E_THREADINTERRUPTED = -2146233063;
            /*int*/ static COR_E_THREADSTART = -2146233051;
            /*int*/ static COR_E_THREADSTATE = -2146233056;
            /*int*/ static COR_E_TIMEOUT = -2146233083;
            /*int*/ static COR_E_TYPEACCESS = -2146233021;
            /*int*/ static COR_E_TYPEINITIALIZATION = -2146233036;
            /*int*/ static COR_E_TYPELOAD = -2146233054;
            /*int*/ static COR_E_TYPEUNLOADED = -2146234349;
            /*int*/ static COR_E_UNAUTHORIZEDACCESS = -2147024891;
            /*int*/ static COR_E_VERIFICATION = -2146233075;
            /*int*/ static COR_E_WAITHANDLECANNOTBEOPENED = -2146233044;
            /*int*/ static CO_E_NOTINITIALIZED = -2147221008;
            /*int*/ static DISP_E_PARAMNOTFOUND = -2147352572;
            /*int*/ static DISP_E_TYPEMISMATCH = -2147352571;
            /*int*/ static DISP_E_BADVARTYPE = -2147352568;
            /*int*/ static DISP_E_OVERFLOW = -2147352566;
            /*int*/ static DISP_E_DIVBYZERO = -2147352558;
            /*int*/ static E_BOUNDS = -2147483637;
            /*int*/ static E_CHANGED_STATE = -2147483636;
            /*int*/ static E_FILENOTFOUND = -2147024894;
            /*int*/ static E_FAIL = -2147467259;
            /*int*/ static E_HANDLE = -2147024890;
            /*int*/ static E_INVALIDARG = -2147024809;
            /*int*/ static E_NOTIMPL = -2147467263;
            /*int*/ static E_OUTOFMEMORY = -2147024882;
            /*int*/ static E_POINTER = -2147467261;
            /*int*/ static ERROR_MRM_MAP_NOT_FOUND = -2147009761;
            /*int*/ static ERROR_TIMEOUT = -2147023436;
            /*int*/ static RO_E_CLOSED = -2147483629;
            /*int*/ static RPC_E_CHANGED_MODE = -2147417850;
            /*int*/ static TYPE_E_TYPEMISMATCH = -2147316576;
            /*int*/ static STG_E_PATHNOTFOUND = -2147287037;
            /*int*/ static CTL_E_PATHNOTFOUND = -2146828212;
            /*int*/ static CTL_E_FILENOTFOUND = -2146828235;
            /*int*/ static FUSION_E_INVALID_NAME = -2146234297;
            /*int*/ static FUSION_E_REF_DEF_MISMATCH = -2146234304;
            /*int*/ static ERROR_TOO_MANY_OPEN_FILES = -2147024892;
            /*int*/ static ERROR_SHARING_VIOLATION = -2147024864;
            /*int*/ static ERROR_LOCK_VIOLATION = -2147024863;
            /*int*/ static ERROR_OPEN_FAILED = -2147024786;
            /*int*/ static ERROR_DISK_CORRUPT = -2147023503;
            /*int*/ static ERROR_UNRECOGNIZED_VOLUME = -2147023891;
            /*int*/ static ERROR_DLL_INIT_FAILED = -2147023782;
            /*int*/ static MSEE_E_ASSEMBLYLOADINPROGRESS = -2146234346;
            /*int*/ static ERROR_FILE_INVALID = -2147023890;
            static $h = 117269;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"S_OK","d":117269,"h":4295084565,"f":40},{"t":655361,"n":"S_FALSE","d":117269,"h":8590051861,"f":40},{"t":655361,"n":"COR_E_ABANDONEDMUTEX","d":117269,"h":12885019157,"f":40},{"t":655361,"n":"COR_E_AMBIGUOUSIMPLEMENTATION","d":117269,"h":17179986453,"f":40},{"t":655361,"n":"COR_E_AMBIGUOUSMATCH","d":117269,"h":21474953749,"f":40},{"t":655361,"n":"COR_E_APPDOMAINUNLOADED","d":117269,"h":25769921045,"f":40},{"t":655361,"n":"COR_E_APPLICATION","d":117269,"h":30064888341,"f":40},{"t":655361,"n":"COR_E_ARGUMENT","d":117269,"h":34359855637,"f":40},{"t":655361,"n":"COR_E_ARGUMENTOUTOFRANGE","d":117269,"h":38654822933,"f":40},{"t":655361,"n":"COR_E_ARITHMETIC","d":117269,"h":42949790229,"f":40},{"t":655361,"n":"COR_E_ARRAYTYPEMISMATCH","d":117269,"h":47244757525,"f":40},{"t":655361,"n":"COR_E_BADEXEFORMAT","d":117269,"h":51539724821,"f":40},{"t":655361,"n":"COR_E_BADIMAGEFORMAT","d":117269,"h":55834692117,"f":40},{"t":655361,"n":"COR_E_CANNOTUNLOADAPPDOMAIN","d":117269,"h":60129659413,"f":40},{"t":655361,"n":"COR_E_CODECONTRACTFAILED","d":117269,"h":64424626709,"f":40},{"t":655361,"n":"COR_E_CONTEXTMARSHAL","d":117269,"h":68719594005,"f":40},{"t":655361,"n":"COR_E_CUSTOMATTRIBUTEFORMAT","d":117269,"h":73014561301,"f":40},{"t":655361,"n":"COR_E_DATAMISALIGNED","d":117269,"h":77309528597,"f":40},{"t":655361,"n":"COR_E_DIRECTORYNOTFOUND","d":117269,"h":81604495893,"f":40},{"t":655361,"n":"COR_E_DIVIDEBYZERO","d":117269,"h":85899463189,"f":40},{"t":655361,"n":"COR_E_DLLNOTFOUND","d":117269,"h":90194430485,"f":40},{"t":655361,"n":"COR_E_DUPLICATEWAITOBJECT","d":117269,"h":94489397781,"f":40},{"t":655361,"n":"COR_E_ENDOFSTREAM","d":117269,"h":98784365077,"f":40},{"t":655361,"n":"COR_E_ENTRYPOINTNOTFOUND","d":117269,"h":103079332373,"f":40},{"t":655361,"n":"COR_E_EXCEPTION","d":117269,"h":107374299669,"f":40},{"t":655361,"n":"COR_E_EXECUTIONENGINE","d":117269,"h":111669266965,"f":40},{"t":655361,"n":"COR_E_FAILFAST","d":117269,"h":115964234261,"f":40},{"t":655361,"n":"COR_E_FIELDACCESS","d":117269,"h":120259201557,"f":40},{"t":655361,"n":"COR_E_FILELOAD","d":117269,"h":124554168853,"f":40},{"t":655361,"n":"COR_E_FILENOTFOUND","d":117269,"h":128849136149,"f":40},{"t":655361,"n":"COR_E_FORMAT","d":117269,"h":133144103445,"f":40},{"t":655361,"n":"COR_E_INDEXOUTOFRANGE","d":117269,"h":137439070741,"f":40},{"t":655361,"n":"COR_E_INSUFFICIENTEXECUTIONSTACK","d":117269,"h":141734038037,"f":40},{"t":655361,"n":"COR_E_INSUFFICIENTMEMORY","d":117269,"h":146029005333,"f":40},{"t":655361,"n":"COR_E_INVALIDCAST","d":117269,"h":150323972629,"f":40},{"t":655361,"n":"COR_E_INVALIDCOMOBJECT","d":117269,"h":154618939925,"f":40},{"t":655361,"n":"COR_E_INVALIDFILTERCRITERIA","d":117269,"h":158913907221,"f":40},{"t":655361,"n":"COR_E_INVALIDOLEVARIANTTYPE","d":117269,"h":163208874517,"f":40},{"t":655361,"n":"COR_E_INVALIDOPERATION","d":117269,"h":167503841813,"f":40},{"t":655361,"n":"COR_E_INVALIDPROGRAM","d":117269,"h":171798809109,"f":40},{"t":655361,"n":"COR_E_IO","d":117269,"h":176093776405,"f":40},{"t":655361,"n":"COR_E_KEYNOTFOUND","d":117269,"h":180388743701,"f":40},{"t":655361,"n":"COR_E_MARSHALDIRECTIVE","d":117269,"h":184683710997,"f":40},{"t":655361,"n":"COR_E_MEMBERACCESS","d":117269,"h":188978678293,"f":40},{"t":655361,"n":"COR_E_METHODACCESS","d":117269,"h":193273645589,"f":40},{"t":655361,"n":"COR_E_MISSINGFIELD","d":117269,"h":197568612885,"f":40},{"t":655361,"n":"COR_E_MISSINGMANIFESTRESOURCE","d":117269,"h":201863580181,"f":40},{"t":655361,"n":"COR_E_MISSINGMEMBER","d":117269,"h":206158547477,"f":40},{"t":655361,"n":"COR_E_MISSINGMETHOD","d":117269,"h":210453514773,"f":40},{"t":655361,"n":"COR_E_MISSINGSATELLITEASSEMBLY","d":117269,"h":214748482069,"f":40},{"t":655361,"n":"COR_E_MULTICASTNOTSUPPORTED","d":117269,"h":219043449365,"f":40},{"t":655361,"n":"COR_E_NOTFINITENUMBER","d":117269,"h":223338416661,"f":40},{"t":655361,"n":"COR_E_NOTSUPPORTED","d":117269,"h":227633383957,"f":40},{"t":655361,"n":"COR_E_OBJECTDISPOSED","d":117269,"h":231928351253,"f":40},{"t":655361,"n":"COR_E_OPERATIONCANCELED","d":117269,"h":236223318549,"f":40},{"t":655361,"n":"COR_E_OUTOFMEMORY","d":117269,"h":240518285845,"f":40},{"t":655361,"n":"COR_E_OVERFLOW","d":117269,"h":244813253141,"f":40},{"t":655361,"n":"COR_E_PATHTOOLONG","d":117269,"h":249108220437,"f":40},{"t":655361,"n":"COR_E_PLATFORMNOTSUPPORTED","d":117269,"h":253403187733,"f":40},{"t":655361,"n":"COR_E_RANK","d":117269,"h":257698155029,"f":40},{"t":655361,"n":"COR_E_REFLECTIONTYPELOAD","d":117269,"h":261993122325,"f":40},{"t":655361,"n":"COR_E_RUNTIMEWRAPPED","d":117269,"h":266288089621,"f":40},{"t":655361,"n":"COR_E_SAFEARRAYRANKMISMATCH","d":117269,"h":270583056917,"f":40},{"t":655361,"n":"COR_E_SAFEARRAYTYPEMISMATCH","d":117269,"h":274878024213,"f":40},{"t":655361,"n":"COR_E_SECURITY","d":117269,"h":279172991509,"f":40},{"t":655361,"n":"COR_E_SERIALIZATION","d":117269,"h":283467958805,"f":40},{"t":655361,"n":"COR_E_STACKOVERFLOW","d":117269,"h":287762926101,"f":40},{"t":655361,"n":"COR_E_SYNCHRONIZATIONLOCK","d":117269,"h":292057893397,"f":40},{"t":655361,"n":"COR_E_SYSTEM","d":117269,"h":296352860693,"f":40},{"t":655361,"n":"COR_E_TARGET","d":117269,"h":300647827989,"f":40},{"t":655361,"n":"COR_E_TARGETINVOCATION","d":117269,"h":304942795285,"f":40},{"t":655361,"n":"COR_E_TARGETPARAMCOUNT","d":117269,"h":309237762581,"f":40},{"t":655361,"n":"COR_E_THREADABORTED","d":117269,"h":313532729877,"f":40},{"t":655361,"n":"COR_E_THREADINTERRUPTED","d":117269,"h":317827697173,"f":40},{"t":655361,"n":"COR_E_THREADSTART","d":117269,"h":322122664469,"f":40},{"t":655361,"n":"COR_E_THREADSTATE","d":117269,"h":326417631765,"f":40},{"t":655361,"n":"COR_E_TIMEOUT","d":117269,"h":330712599061,"f":40},{"t":655361,"n":"COR_E_TYPEACCESS","d":117269,"h":335007566357,"f":40},{"t":655361,"n":"COR_E_TYPEINITIALIZATION","d":117269,"h":339302533653,"f":40},{"t":655361,"n":"COR_E_TYPELOAD","d":117269,"h":343597500949,"f":40},{"t":655361,"n":"COR_E_TYPEUNLOADED","d":117269,"h":347892468245,"f":40},{"t":655361,"n":"COR_E_UNAUTHORIZEDACCESS","d":117269,"h":352187435541,"f":40},{"t":655361,"n":"COR_E_VERIFICATION","d":117269,"h":356482402837,"f":40},{"t":655361,"n":"COR_E_WAITHANDLECANNOTBEOPENED","d":117269,"h":360777370133,"f":40},{"t":655361,"n":"CO_E_NOTINITIALIZED","d":117269,"h":365072337429,"f":40},{"t":655361,"n":"DISP_E_PARAMNOTFOUND","d":117269,"h":369367304725,"f":40},{"t":655361,"n":"DISP_E_TYPEMISMATCH","d":117269,"h":373662272021,"f":40},{"t":655361,"n":"DISP_E_BADVARTYPE","d":117269,"h":377957239317,"f":40},{"t":655361,"n":"DISP_E_OVERFLOW","d":117269,"h":382252206613,"f":40},{"t":655361,"n":"DISP_E_DIVBYZERO","d":117269,"h":386547173909,"f":40},{"t":655361,"n":"E_BOUNDS","d":117269,"h":390842141205,"f":40},{"t":655361,"n":"E_CHANGED_STATE","d":117269,"h":395137108501,"f":40},{"t":655361,"n":"E_FILENOTFOUND","d":117269,"h":399432075797,"f":40},{"t":655361,"n":"E_FAIL","d":117269,"h":403727043093,"f":40},{"t":655361,"n":"E_HANDLE","d":117269,"h":408022010389,"f":40},{"t":655361,"n":"E_INVALIDARG","d":117269,"h":412316977685,"f":40},{"t":655361,"n":"E_NOTIMPL","d":117269,"h":416611944981,"f":40},{"t":655361,"n":"E_OUTOFMEMORY","d":117269,"h":420906912277,"f":40},{"t":655361,"n":"E_POINTER","d":117269,"h":425201879573,"f":40},{"t":655361,"n":"ERROR_MRM_MAP_NOT_FOUND","d":117269,"h":429496846869,"f":40},{"t":655361,"n":"ERROR_TIMEOUT","d":117269,"h":433791814165,"f":40},{"t":655361,"n":"RO_E_CLOSED","d":117269,"h":438086781461,"f":40},{"t":655361,"n":"RPC_E_CHANGED_MODE","d":117269,"h":442381748757,"f":40},{"t":655361,"n":"TYPE_E_TYPEMISMATCH","d":117269,"h":446676716053,"f":40},{"t":655361,"n":"STG_E_PATHNOTFOUND","d":117269,"h":450971683349,"f":40},{"t":655361,"n":"CTL_E_PATHNOTFOUND","d":117269,"h":455266650645,"f":40},{"t":655361,"n":"CTL_E_FILENOTFOUND","d":117269,"h":459561617941,"f":40},{"t":655361,"n":"FUSION_E_INVALID_NAME","d":117269,"h":463856585237,"f":40},{"t":655361,"n":"FUSION_E_REF_DEF_MISMATCH","d":117269,"h":468151552533,"f":40},{"t":655361,"n":"ERROR_TOO_MANY_OPEN_FILES","d":117269,"h":472446519829,"f":40},{"t":655361,"n":"ERROR_SHARING_VIOLATION","d":117269,"h":476741487125,"f":40},{"t":655361,"n":"ERROR_LOCK_VIOLATION","d":117269,"h":481036454421,"f":40},{"t":655361,"n":"ERROR_OPEN_FAILED","d":117269,"h":485331421717,"f":40},{"t":655361,"n":"ERROR_DISK_CORRUPT","d":117269,"h":489626389013,"f":40},{"t":655361,"n":"ERROR_UNRECOGNIZED_VOLUME","d":117269,"h":493921356309,"f":40},{"t":655361,"n":"ERROR_DLL_INIT_FAILED","d":117269,"h":498216323605,"f":40},{"t":655361,"n":"MSEE_E_ASSEMBLYLOADINPROGRESS","d":117269,"h":502511290901,"f":40},{"t":655361,"n":"ERROR_FILE_INVALID","d":117269,"h":506806258197,"f":40}],"h":117269}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.HResults`; }
        });
        
        $asm.$cls("$st.System.Threading.HostExecutionContextManager", ($self) => class HostExecutionContextManager extends $.$spc.System.Object
        {
            /*HostExecutionContext?*/ static t_currentContext = null;
            /*HostExecutionContext? */ Capture()
            {
                return null;
            }
            /*object */ SetHostExecutionContext(/*HostExecutionContext*/ hostExecutionContext)
            {
                if (hostExecutionContext === null)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$st.System.SR.HostExecutionContextManager_InvalidOperation_NotNewCaptureContext);
                }
                /*var*/ let switcher = new $.$st.System.Threading.HostExecutionContextManager.HostExecutionContextSwitcher().$ctor$1(hostExecutionContext);
                $.$st.System.Threading.HostExecutionContextManager.t_currentContext = hostExecutionContext;
                return switcher;
            }
            /*void */ Revert(/*object*/ previousState)
            {
                /*var*/ let switcher = $.$as(previousState, $.$st.System.Threading.HostExecutionContextManager.HostExecutionContextSwitcher);
                if (switcher === null)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$st.System.SR.HostExecutionContextManager_InvalidOperation_CannotOverrideSetWithoutRevert);
                }
                if ($.$st.System.Threading.HostExecutionContextManager.t_currentContext !== switcher._currentContext || switcher._asyncLocal === null || !switcher._asyncLocal.Value)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$st.System.SR.HostExecutionContextManager_InvalidOperation_CannotUseSwitcherOtherThread);
                }
                switcher._asyncLocal = null;
                $.$st.System.Threading.HostExecutionContextManager.t_currentContext = null;
            }
            static $_HostExecutionContextSwitcher;
            static get HostExecutionContextSwitcher()
            {
                let $cls = $.$st.System.Threading.HostExecutionContextManager;
                return $cls.$_HostExecutionContextSwitcher ??= $asm.$ncls("$st.System.Threading.HostExecutionContextManager.HostExecutionContextSwitcher", ($self) => class HostExecutionContextSwitcher extends $.$spc.System.Object
                {
                    /*HostExecutionContext*/ _currentContext = null;
                    /*AsyncLocal<bool>?*/ _asyncLocal = null;
                    $ctor$1(/*HostExecutionContext*/ currentContext)
                    {
                        super.$ctor();
                        {
                            this._currentContext = currentContext;
                            this._asyncLocal = new ($.$spc.System.Threading.AsyncLocal$$($.$spc.System.Boolean))().$ctor$1();
                            this._asyncLocal.Value = true;
                        }
                        return this;
                    }
                    static $h = 707093;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":576021,"n":"_currentContext","d":707093,"h":4295674389,"f":1},{"t":$.$spc.System.Threading.AsyncLocal$$($.$spc.System.Boolean).$h,"n":"_asyncLocal","d":707093,"h":8590641685,"f":1}],"c":[{"p":[{"n":"currentContext","p":576021}],"n":".ctor","o":"$ctor$1","d":707093,"h":12885608981,"f":1}],"d":641557,"h":707093}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Threading.HostExecutionContextManager.HostExecutionContextSwitcher`; }
                }, $cls, ($v) => $cls.$_HostExecutionContextSwitcher = $v);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 641557;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":576021,"n":"Capture","d":641557,"h":8590576149,"f":129},{"r":131073,"p":[{"n":"hostExecutionContext","p":576021}],"n":"SetHostExecutionContext","d":641557,"h":12885543445,"f":129},{"r":65537,"p":[{"n":"previousState","p":131073}],"n":"Revert","d":641557,"h":17180510741,"f":129}],"l":[{"t":576021,"n":"t_currentContext","d":641557,"h":4295608853,"f":34,"a":[{"t":140181505,"c":4435148801}]}],"c":[{"n":".ctor","o":"$ctor$1","d":641557,"h":25770445333,"f":1}],"j":[707093],"h":641557}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Threading.HostExecutionContextManager`; }
        });
        
        $asm.$cls("$st.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$st.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("System.Threading", $.$st.System.SR.$type.Assembly);
                    $.$st.System.SR.s_resourceManager = temp;
                }
                return $.$st.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$st.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$st.System.SR.resourceCulture = value;
            }
            static /*string */ get CountdownEvent_Increment_AlreadyZero()
            {
                return "The event is already signaled and cannot be incremented.";
            }
            static /*string */ get CountdownEvent_Increment_AlreadyMax()
            {
                return "The increment operation would cause the CurrentCount to overflow.";
            }
            static /*string */ get CountdownEvent_Decrement_BelowZero()
            {
                return "Invalid attempt made to decrement the event's count below zero.";
            }
            static /*string */ get Common_OperationCanceled()
            {
                return "The operation was canceled.";
            }
            static /*string */ get Barrier_SignalAndWait_InvalidOperation_ZeroTotal()
            {
                return "The barrier has no registered participants.";
            }
            static /*string */ get Barrier_SignalAndWait_ArgumentOutOfRange()
            {
                return "The specified timeout must represent a value between -1 and Int32.MaxValue, inclusive.";
            }
            static /*string */ get Barrier_RemoveParticipants_InvalidOperation()
            {
                return "The participantCount argument is greater than the number of participants that haven't yet arrived at the barrier in this phase.";
            }
            static /*string */ get Barrier_RemoveParticipants_ArgumentOutOfRange()
            {
                return "The participantCount argument must be less than or equal the number of participants.";
            }
            static /*string */ get Barrier_InvalidOperation_CalledFromPHA()
            {
                return "This method may not be called from within the postPhaseAction.";
            }
            static /*string */ get Barrier_SignalAndWait_InvalidOperation_ThreadsExceeded()
            {
                return "The number of threads using the barrier exceeded the total number of registered participants.";
            }
            static /*string */ get BarrierPostPhaseException()
            {
                return "The postPhaseAction failed with an exception.";
            }
            static /*string */ get Barrier_AddParticipants_Overflow_ArgumentOutOfRange()
            {
                return "Adding participantCount participants would result in the number of participants exceeding the maximum number allowed.";
            }
            static /*string */ get SynchronizationLockException_IncorrectDispose()
            {
                return "The lock is being disposed while still being used. It either is being held by a thread and/or has active waiters waiting to acquire the lock.";
            }
            static /*string */ get SynchronizationLockException_MisMatchedWrite()
            {
                return "The write lock is being released without being held.";
            }
            static /*string */ get LockRecursionException_UpgradeAfterReadNotAllowed()
            {
                return "Upgradeable lock may not be acquired with read lock held.";
            }
            static /*string */ get LockRecursionException_UpgradeAfterWriteNotAllowed()
            {
                return "Upgradeable lock may not be acquired with write lock held in this mode. Acquiring Upgradeable lock gives the ability to read along with an option to upgrade to a writer.";
            }
            static /*string */ get SynchronizationLockException_MisMatchedUpgrade()
            {
                return "The upgradeable lock is being released without being held.";
            }
            static /*string */ get SynchronizationLockException_MisMatchedRead()
            {
                return "The read lock is being released without being held.";
            }
            static /*string */ get LockRecursionException_WriteAfterReadNotAllowed()
            {
                return "Write lock may not be acquired with read lock held. This pattern is prone to deadlocks. Please ensure that read locks are released before taking a write lock. If an upgrade is necessary, use an upgrade lock in place of the read lock.";
            }
            static /*string */ get LockRecursionException_RecursiveWriteNotAllowed()
            {
                return "Recursive write lock acquisitions not allowed in this mode.";
            }
            static /*string */ get LockRecursionException_ReadAfterWriteNotAllowed()
            {
                return "A read lock may not be acquired with the write lock held in this mode.";
            }
            static /*string */ get LockRecursionException_RecursiveUpgradeNotAllowed()
            {
                return "Recursive upgradeable lock acquisitions not allowed in this mode.";
            }
            static /*string */ get LockRecursionException_RecursiveReadNotAllowed()
            {
                return "Recursive read lock acquisitions not allowed in this mode.";
            }
            static /*string */ get Overflow_UInt16()
            {
                return "Value was either too large or too small for a UInt16.";
            }
            static /*string */ get ReaderWriterLock_Timeout()
            {
                return "The operation has timed out. {0}";
            }
            static /*string */ FormatReaderWriterLock_Timeout(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The operation has timed out. {0}", arg1);
            }
            static /*string */ get ReaderWriterLock_NotOwner()
            {
                return "Attempt to release a lock that is not owned by the calling thread. {0}";
            }
            static /*string */ FormatReaderWriterLock_NotOwner(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Attempt to release a lock that is not owned by the calling thread. {0}", arg1);
            }
            static /*string */ get ExceptionFromHResult()
            {
                return "(Exception from HRESULT: 0x{0:X})";
            }
            static /*string */ FormatExceptionFromHResult(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("(Exception from HRESULT: 0x{0:X})", arg1);
            }
            static /*string */ get ReaderWriterLock_InvalidLockCookie()
            {
                return "The specified lock cookie is invalid for this operation. {0}";
            }
            static /*string */ FormatReaderWriterLock_InvalidLockCookie(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The specified lock cookie is invalid for this operation. {0}", arg1);
            }
            static /*string */ get ReaderWriterLock_RestoreLockWithOwnedLocks()
            {
                return "ReaderWriterLock.RestoreLock was called without releasing all locks acquired since the call to ReleaseLock.";
            }
            static /*string */ get HostExecutionContextManager_InvalidOperation_NotNewCaptureContext()
            {
                return "Cannot apply a context that has been marshaled across AppDomains, that was not acquired through a Capture operation or that has already been the argument to a Set call.";
            }
            static /*string */ get HostExecutionContextManager_InvalidOperation_CannotOverrideSetWithoutRevert()
            {
                return "Must override both HostExecutionContextManager.SetHostExecutionContext and HostExecutionContextManager.Revert.";
            }
            static /*string */ get HostExecutionContextManager_InvalidOperation_CannotUseSwitcherOtherThread()
            {
                return "Undo operation must be performed on the thread where the corresponding context was Set.";
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$st.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$st.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$st.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$st.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$st.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$st.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$st.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$st.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$st.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$st.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$st.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$st.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$st.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 248341;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":248341}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$st.System.Threading.CountdownEvent", ($self) => class CountdownEvent extends $.$spc.System.Object
        {
            /*int*/ _initialCount = 0;
            /*int*/ _currentCount = 0;
            /*ManualResetEventSlim*/ _event = null;
            /*bool*/ _disposed = false;
            $ctor$1(/*int*/ initialCount)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegative($.$spc.System.Int32, initialCount, "initialCount");
                    this._initialCount = initialCount;
                    this._currentCount = initialCount;
                    this._event = new $.$spc.System.Threading.ManualResetEventSlim().$ctor$1();
                    if (initialCount === 0)
                    {
                        this._event.Set$1();
                    }
                }
                return this;
            }
            /*int */ get CurrentCount()
            {
                /*int*/ let observedCount = this._currentCount;
                return observedCount < 0 ? 0 : observedCount;
            }
            /*int */ get InitialCount()
            {
                return this._initialCount;
            }
            /*bool */ get IsSet()
            {
                return (this._currentCount <= 0);
            }
            /*WaitHandle */ get WaitHandle()
            {
                $.$spc.System.ObjectDisposedException.ThrowIf(this._disposed, this);
                return this._event.WaitHandle;
            }
            /*void */ Dispose()
            {
                this.Dispose$1(true);
                $.$spc.System.GC.SuppressFinalize(this);
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                if (disposing)
                {
                    this._event.Dispose();
                    this._disposed = true;
                }
            }
            /*bool */ Signal()
            {
                $.$spc.System.ObjectDisposedException.ThrowIf(this._disposed, this);
                $.$spc.System.Diagnostics.Debug.Assert$1(this._event !== null, "_event != null");
                if (this._currentCount <= 0)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$st.System.SR.CountdownEvent_Decrement_BelowZero);
                }
                /*int*/ let newCount = $.$spc.System.Threading.Interlocked.Decrement($.$ref(() => this._currentCount, ($v) => this._currentCount = $v, $.$spc.System.Int32));
                if (newCount === 0)
                {
                    this._event.Set$1();
                    return true;
                }
                else if (newCount < 0)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$st.System.SR.CountdownEvent_Decrement_BelowZero);
                }
                return false;
            }
            /*bool */ Signal$1(/*int*/ signalCount)
            {
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$spc.System.Int32, signalCount, "signalCount");
                $.$spc.System.ObjectDisposedException.ThrowIf(this._disposed, this);
                $.$spc.System.Diagnostics.Debug.Assert$1(this._event !== null, "_event != null");
                /*int*/ let observedCount;
                /*SpinWait*/ let spin = new $.$spc.System.Threading.SpinWait();
                while(true)
                {
                    observedCount = this._currentCount;
                    if (observedCount < signalCount)
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$st.System.SR.CountdownEvent_Decrement_BelowZero);
                    }
                    if ($.$spc.System.Threading.Interlocked.CompareExchange($.$ref(() => this._currentCount, ($v) => this._currentCount = $v, $.$spc.System.Int32), ((observedCount - signalCount) | 0), observedCount) === observedCount)
                    {
                        break;
                    }
                    spin.SpinOnce$1(-1);
                }
                if (observedCount === signalCount)
                {
                    this._event.Set$1();
                    return true;
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(this._currentCount >= 0, "latch was decremented below zero");
                return false;
            }
            /*void */ AddCount()
            {
                this.AddCount$1(1);
            }
            /*bool */ TryAddCount()
            {
                return this.TryAddCount$1(1);
            }
            /*void */ AddCount$1(/*int*/ signalCount)
            {
                if (!this.TryAddCount$1(signalCount))
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$st.System.SR.CountdownEvent_Increment_AlreadyZero);
                }
            }
            /*bool */ TryAddCount$1(/*int*/ signalCount)
            {
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$spc.System.Int32, signalCount, "signalCount");
                $.$spc.System.ObjectDisposedException.ThrowIf(this._disposed, this);
                /*int*/ let observedCount;
                /*SpinWait*/ let spin = new $.$spc.System.Threading.SpinWait();
                while(true)
                {
                    observedCount = this._currentCount;
                    if (observedCount <= 0)
                    {
                        return false;
                    }
                    else if (observedCount > (((2147483647/*int.MaxValue*/ - signalCount) | 0)))
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$st.System.SR.CountdownEvent_Increment_AlreadyMax);
                    }
                    if ($.$spc.System.Threading.Interlocked.CompareExchange($.$ref(() => this._currentCount, ($v) => this._currentCount = $v, $.$spc.System.Int32), ((observedCount + signalCount) | 0), observedCount) === observedCount)
                    {
                        break;
                    }
                    spin.SpinOnce$1(-1);
                }
                return true;
            }
            /*void */ Reset()
            {
                this.Reset$1(this._initialCount);
            }
            /*void */ Reset$1(/*int*/ count)
            {
                $.$spc.System.ObjectDisposedException.ThrowIf(this._disposed, this);
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegative($.$spc.System.Int32, count, "count");
                this._currentCount = count;
                this._initialCount = count;
                if (count === 0)
                {
                    this._event.Set$1();
                }
                else 
                {
                    this._event.Reset();
                }
            }
            /*void */ Wait()
            {
                this.Wait$5(-1/*Timeout.Infinite*/, $.$spc.System.Threading.CancellationToken.None);
            }
            /*void */ Wait$1(/*CancellationToken*/ cancellationToken)
            {
                this.Wait$5(-1/*Timeout.Infinite*/, cancellationToken);
            }
            /*bool */ Wait$2(/*TimeSpan*/ timeout)
            {
                /*long*/ let totalMilliseconds = $.$cast(timeout.TotalMilliseconds, $.$spc.System.Int64);
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfLessThan($.$spc.System.Int64, totalMilliseconds, BigInt(-1), "timeout");
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$spc.System.Int64, totalMilliseconds, BigInt(2147483647/*int.MaxValue*/), "timeout");
                return this.Wait$5($.$cast(totalMilliseconds, $.$spc.System.Int32), $.$spc.System.Threading.CancellationToken.None);
            }
            /*bool */ Wait$3(/*TimeSpan*/ timeout, /*CancellationToken*/ cancellationToken)
            {
                /*long*/ let totalMilliseconds = $.$cast(timeout.TotalMilliseconds, $.$spc.System.Int64);
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfLessThan($.$spc.System.Int64, totalMilliseconds, BigInt(-1), "timeout");
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$spc.System.Int64, totalMilliseconds, BigInt(2147483647/*int.MaxValue*/), "timeout");
                return this.Wait$5($.$cast(totalMilliseconds, $.$spc.System.Int32), cancellationToken);
            }
            /*bool */ Wait$4(/*int*/ millisecondsTimeout)
            {
                return this.Wait$5(millisecondsTimeout, $.$spc.System.Threading.CancellationToken.None);
            }
            /*bool */ Wait$5(/*int*/ millisecondsTimeout, /*CancellationToken*/ cancellationToken)
            {
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfLessThan($.$spc.System.Int32, millisecondsTimeout, -1, "millisecondsTimeout");
                $.$spc.System.ObjectDisposedException.ThrowIf(this._disposed, this);
                cancellationToken.ThrowIfCancellationRequested();
                /*bool*/ let returnValue = this._event.IsSet;
                if (!returnValue)
                {
                    returnValue = this._event.Wait$5(millisecondsTimeout, cancellationToken);
                }
                return returnValue;
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            static $h = 510485;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":30065281557,"f":1},"n":"CurrentCount","d":510485,"h":25770314261,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":38655216149,"f":1},"n":"InitialCount","d":510485,"h":34360248853,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":47245150741,"f":1},"n":"IsSet","d":510485,"h":42950183445,"f":1},{"p":139132929,"g":{"r":0,"d":0,"h":55835085333,"f":1},"n":"WaitHandle","d":510485,"h":51540118037,"f":1}],"m":[{"r":65537,"n":"Dispose","d":510485,"h":60130052629,"f":1},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":510485,"h":64425019925,"f":132},{"r":262145,"n":"Signal","d":510485,"h":68719987221,"f":1},{"r":262145,"p":[{"n":"signalCount","p":655361}],"n":"Signal","o":"@$1","d":510485,"h":73014954517,"f":1},{"r":65537,"n":"AddCount","d":510485,"h":77309921813,"f":1},{"r":262145,"n":"TryAddCount","d":510485,"h":81604889109,"f":1},{"r":65537,"p":[{"n":"signalCount","p":655361}],"n":"AddCount","o":"@$1","d":510485,"h":85899856405,"f":1},{"r":262145,"p":[{"n":"signalCount","p":655361}],"n":"TryAddCount","o":"@$1","d":510485,"h":90194823701,"f":1},{"r":65537,"n":"Reset","d":510485,"h":94489790997,"f":1},{"r":65537,"p":[{"n":"count","p":655361}],"n":"Reset","o":"@$1","d":510485,"h":98784758293,"f":1},{"r":65537,"n":"Wait","d":510485,"h":103079725589,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]}]},{"r":65537,"p":[{"n":"cancellationToken","p":125960193}],"n":"Wait","o":"@$1","d":510485,"h":107374692885,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]}]},{"r":262145,"p":[{"n":"timeout","p":140705793}],"n":"Wait","o":"@$2","d":510485,"h":111669660181,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]}]},{"r":262145,"p":[{"n":"timeout","p":140705793},{"n":"cancellationToken","p":125960193}],"n":"Wait","o":"@$3","d":510485,"h":115964627477,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]}]},{"r":262145,"p":[{"n":"millisecondsTimeout","p":655361}],"n":"Wait","o":"@$4","d":510485,"h":120259594773,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]}]},{"r":262145,"p":[{"n":"millisecondsTimeout","p":655361},{"n":"cancellationToken","p":125960193}],"n":"Wait","o":"@$5","d":510485,"h":124554562069,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]}]}],"l":[{"t":655361,"n":"_initialCount","d":510485,"h":4295477781,"f":2},{"t":655361,"n":"_currentCount","d":510485,"h":8590445077,"f":2},{"t":128385025,"n":"_event","d":510485,"h":12885412373,"f":2},{"t":262145,"n":"_disposed","d":510485,"h":17180379669,"f":2}],"c":[{"p":[{"n":"initialCount","p":655361}],"n":".ctor","o":"$ctor$1","d":510485,"h":21475346965,"f":1}],"i":[57540609],"h":510485,"a":[{"t":37617665,"c":8627552257,"a":[{"v":"InitialCount = {InitialCount}, CurrentCount = {CurrentCount}","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Threading.CountdownEvent`; }
        });
        
        $asm.$cls("$st.System.Threading.HostExecutionContext", ($self) => class HostExecutionContext extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*object?*/ state)
            {
                super.$ctor();
                {
                    this.State = state;
                }
                return this;
            }
            /*object?*/ State = null;
            /*HostExecutionContext */ CreateCopy()
            {
                return new $.$st.System.Threading.HostExecutionContext().$ctor$2(this.State);
            }
            /*void */ Dispose()
            {
                this.Dispose$1(true);
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            static $h = 576021;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":131073,"g":{"r":0,"d":0,"h":21475412501,"f":16},"s":{"r":0,"d":0,"h":25770379797,"f":16},"n":"State","d":576021,"h":17180445205,"f":16}],"m":[{"r":576021,"n":"CreateCopy","d":576021,"h":30065347093,"f":129},{"r":65537,"n":"Dispose","d":576021,"h":34360314389,"f":1},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":576021,"h":38655281685,"f":129}],"c":[{"n":".ctor","o":"$ctor$1","d":576021,"h":4295543317,"f":1},{"p":[{"n":"state","p":131073}],"n":".ctor","o":"$ctor$2","d":576021,"h":8590510613,"f":1}],"i":[57540609],"h":576021}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Threading.HostExecutionContext`; }
        });
        
        $asm.$cls("$st.System.Threading.Barrier", ($self) => class Barrier extends $.$spc.System.Object
        {
            /*int*/ _currentTotalCount = 0;
            /*int*/ static CURRENT_MASK = 2147418112;
            /*int*/ static TOTAL_MASK = 32767;
            /*int*/ static SENSE_MASK = -2147483648;
            /*int*/ static MAX_PARTICIPANTS = 32767;
            /*long*/ _currentPhase = 0n;
            /*bool*/ _disposed = false;
            /*ManualResetEventSlim*/ _oddEvent = null;
            /*ManualResetEventSlim*/ _evenEvent = null;
            /*ExecutionContext?*/ _ownerThreadContext = null;
            /*ContextCallback?*/ static s_invokePostPhaseAction = null;
            /*Action<Barrier>?*/ _postPhaseAction = null;
            /*Exception?*/ _exception = null;
            /*int*/ _actionCallerID = 0;
            /*int */ get ParticipantsRemaining()
            {
                /*int*/ let currentTotal = this._currentTotalCount;
                /*int*/ let total = (currentTotal & 32767/*TOTAL_MASK*/);
                /*int*/ let current = ((currentTotal & 2147418112/*CURRENT_MASK*/) >> 16);
                return ((total - current) | 0);
            }
            /*int */ get ParticipantCount()
            {
                return (this._currentTotalCount & 32767/*TOTAL_MASK*/);
            }
            /*long */ get CurrentPhaseNumber()
            {
                return $.$ref(() => this._currentPhase, ($v) => this._currentPhase = $v, $.$spc.System.Int64).$v;
            }
            /*long */ set CurrentPhaseNumber(value)
            {
                $.$ref(() => this._currentPhase, ($v) => this._currentPhase = $v, $.$spc.System.Int64).$v = value;
            }
            $ctor$1(/*int*/ participantCount)
            {
                this.$ctor$2(participantCount, null);
                {
                }
                return this;
            }
            $ctor$2(/*int*/ participantCount, /*Action<Barrier>?*/ postPhaseAction)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegative($.$spc.System.Int32, participantCount, "participantCount");
                    $.$spc.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$spc.System.Int32, participantCount, 32767/*MAX_PARTICIPANTS*/, "participantCount");
                    this._currentTotalCount = participantCount;
                    this._postPhaseAction = postPhaseAction;
                    this._oddEvent = new $.$spc.System.Threading.ManualResetEventSlim().$ctor$2(true);
                    this._evenEvent = new $.$spc.System.Threading.ManualResetEventSlim().$ctor$2(false);
                    if (!(postPhaseAction === null))
                    {
                        this._ownerThreadContext = $.$spc.System.Threading.ExecutionContext.Capture();
                    }
                    this._actionCallerID = 0;
                }
                return this;
            }
            static /*void */ GetCurrentTotal(/*int*/ currentTotal, /*out int*/ current, /*out int*/ total, /*out bool*/ sense)
            {
                total.$v = (currentTotal & 32767/*TOTAL_MASK*/);
                current.$v = ((currentTotal & 2147418112/*CURRENT_MASK*/) >> 16);
                sense.$v = (currentTotal & -2147483648/*SENSE_MASK*/) === 0 ? true : false;
            }
            /*bool */ SetCurrentTotal(/*int*/ currentTotal, /*int*/ current, /*int*/ total, /*bool*/ sense)
            {
                /*int*/ let newCurrentTotal = (current << 16) | total;
                if (!sense)
                {
                    newCurrentTotal |= -2147483648/*SENSE_MASK*/;
                }
                return $.$spc.System.Threading.Interlocked.CompareExchange($.$ref(() => this._currentTotalCount, ($v) => this._currentTotalCount = $v, $.$spc.System.Int32), newCurrentTotal, currentTotal) === currentTotal;
            }
            /*long */ AddParticipant()
            {
                try
                {
                    return this.AddParticipants(1);
                }
                catch($e)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$st.System.SR.Barrier_AddParticipants_Overflow_ArgumentOutOfRange);
                }
            }
            /*long */ AddParticipants(/*int*/ participantCount)
            {
                $.$spc.System.ObjectDisposedException.ThrowIf(this._disposed, this);
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$spc.System.Int32, participantCount, "participantCount");
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$spc.System.Int32, participantCount, 32767/*MAX_PARTICIPANTS*/, "participantCount");
                if (this._actionCallerID !== 0 && $.$spc.System.Environment.CurrentManagedThreadId === this._actionCallerID)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$st.System.SR.Barrier_InvalidOperation_CalledFromPHA);
                }
                /*SpinWait*/ let spinner = new $.$spc.System.Threading.SpinWait();
                /*long*/ let newPhase;
                while(true)
                {
                    /*int*/ let currentTotal = this._currentTotalCount;
                    /*int*/ let total;
                    /*int*/ let current;
                    /*bool*/ let sense;
                    $.$st.System.Threading.Barrier.GetCurrentTotal(currentTotal, $.$ref(() => current, ($v) => current = $v, $.$spc.System.Int32), $.$ref(() => total, ($v) => total = $v, $.$spc.System.Int32), $.$ref(() => sense, ($v) => sense = $v, $.$spc.System.Boolean));
                    if (((participantCount + total) | 0) > 32767/*MAX_PARTICIPANTS*/)
                    {
                        throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$17("participantCount", $.$st.System.SR.Barrier_AddParticipants_Overflow_ArgumentOutOfRange);
                    }
                    if (this.SetCurrentTotal(currentTotal, current, ((total + participantCount) | 0), sense))
                    {
                        /*long*/ let currPhase = this.CurrentPhaseNumber;
                        newPhase = (sense !== (currPhase % 2n === 0n)) ? currPhase + 1n : currPhase;
                        if (newPhase !== currPhase)
                        {
                            if (sense)
                            {
                                this._oddEvent.Wait();
                            }
                            else 
                            {
                                this._evenEvent.Wait();
                            }
                        }
                        else 
                        {
                            if (sense && this._evenEvent.IsSet)
                            {
                                this._evenEvent.Reset();
                            }
                            else if (!sense && this._oddEvent.IsSet)
                            {
                                this._oddEvent.Reset();
                            }
                        }
                        break;
                    }
                    spinner.SpinOnce$1(-1);
                }
                return newPhase;
            }
            /*void */ RemoveParticipant()
            {
                this.RemoveParticipants(1);
            }
            /*void */ RemoveParticipants(/*int*/ participantCount)
            {
                $.$spc.System.ObjectDisposedException.ThrowIf(this._disposed, this);
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$spc.System.Int32, participantCount, "participantCount");
                if (this._actionCallerID !== 0 && $.$spc.System.Environment.CurrentManagedThreadId === this._actionCallerID)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$st.System.SR.Barrier_InvalidOperation_CalledFromPHA);
                }
                /*SpinWait*/ let spinner = new $.$spc.System.Threading.SpinWait();
                while(true)
                {
                    /*int*/ let currentTotal = this._currentTotalCount;
                    /*int*/ let total;
                    /*int*/ let current;
                    /*bool*/ let sense;
                    $.$st.System.Threading.Barrier.GetCurrentTotal(currentTotal, $.$ref(() => current, ($v) => current = $v, $.$spc.System.Int32), $.$ref(() => total, ($v) => total = $v, $.$spc.System.Int32), $.$ref(() => sense, ($v) => sense = $v, $.$spc.System.Boolean));
                    if (total < participantCount)
                    {
                        throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$17("participantCount", $.$st.System.SR.Barrier_RemoveParticipants_ArgumentOutOfRange);
                    }
                    if (((total - participantCount) | 0) < current)
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$st.System.SR.Barrier_RemoveParticipants_InvalidOperation);
                    }
                    /*int*/ let remaingParticipants = ((total - participantCount) | 0);
                    if (remaingParticipants > 0 && current === remaingParticipants)
                    {
                        if (this.SetCurrentTotal(currentTotal, 0, ((total - participantCount) | 0), !sense))
                        {
                            this.FinishPhase(sense);
                            break;
                        }
                    }
                    else 
                    {
                        if (this.SetCurrentTotal(currentTotal, current, ((total - participantCount) | 0), sense))
                        {
                            break;
                        }
                    }
                    spinner.SpinOnce$1(-1);
                }
            }
            /*void */ SignalAndWait()
            {
                this.SignalAndWait$1($.$spc.System.Threading.CancellationToken.None);
            }
            /*void */ SignalAndWait$1(/*CancellationToken*/ cancellationToken)
            {
                /*bool*/ let result = this.SignalAndWait$5(-1/*Timeout.Infinite*/, cancellationToken);
                $.$spc.System.Diagnostics.Debug.Assert$1(result, "result");
            }
            /*bool */ SignalAndWait$2(/*TimeSpan*/ timeout)
            {
                return this.SignalAndWait$3(timeout, $.$spc.System.Threading.CancellationToken.None);
            }
            /*bool */ SignalAndWait$3(/*TimeSpan*/ timeout, /*CancellationToken*/ cancellationToken)
            {
                /*long*/ let totalMilliseconds = $.$cast(timeout.TotalMilliseconds, $.$spc.System.Int64);
                if (totalMilliseconds < BigInt(-1) || totalMilliseconds > BigInt(2147483647/*int.MaxValue*/))
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$19("timeout", timeout, $.$st.System.SR.Barrier_SignalAndWait_ArgumentOutOfRange);
                }
                return this.SignalAndWait$5($.$cast(timeout.TotalMilliseconds, $.$spc.System.Int32), cancellationToken);
            }
            /*bool */ SignalAndWait$4(/*int*/ millisecondsTimeout)
            {
                return this.SignalAndWait$5(millisecondsTimeout, $.$spc.System.Threading.CancellationToken.None);
            }
            /*bool */ SignalAndWait$5(/*int*/ millisecondsTimeout, /*CancellationToken*/ cancellationToken)
            {
                $.$spc.System.ObjectDisposedException.ThrowIf(this._disposed, this);
                cancellationToken.ThrowIfCancellationRequested();
                if (millisecondsTimeout < -1)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$19("millisecondsTimeout", $.$box(millisecondsTimeout, $.$spc.System.Int32), $.$st.System.SR.Barrier_SignalAndWait_ArgumentOutOfRange);
                }
                if (this._actionCallerID !== 0 && $.$spc.System.Environment.CurrentManagedThreadId === this._actionCallerID)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$st.System.SR.Barrier_InvalidOperation_CalledFromPHA);
                }
                /*bool*/ let sense;
                /*int*/ let total;
                /*int*/ let current;
                /*int*/ let currentTotal;
                /*long*/ let phase;
                /*SpinWait*/ let spinner = new $.$spc.System.Threading.SpinWait();
                while(true)
                {
                    currentTotal = this._currentTotalCount;
                    $.$st.System.Threading.Barrier.GetCurrentTotal(currentTotal, $.$ref(() => current, ($v) => current = $v, $.$spc.System.Int32), $.$ref(() => total, ($v) => total = $v, $.$spc.System.Int32), $.$ref(() => sense, ($v) => sense = $v, $.$spc.System.Boolean));
                    phase = this.CurrentPhaseNumber;
                    if (total === 0)
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$st.System.SR.Barrier_SignalAndWait_InvalidOperation_ZeroTotal);
                    }
                    if (current === 0 && sense !== (this.CurrentPhaseNumber % 2n === 0n))
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$st.System.SR.Barrier_SignalAndWait_InvalidOperation_ThreadsExceeded);
                    }
                    if (((current + 1) | 0) === total)
                    {
                        if (this.SetCurrentTotal(currentTotal, 0, total, !sense))
                        {
                            if ($.$st.System.Threading.CdsSyncEtwBCLProvider.Log.IsEnabled())
                            {
                                $.$st.System.Threading.CdsSyncEtwBCLProvider.Log.Barrier_PhaseFinished(sense, this.CurrentPhaseNumber);
                            }
                            this.FinishPhase(sense);
                            return true;
                        }
                    }
                    else if (this.SetCurrentTotal(currentTotal, ((current + 1) | 0), total, sense))
                    {
                        break;
                    }
                    spinner.SpinOnce$1(-1);
                }
                /*ManualResetEventSlim*/ let eventToWaitOn = (sense) ? this._evenEvent : this._oddEvent;
                /*bool*/ let waitWasCanceled = false;
                /*bool*/ let waitResult = false;
                try
                {
                    waitResult = this.DiscontinuousWait(eventToWaitOn, millisecondsTimeout, cancellationToken, phase);
                }
                catch($e)
                {
                    if ($e instanceof $.$spc.System.OperationCanceledException)
                    {
                        waitWasCanceled = true;
                    }
                    else if ($e instanceof $.$spc.System.ObjectDisposedException)
                    {
                        if (phase < this.CurrentPhaseNumber)
                        {
                            waitResult = true;
                        }
                        else 
                        {
                            throw $e;
                        }
                    }
                    else
                    {
                        throw $e;
                    }
                }
                if (!waitResult)
                {
                    spinner.Reset();
                    while(true)
                    {
                        /*bool*/ let newSense;
                        currentTotal = this._currentTotalCount;
                        $.$st.System.Threading.Barrier.GetCurrentTotal(currentTotal, $.$ref(() => current, ($v) => current = $v, $.$spc.System.Int32), $.$ref(() => total, ($v) => total = $v, $.$spc.System.Int32), $.$ref(() => newSense, ($v) => newSense = $v, $.$spc.System.Boolean));
                        if (phase < this.CurrentPhaseNumber || sense !== newSense)
                        {
                            this.WaitCurrentPhase(eventToWaitOn, phase);
                            $.$spc.System.Diagnostics.Debug.Assert$1(phase < this.CurrentPhaseNumber, "phase < CurrentPhaseNumber");
                            break;
                        }
                        if (this.SetCurrentTotal(currentTotal, ((current - 1) | 0), total, sense))
                        {
                            if (waitWasCanceled)
                            {
                                throw new $.$spc.System.OperationCanceledException().$ctor$13($.$st.System.SR.Common_OperationCanceled, cancellationToken);
                            }
                            else 
                            {
                                return false;
                            }
                        }
                        spinner.SpinOnce$1(-1);
                    }
                }
                if (!(this._exception === null))
                {
                    throw new $.$st.System.Threading.BarrierPostPhaseException().$ctor$6(this._exception);
                }
                return true;
            }
            /*void */ FinishPhase(/*bool*/ observedSense)
            {
                if (!(this._postPhaseAction === null))
                {
                    try
                    {
                        this._actionCallerID = $.$spc.System.Environment.CurrentManagedThreadId;
                        if (!(this._ownerThreadContext === null))
                        {
                            /*ContextCallback?*/ let handler = $.$st.System.Threading.Barrier.s_invokePostPhaseAction ??= new $.$spc.System.Threading.ContextCallback().$ctor($.$st.System.Threading.Barrier, $.$st.System.Threading.Barrier.InvokePostPhaseAction);
                            $.$spc.System.Threading.ExecutionContext.Run(this._ownerThreadContext, handler, this);
                        }
                        else 
                        {
                            this._postPhaseAction.Invoke(this);
                        }
                        this._exception = null;
                    }
                    catch(ex)
                    {
                        this._exception = ex;
                    }
                    finally
                    {
                        {
                            this._actionCallerID = 0;
                            this.SetResetEvents(observedSense);
                            if (!(this._exception === null))
                            {
                                throw new $.$st.System.Threading.BarrierPostPhaseException().$ctor$6(this._exception);
                            }
                        }
                    }
                }
                else 
                {
                    this.SetResetEvents(observedSense);
                }
            }
            static /*void */ InvokePostPhaseAction(/*object?*/ obj)
            {
                /*var*/ let thisBarrier = $.$cast(obj, $.$st.System.Threading.Barrier);
                thisBarrier.this._postPhaseAction.Invoke(thisBarrier);
            }
            /*void */ SetResetEvents(/*bool*/ observedSense)
            {
                this.CurrentPhaseNumber++;
                if (observedSense)
                {
                    this._oddEvent.Reset();
                    this._evenEvent.Set$1();
                }
                else 
                {
                    this._evenEvent.Reset();
                    this._oddEvent.Set$1();
                }
            }
            /*void */ WaitCurrentPhase(/*ManualResetEventSlim*/ currentPhaseEvent, /*long*/ observedPhase)
            {
                /*SpinWait*/ let spinner = new $.$spc.System.Threading.SpinWait();
                while(!currentPhaseEvent.IsSet && this.CurrentPhaseNumber - observedPhase <= 1n)
                {
                    spinner.SpinOnce();
                }
            }
            /*bool */ DiscontinuousWait(/*ManualResetEventSlim*/ currentPhaseEvent, /*int*/ totalTimeout, /*CancellationToken*/ token, /*long*/ observedPhase)
            {
                /*int*/ let maxWait = 100;
                /*int*/ let waitTimeCeiling = 10000;
                while(observedPhase === this.CurrentPhaseNumber)
                {
                    /*int*/ let waitTime = totalTimeout === -1/*Timeout.Infinite*/ ? maxWait : $.$spc.System.Math.Min$4(maxWait, totalTimeout);
                    if (currentPhaseEvent.Wait$5(waitTime, token))
                    {
                        return true;
                    }
                    if (totalTimeout !== -1/*Timeout.Infinite*/)
                    {
                        totalTimeout -= waitTime;
                        if (totalTimeout <= 0)
                        {
                            return false;
                        }
                    }
                    maxWait = maxWait >= waitTimeCeiling ? waitTimeCeiling : $.$spc.System.Math.Min$4(maxWait << 1, waitTimeCeiling);
                }
                this.WaitCurrentPhase(currentPhaseEvent, observedPhase);
                return true;
            }
            /*void */ Dispose()
            {
                if (this._actionCallerID !== 0 && $.$spc.System.Environment.CurrentManagedThreadId === this._actionCallerID)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$st.System.SR.Barrier_InvalidOperation_CalledFromPHA);
                }
                this.Dispose$1(true);
                $.$spc.System.GC.SuppressFinalize(this);
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                if (!this._disposed)
                {
                    if (disposing)
                    {
                        this._oddEvent.Dispose();
                        this._evenEvent.Dispose();
                    }
                    this._disposed = true;
                }
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            static $h = 313877;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":68719790613,"f":1},"n":"ParticipantsRemaining","d":313877,"h":64424823317,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":77309725205,"f":1},"n":"ParticipantCount","d":313877,"h":73014757909,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":85899659797,"f":1},"s":{"r":0,"d":0,"h":90194627093,"f":8},"n":"CurrentPhaseNumber","d":313877,"h":81604692501,"f":1}],"m":[{"r":65537,"p":[{"n":"currentTotal","p":655361},{"n":"current","p":655361,"f":2},{"n":"total","p":655361,"f":2},{"n":"sense","p":262145,"f":2}],"n":"GetCurrentTotal","d":313877,"h":103079528981,"f":34},{"r":262145,"p":[{"n":"currentTotal","p":655361},{"n":"current","p":655361},{"n":"total","p":655361},{"n":"sense","p":262145}],"n":"SetCurrentTotal","d":313877,"h":107374496277,"f":2},{"r":917505,"n":"AddParticipant","d":313877,"h":111669463573,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]}]},{"r":917505,"p":[{"n":"participantCount","p":655361}],"n":"AddParticipants","d":313877,"h":115964430869,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]}]},{"r":65537,"n":"RemoveParticipant","d":313877,"h":120259398165,"f":1},{"r":65537,"p":[{"n":"participantCount","p":655361}],"n":"RemoveParticipants","d":313877,"h":124554365461,"f":1},{"r":65537,"n":"SignalAndWait","d":313877,"h":128849332757,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]}]},{"r":65537,"p":[{"n":"cancellationToken","p":125960193}],"n":"SignalAndWait","o":"@$1","d":313877,"h":133144300053,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]}]},{"r":262145,"p":[{"n":"timeout","p":140705793}],"n":"SignalAndWait","o":"@$2","d":313877,"h":137439267349,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]}]},{"r":262145,"p":[{"n":"timeout","p":140705793},{"n":"cancellationToken","p":125960193}],"n":"SignalAndWait","o":"@$3","d":313877,"h":141734234645,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]}]},{"r":262145,"p":[{"n":"millisecondsTimeout","p":655361}],"n":"SignalAndWait","o":"@$4","d":313877,"h":146029201941,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]}]},{"r":262145,"p":[{"n":"millisecondsTimeout","p":655361},{"n":"cancellationToken","p":125960193}],"n":"SignalAndWait","o":"@$5","d":313877,"h":150324169237,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]}]},{"r":65537,"p":[{"n":"observedSense","p":262145}],"n":"FinishPhase","d":313877,"h":154619136533,"f":2},{"r":65537,"p":[{"n":"obj","p":131073}],"n":"InvokePostPhaseAction","d":313877,"h":158914103829,"f":34},{"r":65537,"p":[{"n":"observedSense","p":262145}],"n":"SetResetEvents","d":313877,"h":163209071125,"f":2},{"r":65537,"p":[{"n":"currentPhaseEvent","p":128385025},{"n":"observedPhase","p":917505}],"n":"WaitCurrentPhase","d":313877,"h":167504038421,"f":2},{"r":262145,"p":[{"n":"currentPhaseEvent","p":128385025},{"n":"totalTimeout","p":655361},{"n":"token","p":125960193},{"n":"observedPhase","p":917505}],"n":"DiscontinuousWait","d":313877,"h":171799005717,"f":2,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]}]},{"r":65537,"n":"Dispose","d":313877,"h":176093973013,"f":1},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":313877,"h":180388940309,"f":132}],"l":[{"t":655361,"n":"_currentTotalCount","d":313877,"h":4295281173,"f":2},{"t":655361,"n":"CURRENT_MASK","d":313877,"h":8590248469,"f":34},{"t":655361,"n":"TOTAL_MASK","d":313877,"h":12885215765,"f":34},{"t":655361,"n":"SENSE_MASK","d":313877,"h":17180183061,"f":34},{"t":655361,"n":"MAX_PARTICIPANTS","d":313877,"h":21475150357,"f":34},{"t":917505,"n":"_currentPhase","d":313877,"h":25770117653,"f":2},{"t":262145,"n":"_disposed","d":313877,"h":30065084949,"f":2},{"t":128385025,"n":"_oddEvent","d":313877,"h":34360052245,"f":2},{"t":128385025,"n":"_evenEvent","d":313877,"h":38655019541,"f":2},{"t":126943233,"n":"_ownerThreadContext","d":313877,"h":42949986837,"f":2},{"t":126615553,"n":"s_invokePostPhaseAction","d":313877,"h":47244954133,"f":34},{"t":$.$spc.System.Action$$($.$st.System.Threading.Barrier).$h,"n":"_postPhaseAction","d":313877,"h":51539921429,"f":2},{"t":47251457,"n":"_exception","d":313877,"h":55834888725,"f":2},{"t":655361,"n":"_actionCallerID","d":313877,"h":60129856021,"f":2}],"c":[{"p":[{"n":"participantCount","p":655361}],"n":".ctor","o":"$ctor$1","d":313877,"h":94489594389,"f":1},{"p":[{"n":"participantCount","p":655361},{"n":"postPhaseAction","p":$.$spc.System.Action$$($.$st.System.Threading.Barrier).$h}],"n":".ctor","o":"$ctor$2","d":313877,"h":98784561685,"f":1}],"i":[57540609],"h":313877,"a":[{"t":37617665,"c":8627552257,"a":[{"v":"ParticipantCount = {ParticipantCount}, ParticipantsRemaining = {ParticipantsRemaining}","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Threading.Barrier`; }
        });
        
        $asm.$cls("$st.System.Threading.ReaderWriterLock", ($self) => class ReaderWriterLock extends $.$spc.System.Runtime.ConstrainedExecution.CriticalFinalizerObject
        {
            /*int*/ static InvalidThreadID = -1;
            /*ushort*/ static MaxAcquireCount = 65535;
            /*int*/ static DefaultSpinCount = 0;
            /*int*/ static IncorrectButCompatibleNotOwnerExceptionHResult = 288;
            /*long*/ static s_mostRecentLockID = 0n;
            /*ManualResetEventSlim?*/ _readerEvent = null;
            /*AutoResetEvent?*/ _writerEvent = null;
            /*long*/ _lockID = 0n;
            /*int*/ _state = 0;
            /*int*/ _writerID = -1;
            /*int*/ _writerSeqNum = 1;
            /*ushort*/ _writerLevel = 0;
            $ctor$2()
            {
                super.$ctor$1();
                {
                    this._lockID = $.$spc.System.Threading.Interlocked.Increment$1($.$ref(() => $.$st.System.Threading.ReaderWriterLock.s_mostRecentLockID, ($v) => $.$st.System.Threading.ReaderWriterLock.s_mostRecentLockID = $v, $.$spc.System.Int64));
                }
                return this;
            }
            /*bool */ get IsReaderLockHeld()
            {
                /*ThreadLocalLockEntry?*/ let threadLocalLockEntry = $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.GetCurrent(this._lockID);
                if (threadLocalLockEntry !== null)
                {
                    return threadLocalLockEntry._readerLevel > 0;
                }
                return false;
            }
            /*bool */ get IsWriterLockHeld()
            {
                return this._writerID === $.$st.System.Threading.ReaderWriterLock.GetCurrentThreadID();
            }
            /*int */ get WriterSeqNum()
            {
                return this._writerSeqNum;
            }
            /*bool */ AnyWritersSince(/*int*/ seqNum)
            {
                if (this._writerID === $.$st.System.Threading.ReaderWriterLock.GetCurrentThreadID())
                {
                    ++seqNum;
                }
                return (this._writerSeqNum >>> 0) > (seqNum >>> 0);
            }
            /*void */ AcquireReaderLock(/*int*/ millisecondsTimeout)
            {
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfLessThan($.$spc.System.Int32, millisecondsTimeout, -1, "millisecondsTimeout");
                /*ThreadLocalLockEntry*/ let threadLocalLockEntry = $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.GetOrCreateCurrent(this._lockID);
                if ($.$spc.System.Threading.Interlocked.CompareExchange($.$ref(() => this._state, ($v) => this._state = $v, $.$spc.System.Int32), 1/*LockStates.Reader*/, 0) === 0)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(threadLocalLockEntry._readerLevel === 0, "threadLocalLockEntry._readerLevel == 0");
                }
                else if (threadLocalLockEntry._readerLevel > 0)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1((this._state & 1023/*LockStates.ReadersMask*/) !== 0, "(_state & LockStates.ReadersMask) != 0");
                    if (threadLocalLockEntry._readerLevel === 65535/*MaxAcquireCount*/)
                    {
                        throw new $.$spc.System.OverflowException().$ctor$14($.$st.System.SR.Overflow_UInt16);
                    }
                    ++threadLocalLockEntry._readerLevel;
                    return;
                }
                else if (this._writerID === $.$st.System.Threading.ReaderWriterLock.GetCurrentThreadID())
                {
                    this.AcquireWriterLock(millisecondsTimeout);
                    $.$spc.System.Diagnostics.Debug.Assert$1(threadLocalLockEntry.IsFree, "threadLocalLockEntry.IsFree");
                    return;
                }
                else 
                {
                    /*int*/ let spinCount = 0;
                    /*int*/ let currentState = this._state;
                    do
                    {
                        /*int*/ let knownState = currentState;
                        if (knownState < 1023/*LockStates.ReadersMask*/ || ((knownState & 1024/*LockStates.ReaderSignaled*/) !== 0 && (knownState & 4096/*LockStates.Writer*/) === 0 && (((((knownState & 1023/*LockStates.ReadersMask*/) + ((knownState & 8380416/*LockStates.WaitingReadersMask*/) >> 13/*LockStates.WaitingReadersShift*/)) | 0)) <= ((1023/*LockStates.ReadersMask*/ - 2) | 0))))
                        {
                            currentState = $.$spc.System.Threading.Interlocked.CompareExchange($.$ref(() => this._state, ($v) => this._state = $v, $.$spc.System.Int32), ((knownState + 1/*LockStates.Reader*/) | 0), knownState);
                            if (currentState === knownState)
                            {
                                break;
                            }
                            continue;
                        }
                        if ((knownState & 1023/*LockStates.ReadersMask*/) === 1023/*LockStates.ReadersMask*/ || (knownState & 8380416/*LockStates.WaitingReadersMask*/) === 8380416/*LockStates.WaitingReadersMask*/ || (knownState & 3072/*LockStates.CachingEvents*/) === 1024/*LockStates.ReaderSignaled*/)
                        {
                            /*int*/ let sleepDurationMilliseconds = 100;
                            if ((knownState & 1023/*LockStates.ReadersMask*/) === 1023/*LockStates.ReadersMask*/ || (knownState & 8380416/*LockStates.WaitingReadersMask*/) === 8380416/*LockStates.WaitingReadersMask*/)
                            {
                                sleepDurationMilliseconds = 1000;
                            }
                            $.$spc.System.Threading.Thread.Sleep(sleepDurationMilliseconds);
                            spinCount = 0;
                            currentState = this._state;
                            continue;
                        }
                        ++spinCount;
                        if ((knownState & 3072/*LockStates.CachingEvents*/) === 3072/*LockStates.CachingEvents*/)
                        {
                            if (spinCount > $.$st.System.Threading.ReaderWriterLock.DefaultSpinCount)
                            {
                                $.$spc.System.Threading.Thread.Sleep(1);
                                spinCount = 0;
                            }
                            currentState = this._state;
                            continue;
                        }
                        if (spinCount <= $.$st.System.Threading.ReaderWriterLock.DefaultSpinCount)
                        {
                            currentState = this._state;
                            continue;
                        }
                        currentState = $.$spc.System.Threading.Interlocked.CompareExchange($.$ref(() => this._state, ($v) => this._state = $v, $.$spc.System.Int32), ((knownState + 8192/*LockStates.WaitingReader*/) | 0), knownState);
                        if (currentState !== knownState)
                        {
                            continue;
                        }
                        /*int*/ let modifyState = -8192/*LockStates.WaitingReader*/;
                        /*ManualResetEventSlim?*/ let readerEvent = null;
                        /*bool*/ let waitSucceeded = false;
                        try
                        {
                            readerEvent = this.GetOrCreateReaderEvent();
                            waitSucceeded = readerEvent.Wait$4(millisecondsTimeout);
                            $.$spc.System.Diagnostics.Debug.Assert$1(threadLocalLockEntry.HasLockID(this._lockID), "threadLocalLockEntry.HasLockID(_lockID)");
                            if (waitSucceeded)
                            {
                                $.$spc.System.Diagnostics.Debug.Assert$1((this._state & 1024/*LockStates.ReaderSignaled*/) !== 0, "(_state & LockStates.ReaderSignaled) != 0");
                                $.$spc.System.Diagnostics.Debug.Assert$1((this._state & 1023/*LockStates.ReadersMask*/) < 1023/*LockStates.ReadersMask*/, "(_state & LockStates.ReadersMask) < LockStates.ReadersMask");
                                modifyState += 1/*LockStates.Reader*/;
                            }
                        }
                        finally
                        {
                            {
                                knownState = (($.$spc.System.Threading.Interlocked.Add($.$ref(() => this._state, ($v) => this._state = $v, $.$spc.System.Int32), modifyState) - modifyState) | 0);
                                if (!waitSucceeded)
                                {
                                    if ((knownState & 1024/*LockStates.ReaderSignaled*/) !== 0 && (knownState & 8380416/*LockStates.WaitingReadersMask*/) === 8192/*LockStates.WaitingReader*/)
                                    {
                                        if (readerEvent === null)
                                        {
                                            readerEvent = this._readerEvent;
                                            $.$spc.System.Diagnostics.Debug.Assert$1(readerEvent !== null, "readerEvent != null");
                                        }
                                        readerEvent.Wait();
                                        $.$spc.System.Diagnostics.Debug.Assert$1((this._state & 1023/*LockStates.ReadersMask*/) < 1023/*LockStates.ReadersMask*/, "(_state & LockStates.ReadersMask) < LockStates.ReadersMask");
                                        readerEvent.Reset();
                                        $.$spc.System.Threading.Interlocked.Add($.$ref(() => this._state, ($v) => this._state = $v, $.$spc.System.Int32), ((1/*LockStates.Reader*/ - 1024/*LockStates.ReaderSignaled*/) | 0));
                                        ++threadLocalLockEntry._readerLevel;
                                        this.ReleaseReaderLock();
                                    }
                                    $.$spc.System.Diagnostics.Debug.Assert$1(threadLocalLockEntry.IsFree, "threadLocalLockEntry.IsFree");
                                }
                            }
                        }
                        if (!waitSucceeded)
                        {
                            throw $.$st.System.Threading.ReaderWriterLock.GetTimeoutException();
                        }
                        $.$spc.System.Diagnostics.Debug.Assert$1((knownState & 1024/*LockStates.ReaderSignaled*/) !== 0, "(knownState & LockStates.ReaderSignaled) != 0");
                        $.$spc.System.Diagnostics.Debug.Assert$1((knownState & 1023/*LockStates.ReadersMask*/) < 1023/*LockStates.ReadersMask*/, "(knownState & LockStates.ReadersMask) < LockStates.ReadersMask");
                        if ((knownState & 8380416/*LockStates.WaitingReadersMask*/) === 8192/*LockStates.WaitingReader*/)
                        {
                            readerEvent.Reset();
                            $.$spc.System.Threading.Interlocked.Add($.$ref(() => this._state, ($v) => this._state = $v, $.$spc.System.Int32), -1024/*LockStates.ReaderSignaled*/);
                        }
                        break;
                    }
                    while($.$st.System.Threading.ReaderWriterLock.YieldProcessor());
                }
                $.$spc.System.Diagnostics.Debug.Assert$1((this._state & 4096/*LockStates.Writer*/) === 0, "(_state & LockStates.Writer) == 0");
                $.$spc.System.Diagnostics.Debug.Assert$1((this._state & 1023/*LockStates.ReadersMask*/) !== 0, "(_state & LockStates.ReadersMask) != 0");
                ++threadLocalLockEntry._readerLevel;
            }
            /*void */ AcquireReaderLock$1(/*TimeSpan*/ timeout)
            {
                return this.AcquireReaderLock($.$st.System.Threading.ReaderWriterLock.ToTimeoutMilliseconds(timeout));
            }
            /*void */ AcquireWriterLock(/*int*/ millisecondsTimeout)
            {
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfLessThan($.$spc.System.Int32, millisecondsTimeout, -1, "millisecondsTimeout");
                /*int*/ let threadID = $.$st.System.Threading.ReaderWriterLock.GetCurrentThreadID();
                if ($.$spc.System.Threading.Interlocked.CompareExchange($.$ref(() => this._state, ($v) => this._state = $v, $.$spc.System.Int32), 4096/*LockStates.Writer*/, 0) === 0)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1((this._state & 1023/*LockStates.ReadersMask*/) === 0, "(_state & LockStates.ReadersMask) == 0");
                }
                else if (this._writerID === threadID)
                {
                    if (this._writerLevel === 65535/*MaxAcquireCount*/)
                    {
                        throw new $.$spc.System.OverflowException().$ctor$14($.$st.System.SR.Overflow_UInt16);
                    }
                    ++this._writerLevel;
                    return;
                }
                else 
                {
                    /*int*/ let spinCount = 0;
                    /*int*/ let currentState = this._state;
                    do
                    {
                        /*int*/ let knownState = currentState;
                        if (knownState === 0 || knownState === 3072/*LockStates.CachingEvents*/)
                        {
                            currentState = $.$spc.System.Threading.Interlocked.CompareExchange($.$ref(() => this._state, ($v) => this._state = $v, $.$spc.System.Int32), ((knownState + 4096/*LockStates.Writer*/) | 0), knownState);
                            if (currentState === knownState)
                            {
                                break;
                            }
                            continue;
                        }
                        if ((knownState & -8388608/*LockStates.WaitingWritersMask*/) === -8388608/*LockStates.WaitingWritersMask*/)
                        {
                            $.$spc.System.Threading.Thread.Sleep(1000);
                            spinCount = 0;
                            currentState = this._state;
                            continue;
                        }
                        ++spinCount;
                        if ((knownState & 3072/*LockStates.CachingEvents*/) === 3072/*LockStates.CachingEvents*/)
                        {
                            if (spinCount > $.$st.System.Threading.ReaderWriterLock.DefaultSpinCount)
                            {
                                $.$spc.System.Threading.Thread.Sleep(1);
                                spinCount = 0;
                            }
                            currentState = this._state;
                            continue;
                        }
                        if (spinCount <= $.$st.System.Threading.ReaderWriterLock.DefaultSpinCount)
                        {
                            currentState = this._state;
                            continue;
                        }
                        currentState = $.$spc.System.Threading.Interlocked.CompareExchange($.$ref(() => this._state, ($v) => this._state = $v, $.$spc.System.Int32), ((knownState + 8388608/*LockStates.WaitingWriter*/) | 0), knownState);
                        if (currentState !== knownState)
                        {
                            continue;
                        }
                        /*int*/ let modifyState = -8388608/*LockStates.WaitingWriter*/;
                        /*AutoResetEvent?*/ let writerEvent = null;
                        /*bool*/ let waitSucceeded = false;
                        try
                        {
                            writerEvent = this.GetOrCreateWriterEvent();
                            waitSucceeded = writerEvent.WaitOne(millisecondsTimeout);
                            if (waitSucceeded)
                            {
                                $.$spc.System.Diagnostics.Debug.Assert$1((this._state & 2048/*LockStates.WriterSignaled*/) !== 0, "(_state & LockStates.WriterSignaled) != 0");
                                modifyState += ((4096/*LockStates.Writer*/ - 2048/*LockStates.WriterSignaled*/) | 0);
                            }
                        }
                        finally
                        {
                            {
                                knownState = (($.$spc.System.Threading.Interlocked.Add($.$ref(() => this._state, ($v) => this._state = $v, $.$spc.System.Int32), modifyState) - modifyState) | 0);
                                if (!waitSucceeded && (knownState & 2048/*LockStates.WriterSignaled*/) !== 0 && (knownState & -8388608/*LockStates.WaitingWritersMask*/) === 8388608/*LockStates.WaitingWriter*/)
                                {
                                    if (writerEvent === null)
                                    {
                                        writerEvent = this._writerEvent;
                                        $.$spc.System.Diagnostics.Debug.Assert$1(writerEvent !== null, "writerEvent != null");
                                    }
                                    while(true)
                                    {
                                        knownState = this._state;
                                        if ((knownState & 2048/*LockStates.WriterSignaled*/) === 0 || (knownState & -8388608/*LockStates.WaitingWritersMask*/) !== 0)
                                        {
                                            break;
                                        }
                                        if (!writerEvent.WaitOne(10))
                                        {
                                            continue;
                                        }
                                        modifyState = ((4096/*LockStates.Writer*/ - 2048/*LockStates.WriterSignaled*/) | 0);
                                        knownState = (($.$spc.System.Threading.Interlocked.Add($.$ref(() => this._state, ($v) => this._state = $v, $.$spc.System.Int32), modifyState) - modifyState) | 0);
                                        $.$spc.System.Diagnostics.Debug.Assert$1((knownState & 2048/*LockStates.WriterSignaled*/) !== 0, "(knownState & LockStates.WriterSignaled) != 0");
                                        $.$spc.System.Diagnostics.Debug.Assert$1((knownState & 4096/*LockStates.Writer*/) === 0, "(knownState & LockStates.Writer) == 0");
                                        this._writerID = threadID;
                                        $.$spc.System.Diagnostics.Debug.Assert$1(this._writerLevel === 0, "_writerLevel == 0");
                                        this._writerLevel = 1;
                                        this.ReleaseWriterLock();
                                        break;
                                    }
                                }
                            }
                        }
                        if (!waitSucceeded)
                        {
                            throw $.$st.System.Threading.ReaderWriterLock.GetTimeoutException();
                        }
                        break;
                    }
                    while($.$st.System.Threading.ReaderWriterLock.YieldProcessor());
                }
                $.$spc.System.Diagnostics.Debug.Assert$1((this._state & 4096/*LockStates.Writer*/) !== 0, "(_state & LockStates.Writer) != 0");
                $.$spc.System.Diagnostics.Debug.Assert$1((this._state & 1023/*LockStates.ReadersMask*/) === 0, "(_state & LockStates.ReadersMask) == 0");
                $.$spc.System.Diagnostics.Debug.Assert$1(this._writerID === -1/*InvalidThreadID*/, "_writerID == InvalidThreadID");
                this._writerID = threadID;
                this._writerLevel = 1;
                ++this._writerSeqNum;
                return;
            }
            /*void */ AcquireWriterLock$1(/*TimeSpan*/ timeout)
            {
                return this.AcquireWriterLock($.$st.System.Threading.ReaderWriterLock.ToTimeoutMilliseconds(timeout));
            }
            /*void */ ReleaseReaderLock()
            {
                if (this._writerID === $.$st.System.Threading.ReaderWriterLock.GetCurrentThreadID())
                {
                    this.ReleaseWriterLock();
                    return;
                }
                /*ThreadLocalLockEntry?*/ let threadLocalLockEntry = $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.GetCurrent(this._lockID);
                if (threadLocalLockEntry === null)
                {
                    throw $.$st.System.Threading.ReaderWriterLock.GetNotOwnerException();
                }
                $.$spc.System.Diagnostics.Debug.Assert$1((this._state & 4096/*LockStates.Writer*/) === 0, "(_state & LockStates.Writer) == 0");
                $.$spc.System.Diagnostics.Debug.Assert$1((this._state & 1023/*LockStates.ReadersMask*/) !== 0, "(_state & LockStates.ReadersMask) != 0");
                $.$spc.System.Diagnostics.Debug.Assert$1(threadLocalLockEntry._readerLevel > 0, "threadLocalLockEntry._readerLevel > 0");
                --threadLocalLockEntry._readerLevel;
                if (threadLocalLockEntry._readerLevel > 0)
                {
                    return;
                }
                /*bool*/ let isLastReader;
                /*bool*/ let cacheEvents;
                /*AutoResetEvent?*/ let writerEvent = null;
                /*ManualResetEventSlim?*/ let readerEvent = null;
                /*int*/ let currentState = this._state;
                /*int*/ let knownState;
                do
                {
                    isLastReader = false;
                    cacheEvents = false;
                    knownState = currentState;
                    /*int*/ let modifyState = -1/*LockStates.Reader*/;
                    if ((knownState & (1023/*LockStates.ReadersMask*/ | 1024/*LockStates.ReaderSignaled*/)) === 1/*LockStates.Reader*/)
                    {
                        isLastReader = true;
                        if ((knownState & -8388608/*LockStates.WaitingWritersMask*/) !== 0)
                        {
                            writerEvent = this.TryGetOrCreateWriterEvent();
                            if (writerEvent === null)
                            {
                                $.$spc.System.Threading.Thread.Sleep(100);
                                currentState = this._state;
                                knownState = 0;
                                $.$spc.System.Diagnostics.Debug.Assert$1(currentState !== knownState, "currentState != knownState");
                                continue;
                            }
                            modifyState += 2048/*LockStates.WriterSignaled*/;
                        }
                        else if ((knownState & 8380416/*LockStates.WaitingReadersMask*/) !== 0)
                        {
                            readerEvent = this.TryGetOrCreateReaderEvent();
                            if (readerEvent === null)
                            {
                                $.$spc.System.Threading.Thread.Sleep(100);
                                currentState = this._state;
                                knownState = 0;
                                $.$spc.System.Diagnostics.Debug.Assert$1(currentState !== knownState, "currentState != knownState");
                                continue;
                            }
                            modifyState += 1024/*LockStates.ReaderSignaled*/;
                        }
                        else if (knownState === 1/*LockStates.Reader*/ && (this._readerEvent !== null || this._writerEvent !== null))
                        {
                            cacheEvents = true;
                            modifyState += 3072/*LockStates.CachingEvents*/;
                        }
                    }
                    $.$spc.System.Diagnostics.Debug.Assert$1((knownState & 4096/*LockStates.Writer*/) === 0, "(knownState & LockStates.Writer) == 0");
                    $.$spc.System.Diagnostics.Debug.Assert$1((knownState & 1023/*LockStates.ReadersMask*/) !== 0, "(knownState & LockStates.ReadersMask) != 0");
                    currentState = $.$spc.System.Threading.Interlocked.CompareExchange($.$ref(() => this._state, ($v) => this._state = $v, $.$spc.System.Int32), ((knownState + modifyState) | 0), knownState);
                }
                while(currentState !== knownState);
                if (isLastReader)
                {
                    if ((knownState & -8388608/*LockStates.WaitingWritersMask*/) !== 0)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1((this._state & 2048/*LockStates.WriterSignaled*/) !== 0, "(_state & LockStates.WriterSignaled) != 0");
                        $.$spc.System.Diagnostics.Debug.Assert$1(writerEvent !== null, "writerEvent != null");
                        writerEvent.Set$1();
                    }
                    else if ((knownState & 8380416/*LockStates.WaitingReadersMask*/) !== 0)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1((this._state & 1024/*LockStates.ReaderSignaled*/) !== 0, "(_state & LockStates.ReaderSignaled) != 0");
                        $.$spc.System.Diagnostics.Debug.Assert$1(readerEvent !== null, "readerEvent != null");
                        readerEvent.Set$1();
                    }
                    else if (cacheEvents)
                    {
                        this.ReleaseEvents();
                    }
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(threadLocalLockEntry.IsFree, "threadLocalLockEntry.IsFree");
            }
            /*void */ ReleaseWriterLock()
            {
                if (this._writerID !== $.$st.System.Threading.ReaderWriterLock.GetCurrentThreadID())
                {
                    throw $.$st.System.Threading.ReaderWriterLock.GetNotOwnerException();
                }
                $.$spc.System.Diagnostics.Debug.Assert$1((this._state & 1023/*LockStates.ReadersMask*/) === 0, "(_state & LockStates.ReadersMask) == 0");
                $.$spc.System.Diagnostics.Debug.Assert$1((this._state & 4096/*LockStates.Writer*/) !== 0, "(_state & LockStates.Writer) != 0");
                $.$spc.System.Diagnostics.Debug.Assert$1(this._writerLevel > 0, "_writerLevel > 0");
                --this._writerLevel;
                if (this._writerLevel > 0)
                {
                    return;
                }
                this._writerID = -1/*InvalidThreadID*/;
                /*bool*/ let cacheEvents;
                /*ManualResetEventSlim?*/ let readerEvent = null;
                /*AutoResetEvent?*/ let writerEvent = null;
                /*int*/ let currentState = this._state;
                /*int*/ let knownState;
                do
                {
                    cacheEvents = false;
                    knownState = currentState;
                    /*int*/ let modifyState = -4096/*LockStates.Writer*/;
                    if ((knownState & 8380416/*LockStates.WaitingReadersMask*/) !== 0)
                    {
                        readerEvent = this.TryGetOrCreateReaderEvent();
                        if (readerEvent === null)
                        {
                            $.$spc.System.Threading.Thread.Sleep(100);
                            currentState = this._state;
                            knownState = 0;
                            $.$spc.System.Diagnostics.Debug.Assert$1(currentState !== knownState, "currentState != knownState");
                            continue;
                        }
                        modifyState += 1024/*LockStates.ReaderSignaled*/;
                    }
                    else if ((knownState & -8388608/*LockStates.WaitingWritersMask*/) !== 0)
                    {
                        writerEvent = this.TryGetOrCreateWriterEvent();
                        if (writerEvent === null)
                        {
                            $.$spc.System.Threading.Thread.Sleep(100);
                            currentState = this._state;
                            knownState = 0;
                            $.$spc.System.Diagnostics.Debug.Assert$1(currentState !== knownState, "currentState != knownState");
                            continue;
                        }
                        modifyState += 2048/*LockStates.WriterSignaled*/;
                    }
                    else if (knownState === 4096/*LockStates.Writer*/ && (this._readerEvent !== null || this._writerEvent !== null))
                    {
                        cacheEvents = true;
                        modifyState += 3072/*LockStates.CachingEvents*/;
                    }
                    $.$spc.System.Diagnostics.Debug.Assert$1((knownState & 1023/*LockStates.ReadersMask*/) === 0, "(knownState & LockStates.ReadersMask) == 0");
                    $.$spc.System.Diagnostics.Debug.Assert$1((knownState & 4096/*LockStates.Writer*/) !== 0, "(knownState & LockStates.Writer) != 0");
                    currentState = $.$spc.System.Threading.Interlocked.CompareExchange($.$ref(() => this._state, ($v) => this._state = $v, $.$spc.System.Int32), ((knownState + modifyState) | 0), knownState);
                }
                while(currentState !== knownState);
                if ((knownState & 8380416/*LockStates.WaitingReadersMask*/) !== 0)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1((this._state & 1024/*LockStates.ReaderSignaled*/) !== 0, "(_state & LockStates.ReaderSignaled) != 0");
                    $.$spc.System.Diagnostics.Debug.Assert$1(readerEvent !== null, "readerEvent != null");
                    readerEvent.Set$1();
                }
                else if ((knownState & -8388608/*LockStates.WaitingWritersMask*/) !== 0)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1((this._state & 2048/*LockStates.WriterSignaled*/) !== 0, "(_state & LockStates.WriterSignaled) != 0");
                    $.$spc.System.Diagnostics.Debug.Assert$1(writerEvent !== null, "writerEvent != null");
                    writerEvent.Set$1();
                }
                else if (cacheEvents)
                {
                    this.ReleaseEvents();
                }
            }
            /*LockCookie */ UpgradeToWriterLock(/*int*/ millisecondsTimeout)
            {
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfLessThan($.$spc.System.Int32, millisecondsTimeout, -1, "millisecondsTimeout");
                /*LockCookie*/ let lockCookie = new $.$st.System.Threading.LockCookie();
                /*int*/ let threadID = $.$st.System.Threading.ReaderWriterLock.GetCurrentThreadID();
                lockCookie._threadID = threadID;
                if (this._writerID === threadID)
                {
                    lockCookie._flags = 8192/*LockCookieFlags.Upgrade*/ | 131072/*LockCookieFlags.OwnedWriter*/;
                    lockCookie._writerLevel = this._writerLevel;
                    this.AcquireWriterLock(millisecondsTimeout);
                    return lockCookie;
                }
                /*ThreadLocalLockEntry?*/ let threadLocalLockEntry = $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.GetCurrent(this._lockID);
                if (threadLocalLockEntry === null)
                {
                    lockCookie._flags = 8192/*LockCookieFlags.Upgrade*/ | 65536/*LockCookieFlags.OwnedNone*/;
                }
                else 
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1((this._state & 1023/*LockStates.ReadersMask*/) !== 0, "(_state & LockStates.ReadersMask) != 0");
                    $.$spc.System.Diagnostics.Debug.Assert$1(threadLocalLockEntry._readerLevel > 0, "threadLocalLockEntry._readerLevel > 0");
                    lockCookie._flags = 8192/*LockCookieFlags.Upgrade*/ | 262144/*LockCookieFlags.OwnedReader*/;
                    lockCookie._readerLevel = threadLocalLockEntry._readerLevel;
                    /*int*/ let knownState = $.$spc.System.Threading.Interlocked.CompareExchange($.$ref(() => this._state, ($v) => this._state = $v, $.$spc.System.Int32), 4096/*LockStates.Writer*/, 1/*LockStates.Reader*/);
                    if (knownState === 1/*LockStates.Reader*/)
                    {
                        threadLocalLockEntry._readerLevel = 0;
                        $.$spc.System.Diagnostics.Debug.Assert$1(threadLocalLockEntry.IsFree, "threadLocalLockEntry.IsFree");
                        this._writerID = threadID;
                        this._writerLevel = 1;
                        ++this._writerSeqNum;
                        return lockCookie;
                    }
                    threadLocalLockEntry._readerLevel = 1;
                    this.ReleaseReaderLock();
                }
                /*bool*/ let acquired = false;
                try
                {
                    this.AcquireWriterLock(millisecondsTimeout);
                    acquired = true;
                    return lockCookie;
                }
                finally
                {
                    {
                        if (!acquired)
                        {
                            /*LockCookieFlags*/ let flags = lockCookie._flags;
                            lockCookie._flags = -483329/*LockCookieFlags.Invalid*/;
                            this.RecoverLock($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$st.System.Threading.LockCookie, () => lockCookie, ($v) => lockCookie = $v, null), flags & 262144/*LockCookieFlags.OwnedReader*/);
                        }
                    }
                }
            }
            /*LockCookie */ UpgradeToWriterLock$1(/*TimeSpan*/ timeout)
            {
                return this.UpgradeToWriterLock($.$st.System.Threading.ReaderWriterLock.ToTimeoutMilliseconds(timeout));
            }
            /*void */ DowngradeFromWriterLock(/*ref LockCookie*/ lockCookie)
            {
                /*int*/ let threadID = $.$st.System.Threading.ReaderWriterLock.GetCurrentThreadID();
                if (this._writerID !== threadID)
                {
                    throw $.$st.System.Threading.ReaderWriterLock.GetNotOwnerException();
                }
                /*LockCookieFlags*/ let flags = lockCookie.$v._flags;
                /*ushort*/ let requestedWriterLevel = lockCookie.$v._writerLevel;
                if ((flags & -483329/*LockCookieFlags.Invalid*/) !== 0 || lockCookie.$v._threadID !== threadID || ((flags & (131072/*LockCookieFlags.OwnedWriter*/ | 65536/*LockCookieFlags.OwnedNone*/)) !== 0 && this._writerLevel <= requestedWriterLevel))
                {
                    throw $.$st.System.Threading.ReaderWriterLock.GetInvalidLockCookieException();
                }
                if ((flags & 262144/*LockCookieFlags.OwnedReader*/) !== 0)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._writerLevel > 0, "_writerLevel > 0");
                    /*ThreadLocalLockEntry*/ let threadLocalLockEntry = $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.GetOrCreateCurrent(this._lockID);
                    this._writerID = -1/*InvalidThreadID*/;
                    this._writerLevel = 0;
                    /*ManualResetEventSlim?*/ let readerEvent = null;
                    /*int*/ let currentState = this._state;
                    /*int*/ let knownState;
                    do
                    {
                        knownState = currentState;
                        /*int*/ let modifyState = ((1/*LockStates.Reader*/ - 4096/*LockStates.Writer*/) | 0);
                        if ((knownState & 8380416/*LockStates.WaitingReadersMask*/) !== 0)
                        {
                            readerEvent = this.TryGetOrCreateReaderEvent();
                            if (readerEvent === null)
                            {
                                $.$spc.System.Threading.Thread.Sleep(100);
                                currentState = this._state;
                                knownState = 0;
                                $.$spc.System.Diagnostics.Debug.Assert$1(currentState !== knownState, "currentState != knownState");
                                continue;
                            }
                            modifyState += 1024/*LockStates.ReaderSignaled*/;
                        }
                        $.$spc.System.Diagnostics.Debug.Assert$1((knownState & 1023/*LockStates.ReadersMask*/) === 0, "(knownState & LockStates.ReadersMask) == 0");
                        currentState = $.$spc.System.Threading.Interlocked.CompareExchange($.$ref(() => this._state, ($v) => this._state = $v, $.$spc.System.Int32), ((knownState + modifyState) | 0), knownState);
                    }
                    while(currentState !== knownState);
                    if ((knownState & 8380416/*LockStates.WaitingReadersMask*/) !== 0)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1((this._state & 1024/*LockStates.ReaderSignaled*/) !== 0, "(_state & LockStates.ReaderSignaled) != 0");
                        $.$spc.System.Diagnostics.Debug.Assert$1(readerEvent !== null, "readerEvent != null");
                        readerEvent.Set$1();
                    }
                    threadLocalLockEntry._readerLevel = lockCookie.$v._readerLevel;
                }
                else if ((flags & (131072/*LockCookieFlags.OwnedWriter*/ | 65536/*LockCookieFlags.OwnedNone*/)) !== 0)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._writerLevel > 0, "_writerLevel > 0");
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._writerLevel > requestedWriterLevel, "_writerLevel > requestedWriterLevel");
                    if (requestedWriterLevel > 0)
                    {
                        this._writerLevel = requestedWriterLevel;
                    }
                    else 
                    {
                        if (this._writerLevel !== 1)
                        {
                            this._writerLevel = 1;
                        }
                        this.ReleaseWriterLock();
                    }
                    $.$spc.System.Diagnostics.Debug.Assert$1((flags & 131072/*LockCookieFlags.OwnedWriter*/) !== 0 || this._writerID !== threadID, "(flags & LockCookieFlags.OwnedWriter) != 0 || _writerID != threadID");
                }
                lockCookie.$v._flags = -483329/*LockCookieFlags.Invalid*/;
            }
            /*LockCookie */ ReleaseLock()
            {
                /*LockCookie*/ let lockCookie = new $.$st.System.Threading.LockCookie();
                /*int*/ let threadID = $.$st.System.Threading.ReaderWriterLock.GetCurrentThreadID();
                lockCookie._threadID = threadID;
                if (this._writerID === threadID)
                {
                    lockCookie._flags = 16384/*LockCookieFlags.Release*/ | 131072/*LockCookieFlags.OwnedWriter*/;
                    lockCookie._writerLevel = this._writerLevel;
                    this._writerLevel = 1;
                    this.ReleaseWriterLock();
                    return lockCookie;
                }
                /*ThreadLocalLockEntry?*/ let threadLocalLockEntry = $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.GetCurrent(this._lockID);
                if (threadLocalLockEntry === null)
                {
                    lockCookie._flags = 16384/*LockCookieFlags.Release*/ | 65536/*LockCookieFlags.OwnedNone*/;
                    return lockCookie;
                }
                $.$spc.System.Diagnostics.Debug.Assert$1((this._state & 1023/*LockStates.ReadersMask*/) !== 0, "(_state & LockStates.ReadersMask) != 0");
                $.$spc.System.Diagnostics.Debug.Assert$1(threadLocalLockEntry._readerLevel > 0, "threadLocalLockEntry._readerLevel > 0");
                lockCookie._flags = 16384/*LockCookieFlags.Release*/ | 262144/*LockCookieFlags.OwnedReader*/;
                lockCookie._readerLevel = threadLocalLockEntry._readerLevel;
                threadLocalLockEntry._readerLevel = 1;
                this.ReleaseReaderLock();
                return lockCookie;
            }
            /*void */ RestoreLock(/*ref LockCookie*/ lockCookie)
            {
                /*int*/ let threadID = $.$st.System.Threading.ReaderWriterLock.GetCurrentThreadID();
                if (lockCookie.$v._threadID !== threadID)
                {
                    throw $.$st.System.Threading.ReaderWriterLock.GetInvalidLockCookieException();
                }
                if (this._writerID === threadID || $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.GetCurrent(this._lockID) !== null)
                {
                    throw new $.$spc.System.Threading.SynchronizationLockException().$ctor$10($.$st.System.SR.ReaderWriterLock_RestoreLockWithOwnedLocks);
                }
                /*LockCookieFlags*/ let flags = lockCookie.$v._flags;
                if ((flags & -483329/*LockCookieFlags.Invalid*/) !== 0)
                {
                    throw $.$st.System.Threading.ReaderWriterLock.GetInvalidLockCookieException();
                }
                do
                {
                    if ((flags & 65536/*LockCookieFlags.OwnedNone*/) !== 0)
                    {
                        break;
                    }
                    if ((flags & 131072/*LockCookieFlags.OwnedWriter*/) !== 0)
                    {
                        if ($.$spc.System.Threading.Interlocked.CompareExchange($.$ref(() => this._state, ($v) => this._state = $v, $.$spc.System.Int32), 4096/*LockStates.Writer*/, 0) === 0)
                        {
                            this._writerID = threadID;
                            this._writerLevel = lockCookie.$v._writerLevel;
                            ++this._writerSeqNum;
                            break;
                        }
                    }
                    else if ((flags & 262144/*LockCookieFlags.OwnedReader*/) !== 0)
                    {
                        /*ThreadLocalLockEntry*/ let threadLocalLockEntry = $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.GetOrCreateCurrent(this._lockID);
                        $.$spc.System.Diagnostics.Debug.Assert$1(threadLocalLockEntry.IsFree, "threadLocalLockEntry.IsFree");
                        /*int*/ let knownState = this._state;
                        if (knownState < 1023/*LockStates.ReadersMask*/ && $.$spc.System.Threading.Interlocked.CompareExchange($.$ref(() => this._state, ($v) => this._state = $v, $.$spc.System.Int32), ((knownState + 1/*LockStates.Reader*/) | 0), knownState) === knownState)
                        {
                            threadLocalLockEntry._readerLevel = lockCookie.$v._readerLevel;
                            break;
                        }
                    }
                    this.RecoverLock(lockCookie, flags);
                }
                while(false);
                lockCookie.$v._flags = -483329/*LockCookieFlags.Invalid*/;
            }
            /*void */ RecoverLock(/*ref LockCookie*/ lockCookie, /*LockCookieFlags*/ flags)
            {
                if ((flags & 131072/*LockCookieFlags.OwnedWriter*/) !== 0)
                {
                    this.AcquireWriterLock(-1/*Timeout.Infinite*/);
                    this._writerLevel = lockCookie.$v._writerLevel;
                }
                else if ((flags & 262144/*LockCookieFlags.OwnedReader*/) !== 0)
                {
                    this.AcquireReaderLock(-1/*Timeout.Infinite*/);
                    /*ThreadLocalLockEntry?*/ let threadLocalLockEntry = $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.GetCurrent(this._lockID);
                    $.$spc.System.Diagnostics.Debug.Assert$1(threadLocalLockEntry !== null, "threadLocalLockEntry != null");
                    threadLocalLockEntry._readerLevel = lockCookie.$v._readerLevel;
                }
            }
            static /*int */ GetCurrentThreadID()
            {
                /*int*/ let threadID = $.$spc.System.Environment.CurrentManagedThreadId;
                $.$spc.System.Diagnostics.Debug.Assert$1(threadID !== -1/*InvalidThreadID*/, "threadID != InvalidThreadID");
                return threadID;
            }
            static /*bool */ YieldProcessor()
            {
                $.$spc.System.Threading.Thread.SpinWait(1);
                return true;
            }
            /*ManualResetEventSlim */ GetOrCreateReaderEvent()
            {
                /*ManualResetEventSlim?*/ let currentEvent = this._readerEvent;
                if (currentEvent !== null)
                {
                    return currentEvent;
                }
                currentEvent = new $.$spc.System.Threading.ManualResetEventSlim().$ctor$3(false, 0);
                /*ManualResetEventSlim?*/ let previousEvent = $.$spc.System.Threading.Interlocked.CompareExchange$14($.$spc.System.Threading.ManualResetEventSlim, $.$ref(() => this._readerEvent, ($v) => this._readerEvent = $v, $.$spc.System.Threading.ManualResetEventSlim), currentEvent, null);
                if (previousEvent === null)
                {
                    return currentEvent;
                }
                currentEvent.Dispose();
                return previousEvent;
            }
            /*AutoResetEvent */ GetOrCreateWriterEvent()
            {
                /*AutoResetEvent?*/ let currentEvent = this._writerEvent;
                if (currentEvent !== null)
                {
                    return currentEvent;
                }
                currentEvent = new $.$spc.System.Threading.AutoResetEvent().$ctor$8(false);
                /*AutoResetEvent?*/ let previousEvent = $.$spc.System.Threading.Interlocked.CompareExchange$14($.$spc.System.Threading.AutoResetEvent, $.$ref(() => this._writerEvent, ($v) => this._writerEvent = $v, $.$spc.System.Threading.AutoResetEvent), currentEvent, null);
                if (previousEvent === null)
                {
                    return currentEvent;
                }
                currentEvent.Dispose$1();
                return previousEvent;
            }
            /*ManualResetEventSlim? */ TryGetOrCreateReaderEvent()
            {
                try
                {
                    return this.GetOrCreateReaderEvent();
                }
                catch($e)
                {
                    return null;
                }
            }
            /*AutoResetEvent? */ TryGetOrCreateWriterEvent()
            {
                try
                {
                    return this.GetOrCreateWriterEvent();
                }
                catch($e)
                {
                    return null;
                }
            }
            /*void */ ReleaseEvents()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1((this._state & 3072/*LockStates.CachingEvents*/) === 3072/*LockStates.CachingEvents*/, "(_state & LockStates.CachingEvents) == LockStates.CachingEvents");
                /*AutoResetEvent?*/ let writerEvent = this._writerEvent;
                this._writerEvent = null;
                /*ManualResetEventSlim?*/ let readerEvent = this._readerEvent;
                this._readerEvent = null;
                $.$spc.System.Threading.Interlocked.Add($.$ref(() => this._state, ($v) => this._state = $v, $.$spc.System.Int32), -3072/*LockStates.CachingEvents*/);
                writerEvent?.Dispose$1();
                readerEvent?.Dispose();
            }
            static /*int */ ToTimeoutMilliseconds(/*TimeSpan*/ timeout)
            {
                /*var*/ let timeoutMilliseconds = $.$cast(timeout.TotalMilliseconds, $.$spc.System.Int64);
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfLessThan($.$spc.System.Int64, timeoutMilliseconds, BigInt(-1), "timeout");
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$spc.System.Int64, timeoutMilliseconds, BigInt(2147483647/*int.MaxValue*/), "timeout");
                return $.$cast(timeoutMilliseconds, $.$spc.System.Int32);
            }
            static $_ReaderWriterLockApplicationException;
            static get ReaderWriterLockApplicationException()
            {
                let $cls = $.$st.System.Threading.ReaderWriterLock;
                return $cls.$_ReaderWriterLockApplicationException ??= $asm.$ncls("$st.System.Threading.ReaderWriterLock.ReaderWriterLockApplicationException", ($self) => class ReaderWriterLockApplicationException extends $.$spc.System.ApplicationException
                {
                    $ctor$9(/*int*/ errorHResult, /*string*/ message)
                    {
                        super.$ctor$6($.$st.System.SR.Format(message, $.$st.System.SR.Format($.$st.System.SR.ExceptionFromHResult, $.$box(errorHResult, $.$spc.System.Int32))));
                        {
                            this.HResult = errorHResult;
                        }
                        return this;
                    }
                    $ctor$10(/*SerializationInfo*/ info, /*StreamingContext*/ context)
                    {
                        super.$ctor$8(info, context);
                        {
                        }
                        return this;
                    }
                    static $h = 1034773;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":13303809,"d":903701,"h":1034773}; }
                    static get $b() { return $.$spc.System.ApplicationException; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
                    static get $fullName() { return `System.Threading.ReaderWriterLock.ReaderWriterLockApplicationException`; }
                }, $cls, ($v) => $cls.$_ReaderWriterLockApplicationException = $v);
            }
            static /*ReaderWriterLockApplicationException */ GetTimeoutException()
            {
                return new $.$st.System.Threading.ReaderWriterLock.ReaderWriterLockApplicationException().$ctor$9(-2147023436/*HResults.ERROR_TIMEOUT*/, $.$st.System.SR.ReaderWriterLock_Timeout);
            }
            static /*ReaderWriterLockApplicationException */ GetNotOwnerException()
            {
                return new $.$st.System.Threading.ReaderWriterLock.ReaderWriterLockApplicationException().$ctor$9(288/*IncorrectButCompatibleNotOwnerExceptionHResult*/, $.$st.System.SR.ReaderWriterLock_NotOwner);
            }
            static /*ReaderWriterLockApplicationException */ GetInvalidLockCookieException()
            {
                return new $.$st.System.Threading.ReaderWriterLock.ReaderWriterLockApplicationException().$ctor$9(-2147024809/*HResults.E_INVALIDARG*/, $.$st.System.SR.ReaderWriterLock_InvalidLockCookie);
            }
            static $_LockStates;
            static get LockStates()
            {
                let $cls = $.$st.System.Threading.ReaderWriterLock;
                return $cls.$_LockStates ??= $asm.$ncls("$st.System.Threading.ReaderWriterLock.LockStates", ($self) => class LockStates
                {
                    /*int*/ static Reader = 1;
                    /*int*/ static ReadersMask = 1023;
                    /*int*/ static ReaderSignaled = 1024;
                    /*int*/ static WriterSignaled = 2048;
                    /*int*/ static Writer = 4096;
                    /*int*/ static WaitingReader = 8192;
                    /*int*/ static WaitingReadersMask = 8380416;
                    /*int*/ static WaitingReadersShift = 13;
                    /*int*/ static WaitingWriter = 8388608;
                    /*int*/ static WaitingWritersMask = -8388608;
                    /*int*/ static CachingEvents = 3072;
                    static $h = 969237;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"Reader","d":969237,"h":4295936533,"f":33},{"t":655361,"n":"ReadersMask","d":969237,"h":8590903829,"f":33},{"t":655361,"n":"ReaderSignaled","d":969237,"h":12885871125,"f":33},{"t":655361,"n":"WriterSignaled","d":969237,"h":17180838421,"f":33},{"t":655361,"n":"Writer","d":969237,"h":21475805717,"f":33},{"t":655361,"n":"WaitingReader","d":969237,"h":25770773013,"f":33},{"t":655361,"n":"WaitingReadersMask","d":969237,"h":30065740309,"f":33},{"t":655361,"n":"WaitingReadersShift","d":969237,"h":34360707605,"f":33},{"t":655361,"n":"WaitingWriter","d":969237,"h":38655674901,"f":33},{"t":655361,"n":"WaitingWritersMask","d":969237,"h":42950642197,"f":33},{"t":655361,"n":"CachingEvents","d":969237,"h":47245609493,"f":33}],"d":903701,"h":969237}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Threading.ReaderWriterLock.LockStates`; }
                }, $cls, ($v) => $cls.$_LockStates = $v);
            }
            static $_ThreadLocalLockEntry;
            static get ThreadLocalLockEntry()
            {
                let $cls = $.$st.System.Threading.ReaderWriterLock;
                return $cls.$_ThreadLocalLockEntry ??= $asm.$ncls("$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry", ($self) => class ThreadLocalLockEntry extends $.$spc.System.Object
                {
                    /*ThreadLocalLockEntry?*/ static t_lockEntryHead = null;
                    /*long*/ _lockID = 0n;
                    /*ThreadLocalLockEntry?*/ _next = null;
                    /*ushort*/ _readerLevel = 0;
                    $ctor$1(/*long*/ lockID)
                    {
                        super.$ctor();
                        {
                            this._lockID = lockID;
                        }
                        return this;
                    }
                    /*bool */ HasLockID(/*long*/ lockID)
                    {
                        return this._lockID === lockID;
                    }
                    /*bool */ get IsFree()
                    {
                        return this._readerLevel === 0;
                    }
                    static /*void */ VerifyNoNonemptyEntryInListAfter(/*long*/ lockID, /*ThreadLocalLockEntry*/ afterEntry)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(lockID !== 0n, "lockID != 0");
                        $.$spc.System.Diagnostics.Debug.Assert$1(afterEntry !== null, "afterEntry != null");
                        for(/*ThreadLocalLockEntry?*/ let currentEntry = afterEntry._next; currentEntry !== null; currentEntry = currentEntry._next)
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(currentEntry._lockID !== lockID || currentEntry.IsFree, "currentEntry._lockID != lockID || currentEntry.IsFree");
                        }
                    }
                    static /*ThreadLocalLockEntry? */ GetCurrent(/*long*/ lockID)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(lockID !== 0n, "lockID != 0");
                        /*ThreadLocalLockEntry?*/ let headEntry = $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.t_lockEntryHead;
                        for(/*ThreadLocalLockEntry?*/ let currentEntry = headEntry; currentEntry !== null; currentEntry = currentEntry._next)
                        {
                            if (currentEntry._lockID === lockID)
                            {
                                $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.VerifyNoNonemptyEntryInListAfter(lockID, currentEntry);
                                return currentEntry.IsFree ? null : currentEntry;
                            }
                        }
                        return null;
                    }
                    static /*ThreadLocalLockEntry */ GetOrCreateCurrent(/*long*/ lockID)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(lockID !== 0n, "lockID != 0");
                        /*ThreadLocalLockEntry?*/ let headEntry = $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.t_lockEntryHead;
                        if (headEntry !== null && headEntry._lockID === lockID)
                        {
                            $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.VerifyNoNonemptyEntryInListAfter(lockID, headEntry);
                            return headEntry;
                        }
                        return $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.GetOrCreateCurrentSlow(lockID, headEntry);
                    }
                    static /*ThreadLocalLockEntry */ GetOrCreateCurrentSlow(/*long*/ lockID, /*ThreadLocalLockEntry?*/ headEntry)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(lockID !== 0n, "lockID != 0");
                        $.$spc.System.Diagnostics.Debug.Assert$1(headEntry === $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.t_lockEntryHead, "headEntry == t_lockEntryHead");
                        $.$spc.System.Diagnostics.Debug.Assert$1(headEntry === null || headEntry._lockID !== lockID, "headEntry == null || headEntry._lockID != lockID");
                        /*ThreadLocalLockEntry?*/ let entry = null;
                        /*ThreadLocalLockEntry?*/ let emptyEntryPrevious = null;
                        /*ThreadLocalLockEntry?*/ let emptyEntry = null;
                        if (headEntry !== null)
                        {
                            if (headEntry.IsFree)
                            {
                                emptyEntry = headEntry;
                            }
                            for(/*ThreadLocalLockEntry?*/ let previousEntry = headEntry, currentEntry = headEntry._next; currentEntry !== null; previousEntry = currentEntry, currentEntry = currentEntry._next)
                            {
                                if (currentEntry._lockID === lockID)
                                {
                                    $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.VerifyNoNonemptyEntryInListAfter(lockID, currentEntry);
                                    previousEntry._next = currentEntry._next;
                                    entry = currentEntry;
                                    break;
                                }
                                if (emptyEntry === null && currentEntry.IsFree)
                                {
                                    emptyEntryPrevious = previousEntry;
                                    emptyEntry = currentEntry;
                                }
                            }
                        }
                        if (entry === null)
                        {
                            if (emptyEntry !== null)
                            {
                                emptyEntry._lockID = lockID;
                                if (emptyEntryPrevious === null)
                                {
                                    $.$spc.System.Diagnostics.Debug.Assert$1(emptyEntry === headEntry, "emptyEntry == headEntry");
                                    return emptyEntry;
                                }
                                emptyEntryPrevious._next = emptyEntry._next;
                                entry = emptyEntry;
                            }
                            else 
                            {
                                entry = new $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry().$ctor$1(lockID);
                            }
                        }
                        $.$spc.System.Diagnostics.Debug.Assert$1(entry._lockID === lockID, "entry._lockID == lockID");
                        entry._next = headEntry;
                        $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.t_lockEntryHead = entry;
                        return entry;
                    }
                    static $h = 1100309;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":34360838677,"f":1},"n":"IsFree","d":1100309,"h":30065871381,"f":1}],"m":[{"r":262145,"p":[{"n":"lockID","p":917505}],"n":"HasLockID","d":1100309,"h":25770904085,"f":1},{"r":65537,"p":[{"n":"lockID","p":917505},{"n":"afterEntry","p":1100309}],"n":"VerifyNoNonemptyEntryInListAfter","d":1100309,"h":38655805973,"f":34,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"DEBUG","t":1310721}]}]},{"r":1100309,"p":[{"n":"lockID","p":917505}],"n":"GetCurrent","d":1100309,"h":42950773269,"f":33},{"r":1100309,"p":[{"n":"lockID","p":917505}],"n":"GetOrCreateCurrent","d":1100309,"h":47245740565,"f":33},{"r":1100309,"p":[{"n":"lockID","p":917505},{"n":"headEntry","p":1100309}],"n":"GetOrCreateCurrentSlow","d":1100309,"h":51540707861,"f":34}],"l":[{"t":1100309,"n":"t_lockEntryHead","d":1100309,"h":4296067605,"f":34,"a":[{"t":140181505,"c":4435148801}]},{"t":917505,"n":"_lockID","d":1100309,"h":8591034901,"f":2},{"t":1100309,"n":"_next","d":1100309,"h":12886002197,"f":2},{"t":589825,"n":"_readerLevel","d":1100309,"h":17180969493,"f":1}],"c":[{"p":[{"n":"lockID","p":917505}],"n":".ctor","o":"$ctor$1","d":1100309,"h":21475936789,"f":2}],"d":903701,"h":1100309}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Threading.ReaderWriterLock.ThreadLocalLockEntry`; }
                }, $cls, ($v) => $cls.$_ThreadLocalLockEntry = $v);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.DefaultSpinCount = /*Environment.ProcessorCount != 1 ? 500 : */ 0;
                }
            }
            static $h = 903701;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":97124353,"p":[{"p":262145,"g":{"r":0,"d":0,"h":64425413141,"f":1},"n":"IsReaderLockHeld","d":903701,"h":60130445845,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":73015347733,"f":1},"n":"IsWriterLockHeld","d":903701,"h":68720380437,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":81605282325,"f":1},"n":"WriterSeqNum","d":903701,"h":77310315029,"f":1}],"m":[{"r":262145,"p":[{"n":"seqNum","p":655361}],"n":"AnyWritersSince","d":903701,"h":85900249621,"f":1},{"r":65537,"p":[{"n":"millisecondsTimeout","p":655361}],"n":"AcquireReaderLock","d":903701,"h":90195216917,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]}]},{"r":65537,"p":[{"n":"timeout","p":140705793}],"n":"AcquireReaderLock","o":"@$1","d":903701,"h":94490184213,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]}]},{"r":65537,"p":[{"n":"millisecondsTimeout","p":655361}],"n":"AcquireWriterLock","d":903701,"h":98785151509,"f":1},{"r":65537,"p":[{"n":"timeout","p":140705793}],"n":"AcquireWriterLock","o":"@$1","d":903701,"h":103080118805,"f":1},{"r":65537,"n":"ReleaseReaderLock","d":903701,"h":107375086101,"f":1},{"r":65537,"n":"ReleaseWriterLock","d":903701,"h":111670053397,"f":1},{"r":772629,"p":[{"n":"millisecondsTimeout","p":655361}],"n":"UpgradeToWriterLock","d":903701,"h":115965020693,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]}]},{"r":772629,"p":[{"n":"timeout","p":140705793}],"n":"UpgradeToWriterLock","o":"@$1","d":903701,"h":120259987989,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]}]},{"r":65537,"p":[{"n":"lockCookie","p":772629,"f":4}],"n":"DowngradeFromWriterLock","d":903701,"h":124554955285,"f":1},{"r":772629,"n":"ReleaseLock","d":903701,"h":128849922581,"f":1},{"r":65537,"p":[{"n":"lockCookie","p":772629,"f":4}],"n":"RestoreLock","d":903701,"h":133144889877,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]}]},{"r":65537,"p":[{"n":"lockCookie","p":772629,"f":4},{"n":"flags","p":838165}],"n":"RecoverLock","d":903701,"h":137439857173,"f":2,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]}]},{"r":655361,"n":"GetCurrentThreadID","d":903701,"h":141734824469,"f":34},{"r":262145,"n":"YieldProcessor","d":903701,"h":146029791765,"f":34},{"r":128385025,"n":"GetOrCreateReaderEvent","d":903701,"h":150324759061,"f":2},{"r":125894657,"n":"GetOrCreateWriterEvent","d":903701,"h":154619726357,"f":2},{"r":128385025,"n":"TryGetOrCreateReaderEvent","d":903701,"h":158914693653,"f":2},{"r":125894657,"n":"TryGetOrCreateWriterEvent","d":903701,"h":163209660949,"f":2},{"r":65537,"n":"ReleaseEvents","d":903701,"h":167504628245,"f":2},{"r":655361,"p":[{"n":"timeout","p":140705793}],"n":"ToTimeoutMilliseconds","d":903701,"h":171799595541,"f":34},{"r":1034773,"n":"GetTimeoutException","d":903701,"h":180389530133,"f":34},{"r":1034773,"n":"GetNotOwnerException","d":903701,"h":184684497429,"f":34},{"r":1034773,"n":"GetInvalidLockCookieException","d":903701,"h":188979464725,"f":34}],"l":[{"t":655361,"n":"InvalidThreadID","d":903701,"h":4295870997,"f":34},{"t":589825,"n":"MaxAcquireCount","d":903701,"h":8590838293,"f":34},{"t":655361,"n":"DefaultSpinCount","d":903701,"h":12885805589,"f":34},{"t":655361,"n":"IncorrectButCompatibleNotOwnerExceptionHResult","d":903701,"h":17180772885,"f":34},{"t":917505,"n":"s_mostRecentLockID","d":903701,"h":21475740181,"f":34},{"t":128385025,"n":"_readerEvent","d":903701,"h":25770707477,"f":2},{"t":125894657,"n":"_writerEvent","d":903701,"h":30065674773,"f":2},{"t":917505,"n":"_lockID","d":903701,"h":34360642069,"f":2},{"t":655361,"n":"_state","d":903701,"h":38655609365,"f":2},{"t":655361,"n":"_writerID","d":903701,"h":42950576661,"f":2},{"t":655361,"n":"_writerSeqNum","d":903701,"h":47245543957,"f":2},{"t":589825,"n":"_writerLevel","d":903701,"h":51540511253,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":903701,"h":55835478549,"f":1}],"j":[969237,1100309],"h":903701}; }
            static get $b() { return $.$spc.System.Runtime.ConstrainedExecution.CriticalFinalizerObject; }
            static get $fullName() { return `System.Threading.ReaderWriterLock`; }
        });
        
        $asm.$str("$st.System.Threading.LockCookie", ($self) => class LockCookie extends $.$spc.System.ValueType
        {
            /*LockCookieFlags*/  get _flags() { return this.$getField(0, $.$st.System.Threading.LockCookieFlags); }
            /*LockCookieFlags*/  set _flags(value) { this.$setField(0, $.$st.System.Threading.LockCookieFlags, value); }
            /*ushort*/  get _readerLevel() { return this.$getField(4, $.$spc.System.UInt16); }
            /*ushort*/  set _readerLevel(value) { this.$setField(4, $.$spc.System.UInt16, value); }
            /*ushort*/  get _writerLevel() { return this.$getField(6, $.$spc.System.UInt16); }
            /*ushort*/  set _writerLevel(value) { this.$setField(6, $.$spc.System.UInt16, value); }
            /*int*/  get _threadID() { return this.$getField(8, $.$spc.System.Int32); }
            /*int*/  set _threadID(value) { this.$setField(8, $.$spc.System.Int32, value); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return ((((((this._flags + this._readerLevel) | 0) + this._writerLevel) | 0) + this._threadID) | 0);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$st.System.Threading.LockCookie.GetHashCode.apply(this, arguments); }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                let other;
                return $.$is(obj, $.$st.System.Threading.LockCookie, { set $v(v){ other = v; } }) && this.Equals$2(other.Clone());
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$st.System.Threading.LockCookie.Equals.apply(this, arguments); }
            /*bool */ Equals$2(/*LockCookie*/ obj)
            {
                return this._flags === obj._flags && this._readerLevel === obj._readerLevel && this._writerLevel === obj._writerLevel && this._threadID === obj._threadID;
            }
            static /*bool */ op_Equality(/*LockCookie*/ a, /*LockCookie*/ b)
            {
                return a.Equals$2(b.Clone());
            }
            static /*bool */ op_Inequality(/*LockCookie*/ a, /*LockCookie*/ b)
            {
                return !a.Equals$2(b.Clone());
            }
            //Generated interface implemetation for System.IEquatable<System.Threading.LockCookie>.Equals(System.Threading.LockCookie)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._flags = this._flags;
                copy._readerLevel = this._readerLevel;
                copy._writerLevel = this._writerLevel;
                copy._threadID = this._threadID;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._flags = 0;
                this._readerLevel = 0;
                this._writerLevel = 0;
                this._threadID = 0;
            }
            static $h = 772629;
            static $z = 12;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"m":[{"r":655361,"n":"GetHashCode","d":772629,"h":21475609109,"f":32769},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":772629,"h":25770576405,"f":32769},{"r":262145,"p":[{"n":"obj","p":772629}],"n":"Equals","o":"@$2","d":772629,"h":30065543701,"f":1}],"l":[{"t":838165,"n":"_flags","d":772629,"h":4295739925,"f":8},{"t":589825,"n":"_readerLevel","d":772629,"h":8590707221,"f":8},{"t":589825,"n":"_writerLevel","d":772629,"h":12885674517,"f":8},{"t":655361,"n":"_threadID","d":772629,"h":17180641813,"f":8}],"c":[{"n":".ctor","o":"$ctor$2","d":772629,"h":42950445589,"f":1}],"i":[$.$spc.System.IEquatable$$($.$st.System.Threading.LockCookie).$h],"h":772629}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$st.System.Threading.LockCookie) ]; }
            static get $fullName() { return `System.Threading.LockCookie`; }
        });
        
        $asm.$str("$st.System.Threading.LockCookieFlags", ($self) => class LockCookieFlags extends $.$spc.System.Enum
        {
            static Upgrade = 8192;
            static Release = 16384;
            static OwnedNone = 65536;
            static OwnedWriter = 131072;
            static OwnedReader = 262144;
            static Invalid = -483329;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Upgrade": 8192n,
                    "Release": 16384n,
                    "OwnedNone": 65536n,
                    "OwnedWriter": 131072n,
                    "OwnedReader": 262144n,
                    "Invalid": -483329n
                };
            }
            static $h = 838165;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":838165,"n":"Upgrade","d":838165,"h":4295805461,"f":33},{"t":838165,"n":"Release","d":838165,"h":8590772757,"f":33},{"t":838165,"n":"OwnedNone","d":838165,"h":12885740053,"f":33},{"t":838165,"n":"OwnedWriter","d":838165,"h":17180707349,"f":33},{"t":838165,"n":"OwnedReader","d":838165,"h":21475674645,"f":33},{"t":838165,"n":"Invalid","d":838165,"h":25770641941,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":838165,"h":30065609237,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":838165,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Threading.LockCookieFlags`; }
        });
        
        $asm.$cls("$st.System.Threading.CdsSyncEtwBCLProvider", ($self) => class CdsSyncEtwBCLProvider extends $.$spc.System.Diagnostics.Tracing.EventSource
        {
            /*CdsSyncEtwBCLProvider*/ static Log = null;
            $ctor$8()
            {
                super.$ctor$4();
                {
                }
                return this;
            }
            /*EventKeywords*/ static ALL_KEYWORDS = -1n;
            /*int*/ static BARRIER_PHASEFINISHED_ID = 3;
            /*void */ Barrier_PhaseFinished(/*bool*/ currentSense, /*long*/ phaseNum)
            {
                if (this.IsEnabled$1(5/*EventLevel.Verbose*/, -1n))
                {
                    {
                        /*EventData**/ let eventPayload = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocPointer($.$spc.System.Diagnostics.Tracing.EventSource.EventData, 2, null);
                        /*int*/ let senseAsInt32 = currentSense ? 1 : 0;
                        eventPayload.SetAt((() =>
                        {
                            //new $.$spc.System.Diagnostics.Tracing.EventSource.EventData()
                            const $t1 = $.$spc.System.Diagnostics.Tracing.EventSource.EventData;
                            const $i1 = new $t1();
                            $i1.Size = $.$spc.System.Int32.$z;
                            $i1.DataPointer = ($.$cast(($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Int32, () => senseAsInt32, ($v) => senseAsInt32 = $v, null)), $.$spc.System.IntPtr));
                            return $i1;
                        })(), 0);
                        eventPayload.SetAt((() =>
                        {
                            //new $.$spc.System.Diagnostics.Tracing.EventSource.EventData()
                            const $t2 = $.$spc.System.Diagnostics.Tracing.EventSource.EventData;
                            const $i2 = new $t2();
                            $i2.Size = $.$spc.System.Int64.$z;
                            $i2.DataPointer = ($.$spc.InteropUtility.castObject2Address($.$box(phaseNum, $.$spc.System.Int64), 0, false));
                            return $i2;
                        })(), 1);
                        this.WriteEventCore(3/*BARRIER_PHASEFINISHED_ID*/, 2, eventPayload);
                    }
                }
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Log = new $.$st.System.Threading.CdsSyncEtwBCLProvider().$ctor$8();
                }
            }
            static $h = 444949;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":41746433,"m":[{"r":65537,"p":[{"n":"currentSense","p":262145},{"n":"phaseNum","p":917505}],"n":"Barrier_PhaseFinished","d":444949,"h":21475281429,"f":1,"a":[{"t":39976961,"c":4334944257,"a":[{"v":3,"t":655361}],"n":[{"n":"Level","v":5,"t":40960001},{"n":"Version","v":1,"t":393217}]}]}],"l":[{"t":444949,"n":"Log","d":444949,"h":4295412245,"f":33},{"t":40894465,"n":"ALL_KEYWORDS","d":444949,"h":12885346837,"f":34},{"t":655361,"n":"BARRIER_PHASEFINISHED_ID","d":444949,"h":17180314133,"f":34}],"c":[{"n":".ctor","o":"$ctor$8","d":444949,"h":8590379541,"f":2}],"i":[57540609],"h":444949,"a":[{"t":42074113,"c":55876648961,"n":[{"n":"Name","v":"System.Threading.SynchronizationEventSource","t":1310721},{"n":"Guid","v":"EC631D38-466B-4290-9306-834971BA0217","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Diagnostics.Tracing.EventSource; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Threading.CdsSyncEtwBCLProvider`; }
        });
        
        $asm.$cls("$st.System.Threading.BarrierPostPhaseException", ($self) => class BarrierPostPhaseException extends $.$spc.System.Exception
        {
            $ctor$5()
            {
                this.$ctor$7(null);
                {
                }
                return this;
            }
            $ctor$6(/*Exception?*/ innerException)
            {
                this.$ctor$8(null, innerException);
                {
                }
                return this;
            }
            $ctor$7(/*string?*/ message)
            {
                this.$ctor$8(message, null);
                {
                }
                return this;
            }
            $ctor$8(/*string?*/ message, /*Exception?*/ innerException)
            {
                super.$ctor$3(message === null ? $.$st.System.SR.BarrierPostPhaseException : message, innerException);
                {
                }
                return this;
            }
            $ctor$9(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor$4(info, context);
                {
                }
                return this;
            }
            static $h = 379413;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":47251457,"h":379413}; }
            static get $b() { return $.$spc.System.Exception; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Threading.BarrierPostPhaseException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib"))