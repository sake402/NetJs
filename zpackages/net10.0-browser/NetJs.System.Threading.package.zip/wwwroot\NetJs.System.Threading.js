
(function ($global, $, $spc) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Threading", 
    {"h":35784,"f":"System.Threading","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bf7a34a6f78fee11131301a9f55ca16a968616013","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Threading","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Threading","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$st.System.HResults", ($self) => class HResults
        {
            /*int*/ static S_OK = 0;
            /*int*/ static S_FALSE = 1;
            /*int*/ static COR_E_ABANDONEDMUTEX = -2146233043;
            /*int*/ static COR_E_AMBIGUOUSIMPLEMENTATION = -2146234262;
            /*int*/ static COR_E_AMBIGUOUSMATCH = -2147475171;
            /*int*/ static COR_E_APPDOMAINUNLOADED = -2146234348;
            /*int*/ static COR_E_APPLICATION = -2146232832;
            /*int*/ static COR_E_ARGUMENT = -2147024809;
            /*int*/ static COR_E_ARGUMENTOUTOFRANGE = -2146233086;
            /*int*/ static COR_E_ARITHMETIC = -2147024362;
            /*int*/ static COR_E_ARRAYTYPEMISMATCH = -2146233085;
            /*int*/ static COR_E_BADEXEFORMAT = -2147024703;
            /*int*/ static COR_E_BADIMAGEFORMAT = -2147024885;
            /*int*/ static COR_E_CANNOTUNLOADAPPDOMAIN = -2146234347;
            /*int*/ static COR_E_CODECONTRACTFAILED = -2146233022;
            /*int*/ static COR_E_CONTEXTMARSHAL = -2146233084;
            /*int*/ static COR_E_CUSTOMATTRIBUTEFORMAT = -2146232827;
            /*int*/ static COR_E_DATAMISALIGNED = -2146233023;
            /*int*/ static COR_E_DIRECTORYNOTFOUND = -2147024893;
            /*int*/ static COR_E_DIVIDEBYZERO = -2147352558;
            /*int*/ static COR_E_DLLNOTFOUND = -2146233052;
            /*int*/ static COR_E_DUPLICATEWAITOBJECT = -2146233047;
            /*int*/ static COR_E_ENDOFSTREAM = -2147024858;
            /*int*/ static COR_E_ENTRYPOINTNOTFOUND = -2146233053;
            /*int*/ static COR_E_EXCEPTION = -2146233088;
            /*int*/ static COR_E_EXECUTIONENGINE = -2146233082;
            /*int*/ static COR_E_FAILFAST = -2146232797;
            /*int*/ static COR_E_FIELDACCESS = -2146233081;
            /*int*/ static COR_E_FILELOAD = -2146232799;
            /*int*/ static COR_E_FILENOTFOUND = -2147024894;
            /*int*/ static COR_E_FORMAT = -2146233033;
            /*int*/ static COR_E_INDEXOUTOFRANGE = -2146233080;
            /*int*/ static COR_E_INSUFFICIENTEXECUTIONSTACK = -2146232968;
            /*int*/ static COR_E_INSUFFICIENTMEMORY = -2146233027;
            /*int*/ static COR_E_INVALIDCAST = -2147467262;
            /*int*/ static COR_E_INVALIDCOMOBJECT = -2146233049;
            /*int*/ static COR_E_INVALIDFILTERCRITERIA = -2146232831;
            /*int*/ static COR_E_INVALIDOLEVARIANTTYPE = -2146233039;
            /*int*/ static COR_E_INVALIDOPERATION = -2146233079;
            /*int*/ static COR_E_INVALIDPROGRAM = -2146233030;
            /*int*/ static COR_E_IO = -2146232800;
            /*int*/ static COR_E_KEYNOTFOUND = -2146232969;
            /*int*/ static COR_E_MARSHALDIRECTIVE = -2146233035;
            /*int*/ static COR_E_MEMBERACCESS = -2146233062;
            /*int*/ static COR_E_METHODACCESS = -2146233072;
            /*int*/ static COR_E_MISSINGFIELD = -2146233071;
            /*int*/ static COR_E_MISSINGMANIFESTRESOURCE = -2146233038;
            /*int*/ static COR_E_MISSINGMEMBER = -2146233070;
            /*int*/ static COR_E_MISSINGMETHOD = -2146233069;
            /*int*/ static COR_E_MISSINGSATELLITEASSEMBLY = -2146233034;
            /*int*/ static COR_E_MULTICASTNOTSUPPORTED = -2146233068;
            /*int*/ static COR_E_NOTFINITENUMBER = -2146233048;
            /*int*/ static COR_E_NOTSUPPORTED = -2146233067;
            /*int*/ static COR_E_OBJECTDISPOSED = -2146232798;
            /*int*/ static COR_E_OPERATIONCANCELED = -2146233029;
            /*int*/ static COR_E_OUTOFMEMORY = -2147024882;
            /*int*/ static COR_E_OVERFLOW = -2146233066;
            /*int*/ static COR_E_PATHTOOLONG = -2147024690;
            /*int*/ static COR_E_PLATFORMNOTSUPPORTED = -2146233031;
            /*int*/ static COR_E_RANK = -2146233065;
            /*int*/ static COR_E_REFLECTIONTYPELOAD = -2146232830;
            /*int*/ static COR_E_RUNTIMEWRAPPED = -2146233026;
            /*int*/ static COR_E_SAFEARRAYRANKMISMATCH = -2146233032;
            /*int*/ static COR_E_SAFEARRAYTYPEMISMATCH = -2146233037;
            /*int*/ static COR_E_SECURITY = -2146233078;
            /*int*/ static COR_E_SERIALIZATION = -2146233076;
            /*int*/ static COR_E_STACKOVERFLOW = -2147023895;
            /*int*/ static COR_E_SYNCHRONIZATIONLOCK = -2146233064;
            /*int*/ static COR_E_SYSTEM = -2146233087;
            /*int*/ static COR_E_TARGET = -2146232829;
            /*int*/ static COR_E_TARGETINVOCATION = -2146232828;
            /*int*/ static COR_E_TARGETPARAMCOUNT = -2147352562;
            /*int*/ static COR_E_THREADABORTED = -2146233040;
            /*int*/ static COR_E_THREADINTERRUPTED = -2146233063;
            /*int*/ static COR_E_THREADSTART = -2146233051;
            /*int*/ static COR_E_THREADSTATE = -2146233056;
            /*int*/ static COR_E_TIMEOUT = -2146233083;
            /*int*/ static COR_E_TYPEACCESS = -2146233021;
            /*int*/ static COR_E_TYPEINITIALIZATION = -2146233036;
            /*int*/ static COR_E_TYPELOAD = -2146233054;
            /*int*/ static COR_E_TYPEUNLOADED = -2146234349;
            /*int*/ static COR_E_UNAUTHORIZEDACCESS = -2147024891;
            /*int*/ static COR_E_VERIFICATION = -2146233075;
            /*int*/ static COR_E_WAITHANDLECANNOTBEOPENED = -2146233044;
            /*int*/ static CO_E_NOTINITIALIZED = -2147221008;
            /*int*/ static DISP_E_PARAMNOTFOUND = -2147352572;
            /*int*/ static DISP_E_TYPEMISMATCH = -2147352571;
            /*int*/ static DISP_E_BADVARTYPE = -2147352568;
            /*int*/ static DISP_E_OVERFLOW = -2147352566;
            /*int*/ static DISP_E_DIVBYZERO = -2147352558;
            /*int*/ static E_BOUNDS = -2147483637;
            /*int*/ static E_CHANGED_STATE = -2147483636;
            /*int*/ static E_FILENOTFOUND = -2147024894;
            /*int*/ static E_FAIL = -2147467259;
            /*int*/ static E_HANDLE = -2147024890;
            /*int*/ static E_INVALIDARG = -2147024809;
            /*int*/ static E_NOTIMPL = -2147467263;
            /*int*/ static E_OUTOFMEMORY = -2147024882;
            /*int*/ static E_POINTER = -2147467261;
            /*int*/ static ERROR_MRM_MAP_NOT_FOUND = -2147009761;
            /*int*/ static ERROR_TIMEOUT = -2147023436;
            /*int*/ static RO_E_CLOSED = -2147483629;
            /*int*/ static RPC_E_CHANGED_MODE = -2147417850;
            /*int*/ static TYPE_E_TYPEMISMATCH = -2147316576;
            /*int*/ static STG_E_PATHNOTFOUND = -2147287037;
            /*int*/ static CTL_E_PATHNOTFOUND = -2146828212;
            /*int*/ static CTL_E_FILENOTFOUND = -2146828235;
            /*int*/ static FUSION_E_INVALID_NAME = -2146234297;
            /*int*/ static FUSION_E_REF_DEF_MISMATCH = -2146234304;
            /*int*/ static ERROR_TOO_MANY_OPEN_FILES = -2147024892;
            /*int*/ static ERROR_SHARING_VIOLATION = -2147024864;
            /*int*/ static ERROR_LOCK_VIOLATION = -2147024863;
            /*int*/ static ERROR_OPEN_FAILED = -2147024786;
            /*int*/ static ERROR_DISK_CORRUPT = -2147023503;
            /*int*/ static ERROR_UNRECOGNIZED_VOLUME = -2147023891;
            /*int*/ static ERROR_DLL_INIT_FAILED = -2147023782;
            /*int*/ static MSEE_E_ASSEMBLYLOADINPROGRESS = -2146234346;
            /*int*/ static ERROR_FILE_INVALID = -2147023890;
            static $h = 101320;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"S_OK","d":101320,"h":4295068616,"f":40},{"t":655361,"n":"S_FALSE","d":101320,"h":8590035912,"f":40},{"t":655361,"n":"COR_E_ABANDONEDMUTEX","d":101320,"h":12885003208,"f":40},{"t":655361,"n":"COR_E_AMBIGUOUSIMPLEMENTATION","d":101320,"h":17179970504,"f":40},{"t":655361,"n":"COR_E_AMBIGUOUSMATCH","d":101320,"h":21474937800,"f":40},{"t":655361,"n":"COR_E_APPDOMAINUNLOADED","d":101320,"h":25769905096,"f":40},{"t":655361,"n":"COR_E_APPLICATION","d":101320,"h":30064872392,"f":40},{"t":655361,"n":"COR_E_ARGUMENT","d":101320,"h":34359839688,"f":40},{"t":655361,"n":"COR_E_ARGUMENTOUTOFRANGE","d":101320,"h":38654806984,"f":40},{"t":655361,"n":"COR_E_ARITHMETIC","d":101320,"h":42949774280,"f":40},{"t":655361,"n":"COR_E_ARRAYTYPEMISMATCH","d":101320,"h":47244741576,"f":40},{"t":655361,"n":"COR_E_BADEXEFORMAT","d":101320,"h":51539708872,"f":40},{"t":655361,"n":"COR_E_BADIMAGEFORMAT","d":101320,"h":55834676168,"f":40},{"t":655361,"n":"COR_E_CANNOTUNLOADAPPDOMAIN","d":101320,"h":60129643464,"f":40},{"t":655361,"n":"COR_E_CODECONTRACTFAILED","d":101320,"h":64424610760,"f":40},{"t":655361,"n":"COR_E_CONTEXTMARSHAL","d":101320,"h":68719578056,"f":40},{"t":655361,"n":"COR_E_CUSTOMATTRIBUTEFORMAT","d":101320,"h":73014545352,"f":40},{"t":655361,"n":"COR_E_DATAMISALIGNED","d":101320,"h":77309512648,"f":40},{"t":655361,"n":"COR_E_DIRECTORYNOTFOUND","d":101320,"h":81604479944,"f":40},{"t":655361,"n":"COR_E_DIVIDEBYZERO","d":101320,"h":85899447240,"f":40},{"t":655361,"n":"COR_E_DLLNOTFOUND","d":101320,"h":90194414536,"f":40},{"t":655361,"n":"COR_E_DUPLICATEWAITOBJECT","d":101320,"h":94489381832,"f":40},{"t":655361,"n":"COR_E_ENDOFSTREAM","d":101320,"h":98784349128,"f":40},{"t":655361,"n":"COR_E_ENTRYPOINTNOTFOUND","d":101320,"h":103079316424,"f":40},{"t":655361,"n":"COR_E_EXCEPTION","d":101320,"h":107374283720,"f":40},{"t":655361,"n":"COR_E_EXECUTIONENGINE","d":101320,"h":111669251016,"f":40},{"t":655361,"n":"COR_E_FAILFAST","d":101320,"h":115964218312,"f":40},{"t":655361,"n":"COR_E_FIELDACCESS","d":101320,"h":120259185608,"f":40},{"t":655361,"n":"COR_E_FILELOAD","d":101320,"h":124554152904,"f":40},{"t":655361,"n":"COR_E_FILENOTFOUND","d":101320,"h":128849120200,"f":40},{"t":655361,"n":"COR_E_FORMAT","d":101320,"h":133144087496,"f":40},{"t":655361,"n":"COR_E_INDEXOUTOFRANGE","d":101320,"h":137439054792,"f":40},{"t":655361,"n":"COR_E_INSUFFICIENTEXECUTIONSTACK","d":101320,"h":141734022088,"f":40},{"t":655361,"n":"COR_E_INSUFFICIENTMEMORY","d":101320,"h":146028989384,"f":40},{"t":655361,"n":"COR_E_INVALIDCAST","d":101320,"h":150323956680,"f":40},{"t":655361,"n":"COR_E_INVALIDCOMOBJECT","d":101320,"h":154618923976,"f":40},{"t":655361,"n":"COR_E_INVALIDFILTERCRITERIA","d":101320,"h":158913891272,"f":40},{"t":655361,"n":"COR_E_INVALIDOLEVARIANTTYPE","d":101320,"h":163208858568,"f":40},{"t":655361,"n":"COR_E_INVALIDOPERATION","d":101320,"h":167503825864,"f":40},{"t":655361,"n":"COR_E_INVALIDPROGRAM","d":101320,"h":171798793160,"f":40},{"t":655361,"n":"COR_E_IO","d":101320,"h":176093760456,"f":40},{"t":655361,"n":"COR_E_KEYNOTFOUND","d":101320,"h":180388727752,"f":40},{"t":655361,"n":"COR_E_MARSHALDIRECTIVE","d":101320,"h":184683695048,"f":40},{"t":655361,"n":"COR_E_MEMBERACCESS","d":101320,"h":188978662344,"f":40},{"t":655361,"n":"COR_E_METHODACCESS","d":101320,"h":193273629640,"f":40},{"t":655361,"n":"COR_E_MISSINGFIELD","d":101320,"h":197568596936,"f":40},{"t":655361,"n":"COR_E_MISSINGMANIFESTRESOURCE","d":101320,"h":201863564232,"f":40},{"t":655361,"n":"COR_E_MISSINGMEMBER","d":101320,"h":206158531528,"f":40},{"t":655361,"n":"COR_E_MISSINGMETHOD","d":101320,"h":210453498824,"f":40},{"t":655361,"n":"COR_E_MISSINGSATELLITEASSEMBLY","d":101320,"h":214748466120,"f":40},{"t":655361,"n":"COR_E_MULTICASTNOTSUPPORTED","d":101320,"h":219043433416,"f":40},{"t":655361,"n":"COR_E_NOTFINITENUMBER","d":101320,"h":223338400712,"f":40},{"t":655361,"n":"COR_E_NOTSUPPORTED","d":101320,"h":227633368008,"f":40},{"t":655361,"n":"COR_E_OBJECTDISPOSED","d":101320,"h":231928335304,"f":40},{"t":655361,"n":"COR_E_OPERATIONCANCELED","d":101320,"h":236223302600,"f":40},{"t":655361,"n":"COR_E_OUTOFMEMORY","d":101320,"h":240518269896,"f":40},{"t":655361,"n":"COR_E_OVERFLOW","d":101320,"h":244813237192,"f":40},{"t":655361,"n":"COR_E_PATHTOOLONG","d":101320,"h":249108204488,"f":40},{"t":655361,"n":"COR_E_PLATFORMNOTSUPPORTED","d":101320,"h":253403171784,"f":40},{"t":655361,"n":"COR_E_RANK","d":101320,"h":257698139080,"f":40},{"t":655361,"n":"COR_E_REFLECTIONTYPELOAD","d":101320,"h":261993106376,"f":40},{"t":655361,"n":"COR_E_RUNTIMEWRAPPED","d":101320,"h":266288073672,"f":40},{"t":655361,"n":"COR_E_SAFEARRAYRANKMISMATCH","d":101320,"h":270583040968,"f":40},{"t":655361,"n":"COR_E_SAFEARRAYTYPEMISMATCH","d":101320,"h":274878008264,"f":40},{"t":655361,"n":"COR_E_SECURITY","d":101320,"h":279172975560,"f":40},{"t":655361,"n":"COR_E_SERIALIZATION","d":101320,"h":283467942856,"f":40},{"t":655361,"n":"COR_E_STACKOVERFLOW","d":101320,"h":287762910152,"f":40},{"t":655361,"n":"COR_E_SYNCHRONIZATIONLOCK","d":101320,"h":292057877448,"f":40},{"t":655361,"n":"COR_E_SYSTEM","d":101320,"h":296352844744,"f":40},{"t":655361,"n":"COR_E_TARGET","d":101320,"h":300647812040,"f":40},{"t":655361,"n":"COR_E_TARGETINVOCATION","d":101320,"h":304942779336,"f":40},{"t":655361,"n":"COR_E_TARGETPARAMCOUNT","d":101320,"h":309237746632,"f":40},{"t":655361,"n":"COR_E_THREADABORTED","d":101320,"h":313532713928,"f":40},{"t":655361,"n":"COR_E_THREADINTERRUPTED","d":101320,"h":317827681224,"f":40},{"t":655361,"n":"COR_E_THREADSTART","d":101320,"h":322122648520,"f":40},{"t":655361,"n":"COR_E_THREADSTATE","d":101320,"h":326417615816,"f":40},{"t":655361,"n":"COR_E_TIMEOUT","d":101320,"h":330712583112,"f":40},{"t":655361,"n":"COR_E_TYPEACCESS","d":101320,"h":335007550408,"f":40},{"t":655361,"n":"COR_E_TYPEINITIALIZATION","d":101320,"h":339302517704,"f":40},{"t":655361,"n":"COR_E_TYPELOAD","d":101320,"h":343597485000,"f":40},{"t":655361,"n":"COR_E_TYPEUNLOADED","d":101320,"h":347892452296,"f":40},{"t":655361,"n":"COR_E_UNAUTHORIZEDACCESS","d":101320,"h":352187419592,"f":40},{"t":655361,"n":"COR_E_VERIFICATION","d":101320,"h":356482386888,"f":40},{"t":655361,"n":"COR_E_WAITHANDLECANNOTBEOPENED","d":101320,"h":360777354184,"f":40},{"t":655361,"n":"CO_E_NOTINITIALIZED","d":101320,"h":365072321480,"f":40},{"t":655361,"n":"DISP_E_PARAMNOTFOUND","d":101320,"h":369367288776,"f":40},{"t":655361,"n":"DISP_E_TYPEMISMATCH","d":101320,"h":373662256072,"f":40},{"t":655361,"n":"DISP_E_BADVARTYPE","d":101320,"h":377957223368,"f":40},{"t":655361,"n":"DISP_E_OVERFLOW","d":101320,"h":382252190664,"f":40},{"t":655361,"n":"DISP_E_DIVBYZERO","d":101320,"h":386547157960,"f":40},{"t":655361,"n":"E_BOUNDS","d":101320,"h":390842125256,"f":40},{"t":655361,"n":"E_CHANGED_STATE","d":101320,"h":395137092552,"f":40},{"t":655361,"n":"E_FILENOTFOUND","d":101320,"h":399432059848,"f":40},{"t":655361,"n":"E_FAIL","d":101320,"h":403727027144,"f":40},{"t":655361,"n":"E_HANDLE","d":101320,"h":408021994440,"f":40},{"t":655361,"n":"E_INVALIDARG","d":101320,"h":412316961736,"f":40},{"t":655361,"n":"E_NOTIMPL","d":101320,"h":416611929032,"f":40},{"t":655361,"n":"E_OUTOFMEMORY","d":101320,"h":420906896328,"f":40},{"t":655361,"n":"E_POINTER","d":101320,"h":425201863624,"f":40},{"t":655361,"n":"ERROR_MRM_MAP_NOT_FOUND","d":101320,"h":429496830920,"f":40},{"t":655361,"n":"ERROR_TIMEOUT","d":101320,"h":433791798216,"f":40},{"t":655361,"n":"RO_E_CLOSED","d":101320,"h":438086765512,"f":40},{"t":655361,"n":"RPC_E_CHANGED_MODE","d":101320,"h":442381732808,"f":40},{"t":655361,"n":"TYPE_E_TYPEMISMATCH","d":101320,"h":446676700104,"f":40},{"t":655361,"n":"STG_E_PATHNOTFOUND","d":101320,"h":450971667400,"f":40},{"t":655361,"n":"CTL_E_PATHNOTFOUND","d":101320,"h":455266634696,"f":40},{"t":655361,"n":"CTL_E_FILENOTFOUND","d":101320,"h":459561601992,"f":40},{"t":655361,"n":"FUSION_E_INVALID_NAME","d":101320,"h":463856569288,"f":40},{"t":655361,"n":"FUSION_E_REF_DEF_MISMATCH","d":101320,"h":468151536584,"f":40},{"t":655361,"n":"ERROR_TOO_MANY_OPEN_FILES","d":101320,"h":472446503880,"f":40},{"t":655361,"n":"ERROR_SHARING_VIOLATION","d":101320,"h":476741471176,"f":40},{"t":655361,"n":"ERROR_LOCK_VIOLATION","d":101320,"h":481036438472,"f":40},{"t":655361,"n":"ERROR_OPEN_FAILED","d":101320,"h":485331405768,"f":40},{"t":655361,"n":"ERROR_DISK_CORRUPT","d":101320,"h":489626373064,"f":40},{"t":655361,"n":"ERROR_UNRECOGNIZED_VOLUME","d":101320,"h":493921340360,"f":40},{"t":655361,"n":"ERROR_DLL_INIT_FAILED","d":101320,"h":498216307656,"f":40},{"t":655361,"n":"MSEE_E_ASSEMBLYLOADINPROGRESS","d":101320,"h":502511274952,"f":40},{"t":655361,"n":"ERROR_FILE_INVALID","d":101320,"h":506806242248,"f":40}],"h":101320}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.HResults`; }
        });
        
        $asm.$cls("$st.System.Threading.HostExecutionContextManager", ($self) => class HostExecutionContextManager extends $.$spc.System.Object
        {
            /*HostExecutionContext?*/ static t_currentContext = null;
            /*HostExecutionContext? */ Capture()
            {
                return null;
            }
            /*object */ SetHostExecutionContext(/*HostExecutionContext*/ hostExecutionContext)
            {
                if (hostExecutionContext === null)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$st.System.SR.HostExecutionContextManager_InvalidOperation_NotNewCaptureContext);
                }
                /*var*/ let switcher = new $.$st.System.Threading.HostExecutionContextManager.HostExecutionContextSwitcher().$ctor$1(hostExecutionContext);
                $.$st.System.Threading.HostExecutionContextManager.t_currentContext = hostExecutionContext;
                return switcher;
            }
            /*void */ Revert(/*object*/ previousState)
            {
                /*var*/ let switcher = $.$as(previousState, $.$st.System.Threading.HostExecutionContextManager.HostExecutionContextSwitcher);
                if (switcher === null)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$st.System.SR.HostExecutionContextManager_InvalidOperation_CannotOverrideSetWithoutRevert);
                }
                if ($.$st.System.Threading.HostExecutionContextManager.t_currentContext !== switcher._currentContext || switcher._asyncLocal === null || !switcher._asyncLocal.Value)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$st.System.SR.HostExecutionContextManager_InvalidOperation_CannotUseSwitcherOtherThread);
                }
                switcher._asyncLocal = null;
                $.$st.System.Threading.HostExecutionContextManager.t_currentContext = null;
            }
            static $_HostExecutionContextSwitcher;
            static get HostExecutionContextSwitcher()
            {
                let $cls = $.$st.System.Threading.HostExecutionContextManager;
                return $cls.$_HostExecutionContextSwitcher ??= $asm.$ncls("$st.System.Threading.HostExecutionContextManager.HostExecutionContextSwitcher", ($self) => class HostExecutionContextSwitcher extends $.$spc.System.Object
                {
                    /*HostExecutionContext*/ _currentContext = null;
                    /*AsyncLocal<bool>?*/ _asyncLocal = null;
                    $ctor$1(/*HostExecutionContext*/ currentContext)
                    {
                        super.$ctor();
                        {
                            this._currentContext = currentContext;
                            this._asyncLocal = new ($.$spc.System.Threading.AsyncLocal$$($.$spc.System.Boolean))().$ctor$1();
                            this._asyncLocal.Value = true;
                        }
                        return this;
                    }
                    static $h = 691144;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":560072,"n":"_currentContext","d":691144,"h":4295658440,"f":1},{"t":$.$spc.System.Threading.AsyncLocal$$($.$spc.System.Boolean).$h,"n":"_asyncLocal","d":691144,"h":8590625736,"f":1}],"c":[{"p":[{"n":"currentContext","p":560072}],"n":".ctor","o":"$ctor$1","d":691144,"h":12885593032,"f":1}],"d":625608,"h":691144}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Threading.HostExecutionContextManager.HostExecutionContextSwitcher`; }
                }, $cls, ($v) => $cls.$_HostExecutionContextSwitcher = $v);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 625608;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":560072,"n":"Capture","d":625608,"h":8590560200,"f":129},{"r":131073,"p":[{"n":"hostExecutionContext","p":560072}],"n":"SetHostExecutionContext","d":625608,"h":12885527496,"f":129},{"r":65537,"p":[{"n":"previousState","p":131073}],"n":"Revert","d":625608,"h":17180494792,"f":129}],"l":[{"t":560072,"n":"t_currentContext","d":625608,"h":4295592904,"f":34,"a":[{"t":140181505,"c":4435148801}]}],"c":[{"n":".ctor","o":"$ctor$1","d":625608,"h":25770429384,"f":1}],"j":[691144],"h":625608}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Threading.HostExecutionContextManager`; }
        });
        
        $asm.$cls("$st.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$st.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("System.Threading", $.$st.System.SR.$type.Assembly);
                    $.$st.System.SR.s_resourceManager = temp;
                }
                return $.$st.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$st.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$st.System.SR.resourceCulture = value;
            }
            static /*string */ get CountdownEvent_Increment_AlreadyZero()
            {
                return "The event is already signaled and cannot be incremented.";
            }
            static /*string */ get CountdownEvent_Increment_AlreadyMax()
            {
                return "The increment operation would cause the CurrentCount to overflow.";
            }
            static /*string */ get CountdownEvent_Decrement_BelowZero()
            {
                return "Invalid attempt made to decrement the event's count below zero.";
            }
            static /*string */ get Common_OperationCanceled()
            {
                return "The operation was canceled.";
            }
            static /*string */ get Barrier_SignalAndWait_InvalidOperation_ZeroTotal()
            {
                return "The barrier has no registered participants.";
            }
            static /*string */ get Barrier_SignalAndWait_ArgumentOutOfRange()
            {
                return "The specified timeout must represent a value between -1 and Int32.MaxValue, inclusive.";
            }
            static /*string */ get Barrier_RemoveParticipants_InvalidOperation()
            {
                return "The participantCount argument is greater than the number of participants that haven't yet arrived at the barrier in this phase.";
            }
            static /*string */ get Barrier_RemoveParticipants_ArgumentOutOfRange()
            {
                return "The participantCount argument must be less than or equal the number of participants.";
            }
            static /*string */ get Barrier_InvalidOperation_CalledFromPHA()
            {
                return "This method may not be called from within the postPhaseAction.";
            }
            static /*string */ get Barrier_SignalAndWait_InvalidOperation_ThreadsExceeded()
            {
                return "The number of threads using the barrier exceeded the total number of registered participants.";
            }
            static /*string */ get BarrierPostPhaseException()
            {
                return "The postPhaseAction failed with an exception.";
            }
            static /*string */ get Barrier_AddParticipants_Overflow_ArgumentOutOfRange()
            {
                return "Adding participantCount participants would result in the number of participants exceeding the maximum number allowed.";
            }
            static /*string */ get SynchronizationLockException_IncorrectDispose()
            {
                return "The lock is being disposed while still being used. It either is being held by a thread and/or has active waiters waiting to acquire the lock.";
            }
            static /*string */ get SynchronizationLockException_MisMatchedWrite()
            {
                return "The write lock is being released without being held.";
            }
            static /*string */ get LockRecursionException_UpgradeAfterReadNotAllowed()
            {
                return "Upgradeable lock may not be acquired with read lock held.";
            }
            static /*string */ get LockRecursionException_UpgradeAfterWriteNotAllowed()
            {
                return "Upgradeable lock may not be acquired with write lock held in this mode. Acquiring Upgradeable lock gives the ability to read along with an option to upgrade to a writer.";
            }
            static /*string */ get SynchronizationLockException_MisMatchedUpgrade()
            {
                return "The upgradeable lock is being released without being held.";
            }
            static /*string */ get SynchronizationLockException_MisMatchedRead()
            {
                return "The read lock is being released without being held.";
            }
            static /*string */ get LockRecursionException_WriteAfterReadNotAllowed()
            {
                return "Write lock may not be acquired with read lock held. This pattern is prone to deadlocks. Please ensure that read locks are released before taking a write lock. If an upgrade is necessary, use an upgrade lock in place of the read lock.";
            }
            static /*string */ get LockRecursionException_RecursiveWriteNotAllowed()
            {
                return "Recursive write lock acquisitions not allowed in this mode.";
            }
            static /*string */ get LockRecursionException_ReadAfterWriteNotAllowed()
            {
                return "A read lock may not be acquired with the write lock held in this mode.";
            }
            static /*string */ get LockRecursionException_RecursiveUpgradeNotAllowed()
            {
                return "Recursive upgradeable lock acquisitions not allowed in this mode.";
            }
            static /*string */ get LockRecursionException_RecursiveReadNotAllowed()
            {
                return "Recursive read lock acquisitions not allowed in this mode.";
            }
            static /*string */ get Overflow_UInt16()
            {
                return "Value was either too large or too small for a UInt16.";
            }
            static /*string */ get ReaderWriterLock_Timeout()
            {
                return "The operation has timed out. {0}";
            }
            static /*string */ FormatReaderWriterLock_Timeout(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The operation has timed out. {0}", arg1);
            }
            static /*string */ get ReaderWriterLock_NotOwner()
            {
                return "Attempt to release a lock that is not owned by the calling thread. {0}";
            }
            static /*string */ FormatReaderWriterLock_NotOwner(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Attempt to release a lock that is not owned by the calling thread. {0}", arg1);
            }
            static /*string */ get ExceptionFromHResult()
            {
                return "(Exception from HRESULT: 0x{0:X})";
            }
            static /*string */ FormatExceptionFromHResult(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("(Exception from HRESULT: 0x{0:X})", arg1);
            }
            static /*string */ get ReaderWriterLock_InvalidLockCookie()
            {
                return "The specified lock cookie is invalid for this operation. {0}";
            }
            static /*string */ FormatReaderWriterLock_InvalidLockCookie(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The specified lock cookie is invalid for this operation. {0}", arg1);
            }
            static /*string */ get ReaderWriterLock_RestoreLockWithOwnedLocks()
            {
                return "ReaderWriterLock.RestoreLock was called without releasing all locks acquired since the call to ReleaseLock.";
            }
            static /*string */ get HostExecutionContextManager_InvalidOperation_NotNewCaptureContext()
            {
                return "Cannot apply a context that has been marshaled across AppDomains, that was not acquired through a Capture operation or that has already been the argument to a Set call.";
            }
            static /*string */ get HostExecutionContextManager_InvalidOperation_CannotOverrideSetWithoutRevert()
            {
                return "Must override both HostExecutionContextManager.SetHostExecutionContext and HostExecutionContextManager.Revert.";
            }
            static /*string */ get HostExecutionContextManager_InvalidOperation_CannotUseSwitcherOtherThread()
            {
                return "Undo operation must be performed on the thread where the corresponding context was Set.";
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$st.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$st.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$st.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$st.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$st.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$st.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$st.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$st.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$st.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$st.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$st.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$st.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$st.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 232392;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":232392}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$st.System.Obsoletions", ($self) => class Obsoletions
        {
            /*string*/ static SharedUrlFormat = null;
            /*string*/ static SystemTextEncodingUTF7Message = null;
            /*string*/ static SystemTextEncodingUTF7DiagId = null;
            /*string*/ static PrincipalPermissionAttributeMessage = null;
            /*string*/ static PrincipalPermissionAttributeDiagId = null;
            /*string*/ static CodeAccessSecurityMessage = null;
            /*string*/ static CodeAccessSecurityDiagId = null;
            /*string*/ static ConstrainedExecutionRegionMessage = null;
            /*string*/ static ConstrainedExecutionRegionDiagId = null;
            /*string*/ static GlobalAssemblyCacheMessage = null;
            /*string*/ static GlobalAssemblyCacheDiagId = null;
            /*string*/ static ThreadAbortMessage = null;
            /*string*/ static ThreadResetAbortMessage = null;
            /*string*/ static ThreadAbortDiagId = null;
            /*string*/ static DefaultCryptoAlgorithmsMessage = null;
            /*string*/ static DefaultCryptoAlgorithmsDiagId = null;
            /*string*/ static CreatePdbGeneratorMessage = null;
            /*string*/ static CreatePdbGeneratorDiagId = null;
            /*string*/ static AuthenticationManagerMessage = null;
            /*string*/ static AuthenticationManagerDiagId = null;
            /*string*/ static RemotingApisMessage = null;
            /*string*/ static RemotingApisDiagId = null;
            /*string*/ static BinaryFormatterMessage = null;
            /*string*/ static BinaryFormatterDiagId = null;
            /*string*/ static CodeBaseMessage = null;
            /*string*/ static CodeBaseDiagId = null;
            /*string*/ static EscapeUriStringMessage = null;
            /*string*/ static EscapeUriStringDiagId = null;
            /*string*/ static WebRequestMessage = null;
            /*string*/ static WebRequestDiagId = null;
            /*string*/ static DisablePrivateReflectionAttributeMessage = null;
            /*string*/ static DisablePrivateReflectionAttributeDiagId = null;
            /*string*/ static GetContextInfoMessage = null;
            /*string*/ static GetContextInfoDiagId = null;
            /*string*/ static StrongNameKeyPairMessage = null;
            /*string*/ static StrongNameKeyPairDiagId = null;
            /*string*/ static ReflectionOnlyLoadingMessage = null;
            /*string*/ static ReflectionOnlyLoadingDiagId = null;
            /*string*/ static RuntimeEnvironmentMessage = null;
            /*string*/ static RuntimeEnvironmentDiagId = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesMessage = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesDiagId = null;
            /*string*/ static DerivedCryptographicTypesMessage = null;
            /*string*/ static DerivedCryptographicTypesDiagId = null;
            /*string*/ static RijndaelMessage = null;
            /*string*/ static RijndaelDiagId = null;
            /*string*/ static RNGCryptoServiceProviderMessage = null;
            /*string*/ static RNGCryptoServiceProviderDiagId = null;
            /*string*/ static AppDomainCreateUnloadMessage = null;
            /*string*/ static AppDomainCreateUnloadDiagId = null;
            /*string*/ static SuppressIldasmAttributeMessage = null;
            /*string*/ static SuppressIldasmAttributeDiagId = null;
            /*string*/ static X509CertificateImmutableMessage = null;
            /*string*/ static X509CertificateImmutableDiagId = null;
            /*string*/ static PublicKeyPropertyMessage = null;
            /*string*/ static PublicKeyPropertyDiagId = null;
            /*string*/ static X509CertificatePrivateKeyMessage = null;
            /*string*/ static X509CertificatePrivateKeyDiagId = null;
            /*string*/ static ProduceLegacyHmacValuesMessage = null;
            /*string*/ static ProduceLegacyHmacValuesDiagId = null;
            /*string*/ static UseManagedSha1Message = null;
            /*string*/ static UseManagedSha1DiagId = null;
            /*string*/ static CryptoConfigEncodeOIDMessage = null;
            /*string*/ static CryptoConfigEncodeOIDDiagId = null;
            /*string*/ static CorruptedStateRecoveryMessage = null;
            /*string*/ static CorruptedStateRecoveryDiagId = null;
            /*string*/ static Rfc2898CryptDeriveKeyMessage = null;
            /*string*/ static Rfc2898CryptDeriveKeyDiagId = null;
            /*string*/ static CmsSignerCspParamsCtorMessage = null;
            /*string*/ static CmsSignerCspParamsCtorDiagId = null;
            /*string*/ static SignerInfoCounterSigMessage = null;
            /*string*/ static SignerInfoCounterSigDiagId = null;
            /*string*/ static RegexCompileToAssemblyMessage = null;
            /*string*/ static RegexCompileToAssemblyDiagId = null;
            /*string*/ static AssemblyNameMembersMessage = null;
            /*string*/ static AssemblyNameMembersDiagId = null;
            /*string*/ static SystemDataSerializationFormatBinaryMessage = null;
            /*string*/ static SystemDataSerializationFormatBinaryDiagId = null;
            /*string*/ static TlsVersion10and11Message = null;
            /*string*/ static TlsVersion10and11DiagId = null;
            /*string*/ static EncryptionPolicyMessage = null;
            /*string*/ static EncryptionPolicyDiagId = null;
            /*string*/ static EccXmlExportImportMessage = null;
            /*string*/ static EccXmlExportImportDiagId = null;
            /*string*/ static EcDhPublicKeyBlobMessage = null;
            /*string*/ static EcDhPublicKeyBlobDiagId = null;
            /*string*/ static AssemblyNameCodeBaseMessage = null;
            /*string*/ static AssemblyNameCodeBaseDiagId = null;
            /*string*/ static CryptoStringFactoryMessage = null;
            /*string*/ static CryptoStringFactoryDiagId = null;
            /*string*/ static ControlledExecutionRunMessage = null;
            /*string*/ static ControlledExecutionRunDiagId = null;
            /*string*/ static XmlSecureResolverMessage = null;
            /*string*/ static XmlSecureResolverDiagId = null;
            /*string*/ static RsaEncryptDecryptValueMessage = null;
            /*string*/ static RsaEncryptDecryptDiagId = null;
            /*string*/ static JsonSerializerOptionsAddContextMessage = null;
            /*string*/ static JsonSerializerOptionsAddContextDiagId = null;
            /*string*/ static LegacyFormatterMessage = null;
            /*string*/ static LegacyFormatterDiagId = null;
            /*string*/ static LegacyFormatterImplMessage = null;
            /*string*/ static LegacyFormatterImplDiagId = null;
            /*string*/ static RegexExtensibilityImplMessage = null;
            /*string*/ static RegexExtensibilityDiagId = null;
            /*string*/ static AesGcmTagConstructorMessage = null;
            /*string*/ static AesGcmTagConstructorDiagId = null;
            /*string*/ static ThreadVolatileReadWriteMessage = null;
            /*string*/ static ThreadVolatileReadWriteDiagId = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationMessage = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationDiagId = null;
            /*string*/ static LoadFromHashAlgorithmMessage = null;
            /*string*/ static LoadFromHashAlgorithmDiagId = null;
            /*string*/ static X509CtorCertDataObsoleteMessage = null;
            /*string*/ static X509CtorCertDataObsoleteDiagId = null;
            /*string*/ static TlsCipherAlgorithmEnumsMessage = null;
            /*string*/ static TlsCipherAlgorithmEnumsDiagId = null;
            /*string*/ static SystemEventsEventsThreadShutdownMessage = null;
            /*string*/ static SystemEventsEventsThreadShutdownDiagId = null;
            /*string*/ static Rfc2898DeriveBytesCtorMessage = null;
            /*string*/ static Rfc2898DeriveBytesCtorDiagId = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteMessage = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteDiagId = null;
            /*string*/ static XsltSettingsEnableScriptMessage = null;
            /*string*/ static XsltSettingsEnableScriptDiagId = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                }
                {
                    this.SystemTextEncodingUTF7Message = "The UTF-7 encoding is insecure and should not be used. Consider using UTF-8 instead.";
                }
                {
                    this.SystemTextEncodingUTF7DiagId = "SYSLIB0001";
                }
                {
                    this.PrincipalPermissionAttributeMessage = "PrincipalPermissionAttribute is not honored by the runtime and must not be used.";
                }
                {
                    this.PrincipalPermissionAttributeDiagId = "SYSLIB0002";
                }
                {
                    this.CodeAccessSecurityMessage = "Code Access Security is not supported or honored by the runtime.";
                }
                {
                    this.CodeAccessSecurityDiagId = "SYSLIB0003";
                }
                {
                    this.ConstrainedExecutionRegionMessage = "The Constrained Execution Region (CER) feature is not supported.";
                }
                {
                    this.ConstrainedExecutionRegionDiagId = "SYSLIB0004";
                }
                {
                    this.GlobalAssemblyCacheMessage = "The Global Assembly Cache is not supported.";
                }
                {
                    this.GlobalAssemblyCacheDiagId = "SYSLIB0005";
                }
                {
                    this.ThreadAbortMessage = "Thread.Abort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadResetAbortMessage = "Thread.ResetAbort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadAbortDiagId = "SYSLIB0006";
                }
                {
                    this.DefaultCryptoAlgorithmsMessage = "The default implementation of this cryptography algorithm is not supported.";
                }
                {
                    this.DefaultCryptoAlgorithmsDiagId = "SYSLIB0007";
                }
                {
                    this.CreatePdbGeneratorMessage = "The CreatePdbGenerator API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.CreatePdbGeneratorDiagId = "SYSLIB0008";
                }
                {
                    this.AuthenticationManagerMessage = "AuthenticationManager is not supported. Methods will no-op or throw PlatformNotSupportedException.";
                }
                {
                    this.AuthenticationManagerDiagId = "SYSLIB0009";
                }
                {
                    this.RemotingApisMessage = "This Remoting API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.RemotingApisDiagId = "SYSLIB0010";
                }
                {
                    this.BinaryFormatterMessage = "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.";
                }
                {
                    this.BinaryFormatterDiagId = "SYSLIB0011";
                }
                {
                    this.CodeBaseMessage = "Assembly.CodeBase and Assembly.EscapedCodeBase are only included for .NET Framework compatibility. Use Assembly.Location instead.";
                }
                {
                    this.CodeBaseDiagId = "SYSLIB0012";
                }
                {
                    this.EscapeUriStringMessage = "Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.";
                }
                {
                    this.EscapeUriStringDiagId = "SYSLIB0013";
                }
                {
                    this.WebRequestMessage = "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.";
                }
                {
                    this.WebRequestDiagId = "SYSLIB0014";
                }
                {
                    this.DisablePrivateReflectionAttributeMessage = "DisablePrivateReflectionAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.DisablePrivateReflectionAttributeDiagId = "SYSLIB0015";
                }
                {
                    this.GetContextInfoMessage = "Use the Graphics.GetContextInfo overloads that accept arguments for better performance and fewer allocations.";
                }
                {
                    this.GetContextInfoDiagId = "SYSLIB0016";
                }
                {
                    this.StrongNameKeyPairMessage = "Strong name signing is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.StrongNameKeyPairDiagId = "SYSLIB0017";
                }
                {
                    this.ReflectionOnlyLoadingMessage = "ReflectionOnly loading is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ReflectionOnlyLoadingDiagId = "SYSLIB0018";
                }
                {
                    this.RuntimeEnvironmentMessage = "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.";
                }
                {
                    this.RuntimeEnvironmentDiagId = "SYSLIB0019";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesMessage = "JsonSerializerOptions.IgnoreNullValues is obsolete. To ignore null values when serializing, set DefaultIgnoreCondition to JsonIgnoreCondition.WhenWritingNull.";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesDiagId = "SYSLIB0020";
                }
                {
                    this.DerivedCryptographicTypesMessage = "Derived cryptographic types are obsolete. Use the Create method on the base type instead.";
                }
                {
                    this.DerivedCryptographicTypesDiagId = "SYSLIB0021";
                }
                {
                    this.RijndaelMessage = "The Rijndael and RijndaelManaged types are obsolete. Use Aes instead.";
                }
                {
                    this.RijndaelDiagId = "SYSLIB0022";
                }
                {
                    this.RNGCryptoServiceProviderMessage = "RNGCryptoServiceProvider is obsolete. To generate a random number, use one of the RandomNumberGenerator static methods instead.";
                }
                {
                    this.RNGCryptoServiceProviderDiagId = "SYSLIB0023";
                }
                {
                    this.AppDomainCreateUnloadMessage = "Creating and unloading AppDomains is not supported and throws an exception.";
                }
                {
                    this.AppDomainCreateUnloadDiagId = "SYSLIB0024";
                }
                {
                    this.SuppressIldasmAttributeMessage = "SuppressIldasmAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.SuppressIldasmAttributeDiagId = "SYSLIB0025";
                }
                {
                    this.X509CertificateImmutableMessage = "X509Certificate and X509Certificate2 are immutable. Use X509CertificateLoader to create a new certificate.";
                }
                {
                    this.X509CertificateImmutableDiagId = "SYSLIB0026";
                }
                {
                    this.PublicKeyPropertyMessage = "PublicKey.Key is obsolete. Use the appropriate method to get the public key, such as GetRSAPublicKey.";
                }
                {
                    this.PublicKeyPropertyDiagId = "SYSLIB0027";
                }
                {
                    this.X509CertificatePrivateKeyMessage = "X509Certificate2.PrivateKey is obsolete. Use the appropriate method to get the private key, such as GetRSAPrivateKey, or use the CopyWithPrivateKey method to create a new instance with a private key.";
                }
                {
                    this.X509CertificatePrivateKeyDiagId = "SYSLIB0028";
                }
                {
                    this.ProduceLegacyHmacValuesMessage = "ProduceLegacyHmacValues is obsolete. Producing legacy HMAC values is not supported.";
                }
                {
                    this.ProduceLegacyHmacValuesDiagId = "SYSLIB0029";
                }
                {
                    this.UseManagedSha1Message = "HMACSHA1 always uses the algorithm implementation provided by the platform. Use a constructor without the useManagedSha1 parameter.";
                }
                {
                    this.UseManagedSha1DiagId = "SYSLIB0030";
                }
                {
                    this.CryptoConfigEncodeOIDMessage = "EncodeOID is obsolete. Use the ASN.1 functionality provided in System.Formats.Asn1.";
                }
                {
                    this.CryptoConfigEncodeOIDDiagId = "SYSLIB0031";
                }
                {
                    this.CorruptedStateRecoveryMessage = "Recovery from corrupted process state exceptions is not supported; HandleProcessCorruptedStateExceptionsAttribute is ignored.";
                }
                {
                    this.CorruptedStateRecoveryDiagId = "SYSLIB0032";
                }
                {
                    this.Rfc2898CryptDeriveKeyMessage = "Rfc2898DeriveBytes.CryptDeriveKey is obsolete and is not supported. Use PasswordDeriveBytes.CryptDeriveKey instead.";
                }
                {
                    this.Rfc2898CryptDeriveKeyDiagId = "SYSLIB0033";
                }
                {
                    this.CmsSignerCspParamsCtorMessage = "CmsSigner(CspParameters) is obsolete and is not supported. Use an alternative constructor instead.";
                }
                {
                    this.CmsSignerCspParamsCtorDiagId = "SYSLIB0034";
                }
                {
                    this.SignerInfoCounterSigMessage = "ComputeCounterSignature without specifying a CmsSigner is obsolete and is not supported. Use the overload that accepts a CmsSigner.";
                }
                {
                    this.SignerInfoCounterSigDiagId = "SYSLIB0035";
                }
                {
                    this.RegexCompileToAssemblyMessage = "Regex.CompileToAssembly is obsolete and not supported. Use the GeneratedRegexAttribute with the regular expression source generator instead.";
                }
                {
                    this.RegexCompileToAssemblyDiagId = "SYSLIB0036";
                }
                {
                    this.AssemblyNameMembersMessage = "AssemblyName members HashAlgorithm, ProcessorArchitecture, and VersionCompatibility are obsolete and not supported.";
                }
                {
                    this.AssemblyNameMembersDiagId = "SYSLIB0037";
                }
                {
                    this.SystemDataSerializationFormatBinaryMessage = "SerializationFormat.Binary is obsolete and should not be used. See https://aka.ms/serializationformat-binary-obsolete for more information.";
                }
                {
                    this.SystemDataSerializationFormatBinaryDiagId = "SYSLIB0038";
                }
                {
                    this.TlsVersion10and11Message = "TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.";
                }
                {
                    this.TlsVersion10and11DiagId = "SYSLIB0039";
                }
                {
                    this.EncryptionPolicyMessage = "EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.";
                }
                {
                    this.EncryptionPolicyDiagId = "SYSLIB0040";
                }
                {
                    this.EccXmlExportImportMessage = "ToXmlString and FromXmlString have no implementation for ECC types, and are obsolete. Use a standard import and export format such as ExportSubjectPublicKeyInfo or ImportSubjectPublicKeyInfo for public keys and ExportPkcs8PrivateKey or ImportPkcs8PrivateKey for private keys.";
                }
                {
                    this.EccXmlExportImportDiagId = "SYSLIB0042";
                }
                {
                    this.EcDhPublicKeyBlobMessage = "ECDiffieHellmanPublicKey.ToByteArray() and the associated constructor do not have a consistent and interoperable implementation on all platforms. Use ECDiffieHellmanPublicKey.ExportSubjectPublicKeyInfo() instead.";
                }
                {
                    this.EcDhPublicKeyBlobDiagId = "SYSLIB0043";
                }
                {
                    this.AssemblyNameCodeBaseMessage = "AssemblyName.CodeBase and AssemblyName.EscapedCodeBase are obsolete. Using them for loading an assembly is not supported.";
                }
                {
                    this.AssemblyNameCodeBaseDiagId = "SYSLIB0044";
                }
                {
                    this.CryptoStringFactoryMessage = "Cryptographic factory methods accepting an algorithm name are obsolete. Use the parameterless Create factory method on the algorithm type instead.";
                }
                {
                    this.CryptoStringFactoryDiagId = "SYSLIB0045";
                }
                {
                    this.ControlledExecutionRunMessage = "ControlledExecution.Run method may corrupt the process and should not be used in production code.";
                }
                {
                    this.ControlledExecutionRunDiagId = "SYSLIB0046";
                }
                {
                    this.XmlSecureResolverMessage = "XmlSecureResolver is obsolete. Use XmlResolver.ThrowingResolver instead when attempting to forbid XML external entity resolution.";
                }
                {
                    this.XmlSecureResolverDiagId = "SYSLIB0047";
                }
                {
                    this.RsaEncryptDecryptValueMessage = "RSA.EncryptValue and DecryptValue are not supported and throw NotSupportedException. Use RSA.Encrypt and RSA.Decrypt instead.";
                }
                {
                    this.RsaEncryptDecryptDiagId = "SYSLIB0048";
                }
                {
                    this.JsonSerializerOptionsAddContextMessage = "JsonSerializerOptions.AddContext is obsolete. To register a JsonSerializerContext, use either the TypeInfoResolver or TypeInfoResolverChain properties.";
                }
                {
                    this.JsonSerializerOptionsAddContextDiagId = "SYSLIB0049";
                }
                {
                    this.LegacyFormatterMessage = "Formatter-based serialization is obsolete and should not be used.";
                }
                {
                    this.LegacyFormatterDiagId = "SYSLIB0050";
                }
                {
                    this.LegacyFormatterImplMessage = "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.";
                }
                {
                    this.LegacyFormatterImplDiagId = "SYSLIB0051";
                }
                {
                    this.RegexExtensibilityImplMessage = "This API supports obsolete mechanisms for Regex extensibility. It is not supported.";
                }
                {
                    this.RegexExtensibilityDiagId = "SYSLIB0052";
                }
                {
                    this.AesGcmTagConstructorMessage = "AesGcm should indicate the required tag size for encryption and decryption. Use a constructor that accepts the tag size.";
                }
                {
                    this.AesGcmTagConstructorDiagId = "SYSLIB0053";
                }
                {
                    this.ThreadVolatileReadWriteMessage = "Thread.VolatileRead and Thread.VolatileWrite are obsolete. Use Volatile.Read or Volatile.Write respectively instead.";
                }
                {
                    this.ThreadVolatileReadWriteDiagId = "SYSLIB0054";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationMessage = "The underlying hardware instruction does not perform a signed saturate narrowing operation, and it always returns an unsigned result. Use the unsigned overload instead.";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationDiagId = "SYSLIB0055";
                }
                {
                    this.LoadFromHashAlgorithmMessage = "LoadFrom with a custom AssemblyHashAlgorithm is obsolete. Use overloads without an AssemblyHashAlgorithm.";
                }
                {
                    this.LoadFromHashAlgorithmDiagId = "SYSLIB0056";
                }
                {
                    this.X509CtorCertDataObsoleteMessage = "Loading certificate data through the constructor or Import is obsolete. Use X509CertificateLoader instead to load certificates.";
                }
                {
                    this.X509CtorCertDataObsoleteDiagId = "SYSLIB0057";
                }
                {
                    this.TlsCipherAlgorithmEnumsMessage = "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.";
                }
                {
                    this.TlsCipherAlgorithmEnumsDiagId = "SYSLIB0058";
                }
                {
                    this.SystemEventsEventsThreadShutdownMessage = "SystemEvents.EventsThreadShutdown callbacks are not run before the process exits. Use AppDomain.ProcessExit instead.";
                }
                {
                    this.SystemEventsEventsThreadShutdownDiagId = "SYSLIB0059";
                }
                {
                    this.Rfc2898DeriveBytesCtorMessage = "The constructors on Rfc2898DeriveBytes are obsolete. Use the static Pbkdf2 method instead.";
                }
                {
                    this.Rfc2898DeriveBytesCtorDiagId = "SYSLIB0060";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteMessage = "The Queryable MinBy and MaxBy taking an IComparer<TSource> are obsolete. Use the new ones that take an IComparer<TKey>.";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteDiagId = "SYSLIB0061";
                }
                {
                    this.XsltSettingsEnableScriptMessage = "XSLT Script blocks are not supported.";
                }
                {
                    this.XsltSettingsEnableScriptDiagId = "SYSLIB0062";
                }
            }
            static $h = 166856;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"SharedUrlFormat","d":166856,"h":4295134152,"f":40},{"t":1310721,"n":"SystemTextEncodingUTF7Message","d":166856,"h":8590101448,"f":40},{"t":1310721,"n":"SystemTextEncodingUTF7DiagId","d":166856,"h":12885068744,"f":40},{"t":1310721,"n":"PrincipalPermissionAttributeMessage","d":166856,"h":17180036040,"f":40},{"t":1310721,"n":"PrincipalPermissionAttributeDiagId","d":166856,"h":21475003336,"f":40},{"t":1310721,"n":"CodeAccessSecurityMessage","d":166856,"h":25769970632,"f":40},{"t":1310721,"n":"CodeAccessSecurityDiagId","d":166856,"h":30064937928,"f":40},{"t":1310721,"n":"ConstrainedExecutionRegionMessage","d":166856,"h":34359905224,"f":40},{"t":1310721,"n":"ConstrainedExecutionRegionDiagId","d":166856,"h":38654872520,"f":40},{"t":1310721,"n":"GlobalAssemblyCacheMessage","d":166856,"h":42949839816,"f":40},{"t":1310721,"n":"GlobalAssemblyCacheDiagId","d":166856,"h":47244807112,"f":40},{"t":1310721,"n":"ThreadAbortMessage","d":166856,"h":51539774408,"f":40},{"t":1310721,"n":"ThreadResetAbortMessage","d":166856,"h":55834741704,"f":40},{"t":1310721,"n":"ThreadAbortDiagId","d":166856,"h":60129709000,"f":40},{"t":1310721,"n":"DefaultCryptoAlgorithmsMessage","d":166856,"h":64424676296,"f":40},{"t":1310721,"n":"DefaultCryptoAlgorithmsDiagId","d":166856,"h":68719643592,"f":40},{"t":1310721,"n":"CreatePdbGeneratorMessage","d":166856,"h":73014610888,"f":40},{"t":1310721,"n":"CreatePdbGeneratorDiagId","d":166856,"h":77309578184,"f":40},{"t":1310721,"n":"AuthenticationManagerMessage","d":166856,"h":81604545480,"f":40},{"t":1310721,"n":"AuthenticationManagerDiagId","d":166856,"h":85899512776,"f":40},{"t":1310721,"n":"RemotingApisMessage","d":166856,"h":90194480072,"f":40},{"t":1310721,"n":"RemotingApisDiagId","d":166856,"h":94489447368,"f":40},{"t":1310721,"n":"BinaryFormatterMessage","d":166856,"h":98784414664,"f":40},{"t":1310721,"n":"BinaryFormatterDiagId","d":166856,"h":103079381960,"f":40},{"t":1310721,"n":"CodeBaseMessage","d":166856,"h":107374349256,"f":40},{"t":1310721,"n":"CodeBaseDiagId","d":166856,"h":111669316552,"f":40},{"t":1310721,"n":"EscapeUriStringMessage","d":166856,"h":115964283848,"f":40},{"t":1310721,"n":"EscapeUriStringDiagId","d":166856,"h":120259251144,"f":40},{"t":1310721,"n":"WebRequestMessage","d":166856,"h":124554218440,"f":40},{"t":1310721,"n":"WebRequestDiagId","d":166856,"h":128849185736,"f":40},{"t":1310721,"n":"DisablePrivateReflectionAttributeMessage","d":166856,"h":133144153032,"f":40},{"t":1310721,"n":"DisablePrivateReflectionAttributeDiagId","d":166856,"h":137439120328,"f":40},{"t":1310721,"n":"GetContextInfoMessage","d":166856,"h":141734087624,"f":40},{"t":1310721,"n":"GetContextInfoDiagId","d":166856,"h":146029054920,"f":40},{"t":1310721,"n":"StrongNameKeyPairMessage","d":166856,"h":150324022216,"f":40},{"t":1310721,"n":"StrongNameKeyPairDiagId","d":166856,"h":154618989512,"f":40},{"t":1310721,"n":"ReflectionOnlyLoadingMessage","d":166856,"h":158913956808,"f":40},{"t":1310721,"n":"ReflectionOnlyLoadingDiagId","d":166856,"h":163208924104,"f":40},{"t":1310721,"n":"RuntimeEnvironmentMessage","d":166856,"h":167503891400,"f":40},{"t":1310721,"n":"RuntimeEnvironmentDiagId","d":166856,"h":171798858696,"f":40},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesMessage","d":166856,"h":176093825992,"f":40},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesDiagId","d":166856,"h":180388793288,"f":40},{"t":1310721,"n":"DerivedCryptographicTypesMessage","d":166856,"h":184683760584,"f":40},{"t":1310721,"n":"DerivedCryptographicTypesDiagId","d":166856,"h":188978727880,"f":40},{"t":1310721,"n":"RijndaelMessage","d":166856,"h":193273695176,"f":40},{"t":1310721,"n":"RijndaelDiagId","d":166856,"h":197568662472,"f":40},{"t":1310721,"n":"RNGCryptoServiceProviderMessage","d":166856,"h":201863629768,"f":40},{"t":1310721,"n":"RNGCryptoServiceProviderDiagId","d":166856,"h":206158597064,"f":40},{"t":1310721,"n":"AppDomainCreateUnloadMessage","d":166856,"h":210453564360,"f":40},{"t":1310721,"n":"AppDomainCreateUnloadDiagId","d":166856,"h":214748531656,"f":40},{"t":1310721,"n":"SuppressIldasmAttributeMessage","d":166856,"h":219043498952,"f":40},{"t":1310721,"n":"SuppressIldasmAttributeDiagId","d":166856,"h":223338466248,"f":40},{"t":1310721,"n":"X509CertificateImmutableMessage","d":166856,"h":227633433544,"f":40},{"t":1310721,"n":"X509CertificateImmutableDiagId","d":166856,"h":231928400840,"f":40},{"t":1310721,"n":"PublicKeyPropertyMessage","d":166856,"h":236223368136,"f":40},{"t":1310721,"n":"PublicKeyPropertyDiagId","d":166856,"h":240518335432,"f":40},{"t":1310721,"n":"X509CertificatePrivateKeyMessage","d":166856,"h":244813302728,"f":40},{"t":1310721,"n":"X509CertificatePrivateKeyDiagId","d":166856,"h":249108270024,"f":40},{"t":1310721,"n":"ProduceLegacyHmacValuesMessage","d":166856,"h":253403237320,"f":40},{"t":1310721,"n":"ProduceLegacyHmacValuesDiagId","d":166856,"h":257698204616,"f":40},{"t":1310721,"n":"UseManagedSha1Message","d":166856,"h":261993171912,"f":40},{"t":1310721,"n":"UseManagedSha1DiagId","d":166856,"h":266288139208,"f":40},{"t":1310721,"n":"CryptoConfigEncodeOIDMessage","d":166856,"h":270583106504,"f":40},{"t":1310721,"n":"CryptoConfigEncodeOIDDiagId","d":166856,"h":274878073800,"f":40},{"t":1310721,"n":"CorruptedStateRecoveryMessage","d":166856,"h":279173041096,"f":40},{"t":1310721,"n":"CorruptedStateRecoveryDiagId","d":166856,"h":283468008392,"f":40},{"t":1310721,"n":"Rfc2898CryptDeriveKeyMessage","d":166856,"h":287762975688,"f":40},{"t":1310721,"n":"Rfc2898CryptDeriveKeyDiagId","d":166856,"h":292057942984,"f":40},{"t":1310721,"n":"CmsSignerCspParamsCtorMessage","d":166856,"h":296352910280,"f":40},{"t":1310721,"n":"CmsSignerCspParamsCtorDiagId","d":166856,"h":300647877576,"f":40},{"t":1310721,"n":"SignerInfoCounterSigMessage","d":166856,"h":304942844872,"f":40},{"t":1310721,"n":"SignerInfoCounterSigDiagId","d":166856,"h":309237812168,"f":40},{"t":1310721,"n":"RegexCompileToAssemblyMessage","d":166856,"h":313532779464,"f":40},{"t":1310721,"n":"RegexCompileToAssemblyDiagId","d":166856,"h":317827746760,"f":40},{"t":1310721,"n":"AssemblyNameMembersMessage","d":166856,"h":322122714056,"f":40},{"t":1310721,"n":"AssemblyNameMembersDiagId","d":166856,"h":326417681352,"f":40},{"t":1310721,"n":"SystemDataSerializationFormatBinaryMessage","d":166856,"h":330712648648,"f":40},{"t":1310721,"n":"SystemDataSerializationFormatBinaryDiagId","d":166856,"h":335007615944,"f":40},{"t":1310721,"n":"TlsVersion10and11Message","d":166856,"h":339302583240,"f":40},{"t":1310721,"n":"TlsVersion10and11DiagId","d":166856,"h":343597550536,"f":40},{"t":1310721,"n":"EncryptionPolicyMessage","d":166856,"h":347892517832,"f":40},{"t":1310721,"n":"EncryptionPolicyDiagId","d":166856,"h":352187485128,"f":40},{"t":1310721,"n":"EccXmlExportImportMessage","d":166856,"h":356482452424,"f":40},{"t":1310721,"n":"EccXmlExportImportDiagId","d":166856,"h":360777419720,"f":40},{"t":1310721,"n":"EcDhPublicKeyBlobMessage","d":166856,"h":365072387016,"f":40},{"t":1310721,"n":"EcDhPublicKeyBlobDiagId","d":166856,"h":369367354312,"f":40},{"t":1310721,"n":"AssemblyNameCodeBaseMessage","d":166856,"h":373662321608,"f":40},{"t":1310721,"n":"AssemblyNameCodeBaseDiagId","d":166856,"h":377957288904,"f":40},{"t":1310721,"n":"CryptoStringFactoryMessage","d":166856,"h":382252256200,"f":40},{"t":1310721,"n":"CryptoStringFactoryDiagId","d":166856,"h":386547223496,"f":40},{"t":1310721,"n":"ControlledExecutionRunMessage","d":166856,"h":390842190792,"f":40},{"t":1310721,"n":"ControlledExecutionRunDiagId","d":166856,"h":395137158088,"f":40},{"t":1310721,"n":"XmlSecureResolverMessage","d":166856,"h":399432125384,"f":40},{"t":1310721,"n":"XmlSecureResolverDiagId","d":166856,"h":403727092680,"f":40},{"t":1310721,"n":"RsaEncryptDecryptValueMessage","d":166856,"h":408022059976,"f":40},{"t":1310721,"n":"RsaEncryptDecryptDiagId","d":166856,"h":412317027272,"f":40},{"t":1310721,"n":"JsonSerializerOptionsAddContextMessage","d":166856,"h":416611994568,"f":40},{"t":1310721,"n":"JsonSerializerOptionsAddContextDiagId","d":166856,"h":420906961864,"f":40},{"t":1310721,"n":"LegacyFormatterMessage","d":166856,"h":425201929160,"f":40},{"t":1310721,"n":"LegacyFormatterDiagId","d":166856,"h":429496896456,"f":40},{"t":1310721,"n":"LegacyFormatterImplMessage","d":166856,"h":433791863752,"f":40},{"t":1310721,"n":"LegacyFormatterImplDiagId","d":166856,"h":438086831048,"f":40},{"t":1310721,"n":"RegexExtensibilityImplMessage","d":166856,"h":442381798344,"f":40},{"t":1310721,"n":"RegexExtensibilityDiagId","d":166856,"h":446676765640,"f":40},{"t":1310721,"n":"AesGcmTagConstructorMessage","d":166856,"h":450971732936,"f":40},{"t":1310721,"n":"AesGcmTagConstructorDiagId","d":166856,"h":455266700232,"f":40},{"t":1310721,"n":"ThreadVolatileReadWriteMessage","d":166856,"h":459561667528,"f":40},{"t":1310721,"n":"ThreadVolatileReadWriteDiagId","d":166856,"h":463856634824,"f":40},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationMessage","d":166856,"h":468151602120,"f":40},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationDiagId","d":166856,"h":472446569416,"f":40},{"t":1310721,"n":"LoadFromHashAlgorithmMessage","d":166856,"h":476741536712,"f":40},{"t":1310721,"n":"LoadFromHashAlgorithmDiagId","d":166856,"h":481036504008,"f":40},{"t":1310721,"n":"X509CtorCertDataObsoleteMessage","d":166856,"h":485331471304,"f":40},{"t":1310721,"n":"X509CtorCertDataObsoleteDiagId","d":166856,"h":489626438600,"f":40},{"t":1310721,"n":"TlsCipherAlgorithmEnumsMessage","d":166856,"h":493921405896,"f":40},{"t":1310721,"n":"TlsCipherAlgorithmEnumsDiagId","d":166856,"h":498216373192,"f":40},{"t":1310721,"n":"SystemEventsEventsThreadShutdownMessage","d":166856,"h":502511340488,"f":40},{"t":1310721,"n":"SystemEventsEventsThreadShutdownDiagId","d":166856,"h":506806307784,"f":40},{"t":1310721,"n":"Rfc2898DeriveBytesCtorMessage","d":166856,"h":511101275080,"f":40},{"t":1310721,"n":"Rfc2898DeriveBytesCtorDiagId","d":166856,"h":515396242376,"f":40},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteMessage","d":166856,"h":519691209672,"f":40},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteDiagId","d":166856,"h":523986176968,"f":40},{"t":1310721,"n":"XsltSettingsEnableScriptMessage","d":166856,"h":528281144264,"f":40},{"t":1310721,"n":"XsltSettingsEnableScriptDiagId","d":166856,"h":532576111560,"f":40}],"h":166856}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Obsoletions`; }
        });
        
        $asm.$cls("$st.System.Threading.HostExecutionContext", ($self) => class HostExecutionContext extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*object?*/ state)
            {
                super.$ctor();
                {
                    this.State = state;
                }
                return this;
            }
            /*object?*/ State = null;
            /*HostExecutionContext */ CreateCopy()
            {
                return new $.$st.System.Threading.HostExecutionContext().$ctor$2(this.State);
            }
            /*void */ Dispose()
            {
                this.Dispose$1(true);
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            static $h = 560072;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":131073,"g":{"r":0,"d":0,"h":21475396552,"f":16},"s":{"r":0,"d":0,"h":25770363848,"f":16},"n":"State","d":560072,"h":17180429256,"f":16}],"m":[{"r":560072,"n":"CreateCopy","d":560072,"h":30065331144,"f":129},{"r":65537,"n":"Dispose","d":560072,"h":34360298440,"f":1},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":560072,"h":38655265736,"f":129}],"c":[{"n":".ctor","o":"$ctor$1","d":560072,"h":4295527368,"f":1},{"p":[{"n":"state","p":131073}],"n":".ctor","o":"$ctor$2","d":560072,"h":8590494664,"f":1}],"i":[57540609],"h":560072}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Threading.HostExecutionContext`; }
        });
        
        $asm.$cls("$st.System.Threading.CountdownEvent", ($self) => class CountdownEvent extends $.$spc.System.Object
        {
            /*int*/ _initialCount = 0;
            /*int*/ _currentCount = 0;
            /*ManualResetEventSlim*/ _event = null;
            /*bool*/ _disposed = false;
            $ctor$1(/*int*/ initialCount)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegative($.$spc.System.Int32, initialCount, "initialCount");
                    this._initialCount = initialCount;
                    this._currentCount = initialCount;
                    this._event = new $.$spc.System.Threading.ManualResetEventSlim().$ctor$1();
                    if (initialCount === 0)
                    {
                        this._event.Set$1();
                    }
                }
                return this;
            }
            /*int */ get CurrentCount()
            {
                /*int*/ let observedCount = this._currentCount;
                return observedCount < 0 ? 0 : observedCount;
            }
            /*int */ get InitialCount()
            {
                return this._initialCount;
            }
            /*bool */ get IsSet()
            {
                return (this._currentCount <= 0);
            }
            /*WaitHandle */ get WaitHandle()
            {
                $.$spc.System.ObjectDisposedException.ThrowIf(this._disposed, this);
                return this._event.WaitHandle;
            }
            /*void */ Dispose()
            {
                this.Dispose$1(true);
                $.$spc.System.GC.SuppressFinalize(this);
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                if (disposing)
                {
                    this._event.Dispose();
                    this._disposed = true;
                }
            }
            /*bool */ Signal()
            {
                $.$spc.System.ObjectDisposedException.ThrowIf(this._disposed, this);
                $.$spc.System.Diagnostics.Debug.Assert$1(this._event !== null, "_event != null");
                if (this._currentCount <= 0)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$st.System.SR.CountdownEvent_Decrement_BelowZero);
                }
                /*int*/ let newCount = $.$spc.System.Threading.Interlocked.Decrement($.$ref(() => this._currentCount, ($v) => this._currentCount = $v, $.$spc.System.Int32));
                if (newCount === 0)
                {
                    this._event.Set$1();
                    return true;
                }
                else if (newCount < 0)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$st.System.SR.CountdownEvent_Decrement_BelowZero);
                }
                return false;
            }
            /*bool */ Signal$1(/*int*/ signalCount)
            {
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$spc.System.Int32, signalCount, "signalCount");
                $.$spc.System.ObjectDisposedException.ThrowIf(this._disposed, this);
                $.$spc.System.Diagnostics.Debug.Assert$1(this._event !== null, "_event != null");
                /*int*/ let observedCount;
                /*SpinWait*/ let spin = new $.$spc.System.Threading.SpinWait();
                while(true)
                {
                    observedCount = this._currentCount;
                    if (observedCount < signalCount)
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$st.System.SR.CountdownEvent_Decrement_BelowZero);
                    }
                    if ($.$spc.System.Threading.Interlocked.CompareExchange($.$ref(() => this._currentCount, ($v) => this._currentCount = $v, $.$spc.System.Int32), ((observedCount - signalCount) | 0), observedCount) === observedCount)
                    {
                        break;
                    }
                    spin.SpinOnce$1(-1);
                }
                if (observedCount === signalCount)
                {
                    this._event.Set$1();
                    return true;
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(this._currentCount >= 0, "latch was decremented below zero");
                return false;
            }
            /*void */ AddCount()
            {
                this.AddCount$1(1);
            }
            /*bool */ TryAddCount()
            {
                return this.TryAddCount$1(1);
            }
            /*void */ AddCount$1(/*int*/ signalCount)
            {
                if (!this.TryAddCount$1(signalCount))
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$st.System.SR.CountdownEvent_Increment_AlreadyZero);
                }
            }
            /*bool */ TryAddCount$1(/*int*/ signalCount)
            {
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$spc.System.Int32, signalCount, "signalCount");
                $.$spc.System.ObjectDisposedException.ThrowIf(this._disposed, this);
                /*int*/ let observedCount;
                /*SpinWait*/ let spin = new $.$spc.System.Threading.SpinWait();
                while(true)
                {
                    observedCount = this._currentCount;
                    if (observedCount <= 0)
                    {
                        return false;
                    }
                    else if (observedCount > (((2147483647/*int.MaxValue*/ - signalCount) | 0)))
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$st.System.SR.CountdownEvent_Increment_AlreadyMax);
                    }
                    if ($.$spc.System.Threading.Interlocked.CompareExchange($.$ref(() => this._currentCount, ($v) => this._currentCount = $v, $.$spc.System.Int32), ((observedCount + signalCount) | 0), observedCount) === observedCount)
                    {
                        break;
                    }
                    spin.SpinOnce$1(-1);
                }
                return true;
            }
            /*void */ Reset()
            {
                this.Reset$1(this._initialCount);
            }
            /*void */ Reset$1(/*int*/ count)
            {
                $.$spc.System.ObjectDisposedException.ThrowIf(this._disposed, this);
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegative($.$spc.System.Int32, count, "count");
                this._currentCount = count;
                this._initialCount = count;
                if (count === 0)
                {
                    this._event.Set$1();
                }
                else 
                {
                    this._event.Reset();
                }
            }
            /*void */ Wait()
            {
                this.Wait$5(-1/*Timeout.Infinite*/, $.$spc.System.Threading.CancellationToken.None);
            }
            /*void */ Wait$1(/*CancellationToken*/ cancellationToken)
            {
                this.Wait$5(-1/*Timeout.Infinite*/, cancellationToken);
            }
            /*bool */ Wait$2(/*TimeSpan*/ timeout)
            {
                /*long*/ let totalMilliseconds = $.$cast(timeout.TotalMilliseconds, $.$spc.System.Int64);
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfLessThan($.$spc.System.Int64, totalMilliseconds, BigInt(-1), "timeout");
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$spc.System.Int64, totalMilliseconds, BigInt(2147483647/*int.MaxValue*/), "timeout");
                return this.Wait$5($.$cast(totalMilliseconds, $.$spc.System.Int32), $.$spc.System.Threading.CancellationToken.None);
            }
            /*bool */ Wait$3(/*TimeSpan*/ timeout, /*CancellationToken*/ cancellationToken)
            {
                /*long*/ let totalMilliseconds = $.$cast(timeout.TotalMilliseconds, $.$spc.System.Int64);
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfLessThan($.$spc.System.Int64, totalMilliseconds, BigInt(-1), "timeout");
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$spc.System.Int64, totalMilliseconds, BigInt(2147483647/*int.MaxValue*/), "timeout");
                return this.Wait$5($.$cast(totalMilliseconds, $.$spc.System.Int32), cancellationToken);
            }
            /*bool */ Wait$4(/*int*/ millisecondsTimeout)
            {
                return this.Wait$5(millisecondsTimeout, $.$spc.System.Threading.CancellationToken.None);
            }
            /*bool */ Wait$5(/*int*/ millisecondsTimeout, /*CancellationToken*/ cancellationToken)
            {
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfLessThan($.$spc.System.Int32, millisecondsTimeout, -1, "millisecondsTimeout");
                $.$spc.System.ObjectDisposedException.ThrowIf(this._disposed, this);
                cancellationToken.ThrowIfCancellationRequested();
                /*bool*/ let returnValue = this._event.IsSet;
                if (!returnValue)
                {
                    returnValue = this._event.Wait$5(millisecondsTimeout, cancellationToken);
                }
                return returnValue;
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            static $h = 494536;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":30065265608,"f":1},"n":"CurrentCount","d":494536,"h":25770298312,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":38655200200,"f":1},"n":"InitialCount","d":494536,"h":34360232904,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":47245134792,"f":1},"n":"IsSet","d":494536,"h":42950167496,"f":1},{"p":139132929,"g":{"r":0,"d":0,"h":55835069384,"f":1},"n":"WaitHandle","d":494536,"h":51540102088,"f":1}],"m":[{"r":65537,"n":"Dispose","d":494536,"h":60130036680,"f":1},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":494536,"h":64425003976,"f":132},{"r":262145,"n":"Signal","d":494536,"h":68719971272,"f":1},{"r":262145,"p":[{"n":"signalCount","p":655361}],"n":"Signal","o":"@$1","d":494536,"h":73014938568,"f":1},{"r":65537,"n":"AddCount","d":494536,"h":77309905864,"f":1},{"r":262145,"n":"TryAddCount","d":494536,"h":81604873160,"f":1},{"r":65537,"p":[{"n":"signalCount","p":655361}],"n":"AddCount","o":"@$1","d":494536,"h":85899840456,"f":1},{"r":262145,"p":[{"n":"signalCount","p":655361}],"n":"TryAddCount","o":"@$1","d":494536,"h":90194807752,"f":1},{"r":65537,"n":"Reset","d":494536,"h":94489775048,"f":1},{"r":65537,"p":[{"n":"count","p":655361}],"n":"Reset","o":"@$1","d":494536,"h":98784742344,"f":1},{"r":65537,"n":"Wait","d":494536,"h":103079709640,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]}]},{"r":65537,"p":[{"n":"cancellationToken","p":125960193}],"n":"Wait","o":"@$1","d":494536,"h":107374676936,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]}]},{"r":262145,"p":[{"n":"timeout","p":140705793}],"n":"Wait","o":"@$2","d":494536,"h":111669644232,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]}]},{"r":262145,"p":[{"n":"timeout","p":140705793},{"n":"cancellationToken","p":125960193}],"n":"Wait","o":"@$3","d":494536,"h":115964611528,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]}]},{"r":262145,"p":[{"n":"millisecondsTimeout","p":655361}],"n":"Wait","o":"@$4","d":494536,"h":120259578824,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]}]},{"r":262145,"p":[{"n":"millisecondsTimeout","p":655361},{"n":"cancellationToken","p":125960193}],"n":"Wait","o":"@$5","d":494536,"h":124554546120,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]}]}],"l":[{"t":655361,"n":"_initialCount","d":494536,"h":4295461832,"f":2},{"t":655361,"n":"_currentCount","d":494536,"h":8590429128,"f":2},{"t":128385025,"n":"_event","d":494536,"h":12885396424,"f":2},{"t":262145,"n":"_disposed","d":494536,"h":17180363720,"f":2}],"c":[{"p":[{"n":"initialCount","p":655361}],"n":".ctor","o":"$ctor$1","d":494536,"h":21475331016,"f":1}],"i":[57540609],"h":494536,"a":[{"t":37617665,"c":8627552257,"a":[{"v":"InitialCount = {InitialCount}, CurrentCount = {CurrentCount}","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Threading.CountdownEvent`; }
        });
        
        $asm.$cls("$st.System.Threading.Barrier", ($self) => class Barrier extends $.$spc.System.Object
        {
            /*int*/ _currentTotalCount = 0;
            /*int*/ static CURRENT_MASK = 2147418112;
            /*int*/ static TOTAL_MASK = 32767;
            /*int*/ static SENSE_MASK = -2147483648;
            /*int*/ static MAX_PARTICIPANTS = 32767;
            /*long*/ _currentPhase = 0n;
            /*bool*/ _disposed = false;
            /*ManualResetEventSlim*/ _oddEvent = null;
            /*ManualResetEventSlim*/ _evenEvent = null;
            /*ExecutionContext?*/ _ownerThreadContext = null;
            /*ContextCallback?*/ static s_invokePostPhaseAction = null;
            /*Action<Barrier>?*/ _postPhaseAction = null;
            /*Exception?*/ _exception = null;
            /*int*/ _actionCallerID = 0;
            /*int */ get ParticipantsRemaining()
            {
                /*int*/ let currentTotal = this._currentTotalCount;
                /*int*/ let total = (currentTotal & 32767/*TOTAL_MASK*/);
                /*int*/ let current = ((currentTotal & 2147418112/*CURRENT_MASK*/) >> 16);
                return ((total - current) | 0);
            }
            /*int */ get ParticipantCount()
            {
                return (this._currentTotalCount & 32767/*TOTAL_MASK*/);
            }
            /*long */ get CurrentPhaseNumber()
            {
                return $.$ref(() => this._currentPhase, ($v) => this._currentPhase = $v, $.$spc.System.Int64).$v;
            }
            /*long */ set CurrentPhaseNumber(value)
            {
                $.$ref(() => this._currentPhase, ($v) => this._currentPhase = $v, $.$spc.System.Int64).$v = value;
            }
            $ctor$1(/*int*/ participantCount)
            {
                this.$ctor$2(participantCount, null);
                {
                }
                return this;
            }
            $ctor$2(/*int*/ participantCount, /*Action<Barrier>?*/ postPhaseAction)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegative($.$spc.System.Int32, participantCount, "participantCount");
                    $.$spc.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$spc.System.Int32, participantCount, 32767/*MAX_PARTICIPANTS*/, "participantCount");
                    this._currentTotalCount = participantCount;
                    this._postPhaseAction = postPhaseAction;
                    this._oddEvent = new $.$spc.System.Threading.ManualResetEventSlim().$ctor$2(true);
                    this._evenEvent = new $.$spc.System.Threading.ManualResetEventSlim().$ctor$2(false);
                    if (!(postPhaseAction === null))
                    {
                        this._ownerThreadContext = $.$spc.System.Threading.ExecutionContext.Capture();
                    }
                    this._actionCallerID = 0;
                }
                return this;
            }
            static /*void */ GetCurrentTotal(/*int*/ currentTotal, /*out int*/ current, /*out int*/ total, /*out bool*/ sense)
            {
                total.$v = (currentTotal & 32767/*TOTAL_MASK*/);
                current.$v = ((currentTotal & 2147418112/*CURRENT_MASK*/) >> 16);
                sense.$v = (currentTotal & -2147483648/*SENSE_MASK*/) === 0 ? true : false;
            }
            /*bool */ SetCurrentTotal(/*int*/ currentTotal, /*int*/ current, /*int*/ total, /*bool*/ sense)
            {
                /*int*/ let newCurrentTotal = (current << 16) | total;
                if (!sense)
                {
                    newCurrentTotal |= -2147483648/*SENSE_MASK*/;
                }
                return $.$spc.System.Threading.Interlocked.CompareExchange($.$ref(() => this._currentTotalCount, ($v) => this._currentTotalCount = $v, $.$spc.System.Int32), newCurrentTotal, currentTotal) === currentTotal;
            }
            /*long */ AddParticipant()
            {
                try
                {
                    return this.AddParticipants(1);
                }
                catch($e)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$st.System.SR.Barrier_AddParticipants_Overflow_ArgumentOutOfRange);
                }
            }
            /*long */ AddParticipants(/*int*/ participantCount)
            {
                $.$spc.System.ObjectDisposedException.ThrowIf(this._disposed, this);
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$spc.System.Int32, participantCount, "participantCount");
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$spc.System.Int32, participantCount, 32767/*MAX_PARTICIPANTS*/, "participantCount");
                if (this._actionCallerID !== 0 && $.$spc.System.Environment.CurrentManagedThreadId === this._actionCallerID)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$st.System.SR.Barrier_InvalidOperation_CalledFromPHA);
                }
                /*SpinWait*/ let spinner = new $.$spc.System.Threading.SpinWait();
                /*long*/ let newPhase;
                while(true)
                {
                    /*int*/ let currentTotal = this._currentTotalCount;
                    /*int*/ let total;
                    /*int*/ let current;
                    /*bool*/ let sense;
                    $.$st.System.Threading.Barrier.GetCurrentTotal(currentTotal, $.$ref(() => current, ($v) => current = $v, $.$spc.System.Int32), $.$ref(() => total, ($v) => total = $v, $.$spc.System.Int32), $.$ref(() => sense, ($v) => sense = $v, $.$spc.System.Boolean));
                    if (((participantCount + total) | 0) > 32767/*MAX_PARTICIPANTS*/)
                    {
                        throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$17("participantCount", $.$st.System.SR.Barrier_AddParticipants_Overflow_ArgumentOutOfRange);
                    }
                    if (this.SetCurrentTotal(currentTotal, current, ((total + participantCount) | 0), sense))
                    {
                        /*long*/ let currPhase = this.CurrentPhaseNumber;
                        newPhase = (sense !== (currPhase % 2n === 0n)) ? currPhase + 1n : currPhase;
                        if (newPhase !== currPhase)
                        {
                            if (sense)
                            {
                                this._oddEvent.Wait();
                            }
                            else 
                            {
                                this._evenEvent.Wait();
                            }
                        }
                        else 
                        {
                            if (sense && this._evenEvent.IsSet)
                            {
                                this._evenEvent.Reset();
                            }
                            else if (!sense && this._oddEvent.IsSet)
                            {
                                this._oddEvent.Reset();
                            }
                        }
                        break;
                    }
                    spinner.SpinOnce$1(-1);
                }
                return newPhase;
            }
            /*void */ RemoveParticipant()
            {
                this.RemoveParticipants(1);
            }
            /*void */ RemoveParticipants(/*int*/ participantCount)
            {
                $.$spc.System.ObjectDisposedException.ThrowIf(this._disposed, this);
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$spc.System.Int32, participantCount, "participantCount");
                if (this._actionCallerID !== 0 && $.$spc.System.Environment.CurrentManagedThreadId === this._actionCallerID)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$st.System.SR.Barrier_InvalidOperation_CalledFromPHA);
                }
                /*SpinWait*/ let spinner = new $.$spc.System.Threading.SpinWait();
                while(true)
                {
                    /*int*/ let currentTotal = this._currentTotalCount;
                    /*int*/ let total;
                    /*int*/ let current;
                    /*bool*/ let sense;
                    $.$st.System.Threading.Barrier.GetCurrentTotal(currentTotal, $.$ref(() => current, ($v) => current = $v, $.$spc.System.Int32), $.$ref(() => total, ($v) => total = $v, $.$spc.System.Int32), $.$ref(() => sense, ($v) => sense = $v, $.$spc.System.Boolean));
                    if (total < participantCount)
                    {
                        throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$17("participantCount", $.$st.System.SR.Barrier_RemoveParticipants_ArgumentOutOfRange);
                    }
                    if (((total - participantCount) | 0) < current)
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$st.System.SR.Barrier_RemoveParticipants_InvalidOperation);
                    }
                    /*int*/ let remaingParticipants = ((total - participantCount) | 0);
                    if (remaingParticipants > 0 && current === remaingParticipants)
                    {
                        if (this.SetCurrentTotal(currentTotal, 0, ((total - participantCount) | 0), !sense))
                        {
                            this.FinishPhase(sense);
                            break;
                        }
                    }
                    else 
                    {
                        if (this.SetCurrentTotal(currentTotal, current, ((total - participantCount) | 0), sense))
                        {
                            break;
                        }
                    }
                    spinner.SpinOnce$1(-1);
                }
            }
            /*void */ SignalAndWait()
            {
                this.SignalAndWait$1($.$spc.System.Threading.CancellationToken.None);
            }
            /*void */ SignalAndWait$1(/*CancellationToken*/ cancellationToken)
            {
                /*bool*/ let result = this.SignalAndWait$5(-1/*Timeout.Infinite*/, cancellationToken);
                $.$spc.System.Diagnostics.Debug.Assert$1(result, "result");
            }
            /*bool */ SignalAndWait$2(/*TimeSpan*/ timeout)
            {
                return this.SignalAndWait$3(timeout, $.$spc.System.Threading.CancellationToken.None);
            }
            /*bool */ SignalAndWait$3(/*TimeSpan*/ timeout, /*CancellationToken*/ cancellationToken)
            {
                /*long*/ let totalMilliseconds = $.$cast(timeout.TotalMilliseconds, $.$spc.System.Int64);
                if (totalMilliseconds < BigInt(-1) || totalMilliseconds > BigInt(2147483647/*int.MaxValue*/))
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$19("timeout", timeout, $.$st.System.SR.Barrier_SignalAndWait_ArgumentOutOfRange);
                }
                return this.SignalAndWait$5($.$cast(timeout.TotalMilliseconds, $.$spc.System.Int32), cancellationToken);
            }
            /*bool */ SignalAndWait$4(/*int*/ millisecondsTimeout)
            {
                return this.SignalAndWait$5(millisecondsTimeout, $.$spc.System.Threading.CancellationToken.None);
            }
            /*bool */ SignalAndWait$5(/*int*/ millisecondsTimeout, /*CancellationToken*/ cancellationToken)
            {
                $.$spc.System.ObjectDisposedException.ThrowIf(this._disposed, this);
                cancellationToken.ThrowIfCancellationRequested();
                if (millisecondsTimeout < -1)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$19("millisecondsTimeout", $.$box(millisecondsTimeout, $.$spc.System.Int32), $.$st.System.SR.Barrier_SignalAndWait_ArgumentOutOfRange);
                }
                if (this._actionCallerID !== 0 && $.$spc.System.Environment.CurrentManagedThreadId === this._actionCallerID)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$st.System.SR.Barrier_InvalidOperation_CalledFromPHA);
                }
                /*bool*/ let sense;
                /*int*/ let total;
                /*int*/ let current;
                /*int*/ let currentTotal;
                /*long*/ let phase;
                /*SpinWait*/ let spinner = new $.$spc.System.Threading.SpinWait();
                while(true)
                {
                    currentTotal = this._currentTotalCount;
                    $.$st.System.Threading.Barrier.GetCurrentTotal(currentTotal, $.$ref(() => current, ($v) => current = $v, $.$spc.System.Int32), $.$ref(() => total, ($v) => total = $v, $.$spc.System.Int32), $.$ref(() => sense, ($v) => sense = $v, $.$spc.System.Boolean));
                    phase = this.CurrentPhaseNumber;
                    if (total === 0)
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$st.System.SR.Barrier_SignalAndWait_InvalidOperation_ZeroTotal);
                    }
                    if (current === 0 && sense !== (this.CurrentPhaseNumber % 2n === 0n))
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$st.System.SR.Barrier_SignalAndWait_InvalidOperation_ThreadsExceeded);
                    }
                    if (((current + 1) | 0) === total)
                    {
                        if (this.SetCurrentTotal(currentTotal, 0, total, !sense))
                        {
                            if ($.$st.System.Threading.CdsSyncEtwBCLProvider.Log.IsEnabled())
                            {
                                $.$st.System.Threading.CdsSyncEtwBCLProvider.Log.Barrier_PhaseFinished(sense, this.CurrentPhaseNumber);
                            }
                            this.FinishPhase(sense);
                            return true;
                        }
                    }
                    else if (this.SetCurrentTotal(currentTotal, ((current + 1) | 0), total, sense))
                    {
                        break;
                    }
                    spinner.SpinOnce$1(-1);
                }
                /*ManualResetEventSlim*/ let eventToWaitOn = (sense) ? this._evenEvent : this._oddEvent;
                /*bool*/ let waitWasCanceled = false;
                /*bool*/ let waitResult = false;
                try
                {
                    waitResult = this.DiscontinuousWait(eventToWaitOn, millisecondsTimeout, cancellationToken, phase);
                }
                catch($e)
                {
                    if ($e instanceof $.$spc.System.OperationCanceledException)
                    {
                        waitWasCanceled = true;
                    }
                    else if ($e instanceof $.$spc.System.ObjectDisposedException)
                    {
                        if (phase < this.CurrentPhaseNumber)
                        {
                            waitResult = true;
                        }
                        else 
                        {
                            throw $e;
                        }
                    }
                    else
                    {
                        throw $e;
                    }
                }
                if (!waitResult)
                {
                    spinner.Reset();
                    while(true)
                    {
                        /*bool*/ let newSense;
                        currentTotal = this._currentTotalCount;
                        $.$st.System.Threading.Barrier.GetCurrentTotal(currentTotal, $.$ref(() => current, ($v) => current = $v, $.$spc.System.Int32), $.$ref(() => total, ($v) => total = $v, $.$spc.System.Int32), $.$ref(() => newSense, ($v) => newSense = $v, $.$spc.System.Boolean));
                        if (phase < this.CurrentPhaseNumber || sense !== newSense)
                        {
                            this.WaitCurrentPhase(eventToWaitOn, phase);
                            $.$spc.System.Diagnostics.Debug.Assert$1(phase < this.CurrentPhaseNumber, "phase < CurrentPhaseNumber");
                            break;
                        }
                        if (this.SetCurrentTotal(currentTotal, ((current - 1) | 0), total, sense))
                        {
                            if (waitWasCanceled)
                            {
                                throw new $.$spc.System.OperationCanceledException().$ctor$13($.$st.System.SR.Common_OperationCanceled, cancellationToken);
                            }
                            else 
                            {
                                return false;
                            }
                        }
                        spinner.SpinOnce$1(-1);
                    }
                }
                if (!(this._exception === null))
                {
                    throw new $.$st.System.Threading.BarrierPostPhaseException().$ctor$6(this._exception);
                }
                return true;
            }
            /*void */ FinishPhase(/*bool*/ observedSense)
            {
                if (!(this._postPhaseAction === null))
                {
                    try
                    {
                        this._actionCallerID = $.$spc.System.Environment.CurrentManagedThreadId;
                        if (!(this._ownerThreadContext === null))
                        {
                            /*ContextCallback?*/ let handler = $.$st.System.Threading.Barrier.s_invokePostPhaseAction ??= new $.$spc.System.Threading.ContextCallback().$ctor($.$st.System.Threading.Barrier, $.$st.System.Threading.Barrier.InvokePostPhaseAction);
                            $.$spc.System.Threading.ExecutionContext.Run(this._ownerThreadContext, handler, this);
                        }
                        else 
                        {
                            this._postPhaseAction.Invoke(this);
                        }
                        this._exception = null;
                    }
                    catch(ex)
                    {
                        this._exception = ex;
                    }
                    finally
                    {
                        {
                            this._actionCallerID = 0;
                            this.SetResetEvents(observedSense);
                            if (!(this._exception === null))
                            {
                                throw new $.$st.System.Threading.BarrierPostPhaseException().$ctor$6(this._exception);
                            }
                        }
                    }
                }
                else 
                {
                    this.SetResetEvents(observedSense);
                }
            }
            static /*void */ InvokePostPhaseAction(/*object?*/ obj)
            {
                /*var*/ let thisBarrier = $.$cast(obj, $.$st.System.Threading.Barrier);
                thisBarrier.this._postPhaseAction.Invoke(thisBarrier);
            }
            /*void */ SetResetEvents(/*bool*/ observedSense)
            {
                this.CurrentPhaseNumber++;
                if (observedSense)
                {
                    this._oddEvent.Reset();
                    this._evenEvent.Set$1();
                }
                else 
                {
                    this._evenEvent.Reset();
                    this._oddEvent.Set$1();
                }
            }
            /*void */ WaitCurrentPhase(/*ManualResetEventSlim*/ currentPhaseEvent, /*long*/ observedPhase)
            {
                /*SpinWait*/ let spinner = new $.$spc.System.Threading.SpinWait();
                while(!currentPhaseEvent.IsSet && this.CurrentPhaseNumber - observedPhase <= 1n)
                {
                    spinner.SpinOnce();
                }
            }
            /*bool */ DiscontinuousWait(/*ManualResetEventSlim*/ currentPhaseEvent, /*int*/ totalTimeout, /*CancellationToken*/ token, /*long*/ observedPhase)
            {
                /*int*/ let maxWait = 100;
                /*int*/ let waitTimeCeiling = 10000;
                while(observedPhase === this.CurrentPhaseNumber)
                {
                    /*int*/ let waitTime = totalTimeout === -1/*Timeout.Infinite*/ ? maxWait : $.$spc.System.Math.Min$4(maxWait, totalTimeout);
                    if (currentPhaseEvent.Wait$5(waitTime, token))
                    {
                        return true;
                    }
                    if (totalTimeout !== -1/*Timeout.Infinite*/)
                    {
                        totalTimeout -= waitTime;
                        if (totalTimeout <= 0)
                        {
                            return false;
                        }
                    }
                    maxWait = maxWait >= waitTimeCeiling ? waitTimeCeiling : $.$spc.System.Math.Min$4(maxWait << 1, waitTimeCeiling);
                }
                this.WaitCurrentPhase(currentPhaseEvent, observedPhase);
                return true;
            }
            /*void */ Dispose()
            {
                if (this._actionCallerID !== 0 && $.$spc.System.Environment.CurrentManagedThreadId === this._actionCallerID)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$st.System.SR.Barrier_InvalidOperation_CalledFromPHA);
                }
                this.Dispose$1(true);
                $.$spc.System.GC.SuppressFinalize(this);
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                if (!this._disposed)
                {
                    if (disposing)
                    {
                        this._oddEvent.Dispose();
                        this._evenEvent.Dispose();
                    }
                    this._disposed = true;
                }
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            static $h = 297928;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":68719774664,"f":1},"n":"ParticipantsRemaining","d":297928,"h":64424807368,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":77309709256,"f":1},"n":"ParticipantCount","d":297928,"h":73014741960,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":85899643848,"f":1},"s":{"r":0,"d":0,"h":90194611144,"f":8},"n":"CurrentPhaseNumber","d":297928,"h":81604676552,"f":1}],"m":[{"r":65537,"p":[{"n":"currentTotal","p":655361},{"n":"current","p":655361,"f":2},{"n":"total","p":655361,"f":2},{"n":"sense","p":262145,"f":2}],"n":"GetCurrentTotal","d":297928,"h":103079513032,"f":34},{"r":262145,"p":[{"n":"currentTotal","p":655361},{"n":"current","p":655361},{"n":"total","p":655361},{"n":"sense","p":262145}],"n":"SetCurrentTotal","d":297928,"h":107374480328,"f":2},{"r":917505,"n":"AddParticipant","d":297928,"h":111669447624,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]}]},{"r":917505,"p":[{"n":"participantCount","p":655361}],"n":"AddParticipants","d":297928,"h":115964414920,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]}]},{"r":65537,"n":"RemoveParticipant","d":297928,"h":120259382216,"f":1},{"r":65537,"p":[{"n":"participantCount","p":655361}],"n":"RemoveParticipants","d":297928,"h":124554349512,"f":1},{"r":65537,"n":"SignalAndWait","d":297928,"h":128849316808,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]}]},{"r":65537,"p":[{"n":"cancellationToken","p":125960193}],"n":"SignalAndWait","o":"@$1","d":297928,"h":133144284104,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]}]},{"r":262145,"p":[{"n":"timeout","p":140705793}],"n":"SignalAndWait","o":"@$2","d":297928,"h":137439251400,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]}]},{"r":262145,"p":[{"n":"timeout","p":140705793},{"n":"cancellationToken","p":125960193}],"n":"SignalAndWait","o":"@$3","d":297928,"h":141734218696,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]}]},{"r":262145,"p":[{"n":"millisecondsTimeout","p":655361}],"n":"SignalAndWait","o":"@$4","d":297928,"h":146029185992,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]}]},{"r":262145,"p":[{"n":"millisecondsTimeout","p":655361},{"n":"cancellationToken","p":125960193}],"n":"SignalAndWait","o":"@$5","d":297928,"h":150324153288,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]}]},{"r":65537,"p":[{"n":"observedSense","p":262145}],"n":"FinishPhase","d":297928,"h":154619120584,"f":2},{"r":65537,"p":[{"n":"obj","p":131073}],"n":"InvokePostPhaseAction","d":297928,"h":158914087880,"f":34},{"r":65537,"p":[{"n":"observedSense","p":262145}],"n":"SetResetEvents","d":297928,"h":163209055176,"f":2},{"r":65537,"p":[{"n":"currentPhaseEvent","p":128385025},{"n":"observedPhase","p":917505}],"n":"WaitCurrentPhase","d":297928,"h":167504022472,"f":2},{"r":262145,"p":[{"n":"currentPhaseEvent","p":128385025},{"n":"totalTimeout","p":655361},{"n":"token","p":125960193},{"n":"observedPhase","p":917505}],"n":"DiscontinuousWait","d":297928,"h":171798989768,"f":2,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]}]},{"r":65537,"n":"Dispose","d":297928,"h":176093957064,"f":1},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":297928,"h":180388924360,"f":132}],"l":[{"t":655361,"n":"_currentTotalCount","d":297928,"h":4295265224,"f":2},{"t":655361,"n":"CURRENT_MASK","d":297928,"h":8590232520,"f":34},{"t":655361,"n":"TOTAL_MASK","d":297928,"h":12885199816,"f":34},{"t":655361,"n":"SENSE_MASK","d":297928,"h":17180167112,"f":34},{"t":655361,"n":"MAX_PARTICIPANTS","d":297928,"h":21475134408,"f":34},{"t":917505,"n":"_currentPhase","d":297928,"h":25770101704,"f":2},{"t":262145,"n":"_disposed","d":297928,"h":30065069000,"f":2},{"t":128385025,"n":"_oddEvent","d":297928,"h":34360036296,"f":2},{"t":128385025,"n":"_evenEvent","d":297928,"h":38655003592,"f":2},{"t":126943233,"n":"_ownerThreadContext","d":297928,"h":42949970888,"f":2},{"t":126615553,"n":"s_invokePostPhaseAction","d":297928,"h":47244938184,"f":34},{"t":$.$spc.System.Action$$($.$st.System.Threading.Barrier).$h,"n":"_postPhaseAction","d":297928,"h":51539905480,"f":2},{"t":47251457,"n":"_exception","d":297928,"h":55834872776,"f":2},{"t":655361,"n":"_actionCallerID","d":297928,"h":60129840072,"f":2}],"c":[{"p":[{"n":"participantCount","p":655361}],"n":".ctor","o":"$ctor$1","d":297928,"h":94489578440,"f":1},{"p":[{"n":"participantCount","p":655361},{"n":"postPhaseAction","p":$.$spc.System.Action$$($.$st.System.Threading.Barrier).$h}],"n":".ctor","o":"$ctor$2","d":297928,"h":98784545736,"f":1}],"i":[57540609],"h":297928,"a":[{"t":37617665,"c":8627552257,"a":[{"v":"ParticipantCount = {ParticipantCount}, ParticipantsRemaining = {ParticipantsRemaining}","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Threading.Barrier`; }
        });
        
        $asm.$cls("$st.System.Threading.ReaderWriterLock", ($self) => class ReaderWriterLock extends $.$spc.System.Runtime.ConstrainedExecution.CriticalFinalizerObject
        {
            /*int*/ static InvalidThreadID = -1;
            /*ushort*/ static MaxAcquireCount = 65535;
            /*int*/ static DefaultSpinCount = 0;
            /*int*/ static IncorrectButCompatibleNotOwnerExceptionHResult = 288;
            /*long*/ static s_mostRecentLockID = 0n;
            /*ManualResetEventSlim?*/ _readerEvent = null;
            /*AutoResetEvent?*/ _writerEvent = null;
            /*long*/ _lockID = 0n;
            /*int*/ _state = 0;
            /*int*/ _writerID = -1;
            /*int*/ _writerSeqNum = 1;
            /*ushort*/ _writerLevel = 0;
            $ctor$2()
            {
                super.$ctor$1();
                {
                    this._lockID = $.$spc.System.Threading.Interlocked.Increment$1($.$ref(() => $.$st.System.Threading.ReaderWriterLock.s_mostRecentLockID, ($v) => $.$st.System.Threading.ReaderWriterLock.s_mostRecentLockID = $v, $.$spc.System.Int64));
                }
                return this;
            }
            /*bool */ get IsReaderLockHeld()
            {
                /*ThreadLocalLockEntry?*/ let threadLocalLockEntry = $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.GetCurrent(this._lockID);
                if (threadLocalLockEntry !== null)
                {
                    return threadLocalLockEntry._readerLevel > 0;
                }
                return false;
            }
            /*bool */ get IsWriterLockHeld()
            {
                return this._writerID === $.$st.System.Threading.ReaderWriterLock.GetCurrentThreadID();
            }
            /*int */ get WriterSeqNum()
            {
                return this._writerSeqNum;
            }
            /*bool */ AnyWritersSince(/*int*/ seqNum)
            {
                if (this._writerID === $.$st.System.Threading.ReaderWriterLock.GetCurrentThreadID())
                {
                    ++seqNum;
                }
                return (this._writerSeqNum >>> 0) > (seqNum >>> 0);
            }
            /*void */ AcquireReaderLock(/*int*/ millisecondsTimeout)
            {
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfLessThan($.$spc.System.Int32, millisecondsTimeout, -1, "millisecondsTimeout");
                /*ThreadLocalLockEntry*/ let threadLocalLockEntry = $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.GetOrCreateCurrent(this._lockID);
                if ($.$spc.System.Threading.Interlocked.CompareExchange($.$ref(() => this._state, ($v) => this._state = $v, $.$spc.System.Int32), 1/*LockStates.Reader*/, 0) === 0)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(threadLocalLockEntry._readerLevel === 0, "threadLocalLockEntry._readerLevel == 0");
                }
                else if (threadLocalLockEntry._readerLevel > 0)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1((this._state & 1023/*LockStates.ReadersMask*/) !== 0, "(_state & LockStates.ReadersMask) != 0");
                    if (threadLocalLockEntry._readerLevel === 65535/*MaxAcquireCount*/)
                    {
                        throw new $.$spc.System.OverflowException().$ctor$14($.$st.System.SR.Overflow_UInt16);
                    }
                    ++threadLocalLockEntry._readerLevel;
                    return;
                }
                else if (this._writerID === $.$st.System.Threading.ReaderWriterLock.GetCurrentThreadID())
                {
                    this.AcquireWriterLock(millisecondsTimeout);
                    $.$spc.System.Diagnostics.Debug.Assert$1(threadLocalLockEntry.IsFree, "threadLocalLockEntry.IsFree");
                    return;
                }
                else 
                {
                    /*int*/ let spinCount = 0;
                    /*int*/ let currentState = this._state;
                    do
                    {
                        /*int*/ let knownState = currentState;
                        if (knownState < 1023/*LockStates.ReadersMask*/ || ((knownState & 1024/*LockStates.ReaderSignaled*/) !== 0 && (knownState & 4096/*LockStates.Writer*/) === 0 && (((((knownState & 1023/*LockStates.ReadersMask*/) + ((knownState & 8380416/*LockStates.WaitingReadersMask*/) >> 13/*LockStates.WaitingReadersShift*/)) | 0)) <= ((1023/*LockStates.ReadersMask*/ - 2) | 0))))
                        {
                            currentState = $.$spc.System.Threading.Interlocked.CompareExchange($.$ref(() => this._state, ($v) => this._state = $v, $.$spc.System.Int32), ((knownState + 1/*LockStates.Reader*/) | 0), knownState);
                            if (currentState === knownState)
                            {
                                break;
                            }
                            continue;
                        }
                        if ((knownState & 1023/*LockStates.ReadersMask*/) === 1023/*LockStates.ReadersMask*/ || (knownState & 8380416/*LockStates.WaitingReadersMask*/) === 8380416/*LockStates.WaitingReadersMask*/ || (knownState & 3072/*LockStates.CachingEvents*/) === 1024/*LockStates.ReaderSignaled*/)
                        {
                            /*int*/ let sleepDurationMilliseconds = 100;
                            if ((knownState & 1023/*LockStates.ReadersMask*/) === 1023/*LockStates.ReadersMask*/ || (knownState & 8380416/*LockStates.WaitingReadersMask*/) === 8380416/*LockStates.WaitingReadersMask*/)
                            {
                                sleepDurationMilliseconds = 1000;
                            }
                            $.$spc.System.Threading.Thread.Sleep(sleepDurationMilliseconds);
                            spinCount = 0;
                            currentState = this._state;
                            continue;
                        }
                        ++spinCount;
                        if ((knownState & 3072/*LockStates.CachingEvents*/) === 3072/*LockStates.CachingEvents*/)
                        {
                            if (spinCount > $.$st.System.Threading.ReaderWriterLock.DefaultSpinCount)
                            {
                                $.$spc.System.Threading.Thread.Sleep(1);
                                spinCount = 0;
                            }
                            currentState = this._state;
                            continue;
                        }
                        if (spinCount <= $.$st.System.Threading.ReaderWriterLock.DefaultSpinCount)
                        {
                            currentState = this._state;
                            continue;
                        }
                        currentState = $.$spc.System.Threading.Interlocked.CompareExchange($.$ref(() => this._state, ($v) => this._state = $v, $.$spc.System.Int32), ((knownState + 8192/*LockStates.WaitingReader*/) | 0), knownState);
                        if (currentState !== knownState)
                        {
                            continue;
                        }
                        /*int*/ let modifyState = -8192/*LockStates.WaitingReader*/;
                        /*ManualResetEventSlim?*/ let readerEvent = null;
                        /*bool*/ let waitSucceeded = false;
                        try
                        {
                            readerEvent = this.GetOrCreateReaderEvent();
                            waitSucceeded = readerEvent.Wait$4(millisecondsTimeout);
                            $.$spc.System.Diagnostics.Debug.Assert$1(threadLocalLockEntry.HasLockID(this._lockID), "threadLocalLockEntry.HasLockID(_lockID)");
                            if (waitSucceeded)
                            {
                                $.$spc.System.Diagnostics.Debug.Assert$1((this._state & 1024/*LockStates.ReaderSignaled*/) !== 0, "(_state & LockStates.ReaderSignaled) != 0");
                                $.$spc.System.Diagnostics.Debug.Assert$1((this._state & 1023/*LockStates.ReadersMask*/) < 1023/*LockStates.ReadersMask*/, "(_state & LockStates.ReadersMask) < LockStates.ReadersMask");
                                modifyState += 1/*LockStates.Reader*/;
                            }
                        }
                        finally
                        {
                            {
                                knownState = (($.$spc.System.Threading.Interlocked.Add($.$ref(() => this._state, ($v) => this._state = $v, $.$spc.System.Int32), modifyState) - modifyState) | 0);
                                if (!waitSucceeded)
                                {
                                    if ((knownState & 1024/*LockStates.ReaderSignaled*/) !== 0 && (knownState & 8380416/*LockStates.WaitingReadersMask*/) === 8192/*LockStates.WaitingReader*/)
                                    {
                                        if (readerEvent === null)
                                        {
                                            readerEvent = this._readerEvent;
                                            $.$spc.System.Diagnostics.Debug.Assert$1(readerEvent !== null, "readerEvent != null");
                                        }
                                        readerEvent.Wait();
                                        $.$spc.System.Diagnostics.Debug.Assert$1((this._state & 1023/*LockStates.ReadersMask*/) < 1023/*LockStates.ReadersMask*/, "(_state & LockStates.ReadersMask) < LockStates.ReadersMask");
                                        readerEvent.Reset();
                                        $.$spc.System.Threading.Interlocked.Add($.$ref(() => this._state, ($v) => this._state = $v, $.$spc.System.Int32), ((1/*LockStates.Reader*/ - 1024/*LockStates.ReaderSignaled*/) | 0));
                                        ++threadLocalLockEntry._readerLevel;
                                        this.ReleaseReaderLock();
                                    }
                                    $.$spc.System.Diagnostics.Debug.Assert$1(threadLocalLockEntry.IsFree, "threadLocalLockEntry.IsFree");
                                }
                            }
                        }
                        if (!waitSucceeded)
                        {
                            throw $.$st.System.Threading.ReaderWriterLock.GetTimeoutException();
                        }
                        $.$spc.System.Diagnostics.Debug.Assert$1((knownState & 1024/*LockStates.ReaderSignaled*/) !== 0, "(knownState & LockStates.ReaderSignaled) != 0");
                        $.$spc.System.Diagnostics.Debug.Assert$1((knownState & 1023/*LockStates.ReadersMask*/) < 1023/*LockStates.ReadersMask*/, "(knownState & LockStates.ReadersMask) < LockStates.ReadersMask");
                        if ((knownState & 8380416/*LockStates.WaitingReadersMask*/) === 8192/*LockStates.WaitingReader*/)
                        {
                            readerEvent.Reset();
                            $.$spc.System.Threading.Interlocked.Add($.$ref(() => this._state, ($v) => this._state = $v, $.$spc.System.Int32), -1024/*LockStates.ReaderSignaled*/);
                        }
                        break;
                    }
                    while($.$st.System.Threading.ReaderWriterLock.YieldProcessor());
                }
                $.$spc.System.Diagnostics.Debug.Assert$1((this._state & 4096/*LockStates.Writer*/) === 0, "(_state & LockStates.Writer) == 0");
                $.$spc.System.Diagnostics.Debug.Assert$1((this._state & 1023/*LockStates.ReadersMask*/) !== 0, "(_state & LockStates.ReadersMask) != 0");
                ++threadLocalLockEntry._readerLevel;
            }
            /*void */ AcquireReaderLock$1(/*TimeSpan*/ timeout)
            {
                return this.AcquireReaderLock($.$st.System.Threading.ReaderWriterLock.ToTimeoutMilliseconds(timeout));
            }
            /*void */ AcquireWriterLock(/*int*/ millisecondsTimeout)
            {
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfLessThan($.$spc.System.Int32, millisecondsTimeout, -1, "millisecondsTimeout");
                /*int*/ let threadID = $.$st.System.Threading.ReaderWriterLock.GetCurrentThreadID();
                if ($.$spc.System.Threading.Interlocked.CompareExchange($.$ref(() => this._state, ($v) => this._state = $v, $.$spc.System.Int32), 4096/*LockStates.Writer*/, 0) === 0)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1((this._state & 1023/*LockStates.ReadersMask*/) === 0, "(_state & LockStates.ReadersMask) == 0");
                }
                else if (this._writerID === threadID)
                {
                    if (this._writerLevel === 65535/*MaxAcquireCount*/)
                    {
                        throw new $.$spc.System.OverflowException().$ctor$14($.$st.System.SR.Overflow_UInt16);
                    }
                    ++this._writerLevel;
                    return;
                }
                else 
                {
                    /*int*/ let spinCount = 0;
                    /*int*/ let currentState = this._state;
                    do
                    {
                        /*int*/ let knownState = currentState;
                        if (knownState === 0 || knownState === 3072/*LockStates.CachingEvents*/)
                        {
                            currentState = $.$spc.System.Threading.Interlocked.CompareExchange($.$ref(() => this._state, ($v) => this._state = $v, $.$spc.System.Int32), ((knownState + 4096/*LockStates.Writer*/) | 0), knownState);
                            if (currentState === knownState)
                            {
                                break;
                            }
                            continue;
                        }
                        if ((knownState & -8388608/*LockStates.WaitingWritersMask*/) === -8388608/*LockStates.WaitingWritersMask*/)
                        {
                            $.$spc.System.Threading.Thread.Sleep(1000);
                            spinCount = 0;
                            currentState = this._state;
                            continue;
                        }
                        ++spinCount;
                        if ((knownState & 3072/*LockStates.CachingEvents*/) === 3072/*LockStates.CachingEvents*/)
                        {
                            if (spinCount > $.$st.System.Threading.ReaderWriterLock.DefaultSpinCount)
                            {
                                $.$spc.System.Threading.Thread.Sleep(1);
                                spinCount = 0;
                            }
                            currentState = this._state;
                            continue;
                        }
                        if (spinCount <= $.$st.System.Threading.ReaderWriterLock.DefaultSpinCount)
                        {
                            currentState = this._state;
                            continue;
                        }
                        currentState = $.$spc.System.Threading.Interlocked.CompareExchange($.$ref(() => this._state, ($v) => this._state = $v, $.$spc.System.Int32), ((knownState + 8388608/*LockStates.WaitingWriter*/) | 0), knownState);
                        if (currentState !== knownState)
                        {
                            continue;
                        }
                        /*int*/ let modifyState = -8388608/*LockStates.WaitingWriter*/;
                        /*AutoResetEvent?*/ let writerEvent = null;
                        /*bool*/ let waitSucceeded = false;
                        try
                        {
                            writerEvent = this.GetOrCreateWriterEvent();
                            waitSucceeded = writerEvent.WaitOne(millisecondsTimeout);
                            if (waitSucceeded)
                            {
                                $.$spc.System.Diagnostics.Debug.Assert$1((this._state & 2048/*LockStates.WriterSignaled*/) !== 0, "(_state & LockStates.WriterSignaled) != 0");
                                modifyState += ((4096/*LockStates.Writer*/ - 2048/*LockStates.WriterSignaled*/) | 0);
                            }
                        }
                        finally
                        {
                            {
                                knownState = (($.$spc.System.Threading.Interlocked.Add($.$ref(() => this._state, ($v) => this._state = $v, $.$spc.System.Int32), modifyState) - modifyState) | 0);
                                if (!waitSucceeded && (knownState & 2048/*LockStates.WriterSignaled*/) !== 0 && (knownState & -8388608/*LockStates.WaitingWritersMask*/) === 8388608/*LockStates.WaitingWriter*/)
                                {
                                    if (writerEvent === null)
                                    {
                                        writerEvent = this._writerEvent;
                                        $.$spc.System.Diagnostics.Debug.Assert$1(writerEvent !== null, "writerEvent != null");
                                    }
                                    while(true)
                                    {
                                        knownState = this._state;
                                        if ((knownState & 2048/*LockStates.WriterSignaled*/) === 0 || (knownState & -8388608/*LockStates.WaitingWritersMask*/) !== 0)
                                        {
                                            break;
                                        }
                                        if (!writerEvent.WaitOne(10))
                                        {
                                            continue;
                                        }
                                        modifyState = ((4096/*LockStates.Writer*/ - 2048/*LockStates.WriterSignaled*/) | 0);
                                        knownState = (($.$spc.System.Threading.Interlocked.Add($.$ref(() => this._state, ($v) => this._state = $v, $.$spc.System.Int32), modifyState) - modifyState) | 0);
                                        $.$spc.System.Diagnostics.Debug.Assert$1((knownState & 2048/*LockStates.WriterSignaled*/) !== 0, "(knownState & LockStates.WriterSignaled) != 0");
                                        $.$spc.System.Diagnostics.Debug.Assert$1((knownState & 4096/*LockStates.Writer*/) === 0, "(knownState & LockStates.Writer) == 0");
                                        this._writerID = threadID;
                                        $.$spc.System.Diagnostics.Debug.Assert$1(this._writerLevel === 0, "_writerLevel == 0");
                                        this._writerLevel = 1;
                                        this.ReleaseWriterLock();
                                        break;
                                    }
                                }
                            }
                        }
                        if (!waitSucceeded)
                        {
                            throw $.$st.System.Threading.ReaderWriterLock.GetTimeoutException();
                        }
                        break;
                    }
                    while($.$st.System.Threading.ReaderWriterLock.YieldProcessor());
                }
                $.$spc.System.Diagnostics.Debug.Assert$1((this._state & 4096/*LockStates.Writer*/) !== 0, "(_state & LockStates.Writer) != 0");
                $.$spc.System.Diagnostics.Debug.Assert$1((this._state & 1023/*LockStates.ReadersMask*/) === 0, "(_state & LockStates.ReadersMask) == 0");
                $.$spc.System.Diagnostics.Debug.Assert$1(this._writerID === -1/*InvalidThreadID*/, "_writerID == InvalidThreadID");
                this._writerID = threadID;
                this._writerLevel = 1;
                ++this._writerSeqNum;
                return;
            }
            /*void */ AcquireWriterLock$1(/*TimeSpan*/ timeout)
            {
                return this.AcquireWriterLock($.$st.System.Threading.ReaderWriterLock.ToTimeoutMilliseconds(timeout));
            }
            /*void */ ReleaseReaderLock()
            {
                if (this._writerID === $.$st.System.Threading.ReaderWriterLock.GetCurrentThreadID())
                {
                    this.ReleaseWriterLock();
                    return;
                }
                /*ThreadLocalLockEntry?*/ let threadLocalLockEntry = $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.GetCurrent(this._lockID);
                if (threadLocalLockEntry === null)
                {
                    throw $.$st.System.Threading.ReaderWriterLock.GetNotOwnerException();
                }
                $.$spc.System.Diagnostics.Debug.Assert$1((this._state & 4096/*LockStates.Writer*/) === 0, "(_state & LockStates.Writer) == 0");
                $.$spc.System.Diagnostics.Debug.Assert$1((this._state & 1023/*LockStates.ReadersMask*/) !== 0, "(_state & LockStates.ReadersMask) != 0");
                $.$spc.System.Diagnostics.Debug.Assert$1(threadLocalLockEntry._readerLevel > 0, "threadLocalLockEntry._readerLevel > 0");
                --threadLocalLockEntry._readerLevel;
                if (threadLocalLockEntry._readerLevel > 0)
                {
                    return;
                }
                /*bool*/ let isLastReader;
                /*bool*/ let cacheEvents;
                /*AutoResetEvent?*/ let writerEvent = null;
                /*ManualResetEventSlim?*/ let readerEvent = null;
                /*int*/ let currentState = this._state;
                /*int*/ let knownState;
                do
                {
                    isLastReader = false;
                    cacheEvents = false;
                    knownState = currentState;
                    /*int*/ let modifyState = -1/*LockStates.Reader*/;
                    if ((knownState & (1023/*LockStates.ReadersMask*/ | 1024/*LockStates.ReaderSignaled*/)) === 1/*LockStates.Reader*/)
                    {
                        isLastReader = true;
                        if ((knownState & -8388608/*LockStates.WaitingWritersMask*/) !== 0)
                        {
                            writerEvent = this.TryGetOrCreateWriterEvent();
                            if (writerEvent === null)
                            {
                                $.$spc.System.Threading.Thread.Sleep(100);
                                currentState = this._state;
                                knownState = 0;
                                $.$spc.System.Diagnostics.Debug.Assert$1(currentState !== knownState, "currentState != knownState");
                                continue;
                            }
                            modifyState += 2048/*LockStates.WriterSignaled*/;
                        }
                        else if ((knownState & 8380416/*LockStates.WaitingReadersMask*/) !== 0)
                        {
                            readerEvent = this.TryGetOrCreateReaderEvent();
                            if (readerEvent === null)
                            {
                                $.$spc.System.Threading.Thread.Sleep(100);
                                currentState = this._state;
                                knownState = 0;
                                $.$spc.System.Diagnostics.Debug.Assert$1(currentState !== knownState, "currentState != knownState");
                                continue;
                            }
                            modifyState += 1024/*LockStates.ReaderSignaled*/;
                        }
                        else if (knownState === 1/*LockStates.Reader*/ && (this._readerEvent !== null || this._writerEvent !== null))
                        {
                            cacheEvents = true;
                            modifyState += 3072/*LockStates.CachingEvents*/;
                        }
                    }
                    $.$spc.System.Diagnostics.Debug.Assert$1((knownState & 4096/*LockStates.Writer*/) === 0, "(knownState & LockStates.Writer) == 0");
                    $.$spc.System.Diagnostics.Debug.Assert$1((knownState & 1023/*LockStates.ReadersMask*/) !== 0, "(knownState & LockStates.ReadersMask) != 0");
                    currentState = $.$spc.System.Threading.Interlocked.CompareExchange($.$ref(() => this._state, ($v) => this._state = $v, $.$spc.System.Int32), ((knownState + modifyState) | 0), knownState);
                }
                while(currentState !== knownState);
                if (isLastReader)
                {
                    if ((knownState & -8388608/*LockStates.WaitingWritersMask*/) !== 0)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1((this._state & 2048/*LockStates.WriterSignaled*/) !== 0, "(_state & LockStates.WriterSignaled) != 0");
                        $.$spc.System.Diagnostics.Debug.Assert$1(writerEvent !== null, "writerEvent != null");
                        writerEvent.Set$1();
                    }
                    else if ((knownState & 8380416/*LockStates.WaitingReadersMask*/) !== 0)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1((this._state & 1024/*LockStates.ReaderSignaled*/) !== 0, "(_state & LockStates.ReaderSignaled) != 0");
                        $.$spc.System.Diagnostics.Debug.Assert$1(readerEvent !== null, "readerEvent != null");
                        readerEvent.Set$1();
                    }
                    else if (cacheEvents)
                    {
                        this.ReleaseEvents();
                    }
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(threadLocalLockEntry.IsFree, "threadLocalLockEntry.IsFree");
            }
            /*void */ ReleaseWriterLock()
            {
                if (this._writerID !== $.$st.System.Threading.ReaderWriterLock.GetCurrentThreadID())
                {
                    throw $.$st.System.Threading.ReaderWriterLock.GetNotOwnerException();
                }
                $.$spc.System.Diagnostics.Debug.Assert$1((this._state & 1023/*LockStates.ReadersMask*/) === 0, "(_state & LockStates.ReadersMask) == 0");
                $.$spc.System.Diagnostics.Debug.Assert$1((this._state & 4096/*LockStates.Writer*/) !== 0, "(_state & LockStates.Writer) != 0");
                $.$spc.System.Diagnostics.Debug.Assert$1(this._writerLevel > 0, "_writerLevel > 0");
                --this._writerLevel;
                if (this._writerLevel > 0)
                {
                    return;
                }
                this._writerID = -1/*InvalidThreadID*/;
                /*bool*/ let cacheEvents;
                /*ManualResetEventSlim?*/ let readerEvent = null;
                /*AutoResetEvent?*/ let writerEvent = null;
                /*int*/ let currentState = this._state;
                /*int*/ let knownState;
                do
                {
                    cacheEvents = false;
                    knownState = currentState;
                    /*int*/ let modifyState = -4096/*LockStates.Writer*/;
                    if ((knownState & 8380416/*LockStates.WaitingReadersMask*/) !== 0)
                    {
                        readerEvent = this.TryGetOrCreateReaderEvent();
                        if (readerEvent === null)
                        {
                            $.$spc.System.Threading.Thread.Sleep(100);
                            currentState = this._state;
                            knownState = 0;
                            $.$spc.System.Diagnostics.Debug.Assert$1(currentState !== knownState, "currentState != knownState");
                            continue;
                        }
                        modifyState += 1024/*LockStates.ReaderSignaled*/;
                    }
                    else if ((knownState & -8388608/*LockStates.WaitingWritersMask*/) !== 0)
                    {
                        writerEvent = this.TryGetOrCreateWriterEvent();
                        if (writerEvent === null)
                        {
                            $.$spc.System.Threading.Thread.Sleep(100);
                            currentState = this._state;
                            knownState = 0;
                            $.$spc.System.Diagnostics.Debug.Assert$1(currentState !== knownState, "currentState != knownState");
                            continue;
                        }
                        modifyState += 2048/*LockStates.WriterSignaled*/;
                    }
                    else if (knownState === 4096/*LockStates.Writer*/ && (this._readerEvent !== null || this._writerEvent !== null))
                    {
                        cacheEvents = true;
                        modifyState += 3072/*LockStates.CachingEvents*/;
                    }
                    $.$spc.System.Diagnostics.Debug.Assert$1((knownState & 1023/*LockStates.ReadersMask*/) === 0, "(knownState & LockStates.ReadersMask) == 0");
                    $.$spc.System.Diagnostics.Debug.Assert$1((knownState & 4096/*LockStates.Writer*/) !== 0, "(knownState & LockStates.Writer) != 0");
                    currentState = $.$spc.System.Threading.Interlocked.CompareExchange($.$ref(() => this._state, ($v) => this._state = $v, $.$spc.System.Int32), ((knownState + modifyState) | 0), knownState);
                }
                while(currentState !== knownState);
                if ((knownState & 8380416/*LockStates.WaitingReadersMask*/) !== 0)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1((this._state & 1024/*LockStates.ReaderSignaled*/) !== 0, "(_state & LockStates.ReaderSignaled) != 0");
                    $.$spc.System.Diagnostics.Debug.Assert$1(readerEvent !== null, "readerEvent != null");
                    readerEvent.Set$1();
                }
                else if ((knownState & -8388608/*LockStates.WaitingWritersMask*/) !== 0)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1((this._state & 2048/*LockStates.WriterSignaled*/) !== 0, "(_state & LockStates.WriterSignaled) != 0");
                    $.$spc.System.Diagnostics.Debug.Assert$1(writerEvent !== null, "writerEvent != null");
                    writerEvent.Set$1();
                }
                else if (cacheEvents)
                {
                    this.ReleaseEvents();
                }
            }
            /*LockCookie */ UpgradeToWriterLock(/*int*/ millisecondsTimeout)
            {
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfLessThan($.$spc.System.Int32, millisecondsTimeout, -1, "millisecondsTimeout");
                /*LockCookie*/ let lockCookie = new $.$st.System.Threading.LockCookie();
                /*int*/ let threadID = $.$st.System.Threading.ReaderWriterLock.GetCurrentThreadID();
                lockCookie._threadID = threadID;
                if (this._writerID === threadID)
                {
                    lockCookie._flags = 8192/*LockCookieFlags.Upgrade*/ | 131072/*LockCookieFlags.OwnedWriter*/;
                    lockCookie._writerLevel = this._writerLevel;
                    this.AcquireWriterLock(millisecondsTimeout);
                    return lockCookie;
                }
                /*ThreadLocalLockEntry?*/ let threadLocalLockEntry = $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.GetCurrent(this._lockID);
                if (threadLocalLockEntry === null)
                {
                    lockCookie._flags = 8192/*LockCookieFlags.Upgrade*/ | 65536/*LockCookieFlags.OwnedNone*/;
                }
                else 
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1((this._state & 1023/*LockStates.ReadersMask*/) !== 0, "(_state & LockStates.ReadersMask) != 0");
                    $.$spc.System.Diagnostics.Debug.Assert$1(threadLocalLockEntry._readerLevel > 0, "threadLocalLockEntry._readerLevel > 0");
                    lockCookie._flags = 8192/*LockCookieFlags.Upgrade*/ | 262144/*LockCookieFlags.OwnedReader*/;
                    lockCookie._readerLevel = threadLocalLockEntry._readerLevel;
                    /*int*/ let knownState = $.$spc.System.Threading.Interlocked.CompareExchange($.$ref(() => this._state, ($v) => this._state = $v, $.$spc.System.Int32), 4096/*LockStates.Writer*/, 1/*LockStates.Reader*/);
                    if (knownState === 1/*LockStates.Reader*/)
                    {
                        threadLocalLockEntry._readerLevel = 0;
                        $.$spc.System.Diagnostics.Debug.Assert$1(threadLocalLockEntry.IsFree, "threadLocalLockEntry.IsFree");
                        this._writerID = threadID;
                        this._writerLevel = 1;
                        ++this._writerSeqNum;
                        return lockCookie;
                    }
                    threadLocalLockEntry._readerLevel = 1;
                    this.ReleaseReaderLock();
                }
                /*bool*/ let acquired = false;
                try
                {
                    this.AcquireWriterLock(millisecondsTimeout);
                    acquired = true;
                    return lockCookie;
                }
                finally
                {
                    {
                        if (!acquired)
                        {
                            /*LockCookieFlags*/ let flags = lockCookie._flags;
                            lockCookie._flags = -483329/*LockCookieFlags.Invalid*/;
                            this.RecoverLock($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$st.System.Threading.LockCookie, () => lockCookie, ($v) => lockCookie = $v, null), flags & 262144/*LockCookieFlags.OwnedReader*/);
                        }
                    }
                }
            }
            /*LockCookie */ UpgradeToWriterLock$1(/*TimeSpan*/ timeout)
            {
                return this.UpgradeToWriterLock($.$st.System.Threading.ReaderWriterLock.ToTimeoutMilliseconds(timeout));
            }
            /*void */ DowngradeFromWriterLock(/*ref LockCookie*/ lockCookie)
            {
                /*int*/ let threadID = $.$st.System.Threading.ReaderWriterLock.GetCurrentThreadID();
                if (this._writerID !== threadID)
                {
                    throw $.$st.System.Threading.ReaderWriterLock.GetNotOwnerException();
                }
                /*LockCookieFlags*/ let flags = lockCookie.$v._flags;
                /*ushort*/ let requestedWriterLevel = lockCookie.$v._writerLevel;
                if ((flags & -483329/*LockCookieFlags.Invalid*/) !== 0 || lockCookie.$v._threadID !== threadID || ((flags & (131072/*LockCookieFlags.OwnedWriter*/ | 65536/*LockCookieFlags.OwnedNone*/)) !== 0 && this._writerLevel <= requestedWriterLevel))
                {
                    throw $.$st.System.Threading.ReaderWriterLock.GetInvalidLockCookieException();
                }
                if ((flags & 262144/*LockCookieFlags.OwnedReader*/) !== 0)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._writerLevel > 0, "_writerLevel > 0");
                    /*ThreadLocalLockEntry*/ let threadLocalLockEntry = $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.GetOrCreateCurrent(this._lockID);
                    this._writerID = -1/*InvalidThreadID*/;
                    this._writerLevel = 0;
                    /*ManualResetEventSlim?*/ let readerEvent = null;
                    /*int*/ let currentState = this._state;
                    /*int*/ let knownState;
                    do
                    {
                        knownState = currentState;
                        /*int*/ let modifyState = ((1/*LockStates.Reader*/ - 4096/*LockStates.Writer*/) | 0);
                        if ((knownState & 8380416/*LockStates.WaitingReadersMask*/) !== 0)
                        {
                            readerEvent = this.TryGetOrCreateReaderEvent();
                            if (readerEvent === null)
                            {
                                $.$spc.System.Threading.Thread.Sleep(100);
                                currentState = this._state;
                                knownState = 0;
                                $.$spc.System.Diagnostics.Debug.Assert$1(currentState !== knownState, "currentState != knownState");
                                continue;
                            }
                            modifyState += 1024/*LockStates.ReaderSignaled*/;
                        }
                        $.$spc.System.Diagnostics.Debug.Assert$1((knownState & 1023/*LockStates.ReadersMask*/) === 0, "(knownState & LockStates.ReadersMask) == 0");
                        currentState = $.$spc.System.Threading.Interlocked.CompareExchange($.$ref(() => this._state, ($v) => this._state = $v, $.$spc.System.Int32), ((knownState + modifyState) | 0), knownState);
                    }
                    while(currentState !== knownState);
                    if ((knownState & 8380416/*LockStates.WaitingReadersMask*/) !== 0)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1((this._state & 1024/*LockStates.ReaderSignaled*/) !== 0, "(_state & LockStates.ReaderSignaled) != 0");
                        $.$spc.System.Diagnostics.Debug.Assert$1(readerEvent !== null, "readerEvent != null");
                        readerEvent.Set$1();
                    }
                    threadLocalLockEntry._readerLevel = lockCookie.$v._readerLevel;
                }
                else if ((flags & (131072/*LockCookieFlags.OwnedWriter*/ | 65536/*LockCookieFlags.OwnedNone*/)) !== 0)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._writerLevel > 0, "_writerLevel > 0");
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._writerLevel > requestedWriterLevel, "_writerLevel > requestedWriterLevel");
                    if (requestedWriterLevel > 0)
                    {
                        this._writerLevel = requestedWriterLevel;
                    }
                    else 
                    {
                        if (this._writerLevel !== 1)
                        {
                            this._writerLevel = 1;
                        }
                        this.ReleaseWriterLock();
                    }
                    $.$spc.System.Diagnostics.Debug.Assert$1((flags & 131072/*LockCookieFlags.OwnedWriter*/) !== 0 || this._writerID !== threadID, "(flags & LockCookieFlags.OwnedWriter) != 0 || _writerID != threadID");
                }
                lockCookie.$v._flags = -483329/*LockCookieFlags.Invalid*/;
            }
            /*LockCookie */ ReleaseLock()
            {
                /*LockCookie*/ let lockCookie = new $.$st.System.Threading.LockCookie();
                /*int*/ let threadID = $.$st.System.Threading.ReaderWriterLock.GetCurrentThreadID();
                lockCookie._threadID = threadID;
                if (this._writerID === threadID)
                {
                    lockCookie._flags = 16384/*LockCookieFlags.Release*/ | 131072/*LockCookieFlags.OwnedWriter*/;
                    lockCookie._writerLevel = this._writerLevel;
                    this._writerLevel = 1;
                    this.ReleaseWriterLock();
                    return lockCookie;
                }
                /*ThreadLocalLockEntry?*/ let threadLocalLockEntry = $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.GetCurrent(this._lockID);
                if (threadLocalLockEntry === null)
                {
                    lockCookie._flags = 16384/*LockCookieFlags.Release*/ | 65536/*LockCookieFlags.OwnedNone*/;
                    return lockCookie;
                }
                $.$spc.System.Diagnostics.Debug.Assert$1((this._state & 1023/*LockStates.ReadersMask*/) !== 0, "(_state & LockStates.ReadersMask) != 0");
                $.$spc.System.Diagnostics.Debug.Assert$1(threadLocalLockEntry._readerLevel > 0, "threadLocalLockEntry._readerLevel > 0");
                lockCookie._flags = 16384/*LockCookieFlags.Release*/ | 262144/*LockCookieFlags.OwnedReader*/;
                lockCookie._readerLevel = threadLocalLockEntry._readerLevel;
                threadLocalLockEntry._readerLevel = 1;
                this.ReleaseReaderLock();
                return lockCookie;
            }
            /*void */ RestoreLock(/*ref LockCookie*/ lockCookie)
            {
                /*int*/ let threadID = $.$st.System.Threading.ReaderWriterLock.GetCurrentThreadID();
                if (lockCookie.$v._threadID !== threadID)
                {
                    throw $.$st.System.Threading.ReaderWriterLock.GetInvalidLockCookieException();
                }
                if (this._writerID === threadID || $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.GetCurrent(this._lockID) !== null)
                {
                    throw new $.$spc.System.Threading.SynchronizationLockException().$ctor$10($.$st.System.SR.ReaderWriterLock_RestoreLockWithOwnedLocks);
                }
                /*LockCookieFlags*/ let flags = lockCookie.$v._flags;
                if ((flags & -483329/*LockCookieFlags.Invalid*/) !== 0)
                {
                    throw $.$st.System.Threading.ReaderWriterLock.GetInvalidLockCookieException();
                }
                do
                {
                    if ((flags & 65536/*LockCookieFlags.OwnedNone*/) !== 0)
                    {
                        break;
                    }
                    if ((flags & 131072/*LockCookieFlags.OwnedWriter*/) !== 0)
                    {
                        if ($.$spc.System.Threading.Interlocked.CompareExchange($.$ref(() => this._state, ($v) => this._state = $v, $.$spc.System.Int32), 4096/*LockStates.Writer*/, 0) === 0)
                        {
                            this._writerID = threadID;
                            this._writerLevel = lockCookie.$v._writerLevel;
                            ++this._writerSeqNum;
                            break;
                        }
                    }
                    else if ((flags & 262144/*LockCookieFlags.OwnedReader*/) !== 0)
                    {
                        /*ThreadLocalLockEntry*/ let threadLocalLockEntry = $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.GetOrCreateCurrent(this._lockID);
                        $.$spc.System.Diagnostics.Debug.Assert$1(threadLocalLockEntry.IsFree, "threadLocalLockEntry.IsFree");
                        /*int*/ let knownState = this._state;
                        if (knownState < 1023/*LockStates.ReadersMask*/ && $.$spc.System.Threading.Interlocked.CompareExchange($.$ref(() => this._state, ($v) => this._state = $v, $.$spc.System.Int32), ((knownState + 1/*LockStates.Reader*/) | 0), knownState) === knownState)
                        {
                            threadLocalLockEntry._readerLevel = lockCookie.$v._readerLevel;
                            break;
                        }
                    }
                    this.RecoverLock(lockCookie, flags);
                }
                while(false);
                lockCookie.$v._flags = -483329/*LockCookieFlags.Invalid*/;
            }
            /*void */ RecoverLock(/*ref LockCookie*/ lockCookie, /*LockCookieFlags*/ flags)
            {
                if ((flags & 131072/*LockCookieFlags.OwnedWriter*/) !== 0)
                {
                    this.AcquireWriterLock(-1/*Timeout.Infinite*/);
                    this._writerLevel = lockCookie.$v._writerLevel;
                }
                else if ((flags & 262144/*LockCookieFlags.OwnedReader*/) !== 0)
                {
                    this.AcquireReaderLock(-1/*Timeout.Infinite*/);
                    /*ThreadLocalLockEntry?*/ let threadLocalLockEntry = $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.GetCurrent(this._lockID);
                    $.$spc.System.Diagnostics.Debug.Assert$1(threadLocalLockEntry !== null, "threadLocalLockEntry != null");
                    threadLocalLockEntry._readerLevel = lockCookie.$v._readerLevel;
                }
            }
            static /*int */ GetCurrentThreadID()
            {
                /*int*/ let threadID = $.$spc.System.Environment.CurrentManagedThreadId;
                $.$spc.System.Diagnostics.Debug.Assert$1(threadID !== -1/*InvalidThreadID*/, "threadID != InvalidThreadID");
                return threadID;
            }
            static /*bool */ YieldProcessor()
            {
                $.$spc.System.Threading.Thread.SpinWait(1);
                return true;
            }
            /*ManualResetEventSlim */ GetOrCreateReaderEvent()
            {
                /*ManualResetEventSlim?*/ let currentEvent = this._readerEvent;
                if (currentEvent !== null)
                {
                    return currentEvent;
                }
                currentEvent = new $.$spc.System.Threading.ManualResetEventSlim().$ctor$3(false, 0);
                /*ManualResetEventSlim?*/ let previousEvent = $.$spc.System.Threading.Interlocked.CompareExchange$14($.$spc.System.Threading.ManualResetEventSlim, $.$ref(() => this._readerEvent, ($v) => this._readerEvent = $v, $.$spc.System.Threading.ManualResetEventSlim), currentEvent, null);
                if (previousEvent === null)
                {
                    return currentEvent;
                }
                currentEvent.Dispose();
                return previousEvent;
            }
            /*AutoResetEvent */ GetOrCreateWriterEvent()
            {
                /*AutoResetEvent?*/ let currentEvent = this._writerEvent;
                if (currentEvent !== null)
                {
                    return currentEvent;
                }
                currentEvent = new $.$spc.System.Threading.AutoResetEvent().$ctor$8(false);
                /*AutoResetEvent?*/ let previousEvent = $.$spc.System.Threading.Interlocked.CompareExchange$14($.$spc.System.Threading.AutoResetEvent, $.$ref(() => this._writerEvent, ($v) => this._writerEvent = $v, $.$spc.System.Threading.AutoResetEvent), currentEvent, null);
                if (previousEvent === null)
                {
                    return currentEvent;
                }
                currentEvent.Dispose$1();
                return previousEvent;
            }
            /*ManualResetEventSlim? */ TryGetOrCreateReaderEvent()
            {
                try
                {
                    return this.GetOrCreateReaderEvent();
                }
                catch($e)
                {
                    return null;
                }
            }
            /*AutoResetEvent? */ TryGetOrCreateWriterEvent()
            {
                try
                {
                    return this.GetOrCreateWriterEvent();
                }
                catch($e)
                {
                    return null;
                }
            }
            /*void */ ReleaseEvents()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1((this._state & 3072/*LockStates.CachingEvents*/) === 3072/*LockStates.CachingEvents*/, "(_state & LockStates.CachingEvents) == LockStates.CachingEvents");
                /*AutoResetEvent?*/ let writerEvent = this._writerEvent;
                this._writerEvent = null;
                /*ManualResetEventSlim?*/ let readerEvent = this._readerEvent;
                this._readerEvent = null;
                $.$spc.System.Threading.Interlocked.Add($.$ref(() => this._state, ($v) => this._state = $v, $.$spc.System.Int32), -3072/*LockStates.CachingEvents*/);
                writerEvent?.Dispose$1();
                readerEvent?.Dispose();
            }
            static /*int */ ToTimeoutMilliseconds(/*TimeSpan*/ timeout)
            {
                /*var*/ let timeoutMilliseconds = $.$cast(timeout.TotalMilliseconds, $.$spc.System.Int64);
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfLessThan($.$spc.System.Int64, timeoutMilliseconds, BigInt(-1), "timeout");
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$spc.System.Int64, timeoutMilliseconds, BigInt(2147483647/*int.MaxValue*/), "timeout");
                return $.$cast(timeoutMilliseconds, $.$spc.System.Int32);
            }
            static $_ReaderWriterLockApplicationException;
            static get ReaderWriterLockApplicationException()
            {
                let $cls = $.$st.System.Threading.ReaderWriterLock;
                return $cls.$_ReaderWriterLockApplicationException ??= $asm.$ncls("$st.System.Threading.ReaderWriterLock.ReaderWriterLockApplicationException", ($self) => class ReaderWriterLockApplicationException extends $.$spc.System.ApplicationException
                {
                    $ctor$9(/*int*/ errorHResult, /*string*/ message)
                    {
                        super.$ctor$6($.$st.System.SR.Format(message, $.$st.System.SR.Format($.$st.System.SR.ExceptionFromHResult, $.$box(errorHResult, $.$spc.System.Int32))));
                        {
                            this.HResult = errorHResult;
                        }
                        return this;
                    }
                    $ctor$10(/*SerializationInfo*/ info, /*StreamingContext*/ context)
                    {
                        super.$ctor$8(info, context);
                        {
                        }
                        return this;
                    }
                    static $h = 1018824;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":13303809,"d":887752,"h":1018824}; }
                    static get $b() { return $.$spc.System.ApplicationException; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
                    static get $fullName() { return `System.Threading.ReaderWriterLock.ReaderWriterLockApplicationException`; }
                }, $cls, ($v) => $cls.$_ReaderWriterLockApplicationException = $v);
            }
            static /*ReaderWriterLockApplicationException */ GetTimeoutException()
            {
                return new $.$st.System.Threading.ReaderWriterLock.ReaderWriterLockApplicationException().$ctor$9(-2147023436/*HResults.ERROR_TIMEOUT*/, $.$st.System.SR.ReaderWriterLock_Timeout);
            }
            static /*ReaderWriterLockApplicationException */ GetNotOwnerException()
            {
                return new $.$st.System.Threading.ReaderWriterLock.ReaderWriterLockApplicationException().$ctor$9(288/*IncorrectButCompatibleNotOwnerExceptionHResult*/, $.$st.System.SR.ReaderWriterLock_NotOwner);
            }
            static /*ReaderWriterLockApplicationException */ GetInvalidLockCookieException()
            {
                return new $.$st.System.Threading.ReaderWriterLock.ReaderWriterLockApplicationException().$ctor$9(-2147024809/*HResults.E_INVALIDARG*/, $.$st.System.SR.ReaderWriterLock_InvalidLockCookie);
            }
            static $_LockStates;
            static get LockStates()
            {
                let $cls = $.$st.System.Threading.ReaderWriterLock;
                return $cls.$_LockStates ??= $asm.$ncls("$st.System.Threading.ReaderWriterLock.LockStates", ($self) => class LockStates
                {
                    /*int*/ static Reader = 1;
                    /*int*/ static ReadersMask = 1023;
                    /*int*/ static ReaderSignaled = 1024;
                    /*int*/ static WriterSignaled = 2048;
                    /*int*/ static Writer = 4096;
                    /*int*/ static WaitingReader = 8192;
                    /*int*/ static WaitingReadersMask = 8380416;
                    /*int*/ static WaitingReadersShift = 13;
                    /*int*/ static WaitingWriter = 8388608;
                    /*int*/ static WaitingWritersMask = -8388608;
                    /*int*/ static CachingEvents = 3072;
                    static $h = 953288;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"Reader","d":953288,"h":4295920584,"f":33},{"t":655361,"n":"ReadersMask","d":953288,"h":8590887880,"f":33},{"t":655361,"n":"ReaderSignaled","d":953288,"h":12885855176,"f":33},{"t":655361,"n":"WriterSignaled","d":953288,"h":17180822472,"f":33},{"t":655361,"n":"Writer","d":953288,"h":21475789768,"f":33},{"t":655361,"n":"WaitingReader","d":953288,"h":25770757064,"f":33},{"t":655361,"n":"WaitingReadersMask","d":953288,"h":30065724360,"f":33},{"t":655361,"n":"WaitingReadersShift","d":953288,"h":34360691656,"f":33},{"t":655361,"n":"WaitingWriter","d":953288,"h":38655658952,"f":33},{"t":655361,"n":"WaitingWritersMask","d":953288,"h":42950626248,"f":33},{"t":655361,"n":"CachingEvents","d":953288,"h":47245593544,"f":33}],"d":887752,"h":953288}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Threading.ReaderWriterLock.LockStates`; }
                }, $cls, ($v) => $cls.$_LockStates = $v);
            }
            static $_ThreadLocalLockEntry;
            static get ThreadLocalLockEntry()
            {
                let $cls = $.$st.System.Threading.ReaderWriterLock;
                return $cls.$_ThreadLocalLockEntry ??= $asm.$ncls("$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry", ($self) => class ThreadLocalLockEntry extends $.$spc.System.Object
                {
                    /*ThreadLocalLockEntry?*/ static t_lockEntryHead = null;
                    /*long*/ _lockID = 0n;
                    /*ThreadLocalLockEntry?*/ _next = null;
                    /*ushort*/ _readerLevel = 0;
                    $ctor$1(/*long*/ lockID)
                    {
                        super.$ctor();
                        {
                            this._lockID = lockID;
                        }
                        return this;
                    }
                    /*bool */ HasLockID(/*long*/ lockID)
                    {
                        return this._lockID === lockID;
                    }
                    /*bool */ get IsFree()
                    {
                        return this._readerLevel === 0;
                    }
                    static /*void */ VerifyNoNonemptyEntryInListAfter(/*long*/ lockID, /*ThreadLocalLockEntry*/ afterEntry)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(lockID !== 0n, "lockID != 0");
                        $.$spc.System.Diagnostics.Debug.Assert$1(afterEntry !== null, "afterEntry != null");
                        for(/*ThreadLocalLockEntry?*/ let currentEntry = afterEntry._next; currentEntry !== null; currentEntry = currentEntry._next)
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(currentEntry._lockID !== lockID || currentEntry.IsFree, "currentEntry._lockID != lockID || currentEntry.IsFree");
                        }
                    }
                    static /*ThreadLocalLockEntry? */ GetCurrent(/*long*/ lockID)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(lockID !== 0n, "lockID != 0");
                        /*ThreadLocalLockEntry?*/ let headEntry = $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.t_lockEntryHead;
                        for(/*ThreadLocalLockEntry?*/ let currentEntry = headEntry; currentEntry !== null; currentEntry = currentEntry._next)
                        {
                            if (currentEntry._lockID === lockID)
                            {
                                $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.VerifyNoNonemptyEntryInListAfter(lockID, currentEntry);
                                return currentEntry.IsFree ? null : currentEntry;
                            }
                        }
                        return null;
                    }
                    static /*ThreadLocalLockEntry */ GetOrCreateCurrent(/*long*/ lockID)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(lockID !== 0n, "lockID != 0");
                        /*ThreadLocalLockEntry?*/ let headEntry = $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.t_lockEntryHead;
                        if (headEntry !== null && headEntry._lockID === lockID)
                        {
                            $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.VerifyNoNonemptyEntryInListAfter(lockID, headEntry);
                            return headEntry;
                        }
                        return $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.GetOrCreateCurrentSlow(lockID, headEntry);
                    }
                    static /*ThreadLocalLockEntry */ GetOrCreateCurrentSlow(/*long*/ lockID, /*ThreadLocalLockEntry?*/ headEntry)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(lockID !== 0n, "lockID != 0");
                        $.$spc.System.Diagnostics.Debug.Assert$1(headEntry === $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.t_lockEntryHead, "headEntry == t_lockEntryHead");
                        $.$spc.System.Diagnostics.Debug.Assert$1(headEntry === null || headEntry._lockID !== lockID, "headEntry == null || headEntry._lockID != lockID");
                        /*ThreadLocalLockEntry?*/ let entry = null;
                        /*ThreadLocalLockEntry?*/ let emptyEntryPrevious = null;
                        /*ThreadLocalLockEntry?*/ let emptyEntry = null;
                        if (headEntry !== null)
                        {
                            if (headEntry.IsFree)
                            {
                                emptyEntry = headEntry;
                            }
                            for(/*ThreadLocalLockEntry?*/ let previousEntry = headEntry, currentEntry = headEntry._next; currentEntry !== null; previousEntry = currentEntry, currentEntry = currentEntry._next)
                            {
                                if (currentEntry._lockID === lockID)
                                {
                                    $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.VerifyNoNonemptyEntryInListAfter(lockID, currentEntry);
                                    previousEntry._next = currentEntry._next;
                                    entry = currentEntry;
                                    break;
                                }
                                if (emptyEntry === null && currentEntry.IsFree)
                                {
                                    emptyEntryPrevious = previousEntry;
                                    emptyEntry = currentEntry;
                                }
                            }
                        }
                        if (entry === null)
                        {
                            if (emptyEntry !== null)
                            {
                                emptyEntry._lockID = lockID;
                                if (emptyEntryPrevious === null)
                                {
                                    $.$spc.System.Diagnostics.Debug.Assert$1(emptyEntry === headEntry, "emptyEntry == headEntry");
                                    return emptyEntry;
                                }
                                emptyEntryPrevious._next = emptyEntry._next;
                                entry = emptyEntry;
                            }
                            else 
                            {
                                entry = new $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry().$ctor$1(lockID);
                            }
                        }
                        $.$spc.System.Diagnostics.Debug.Assert$1(entry._lockID === lockID, "entry._lockID == lockID");
                        entry._next = headEntry;
                        $.$st.System.Threading.ReaderWriterLock.ThreadLocalLockEntry.t_lockEntryHead = entry;
                        return entry;
                    }
                    static $h = 1084360;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":34360822728,"f":1},"n":"IsFree","d":1084360,"h":30065855432,"f":1}],"m":[{"r":262145,"p":[{"n":"lockID","p":917505}],"n":"HasLockID","d":1084360,"h":25770888136,"f":1},{"r":65537,"p":[{"n":"lockID","p":917505},{"n":"afterEntry","p":1084360}],"n":"VerifyNoNonemptyEntryInListAfter","d":1084360,"h":38655790024,"f":34,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"DEBUG","t":1310721}]}]},{"r":1084360,"p":[{"n":"lockID","p":917505}],"n":"GetCurrent","d":1084360,"h":42950757320,"f":33},{"r":1084360,"p":[{"n":"lockID","p":917505}],"n":"GetOrCreateCurrent","d":1084360,"h":47245724616,"f":33},{"r":1084360,"p":[{"n":"lockID","p":917505},{"n":"headEntry","p":1084360}],"n":"GetOrCreateCurrentSlow","d":1084360,"h":51540691912,"f":34}],"l":[{"t":1084360,"n":"t_lockEntryHead","d":1084360,"h":4296051656,"f":34,"a":[{"t":140181505,"c":4435148801}]},{"t":917505,"n":"_lockID","d":1084360,"h":8591018952,"f":2},{"t":1084360,"n":"_next","d":1084360,"h":12885986248,"f":2},{"t":589825,"n":"_readerLevel","d":1084360,"h":17180953544,"f":1}],"c":[{"p":[{"n":"lockID","p":917505}],"n":".ctor","o":"$ctor$1","d":1084360,"h":21475920840,"f":2}],"d":887752,"h":1084360}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Threading.ReaderWriterLock.ThreadLocalLockEntry`; }
                }, $cls, ($v) => $cls.$_ThreadLocalLockEntry = $v);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.DefaultSpinCount = /*Environment.ProcessorCount != 1 ? 500 : */ 0;
                }
            }
            static $h = 887752;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":97124353,"p":[{"p":262145,"g":{"r":0,"d":0,"h":64425397192,"f":1},"n":"IsReaderLockHeld","d":887752,"h":60130429896,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":73015331784,"f":1},"n":"IsWriterLockHeld","d":887752,"h":68720364488,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":81605266376,"f":1},"n":"WriterSeqNum","d":887752,"h":77310299080,"f":1}],"m":[{"r":262145,"p":[{"n":"seqNum","p":655361}],"n":"AnyWritersSince","d":887752,"h":85900233672,"f":1},{"r":65537,"p":[{"n":"millisecondsTimeout","p":655361}],"n":"AcquireReaderLock","d":887752,"h":90195200968,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]}]},{"r":65537,"p":[{"n":"timeout","p":140705793}],"n":"AcquireReaderLock","o":"@$1","d":887752,"h":94490168264,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]}]},{"r":65537,"p":[{"n":"millisecondsTimeout","p":655361}],"n":"AcquireWriterLock","d":887752,"h":98785135560,"f":1},{"r":65537,"p":[{"n":"timeout","p":140705793}],"n":"AcquireWriterLock","o":"@$1","d":887752,"h":103080102856,"f":1},{"r":65537,"n":"ReleaseReaderLock","d":887752,"h":107375070152,"f":1},{"r":65537,"n":"ReleaseWriterLock","d":887752,"h":111670037448,"f":1},{"r":756680,"p":[{"n":"millisecondsTimeout","p":655361}],"n":"UpgradeToWriterLock","d":887752,"h":115965004744,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]}]},{"r":756680,"p":[{"n":"timeout","p":140705793}],"n":"UpgradeToWriterLock","o":"@$1","d":887752,"h":120259972040,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]}]},{"r":65537,"p":[{"n":"lockCookie","p":756680,"f":4}],"n":"DowngradeFromWriterLock","d":887752,"h":124554939336,"f":1},{"r":756680,"n":"ReleaseLock","d":887752,"h":128849906632,"f":1},{"r":65537,"p":[{"n":"lockCookie","p":756680,"f":4}],"n":"RestoreLock","d":887752,"h":133144873928,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]}]},{"r":65537,"p":[{"n":"lockCookie","p":756680,"f":4},{"n":"flags","p":822216}],"n":"RecoverLock","d":887752,"h":137439841224,"f":2,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]}]},{"r":655361,"n":"GetCurrentThreadID","d":887752,"h":141734808520,"f":34},{"r":262145,"n":"YieldProcessor","d":887752,"h":146029775816,"f":34},{"r":128385025,"n":"GetOrCreateReaderEvent","d":887752,"h":150324743112,"f":2},{"r":125894657,"n":"GetOrCreateWriterEvent","d":887752,"h":154619710408,"f":2},{"r":128385025,"n":"TryGetOrCreateReaderEvent","d":887752,"h":158914677704,"f":2},{"r":125894657,"n":"TryGetOrCreateWriterEvent","d":887752,"h":163209645000,"f":2},{"r":65537,"n":"ReleaseEvents","d":887752,"h":167504612296,"f":2},{"r":655361,"p":[{"n":"timeout","p":140705793}],"n":"ToTimeoutMilliseconds","d":887752,"h":171799579592,"f":34},{"r":1018824,"n":"GetTimeoutException","d":887752,"h":180389514184,"f":34},{"r":1018824,"n":"GetNotOwnerException","d":887752,"h":184684481480,"f":34},{"r":1018824,"n":"GetInvalidLockCookieException","d":887752,"h":188979448776,"f":34}],"l":[{"t":655361,"n":"InvalidThreadID","d":887752,"h":4295855048,"f":34},{"t":589825,"n":"MaxAcquireCount","d":887752,"h":8590822344,"f":34},{"t":655361,"n":"DefaultSpinCount","d":887752,"h":12885789640,"f":34},{"t":655361,"n":"IncorrectButCompatibleNotOwnerExceptionHResult","d":887752,"h":17180756936,"f":34},{"t":917505,"n":"s_mostRecentLockID","d":887752,"h":21475724232,"f":34},{"t":128385025,"n":"_readerEvent","d":887752,"h":25770691528,"f":2},{"t":125894657,"n":"_writerEvent","d":887752,"h":30065658824,"f":2},{"t":917505,"n":"_lockID","d":887752,"h":34360626120,"f":2},{"t":655361,"n":"_state","d":887752,"h":38655593416,"f":2},{"t":655361,"n":"_writerID","d":887752,"h":42950560712,"f":2},{"t":655361,"n":"_writerSeqNum","d":887752,"h":47245528008,"f":2},{"t":589825,"n":"_writerLevel","d":887752,"h":51540495304,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":887752,"h":55835462600,"f":1}],"j":[953288,1084360],"h":887752}; }
            static get $b() { return $.$spc.System.Runtime.ConstrainedExecution.CriticalFinalizerObject; }
            static get $fullName() { return `System.Threading.ReaderWriterLock`; }
        });
        
        $asm.$str("$st.System.Threading.LockCookie", ($self) => class LockCookie extends $.$spc.System.ValueType
        {
            /*LockCookieFlags*/  get _flags() { return this.$getField(0, $.$st.System.Threading.LockCookieFlags); }
            /*LockCookieFlags*/  set _flags(value) { this.$setField(0, $.$st.System.Threading.LockCookieFlags, value); }
            /*ushort*/  get _readerLevel() { return this.$getField(4, $.$spc.System.UInt16); }
            /*ushort*/  set _readerLevel(value) { this.$setField(4, $.$spc.System.UInt16, value); }
            /*ushort*/  get _writerLevel() { return this.$getField(6, $.$spc.System.UInt16); }
            /*ushort*/  set _writerLevel(value) { this.$setField(6, $.$spc.System.UInt16, value); }
            /*int*/  get _threadID() { return this.$getField(8, $.$spc.System.Int32); }
            /*int*/  set _threadID(value) { this.$setField(8, $.$spc.System.Int32, value); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return ((((((this._flags + this._readerLevel) | 0) + this._writerLevel) | 0) + this._threadID) | 0);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$st.System.Threading.LockCookie.GetHashCode.apply(this, arguments); }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                let other;
                return $.$is(obj, $.$st.System.Threading.LockCookie, { set $v(v){ other = v; } }) && this.Equals$2(other.Clone());
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$st.System.Threading.LockCookie.Equals.apply(this, arguments); }
            /*bool */ Equals$2(/*LockCookie*/ obj)
            {
                return this._flags === obj._flags && this._readerLevel === obj._readerLevel && this._writerLevel === obj._writerLevel && this._threadID === obj._threadID;
            }
            static /*bool */ op_Equality(/*LockCookie*/ a, /*LockCookie*/ b)
            {
                return a.Equals$2(b.Clone());
            }
            static /*bool */ op_Inequality(/*LockCookie*/ a, /*LockCookie*/ b)
            {
                return !a.Equals$2(b.Clone());
            }
            //Generated interface implemetation for System.IEquatable<System.Threading.LockCookie>.Equals(System.Threading.LockCookie)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._flags = this._flags;
                copy._readerLevel = this._readerLevel;
                copy._writerLevel = this._writerLevel;
                copy._threadID = this._threadID;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._flags = 0;
                this._readerLevel = 0;
                this._writerLevel = 0;
                this._threadID = 0;
            }
            static $h = 756680;
            static $z = 12;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"m":[{"r":655361,"n":"GetHashCode","d":756680,"h":21475593160,"f":32769},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":756680,"h":25770560456,"f":32769},{"r":262145,"p":[{"n":"obj","p":756680}],"n":"Equals","o":"@$2","d":756680,"h":30065527752,"f":1}],"l":[{"t":822216,"n":"_flags","d":756680,"h":4295723976,"f":8},{"t":589825,"n":"_readerLevel","d":756680,"h":8590691272,"f":8},{"t":589825,"n":"_writerLevel","d":756680,"h":12885658568,"f":8},{"t":655361,"n":"_threadID","d":756680,"h":17180625864,"f":8}],"c":[{"n":".ctor","o":"$ctor$2","d":756680,"h":42950429640,"f":1}],"i":[$.$spc.System.IEquatable$$($.$st.System.Threading.LockCookie).$h],"h":756680}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$st.System.Threading.LockCookie) ]; }
            static get $fullName() { return `System.Threading.LockCookie`; }
        });
        
        $asm.$str("$st.System.Threading.LockCookieFlags", ($self) => class LockCookieFlags extends $.$spc.System.Enum
        {
            static Upgrade = 8192;
            static Release = 16384;
            static OwnedNone = 65536;
            static OwnedWriter = 131072;
            static OwnedReader = 262144;
            static Invalid = -483329;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Upgrade": 8192n,
                    "Release": 16384n,
                    "OwnedNone": 65536n,
                    "OwnedWriter": 131072n,
                    "OwnedReader": 262144n,
                    "Invalid": -483329n
                };
            }
            static $h = 822216;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":822216,"n":"Upgrade","d":822216,"h":4295789512,"f":33},{"t":822216,"n":"Release","d":822216,"h":8590756808,"f":33},{"t":822216,"n":"OwnedNone","d":822216,"h":12885724104,"f":33},{"t":822216,"n":"OwnedWriter","d":822216,"h":17180691400,"f":33},{"t":822216,"n":"OwnedReader","d":822216,"h":21475658696,"f":33},{"t":822216,"n":"Invalid","d":822216,"h":25770625992,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":822216,"h":30065593288,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":822216,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Threading.LockCookieFlags`; }
        });
        
        $asm.$cls("$st.System.Threading.CdsSyncEtwBCLProvider", ($self) => class CdsSyncEtwBCLProvider extends $.$spc.System.Diagnostics.Tracing.EventSource
        {
            /*CdsSyncEtwBCLProvider*/ static Log = null;
            $ctor$8()
            {
                super.$ctor$4();
                {
                }
                return this;
            }
            /*EventKeywords*/ static ALL_KEYWORDS = -1n;
            /*int*/ static BARRIER_PHASEFINISHED_ID = 3;
            /*void */ Barrier_PhaseFinished(/*bool*/ currentSense, /*long*/ phaseNum)
            {
                if (this.IsEnabled$1(5/*EventLevel.Verbose*/, -1n))
                {
                    {
                        /*EventData**/ let eventPayload = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocPointer($.$spc.System.Diagnostics.Tracing.EventSource.EventData, 2, null);
                        /*int*/ let senseAsInt32 = currentSense ? 1 : 0;
                        eventPayload.SetAt((() =>
                        {
                            //new $.$spc.System.Diagnostics.Tracing.EventSource.EventData()
                            const $t1 = $.$spc.System.Diagnostics.Tracing.EventSource.EventData;
                            const $i1 = new $t1();
                            $i1.Size = $.$spc.System.Int32.$z;
                            $i1.DataPointer = ($.$cast(($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Int32, () => senseAsInt32, ($v) => senseAsInt32 = $v, null)), $.$spc.System.IntPtr));
                            return $i1;
                        })(), 0);
                        eventPayload.SetAt((() =>
                        {
                            //new $.$spc.System.Diagnostics.Tracing.EventSource.EventData()
                            const $t2 = $.$spc.System.Diagnostics.Tracing.EventSource.EventData;
                            const $i2 = new $t2();
                            $i2.Size = $.$spc.System.Int64.$z;
                            $i2.DataPointer = ($.$spc.InteropUtility.castObject2Address($.$box(phaseNum, $.$spc.System.Int64), 0, false));
                            return $i2;
                        })(), 1);
                        this.WriteEventCore(3/*BARRIER_PHASEFINISHED_ID*/, 2, eventPayload);
                    }
                }
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Log = new $.$st.System.Threading.CdsSyncEtwBCLProvider().$ctor$8();
                }
            }
            static $h = 429000;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":41746433,"m":[{"r":65537,"p":[{"n":"currentSense","p":262145},{"n":"phaseNum","p":917505}],"n":"Barrier_PhaseFinished","d":429000,"h":21475265480,"f":1,"a":[{"t":39976961,"c":4334944257,"a":[{"v":3,"t":655361}],"n":[{"n":"Level","v":5,"t":40960001},{"n":"Version","v":1,"t":393217}]}]}],"l":[{"t":429000,"n":"Log","d":429000,"h":4295396296,"f":33},{"t":40894465,"n":"ALL_KEYWORDS","d":429000,"h":12885330888,"f":34},{"t":655361,"n":"BARRIER_PHASEFINISHED_ID","d":429000,"h":17180298184,"f":34}],"c":[{"n":".ctor","o":"$ctor$8","d":429000,"h":8590363592,"f":2}],"i":[57540609],"h":429000,"a":[{"t":42074113,"c":55876648961,"n":[{"n":"Name","v":"System.Threading.SynchronizationEventSource","t":1310721},{"n":"Guid","v":"EC631D38-466B-4290-9306-834971BA0217","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Diagnostics.Tracing.EventSource; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Threading.CdsSyncEtwBCLProvider`; }
        });
        
        $asm.$cls("$st.System.Threading.BarrierPostPhaseException", ($self) => class BarrierPostPhaseException extends $.$spc.System.Exception
        {
            $ctor$5()
            {
                this.$ctor$7(null);
                {
                }
                return this;
            }
            $ctor$6(/*Exception?*/ innerException)
            {
                this.$ctor$8(null, innerException);
                {
                }
                return this;
            }
            $ctor$7(/*string?*/ message)
            {
                this.$ctor$8(message, null);
                {
                }
                return this;
            }
            $ctor$8(/*string?*/ message, /*Exception?*/ innerException)
            {
                super.$ctor$3(message === null ? $.$st.System.SR.BarrierPostPhaseException : message, innerException);
                {
                }
                return this;
            }
            $ctor$9(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor$4(info, context);
                {
                }
                return this;
            }
            static $h = 363464;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":47251457,"h":363464}; }
            static get $b() { return $.$spc.System.Exception; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Threading.BarrierPostPhaseException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib"))