
(function ($global, $, $$, $mwp, $sc, $sm, $spu, $sr, $sdt, $st, $scc, $sris, $scn, $stt, $ssc, $sspw, $ssa, $mwr, $snv, $sri, $sl, $sci, $scm, $so, $scp, $scs, $stee, $scsl, $sttp, $sdd, $sdf, $sifd, $sto, $sip, $sdpc, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $sxr) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Transactions.Local", 
    {"h":42252,"f":"System.Transactions.Local","v":"1.0.35.0","a":[{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Beff628fa5ab8bd29ec37e9c13a50148694bea088","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Transactions.Local","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Transactions.Local","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115081217,"c":4410048513,"a":[{"v":"browser1.0","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$stl.System.Transactions.IDtcTransaction", ($self) => class IDtcTransaction
        {
            static $h = 2532620;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"p":[{"n":"retaining","p":655361},{"n":"commitType","p":655361,"a":[{"t":105578497,"c":8695513089,"a":[{"v":7,"t":110755841}]}]},{"n":"reserved","p":655361}],"n":"Commit","o":"System$Transactions$IDtcTransaction$Commit","d":2532620,"h":4297499916,"f":16777473},{"r":65537,"p":[{"n":"reason","p":786433},{"n":"retaining","p":655361},{"n":"async","p":655361}],"n":"Abort","o":"System$Transactions$IDtcTransaction$Abort","d":2532620,"h":8592467212,"f":16777473},{"r":65537,"p":[{"n":"transactionInformation","p":786433}],"n":"GetTransactionInfo","o":"System$Transactions$IDtcTransaction$GetTransactionInfo","d":2532620,"h":12887434508,"f":16777473}],"h":2532620,"a":[{"t":99024897,"c":4393992193},{"t":104267777,"c":4399235073,"a":[{"v":"0fb15084-af41-11ce-bd2b-204c4f4f5020","t":1310721}]},{"t":104792065,"c":4399759361,"a":[{"v":1,"t":99090433}]}]}; }
            static get $fullName() { return `System.Transactions.IDtcTransaction`; }
        });
        
        $asm.$cls("$stl.System.Transactions.IEnlistmentNotificationInternal", ($self) => class IEnlistmentNotificationInternal
        {
            static $h = 2663692;
            static $f = 0b100100;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"p":[{"n":"preparingEnlistment","p":2925836}],"n":"Prepare","o":"System$Transactions$IEnlistmentNotificationInternal$Prepare","d":2663692,"h":4297630988,"f":16777473},{"r":65537,"p":[{"n":"enlistment","p":2925836}],"n":"Commit","o":"System$Transactions$IEnlistmentNotificationInternal$Commit","d":2663692,"h":8592598284,"f":16777473},{"r":65537,"p":[{"n":"enlistment","p":2925836}],"n":"Rollback","o":"System$Transactions$IEnlistmentNotificationInternal$Rollback","d":2663692,"h":12887565580,"f":16777473},{"r":65537,"p":[{"n":"enlistment","p":2925836}],"n":"InDoubt","o":"System$Transactions$IEnlistmentNotificationInternal$InDoubt","d":2663692,"h":17182532876,"f":16777473}],"h":2663692}; }
            static get $fullName() { return `System.Transactions.IEnlistmentNotificationInternal`; }
        });
        
        $asm.$cls("$stl.System.Transactions.ITransactionPromoter", ($self) => class ITransactionPromoter
        {
            static $h = 3253516;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":$.$typeArray($.$$.System.Byte).$h,"n":"Promote","o":"System$Transactions$ITransactionPromoter$Promote","d":3253516,"h":4298220812,"f":16777473}],"h":3253516}; }
            static get $fullName() { return `System.Transactions.ITransactionPromoter`; }
        });
        
        $asm.$cls("$stl.System.Transactions.IEnlistmentNotification", ($self) => class IEnlistmentNotification
        {
            static $h = 2598156;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"p":[{"n":"preparingEnlistment","p":3908876}],"n":"Prepare","o":"System$Transactions$IEnlistmentNotification$Prepare","d":2598156,"h":4297565452,"f":16777473},{"r":65537,"p":[{"n":"enlistment","p":1746188}],"n":"Commit","o":"System$Transactions$IEnlistmentNotification$Commit","d":2598156,"h":8592532748,"f":16777473},{"r":65537,"p":[{"n":"enlistment","p":1746188}],"n":"Rollback","o":"System$Transactions$IEnlistmentNotification$Rollback","d":2598156,"h":12887500044,"f":16777473},{"r":65537,"p":[{"n":"enlistment","p":1746188}],"n":"InDoubt","o":"System$Transactions$IEnlistmentNotification$InDoubt","d":2598156,"h":17182467340,"f":16777473}],"h":2598156}; }
            static get $fullName() { return `System.Transactions.IEnlistmentNotification`; }
        });
        
        $asm.$cls("$stl.System.Transactions.IPromotedEnlistment", ($self) => class IPromotedEnlistment
        {
            static $h = 2925836;
            static $f = 0b100100;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":2729228,"g":{"r":0,"d":0,"h":51542533388,"f":50331905},"s":{"r":0,"d":0,"h":55837500684,"f":83886337},"n":"InternalEnlistment","o":"System$Transactions$IPromotedEnlistment$InternalEnlistment","d":2925836,"h":47247566092,"f":2097409}],"m":[{"r":65537,"n":"EnlistmentDone","o":"System$Transactions$IPromotedEnlistment$EnlistmentDone","d":2925836,"h":4297893132,"f":16777473},{"r":65537,"n":"Prepared","o":"System$Transactions$IPromotedEnlistment$Prepared","d":2925836,"h":8592860428,"f":16777473},{"r":65537,"n":"ForceRollback","o":"System$Transactions$IPromotedEnlistment$ForceRollback","d":2925836,"h":12887827724,"f":16777473},{"r":65537,"p":[{"n":"e","p":47251457}],"n":"ForceRollback","o":"System$Transactions$IPromotedEnlistment$ForceRollback$1","d":2925836,"h":17182795020,"f":16777473},{"r":65537,"n":"Committed","o":"System$Transactions$IPromotedEnlistment$Committed","d":2925836,"h":21477762316,"f":16777473},{"r":65537,"n":"Aborted","o":"System$Transactions$IPromotedEnlistment$Aborted","d":2925836,"h":25772729612,"f":16777473},{"r":65537,"p":[{"n":"e","p":47251457}],"n":"Aborted","o":"System$Transactions$IPromotedEnlistment$Aborted$1","d":2925836,"h":30067696908,"f":16777473},{"r":65537,"n":"InDoubt","o":"System$Transactions$IPromotedEnlistment$InDoubt","d":2925836,"h":34362664204,"f":16777473},{"r":65537,"p":[{"n":"e","p":47251457}],"n":"InDoubt","o":"System$Transactions$IPromotedEnlistment$InDoubt$1","d":2925836,"h":38657631500,"f":16777473},{"r":$.$typeArray($.$$.System.Byte).$h,"n":"GetRecoveryInformation","o":"System$Transactions$IPromotedEnlistment$GetRecoveryInformation","d":2925836,"h":42952598796,"f":16777473}],"h":2925836}; }
            static get $fullName() { return `System.Transactions.IPromotedEnlistment`; }
        });
        
        $asm.$cls("$stl.System.Transactions.IPromotableSinglePhaseNotification", ($self) => class IPromotableSinglePhaseNotification
        {
            static $h = 2860300;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"n":"Initialize","o":"System$Transactions$IPromotableSinglePhaseNotification$Initialize","d":2860300,"h":4297827596,"f":16777473},{"r":65537,"p":[{"n":"singlePhaseEnlistment","p":4105484}],"n":"SinglePhaseCommit","o":"System$Transactions$IPromotableSinglePhaseNotification$SinglePhaseCommit","d":2860300,"h":8592794892,"f":16777473},{"r":65537,"p":[{"n":"singlePhaseEnlistment","p":4105484}],"n":"Rollback","o":"System$Transactions$IPromotableSinglePhaseNotification$Rollback","d":2860300,"h":12887762188,"f":16777473}],"i":[3253516],"h":2860300}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stl.System.Transactions.ITransactionPromoter ]; }
            static get $fullName() { return `System.Transactions.IPromotableSinglePhaseNotification`; }
        });
        
        $asm.$cls("$stl.System.Transactions.ISimpleTransactionSuperior", ($self) => class ISimpleTransactionSuperior
        {
            static $h = 2991372;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"n":"Rollback","o":"System$Transactions$ISimpleTransactionSuperior$Rollback","d":2991372,"h":4297958668,"f":16777473}],"i":[3253516],"h":2991372}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stl.System.Transactions.ITransactionPromoter ]; }
            static get $fullName() { return `System.Transactions.ISimpleTransactionSuperior`; }
        });
        
        $asm.$cls("$stl.System.Transactions.ISinglePhaseNotificationInternal", ($self) => class ISinglePhaseNotificationInternal
        {
            static $h = 3122444;
            static $f = 0b100100;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"p":[{"n":"singlePhaseEnlistment","p":2925836}],"n":"SinglePhaseCommit","o":"System$Transactions$ISinglePhaseNotificationInternal$SinglePhaseCommit","d":3122444,"h":4298089740,"f":16777473}],"i":[2663692],"h":3122444}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stl.System.Transactions.IEnlistmentNotificationInternal ]; }
            static get $fullName() { return `System.Transactions.ISinglePhaseNotificationInternal`; }
        });
        
        $asm.$cls("$stl.System.Transactions.ISinglePhaseNotification", ($self) => class ISinglePhaseNotification
        {
            static $h = 3056908;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"p":[{"n":"singlePhaseEnlistment","p":4105484}],"n":"SinglePhaseCommit","o":"System$Transactions$ISinglePhaseNotification$SinglePhaseCommit","d":3056908,"h":4298024204,"f":16777473}],"i":[2598156],"h":3056908}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stl.System.Transactions.IEnlistmentNotification ]; }
            static get $fullName() { return `System.Transactions.ISinglePhaseNotification`; }
        });
        
        $asm.$cls("$stl.System.Transactions.EnlistmentState", ($self) => class EnlistmentState extends $.$$.System.Object
        {
            /*EnlistmentStatePromoted?*/ static _enlistmentStatePromoted = null;
            /*object?*/ static s_classSyncObject = null;
            static /*EnlistmentStatePromoted */ get EnlistmentStatePromoted()
            {
                return $.$$.System.Threading.LazyInitializer.EnsureInitialized$3($.$stl.System.Transactions.EnlistmentStatePromoted, $.$ref(() => $.$stl.System.Transactions.EnlistmentState._enlistmentStatePromoted, ($v) => $.$stl.System.Transactions.EnlistmentState._enlistmentStatePromoted = $v, $.$stl.System.Transactions.EnlistmentStatePromoted), $.$ref(() => $.$stl.System.Transactions.EnlistmentState.s_classSyncObject, ($v) => $.$stl.System.Transactions.EnlistmentState.s_classSyncObject = $v, $.$$.System.Object), new ($.$$.System.Func$$($.$stl.System.Transactions.EnlistmentStatePromoted))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.EnlistmentStatePromoted().$ctor$2();
                }, {"r":2008332,"n":"","d":1942796,"h":0,"f":17825794}));
            }
            /*void */ EnlistmentDone(/*InternalEnlistment*/ enlistment)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateEnlistmentStateException(null, enlistment === null ? $.$$.System.Guid.Empty : enlistment.DistributedTxId);
            }
            /*void */ Prepared(/*InternalEnlistment*/ enlistment)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateEnlistmentStateException(null, enlistment === null ? $.$$.System.Guid.Empty : enlistment.DistributedTxId);
            }
            /*void */ ForceRollback(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateEnlistmentStateException(null, enlistment === null ? $.$$.System.Guid.Empty : enlistment.DistributedTxId);
            }
            /*void */ Committed(/*InternalEnlistment*/ enlistment)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateEnlistmentStateException(null, enlistment === null ? $.$$.System.Guid.Empty : enlistment.DistributedTxId);
            }
            /*void */ Aborted(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateEnlistmentStateException(null, enlistment === null ? $.$$.System.Guid.Empty : enlistment.DistributedTxId);
            }
            /*void */ InDoubt(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateEnlistmentStateException(null, enlistment === null ? $.$$.System.Guid.Empty : enlistment.DistributedTxId);
            }
            /*byte[] */ RecoveryInformation(/*InternalEnlistment*/ enlistment)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateEnlistmentStateException(null, enlistment === null ? $.$$.System.Guid.Empty : enlistment.DistributedTxId);
            }
            /*void */ InternalAborted(/*InternalEnlistment*/ enlistment)
            {
                $.$$.System.Diagnostics.Debug.Fail$1(`Invalid Event for InternalEnlistment State; Current State: ${$.$$.System.Type.ToString.call($.$$.System.Object.GetType.call(this))}`);
                throw $.$stl.System.Transactions.TransactionException.CreateEnlistmentStateException(null, enlistment === null ? $.$$.System.Guid.Empty : enlistment.DistributedTxId);
            }
            /*void */ InternalCommitted(/*InternalEnlistment*/ enlistment)
            {
                $.$$.System.Diagnostics.Debug.Fail$1(`Invalid Event for InternalEnlistment State; Current State: ${$.$$.System.Type.ToString.call($.$$.System.Object.GetType.call(this))}`);
                throw $.$stl.System.Transactions.TransactionException.CreateEnlistmentStateException(null, enlistment === null ? $.$$.System.Guid.Empty : enlistment.DistributedTxId);
            }
            /*void */ InternalIndoubt(/*InternalEnlistment*/ enlistment)
            {
                $.$$.System.Diagnostics.Debug.Fail$1(`Invalid Event for InternalEnlistment State; Current State: ${$.$$.System.Type.ToString.call($.$$.System.Object.GetType.call(this))}`);
                throw $.$stl.System.Transactions.TransactionException.CreateEnlistmentStateException(null, enlistment === null ? $.$$.System.Guid.Empty : enlistment.DistributedTxId);
            }
            /*void */ ChangeStateCommitting(/*InternalEnlistment*/ enlistment)
            {
                $.$$.System.Diagnostics.Debug.Fail$1(`Invalid Event for InternalEnlistment State; Current State: ${$.$$.System.Type.ToString.call($.$$.System.Object.GetType.call(this))}`);
                throw $.$stl.System.Transactions.TransactionException.CreateEnlistmentStateException(null, enlistment === null ? $.$$.System.Guid.Empty : enlistment.DistributedTxId);
            }
            /*void */ ChangeStatePromoted(/*InternalEnlistment*/ enlistment, /*IPromotedEnlistment*/ promotedEnlistment)
            {
                $.$$.System.Diagnostics.Debug.Fail$1(`Invalid Event for InternalEnlistment State; Current State: ${$.$$.System.Type.ToString.call($.$$.System.Object.GetType.call(this))}`);
                throw $.$stl.System.Transactions.TransactionException.CreateEnlistmentStateException(null, enlistment === null ? $.$$.System.Guid.Empty : enlistment.DistributedTxId);
            }
            /*void */ ChangeStateDelegated(/*InternalEnlistment*/ enlistment)
            {
                $.$$.System.Diagnostics.Debug.Fail$1(`Invalid Event for InternalEnlistment State; Current State: ${$.$$.System.Type.ToString.call($.$$.System.Object.GetType.call(this))}`);
                throw $.$stl.System.Transactions.TransactionException.CreateEnlistmentStateException(null, enlistment === null ? $.$$.System.Guid.Empty : enlistment.DistributedTxId);
            }
            /*void */ ChangeStatePreparing(/*InternalEnlistment*/ enlistment)
            {
                $.$$.System.Diagnostics.Debug.Fail$1(`Invalid Event for InternalEnlistment State; Current State: ${$.$$.System.Type.ToString.call($.$$.System.Object.GetType.call(this))}`);
                throw $.$stl.System.Transactions.TransactionException.CreateEnlistmentStateException(null, enlistment === null ? $.$$.System.Guid.Empty : enlistment.DistributedTxId);
            }
            /*void */ ChangeStateSinglePhaseCommit(/*InternalEnlistment*/ enlistment)
            {
                $.$$.System.Diagnostics.Debug.Fail$1(`Invalid Event for InternalEnlistment State; Current State: ${$.$$.System.Type.ToString.call($.$$.System.Object.GetType.call(this))}`);
                throw $.$stl.System.Transactions.TransactionException.CreateEnlistmentStateException(null, enlistment === null ? $.$$.System.Guid.Empty : enlistment.DistributedTxId);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 1942796;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":2008332,"g":{"r":0,"d":0,"h":21476779276,"f":50331688},"n":"EnlistmentStatePromoted","d":1942796,"h":17181811980,"f":2097192}],"m":[{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"EnterState","d":1942796,"h":4296910092,"f":16777480},{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"EnlistmentDone","d":1942796,"h":25771746572,"f":16777352},{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"Prepared","d":1942796,"h":30066713868,"f":16777352},{"r":65537,"p":[{"n":"enlistment","p":2729228},{"n":"e","p":47251457}],"n":"ForceRollback","d":1942796,"h":34361681164,"f":16777352},{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"Committed","d":1942796,"h":38656648460,"f":16777352},{"r":65537,"p":[{"n":"enlistment","p":2729228},{"n":"e","p":47251457}],"n":"Aborted","d":1942796,"h":42951615756,"f":16777352},{"r":65537,"p":[{"n":"enlistment","p":2729228},{"n":"e","p":47251457}],"n":"InDoubt","d":1942796,"h":47246583052,"f":16777352},{"r":$.$typeArray($.$$.System.Byte).$h,"p":[{"n":"enlistment","p":2729228}],"n":"RecoveryInformation","d":1942796,"h":51541550348,"f":16777352},{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"InternalAborted","d":1942796,"h":55836517644,"f":16777352},{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"InternalCommitted","d":1942796,"h":60131484940,"f":16777352},{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"InternalIndoubt","d":1942796,"h":64426452236,"f":16777352},{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"ChangeStateCommitting","d":1942796,"h":68721419532,"f":16777352},{"r":65537,"p":[{"n":"enlistment","p":2729228},{"n":"promotedEnlistment","p":2925836}],"n":"ChangeStatePromoted","d":1942796,"h":73016386828,"f":16777352},{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"ChangeStateDelegated","d":1942796,"h":77311354124,"f":16777352},{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"ChangeStatePreparing","d":1942796,"h":81606321420,"f":16777352},{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"ChangeStateSinglePhaseCommit","d":1942796,"h":85901288716,"f":16777352}],"l":[{"t":2008332,"n":"_enlistmentStatePromoted","d":1942796,"h":8591877388,"f":4194344},{"t":131073,"n":"s_classSyncObject","d":1942796,"h":12886844684,"f":4194338}],"c":[{"n":".ctor","o":"$ctor$1","d":1942796,"h":90196256012,"f":16777220}],"h":1942796}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Transactions.EnlistmentState`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionState", ($self) => class TransactionState extends $.$$.System.Object
        {
            /*TransactionStateActive?*/ static s_transactionStateActive = null;
            /*TransactionStateSubordinateActive?*/ static s_transactionStateSubordinateActive = null;
            /*TransactionStatePhase0?*/ static s_transactionStatePhase0 = null;
            /*TransactionStateVolatilePhase1?*/ static s_transactionStateVolatilePhase1 = null;
            /*TransactionStateVolatileSPC?*/ static s_transactionStateVolatileSPC = null;
            /*TransactionStateSPC?*/ static s_transactionStateSPC = null;
            /*TransactionStateAborted?*/ static s_transactionStateAborted = null;
            /*TransactionStateCommitted?*/ static s_transactionStateCommitted = null;
            /*TransactionStateInDoubt?*/ static s_transactionStateInDoubt = null;
            /*TransactionStatePromoted?*/ static s_transactionStatePromoted = null;
            /*TransactionStateNonCommittablePromoted?*/ static s_transactionStateNonCommittablePromoted = null;
            /*TransactionStatePromotedP0Wave?*/ static s_transactionStatePromotedP0Wave = null;
            /*TransactionStatePromotedCommitting?*/ static s_transactionStatePromotedCommitting = null;
            /*TransactionStatePromotedPhase0?*/ static s_transactionStatePromotedPhase0 = null;
            /*TransactionStatePromotedPhase1?*/ static s_transactionStatePromotedPhase1 = null;
            /*TransactionStatePromotedP0Aborting?*/ static s_transactionStatePromotedP0Aborting = null;
            /*TransactionStatePromotedP1Aborting?*/ static s_transactionStatePromotedP1Aborting = null;
            /*TransactionStatePromotedAborted?*/ static s_transactionStatePromotedAborted = null;
            /*TransactionStatePromotedCommitted?*/ static s_transactionStatePromotedCommitted = null;
            /*TransactionStatePromotedIndoubt?*/ static s_transactionStatePromotedIndoubt = null;
            /*TransactionStateDelegated?*/ static s_transactionStateDelegated = null;
            /*TransactionStateDelegatedSubordinate?*/ static s_transactionStateDelegatedSubordinate = null;
            /*TransactionStateDelegatedP0Wave?*/ static s_transactionStateDelegatedP0Wave = null;
            /*TransactionStateDelegatedCommitting?*/ static s_transactionStateDelegatedCommitting = null;
            /*TransactionStateDelegatedAborting?*/ static s_transactionStateDelegatedAborting = null;
            /*TransactionStatePSPEOperation?*/ static s_transactionStatePSPEOperation = null;
            /*TransactionStateDelegatedNonMSDTC?*/ static s_transactionStateDelegatedNonMSDTC = null;
            /*TransactionStatePromotedNonMSDTCPhase0?*/ static s_transactionStatePromotedNonMSDTCPhase0 = null;
            /*TransactionStatePromotedNonMSDTCVolatilePhase1?*/ static s_transactionStatePromotedNonMSDTCVolatilePhase1 = null;
            /*TransactionStatePromotedNonMSDTCSinglePhaseCommit?*/ static s_transactionStatePromotedNonMSDTCSinglePhaseCommit = null;
            /*TransactionStatePromotedNonMSDTCAborted?*/ static s_transactionStatePromotedNonMSDTCAborted = null;
            /*TransactionStatePromotedNonMSDTCCommitted?*/ static s_transactionStatePromotedNonMSDTCCommitted = null;
            /*TransactionStatePromotedNonMSDTCIndoubt?*/ static s_transactionStatePromotedNonMSDTCIndoubt = null;
            /*object?*/ static s_classSyncObject = null;
            static /*TransactionStateActive */ get TransactionStateActive()
            {
                return $.$$.System.Threading.LazyInitializer.EnsureInitialized$3($.$stl.System.Transactions.TransactionStateActive, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStateActive, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStateActive = $v, $.$stl.System.Transactions.TransactionStateActive), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$$.System.Object), new ($.$$.System.Func$$($.$stl.System.Transactions.TransactionStateActive))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStateActive().$ctor$4();
                }, {"r":5874956,"n":"","d":5743884,"h":0,"f":17825794}));
            }
            static /*TransactionStateSubordinateActive */ get TransactionStateSubordinateActive()
            {
                return $.$$.System.Threading.LazyInitializer.EnsureInitialized$3($.$stl.System.Transactions.TransactionStateSubordinateActive, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStateSubordinateActive, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStateSubordinateActive = $v, $.$stl.System.Transactions.TransactionStateSubordinateActive), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$$.System.Object), new ($.$$.System.Func$$($.$stl.System.Transactions.TransactionStateSubordinateActive))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStateSubordinateActive().$ctor$5();
                }, {"r":8234252,"n":"","d":5743884,"h":0,"f":17825794}));
            }
            static /*TransactionStatePSPEOperation */ get TransactionStatePSPEOperation()
            {
                return $.$$.System.Threading.LazyInitializer.EnsureInitialized$3($.$stl.System.Transactions.TransactionStatePSPEOperation, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePSPEOperation, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePSPEOperation = $v, $.$stl.System.Transactions.TransactionStatePSPEOperation), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$$.System.Object), new ($.$$.System.Func$$($.$stl.System.Transactions.TransactionStatePSPEOperation))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePSPEOperation().$ctor$2();
                }, {"r":8103180,"n":"","d":5743884,"h":0,"f":17825794}));
            }
            static /*TransactionStatePhase0 */ get TransactionStatePhase0()
            {
                return $.$$.System.Threading.LazyInitializer.EnsureInitialized$3($.$stl.System.Transactions.TransactionStatePhase0, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePhase0, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePhase0 = $v, $.$stl.System.Transactions.TransactionStatePhase0), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$$.System.Object), new ($.$$.System.Func$$($.$stl.System.Transactions.TransactionStatePhase0))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePhase0().$ctor$4();
                }, {"r":6661388,"n":"","d":5743884,"h":0,"f":17825794}));
            }
            static /*TransactionStateVolatilePhase1 */ get TransactionStateVolatilePhase1()
            {
                return $.$$.System.Threading.LazyInitializer.EnsureInitialized$3($.$stl.System.Transactions.TransactionStateVolatilePhase1, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStateVolatilePhase1, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStateVolatilePhase1 = $v, $.$stl.System.Transactions.TransactionStateVolatilePhase1), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$$.System.Object), new ($.$$.System.Func$$($.$stl.System.Transactions.TransactionStateVolatilePhase1))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStateVolatilePhase1().$ctor$3();
                }, {"r":8299788,"n":"","d":5743884,"h":0,"f":17825794}));
            }
            static /*TransactionStateVolatileSPC */ get TransactionStateVolatileSPC()
            {
                return $.$$.System.Threading.LazyInitializer.EnsureInitialized$3($.$stl.System.Transactions.TransactionStateVolatileSPC, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStateVolatileSPC, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStateVolatileSPC = $v, $.$stl.System.Transactions.TransactionStateVolatileSPC), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$$.System.Object), new ($.$$.System.Func$$($.$stl.System.Transactions.TransactionStateVolatileSPC))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStateVolatileSPC().$ctor$3();
                }, {"r":8365324,"n":"","d":5743884,"h":0,"f":17825794}));
            }
            static /*TransactionStateSPC */ get TransactionStateSPC()
            {
                return $.$$.System.Threading.LazyInitializer.EnsureInitialized$3($.$stl.System.Transactions.TransactionStateSPC, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStateSPC, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStateSPC = $v, $.$stl.System.Transactions.TransactionStateSPC), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$$.System.Object), new ($.$$.System.Func$$($.$stl.System.Transactions.TransactionStateSPC))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStateSPC().$ctor$3();
                }, {"r":8168716,"n":"","d":5743884,"h":0,"f":17825794}));
            }
            static /*TransactionStateAborted */ get TransactionStateAborted()
            {
                return $.$$.System.Threading.LazyInitializer.EnsureInitialized$3($.$stl.System.Transactions.TransactionStateAborted, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStateAborted, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStateAborted = $v, $.$stl.System.Transactions.TransactionStateAborted), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$$.System.Object), new ($.$$.System.Func$$($.$stl.System.Transactions.TransactionStateAborted))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStateAborted().$ctor$3();
                }, {"r":5809420,"n":"","d":5743884,"h":0,"f":17825794}));
            }
            static /*TransactionStateCommitted */ get TransactionStateCommitted()
            {
                return $.$$.System.Threading.LazyInitializer.EnsureInitialized$3($.$stl.System.Transactions.TransactionStateCommitted, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStateCommitted, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStateCommitted = $v, $.$stl.System.Transactions.TransactionStateCommitted), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$$.System.Object), new ($.$$.System.Func$$($.$stl.System.Transactions.TransactionStateCommitted))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStateCommitted().$ctor$3();
                }, {"r":5940492,"n":"","d":5743884,"h":0,"f":17825794}));
            }
            static /*TransactionStateInDoubt */ get TransactionStateInDoubt()
            {
                return $.$$.System.Threading.LazyInitializer.EnsureInitialized$3($.$stl.System.Transactions.TransactionStateInDoubt, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStateInDoubt, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStateInDoubt = $v, $.$stl.System.Transactions.TransactionStateInDoubt), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$$.System.Object), new ($.$$.System.Func$$($.$stl.System.Transactions.TransactionStateInDoubt))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStateInDoubt().$ctor$3();
                }, {"r":6530316,"n":"","d":5743884,"h":0,"f":17825794}));
            }
            static /*TransactionStatePromoted */ get TransactionStatePromoted()
            {
                return $.$$.System.Threading.LazyInitializer.EnsureInitialized$3($.$stl.System.Transactions.TransactionStatePromoted, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromoted, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromoted = $v, $.$stl.System.Transactions.TransactionStatePromoted), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$$.System.Object), new ($.$$.System.Func$$($.$stl.System.Transactions.TransactionStatePromoted))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromoted().$ctor$3();
                }, {"r":6726924,"n":"","d":5743884,"h":0,"f":17825794}));
            }
            static /*TransactionStateNonCommittablePromoted */ get TransactionStateNonCommittablePromoted()
            {
                return $.$$.System.Threading.LazyInitializer.EnsureInitialized$3($.$stl.System.Transactions.TransactionStateNonCommittablePromoted, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStateNonCommittablePromoted, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStateNonCommittablePromoted = $v, $.$stl.System.Transactions.TransactionStateNonCommittablePromoted), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$$.System.Object), new ($.$$.System.Func$$($.$stl.System.Transactions.TransactionStateNonCommittablePromoted))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStateNonCommittablePromoted().$ctor$3();
                }, {"r":6595852,"n":"","d":5743884,"h":0,"f":17825794}));
            }
            static /*TransactionStatePromotedP0Wave */ get TransactionStatePromotedP0Wave()
            {
                return $.$$.System.Threading.LazyInitializer.EnsureInitialized$3($.$stl.System.Transactions.TransactionStatePromotedP0Wave, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedP0Wave, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedP0Wave = $v, $.$stl.System.Transactions.TransactionStatePromotedP0Wave), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$$.System.Object), new ($.$$.System.Func$$($.$stl.System.Transactions.TransactionStatePromotedP0Wave))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromotedP0Wave().$ctor$3();
                }, {"r":7841036,"n":"","d":5743884,"h":0,"f":17825794}));
            }
            static /*TransactionStatePromotedCommitting */ get TransactionStatePromotedCommitting()
            {
                return $.$$.System.Threading.LazyInitializer.EnsureInitialized$3($.$stl.System.Transactions.TransactionStatePromotedCommitting, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedCommitting, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedCommitting = $v, $.$stl.System.Transactions.TransactionStatePromotedCommitting), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$$.System.Object), new ($.$$.System.Func$$($.$stl.System.Transactions.TransactionStatePromotedCommitting))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromotedCommitting().$ctor$3();
                }, {"r":7054604,"n":"","d":5743884,"h":0,"f":17825794}));
            }
            static /*TransactionStatePromotedPhase0 */ get TransactionStatePromotedPhase0()
            {
                return $.$$.System.Threading.LazyInitializer.EnsureInitialized$3($.$stl.System.Transactions.TransactionStatePromotedPhase0, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedPhase0, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedPhase0 = $v, $.$stl.System.Transactions.TransactionStatePromotedPhase0), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$$.System.Object), new ($.$$.System.Func$$($.$stl.System.Transactions.TransactionStatePromotedPhase0))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromotedPhase0().$ctor$4();
                }, {"r":7972108,"n":"","d":5743884,"h":0,"f":17825794}));
            }
            static /*TransactionStatePromotedPhase1 */ get TransactionStatePromotedPhase1()
            {
                return $.$$.System.Threading.LazyInitializer.EnsureInitialized$3($.$stl.System.Transactions.TransactionStatePromotedPhase1, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedPhase1, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedPhase1 = $v, $.$stl.System.Transactions.TransactionStatePromotedPhase1), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$$.System.Object), new ($.$$.System.Func$$($.$stl.System.Transactions.TransactionStatePromotedPhase1))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromotedPhase1().$ctor$4();
                }, {"r":8037644,"n":"","d":5743884,"h":0,"f":17825794}));
            }
            static /*TransactionStatePromotedP0Aborting */ get TransactionStatePromotedP0Aborting()
            {
                return $.$$.System.Threading.LazyInitializer.EnsureInitialized$3($.$stl.System.Transactions.TransactionStatePromotedP0Aborting, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedP0Aborting, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedP0Aborting = $v, $.$stl.System.Transactions.TransactionStatePromotedP0Aborting), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$$.System.Object), new ($.$$.System.Func$$($.$stl.System.Transactions.TransactionStatePromotedP0Aborting))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromotedP0Aborting().$ctor$4();
                }, {"r":7775500,"n":"","d":5743884,"h":0,"f":17825794}));
            }
            static /*TransactionStatePromotedP1Aborting */ get TransactionStatePromotedP1Aborting()
            {
                return $.$$.System.Threading.LazyInitializer.EnsureInitialized$3($.$stl.System.Transactions.TransactionStatePromotedP1Aborting, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedP1Aborting, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedP1Aborting = $v, $.$stl.System.Transactions.TransactionStatePromotedP1Aborting), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$$.System.Object), new ($.$$.System.Func$$($.$stl.System.Transactions.TransactionStatePromotedP1Aborting))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromotedP1Aborting().$ctor$4();
                }, {"r":7906572,"n":"","d":5743884,"h":0,"f":17825794}));
            }
            static /*TransactionStatePromotedAborted */ get TransactionStatePromotedAborted()
            {
                return $.$$.System.Threading.LazyInitializer.EnsureInitialized$3($.$stl.System.Transactions.TransactionStatePromotedAborted, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedAborted, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedAborted = $v, $.$stl.System.Transactions.TransactionStatePromotedAborted), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$$.System.Object), new ($.$$.System.Func$$($.$stl.System.Transactions.TransactionStatePromotedAborted))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromotedAborted().$ctor$4();
                }, {"r":6792460,"n":"","d":5743884,"h":0,"f":17825794}));
            }
            static /*TransactionStatePromotedCommitted */ get TransactionStatePromotedCommitted()
            {
                return $.$$.System.Threading.LazyInitializer.EnsureInitialized$3($.$stl.System.Transactions.TransactionStatePromotedCommitted, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedCommitted, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedCommitted = $v, $.$stl.System.Transactions.TransactionStatePromotedCommitted), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$$.System.Object), new ($.$$.System.Func$$($.$stl.System.Transactions.TransactionStatePromotedCommitted))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromotedCommitted().$ctor$4();
                }, {"r":6989068,"n":"","d":5743884,"h":0,"f":17825794}));
            }
            static /*TransactionStatePromotedIndoubt */ get TransactionStatePromotedIndoubt()
            {
                return $.$$.System.Threading.LazyInitializer.EnsureInitialized$3($.$stl.System.Transactions.TransactionStatePromotedIndoubt, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedIndoubt, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedIndoubt = $v, $.$stl.System.Transactions.TransactionStatePromotedIndoubt), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$$.System.Object), new ($.$$.System.Func$$($.$stl.System.Transactions.TransactionStatePromotedIndoubt))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromotedIndoubt().$ctor$4();
                }, {"r":7185676,"n":"","d":5743884,"h":0,"f":17825794}));
            }
            static /*TransactionStateDelegated */ get TransactionStateDelegated()
            {
                return $.$$.System.Threading.LazyInitializer.EnsureInitialized$3($.$stl.System.Transactions.TransactionStateDelegated, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStateDelegated, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStateDelegated = $v, $.$stl.System.Transactions.TransactionStateDelegated), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$$.System.Object), new ($.$$.System.Func$$($.$stl.System.Transactions.TransactionStateDelegated))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStateDelegated().$ctor$5();
                }, {"r":6006028,"n":"","d":5743884,"h":0,"f":17825794}));
            }
            static /*TransactionStateDelegatedSubordinate */ get TransactionStateDelegatedSubordinate()
            {
                return $.$$.System.Threading.LazyInitializer.EnsureInitialized$3($.$stl.System.Transactions.TransactionStateDelegatedSubordinate, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStateDelegatedSubordinate, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStateDelegatedSubordinate = $v, $.$stl.System.Transactions.TransactionStateDelegatedSubordinate), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$$.System.Object), new ($.$$.System.Func$$($.$stl.System.Transactions.TransactionStateDelegatedSubordinate))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStateDelegatedSubordinate().$ctor$5();
                }, {"r":6399244,"n":"","d":5743884,"h":0,"f":17825794}));
            }
            static /*TransactionStateDelegatedP0Wave */ get TransactionStateDelegatedP0Wave()
            {
                return $.$$.System.Threading.LazyInitializer.EnsureInitialized$3($.$stl.System.Transactions.TransactionStateDelegatedP0Wave, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStateDelegatedP0Wave, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStateDelegatedP0Wave = $v, $.$stl.System.Transactions.TransactionStateDelegatedP0Wave), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$$.System.Object), new ($.$$.System.Func$$($.$stl.System.Transactions.TransactionStateDelegatedP0Wave))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStateDelegatedP0Wave().$ctor$4();
                }, {"r":6333708,"n":"","d":5743884,"h":0,"f":17825794}));
            }
            static /*TransactionStateDelegatedCommitting */ get TransactionStateDelegatedCommitting()
            {
                return $.$$.System.Threading.LazyInitializer.EnsureInitialized$3($.$stl.System.Transactions.TransactionStateDelegatedCommitting, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStateDelegatedCommitting, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStateDelegatedCommitting = $v, $.$stl.System.Transactions.TransactionStateDelegatedCommitting), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$$.System.Object), new ($.$$.System.Func$$($.$stl.System.Transactions.TransactionStateDelegatedCommitting))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStateDelegatedCommitting().$ctor$4();
                }, {"r":6202636,"n":"","d":5743884,"h":0,"f":17825794}));
            }
            static /*TransactionStateDelegatedAborting */ get TransactionStateDelegatedAborting()
            {
                return $.$$.System.Threading.LazyInitializer.EnsureInitialized$3($.$stl.System.Transactions.TransactionStateDelegatedAborting, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStateDelegatedAborting, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStateDelegatedAborting = $v, $.$stl.System.Transactions.TransactionStateDelegatedAborting), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$$.System.Object), new ($.$$.System.Func$$($.$stl.System.Transactions.TransactionStateDelegatedAborting))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStateDelegatedAborting().$ctor$5();
                }, {"r":6071564,"n":"","d":5743884,"h":0,"f":17825794}));
            }
            static /*TransactionStateDelegatedNonMSDTC */ get TransactionStateDelegatedNonMSDTC()
            {
                return $.$$.System.Threading.LazyInitializer.EnsureInitialized$3($.$stl.System.Transactions.TransactionStateDelegatedNonMSDTC, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStateDelegatedNonMSDTC, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStateDelegatedNonMSDTC = $v, $.$stl.System.Transactions.TransactionStateDelegatedNonMSDTC), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$$.System.Object), new ($.$$.System.Func$$($.$stl.System.Transactions.TransactionStateDelegatedNonMSDTC))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStateDelegatedNonMSDTC().$ctor$3();
                }, {"r":6268172,"n":"","d":5743884,"h":0,"f":17825794}));
            }
            static /*TransactionStatePromotedNonMSDTCPhase0 */ get TransactionStatePromotedNonMSDTCPhase0()
            {
                return $.$$.System.Threading.LazyInitializer.EnsureInitialized$3($.$stl.System.Transactions.TransactionStatePromotedNonMSDTCPhase0, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedNonMSDTCPhase0, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedNonMSDTCPhase0 = $v, $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCPhase0), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$$.System.Object), new ($.$$.System.Func$$($.$stl.System.Transactions.TransactionStatePromotedNonMSDTCPhase0))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCPhase0().$ctor$3();
                }, {"r":7578892,"n":"","d":5743884,"h":0,"f":17825794}));
            }
            static /*TransactionStatePromotedNonMSDTCVolatilePhase1 */ get TransactionStatePromotedNonMSDTCVolatilePhase1()
            {
                return $.$$.System.Threading.LazyInitializer.EnsureInitialized$3($.$stl.System.Transactions.TransactionStatePromotedNonMSDTCVolatilePhase1, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedNonMSDTCVolatilePhase1, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedNonMSDTCVolatilePhase1 = $v, $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCVolatilePhase1), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$$.System.Object), new ($.$$.System.Func$$($.$stl.System.Transactions.TransactionStatePromotedNonMSDTCVolatilePhase1))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCVolatilePhase1().$ctor$3();
                }, {"r":7709964,"n":"","d":5743884,"h":0,"f":17825794}));
            }
            static /*TransactionStatePromotedNonMSDTCSinglePhaseCommit */ get TransactionStatePromotedNonMSDTCSinglePhaseCommit()
            {
                return $.$$.System.Threading.LazyInitializer.EnsureInitialized$3($.$stl.System.Transactions.TransactionStatePromotedNonMSDTCSinglePhaseCommit, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedNonMSDTCSinglePhaseCommit, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedNonMSDTCSinglePhaseCommit = $v, $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCSinglePhaseCommit), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$$.System.Object), new ($.$$.System.Func$$($.$stl.System.Transactions.TransactionStatePromotedNonMSDTCSinglePhaseCommit))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCSinglePhaseCommit().$ctor$3();
                }, {"r":7644428,"n":"","d":5743884,"h":0,"f":17825794}));
            }
            static /*TransactionStatePromotedNonMSDTCAborted */ get TransactionStatePromotedNonMSDTCAborted()
            {
                return $.$$.System.Threading.LazyInitializer.EnsureInitialized$3($.$stl.System.Transactions.TransactionStatePromotedNonMSDTCAborted, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedNonMSDTCAborted, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedNonMSDTCAborted = $v, $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCAborted), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$$.System.Object), new ($.$$.System.Func$$($.$stl.System.Transactions.TransactionStatePromotedNonMSDTCAborted))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCAborted().$ctor$4();
                }, {"r":7251212,"n":"","d":5743884,"h":0,"f":17825794}));
            }
            static /*TransactionStatePromotedNonMSDTCCommitted */ get TransactionStatePromotedNonMSDTCCommitted()
            {
                return $.$$.System.Threading.LazyInitializer.EnsureInitialized$3($.$stl.System.Transactions.TransactionStatePromotedNonMSDTCCommitted, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedNonMSDTCCommitted, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedNonMSDTCCommitted = $v, $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCCommitted), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$$.System.Object), new ($.$$.System.Func$$($.$stl.System.Transactions.TransactionStatePromotedNonMSDTCCommitted))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCCommitted().$ctor$4();
                }, {"r":7382284,"n":"","d":5743884,"h":0,"f":17825794}));
            }
            static /*TransactionStatePromotedNonMSDTCIndoubt */ get TransactionStatePromotedNonMSDTCIndoubt()
            {
                return $.$$.System.Threading.LazyInitializer.EnsureInitialized$3($.$stl.System.Transactions.TransactionStatePromotedNonMSDTCIndoubt, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedNonMSDTCIndoubt, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedNonMSDTCIndoubt = $v, $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCIndoubt), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$$.System.Object), new ($.$$.System.Func$$($.$stl.System.Transactions.TransactionStatePromotedNonMSDTCIndoubt))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCIndoubt().$ctor$4();
                }, {"r":7513356,"n":"","d":5743884,"h":0,"f":17825794}));
            }
            /*void */ CommonEnterState(/*InternalTransaction*/ tx)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(tx.State !== this, "Changing to the same state.");
                tx.State = this;
                $.$$.System.Array.$WriteT1.call(tx._stateHistory, this, tx._currentStateHist);
                if (++tx._currentStateHist > 20/*InternalTransaction.MaxStateHist*/)
                {
                    tx._currentStateHist = 0;
                }
            }
            /*void */ BeginCommit(/*InternalTransaction*/ tx, /*bool*/ asyncCommit, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException(tx._innerException, tx.DistributedTxId);
            }
            /*void */ EndCommit(/*InternalTransaction*/ tx)
            {
                $.$$.System.Diagnostics.Debug.Fail$1(`Invalid Event for State; Current State: ${$.$$.System.Type.ToString.call($.$$.System.Object.GetType.call(this))}`);
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException(tx._innerException, tx.DistributedTxId);
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException(tx._innerException, tx.DistributedTxId);
            }
            /*Enlistment */ EnlistDurable(/*InternalTransaction*/ tx, /*Guid*/ resourceManagerIdentifier, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException(tx._innerException, tx.DistributedTxId);
            }
            /*Enlistment */ EnlistDurable$1(/*InternalTransaction*/ tx, /*Guid*/ resourceManagerIdentifier, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException(tx._innerException, tx.DistributedTxId);
            }
            /*Enlistment */ EnlistVolatile(/*InternalTransaction*/ tx, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException(tx._innerException, tx.DistributedTxId);
            }
            /*Enlistment */ EnlistVolatile$1(/*InternalTransaction*/ tx, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException(tx._innerException, tx.DistributedTxId);
            }
            /*void */ CheckForFinishedTransaction(/*InternalTransaction*/ tx)
            {
            }
            /*Guid */ get_Identifier(/*InternalTransaction*/ tx)
            {
                return $.$$.System.Guid.Empty;
            }
            /*void */ AddOutcomeRegistrant(/*InternalTransaction*/ tx, /*TransactionCompletedEventHandler?*/ transactionCompletedDelegate)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException(tx._innerException, tx.DistributedTxId);
            }
            /*void */ GetObjectData(/*InternalTransaction*/ tx, /*SerializationInfo*/ serializationInfo, /*StreamingContext*/ context)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException(tx._innerException, tx.DistributedTxId);
            }
            /*bool */ EnlistPromotableSinglePhase(/*InternalTransaction*/ tx, /*IPromotableSinglePhaseNotification*/ promotableSinglePhaseNotification, /*Transaction*/ atomicTransaction, /*Guid*/ promoterType)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException(tx._innerException, tx.DistributedTxId);
            }
            /*void */ CompleteBlockingClone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ CompleteAbortingClone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ CreateBlockingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException(tx._innerException, tx.DistributedTxId);
            }
            /*void */ CreateAbortingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException(tx._innerException, tx.DistributedTxId);
            }
            /*void */ ChangeStateTransactionAborted(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                $.$$.System.Diagnostics.Debug.Fail$1(`Invalid Event for State; Current State: ${$.$$.System.Type.ToString.call($.$$.System.Object.GetType.call(this))}`);
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace$1(0/*TransactionExceptionType.InvalidOperationException*/, (tx?.TransactionTraceId.TransactionIdentifier ?? null) ?? $.$$.System.String.Empty, $.$$.System.Exception.ToString.call(e));
                }
                throw new $.$$.System.InvalidOperationException().$ctor$9();
            }
            /*void */ ChangeStateTransactionCommitted(/*InternalTransaction*/ tx)
            {
                $.$$.System.Diagnostics.Debug.Fail$1(`Invalid Event for State; Current State: ${$.$$.System.Type.ToString.call($.$$.System.Object.GetType.call(this))}`);
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace$1(0/*TransactionExceptionType.InvalidOperationException*/, (tx?.TransactionTraceId.TransactionIdentifier ?? null) ?? $.$$.System.String.Empty, $.$$.System.String.Empty);
                }
                throw new $.$$.System.InvalidOperationException().$ctor$9();
            }
            /*void */ InDoubtFromEnlistment(/*InternalTransaction*/ tx)
            {
                $.$$.System.Diagnostics.Debug.Fail$1(`Invalid Event for State; Current State: ${$.$$.System.Type.ToString.call($.$$.System.Object.GetType.call(this))}`);
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace$1(0/*TransactionExceptionType.InvalidOperationException*/, (tx?.TransactionTraceId.TransactionIdentifier ?? null) ?? $.$$.System.String.Empty, $.$$.System.String.Empty);
                }
                throw new $.$$.System.InvalidOperationException().$ctor$9();
            }
            /*void */ ChangeStatePromotedAborted(/*InternalTransaction*/ tx)
            {
                $.$$.System.Diagnostics.Debug.Fail$1(`Invalid Event for State; Current State: ${$.$$.System.Type.ToString.call($.$$.System.Object.GetType.call(this))}`);
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace$1(0/*TransactionExceptionType.InvalidOperationException*/, (tx?.TransactionTraceId.TransactionIdentifier ?? null) ?? $.$$.System.String.Empty, $.$$.System.String.Empty);
                }
                throw new $.$$.System.InvalidOperationException().$ctor$9();
            }
            /*void */ ChangeStatePromotedCommitted(/*InternalTransaction*/ tx)
            {
                $.$$.System.Diagnostics.Debug.Fail$1(`Invalid Event for State; Current State: ${$.$$.System.Type.ToString.call($.$$.System.Object.GetType.call(this))}`);
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace$1(0/*TransactionExceptionType.InvalidOperationException*/, (tx?.TransactionTraceId.TransactionIdentifier ?? null) ?? $.$$.System.String.Empty, $.$$.System.String.Empty);
                }
                throw new $.$$.System.InvalidOperationException().$ctor$9();
            }
            /*void */ InDoubtFromDtc(/*InternalTransaction*/ tx)
            {
                $.$$.System.Diagnostics.Debug.Fail$1(`Invalid Event for State; Current State: ${$.$$.System.Type.ToString.call($.$$.System.Object.GetType.call(this))}`);
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace$1(0/*TransactionExceptionType.InvalidOperationException*/, (tx?.TransactionTraceId.TransactionIdentifier ?? null) ?? $.$$.System.String.Empty, $.$$.System.String.Empty);
                }
                throw new $.$$.System.InvalidOperationException().$ctor$9();
            }
            /*void */ ChangeStatePromotedPhase0(/*InternalTransaction*/ tx)
            {
                $.$$.System.Diagnostics.Debug.Fail$1(`Invalid Event for State; Current State: ${$.$$.System.Type.ToString.call($.$$.System.Object.GetType.call(this))}`);
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace$1(0/*TransactionExceptionType.InvalidOperationException*/, (tx?.TransactionTraceId.TransactionIdentifier ?? null) ?? $.$$.System.String.Empty, $.$$.System.String.Empty);
                }
                throw new $.$$.System.InvalidOperationException().$ctor$9();
            }
            /*void */ ChangeStatePromotedPhase1(/*InternalTransaction*/ tx)
            {
                $.$$.System.Diagnostics.Debug.Fail$1(`Invalid Event for State; Current State: ${$.$$.System.Type.ToString.call($.$$.System.Object.GetType.call(this))}`);
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace$1(0/*TransactionExceptionType.InvalidOperationException*/, (tx?.TransactionTraceId.TransactionIdentifier ?? null) ?? $.$$.System.String.Empty, $.$$.System.String.Empty);
                }
                throw new $.$$.System.InvalidOperationException().$ctor$9();
            }
            /*void */ ChangeStateAbortedDuringPromotion(/*InternalTransaction*/ tx)
            {
                $.$$.System.Diagnostics.Debug.Fail$1(`Invalid Event for State; Current State: ${$.$$.System.Type.ToString.call($.$$.System.Object.GetType.call(this))}`);
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace$1(0/*TransactionExceptionType.InvalidOperationException*/, (tx?.TransactionTraceId.TransactionIdentifier ?? null) ?? $.$$.System.String.Empty, $.$$.System.String.Empty);
                }
                throw new $.$$.System.InvalidOperationException().$ctor$9();
            }
            /*void */ Timeout(/*InternalTransaction*/ tx)
            {
            }
            /*void */ Phase0VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
                $.$$.System.Diagnostics.Debug.Fail$1(`Invalid Event for State; Current State: ${$.$$.System.Type.ToString.call($.$$.System.Object.GetType.call(this))}`);
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException(tx._innerException, tx.DistributedTxId);
            }
            /*void */ Phase1VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
                $.$$.System.Diagnostics.Debug.Fail$1(`Invalid Event for State; Current State: ${$.$$.System.Type.ToString.call($.$$.System.Object.GetType.call(this))}`);
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException(tx._innerException, tx.DistributedTxId);
            }
            /*void */ RestartCommitIfNeeded(/*InternalTransaction*/ tx)
            {
                $.$$.System.Diagnostics.Debug.Fail$1(`Invalid Event for State; Current State: ${$.$$.System.Type.ToString.call($.$$.System.Object.GetType.call(this))}`);
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace$1(0/*TransactionExceptionType.InvalidOperationException*/, (tx?.TransactionTraceId.TransactionIdentifier ?? null) ?? $.$$.System.String.Empty, $.$$.System.String.Empty);
                }
                throw new $.$$.System.InvalidOperationException().$ctor$9();
            }
            /*bool */ ContinuePhase0Prepares()
            {
                return false;
            }
            /*bool */ ContinuePhase1Prepares()
            {
                return false;
            }
            /*void */ Promote(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException(tx._innerException, tx.DistributedTxId);
            }
            /*byte[] */ PromotedToken(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException(tx._innerException, tx.DistributedTxId);
            }
            /*Enlistment */ PromoteAndEnlistDurable(/*InternalTransaction*/ tx, /*Guid*/ resourceManagerIdentifier, /*IPromotableSinglePhaseNotification*/ promotableNotification, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException(tx._innerException, tx.DistributedTxId);
            }
            /*void */ SetDistributedTransactionId(/*InternalTransaction*/ tx, /*IPromotableSinglePhaseNotification*/ promotableNotification, /*Guid*/ distributedTransactionIdentifier)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException(tx._innerException, tx.DistributedTxId);
            }
            /*void */ DisposeRoot(/*InternalTransaction*/ tx)
            {
            }
            /*bool */ IsCompleted(/*InternalTransaction*/ tx)
            {
                tx._needPulse = true;
                return false;
            }
            static /*void */ AddVolatileEnlistment(/*ref VolatileEnlistmentSet*/ enlistments, /*Enlistment*/ enlistment)
            {
                if (enlistments.$v._volatileEnlistmentCount === enlistments.$v._volatileEnlistmentSize)
                {
                    /*InternalEnlistment[]*/ let newEnlistments = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$stl.System.Transactions.InternalEnlistment), null, [((enlistments.$v._volatileEnlistmentSize + 8/*InternalTransaction.VolatileArrayIncrement*/) | 0)], null);
                    if (enlistments.$v._volatileEnlistmentSize > 0)
                    {
                        $.$$.System.Array.Copy$2(enlistments.$v._volatileEnlistments, 0, newEnlistments, 0, enlistments.$v._volatileEnlistmentSize);
                    }
                    enlistments.$v._volatileEnlistmentSize += 8/*InternalTransaction.VolatileArrayIncrement*/;
                    enlistments.$v._volatileEnlistments = newEnlistments;
                }
                $.$$.System.Array.$WriteT1.call(enlistments.$v._volatileEnlistments, enlistment.InternalEnlistment, enlistments.$v._volatileEnlistmentCount);
                enlistments.$v._volatileEnlistmentCount++;
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentActive.EnterState($.$$.System.Array.$ReadT1.call(enlistments.$v._volatileEnlistments, ((enlistments.$v._volatileEnlistmentCount - 1) | 0)));
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 5743884;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":5874956,"g":{"r":0,"d":0,"h":154624566540,"f":50331688},"n":"TransactionStateActive","d":5743884,"h":150329599244,"f":2097192},{"p":8234252,"g":{"r":0,"d":0,"h":163214501132,"f":50331688},"n":"TransactionStateSubordinateActive","d":5743884,"h":158919533836,"f":2097192},{"p":8103180,"g":{"r":0,"d":0,"h":171804435724,"f":50331688},"n":"TransactionStatePSPEOperation","d":5743884,"h":167509468428,"f":2097192},{"p":6661388,"g":{"r":0,"d":0,"h":180394370316,"f":50331684},"n":"TransactionStatePhase0","d":5743884,"h":176099403020,"f":2097188},{"p":8299788,"g":{"r":0,"d":0,"h":188984304908,"f":50331684},"n":"TransactionStateVolatilePhase1","d":5743884,"h":184689337612,"f":2097188},{"p":8365324,"g":{"r":0,"d":0,"h":197574239500,"f":50331684},"n":"TransactionStateVolatileSPC","d":5743884,"h":193279272204,"f":2097188},{"p":8168716,"g":{"r":0,"d":0,"h":206164174092,"f":50331684},"n":"TransactionStateSPC","d":5743884,"h":201869206796,"f":2097188},{"p":5809420,"g":{"r":0,"d":0,"h":214754108684,"f":50331684},"n":"TransactionStateAborted","d":5743884,"h":210459141388,"f":2097188},{"p":5940492,"g":{"r":0,"d":0,"h":223344043276,"f":50331684},"n":"TransactionStateCommitted","d":5743884,"h":219049075980,"f":2097188},{"p":6530316,"g":{"r":0,"d":0,"h":231933977868,"f":50331684},"n":"TransactionStateInDoubt","d":5743884,"h":227639010572,"f":2097188},{"p":6726924,"g":{"r":0,"d":0,"h":240523912460,"f":50331688},"n":"TransactionStatePromoted","d":5743884,"h":236228945164,"f":2097192},{"p":6595852,"g":{"r":0,"d":0,"h":249113847052,"f":50331688},"n":"TransactionStateNonCommittablePromoted","d":5743884,"h":244818879756,"f":2097192},{"p":7841036,"g":{"r":0,"d":0,"h":257703781644,"f":50331684},"n":"TransactionStatePromotedP0Wave","d":5743884,"h":253408814348,"f":2097188},{"p":7054604,"g":{"r":0,"d":0,"h":266293716236,"f":50331684},"n":"TransactionStatePromotedCommitting","d":5743884,"h":261998748940,"f":2097188},{"p":7972108,"g":{"r":0,"d":0,"h":274883650828,"f":50331684},"n":"TransactionStatePromotedPhase0","d":5743884,"h":270588683532,"f":2097188},{"p":8037644,"g":{"r":0,"d":0,"h":283473585420,"f":50331684},"n":"TransactionStatePromotedPhase1","d":5743884,"h":279178618124,"f":2097188},{"p":7775500,"g":{"r":0,"d":0,"h":292063520012,"f":50331684},"n":"TransactionStatePromotedP0Aborting","d":5743884,"h":287768552716,"f":2097188},{"p":7906572,"g":{"r":0,"d":0,"h":300653454604,"f":50331684},"n":"TransactionStatePromotedP1Aborting","d":5743884,"h":296358487308,"f":2097188},{"p":6792460,"g":{"r":0,"d":0,"h":309243389196,"f":50331684},"n":"TransactionStatePromotedAborted","d":5743884,"h":304948421900,"f":2097188},{"p":6989068,"g":{"r":0,"d":0,"h":317833323788,"f":50331684},"n":"TransactionStatePromotedCommitted","d":5743884,"h":313538356492,"f":2097188},{"p":7185676,"g":{"r":0,"d":0,"h":326423258380,"f":50331684},"n":"TransactionStatePromotedIndoubt","d":5743884,"h":322128291084,"f":2097188},{"p":6006028,"g":{"r":0,"d":0,"h":335013192972,"f":50331684},"n":"TransactionStateDelegated","d":5743884,"h":330718225676,"f":2097188},{"p":6399244,"g":{"r":0,"d":0,"h":343603127564,"f":50331688},"n":"TransactionStateDelegatedSubordinate","d":5743884,"h":339308160268,"f":2097192},{"p":6333708,"g":{"r":0,"d":0,"h":352193062156,"f":50331684},"n":"TransactionStateDelegatedP0Wave","d":5743884,"h":347898094860,"f":2097188},{"p":6202636,"g":{"r":0,"d":0,"h":360782996748,"f":50331684},"n":"TransactionStateDelegatedCommitting","d":5743884,"h":356488029452,"f":2097188},{"p":6071564,"g":{"r":0,"d":0,"h":369372931340,"f":50331684},"n":"TransactionStateDelegatedAborting","d":5743884,"h":365077964044,"f":2097188},{"p":6268172,"g":{"r":0,"d":0,"h":377962865932,"f":50331684},"n":"TransactionStateDelegatedNonMSDTC","d":5743884,"h":373667898636,"f":2097188},{"p":7578892,"g":{"r":0,"d":0,"h":386552800524,"f":50331684},"n":"TransactionStatePromotedNonMSDTCPhase0","d":5743884,"h":382257833228,"f":2097188},{"p":7709964,"g":{"r":0,"d":0,"h":395142735116,"f":50331684},"n":"TransactionStatePromotedNonMSDTCVolatilePhase1","d":5743884,"h":390847767820,"f":2097188},{"p":7644428,"g":{"r":0,"d":0,"h":403732669708,"f":50331684},"n":"TransactionStatePromotedNonMSDTCSinglePhaseCommit","d":5743884,"h":399437702412,"f":2097188},{"p":7251212,"g":{"r":0,"d":0,"h":412322604300,"f":50331684},"n":"TransactionStatePromotedNonMSDTCAborted","d":5743884,"h":408027637004,"f":2097188},{"p":7382284,"g":{"r":0,"d":0,"h":420912538892,"f":50331684},"n":"TransactionStatePromotedNonMSDTCCommitted","d":5743884,"h":416617571596,"f":2097188},{"p":7513356,"g":{"r":0,"d":0,"h":429502473484,"f":50331684},"n":"TransactionStatePromotedNonMSDTCIndoubt","d":5743884,"h":425207506188,"f":2097188}],"m":[{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"CommonEnterState","d":5743884,"h":433797440780,"f":16777224},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"EnterState","d":5743884,"h":438092408076,"f":16777480},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"asyncCommit","p":262145},{"n":"asyncCallback","p":14548993},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":5743884,"h":442387375372,"f":16777352},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"EndCommit","d":5743884,"h":446682342668,"f":16777352},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"e","p":47251457}],"n":"Rollback","d":5743884,"h":450977309964,"f":16777352},{"r":1746188,"p":[{"n":"tx","p":2794764},{"n":"resourceManagerIdentifier","p":56229889},{"n":"enlistmentNotification","p":2598156},{"n":"enlistmentOptions","p":1877260},{"n":"atomicTransaction","p":4302092}],"n":"EnlistDurable","d":5743884,"h":455272277260,"f":16777352},{"r":1746188,"p":[{"n":"tx","p":2794764},{"n":"resourceManagerIdentifier","p":56229889},{"n":"enlistmentNotification","p":3056908},{"n":"enlistmentOptions","p":1877260},{"n":"atomicTransaction","p":4302092}],"n":"EnlistDurable","o":"@$1","d":5743884,"h":459567244556,"f":16777352},{"r":1746188,"p":[{"n":"tx","p":2794764},{"n":"enlistmentNotification","p":2598156},{"n":"enlistmentOptions","p":1877260},{"n":"atomicTransaction","p":4302092}],"n":"EnlistVolatile","d":5743884,"h":463862211852,"f":16777352},{"r":1746188,"p":[{"n":"tx","p":2794764},{"n":"enlistmentNotification","p":3056908},{"n":"enlistmentOptions","p":1877260},{"n":"atomicTransaction","p":4302092}],"n":"EnlistVolatile","o":"@$1","d":5743884,"h":468157179148,"f":16777352},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"CheckForFinishedTransaction","d":5743884,"h":472452146444,"f":16777352},{"r":56229889,"p":[{"n":"tx","p":2794764}],"n":"get_Identifier","d":5743884,"h":476747113740,"f":16777352},{"r":8430860,"p":[{"n":"tx","p":2794764}],"n":"get_Status","d":5743884,"h":481042081036,"f":16777480},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"transactionCompletedDelegate","p":4433164}],"n":"AddOutcomeRegistrant","d":5743884,"h":485337048332,"f":16777352},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"serializationInfo","p":113836033},{"n":"context","p":113967105}],"n":"GetObjectData","d":5743884,"h":489632015628,"f":16777352},{"r":262145,"p":[{"n":"tx","p":2794764},{"n":"promotableSinglePhaseNotification","p":2860300},{"n":"atomicTransaction","p":4302092},{"n":"promoterType","p":56229889}],"n":"EnlistPromotableSinglePhase","d":5743884,"h":493926982924,"f":16777352},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"CompleteBlockingClone","d":5743884,"h":498221950220,"f":16777352},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"CompleteAbortingClone","d":5743884,"h":502516917516,"f":16777352},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"CreateBlockingClone","d":5743884,"h":506811884812,"f":16777352},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"CreateAbortingClone","d":5743884,"h":511106852108,"f":16777352},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"e","p":47251457}],"n":"ChangeStateTransactionAborted","d":5743884,"h":515401819404,"f":16777352},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"ChangeStateTransactionCommitted","d":5743884,"h":519696786700,"f":16777352},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"InDoubtFromEnlistment","d":5743884,"h":523991753996,"f":16777352},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"ChangeStatePromotedAborted","d":5743884,"h":528286721292,"f":16777352},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"ChangeStatePromotedCommitted","d":5743884,"h":532581688588,"f":16777352},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"InDoubtFromDtc","d":5743884,"h":536876655884,"f":16777352},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"ChangeStatePromotedPhase0","d":5743884,"h":541171623180,"f":16777352},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"ChangeStatePromotedPhase1","d":5743884,"h":545466590476,"f":16777352},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"ChangeStateAbortedDuringPromotion","d":5743884,"h":549761557772,"f":16777352},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"Timeout","d":5743884,"h":554056525068,"f":16777352},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"Phase0VolatilePrepareDone","d":5743884,"h":558351492364,"f":16777352},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"Phase1VolatilePrepareDone","d":5743884,"h":562646459660,"f":16777352},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"RestartCommitIfNeeded","d":5743884,"h":566941426956,"f":16777352},{"r":262145,"n":"ContinuePhase0Prepares","d":5743884,"h":571236394252,"f":16777352},{"r":262145,"n":"ContinuePhase1Prepares","d":5743884,"h":575531361548,"f":16777352},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"Promote","d":5743884,"h":579826328844,"f":16777352},{"r":$.$typeArray($.$$.System.Byte).$h,"p":[{"n":"tx","p":2794764}],"n":"PromotedToken","d":5743884,"h":584121296140,"f":16777352},{"r":1746188,"p":[{"n":"tx","p":2794764},{"n":"resourceManagerIdentifier","p":56229889},{"n":"promotableNotification","p":2860300},{"n":"enlistmentNotification","p":3056908},{"n":"enlistmentOptions","p":1877260},{"n":"atomicTransaction","p":4302092}],"n":"PromoteAndEnlistDurable","d":5743884,"h":588416263436,"f":16777352},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"promotableNotification","p":2860300},{"n":"distributedTransactionIdentifier","p":56229889}],"n":"SetDistributedTransactionId","d":5743884,"h":592711230732,"f":16777352},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"DisposeRoot","d":5743884,"h":597006198028,"f":16777352},{"r":262145,"p":[{"n":"tx","p":2794764}],"n":"IsCompleted","d":5743884,"h":601301165324,"f":16777352},{"r":65537,"p":[{"n":"enlistments","p":9348364,"f":4},{"n":"enlistment","p":1746188}],"n":"AddVolatileEnlistment","d":5743884,"h":605596132620,"f":16777252}],"l":[{"t":5874956,"n":"s_transactionStateActive","d":5743884,"h":4300711180,"f":4194338},{"t":8234252,"n":"s_transactionStateSubordinateActive","d":5743884,"h":8595678476,"f":4194338},{"t":6661388,"n":"s_transactionStatePhase0","d":5743884,"h":12890645772,"f":4194338},{"t":8299788,"n":"s_transactionStateVolatilePhase1","d":5743884,"h":17185613068,"f":4194338},{"t":8365324,"n":"s_transactionStateVolatileSPC","d":5743884,"h":21480580364,"f":4194338},{"t":8168716,"n":"s_transactionStateSPC","d":5743884,"h":25775547660,"f":4194338},{"t":5809420,"n":"s_transactionStateAborted","d":5743884,"h":30070514956,"f":4194338},{"t":5940492,"n":"s_transactionStateCommitted","d":5743884,"h":34365482252,"f":4194338},{"t":6530316,"n":"s_transactionStateInDoubt","d":5743884,"h":38660449548,"f":4194338},{"t":6726924,"n":"s_transactionStatePromoted","d":5743884,"h":42955416844,"f":4194338},{"t":6595852,"n":"s_transactionStateNonCommittablePromoted","d":5743884,"h":47250384140,"f":4194338},{"t":7841036,"n":"s_transactionStatePromotedP0Wave","d":5743884,"h":51545351436,"f":4194338},{"t":7054604,"n":"s_transactionStatePromotedCommitting","d":5743884,"h":55840318732,"f":4194338},{"t":7972108,"n":"s_transactionStatePromotedPhase0","d":5743884,"h":60135286028,"f":4194338},{"t":8037644,"n":"s_transactionStatePromotedPhase1","d":5743884,"h":64430253324,"f":4194338},{"t":7775500,"n":"s_transactionStatePromotedP0Aborting","d":5743884,"h":68725220620,"f":4194338},{"t":7906572,"n":"s_transactionStatePromotedP1Aborting","d":5743884,"h":73020187916,"f":4194338},{"t":6792460,"n":"s_transactionStatePromotedAborted","d":5743884,"h":77315155212,"f":4194338},{"t":6989068,"n":"s_transactionStatePromotedCommitted","d":5743884,"h":81610122508,"f":4194338},{"t":7185676,"n":"s_transactionStatePromotedIndoubt","d":5743884,"h":85905089804,"f":4194338},{"t":6006028,"n":"s_transactionStateDelegated","d":5743884,"h":90200057100,"f":4194338},{"t":6399244,"n":"s_transactionStateDelegatedSubordinate","d":5743884,"h":94495024396,"f":4194338},{"t":6333708,"n":"s_transactionStateDelegatedP0Wave","d":5743884,"h":98789991692,"f":4194338},{"t":6202636,"n":"s_transactionStateDelegatedCommitting","d":5743884,"h":103084958988,"f":4194338},{"t":6071564,"n":"s_transactionStateDelegatedAborting","d":5743884,"h":107379926284,"f":4194338},{"t":8103180,"n":"s_transactionStatePSPEOperation","d":5743884,"h":111674893580,"f":4194338},{"t":6268172,"n":"s_transactionStateDelegatedNonMSDTC","d":5743884,"h":115969860876,"f":4194338},{"t":7578892,"n":"s_transactionStatePromotedNonMSDTCPhase0","d":5743884,"h":120264828172,"f":4194338},{"t":7709964,"n":"s_transactionStatePromotedNonMSDTCVolatilePhase1","d":5743884,"h":124559795468,"f":4194338},{"t":7644428,"n":"s_transactionStatePromotedNonMSDTCSinglePhaseCommit","d":5743884,"h":128854762764,"f":4194338},{"t":7251212,"n":"s_transactionStatePromotedNonMSDTCAborted","d":5743884,"h":133149730060,"f":4194338},{"t":7382284,"n":"s_transactionStatePromotedNonMSDTCCommitted","d":5743884,"h":137444697356,"f":4194338},{"t":7513356,"n":"s_transactionStatePromotedNonMSDTCIndoubt","d":5743884,"h":141739664652,"f":4194338},{"t":131073,"n":"s_classSyncObject","d":5743884,"h":146034631948,"f":4194344}],"c":[{"n":".ctor","o":"$ctor$1","d":5743884,"h":609891099916,"f":16777220}],"h":5743884}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Transactions.TransactionState`; }
        });
        
        $asm.$cls("$stl.System.Transactions.VolatileDemultiplexer", ($self) => class VolatileDemultiplexer extends $.$$.System.Object
        {
            /*InternalTransaction*/ _transaction = null;
            /*IPromotedEnlistment?*/ _promotedEnlistment = null;
            /*IPromotedEnlistment?*/ _preparingEnlistment = null;
            $ctor$1(/*InternalTransaction*/ transaction)
            {
                super.$ctor();
                {
                    this._transaction = transaction;
                }
                return this;
            }
            static /*void */ BroadcastCommitted(/*ref VolatileEnlistmentSet*/ volatiles)
            {
                for(/*int*/ let i = 0; i < volatiles.$v._volatileEnlistmentCount; i++)
                {
                    $.$$.System.Array.$ReadT1.call(volatiles.$v._volatileEnlistments, i)._twoPhaseState.InternalCommitted($.$$.System.Array.$ReadT1.call(volatiles.$v._volatileEnlistments, i));
                }
            }
            static /*void */ BroadcastRollback(/*ref VolatileEnlistmentSet*/ volatiles)
            {
                for(/*int*/ let i = 0; i < volatiles.$v._volatileEnlistmentCount; i++)
                {
                    $.$$.System.Array.$ReadT1.call(volatiles.$v._volatileEnlistments, i)._twoPhaseState.InternalAborted($.$$.System.Array.$ReadT1.call(volatiles.$v._volatileEnlistments, i));
                }
            }
            static /*void */ BroadcastInDoubt(/*ref VolatileEnlistmentSet*/ volatiles)
            {
                for(/*int*/ let i = 0; i < volatiles.$v._volatileEnlistmentCount; i++)
                {
                    $.$$.System.Array.$ReadT1.call(volatiles.$v._volatileEnlistments, i)._twoPhaseState.InternalIndoubt($.$$.System.Array.$ReadT1.call(volatiles.$v._volatileEnlistments, i));
                }
            }
            /*object?*/ static s_classSyncObject = null;
            static /*object */ get ClassSyncObject()
            {
                if ($.$stl.System.Transactions.VolatileDemultiplexer.s_classSyncObject === null)
                {
                    /*object*/ let o = new $.$$.System.Object().$ctor();
                    $.$$.System.Threading.Interlocked.CompareExchange$6($.$ref(() => $.$stl.System.Transactions.VolatileDemultiplexer.s_classSyncObject, ($v) => $.$stl.System.Transactions.VolatileDemultiplexer.s_classSyncObject = $v, $.$$.System.Object), o, null);
                }
                return $.$stl.System.Transactions.VolatileDemultiplexer.s_classSyncObject;
            }
            /*WaitCallback?*/ static s_prepareCallback = null;
            static /*WaitCallback */ get PrepareCallback()
            {
                return $.$$.System.Threading.LazyInitializer.EnsureInitialized$3($.$$.System.Threading.WaitCallback, $.$ref(() => $.$stl.System.Transactions.VolatileDemultiplexer.s_prepareCallback, ($v) => $.$stl.System.Transactions.VolatileDemultiplexer.s_prepareCallback = $v, $.$$.System.Threading.WaitCallback), $.$ref(() => $.$stl.System.Transactions.VolatileDemultiplexer.s_classSyncObject, ($v) => $.$stl.System.Transactions.VolatileDemultiplexer.s_classSyncObject = $v, $.$$.System.Object), new ($.$$.System.Func$$($.$$.System.Threading.WaitCallback))().$ctor(this,  () =>
                {
                    return $.$stl.System.Transactions.VolatileDemultiplexer.PoolablePrepare;
                }, {"r":138936321,"n":"","d":8693004,"h":0,"f":17825794}));
            }
            static /*void */ PoolablePrepare(/*object*/ state)
            {
                /*VolatileDemultiplexer*/ let demux = $.$cast(state, $.$stl.System.Transactions.VolatileDemultiplexer);
                /*bool*/ let tookLock = false;
                try
                {
                    $.$$.System.Threading.Monitor.TryEnter(demux._transaction, 250, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => tookLock, ($v) => tookLock = $v, null));
                    if (tookLock)
                    {
                        demux.InternalPrepare();
                    }
                    else 
                    {
                        if (!$.$$.System.Threading.ThreadPool.QueueUserWorkItem($.$stl.System.Transactions.VolatileDemultiplexer.PrepareCallback, demux))
                        {
                            throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException$1(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.UnexpectedFailureOfThreadPool, null);
                        }
                    }
                }
                finally
                {
                    {
                        if (tookLock)
                        {
                            $.$$.System.Threading.Monitor.Exit(demux._transaction);
                        }
                    }
                }
            }
            /*WaitCallback?*/ static s_commitCallback = null;
            static /*WaitCallback */ get CommitCallback()
            {
                return $.$$.System.Threading.LazyInitializer.EnsureInitialized$3($.$$.System.Threading.WaitCallback, $.$ref(() => $.$stl.System.Transactions.VolatileDemultiplexer.s_commitCallback, ($v) => $.$stl.System.Transactions.VolatileDemultiplexer.s_commitCallback = $v, $.$$.System.Threading.WaitCallback), $.$ref(() => $.$stl.System.Transactions.VolatileDemultiplexer.s_classSyncObject, ($v) => $.$stl.System.Transactions.VolatileDemultiplexer.s_classSyncObject = $v, $.$$.System.Object), new ($.$$.System.Func$$($.$$.System.Threading.WaitCallback))().$ctor(this,  () =>
                {
                    return $.$stl.System.Transactions.VolatileDemultiplexer.PoolableCommit;
                }, {"r":138936321,"n":"","d":8693004,"h":0,"f":17825794}));
            }
            static /*void */ PoolableCommit(/*object*/ state)
            {
                /*VolatileDemultiplexer*/ let demux = $.$cast(state, $.$stl.System.Transactions.VolatileDemultiplexer);
                /*bool*/ let tookLock = false;
                try
                {
                    $.$$.System.Threading.Monitor.TryEnter(demux._transaction, 250, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => tookLock, ($v) => tookLock = $v, null));
                    if (tookLock)
                    {
                        demux.InternalCommit();
                    }
                    else 
                    {
                        if (!$.$$.System.Threading.ThreadPool.QueueUserWorkItem($.$stl.System.Transactions.VolatileDemultiplexer.CommitCallback, demux))
                        {
                            throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException$1(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.UnexpectedFailureOfThreadPool, null);
                        }
                    }
                }
                finally
                {
                    {
                        if (tookLock)
                        {
                            $.$$.System.Threading.Monitor.Exit(demux._transaction);
                        }
                    }
                }
            }
            /*WaitCallback?*/ static s_rollbackCallback = null;
            static /*WaitCallback */ get RollbackCallback()
            {
                return $.$$.System.Threading.LazyInitializer.EnsureInitialized$3($.$$.System.Threading.WaitCallback, $.$ref(() => $.$stl.System.Transactions.VolatileDemultiplexer.s_rollbackCallback, ($v) => $.$stl.System.Transactions.VolatileDemultiplexer.s_rollbackCallback = $v, $.$$.System.Threading.WaitCallback), $.$ref(() => $.$stl.System.Transactions.VolatileDemultiplexer.s_classSyncObject, ($v) => $.$stl.System.Transactions.VolatileDemultiplexer.s_classSyncObject = $v, $.$$.System.Object), new ($.$$.System.Func$$($.$$.System.Threading.WaitCallback))().$ctor(this,  () =>
                {
                    return $.$stl.System.Transactions.VolatileDemultiplexer.PoolableRollback;
                }, {"r":138936321,"n":"","d":8693004,"h":0,"f":17825794}));
            }
            static /*void */ PoolableRollback(/*object*/ state)
            {
                /*VolatileDemultiplexer*/ let demux = $.$cast(state, $.$stl.System.Transactions.VolatileDemultiplexer);
                /*bool*/ let tookLock = false;
                try
                {
                    $.$$.System.Threading.Monitor.TryEnter(demux._transaction, 250, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => tookLock, ($v) => tookLock = $v, null));
                    if (tookLock)
                    {
                        demux.InternalRollback();
                    }
                    else 
                    {
                        if (!$.$$.System.Threading.ThreadPool.QueueUserWorkItem($.$stl.System.Transactions.VolatileDemultiplexer.RollbackCallback, demux))
                        {
                            throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException$1(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.UnexpectedFailureOfThreadPool, null);
                        }
                    }
                }
                finally
                {
                    {
                        if (tookLock)
                        {
                            $.$$.System.Threading.Monitor.Exit(demux._transaction);
                        }
                    }
                }
            }
            /*WaitCallback?*/ static s_inDoubtCallback = null;
            static /*WaitCallback */ get InDoubtCallback()
            {
                return $.$$.System.Threading.LazyInitializer.EnsureInitialized$3($.$$.System.Threading.WaitCallback, $.$ref(() => $.$stl.System.Transactions.VolatileDemultiplexer.s_inDoubtCallback, ($v) => $.$stl.System.Transactions.VolatileDemultiplexer.s_inDoubtCallback = $v, $.$$.System.Threading.WaitCallback), $.$ref(() => $.$stl.System.Transactions.VolatileDemultiplexer.s_classSyncObject, ($v) => $.$stl.System.Transactions.VolatileDemultiplexer.s_classSyncObject = $v, $.$$.System.Object), new ($.$$.System.Func$$($.$$.System.Threading.WaitCallback))().$ctor(this,  () =>
                {
                    return $.$stl.System.Transactions.VolatileDemultiplexer.PoolableInDoubt;
                }, {"r":138936321,"n":"","d":8693004,"h":0,"f":17825794}));
            }
            static /*void */ PoolableInDoubt(/*object*/ state)
            {
                /*VolatileDemultiplexer*/ let demux = $.$cast(state, $.$stl.System.Transactions.VolatileDemultiplexer);
                /*bool*/ let tookLock = false;
                try
                {
                    $.$$.System.Threading.Monitor.TryEnter(demux._transaction, 250, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => tookLock, ($v) => tookLock = $v, null));
                    if (tookLock)
                    {
                        demux.InternalInDoubt();
                    }
                    else 
                    {
                        if (!$.$$.System.Threading.ThreadPool.QueueUserWorkItem($.$stl.System.Transactions.VolatileDemultiplexer.InDoubtCallback, demux))
                        {
                            throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException$1(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.UnexpectedFailureOfThreadPool, null);
                        }
                    }
                }
                finally
                {
                    {
                        if (tookLock)
                        {
                            $.$$.System.Threading.Monitor.Exit(demux._transaction);
                        }
                    }
                }
            }
            //Generated interface implemetation for System.Transactions.IEnlistmentNotificationInternal.Prepare(System.Transactions.IPromotedEnlistment)
            System$Transactions$IEnlistmentNotificationInternal$Prepare()
            {
                return this.Prepare(...arguments);
            }
            //Generated interface implemetation for System.Transactions.IEnlistmentNotificationInternal.Commit(System.Transactions.IPromotedEnlistment)
            System$Transactions$IEnlistmentNotificationInternal$Commit()
            {
                return this.Commit(...arguments);
            }
            //Generated interface implemetation for System.Transactions.IEnlistmentNotificationInternal.Rollback(System.Transactions.IPromotedEnlistment)
            System$Transactions$IEnlistmentNotificationInternal$Rollback()
            {
                return this.Rollback(...arguments);
            }
            //Generated interface implemetation for System.Transactions.IEnlistmentNotificationInternal.InDoubt(System.Transactions.IPromotedEnlistment)
            System$Transactions$IEnlistmentNotificationInternal$InDoubt()
            {
                return this.InDoubt(...arguments);
            }
            static $h = 8693004;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":131073,"g":{"r":0,"d":0,"h":42958365964,"f":50331688},"n":"ClassSyncObject","d":8693004,"h":38663398668,"f":2097192},{"p":138936321,"g":{"r":0,"d":0,"h":55843267852,"f":50331682},"n":"PrepareCallback","d":8693004,"h":51548300556,"f":2097186},{"p":138936321,"g":{"r":0,"d":0,"h":73023137036,"f":50331682},"n":"CommitCallback","d":8693004,"h":68728169740,"f":2097186},{"p":138936321,"g":{"r":0,"d":0,"h":90203006220,"f":50331682},"n":"RollbackCallback","d":8693004,"h":85908038924,"f":2097186},{"p":138936321,"g":{"r":0,"d":0,"h":107382875404,"f":50331682},"n":"InDoubtCallback","d":8693004,"h":103087908108,"f":2097186}],"m":[{"r":65537,"p":[{"n":"volatiles","p":9348364,"f":4}],"n":"BroadcastCommitted","d":8693004,"h":21483529484,"f":16777256},{"r":65537,"p":[{"n":"volatiles","p":9348364,"f":4}],"n":"BroadcastRollback","d":8693004,"h":25778496780,"f":16777256},{"r":65537,"p":[{"n":"volatiles","p":9348364,"f":4}],"n":"BroadcastInDoubt","d":8693004,"h":30073464076,"f":16777256},{"r":65537,"p":[{"n":"state","p":131073}],"n":"PoolablePrepare","d":8693004,"h":60138235148,"f":16777252},{"r":65537,"p":[{"n":"state","p":131073}],"n":"PoolableCommit","d":8693004,"h":77318104332,"f":16777252},{"r":65537,"p":[{"n":"state","p":131073}],"n":"PoolableRollback","d":8693004,"h":94497973516,"f":16777252},{"r":65537,"p":[{"n":"state","p":131073}],"n":"PoolableInDoubt","d":8693004,"h":111677842700,"f":16777252},{"r":65537,"n":"InternalPrepare","d":8693004,"h":115972809996,"f":16777476},{"r":65537,"n":"InternalCommit","d":8693004,"h":120267777292,"f":16777476},{"r":65537,"n":"InternalRollback","d":8693004,"h":124562744588,"f":16777476},{"r":65537,"n":"InternalInDoubt","d":8693004,"h":128857711884,"f":16777476},{"r":65537,"p":[{"n":"en","p":2925836}],"n":"Prepare","d":8693004,"h":133152679180,"f":16777473},{"r":65537,"p":[{"n":"en","p":2925836}],"n":"Commit","d":8693004,"h":137447646476,"f":16777473},{"r":65537,"p":[{"n":"en","p":2925836}],"n":"Rollback","d":8693004,"h":141742613772,"f":16777473},{"r":65537,"p":[{"n":"en","p":2925836}],"n":"InDoubt","d":8693004,"h":146037581068,"f":16777473}],"l":[{"t":2794764,"n":"_transaction","d":8693004,"h":4303660300,"f":4194308},{"t":2925836,"n":"_promotedEnlistment","d":8693004,"h":8598627596,"f":4194312},{"t":2925836,"n":"_preparingEnlistment","d":8693004,"h":12893594892,"f":4194312},{"t":131073,"n":"s_classSyncObject","d":8693004,"h":34368431372,"f":4194338},{"t":138936321,"n":"s_prepareCallback","d":8693004,"h":47253333260,"f":4194338},{"t":138936321,"n":"s_commitCallback","d":8693004,"h":64433202444,"f":4194338},{"t":138936321,"n":"s_rollbackCallback","d":8693004,"h":81613071628,"f":4194338},{"t":138936321,"n":"s_inDoubtCallback","d":8693004,"h":98792940812,"f":4194338}],"c":[{"p":[{"n":"transaction","p":2794764}],"n":".ctor","o":"$ctor$1","d":8693004,"h":17188562188,"f":16777217}],"i":[2663692],"h":8693004}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stl.System.Transactions.IEnlistmentNotificationInternal ]; }
            static get $fullName() { return `System.Transactions.VolatileDemultiplexer`; }
        });
        
        $asm.$cls("$stl.System.Transactions.DurableEnlistmentState", ($self) => class DurableEnlistmentState extends $.$stl.System.Transactions.EnlistmentState
        {
            /*DurableEnlistmentActive?*/ static s_durableEnlistmentActive = null;
            /*DurableEnlistmentAborting?*/ static s_durableEnlistmentAborting = null;
            /*DurableEnlistmentCommitting?*/ static s_durableEnlistmentCommitting = null;
            /*DurableEnlistmentDelegated?*/ static s_durableEnlistmentDelegated = null;
            /*DurableEnlistmentEnded?*/ static s_durableEnlistmentEnded = null;
            /*object?*/ static s_classSyncObject$1 = null;
            static /*DurableEnlistmentActive */ get DurableEnlistmentActive()
            {
                return $.$$.System.Threading.LazyInitializer.EnsureInitialized$3($.$stl.System.Transactions.DurableEnlistmentActive, $.$ref(() => $.$stl.System.Transactions.DurableEnlistmentState.s_durableEnlistmentActive, ($v) => $.$stl.System.Transactions.DurableEnlistmentState.s_durableEnlistmentActive = $v, $.$stl.System.Transactions.DurableEnlistmentActive), $.$ref(() => $.$stl.System.Transactions.DurableEnlistmentState.s_classSyncObject$1, ($v) => $.$stl.System.Transactions.DurableEnlistmentState.s_classSyncObject$1 = $v, $.$$.System.Object), new ($.$$.System.Func$$($.$stl.System.Transactions.DurableEnlistmentActive))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.DurableEnlistmentActive().$ctor$3();
                }, {"r":1287436,"n":"","d":1549580,"h":0,"f":17825794}));
            }
            static /*DurableEnlistmentAborting */ get DurableEnlistmentAborting()
            {
                return $.$$.System.Threading.LazyInitializer.EnsureInitialized$3($.$stl.System.Transactions.DurableEnlistmentAborting, $.$ref(() => $.$stl.System.Transactions.DurableEnlistmentState.s_durableEnlistmentAborting, ($v) => $.$stl.System.Transactions.DurableEnlistmentState.s_durableEnlistmentAborting = $v, $.$stl.System.Transactions.DurableEnlistmentAborting), $.$ref(() => $.$stl.System.Transactions.DurableEnlistmentState.s_classSyncObject$1, ($v) => $.$stl.System.Transactions.DurableEnlistmentState.s_classSyncObject$1 = $v, $.$$.System.Object), new ($.$$.System.Func$$($.$stl.System.Transactions.DurableEnlistmentAborting))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.DurableEnlistmentAborting().$ctor$3();
                }, {"r":1221900,"n":"","d":1549580,"h":0,"f":17825794}));
            }
            static /*DurableEnlistmentCommitting */ get DurableEnlistmentCommitting()
            {
                return $.$$.System.Threading.LazyInitializer.EnsureInitialized$3($.$stl.System.Transactions.DurableEnlistmentCommitting, $.$ref(() => $.$stl.System.Transactions.DurableEnlistmentState.s_durableEnlistmentCommitting, ($v) => $.$stl.System.Transactions.DurableEnlistmentState.s_durableEnlistmentCommitting = $v, $.$stl.System.Transactions.DurableEnlistmentCommitting), $.$ref(() => $.$stl.System.Transactions.DurableEnlistmentState.s_classSyncObject$1, ($v) => $.$stl.System.Transactions.DurableEnlistmentState.s_classSyncObject$1 = $v, $.$$.System.Object), new ($.$$.System.Func$$($.$stl.System.Transactions.DurableEnlistmentCommitting))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.DurableEnlistmentCommitting().$ctor$3();
                }, {"r":1352972,"n":"","d":1549580,"h":0,"f":17825794}));
            }
            static /*DurableEnlistmentDelegated */ get DurableEnlistmentDelegated()
            {
                return $.$$.System.Threading.LazyInitializer.EnsureInitialized$3($.$stl.System.Transactions.DurableEnlistmentDelegated, $.$ref(() => $.$stl.System.Transactions.DurableEnlistmentState.s_durableEnlistmentDelegated, ($v) => $.$stl.System.Transactions.DurableEnlistmentState.s_durableEnlistmentDelegated = $v, $.$stl.System.Transactions.DurableEnlistmentDelegated), $.$ref(() => $.$stl.System.Transactions.DurableEnlistmentState.s_classSyncObject$1, ($v) => $.$stl.System.Transactions.DurableEnlistmentState.s_classSyncObject$1 = $v, $.$$.System.Object), new ($.$$.System.Func$$($.$stl.System.Transactions.DurableEnlistmentDelegated))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.DurableEnlistmentDelegated().$ctor$3();
                }, {"r":1418508,"n":"","d":1549580,"h":0,"f":17825794}));
            }
            static /*DurableEnlistmentEnded */ get DurableEnlistmentEnded()
            {
                return $.$$.System.Threading.LazyInitializer.EnsureInitialized$3($.$stl.System.Transactions.DurableEnlistmentEnded, $.$ref(() => $.$stl.System.Transactions.DurableEnlistmentState.s_durableEnlistmentEnded, ($v) => $.$stl.System.Transactions.DurableEnlistmentState.s_durableEnlistmentEnded = $v, $.$stl.System.Transactions.DurableEnlistmentEnded), $.$ref(() => $.$stl.System.Transactions.DurableEnlistmentState.s_classSyncObject$1, ($v) => $.$stl.System.Transactions.DurableEnlistmentState.s_classSyncObject$1 = $v, $.$$.System.Object), new ($.$$.System.Func$$($.$stl.System.Transactions.DurableEnlistmentEnded))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.DurableEnlistmentEnded().$ctor$3();
                }, {"r":1484044,"n":"","d":1549580,"h":0,"f":17825794}));
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 1549580;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1942796,"p":[{"p":1287436,"g":{"r":0,"d":0,"h":34361287948,"f":50331688},"n":"DurableEnlistmentActive","d":1549580,"h":30066320652,"f":2097192},{"p":1221900,"g":{"r":0,"d":0,"h":42951222540,"f":50331684},"n":"DurableEnlistmentAborting","d":1549580,"h":38656255244,"f":2097188},{"p":1352972,"g":{"r":0,"d":0,"h":51541157132,"f":50331684},"n":"DurableEnlistmentCommitting","d":1549580,"h":47246189836,"f":2097188},{"p":1418508,"g":{"r":0,"d":0,"h":60131091724,"f":50331684},"n":"DurableEnlistmentDelegated","d":1549580,"h":55836124428,"f":2097188},{"p":1484044,"g":{"r":0,"d":0,"h":68721026316,"f":50331684},"n":"DurableEnlistmentEnded","d":1549580,"h":64426059020,"f":2097188}],"l":[{"t":1287436,"n":"s_durableEnlistmentActive","d":1549580,"h":4296516876,"f":4194338},{"t":1221900,"n":"s_durableEnlistmentAborting","d":1549580,"h":8591484172,"f":4194338},{"t":1352972,"n":"s_durableEnlistmentCommitting","d":1549580,"h":12886451468,"f":4194338},{"t":1418508,"n":"s_durableEnlistmentDelegated","d":1549580,"h":17181418764,"f":4194338},{"t":1484044,"n":"s_durableEnlistmentEnded","d":1549580,"h":21476386060,"f":4194338},{"t":131073,"n":"s_classSyncObject","o":"@$1","d":1549580,"h":25771353356,"f":4194338}],"c":[{"n":".ctor","o":"$ctor$2","d":1549580,"h":73015993612,"f":16777220}],"h":1549580}; }
            static get $b() { return $.$stl.System.Transactions.EnlistmentState; }
            static get $fullName() { return `System.Transactions.DurableEnlistmentState`; }
        });
        
        $asm.$cls("$stl.System.Transactions.VolatileEnlistmentState", ($self) => class VolatileEnlistmentState extends $.$stl.System.Transactions.EnlistmentState
        {
            /*VolatileEnlistmentActive?*/ static s_volatileEnlistmentActive = null;
            /*VolatileEnlistmentPreparing?*/ static s_volatileEnlistmentPreparing = null;
            /*VolatileEnlistmentPrepared?*/ static s_volatileEnlistmentPrepared = null;
            /*VolatileEnlistmentSPC?*/ static s_volatileEnlistmentSPC = null;
            /*VolatileEnlistmentPreparingAborting?*/ static s_volatileEnlistmentPreparingAborting = null;
            /*VolatileEnlistmentAborting?*/ static s_volatileEnlistmentAborting = null;
            /*VolatileEnlistmentCommitting?*/ static s_volatileEnlistmentCommitting = null;
            /*VolatileEnlistmentInDoubt?*/ static s_volatileEnlistmentInDoubt = null;
            /*VolatileEnlistmentEnded?*/ static s_volatileEnlistmentEnded = null;
            /*VolatileEnlistmentDone?*/ static s_volatileEnlistmentDone = null;
            /*object?*/ static s_classSyncObject$1 = null;
            static /*VolatileEnlistmentActive */ get VolatileEnlistmentActive()
            {
                return $.$$.System.Threading.LazyInitializer.EnsureInitialized$3($.$stl.System.Transactions.VolatileEnlistmentActive, $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentActive, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentActive = $v, $.$stl.System.Transactions.VolatileEnlistmentActive), $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject$1, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject$1 = $v, $.$$.System.Object), new ($.$$.System.Func$$($.$stl.System.Transactions.VolatileEnlistmentActive))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.VolatileEnlistmentActive().$ctor$3();
                }, {"r":8824076,"n":"","d":9479436,"h":0,"f":17825794}));
            }
            static /*VolatileEnlistmentPreparing */ get VolatileEnlistmentPreparing()
            {
                return $.$$.System.Threading.LazyInitializer.EnsureInitialized$3($.$stl.System.Transactions.VolatileEnlistmentPreparing, $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentPreparing, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentPreparing = $v, $.$stl.System.Transactions.VolatileEnlistmentPreparing), $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject$1, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject$1 = $v, $.$$.System.Object), new ($.$$.System.Func$$($.$stl.System.Transactions.VolatileEnlistmentPreparing))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.VolatileEnlistmentPreparing().$ctor$3();
                }, {"r":9217292,"n":"","d":9479436,"h":0,"f":17825794}));
            }
            static /*VolatileEnlistmentPrepared */ get VolatileEnlistmentPrepared()
            {
                return $.$$.System.Threading.LazyInitializer.EnsureInitialized$3($.$stl.System.Transactions.VolatileEnlistmentPrepared, $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentPrepared, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentPrepared = $v, $.$stl.System.Transactions.VolatileEnlistmentPrepared), $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject$1, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject$1 = $v, $.$$.System.Object), new ($.$$.System.Func$$($.$stl.System.Transactions.VolatileEnlistmentPrepared))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.VolatileEnlistmentPrepared().$ctor$3();
                }, {"r":9151756,"n":"","d":9479436,"h":0,"f":17825794}));
            }
            static /*VolatileEnlistmentSPC */ get VolatileEnlistmentSPC()
            {
                return $.$$.System.Threading.LazyInitializer.EnsureInitialized$3($.$stl.System.Transactions.VolatileEnlistmentSPC, $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentSPC, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentSPC = $v, $.$stl.System.Transactions.VolatileEnlistmentSPC), $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject$1, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject$1 = $v, $.$$.System.Object), new ($.$$.System.Func$$($.$stl.System.Transactions.VolatileEnlistmentSPC))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.VolatileEnlistmentSPC().$ctor$3();
                }, {"r":9413900,"n":"","d":9479436,"h":0,"f":17825794}));
            }
            static /*VolatileEnlistmentPreparingAborting */ get VolatileEnlistmentPreparingAborting()
            {
                return $.$$.System.Threading.LazyInitializer.EnsureInitialized$3($.$stl.System.Transactions.VolatileEnlistmentPreparingAborting, $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentPreparingAborting, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentPreparingAborting = $v, $.$stl.System.Transactions.VolatileEnlistmentPreparingAborting), $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject$1, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject$1 = $v, $.$$.System.Object), new ($.$$.System.Func$$($.$stl.System.Transactions.VolatileEnlistmentPreparingAborting))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.VolatileEnlistmentPreparingAborting().$ctor$3();
                }, {"r":9282828,"n":"","d":9479436,"h":0,"f":17825794}));
            }
            static /*VolatileEnlistmentAborting */ get VolatileEnlistmentAborting()
            {
                return $.$$.System.Threading.LazyInitializer.EnsureInitialized$3($.$stl.System.Transactions.VolatileEnlistmentAborting, $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentAborting, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentAborting = $v, $.$stl.System.Transactions.VolatileEnlistmentAborting), $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject$1, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject$1 = $v, $.$$.System.Object), new ($.$$.System.Func$$($.$stl.System.Transactions.VolatileEnlistmentAborting))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.VolatileEnlistmentAborting().$ctor$3();
                }, {"r":8758540,"n":"","d":9479436,"h":0,"f":17825794}));
            }
            static /*VolatileEnlistmentCommitting */ get VolatileEnlistmentCommitting()
            {
                return $.$$.System.Threading.LazyInitializer.EnsureInitialized$3($.$stl.System.Transactions.VolatileEnlistmentCommitting, $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentCommitting, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentCommitting = $v, $.$stl.System.Transactions.VolatileEnlistmentCommitting), $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject$1, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject$1 = $v, $.$$.System.Object), new ($.$$.System.Func$$($.$stl.System.Transactions.VolatileEnlistmentCommitting))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.VolatileEnlistmentCommitting().$ctor$3();
                }, {"r":8889612,"n":"","d":9479436,"h":0,"f":17825794}));
            }
            static /*VolatileEnlistmentInDoubt */ get VolatileEnlistmentInDoubt()
            {
                return $.$$.System.Threading.LazyInitializer.EnsureInitialized$3($.$stl.System.Transactions.VolatileEnlistmentInDoubt, $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentInDoubt, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentInDoubt = $v, $.$stl.System.Transactions.VolatileEnlistmentInDoubt), $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject$1, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject$1 = $v, $.$$.System.Object), new ($.$$.System.Func$$($.$stl.System.Transactions.VolatileEnlistmentInDoubt))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.VolatileEnlistmentInDoubt().$ctor$3();
                }, {"r":9086220,"n":"","d":9479436,"h":0,"f":17825794}));
            }
            static /*VolatileEnlistmentEnded */ get VolatileEnlistmentEnded()
            {
                return $.$$.System.Threading.LazyInitializer.EnsureInitialized$3($.$stl.System.Transactions.VolatileEnlistmentEnded, $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentEnded, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentEnded = $v, $.$stl.System.Transactions.VolatileEnlistmentEnded), $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject$1, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject$1 = $v, $.$$.System.Object), new ($.$$.System.Func$$($.$stl.System.Transactions.VolatileEnlistmentEnded))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.VolatileEnlistmentEnded().$ctor$3();
                }, {"r":9020684,"n":"","d":9479436,"h":0,"f":17825794}));
            }
            static /*VolatileEnlistmentDone */ get VolatileEnlistmentDone()
            {
                return $.$$.System.Threading.LazyInitializer.EnsureInitialized$3($.$stl.System.Transactions.VolatileEnlistmentDone, $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentDone, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentDone = $v, $.$stl.System.Transactions.VolatileEnlistmentDone), $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject$1, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject$1 = $v, $.$$.System.Object), new ($.$$.System.Func$$($.$stl.System.Transactions.VolatileEnlistmentDone))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.VolatileEnlistmentDone().$ctor$4();
                }, {"r":8955148,"n":"","d":9479436,"h":0,"f":17825794}));
            }
            /*byte[] */ RecoveryInformation(/*InternalEnlistment*/ enlistment)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.VolEnlistNoRecoveryInfo, null, enlistment === null ? $.$$.System.Guid.Empty : enlistment.DistributedTxId);
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 9479436;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1942796,"p":[{"p":8824076,"g":{"r":0,"d":0,"h":55844054284,"f":50331688},"n":"VolatileEnlistmentActive","d":9479436,"h":51549086988,"f":2097192},{"p":9217292,"g":{"r":0,"d":0,"h":64433988876,"f":50331684},"n":"VolatileEnlistmentPreparing","d":9479436,"h":60139021580,"f":2097188},{"p":9151756,"g":{"r":0,"d":0,"h":73023923468,"f":50331684},"n":"VolatileEnlistmentPrepared","d":9479436,"h":68728956172,"f":2097188},{"p":9413900,"g":{"r":0,"d":0,"h":81613858060,"f":50331684},"n":"VolatileEnlistmentSPC","d":9479436,"h":77318890764,"f":2097188},{"p":9282828,"g":{"r":0,"d":0,"h":90203792652,"f":50331684},"n":"VolatileEnlistmentPreparingAborting","d":9479436,"h":85908825356,"f":2097188},{"p":8758540,"g":{"r":0,"d":0,"h":98793727244,"f":50331684},"n":"VolatileEnlistmentAborting","d":9479436,"h":94498759948,"f":2097188},{"p":8889612,"g":{"r":0,"d":0,"h":107383661836,"f":50331684},"n":"VolatileEnlistmentCommitting","d":9479436,"h":103088694540,"f":2097188},{"p":9086220,"g":{"r":0,"d":0,"h":115973596428,"f":50331684},"n":"VolatileEnlistmentInDoubt","d":9479436,"h":111678629132,"f":2097188},{"p":9020684,"g":{"r":0,"d":0,"h":124563531020,"f":50331684},"n":"VolatileEnlistmentEnded","d":9479436,"h":120268563724,"f":2097188},{"p":8955148,"g":{"r":0,"d":0,"h":133153465612,"f":50331684},"n":"VolatileEnlistmentDone","d":9479436,"h":128858498316,"f":2097188}],"m":[{"r":$.$typeArray($.$$.System.Byte).$h,"p":[{"n":"enlistment","p":2729228}],"n":"RecoveryInformation","d":9479436,"h":137448432908,"f":16809992}],"l":[{"t":8824076,"n":"s_volatileEnlistmentActive","d":9479436,"h":4304446732,"f":4194338},{"t":9217292,"n":"s_volatileEnlistmentPreparing","d":9479436,"h":8599414028,"f":4194338},{"t":9151756,"n":"s_volatileEnlistmentPrepared","d":9479436,"h":12894381324,"f":4194338},{"t":9413900,"n":"s_volatileEnlistmentSPC","d":9479436,"h":17189348620,"f":4194338},{"t":9282828,"n":"s_volatileEnlistmentPreparingAborting","d":9479436,"h":21484315916,"f":4194338},{"t":8758540,"n":"s_volatileEnlistmentAborting","d":9479436,"h":25779283212,"f":4194338},{"t":8889612,"n":"s_volatileEnlistmentCommitting","d":9479436,"h":30074250508,"f":4194338},{"t":9086220,"n":"s_volatileEnlistmentInDoubt","d":9479436,"h":34369217804,"f":4194338},{"t":9020684,"n":"s_volatileEnlistmentEnded","d":9479436,"h":38664185100,"f":4194338},{"t":8955148,"n":"s_volatileEnlistmentDone","d":9479436,"h":42959152396,"f":4194338},{"t":131073,"n":"s_classSyncObject","o":"@$1","d":9479436,"h":47254119692,"f":4194338}],"c":[{"n":".ctor","o":"$ctor$2","d":9479436,"h":141743400204,"f":16777220}],"h":9479436}; }
            static get $b() { return $.$stl.System.Transactions.EnlistmentState; }
            static get $fullName() { return `System.Transactions.VolatileEnlistmentState`; }
        });
        
        $asm.$cls("$stl.System.Transactions.ActiveStates", ($self) => class ActiveStates extends $.$stl.System.Transactions.TransactionState
        {
            /*TransactionStatus */ get_Status(/*InternalTransaction*/ tx)
            {
                return 0/*TransactionStatus.Active*/;
            }
            /*void */ AddOutcomeRegistrant(/*InternalTransaction*/ tx, /*TransactionCompletedEventHandler?*/ transactionCompletedDelegate)
            {
                tx._transactionCompletedDelegate = $.$cast($.$$.System.Delegate.Combine(tx._transactionCompletedDelegate, transactionCompletedDelegate), $.$stl.System.Transactions.TransactionCompletedEventHandler);
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 238860;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":5743884,"m":[{"r":8430860,"p":[{"n":"tx","p":2794764}],"n":"get_Status","d":238860,"h":4295206156,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"transactionCompletedDelegate","p":4433164}],"n":"AddOutcomeRegistrant","d":238860,"h":8590173452,"f":16809992}],"c":[{"n":".ctor","o":"$ctor$2","d":238860,"h":12885140748,"f":16777220}],"h":238860}; }
            static get $b() { return $.$stl.System.Transactions.TransactionState; }
            static get $fullName() { return `System.Transactions.ActiveStates`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateEnded", ($self) => class TransactionStateEnded extends $.$stl.System.Transactions.TransactionState
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                if (tx._needPulse)
                {
                    $.$$.System.Threading.Monitor.Pulse(tx);
                }
            }
            /*void */ AddOutcomeRegistrant(/*InternalTransaction*/ tx, /*TransactionCompletedEventHandler?*/ transactionCompletedDelegate)
            {
                if (transactionCompletedDelegate !== null)
                {
                    /*TransactionEventArgs*/ let args = new $.$stl.System.Transactions.TransactionEventArgs().$ctor$2();
                    args._transaction = tx._outcomeSource.InternalClone();
                    transactionCompletedDelegate.Invoke(args._transaction, args);
                }
            }
            /*bool */ IsCompleted(/*InternalTransaction*/ tx)
            {
                return true;
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 6464780;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":5743884,"m":[{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"EnterState","d":6464780,"h":4301432076,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"transactionCompletedDelegate","p":4433164}],"n":"AddOutcomeRegistrant","d":6464780,"h":8596399372,"f":16809992},{"r":262145,"p":[{"n":"tx","p":2794764}],"n":"IsCompleted","d":6464780,"h":12891366668,"f":16809992}],"c":[{"n":".ctor","o":"$ctor$2","d":6464780,"h":17186333964,"f":16777220}],"h":6464780}; }
            static get $b() { return $.$stl.System.Transactions.TransactionState; }
            static get $fullName() { return `System.Transactions.TransactionStateEnded`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedBase", ($self) => class TransactionStatePromotedBase extends $.$stl.System.Transactions.TransactionState
        {
            /*TransactionStatus */ get_Status(/*InternalTransaction*/ tx)
            {
                return 0/*TransactionStatus.Active*/;
            }
            /*Enlistment */ EnlistVolatile(/*InternalTransaction*/ tx, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(tx.PromotedTransaction !== null, "Promoted state not valid for transaction.");
                $.$$.System.Threading.Monitor.Exit(tx);
                try
                {
                    /*Enlistment*/ let en = new $.$stl.System.Transactions.Enlistment().$ctor$3(enlistmentNotification, tx, atomicTransaction);
                    $.$stl.System.Transactions.EnlistmentState.EnlistmentStatePromoted.EnterState(en.InternalEnlistment);
                    en.InternalEnlistment.PromotedEnlistment = tx.PromotedTransaction.EnlistVolatile(en.InternalEnlistment, enlistmentOptions);
                    return en;
                }
                finally
                {
                    {
                        $.$$.System.Threading.Monitor.Enter$1(tx);
                    }
                }
            }
            /*Enlistment */ EnlistVolatile$1(/*InternalTransaction*/ tx, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(tx.PromotedTransaction !== null, "Promoted state not valid for transaction.");
                $.$$.System.Threading.Monitor.Exit(tx);
                try
                {
                    /*Enlistment*/ let en = new $.$stl.System.Transactions.Enlistment().$ctor$3(enlistmentNotification, tx, atomicTransaction);
                    $.$stl.System.Transactions.EnlistmentState.EnlistmentStatePromoted.EnterState(en.InternalEnlistment);
                    en.InternalEnlistment.PromotedEnlistment = tx.PromotedTransaction.EnlistVolatile(en.InternalEnlistment, enlistmentOptions);
                    return en;
                }
                finally
                {
                    {
                        $.$$.System.Threading.Monitor.Enter$1(tx);
                    }
                }
            }
            /*Enlistment */ EnlistDurable(/*InternalTransaction*/ tx, /*Guid*/ resourceManagerIdentifier, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(tx.PromotedTransaction !== null, "Promoted state not valid for transaction.");
                tx.ThrowIfPromoterTypeIsNotMSDTC();
                $.$$.System.Threading.Monitor.Exit(tx);
                try
                {
                    /*Enlistment*/ let en = new $.$stl.System.Transactions.Enlistment().$ctor$1(resourceManagerIdentifier, tx, enlistmentNotification, null, atomicTransaction);
                    $.$stl.System.Transactions.EnlistmentState.EnlistmentStatePromoted.EnterState(en.InternalEnlistment);
                    en.InternalEnlistment.PromotedEnlistment = tx.PromotedTransaction.EnlistDurable(resourceManagerIdentifier, $.$cast(en.InternalEnlistment, $.$stl.System.Transactions.DurableInternalEnlistment), false, enlistmentOptions);
                    return en;
                }
                finally
                {
                    {
                        $.$$.System.Threading.Monitor.Enter$1(tx);
                    }
                }
            }
            /*Enlistment */ EnlistDurable$1(/*InternalTransaction*/ tx, /*Guid*/ resourceManagerIdentifier, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(tx.PromotedTransaction !== null, "Promoted state not valid for transaction.");
                tx.ThrowIfPromoterTypeIsNotMSDTC();
                $.$$.System.Threading.Monitor.Exit(tx);
                try
                {
                    /*Enlistment*/ let en = new $.$stl.System.Transactions.Enlistment().$ctor$1(resourceManagerIdentifier, tx, enlistmentNotification, enlistmentNotification, atomicTransaction);
                    $.$stl.System.Transactions.EnlistmentState.EnlistmentStatePromoted.EnterState(en.InternalEnlistment);
                    en.InternalEnlistment.PromotedEnlistment = tx.PromotedTransaction.EnlistDurable(resourceManagerIdentifier, $.$cast(en.InternalEnlistment, $.$stl.System.Transactions.DurableInternalEnlistment), true, enlistmentOptions);
                    return en;
                }
                finally
                {
                    {
                        $.$$.System.Threading.Monitor.Enter$1(tx);
                    }
                }
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(tx.PromotedTransaction !== null, "Promoted state not valid for transaction.");
                tx._innerException ??= e;
                $.$$.System.Threading.Monitor.Exit(tx);
                try
                {
                    tx.PromotedTransaction.Rollback();
                }
                finally
                {
                    {
                        $.$$.System.Threading.Monitor.Enter$1(tx);
                    }
                }
            }
            /*Guid */ get_Identifier(/*InternalTransaction?*/ tx)
            {
                if (tx !== null && tx.PromotedTransaction !== null)
                {
                    return tx.PromotedTransaction.Identifier;
                }
                else 
                {
                    return $.$$.System.Guid.Empty;
                }
            }
            /*void */ AddOutcomeRegistrant(/*InternalTransaction*/ tx, /*TransactionCompletedEventHandler?*/ transactionCompletedDelegate)
            {
                tx._transactionCompletedDelegate = $.$cast($.$$.System.Delegate.Combine(tx._transactionCompletedDelegate, transactionCompletedDelegate), $.$stl.System.Transactions.TransactionCompletedEventHandler);
            }
            /*void */ BeginCommit(/*InternalTransaction*/ tx, /*bool*/ asyncCommit, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                tx._asyncCommit = asyncCommit;
                tx._asyncCallback = asyncCallback;
                tx._asyncState = asyncState;
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedCommitting.EnterState(tx);
            }
            /*void */ RestartCommitIfNeeded(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedP0Wave.EnterState(tx);
            }
            /*bool */ EnlistPromotableSinglePhase(/*InternalTransaction*/ tx, /*IPromotableSinglePhaseNotification*/ promotableSinglePhaseNotification, /*Transaction*/ atomicTransaction, /*Guid*/ promoterType)
            {
                return false;
            }
            /*void */ CompleteBlockingClone(/*InternalTransaction*/ tx)
            {
                if (tx._phase0Volatiles._dependentClones > 0)
                {
                    tx._phase0Volatiles._dependentClones--;
                    $.$$.System.Diagnostics.Debug.Assert$2(tx._phase0Volatiles._preparedVolatileEnlistments <= ((tx._phase0Volatiles._volatileEnlistmentCount + tx._phase0Volatiles._dependentClones) | 0), "tx._phase0Volatiles._preparedVolatileEnlistments <=\r\n                    tx._phase0Volatiles._volatileEnlistmentCount + tx._phase0Volatiles._dependentClones");
                    if (tx._phase0Volatiles._preparedVolatileEnlistments === ((tx._phase0VolatileWaveCount + tx._phase0Volatiles._dependentClones) | 0))
                    {
                        tx.State.Phase0VolatilePrepareDone(tx);
                    }
                }
                else 
                {
                    tx._phase0WaveDependentCloneCount--;
                    $.$$.System.Diagnostics.Debug.Assert$2(tx._phase0WaveDependentCloneCount >= 0, "tx._phase0WaveDependentCloneCount >= 0");
                    if (tx._phase0WaveDependentCloneCount === 0)
                    {
                        /*OletxDependentTransaction*/ let dtx = tx._phase0WaveDependentClone;
                        tx._phase0WaveDependentClone = null;
                        $.$$.System.Threading.Monitor.Exit(tx);
                        try
                        {
                            try
                            {
                                dtx.Complete();
                            }
                            finally
                            {
                                {
                                    dtx.Dispose();
                                }
                            }
                        }
                        finally
                        {
                            {
                                $.$$.System.Threading.Monitor.Enter$1(tx);
                            }
                        }
                    }
                }
            }
            /*void */ CompleteAbortingClone(/*InternalTransaction*/ tx)
            {
                if (null !== tx._phase1Volatiles.VolatileDemux)
                {
                    tx._phase1Volatiles._dependentClones--;
                    $.$$.System.Diagnostics.Debug.Assert$2(tx._phase1Volatiles._dependentClones >= 0, "tx._phase1Volatiles._dependentClones >= 0");
                }
                else 
                {
                    tx._abortingDependentCloneCount--;
                    $.$$.System.Diagnostics.Debug.Assert$2(0 <= tx._abortingDependentCloneCount, "0 <= tx._abortingDependentCloneCount");
                    if (0 === tx._abortingDependentCloneCount)
                    {
                        /*OletxDependentTransaction*/ let dtx = tx._abortingDependentClone;
                        tx._abortingDependentClone = null;
                        $.$$.System.Threading.Monitor.Exit(tx);
                        try
                        {
                            try
                            {
                                dtx.Complete();
                            }
                            finally
                            {
                                {
                                    dtx.Dispose();
                                }
                            }
                        }
                        finally
                        {
                            {
                                $.$$.System.Threading.Monitor.Enter$1(tx);
                            }
                        }
                    }
                }
            }
            /*void */ CreateBlockingClone(/*InternalTransaction*/ tx)
            {
                if (tx._phase0WaveDependentClone === null)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(tx.PromotedTransaction !== null, "tx.PromotedTransaction != null");
                    tx._phase0WaveDependentClone = tx.PromotedTransaction.DependentClone(true);
                }
                tx._phase0WaveDependentCloneCount++;
            }
            /*void */ CreateAbortingClone(/*InternalTransaction*/ tx)
            {
                if (null !== tx._phase1Volatiles.VolatileDemux)
                {
                    tx._phase1Volatiles._dependentClones++;
                }
                else 
                {
                    if (null === tx._abortingDependentClone)
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(tx.PromotedTransaction !== null, "tx.PromotedTransaction != null");
                        tx._abortingDependentClone = tx.PromotedTransaction.DependentClone(false);
                    }
                    tx._abortingDependentCloneCount++;
                }
            }
            /*bool */ ContinuePhase0Prepares()
            {
                return true;
            }
            /*void */ GetObjectData(/*InternalTransaction*/ tx, /*SerializationInfo*/ serializationInfo, /*StreamingContext*/ context)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(tx.PromotedTransaction !== null, "Promoted state not valid for transaction.");
                tx.ThrowIfPromoterTypeIsNotMSDTC();
                /*OletxTransaction*/ let serializableTx = tx.PromotedTransaction;
                if (serializableTx === null)
                {
                    throw new $.$$.System.NotSupportedException().$ctor$9();
                }
                serializationInfo.FullTypeName = $.$$.System.Object.GetType.call(serializableTx).FullName;
                serializableTx.GetObjectData(serializationInfo, context);
            }
            /*void */ ChangeStatePromotedAborted(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedAborted.EnterState(tx);
            }
            /*void */ ChangeStatePromotedCommitted(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedCommitted.EnterState(tx);
            }
            /*void */ InDoubtFromDtc(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedIndoubt.EnterState(tx);
            }
            /*void */ InDoubtFromEnlistment(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedIndoubt.EnterState(tx);
            }
            /*void */ ChangeStateAbortedDuringPromotion(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStateAborted.EnterState(tx);
            }
            /*void */ Timeout(/*InternalTransaction*/ tx)
            {
                try
                {
                    tx._innerException ??= new $.$$.System.TimeoutException().$ctor$12($.$stl.System.SR.TraceTransactionTimeout);
                    $.$$.System.Diagnostics.Debug.Assert$2(tx.PromotedTransaction !== null, "tx.PromotedTransaction != null");
                    tx.PromotedTransaction.Rollback();
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.TransactionTimeout$1(tx.TransactionTraceId);
                    }
                }
                catch(te)
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.ExceptionConsumed(te);
                    }
                }
            }
            /*void */ Promote(/*InternalTransaction*/ tx)
            {
            }
            /*byte[] */ PromotedToken(/*InternalTransaction*/ tx)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(tx.promotedToken !== null, "InternalTransaction.promotedToken is null in TransactionStateDelegatedNonMSDTCBase or one of its derived classes.");
                return tx.promotedToken;
            }
            /*void */ Phase0VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ Phase1VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 6923532;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":5743884,"m":[{"r":8430860,"p":[{"n":"tx","p":2794764}],"n":"get_Status","d":6923532,"h":4301890828,"f":16809992},{"r":1746188,"p":[{"n":"tx","p":2794764},{"n":"enlistmentNotification","p":2598156},{"n":"enlistmentOptions","p":1877260},{"n":"atomicTransaction","p":4302092}],"n":"EnlistVolatile","d":6923532,"h":8596858124,"f":16809992},{"r":1746188,"p":[{"n":"tx","p":2794764},{"n":"enlistmentNotification","p":3056908},{"n":"enlistmentOptions","p":1877260},{"n":"atomicTransaction","p":4302092}],"n":"EnlistVolatile","o":"@$1","d":6923532,"h":12891825420,"f":16809992},{"r":1746188,"p":[{"n":"tx","p":2794764},{"n":"resourceManagerIdentifier","p":56229889},{"n":"enlistmentNotification","p":2598156},{"n":"enlistmentOptions","p":1877260},{"n":"atomicTransaction","p":4302092}],"n":"EnlistDurable","d":6923532,"h":17186792716,"f":16809992},{"r":1746188,"p":[{"n":"tx","p":2794764},{"n":"resourceManagerIdentifier","p":56229889},{"n":"enlistmentNotification","p":3056908},{"n":"enlistmentOptions","p":1877260},{"n":"atomicTransaction","p":4302092}],"n":"EnlistDurable","o":"@$1","d":6923532,"h":21481760012,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"e","p":47251457}],"n":"Rollback","d":6923532,"h":25776727308,"f":16809992},{"r":56229889,"p":[{"n":"tx","p":2794764}],"n":"get_Identifier","d":6923532,"h":30071694604,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"transactionCompletedDelegate","p":4433164}],"n":"AddOutcomeRegistrant","d":6923532,"h":34366661900,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"asyncCommit","p":262145},{"n":"asyncCallback","p":14548993},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":6923532,"h":38661629196,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"RestartCommitIfNeeded","d":6923532,"h":42956596492,"f":16809992},{"r":262145,"p":[{"n":"tx","p":2794764},{"n":"promotableSinglePhaseNotification","p":2860300},{"n":"atomicTransaction","p":4302092},{"n":"promoterType","p":56229889}],"n":"EnlistPromotableSinglePhase","d":6923532,"h":47251563788,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"CompleteBlockingClone","d":6923532,"h":51546531084,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"CompleteAbortingClone","d":6923532,"h":55841498380,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"CreateBlockingClone","d":6923532,"h":60136465676,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"CreateAbortingClone","d":6923532,"h":64431432972,"f":16809992},{"r":262145,"n":"ContinuePhase0Prepares","d":6923532,"h":68726400268,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"serializationInfo","p":113836033},{"n":"context","p":113967105}],"n":"GetObjectData","d":6923532,"h":73021367564,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"ChangeStatePromotedAborted","d":6923532,"h":77316334860,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"ChangeStatePromotedCommitted","d":6923532,"h":81611302156,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"InDoubtFromDtc","d":6923532,"h":85906269452,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"InDoubtFromEnlistment","d":6923532,"h":90201236748,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"ChangeStateAbortedDuringPromotion","d":6923532,"h":94496204044,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"Timeout","d":6923532,"h":98791171340,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"Promote","d":6923532,"h":103086138636,"f":16809992},{"r":$.$typeArray($.$$.System.Byte).$h,"p":[{"n":"tx","p":2794764}],"n":"PromotedToken","d":6923532,"h":107381105932,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"Phase0VolatilePrepareDone","d":6923532,"h":111676073228,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"Phase1VolatilePrepareDone","d":6923532,"h":115971040524,"f":16809992}],"c":[{"n":".ctor","o":"$ctor$2","d":6923532,"h":120266007820,"f":16777220}],"h":6923532}; }
            static get $b() { return $.$stl.System.Transactions.TransactionState; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedBase`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedNonMSDTCBase", ($self) => class TransactionStatePromotedNonMSDTCBase extends $.$stl.System.Transactions.TransactionState
        {
            /*TransactionStatus */ get_Status(/*InternalTransaction*/ tx)
            {
                return 0/*TransactionStatus.Active*/;
            }
            /*Enlistment */ EnlistVolatile(/*InternalTransaction*/ tx, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                /*Enlistment*/ let enlistment = new $.$stl.System.Transactions.Enlistment().$ctor$5(tx, enlistmentNotification, null, atomicTransaction, enlistmentOptions);
                if ((enlistmentOptions & 1/*EnlistmentOptions.EnlistDuringPrepareRequired*/) !== 0)
                {
                    $.$stl.System.Transactions.TransactionState.AddVolatileEnlistment($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase0Volatiles, ($v) => tx._phase0Volatiles = $v, null), enlistment);
                }
                else 
                {
                    $.$stl.System.Transactions.TransactionState.AddVolatileEnlistment($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase1Volatiles, ($v) => tx._phase1Volatiles = $v, null), enlistment);
                }
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionstateEnlist$1(enlistment.InternalEnlistment.EnlistmentTraceId, 0/*EnlistmentType.Volatile*/, enlistmentOptions);
                }
                return enlistment;
            }
            /*Enlistment */ EnlistVolatile$1(/*InternalTransaction*/ tx, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                /*Enlistment*/ let enlistment = new $.$stl.System.Transactions.Enlistment().$ctor$5(tx, enlistmentNotification, enlistmentNotification, atomicTransaction, enlistmentOptions);
                if ((enlistmentOptions & 1/*EnlistmentOptions.EnlistDuringPrepareRequired*/) !== 0)
                {
                    $.$stl.System.Transactions.TransactionState.AddVolatileEnlistment($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase0Volatiles, ($v) => tx._phase0Volatiles = $v, null), enlistment);
                }
                else 
                {
                    $.$stl.System.Transactions.TransactionState.AddVolatileEnlistment($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase1Volatiles, ($v) => tx._phase1Volatiles = $v, null), enlistment);
                }
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionstateEnlist$1(enlistment.InternalEnlistment.EnlistmentTraceId, 0/*EnlistmentType.Volatile*/, enlistmentOptions);
                }
                return enlistment;
            }
            /*Enlistment */ EnlistDurable(/*InternalTransaction*/ tx, /*Guid*/ resourceManagerIdentifier, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                throw new $.$stl.System.Transactions.TransactionPromotionException().$ctor$15($.$stl.System.SR.Format$6($.$stl.System.SR.PromoterTypeUnrecognized, $.$$.System.Guid.ToString.call(tx._promoterType)), tx._innerException);
            }
            /*Enlistment */ EnlistDurable$1(/*InternalTransaction*/ tx, /*Guid*/ resourceManagerIdentifier, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                throw new $.$stl.System.Transactions.TransactionPromotionException().$ctor$15($.$stl.System.SR.Format$6($.$stl.System.SR.PromoterTypeUnrecognized, $.$$.System.Guid.ToString.call(tx._promoterType)), tx._innerException);
            }
            /*bool */ EnlistPromotableSinglePhase(/*InternalTransaction*/ tx, /*IPromotableSinglePhaseNotification*/ promotableSinglePhaseNotification, /*Transaction*/ atomicTransaction, /*Guid*/ promoterType)
            {
                return false;
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(tx._durableEnlistment !== null, "PromotedNonMSDTC state is not valid for transaction");
                tx._innerException ??= e;
                $.$stl.System.Transactions.TransactionState.TransactionStateAborted.EnterState(tx);
            }
            /*Guid */ get_Identifier(/*InternalTransaction*/ tx)
            {
                return tx._distributedTransactionIdentifierNonMSDTC;
            }
            /*void */ AddOutcomeRegistrant(/*InternalTransaction*/ tx, /*TransactionCompletedEventHandler?*/ transactionCompletedDelegate)
            {
                tx._transactionCompletedDelegate = $.$cast($.$$.System.Delegate.Combine(tx._transactionCompletedDelegate, transactionCompletedDelegate), $.$stl.System.Transactions.TransactionCompletedEventHandler);
            }
            /*void */ BeginCommit(/*InternalTransaction*/ tx, /*bool*/ asyncCommit, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                tx._asyncCommit = asyncCommit;
                tx._asyncCallback = asyncCallback;
                tx._asyncState = asyncState;
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedNonMSDTCPhase0.EnterState(tx);
            }
            /*void */ CompleteBlockingClone(/*InternalTransaction*/ tx)
            {
                if (tx._phase0Volatiles._dependentClones > 0)
                {
                    tx._phase0Volatiles._dependentClones--;
                    $.$$.System.Diagnostics.Debug.Assert$2(tx._phase0Volatiles._preparedVolatileEnlistments <= ((tx._phase0Volatiles._volatileEnlistmentCount + tx._phase0Volatiles._dependentClones) | 0), "tx._phase0Volatiles._preparedVolatileEnlistments <=\r\n                    tx._phase0Volatiles._volatileEnlistmentCount + tx._phase0Volatiles._dependentClones");
                    if (tx._phase0Volatiles._preparedVolatileEnlistments === ((tx._phase0VolatileWaveCount + tx._phase0Volatiles._dependentClones) | 0))
                    {
                        tx.State.Phase0VolatilePrepareDone(tx);
                    }
                }
            }
            /*void */ CompleteAbortingClone(/*InternalTransaction*/ tx)
            {
                tx._phase1Volatiles._dependentClones--;
                $.$$.System.Diagnostics.Debug.Assert$2(tx._phase1Volatiles._dependentClones >= 0, "tx._phase1Volatiles._dependentClones >= 0");
            }
            /*void */ CreateBlockingClone(/*InternalTransaction*/ tx)
            {
                tx._phase0Volatiles._dependentClones++;
            }
            /*void */ CreateAbortingClone(/*InternalTransaction*/ tx)
            {
                tx._phase1Volatiles._dependentClones++;
            }
            /*bool */ ContinuePhase0Prepares()
            {
                return true;
            }
            /*void */ GetObjectData(/*InternalTransaction*/ tx, /*SerializationInfo*/ serializationInfo, /*StreamingContext*/ context)
            {
                throw new $.$stl.System.Transactions.TransactionPromotionException().$ctor$15($.$stl.System.SR.Format$6($.$stl.System.SR.PromoterTypeUnrecognized, $.$$.System.Guid.ToString.call(tx._promoterType)), tx._innerException);
            }
            /*void */ ChangeStateTransactionAborted(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                tx._innerException ??= e;
                $.$stl.System.Transactions.TransactionState.TransactionStateAborted.EnterState(tx);
            }
            /*void */ InDoubtFromEnlistment(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedNonMSDTCIndoubt.EnterState(tx);
            }
            /*void */ ChangeStateAbortedDuringPromotion(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStateAborted.EnterState(tx);
            }
            /*void */ Timeout(/*InternalTransaction*/ tx)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionTimeout$1(tx.TransactionTraceId);
                }
                /*TimeoutException*/ let e = new $.$$.System.TimeoutException().$ctor$12($.$stl.System.SR.TraceTransactionTimeout);
                this.Rollback(tx, e);
            }
            /*void */ Promote(/*InternalTransaction*/ tx)
            {
            }
            /*void */ Phase0VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ Phase1VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            /*byte[] */ PromotedToken(/*InternalTransaction*/ tx)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(tx.promotedToken !== null, "InternalTransaction.promotedToken is null in TransactionStateDelegatedNonMSDTCBase or one of its derived classes.");
                return tx.promotedToken;
            }
            /*void */ DisposeRoot(/*InternalTransaction*/ tx)
            {
                tx.State.Rollback(tx, null);
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 7316748;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":5743884,"m":[{"r":8430860,"p":[{"n":"tx","p":2794764}],"n":"get_Status","d":7316748,"h":4302284044,"f":16809992},{"r":1746188,"p":[{"n":"tx","p":2794764},{"n":"enlistmentNotification","p":2598156},{"n":"enlistmentOptions","p":1877260},{"n":"atomicTransaction","p":4302092}],"n":"EnlistVolatile","d":7316748,"h":8597251340,"f":16809992},{"r":1746188,"p":[{"n":"tx","p":2794764},{"n":"enlistmentNotification","p":3056908},{"n":"enlistmentOptions","p":1877260},{"n":"atomicTransaction","p":4302092}],"n":"EnlistVolatile","o":"@$1","d":7316748,"h":12892218636,"f":16809992},{"r":1746188,"p":[{"n":"tx","p":2794764},{"n":"resourceManagerIdentifier","p":56229889},{"n":"enlistmentNotification","p":2598156},{"n":"enlistmentOptions","p":1877260},{"n":"atomicTransaction","p":4302092}],"n":"EnlistDurable","d":7316748,"h":17187185932,"f":16809992},{"r":1746188,"p":[{"n":"tx","p":2794764},{"n":"resourceManagerIdentifier","p":56229889},{"n":"enlistmentNotification","p":3056908},{"n":"enlistmentOptions","p":1877260},{"n":"atomicTransaction","p":4302092}],"n":"EnlistDurable","o":"@$1","d":7316748,"h":21482153228,"f":16809992},{"r":262145,"p":[{"n":"tx","p":2794764},{"n":"promotableSinglePhaseNotification","p":2860300},{"n":"atomicTransaction","p":4302092},{"n":"promoterType","p":56229889}],"n":"EnlistPromotableSinglePhase","d":7316748,"h":25777120524,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"e","p":47251457}],"n":"Rollback","d":7316748,"h":30072087820,"f":16809992},{"r":56229889,"p":[{"n":"tx","p":2794764}],"n":"get_Identifier","d":7316748,"h":34367055116,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"transactionCompletedDelegate","p":4433164}],"n":"AddOutcomeRegistrant","d":7316748,"h":38662022412,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"asyncCommit","p":262145},{"n":"asyncCallback","p":14548993},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":7316748,"h":42956989708,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"CompleteBlockingClone","d":7316748,"h":47251957004,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"CompleteAbortingClone","d":7316748,"h":51546924300,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"CreateBlockingClone","d":7316748,"h":55841891596,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"CreateAbortingClone","d":7316748,"h":60136858892,"f":16809992},{"r":262145,"n":"ContinuePhase0Prepares","d":7316748,"h":64431826188,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"serializationInfo","p":113836033},{"n":"context","p":113967105}],"n":"GetObjectData","d":7316748,"h":68726793484,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"e","p":47251457}],"n":"ChangeStateTransactionAborted","d":7316748,"h":73021760780,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"InDoubtFromEnlistment","d":7316748,"h":77316728076,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"ChangeStateAbortedDuringPromotion","d":7316748,"h":81611695372,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"Timeout","d":7316748,"h":85906662668,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"Promote","d":7316748,"h":90201629964,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"Phase0VolatilePrepareDone","d":7316748,"h":94496597260,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"Phase1VolatilePrepareDone","d":7316748,"h":98791564556,"f":16809992},{"r":$.$typeArray($.$$.System.Byte).$h,"p":[{"n":"tx","p":2794764}],"n":"PromotedToken","d":7316748,"h":103086531852,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"DisposeRoot","d":7316748,"h":107381499148,"f":16809992}],"c":[{"n":".ctor","o":"$ctor$2","d":7316748,"h":111676466444,"f":16777220}],"h":7316748}; }
            static get $b() { return $.$stl.System.Transactions.TransactionState; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedNonMSDTCBase`; }
        });
        
        $asm.$cls("$stl.System.Transactions.EnlistableStates", ($self) => class EnlistableStates extends $.$stl.System.Transactions.ActiveStates
        {
            /*Enlistment */ EnlistDurable(/*InternalTransaction*/ tx, /*Guid*/ resourceManagerIdentifier, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                tx.ThrowIfPromoterTypeIsNotMSDTC();
                tx._promoteState.EnterState(tx);
                return tx.State.EnlistDurable(tx, resourceManagerIdentifier, enlistmentNotification, enlistmentOptions, atomicTransaction);
            }
            /*Enlistment */ EnlistDurable$1(/*InternalTransaction*/ tx, /*Guid*/ resourceManagerIdentifier, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                tx.ThrowIfPromoterTypeIsNotMSDTC();
                if (tx._durableEnlistment !== null || (enlistmentOptions & 1/*EnlistmentOptions.EnlistDuringPrepareRequired*/) !== 0)
                {
                    tx._promoteState.EnterState(tx);
                    return tx.State.EnlistDurable$1(tx, resourceManagerIdentifier, enlistmentNotification, enlistmentOptions, atomicTransaction);
                }
                /*Enlistment*/ let en = new $.$stl.System.Transactions.Enlistment().$ctor$1(resourceManagerIdentifier, tx, enlistmentNotification, enlistmentNotification, atomicTransaction);
                tx._durableEnlistment = en.InternalEnlistment;
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentActive.EnterState(tx._durableEnlistment);
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionstateEnlist$1(tx._durableEnlistment.EnlistmentTraceId, 1/*EnlistmentType.Durable*/, 0/*EnlistmentOptions.None*/);
                }
                return en;
            }
            /*void */ Timeout(/*InternalTransaction*/ tx)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionTimeout$1(tx.TransactionTraceId);
                }
                /*TimeoutException*/ let e = new $.$$.System.TimeoutException().$ctor$12($.$stl.System.SR.TraceTransactionTimeout);
                this.Rollback(tx, e);
            }
            /*void */ GetObjectData(/*InternalTransaction*/ tx, /*SerializationInfo*/ serializationInfo, /*StreamingContext*/ context)
            {
                tx.ThrowIfPromoterTypeIsNotMSDTC();
                tx._promoteState.EnterState(tx);
                tx.State.GetObjectData(tx, serializationInfo, context);
            }
            /*void */ CompleteBlockingClone(/*InternalTransaction*/ tx)
            {
                tx._phase0Volatiles._dependentClones--;
                $.$$.System.Diagnostics.Debug.Assert$2(tx._phase0Volatiles._dependentClones >= 0, "tx._phase0Volatiles._dependentClones >= 0");
                $.$$.System.Diagnostics.Debug.Assert$2(tx._phase0Volatiles._preparedVolatileEnlistments <= ((tx._phase0Volatiles._volatileEnlistmentCount + tx._phase0Volatiles._dependentClones) | 0), "tx._phase0Volatiles._preparedVolatileEnlistments <=\r\n                tx._phase0Volatiles._volatileEnlistmentCount + tx._phase0Volatiles._dependentClones");
                if (tx._phase0Volatiles._preparedVolatileEnlistments === ((tx._phase0VolatileWaveCount + tx._phase0Volatiles._dependentClones) | 0))
                {
                    tx.State.Phase0VolatilePrepareDone(tx);
                }
            }
            /*void */ CompleteAbortingClone(/*InternalTransaction*/ tx)
            {
                tx._phase1Volatiles._dependentClones--;
                $.$$.System.Diagnostics.Debug.Assert$2(tx._phase1Volatiles._dependentClones >= 0, "tx._phase1Volatiles._dependentClones >= 0");
            }
            /*void */ CreateBlockingClone(/*InternalTransaction*/ tx)
            {
                tx._phase0Volatiles._dependentClones++;
            }
            /*void */ CreateAbortingClone(/*InternalTransaction*/ tx)
            {
                tx._phase1Volatiles._dependentClones++;
            }
            /*void */ Promote(/*InternalTransaction*/ tx)
            {
                tx._promoteState.EnterState(tx);
                tx.State.CheckForFinishedTransaction(tx);
            }
            /*byte[] */ PromotedToken(/*InternalTransaction*/ tx)
            {
                if (tx.promotedToken === null)
                {
                    tx._promoteState.EnterState(tx);
                    tx.State.CheckForFinishedTransaction(tx);
                }
                $.$$.System.Diagnostics.Debug.Assert$2(tx.promotedToken !== null, "tx.promotedToken != null");
                return tx.promotedToken;
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 1680652;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":238860,"m":[{"r":1746188,"p":[{"n":"tx","p":2794764},{"n":"resourceManagerIdentifier","p":56229889},{"n":"enlistmentNotification","p":2598156},{"n":"enlistmentOptions","p":1877260},{"n":"atomicTransaction","p":4302092}],"n":"EnlistDurable","d":1680652,"h":4296647948,"f":16809992},{"r":1746188,"p":[{"n":"tx","p":2794764},{"n":"resourceManagerIdentifier","p":56229889},{"n":"enlistmentNotification","p":3056908},{"n":"enlistmentOptions","p":1877260},{"n":"atomicTransaction","p":4302092}],"n":"EnlistDurable","o":"@$1","d":1680652,"h":8591615244,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"Timeout","d":1680652,"h":12886582540,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"serializationInfo","p":113836033},{"n":"context","p":113967105}],"n":"GetObjectData","d":1680652,"h":17181549836,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"CompleteBlockingClone","d":1680652,"h":21476517132,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"CompleteAbortingClone","d":1680652,"h":25771484428,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"CreateBlockingClone","d":1680652,"h":30066451724,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"CreateAbortingClone","d":1680652,"h":34361419020,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"Promote","d":1680652,"h":38656386316,"f":16809992},{"r":$.$typeArray($.$$.System.Byte).$h,"p":[{"n":"tx","p":2794764}],"n":"PromotedToken","d":1680652,"h":42951353612,"f":16809992}],"c":[{"n":".ctor","o":"$ctor$3","d":1680652,"h":47246320908,"f":16777220}],"h":1680652}; }
            static get $b() { return $.$stl.System.Transactions.ActiveStates; }
            static get $fullName() { return `System.Transactions.EnlistableStates`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedAborting", ($self) => class TransactionStatePromotedAborting extends $.$stl.System.Transactions.TransactionStatePromotedBase
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
            }
            /*TransactionStatus */ get_Status(/*InternalTransaction*/ tx)
            {
                return 2/*TransactionStatus.Aborted*/;
            }
            /*void */ BeginCommit(/*InternalTransaction*/ tx, /*bool*/ asyncCommit, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException(tx._innerException, tx.DistributedTxId);
            }
            /*void */ CreateBlockingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException(tx._innerException, tx.DistributedTxId);
            }
            /*void */ CreateAbortingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException(tx._innerException, tx.DistributedTxId);
            }
            /*void */ ChangeStatePromotedAborted(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedAborted.EnterState(tx);
            }
            /*void */ ChangeStateTransactionAborted(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
            }
            /*void */ RestartCommitIfNeeded(/*InternalTransaction*/ tx)
            {
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 6857996;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6923532,"m":[{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"EnterState","d":6857996,"h":4301825292,"f":16809992},{"r":8430860,"p":[{"n":"tx","p":2794764}],"n":"get_Status","d":6857996,"h":8596792588,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"asyncCommit","p":262145},{"n":"asyncCallback","p":14548993},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":6857996,"h":12891759884,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"CreateBlockingClone","d":6857996,"h":17186727180,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"CreateAbortingClone","d":6857996,"h":21481694476,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"ChangeStatePromotedAborted","d":6857996,"h":25776661772,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"e","p":47251457}],"n":"ChangeStateTransactionAborted","d":6857996,"h":30071629068,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"RestartCommitIfNeeded","d":6857996,"h":34366596364,"f":16809992}],"c":[{"n":".ctor","o":"$ctor$3","d":6857996,"h":38661563660,"f":16777220}],"h":6857996}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedBase; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedAborting`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedEnded", ($self) => class TransactionStatePromotedEnded extends $.$stl.System.Transactions.TransactionStateEnded
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                super.EnterState(tx);
                this.CommonEnterState(tx);
                if (!$.$$.System.Threading.ThreadPool.QueueUserWorkItem($.$stl.System.Transactions.TransactionStatePromotedEnded.SignalMethod, tx))
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.UnexpectedFailureOfThreadPool, null, tx === null ? $.$$.System.Guid.Empty : tx.DistributedTxId);
                }
            }
            /*void */ AddOutcomeRegistrant(/*InternalTransaction*/ tx, /*TransactionCompletedEventHandler?*/ transactionCompletedDelegate)
            {
                if (transactionCompletedDelegate !== null)
                {
                    /*TransactionEventArgs*/ let args = new $.$stl.System.Transactions.TransactionEventArgs().$ctor$2();
                    args._transaction = tx._outcomeSource.InternalClone();
                    transactionCompletedDelegate.Invoke(args._transaction, args);
                }
            }
            /*void */ EndCommit(/*InternalTransaction*/ tx)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(tx.PromotedTransaction !== null, "Promoted state not valid for transaction.");
                this.PromotedTransactionOutcome(tx);
            }
            /*void */ CompleteBlockingClone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ CompleteAbortingClone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ CreateBlockingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException(tx._innerException, tx.DistributedTxId);
            }
            /*void */ CreateAbortingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException(tx._innerException, tx.DistributedTxId);
            }
            /*Guid */ get_Identifier(/*InternalTransaction*/ tx)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(tx.PromotedTransaction !== null, "tx.PromotedTransaction != null");
                return tx.PromotedTransaction.Identifier;
            }
            /*void */ Promote(/*InternalTransaction*/ tx)
            {
            }
            /*WaitCallback?*/ static s_signalMethod = null;
            static /*WaitCallback */ get SignalMethod()
            {
                return $.$$.System.Threading.LazyInitializer.EnsureInitialized$3($.$$.System.Threading.WaitCallback, $.$ref(() => $.$stl.System.Transactions.TransactionStatePromotedEnded.s_signalMethod, ($v) => $.$stl.System.Transactions.TransactionStatePromotedEnded.s_signalMethod = $v, $.$$.System.Threading.WaitCallback), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$$.System.Object), new ($.$$.System.Func$$($.$$.System.Threading.WaitCallback))().$ctor(this,  () =>
                {
                    return $.$stl.System.Transactions.TransactionStatePromotedEnded.SignalCallback;
                }, {"r":138936321,"n":"","d":7120140,"h":0,"f":17825794}));
            }
            static /*void */ SignalCallback(/*object*/ state)
            {
                /*InternalTransaction*/ let tx = $.$cast(state, $.$stl.System.Transactions.InternalTransaction);
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(tx)
                    {
                        tx.SignalAsyncCompletion();
                        $.$stl.System.Transactions.TransactionTable.Remove(tx);
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(tx)
                }
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 7120140;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6464780,"p":[{"p":138936321,"g":{"r":0,"d":0,"h":55841694988,"f":50331682},"n":"SignalMethod","d":7120140,"h":51546727692,"f":2097186}],"m":[{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"EnterState","d":7120140,"h":4302087436,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"transactionCompletedDelegate","p":4433164}],"n":"AddOutcomeRegistrant","d":7120140,"h":8597054732,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"EndCommit","d":7120140,"h":12892022028,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"CompleteBlockingClone","d":7120140,"h":17186989324,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"CompleteAbortingClone","d":7120140,"h":21481956620,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"CreateBlockingClone","d":7120140,"h":25776923916,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"CreateAbortingClone","d":7120140,"h":30071891212,"f":16809992},{"r":56229889,"p":[{"n":"tx","p":2794764}],"n":"get_Identifier","d":7120140,"h":34366858508,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"Promote","d":7120140,"h":38661825804,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"PromotedTransactionOutcome","d":7120140,"h":42956793100,"f":16777476},{"r":65537,"p":[{"n":"state","p":131073}],"n":"SignalCallback","d":7120140,"h":60136662284,"f":16777250}],"l":[{"t":138936321,"n":"s_signalMethod","d":7120140,"h":47251760396,"f":4194338}],"c":[{"n":".ctor","o":"$ctor$3","d":7120140,"h":64431629580,"f":16777220}],"h":7120140}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStateEnded; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedEnded`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedNonMSDTCEnded", ($self) => class TransactionStatePromotedNonMSDTCEnded extends $.$stl.System.Transactions.TransactionStateEnded
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                super.EnterState(tx);
                this.CommonEnterState(tx);
                if (!$.$$.System.Threading.ThreadPool.QueueUserWorkItem($.$stl.System.Transactions.TransactionStatePromotedNonMSDTCEnded.SignalMethod, tx))
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.UnexpectedFailureOfThreadPool, null, tx === null ? $.$$.System.Guid.Empty : tx.DistributedTxId);
                }
            }
            /*void */ AddOutcomeRegistrant(/*InternalTransaction*/ tx, /*TransactionCompletedEventHandler?*/ transactionCompletedDelegate)
            {
                if (transactionCompletedDelegate !== null)
                {
                    /*TransactionEventArgs*/ let args = new $.$stl.System.Transactions.TransactionEventArgs().$ctor$2();
                    args._transaction = tx._outcomeSource.InternalClone();
                    transactionCompletedDelegate.Invoke(args._transaction, args);
                }
            }
            /*void */ EndCommit(/*InternalTransaction*/ tx)
            {
                this.PromotedTransactionOutcome(tx);
            }
            /*void */ CompleteBlockingClone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ CompleteAbortingClone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ CreateBlockingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException(tx._innerException, tx.DistributedTxId);
            }
            /*void */ CreateAbortingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException(tx._innerException, tx.DistributedTxId);
            }
            /*Guid */ get_Identifier(/*InternalTransaction*/ tx)
            {
                return tx._distributedTransactionIdentifierNonMSDTC;
            }
            /*void */ Promote(/*InternalTransaction*/ tx)
            {
            }
            /*WaitCallback?*/ static s_signalMethod = null;
            static /*WaitCallback */ get SignalMethod()
            {
                return $.$$.System.Threading.LazyInitializer.EnsureInitialized$3($.$$.System.Threading.WaitCallback, $.$ref(() => $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCEnded.s_signalMethod, ($v) => $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCEnded.s_signalMethod = $v, $.$$.System.Threading.WaitCallback), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$$.System.Object), new ($.$$.System.Func$$($.$$.System.Threading.WaitCallback))().$ctor(this,  () =>
                {
                    return $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCEnded.SignalCallback;
                }, {"r":138936321,"n":"","d":7447820,"h":0,"f":17825794}));
            }
            static /*void */ SignalCallback(/*object*/ state)
            {
                /*InternalTransaction*/ let tx = $.$cast(state, $.$stl.System.Transactions.InternalTransaction);
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(tx)
                    {
                        tx.SignalAsyncCompletion();
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(tx)
                }
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 7447820;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6464780,"p":[{"p":138936321,"g":{"r":0,"d":0,"h":55842022668,"f":50331682},"n":"SignalMethod","d":7447820,"h":51547055372,"f":2097186}],"m":[{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"EnterState","d":7447820,"h":4302415116,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"transactionCompletedDelegate","p":4433164}],"n":"AddOutcomeRegistrant","d":7447820,"h":8597382412,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"EndCommit","d":7447820,"h":12892349708,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"CompleteBlockingClone","d":7447820,"h":17187317004,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"CompleteAbortingClone","d":7447820,"h":21482284300,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"CreateBlockingClone","d":7447820,"h":25777251596,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"CreateAbortingClone","d":7447820,"h":30072218892,"f":16809992},{"r":56229889,"p":[{"n":"tx","p":2794764}],"n":"get_Identifier","d":7447820,"h":34367186188,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"Promote","d":7447820,"h":38662153484,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"PromotedTransactionOutcome","d":7447820,"h":42957120780,"f":16777476},{"r":65537,"p":[{"n":"state","p":131073}],"n":"SignalCallback","d":7447820,"h":60136989964,"f":16777250}],"l":[{"t":138936321,"n":"s_signalMethod","d":7447820,"h":47252088076,"f":4194338}],"c":[{"n":".ctor","o":"$ctor$3","d":7447820,"h":64431957260,"f":16777220}],"h":7447820}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStateEnded; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedNonMSDTCEnded`; }
        });
        
        $asm.$cls("$stl.System.Transactions.EnterpriseServices", ($self) => class EnterpriseServices
        {
            static /*bool */ get EnterpriseServicesOk()
            {
                return false;
            }
            static /*void */ VerifyEnterpriseServicesOk()
            {
                if (!$.$stl.System.Transactions.EnterpriseServices.EnterpriseServicesOk)
                {
                    $.$stl.System.Transactions.EnterpriseServices.ThrowNotSupported();
                }
            }
            static /*Transaction? */ GetContextTransaction()
            {
                if ($.$stl.System.Transactions.EnterpriseServices.EnterpriseServicesOk)
                {
                    $.$stl.System.Transactions.EnterpriseServices.ThrowNotSupported();
                }
                return null;
            }
            /*bool*/ static CreatedServiceDomain = false;
            static /*bool */ UseServiceDomainForCurrent()
            {
                return false;
            }
            static /*void */ PushServiceDomain()
            {
                $.$stl.System.Transactions.EnterpriseServices.ThrowNotSupported();
            }
            static /*void */ LeaveServiceDomain()
            {
                $.$stl.System.Transactions.EnterpriseServices.ThrowNotSupported();
            }
            static /*void */ ThrowNotSupported()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$16($.$stl.System.SR.EsNotSupported);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.CreatedServiceDomain = false;
                }
            }
            static $h = 2204940;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":8592139532,"f":50331688},"n":"EnterpriseServicesOk","d":2204940,"h":4297172236,"f":2097192},{"p":262145,"g":{"r":0,"d":0,"h":30066976012,"f":50331688},"s":{"r":0,"d":0,"h":34361943308,"f":83886120},"n":"CreatedServiceDomain","d":2204940,"h":25772008716,"f":2097192}],"m":[{"r":65537,"n":"VerifyEnterpriseServicesOk","d":2204940,"h":12887106828,"f":16777256},{"r":4302092,"n":"GetContextTransaction","d":2204940,"h":17182074124,"f":16777256},{"r":262145,"n":"UseServiceDomainForCurrent","d":2204940,"h":38656910604,"f":16777256},{"r":65537,"n":"PushServiceDomain","d":2204940,"h":42951877900,"f":16777256},{"r":65537,"n":"LeaveServiceDomain","d":2204940,"h":47246845196,"f":16777256},{"r":65537,"n":"ThrowNotSupported","d":2204940,"h":51541812492,"f":16777250}],"h":2204940}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Transactions.EnterpriseServices`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionInformation", ($self) => class TransactionInformation extends $.$$.System.Object
        {
            /*InternalTransaction*/ _internalTransaction = null;
            $ctor$1(/*InternalTransaction*/ internalTransaction)
            {
                super.$ctor();
                {
                    this._internalTransaction = internalTransaction;
                }
                return this;
            }
            /*string */ get LocalIdentifier()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "LocalIdentifier");
                }
                try
                {
                    return this._internalTransaction.TransactionTraceId.TransactionIdentifier;
                }
                finally
                {
                    {
                        if (etwLog.IsEnabled())
                        {
                            etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "LocalIdentifier");
                        }
                    }
                }
            }
            /*Guid */ get DistributedIdentifier()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "DistributedIdentifier");
                }
                try
                {
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1(this._internalTransaction)
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                            return this._internalTransaction.State.get_Identifier(this._internalTransaction);
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit(this._internalTransaction)
                    }
                }
                finally
                {
                    {
                        if (etwLog.IsEnabled())
                        {
                            etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "DistributedIdentifier");
                        }
                    }
                }
            }
            /*DateTime */ get CreationTime()
            {
                return new $.$$.System.DateTime().$ctor$20(this._internalTransaction.CreationTime);
            }
            /*TransactionStatus */ get Status()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "Status");
                }
                try
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                    return this._internalTransaction.State.get_Status(this._internalTransaction);
                }
                finally
                {
                    {
                        if (etwLog.IsEnabled())
                        {
                            etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "Status");
                        }
                    }
                }
            }
            static $h = 4760844;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17184630028,"f":50331649},"n":"LocalIdentifier","d":4760844,"h":12889662732,"f":2097153},{"p":56229889,"g":{"r":0,"d":0,"h":25774564620,"f":50331649},"n":"DistributedIdentifier","d":4760844,"h":21479597324,"f":2097153},{"p":34275329,"g":{"r":0,"d":0,"h":34364499212,"f":50331649},"n":"CreationTime","d":4760844,"h":30069531916,"f":2097153},{"p":8430860,"g":{"r":0,"d":0,"h":42954433804,"f":50331649},"n":"Status","d":4760844,"h":38659466508,"f":2097153}],"l":[{"t":2794764,"n":"_internalTransaction","d":4760844,"h":4299728140,"f":4194306}],"c":[{"p":[{"n":"internalTransaction","p":2794764}],"n":".ctor","o":"$ctor$1","d":4760844,"h":8594695436,"f":16777224}],"h":4760844}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Transactions.TransactionInformation`; }
        });
        
        $asm.$cls("$stl.System.Transactions.Configuration.ConfigurationStrings", ($self) => class ConfigurationStrings
        {
            /*string*/ static DefaultDistributedTransactionManagerName = null;
            /*string*/ static DefaultMaxTimeout = null;
            /*string*/ static DefaultTimeout = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.DefaultDistributedTransactionManagerName = "";
                }
                {
                    this.DefaultMaxTimeout = "00:10:00";
                }
                {
                    this.DefaultTimeout = "00:01:00";
                }
            }
            static $h = 697612;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"DefaultDistributedTransactionManagerName","d":697612,"h":4295664908,"f":4194344},{"t":1310721,"n":"DefaultMaxTimeout","d":697612,"h":8590632204,"f":4194344},{"t":1310721,"n":"DefaultTimeout","d":697612,"h":12885599500,"f":4194344}],"h":697612}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Transactions.Configuration.ConfigurationStrings`; }
        });
        
        $asm.$cls("$stl.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$$.System.Object.ReferenceEquals($.$stl.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("System.Transactions.Local", $.$stl.System.SR.$type.Assembly);
                    $.$stl.System.SR.s_resourceManager = temp;
                }
                return $.$stl.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$stl.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$stl.System.SR.resourceCulture = value;
            }
            static /*string */ get AsyncFlowAndESInteropNotSupported()
            {
                return "TransactionScope with TransactionScopeAsyncFlowOption.Enabled option is not supported when the TransactionScope is used within Enterprise Service context with Automatic or Full EnterpriseServicesInteropOption enabled in parent scope.";
            }
            static /*string */ get BadAsyncResult()
            {
                return "The IAsyncResult parameter must be the same parameter returned by BeginCommit.";
            }
            static /*string */ get BadResourceManagerId()
            {
                return "Resource Manager Identifiers cannot be Guid.Empty.";
            }
            static /*string */ get CannotPromoteSnapshot()
            {
                return "Transactions with IsolationLevel Snapshot cannot be promoted.";
            }
            static /*string */ get CannotSetCurrent()
            {
                return "Current cannot be set directly when Com+ Interop is enabled.";
            }
            static /*string */ get CurrentDelegateSet()
            {
                return "The delegate for an external current can only be set once.";
            }
            static /*string */ get DisposeScope()
            {
                return "The current TransactionScope is already complete. You should dispose the TransactionScope.";
            }
            static /*string */ get EnlistmentStateException()
            {
                return "The operation is not valid for the current state of the enlistment.";
            }
            static /*string */ get EsNotSupported()
            {
                return "Com+ Interop features cannot be supported.";
            }
            static /*string */ get InternalError()
            {
                return "Internal Error";
            }
            static /*string */ get InvalidArgument()
            {
                return "The argument is invalid.";
            }
            static /*string */ get InvalidIPromotableSinglePhaseNotificationSpecified()
            {
                return "The specified IPromotableSinglePhaseNotification is not the same as the one provided to EnlistPromotableSinglePhase.";
            }
            static /*string */ get InvalidRecoveryInformation()
            {
                return "Transaction Manager in the Recovery Information does not match the configured transaction manager.";
            }
            static /*string */ get InvalidScopeThread()
            {
                return "A TransactionScope must be disposed on the same thread that it was created.";
            }
            static /*string */ get PromotionFailed()
            {
                return "There was an error promoting the transaction to a distributed transaction.";
            }
            static /*string */ get PromotedReturnedInvalidValue()
            {
                return "The Promote method returned an invalid value for the distributed transaction.";
            }
            static /*string */ get PromotedTransactionExists()
            {
                return "The transaction returned from Promote already exists as a distributed transaction.";
            }
            static /*string */ get TooLate()
            {
                return "It is too late to add enlistments to this transaction.";
            }
            static /*string */ get TraceTransactionTimeout()
            {
                return "Transaction Timeout";
            }
            static /*string */ get TransactionAborted()
            {
                return "The transaction has aborted.";
            }
            static /*string */ get TransactionAlreadyCompleted()
            {
                return "DependentTransaction.Complete or CommittableTransaction.Commit has already been called for this transaction.";
            }
            static /*string */ get TransactionIndoubt()
            {
                return "The transaction is in doubt.";
            }
            static /*string */ get TransactionManagerCommunicationException()
            {
                return "Communication with the underlying transaction manager has failed.";
            }
            static /*string */ get TransactionScopeComplete()
            {
                return "The current TransactionScope is already complete.";
            }
            static /*string */ get TransactionScopeIncorrectCurrent()
            {
                return "Transaction.Current has changed inside of the TransactionScope.";
            }
            static /*string */ get TransactionScopeInvalidNesting()
            {
                return "TransactionScope nested incorrectly.";
            }
            static /*string */ get TransactionScopeIsolationLevelDifferentFromTransaction()
            {
                return "The transaction specified for TransactionScope has a different IsolationLevel than the value requested for the scope.";
            }
            static /*string */ get TransactionScopeTimerObjectInvalid()
            {
                return "TransactionScope timer object is invalid.";
            }
            static /*string */ get TransactionStateException()
            {
                return "The operation is not valid for the state of the transaction.";
            }
            static /*string */ get UnexpectedFailureOfThreadPool()
            {
                return "There was an unexpected failure of QueueUserWorkItem.";
            }
            static /*string */ get UnexpectedTimerFailure()
            {
                return "There was an unexpected failure of a timer.";
            }
            static /*string */ get UnrecognizedRecoveryInformation()
            {
                return "The RecoveryInformation provided is not recognized by this version of System.Transactions.";
            }
            static /*string */ get VolEnlistNoRecoveryInfo()
            {
                return "Volatile enlistments do not generate recovery information.";
            }
            static /*string */ get DistributedTxIDInTransactionException()
            {
                return "{0} Distributed Transaction ID is {1}";
            }
            static /*string */ FormatDistributedTxIDInTransactionException(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$$.System.String.Format$8("{0} Distributed Transaction ID is {1}", arg1, arg2);
            }
            static /*string */ get PromoterTypeInvalid()
            {
                return "The specified PromoterType is invalid.";
            }
            static /*string */ get PromoterTypeUnrecognized()
            {
                return "There is a promotable enlistment for the transaction which has a PromoterType value that is not recognized by System.Transactions. {0}";
            }
            static /*string */ FormatPromoterTypeUnrecognized(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("There is a promotable enlistment for the transaction which has a PromoterType value that is not recognized by System.Transactions. {0}", arg1);
            }
            static /*string */ get DistributedNotSupported()
            {
                return "This platform does not support distributed transactions.";
            }
            static /*string */ get TraceSourceOletx()
            {
                return "[Distributed]";
            }
            static /*string */ get TraceConfiguredDefaultTimeoutAdjusted()
            {
                return "Configured DefaultTimeout is greater than configured DefaultMaximumTimeout - adjusting down to DefaultMaximumTimeout";
            }
            static /*string */ get TraceMethodEntered()
            {
                return "Method Entered";
            }
            static /*string */ get TraceMethodExited()
            {
                return "Method Exited";
            }
            static /*string */ get OperationInvalidOnAnEmptyDocument()
            {
                return "The operation is invalid because the document is empty.";
            }
            static /*string */ get CannotAddToClosedDocument()
            {
                return "Cannot add an element to a closed document.";
            }
            static /*string */ get TextNodeAlreadyPopulated()
            {
                return "The text node already has a value.";
            }
            static /*string */ get TraceEnlistment()
            {
                return "Enlistment Created";
            }
            static /*string */ get TraceTransactionPromoted()
            {
                return "Transaction Promoted";
            }
            static /*string */ get TraceEnlistmentNotificationCall()
            {
                return "Enlistment Notification Call";
            }
            static /*string */ get TraceEnlistmentCallbackPositive()
            {
                return "Enlistment Callback Positive";
            }
            static /*string */ get TraceEnlistmentCallbackNegative()
            {
                return "Enlistment Callback Negative";
            }
            static /*string */ get DocumentAlreadyClosed()
            {
                return "Cannot close an element on a closed document.";
            }
            static /*string */ get TraceInternalError()
            {
                return "Internal Error";
            }
            static /*string */ get TraceInvalidOperationException()
            {
                return "InvalidOperationException Thrown";
            }
            static /*string */ get TraceExceptionConsumed()
            {
                return "Exception Consumed";
            }
            static /*string */ get TraceTransactionException()
            {
                return "TransactionException Thrown";
            }
            static /*string */ get TraceTransactionDeserialized()
            {
                return "Transaction Deserialized";
            }
            static /*string */ get TraceTransactionSerialized()
            {
                return "Transaction Serialized";
            }
            static /*string */ get TraceTransactionManagerCreated()
            {
                return "Transaction Manager Instance Created";
            }
            static /*string */ get TraceReenlist()
            {
                return "TransactionManager.Reenlist Called";
            }
            static /*string */ get TraceTransactionCreated()
            {
                return "Transaction Created";
            }
            static /*string */ get TraceTransactionCommitCalled()
            {
                return "CommittableTransaction.Commit Called";
            }
            static /*string */ get TraceTransactionCommitted()
            {
                return "Transaction Committed";
            }
            static /*string */ get TraceTransactionAborted()
            {
                return "Transaction Aborted";
            }
            static /*string */ get TraceTransactionInDoubt()
            {
                return "Transaction InDoubt";
            }
            static /*string */ get TraceTransactionScopeCreated()
            {
                return "TransactionScope Created";
            }
            static /*string */ get TraceTransactionScopeDisposed()
            {
                return "TransactionScope Disposed";
            }
            static /*string */ get ProxyCannotSupportMultipleNodeNames()
            {
                return "MSDTC Proxy cannot support specification of different node names in the same process.";
            }
            static /*string */ get CannotSupportNodeNameSpecification()
            {
                return "Cannot support specification of node name for the distributed transaction manager through System.Transactions due to MSDTC Proxy version.";
            }
            static /*string */ get FailedToCreateTraceSource()
            {
                return "Failed to create trace source.";
            }
            static /*string */ get FailedToInitializeTraceSource()
            {
                return "Failed to initialize trace source.";
            }
            static /*string */ get TraceRecoveryComplete()
            {
                return "TransactionManager.RecoveryComplete Called";
            }
            static /*string */ get TraceCloneCreated()
            {
                return "Clone Created";
            }
            static /*string */ get TraceDependentCloneComplete()
            {
                return "Dependent Clone Completed";
            }
            static /*string */ get TraceDependentCloneCreated()
            {
                return "Dependent Clone Created";
            }
            static /*string */ get TraceTransactionScopeTimeout()
            {
                return "TransactionScope Timeout";
            }
            static /*string */ get TraceTransactionRollbackCalled()
            {
                return "Transaction.Rollback Called";
            }
            static /*string */ get TraceFailure()
            {
                return "Trace Event Type: {0}\\nTrace Code: {1}\\nTrace Description {2}\\nObject: {3}";
            }
            static /*string */ FormatTraceFailure(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3, /*object*/ arg4)
            {
                return $.$$.System.String.Format$11("Trace Event Type: {0}\\nTrace Code: {1}\\nTrace Description {2}\\nObject: {3}", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ arg1, arg2, arg3, arg4 ]));
            }
            static /*string */ get OletxEnlistmentUnexpectedTransactionStatus()
            {
                return "Internal Error - Unexpected transaction status value in enlistment constructor.";
            }
            static /*string */ get UnableToDeserializeTransaction()
            {
                return "Unable to deserialize the transaction.";
            }
            static /*string */ get UnableToDeserializeTransactionInternalError()
            {
                return "Internal Error - Unable to deserialize the transaction.";
            }
            static /*string */ get TransactionAlreadyOver()
            {
                return "The transaction has already been implicitly or explicitly committed or aborted.";
            }
            static /*string */ get EventLogValue()
            {
                return "Process Name: {0}\\nProcess Id: {1}\\nCode: {2}\\nDescription: {3}";
            }
            static /*string */ FormatEventLogValue(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3, /*object*/ arg4)
            {
                return $.$$.System.String.Format$11("Process Name: {0}\\nProcess Id: {1}\\nCode: {2}\\nDescription: {3}", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ arg1, arg2, arg3, arg4 ]));
            }
            static /*string */ get EventLogSourceValue()
            {
                return "Source: {0}";
            }
            static /*string */ FormatEventLogSourceValue(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Source: {0}", arg1);
            }
            static /*string */ get EventLogExceptionValue()
            {
                return "Exception: {0}";
            }
            static /*string */ FormatEventLogExceptionValue(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Exception: {0}", arg1);
            }
            static /*string */ get EventLogEventIdValue()
            {
                return "Event ID: {0}";
            }
            static /*string */ FormatEventLogEventIdValue(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Event ID: {0}", arg1);
            }
            static /*string */ get EventLogTraceValue()
            {
                return "Other information : {0}";
            }
            static /*string */ FormatEventLogTraceValue(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Other information : {0}", arg1);
            }
            static /*string */ get TraceTransactionScopeCurrentTransactionChanged()
            {
                return "TransactionScope Current Transaction Changed";
            }
            static /*string */ get TraceTransactionScopeNestedIncorrectly()
            {
                return "TransactionScope Nested Incorrectly";
            }
            static /*string */ get TraceTransactionScopeIncomplete()
            {
                return "TransactionScope Incomplete";
            }
            static /*string */ get UnableToGetNotificationShimFactory()
            {
                return "Distributed transaction manager is unable to create the NotificationShimFactory object.";
            }
            static /*string */ get CannotGetTransactionIdentifier()
            {
                return "Unable to obtain the transaction identifier.";
            }
            static /*string */ get ReenlistAfterRecoveryComplete()
            {
                return "Calling TransactionManager.Reenlist is not allowed after TransactionManager.RecoveryComplete is called for a given resource manager identifier.";
            }
            static /*string */ get DuplicateRecoveryComplete()
            {
                return "RecoveryComplete must not be called twice by the same resource manager identifier instance.";
            }
            static /*string */ get DtcTransactionManagerUnavailable()
            {
                return "MSDTC Transaction Manager is unavailable.";
            }
            static /*string */ get NetworkTransactionsDisabled()
            {
                return "Network access for Distributed Transaction Manager (MSDTC) has been disabled. Please enable DTC for network access in the security configuration for MSDTC using the Component Services Administrative tool.";
            }
            static /*string */ get TraceSourceLtm()
            {
                return "[Lightweight]";
            }
            static /*string */ get TraceCodeAppDomainUnloading()
            {
                return "AppDomain unloading.";
            }
            static /*string */ get UnhandledException()
            {
                return "Unhandled Exception";
            }
            static /*string */ get ResourceManagerIdDoesNotMatchRecoveryInformation()
            {
                return "The resourceManagerIdentifier does not match the contents of the specified recovery information.";
            }
            static /*string */ get OletxTooManyEnlistments()
            {
                return "The distributed transaction manager does not allow any more durable enlistments on the transaction.";
            }
            static /*string */ get FailedToTraceEvent()
            {
                return "Failed to trace event: {0}.";
            }
            static /*string */ FormatFailedToTraceEvent(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Failed to trace event: {0}.", arg1);
            }
            static /*string */ get TraceSourceBase()
            {
                return "[Base]";
            }
            static /*string */ get DistributedNotSupportedOn32Bits()
            {
                return "Distributed transactions are currently unsupported in 32-bit processes.";
            }
            static /*string */ get ImplicitDistributedTransactionsDisabled()
            {
                return "Implicit distributed transactions have not been enabled. If you're intentionally starting a distributed transaction, set TransactionManager.ImplicitDistributedTransactions to true.";
            }
            static /*string */ get ImplicitDistributedTransactionsCannotBeChanged()
            {
                return "TransactionManager.ImplicitDistributedTransaction cannot be changed once set, or once System.Transactions distributed transactions have been initialized. Set this flag once at the start of your program.";
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$stl.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                if ($.$stl.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$stl.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$stl.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$stl.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$stl.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$stl.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$stl.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$stl.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$stl.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$stl.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$stl.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$stl.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 173324;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":173324}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$stl.System.Transactions.Configuration.DefaultSettingsSection", ($self) => class DefaultSettingsSection extends $.$$.System.Object
        {
            /*DefaultSettingsSection*/ static s_section = null;
            /*TimeSpan*/ static s_timeout;
            static /*DefaultSettingsSection */ GetSection()
            {
                return $.$stl.System.Transactions.Configuration.DefaultSettingsSection.s_section;
            }
            /*string*/ static DistributedTransactionManagerName = null;
            static /*TimeSpan */ get Timeout()
            {
                return $.$stl.System.Transactions.Configuration.DefaultSettingsSection.s_timeout;
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_section = new $.$stl.System.Transactions.Configuration.DefaultSettingsSection().$ctor$1();
                }
                {
                    this.s_timeout = $.$$.System.TimeSpan.Parse$2("00:01:00"/*ConfigurationStrings.DefaultTimeout*/);
                }
                {
                    this.DistributedTransactionManagerName = "";
                }
            }
            static $h = 763148;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":25770566924,"f":50331681},"s":{"r":0,"d":0,"h":30065534220,"f":83886113},"n":"DistributedTransactionManagerName","d":763148,"h":21475599628,"f":2097185},{"p":140574721,"g":{"r":0,"d":0,"h":38655468812,"f":50331681},"n":"Timeout","d":763148,"h":34360501516,"f":2097185}],"m":[{"r":763148,"n":"GetSection","d":763148,"h":12885665036,"f":16777256}],"l":[{"t":763148,"n":"s_section","d":763148,"h":4295730444,"f":4194338},{"t":140574721,"n":"s_timeout","d":763148,"h":8590697740,"f":4194338}],"c":[{"n":".ctor","o":"$ctor$1","d":763148,"h":42950436108,"f":16777217}],"h":763148}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Transactions.Configuration.DefaultSettingsSection`; }
        });
        
        $asm.$cls("$stl.System.Transactions.Configuration.MachineSettingsSection", ($self) => class MachineSettingsSection extends $.$$.System.Object
        {
            /*MachineSettingsSection*/ static s_section = null;
            /*TimeSpan*/ static s_maxTimeout;
            static /*MachineSettingsSection */ GetSection()
            {
                return $.$stl.System.Transactions.Configuration.MachineSettingsSection.s_section;
            }
            static /*TimeSpan */ get MaxTimeout()
            {
                return $.$stl.System.Transactions.Configuration.MachineSettingsSection.s_maxTimeout;
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_section = new $.$stl.System.Transactions.Configuration.MachineSettingsSection().$ctor$1();
                }
                {
                    this.s_maxTimeout = $.$$.System.TimeSpan.Parse$2("00:10:00"/*ConfigurationStrings.DefaultMaxTimeout*/);
                }
            }
            static $h = 828684;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":140574721,"g":{"r":0,"d":0,"h":21475665164,"f":50331681},"n":"MaxTimeout","d":828684,"h":17180697868,"f":2097185}],"m":[{"r":828684,"n":"GetSection","d":828684,"h":12885730572,"f":16777256}],"l":[{"t":828684,"n":"s_section","d":828684,"h":4295795980,"f":4194338},{"t":140574721,"n":"s_maxTimeout","d":828684,"h":8590763276,"f":4194338}],"c":[{"n":".ctor","o":"$ctor$1","d":828684,"h":25770632460,"f":16777217}],"h":828684}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Transactions.Configuration.MachineSettingsSection`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionInterop", ($self) => class TransactionInterop
        {
            static /*OletxTransaction */ ConvertToOletxTransaction(/*Transaction*/ transaction)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(transaction, "transaction");
                $.$$.System.ObjectDisposedException.ThrowIf(transaction.Disposed, transaction);
                if (transaction._complete)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateTransactionCompletedException(transaction.DistributedTxId);
                }
                /*OletxTransaction?*/ let distributedTx = transaction.Promote();
                if (distributedTx === null)
                {
                    throw $.$stl.System.Transactions.Oletx.OletxTransaction.NotSupported();
                }
                return distributedTx;
            }
            /*Guid*/ static PromoterTypeDtc;
            static /*byte[] */ GetExportCookie(/*Transaction*/ transaction, /*byte[]*/ whereabouts)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(transaction, "transaction");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(whereabouts, "whereabouts");
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetExportCookie");
                }
                /*var*/ let whereaboutsCopy = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Byte), null, [whereabouts.length], null);
                $.$$.System.Buffer.BlockCopy(whereabouts, 0, whereaboutsCopy, 0, whereabouts.length);
                $.$stl.System.Transactions.TransactionInterop.ConvertToOletxTransaction(transaction);
                /*byte[]*/ let cookie = $.$stl.System.Transactions.Oletx.OletxTransaction.GetExportCookie(whereaboutsCopy);
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetExportCookie");
                }
                return cookie;
            }
            static /*Transaction */ GetTransactionFromExportCookie(/*byte[]*/ cookie)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(cookie, "cookie");
                if (cookie.length < 32)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$stl.System.SR.InvalidArgument, "cookie");
                }
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetTransactionFromExportCookie");
                }
                /*var*/ let cookieCopy = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Byte), null, [cookie.length], null);
                $.$$.System.Buffer.BlockCopy(cookie, 0, cookieCopy, 0, cookie.length);
                cookie = cookieCopy;
                /*var*/ let txId = new $.$$.System.Guid().$ctor$7($.$$.System.Span$$($.$$.System.Byte).op_Implicit($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, cookie, 16, 16)));
                /*Transaction?*/ let transaction = $.$stl.System.Transactions.TransactionManager.FindPromotedTransaction(txId);
                if ($.$stl.System.Transactions.Transaction.op_Inequality(transaction, null))
                {
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodExit$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetTransactionFromExportCookie");
                    }
                    return transaction;
                }
                /*OletxTransaction*/ let dTx = $.$stl.System.Transactions.Oletx.OletxTransactionManager.GetTransactionFromExportCookie(cookieCopy, txId);
                transaction = $.$stl.System.Transactions.TransactionManager.FindOrCreatePromotedTransaction(txId, dTx);
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetTransactionFromExportCookie");
                }
                return transaction;
            }
            static /*byte[] */ GetTransmitterPropagationToken(/*Transaction*/ transaction)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(transaction, "transaction");
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetTransmitterPropagationToken");
                }
                $.$stl.System.Transactions.TransactionInterop.ConvertToOletxTransaction(transaction);
                /*byte[]*/ let token = $.$stl.System.Transactions.Oletx.OletxTransaction.GetTransmitterPropagationToken();
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetTransmitterPropagationToken");
                }
                return token;
            }
            static /*Transaction */ GetTransactionFromTransmitterPropagationToken(/*byte[]*/ propagationToken)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(propagationToken, "propagationToken");
                if (propagationToken.length < 24)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$stl.System.SR.InvalidArgument, "propagationToken");
                }
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetTransactionFromTransmitterPropagationToken");
                }
                /*var*/ let txId = new $.$$.System.Guid().$ctor$7($.$$.System.Span$$($.$$.System.Byte).op_Implicit($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, propagationToken, 8, 16)));
                /*Transaction?*/ let tx = $.$stl.System.Transactions.TransactionManager.FindPromotedTransaction(txId);
                if ($.$stl.System.Transactions.Transaction.op_Inequality(null, tx))
                {
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodExit$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetTransactionFromTransmitterPropagationToken");
                    }
                    return tx;
                }
                /*OletxTransaction*/ let dTx = $.$stl.System.Transactions.TransactionInterop.GetOletxTransactionFromTransmitterPropagationToken(propagationToken);
                /*Transaction*/ let returnValue = $.$stl.System.Transactions.TransactionManager.FindOrCreatePromotedTransaction(txId, dTx);
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetTransactionFromTransmitterPropagationToken");
                }
                return returnValue;
            }
            static /*IDtcTransaction */ GetDtcTransaction(/*Transaction*/ transaction)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(transaction, "transaction");
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetDtcTransaction");
                }
                $.$stl.System.Transactions.TransactionInterop.ConvertToOletxTransaction(transaction);
                /*IDtcTransaction*/ let transactionNative = $.$stl.System.Transactions.Oletx.OletxTransaction.GetDtcTransaction();
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetDtcTransaction");
                }
                return transactionNative;
            }
            static /*Transaction */ GetTransactionFromDtcTransaction(/*IDtcTransaction*/ transactionNative)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(transactionNative, "transactionNative");
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetTransactionFromDtcTransaction");
                }
                /*Transaction*/ let transaction = $.$stl.System.Transactions.Oletx.OletxTransactionManager.GetTransactionFromDtcTransaction(transactionNative);
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetTransactionFromDtcTransaction");
                }
                return transaction;
            }
            static /*byte[] */ GetWhereabouts()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetWhereabouts");
                }
                /*byte[]*/ let returnValue = $.$stl.System.Transactions.Oletx.OletxTransactionManager.GetWhereabouts();
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetWhereabouts");
                }
                return returnValue;
            }
            static /*OletxTransaction */ GetOletxTransactionFromTransmitterPropagationToken(/*byte[]*/ propagationToken)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(propagationToken, "propagationToken");
                if (propagationToken.length < 24)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$stl.System.SR.InvalidArgument, "propagationToken");
                }
                /*byte[]*/ let propagationTokenCopy = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Byte), null, [propagationToken.length], null);
                $.$$.System.Array.Copy(propagationToken, propagationTokenCopy, propagationToken.length);
                return $.$stl.System.Transactions.Oletx.OletxTransactionManager.GetOletxTransactionFromTransmitterPropagationToken(propagationTokenCopy);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.PromoterTypeDtc = new $.$$.System.Guid().$ctor$8("14229753-FFE1-428D-82B7-DF73045CB8DA");
                }
            }
            static $h = 4826380;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":3515660,"p":[{"n":"transaction","p":4302092}],"n":"ConvertToOletxTransaction","d":4826380,"h":4299793676,"f":16777256},{"r":$.$typeArray($.$$.System.Byte).$h,"p":[{"n":"transaction","p":4302092},{"n":"whereabouts","p":$.$typeArray($.$$.System.Byte).$h}],"n":"GetExportCookie","d":4826380,"h":12889728268,"f":16777249},{"r":4302092,"p":[{"n":"cookie","p":$.$typeArray($.$$.System.Byte).$h}],"n":"GetTransactionFromExportCookie","d":4826380,"h":17184695564,"f":16777249},{"r":$.$typeArray($.$$.System.Byte).$h,"p":[{"n":"transaction","p":4302092}],"n":"GetTransmitterPropagationToken","d":4826380,"h":21479662860,"f":16777249},{"r":4302092,"p":[{"n":"propagationToken","p":$.$typeArray($.$$.System.Byte).$h}],"n":"GetTransactionFromTransmitterPropagationToken","d":4826380,"h":25774630156,"f":16777249},{"r":2532620,"p":[{"n":"transaction","p":4302092}],"n":"GetDtcTransaction","d":4826380,"h":30069597452,"f":16777249},{"r":4302092,"p":[{"n":"transactionNative","p":2532620}],"n":"GetTransactionFromDtcTransaction","d":4826380,"h":34364564748,"f":16777249},{"r":$.$typeArray($.$$.System.Byte).$h,"n":"GetWhereabouts","d":4826380,"h":38659532044,"f":16777249},{"r":3515660,"p":[{"n":"propagationToken","p":$.$typeArray($.$$.System.Byte).$h}],"n":"GetOletxTransactionFromTransmitterPropagationToken","d":4826380,"h":42954499340,"f":16777256}],"l":[{"t":56229889,"n":"PromoterTypeDtc","d":4826380,"h":8594760972,"f":4194337}],"h":4826380}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Transactions.TransactionInterop`; }
        });
        
        $asm.$cls("$stl.System.Obsoletions", ($self) => class Obsoletions
        {
            /*string*/ static SharedUrlFormat = null;
            /*string*/ static SystemTextEncodingUTF7Message = null;
            /*string*/ static SystemTextEncodingUTF7DiagId = null;
            /*string*/ static PrincipalPermissionAttributeMessage = null;
            /*string*/ static PrincipalPermissionAttributeDiagId = null;
            /*string*/ static CodeAccessSecurityMessage = null;
            /*string*/ static CodeAccessSecurityDiagId = null;
            /*string*/ static ConstrainedExecutionRegionMessage = null;
            /*string*/ static ConstrainedExecutionRegionDiagId = null;
            /*string*/ static GlobalAssemblyCacheMessage = null;
            /*string*/ static GlobalAssemblyCacheDiagId = null;
            /*string*/ static ThreadAbortMessage = null;
            /*string*/ static ThreadResetAbortMessage = null;
            /*string*/ static ThreadAbortDiagId = null;
            /*string*/ static DefaultCryptoAlgorithmsMessage = null;
            /*string*/ static DefaultCryptoAlgorithmsDiagId = null;
            /*string*/ static CreatePdbGeneratorMessage = null;
            /*string*/ static CreatePdbGeneratorDiagId = null;
            /*string*/ static AuthenticationManagerMessage = null;
            /*string*/ static AuthenticationManagerDiagId = null;
            /*string*/ static RemotingApisMessage = null;
            /*string*/ static RemotingApisDiagId = null;
            /*string*/ static BinaryFormatterMessage = null;
            /*string*/ static BinaryFormatterDiagId = null;
            /*string*/ static CodeBaseMessage = null;
            /*string*/ static CodeBaseDiagId = null;
            /*string*/ static EscapeUriStringMessage = null;
            /*string*/ static EscapeUriStringDiagId = null;
            /*string*/ static WebRequestMessage = null;
            /*string*/ static WebRequestDiagId = null;
            /*string*/ static DisablePrivateReflectionAttributeMessage = null;
            /*string*/ static DisablePrivateReflectionAttributeDiagId = null;
            /*string*/ static GetContextInfoMessage = null;
            /*string*/ static GetContextInfoDiagId = null;
            /*string*/ static StrongNameKeyPairMessage = null;
            /*string*/ static StrongNameKeyPairDiagId = null;
            /*string*/ static ReflectionOnlyLoadingMessage = null;
            /*string*/ static ReflectionOnlyLoadingDiagId = null;
            /*string*/ static RuntimeEnvironmentMessage = null;
            /*string*/ static RuntimeEnvironmentDiagId = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesMessage = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesDiagId = null;
            /*string*/ static DerivedCryptographicTypesMessage = null;
            /*string*/ static DerivedCryptographicTypesDiagId = null;
            /*string*/ static RijndaelMessage = null;
            /*string*/ static RijndaelDiagId = null;
            /*string*/ static RNGCryptoServiceProviderMessage = null;
            /*string*/ static RNGCryptoServiceProviderDiagId = null;
            /*string*/ static AppDomainCreateUnloadMessage = null;
            /*string*/ static AppDomainCreateUnloadDiagId = null;
            /*string*/ static SuppressIldasmAttributeMessage = null;
            /*string*/ static SuppressIldasmAttributeDiagId = null;
            /*string*/ static X509CertificateImmutableMessage = null;
            /*string*/ static X509CertificateImmutableDiagId = null;
            /*string*/ static PublicKeyPropertyMessage = null;
            /*string*/ static PublicKeyPropertyDiagId = null;
            /*string*/ static X509CertificatePrivateKeyMessage = null;
            /*string*/ static X509CertificatePrivateKeyDiagId = null;
            /*string*/ static ProduceLegacyHmacValuesMessage = null;
            /*string*/ static ProduceLegacyHmacValuesDiagId = null;
            /*string*/ static UseManagedSha1Message = null;
            /*string*/ static UseManagedSha1DiagId = null;
            /*string*/ static CryptoConfigEncodeOIDMessage = null;
            /*string*/ static CryptoConfigEncodeOIDDiagId = null;
            /*string*/ static CorruptedStateRecoveryMessage = null;
            /*string*/ static CorruptedStateRecoveryDiagId = null;
            /*string*/ static Rfc2898CryptDeriveKeyMessage = null;
            /*string*/ static Rfc2898CryptDeriveKeyDiagId = null;
            /*string*/ static CmsSignerCspParamsCtorMessage = null;
            /*string*/ static CmsSignerCspParamsCtorDiagId = null;
            /*string*/ static SignerInfoCounterSigMessage = null;
            /*string*/ static SignerInfoCounterSigDiagId = null;
            /*string*/ static RegexCompileToAssemblyMessage = null;
            /*string*/ static RegexCompileToAssemblyDiagId = null;
            /*string*/ static AssemblyNameMembersMessage = null;
            /*string*/ static AssemblyNameMembersDiagId = null;
            /*string*/ static SystemDataSerializationFormatBinaryMessage = null;
            /*string*/ static SystemDataSerializationFormatBinaryDiagId = null;
            /*string*/ static TlsVersion10and11Message = null;
            /*string*/ static TlsVersion10and11DiagId = null;
            /*string*/ static EncryptionPolicyMessage = null;
            /*string*/ static EncryptionPolicyDiagId = null;
            /*string*/ static EccXmlExportImportMessage = null;
            /*string*/ static EccXmlExportImportDiagId = null;
            /*string*/ static EcDhPublicKeyBlobMessage = null;
            /*string*/ static EcDhPublicKeyBlobDiagId = null;
            /*string*/ static AssemblyNameCodeBaseMessage = null;
            /*string*/ static AssemblyNameCodeBaseDiagId = null;
            /*string*/ static CryptoStringFactoryMessage = null;
            /*string*/ static CryptoStringFactoryDiagId = null;
            /*string*/ static ControlledExecutionRunMessage = null;
            /*string*/ static ControlledExecutionRunDiagId = null;
            /*string*/ static XmlSecureResolverMessage = null;
            /*string*/ static XmlSecureResolverDiagId = null;
            /*string*/ static RsaEncryptDecryptValueMessage = null;
            /*string*/ static RsaEncryptDecryptDiagId = null;
            /*string*/ static JsonSerializerOptionsAddContextMessage = null;
            /*string*/ static JsonSerializerOptionsAddContextDiagId = null;
            /*string*/ static LegacyFormatterMessage = null;
            /*string*/ static LegacyFormatterDiagId = null;
            /*string*/ static LegacyFormatterImplMessage = null;
            /*string*/ static LegacyFormatterImplDiagId = null;
            /*string*/ static RegexExtensibilityImplMessage = null;
            /*string*/ static RegexExtensibilityDiagId = null;
            /*string*/ static AesGcmTagConstructorMessage = null;
            /*string*/ static AesGcmTagConstructorDiagId = null;
            /*string*/ static ThreadVolatileReadWriteMessage = null;
            /*string*/ static ThreadVolatileReadWriteDiagId = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationMessage = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationDiagId = null;
            /*string*/ static LoadFromHashAlgorithmMessage = null;
            /*string*/ static LoadFromHashAlgorithmDiagId = null;
            /*string*/ static X509CtorCertDataObsoleteMessage = null;
            /*string*/ static X509CtorCertDataObsoleteDiagId = null;
            /*string*/ static TlsCipherAlgorithmEnumsMessage = null;
            /*string*/ static TlsCipherAlgorithmEnumsDiagId = null;
            /*string*/ static SystemEventsEventsThreadShutdownMessage = null;
            /*string*/ static SystemEventsEventsThreadShutdownDiagId = null;
            /*string*/ static Rfc2898DeriveBytesCtorMessage = null;
            /*string*/ static Rfc2898DeriveBytesCtorDiagId = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteMessage = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteDiagId = null;
            /*string*/ static XsltSettingsEnableScriptMessage = null;
            /*string*/ static XsltSettingsEnableScriptDiagId = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                }
                {
                    this.SystemTextEncodingUTF7Message = "The UTF-7 encoding is insecure and should not be used. Consider using UTF-8 instead.";
                }
                {
                    this.SystemTextEncodingUTF7DiagId = "SYSLIB0001";
                }
                {
                    this.PrincipalPermissionAttributeMessage = "PrincipalPermissionAttribute is not honored by the runtime and must not be used.";
                }
                {
                    this.PrincipalPermissionAttributeDiagId = "SYSLIB0002";
                }
                {
                    this.CodeAccessSecurityMessage = "Code Access Security is not supported or honored by the runtime.";
                }
                {
                    this.CodeAccessSecurityDiagId = "SYSLIB0003";
                }
                {
                    this.ConstrainedExecutionRegionMessage = "The Constrained Execution Region (CER) feature is not supported.";
                }
                {
                    this.ConstrainedExecutionRegionDiagId = "SYSLIB0004";
                }
                {
                    this.GlobalAssemblyCacheMessage = "The Global Assembly Cache is not supported.";
                }
                {
                    this.GlobalAssemblyCacheDiagId = "SYSLIB0005";
                }
                {
                    this.ThreadAbortMessage = "Thread.Abort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadResetAbortMessage = "Thread.ResetAbort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadAbortDiagId = "SYSLIB0006";
                }
                {
                    this.DefaultCryptoAlgorithmsMessage = "The default implementation of this cryptography algorithm is not supported.";
                }
                {
                    this.DefaultCryptoAlgorithmsDiagId = "SYSLIB0007";
                }
                {
                    this.CreatePdbGeneratorMessage = "The CreatePdbGenerator API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.CreatePdbGeneratorDiagId = "SYSLIB0008";
                }
                {
                    this.AuthenticationManagerMessage = "AuthenticationManager is not supported. Methods will no-op or throw PlatformNotSupportedException.";
                }
                {
                    this.AuthenticationManagerDiagId = "SYSLIB0009";
                }
                {
                    this.RemotingApisMessage = "This Remoting API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.RemotingApisDiagId = "SYSLIB0010";
                }
                {
                    this.BinaryFormatterMessage = "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.";
                }
                {
                    this.BinaryFormatterDiagId = "SYSLIB0011";
                }
                {
                    this.CodeBaseMessage = "Assembly.CodeBase and Assembly.EscapedCodeBase are only included for .NET Framework compatibility. Use Assembly.Location instead.";
                }
                {
                    this.CodeBaseDiagId = "SYSLIB0012";
                }
                {
                    this.EscapeUriStringMessage = "Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.";
                }
                {
                    this.EscapeUriStringDiagId = "SYSLIB0013";
                }
                {
                    this.WebRequestMessage = "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.";
                }
                {
                    this.WebRequestDiagId = "SYSLIB0014";
                }
                {
                    this.DisablePrivateReflectionAttributeMessage = "DisablePrivateReflectionAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.DisablePrivateReflectionAttributeDiagId = "SYSLIB0015";
                }
                {
                    this.GetContextInfoMessage = "Use the Graphics.GetContextInfo overloads that accept arguments for better performance and fewer allocations.";
                }
                {
                    this.GetContextInfoDiagId = "SYSLIB0016";
                }
                {
                    this.StrongNameKeyPairMessage = "Strong name signing is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.StrongNameKeyPairDiagId = "SYSLIB0017";
                }
                {
                    this.ReflectionOnlyLoadingMessage = "ReflectionOnly loading is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ReflectionOnlyLoadingDiagId = "SYSLIB0018";
                }
                {
                    this.RuntimeEnvironmentMessage = "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.";
                }
                {
                    this.RuntimeEnvironmentDiagId = "SYSLIB0019";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesMessage = "JsonSerializerOptions.IgnoreNullValues is obsolete. To ignore null values when serializing, set DefaultIgnoreCondition to JsonIgnoreCondition.WhenWritingNull.";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesDiagId = "SYSLIB0020";
                }
                {
                    this.DerivedCryptographicTypesMessage = "Derived cryptographic types are obsolete. Use the Create method on the base type instead.";
                }
                {
                    this.DerivedCryptographicTypesDiagId = "SYSLIB0021";
                }
                {
                    this.RijndaelMessage = "The Rijndael and RijndaelManaged types are obsolete. Use Aes instead.";
                }
                {
                    this.RijndaelDiagId = "SYSLIB0022";
                }
                {
                    this.RNGCryptoServiceProviderMessage = "RNGCryptoServiceProvider is obsolete. To generate a random number, use one of the RandomNumberGenerator static methods instead.";
                }
                {
                    this.RNGCryptoServiceProviderDiagId = "SYSLIB0023";
                }
                {
                    this.AppDomainCreateUnloadMessage = "Creating and unloading AppDomains is not supported and throws an exception.";
                }
                {
                    this.AppDomainCreateUnloadDiagId = "SYSLIB0024";
                }
                {
                    this.SuppressIldasmAttributeMessage = "SuppressIldasmAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.SuppressIldasmAttributeDiagId = "SYSLIB0025";
                }
                {
                    this.X509CertificateImmutableMessage = "X509Certificate and X509Certificate2 are immutable. Use X509CertificateLoader to create a new certificate.";
                }
                {
                    this.X509CertificateImmutableDiagId = "SYSLIB0026";
                }
                {
                    this.PublicKeyPropertyMessage = "PublicKey.Key is obsolete. Use the appropriate method to get the public key, such as GetRSAPublicKey.";
                }
                {
                    this.PublicKeyPropertyDiagId = "SYSLIB0027";
                }
                {
                    this.X509CertificatePrivateKeyMessage = "X509Certificate2.PrivateKey is obsolete. Use the appropriate method to get the private key, such as GetRSAPrivateKey, or use the CopyWithPrivateKey method to create a new instance with a private key.";
                }
                {
                    this.X509CertificatePrivateKeyDiagId = "SYSLIB0028";
                }
                {
                    this.ProduceLegacyHmacValuesMessage = "ProduceLegacyHmacValues is obsolete. Producing legacy HMAC values is not supported.";
                }
                {
                    this.ProduceLegacyHmacValuesDiagId = "SYSLIB0029";
                }
                {
                    this.UseManagedSha1Message = "HMACSHA1 always uses the algorithm implementation provided by the platform. Use a constructor without the useManagedSha1 parameter.";
                }
                {
                    this.UseManagedSha1DiagId = "SYSLIB0030";
                }
                {
                    this.CryptoConfigEncodeOIDMessage = "EncodeOID is obsolete. Use the ASN.1 functionality provided in System.Formats.Asn1.";
                }
                {
                    this.CryptoConfigEncodeOIDDiagId = "SYSLIB0031";
                }
                {
                    this.CorruptedStateRecoveryMessage = "Recovery from corrupted process state exceptions is not supported; HandleProcessCorruptedStateExceptionsAttribute is ignored.";
                }
                {
                    this.CorruptedStateRecoveryDiagId = "SYSLIB0032";
                }
                {
                    this.Rfc2898CryptDeriveKeyMessage = "Rfc2898DeriveBytes.CryptDeriveKey is obsolete and is not supported. Use PasswordDeriveBytes.CryptDeriveKey instead.";
                }
                {
                    this.Rfc2898CryptDeriveKeyDiagId = "SYSLIB0033";
                }
                {
                    this.CmsSignerCspParamsCtorMessage = "CmsSigner(CspParameters) is obsolete and is not supported. Use an alternative constructor instead.";
                }
                {
                    this.CmsSignerCspParamsCtorDiagId = "SYSLIB0034";
                }
                {
                    this.SignerInfoCounterSigMessage = "ComputeCounterSignature without specifying a CmsSigner is obsolete and is not supported. Use the overload that accepts a CmsSigner.";
                }
                {
                    this.SignerInfoCounterSigDiagId = "SYSLIB0035";
                }
                {
                    this.RegexCompileToAssemblyMessage = "Regex.CompileToAssembly is obsolete and not supported. Use the GeneratedRegexAttribute with the regular expression source generator instead.";
                }
                {
                    this.RegexCompileToAssemblyDiagId = "SYSLIB0036";
                }
                {
                    this.AssemblyNameMembersMessage = "AssemblyName members HashAlgorithm, ProcessorArchitecture, and VersionCompatibility are obsolete and not supported.";
                }
                {
                    this.AssemblyNameMembersDiagId = "SYSLIB0037";
                }
                {
                    this.SystemDataSerializationFormatBinaryMessage = "SerializationFormat.Binary is obsolete and should not be used. See https://aka.ms/serializationformat-binary-obsolete for more information.";
                }
                {
                    this.SystemDataSerializationFormatBinaryDiagId = "SYSLIB0038";
                }
                {
                    this.TlsVersion10and11Message = "TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.";
                }
                {
                    this.TlsVersion10and11DiagId = "SYSLIB0039";
                }
                {
                    this.EncryptionPolicyMessage = "EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.";
                }
                {
                    this.EncryptionPolicyDiagId = "SYSLIB0040";
                }
                {
                    this.EccXmlExportImportMessage = "ToXmlString and FromXmlString have no implementation for ECC types, and are obsolete. Use a standard import and export format such as ExportSubjectPublicKeyInfo or ImportSubjectPublicKeyInfo for public keys and ExportPkcs8PrivateKey or ImportPkcs8PrivateKey for private keys.";
                }
                {
                    this.EccXmlExportImportDiagId = "SYSLIB0042";
                }
                {
                    this.EcDhPublicKeyBlobMessage = "ECDiffieHellmanPublicKey.ToByteArray() and the associated constructor do not have a consistent and interoperable implementation on all platforms. Use ECDiffieHellmanPublicKey.ExportSubjectPublicKeyInfo() instead.";
                }
                {
                    this.EcDhPublicKeyBlobDiagId = "SYSLIB0043";
                }
                {
                    this.AssemblyNameCodeBaseMessage = "AssemblyName.CodeBase and AssemblyName.EscapedCodeBase are obsolete. Using them for loading an assembly is not supported.";
                }
                {
                    this.AssemblyNameCodeBaseDiagId = "SYSLIB0044";
                }
                {
                    this.CryptoStringFactoryMessage = "Cryptographic factory methods accepting an algorithm name are obsolete. Use the parameterless Create factory method on the algorithm type instead.";
                }
                {
                    this.CryptoStringFactoryDiagId = "SYSLIB0045";
                }
                {
                    this.ControlledExecutionRunMessage = "ControlledExecution.Run method may corrupt the process and should not be used in production code.";
                }
                {
                    this.ControlledExecutionRunDiagId = "SYSLIB0046";
                }
                {
                    this.XmlSecureResolverMessage = "XmlSecureResolver is obsolete. Use XmlResolver.ThrowingResolver instead when attempting to forbid XML external entity resolution.";
                }
                {
                    this.XmlSecureResolverDiagId = "SYSLIB0047";
                }
                {
                    this.RsaEncryptDecryptValueMessage = "RSA.EncryptValue and DecryptValue are not supported and throw NotSupportedException. Use RSA.Encrypt and RSA.Decrypt instead.";
                }
                {
                    this.RsaEncryptDecryptDiagId = "SYSLIB0048";
                }
                {
                    this.JsonSerializerOptionsAddContextMessage = "JsonSerializerOptions.AddContext is obsolete. To register a JsonSerializerContext, use either the TypeInfoResolver or TypeInfoResolverChain properties.";
                }
                {
                    this.JsonSerializerOptionsAddContextDiagId = "SYSLIB0049";
                }
                {
                    this.LegacyFormatterMessage = "Formatter-based serialization is obsolete and should not be used.";
                }
                {
                    this.LegacyFormatterDiagId = "SYSLIB0050";
                }
                {
                    this.LegacyFormatterImplMessage = "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.";
                }
                {
                    this.LegacyFormatterImplDiagId = "SYSLIB0051";
                }
                {
                    this.RegexExtensibilityImplMessage = "This API supports obsolete mechanisms for Regex extensibility. It is not supported.";
                }
                {
                    this.RegexExtensibilityDiagId = "SYSLIB0052";
                }
                {
                    this.AesGcmTagConstructorMessage = "AesGcm should indicate the required tag size for encryption and decryption. Use a constructor that accepts the tag size.";
                }
                {
                    this.AesGcmTagConstructorDiagId = "SYSLIB0053";
                }
                {
                    this.ThreadVolatileReadWriteMessage = "Thread.VolatileRead and Thread.VolatileWrite are obsolete. Use Volatile.Read or Volatile.Write respectively instead.";
                }
                {
                    this.ThreadVolatileReadWriteDiagId = "SYSLIB0054";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationMessage = "The underlying hardware instruction does not perform a signed saturate narrowing operation, and it always returns an unsigned result. Use the unsigned overload instead.";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationDiagId = "SYSLIB0055";
                }
                {
                    this.LoadFromHashAlgorithmMessage = "LoadFrom with a custom AssemblyHashAlgorithm is obsolete. Use overloads without an AssemblyHashAlgorithm.";
                }
                {
                    this.LoadFromHashAlgorithmDiagId = "SYSLIB0056";
                }
                {
                    this.X509CtorCertDataObsoleteMessage = "Loading certificate data through the constructor or Import is obsolete. Use X509CertificateLoader instead to load certificates.";
                }
                {
                    this.X509CtorCertDataObsoleteDiagId = "SYSLIB0057";
                }
                {
                    this.TlsCipherAlgorithmEnumsMessage = "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.";
                }
                {
                    this.TlsCipherAlgorithmEnumsDiagId = "SYSLIB0058";
                }
                {
                    this.SystemEventsEventsThreadShutdownMessage = "SystemEvents.EventsThreadShutdown callbacks are not run before the process exits. Use AppDomain.ProcessExit instead.";
                }
                {
                    this.SystemEventsEventsThreadShutdownDiagId = "SYSLIB0059";
                }
                {
                    this.Rfc2898DeriveBytesCtorMessage = "The constructors on Rfc2898DeriveBytes are obsolete. Use the static Pbkdf2 method instead.";
                }
                {
                    this.Rfc2898DeriveBytesCtorDiagId = "SYSLIB0060";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteMessage = "The Queryable MinBy and MaxBy taking an IComparer<TSource> are obsolete. Use the new ones that take an IComparer<TKey>.";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteDiagId = "SYSLIB0061";
                }
                {
                    this.XsltSettingsEnableScriptMessage = "XSLT Script blocks are not supported.";
                }
                {
                    this.XsltSettingsEnableScriptDiagId = "SYSLIB0062";
                }
            }
            static $h = 107788;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"SharedUrlFormat","d":107788,"h":4295075084,"f":4194344},{"t":1310721,"n":"SystemTextEncodingUTF7Message","d":107788,"h":8590042380,"f":4194344},{"t":1310721,"n":"SystemTextEncodingUTF7DiagId","d":107788,"h":12885009676,"f":4194344},{"t":1310721,"n":"PrincipalPermissionAttributeMessage","d":107788,"h":17179976972,"f":4194344},{"t":1310721,"n":"PrincipalPermissionAttributeDiagId","d":107788,"h":21474944268,"f":4194344},{"t":1310721,"n":"CodeAccessSecurityMessage","d":107788,"h":25769911564,"f":4194344},{"t":1310721,"n":"CodeAccessSecurityDiagId","d":107788,"h":30064878860,"f":4194344},{"t":1310721,"n":"ConstrainedExecutionRegionMessage","d":107788,"h":34359846156,"f":4194344},{"t":1310721,"n":"ConstrainedExecutionRegionDiagId","d":107788,"h":38654813452,"f":4194344},{"t":1310721,"n":"GlobalAssemblyCacheMessage","d":107788,"h":42949780748,"f":4194344},{"t":1310721,"n":"GlobalAssemblyCacheDiagId","d":107788,"h":47244748044,"f":4194344},{"t":1310721,"n":"ThreadAbortMessage","d":107788,"h":51539715340,"f":4194344},{"t":1310721,"n":"ThreadResetAbortMessage","d":107788,"h":55834682636,"f":4194344},{"t":1310721,"n":"ThreadAbortDiagId","d":107788,"h":60129649932,"f":4194344},{"t":1310721,"n":"DefaultCryptoAlgorithmsMessage","d":107788,"h":64424617228,"f":4194344},{"t":1310721,"n":"DefaultCryptoAlgorithmsDiagId","d":107788,"h":68719584524,"f":4194344},{"t":1310721,"n":"CreatePdbGeneratorMessage","d":107788,"h":73014551820,"f":4194344},{"t":1310721,"n":"CreatePdbGeneratorDiagId","d":107788,"h":77309519116,"f":4194344},{"t":1310721,"n":"AuthenticationManagerMessage","d":107788,"h":81604486412,"f":4194344},{"t":1310721,"n":"AuthenticationManagerDiagId","d":107788,"h":85899453708,"f":4194344},{"t":1310721,"n":"RemotingApisMessage","d":107788,"h":90194421004,"f":4194344},{"t":1310721,"n":"RemotingApisDiagId","d":107788,"h":94489388300,"f":4194344},{"t":1310721,"n":"BinaryFormatterMessage","d":107788,"h":98784355596,"f":4194344},{"t":1310721,"n":"BinaryFormatterDiagId","d":107788,"h":103079322892,"f":4194344},{"t":1310721,"n":"CodeBaseMessage","d":107788,"h":107374290188,"f":4194344},{"t":1310721,"n":"CodeBaseDiagId","d":107788,"h":111669257484,"f":4194344},{"t":1310721,"n":"EscapeUriStringMessage","d":107788,"h":115964224780,"f":4194344},{"t":1310721,"n":"EscapeUriStringDiagId","d":107788,"h":120259192076,"f":4194344},{"t":1310721,"n":"WebRequestMessage","d":107788,"h":124554159372,"f":4194344},{"t":1310721,"n":"WebRequestDiagId","d":107788,"h":128849126668,"f":4194344},{"t":1310721,"n":"DisablePrivateReflectionAttributeMessage","d":107788,"h":133144093964,"f":4194344},{"t":1310721,"n":"DisablePrivateReflectionAttributeDiagId","d":107788,"h":137439061260,"f":4194344},{"t":1310721,"n":"GetContextInfoMessage","d":107788,"h":141734028556,"f":4194344},{"t":1310721,"n":"GetContextInfoDiagId","d":107788,"h":146028995852,"f":4194344},{"t":1310721,"n":"StrongNameKeyPairMessage","d":107788,"h":150323963148,"f":4194344},{"t":1310721,"n":"StrongNameKeyPairDiagId","d":107788,"h":154618930444,"f":4194344},{"t":1310721,"n":"ReflectionOnlyLoadingMessage","d":107788,"h":158913897740,"f":4194344},{"t":1310721,"n":"ReflectionOnlyLoadingDiagId","d":107788,"h":163208865036,"f":4194344},{"t":1310721,"n":"RuntimeEnvironmentMessage","d":107788,"h":167503832332,"f":4194344},{"t":1310721,"n":"RuntimeEnvironmentDiagId","d":107788,"h":171798799628,"f":4194344},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesMessage","d":107788,"h":176093766924,"f":4194344},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesDiagId","d":107788,"h":180388734220,"f":4194344},{"t":1310721,"n":"DerivedCryptographicTypesMessage","d":107788,"h":184683701516,"f":4194344},{"t":1310721,"n":"DerivedCryptographicTypesDiagId","d":107788,"h":188978668812,"f":4194344},{"t":1310721,"n":"RijndaelMessage","d":107788,"h":193273636108,"f":4194344},{"t":1310721,"n":"RijndaelDiagId","d":107788,"h":197568603404,"f":4194344},{"t":1310721,"n":"RNGCryptoServiceProviderMessage","d":107788,"h":201863570700,"f":4194344},{"t":1310721,"n":"RNGCryptoServiceProviderDiagId","d":107788,"h":206158537996,"f":4194344},{"t":1310721,"n":"AppDomainCreateUnloadMessage","d":107788,"h":210453505292,"f":4194344},{"t":1310721,"n":"AppDomainCreateUnloadDiagId","d":107788,"h":214748472588,"f":4194344},{"t":1310721,"n":"SuppressIldasmAttributeMessage","d":107788,"h":219043439884,"f":4194344},{"t":1310721,"n":"SuppressIldasmAttributeDiagId","d":107788,"h":223338407180,"f":4194344},{"t":1310721,"n":"X509CertificateImmutableMessage","d":107788,"h":227633374476,"f":4194344},{"t":1310721,"n":"X509CertificateImmutableDiagId","d":107788,"h":231928341772,"f":4194344},{"t":1310721,"n":"PublicKeyPropertyMessage","d":107788,"h":236223309068,"f":4194344},{"t":1310721,"n":"PublicKeyPropertyDiagId","d":107788,"h":240518276364,"f":4194344},{"t":1310721,"n":"X509CertificatePrivateKeyMessage","d":107788,"h":244813243660,"f":4194344},{"t":1310721,"n":"X509CertificatePrivateKeyDiagId","d":107788,"h":249108210956,"f":4194344},{"t":1310721,"n":"ProduceLegacyHmacValuesMessage","d":107788,"h":253403178252,"f":4194344},{"t":1310721,"n":"ProduceLegacyHmacValuesDiagId","d":107788,"h":257698145548,"f":4194344},{"t":1310721,"n":"UseManagedSha1Message","d":107788,"h":261993112844,"f":4194344},{"t":1310721,"n":"UseManagedSha1DiagId","d":107788,"h":266288080140,"f":4194344},{"t":1310721,"n":"CryptoConfigEncodeOIDMessage","d":107788,"h":270583047436,"f":4194344},{"t":1310721,"n":"CryptoConfigEncodeOIDDiagId","d":107788,"h":274878014732,"f":4194344},{"t":1310721,"n":"CorruptedStateRecoveryMessage","d":107788,"h":279172982028,"f":4194344},{"t":1310721,"n":"CorruptedStateRecoveryDiagId","d":107788,"h":283467949324,"f":4194344},{"t":1310721,"n":"Rfc2898CryptDeriveKeyMessage","d":107788,"h":287762916620,"f":4194344},{"t":1310721,"n":"Rfc2898CryptDeriveKeyDiagId","d":107788,"h":292057883916,"f":4194344},{"t":1310721,"n":"CmsSignerCspParamsCtorMessage","d":107788,"h":296352851212,"f":4194344},{"t":1310721,"n":"CmsSignerCspParamsCtorDiagId","d":107788,"h":300647818508,"f":4194344},{"t":1310721,"n":"SignerInfoCounterSigMessage","d":107788,"h":304942785804,"f":4194344},{"t":1310721,"n":"SignerInfoCounterSigDiagId","d":107788,"h":309237753100,"f":4194344},{"t":1310721,"n":"RegexCompileToAssemblyMessage","d":107788,"h":313532720396,"f":4194344},{"t":1310721,"n":"RegexCompileToAssemblyDiagId","d":107788,"h":317827687692,"f":4194344},{"t":1310721,"n":"AssemblyNameMembersMessage","d":107788,"h":322122654988,"f":4194344},{"t":1310721,"n":"AssemblyNameMembersDiagId","d":107788,"h":326417622284,"f":4194344},{"t":1310721,"n":"SystemDataSerializationFormatBinaryMessage","d":107788,"h":330712589580,"f":4194344},{"t":1310721,"n":"SystemDataSerializationFormatBinaryDiagId","d":107788,"h":335007556876,"f":4194344},{"t":1310721,"n":"TlsVersion10and11Message","d":107788,"h":339302524172,"f":4194344},{"t":1310721,"n":"TlsVersion10and11DiagId","d":107788,"h":343597491468,"f":4194344},{"t":1310721,"n":"EncryptionPolicyMessage","d":107788,"h":347892458764,"f":4194344},{"t":1310721,"n":"EncryptionPolicyDiagId","d":107788,"h":352187426060,"f":4194344},{"t":1310721,"n":"EccXmlExportImportMessage","d":107788,"h":356482393356,"f":4194344},{"t":1310721,"n":"EccXmlExportImportDiagId","d":107788,"h":360777360652,"f":4194344},{"t":1310721,"n":"EcDhPublicKeyBlobMessage","d":107788,"h":365072327948,"f":4194344},{"t":1310721,"n":"EcDhPublicKeyBlobDiagId","d":107788,"h":369367295244,"f":4194344},{"t":1310721,"n":"AssemblyNameCodeBaseMessage","d":107788,"h":373662262540,"f":4194344},{"t":1310721,"n":"AssemblyNameCodeBaseDiagId","d":107788,"h":377957229836,"f":4194344},{"t":1310721,"n":"CryptoStringFactoryMessage","d":107788,"h":382252197132,"f":4194344},{"t":1310721,"n":"CryptoStringFactoryDiagId","d":107788,"h":386547164428,"f":4194344},{"t":1310721,"n":"ControlledExecutionRunMessage","d":107788,"h":390842131724,"f":4194344},{"t":1310721,"n":"ControlledExecutionRunDiagId","d":107788,"h":395137099020,"f":4194344},{"t":1310721,"n":"XmlSecureResolverMessage","d":107788,"h":399432066316,"f":4194344},{"t":1310721,"n":"XmlSecureResolverDiagId","d":107788,"h":403727033612,"f":4194344},{"t":1310721,"n":"RsaEncryptDecryptValueMessage","d":107788,"h":408022000908,"f":4194344},{"t":1310721,"n":"RsaEncryptDecryptDiagId","d":107788,"h":412316968204,"f":4194344},{"t":1310721,"n":"JsonSerializerOptionsAddContextMessage","d":107788,"h":416611935500,"f":4194344},{"t":1310721,"n":"JsonSerializerOptionsAddContextDiagId","d":107788,"h":420906902796,"f":4194344},{"t":1310721,"n":"LegacyFormatterMessage","d":107788,"h":425201870092,"f":4194344},{"t":1310721,"n":"LegacyFormatterDiagId","d":107788,"h":429496837388,"f":4194344},{"t":1310721,"n":"LegacyFormatterImplMessage","d":107788,"h":433791804684,"f":4194344},{"t":1310721,"n":"LegacyFormatterImplDiagId","d":107788,"h":438086771980,"f":4194344},{"t":1310721,"n":"RegexExtensibilityImplMessage","d":107788,"h":442381739276,"f":4194344},{"t":1310721,"n":"RegexExtensibilityDiagId","d":107788,"h":446676706572,"f":4194344},{"t":1310721,"n":"AesGcmTagConstructorMessage","d":107788,"h":450971673868,"f":4194344},{"t":1310721,"n":"AesGcmTagConstructorDiagId","d":107788,"h":455266641164,"f":4194344},{"t":1310721,"n":"ThreadVolatileReadWriteMessage","d":107788,"h":459561608460,"f":4194344},{"t":1310721,"n":"ThreadVolatileReadWriteDiagId","d":107788,"h":463856575756,"f":4194344},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationMessage","d":107788,"h":468151543052,"f":4194344},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationDiagId","d":107788,"h":472446510348,"f":4194344},{"t":1310721,"n":"LoadFromHashAlgorithmMessage","d":107788,"h":476741477644,"f":4194344},{"t":1310721,"n":"LoadFromHashAlgorithmDiagId","d":107788,"h":481036444940,"f":4194344},{"t":1310721,"n":"X509CtorCertDataObsoleteMessage","d":107788,"h":485331412236,"f":4194344},{"t":1310721,"n":"X509CtorCertDataObsoleteDiagId","d":107788,"h":489626379532,"f":4194344},{"t":1310721,"n":"TlsCipherAlgorithmEnumsMessage","d":107788,"h":493921346828,"f":4194344},{"t":1310721,"n":"TlsCipherAlgorithmEnumsDiagId","d":107788,"h":498216314124,"f":4194344},{"t":1310721,"n":"SystemEventsEventsThreadShutdownMessage","d":107788,"h":502511281420,"f":4194344},{"t":1310721,"n":"SystemEventsEventsThreadShutdownDiagId","d":107788,"h":506806248716,"f":4194344},{"t":1310721,"n":"Rfc2898DeriveBytesCtorMessage","d":107788,"h":511101216012,"f":4194344},{"t":1310721,"n":"Rfc2898DeriveBytesCtorDiagId","d":107788,"h":515396183308,"f":4194344},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteMessage","d":107788,"h":519691150604,"f":4194344},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteDiagId","d":107788,"h":523986117900,"f":4194344},{"t":1310721,"n":"XsltSettingsEnableScriptMessage","d":107788,"h":528281085196,"f":4194344},{"t":1310721,"n":"XsltSettingsEnableScriptDiagId","d":107788,"h":532576052492,"f":4194344}],"h":107788}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Obsoletions`; }
        });
        
        $asm.$cls("$stl.System.Transactions.CheapUnfairReaderWriterLock", ($self) => class CheapUnfairReaderWriterLock extends $.$$.System.Object
        {
            /*object?*/ _writerFinishedEvent = null;
            /*int*/ _readersIn = 0;
            /*int*/ _readersOut = 0;
            /*bool*/ _writerPresent = false;
            /*object?*/ _syncRoot = null;
            /*int*/ static MAX_SPIN_COUNT = 100;
            /*int*/ static SLEEP_TIME = 500;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*object */ get SyncRoot()
            {
                if (this._syncRoot === null)
                {
                    $.$$.System.Threading.Interlocked.CompareExchange$6($.$ref(() => this._syncRoot, ($v) => this._syncRoot = $v, $.$$.System.Object), new $.$$.System.Object().$ctor(), null);
                }
                return this._syncRoot;
            }
            /*bool */ get ReadersPresent()
            {
                return this._readersIn !== this._readersOut;
            }
            /*ManualResetEvent */ get WriterFinishedEvent()
            {
                if (this._writerFinishedEvent === null)
                {
                    $.$$.System.Threading.Interlocked.CompareExchange$6($.$ref(() => this._writerFinishedEvent, ($v) => this._writerFinishedEvent = $v, $.$$.System.Object), new $.$$.System.Threading.ManualResetEvent().$ctor$8(true), null);
                }
                return $.$cast(this._writerFinishedEvent, $.$$.System.Threading.ManualResetEvent);
            }
            /*int */ EnterReadLock()
            {
                /*int*/ let readerIndex;
                do
                {
                    if (this._writerPresent)
                    {
                        this.WriterFinishedEvent.WaitOne();
                    }
                    readerIndex = $.$$.System.Threading.Interlocked.Increment($.$ref(() => this._readersIn, ($v) => this._readersIn = $v, $.$$.System.Int32));
                    if (!this._writerPresent)
                    {
                        break;
                    }
                    $.$$.System.Threading.Interlocked.Decrement($.$ref(() => this._readersIn, ($v) => this._readersIn = $v, $.$$.System.Int32));
                }
                while(true);
                return readerIndex;
            }
            /*void */ EnterWriteLock()
            {
                $.$$.System.Threading.Monitor.Enter$1(this.SyncRoot);
                this._writerPresent = true;
                this.WriterFinishedEvent.Reset();
                do
                {
                    /*int*/ let i = 0;
                    while(this.ReadersPresent && i < 100/*MAX_SPIN_COUNT*/)
                    {
                        $.$$.System.Threading.Thread.Sleep(0);
                        i++;
                    }
                    if (this.ReadersPresent)
                    {
                        $.$$.System.Threading.Thread.Sleep(500/*SLEEP_TIME*/);
                    }
                }
                while(this.ReadersPresent);
            }
            /*void */ ExitReadLock()
            {
                $.$$.System.Threading.Interlocked.Increment($.$ref(() => this._readersOut, ($v) => this._readersOut = $v, $.$$.System.Int32));
            }
            /*void */ ExitWriteLock()
            {
                try
                {
                    this._writerPresent = false;
                    this.WriterFinishedEvent.Set$1();
                }
                finally
                {
                    {
                        $.$$.System.Threading.Monitor.Exit(this.SyncRoot);
                    }
                }
            }
            static $h = 501004;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":131073,"g":{"r":0,"d":0,"h":42950173964,"f":50331650},"n":"SyncRoot","d":501004,"h":38655206668,"f":2097154},{"p":262145,"g":{"r":0,"d":0,"h":51540108556,"f":50331650},"n":"ReadersPresent","d":501004,"h":47245141260,"f":2097154},{"p":128188417,"g":{"r":0,"d":0,"h":60130043148,"f":50331650},"n":"WriterFinishedEvent","d":501004,"h":55835075852,"f":2097154}],"m":[{"r":655361,"n":"EnterReadLock","d":501004,"h":64425010444,"f":16777217},{"r":65537,"n":"EnterWriteLock","d":501004,"h":68719977740,"f":16777217},{"r":65537,"n":"ExitReadLock","d":501004,"h":73014945036,"f":16777217},{"r":65537,"n":"ExitWriteLock","d":501004,"h":77309912332,"f":16777217}],"l":[{"t":131073,"n":"_writerFinishedEvent","d":501004,"h":4295468300,"f":4194306},{"t":655361,"n":"_readersIn","d":501004,"h":8590435596,"f":4194306},{"t":655361,"n":"_readersOut","d":501004,"h":12885402892,"f":4194306},{"t":262145,"n":"_writerPresent","d":501004,"h":17180370188,"f":4194306},{"t":131073,"n":"_syncRoot","d":501004,"h":21475337484,"f":4194306},{"t":655361,"n":"MAX_SPIN_COUNT","d":501004,"h":25770304780,"f":4194338},{"t":655361,"n":"SLEEP_TIME","d":501004,"h":30065272076,"f":4194338}],"c":[{"n":".ctor","o":"$ctor$1","d":501004,"h":34360239372,"f":16777217}],"h":501004}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Transactions.CheapUnfairReaderWriterLock`; }
        });
        
        $asm.$cls("$stl.System.Transactions.Configuration.AppSettings", ($self) => class AppSettings
        {
            /*bool*/ static s_settingsInitialized = false;
            /*object*/ static s_appSettingsLock = null;
            /*bool*/ static s_includeDistributedTxIdInExceptionMessage = false;
            static /*void */ EnsureSettingsLoaded()
            {
                if (!$.$stl.System.Transactions.Configuration.AppSettings.s_settingsInitialized)
                {
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1($.$stl.System.Transactions.Configuration.AppSettings.s_appSettingsLock)
                        {
                            if (!$.$stl.System.Transactions.Configuration.AppSettings.s_settingsInitialized)
                            {
                                $.$stl.System.Transactions.Configuration.AppSettings.s_includeDistributedTxIdInExceptionMessage = false;
                                $.$stl.System.Transactions.Configuration.AppSettings.s_settingsInitialized = true;
                            }
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit($.$stl.System.Transactions.Configuration.AppSettings.s_appSettingsLock)
                    }
                }
            }
            static /*bool */ get IncludeDistributedTxIdInExceptionMessage()
            {
                $.$stl.System.Transactions.Configuration.AppSettings.EnsureSettingsLoaded();
                return $.$stl.System.Transactions.Configuration.AppSettings.s_includeDistributedTxIdInExceptionMessage;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_appSettingsLock = new $.$$.System.Object().$ctor();
                }
            }
            static $h = 632076;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":25770435852,"f":50331688},"n":"IncludeDistributedTxIdInExceptionMessage","d":632076,"h":21475468556,"f":2097192}],"m":[{"r":65537,"n":"EnsureSettingsLoaded","d":632076,"h":17180501260,"f":16777250}],"l":[{"t":262145,"n":"s_settingsInitialized","d":632076,"h":4295599372,"f":4194338},{"t":131073,"n":"s_appSettingsLock","d":632076,"h":8590566668,"f":4194338},{"t":262145,"n":"s_includeDistributedTxIdInExceptionMessage","d":632076,"h":12885533964,"f":4194338}],"h":632076}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Transactions.Configuration.AppSettings`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionTable", ($self) => class TransactionTable extends $.$$.System.Object
        {
            /*Timer*/ _timer = null;
            /*bool*/ _timerEnabled = false;
            /*int*/ static timerInternalExponent = 9;
            /*int*/ _timerInterval = 0;
            /*long*/ _ticks = 0n;
            /*long*/ _lastTimerTime = 0n;
            /*BucketSet*/ _headBucketSet = null;
            /*CheapUnfairReaderWriterLock*/ _rwLock = null;
            $ctor$1()
            {
                super.$ctor();
                {
                    this._timer = new $.$$.System.Threading.Timer().$ctor$3(new $.$$.System.Threading.TimerCallback().$ctor(this, this.ThreadTimer), null, -1/*Timeout.Infinite*/, this._timerInterval);
                    this._timerEnabled = false;
                    this._timerInterval = 1 << 9/*TransactionTable.timerInternalExponent*/;
                    this._ticks = 0n;
                    this._headBucketSet = new $.$stl.System.Transactions.BucketSet().$ctor$1(this, 9223372036854775807n);
                    this._rwLock = new $.$stl.System.Transactions.CheapUnfairReaderWriterLock().$ctor$1();
                }
                return this;
            }
            /*long */ TimeoutTicks(/*TimeSpan*/ timeout)
            {
                if ($.$$.System.TimeSpan.op_Inequality(timeout, $.$$.System.TimeSpan.Zero))
                {
                    /*long*/ let timeoutTicks = ((timeout.Ticks / 10000n) >> BigInt(9/*TransactionTable.timerInternalExponent*/)) + this._ticks;
                    return timeoutTicks + 2n;
                }
                else 
                {
                    return 9223372036854775807n;
                }
            }
            /*TimeSpan */ RecalcTimeout(/*InternalTransaction*/ tx)
            {
                return $.$$.System.TimeSpan.FromMilliseconds$2((tx.AbsoluteTimeout - this._ticks) * BigInt(this._timerInterval));
            }
            /*long */ get CurrentTime()
            {
                if (this._timerEnabled)
                {
                    return this._lastTimerTime;
                }
                else 
                {
                    return $.$$.System.DateTime.UtcNow.Ticks;
                }
            }
            /*int */ Add(/*InternalTransaction*/ txNew)
            {
                /*int*/ let readerIndex;
                readerIndex = this._rwLock.EnterReadLock();
                try
                {
                    if (txNew.AbsoluteTimeout !== 9223372036854775807n)
                    {
                        if (!this._timerEnabled)
                        {
                            if (!this._timer.Change(this._timerInterval, this._timerInterval))
                            {
                                throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException$1(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.UnexpectedTimerFailure, null);
                            }
                            this._lastTimerTime = $.$$.System.DateTime.UtcNow.Ticks;
                            this._timerEnabled = true;
                        }
                    }
                    txNew.CreationTime = this.CurrentTime;
                    this.AddIter(txNew);
                }
                finally
                {
                    {
                        this._rwLock.ExitReadLock();
                    }
                }
                return readerIndex;
            }
            /*void */ AddIter(/*InternalTransaction*/ txNew)
            {
                /*BucketSet*/ let currentBucketSet = this._headBucketSet;
                while(currentBucketSet.AbsoluteTimeout !== txNew.AbsoluteTimeout)
                {
                    /*BucketSet?*/ let lastBucketSet = null;
                    do
                    {
                        /*WeakReference?*/ let nextSetWeak = $.$cast(currentBucketSet.nextSetWeak, $.$$.System.WeakReference);
                        /*BucketSet?*/ let nextBucketSet = null;
                        if (nextSetWeak !== null)
                        {
                            nextBucketSet = $.$cast(nextSetWeak.Target, $.$stl.System.Transactions.BucketSet);
                        }
                        if (nextBucketSet === null)
                        {
                            /*BucketSet*/ let newBucketSet = new $.$stl.System.Transactions.BucketSet().$ctor$1(this, txNew.AbsoluteTimeout);
                            /*WeakReference*/ let newSetWeak = new $.$$.System.WeakReference().$ctor$2(newBucketSet);
                            /*WeakReference?*/ let oldNextSetWeak = $.$cast($.$$.System.Threading.Interlocked.CompareExchange$6($.$ref(() => currentBucketSet.nextSetWeak, ($v) => currentBucketSet.nextSetWeak = $v, $.$$.System.Object), newSetWeak, nextSetWeak), $.$$.System.WeakReference);
                            if (oldNextSetWeak === nextSetWeak)
                            {
                                newBucketSet.prevSet = currentBucketSet;
                            }
                        }
                        else 
                        {
                            lastBucketSet = currentBucketSet;
                            currentBucketSet = nextBucketSet;
                        }
                    }
                    while(currentBucketSet.AbsoluteTimeout > txNew.AbsoluteTimeout);
                    if (currentBucketSet.AbsoluteTimeout !== txNew.AbsoluteTimeout)
                    {
                        /*BucketSet*/ let newBucketSet = new $.$stl.System.Transactions.BucketSet().$ctor$1(this, txNew.AbsoluteTimeout);
                        /*WeakReference*/ let newSetWeak = new $.$$.System.WeakReference().$ctor$2(newBucketSet);
                        $.$$.System.Diagnostics.Debug.Assert$2(lastBucketSet !== null, "lastBucketSet != null");
                        newBucketSet.nextSetWeak = lastBucketSet.nextSetWeak;
                        /*WeakReference?*/ let oldNextSetWeak = $.$cast($.$$.System.Threading.Interlocked.CompareExchange$6($.$ref(() => lastBucketSet.nextSetWeak, ($v) => lastBucketSet.nextSetWeak = $v, $.$$.System.Object), newSetWeak, newBucketSet.nextSetWeak), $.$$.System.WeakReference);
                        if (oldNextSetWeak === newBucketSet.nextSetWeak)
                        {
                            if (oldNextSetWeak !== null)
                            {
                                /*BucketSet?*/ let oldSet = $.$cast(oldNextSetWeak.Target, $.$stl.System.Transactions.BucketSet);
                                if (oldSet !== null)
                                {
                                    oldSet.prevSet = newBucketSet;
                                }
                            }
                            newBucketSet.prevSet = lastBucketSet;
                        }
                        currentBucketSet = lastBucketSet;
                    }
                }
                currentBucketSet.Add(txNew);
            }
            static /*void */ Remove(/*InternalTransaction*/ tx)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(tx._tableBucket !== null, "tx._tableBucket != null");
                tx._tableBucket.Remove(tx);
                tx._tableBucket = null;
            }
            /*void */ ThreadTimer(/*object?*/ state)
            {
                if (!this._timerEnabled)
                {
                    return;
                }
                this._ticks++;
                this._lastTimerTime = $.$$.System.DateTime.UtcNow.Ticks;
                /*BucketSet?*/ let lastBucketSet;
                /*BucketSet*/ let currentBucketSet = this._headBucketSet;
                /*WeakReference?*/ let nextWeakSet;
                /*BucketSet?*/ let nextBucketSet = null;
                nextWeakSet = $.$cast(currentBucketSet.nextSetWeak, $.$$.System.WeakReference);
                if (nextWeakSet !== null)
                {
                    nextBucketSet = $.$cast(nextWeakSet.Target, $.$stl.System.Transactions.BucketSet);
                }
                if (nextBucketSet === null)
                {
                    this._rwLock.EnterWriteLock();
                    try
                    {
                        nextWeakSet = $.$cast(currentBucketSet.nextSetWeak, $.$$.System.WeakReference);
                        if (nextWeakSet !== null)
                        {
                            nextBucketSet = $.$cast(nextWeakSet.Target, $.$stl.System.Transactions.BucketSet);
                        }
                        if (nextBucketSet === null)
                        {
                            if (!this._timer.Change(-1/*Timeout.Infinite*/, -1/*Timeout.Infinite*/))
                            {
                                throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException$1(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.UnexpectedTimerFailure, null);
                            }
                            this._timerEnabled = false;
                            return;
                        }
                    }
                    finally
                    {
                        {
                            this._rwLock.ExitWriteLock();
                        }
                    }
                }
                do
                {
                    do
                    {
                        nextWeakSet = $.$cast(currentBucketSet.nextSetWeak, $.$$.System.WeakReference);
                        if (nextWeakSet === null)
                        {
                            return;
                        }
                        nextBucketSet = $.$cast(nextWeakSet.Target, $.$stl.System.Transactions.BucketSet);
                        if (nextBucketSet === null)
                        {
                            return;
                        }
                        lastBucketSet = currentBucketSet;
                        currentBucketSet = nextBucketSet;
                    }
                    while(currentBucketSet.AbsoluteTimeout > this._ticks);
                    /*WeakReference?*/ let abortingSetsWeak = $.$cast($.$$.System.Threading.Interlocked.CompareExchange$6($.$ref(() => lastBucketSet.nextSetWeak, ($v) => lastBucketSet.nextSetWeak = $v, $.$$.System.Object), null, nextWeakSet), $.$$.System.WeakReference);
                    if (abortingSetsWeak === nextWeakSet)
                    {
                        /*BucketSet?*/ let abortingBucketSets;
                        do
                        {
                            if (abortingSetsWeak !== null)
                            {
                                abortingBucketSets = $.$cast(abortingSetsWeak.Target, $.$stl.System.Transactions.BucketSet);
                            }
                            else 
                            {
                                abortingBucketSets = null;
                            }
                            if (abortingBucketSets !== null)
                            {
                                abortingBucketSets.TimeoutTransactions();
                                abortingSetsWeak = $.$cast(abortingBucketSets.nextSetWeak, $.$$.System.WeakReference);
                            }
                        }
                        while(abortingBucketSets !== null);
                        break;
                    }
                    currentBucketSet = lastBucketSet;
                }
                while(true);
            }
            static $h = 8496396;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":917505,"g":{"r":0,"d":0,"h":55843071244,"f":50331650},"n":"CurrentTime","d":8496396,"h":51548103948,"f":2097154}],"m":[{"r":917505,"p":[{"n":"timeout","p":140574721}],"n":"TimeoutTicks","d":8496396,"h":42958169356,"f":16777224},{"r":140574721,"p":[{"n":"tx","p":2794764}],"n":"RecalcTimeout","d":8496396,"h":47253136652,"f":16777224},{"r":655361,"p":[{"n":"txNew","p":2794764}],"n":"Add","d":8496396,"h":60138038540,"f":16777224},{"r":65537,"p":[{"n":"txNew","p":2794764}],"n":"AddIter","d":8496396,"h":64433005836,"f":16777218},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"Remove","d":8496396,"h":68727973132,"f":16777256},{"r":65537,"p":[{"n":"state","p":131073}],"n":"ThreadTimer","d":8496396,"h":73022940428,"f":16777218}],"l":[{"t":138412033,"n":"_timer","d":8496396,"h":4303463692,"f":4194306},{"t":262145,"n":"_timerEnabled","d":8496396,"h":8598430988,"f":4194306},{"t":655361,"n":"timerInternalExponent","d":8496396,"h":12893398284,"f":4194338},{"t":655361,"n":"_timerInterval","d":8496396,"h":17188365580,"f":4194306},{"t":917505,"n":"_ticks","d":8496396,"h":21483332876,"f":4194306},{"t":917505,"n":"_lastTimerTime","d":8496396,"h":25778300172,"f":4194306},{"t":369932,"n":"_headBucketSet","d":8496396,"h":30073267468,"f":4194306},{"t":501004,"n":"_rwLock","d":8496396,"h":34368234764,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$1","d":8496396,"h":38663202060,"f":16777224}],"h":8496396}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Transactions.TransactionTable`; }
        });
        
        $asm.$cls("$stl.System.Transactions.Oletx.OletxTransactionManager", ($self) => class OletxTransactionManager extends $.$$.System.Object
        {
            /*object?*/ NodeName = null;
            $ctor$1(/*string*/ nodeName)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*IPromotedEnlistment */ ReenlistTransaction(/*Guid*/ resourceManagerIdentifier, /*byte[]*/ resourceManagerRecoveryInformation, /*RecoveringInternalEnlistment*/ internalEnlistment)
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransactionManager.NotSupported();
            }
            /*OletxCommittableTransaction */ CreateTransaction(/*TransactionOptions*/ options)
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransactionManager.NotSupported();
            }
            /*void */ ResourceManagerRecoveryComplete(/*Guid*/ resourceManagerIdentifier)
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransactionManager.NotSupported();
            }
            static /*byte[] */ GetWhereabouts()
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransactionManager.NotSupported();
            }
            static /*Transaction */ GetTransactionFromDtcTransaction(/*IDtcTransaction*/ transactionNative)
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransactionManager.NotSupported();
            }
            static /*OletxTransaction */ GetTransactionFromExportCookie(/*byte[]*/ cookie, /*Guid*/ txId)
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransactionManager.NotSupported();
            }
            static /*OletxTransaction */ GetOletxTransactionFromTransmitterPropagationToken(/*byte[]*/ propagationToken)
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransactionManager.NotSupported();
            }
            static /*Exception */ NotSupported()
            {
                return new $.$$.System.PlatformNotSupportedException().$ctor$16($.$stl.System.SR.DistributedNotSupported);
            }
            static $h = 3646732;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":131073,"g":{"r":0,"d":0,"h":12888548620,"f":50331656},"s":{"r":0,"d":0,"h":17183515916,"f":83886088},"n":"NodeName","d":3646732,"h":8593581324,"f":2097160}],"m":[{"r":2925836,"p":[{"n":"resourceManagerIdentifier","p":56229889},{"n":"resourceManagerRecoveryInformation","p":$.$typeArray($.$$.System.Byte).$h},{"n":"internalEnlistment","p":4039948}],"n":"ReenlistTransaction","d":3646732,"h":25773450508,"f":16777224},{"r":3384588,"p":[{"n":"options","p":5022988}],"n":"CreateTransaction","d":3646732,"h":30068417804,"f":16777224},{"r":65537,"p":[{"n":"resourceManagerIdentifier","p":56229889}],"n":"ResourceManagerRecoveryComplete","d":3646732,"h":34363385100,"f":16777224},{"r":$.$typeArray($.$$.System.Byte).$h,"n":"GetWhereabouts","d":3646732,"h":38658352396,"f":16777256},{"r":4302092,"p":[{"n":"transactionNative","p":2532620}],"n":"GetTransactionFromDtcTransaction","d":3646732,"h":42953319692,"f":16777256},{"r":3515660,"p":[{"n":"cookie","p":$.$typeArray($.$$.System.Byte).$h},{"n":"txId","p":56229889}],"n":"GetTransactionFromExportCookie","d":3646732,"h":47248286988,"f":16777256},{"r":3515660,"p":[{"n":"propagationToken","p":$.$typeArray($.$$.System.Byte).$h}],"n":"GetOletxTransactionFromTransmitterPropagationToken","d":3646732,"h":51543254284,"f":16777256},{"r":47251457,"n":"NotSupported","d":3646732,"h":55838221580,"f":16777256}],"c":[{"p":[{"n":"nodeName","p":1310721}],"n":".ctor","o":"$ctor$1","d":3646732,"h":21478483212,"f":16777224}],"h":3646732}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Transactions.Oletx.OletxTransactionManager`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionManager", ($self) => class TransactionManager
        {
            /*int*/ static RecoveryInformationVersion1 = 1;
            /*int*/ static CurrentRecoveryVersion = 1;
            /*Hashtable?*/ static s_promotedTransactionTable = null;
            /*TransactionTable?*/ static s_transactionTable = null;
            /*TransactionStartedEventHandler?*/ static s_distributedTransactionStartedDelegate = null;
            /*string*/ static DistributedTransactionTrimmingWarning = null;
            /*TransactionStartedEventHandler?*/static  add_DistributedTransactionStarted(value)
            {
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1($.$stl.System.Transactions.TransactionManager.ClassSyncObject)
                    {
                        $.$stl.System.Transactions.TransactionManager.s_distributedTransactionStartedDelegate = $.$cast($.$$.System.Delegate.Combine($.$stl.System.Transactions.TransactionManager.s_distributedTransactionStartedDelegate, value), $.$stl.System.Transactions.TransactionStartedEventHandler);
                        if (value !== null)
                        {
                            $.$stl.System.Transactions.TransactionManager.ProcessExistingTransactions(value);
                        }
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit($.$stl.System.Transactions.TransactionManager.ClassSyncObject)
                }
            }
            /*TransactionStartedEventHandler?*/static  remove_DistributedTransactionStarted(value)
            {
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1($.$stl.System.Transactions.TransactionManager.ClassSyncObject)
                    {
                        $.$stl.System.Transactions.TransactionManager.s_distributedTransactionStartedDelegate = $.$cast($.$$.System.Delegate.Remove($.$stl.System.Transactions.TransactionManager.s_distributedTransactionStartedDelegate, value), $.$stl.System.Transactions.TransactionStartedEventHandler);
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit($.$stl.System.Transactions.TransactionManager.ClassSyncObject)
                }
            }
            static /*void */ ProcessExistingTransactions(/*TransactionStartedEventHandler*/ eventHandler)
            {
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1($.$stl.System.Transactions.TransactionManager.PromotedTransactionTable)
                    {
                        /*IDictionaryEnumerator*/ let e = $.$stl.System.Transactions.TransactionManager.PromotedTransactionTable.GetEnumerator();
                        while(e.System$Collections$IEnumerator$MoveNext())
                        {
                            /*WeakReference*/ let weakRef = $.$cast(e.System$Collections$IDictionaryEnumerator$Value, $.$$.System.WeakReference);
                            let tx;
                            if ($.$is(weakRef.Target, $.$stl.System.Transactions.Transaction, { set $v(v){ tx = v; } }))
                            {
                                /*TransactionEventArgs*/ let args = new $.$stl.System.Transactions.TransactionEventArgs().$ctor$2();
                                args._transaction = tx.InternalClone();
                                eventHandler.Invoke(args._transaction, args);
                            }
                        }
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit($.$stl.System.Transactions.TransactionManager.PromotedTransactionTable)
                }
            }
            static /*void */ FireDistributedTransactionStarted(/*Transaction*/ transaction)
            {
                /*TransactionStartedEventHandler?*/ let localStartedEventHandler = null;
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1($.$stl.System.Transactions.TransactionManager.ClassSyncObject)
                    {
                        localStartedEventHandler = $.$stl.System.Transactions.TransactionManager.s_distributedTransactionStartedDelegate;
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit($.$stl.System.Transactions.TransactionManager.ClassSyncObject)
                }
                if (null !== localStartedEventHandler)
                {
                    /*TransactionEventArgs*/ let args = new $.$stl.System.Transactions.TransactionEventArgs().$ctor$2();
                    args._transaction = transaction.InternalClone();
                    localStartedEventHandler.Invoke(args._transaction, args);
                }
            }
            /*HostCurrentTransactionCallback?*/ static s_currentDelegate = null;
            /*bool*/ static s_currentDelegateSet = false;
            static /*HostCurrentTransactionCallback? */ get HostCurrentCallback()
            {
                return $.$stl.System.Transactions.TransactionManager.s_currentDelegate;
            }
            static /*HostCurrentTransactionCallback? */ set HostCurrentCallback(value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1($.$stl.System.Transactions.TransactionManager.ClassSyncObject)
                    {
                        if ($.$stl.System.Transactions.TransactionManager.s_currentDelegateSet)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$stl.System.SR.CurrentDelegateSet);
                        }
                        $.$stl.System.Transactions.TransactionManager.s_currentDelegateSet = true;
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit($.$stl.System.Transactions.TransactionManager.ClassSyncObject)
                }
                $.$stl.System.Transactions.TransactionManager.s_currentDelegate = value;
            }
            static /*Enlistment */ Reenlist(/*Guid*/ resourceManagerIdentifier, /*byte[]*/ recoveryInformation, /*IEnlistmentNotification*/ enlistmentNotification)
            {
                if ($.$$.System.Guid.op_Equality(resourceManagerIdentifier, $.$$.System.Guid.Empty))
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$stl.System.SR.BadResourceManagerId, "resourceManagerIdentifier");
                }
                $.$$.System.ArgumentNullException.ThrowIfNull$2(recoveryInformation, "recoveryInformation");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(enlistmentNotification, "enlistmentNotification");
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(0/*TraceSourceType.TraceSourceBase*/, "TransactionManager.Reenlist");
                    etwLog.TransactionManagerReenlist(resourceManagerIdentifier);
                }
                /*MemoryStream*/ let stream = new $.$$.System.IO.MemoryStream().$ctor$8(recoveryInformation);
                /*int*/ let recoveryInformationVersion;
                /*string?*/ let nodeName;
                /*byte[]?*/ let resourceManagerRecoveryInformation = null;
                try
                {
                    /*BinaryReader*/ let reader = new $.$$.System.IO.BinaryReader().$ctor$3(stream);
                    recoveryInformationVersion = reader.ReadInt32();
                    if (recoveryInformationVersion === 1/*TransactionManager.RecoveryInformationVersion1*/)
                    {
                        nodeName = reader.ReadString();
                        resourceManagerRecoveryInformation = reader.ReadBytes(((recoveryInformation.length - $.$cast(stream.Position, $.$$.System.Int32)) | 0));
                    }
                    else 
                    {
                        if (etwLog.IsEnabled())
                        {
                            etwLog.TransactionExceptionTrace(0/*TraceSourceType.TraceSourceBase*/, 5/*TransactionExceptionType.UnrecognizedRecoveryInformation*/, "recoveryInformation", $.$$.System.String.Empty);
                        }
                        throw new $.$$.System.ArgumentException().$ctor$13($.$stl.System.SR.UnrecognizedRecoveryInformation, "recoveryInformation");
                    }
                }
                catch($e)
                {
                    if ($e instanceof $.$$.System.IO.EndOfStreamException)
                    {
                        let e = $e;
                        if (etwLog.IsEnabled())
                        {
                            etwLog.TransactionExceptionTrace(0/*TraceSourceType.TraceSourceBase*/, 5/*TransactionExceptionType.UnrecognizedRecoveryInformation*/, "recoveryInformation", $.$$.System.Exception.ToString.call(e));
                        }
                        throw new $.$$.System.ArgumentException().$ctor$12($.$stl.System.SR.UnrecognizedRecoveryInformation, "recoveryInformation", e);
                    }
                    else if ($e instanceof $.$$.System.FormatException)
                    {
                        let e = $e;
                        if (etwLog.IsEnabled())
                        {
                            etwLog.TransactionExceptionTrace(0/*TraceSourceType.TraceSourceBase*/, 5/*TransactionExceptionType.UnrecognizedRecoveryInformation*/, "recoveryInformation", $.$$.System.Exception.ToString.call(e));
                        }
                        throw new $.$$.System.ArgumentException().$ctor$12($.$stl.System.SR.UnrecognizedRecoveryInformation, "recoveryInformation", e);
                    }
                    else
                    {
                        throw $e;
                    }
                }
                finally
                {
                    {
                        stream.Dispose();
                    }
                }
                /*object*/ let syncRoot = new $.$$.System.Object().$ctor();
                /*Enlistment*/ let returnValue = new $.$stl.System.Transactions.Enlistment().$ctor$2(enlistmentNotification, syncRoot);
                $.$stl.System.Transactions.EnlistmentState.EnlistmentStatePromoted.EnterState(returnValue.InternalEnlistment);
                returnValue.InternalEnlistment.PromotedEnlistment = $.$stl.System.Transactions.TransactionManager.DistributedTransactionManager.ReenlistTransaction(resourceManagerIdentifier, resourceManagerRecoveryInformation, $.$cast(returnValue.InternalEnlistment, $.$stl.System.Transactions.RecoveringInternalEnlistment));
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(0/*TraceSourceType.TraceSourceBase*/, "TransactionManager.Reenlist");
                }
                return returnValue;
            }
            static /*OletxTransactionManager */ CheckTransactionManager(/*string?*/ nodeName)
            {
                /*OletxTransactionManager*/ let tm = $.$stl.System.Transactions.TransactionManager.DistributedTransactionManager;
                if (!((tm.NodeName === null && $.$$.System.String.IsNullOrEmpty(nodeName)) || (tm.NodeName !== null && $.$$.System.Object.Equals$1.call(tm.NodeName, nodeName))))
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$stl.System.SR.InvalidRecoveryInformation, "recoveryInformation");
                }
                return tm;
            }
            static /*void */ RecoveryComplete(/*Guid*/ resourceManagerIdentifier)
            {
                if ($.$$.System.Guid.op_Equality(resourceManagerIdentifier, $.$$.System.Guid.Empty))
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$stl.System.SR.BadResourceManagerId, "resourceManagerIdentifier");
                }
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(0/*TraceSourceType.TraceSourceBase*/, "TransactionManager.RecoveryComplete");
                    etwLog.TransactionManagerRecoveryComplete(resourceManagerIdentifier);
                }
                $.$stl.System.Transactions.TransactionManager.DistributedTransactionManager.ResourceManagerRecoveryComplete(resourceManagerIdentifier);
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(0/*TraceSourceType.TraceSourceBase*/, "TransactionManager.RecoveryComplete");
                }
            }
            /*object?*/ static s_classSyncObject = null;
            static /*object */ get ClassSyncObject()
            {
                return $.$$.System.Threading.LazyInitializer.EnsureInitialized$4($.$$.System.Object, $.$ref(() => $.$stl.System.Transactions.TransactionManager.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionManager.s_classSyncObject = $v, $.$$.System.Object));
            }
            static /*IsolationLevel */ get DefaultIsolationLevel()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(0/*TraceSourceType.TraceSourceBase*/, "TransactionManager.get_DefaultIsolationLevel");
                    etwLog.MethodExit$1(0/*TraceSourceType.TraceSourceBase*/, "TransactionManager.get_DefaultIsolationLevel");
                }
                return 0/*IsolationLevel.Serializable*/;
            }
            /*DefaultSettingsSection*/ static DefaultSettings$ = null;
            static /*DefaultSettingsSection */ get DefaultSettings()
            {
                return $.$stl.System.Transactions.TransactionManager.DefaultSettings$ ??= $.$stl.System.Transactions.Configuration.DefaultSettingsSection.GetSection();
            }
            /*MachineSettingsSection*/ static MachineSettings$ = null;
            static /*MachineSettingsSection */ get MachineSettings()
            {
                return $.$stl.System.Transactions.TransactionManager.MachineSettings$ ??= $.$stl.System.Transactions.Configuration.MachineSettingsSection.GetSection();
            }
            /*bool*/ static s_defaultTimeoutValidated = false;
            /*long*/ static s_defaultTimeoutTicks = 0n;
            static /*TimeSpan */ get DefaultTimeout()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(0/*TraceSourceType.TraceSourceBase*/, "TransactionManager.get_DefaultTimeout");
                }
                if (!$.$stl.System.Transactions.TransactionManager.s_defaultTimeoutValidated)
                {
                    $.$$.System.Threading.LazyInitializer.EnsureInitialized$1($.$$.System.Int64, $.$ref(() => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks, ($v) => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks = $v, $.$$.System.Int64), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutValidated, ($v) => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutValidated = $v, null), $.$ref(() => $.$stl.System.Transactions.TransactionManager.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionManager.s_classSyncObject = $v, $.$$.System.Object), new ($.$$.System.Func$$($.$$.System.Int64))().$ctor(this,  () =>
                    {
                        return $.$stl.System.Transactions.TransactionManager.ValidateTimeout($.$stl.System.Transactions.Configuration.DefaultSettingsSection.Timeout).Ticks;
                    }, {"r":917505,"n":"","d":4891916,"h":0,"f":17825794}));
                    if ($.$$.System.Threading.Interlocked.Read($.$ref(() => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks, ($v) => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks = $v, $.$$.System.Int64)) !== $.$stl.System.Transactions.Configuration.DefaultSettingsSection.Timeout.Ticks)
                    {
                        if (etwLog.IsEnabled())
                        {
                            etwLog.ConfiguredDefaultTimeoutAdjusted();
                        }
                    }
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(0/*TraceSourceType.TraceSourceBase*/, "TransactionManager.get_DefaultTimeout");
                }
                return new $.$$.System.TimeSpan().$ctor$7($.$$.System.Threading.Interlocked.Read($.$ref(() => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks, ($v) => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks = $v, $.$$.System.Int64)));
            }
            static /*TimeSpan */ set DefaultTimeout(value)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(0/*TraceSourceType.TraceSourceBase*/, "TransactionManager.set_DefaultTimeout");
                }
                $.$$.System.Threading.Interlocked.Exchange$4($.$ref(() => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks, ($v) => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks = $v, $.$$.System.Int64), $.$stl.System.Transactions.TransactionManager.ValidateTimeout(value).Ticks);
                if ($.$$.System.Threading.Interlocked.Read($.$ref(() => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks, ($v) => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks = $v, $.$$.System.Int64)) !== value.Ticks)
                {
                    if (etwLog.IsEnabled())
                    {
                        etwLog.ConfiguredDefaultTimeoutAdjusted();
                    }
                }
                $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutValidated = true;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(0/*TraceSourceType.TraceSourceBase*/, "TransactionManager.set_DefaultTimeout");
                }
            }
            /*bool*/ static s_cachedMaxTimeout = false;
            /*TimeSpan*/ static s_maximumTimeout;
            static /*TimeSpan */ get MaximumTimeout()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(0/*TraceSourceType.TraceSourceBase*/, "TransactionManager.get_DefaultMaximumTimeout");
                }
                $.$$.System.Threading.LazyInitializer.EnsureInitialized$1($.$$.System.TimeSpan, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.TimeSpan, () => $.$stl.System.Transactions.TransactionManager.s_maximumTimeout, ($v) => $.$stl.System.Transactions.TransactionManager.s_maximumTimeout = $v, null), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => $.$stl.System.Transactions.TransactionManager.s_cachedMaxTimeout, ($v) => $.$stl.System.Transactions.TransactionManager.s_cachedMaxTimeout = $v, null), $.$ref(() => $.$stl.System.Transactions.TransactionManager.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionManager.s_classSyncObject = $v, $.$$.System.Object), new ($.$$.System.Func$$($.$$.System.TimeSpan))().$ctor(this,  () =>
                {
                    return $.$stl.System.Transactions.Configuration.MachineSettingsSection.MaxTimeout;
                }, {"r":140574721,"n":"","d":4891916,"h":0,"f":17825794}));
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(0/*TraceSourceType.TraceSourceBase*/, "TransactionManager.get_DefaultMaximumTimeout");
                }
                return $.$stl.System.Transactions.TransactionManager.s_maximumTimeout;
            }
            static /*TimeSpan */ set MaximumTimeout(value)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(0/*TraceSourceType.TraceSourceBase*/, "TransactionManager.set_DefaultMaximumTimeout");
                }
                $.$$.System.ArgumentOutOfRangeException.ThrowIfLessThan($.$$.System.TimeSpan, value, $.$$.System.TimeSpan.Zero, "value");
                $.$stl.System.Transactions.TransactionManager.s_cachedMaxTimeout = true;
                $.$stl.System.Transactions.TransactionManager.s_maximumTimeout = value;
                $.$$.System.Threading.LazyInitializer.EnsureInitialized$1($.$$.System.Int64, $.$ref(() => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks, ($v) => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks = $v, $.$$.System.Int64), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutValidated, ($v) => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutValidated = $v, null), $.$ref(() => $.$stl.System.Transactions.TransactionManager.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionManager.s_classSyncObject = $v, $.$$.System.Object), new ($.$$.System.Func$$($.$$.System.Int64))().$ctor(this,  () =>
                {
                    return $.$stl.System.Transactions.Configuration.DefaultSettingsSection.Timeout.Ticks;
                }, {"r":917505,"n":"","d":4891916,"h":0,"f":17825794}));
                /*long*/ let defaultTimeoutTicks = $.$$.System.Threading.Interlocked.Read($.$ref(() => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks, ($v) => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks = $v, $.$$.System.Int64));
                $.$$.System.Threading.Interlocked.Exchange$4($.$ref(() => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks, ($v) => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks = $v, $.$$.System.Int64), $.$stl.System.Transactions.TransactionManager.ValidateTimeout(new $.$$.System.TimeSpan().$ctor$7(defaultTimeoutTicks)).Ticks);
                if ($.$$.System.Threading.Interlocked.Read($.$ref(() => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks, ($v) => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks = $v, $.$$.System.Int64)) !== defaultTimeoutTicks)
                {
                    if (etwLog.IsEnabled())
                    {
                        etwLog.ConfiguredDefaultTimeoutAdjusted();
                    }
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(0/*TraceSourceType.TraceSourceBase*/, "TransactionManager.set_DefaultMaximumTimeout");
                }
            }
            static /*bool */ get ImplicitDistributedTransactions()
            {
                return false;
            }
            static /*bool */ set ImplicitDistributedTransactions(value)
            {
                if (value)
                {
                    throw new $.$$.System.PlatformNotSupportedException().$ctor$16($.$stl.System.SR.DistributedNotSupported);
                }
            }
            static /*byte[] */ GetRecoveryInformation(/*string?*/ startupInfo, /*byte[]*/ resourceManagerRecoveryInformation)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(2/*TraceSourceType.TraceSourceOleTx*/, `${"TransactionManager"}.${"GetRecoveryInformation"}`);
                }
                /*MemoryStream*/ let stream = new $.$$.System.IO.MemoryStream().$ctor$3();
                /*byte[]?*/ let returnValue = null;
                try
                {
                    /*BinaryWriter*/ let writer = new $.$$.System.IO.BinaryWriter().$ctor$4(stream);
                    writer.Write$11(1/*CurrentRecoveryVersion*/);
                    if ($.$$.System.String.op_Inequality(startupInfo, null))
                    {
                        writer.Write$17(startupInfo);
                    }
                    else 
                    {
                        writer.Write$17("");
                    }
                    writer.Write$3(resourceManagerRecoveryInformation);
                    writer.Flush();
                    returnValue = stream.ToArray();
                }
                finally
                {
                    {
                        stream.Close();
                    }
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(2/*TraceSourceType.TraceSourceOleTx*/, `${"TransactionManager"}.${"GetRecoveryInformation"}`);
                }
                return returnValue;
            }
            static /*void */ ValidateIsolationLevel(/*IsolationLevel*/ transactionIsolationLevel)
            {
                switch(transactionIsolationLevel)
                {
                    case 0/*IsolationLevel.Serializable*/:
                    case 1/*IsolationLevel.RepeatableRead*/:
                    case 2/*IsolationLevel.ReadCommitted*/:
                    case 3/*IsolationLevel.ReadUncommitted*/:
                    case 6/*IsolationLevel.Unspecified*/:
                    case 5/*IsolationLevel.Chaos*/:
                    case 4/*IsolationLevel.Snapshot*/:
                    break;
                    default:
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("transactionIsolationLevel");
                }
            }
            static /*TimeSpan */ ValidateTimeout(/*TimeSpan*/ transactionTimeout)
            {
                $.$$.System.ArgumentOutOfRangeException.ThrowIfLessThan($.$$.System.TimeSpan, transactionTimeout, $.$$.System.TimeSpan.Zero, "transactionTimeout");
                if ($.$$.System.TimeSpan.op_Inequality($.$stl.System.Transactions.TransactionManager.MaximumTimeout, $.$$.System.TimeSpan.Zero))
                {
                    if ($.$$.System.TimeSpan.op_GreaterThan(transactionTimeout, $.$stl.System.Transactions.TransactionManager.MaximumTimeout) || $.$$.System.TimeSpan.op_Equality(transactionTimeout, $.$$.System.TimeSpan.Zero))
                    {
                        return $.$stl.System.Transactions.TransactionManager.MaximumTimeout;
                    }
                }
                return transactionTimeout;
            }
            static /*Transaction? */ FindPromotedTransaction(/*Guid*/ transactionIdentifier)
            {
                /*Hashtable*/ let promotedTransactionTable = $.$stl.System.Transactions.TransactionManager.PromotedTransactionTable;
                /*WeakReference?*/ let weakRef = $.$cast(promotedTransactionTable.get_Item(transactionIdentifier), $.$$.System.WeakReference);
                if (null !== weakRef)
                {
                    let tx;
                    if ($.$is(weakRef.Target, $.$stl.System.Transactions.Transaction, { set $v(v){ tx = v; } }))
                    {
                        return tx.InternalClone();
                    }
                    else 
                    {
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(promotedTransactionTable)
                            {
                                promotedTransactionTable.Remove(transactionIdentifier);
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(promotedTransactionTable)
                        }
                    }
                }
                return null;
            }
            static /*Transaction */ FindOrCreatePromotedTransaction(/*Guid*/ transactionIdentifier, /*OletxTransaction*/ dtx)
            {
                /*Transaction?*/ let tx = null;
                /*Hashtable*/ let promotedTransactionTable = $.$stl.System.Transactions.TransactionManager.PromotedTransactionTable;
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(promotedTransactionTable)
                    {
                        /*WeakReference?*/ let weakRef = $.$cast(promotedTransactionTable.get_Item(transactionIdentifier), $.$$.System.WeakReference);
                        if (null !== weakRef)
                        {
                            tx = $.$as(weakRef.Target, $.$stl.System.Transactions.Transaction);
                            if ($.$stl.System.Transactions.Transaction.op_Inequality(null, tx))
                            {
                                return tx.InternalClone();
                            }
                            else 
                            {
                                //lock
                                try
                                {
                                    $.$$.System.Threading.Monitor.Enter$1(promotedTransactionTable)
                                    {
                                        promotedTransactionTable.Remove(transactionIdentifier);
                                    }
                                }
                                finally
                                {
                                    $.$$.System.Threading.Monitor.Exit(promotedTransactionTable)
                                }
                            }
                        }
                        tx = new $.$stl.System.Transactions.Transaction().$ctor$4(dtx);
                        tx._internalTransaction._finalizedObject = new $.$stl.System.Transactions.FinalizedObject().$ctor$1(tx._internalTransaction, dtx.Identifier);
                        weakRef = new $.$$.System.WeakReference().$ctor$1(tx, false);
                        promotedTransactionTable.set_Item(dtx.Identifier, weakRef);
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(promotedTransactionTable)
                }
                dtx.SavedLtmPromotedTransaction = tx;
                $.$stl.System.Transactions.TransactionManager.FireDistributedTransactionStarted(tx);
                return tx;
            }
            static /*Hashtable */ get PromotedTransactionTable()
            {
                return $.$$.System.Threading.LazyInitializer.EnsureInitialized$3($.$$.System.Collections.Hashtable, $.$ref(() => $.$stl.System.Transactions.TransactionManager.s_promotedTransactionTable, ($v) => $.$stl.System.Transactions.TransactionManager.s_promotedTransactionTable = $v, $.$$.System.Collections.Hashtable), $.$ref(() => $.$stl.System.Transactions.TransactionManager.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionManager.s_classSyncObject = $v, $.$$.System.Object), new ($.$$.System.Func$$($.$$.System.Collections.Hashtable))().$ctor(this,  () =>
                {
                    return new $.$$.System.Collections.Hashtable().$ctor$16(100);
                }, {"r":31064065,"n":"","d":4891916,"h":0,"f":17825794}));
            }
            static /*TransactionTable */ get TransactionTable()
            {
                return $.$$.System.Threading.LazyInitializer.EnsureInitialized$3($.$stl.System.Transactions.TransactionTable, $.$ref(() => $.$stl.System.Transactions.TransactionManager.s_transactionTable, ($v) => $.$stl.System.Transactions.TransactionManager.s_transactionTable = $v, $.$stl.System.Transactions.TransactionTable), $.$ref(() => $.$stl.System.Transactions.TransactionManager.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionManager.s_classSyncObject = $v, $.$$.System.Object), new ($.$$.System.Func$$($.$stl.System.Transactions.TransactionTable))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionTable().$ctor$1();
                }, {"r":8496396,"n":"","d":4891916,"h":0,"f":17825794}));
            }
            /*OletxTransactionManager?*/ static distributedTransactionManager = null;
            static /*OletxTransactionManager */ get DistributedTransactionManager()
            {
                return $.$$.System.Threading.LazyInitializer.EnsureInitialized$3($.$stl.System.Transactions.Oletx.OletxTransactionManager, $.$ref(() => $.$stl.System.Transactions.TransactionManager.distributedTransactionManager, ($v) => $.$stl.System.Transactions.TransactionManager.distributedTransactionManager = $v, $.$stl.System.Transactions.Oletx.OletxTransactionManager), $.$ref(() => $.$stl.System.Transactions.TransactionManager.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionManager.s_classSyncObject = $v, $.$$.System.Object), new ($.$$.System.Func$$($.$stl.System.Transactions.Oletx.OletxTransactionManager))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.Oletx.OletxTransactionManager().$ctor$1($.$stl.System.Transactions.Configuration.DefaultSettingsSection.DistributedTransactionManagerName);
                }, {"r":3646732,"n":"","d":4891916,"h":0,"f":17825794}));
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.DistributedTransactionTrimmingWarning = "Distributed transactions support may not be compatible with trimming. If your program creates a distributed transaction via System.Transactions, the correctness of the application cannot be guaranteed after trimming.";
                }
                {
                    this.s_maximumTimeout = $.$default($.$$.System.TimeSpan);
                }
            }
            static $h = 4891916;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":2467084,"g":{"r":0,"d":0,"h":64429401356,"f":50331681},"s":{"r":0,"d":0,"h":68724368652,"f":83886113},"n":"HostCurrentCallback","d":4891916,"h":60134434060,"f":2097185},{"p":131073,"g":{"r":0,"d":0,"h":94494172428,"f":50331682},"n":"ClassSyncObject","d":4891916,"h":90199205132,"f":2097186},{"p":3187980,"g":{"r":0,"d":0,"h":103084107020,"f":50331688},"n":"DefaultIsolationLevel","d":4891916,"h":98789139724,"f":2097192},{"p":763148,"g":{"r":0,"d":0,"h":115969008908,"f":50331682},"n":"DefaultSettings","d":4891916,"h":111674041612,"f":2097186},{"p":828684,"g":{"r":0,"d":0,"h":128853910796,"f":50331682},"n":"MachineSettings","d":4891916,"h":124558943500,"f":2097186},{"p":140574721,"g":{"r":0,"d":0,"h":146033779980,"f":50331681},"s":{"r":0,"d":0,"h":150328747276,"f":83886113},"n":"DefaultTimeout","d":4891916,"h":141738812684,"f":2097185},{"p":140574721,"g":{"r":0,"d":0,"h":167508616460,"f":50331681},"s":{"r":0,"d":0,"h":171803583756,"f":83886113},"n":"MaximumTimeout","d":4891916,"h":163213649164,"f":2097185},{"p":262145,"g":{"r":0,"d":0,"h":180393518348,"f":50331681},"s":{"r":0,"d":0,"h":184688485644,"f":83886113,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},"n":"ImplicitDistributedTransactions","d":4891916,"h":176098551052,"f":2097185},{"p":31064065,"g":{"r":0,"d":0,"h":214753256716,"f":50331688},"n":"PromotedTransactionTable","d":4891916,"h":210458289420,"f":2097192},{"p":8496396,"g":{"r":0,"d":0,"h":223343191308,"f":50331688},"n":"TransactionTable","d":4891916,"h":219048224012,"f":2097192},{"p":3646732,"g":{"r":0,"d":0,"h":236228093196,"f":50331688},"n":"DistributedTransactionManager","d":4891916,"h":231933125900,"f":2097192}],"m":[{"r":65537,"p":[{"n":"eventHandler","p":5678348}],"n":"ProcessExistingTransactions","d":4891916,"h":42954564876,"f":16777256},{"r":65537,"p":[{"n":"transaction","p":4302092}],"n":"FireDistributedTransactionStarted","d":4891916,"h":47249532172,"f":16777256},{"r":1746188,"p":[{"n":"resourceManagerIdentifier","p":56229889},{"n":"recoveryInformation","p":$.$typeArray($.$$.System.Byte).$h},{"n":"enlistmentNotification","p":2598156}],"n":"Reenlist","d":4891916,"h":73019335948,"f":16777249},{"r":3646732,"p":[{"n":"nodeName","p":1310721}],"n":"CheckTransactionManager","d":4891916,"h":77314303244,"f":16777250},{"r":65537,"p":[{"n":"resourceManagerIdentifier","p":56229889}],"n":"RecoveryComplete","d":4891916,"h":81609270540,"f":16777249},{"r":$.$typeArray($.$$.System.Byte).$h,"p":[{"n":"startupInfo","p":1310721},{"n":"resourceManagerRecoveryInformation","p":$.$typeArray($.$$.System.Byte).$h}],"n":"GetRecoveryInformation","d":4891916,"h":188983452940,"f":16777256},{"r":65537,"p":[{"n":"transactionIsolationLevel","p":3187980}],"n":"ValidateIsolationLevel","d":4891916,"h":193278420236,"f":16777256},{"r":140574721,"p":[{"n":"transactionTimeout","p":140574721}],"n":"ValidateTimeout","d":4891916,"h":197573387532,"f":16777256},{"r":4302092,"p":[{"n":"transactionIdentifier","p":56229889}],"n":"FindPromotedTransaction","d":4891916,"h":201868354828,"f":16777256},{"r":4302092,"p":[{"n":"transactionIdentifier","p":56229889},{"n":"dtx","p":3515660}],"n":"FindOrCreatePromotedTransaction","d":4891916,"h":206163322124,"f":16777256}],"l":[{"t":655361,"n":"RecoveryInformationVersion1","d":4891916,"h":4299859212,"f":4194338},{"t":655361,"n":"CurrentRecoveryVersion","d":4891916,"h":8594826508,"f":4194338},{"t":31064065,"n":"s_promotedTransactionTable","d":4891916,"h":12889793804,"f":4194338},{"t":8496396,"n":"s_transactionTable","d":4891916,"h":17184761100,"f":4194338},{"t":5678348,"n":"s_distributedTransactionStartedDelegate","d":4891916,"h":21479728396,"f":4194338},{"t":1310721,"n":"DistributedTransactionTrimmingWarning","d":4891916,"h":25774695692,"f":4194344},{"t":2467084,"n":"s_currentDelegate","d":4891916,"h":51544499468,"f":4194344},{"t":262145,"n":"s_currentDelegateSet","d":4891916,"h":55839466764,"f":4194344},{"t":131073,"n":"s_classSyncObject","d":4891916,"h":85904237836,"f":4194338},{"t":262145,"n":"s_defaultTimeoutValidated","d":4891916,"h":133148878092,"f":4194338},{"t":917505,"n":"s_defaultTimeoutTicks","d":4891916,"h":137443845388,"f":4194338},{"t":262145,"n":"s_cachedMaxTimeout","d":4891916,"h":154623714572,"f":4194338},{"t":140574721,"n":"s_maximumTimeout","d":4891916,"h":158918681868,"f":4194338},{"t":3646732,"n":"distributedTransactionManager","d":4891916,"h":227638158604,"f":4194344}],"e":[{"e":5678348,"m":{"r":65537,"p":[{"n":"value","p":5678348}],"n":"add_DistributedTransactionStarted","d":4891916,"h":34364630284,"f":150994977},"r":{"r":65537,"p":[{"n":"value","p":5678348}],"n":"remove_DistributedTransactionStarted","d":4891916,"h":38659597580,"f":285212705},"n":"DistributedTransactionStarted","d":4891916,"h":30069662988,"f":8388641}],"h":4891916}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Transactions.TransactionManager`; }
        });
        
        $asm.$cls("$stl.System.Transactions.Enlistment", ($self) => class Enlistment extends $.$$.System.Object
        {
            /*InternalEnlistment*/ _internalEnlistment = null;
            $ctor$4(/*InternalEnlistment*/ internalEnlistment)
            {
                super.$ctor();
                {
                    this._internalEnlistment = internalEnlistment;
                }
                return this;
            }
            $ctor$1(/*Guid*/ resourceManagerIdentifier, /*InternalTransaction*/ transaction, /*IEnlistmentNotification*/ twoPhaseNotifications, /*ISinglePhaseNotification?*/ singlePhaseNotifications, /*Transaction*/ atomicTransaction)
            {
                super.$ctor();
                {
                    this._internalEnlistment = new $.$stl.System.Transactions.DurableInternalEnlistment().$ctor$5(this, resourceManagerIdentifier, transaction, twoPhaseNotifications, singlePhaseNotifications, atomicTransaction);
                }
                return this;
            }
            $ctor$5(/*InternalTransaction*/ transaction, /*IEnlistmentNotification*/ twoPhaseNotifications, /*ISinglePhaseNotification?*/ singlePhaseNotifications, /*Transaction*/ atomicTransaction, /*EnlistmentOptions*/ enlistmentOptions)
            {
                super.$ctor();
                {
                    if ((enlistmentOptions & 1/*EnlistmentOptions.EnlistDuringPrepareRequired*/) !== 0)
                    {
                        this._internalEnlistment = new $.$stl.System.Transactions.InternalEnlistment().$ctor$3(this, transaction, twoPhaseNotifications, singlePhaseNotifications, atomicTransaction);
                    }
                    else 
                    {
                        this._internalEnlistment = new $.$stl.System.Transactions.Phase1VolatileEnlistment().$ctor$5(this, transaction, twoPhaseNotifications, singlePhaseNotifications, atomicTransaction);
                    }
                }
                return this;
            }
            $ctor$6(/*InternalTransaction*/ transaction, /*IPromotableSinglePhaseNotification*/ promotableSinglePhaseNotification, /*Transaction*/ atomicTransaction)
            {
                super.$ctor();
                {
                    this._internalEnlistment = new $.$stl.System.Transactions.PromotableInternalEnlistment().$ctor$5(this, transaction, promotableSinglePhaseNotification, atomicTransaction);
                }
                return this;
            }
            $ctor$3(/*IEnlistmentNotification*/ twoPhaseNotifications, /*InternalTransaction*/ transaction, /*Transaction*/ atomicTransaction)
            {
                super.$ctor();
                {
                    this._internalEnlistment = new $.$stl.System.Transactions.InternalEnlistment().$ctor$1(this, twoPhaseNotifications, transaction, atomicTransaction);
                }
                return this;
            }
            $ctor$2(/*IEnlistmentNotification*/ twoPhaseNotifications, /*object*/ syncRoot)
            {
                super.$ctor();
                {
                    this._internalEnlistment = new $.$stl.System.Transactions.RecoveringInternalEnlistment().$ctor$7(this, twoPhaseNotifications, syncRoot);
                }
                return this;
            }
            /*void */ Done()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "Done");
                    etwLog.EnlistmentDone$1(this._internalEnlistment);
                }
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this._internalEnlistment.SyncRoot)
                    {
                        this._internalEnlistment.State.EnlistmentDone(this._internalEnlistment);
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this._internalEnlistment.SyncRoot)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "Done");
                }
            }
            /*InternalEnlistment */ get InternalEnlistment()
            {
                return this._internalEnlistment;
            }
            static $h = 1746188;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":2729228,"g":{"r":0,"d":0,"h":42951419148,"f":50331656},"n":"InternalEnlistment","d":1746188,"h":38656451852,"f":2097160}],"m":[{"r":65537,"n":"Done","d":1746188,"h":34361484556,"f":16777217}],"l":[{"t":2729228,"n":"_internalEnlistment","d":1746188,"h":4296713484,"f":4194312}],"c":[{"p":[{"n":"internalEnlistment","p":2729228}],"n":".ctor","o":"$ctor$4","d":1746188,"h":8591680780,"f":16777224},{"p":[{"n":"resourceManagerIdentifier","p":56229889},{"n":"transaction","p":2794764},{"n":"twoPhaseNotifications","p":2598156},{"n":"singlePhaseNotifications","p":3056908},{"n":"atomicTransaction","p":4302092}],"n":".ctor","o":"$ctor$1","d":1746188,"h":12886648076,"f":16777224},{"p":[{"n":"transaction","p":2794764},{"n":"twoPhaseNotifications","p":2598156},{"n":"singlePhaseNotifications","p":3056908},{"n":"atomicTransaction","p":4302092},{"n":"enlistmentOptions","p":1877260}],"n":".ctor","o":"$ctor$5","d":1746188,"h":17181615372,"f":16777224},{"p":[{"n":"transaction","p":2794764},{"n":"promotableSinglePhaseNotification","p":2860300},{"n":"atomicTransaction","p":4302092}],"n":".ctor","o":"$ctor$6","d":1746188,"h":21476582668,"f":16777224},{"p":[{"n":"twoPhaseNotifications","p":2598156},{"n":"transaction","p":2794764},{"n":"atomicTransaction","p":4302092}],"n":".ctor","o":"$ctor$3","d":1746188,"h":25771549964,"f":16777224},{"p":[{"n":"twoPhaseNotifications","p":2598156},{"n":"syncRoot","p":131073}],"n":".ctor","o":"$ctor$2","d":1746188,"h":30066517260,"f":16777224}],"h":1746188}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Transactions.Enlistment`; }
        });
        
        $asm.$cls("$stl.System.Transactions.BucketSet", ($self) => class BucketSet extends $.$$.System.Object
        {
            /*object?*/ nextSetWeak = null;
            /*BucketSet?*/ prevSet = null;
            /*TransactionTable*/ _table = null;
            /*long*/ _absoluteTimeout = 0n;
            /*Bucket*/ headBucket = null;
            $ctor$1(/*TransactionTable*/ table, /*long*/ absoluteTimeout)
            {
                super.$ctor();
                {
                    this.headBucket = new $.$stl.System.Transactions.Bucket().$ctor$1(this);
                    this._table = table;
                    this._absoluteTimeout = absoluteTimeout;
                }
                return this;
            }
            /*long */ get AbsoluteTimeout()
            {
                return this._absoluteTimeout;
            }
            /*void */ Add(/*InternalTransaction*/ newTx)
            {
                while(!this.headBucket.Add(newTx))
                {
                }
            }
            /*void */ TimeoutTransactions()
            {
                /*Bucket?*/ let currentBucket = this.headBucket;
                do
                {
                    currentBucket.TimeoutTransactions();
                    /*WeakReference?*/ let nextWeakBucket = currentBucket.nextBucketWeak;
                    if (nextWeakBucket !== null)
                    {
                        currentBucket = $.$cast(nextWeakBucket.Target, $.$stl.System.Transactions.Bucket);
                    }
                    else 
                    {
                        currentBucket = null;
                    }
                }
                while(currentBucket !== null);
            }
            static $h = 369932;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":917505,"g":{"r":0,"d":0,"h":34360108300,"f":50331656},"n":"AbsoluteTimeout","d":369932,"h":30065141004,"f":2097160}],"m":[{"r":65537,"p":[{"n":"newTx","p":2794764}],"n":"Add","d":369932,"h":38655075596,"f":16777224},{"r":65537,"n":"TimeoutTransactions","d":369932,"h":42950042892,"f":16777224}],"l":[{"t":131073,"n":"nextSetWeak","d":369932,"h":4295337228,"f":4194312},{"t":369932,"n":"prevSet","d":369932,"h":8590304524,"f":4194312},{"t":8496396,"n":"_table","d":369932,"h":12885271820,"f":4194306},{"t":917505,"n":"_absoluteTimeout","d":369932,"h":17180239116,"f":4194306},{"t":304396,"n":"headBucket","d":369932,"h":21475206412,"f":4194312}],"c":[{"p":[{"n":"table","p":8496396},{"n":"absoluteTimeout","p":917505}],"n":".ctor","o":"$ctor$1","d":369932,"h":25770173708,"f":16777224}],"h":369932}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Transactions.BucketSet`; }
        });
        
        $asm.$cls("$stl.System.Transactions.Bucket", ($self) => class Bucket extends $.$$.System.Object
        {
            /*bool*/ _timedOut = false;
            /*int*/ _index = 0;
            /*int*/ _size = 0;
            /*InternalTransaction?[]*/ _transactions = null;
            /*WeakReference?*/ nextBucketWeak = null;
            /*Bucket?*/ _previous = null;
            /*BucketSet*/ _owningSet = null;
            $ctor$1(/*BucketSet*/ owningSet)
            {
                super.$ctor();
                {
                    this._timedOut = false;
                    this._index = -1;
                    this._size = 1024;
                    this._transactions = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$stl.System.Transactions.InternalTransaction), null, [this._size], null);
                    this._owningSet = owningSet;
                }
                return this;
            }
            /*bool */ Add(/*InternalTransaction*/ tx)
            {
                /*int*/ let currentIndex = $.$$.System.Threading.Interlocked.Increment($.$ref(() => this._index, ($v) => this._index = $v, $.$$.System.Int32));
                if (currentIndex < this._size)
                {
                    tx._tableBucket = this;
                    tx._bucketIndex = currentIndex;
                    $.$$.System.Threading.Interlocked.MemoryBarrier();
                    $.$$.System.Array.$WriteT1.call(this._transactions, tx, currentIndex);
                    if (this._timedOut)
                    {
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(tx)
                            {
                                tx.State.Timeout(tx);
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(tx)
                        }
                    }
                }
                else 
                {
                    /*Bucket*/ let newBucket = new $.$stl.System.Transactions.Bucket().$ctor$1(this._owningSet);
                    newBucket.nextBucketWeak = new $.$$.System.WeakReference().$ctor$2(this);
                    /*Bucket*/ let oldBucket = $.$$.System.Threading.Interlocked.CompareExchange$14($.$stl.System.Transactions.Bucket, $.$ref(() => this._owningSet.headBucket, ($v) => this._owningSet.headBucket = $v, $.$stl.System.Transactions.Bucket), newBucket, this);
                    if (oldBucket === this)
                    {
                        this._previous = newBucket;
                    }
                    return false;
                }
                return true;
            }
            /*void */ Remove(/*InternalTransaction*/ tx)
            {
                $.$$.System.Array.$WriteT1.call(this._transactions, null, tx._bucketIndex);
            }
            /*void */ TimeoutTransactions()
            {
                /*int*/ let i;
                /*int*/ let transactionCount = this._index;
                this._timedOut = true;
                $.$$.System.Threading.Interlocked.MemoryBarrier();
                for(i = 0; i <= transactionCount && i < this._size; i++)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(transactionCount === this._index, "Index changed timing out transactions");
                    /*InternalTransaction?*/ let tx = $.$$.System.Array.$ReadT1.call(this._transactions, i);
                    if (tx !== null)
                    {
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(tx)
                            {
                                tx.State.Timeout(tx);
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(tx)
                        }
                    }
                }
            }
            static $h = 304396;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"tx","p":2794764}],"n":"Add","d":304396,"h":38655010060,"f":16777224},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"Remove","d":304396,"h":42949977356,"f":16777224},{"r":65537,"n":"TimeoutTransactions","d":304396,"h":47244944652,"f":16777224}],"l":[{"t":262145,"n":"_timedOut","d":304396,"h":4295271692,"f":4194306},{"t":655361,"n":"_index","d":304396,"h":8590238988,"f":4194306},{"t":655361,"n":"_size","d":304396,"h":12885206284,"f":4194306},{"t":$.$typeArray($.$stl.System.Transactions.InternalTransaction).$h,"n":"_transactions","d":304396,"h":17180173580,"f":4194306},{"t":144637953,"n":"nextBucketWeak","d":304396,"h":21475140876,"f":4194312},{"t":304396,"n":"_previous","d":304396,"h":25770108172,"f":4194306},{"t":369932,"n":"_owningSet","d":304396,"h":30065075468,"f":4194306}],"c":[{"p":[{"n":"owningSet","p":369932}],"n":".ctor","o":"$ctor$1","d":304396,"h":34360042764,"f":16777224}],"h":304396}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Transactions.Bucket`; }
        });
        
        $asm.$cls("$stl.System.Transactions.CallContextCurrentData", ($self) => class CallContextCurrentData
        {
            /*AsyncLocal<ContextKey?>*/ static s_currentTransaction = null;
            /*ConditionalWeakTable<ContextKey, ContextData>*/ static s_contextDataTable = null;
            static /*ContextData */ CreateOrGetCurrentData(/*ContextKey*/ contextKey)
            {
                $.$stl.System.Transactions.CallContextCurrentData.s_currentTransaction.Value = contextKey;
                return $.$stl.System.Transactions.CallContextCurrentData.s_contextDataTable.GetValue(contextKey, new $.$$.System.Runtime.CompilerServices.ConditionalWeakTable$$$($.$stl.System.Transactions.ContextKey, $.$stl.System.Transactions.ContextData).CreateValueCallback().$ctor(this,  (/*env*/ env) =>
                {
                    return new $.$stl.System.Transactions.ContextData().$ctor$1(true);
                }, {"r":894220,"p":[{"n":"env","p":959756}],"n":"","d":435468,"h":0,"f":17825794}));
            }
            static /*void */ ClearCurrentData(/*ContextKey?*/ contextKey, /*bool*/ removeContextData)
            {
                /*ContextKey?*/ let key = $.$stl.System.Transactions.CallContextCurrentData.s_currentTransaction.Value;
                if (contextKey !== null || key !== null)
                {
                    if (removeContextData)
                    {
                        $.$stl.System.Transactions.CallContextCurrentData.s_contextDataTable.Remove$1(contextKey ?? key);
                    }
                    if (key !== null)
                    {
                        $.$stl.System.Transactions.CallContextCurrentData.s_currentTransaction.Value = null;
                    }
                }
            }
            static /*bool */ TryGetCurrentData(/*out ContextData?*/ currentData)
            {
                currentData.$v = null;
                /*ContextKey?*/ let contextKey = $.$stl.System.Transactions.CallContextCurrentData.s_currentTransaction.Value;
                if (contextKey === null)
                {
                    return false;
                }
                else 
                {
                    return $.$stl.System.Transactions.CallContextCurrentData.s_contextDataTable.TryGetValue(contextKey, currentData);
                }
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_currentTransaction = new ($.$$.System.Threading.AsyncLocal$$($.$stl.System.Transactions.ContextKey))().$ctor$1();
                }
                {
                    this.s_contextDataTable = new ($.$$.System.Runtime.CompilerServices.ConditionalWeakTable$$$($.$stl.System.Transactions.ContextKey, $.$stl.System.Transactions.ContextData))().$ctor$1();
                }
            }
            static $h = 435468;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":894220,"p":[{"n":"contextKey","p":959756}],"n":"CreateOrGetCurrentData","d":435468,"h":12885337356,"f":16777249},{"r":65537,"p":[{"n":"contextKey","p":959756},{"n":"removeContextData","p":262145}],"n":"ClearCurrentData","d":435468,"h":17180304652,"f":16777249},{"r":262145,"p":[{"n":"currentData","p":894220,"f":2}],"n":"TryGetCurrentData","d":435468,"h":21475271948,"f":16777249}],"l":[{"t":$.$$.System.Threading.AsyncLocal$$($.$stl.System.Transactions.ContextKey).$h,"n":"s_currentTransaction","d":435468,"h":4295402764,"f":4194338},{"t":$.$$.System.Runtime.CompilerServices.ConditionalWeakTable$$$($.$stl.System.Transactions.ContextKey, $.$stl.System.Transactions.ContextData).$h,"n":"s_contextDataTable","d":435468,"h":8590370060,"f":4194338}],"h":435468}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Transactions.CallContextCurrentData`; }
        });
        
        $asm.$cls("$stl.System.Transactions.ContextKey", ($self) => class ContextKey extends $.$$.System.Object
        {
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 959756;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"c":[{"n":".ctor","o":"$ctor$1","d":959756,"h":4295927052,"f":16777217}],"h":959756}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Transactions.ContextKey`; }
        });
        
        $asm.$cls("$stl.System.Transactions.ContextData", ($self) => class ContextData extends $.$$.System.Object
        {
            /*TransactionScope?*/ CurrentScope = null;
            /*Transaction?*/ CurrentTransaction = null;
            /*DefaultComContextState*/ DefaultComContextState = 0;
            /*WeakReference?*/ WeakDefaultComContext = null;
            /*bool*/ _asyncFlow = false;
            /*ContextData?*/ static t_staticData = null;
            $ctor$1(/*bool*/ asyncFlow)
            {
                super.$ctor();
                {
                    this._asyncFlow = asyncFlow;
                }
                return this;
            }
            static /*ContextData */ get TLSCurrentData()
            {
                return $.$stl.System.Transactions.ContextData.t_staticData ??= new $.$stl.System.Transactions.ContextData().$ctor$1(false);
            }
            static /*ContextData */ set TLSCurrentData(value)
            {
                if (value === null && $.$stl.System.Transactions.ContextData.t_staticData !== null)
                {
                    $.$stl.System.Transactions.ContextData.t_staticData.CurrentScope = null;
                    $.$stl.System.Transactions.ContextData.t_staticData.CurrentTransaction = null;
                    $.$stl.System.Transactions.ContextData.t_staticData.DefaultComContextState = 0/*DefaultComContextState.Unknown*/;
                    $.$stl.System.Transactions.ContextData.t_staticData.WeakDefaultComContext = null;
                }
                else 
                {
                    $.$stl.System.Transactions.ContextData.t_staticData = value;
                }
            }
            static /*ContextData */ LookupContextData(/*TxLookup*/ defaultLookup)
            {
                /*ContextData?*/ let currentData;
                if ($.$stl.System.Transactions.CallContextCurrentData.TryGetCurrentData($.$ref(() => currentData, ($v) => currentData = $v, $.$stl.System.Transactions.ContextData)))
                {
                    if (currentData.CurrentScope === null && $.$stl.System.Transactions.Transaction.op_Equality(currentData.CurrentTransaction, null) && defaultLookup !== 1/*TxLookup.DefaultCallContext*/)
                    {
                        $.$stl.System.Transactions.CallContextCurrentData.ClearCurrentData(null, true);
                        return $.$stl.System.Transactions.ContextData.TLSCurrentData;
                    }
                    return currentData;
                }
                else 
                {
                    return $.$stl.System.Transactions.ContextData.TLSCurrentData;
                }
            }
            static $h = 894220;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":894220,"g":{"r":0,"d":0,"h":38655599884,"f":50331688},"s":{"r":0,"d":0,"h":42950567180,"f":83886120},"n":"TLSCurrentData","d":894220,"h":34360632588,"f":2097192}],"m":[{"r":894220,"p":[{"n":"defaultLookup","p":8627468}],"n":"LookupContextData","d":894220,"h":47245534476,"f":16777256}],"l":[{"t":5154060,"n":"CurrentScope","d":894220,"h":4295861516,"f":4194312},{"t":4302092,"n":"CurrentTransaction","d":894220,"h":8590828812,"f":4194312},{"t":1025292,"n":"DefaultComContextState","d":894220,"h":12885796108,"f":4194312},{"t":144637953,"n":"WeakDefaultComContext","d":894220,"h":17180763404,"f":4194312},{"t":262145,"n":"_asyncFlow","d":894220,"h":21475730700,"f":4194312},{"t":894220,"n":"t_staticData","d":894220,"h":25770697996,"f":4194338,"a":[{"t":140050433,"c":4435017729}]}],"c":[{"p":[{"n":"asyncFlow","p":262145}],"n":".ctor","o":"$ctor$1","d":894220,"h":30065665292,"f":16777224}],"h":894220}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Transactions.ContextData`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionScope", ($self) => class TransactionScope extends $.$$.System.Object
        {
            $ctor$1()
            {
                this.$ctor$14(0/*TransactionScopeOption.Required*/);
                {
                }
                return this;
            }
            $ctor$14(/*TransactionScopeOption*/ scopeOption)
            {
                this.$ctor$13(scopeOption, 0/*TransactionScopeAsyncFlowOption.Suppress*/);
                {
                }
                return this;
            }
            $ctor$7(/*TransactionScopeAsyncFlowOption*/ asyncFlowOption)
            {
                this.$ctor$13(0/*TransactionScopeOption.Required*/, asyncFlowOption);
                {
                }
                return this;
            }
            $ctor$13(/*TransactionScopeOption*/ scopeOption, /*TransactionScopeAsyncFlowOption*/ asyncFlowOption)
            {
                super.$ctor();
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodEnter(0/*TraceSourceType.TraceSourceBase*/, this, "TransactionScope");
                    }
                    this.ValidateAndSetAsyncFlowOption(asyncFlowOption);
                    if (this.NeedToCreateTransaction(scopeOption))
                    {
                        this._committableTransaction = new $.$stl.System.Transactions.CommittableTransaction().$ctor$5();
                        this._expectedCurrent = this._committableTransaction.Clone();
                    }
                    if ($.$stl.System.Transactions.Transaction.op_Equality(null, this._expectedCurrent))
                    {
                        if (etwLog.IsEnabled())
                        {
                            etwLog.TransactionScopeCreated$1($.$stl.System.Transactions.TransactionTraceIdentifier.Empty, 4/*TransactionScopeResult.NoTransaction*/);
                        }
                    }
                    else 
                    {
                        /*TransactionScopeResult*/ let scopeResult;
                        if ($.$stl.System.Transactions.Transaction.op_Equality(null, this._committableTransaction))
                        {
                            scopeResult = 1/*TransactionScopeResult.UsingExistingCurrent*/;
                        }
                        else 
                        {
                            scopeResult = 0/*TransactionScopeResult.CreatedTransaction*/;
                        }
                        if (etwLog.IsEnabled())
                        {
                            etwLog.TransactionScopeCreated$1(this._expectedCurrent.TransactionTraceId, scopeResult);
                        }
                    }
                    this.PushScope();
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodExit(0/*TraceSourceType.TraceSourceBase*/, this, "TransactionScope");
                    }
                }
                return this;
            }
            $ctor$9(/*TransactionScopeOption*/ scopeOption, /*TimeSpan*/ scopeTimeout)
            {
                this.$ctor$8(scopeOption, scopeTimeout, 0/*TransactionScopeAsyncFlowOption.Suppress*/);
                {
                }
                return this;
            }
            $ctor$8(/*TransactionScopeOption*/ scopeOption, /*TimeSpan*/ scopeTimeout, /*TransactionScopeAsyncFlowOption*/ asyncFlowOption)
            {
                super.$ctor();
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodEnter(0/*TraceSourceType.TraceSourceBase*/, this, "TransactionScope");
                    }
                    $.$stl.System.Transactions.TransactionScope.ValidateScopeTimeout("scopeTimeout", scopeTimeout);
                    /*TimeSpan*/ let txTimeout = $.$stl.System.Transactions.TransactionManager.ValidateTimeout(scopeTimeout);
                    this.ValidateAndSetAsyncFlowOption(asyncFlowOption);
                    if (this.NeedToCreateTransaction(scopeOption))
                    {
                        this._committableTransaction = new $.$stl.System.Transactions.CommittableTransaction().$ctor$6(txTimeout);
                        this._expectedCurrent = this._committableTransaction.Clone();
                    }
                    if (($.$stl.System.Transactions.Transaction.op_Inequality(null, this._expectedCurrent)) && ($.$stl.System.Transactions.Transaction.op_Equality(null, this._committableTransaction)) && ($.$$.System.TimeSpan.op_Inequality($.$$.System.TimeSpan.Zero, scopeTimeout)))
                    {
                        this._scopeTimer = new $.$$.System.Threading.Timer().$ctor$5(new $.$$.System.Threading.TimerCallback().$ctor($.$stl.System.Transactions.TransactionScope, $.$stl.System.Transactions.TransactionScope.TimerCallback), this, scopeTimeout, $.$$.System.TimeSpan.Zero);
                    }
                    if ($.$stl.System.Transactions.Transaction.op_Equality(null, this._expectedCurrent))
                    {
                        if (etwLog.IsEnabled())
                        {
                            etwLog.TransactionScopeCreated$1($.$stl.System.Transactions.TransactionTraceIdentifier.Empty, 4/*TransactionScopeResult.NoTransaction*/);
                        }
                    }
                    else 
                    {
                        /*TransactionScopeResult*/ let scopeResult;
                        if ($.$stl.System.Transactions.Transaction.op_Equality(null, this._committableTransaction))
                        {
                            scopeResult = 1/*TransactionScopeResult.UsingExistingCurrent*/;
                        }
                        else 
                        {
                            scopeResult = 0/*TransactionScopeResult.CreatedTransaction*/;
                        }
                        if (etwLog.IsEnabled())
                        {
                            etwLog.TransactionScopeCreated$1(this._expectedCurrent.TransactionTraceId, scopeResult);
                        }
                    }
                    this.PushScope();
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodExit(0/*TraceSourceType.TraceSourceBase*/, this, "TransactionScope");
                    }
                }
                return this;
            }
            $ctor$12(/*TransactionScopeOption*/ scopeOption, /*TransactionOptions*/ transactionOptions)
            {
                this.$ctor$11(scopeOption, transactionOptions.Clone(), 0/*TransactionScopeAsyncFlowOption.Suppress*/);
                {
                }
                return this;
            }
            $ctor$11(/*TransactionScopeOption*/ scopeOption, /*TransactionOptions*/ transactionOptions, /*TransactionScopeAsyncFlowOption*/ asyncFlowOption)
            {
                super.$ctor();
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodEnter(0/*TraceSourceType.TraceSourceBase*/, this, "TransactionScope");
                    }
                    $.$stl.System.Transactions.TransactionScope.ValidateScopeTimeout("transactionOptions.Timeout", transactionOptions.Timeout);
                    /*TimeSpan*/ let scopeTimeout = transactionOptions.Timeout;
                    transactionOptions.Timeout = $.$stl.System.Transactions.TransactionManager.ValidateTimeout(transactionOptions.Timeout);
                    $.$stl.System.Transactions.TransactionManager.ValidateIsolationLevel(transactionOptions.IsolationLevel);
                    this.ValidateAndSetAsyncFlowOption(asyncFlowOption);
                    if (this.NeedToCreateTransaction(scopeOption))
                    {
                        this._committableTransaction = new $.$stl.System.Transactions.CommittableTransaction().$ctor$8(transactionOptions.Clone());
                        this._expectedCurrent = this._committableTransaction.Clone();
                    }
                    else 
                    {
                        if ($.$stl.System.Transactions.Transaction.op_Inequality(null, this._expectedCurrent))
                        {
                            if ((6/*IsolationLevel.Unspecified*/ !== transactionOptions.IsolationLevel) && (this._expectedCurrent.IsolationLevel !== transactionOptions.IsolationLevel))
                            {
                                throw new $.$$.System.ArgumentException().$ctor$13($.$stl.System.SR.TransactionScopeIsolationLevelDifferentFromTransaction, "transactionOptions");
                            }
                        }
                    }
                    if (($.$stl.System.Transactions.Transaction.op_Inequality(null, this._expectedCurrent)) && ($.$stl.System.Transactions.Transaction.op_Equality(null, this._committableTransaction)) && ($.$$.System.TimeSpan.op_Inequality($.$$.System.TimeSpan.Zero, scopeTimeout)))
                    {
                        this._scopeTimer = new $.$$.System.Threading.Timer().$ctor$5(new $.$$.System.Threading.TimerCallback().$ctor($.$stl.System.Transactions.TransactionScope, $.$stl.System.Transactions.TransactionScope.TimerCallback), this, scopeTimeout, $.$$.System.TimeSpan.Zero);
                    }
                    if ($.$stl.System.Transactions.Transaction.op_Equality(null, this._expectedCurrent))
                    {
                        if (etwLog.IsEnabled())
                        {
                            etwLog.TransactionScopeCreated$1($.$stl.System.Transactions.TransactionTraceIdentifier.Empty, 4/*TransactionScopeResult.NoTransaction*/);
                        }
                    }
                    else 
                    {
                        /*TransactionScopeResult*/ let scopeResult;
                        if ($.$stl.System.Transactions.Transaction.op_Equality(null, this._committableTransaction))
                        {
                            scopeResult = 1/*TransactionScopeResult.UsingExistingCurrent*/;
                        }
                        else 
                        {
                            scopeResult = 0/*TransactionScopeResult.CreatedTransaction*/;
                        }
                        if (etwLog.IsEnabled())
                        {
                            etwLog.TransactionScopeCreated$1(this._expectedCurrent.TransactionTraceId, scopeResult);
                        }
                    }
                    this.PushScope();
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodExit(0/*TraceSourceType.TraceSourceBase*/, this, "TransactionScope");
                    }
                }
                return this;
            }
            $ctor$10(/*TransactionScopeOption*/ scopeOption, /*TransactionOptions*/ transactionOptions, /*EnterpriseServicesInteropOption*/ interopOption)
            {
                super.$ctor();
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodEnter(0/*TraceSourceType.TraceSourceBase*/, this, "TransactionScope");
                    }
                    $.$stl.System.Transactions.TransactionScope.ValidateScopeTimeout("transactionOptions.Timeout", transactionOptions.Timeout);
                    /*TimeSpan*/ let scopeTimeout = transactionOptions.Timeout;
                    transactionOptions.Timeout = $.$stl.System.Transactions.TransactionManager.ValidateTimeout(transactionOptions.Timeout);
                    $.$stl.System.Transactions.TransactionManager.ValidateIsolationLevel(transactionOptions.IsolationLevel);
                    $.$stl.System.Transactions.TransactionScope.ValidateInteropOption(interopOption);
                    this._interopModeSpecified = true;
                    this._interopOption = interopOption;
                    if (this.NeedToCreateTransaction(scopeOption))
                    {
                        this._committableTransaction = new $.$stl.System.Transactions.CommittableTransaction().$ctor$8(transactionOptions.Clone());
                        this._expectedCurrent = this._committableTransaction.Clone();
                    }
                    else 
                    {
                        if ($.$stl.System.Transactions.Transaction.op_Inequality(null, this._expectedCurrent))
                        {
                            if ((6/*IsolationLevel.Unspecified*/ !== transactionOptions.IsolationLevel) && (this._expectedCurrent.IsolationLevel !== transactionOptions.IsolationLevel))
                            {
                                throw new $.$$.System.ArgumentException().$ctor$13($.$stl.System.SR.TransactionScopeIsolationLevelDifferentFromTransaction, "transactionOptions");
                            }
                        }
                    }
                    if (($.$stl.System.Transactions.Transaction.op_Inequality(null, this._expectedCurrent)) && ($.$stl.System.Transactions.Transaction.op_Equality(null, this._committableTransaction)) && ($.$$.System.TimeSpan.op_Inequality($.$$.System.TimeSpan.Zero, scopeTimeout)))
                    {
                        this._scopeTimer = new $.$$.System.Threading.Timer().$ctor$5(new $.$$.System.Threading.TimerCallback().$ctor($.$stl.System.Transactions.TransactionScope, $.$stl.System.Transactions.TransactionScope.TimerCallback), this, scopeTimeout, $.$$.System.TimeSpan.Zero);
                    }
                    if ($.$stl.System.Transactions.Transaction.op_Equality(null, this._expectedCurrent))
                    {
                        if (etwLog.IsEnabled())
                        {
                            etwLog.TransactionScopeCreated$1($.$stl.System.Transactions.TransactionTraceIdentifier.Empty, 4/*TransactionScopeResult.NoTransaction*/);
                        }
                    }
                    else 
                    {
                        /*TransactionScopeResult*/ let scopeResult;
                        if ($.$stl.System.Transactions.Transaction.op_Equality(null, this._committableTransaction))
                        {
                            scopeResult = 1/*TransactionScopeResult.UsingExistingCurrent*/;
                        }
                        else 
                        {
                            scopeResult = 0/*TransactionScopeResult.CreatedTransaction*/;
                        }
                        if (etwLog.IsEnabled())
                        {
                            etwLog.TransactionScopeCreated$1(this._expectedCurrent.TransactionTraceId, scopeResult);
                        }
                    }
                    this.PushScope();
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodExit(0/*TraceSourceType.TraceSourceBase*/, this, "TransactionScope");
                    }
                }
                return this;
            }
            $ctor$6(/*Transaction*/ transactionToUse)
            {
                this.$ctor$5(transactionToUse, 0/*TransactionScopeAsyncFlowOption.Suppress*/);
                {
                }
                return this;
            }
            $ctor$5(/*Transaction*/ transactionToUse, /*TransactionScopeAsyncFlowOption*/ asyncFlowOption)
            {
                super.$ctor();
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodEnter(0/*TraceSourceType.TraceSourceBase*/, this, "TransactionScope");
                    }
                    this.ValidateAndSetAsyncFlowOption(asyncFlowOption);
                    this.Initialize(transactionToUse, $.$$.System.TimeSpan.Zero, false);
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodExit(0/*TraceSourceType.TraceSourceBase*/, this, "TransactionScope");
                    }
                }
                return this;
            }
            $ctor$4(/*Transaction*/ transactionToUse, /*TimeSpan*/ scopeTimeout)
            {
                this.$ctor$3(transactionToUse, scopeTimeout, 0/*TransactionScopeAsyncFlowOption.Suppress*/);
                {
                }
                return this;
            }
            $ctor$3(/*Transaction*/ transactionToUse, /*TimeSpan*/ scopeTimeout, /*TransactionScopeAsyncFlowOption*/ asyncFlowOption)
            {
                super.$ctor();
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodEnter(0/*TraceSourceType.TraceSourceBase*/, this, "TransactionScope");
                    }
                    this.ValidateAndSetAsyncFlowOption(asyncFlowOption);
                    this.Initialize(transactionToUse, scopeTimeout, false);
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodExit(0/*TraceSourceType.TraceSourceBase*/, this, "TransactionScope");
                    }
                }
                return this;
            }
            $ctor$2(/*Transaction*/ transactionToUse, /*TimeSpan*/ scopeTimeout, /*EnterpriseServicesInteropOption*/ interopOption)
            {
                super.$ctor();
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodEnter(0/*TraceSourceType.TraceSourceBase*/, this, "TransactionScope");
                    }
                    $.$stl.System.Transactions.TransactionScope.ValidateInteropOption(interopOption);
                    this._interopOption = interopOption;
                    this.Initialize(transactionToUse, scopeTimeout, true);
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodExit(0/*TraceSourceType.TraceSourceBase*/, this, "TransactionScope");
                    }
                }
                return this;
            }
            /*bool */ NeedToCreateTransaction(/*TransactionScopeOption*/ scopeOption)
            {
                /*bool*/ let retVal = false;
                this.CommonInitialize();
                switch(scopeOption)
                {
                    case 2/*TransactionScopeOption.Suppress*/:
                    this._expectedCurrent = null;
                    retVal = false;
                    break;
                    case 0/*TransactionScopeOption.Required*/:
                    this._expectedCurrent = this._savedCurrent;
                    if ($.$stl.System.Transactions.Transaction.op_Equality(null, this._expectedCurrent))
                    {
                        retVal = true;
                    }
                    break;
                    case 1/*TransactionScopeOption.RequiresNew*/:
                    retVal = true;
                    break;
                    default:
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("scopeOption");
                }
                return retVal;
            }
            /*void */ Initialize(/*Transaction*/ transactionToUse, /*TimeSpan*/ scopeTimeout, /*bool*/ interopModeSpecified)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(transactionToUse, "transactionToUse");
                $.$stl.System.Transactions.TransactionScope.ValidateScopeTimeout("scopeTimeout", scopeTimeout);
                this.CommonInitialize();
                if ($.$$.System.TimeSpan.op_Inequality($.$$.System.TimeSpan.Zero, scopeTimeout))
                {
                    this._scopeTimer = new $.$$.System.Threading.Timer().$ctor$5(new $.$$.System.Threading.TimerCallback().$ctor($.$stl.System.Transactions.TransactionScope, $.$stl.System.Transactions.TransactionScope.TimerCallback), this, scopeTimeout, $.$$.System.TimeSpan.Zero);
                }
                this._expectedCurrent = transactionToUse;
                this._interopModeSpecified = interopModeSpecified;
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionScopeCreated$1(this._expectedCurrent.TransactionTraceId, 2/*TransactionScopeResult.TransactionPassed*/);
                }
                this.PushScope();
            }
            /*void */ Dispose()
            {
                /*bool*/ let successful = false;
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(0/*TraceSourceType.TraceSourceBase*/, this, "Dispose");
                }
                if (this._disposed)
                {
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodExit(0/*TraceSourceType.TraceSourceBase*/, this, "Dispose");
                    }
                    return;
                }
                if ((this._scopeThread !== $.$$.System.Threading.Thread.CurrentThread) && !this.AsyncFlowEnabled)
                {
                    if (etwLog.IsEnabled())
                    {
                        etwLog.InvalidOperation("TransactionScope", "InvalidScopeThread");
                    }
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$stl.System.SR.InvalidScopeThread);
                }
                /*Exception?*/ let exToThrow = null;
                try
                {
                    this._disposed = true;
                    $.$$.System.Diagnostics.Debug.Assert$2(this._threadContextData !== null, "_threadContextData != null");
                    /*TransactionScope?*/ let actualCurrentScope = this._threadContextData.CurrentScope;
                    /*Transaction?*/ let contextTransaction = null;
                    /*Transaction?*/ let current = $.$stl.System.Transactions.Transaction.FastGetTransaction(actualCurrentScope, this._threadContextData, $.$ref(() => contextTransaction, ($v) => contextTransaction = $v, $.$stl.System.Transactions.Transaction));
                    if (!$.$$.System.Object.Equals$1.call(this, actualCurrentScope))
                    {
                        if (actualCurrentScope === null)
                        {
                            /*Transaction?*/ let rollbackTransaction = this._committableTransaction ?? this._dependentTransaction;
                            $.$$.System.Diagnostics.Debug.Assert$2($.$stl.System.Transactions.Transaction.op_Inequality(rollbackTransaction, null), "rollbackTransaction != null");
                            rollbackTransaction.Rollback();
                            successful = true;
                            throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionScopeInvalidNesting, null, rollbackTransaction.DistributedTxId);
                        }
                        else if (0/*EnterpriseServicesInteropOption.None*/ === actualCurrentScope._interopOption)
                        {
                            if ((($.$stl.System.Transactions.Transaction.op_Inequality(null, actualCurrentScope._expectedCurrent)) && (!$.$stl.System.Transactions.Transaction.Equals$1.call(actualCurrentScope._expectedCurrent, current))) || (($.$stl.System.Transactions.Transaction.op_Inequality(null, current)) && ($.$stl.System.Transactions.Transaction.op_Equality(null, actualCurrentScope._expectedCurrent))))
                            {
                                /*TransactionTraceIdentifier*/ let myId;
                                /*TransactionTraceIdentifier*/ let currentId;
                                if ($.$stl.System.Transactions.Transaction.op_Equality(null, current))
                                {
                                    currentId = $.$stl.System.Transactions.TransactionTraceIdentifier.Empty;
                                }
                                else 
                                {
                                    currentId = current.TransactionTraceId;
                                }
                                if ($.$stl.System.Transactions.Transaction.op_Equality(null, this._expectedCurrent))
                                {
                                    myId = $.$stl.System.Transactions.TransactionTraceIdentifier.Empty;
                                }
                                else 
                                {
                                    myId = this._expectedCurrent.TransactionTraceId;
                                }
                                if (etwLog.IsEnabled())
                                {
                                    etwLog.TransactionScopeCurrentChanged$1(currentId, myId);
                                }
                                exToThrow = $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionScopeIncorrectCurrent, null, $.$stl.System.Transactions.Transaction.op_Equality(current, null) ? $.$$.System.Guid.Empty : current.DistributedTxId);
                                if ($.$stl.System.Transactions.Transaction.op_Inequality(null, current))
                                {
                                    try
                                    {
                                        current.Rollback();
                                    }
                                    catch($e)
                                    {
                                        if ($e instanceof $.$stl.System.Transactions.TransactionException)
                                        {
                                        }
                                        else if ($e instanceof $.$$.System.ObjectDisposedException)
                                        {
                                        }
                                        else
                                        {
                                            throw $e;
                                        }
                                    }
                                }
                            }
                        }
                        while(!$.$$.System.Object.Equals$1.call(this, actualCurrentScope))
                        {
                            if (null === exToThrow)
                            {
                                exToThrow = $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionScopeInvalidNesting, null, $.$stl.System.Transactions.Transaction.op_Equality(current, null) ? $.$$.System.Guid.Empty : current.DistributedTxId);
                            }
                            if ($.$stl.System.Transactions.Transaction.op_Equality(null, actualCurrentScope._expectedCurrent))
                            {
                                if (etwLog.IsEnabled())
                                {
                                    etwLog.TransactionScopeNestedIncorrectly$1($.$stl.System.Transactions.TransactionTraceIdentifier.Empty);
                                }
                            }
                            else 
                            {
                                if (etwLog.IsEnabled())
                                {
                                    etwLog.TransactionScopeNestedIncorrectly$1(actualCurrentScope._expectedCurrent.TransactionTraceId);
                                }
                            }
                            actualCurrentScope._complete = false;
                            try
                            {
                                actualCurrentScope.InternalDispose();
                            }
                            catch($e)
                            {
                            }
                            actualCurrentScope = this._threadContextData.CurrentScope;
                            this._complete = false;
                        }
                    }
                    else 
                    {
                        if (0/*EnterpriseServicesInteropOption.None*/ === this._interopOption)
                        {
                            if ((($.$stl.System.Transactions.Transaction.op_Inequality(null, this._expectedCurrent)) && (!$.$stl.System.Transactions.Transaction.Equals$1.call(this._expectedCurrent, current))) || (($.$stl.System.Transactions.Transaction.op_Inequality(null, current)) && ($.$stl.System.Transactions.Transaction.op_Equality(null, this._expectedCurrent))))
                            {
                                /*TransactionTraceIdentifier*/ let myId;
                                /*TransactionTraceIdentifier*/ let currentId;
                                if ($.$stl.System.Transactions.Transaction.op_Equality(null, current))
                                {
                                    currentId = $.$stl.System.Transactions.TransactionTraceIdentifier.Empty;
                                }
                                else 
                                {
                                    currentId = current.TransactionTraceId;
                                }
                                if ($.$stl.System.Transactions.Transaction.op_Equality(null, this._expectedCurrent))
                                {
                                    myId = $.$stl.System.Transactions.TransactionTraceIdentifier.Empty;
                                }
                                else 
                                {
                                    myId = this._expectedCurrent.TransactionTraceId;
                                }
                                if (etwLog.IsEnabled())
                                {
                                    etwLog.TransactionScopeCurrentChanged$1(currentId, myId);
                                }
                                if (null === exToThrow)
                                {
                                    exToThrow = $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionScopeIncorrectCurrent, null, $.$stl.System.Transactions.Transaction.op_Equality(current, null) ? $.$$.System.Guid.Empty : current.DistributedTxId);
                                }
                                if ($.$stl.System.Transactions.Transaction.op_Inequality(null, current))
                                {
                                    try
                                    {
                                        current.Rollback();
                                    }
                                    catch($e)
                                    {
                                        if ($e instanceof $.$stl.System.Transactions.TransactionException)
                                        {
                                        }
                                        else if ($e instanceof $.$$.System.ObjectDisposedException)
                                        {
                                        }
                                        else
                                        {
                                            throw $e;
                                        }
                                    }
                                }
                                this._complete = false;
                            }
                        }
                    }
                    successful = true;
                }
                finally
                {
                    {
                        if (!successful)
                        {
                            this.PopScope();
                        }
                    }
                }
                this.InternalDispose();
                if (null !== exToThrow)
                {
                    throw exToThrow;
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(0/*TraceSourceType.TraceSourceBase*/, this, "Dispose");
                }
            }
            /*void */ InternalDispose()
            {
                this._disposed = true;
                try
                {
                    this.PopScope();
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if ($.$stl.System.Transactions.Transaction.op_Equality(null, this._expectedCurrent))
                    {
                        if (etwLog.IsEnabled())
                        {
                            etwLog.TransactionScopeDisposed$1($.$stl.System.Transactions.TransactionTraceIdentifier.Empty);
                        }
                    }
                    else 
                    {
                        if (etwLog.IsEnabled())
                        {
                            etwLog.TransactionScopeDisposed$1(this._expectedCurrent.TransactionTraceId);
                        }
                    }
                    if ($.$stl.System.Transactions.Transaction.op_Inequality(null, this._expectedCurrent))
                    {
                        if (!this._complete)
                        {
                            if (etwLog.IsEnabled())
                            {
                                etwLog.TransactionScopeIncomplete$1(this._expectedCurrent.TransactionTraceId);
                            }
                            /*Transaction?*/ let rollbackTransaction = this._committableTransaction ?? this._dependentTransaction;
                            $.$$.System.Diagnostics.Debug.Assert$2($.$stl.System.Transactions.Transaction.op_Inequality(rollbackTransaction, null), "rollbackTransaction != null");
                            rollbackTransaction.Rollback();
                        }
                        else 
                        {
                            if ($.$stl.System.Transactions.Transaction.op_Inequality(null, this._committableTransaction))
                            {
                                this._committableTransaction.Commit();
                            }
                            else 
                            {
                                $.$$.System.Diagnostics.Debug.Assert$2($.$stl.System.Transactions.Transaction.op_Inequality(null, this._dependentTransaction), "null != this.dependentTransaction");
                                this._dependentTransaction.Complete();
                            }
                        }
                    }
                }
                finally
                {
                    {
                        this._scopeTimer?.Dispose();
                        if ($.$stl.System.Transactions.Transaction.op_Inequality(null, this._committableTransaction))
                        {
                            this._committableTransaction.Dispose();
                            $.$$.System.Diagnostics.Debug.Assert$2($.$stl.System.Transactions.Transaction.op_Inequality(this._expectedCurrent, null), "_expectedCurrent != null");
                            this._expectedCurrent.Dispose();
                        }
                        this._dependentTransaction?.Dispose();
                    }
                }
            }
            /*void */ Complete()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(0/*TraceSourceType.TraceSourceBase*/, this, "Complete");
                }
                $.$$.System.ObjectDisposedException.ThrowIf(this._disposed, this);
                if (this._complete)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException$1(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.DisposeScope, null);
                }
                this._complete = true;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(0/*TraceSourceType.TraceSourceBase*/, this, "Complete");
                }
            }
            static /*void */ TimerCallback(/*object?*/ state)
            {
                /*TransactionScope?*/ let scope = $.$as(state, $.$stl.System.Transactions.TransactionScope);
                if (null === scope)
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.InternalError("TransactionScopeTimerObjectInvalid");
                    }
                    throw $.$stl.System.Transactions.TransactionException.Create$1($.$stl.System.SR.InternalError + $.$stl.System.SR.TransactionScopeTimerObjectInvalid, null);
                }
                scope.Timeout();
            }
            /*void */ Timeout()
            {
                if ((!this._complete) && ($.$stl.System.Transactions.Transaction.op_Inequality(null, this._expectedCurrent)))
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.TransactionScopeTimeout$1(this._expectedCurrent.TransactionTraceId);
                    }
                    try
                    {
                        this._expectedCurrent.Rollback();
                    }
                    catch($e)
                    {
                        if ($e instanceof $.$$.System.ObjectDisposedException)
                        {
                            let ex = $e;
                            if (etwLog.IsEnabled())
                            {
                                etwLog.ExceptionConsumed$1(0/*TraceSourceType.TraceSourceBase*/, ex);
                            }
                        }
                        else if ($e instanceof $.$stl.System.Transactions.TransactionException)
                        {
                            let txEx = $e;
                            if (etwLog.IsEnabled())
                            {
                                etwLog.ExceptionConsumed$1(0/*TraceSourceType.TraceSourceBase*/, txEx);
                            }
                        }
                        else
                        {
                            throw $e;
                        }
                    }
                }
            }
            /*void */ CommonInitialize()
            {
                this.ContextKey = new $.$stl.System.Transactions.ContextKey().$ctor$1();
                this._complete = false;
                this._dependentTransaction = null;
                this._disposed = false;
                this._committableTransaction = null;
                this._expectedCurrent = null;
                this._scopeTimer = null;
                this._scopeThread = $.$$.System.Threading.Thread.CurrentThread;
                $.$stl.System.Transactions.Transaction.GetCurrentTransactionAndScope(this.AsyncFlowEnabled ? 1/*TxLookup.DefaultCallContext*/ : 2/*TxLookup.DefaultTLS*/, $.$ref(() => this._savedCurrent, ($v) => this._savedCurrent = $v, $.$stl.System.Transactions.Transaction), $.$ref(() => this._savedCurrentScope, ($v) => this._savedCurrentScope = $v, $.$stl.System.Transactions.TransactionScope), $.$ref(() => this._contextTransaction, ($v) => this._contextTransaction = $v, $.$stl.System.Transactions.Transaction));
                this.ValidateAsyncFlowOptionAndESInteropOption();
            }
            /*void */ PushScope()
            {
                if (!this._interopModeSpecified)
                {
                    this._interopOption = $.$stl.System.Transactions.Transaction.InteropMode(this._savedCurrentScope);
                }
                this.SaveTLSContextData();
                if (this.AsyncFlowEnabled)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(this.ContextKey !== null, "ContextKey != null");
                    this._threadContextData = $.$stl.System.Transactions.CallContextCurrentData.CreateOrGetCurrentData(this.ContextKey);
                    if (this._savedCurrentScope === null && $.$stl.System.Transactions.Transaction.op_Equality(this._savedCurrent, null))
                    {
                        $.$stl.System.Transactions.ContextData.TLSCurrentData = null;
                    }
                }
                else 
                {
                    this._threadContextData = $.$stl.System.Transactions.ContextData.TLSCurrentData;
                    $.$stl.System.Transactions.CallContextCurrentData.ClearCurrentData(this.ContextKey, false);
                }
                this.SetCurrent(this._expectedCurrent);
                this._threadContextData.CurrentScope = this;
            }
            /*void */ PopScope()
            {
                /*bool*/ let shouldRestoreContextData = true;
                if (this.AsyncFlowEnabled)
                {
                    $.$stl.System.Transactions.CallContextCurrentData.ClearCurrentData(this.ContextKey, true);
                }
                if (this._scopeThread === $.$$.System.Threading.Thread.CurrentThread)
                {
                    this.RestoreSavedTLSContextData();
                }
                if (this._savedCurrentScope !== null)
                {
                    if (this._savedCurrentScope.AsyncFlowEnabled)
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(this._savedCurrentScope.ContextKey !== null, "_savedCurrentScope.ContextKey != null");
                        this._threadContextData = $.$stl.System.Transactions.CallContextCurrentData.CreateOrGetCurrentData(this._savedCurrentScope.ContextKey);
                    }
                    else 
                    {
                        if (this._savedCurrentScope._scopeThread !== $.$$.System.Threading.Thread.CurrentThread)
                        {
                            shouldRestoreContextData = false;
                            $.$stl.System.Transactions.ContextData.TLSCurrentData = null;
                        }
                        else 
                        {
                            this._threadContextData = $.$stl.System.Transactions.ContextData.TLSCurrentData;
                        }
                        $.$stl.System.Transactions.CallContextCurrentData.ClearCurrentData(this._savedCurrentScope.ContextKey, false);
                    }
                }
                else 
                {
                    $.$stl.System.Transactions.CallContextCurrentData.ClearCurrentData(null, false);
                    if (this._scopeThread !== $.$$.System.Threading.Thread.CurrentThread)
                    {
                        shouldRestoreContextData = false;
                        $.$stl.System.Transactions.ContextData.TLSCurrentData = null;
                    }
                    else 
                    {
                        $.$stl.System.Transactions.ContextData.TLSCurrentData = this._threadContextData;
                    }
                }
                if (shouldRestoreContextData)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(this._threadContextData !== null, "_threadContextData != null");
                    this._threadContextData.CurrentScope = this._savedCurrentScope;
                    this.RestoreCurrent();
                }
            }
            /*void */ SetCurrent(/*Transaction?*/ newCurrent)
            {
                if (this._dependentTransaction === null && this._committableTransaction === null)
                {
                    if ($.$stl.System.Transactions.Transaction.op_Inequality(newCurrent, null))
                    {
                        this._dependentTransaction = newCurrent.DependentClone(1/*DependentCloneOption.RollbackIfNotComplete*/);
                    }
                }
                switch(this._interopOption)
                {
                    case 0/*EnterpriseServicesInteropOption.None*/:
                    this._threadContextData.CurrentTransaction = newCurrent;
                    break;
                    case 1/*EnterpriseServicesInteropOption.Automatic*/:
                    $.$stl.System.Transactions.EnterpriseServices.VerifyEnterpriseServicesOk();
                    if ($.$stl.System.Transactions.EnterpriseServices.UseServiceDomainForCurrent())
                    {
                        $.$stl.System.Transactions.EnterpriseServices.PushServiceDomain();
                    }
                    else 
                    {
                        this._threadContextData.CurrentTransaction = newCurrent;
                    }
                    break;
                    case 2/*EnterpriseServicesInteropOption.Full*/:
                    $.$stl.System.Transactions.EnterpriseServices.VerifyEnterpriseServicesOk();
                    $.$stl.System.Transactions.EnterpriseServices.PushServiceDomain();
                    break;
                }
            }
            /*void */ SaveTLSContextData()
            {
                this._savedTLSContextData ??= new $.$stl.System.Transactions.ContextData().$ctor$1(false);
                this._savedTLSContextData.CurrentScope = $.$stl.System.Transactions.ContextData.TLSCurrentData.CurrentScope;
                this._savedTLSContextData.CurrentTransaction = $.$stl.System.Transactions.ContextData.TLSCurrentData.CurrentTransaction;
                this._savedTLSContextData.DefaultComContextState = $.$stl.System.Transactions.ContextData.TLSCurrentData.DefaultComContextState;
                this._savedTLSContextData.WeakDefaultComContext = $.$stl.System.Transactions.ContextData.TLSCurrentData.WeakDefaultComContext;
            }
            /*void */ RestoreSavedTLSContextData()
            {
                if (this._savedTLSContextData !== null)
                {
                    $.$stl.System.Transactions.ContextData.TLSCurrentData.CurrentScope = this._savedTLSContextData.CurrentScope;
                    $.$stl.System.Transactions.ContextData.TLSCurrentData.CurrentTransaction = this._savedTLSContextData.CurrentTransaction;
                    $.$stl.System.Transactions.ContextData.TLSCurrentData.DefaultComContextState = this._savedTLSContextData.DefaultComContextState;
                    $.$stl.System.Transactions.ContextData.TLSCurrentData.WeakDefaultComContext = this._savedTLSContextData.WeakDefaultComContext;
                }
            }
            /*void */ RestoreCurrent()
            {
                if ($.$stl.System.Transactions.EnterpriseServices.CreatedServiceDomain)
                {
                    $.$stl.System.Transactions.EnterpriseServices.LeaveServiceDomain();
                }
                this._threadContextData.CurrentTransaction = this._contextTransaction;
            }
            static /*void */ ValidateInteropOption(/*EnterpriseServicesInteropOption*/ interopOption)
            {
                if (interopOption < 0/*EnterpriseServicesInteropOption.None*/ || interopOption > 2/*EnterpriseServicesInteropOption.Full*/)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("interopOption");
                }
            }
            static /*void */ ValidateScopeTimeout(/*string?*/ paramName, /*TimeSpan*/ scopeTimeout)
            {
                $.$$.System.ArgumentOutOfRangeException.ThrowIfLessThan($.$$.System.TimeSpan, scopeTimeout, $.$$.System.TimeSpan.Zero, paramName);
            }
            /*void */ ValidateAndSetAsyncFlowOption(/*TransactionScopeAsyncFlowOption*/ asyncFlowOption)
            {
                if (asyncFlowOption < 0/*TransactionScopeAsyncFlowOption.Suppress*/ || asyncFlowOption > 1/*TransactionScopeAsyncFlowOption.Enabled*/)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("asyncFlowOption");
                }
                if (asyncFlowOption === 1/*TransactionScopeAsyncFlowOption.Enabled*/)
                {
                    this.AsyncFlowEnabled = true;
                }
            }
            /*void */ ValidateAsyncFlowOptionAndESInteropOption()
            {
                if (this.AsyncFlowEnabled)
                {
                    /*EnterpriseServicesInteropOption*/ let currentInteropOption = this._interopOption;
                    if (!this._interopModeSpecified)
                    {
                        currentInteropOption = $.$stl.System.Transactions.Transaction.InteropMode(this._savedCurrentScope);
                    }
                    if (currentInteropOption !== 0/*EnterpriseServicesInteropOption.None*/)
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$12($.$stl.System.SR.AsyncFlowAndESInteropNotSupported);
                    }
                }
            }
            /*bool*/ _complete = false;
            /*bool */ get ScopeComplete()
            {
                return this._complete;
            }
            /*Transaction?*/ _savedCurrent = null;
            /*Transaction?*/ _contextTransaction = null;
            /*TransactionScope?*/ _savedCurrentScope = null;
            /*ContextData?*/ _threadContextData = null;
            /*ContextData?*/ _savedTLSContextData = null;
            /*Transaction?*/ _expectedCurrent = null;
            /*CommittableTransaction?*/ _committableTransaction = null;
            /*DependentTransaction?*/ _dependentTransaction = null;
            /*bool*/ _disposed = false;
            /*Timer?*/ _scopeTimer = null;
            /*Thread?*/ _scopeThread = null;
            /*bool*/ _interopModeSpecified = false;
            /*EnterpriseServicesInteropOption*/ _interopOption = 0;
            /*EnterpriseServicesInteropOption */ get InteropMode()
            {
                return this._interopOption;
            }
            /*ContextKey?*/ ContextKey = null;
            /*bool*/ AsyncFlowEnabled = false;
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this.AsyncFlowEnabled = false;
            }
            static $h = 5154060;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":150329009420,"f":50331656},"n":"ScopeComplete","d":5154060,"h":146034042124,"f":2097160},{"p":2270476,"g":{"r":0,"d":0,"h":214753518860,"f":50331656},"n":"InteropMode","d":5154060,"h":210458551564,"f":2097160},{"p":959756,"g":{"r":0,"d":0,"h":227638420748,"f":50331656},"s":{"r":0,"d":0,"h":231933388044,"f":83886082},"n":"ContextKey","d":5154060,"h":223343453452,"f":2097160},{"p":262145,"g":{"r":0,"d":0,"h":244818289932,"f":50331656},"s":{"r":0,"d":0,"h":249113257228,"f":83886082},"n":"AsyncFlowEnabled","d":5154060,"h":240523322636,"f":2097160}],"m":[{"r":262145,"p":[{"n":"scopeOption","p":5285132}],"n":"NeedToCreateTransaction","d":5154060,"h":64429663500,"f":16777218},{"r":65537,"p":[{"n":"transactionToUse","p":4302092},{"n":"scopeTimeout","p":140574721},{"n":"interopModeSpecified","p":262145}],"n":"Initialize","d":5154060,"h":68724630796,"f":16777218},{"r":65537,"n":"Dispose","d":5154060,"h":73019598092,"f":16777217},{"r":65537,"n":"InternalDispose","d":5154060,"h":77314565388,"f":16777218},{"r":65537,"n":"Complete","d":5154060,"h":81609532684,"f":16777217},{"r":65537,"p":[{"n":"state","p":131073}],"n":"TimerCallback","d":5154060,"h":85904499980,"f":16777250},{"r":65537,"n":"Timeout","d":5154060,"h":90199467276,"f":16777218},{"r":65537,"n":"CommonInitialize","d":5154060,"h":94494434572,"f":16777218},{"r":65537,"n":"PushScope","d":5154060,"h":98789401868,"f":16777218},{"r":65537,"n":"PopScope","d":5154060,"h":103084369164,"f":16777218},{"r":65537,"p":[{"n":"newCurrent","p":4302092}],"n":"SetCurrent","d":5154060,"h":107379336460,"f":16777218},{"r":65537,"n":"SaveTLSContextData","d":5154060,"h":111674303756,"f":16777218},{"r":65537,"n":"RestoreSavedTLSContextData","d":5154060,"h":115969271052,"f":16777218},{"r":65537,"n":"RestoreCurrent","d":5154060,"h":120264238348,"f":16777218},{"r":65537,"p":[{"n":"interopOption","p":2270476}],"n":"ValidateInteropOption","d":5154060,"h":124559205644,"f":16777250},{"r":65537,"p":[{"n":"paramName","p":1310721},{"n":"scopeTimeout","p":140574721}],"n":"ValidateScopeTimeout","d":5154060,"h":128854172940,"f":16777250},{"r":65537,"p":[{"n":"asyncFlowOption","p":5219596}],"n":"ValidateAndSetAsyncFlowOption","d":5154060,"h":133149140236,"f":16777218},{"r":65537,"n":"ValidateAsyncFlowOptionAndESInteropOption","d":5154060,"h":137444107532,"f":16777218}],"l":[{"t":262145,"n":"_complete","d":5154060,"h":141739074828,"f":4194306},{"t":4302092,"n":"_savedCurrent","d":5154060,"h":154623976716,"f":4194306},{"t":4302092,"n":"_contextTransaction","d":5154060,"h":158918944012,"f":4194306},{"t":5154060,"n":"_savedCurrentScope","d":5154060,"h":163213911308,"f":4194306},{"t":894220,"n":"_threadContextData","d":5154060,"h":167508878604,"f":4194306},{"t":894220,"n":"_savedTLSContextData","d":5154060,"h":171803845900,"f":4194306},{"t":4302092,"n":"_expectedCurrent","d":5154060,"h":176098813196,"f":4194306},{"t":566540,"n":"_committableTransaction","d":5154060,"h":180393780492,"f":4194306},{"t":1156364,"n":"_dependentTransaction","d":5154060,"h":184688747788,"f":4194306},{"t":262145,"n":"_disposed","d":5154060,"h":188983715084,"f":4194306},{"t":138412033,"n":"_scopeTimer","d":5154060,"h":193278682380,"f":4194306},{"t":136314881,"n":"_scopeThread","d":5154060,"h":197573649676,"f":4194306},{"t":262145,"n":"_interopModeSpecified","d":5154060,"h":201868616972,"f":4194306},{"t":2270476,"n":"_interopOption","d":5154060,"h":206163584268,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$1","d":5154060,"h":4300121356,"f":16777217},{"p":[{"n":"scopeOption","p":5285132}],"n":".ctor","o":"$ctor$14","d":5154060,"h":8595088652,"f":16777217},{"p":[{"n":"asyncFlowOption","p":5219596}],"n":".ctor","o":"$ctor$7","d":5154060,"h":12890055948,"f":16777217},{"p":[{"n":"scopeOption","p":5285132},{"n":"asyncFlowOption","p":5219596}],"n":".ctor","o":"$ctor$13","d":5154060,"h":17185023244,"f":16777217},{"p":[{"n":"scopeOption","p":5285132},{"n":"scopeTimeout","p":140574721}],"n":".ctor","o":"$ctor$9","d":5154060,"h":21479990540,"f":16777217},{"p":[{"n":"scopeOption","p":5285132},{"n":"scopeTimeout","p":140574721},{"n":"asyncFlowOption","p":5219596}],"n":".ctor","o":"$ctor$8","d":5154060,"h":25774957836,"f":16777217},{"p":[{"n":"scopeOption","p":5285132},{"n":"transactionOptions","p":5022988}],"n":".ctor","o":"$ctor$12","d":5154060,"h":30069925132,"f":16777217},{"p":[{"n":"scopeOption","p":5285132},{"n":"transactionOptions","p":5022988},{"n":"asyncFlowOption","p":5219596}],"n":".ctor","o":"$ctor$11","d":5154060,"h":34364892428,"f":16777217},{"p":[{"n":"scopeOption","p":5285132},{"n":"transactionOptions","p":5022988},{"n":"interopOption","p":2270476}],"n":".ctor","o":"$ctor$10","d":5154060,"h":38659859724,"f":16777217},{"p":[{"n":"transactionToUse","p":4302092}],"n":".ctor","o":"$ctor$6","d":5154060,"h":42954827020,"f":16777217},{"p":[{"n":"transactionToUse","p":4302092},{"n":"asyncFlowOption","p":5219596}],"n":".ctor","o":"$ctor$5","d":5154060,"h":47249794316,"f":16777217},{"p":[{"n":"transactionToUse","p":4302092},{"n":"scopeTimeout","p":140574721}],"n":".ctor","o":"$ctor$4","d":5154060,"h":51544761612,"f":16777217},{"p":[{"n":"transactionToUse","p":4302092},{"n":"scopeTimeout","p":140574721},{"n":"asyncFlowOption","p":5219596}],"n":".ctor","o":"$ctor$3","d":5154060,"h":55839728908,"f":16777217},{"p":[{"n":"transactionToUse","p":4302092},{"n":"scopeTimeout","p":140574721},{"n":"interopOption","p":2270476}],"n":".ctor","o":"$ctor$2","d":5154060,"h":60134696204,"f":16777217}],"i":[57540609],"h":5154060,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"browser","t":1310721}]}]}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.Transactions.TransactionScope`; }
        });
        
        $asm.$cls("$stl.System.Transactions.InternalTransaction", ($self) => class InternalTransaction extends $.$$.System.Object
        {
            /*TransactionState?*/ _transactionState = null;
            /*TransactionState? */ get State()
            {
                return this._transactionState;
            }
            /*TransactionState? */ set State(value)
            {
                this._transactionState = value;
            }
            /*TransactionState*/ _promoteState = null;
            /*Guid*/ _promoterType;
            /*byte[]?*/ promotedToken = null;
            /*Guid*/ _distributedTransactionIdentifierNonMSDTC;
            /*int*/ static MaxStateHist = 20;
            /*TransactionState[]*/ _stateHistory = null;
            /*int*/ _currentStateHist = 0;
            /*FinalizedObject?*/ _finalizedObject = null;
            /*int*/ _transactionHash = 0;
            /*int */ get TransactionHash()
            {
                return this._transactionHash;
            }
            /*int*/ static _nextHash = 0;
            /*long*/ _absoluteTimeout = 0n;
            /*long */ get AbsoluteTimeout()
            {
                return this._absoluteTimeout;
            }
            /*long*/ _creationTime = 0n;
            /*long */ get CreationTime()
            {
                return this._creationTime;
            }
            /*long */ set CreationTime(value)
            {
                this._creationTime = value;
            }
            /*InternalEnlistment?*/ _durableEnlistment = null;
            /*VolatileEnlistmentSet*/ _phase0Volatiles;
            /*VolatileEnlistmentSet*/ _phase1Volatiles;
            /*int*/ _phase0VolatileWaveCount = 0;
            /*OletxDependentTransaction?*/ _phase0WaveDependentClone = null;
            /*int*/ _phase0WaveDependentCloneCount = 0;
            /*OletxDependentTransaction?*/ _abortingDependentClone = null;
            /*int*/ _abortingDependentCloneCount = 0;
            /*int*/ static VolatileArrayIncrement = 8;
            /*Bucket?*/ _tableBucket = null;
            /*int*/ _bucketIndex = 0;
            /*TransactionCompletedEventHandler?*/ _transactionCompletedDelegate = null;
            /*OletxTransaction?*/ _promotedTransaction = null;
            /*OletxTransaction? */ get PromotedTransaction()
            {
                return this._promotedTransaction;
            }
            /*OletxTransaction? */ set PromotedTransaction(value)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(this._promotedTransaction === null, "A transaction can only be promoted once!");
                this._promotedTransaction = value;
            }
            /*Exception?*/ _innerException = null;
            /*int*/ _cloneCount = 0;
            /*int*/ _enlistmentCount = 0;
            /*ManualResetEvent?*/ _asyncResultEvent = null;
            /*bool*/ _asyncCommit = false;
            /*AsyncCallback?*/ _asyncCallback = null;
            /*object?*/ _asyncState = null;
            /*bool*/ _needPulse = false;
            /*TransactionInformation?*/ _transactionInformation = null;
            /*CommittableTransaction?*/ _committableTransaction = null;
            /*Transaction*/ _outcomeSource = null;
            /*object?*/ static s_classSyncObject = null;
            /*Guid */ get DistributedTxId()
            {
                return this.State.get_Identifier(this);
            }
            /*string?*/ static s_instanceIdentifier = null;
            static /*string */ get InstanceIdentifier()
            {
                return $.$$.System.Threading.LazyInitializer.EnsureInitialized$3($.$$.System.String, $.$ref(() => $.$stl.System.Transactions.InternalTransaction.s_instanceIdentifier, ($v) => $.$stl.System.Transactions.InternalTransaction.s_instanceIdentifier = $v, $.$$.System.String), $.$ref(() => $.$stl.System.Transactions.InternalTransaction.s_classSyncObject, ($v) => $.$stl.System.Transactions.InternalTransaction.s_classSyncObject = $v, $.$$.System.Object), new ($.$$.System.Func$$($.$$.System.String))().$ctor(this,  () =>
                {
                    return `${$.$$.System.Guid.ToString.call($.$$.System.Guid.NewGuid())}:`;
                }, {"r":1310721,"n":"","d":2794764,"h":0,"f":17825794}));
            }
            /*bool*/ _traceIdentifierInited = false;
            /*TransactionTraceIdentifier*/ _traceIdentifier;
            /*TransactionTraceIdentifier */ get TransactionTraceId()
            {
                if (!this._traceIdentifierInited)
                {
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1(this)
                        {
                            if (!this._traceIdentifierInited)
                            {
                                /*TransactionTraceIdentifier*/ let temp = new $.$stl.System.Transactions.TransactionTraceIdentifier().$ctor$3($.$$.System.String.Create$6($.$$.System.Globalization.CultureInfo.InvariantCulture, `${$.$stl.System.Transactions.InternalTransaction.InstanceIdentifier}${this._transactionHash}`), 0);
                                this._traceIdentifier = temp;
                                this._traceIdentifierInited = true;
                            }
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit(this)
                    }
                }
                return this._traceIdentifier;
            }
            /*ITransactionPromoter?*/ _promoter = null;
            /*bool*/ _attemptingPSPEPromote = false;
            /*void */ SetPromoterTypeToMSDTC()
            {
                if (($.$$.System.Guid.op_Inequality(this._promoterType, $.$$.System.Guid.Empty)) && ($.$$.System.Guid.op_Inequality(this._promoterType, $.$stl.System.Transactions.TransactionInterop.PromoterTypeDtc)))
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$stl.System.SR.PromoterTypeInvalid);
                }
                this._promoterType = $.$stl.System.Transactions.TransactionInterop.PromoterTypeDtc;
            }
            /*void */ ThrowIfPromoterTypeIsNotMSDTC()
            {
                if (($.$$.System.Guid.op_Inequality(this._promoterType, $.$$.System.Guid.Empty)) && ($.$$.System.Guid.op_Inequality(this._promoterType, $.$stl.System.Transactions.TransactionInterop.PromoterTypeDtc)))
                {
                    throw new $.$stl.System.Transactions.TransactionPromotionException().$ctor$15($.$stl.System.SR.Format$6($.$stl.System.SR.PromoterTypeUnrecognized, $.$$.System.Guid.ToString.call(this._promoterType)), this._innerException);
                }
            }
            $ctor$1(/*TimeSpan*/ timeout, /*CommittableTransaction*/ committableTransaction)
            {
                super.$ctor();
                {
                    this._absoluteTimeout = $.$stl.System.Transactions.TransactionManager.TransactionTable.TimeoutTicks(timeout);
                    $.$stl.System.Transactions.TransactionState.TransactionStateActive.EnterState(this);
                    this._promoteState = $.$stl.System.Transactions.TransactionState.TransactionStatePromoted;
                    this._committableTransaction = committableTransaction;
                    this._outcomeSource = committableTransaction;
                    this._transactionHash = $.$stl.System.Transactions.TransactionManager.TransactionTable.Add(this);
                }
                return this;
            }
            $ctor$3(/*Transaction*/ outcomeSource, /*OletxTransaction*/ distributedTx)
            {
                super.$ctor();
                {
                    this._promotedTransaction = distributedTx;
                    this._absoluteTimeout = 9223372036854775807n;
                    this._outcomeSource = outcomeSource;
                    this._transactionHash = $.$stl.System.Transactions.TransactionManager.TransactionTable.Add(this);
                    $.$stl.System.Transactions.TransactionState.TransactionStateNonCommittablePromoted.EnterState(this);
                    this._promoteState = $.$stl.System.Transactions.TransactionState.TransactionStateNonCommittablePromoted;
                }
                return this;
            }
            $ctor$2(/*Transaction*/ outcomeSource, /*ITransactionPromoter*/ promoter)
            {
                super.$ctor();
                {
                    this._absoluteTimeout = 9223372036854775807n;
                    this._outcomeSource = outcomeSource;
                    this._transactionHash = $.$stl.System.Transactions.TransactionManager.TransactionTable.Add(this);
                    this._promoter = promoter;
                    $.$stl.System.Transactions.TransactionState.TransactionStateSubordinateActive.EnterState(this);
                    this._promoteState = $.$stl.System.Transactions.TransactionState.TransactionStateDelegatedSubordinate;
                }
                return this;
            }
            static /*void */ DistributedTransactionOutcome(/*InternalTransaction*/ tx, /*TransactionStatus*/ status)
            {
                /*FinalizedObject?*/ let fo = null;
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(tx)
                    {
                        if (null === tx._innerException)
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(tx.PromotedTransaction !== null, "tx.PromotedTransaction != null");
                            tx._innerException = tx.PromotedTransaction.InnerException;
                        }
                        $.$$.System.Diagnostics.Debug.Assert$2(tx.State !== null, "tx.State! != null");
                        switch(status)
                        {
                            case 1/*TransactionStatus.Committed*/:
                            {
                                tx.State.ChangeStatePromotedCommitted(tx);
                                break;
                            }
                            case 2/*TransactionStatus.Aborted*/:
                            {
                                tx.State.ChangeStatePromotedAborted(tx);
                                break;
                            }
                            case 3/*TransactionStatus.InDoubt*/:
                            {
                                tx.State.InDoubtFromDtc(tx);
                                break;
                            }
                            default:
                            {
                                $.$$.System.Diagnostics.Debug.Fail$1("InternalTransaction.DistributedTransactionOutcome - Unexpected TransactionStatus");
                                $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException(1/*TraceSourceType.TraceSourceLtm*/, "", null, tx.DistributedTxId);
                                break;
                            }
                        }
                        fo = tx._finalizedObject;
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(tx)
                }
                fo?.Dispose();
            }
            /*void */ SignalAsyncCompletion()
            {
                this._asyncResultEvent?.Set$1();
                if (this._asyncCallback !== null)
                {
                    $.$$.System.Threading.Monitor.Exit(this);
                    try
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(this._committableTransaction !== null, "_committableTransaction != null");
                        this._asyncCallback.Invoke(this._committableTransaction);
                    }
                    finally
                    {
                        {
                            $.$$.System.Threading.Monitor.Enter$1(this);
                        }
                    }
                }
            }
            /*void */ FireCompletion()
            {
                /*TransactionCompletedEventHandler?*/ let eventHandlers = this._transactionCompletedDelegate;
                if (eventHandlers !== null)
                {
                    /*TransactionEventArgs*/ let args = new $.$stl.System.Transactions.TransactionEventArgs().$ctor$2();
                    args._transaction = this._outcomeSource.InternalClone();
                    eventHandlers.Invoke(args._transaction, args);
                }
            }
            /*void */ Dispose()
            {
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this._promoterType = $.$$.System.Guid.Empty;
                this._distributedTransactionIdentifierNonMSDTC = $.$$.System.Guid.Empty;
                this._stateHistory = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$stl.System.Transactions.TransactionState), null, [20/*MaxStateHist*/], null);
                this._phase0Volatiles = $.$default($.$stl.System.Transactions.VolatileEnlistmentSet);
                this._phase1Volatiles = $.$default($.$stl.System.Transactions.VolatileEnlistmentSet);
                this._traceIdentifier = $.$default($.$stl.System.Transactions.TransactionTraceIdentifier);
            }
            static $h = 2794764;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":5743884,"g":{"r":0,"d":0,"h":12887696652,"f":50331656},"s":{"r":0,"d":0,"h":17182663948,"f":83886088},"n":"State","d":2794764,"h":8592729356,"f":2097160},{"p":655361,"g":{"r":0,"d":0,"h":64427304204,"f":50331656},"n":"TransactionHash","d":2794764,"h":60132336908,"f":2097160},{"p":917505,"g":{"r":0,"d":0,"h":81607173388,"f":50331656},"n":"AbsoluteTimeout","d":2794764,"h":77312206092,"f":2097160},{"p":917505,"g":{"r":0,"d":0,"h":94492075276,"f":50331656},"s":{"r":0,"d":0,"h":98787042572,"f":83886088},"n":"CreationTime","d":2794764,"h":90197107980,"f":2097160},{"p":3515660,"g":{"r":0,"d":0,"h":163211552012,"f":50331656},"s":{"r":0,"d":0,"h":167506519308,"f":83886088},"n":"PromotedTransaction","d":2794764,"h":158916584716,"f":2097160},{"p":56229889,"g":{"r":0,"d":0,"h":227636061452,"f":50331656},"n":"DistributedTxId","d":2794764,"h":223341094156,"f":2097160},{"p":1310721,"g":{"r":0,"d":0,"h":240520963340,"f":50331688},"n":"InstanceIdentifier","d":2794764,"h":236225996044,"f":2097192},{"p":8561932,"g":{"r":0,"d":0,"h":257700832524,"f":50331656},"n":"TransactionTraceId","d":2794764,"h":253405865228,"f":2097160}],"m":[{"r":65537,"n":"SetPromoterTypeToMSDTC","d":2794764,"h":270585734412,"f":16777224},{"r":65537,"n":"ThrowIfPromoterTypeIsNotMSDTC","d":2794764,"h":274880701708,"f":16777224},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"status","p":8430860}],"n":"DistributedTransactionOutcome","d":2794764,"h":292060570892,"f":16777256},{"r":65537,"n":"SignalAsyncCompletion","d":2794764,"h":296355538188,"f":16777224},{"r":65537,"n":"FireCompletion","d":2794764,"h":300650505484,"f":16777224},{"r":65537,"n":"Dispose","d":2794764,"h":304945472780,"f":16777217}],"l":[{"t":5743884,"n":"_transactionState","d":2794764,"h":4297762060,"f":4194306},{"t":5743884,"n":"_promoteState","d":2794764,"h":21477631244,"f":4194312},{"t":56229889,"n":"_promoterType","d":2794764,"h":25772598540,"f":4194312},{"t":$.$typeArray($.$$.System.Byte).$h,"n":"promotedToken","d":2794764,"h":30067565836,"f":4194312},{"t":56229889,"n":"_distributedTransactionIdentifierNonMSDTC","d":2794764,"h":34362533132,"f":4194312},{"t":655361,"n":"MaxStateHist","d":2794764,"h":38657500428,"f":4194344},{"t":$.$typeArray($.$stl.System.Transactions.TransactionState).$h,"n":"_stateHistory","d":2794764,"h":42952467724,"f":4194312},{"t":655361,"n":"_currentStateHist","d":2794764,"h":47247435020,"f":4194312},{"t":2336012,"n":"_finalizedObject","d":2794764,"h":51542402316,"f":4194312},{"t":655361,"n":"_transactionHash","d":2794764,"h":55837369612,"f":4194312},{"t":655361,"n":"_nextHash","d":2794764,"h":68722271500,"f":4194344},{"t":917505,"n":"_absoluteTimeout","d":2794764,"h":73017238796,"f":4194306},{"t":917505,"n":"_creationTime","d":2794764,"h":85902140684,"f":4194306},{"t":2729228,"n":"_durableEnlistment","d":2794764,"h":103082009868,"f":4194312},{"t":9348364,"n":"_phase0Volatiles","d":2794764,"h":107376977164,"f":4194312},{"t":9348364,"n":"_phase1Volatiles","d":2794764,"h":111671944460,"f":4194312},{"t":655361,"n":"_phase0VolatileWaveCount","d":2794764,"h":115966911756,"f":4194312},{"t":3450124,"n":"_phase0WaveDependentClone","d":2794764,"h":120261879052,"f":4194312},{"t":655361,"n":"_phase0WaveDependentCloneCount","d":2794764,"h":124556846348,"f":4194312},{"t":3450124,"n":"_abortingDependentClone","d":2794764,"h":128851813644,"f":4194312},{"t":655361,"n":"_abortingDependentCloneCount","d":2794764,"h":133146780940,"f":4194312},{"t":655361,"n":"VolatileArrayIncrement","d":2794764,"h":137441748236,"f":4194344},{"t":304396,"n":"_tableBucket","d":2794764,"h":141736715532,"f":4194312},{"t":655361,"n":"_bucketIndex","d":2794764,"h":146031682828,"f":4194312},{"t":4433164,"n":"_transactionCompletedDelegate","d":2794764,"h":150326650124,"f":4194312},{"t":3515660,"n":"_promotedTransaction","d":2794764,"h":154621617420,"f":4194306},{"t":655361,"n":"_cloneCount","d":2794764,"h":176096453900,"f":4194312},{"t":655361,"n":"_enlistmentCount","d":2794764,"h":180391421196,"f":4194312},{"t":128188417,"n":"_asyncResultEvent","d":2794764,"h":184686388492,"f":4194312},{"t":262145,"n":"_asyncCommit","d":2794764,"h":188981355788,"f":4194312},{"t":14548993,"n":"_asyncCallback","d":2794764,"h":193276323084,"f":4194312},{"t":131073,"n":"_asyncState","d":2794764,"h":197571290380,"f":4194312},{"t":262145,"n":"_needPulse","d":2794764,"h":201866257676,"f":4194312},{"t":4760844,"n":"_transactionInformation","d":2794764,"h":206161224972,"f":4194312},{"t":566540,"n":"_committableTransaction","d":2794764,"h":210456192268,"f":4194312},{"t":4302092,"n":"_outcomeSource","d":2794764,"h":214751159564,"f":4194312},{"t":131073,"n":"s_classSyncObject","d":2794764,"h":219046126860,"f":4194338},{"t":1310721,"n":"s_instanceIdentifier","d":2794764,"h":231931028748,"f":4194338},{"t":262145,"n":"_traceIdentifierInited","d":2794764,"h":244815930636,"f":4194306},{"t":8561932,"n":"_traceIdentifier","d":2794764,"h":249110897932,"f":4194306},{"t":3253516,"n":"_promoter","d":2794764,"h":261995799820,"f":4194312},{"t":262145,"n":"_attemptingPSPEPromote","d":2794764,"h":266290767116,"f":4194312}],"c":[{"p":[{"n":"timeout","p":140574721},{"n":"committableTransaction","p":566540}],"n":".ctor","o":"$ctor$1","d":2794764,"h":279175669004,"f":16777224},{"p":[{"n":"outcomeSource","p":4302092},{"n":"distributedTx","p":3515660}],"n":".ctor","o":"$ctor$3","d":2794764,"h":283470636300,"f":16777224},{"p":[{"n":"outcomeSource","p":4302092},{"n":"promoter","p":3253516}],"n":".ctor","o":"$ctor$2","d":2794764,"h":287765603596,"f":16777224}],"i":[57540609],"h":2794764}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.Transactions.InternalTransaction`; }
        });
        
        $asm.$cls("$stl.System.Transactions.Oletx.OletxTransaction", ($self) => class OletxTransaction extends $.$$.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*SerializationInfo*/ serializationInfo, /*StreamingContext*/ context)
            {
                super.$ctor();
                {
                    throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
                }
                return this;
            }
            /*Exception?*/ InnerException = null;
            /*Guid*/ Identifier;
            /*RealOletxTransaction?*/ RealTransaction = null;
            /*TransactionTraceIdentifier*/ TransactionTraceId;
            /*IsolationLevel*/ IsolationLevel = 0;
            /*Transaction?*/ SavedLtmPromotedTransaction = null;
            /*IPromotedEnlistment */ EnlistVolatile(/*InternalEnlistment*/ internalEnlistment, /*EnlistmentOptions*/ enlistmentOptions)
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransaction.NotSupported();
            }
            /*IPromotedEnlistment */ EnlistDurable(/*Guid*/ resourceManagerIdentifier, /*DurableInternalEnlistment*/ internalEnlistment, /*bool*/ v, /*EnlistmentOptions*/ enlistmentOptions)
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransaction.NotSupported();
            }
            /*void */ Rollback()
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransaction.NotSupported();
            }
            /*OletxDependentTransaction */ DependentClone(/*bool*/ delayCommit)
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransaction.NotSupported();
            }
            /*IPromotedEnlistment */ EnlistVolatile$1(/*VolatileDemultiplexer*/ volatileDemux, /*EnlistmentOptions*/ enlistmentOptions)
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransaction.NotSupported();
            }
            static /*byte[] */ GetExportCookie(/*byte[]*/ whereaboutsCopy)
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransaction.NotSupported();
            }
            static /*byte[] */ GetTransmitterPropagationToken()
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransaction.NotSupported();
            }
            static /*IDtcTransaction */ GetDtcTransaction()
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransaction.NotSupported();
            }
            /*void */ GetObjectData(/*SerializationInfo*/ serializationInfo, /*StreamingContext*/ context)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose()
            {
            }
            static /*Exception */ NotSupported()
            {
                return new $.$$.System.PlatformNotSupportedException().$ctor$16($.$stl.System.SR.DistributedNotSupported);
            }
            static $_RealOletxTransaction;
            static get RealOletxTransaction()
            {
                let $cls = $.$stl.System.Transactions.Oletx.OletxTransaction;
                return $cls.$_RealOletxTransaction ??= $asm.$ncls("$stl.System.Transactions.Oletx.OletxTransaction.RealOletxTransaction", ($self) => class RealOletxTransaction extends $.$$.System.Object
                {
                    /*InternalTransaction?*/ InternalTransaction = null;
                    //default reference type constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        return this;
                    }
                    static $h = 3581196;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":2794764,"g":{"r":0,"d":0,"h":12888483084,"f":50331656},"s":{"r":0,"d":0,"h":17183450380,"f":83886088},"n":"InternalTransaction","d":3581196,"h":8593515788,"f":2097160}],"c":[{"n":".ctor","o":"$ctor$1","d":3581196,"h":21478417676,"f":16777217}],"d":3515660,"h":3581196}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Transactions.Oletx.OletxTransaction.RealOletxTransaction`; }
                }, $cls, ($v) => $cls.$_RealOletxTransaction = $v);
            }
            //Generated interface implemetation for System.Runtime.Serialization.ISerializable.GetObjectData(System.Runtime.Serialization.SerializationInfo, System.Runtime.Serialization.StreamingContext)
            System$Runtime$Serialization$ISerializable$GetObjectData()
            {
                return this.GetObjectData(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this.Identifier = $.$default($.$$.System.Guid);
                this.TransactionTraceId = $.$default($.$stl.System.Transactions.TransactionTraceIdentifier);
                this.IsolationLevel = 0;
            }
            static $h = 3515660;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":56229889,"g":{"r":0,"d":0,"h":38658221324,"f":50331656},"s":{"r":0,"d":0,"h":42953188620,"f":83886088},"n":"Identifier","d":3515660,"h":34363254028,"f":2097160},{"p":3581196,"g":{"r":0,"d":0,"h":55838090508,"f":50331656},"s":{"r":0,"d":0,"h":60133057804,"f":83886088},"n":"RealTransaction","d":3515660,"h":51543123212,"f":2097160},{"p":8561932,"g":{"r":0,"d":0,"h":73017959692,"f":50331656},"s":{"r":0,"d":0,"h":77312926988,"f":83886088},"n":"TransactionTraceId","d":3515660,"h":68722992396,"f":2097160},{"p":3187980,"g":{"r":0,"d":0,"h":90197828876,"f":50331656},"s":{"r":0,"d":0,"h":94492796172,"f":83886088},"n":"IsolationLevel","d":3515660,"h":85902861580,"f":2097160},{"p":4302092,"g":{"r":0,"d":0,"h":107377698060,"f":50331656},"s":{"r":0,"d":0,"h":111672665356,"f":83886088},"n":"SavedLtmPromotedTransaction","d":3515660,"h":103082730764,"f":2097160}],"m":[{"r":2925836,"p":[{"n":"internalEnlistment","p":2729228},{"n":"enlistmentOptions","p":1877260}],"n":"EnlistVolatile","d":3515660,"h":115967632652,"f":16777224},{"r":2925836,"p":[{"n":"resourceManagerIdentifier","p":56229889},{"n":"internalEnlistment","p":1615116},{"n":"v","p":262145},{"n":"enlistmentOptions","p":1877260}],"n":"EnlistDurable","d":3515660,"h":120262599948,"f":16777224},{"r":65537,"n":"Rollback","d":3515660,"h":124557567244,"f":16777224},{"r":3450124,"p":[{"n":"delayCommit","p":262145}],"n":"DependentClone","d":3515660,"h":128852534540,"f":16777224},{"r":2925836,"p":[{"n":"volatileDemux","p":8693004},{"n":"enlistmentOptions","p":1877260}],"n":"EnlistVolatile","o":"@$1","d":3515660,"h":133147501836,"f":16777224},{"r":$.$typeArray($.$$.System.Byte).$h,"p":[{"n":"whereaboutsCopy","p":$.$typeArray($.$$.System.Byte).$h}],"n":"GetExportCookie","d":3515660,"h":137442469132,"f":16777256},{"r":$.$typeArray($.$$.System.Byte).$h,"n":"GetTransmitterPropagationToken","d":3515660,"h":141737436428,"f":16777256},{"r":2532620,"n":"GetDtcTransaction","d":3515660,"h":146032403724,"f":16777256},{"r":65537,"p":[{"n":"serializationInfo","p":113836033},{"n":"context","p":113967105}],"n":"GetObjectData","d":3515660,"h":150327371020,"f":16777217},{"r":65537,"n":"Dispose","d":3515660,"h":154622338316,"f":16777224},{"r":47251457,"n":"NotSupported","d":3515660,"h":158917305612,"f":16777256}],"c":[{"n":".ctor","o":"$ctor$1","d":3515660,"h":4298482956,"f":16777224},{"p":[{"n":"serializationInfo","p":113836033},{"n":"context","p":113967105}],"n":".ctor","o":"$ctor$2","d":3515660,"h":8593450252,"f":16777220}],"i":[113246209],"j":[3581196],"h":3515660}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Transactions.Oletx.OletxTransaction`; }
        });
        
        $asm.$cls("$stl.System.Transactions.FinalizedObject", ($self) => class FinalizedObject extends $.$$.System.Object
        {
            /*Guid*/ _identifier;
            /*InternalTransaction*/ _internalTransaction = null;
            $ctor$1(/*InternalTransaction*/ internalTransaction, /*Guid*/ identifier)
            {
                super.$ctor();
                {
                    this._internalTransaction = internalTransaction;
                    this._identifier = identifier;
                }
                return this;
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                if (disposing)
                {
                    $.$$.System.GC.SuppressFinalize(this);
                }
                /*Hashtable*/ let promotedTransactionTable = $.$stl.System.Transactions.TransactionManager.PromotedTransactionTable;
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(promotedTransactionTable)
                    {
                        /*WeakReference?*/ let weakRef = $.$cast(promotedTransactionTable.get_Item(this._identifier), $.$$.System.WeakReference);
                        if (null !== weakRef)
                        {
                            if (weakRef.Target !== null)
                            {
                                weakRef.Target = null;
                            }
                        }
                        promotedTransactionTable.Remove(this._identifier);
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(promotedTransactionTable)
                }
            }
            /*void */ Dispose()
            {
                this.Dispose$1(true);
            }
            $dtor()
            {
                this.Dispose$1(false);
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this._identifier = $.$default($.$$.System.Guid);
                $.$finalizer(this);
            }
            static $h = 2336012;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":2336012,"h":17182205196,"f":16777218},{"r":65537,"n":"Dispose","d":2336012,"h":21477172492,"f":16777217}],"l":[{"t":56229889,"n":"_identifier","d":2336012,"h":4297303308,"f":4194306},{"t":2794764,"n":"_internalTransaction","d":2336012,"h":8592270604,"f":4194306}],"c":[{"p":[{"n":"internalTransaction","p":2794764},{"n":"identifier","p":56229889}],"n":".ctor","o":"$ctor$1","d":2336012,"h":12887237900,"f":16777224}],"i":[57540609],"h":2336012}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.Transactions.FinalizedObject`; }
        });
        
        $asm.$cls("$stl.System.Transactions.InternalEnlistment", ($self) => class InternalEnlistment extends $.$$.System.Object
        {
            /*EnlistmentState?*/ _twoPhaseState = null;
            /*IEnlistmentNotification?*/ _twoPhaseNotifications = null;
            /*ISinglePhaseNotification?*/ _singlePhaseNotifications = null;
            /*InternalTransaction*/ _transaction = null;
            /*Transaction?*/ _atomicTransaction = null;
            /*EnlistmentTraceIdentifier*/ _traceIdentifier;
            /*int*/ _enlistmentId = 0;
            /*Guid */ get DistributedTxId()
            {
                /*Guid*/ let returnValue = $.$$.System.Guid.Empty;
                if (this.Transaction !== null)
                {
                    returnValue = this.Transaction.DistributedTxId;
                }
                return returnValue;
            }
            /*Enlistment*/ _enlistment = null;
            /*PreparingEnlistment?*/ _preparingEnlistment = null;
            /*SinglePhaseEnlistment?*/ _singlePhaseEnlistment = null;
            /*IPromotedEnlistment?*/ _promotedEnlistment = null;
            $ctor$2(/*Enlistment*/ enlistment, /*IEnlistmentNotification*/ twoPhaseNotifications)
            {
                super.$ctor();
                {
                    $.$$.System.Diagnostics.Debug.Assert$2($.$is(this, $.$stl.System.Transactions.RecoveringInternalEnlistment), "this is RecoveringInternalEnlistment");
                    this._enlistment = enlistment;
                    this._twoPhaseNotifications = twoPhaseNotifications;
                    this._enlistmentId = 1;
                    this._traceIdentifier = $.$stl.System.Transactions.EnlistmentTraceIdentifier.Empty;
                }
                return this;
            }
            $ctor$4(/*Enlistment*/ enlistment, /*InternalTransaction*/ transaction, /*Transaction*/ atomicTransaction)
            {
                super.$ctor();
                {
                    $.$$.System.Diagnostics.Debug.Assert$2($.$is(this, $.$stl.System.Transactions.PromotableInternalEnlistment), "this is PromotableInternalEnlistment");
                    this._enlistment = enlistment;
                    this._transaction = transaction;
                    this._atomicTransaction = atomicTransaction;
                    this._enlistmentId = transaction._enlistmentCount++;
                    this._traceIdentifier = $.$stl.System.Transactions.EnlistmentTraceIdentifier.Empty;
                }
                return this;
            }
            $ctor$3(/*Enlistment*/ enlistment, /*InternalTransaction*/ transaction, /*IEnlistmentNotification*/ twoPhaseNotifications, /*ISinglePhaseNotification?*/ singlePhaseNotifications, /*Transaction*/ atomicTransaction)
            {
                super.$ctor();
                {
                    this._enlistment = enlistment;
                    this._transaction = transaction;
                    this._twoPhaseNotifications = twoPhaseNotifications;
                    this._singlePhaseNotifications = singlePhaseNotifications;
                    this._atomicTransaction = atomicTransaction;
                    this._enlistmentId = transaction._enlistmentCount++;
                    this._traceIdentifier = $.$stl.System.Transactions.EnlistmentTraceIdentifier.Empty;
                }
                return this;
            }
            $ctor$1(/*Enlistment*/ enlistment, /*IEnlistmentNotification*/ twoPhaseNotifications, /*InternalTransaction*/ transaction, /*Transaction*/ atomicTransaction)
            {
                super.$ctor();
                {
                    this._enlistment = enlistment;
                    this._twoPhaseNotifications = twoPhaseNotifications;
                    this._transaction = transaction;
                    this._atomicTransaction = atomicTransaction;
                }
                return this;
            }
            /*EnlistmentState */ get State()
            {
                $.$$.System.Diagnostics.Debug.Assert$2(this._twoPhaseState !== null, "_twoPhaseState != null");
                return this._twoPhaseState;
            }
            /*EnlistmentState */ set State(value)
            {
                this._twoPhaseState = value;
            }
            /*Enlistment */ get Enlistment()
            {
                return this._enlistment;
            }
            /*PreparingEnlistment */ get PreparingEnlistment()
            {
                return this._preparingEnlistment ??= new $.$stl.System.Transactions.PreparingEnlistment().$ctor$7(this);
            }
            /*SinglePhaseEnlistment */ get SinglePhaseEnlistment()
            {
                return this._singlePhaseEnlistment ??= new $.$stl.System.Transactions.SinglePhaseEnlistment().$ctor$7(this);
            }
            /*InternalTransaction */ get Transaction()
            {
                return this._transaction;
            }
            /*object */ get SyncRoot()
            {
                $.$$.System.Diagnostics.Debug.Assert$2(this._transaction !== null, "this.transaction != null");
                return this._transaction;
            }
            /*IEnlistmentNotification? */ get EnlistmentNotification()
            {
                return this._twoPhaseNotifications;
            }
            /*ISinglePhaseNotification? */ get SinglePhaseNotification()
            {
                return this._singlePhaseNotifications;
            }
            /*IPromotableSinglePhaseNotification */ get PromotableSinglePhaseNotification()
            {
                $.$$.System.Diagnostics.Debug.Fail$1("PromotableSinglePhaseNotification called for a non promotable enlistment.");
                throw new $.$$.System.NotImplementedException().$ctor$9();
            }
            /*IPromotedEnlistment? */ get PromotedEnlistment()
            {
                return this._promotedEnlistment;
            }
            /*IPromotedEnlistment? */ set PromotedEnlistment(value)
            {
                this._promotedEnlistment = value;
            }
            /*EnlistmentTraceIdentifier */ get EnlistmentTraceId()
            {
                if ($.$stl.System.Transactions.EnlistmentTraceIdentifier.op_Equality(this._traceIdentifier, $.$stl.System.Transactions.EnlistmentTraceIdentifier.Empty))
                {
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1(this.SyncRoot)
                        {
                            if ($.$stl.System.Transactions.EnlistmentTraceIdentifier.op_Equality(this._traceIdentifier, $.$stl.System.Transactions.EnlistmentTraceIdentifier.Empty))
                            {
                                /*EnlistmentTraceIdentifier*/ let temp;
                                if ($.$stl.System.Transactions.Transaction.op_Inequality(null, this._atomicTransaction))
                                {
                                    temp = new $.$stl.System.Transactions.EnlistmentTraceIdentifier().$ctor$3($.$$.System.Guid.Empty, this._atomicTransaction.TransactionTraceId, this._enlistmentId);
                                }
                                else 
                                {
                                    temp = new $.$stl.System.Transactions.EnlistmentTraceIdentifier().$ctor$3($.$$.System.Guid.Empty, new $.$stl.System.Transactions.TransactionTraceIdentifier().$ctor$3($.$$.System.String.Create$6($.$$.System.Globalization.CultureInfo.InvariantCulture, `${$.$stl.System.Transactions.InternalTransaction.InstanceIdentifier}${$.$$.System.Threading.Interlocked.Increment($.$ref(() => $.$stl.System.Transactions.InternalTransaction._nextHash, ($v) => $.$stl.System.Transactions.InternalTransaction._nextHash = $v, $.$$.System.Int32))}`), 0), this._enlistmentId);
                                }
                                $.$$.System.Threading.Interlocked.MemoryBarrier();
                                this._traceIdentifier = temp;
                            }
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit(this.SyncRoot)
                    }
                }
                return this._traceIdentifier;
            }
            /*void */ FinishEnlistment()
            {
                this.Transaction._phase0Volatiles._preparedVolatileEnlistments++;
                this.CheckComplete();
            }
            /*void */ CheckComplete()
            {
                $.$$.System.Diagnostics.Debug.Assert$2(this.Transaction._phase0Volatiles._preparedVolatileEnlistments <= ((this.Transaction._phase0Volatiles._volatileEnlistmentCount + this.Transaction._phase0Volatiles._dependentClones) | 0), "Transaction._phase0Volatiles._preparedVolatileEnlistments <=\r\n                Transaction._phase0Volatiles._volatileEnlistmentCount + Transaction._phase0Volatiles._dependentClones");
                if (this.Transaction._phase0Volatiles._preparedVolatileEnlistments === ((this.Transaction._phase0VolatileWaveCount + this.Transaction._phase0Volatiles._dependentClones) | 0))
                {
                    this.Transaction.State.Phase0VolatilePrepareDone(this.Transaction);
                }
            }
            /*Guid */ get ResourceManagerIdentifier()
            {
                $.$$.System.Diagnostics.Debug.Fail$1("ResourceManagerIdentifier called for non durable enlistment");
                throw new $.$$.System.NotImplementedException().$ctor$9();
            }
            /*void */ System$Transactions$ISinglePhaseNotificationInternal$SinglePhaseCommit(/*IPromotedEnlistment*/ singlePhaseEnlistment)
            {
                /*bool*/ let spcCommitted = false;
                this._promotedEnlistment = singlePhaseEnlistment;
                try
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(this._singlePhaseNotifications !== null, "_singlePhaseNotifications != null");
                    this._singlePhaseNotifications.System$Transactions$ISinglePhaseNotification$SinglePhaseCommit(this.SinglePhaseEnlistment);
                    spcCommitted = true;
                }
                finally
                {
                    {
                        if (!spcCommitted)
                        {
                            this.SinglePhaseEnlistment.InDoubt();
                        }
                    }
                }
            }
            /*void */ System$Transactions$IEnlistmentNotificationInternal$Prepare(/*IPromotedEnlistment*/ preparingEnlistment)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(this._twoPhaseNotifications !== null, "_twoPhaseNotifications != null");
                this._promotedEnlistment = preparingEnlistment;
                this._twoPhaseNotifications.System$Transactions$IEnlistmentNotification$Prepare(this.PreparingEnlistment);
            }
            /*void */ System$Transactions$IEnlistmentNotificationInternal$Commit(/*IPromotedEnlistment*/ enlistment)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(this._twoPhaseNotifications !== null, "_twoPhaseNotifications != null");
                this._promotedEnlistment = enlistment;
                this._twoPhaseNotifications.System$Transactions$IEnlistmentNotification$Commit(this.Enlistment);
            }
            /*void */ System$Transactions$IEnlistmentNotificationInternal$Rollback(/*IPromotedEnlistment*/ enlistment)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(this._twoPhaseNotifications !== null, "_twoPhaseNotifications != null");
                this._promotedEnlistment = enlistment;
                this._twoPhaseNotifications.System$Transactions$IEnlistmentNotification$Rollback(this.Enlistment);
            }
            /*void */ System$Transactions$IEnlistmentNotificationInternal$InDoubt(/*IPromotedEnlistment*/ enlistment)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(this._twoPhaseNotifications !== null, "_twoPhaseNotifications != null");
                this._promotedEnlistment = enlistment;
                this._twoPhaseNotifications.System$Transactions$IEnlistmentNotification$InDoubt(this.Enlistment);
            }
            //default member initializer
            constructor()
            {
                super();
                this._transaction = null;
                this._traceIdentifier = $.$default($.$stl.System.Transactions.EnlistmentTraceIdentifier);
            }
            static $h = 2729228;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":56229889,"g":{"r":0,"d":0,"h":38657434892,"f":50331656},"n":"DistributedTxId","d":2729228,"h":34362467596,"f":2097160},{"p":1942796,"g":{"r":0,"d":0,"h":81607107852,"f":50331656},"s":{"r":0,"d":0,"h":85902075148,"f":83886088},"n":"State","d":2729228,"h":77312140556,"f":2097160},{"p":1746188,"g":{"r":0,"d":0,"h":94492009740,"f":50331656},"n":"Enlistment","d":2729228,"h":90197042444,"f":2097160},{"p":3908876,"g":{"r":0,"d":0,"h":103081944332,"f":50331656},"n":"PreparingEnlistment","d":2729228,"h":98786977036,"f":2097160},{"p":4105484,"g":{"r":0,"d":0,"h":111671878924,"f":50331656},"n":"SinglePhaseEnlistment","d":2729228,"h":107376911628,"f":2097160},{"p":2794764,"g":{"r":0,"d":0,"h":120261813516,"f":50331656},"n":"Transaction","d":2729228,"h":115966846220,"f":2097160},{"p":131073,"g":{"r":0,"d":0,"h":128851748108,"f":50331784},"n":"SyncRoot","d":2729228,"h":124556780812,"f":2097288},{"p":2598156,"g":{"r":0,"d":0,"h":137441682700,"f":50331656},"n":"EnlistmentNotification","d":2729228,"h":133146715404,"f":2097160},{"p":3056908,"g":{"r":0,"d":0,"h":146031617292,"f":50331656},"n":"SinglePhaseNotification","d":2729228,"h":141736649996,"f":2097160},{"p":2860300,"g":{"r":0,"d":0,"h":154621551884,"f":50331784},"n":"PromotableSinglePhaseNotification","d":2729228,"h":150326584588,"f":2097288},{"p":2925836,"g":{"r":0,"d":0,"h":163211486476,"f":50331656},"s":{"r":0,"d":0,"h":167506453772,"f":83886088},"n":"PromotedEnlistment","d":2729228,"h":158916519180,"f":2097160},{"p":2073868,"g":{"r":0,"d":0,"h":176096388364,"f":50331656},"n":"EnlistmentTraceId","d":2729228,"h":171801421068,"f":2097160},{"p":56229889,"g":{"r":0,"d":0,"h":193276257548,"f":50331784},"n":"ResourceManagerIdentifier","d":2729228,"h":188981290252,"f":2097288}],"m":[{"r":65537,"n":"FinishEnlistment","d":2729228,"h":180391355660,"f":16777352},{"r":65537,"n":"CheckComplete","d":2729228,"h":184686322956,"f":16777352}],"l":[{"t":1942796,"n":"_twoPhaseState","d":2729228,"h":4297696524,"f":4194312},{"t":2598156,"n":"_twoPhaseNotifications","d":2729228,"h":8592663820,"f":4194308},{"t":3056908,"n":"_singlePhaseNotifications","d":2729228,"h":12887631116,"f":4194308},{"t":2794764,"n":"_transaction","d":2729228,"h":17182598412,"f":4194308},{"t":4302092,"n":"_atomicTransaction","d":2729228,"h":21477565708,"f":4194306},{"t":2073868,"n":"_traceIdentifier","d":2729228,"h":25772533004,"f":4194306},{"t":655361,"n":"_enlistmentId","d":2729228,"h":30067500300,"f":4194306},{"t":1746188,"n":"_enlistment","d":2729228,"h":42952402188,"f":4194306},{"t":3908876,"n":"_preparingEnlistment","d":2729228,"h":47247369484,"f":4194306},{"t":4105484,"n":"_singlePhaseEnlistment","d":2729228,"h":51542336780,"f":4194306},{"t":2925836,"n":"_promotedEnlistment","d":2729228,"h":55837304076,"f":4194306}],"c":[{"p":[{"n":"enlistment","p":1746188},{"n":"twoPhaseNotifications","p":2598156}],"n":".ctor","o":"$ctor$2","d":2729228,"h":60132271372,"f":16777220},{"p":[{"n":"enlistment","p":1746188},{"n":"transaction","p":2794764},{"n":"atomicTransaction","p":4302092}],"n":".ctor","o":"$ctor$4","d":2729228,"h":64427238668,"f":16777220},{"p":[{"n":"enlistment","p":1746188},{"n":"transaction","p":2794764},{"n":"twoPhaseNotifications","p":2598156},{"n":"singlePhaseNotifications","p":3056908},{"n":"atomicTransaction","p":4302092}],"n":".ctor","o":"$ctor$3","d":2729228,"h":68722205964,"f":16777224},{"p":[{"n":"enlistment","p":1746188},{"n":"twoPhaseNotifications","p":2598156},{"n":"transaction","p":2794764},{"n":"atomicTransaction","p":4302092}],"n":".ctor","o":"$ctor$1","d":2729228,"h":73017173260,"f":16777224}],"i":[3122444,2663692],"h":2729228}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stl.System.Transactions.ISinglePhaseNotificationInternal, $.$stl.System.Transactions.IEnlistmentNotificationInternal ]; }
            static get $fullName() { return `System.Transactions.InternalEnlistment`; }
        });
        
        $asm.$cls("$stl.System.Transactions.Transaction", ($self) => class Transaction extends $.$$.System.Object
        {
            static /*bool */ UseServiceDomainForCurrent()
            {
                return false;
            }
            static /*EnterpriseServicesInteropOption */ InteropMode(/*TransactionScope?*/ currentScope)
            {
                if (currentScope !== null)
                {
                    return currentScope.InteropMode;
                }
                return 0/*EnterpriseServicesInteropOption.None*/;
            }
            static /*Transaction? */ FastGetTransaction(/*TransactionScope?*/ currentScope, /*ContextData*/ contextData, /*out Transaction?*/ contextTransaction)
            {
                /*Transaction?*/ let current = null;
                contextTransaction.$v = contextData.CurrentTransaction;
                let $switch1 = $.$stl.System.Transactions.Transaction.InteropMode(currentScope);
                switch($switch1)
                {
                    case 0/*EnterpriseServicesInteropOption.None*/:
                    current = contextTransaction.$v;
                    if ($.$stl.System.Transactions.Transaction.op_Equality(current, null) && currentScope === null)
                    {
                        if ($.$stl.System.Transactions.TransactionManager.s_currentDelegateSet)
                        {
                            current = $.$stl.System.Transactions.TransactionManager.s_currentDelegate.Invoke();
                        }
                        else 
                        {
                            current = $.$stl.System.Transactions.EnterpriseServices.GetContextTransaction();
                        }
                    }
                    break;
                    case 2/*EnterpriseServicesInteropOption.Full*/:
                    current = $.$stl.System.Transactions.EnterpriseServices.GetContextTransaction();
                    break;
                    case 1/*EnterpriseServicesInteropOption.Automatic*/:
                    if ($.$stl.System.Transactions.EnterpriseServices.UseServiceDomainForCurrent())
                    {
                        current = $.$stl.System.Transactions.EnterpriseServices.GetContextTransaction();
                    }
                    else 
                    {
                        current = contextData.CurrentTransaction;
                    }
                    break;
                }
                return current;
            }
            static /*void */ GetCurrentTransactionAndScope(/*TxLookup*/ defaultLookup, /*out Transaction?*/ current, /*out TransactionScope?*/ currentScope, /*out Transaction?*/ contextTransaction)
            {
                current.$v = null;
                currentScope.$v = null;
                contextTransaction.$v = null;
                /*ContextData*/ let contextData = $.$stl.System.Transactions.ContextData.LookupContextData(defaultLookup);
                if (contextData !== null)
                {
                    currentScope.$v = contextData.CurrentScope;
                    current.$v = $.$stl.System.Transactions.Transaction.FastGetTransaction(currentScope.$v, contextData, contextTransaction);
                }
            }
            static /*Transaction? */ get Current()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(0/*TraceSourceType.TraceSourceBase*/, "Transaction.get_Current");
                }
                /*Transaction?*/ let current;
                /*TransactionScope?*/ let currentScope;
                $.$stl.System.Transactions.Transaction.GetCurrentTransactionAndScope(0/*TxLookup.Default*/, $.$ref(() => current, ($v) => current = $v, $.$stl.System.Transactions.Transaction), $.$ref(() => currentScope, ($v) => currentScope = $v, $.$stl.System.Transactions.TransactionScope), $.$discardRef());
                if (currentScope !== null)
                {
                    if (currentScope.ScopeComplete)
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$stl.System.SR.TransactionScopeComplete);
                    }
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(0/*TraceSourceType.TraceSourceBase*/, "Transaction.get_Current");
                }
                return current;
            }
            static /*Transaction? */ set Current(value)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(0/*TraceSourceType.TraceSourceBase*/, "Transaction.set_Current");
                }
                if ($.$stl.System.Transactions.Transaction.InteropMode($.$stl.System.Transactions.ContextData.TLSCurrentData.CurrentScope) !== 0/*EnterpriseServicesInteropOption.None*/)
                {
                    if (etwLog.IsEnabled())
                    {
                        etwLog.InvalidOperation("Transaction", "Transaction.set_Current");
                    }
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$stl.System.SR.CannotSetCurrent);
                }
                $.$stl.System.Transactions.ContextData.TLSCurrentData.CurrentTransaction = value;
                $.$stl.System.Transactions.CallContextCurrentData.ClearCurrentData(null, false);
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(0/*TraceSourceType.TraceSourceBase*/, "Transaction.set_Current");
                }
            }
            /*IsolationLevel*/ _isoLevel = 0;
            /*bool*/ _complete = false;
            /*int*/ _cloneId = 0;
            /*int*/ static _disposedTrueValue = 1;
            /*int*/ _disposed = 0;
            /*bool */ get Disposed()
            {
                return this._disposed === 1/*Transaction._disposedTrueValue*/;
            }
            /*Guid */ get DistributedTxId()
            {
                /*Guid*/ let returnValue = $.$$.System.Guid.Empty;
                if (this._internalTransaction !== null)
                {
                    returnValue = this._internalTransaction.DistributedTxId;
                }
                return returnValue;
            }
            /*InternalTransaction*/ _internalTransaction = null;
            /*TransactionTraceIdentifier*/ _traceIdentifier;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*IsolationLevel*/ isoLevel, /*InternalTransaction?*/ internalTransaction)
            {
                super.$ctor();
                {
                    $.$stl.System.Transactions.TransactionManager.ValidateIsolationLevel(isoLevel);
                    this._isoLevel = isoLevel;
                    if (6/*IsolationLevel.Unspecified*/ === this._isoLevel)
                    {
                        this._isoLevel = $.$stl.System.Transactions.TransactionManager.DefaultIsolationLevel;
                    }
                    if (internalTransaction !== null)
                    {
                        this._internalTransaction = internalTransaction;
                        this._cloneId = $.$$.System.Threading.Interlocked.Increment($.$ref(() => this._internalTransaction._cloneCount, ($v) => this._internalTransaction._cloneCount = $v, $.$$.System.Int32));
                    }
                    else 
                    {
                    }
                }
                return this;
            }
            $ctor$4(/*OletxTransaction*/ distributedTransaction)
            {
                super.$ctor();
                {
                    this._isoLevel = distributedTransaction.IsolationLevel;
                    this._internalTransaction = new $.$stl.System.Transactions.InternalTransaction().$ctor$3(this, distributedTransaction);
                    this._cloneId = $.$$.System.Threading.Interlocked.Increment($.$ref(() => this._internalTransaction._cloneCount, ($v) => this._internalTransaction._cloneCount = $v, $.$$.System.Int32));
                }
                return this;
            }
            $ctor$3(/*IsolationLevel*/ isoLevel, /*ISimpleTransactionSuperior*/ superior)
            {
                super.$ctor();
                {
                    $.$stl.System.Transactions.TransactionManager.ValidateIsolationLevel(isoLevel);
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(superior, "superior");
                    this._isoLevel = isoLevel;
                    if (6/*IsolationLevel.Unspecified*/ === this._isoLevel)
                    {
                        this._isoLevel = $.$stl.System.Transactions.TransactionManager.DefaultIsolationLevel;
                    }
                    this._internalTransaction = new $.$stl.System.Transactions.InternalTransaction().$ctor$2(this, superior);
                    this._internalTransaction.SetPromoterTypeToMSDTC();
                    this._cloneId = 1;
                }
                return this;
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return this._internalTransaction.TransactionHash;
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$stl.System.Transactions.Transaction.GetHashCode.apply(this, arguments); }
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                let transaction;
                return $.$is(obj, $.$stl.System.Transactions.Transaction, { set $v(v){ transaction = v; } }) && this._internalTransaction.TransactionHash === transaction._internalTransaction.TransactionHash;
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$stl.System.Transactions.Transaction.Equals$1.apply(this, arguments); }
            static /*bool */ op_Equality(/*Transaction?*/ x, /*Transaction?*/ y)
            {
                if ((x) !== null)
                {
                    return $.$stl.System.Transactions.Transaction.Equals$1.call(x, y);
                }
                return (y) === null;
            }
            static /*bool */ op_Inequality(/*Transaction?*/ x, /*Transaction?*/ y)
            {
                if ((x) !== null)
                {
                    return !$.$stl.System.Transactions.Transaction.Equals$1.call(x, y);
                }
                return (y) !== null;
            }
            /*TransactionInformation */ get TransactionInformation()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "TransactionInformation");
                }
                $.$$.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                /*TransactionInformation?*/ let txInfo = this._internalTransaction._transactionInformation;
                if (txInfo === null)
                {
                    txInfo = new $.$stl.System.Transactions.TransactionInformation().$ctor$1(this._internalTransaction);
                    this._internalTransaction._transactionInformation = txInfo;
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "TransactionInformation");
                }
                return txInfo;
            }
            /*IsolationLevel */ get IsolationLevel()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "IsolationLevel");
                }
                $.$$.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "IsolationLevel");
                }
                return this._isoLevel;
            }
            /*Guid */ get PromoterType()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "PromoterType");
                }
                $.$$.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this._internalTransaction)
                    {
                        return this._internalTransaction._promoterType;
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this._internalTransaction)
                }
            }
            /*byte[] */ GetPromotedToken()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "GetPromotedToken");
                }
                $.$$.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                /*byte[]*/ let internalPromotedToken;
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this._internalTransaction)
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        internalPromotedToken = this._internalTransaction.State.PromotedToken(this._internalTransaction);
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this._internalTransaction)
                }
                /*byte[]*/ let toReturn = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Byte), null, [internalPromotedToken.length], null);
                $.$$.System.Array.Copy(internalPromotedToken, toReturn, toReturn.length);
                return toReturn;
            }
            /*Enlistment */ EnlistDurable(/*Guid*/ resourceManagerIdentifier, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "EnlistDurable");
                }
                $.$$.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                if ($.$$.System.Guid.op_Equality(resourceManagerIdentifier, $.$$.System.Guid.Empty))
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$stl.System.SR.BadResourceManagerId, "resourceManagerIdentifier");
                }
                $.$$.System.ArgumentNullException.ThrowIfNull$2(enlistmentNotification, "enlistmentNotification");
                if (enlistmentOptions !== 0/*EnlistmentOptions.None*/ && enlistmentOptions !== 1/*EnlistmentOptions.EnlistDuringPrepareRequired*/)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("enlistmentOptions");
                }
                if (this._complete)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateTransactionCompletedException(this.DistributedTxId);
                }
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this._internalTransaction)
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        /*Enlistment*/ let enlistment = this._internalTransaction.State.EnlistDurable(this._internalTransaction, resourceManagerIdentifier, enlistmentNotification, enlistmentOptions, this);
                        if (etwLog.IsEnabled())
                        {
                            etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "EnlistDurable");
                        }
                        return enlistment;
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this._internalTransaction)
                }
            }
            /*Enlistment */ EnlistDurable$1(/*Guid*/ resourceManagerIdentifier, /*ISinglePhaseNotification*/ singlePhaseNotification, /*EnlistmentOptions*/ enlistmentOptions)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "EnlistDurable");
                }
                $.$$.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                if ($.$$.System.Guid.op_Equality(resourceManagerIdentifier, $.$$.System.Guid.Empty))
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$stl.System.SR.BadResourceManagerId, "resourceManagerIdentifier");
                }
                $.$$.System.ArgumentNullException.ThrowIfNull$2(singlePhaseNotification, "singlePhaseNotification");
                if (enlistmentOptions !== 0/*EnlistmentOptions.None*/ && enlistmentOptions !== 1/*EnlistmentOptions.EnlistDuringPrepareRequired*/)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("enlistmentOptions");
                }
                if (this._complete)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateTransactionCompletedException(this.DistributedTxId);
                }
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this._internalTransaction)
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        /*Enlistment*/ let enlistment = this._internalTransaction.State.EnlistDurable$1(this._internalTransaction, resourceManagerIdentifier, singlePhaseNotification, enlistmentOptions, this);
                        if (etwLog.IsEnabled())
                        {
                            etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "EnlistDurable");
                        }
                        return enlistment;
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this._internalTransaction)
                }
            }
            /*void */ Rollback()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "Rollback");
                    etwLog.TransactionRollback(1/*TraceSourceType.TraceSourceLtm*/, this.TransactionTraceId, "Transaction");
                }
                $.$$.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this._internalTransaction)
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        this._internalTransaction.State.Rollback(this._internalTransaction, null);
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this._internalTransaction)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "Rollback");
                }
            }
            /*void */ Rollback$1(/*Exception?*/ e)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "Rollback");
                    etwLog.TransactionRollback(1/*TraceSourceType.TraceSourceLtm*/, this.TransactionTraceId, "Transaction");
                }
                $.$$.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this._internalTransaction)
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        this._internalTransaction.State.Rollback(this._internalTransaction, e);
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this._internalTransaction)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "Rollback");
                }
            }
            /*Enlistment */ EnlistVolatile(/*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "EnlistVolatile");
                }
                $.$$.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                $.$$.System.ArgumentNullException.ThrowIfNull$2(enlistmentNotification, "enlistmentNotification");
                if (enlistmentOptions !== 0/*EnlistmentOptions.None*/ && enlistmentOptions !== 1/*EnlistmentOptions.EnlistDuringPrepareRequired*/)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("enlistmentOptions");
                }
                if (this._complete)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateTransactionCompletedException(this.DistributedTxId);
                }
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this._internalTransaction)
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        /*Enlistment*/ let enlistment = this._internalTransaction.State.EnlistVolatile(this._internalTransaction, enlistmentNotification, enlistmentOptions, this);
                        if (etwLog.IsEnabled())
                        {
                            etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "EnlistVolatile");
                        }
                        return enlistment;
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this._internalTransaction)
                }
            }
            /*Enlistment */ EnlistVolatile$1(/*ISinglePhaseNotification*/ singlePhaseNotification, /*EnlistmentOptions*/ enlistmentOptions)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "EnlistVolatile");
                }
                $.$$.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                $.$$.System.ArgumentNullException.ThrowIfNull$2(singlePhaseNotification, "singlePhaseNotification");
                if (enlistmentOptions !== 0/*EnlistmentOptions.None*/ && enlistmentOptions !== 1/*EnlistmentOptions.EnlistDuringPrepareRequired*/)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("enlistmentOptions");
                }
                if (this._complete)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateTransactionCompletedException(this.DistributedTxId);
                }
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this._internalTransaction)
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        /*Enlistment*/ let enlistment = this._internalTransaction.State.EnlistVolatile$1(this._internalTransaction, singlePhaseNotification, enlistmentOptions, this);
                        if (etwLog.IsEnabled())
                        {
                            etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "EnlistVolatile");
                        }
                        return enlistment;
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this._internalTransaction)
                }
            }
            /*Transaction */ Clone()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "Clone");
                }
                $.$$.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                if (this._complete)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateTransactionCompletedException(this.DistributedTxId);
                }
                /*Transaction*/ let clone = this.InternalClone();
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "Clone");
                }
                return clone;
            }
            /*Transaction */ InternalClone()
            {
                /*Transaction*/ let clone = new $.$stl.System.Transactions.Transaction().$ctor$2(this._isoLevel, this._internalTransaction);
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionCloneCreate$1(clone, "Transaction");
                }
                return clone;
            }
            /*DependentTransaction */ DependentClone(/*DependentCloneOption*/ cloneOption)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "DependentClone");
                }
                if (cloneOption !== 0/*DependentCloneOption.BlockCommitUntilComplete*/ && cloneOption !== 1/*DependentCloneOption.RollbackIfNotComplete*/)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("cloneOption");
                }
                $.$$.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                if (this._complete)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateTransactionCompletedException(this.DistributedTxId);
                }
                /*DependentTransaction*/ let clone = new $.$stl.System.Transactions.DependentTransaction().$ctor$5(this._isoLevel, this._internalTransaction, cloneOption === 0/*DependentCloneOption.BlockCommitUntilComplete*/);
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionCloneCreate$1(clone, "DependentTransaction");
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "DependentClone");
                }
                return clone;
            }
            /*TransactionTraceIdentifier */ get TransactionTraceId()
            {
                if ($.$stl.System.Transactions.TransactionTraceIdentifier.op_Equality(this._traceIdentifier, $.$stl.System.Transactions.TransactionTraceIdentifier.Empty))
                {
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1(this._internalTransaction)
                        {
                            if ($.$stl.System.Transactions.TransactionTraceIdentifier.op_Equality(this._traceIdentifier, $.$stl.System.Transactions.TransactionTraceIdentifier.Empty))
                            {
                                /*TransactionTraceIdentifier*/ let temp = new $.$stl.System.Transactions.TransactionTraceIdentifier().$ctor$3(this._internalTransaction.TransactionTraceId.TransactionIdentifier, this._cloneId);
                                $.$$.System.Threading.Interlocked.MemoryBarrier();
                                this._traceIdentifier = temp;
                            }
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit(this._internalTransaction)
                    }
                }
                return this._traceIdentifier;
            }
            /*TransactionCompletedEventHandler?*/ add_TransactionCompleted(value)
            {
                $.$$.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this._internalTransaction)
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        this._internalTransaction.State.AddOutcomeRegistrant(this._internalTransaction, value);
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this._internalTransaction)
                }
            }
            /*TransactionCompletedEventHandler?*/ remove_TransactionCompleted(value)
            {
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this._internalTransaction)
                    {
                        this._internalTransaction._transactionCompletedDelegate = $.$cast($.$$.System.Delegate.Remove(this._internalTransaction._transactionCompletedDelegate, value), $.$stl.System.Transactions.TransactionCompletedEventHandler);
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this._internalTransaction)
                }
            }
            /*void */ Dispose()
            {
                this.InternalDispose();
            }
            /*void */ InternalDispose()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "InternalDispose");
                }
                if ($.$$.System.Threading.Interlocked.Exchange$3($.$ref(() => this._disposed, ($v) => this._disposed = $v, $.$$.System.Int32), 1/*Transaction._disposedTrueValue*/) === 1/*Transaction._disposedTrueValue*/)
                {
                    return;
                }
                /*long*/ let remainingITx = BigInt($.$$.System.Threading.Interlocked.Decrement($.$ref(() => this._internalTransaction._cloneCount, ($v) => this._internalTransaction._cloneCount = $v, $.$$.System.Int32)));
                if (remainingITx === 0n)
                {
                    this._internalTransaction.Dispose();
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "InternalDispose");
                }
            }
            /*void */ System$Runtime$Serialization$ISerializable$GetObjectData(/*SerializationInfo*/ serializationInfo, /*StreamingContext*/ context)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ EnlistPromotableSinglePhase$1(/*IPromotableSinglePhaseNotification*/ promotableSinglePhaseNotification)
            {
                return this.EnlistPromotableSinglePhase(promotableSinglePhaseNotification, $.$stl.System.Transactions.TransactionInterop.PromoterTypeDtc);
            }
            /*bool */ EnlistPromotableSinglePhase(/*IPromotableSinglePhaseNotification*/ promotableSinglePhaseNotification, /*Guid*/ promoterType)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "EnlistPromotableSinglePhase");
                }
                $.$$.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                $.$$.System.ArgumentNullException.ThrowIfNull$2(promotableSinglePhaseNotification, "promotableSinglePhaseNotification");
                if ($.$$.System.Guid.op_Equality(promoterType, $.$$.System.Guid.Empty))
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$stl.System.SR.PromoterTypeInvalid, "promoterType");
                }
                if (this._complete)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateTransactionCompletedException(this.DistributedTxId);
                }
                /*bool*/ let succeeded = false;
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this._internalTransaction)
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        succeeded = this._internalTransaction.State.EnlistPromotableSinglePhase(this._internalTransaction, promotableSinglePhaseNotification, this, promoterType);
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this._internalTransaction)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "EnlistPromotableSinglePhase");
                }
                return succeeded;
            }
            /*Enlistment */ PromoteAndEnlistDurable(/*Guid*/ resourceManagerIdentifier, /*IPromotableSinglePhaseNotification*/ promotableNotification, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(2/*TraceSourceType.TraceSourceOleTx*/, this, "PromoteAndEnlistDurable");
                }
                $.$$.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                if ($.$$.System.Guid.op_Equality(resourceManagerIdentifier, $.$$.System.Guid.Empty))
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$stl.System.SR.BadResourceManagerId, "resourceManagerIdentifier");
                }
                $.$$.System.ArgumentNullException.ThrowIfNull$2(promotableNotification, "promotableNotification");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(enlistmentNotification, "enlistmentNotification");
                if (enlistmentOptions !== 0/*EnlistmentOptions.None*/ && enlistmentOptions !== 1/*EnlistmentOptions.EnlistDuringPrepareRequired*/)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("enlistmentOptions");
                }
                if (this._complete)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateTransactionCompletedException(this.DistributedTxId);
                }
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this._internalTransaction)
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        /*Enlistment*/ let enlistment = this._internalTransaction.State.PromoteAndEnlistDurable(this._internalTransaction, resourceManagerIdentifier, promotableNotification, enlistmentNotification, enlistmentOptions, this);
                        if (etwLog.IsEnabled())
                        {
                            etwLog.MethodExit(2/*TraceSourceType.TraceSourceOleTx*/, this, "PromoteAndEnlistDurable");
                        }
                        return enlistment;
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this._internalTransaction)
                }
            }
            /*void */ SetDistributedTransactionIdentifier(/*IPromotableSinglePhaseNotification*/ promotableNotification, /*Guid*/ distributedTransactionIdentifier)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "SetDistributedTransactionIdentifier");
                }
                $.$$.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                $.$$.System.ArgumentNullException.ThrowIfNull$2(promotableNotification, "promotableNotification");
                if ($.$$.System.Guid.op_Equality(distributedTransactionIdentifier, $.$$.System.Guid.Empty))
                {
                    throw new $.$$.System.ArgumentException().$ctor$13(null, "distributedTransactionIdentifier");
                }
                if (this._complete)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateTransactionCompletedException(this.DistributedTxId);
                }
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this._internalTransaction)
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        this._internalTransaction.State.SetDistributedTransactionId(this._internalTransaction, promotableNotification, distributedTransactionIdentifier);
                        if (etwLog.IsEnabled())
                        {
                            etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "SetDistributedTransactionIdentifier");
                        }
                        return;
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this._internalTransaction)
                }
            }
            /*OletxTransaction? */ Promote()
            {
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this._internalTransaction)
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        this._internalTransaction.ThrowIfPromoterTypeIsNotMSDTC();
                        this._internalTransaction.State.Promote(this._internalTransaction);
                        return this._internalTransaction.PromotedTransaction;
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this._internalTransaction)
                }
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this._internalTransaction = null;
                this._traceIdentifier = $.$default($.$stl.System.Transactions.TransactionTraceIdentifier);
            }
            static $h = 4302092;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":4302092,"g":{"r":0,"d":0,"h":25774105868,"f":50331681},"s":{"r":0,"d":0,"h":30069073164,"f":83886113},"n":"Current","d":4302092,"h":21479138572,"f":2097185},{"p":262145,"g":{"r":0,"d":0,"h":60133844236,"f":50331656},"n":"Disposed","d":4302092,"h":55838876940,"f":2097160},{"p":56229889,"g":{"r":0,"d":0,"h":68723778828,"f":50331656},"n":"DistributedTxId","d":4302092,"h":64428811532,"f":2097160},{"p":4760844,"g":{"r":0,"d":0,"h":120263386380,"f":50331649},"n":"TransactionInformation","d":4302092,"h":115968419084,"f":2097153},{"p":3187980,"g":{"r":0,"d":0,"h":128853320972,"f":50331649},"n":"IsolationLevel","d":4302092,"h":124558353676,"f":2097153},{"p":56229889,"g":{"r":0,"d":0,"h":137443255564,"f":50331649},"n":"PromoterType","d":4302092,"h":133148288268,"f":2097153},{"p":8561932,"g":{"r":0,"d":0,"h":188982863116,"f":50331656},"n":"TransactionTraceId","d":4302092,"h":184687895820,"f":2097160}],"m":[{"r":262145,"n":"UseServiceDomainForCurrent","d":4302092,"h":4299269388,"f":16777256},{"r":2270476,"p":[{"n":"currentScope","p":5154060}],"n":"InteropMode","d":4302092,"h":8594236684,"f":16777256},{"r":4302092,"p":[{"n":"currentScope","p":5154060},{"n":"contextData","p":894220},{"n":"contextTransaction","p":4302092,"f":2}],"n":"FastGetTransaction","d":4302092,"h":12889203980,"f":16777256},{"r":65537,"p":[{"n":"defaultLookup","p":8627468},{"n":"current","p":4302092,"f":2},{"n":"currentScope","p":5154060,"f":2},{"n":"contextTransaction","p":4302092,"f":2}],"n":"GetCurrentTransactionAndScope","d":4302092,"h":17184171276,"f":16777256},{"r":655361,"n":"GetHashCode","d":4302092,"h":98788549900,"f":16809985},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","o":"@$1","d":4302092,"h":103083517196,"f":16809985},{"r":$.$typeArray($.$$.System.Byte).$h,"n":"GetPromotedToken","d":4302092,"h":141738222860,"f":16777217},{"r":1746188,"p":[{"n":"resourceManagerIdentifier","p":56229889},{"n":"enlistmentNotification","p":2598156},{"n":"enlistmentOptions","p":1877260}],"n":"EnlistDurable","d":4302092,"h":146033190156,"f":16777217},{"r":1746188,"p":[{"n":"resourceManagerIdentifier","p":56229889},{"n":"singlePhaseNotification","p":3056908},{"n":"enlistmentOptions","p":1877260}],"n":"EnlistDurable","o":"@$1","d":4302092,"h":150328157452,"f":16777217},{"r":65537,"n":"Rollback","d":4302092,"h":154623124748,"f":16777217},{"r":65537,"p":[{"n":"e","p":47251457}],"n":"Rollback","o":"@$1","d":4302092,"h":158918092044,"f":16777217},{"r":1746188,"p":[{"n":"enlistmentNotification","p":2598156},{"n":"enlistmentOptions","p":1877260}],"n":"EnlistVolatile","d":4302092,"h":163213059340,"f":16777217},{"r":1746188,"p":[{"n":"singlePhaseNotification","p":3056908},{"n":"enlistmentOptions","p":1877260}],"n":"EnlistVolatile","o":"@$1","d":4302092,"h":167508026636,"f":16777217},{"r":4302092,"n":"Clone","d":4302092,"h":171802993932,"f":16777217},{"r":4302092,"n":"InternalClone","d":4302092,"h":176097961228,"f":16777224},{"r":1156364,"p":[{"n":"cloneOption","p":1090828}],"n":"DependentClone","d":4302092,"h":180392928524,"f":16777217},{"r":65537,"n":"Dispose","d":4302092,"h":206162732300,"f":16777217},{"r":65537,"n":"InternalDispose","d":4302092,"h":210457699596,"f":16777352},{"r":262145,"p":[{"n":"promotableSinglePhaseNotification","p":2860300}],"n":"EnlistPromotableSinglePhase","o":"@$1","d":4302092,"h":219047634188,"f":16777217},{"r":262145,"p":[{"n":"promotableSinglePhaseNotification","p":2860300},{"n":"promoterType","p":56229889}],"n":"EnlistPromotableSinglePhase","d":4302092,"h":223342601484,"f":16777217},{"r":1746188,"p":[{"n":"resourceManagerIdentifier","p":56229889},{"n":"promotableNotification","p":2860300},{"n":"enlistmentNotification","p":3056908},{"n":"enlistmentOptions","p":1877260}],"n":"PromoteAndEnlistDurable","d":4302092,"h":227637568780,"f":16777217},{"r":65537,"p":[{"n":"promotableNotification","p":2860300},{"n":"distributedTransactionIdentifier","p":56229889}],"n":"SetDistributedTransactionIdentifier","d":4302092,"h":231932536076,"f":16777217},{"r":3515660,"n":"Promote","d":4302092,"h":236227503372,"f":16777224}],"l":[{"t":3187980,"n":"_isoLevel","d":4302092,"h":34364040460,"f":4194312},{"t":262145,"n":"_complete","d":4302092,"h":38659007756,"f":4194312},{"t":655361,"n":"_cloneId","d":4302092,"h":42953975052,"f":4194312},{"t":655361,"n":"_disposedTrueValue","d":4302092,"h":47248942348,"f":4194344},{"t":655361,"n":"_disposed","d":4302092,"h":51543909644,"f":4194312},{"t":2794764,"n":"_internalTransaction","d":4302092,"h":73018746124,"f":4194312},{"t":8561932,"n":"_traceIdentifier","d":4302092,"h":77313713420,"f":4194312}],"c":[{"n":".ctor","o":"$ctor$1","d":4302092,"h":81608680716,"f":16777218},{"p":[{"n":"isoLevel","p":3187980},{"n":"internalTransaction","p":2794764}],"n":".ctor","o":"$ctor$2","d":4302092,"h":85903648012,"f":16777224},{"p":[{"n":"distributedTransaction","p":3515660}],"n":".ctor","o":"$ctor$4","d":4302092,"h":90198615308,"f":16777224},{"p":[{"n":"isoLevel","p":3187980},{"n":"superior","p":2991372}],"n":".ctor","o":"$ctor$3","d":4302092,"h":94493582604,"f":16777224}],"e":[{"e":4433164,"m":{"r":65537,"p":[{"n":"value","p":4433164}],"n":"add_TransactionCompleted","d":4302092,"h":197572797708,"f":150994945},"r":{"r":65537,"p":[{"n":"value","p":4433164}],"n":"remove_TransactionCompleted","d":4302092,"h":201867765004,"f":285212673},"n":"TransactionCompleted","d":4302092,"h":193277830412,"f":8388609}],"i":[57540609,113246209],"h":4302092}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable, $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Transactions.Transaction`; }
        });
        
        $asm.$cls("$stl.System.Transactions.EnlistmentStatePromoted", ($self) => class EnlistmentStatePromoted extends $.$stl.System.Transactions.EnlistmentState
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                enlistment.State = this;
            }
            /*void */ EnlistmentDone(/*InternalEnlistment*/ enlistment)
            {
                $.$$.System.Threading.Monitor.Exit(enlistment.SyncRoot);
                try
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(enlistment.PromotedEnlistment !== null, "enlistment.PromotedEnlistment != null");
                    enlistment.PromotedEnlistment.System$Transactions$IPromotedEnlistment$EnlistmentDone();
                }
                finally
                {
                    {
                        $.$$.System.Threading.Monitor.Enter$1(enlistment.SyncRoot);
                    }
                }
            }
            /*void */ Prepared(/*InternalEnlistment*/ enlistment)
            {
                $.$$.System.Threading.Monitor.Exit(enlistment.SyncRoot);
                try
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(enlistment.PromotedEnlistment !== null, "enlistment.PromotedEnlistment != null");
                    enlistment.PromotedEnlistment.System$Transactions$IPromotedEnlistment$Prepared();
                }
                finally
                {
                    {
                        $.$$.System.Threading.Monitor.Enter$1(enlistment.SyncRoot);
                    }
                }
            }
            /*void */ ForceRollback(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
                $.$$.System.Threading.Monitor.Exit(enlistment.SyncRoot);
                try
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(enlistment.PromotedEnlistment !== null, "enlistment.PromotedEnlistment != null");
                    enlistment.PromotedEnlistment.System$Transactions$IPromotedEnlistment$ForceRollback$1(e);
                }
                finally
                {
                    {
                        $.$$.System.Threading.Monitor.Enter$1(enlistment.SyncRoot);
                    }
                }
            }
            /*void */ Committed(/*InternalEnlistment*/ enlistment)
            {
                $.$$.System.Threading.Monitor.Exit(enlistment.SyncRoot);
                try
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(enlistment.PromotedEnlistment !== null, "enlistment.PromotedEnlistment != null");
                    enlistment.PromotedEnlistment.System$Transactions$IPromotedEnlistment$Committed();
                }
                finally
                {
                    {
                        $.$$.System.Threading.Monitor.Enter$1(enlistment.SyncRoot);
                    }
                }
            }
            /*void */ Aborted(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
                $.$$.System.Threading.Monitor.Exit(enlistment.SyncRoot);
                try
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(enlistment.PromotedEnlistment !== null, "enlistment.PromotedEnlistment != null");
                    enlistment.PromotedEnlistment.System$Transactions$IPromotedEnlistment$Aborted$1(e);
                }
                finally
                {
                    {
                        $.$$.System.Threading.Monitor.Enter$1(enlistment.SyncRoot);
                    }
                }
            }
            /*void */ InDoubt(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
                $.$$.System.Threading.Monitor.Exit(enlistment.SyncRoot);
                try
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(enlistment.PromotedEnlistment !== null, "enlistment.PromotedEnlistment != null");
                    enlistment.PromotedEnlistment.System$Transactions$IPromotedEnlistment$InDoubt$1(e);
                }
                finally
                {
                    {
                        $.$$.System.Threading.Monitor.Enter$1(enlistment.SyncRoot);
                    }
                }
            }
            /*byte[] */ RecoveryInformation(/*InternalEnlistment*/ enlistment)
            {
                $.$$.System.Threading.Monitor.Exit(enlistment.SyncRoot);
                try
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(enlistment.PromotedEnlistment !== null, "enlistment.PromotedEnlistment != null");
                    return enlistment.PromotedEnlistment.System$Transactions$IPromotedEnlistment$GetRecoveryInformation();
                }
                finally
                {
                    {
                        $.$$.System.Threading.Monitor.Enter$1(enlistment.SyncRoot);
                    }
                }
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 2008332;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1942796,"m":[{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"EnterState","d":2008332,"h":4296975628,"f":16809992},{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"EnlistmentDone","d":2008332,"h":8591942924,"f":16809992},{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"Prepared","d":2008332,"h":12886910220,"f":16809992},{"r":65537,"p":[{"n":"enlistment","p":2729228},{"n":"e","p":47251457}],"n":"ForceRollback","d":2008332,"h":17181877516,"f":16809992},{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"Committed","d":2008332,"h":21476844812,"f":16809992},{"r":65537,"p":[{"n":"enlistment","p":2729228},{"n":"e","p":47251457}],"n":"Aborted","d":2008332,"h":25771812108,"f":16809992},{"r":65537,"p":[{"n":"enlistment","p":2729228},{"n":"e","p":47251457}],"n":"InDoubt","d":2008332,"h":30066779404,"f":16809992},{"r":$.$typeArray($.$$.System.Byte).$h,"p":[{"n":"enlistment","p":2729228}],"n":"RecoveryInformation","d":2008332,"h":34361746700,"f":16809992}],"c":[{"n":".ctor","o":"$ctor$2","d":2008332,"h":38656713996,"f":16777217}],"h":2008332}; }
            static get $b() { return $.$stl.System.Transactions.EnlistmentState; }
            static get $fullName() { return `System.Transactions.EnlistmentStatePromoted`; }
        });
        
        $asm.$str("$stl.System.Transactions.VolatileEnlistmentSet", ($self) => class VolatileEnlistmentSet extends $.$$.System.ValueType
        {
            /*InternalEnlistment[]*/  get _volatileEnlistments() { return this.$getField(0, 4); }
            /*InternalEnlistment[]*/  set _volatileEnlistments(value) { this.$setField(0, 4, value); }
            /*int*/  get _volatileEnlistmentCount() { return this.$getField(4, 4); }
            /*int*/  set _volatileEnlistmentCount(value) { this.$setField(4, 4, value); }
            /*int*/  get _volatileEnlistmentSize() { return this.$getField(8, 4); }
            /*int*/  set _volatileEnlistmentSize(value) { this.$setField(8, 4, value); }
            /*int*/  get _dependentClones() { return this.$getField(12, 4); }
            /*int*/  set _dependentClones(value) { this.$setField(12, 4, value); }
            /*int*/  get _preparedVolatileEnlistments() { return this.$getField(16, 4); }
            /*int*/  set _preparedVolatileEnlistments(value) { this.$setField(16, 4, value); }
            /*VolatileDemultiplexer*/  get _volatileDemux() { return this.$getField(20, 4); }
            /*VolatileDemultiplexer*/  set _volatileDemux(value) { this.$setField(20, 4, value); }
            /*VolatileDemultiplexer */ get VolatileDemux()
            {
                return this._volatileDemux;
            }
            /*VolatileDemultiplexer */ set VolatileDemux(value)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(this._volatileDemux === null, "volatileDemux can only be set once.");
                this._volatileDemux = value;
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._volatileEnlistments = this._volatileEnlistments;
                copy._volatileEnlistmentCount = this._volatileEnlistmentCount;
                copy._volatileEnlistmentSize = this._volatileEnlistmentSize;
                copy._dependentClones = this._dependentClones;
                copy._preparedVolatileEnlistments = this._preparedVolatileEnlistments;
                copy._volatileDemux = this._volatileDemux;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._volatileEnlistments = null;
                this._volatileEnlistmentCount = 0;
                this._volatileEnlistmentSize = 0;
                this._dependentClones = 0;
                this._preparedVolatileEnlistments = 0;
                this._volatileDemux = null;
            }
            static $h = 9348364;
            static $z = 24;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":8693004,"g":{"r":0,"d":0,"h":34369086732,"f":50331656},"s":{"r":0,"d":0,"h":38664054028,"f":83886088},"n":"VolatileDemux","d":9348364,"h":30074119436,"f":2097160}],"l":[{"t":$.$typeArray($.$stl.System.Transactions.InternalEnlistment).$h,"n":"_volatileEnlistments","d":9348364,"h":4304315660,"f":4194312},{"t":655361,"n":"_volatileEnlistmentCount","d":9348364,"h":8599282956,"f":4194312},{"t":655361,"n":"_volatileEnlistmentSize","d":9348364,"h":12894250252,"f":4194312},{"t":655361,"n":"_dependentClones","d":9348364,"h":17189217548,"f":4194312},{"t":655361,"n":"_preparedVolatileEnlistments","d":9348364,"h":21484184844,"f":4194312},{"t":8693004,"n":"_volatileDemux","d":9348364,"h":25779152140,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$2","d":9348364,"h":42959021324,"f":16777217}],"h":9348364}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.Transactions.VolatileEnlistmentSet`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePSPEOperation", ($self) => class TransactionStatePSPEOperation extends $.$stl.System.Transactions.TransactionState
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                throw new $.$$.System.InvalidOperationException().$ctor$9();
            }
            /*TransactionStatus */ get_Status(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException(tx._innerException, tx.DistributedTxId);
            }
            /*void */ PSPEInitialize(/*InternalTransaction*/ tx, /*IPromotableSinglePhaseNotification*/ promotableSinglePhaseNotification, /*Guid*/ promoterType)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(tx.State === $.$stl.System.Transactions.TransactionState.TransactionStateActive, "PSPEPromote called from state other than TransactionStateActive");
                this.CommonEnterState(tx);
                try
                {
                    promotableSinglePhaseNotification.System$Transactions$IPromotableSinglePhaseNotification$Initialize();
                    tx._promoterType = promoterType;
                }
                finally
                {
                    {
                        $.$stl.System.Transactions.TransactionState.TransactionStateActive.CommonEnterState(tx);
                    }
                }
            }
            /*void */ Phase0PSPEInitialize(/*InternalTransaction*/ tx, /*IPromotableSinglePhaseNotification*/ promotableSinglePhaseNotification, /*Guid*/ promoterType)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(tx.State === $.$stl.System.Transactions.TransactionState.TransactionStatePhase0, "Phase0PSPEInitialize called from state other than TransactionStatePhase0");
                this.CommonEnterState(tx);
                try
                {
                    promotableSinglePhaseNotification.System$Transactions$IPromotableSinglePhaseNotification$Initialize();
                    tx._promoterType = promoterType;
                }
                finally
                {
                    {
                        $.$stl.System.Transactions.TransactionState.TransactionStatePhase0.CommonEnterState(tx);
                    }
                }
            }
            /*Oletx.OletxTransaction? */ PSPEPromote(/*InternalTransaction*/ tx)
            {
                /*bool*/ let changeToReturnState = true;
                /*TransactionState?*/ let returnState = tx.State;
                $.$$.System.Diagnostics.Debug.Assert$2(returnState === $.$stl.System.Transactions.TransactionState.TransactionStateDelegated || returnState === $.$stl.System.Transactions.TransactionState.TransactionStateDelegatedSubordinate || returnState === $.$stl.System.Transactions.TransactionState.TransactionStateDelegatedNonMSDTC, "PSPEPromote called from state other than TransactionStateDelegated[NonMSDTC]");
                this.CommonEnterState(tx);
                /*Oletx.OletxTransaction?*/ let distributedTx = null;
                try
                {
                    if (tx._attemptingPSPEPromote)
                    {
                        throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.PromotedReturnedInvalidValue, null, tx.DistributedTxId);
                    }
                    tx._attemptingPSPEPromote = true;
                    $.$$.System.Diagnostics.Debug.Assert$2(tx._promoter !== null, "tx._promoter != null");
                    /*byte[]?*/ let propagationToken = tx._promoter.System$Transactions$ITransactionPromoter$Promote();
                    if ($.$$.System.Guid.op_Inequality(tx._promoterType, $.$stl.System.Transactions.TransactionInterop.PromoterTypeDtc))
                    {
                        if (propagationToken === null)
                        {
                            throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.PromotedReturnedInvalidValue, null, tx.DistributedTxId);
                        }
                        tx.promotedToken = propagationToken;
                        return null;
                    }
                    if (propagationToken === null)
                    {
                        if (tx.PromotedTransaction === null)
                        {
                            throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.PromotedReturnedInvalidValue, null, tx.DistributedTxId);
                        }
                        changeToReturnState = false;
                        distributedTx = tx.PromotedTransaction;
                    }
                    if (distributedTx === null)
                    {
                        try
                        {
                            distributedTx = $.$stl.System.Transactions.TransactionInterop.GetOletxTransactionFromTransmitterPropagationToken(propagationToken);
                        }
                        catch(e)
                        {
                            throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.PromotedReturnedInvalidValue, e, tx.DistributedTxId);
                        }
                        if ($.$stl.System.Transactions.Transaction.op_Inequality($.$stl.System.Transactions.TransactionManager.FindPromotedTransaction(distributedTx.Identifier), null))
                        {
                            throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.PromotedTransactionExists, null, tx.DistributedTxId);
                        }
                    }
                }
                finally
                {
                    {
                        tx._attemptingPSPEPromote = false;
                        if (changeToReturnState)
                        {
                            returnState.CommonEnterState(tx);
                        }
                    }
                }
                return distributedTx;
            }
            /*Enlistment */ PromoteAndEnlistDurable(/*InternalTransaction*/ tx, /*Guid*/ resourceManagerIdentifier, /*IPromotableSinglePhaseNotification*/ promotableNotification, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                if (!tx._attemptingPSPEPromote)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException(tx._innerException, tx.DistributedTxId);
                }
                if (promotableNotification !== tx._promoter)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.InvalidIPromotableSinglePhaseNotificationSpecified, null, tx.DistributedTxId);
                }
                /*Enlistment*/ let enlistment;
                tx._durableEnlistment = null;
                tx._promoteState = $.$stl.System.Transactions.TransactionState.TransactionStatePromoted;
                tx._promoteState.EnterState(tx);
                enlistment = tx.State.EnlistDurable$1(tx, resourceManagerIdentifier, enlistmentNotification, enlistmentOptions, atomicTransaction);
                tx._durableEnlistment = enlistment.InternalEnlistment;
                return enlistment;
            }
            /*void */ SetDistributedTransactionId(/*InternalTransaction*/ tx, /*IPromotableSinglePhaseNotification*/ promotableNotification, /*Guid*/ distributedTransactionIdentifier)
            {
                if (!tx._attemptingPSPEPromote)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException(tx._innerException, tx.DistributedTxId);
                }
                if (promotableNotification !== tx._promoter)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.InvalidIPromotableSinglePhaseNotificationSpecified, null, tx.DistributedTxId);
                }
                tx._distributedTransactionIdentifierNonMSDTC = distributedTransactionIdentifier;
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 8103180;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":5743884,"m":[{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"EnterState","d":8103180,"h":4303070476,"f":16809992},{"r":8430860,"p":[{"n":"tx","p":2794764}],"n":"get_Status","d":8103180,"h":8598037772,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"promotableSinglePhaseNotification","p":2860300},{"n":"promoterType","p":56229889}],"n":"PSPEInitialize","d":8103180,"h":12893005068,"f":16777224},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"promotableSinglePhaseNotification","p":2860300},{"n":"promoterType","p":56229889}],"n":"Phase0PSPEInitialize","d":8103180,"h":17187972364,"f":16777224},{"r":3515660,"p":[{"n":"tx","p":2794764}],"n":"PSPEPromote","d":8103180,"h":21482939660,"f":16777224},{"r":1746188,"p":[{"n":"tx","p":2794764},{"n":"resourceManagerIdentifier","p":56229889},{"n":"promotableNotification","p":2860300},{"n":"enlistmentNotification","p":3056908},{"n":"enlistmentOptions","p":1877260},{"n":"atomicTransaction","p":4302092}],"n":"PromoteAndEnlistDurable","d":8103180,"h":25777906956,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"promotableNotification","p":2860300},{"n":"distributedTransactionIdentifier","p":56229889}],"n":"SetDistributedTransactionId","d":8103180,"h":30072874252,"f":16809992}],"c":[{"n":".ctor","o":"$ctor$2","d":8103180,"h":34367841548,"f":16777217}],"h":8103180}; }
            static get $b() { return $.$stl.System.Transactions.TransactionState; }
            static get $fullName() { return `System.Transactions.TransactionStatePSPEOperation`; }
        });
        
        $asm.$str("$stl.System.Transactions.EnlistmentTraceIdentifier", ($self) => class EnlistmentTraceIdentifier extends $.$$.System.ValueType
        {
            static /*EnlistmentTraceIdentifier */ get Empty()
            {
                return new $.$stl.System.Transactions.EnlistmentTraceIdentifier();
            }
            $ctor$3(/*Guid*/ resourceManagerIdentifier, /*TransactionTraceIdentifier*/ transactionTraceId, /*int*/ enlistmentIdentifier)
            {
                super.$ctor$1();
                {
                    this._resourceManagerIdentifier = resourceManagerIdentifier;
                    this._transactionTraceIdentifier = transactionTraceId;
                    this._enlistmentIdentifier = enlistmentIdentifier;
                }
                return this;
            }
            /*Guid*/  get _resourceManagerIdentifier() { return this.$getField(0, 16); }
            /*Guid*/  set _resourceManagerIdentifier(value) { this.$setField(0, 16, value); }
            /*Guid */ get ResourceManagerIdentifier()
            {
                return this._resourceManagerIdentifier;
            }
            /*TransactionTraceIdentifier*/  get _transactionTraceIdentifier() { return this.$getField(16, 8); }
            /*TransactionTraceIdentifier*/  set _transactionTraceIdentifier(value) { this.$setField(16, 8, value); }
            /*TransactionTraceIdentifier */ get TransactionTraceId()
            {
                return this._transactionTraceIdentifier;
            }
            /*int*/  get _enlistmentIdentifier() { return this.$getField(24, 4); }
            /*int*/  set _enlistmentIdentifier(value) { this.$setField(24, 4, value); }
            /*int */ get EnlistmentIdentifier()
            {
                return this._enlistmentIdentifier;
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$$.System.ValueType.GetHashCode.call(this);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$stl.System.Transactions.EnlistmentTraceIdentifier.GetHashCode.apply(this, arguments); }
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                let enlistmentTraceId;
                return $.$is(obj, $.$stl.System.Transactions.EnlistmentTraceIdentifier, { set $v(v){ enlistmentTraceId = v; } }) && this.Equals$2(enlistmentTraceId);
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$stl.System.Transactions.EnlistmentTraceIdentifier.Equals$1.apply(this, arguments); }
            /*bool */ Equals$2(/*EnlistmentTraceIdentifier*/ other)
            {
                return this._enlistmentIdentifier === other._enlistmentIdentifier && $.$$.System.Guid.op_Equality(this._resourceManagerIdentifier, other._resourceManagerIdentifier) && $.$stl.System.Transactions.TransactionTraceIdentifier.op_Equality(this._transactionTraceIdentifier, other._transactionTraceIdentifier);
            }
            static /*bool */ op_Equality(/*EnlistmentTraceIdentifier*/ left, /*EnlistmentTraceIdentifier*/ right)
            {
                return left.Equals$2(right);
            }
            static /*bool */ op_Inequality(/*EnlistmentTraceIdentifier*/ left, /*EnlistmentTraceIdentifier*/ right)
            {
                return !left.Equals$2(right);
            }
            //Generated interface implemetation for System.IEquatable<System.Transactions.EnlistmentTraceIdentifier>.Equals(System.Transactions.EnlistmentTraceIdentifier)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._resourceManagerIdentifier = this._resourceManagerIdentifier.Clone();
                copy._transactionTraceIdentifier = this._transactionTraceIdentifier.Clone();
                copy._enlistmentIdentifier = this._enlistmentIdentifier;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._resourceManagerIdentifier = $.$default($.$$.System.Guid);
                this._transactionTraceIdentifier = $.$default($.$stl.System.Transactions.TransactionTraceIdentifier);
                this._enlistmentIdentifier = 0;
            }
            static $h = 2073868;
            static $z = 28;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":2073868,"g":{"r":0,"d":0,"h":8592008460,"f":50331681},"n":"Empty","d":2073868,"h":4297041164,"f":2097185},{"p":56229889,"g":{"r":0,"d":0,"h":25771877644,"f":50331649},"n":"ResourceManagerIdentifier","d":2073868,"h":21476910348,"f":2097153},{"p":8561932,"g":{"r":0,"d":0,"h":38656779532,"f":50331649},"n":"TransactionTraceId","d":2073868,"h":34361812236,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":51541681420,"f":50331649},"n":"EnlistmentIdentifier","d":2073868,"h":47246714124,"f":2097153}],"m":[{"r":655361,"n":"GetHashCode","d":2073868,"h":55836648716,"f":16809985},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","o":"@$1","d":2073868,"h":60131616012,"f":16809985},{"r":262145,"p":[{"n":"other","p":2073868}],"n":"Equals","o":"@$2","d":2073868,"h":64426583308,"f":16777217}],"l":[{"t":56229889,"n":"_resourceManagerIdentifier","d":2073868,"h":17181943052,"f":4194306},{"t":8561932,"n":"_transactionTraceIdentifier","d":2073868,"h":30066844940,"f":4194306},{"t":655361,"n":"_enlistmentIdentifier","d":2073868,"h":42951746828,"f":4194306}],"c":[{"p":[{"n":"resourceManagerIdentifier","p":56229889},{"n":"transactionTraceId","p":8561932},{"n":"enlistmentIdentifier","p":655361}],"n":".ctor","o":"$ctor$3","d":2073868,"h":12886975756,"f":16777217},{"n":".ctor","o":"$ctor$2","d":2073868,"h":77311485196,"f":16777217}],"i":[$.$$.System.IEquatable$$($.$stl.System.Transactions.EnlistmentTraceIdentifier).$h],"h":2073868}; }
            static get $b() { return $.$$.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IEquatable$$($.$stl.System.Transactions.EnlistmentTraceIdentifier) ]; }
            static get $fullName() { return `System.Transactions.EnlistmentTraceIdentifier`; }
        });
        
        $asm.$str("$stl.System.Transactions.TransactionOptions", ($self) => class TransactionOptions extends $.$$.System.ValueType
        {
            /*TimeSpan*/  get _timeout() { return this.$getField(0, $.$$.System.TimeSpan); }
            /*TimeSpan*/  set _timeout(value) { this.$setField(0, $.$$.System.TimeSpan, value); }
            /*IsolationLevel*/  get _isolationLevel() { return this.$getField(8, $.$stl.System.Transactions.IsolationLevel); }
            /*IsolationLevel*/  set _isolationLevel(value) { this.$setField(8, $.$stl.System.Transactions.IsolationLevel, value); }
            /*TimeSpan */ get Timeout()
            {
                return this._timeout;
            }
            /*TimeSpan */ set Timeout(value)
            {
                this._timeout = value;
            }
            /*IsolationLevel */ get IsolationLevel()
            {
                return this._isolationLevel;
            }
            /*IsolationLevel */ set IsolationLevel(value)
            {
                this._isolationLevel = value;
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$$.System.ValueType.GetHashCode.call(this);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$stl.System.Transactions.TransactionOptions.GetHashCode.apply(this, arguments); }
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                let transactionOptions;
                return $.$is(obj, $.$stl.System.Transactions.TransactionOptions, { set $v(v){ transactionOptions = v; } }) && this.Equals$2(transactionOptions.Clone());
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$stl.System.Transactions.TransactionOptions.Equals$1.apply(this, arguments); }
            /*bool */ Equals$2(/*TransactionOptions*/ other)
            {
                return $.$$.System.TimeSpan.op_Equality(this._timeout, other._timeout) && this._isolationLevel === other._isolationLevel;
            }
            static /*bool */ op_Equality(/*TransactionOptions*/ x, /*TransactionOptions*/ y)
            {
                return x.Equals$2(y.Clone());
            }
            static /*bool */ op_Inequality(/*TransactionOptions*/ x, /*TransactionOptions*/ y)
            {
                return !x.Equals$2(y.Clone());
            }
            //Generated interface implemetation for System.IEquatable<System.Transactions.TransactionOptions>.Equals(System.Transactions.TransactionOptions)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._timeout = this._timeout.Clone();
                copy._isolationLevel = this._isolationLevel;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._timeout = $.$default($.$$.System.TimeSpan);
                this._isolationLevel = 0;
            }
            static $h = 5022988;
            static $z = 12;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":140574721,"g":{"r":0,"d":0,"h":17184892172,"f":50331649},"s":{"r":0,"d":0,"h":21479859468,"f":83886081},"n":"Timeout","d":5022988,"h":12889924876,"f":2097153},{"p":3187980,"g":{"r":0,"d":0,"h":30069794060,"f":50331649},"s":{"r":0,"d":0,"h":34364761356,"f":83886081},"n":"IsolationLevel","d":5022988,"h":25774826764,"f":2097153}],"m":[{"r":655361,"n":"GetHashCode","d":5022988,"h":38659728652,"f":16809985},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","o":"@$1","d":5022988,"h":42954695948,"f":16809985},{"r":262145,"p":[{"n":"other","p":5022988}],"n":"Equals","o":"@$2","d":5022988,"h":47249663244,"f":16777217}],"l":[{"t":140574721,"n":"_timeout","d":5022988,"h":4299990284,"f":4194306},{"t":3187980,"n":"_isolationLevel","d":5022988,"h":8594957580,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$2","d":5022988,"h":60134565132,"f":16777217}],"i":[$.$$.System.IEquatable$$($.$stl.System.Transactions.TransactionOptions).$h],"h":5022988}; }
            static get $b() { return $.$$.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IEquatable$$($.$stl.System.Transactions.TransactionOptions) ]; }
            static get $fullName() { return `System.Transactions.TransactionOptions`; }
        });
        
        $asm.$str("$stl.System.Transactions.TransactionTraceIdentifier", ($self) => class TransactionTraceIdentifier extends $.$$.System.ValueType
        {
            static /*TransactionTraceIdentifier */ get Empty()
            {
                return new $.$stl.System.Transactions.TransactionTraceIdentifier();
            }
            $ctor$3(/*string*/ transactionIdentifier, /*int*/ cloneIdentifier)
            {
                super.$ctor$1();
                {
                    this._transactionIdentifier = transactionIdentifier;
                    this._cloneIdentifier = cloneIdentifier;
                }
                return this;
            }
            /*string*/  get _transactionIdentifier() { return this.$getField(0, 4); }
            /*string*/  set _transactionIdentifier(value) { this.$setField(0, 4, value); }
            /*string */ get TransactionIdentifier()
            {
                return this._transactionIdentifier;
            }
            /*int*/  get _cloneIdentifier() { return this.$getField(4, 4); }
            /*int*/  set _cloneIdentifier(value) { this.$setField(4, 4, value); }
            /*int */ get CloneIdentifier()
            {
                return this._cloneIdentifier;
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$$.System.ValueType.GetHashCode.call(this);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$stl.System.Transactions.TransactionTraceIdentifier.GetHashCode.apply(this, arguments); }
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                let transactionTraceId;
                return $.$is(obj, $.$stl.System.Transactions.TransactionTraceIdentifier, { set $v(v){ transactionTraceId = v; } }) && this.Equals$2(transactionTraceId);
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$stl.System.Transactions.TransactionTraceIdentifier.Equals$1.apply(this, arguments); }
            /*bool */ Equals$2(/*TransactionTraceIdentifier*/ other)
            {
                return this._cloneIdentifier === other._cloneIdentifier && $.$$.System.String.op_Equality(this._transactionIdentifier, other._transactionIdentifier);
            }
            static /*bool */ op_Equality(/*TransactionTraceIdentifier*/ left, /*TransactionTraceIdentifier*/ right)
            {
                return left.Equals$2(right);
            }
            static /*bool */ op_Inequality(/*TransactionTraceIdentifier*/ left, /*TransactionTraceIdentifier*/ right)
            {
                return !left.Equals$2(right);
            }
            //Generated interface implemetation for System.IEquatable<System.Transactions.TransactionTraceIdentifier>.Equals(System.Transactions.TransactionTraceIdentifier)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._transactionIdentifier = this._transactionIdentifier;
                copy._cloneIdentifier = this._cloneIdentifier;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._transactionIdentifier = null;
                this._cloneIdentifier = 0;
            }
            static $h = 8561932;
            static $z = 8;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":8561932,"g":{"r":0,"d":0,"h":8598496524,"f":50331681},"n":"Empty","d":8561932,"h":4303529228,"f":2097185},{"p":1310721,"g":{"r":0,"d":0,"h":25778365708,"f":50331649},"n":"TransactionIdentifier","d":8561932,"h":21483398412,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":38663267596,"f":50331649},"n":"CloneIdentifier","d":8561932,"h":34368300300,"f":2097153}],"m":[{"r":655361,"n":"GetHashCode","d":8561932,"h":42958234892,"f":16809985},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","o":"@$1","d":8561932,"h":47253202188,"f":16809985},{"r":262145,"p":[{"n":"other","p":8561932}],"n":"Equals","o":"@$2","d":8561932,"h":51548169484,"f":16777217}],"l":[{"t":1310721,"n":"_transactionIdentifier","d":8561932,"h":17188431116,"f":4194306},{"t":655361,"n":"_cloneIdentifier","d":8561932,"h":30073333004,"f":4194306}],"c":[{"p":[{"n":"transactionIdentifier","p":1310721},{"n":"cloneIdentifier","p":655361}],"n":".ctor","o":"$ctor$3","d":8561932,"h":12893463820,"f":16777217},{"n":".ctor","o":"$ctor$2","d":8561932,"h":64433071372,"f":16777217}],"i":[$.$$.System.IEquatable$$($.$stl.System.Transactions.TransactionTraceIdentifier).$h],"h":8561932}; }
            static get $b() { return $.$$.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IEquatable$$($.$stl.System.Transactions.TransactionTraceIdentifier) ]; }
            static get $fullName() { return `System.Transactions.TransactionTraceIdentifier`; }
        });
        
        $asm.$cls("$stl.System.Transactions.Phase0VolatileDemultiplexer", ($self) => class Phase0VolatileDemultiplexer extends $.$stl.System.Transactions.VolatileDemultiplexer
        {
            $ctor$2(/*InternalTransaction*/ transaction)
            {
                super.$ctor$1(transaction);
                {
                }
                return this;
            }
            /*void */ InternalPrepare()
            {
                $.$$.System.Diagnostics.Debug.Assert$2(this._promotedEnlistment !== null && this._transaction.State !== null, "_promotedEnlistment != null && _transaction.State != null");
                try
                {
                    this._transaction.State.ChangeStatePromotedPhase0(this._transaction);
                }
                catch($e)
                {
                    if ($e instanceof $.$stl.System.Transactions.TransactionAbortedException)
                    {
                        let e = $e;
                        this._promotedEnlistment.System$Transactions$IPromotedEnlistment$ForceRollback$1(e);
                        /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                        if (etwLog.IsEnabled())
                        {
                            etwLog.ExceptionConsumed(e);
                        }
                    }
                    else if ($e instanceof $.$stl.System.Transactions.TransactionInDoubtException)
                    {
                        let e = $e;
                        this._promotedEnlistment.System$Transactions$IPromotedEnlistment$EnlistmentDone();
                        /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                        if (etwLog.IsEnabled())
                        {
                            etwLog.ExceptionConsumed(e);
                        }
                    }
                    else
                    {
                        throw $e;
                    }
                }
            }
            /*void */ InternalCommit()
            {
                $.$$.System.Diagnostics.Debug.Assert$2(this._promotedEnlistment !== null && this._transaction.State !== null, "_promotedEnlistment != null && _transaction.State != null");
                this._promotedEnlistment.System$Transactions$IPromotedEnlistment$EnlistmentDone();
                this._transaction.State.ChangeStatePromotedCommitted(this._transaction);
            }
            /*void */ InternalRollback()
            {
                $.$$.System.Diagnostics.Debug.Assert$2(this._promotedEnlistment !== null && this._transaction.State !== null, "_promotedEnlistment != null && _transaction.State != null");
                this._promotedEnlistment.System$Transactions$IPromotedEnlistment$EnlistmentDone();
                this._transaction.State.ChangeStatePromotedAborted(this._transaction);
            }
            /*void */ InternalInDoubt()
            {
                $.$$.System.Diagnostics.Debug.Assert$2(this._transaction.State !== null, "_transaction.State != null");
                this._transaction.State.InDoubtFromDtc(this._transaction);
            }
            /*void */ Prepare(/*IPromotedEnlistment*/ en)
            {
                this._preparingEnlistment = en;
                $.$stl.System.Transactions.VolatileDemultiplexer.PoolablePrepare(this);
            }
            /*void */ Commit(/*IPromotedEnlistment*/ en)
            {
                this._promotedEnlistment = en;
                $.$stl.System.Transactions.VolatileDemultiplexer.PoolableCommit(this);
            }
            /*void */ Rollback(/*IPromotedEnlistment*/ en)
            {
                this._promotedEnlistment = en;
                $.$stl.System.Transactions.VolatileDemultiplexer.PoolableRollback(this);
            }
            /*void */ InDoubt(/*IPromotedEnlistment*/ en)
            {
                this._promotedEnlistment = en;
                $.$stl.System.Transactions.VolatileDemultiplexer.PoolableInDoubt(this);
            }
            static $h = 3712268;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":8693004,"m":[{"r":65537,"n":"InternalPrepare","d":3712268,"h":8593646860,"f":16809988},{"r":65537,"n":"InternalCommit","d":3712268,"h":12888614156,"f":16809988},{"r":65537,"n":"InternalRollback","d":3712268,"h":17183581452,"f":16809988},{"r":65537,"n":"InternalInDoubt","d":3712268,"h":21478548748,"f":16809988},{"r":65537,"p":[{"n":"en","p":2925836}],"n":"Prepare","d":3712268,"h":25773516044,"f":16809985},{"r":65537,"p":[{"n":"en","p":2925836}],"n":"Commit","d":3712268,"h":30068483340,"f":16809985},{"r":65537,"p":[{"n":"en","p":2925836}],"n":"Rollback","d":3712268,"h":34363450636,"f":16809985},{"r":65537,"p":[{"n":"en","p":2925836}],"n":"InDoubt","d":3712268,"h":38658417932,"f":16809985}],"c":[{"p":[{"n":"transaction","p":2794764}],"n":".ctor","o":"$ctor$2","d":3712268,"h":4298679564,"f":16777217}],"i":[2663692],"h":3712268}; }
            static get $b() { return $.$stl.System.Transactions.VolatileDemultiplexer; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stl.System.Transactions.IEnlistmentNotificationInternal ]; }
            static get $fullName() { return `System.Transactions.Phase0VolatileDemultiplexer`; }
        });
        
        $asm.$cls("$stl.System.Transactions.Phase1VolatileDemultiplexer", ($self) => class Phase1VolatileDemultiplexer extends $.$stl.System.Transactions.VolatileDemultiplexer
        {
            $ctor$2(/*InternalTransaction*/ transaction)
            {
                super.$ctor$1(transaction);
                {
                }
                return this;
            }
            /*void */ InternalPrepare()
            {
                $.$$.System.Diagnostics.Debug.Assert$2(this._promotedEnlistment !== null && this._transaction.State !== null, "_promotedEnlistment != null && _transaction.State != null");
                try
                {
                    this._transaction.State.ChangeStatePromotedPhase1(this._transaction);
                }
                catch($e)
                {
                    if ($e instanceof $.$stl.System.Transactions.TransactionAbortedException)
                    {
                        let e = $e;
                        this._promotedEnlistment.System$Transactions$IPromotedEnlistment$ForceRollback$1(e);
                        /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                        if (etwLog.IsEnabled())
                        {
                            etwLog.ExceptionConsumed(e);
                        }
                    }
                    else if ($e instanceof $.$stl.System.Transactions.TransactionInDoubtException)
                    {
                        let e = $e;
                        this._promotedEnlistment.System$Transactions$IPromotedEnlistment$EnlistmentDone();
                        /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                        if (etwLog.IsEnabled())
                        {
                            etwLog.ExceptionConsumed(e);
                        }
                    }
                    else
                    {
                        throw $e;
                    }
                }
            }
            /*void */ InternalCommit()
            {
                $.$$.System.Diagnostics.Debug.Assert$2(this._promotedEnlistment !== null && this._transaction.State !== null, "_promotedEnlistment != null && _transaction.State != null");
                this._promotedEnlistment.System$Transactions$IPromotedEnlistment$EnlistmentDone();
                this._transaction.State.ChangeStatePromotedCommitted(this._transaction);
            }
            /*void */ InternalRollback()
            {
                $.$$.System.Diagnostics.Debug.Assert$2(this._promotedEnlistment !== null && this._transaction.State !== null, "_promotedEnlistment != null && _transaction.State != null");
                this._promotedEnlistment.System$Transactions$IPromotedEnlistment$EnlistmentDone();
                this._transaction.State.ChangeStatePromotedAborted(this._transaction);
            }
            /*void */ InternalInDoubt()
            {
                $.$$.System.Diagnostics.Debug.Assert$2(this._transaction.State !== null, "_transaction.State != null");
                this._transaction.State.InDoubtFromDtc(this._transaction);
            }
            /*void */ Prepare(/*IPromotedEnlistment*/ en)
            {
                this._preparingEnlistment = en;
                $.$stl.System.Transactions.VolatileDemultiplexer.PoolablePrepare(this);
            }
            /*void */ Commit(/*IPromotedEnlistment*/ en)
            {
                this._promotedEnlistment = en;
                $.$stl.System.Transactions.VolatileDemultiplexer.PoolableCommit(this);
            }
            /*void */ Rollback(/*IPromotedEnlistment*/ en)
            {
                this._promotedEnlistment = en;
                $.$stl.System.Transactions.VolatileDemultiplexer.PoolableRollback(this);
            }
            /*void */ InDoubt(/*IPromotedEnlistment*/ en)
            {
                this._promotedEnlistment = en;
                $.$stl.System.Transactions.VolatileDemultiplexer.PoolableInDoubt(this);
            }
            static $h = 3777804;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":8693004,"m":[{"r":65537,"n":"InternalPrepare","d":3777804,"h":8593712396,"f":16809988},{"r":65537,"n":"InternalCommit","d":3777804,"h":12888679692,"f":16809988},{"r":65537,"n":"InternalRollback","d":3777804,"h":17183646988,"f":16809988},{"r":65537,"n":"InternalInDoubt","d":3777804,"h":21478614284,"f":16809988},{"r":65537,"p":[{"n":"en","p":2925836}],"n":"Prepare","d":3777804,"h":25773581580,"f":16809985},{"r":65537,"p":[{"n":"en","p":2925836}],"n":"Commit","d":3777804,"h":30068548876,"f":16809985},{"r":65537,"p":[{"n":"en","p":2925836}],"n":"Rollback","d":3777804,"h":34363516172,"f":16809985},{"r":65537,"p":[{"n":"en","p":2925836}],"n":"InDoubt","d":3777804,"h":38658483468,"f":16809985}],"c":[{"p":[{"n":"transaction","p":2794764}],"n":".ctor","o":"$ctor$2","d":3777804,"h":4298745100,"f":16777217}],"i":[2663692],"h":3777804}; }
            static get $b() { return $.$stl.System.Transactions.VolatileDemultiplexer; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stl.System.Transactions.IEnlistmentNotificationInternal ]; }
            static get $fullName() { return `System.Transactions.Phase1VolatileDemultiplexer`; }
        });
        
        $asm.$cls("$stl.System.Transactions.DurableEnlistmentActive", ($self) => class DurableEnlistmentActive extends $.$stl.System.Transactions.DurableEnlistmentState
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                enlistment.State = this;
            }
            /*void */ EnlistmentDone(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentEnded.EnterState(enlistment);
            }
            /*void */ InternalAborted(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentAborting.EnterState(enlistment);
            }
            /*void */ ChangeStateCommitting(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentCommitting.EnterState(enlistment);
            }
            /*void */ ChangeStatePromoted(/*InternalEnlistment*/ enlistment, /*IPromotedEnlistment*/ promotedEnlistment)
            {
                enlistment.PromotedEnlistment = promotedEnlistment;
                $.$stl.System.Transactions.EnlistmentState.EnlistmentStatePromoted.EnterState(enlistment);
            }
            /*void */ ChangeStateDelegated(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentDelegated.EnterState(enlistment);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 1287436;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1549580,"m":[{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"EnterState","d":1287436,"h":4296254732,"f":16809992},{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"EnlistmentDone","d":1287436,"h":8591222028,"f":16809992},{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"InternalAborted","d":1287436,"h":12886189324,"f":16809992},{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"ChangeStateCommitting","d":1287436,"h":17181156620,"f":16809992},{"r":65537,"p":[{"n":"enlistment","p":2729228},{"n":"promotedEnlistment","p":2925836}],"n":"ChangeStatePromoted","d":1287436,"h":21476123916,"f":16809992},{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"ChangeStateDelegated","d":1287436,"h":25771091212,"f":16809992}],"c":[{"n":".ctor","o":"$ctor$3","d":1287436,"h":30066058508,"f":16777217}],"h":1287436}; }
            static get $b() { return $.$stl.System.Transactions.DurableEnlistmentState; }
            static get $fullName() { return `System.Transactions.DurableEnlistmentActive`; }
        });
        
        $asm.$cls("$stl.System.Transactions.DurableEnlistmentAborting", ($self) => class DurableEnlistmentAborting extends $.$stl.System.Transactions.DurableEnlistmentState
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                enlistment.State = this;
                $.$$.System.Threading.Monitor.Exit(enlistment.Transaction);
                try
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.EnlistmentStatus(1/*TraceSourceType.TraceSourceLtm*/, enlistment.EnlistmentTraceId, 2/*NotificationCall.Rollback*/);
                    }
                    if (enlistment.SinglePhaseNotification !== null)
                    {
                        enlistment.SinglePhaseNotification.System$Transactions$IEnlistmentNotification$Rollback(enlistment.SinglePhaseEnlistment);
                    }
                    else 
                    {
                        enlistment.PromotableSinglePhaseNotification.System$Transactions$IPromotableSinglePhaseNotification$Rollback(enlistment.SinglePhaseEnlistment);
                    }
                }
                finally
                {
                    {
                        $.$$.System.Threading.Monitor.Enter$1(enlistment.Transaction);
                    }
                }
            }
            /*void */ Aborted(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
                enlistment.Transaction._innerException ??= e;
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentEnded.EnterState(enlistment);
            }
            /*void */ EnlistmentDone(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentEnded.EnterState(enlistment);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 1221900;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1549580,"m":[{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"EnterState","d":1221900,"h":4296189196,"f":16809992},{"r":65537,"p":[{"n":"enlistment","p":2729228},{"n":"e","p":47251457}],"n":"Aborted","d":1221900,"h":8591156492,"f":16809992},{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"EnlistmentDone","d":1221900,"h":12886123788,"f":16809992}],"c":[{"n":".ctor","o":"$ctor$3","d":1221900,"h":17181091084,"f":16777217}],"h":1221900}; }
            static get $b() { return $.$stl.System.Transactions.DurableEnlistmentState; }
            static get $fullName() { return `System.Transactions.DurableEnlistmentAborting`; }
        });
        
        $asm.$cls("$stl.System.Transactions.VolatileEnlistmentActive", ($self) => class VolatileEnlistmentActive extends $.$stl.System.Transactions.VolatileEnlistmentState
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                enlistment.State = this;
            }
            /*void */ EnlistmentDone(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentDone.EnterState(enlistment);
                enlistment.FinishEnlistment();
            }
            /*void */ ChangeStatePreparing(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentPreparing.EnterState(enlistment);
            }
            /*void */ ChangeStateSinglePhaseCommit(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentSPC.EnterState(enlistment);
            }
            /*void */ InternalAborted(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentAborting.EnterState(enlistment);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 8824076;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":9479436,"m":[{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"EnterState","d":8824076,"h":4303791372,"f":16809992},{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"EnlistmentDone","d":8824076,"h":8598758668,"f":16809992},{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"ChangeStatePreparing","d":8824076,"h":12893725964,"f":16809992},{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"ChangeStateSinglePhaseCommit","d":8824076,"h":17188693260,"f":16809992},{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"InternalAborted","d":8824076,"h":21483660556,"f":16809992}],"c":[{"n":".ctor","o":"$ctor$3","d":8824076,"h":25778627852,"f":16777217}],"h":8824076}; }
            static get $b() { return $.$stl.System.Transactions.VolatileEnlistmentState; }
            static get $fullName() { return `System.Transactions.VolatileEnlistmentActive`; }
        });
        
        $asm.$cls("$stl.System.Transactions.VolatileEnlistmentPreparing", ($self) => class VolatileEnlistmentPreparing extends $.$stl.System.Transactions.VolatileEnlistmentState
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                enlistment.State = this;
                $.$$.System.Threading.Monitor.Exit(enlistment.Transaction);
                try
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.EnlistmentStatus(1/*TraceSourceType.TraceSourceLtm*/, enlistment.EnlistmentTraceId, 0/*NotificationCall.Prepare*/);
                    }
                    $.$$.System.Diagnostics.Debug.Assert$2(enlistment.EnlistmentNotification !== null, "enlistment.EnlistmentNotification != null");
                    enlistment.EnlistmentNotification.System$Transactions$IEnlistmentNotification$Prepare(enlistment.PreparingEnlistment);
                }
                finally
                {
                    {
                        $.$$.System.Threading.Monitor.Enter$1(enlistment.Transaction);
                    }
                }
            }
            /*void */ EnlistmentDone(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentDone.EnterState(enlistment);
                enlistment.FinishEnlistment();
            }
            /*void */ Prepared(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentPrepared.EnterState(enlistment);
                enlistment.FinishEnlistment();
            }
            /*void */ ForceRollback(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentEnded.EnterState(enlistment);
                $.$$.System.Diagnostics.Debug.Assert$2(enlistment.Transaction.State !== null, "enlistment.Transaction.State != null");
                enlistment.Transaction.State.ChangeStateTransactionAborted(enlistment.Transaction, e);
                enlistment.FinishEnlistment();
            }
            /*void */ ChangeStatePreparing(/*InternalEnlistment*/ enlistment)
            {
            }
            /*void */ InternalAborted(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentPreparingAborting.EnterState(enlistment);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 9217292;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":9479436,"m":[{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"EnterState","d":9217292,"h":4304184588,"f":16809992},{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"EnlistmentDone","d":9217292,"h":8599151884,"f":16809992},{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"Prepared","d":9217292,"h":12894119180,"f":16809992},{"r":65537,"p":[{"n":"enlistment","p":2729228},{"n":"e","p":47251457}],"n":"ForceRollback","d":9217292,"h":17189086476,"f":16809992},{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"ChangeStatePreparing","d":9217292,"h":21484053772,"f":16809992},{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"InternalAborted","d":9217292,"h":25779021068,"f":16809992}],"c":[{"n":".ctor","o":"$ctor$3","d":9217292,"h":30073988364,"f":16777217}],"h":9217292}; }
            static get $b() { return $.$stl.System.Transactions.VolatileEnlistmentState; }
            static get $fullName() { return `System.Transactions.VolatileEnlistmentPreparing`; }
        });
        
        $asm.$cls("$stl.System.Transactions.DurableEnlistmentCommitting", ($self) => class DurableEnlistmentCommitting extends $.$stl.System.Transactions.DurableEnlistmentState
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                /*bool*/ let spcCommitted = false;
                enlistment.State = this;
                $.$$.System.Threading.Monitor.Exit(enlistment.Transaction);
                try
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.EnlistmentStatus(1/*TraceSourceType.TraceSourceLtm*/, enlistment.EnlistmentTraceId, 4/*NotificationCall.SinglePhaseCommit*/);
                    }
                    if (enlistment.SinglePhaseNotification !== null)
                    {
                        enlistment.SinglePhaseNotification.System$Transactions$ISinglePhaseNotification$SinglePhaseCommit(enlistment.SinglePhaseEnlistment);
                    }
                    else 
                    {
                        enlistment.PromotableSinglePhaseNotification.System$Transactions$IPromotableSinglePhaseNotification$SinglePhaseCommit(enlistment.SinglePhaseEnlistment);
                    }
                    spcCommitted = true;
                }
                finally
                {
                    {
                        if (!spcCommitted)
                        {
                            enlistment.SinglePhaseEnlistment.InDoubt();
                        }
                        $.$$.System.Threading.Monitor.Enter$1(enlistment.Transaction);
                    }
                }
            }
            /*void */ EnlistmentDone(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentEnded.EnterState(enlistment);
                $.$$.System.Diagnostics.Debug.Assert$2(enlistment.Transaction.State !== null, "enlistment.Transaction.State != null");
                enlistment.Transaction.State.ChangeStateTransactionCommitted(enlistment.Transaction);
            }
            /*void */ Committed(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentEnded.EnterState(enlistment);
                $.$$.System.Diagnostics.Debug.Assert$2(enlistment.Transaction.State !== null, "enlistment.Transaction.State != null");
                enlistment.Transaction.State.ChangeStateTransactionCommitted(enlistment.Transaction);
            }
            /*void */ Aborted(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentEnded.EnterState(enlistment);
                $.$$.System.Diagnostics.Debug.Assert$2(enlistment.Transaction.State !== null, "enlistment.Transaction.State != null");
                enlistment.Transaction.State.ChangeStateTransactionAborted(enlistment.Transaction, e);
            }
            /*void */ InDoubt(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentEnded.EnterState(enlistment);
                enlistment.Transaction._innerException ??= e;
                $.$$.System.Diagnostics.Debug.Assert$2(enlistment.Transaction.State !== null, "enlistment.Transaction.State != null");
                enlistment.Transaction.State.InDoubtFromEnlistment(enlistment.Transaction);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 1352972;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1549580,"m":[{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"EnterState","d":1352972,"h":4296320268,"f":16809992},{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"EnlistmentDone","d":1352972,"h":8591287564,"f":16809992},{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"Committed","d":1352972,"h":12886254860,"f":16809992},{"r":65537,"p":[{"n":"enlistment","p":2729228},{"n":"e","p":47251457}],"n":"Aborted","d":1352972,"h":17181222156,"f":16809992},{"r":65537,"p":[{"n":"enlistment","p":2729228},{"n":"e","p":47251457}],"n":"InDoubt","d":1352972,"h":21476189452,"f":16809992}],"c":[{"n":".ctor","o":"$ctor$3","d":1352972,"h":25771156748,"f":16777217}],"h":1352972}; }
            static get $b() { return $.$stl.System.Transactions.DurableEnlistmentState; }
            static get $fullName() { return `System.Transactions.DurableEnlistmentCommitting`; }
        });
        
        $asm.$cls("$stl.System.Transactions.VolatileEnlistmentSPC", ($self) => class VolatileEnlistmentSPC extends $.$stl.System.Transactions.VolatileEnlistmentState
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                /*bool*/ let spcCommitted = false;
                enlistment.State = this;
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.EnlistmentStatus(1/*TraceSourceType.TraceSourceLtm*/, enlistment.EnlistmentTraceId, 4/*NotificationCall.SinglePhaseCommit*/);
                }
                $.$$.System.Threading.Monitor.Exit(enlistment.Transaction);
                try
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(enlistment.SinglePhaseNotification !== null, "enlistment.SinglePhaseNotification != null");
                    enlistment.SinglePhaseNotification.System$Transactions$ISinglePhaseNotification$SinglePhaseCommit(enlistment.SinglePhaseEnlistment);
                    spcCommitted = true;
                }
                finally
                {
                    {
                        if (!spcCommitted)
                        {
                            enlistment.SinglePhaseEnlistment.InDoubt();
                        }
                        $.$$.System.Threading.Monitor.Enter$1(enlistment.Transaction);
                    }
                }
            }
            /*void */ EnlistmentDone(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentEnded.EnterState(enlistment);
                $.$$.System.Diagnostics.Debug.Assert$2(enlistment.Transaction.State !== null, "enlistment.Transaction.State != null");
                enlistment.Transaction.State.ChangeStateTransactionCommitted(enlistment.Transaction);
            }
            /*void */ Committed(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentEnded.EnterState(enlistment);
                $.$$.System.Diagnostics.Debug.Assert$2(enlistment.Transaction.State !== null, "enlistment.Transaction.State != null");
                enlistment.Transaction.State.ChangeStateTransactionCommitted(enlistment.Transaction);
            }
            /*void */ Aborted(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentEnded.EnterState(enlistment);
                $.$$.System.Diagnostics.Debug.Assert$2(enlistment.Transaction.State !== null, "enlistment.Transaction.State != null");
                enlistment.Transaction.State.ChangeStateTransactionAborted(enlistment.Transaction, e);
            }
            /*void */ InDoubt(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentEnded.EnterState(enlistment);
                enlistment.Transaction._innerException ??= e;
                $.$$.System.Diagnostics.Debug.Assert$2(enlistment.Transaction.State !== null, "enlistment.Transaction.State != null");
                enlistment.Transaction.State.InDoubtFromEnlistment(enlistment.Transaction);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 9413900;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":9479436,"m":[{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"EnterState","d":9413900,"h":4304381196,"f":16809992},{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"EnlistmentDone","d":9413900,"h":8599348492,"f":16809992},{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"Committed","d":9413900,"h":12894315788,"f":16809992},{"r":65537,"p":[{"n":"enlistment","p":2729228},{"n":"e","p":47251457}],"n":"Aborted","d":9413900,"h":17189283084,"f":16809992},{"r":65537,"p":[{"n":"enlistment","p":2729228},{"n":"e","p":47251457}],"n":"InDoubt","d":9413900,"h":21484250380,"f":16809992}],"c":[{"n":".ctor","o":"$ctor$3","d":9413900,"h":25779217676,"f":16777217}],"h":9413900}; }
            static get $b() { return $.$stl.System.Transactions.VolatileEnlistmentState; }
            static get $fullName() { return `System.Transactions.VolatileEnlistmentSPC`; }
        });
        
        $asm.$cls("$stl.System.Transactions.DurableEnlistmentDelegated", ($self) => class DurableEnlistmentDelegated extends $.$stl.System.Transactions.DurableEnlistmentState
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                enlistment.State = this;
                $.$$.System.Diagnostics.Debug.Assert$2(enlistment.PromotableSinglePhaseNotification !== null, "enlistment.PromotableSinglePhaseNotification != null");
            }
            /*void */ Committed(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentEnded.EnterState(enlistment);
                $.$$.System.Diagnostics.Debug.Assert$2(enlistment.Transaction.State !== null, "enlistment.Transaction.State != null");
                enlistment.Transaction.State.ChangeStatePromotedCommitted(enlistment.Transaction);
            }
            /*void */ Aborted(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentEnded.EnterState(enlistment);
                enlistment.Transaction._innerException ??= e;
                $.$$.System.Diagnostics.Debug.Assert$2(enlistment.Transaction.State !== null, "enlistment.Transaction.State != null");
                enlistment.Transaction.State.ChangeStatePromotedAborted(enlistment.Transaction);
            }
            /*void */ InDoubt(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentEnded.EnterState(enlistment);
                enlistment.Transaction._innerException ??= e;
                $.$$.System.Diagnostics.Debug.Assert$2(enlistment.Transaction.State !== null, "enlistment.Transaction.State != null");
                enlistment.Transaction.State.InDoubtFromEnlistment(enlistment.Transaction);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 1418508;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1549580,"m":[{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"EnterState","d":1418508,"h":4296385804,"f":16809992},{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"Committed","d":1418508,"h":8591353100,"f":16809992},{"r":65537,"p":[{"n":"enlistment","p":2729228},{"n":"e","p":47251457}],"n":"Aborted","d":1418508,"h":12886320396,"f":16809992},{"r":65537,"p":[{"n":"enlistment","p":2729228},{"n":"e","p":47251457}],"n":"InDoubt","d":1418508,"h":17181287692,"f":16809992}],"c":[{"n":".ctor","o":"$ctor$3","d":1418508,"h":21476254988,"f":16777217}],"h":1418508}; }
            static get $b() { return $.$stl.System.Transactions.DurableEnlistmentState; }
            static get $fullName() { return `System.Transactions.DurableEnlistmentDelegated`; }
        });
        
        $asm.$cls("$stl.System.Transactions.DurableEnlistmentEnded", ($self) => class DurableEnlistmentEnded extends $.$stl.System.Transactions.DurableEnlistmentState
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                enlistment.State = this;
            }
            /*void */ InternalAborted(/*InternalEnlistment*/ enlistment)
            {
            }
            /*void */ InDoubt(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 1484044;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1549580,"m":[{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"EnterState","d":1484044,"h":4296451340,"f":16809992},{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"InternalAborted","d":1484044,"h":8591418636,"f":16809992},{"r":65537,"p":[{"n":"enlistment","p":2729228},{"n":"e","p":47251457}],"n":"InDoubt","d":1484044,"h":12886385932,"f":16809992}],"c":[{"n":".ctor","o":"$ctor$3","d":1484044,"h":17181353228,"f":16777217}],"h":1484044}; }
            static get $b() { return $.$stl.System.Transactions.DurableEnlistmentState; }
            static get $fullName() { return `System.Transactions.DurableEnlistmentEnded`; }
        });
        
        $asm.$cls("$stl.System.Transactions.VolatileEnlistmentPrepared", ($self) => class VolatileEnlistmentPrepared extends $.$stl.System.Transactions.VolatileEnlistmentState
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                enlistment.State = this;
            }
            /*void */ InternalAborted(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentAborting.EnterState(enlistment);
            }
            /*void */ InternalCommitted(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentCommitting.EnterState(enlistment);
            }
            /*void */ InternalIndoubt(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentInDoubt.EnterState(enlistment);
            }
            /*void */ ChangeStatePreparing(/*InternalEnlistment*/ enlistment)
            {
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 9151756;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":9479436,"m":[{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"EnterState","d":9151756,"h":4304119052,"f":16809992},{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"InternalAborted","d":9151756,"h":8599086348,"f":16809992},{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"InternalCommitted","d":9151756,"h":12894053644,"f":16809992},{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"InternalIndoubt","d":9151756,"h":17189020940,"f":16809992},{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"ChangeStatePreparing","d":9151756,"h":21483988236,"f":16809992}],"c":[{"n":".ctor","o":"$ctor$3","d":9151756,"h":25778955532,"f":16777217}],"h":9151756}; }
            static get $b() { return $.$stl.System.Transactions.VolatileEnlistmentState; }
            static get $fullName() { return `System.Transactions.VolatileEnlistmentPrepared`; }
        });
        
        $asm.$cls("$stl.System.Transactions.VolatileEnlistmentPreparingAborting", ($self) => class VolatileEnlistmentPreparingAborting extends $.$stl.System.Transactions.VolatileEnlistmentState
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                enlistment.State = this;
            }
            /*void */ EnlistmentDone(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentEnded.EnterState(enlistment);
            }
            /*void */ Prepared(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentAborting.EnterState(enlistment);
                enlistment.FinishEnlistment();
            }
            /*void */ ForceRollback(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentEnded.EnterState(enlistment);
                if (enlistment.Transaction._innerException === null)
                {
                    enlistment.Transaction._innerException = e;
                }
                enlistment.FinishEnlistment();
            }
            /*void */ InternalAborted(/*InternalEnlistment*/ enlistment)
            {
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 9282828;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":9479436,"m":[{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"EnterState","d":9282828,"h":4304250124,"f":16809992},{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"EnlistmentDone","d":9282828,"h":8599217420,"f":16809992},{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"Prepared","d":9282828,"h":12894184716,"f":16809992},{"r":65537,"p":[{"n":"enlistment","p":2729228},{"n":"e","p":47251457}],"n":"ForceRollback","d":9282828,"h":17189152012,"f":16809992},{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"InternalAborted","d":9282828,"h":21484119308,"f":16809992}],"c":[{"n":".ctor","o":"$ctor$3","d":9282828,"h":25779086604,"f":16777217}],"h":9282828}; }
            static get $b() { return $.$stl.System.Transactions.VolatileEnlistmentState; }
            static get $fullName() { return `System.Transactions.VolatileEnlistmentPreparingAborting`; }
        });
        
        $asm.$cls("$stl.System.Transactions.VolatileEnlistmentAborting", ($self) => class VolatileEnlistmentAborting extends $.$stl.System.Transactions.VolatileEnlistmentState
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                enlistment.State = this;
                $.$$.System.Threading.Monitor.Exit(enlistment.Transaction);
                try
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.EnlistmentStatus(1/*TraceSourceType.TraceSourceLtm*/, enlistment.EnlistmentTraceId, 2/*NotificationCall.Rollback*/);
                    }
                    $.$$.System.Diagnostics.Debug.Assert$2(enlistment.EnlistmentNotification !== null, "enlistment.EnlistmentNotification != null");
                    enlistment.EnlistmentNotification.System$Transactions$IEnlistmentNotification$Rollback(enlistment.SinglePhaseEnlistment);
                }
                finally
                {
                    {
                        $.$$.System.Threading.Monitor.Enter$1(enlistment.Transaction);
                    }
                }
            }
            /*void */ ChangeStatePreparing(/*InternalEnlistment*/ enlistment)
            {
            }
            /*void */ EnlistmentDone(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentEnded.EnterState(enlistment);
            }
            /*void */ InternalAborted(/*InternalEnlistment*/ enlistment)
            {
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 8758540;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":9479436,"m":[{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"EnterState","d":8758540,"h":4303725836,"f":16809992},{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"ChangeStatePreparing","d":8758540,"h":8598693132,"f":16809992},{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"EnlistmentDone","d":8758540,"h":12893660428,"f":16809992},{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"InternalAborted","d":8758540,"h":17188627724,"f":16809992}],"c":[{"n":".ctor","o":"$ctor$3","d":8758540,"h":21483595020,"f":16777217}],"h":8758540}; }
            static get $b() { return $.$stl.System.Transactions.VolatileEnlistmentState; }
            static get $fullName() { return `System.Transactions.VolatileEnlistmentAborting`; }
        });
        
        $asm.$cls("$stl.System.Transactions.VolatileEnlistmentCommitting", ($self) => class VolatileEnlistmentCommitting extends $.$stl.System.Transactions.VolatileEnlistmentState
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                enlistment.State = this;
                $.$$.System.Threading.Monitor.Exit(enlistment.Transaction);
                try
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.EnlistmentStatus(1/*TraceSourceType.TraceSourceLtm*/, enlistment.EnlistmentTraceId, 1/*NotificationCall.Commit*/);
                    }
                    $.$$.System.Diagnostics.Debug.Assert$2(enlistment.EnlistmentNotification !== null, "enlistment.EnlistmentNotification != null");
                    enlistment.EnlistmentNotification.System$Transactions$IEnlistmentNotification$Commit(enlistment.Enlistment);
                }
                finally
                {
                    {
                        $.$$.System.Threading.Monitor.Enter$1(enlistment.Transaction);
                    }
                }
            }
            /*void */ EnlistmentDone(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentEnded.EnterState(enlistment);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 8889612;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":9479436,"m":[{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"EnterState","d":8889612,"h":4303856908,"f":16809992},{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"EnlistmentDone","d":8889612,"h":8598824204,"f":16809992}],"c":[{"n":".ctor","o":"$ctor$3","d":8889612,"h":12893791500,"f":16777217}],"h":8889612}; }
            static get $b() { return $.$stl.System.Transactions.VolatileEnlistmentState; }
            static get $fullName() { return `System.Transactions.VolatileEnlistmentCommitting`; }
        });
        
        $asm.$cls("$stl.System.Transactions.VolatileEnlistmentInDoubt", ($self) => class VolatileEnlistmentInDoubt extends $.$stl.System.Transactions.VolatileEnlistmentState
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                enlistment.State = this;
                $.$$.System.Threading.Monitor.Exit(enlistment.Transaction);
                try
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.EnlistmentStatus(1/*TraceSourceType.TraceSourceLtm*/, enlistment.EnlistmentTraceId, 3/*NotificationCall.InDoubt*/);
                    }
                    $.$$.System.Diagnostics.Debug.Assert$2(enlistment.EnlistmentNotification !== null, "enlistment.EnlistmentNotification != null");
                    enlistment.EnlistmentNotification.System$Transactions$IEnlistmentNotification$InDoubt(enlistment.PreparingEnlistment);
                }
                finally
                {
                    {
                        $.$$.System.Threading.Monitor.Enter$1(enlistment.Transaction);
                    }
                }
            }
            /*void */ EnlistmentDone(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentEnded.EnterState(enlistment);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 9086220;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":9479436,"m":[{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"EnterState","d":9086220,"h":4304053516,"f":16809992},{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"EnlistmentDone","d":9086220,"h":8599020812,"f":16809992}],"c":[{"n":".ctor","o":"$ctor$3","d":9086220,"h":12893988108,"f":16777217}],"h":9086220}; }
            static get $b() { return $.$stl.System.Transactions.VolatileEnlistmentState; }
            static get $fullName() { return `System.Transactions.VolatileEnlistmentInDoubt`; }
        });
        
        $asm.$cls("$stl.System.Transactions.VolatileEnlistmentEnded", ($self) => class VolatileEnlistmentEnded extends $.$stl.System.Transactions.VolatileEnlistmentState
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                enlistment.State = this;
            }
            /*void */ ChangeStatePreparing(/*InternalEnlistment*/ enlistment)
            {
            }
            /*void */ InternalAborted(/*InternalEnlistment*/ enlistment)
            {
            }
            /*void */ InternalCommitted(/*InternalEnlistment*/ enlistment)
            {
            }
            /*void */ InternalIndoubt(/*InternalEnlistment*/ enlistment)
            {
            }
            /*void */ InDoubt(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 9020684;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":9479436,"m":[{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"EnterState","d":9020684,"h":4303987980,"f":16809992},{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"ChangeStatePreparing","d":9020684,"h":8598955276,"f":16809992},{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"InternalAborted","d":9020684,"h":12893922572,"f":16809992},{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"InternalCommitted","d":9020684,"h":17188889868,"f":16809992},{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"InternalIndoubt","d":9020684,"h":21483857164,"f":16809992},{"r":65537,"p":[{"n":"enlistment","p":2729228},{"n":"e","p":47251457}],"n":"InDoubt","d":9020684,"h":25778824460,"f":16809992}],"c":[{"n":".ctor","o":"$ctor$3","d":9020684,"h":30073791756,"f":16777217}],"h":9020684}; }
            static get $b() { return $.$stl.System.Transactions.VolatileEnlistmentState; }
            static get $fullName() { return `System.Transactions.VolatileEnlistmentEnded`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateVolatilePhase1", ($self) => class TransactionStateVolatilePhase1 extends $.$stl.System.Transactions.ActiveStates
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                $.$$.System.Diagnostics.Debug.Assert$2(tx._committableTransaction !== null, "tx._committableTransaction != null");
                tx._committableTransaction._complete = true;
                if (tx._phase1Volatiles._dependentClones !== 0)
                {
                    $.$stl.System.Transactions.TransactionState.TransactionStateAborted.EnterState(tx);
                    return;
                }
                if (tx._phase1Volatiles._volatileEnlistmentCount === 1 && tx._durableEnlistment === null && $.$$.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, 0).SinglePhaseNotification !== null)
                {
                    $.$stl.System.Transactions.TransactionState.TransactionStateVolatileSPC.EnterState(tx);
                }
                else if (tx._phase1Volatiles._volatileEnlistmentCount > 0)
                {
                    for(/*int*/ let i = 0; i < tx._phase1Volatiles._volatileEnlistmentCount; i++)
                    {
                        $.$$.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i)._twoPhaseState.ChangeStatePreparing($.$$.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i));
                        if (!tx.State.ContinuePhase1Prepares())
                        {
                            break;
                        }
                    }
                }
                else 
                {
                    $.$stl.System.Transactions.TransactionState.TransactionStateSPC.EnterState(tx);
                }
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                this.ChangeStateTransactionAborted(tx, e);
            }
            /*void */ ChangeStateTransactionAborted(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                tx._innerException ??= e;
                $.$stl.System.Transactions.TransactionState.TransactionStateAborted.EnterState(tx);
            }
            /*void */ Phase1VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStateSPC.EnterState(tx);
            }
            /*bool */ ContinuePhase1Prepares()
            {
                return true;
            }
            /*void */ Timeout(/*InternalTransaction*/ tx)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionTimeout$1(tx.TransactionTraceId);
                }
                /*TimeoutException*/ let e = new $.$$.System.TimeoutException().$ctor$12($.$stl.System.SR.TraceTransactionTimeout);
                this.Rollback(tx, e);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 8299788;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":238860,"m":[{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"EnterState","d":8299788,"h":4303267084,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"e","p":47251457}],"n":"Rollback","d":8299788,"h":8598234380,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"e","p":47251457}],"n":"ChangeStateTransactionAborted","d":8299788,"h":12893201676,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"Phase1VolatilePrepareDone","d":8299788,"h":17188168972,"f":16809992},{"r":262145,"n":"ContinuePhase1Prepares","d":8299788,"h":21483136268,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"Timeout","d":8299788,"h":25778103564,"f":16809992}],"c":[{"n":".ctor","o":"$ctor$3","d":8299788,"h":30073070860,"f":16777217}],"h":8299788}; }
            static get $b() { return $.$stl.System.Transactions.ActiveStates; }
            static get $fullName() { return `System.Transactions.TransactionStateVolatilePhase1`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateVolatileSPC", ($self) => class TransactionStateVolatileSPC extends $.$stl.System.Transactions.ActiveStates
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                $.$$.System.Diagnostics.Debug.Assert$2(tx._phase1Volatiles._volatileEnlistmentCount === 1, "There must be exactly 1 phase 1 volatile enlistment for TransactionStateVolatileSPC");
                $.$$.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, 0)._twoPhaseState.ChangeStateSinglePhaseCommit($.$$.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, 0));
            }
            /*void */ ChangeStateTransactionCommitted(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStateCommitted.EnterState(tx);
            }
            /*void */ InDoubtFromEnlistment(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStateInDoubt.EnterState(tx);
            }
            /*void */ ChangeStateTransactionAborted(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                tx._innerException ??= e;
                $.$stl.System.Transactions.TransactionState.TransactionStateAborted.EnterState(tx);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 8365324;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":238860,"m":[{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"EnterState","d":8365324,"h":4303332620,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"ChangeStateTransactionCommitted","d":8365324,"h":8598299916,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"InDoubtFromEnlistment","d":8365324,"h":12893267212,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"e","p":47251457}],"n":"ChangeStateTransactionAborted","d":8365324,"h":17188234508,"f":16809992}],"c":[{"n":".ctor","o":"$ctor$3","d":8365324,"h":21483201804,"f":16777217}],"h":8365324}; }
            static get $b() { return $.$stl.System.Transactions.ActiveStates; }
            static get $fullName() { return `System.Transactions.TransactionStateVolatileSPC`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateSPC", ($self) => class TransactionStateSPC extends $.$stl.System.Transactions.ActiveStates
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                if (tx._durableEnlistment !== null)
                {
                    tx._durableEnlistment.State.ChangeStateCommitting(tx._durableEnlistment);
                }
                else 
                {
                    $.$stl.System.Transactions.TransactionState.TransactionStateCommitted.EnterState(tx);
                }
            }
            /*void */ ChangeStateTransactionCommitted(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStateCommitted.EnterState(tx);
            }
            /*void */ InDoubtFromEnlistment(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStateInDoubt.EnterState(tx);
            }
            /*void */ ChangeStateTransactionAborted(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                tx._innerException ??= e;
                $.$stl.System.Transactions.TransactionState.TransactionStateAborted.EnterState(tx);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 8168716;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":238860,"m":[{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"EnterState","d":8168716,"h":4303136012,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"ChangeStateTransactionCommitted","d":8168716,"h":8598103308,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"InDoubtFromEnlistment","d":8168716,"h":12893070604,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"e","p":47251457}],"n":"ChangeStateTransactionAborted","d":8168716,"h":17188037900,"f":16809992}],"c":[{"n":".ctor","o":"$ctor$3","d":8168716,"h":21483005196,"f":16777217}],"h":8168716}; }
            static get $b() { return $.$stl.System.Transactions.ActiveStates; }
            static get $fullName() { return `System.Transactions.TransactionStateSPC`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateAborted", ($self) => class TransactionStateAborted extends $.$stl.System.Transactions.TransactionStateEnded
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                super.EnterState(tx);
                this.CommonEnterState(tx);
                for(/*int*/ let i = 0; i < tx._phase0Volatiles._volatileEnlistmentCount; i++)
                {
                    $.$$.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i)._twoPhaseState.InternalAborted($.$$.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i));
                }
                for(/*int*/ let i = 0; i < tx._phase1Volatiles._volatileEnlistmentCount; i++)
                {
                    $.$$.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i)._twoPhaseState.InternalAborted($.$$.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i));
                }
                tx._durableEnlistment?.State.InternalAborted(tx._durableEnlistment);
                $.$stl.System.Transactions.TransactionTable.Remove(tx);
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionTimeout$1(tx.TransactionTraceId);
                }
                tx.FireCompletion();
                if (tx._asyncCommit)
                {
                    tx.SignalAsyncCompletion();
                }
            }
            /*TransactionStatus */ get_Status(/*InternalTransaction*/ tx)
            {
                return 2/*TransactionStatus.Aborted*/;
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
            }
            /*void */ BeginCommit(/*InternalTransaction*/ tx, /*bool*/ asyncCommit, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw $.$stl.System.Transactions.TransactionStateAborted.CreateTransactionAbortedException(tx);
            }
            /*void */ EndCommit(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionStateAborted.CreateTransactionAbortedException(tx);
            }
            /*void */ RestartCommitIfNeeded(/*InternalTransaction*/ tx)
            {
            }
            /*void */ Timeout(/*InternalTransaction*/ tx)
            {
            }
            /*void */ Phase0VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ Phase1VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ ChangeStateTransactionAborted(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
            }
            /*void */ ChangeStatePromotedAborted(/*InternalTransaction*/ tx)
            {
            }
            /*void */ ChangeStateAbortedDuringPromotion(/*InternalTransaction*/ tx)
            {
            }
            /*void */ CreateBlockingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionStateAborted.CreateTransactionAbortedException(tx);
            }
            /*void */ CreateAbortingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionStateAborted.CreateTransactionAbortedException(tx);
            }
            /*void */ GetObjectData(/*InternalTransaction*/ tx, /*SerializationInfo*/ serializationInfo, /*StreamingContext*/ context)
            {
                throw $.$stl.System.Transactions.TransactionStateAborted.CreateTransactionAbortedException(tx);
            }
            /*void */ CheckForFinishedTransaction(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionStateAborted.CreateTransactionAbortedException(tx);
            }
            static /*TransactionAbortedException */ CreateTransactionAbortedException(/*InternalTransaction*/ tx)
            {
                return $.$stl.System.Transactions.TransactionAbortedException.Create$3($.$stl.System.SR.TransactionAborted, tx._innerException, tx.DistributedTxId);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 5809420;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6464780,"m":[{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"EnterState","d":5809420,"h":4300776716,"f":16809992},{"r":8430860,"p":[{"n":"tx","p":2794764}],"n":"get_Status","d":5809420,"h":8595744012,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"e","p":47251457}],"n":"Rollback","d":5809420,"h":12890711308,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"asyncCommit","p":262145},{"n":"asyncCallback","p":14548993},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":5809420,"h":17185678604,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"EndCommit","d":5809420,"h":21480645900,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"RestartCommitIfNeeded","d":5809420,"h":25775613196,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"Timeout","d":5809420,"h":30070580492,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"Phase0VolatilePrepareDone","d":5809420,"h":34365547788,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"Phase1VolatilePrepareDone","d":5809420,"h":38660515084,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"e","p":47251457}],"n":"ChangeStateTransactionAborted","d":5809420,"h":42955482380,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"ChangeStatePromotedAborted","d":5809420,"h":47250449676,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"ChangeStateAbortedDuringPromotion","d":5809420,"h":51545416972,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"CreateBlockingClone","d":5809420,"h":55840384268,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"CreateAbortingClone","d":5809420,"h":60135351564,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"serializationInfo","p":113836033},{"n":"context","p":113967105}],"n":"GetObjectData","d":5809420,"h":64430318860,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"CheckForFinishedTransaction","d":5809420,"h":68725286156,"f":16809992},{"r":4367628,"p":[{"n":"tx","p":2794764}],"n":"CreateTransactionAbortedException","d":5809420,"h":73020253452,"f":16777250}],"c":[{"n":".ctor","o":"$ctor$3","d":5809420,"h":77315220748,"f":16777217}],"h":5809420}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStateEnded; }
            static get $fullName() { return `System.Transactions.TransactionStateAborted`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateCommitted", ($self) => class TransactionStateCommitted extends $.$stl.System.Transactions.TransactionStateEnded
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                super.EnterState(tx);
                this.CommonEnterState(tx);
                for(/*int*/ let i = 0; i < tx._phase0Volatiles._volatileEnlistmentCount; i++)
                {
                    $.$$.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i)._twoPhaseState.InternalCommitted($.$$.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i));
                }
                for(/*int*/ let i = 0; i < tx._phase1Volatiles._volatileEnlistmentCount; i++)
                {
                    $.$$.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i)._twoPhaseState.InternalCommitted($.$$.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i));
                }
                $.$stl.System.Transactions.TransactionTable.Remove(tx);
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionCommitted(1/*TraceSourceType.TraceSourceLtm*/, tx.TransactionTraceId);
                }
                tx.FireCompletion();
                if (tx._asyncCommit)
                {
                    tx.SignalAsyncCompletion();
                }
            }
            /*TransactionStatus */ get_Status(/*InternalTransaction*/ tx)
            {
                return 1/*TransactionStatus.Committed*/;
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException(tx._innerException, tx.DistributedTxId);
            }
            /*void */ EndCommit(/*InternalTransaction*/ tx)
            {
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 5940492;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6464780,"m":[{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"EnterState","d":5940492,"h":4300907788,"f":16809992},{"r":8430860,"p":[{"n":"tx","p":2794764}],"n":"get_Status","d":5940492,"h":8595875084,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"e","p":47251457}],"n":"Rollback","d":5940492,"h":12890842380,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"EndCommit","d":5940492,"h":17185809676,"f":16809992}],"c":[{"n":".ctor","o":"$ctor$3","d":5940492,"h":21480776972,"f":16777217}],"h":5940492}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStateEnded; }
            static get $fullName() { return `System.Transactions.TransactionStateCommitted`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateInDoubt", ($self) => class TransactionStateInDoubt extends $.$stl.System.Transactions.TransactionStateEnded
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                super.EnterState(tx);
                this.CommonEnterState(tx);
                for(/*int*/ let i = 0; i < tx._phase0Volatiles._volatileEnlistmentCount; i++)
                {
                    $.$$.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i)._twoPhaseState.InternalIndoubt($.$$.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i));
                }
                for(/*int*/ let i = 0; i < tx._phase1Volatiles._volatileEnlistmentCount; i++)
                {
                    $.$$.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i)._twoPhaseState.InternalIndoubt($.$$.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i));
                }
                $.$stl.System.Transactions.TransactionTable.Remove(tx);
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionInDoubt(1/*TraceSourceType.TraceSourceLtm*/, tx.TransactionTraceId);
                }
                tx.FireCompletion();
                if (tx._asyncCommit)
                {
                    tx.SignalAsyncCompletion();
                }
            }
            /*TransactionStatus */ get_Status(/*InternalTransaction*/ tx)
            {
                return 3/*TransactionStatus.InDoubt*/;
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException(tx._innerException, tx.DistributedTxId);
            }
            /*void */ EndCommit(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionInDoubtException.Create$3(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionIndoubt, tx._innerException, tx.DistributedTxId);
            }
            /*void */ CheckForFinishedTransaction(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionInDoubtException.Create$3(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionIndoubt, tx._innerException, tx.DistributedTxId);
            }
            /*void */ GetObjectData(/*InternalTransaction*/ tx, /*SerializationInfo*/ serializationInfo, /*StreamingContext*/ context)
            {
                throw $.$stl.System.Transactions.TransactionInDoubtException.Create$3(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionIndoubt, tx._innerException, tx.DistributedTxId);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 6530316;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6464780,"m":[{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"EnterState","d":6530316,"h":4301497612,"f":16809992},{"r":8430860,"p":[{"n":"tx","p":2794764}],"n":"get_Status","d":6530316,"h":8596464908,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"e","p":47251457}],"n":"Rollback","d":6530316,"h":12891432204,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"EndCommit","d":6530316,"h":17186399500,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"CheckForFinishedTransaction","d":6530316,"h":21481366796,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"serializationInfo","p":113836033},{"n":"context","p":113967105}],"n":"GetObjectData","d":6530316,"h":25776334092,"f":16809992}],"c":[{"n":".ctor","o":"$ctor$3","d":6530316,"h":30071301388,"f":16777217}],"h":6530316}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStateEnded; }
            static get $fullName() { return `System.Transactions.TransactionStateInDoubt`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateNonCommittablePromoted", ($self) => class TransactionStateNonCommittablePromoted extends $.$stl.System.Transactions.TransactionStatePromotedBase
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                $.$$.System.Diagnostics.Debug.Assert$2(tx.PromotedTransaction !== null && tx.PromotedTransaction.RealTransaction !== null, "tx.PromotedTransaction != null && tx.PromotedTransaction.RealTransaction != null");
                tx.PromotedTransaction.RealTransaction.InternalTransaction = tx;
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 6595852;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6923532,"m":[{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"EnterState","d":6595852,"h":4301563148,"f":16809992}],"c":[{"n":".ctor","o":"$ctor$3","d":6595852,"h":8596530444,"f":16777217}],"h":6595852}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedBase; }
            static get $fullName() { return `System.Transactions.TransactionStateNonCommittablePromoted`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromoted", ($self) => class TransactionStatePromoted extends $.$stl.System.Transactions.TransactionStatePromotedBase
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(($.$$.System.Guid.op_Equality(tx._promoterType, $.$$.System.Guid.Empty)) || ($.$$.System.Guid.op_Equality(tx._promoterType, $.$stl.System.Transactions.TransactionInterop.PromoterTypeDtc)), "Promoted to MSTC but PromoterType is not TransactionInterop.PromoterTypeDtc");
                tx.SetPromoterTypeToMSDTC();
                if (tx._outcomeSource._isoLevel === 4/*IsolationLevel.Snapshot*/)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException$1(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.CannotPromoteSnapshot, null);
                }
                this.CommonEnterState(tx);
                /*OletxCommittableTransaction?*/ let distributedTx = null;
                try
                {
                    /*TimeSpan*/ let newTimeout;
                    if (tx.AbsoluteTimeout === 9223372036854775807n)
                    {
                        newTimeout = $.$$.System.TimeSpan.Zero;
                    }
                    else 
                    {
                        newTimeout = $.$stl.System.Transactions.TransactionManager.TransactionTable.RecalcTimeout(tx);
                        if ($.$$.System.TimeSpan.op_LessThanOrEqual(newTimeout, $.$$.System.TimeSpan.Zero))
                        {
                            return;
                        }
                    }
                    /*TransactionOptions*/ let options = new $.$stl.System.Transactions.TransactionOptions();
                    options.IsolationLevel = tx._outcomeSource._isoLevel;
                    options.Timeout = newTimeout;
                    distributedTx = $.$stl.System.Transactions.TransactionManager.DistributedTransactionManager.CreateTransaction(options.Clone());
                    distributedTx.SavedLtmPromotedTransaction = tx._outcomeSource;
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.TransactionPromoted$1(tx.TransactionTraceId, distributedTx.TransactionTraceId);
                    }
                }
                catch(te)
                {
                    tx._innerException = te;
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.ExceptionConsumed(te);
                    }
                    return;
                }
                finally
                {
                    {
                        if (distributedTx === null)
                        {
                            tx.State.ChangeStateAbortedDuringPromotion(tx);
                        }
                    }
                }
                tx.PromotedTransaction = distributedTx;
                /*Hashtable*/ let promotedTransactionTable = $.$stl.System.Transactions.TransactionManager.PromotedTransactionTable;
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(promotedTransactionTable)
                    {
                        tx._finalizedObject = new $.$stl.System.Transactions.FinalizedObject().$ctor$1(tx, distributedTx.Identifier);
                        /*WeakReference*/ let weakRef = new $.$$.System.WeakReference().$ctor$1(tx._outcomeSource, false);
                        promotedTransactionTable.set_Item(distributedTx.Identifier, weakRef);
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(promotedTransactionTable)
                }
                $.$stl.System.Transactions.TransactionManager.FireDistributedTransactionStarted(tx._outcomeSource);
                this.PromoteEnlistmentsAndOutcome(tx);
            }
            static /*bool */ PromotePhaseVolatiles(/*InternalTransaction*/ tx, /*ref VolatileEnlistmentSet*/ volatiles, /*bool*/ phase0)
            {
                if (((volatiles.$v._volatileEnlistmentCount + volatiles.$v._dependentClones) | 0) > 0)
                {
                    if (phase0)
                    {
                        volatiles.$v.VolatileDemux = new $.$stl.System.Transactions.Phase0VolatileDemultiplexer().$ctor$2(tx);
                    }
                    else 
                    {
                        volatiles.$v.VolatileDemux = new $.$stl.System.Transactions.Phase1VolatileDemultiplexer().$ctor$2(tx);
                    }
                    $.$$.System.Diagnostics.Debug.Assert$2(tx.PromotedTransaction !== null, "tx.PromotedTransaction != null");
                    volatiles.$v.VolatileDemux._promotedEnlistment = tx.PromotedTransaction.EnlistVolatile$1(volatiles.$v.VolatileDemux, phase0 ? 1/*EnlistmentOptions.EnlistDuringPrepareRequired*/ : 0/*EnlistmentOptions.None*/);
                }
                return true;
            }
            /*bool */ PromoteDurable(/*InternalTransaction*/ tx)
            {
                if (tx._durableEnlistment !== null)
                {
                    /*InternalEnlistment*/ let enlistment = tx._durableEnlistment;
                    $.$$.System.Diagnostics.Debug.Assert$2(tx.PromotedTransaction !== null, "tx.PromotedTransaction != null");
                    /*IPromotedEnlistment*/ let promotedEnlistment = tx.PromotedTransaction.EnlistDurable(enlistment.ResourceManagerIdentifier, $.$cast(enlistment, $.$stl.System.Transactions.DurableInternalEnlistment), enlistment.SinglePhaseNotification !== null, 0/*EnlistmentOptions.None*/);
                    tx._durableEnlistment.State.ChangeStatePromoted(tx._durableEnlistment, promotedEnlistment);
                }
                return true;
            }
            /*void */ PromoteEnlistmentsAndOutcome(/*InternalTransaction*/ tx)
            {
                /*bool*/ let enlistmentsPromoted = false;
                $.$$.System.Diagnostics.Debug.Assert$2(tx.PromotedTransaction !== null && tx.PromotedTransaction.RealTransaction !== null, "tx.PromotedTransaction != null && tx.PromotedTransaction.RealTransaction != null");
                tx.PromotedTransaction.RealTransaction.InternalTransaction = tx;
                $.$$.System.Diagnostics.Debug.Assert$2(tx.State !== null, "tx.State != null");
                try
                {
                    enlistmentsPromoted = $.$stl.System.Transactions.TransactionStatePromoted.PromotePhaseVolatiles(tx, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase0Volatiles, ($v) => tx._phase0Volatiles = $v, null), true);
                }
                catch(te)
                {
                    tx._innerException = te;
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.ExceptionConsumed(te);
                    }
                    return;
                }
                finally
                {
                    {
                        if (!enlistmentsPromoted)
                        {
                            tx.PromotedTransaction.Rollback();
                            tx.State.ChangeStateAbortedDuringPromotion(tx);
                        }
                    }
                }
                enlistmentsPromoted = false;
                try
                {
                    enlistmentsPromoted = $.$stl.System.Transactions.TransactionStatePromoted.PromotePhaseVolatiles(tx, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase1Volatiles, ($v) => tx._phase1Volatiles = $v, null), false);
                }
                catch(te)
                {
                    tx._innerException = te;
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.ExceptionConsumed(te);
                    }
                    return;
                }
                finally
                {
                    {
                        if (!enlistmentsPromoted)
                        {
                            tx.PromotedTransaction.Rollback();
                            tx.State.ChangeStateAbortedDuringPromotion(tx);
                        }
                    }
                }
                enlistmentsPromoted = false;
                try
                {
                    enlistmentsPromoted = this.PromoteDurable(tx);
                }
                catch(te)
                {
                    tx._innerException = te;
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.ExceptionConsumed(te);
                    }
                    return;
                }
                finally
                {
                    {
                        if (!enlistmentsPromoted)
                        {
                            tx.PromotedTransaction.Rollback();
                            tx.State.ChangeStateAbortedDuringPromotion(tx);
                        }
                    }
                }
            }
            /*void */ DisposeRoot(/*InternalTransaction*/ tx)
            {
                tx.State.Rollback(tx, null);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 6726924;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6923532,"m":[{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"EnterState","d":6726924,"h":4301694220,"f":16809992},{"r":262145,"p":[{"n":"tx","p":2794764},{"n":"volatiles","p":9348364,"f":4},{"n":"phase0","p":262145}],"n":"PromotePhaseVolatiles","d":6726924,"h":8596661516,"f":16777252},{"r":262145,"p":[{"n":"tx","p":2794764}],"n":"PromoteDurable","d":6726924,"h":12891628812,"f":16777352},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"PromoteEnlistmentsAndOutcome","d":6726924,"h":17186596108,"f":16777352},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"DisposeRoot","d":6726924,"h":21481563404,"f":16809992}],"c":[{"n":".ctor","o":"$ctor$3","d":6726924,"h":25776530700,"f":16777217}],"h":6726924}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedBase; }
            static get $fullName() { return `System.Transactions.TransactionStatePromoted`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedP0Wave", ($self) => class TransactionStatePromotedP0Wave extends $.$stl.System.Transactions.TransactionStatePromotedBase
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
            }
            /*void */ BeginCommit(/*InternalTransaction*/ tx, /*bool*/ asyncCommit, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException(tx._innerException, tx.DistributedTxId);
            }
            /*void */ Phase0VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
                try
                {
                    $.$stl.System.Transactions.TransactionState.TransactionStatePromotedCommitting.EnterState(tx);
                }
                catch(e)
                {
                    tx._innerException ??= e;
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.ExceptionConsumed(e);
                    }
                }
            }
            /*bool */ ContinuePhase0Prepares()
            {
                return true;
            }
            /*void */ ChangeStateTransactionAborted(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                tx._innerException ??= e;
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedP0Aborting.EnterState(tx);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 7841036;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6923532,"m":[{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"EnterState","d":7841036,"h":4302808332,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"asyncCommit","p":262145},{"n":"asyncCallback","p":14548993},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":7841036,"h":8597775628,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"Phase0VolatilePrepareDone","d":7841036,"h":12892742924,"f":16809992},{"r":262145,"n":"ContinuePhase0Prepares","d":7841036,"h":17187710220,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"e","p":47251457}],"n":"ChangeStateTransactionAborted","d":7841036,"h":21482677516,"f":16809992}],"c":[{"n":".ctor","o":"$ctor$3","d":7841036,"h":25777644812,"f":16777217}],"h":7841036}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedBase; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedP0Wave`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedCommitting", ($self) => class TransactionStatePromotedCommitting extends $.$stl.System.Transactions.TransactionStatePromotedBase
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                /*OletxCommittableTransaction*/ let ctx = $.$cast(tx.PromotedTransaction, $.$stl.System.Transactions.Oletx.OletxCommittableTransaction);
                ctx.BeginCommit(tx);
            }
            /*void */ BeginCommit(/*InternalTransaction*/ tx, /*bool*/ asyncCommit, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException(tx._innerException, tx.DistributedTxId);
            }
            /*void */ ChangeStatePromotedPhase0(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedPhase0.EnterState(tx);
            }
            /*void */ ChangeStatePromotedPhase1(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedPhase1.EnterState(tx);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 7054604;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6923532,"m":[{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"EnterState","d":7054604,"h":4302021900,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"asyncCommit","p":262145},{"n":"asyncCallback","p":14548993},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":7054604,"h":8596989196,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"ChangeStatePromotedPhase0","d":7054604,"h":12891956492,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"ChangeStatePromotedPhase1","d":7054604,"h":17186923788,"f":16809992}],"c":[{"n":".ctor","o":"$ctor$3","d":7054604,"h":21481891084,"f":16777217}],"h":7054604}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedBase; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedCommitting`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedNonMSDTCPhase0", ($self) => class TransactionStatePromotedNonMSDTCPhase0 extends $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCBase
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                /*int*/ let volatileCount = tx._phase0Volatiles._volatileEnlistmentCount;
                /*int*/ let dependentCount = tx._phase0Volatiles._dependentClones;
                tx._phase0VolatileWaveCount = volatileCount;
                if (tx._phase0Volatiles._preparedVolatileEnlistments < ((volatileCount + dependentCount) | 0))
                {
                    for(/*int*/ let i = 0; i < volatileCount; i++)
                    {
                        $.$$.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i)._twoPhaseState.ChangeStatePreparing($.$$.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i));
                        if (!tx.State.ContinuePhase0Prepares())
                        {
                            break;
                        }
                    }
                }
                else 
                {
                    $.$stl.System.Transactions.TransactionState.TransactionStatePromotedNonMSDTCVolatilePhase1.EnterState(tx);
                }
            }
            /*void */ BeginCommit(/*InternalTransaction*/ tx, /*bool*/ asyncCommit, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException(tx._innerException, tx.DistributedTxId);
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                this.ChangeStateTransactionAborted(tx, e);
            }
            /*void */ Phase0VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
                /*int*/ let volatileCount = tx._phase0Volatiles._volatileEnlistmentCount;
                /*int*/ let dependentCount = tx._phase0Volatiles._dependentClones;
                tx._phase0VolatileWaveCount = volatileCount;
                if (tx._phase0Volatiles._preparedVolatileEnlistments < ((volatileCount + dependentCount) | 0))
                {
                    for(/*int*/ let i = 0; i < volatileCount; i++)
                    {
                        $.$$.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i)._twoPhaseState.ChangeStatePreparing($.$$.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i));
                        if (!tx.State.ContinuePhase0Prepares())
                        {
                            break;
                        }
                    }
                }
                else 
                {
                    $.$stl.System.Transactions.TransactionState.TransactionStatePromotedNonMSDTCVolatilePhase1.EnterState(tx);
                }
            }
            /*void */ Phase1VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            /*bool */ ContinuePhase0Prepares()
            {
                return true;
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 7578892;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7316748,"m":[{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"EnterState","d":7578892,"h":4302546188,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"asyncCommit","p":262145},{"n":"asyncCallback","p":14548993},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":7578892,"h":8597513484,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"e","p":47251457}],"n":"Rollback","d":7578892,"h":12892480780,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"Phase0VolatilePrepareDone","d":7578892,"h":17187448076,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"Phase1VolatilePrepareDone","d":7578892,"h":21482415372,"f":16809992},{"r":262145,"n":"ContinuePhase0Prepares","d":7578892,"h":25777382668,"f":16809992}],"c":[{"n":".ctor","o":"$ctor$3","d":7578892,"h":30072349964,"f":16777217}],"h":7578892}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCBase; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedNonMSDTCPhase0`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedNonMSDTCVolatilePhase1", ($self) => class TransactionStatePromotedNonMSDTCVolatilePhase1 extends $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCBase
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                $.$$.System.Diagnostics.Debug.Assert$2(tx._committableTransaction !== null, "tx._committableTransaction != null");
                tx._committableTransaction._complete = true;
                if (tx._phase1Volatiles._dependentClones !== 0)
                {
                    this.ChangeStateTransactionAborted(tx, null);
                    return;
                }
                if (tx._phase1Volatiles._volatileEnlistmentCount > 0)
                {
                    for(/*int*/ let i = 0; i < tx._phase1Volatiles._volatileEnlistmentCount; i++)
                    {
                        $.$$.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i)._twoPhaseState.ChangeStatePreparing($.$$.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i));
                        if (!tx.State.ContinuePhase1Prepares())
                        {
                            break;
                        }
                    }
                }
                else 
                {
                    $.$stl.System.Transactions.TransactionState.TransactionStatePromotedNonMSDTCSinglePhaseCommit.EnterState(tx);
                }
            }
            /*void */ BeginCommit(/*InternalTransaction*/ tx, /*bool*/ asyncCommit, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException(tx._innerException, tx.DistributedTxId);
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                this.ChangeStateTransactionAborted(tx, e);
            }
            /*void */ Phase1VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedNonMSDTCSinglePhaseCommit.EnterState(tx);
            }
            /*bool */ ContinuePhase1Prepares()
            {
                return true;
            }
            /*Enlistment */ EnlistVolatile(/*InternalTransaction*/ tx, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                throw $.$stl.System.Transactions.TransactionException.Create$2($.$stl.System.SR.TooLate, tx === null ? $.$$.System.Guid.Empty : tx.DistributedTxId);
            }
            /*Enlistment */ EnlistVolatile$1(/*InternalTransaction*/ tx, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                throw $.$stl.System.Transactions.TransactionException.Create$2($.$stl.System.SR.TooLate, tx === null ? $.$$.System.Guid.Empty : tx.DistributedTxId);
            }
            /*bool */ EnlistPromotableSinglePhase(/*InternalTransaction*/ tx, /*IPromotableSinglePhaseNotification*/ promotableSinglePhaseNotification, /*Transaction*/ atomicTransaction, /*Guid*/ promoterType)
            {
                throw $.$stl.System.Transactions.TransactionException.Create$2($.$stl.System.SR.TooLate, tx === null ? $.$$.System.Guid.Empty : tx.DistributedTxId);
            }
            /*void */ CreateBlockingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.Create$2($.$stl.System.SR.TooLate, tx === null ? $.$$.System.Guid.Empty : tx.DistributedTxId);
            }
            /*void */ CreateAbortingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.Create$2($.$stl.System.SR.TooLate, tx === null ? $.$$.System.Guid.Empty : tx.DistributedTxId);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 7709964;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7316748,"m":[{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"EnterState","d":7709964,"h":4302677260,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"asyncCommit","p":262145},{"n":"asyncCallback","p":14548993},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":7709964,"h":8597644556,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"e","p":47251457}],"n":"Rollback","d":7709964,"h":12892611852,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"Phase1VolatilePrepareDone","d":7709964,"h":17187579148,"f":16809992},{"r":262145,"n":"ContinuePhase1Prepares","d":7709964,"h":21482546444,"f":16809992},{"r":1746188,"p":[{"n":"tx","p":2794764},{"n":"enlistmentNotification","p":2598156},{"n":"enlistmentOptions","p":1877260},{"n":"atomicTransaction","p":4302092}],"n":"EnlistVolatile","d":7709964,"h":25777513740,"f":16809992},{"r":1746188,"p":[{"n":"tx","p":2794764},{"n":"enlistmentNotification","p":3056908},{"n":"enlistmentOptions","p":1877260},{"n":"atomicTransaction","p":4302092}],"n":"EnlistVolatile","o":"@$1","d":7709964,"h":30072481036,"f":16809992},{"r":262145,"p":[{"n":"tx","p":2794764},{"n":"promotableSinglePhaseNotification","p":2860300},{"n":"atomicTransaction","p":4302092},{"n":"promoterType","p":56229889}],"n":"EnlistPromotableSinglePhase","d":7709964,"h":34367448332,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"CreateBlockingClone","d":7709964,"h":38662415628,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"CreateAbortingClone","d":7709964,"h":42957382924,"f":16809992}],"c":[{"n":".ctor","o":"$ctor$3","d":7709964,"h":47252350220,"f":16777217}],"h":7709964}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCBase; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedNonMSDTCVolatilePhase1`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedNonMSDTCSinglePhaseCommit", ($self) => class TransactionStatePromotedNonMSDTCSinglePhaseCommit extends $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCBase
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                $.$$.System.Diagnostics.Debug.Assert$2(tx._durableEnlistment !== null, "tx._durableEnlistment != null");
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.EnlistmentStatus(1/*TraceSourceType.TraceSourceLtm*/, tx._durableEnlistment.EnlistmentTraceId, 4/*NotificationCall.SinglePhaseCommit*/);
                }
                $.$stl.System.Transactions.TransactionTable.Remove(tx);
                tx._durableEnlistment.State.ChangeStateCommitting(tx._durableEnlistment);
            }
            /*void */ BeginCommit(/*InternalTransaction*/ tx, /*bool*/ asyncCommit, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException(tx._innerException, tx.DistributedTxId);
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException(tx._innerException, tx.DistributedTxId);
            }
            /*void */ ChangeStateTransactionCommitted(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedNonMSDTCCommitted.EnterState(tx);
            }
            /*void */ InDoubtFromEnlistment(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedNonMSDTCIndoubt.EnterState(tx);
            }
            /*void */ ChangeStateTransactionAborted(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                tx._innerException ??= e;
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedNonMSDTCAborted.EnterState(tx);
            }
            /*void */ ChangeStateAbortedDuringPromotion(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStateAborted.EnterState(tx);
            }
            /*Enlistment */ EnlistVolatile(/*InternalTransaction*/ tx, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                throw $.$stl.System.Transactions.TransactionException.Create$2($.$stl.System.SR.TooLate, tx === null ? $.$$.System.Guid.Empty : tx.DistributedTxId);
            }
            /*Enlistment */ EnlistVolatile$1(/*InternalTransaction*/ tx, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                throw $.$stl.System.Transactions.TransactionException.Create$2($.$stl.System.SR.TooLate, tx === null ? $.$$.System.Guid.Empty : tx.DistributedTxId);
            }
            /*bool */ EnlistPromotableSinglePhase(/*InternalTransaction*/ tx, /*IPromotableSinglePhaseNotification*/ promotableSinglePhaseNotification, /*Transaction*/ atomicTransaction, /*Guid*/ promoterType)
            {
                throw $.$stl.System.Transactions.TransactionException.Create$2($.$stl.System.SR.TooLate, tx === null ? $.$$.System.Guid.Empty : tx.DistributedTxId);
            }
            /*void */ CreateBlockingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.Create$2($.$stl.System.SR.TooLate, tx === null ? $.$$.System.Guid.Empty : tx.DistributedTxId);
            }
            /*void */ CreateAbortingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.Create$2($.$stl.System.SR.TooLate, tx === null ? $.$$.System.Guid.Empty : tx.DistributedTxId);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 7644428;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7316748,"m":[{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"EnterState","d":7644428,"h":4302611724,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"asyncCommit","p":262145},{"n":"asyncCallback","p":14548993},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":7644428,"h":8597579020,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"e","p":47251457}],"n":"Rollback","d":7644428,"h":12892546316,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"ChangeStateTransactionCommitted","d":7644428,"h":17187513612,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"InDoubtFromEnlistment","d":7644428,"h":21482480908,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"e","p":47251457}],"n":"ChangeStateTransactionAborted","d":7644428,"h":25777448204,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"ChangeStateAbortedDuringPromotion","d":7644428,"h":30072415500,"f":16809992},{"r":1746188,"p":[{"n":"tx","p":2794764},{"n":"enlistmentNotification","p":2598156},{"n":"enlistmentOptions","p":1877260},{"n":"atomicTransaction","p":4302092}],"n":"EnlistVolatile","d":7644428,"h":34367382796,"f":16809992},{"r":1746188,"p":[{"n":"tx","p":2794764},{"n":"enlistmentNotification","p":3056908},{"n":"enlistmentOptions","p":1877260},{"n":"atomicTransaction","p":4302092}],"n":"EnlistVolatile","o":"@$1","d":7644428,"h":38662350092,"f":16809992},{"r":262145,"p":[{"n":"tx","p":2794764},{"n":"promotableSinglePhaseNotification","p":2860300},{"n":"atomicTransaction","p":4302092},{"n":"promoterType","p":56229889}],"n":"EnlistPromotableSinglePhase","d":7644428,"h":42957317388,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"CreateBlockingClone","d":7644428,"h":47252284684,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"CreateAbortingClone","d":7644428,"h":51547251980,"f":16809992}],"c":[{"n":".ctor","o":"$ctor$3","d":7644428,"h":55842219276,"f":16777217}],"h":7644428}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCBase; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedNonMSDTCSinglePhaseCommit`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateDelegatedNonMSDTC", ($self) => class TransactionStateDelegatedNonMSDTC extends $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCBase
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                /*OletxTransaction?*/ let distributedTx;
                try
                {
                    if (tx._durableEnlistment !== null)
                    {
                        /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                        if (etwLog.IsEnabled())
                        {
                            etwLog.EnlistmentStatus(1/*TraceSourceType.TraceSourceLtm*/, tx._durableEnlistment.EnlistmentTraceId, 5/*NotificationCall.Promote*/);
                        }
                    }
                    distributedTx = $.$stl.System.Transactions.TransactionState.TransactionStatePSPEOperation.PSPEPromote(tx);
                    $.$$.System.Diagnostics.Debug.Assert$2((distributedTx === null), "PSPEPromote for non-MSDTC promotion returned a distributed transaction.");
                    $.$$.System.Diagnostics.Debug.Assert$2((tx.promotedToken !== null), "PSPEPromote for non-MSDTC promotion did not set InternalTransaction.PromotedToken.");
                }
                catch(e)
                {
                    tx._innerException = e;
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.ExceptionConsumed(e);
                    }
                }
                finally
                {
                    {
                        if (tx.promotedToken === null)
                        {
                            tx.State.ChangeStateAbortedDuringPromotion(tx);
                        }
                    }
                }
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 6268172;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7316748,"m":[{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"EnterState","d":6268172,"h":4301235468,"f":16809992}],"c":[{"n":".ctor","o":"$ctor$3","d":6268172,"h":8596202764,"f":16777217}],"h":6268172}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCBase; }
            static get $fullName() { return `System.Transactions.TransactionStateDelegatedNonMSDTC`; }
        });
        
        $asm.$cls("$stl.System.Transactions.FinishVolatileDelegate", ($self) => class FinishVolatileDelegate extends $.$$.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*void*/ Invoke(/**/ enlistment)
            {
                return this.$nativeFunction.call(this.$target, enlistment);
            }
            static $h = 2401548;
            static $f = 0b10000000;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"Invoke","d":2401548,"h":8592336140,"f":16777345},{"r":57016321,"p":[{"n":"enlistment","p":2729228},{"n":"callback","p":14548993},{"n":"object","p":131073}],"n":"BeginInvoke","d":2401548,"h":12887303436,"f":16777345},{"r":65537,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":2401548,"h":17182270732,"f":16777345}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":2401548,"h":4297368844,"f":16777217}],"i":[57212929,113246209],"h":2401548}; }
            static get $b() { return $.$$.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.ICloneable, $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Transactions.FinishVolatileDelegate`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionCompletedEventHandler", ($self) => class TransactionCompletedEventHandler extends $.$$.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*void*/ Invoke(/*$.$$.System.Nullable$$*/ sender, /**/ e)
            {
                return this.$nativeFunction.call(this.$target, sender, e);
            }
            static $h = 4433164;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":4498700}],"n":"Invoke","d":4433164,"h":8594367756,"f":16777345},{"r":57016321,"p":[{"n":"sender","p":131073},{"n":"e","p":4498700},{"n":"callback","p":14548993},{"n":"object","p":131073}],"n":"BeginInvoke","d":4433164,"h":12889335052,"f":16777345},{"r":65537,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":4433164,"h":17184302348,"f":16777345}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":4433164,"h":4299400460,"f":16777217}],"i":[57212929,113246209],"h":4433164}; }
            static get $b() { return $.$$.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.ICloneable, $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Transactions.TransactionCompletedEventHandler`; }
        });
        
        $asm.$cls("$stl.System.Transactions.HostCurrentTransactionCallback", ($self) => class HostCurrentTransactionCallback extends $.$$.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*Transaction?*/ Invoke()
            {
                return this.$nativeFunction.call(this.$target, );
            }
            static $h = 2467084;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":4302092,"n":"Invoke","d":2467084,"h":8592401676,"f":16777345},{"r":57016321,"p":[{"n":"callback","p":14548993},{"n":"object","p":131073}],"n":"BeginInvoke","d":2467084,"h":12887368972,"f":16777345},{"r":4302092,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":2467084,"h":17182336268,"f":16777345}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":2467084,"h":4297434380,"f":16777217}],"i":[57212929,113246209],"h":2467084}; }
            static get $b() { return $.$$.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.ICloneable, $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Transactions.HostCurrentTransactionCallback`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStartedEventHandler", ($self) => class TransactionStartedEventHandler extends $.$$.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*void*/ Invoke(/*$.$$.System.Nullable$$*/ sender, /**/ e)
            {
                return this.$nativeFunction.call(this.$target, sender, e);
            }
            static $h = 5678348;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":4498700}],"n":"Invoke","d":5678348,"h":8595612940,"f":16777345},{"r":57016321,"p":[{"n":"sender","p":131073},{"n":"e","p":4498700},{"n":"callback","p":14548993},{"n":"object","p":131073}],"n":"BeginInvoke","d":5678348,"h":12890580236,"f":16777345},{"r":65537,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":5678348,"h":17185547532,"f":16777345}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":5678348,"h":4300645644,"f":16777217}],"i":[57212929,113246209],"h":5678348}; }
            static get $b() { return $.$$.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.ICloneable, $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Transactions.TransactionStartedEventHandler`; }
        });
        
        $asm.$str("$stl.System.Transactions.TransactionScopeOption", ($self) => class TransactionScopeOption extends $.$$.System.Enum
        {
            static Required = 0;
            static RequiresNew = 1;
            static Suppress = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Required": 0n,
                    "RequiresNew": 1n,
                    "Suppress": 2n
                };
            }
            static $h = 5285132;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":5285132,"n":"Required","d":5285132,"h":4300252428,"f":4194337},{"t":5285132,"n":"RequiresNew","d":5285132,"h":8595219724,"f":4194337},{"t":5285132,"n":"Suppress","d":5285132,"h":12890187020,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":5285132,"h":17185154316,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":5285132}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Transactions.TransactionScopeOption`; }
        });
        
        $asm.$str("$stl.System.Transactions.TransactionScopeAsyncFlowOption", ($self) => class TransactionScopeAsyncFlowOption extends $.$$.System.Enum
        {
            static Suppress = 0;
            static Enabled = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Suppress": 0n,
                    "Enabled": 1n
                };
            }
            static $h = 5219596;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":5219596,"n":"Suppress","d":5219596,"h":4300186892,"f":4194337},{"t":5219596,"n":"Enabled","d":5219596,"h":8595154188,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":5219596,"h":12890121484,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":5219596}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Transactions.TransactionScopeAsyncFlowOption`; }
        });
        
        $asm.$str("$stl.System.Transactions.IsolationLevel", ($self) => class IsolationLevel extends $.$$.System.Enum
        {
            static Serializable = 0;
            static RepeatableRead = 1;
            static ReadCommitted = 2;
            static ReadUncommitted = 3;
            static Snapshot = 4;
            static Chaos = 5;
            static Unspecified = 6;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Serializable": 0n,
                    "RepeatableRead": 1n,
                    "ReadCommitted": 2n,
                    "ReadUncommitted": 3n,
                    "Snapshot": 4n,
                    "Chaos": 5n,
                    "Unspecified": 6n
                };
            }
            static $h = 3187980;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":3187980,"n":"Serializable","d":3187980,"h":4298155276,"f":4194337},{"t":3187980,"n":"RepeatableRead","d":3187980,"h":8593122572,"f":4194337},{"t":3187980,"n":"ReadCommitted","d":3187980,"h":12888089868,"f":4194337},{"t":3187980,"n":"ReadUncommitted","d":3187980,"h":17183057164,"f":4194337},{"t":3187980,"n":"Snapshot","d":3187980,"h":21478024460,"f":4194337},{"t":3187980,"n":"Chaos","d":3187980,"h":25772991756,"f":4194337},{"t":3187980,"n":"Unspecified","d":3187980,"h":30067959052,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":3187980,"h":34362926348,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":3187980}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Transactions.IsolationLevel`; }
        });
        
        $asm.$str("$stl.System.Transactions.TransactionStatus", ($self) => class TransactionStatus extends $.$$.System.Enum
        {
            static Active = 0;
            static Committed = 1;
            static Aborted = 2;
            static InDoubt = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Active": 0n,
                    "Committed": 1n,
                    "Aborted": 2n,
                    "InDoubt": 3n
                };
            }
            static $h = 8430860;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":8430860,"n":"Active","d":8430860,"h":4303398156,"f":4194337},{"t":8430860,"n":"Committed","d":8430860,"h":8598365452,"f":4194337},{"t":8430860,"n":"Aborted","d":8430860,"h":12893332748,"f":4194337},{"t":8430860,"n":"InDoubt","d":8430860,"h":17188300044,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":8430860,"h":21483267340,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":8430860}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Transactions.TransactionStatus`; }
        });
        
        $asm.$str("$stl.System.Transactions.DependentCloneOption", ($self) => class DependentCloneOption extends $.$$.System.Enum
        {
            static BlockCommitUntilComplete = 0;
            static RollbackIfNotComplete = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "BlockCommitUntilComplete": 0n,
                    "RollbackIfNotComplete": 1n
                };
            }
            static $h = 1090828;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1090828,"n":"BlockCommitUntilComplete","d":1090828,"h":4296058124,"f":4194337},{"t":1090828,"n":"RollbackIfNotComplete","d":1090828,"h":8591025420,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":1090828,"h":12885992716,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":1090828}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Transactions.DependentCloneOption`; }
        });
        
        $asm.$str("$stl.System.Transactions.EnlistmentOptions", ($self) => class EnlistmentOptions extends $.$$.System.Enum
        {
            static None = 0;
            static EnlistDuringPrepareRequired = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "EnlistDuringPrepareRequired": 1n
                };
            }
            static $h = 1877260;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1877260,"n":"None","d":1877260,"h":4296844556,"f":4194337},{"t":1877260,"n":"EnlistDuringPrepareRequired","d":1877260,"h":8591811852,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":1877260,"h":12886779148,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":1877260,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Transactions.EnlistmentOptions`; }
        });
        
        $asm.$str("$stl.System.Transactions.EnterpriseServicesInteropOption", ($self) => class EnterpriseServicesInteropOption extends $.$$.System.Enum
        {
            static None = 0;
            static Automatic = 1;
            static Full = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "Automatic": 1n,
                    "Full": 2n
                };
            }
            static $h = 2270476;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2270476,"n":"None","d":2270476,"h":4297237772,"f":4194337},{"t":2270476,"n":"Automatic","d":2270476,"h":8592205068,"f":4194337},{"t":2270476,"n":"Full","d":2270476,"h":12887172364,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":2270476,"h":17182139660,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":2270476}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Transactions.EnterpriseServicesInteropOption`; }
        });
        
        $asm.$str("$stl.System.Transactions.EnlistmentType", ($self) => class EnlistmentType extends $.$$.System.Enum
        {
            static Volatile = 0;
            static Durable = 1;
            static PromotableSinglePhase = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Volatile": 0n,
                    "Durable": 1n,
                    "PromotableSinglePhase": 2n
                };
            }
            static $h = 2139404;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2139404,"n":"Volatile","d":2139404,"h":4297106700,"f":4194337},{"t":2139404,"n":"Durable","d":2139404,"h":8592073996,"f":4194337},{"t":2139404,"n":"PromotableSinglePhase","d":2139404,"h":12887041292,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":2139404,"h":17182008588,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":2139404}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Transactions.EnlistmentType`; }
        });
        
        $asm.$str("$stl.System.Transactions.NotificationCall", ($self) => class NotificationCall extends $.$$.System.Enum
        {
            static Prepare = 0;
            static Commit = 1;
            static Rollback = 2;
            static InDoubt = 3;
            static SinglePhaseCommit = 4;
            static Promote = 5;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Prepare": 0n,
                    "Commit": 1n,
                    "Rollback": 2n,
                    "InDoubt": 3n,
                    "SinglePhaseCommit": 4n,
                    "Promote": 5n
                };
            }
            static $h = 3319052;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":3319052,"n":"Prepare","d":3319052,"h":4298286348,"f":4194337},{"t":3319052,"n":"Commit","d":3319052,"h":8593253644,"f":4194337},{"t":3319052,"n":"Rollback","d":3319052,"h":12888220940,"f":4194337},{"t":3319052,"n":"InDoubt","d":3319052,"h":17183188236,"f":4194337},{"t":3319052,"n":"SinglePhaseCommit","d":3319052,"h":21478155532,"f":4194337},{"t":3319052,"n":"Promote","d":3319052,"h":25773122828,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":3319052,"h":30068090124,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":3319052}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Transactions.NotificationCall`; }
        });
        
        $asm.$str("$stl.System.Transactions.EnlistmentCallback", ($self) => class EnlistmentCallback extends $.$$.System.Enum
        {
            static Done = 0;
            static Prepared = 1;
            static ForceRollback = 2;
            static Committed = 3;
            static Aborted = 4;
            static InDoubt = 5;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Done": 0n,
                    "Prepared": 1n,
                    "ForceRollback": 2n,
                    "Committed": 3n,
                    "Aborted": 4n,
                    "InDoubt": 5n
                };
            }
            static $h = 1811724;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1811724,"n":"Done","d":1811724,"h":4296779020,"f":4194337},{"t":1811724,"n":"Prepared","d":1811724,"h":8591746316,"f":4194337},{"t":1811724,"n":"ForceRollback","d":1811724,"h":12886713612,"f":4194337},{"t":1811724,"n":"Committed","d":1811724,"h":17181680908,"f":4194337},{"t":1811724,"n":"Aborted","d":1811724,"h":21476648204,"f":4194337},{"t":1811724,"n":"InDoubt","d":1811724,"h":25771615500,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":1811724,"h":30066582796,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":1811724}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Transactions.EnlistmentCallback`; }
        });
        
        $asm.$str("$stl.System.Transactions.TransactionScopeResult", ($self) => class TransactionScopeResult extends $.$$.System.Enum
        {
            static CreatedTransaction = 0;
            static UsingExistingCurrent = 1;
            static TransactionPassed = 2;
            static DependentTransactionPassed = 3;
            static NoTransaction = 4;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "CreatedTransaction": 0n,
                    "UsingExistingCurrent": 1n,
                    "TransactionPassed": 2n,
                    "DependentTransactionPassed": 3n,
                    "NoTransaction": 4n
                };
            }
            static $h = 5350668;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":5350668,"n":"CreatedTransaction","d":5350668,"h":4300317964,"f":4194337},{"t":5350668,"n":"UsingExistingCurrent","d":5350668,"h":8595285260,"f":4194337},{"t":5350668,"n":"TransactionPassed","d":5350668,"h":12890252556,"f":4194337},{"t":5350668,"n":"DependentTransactionPassed","d":5350668,"h":17185219852,"f":4194337},{"t":5350668,"n":"NoTransaction","d":5350668,"h":21480187148,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":5350668,"h":25775154444,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":5350668}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Transactions.TransactionScopeResult`; }
        });
        
        $asm.$str("$stl.System.Transactions.TransactionExceptionType", ($self) => class TransactionExceptionType extends $.$$.System.Enum
        {
            static InvalidOperationException = 0;
            static TransactionAbortedException = 1;
            static TransactionException = 2;
            static TransactionInDoubtException = 3;
            static TransactionManagerCommunicationException = 4;
            static UnrecognizedRecoveryInformation = 5;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "InvalidOperationException": 0n,
                    "TransactionAbortedException": 1n,
                    "TransactionException": 2n,
                    "TransactionInDoubtException": 3n,
                    "TransactionManagerCommunicationException": 4n,
                    "UnrecognizedRecoveryInformation": 5n
                };
            }
            static $h = 4629772;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":4629772,"n":"UnrecognizedRecoveryInformation","d":4629772,"h":25774433548,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":4629772,"h":30069400844,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":4629772}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Transactions.TransactionExceptionType`; }
        });
        
        $asm.$str("$stl.System.Transactions.TraceSourceType", ($self) => class TraceSourceType extends $.$$.System.Enum
        {
            static TraceSourceBase = 0;
            static TraceSourceLtm = 1;
            static TraceSourceOleTx = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "TraceSourceBase": 0n,
                    "TraceSourceLtm": 1n,
                    "TraceSourceOleTx": 2n
                };
            }
            static $h = 4236556;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":4236556,"n":"TraceSourceBase","d":4236556,"h":4299203852,"f":4194337},{"t":4236556,"n":"TraceSourceLtm","d":4236556,"h":8594171148,"f":4194337},{"t":4236556,"n":"TraceSourceOleTx","d":4236556,"h":12889138444,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":4236556,"h":17184105740,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":4236556}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Transactions.TraceSourceType`; }
        });
        
        $asm.$str("$stl.System.Transactions.DefaultComContextState", ($self) => class DefaultComContextState extends $.$$.System.Enum
        {
            static Unknown = 0;
            static Unavailable = -1;
            static Available = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unknown": 0n,
                    "Unavailable": -1n,
                    "Available": 1n
                };
            }
            static $h = 1025292;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1025292,"n":"Unknown","d":1025292,"h":4295992588,"f":4194337},{"t":1025292,"n":"Unavailable","d":1025292,"h":8590959884,"f":4194337},{"t":1025292,"n":"Available","d":1025292,"h":12885927180,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":1025292,"h":17180894476,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":1025292}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Transactions.DefaultComContextState`; }
        });
        
        $asm.$str("$stl.System.Transactions.TxLookup", ($self) => class TxLookup extends $.$$.System.Enum
        {
            static Default = 0;
            static DefaultCallContext = 1;
            static DefaultTLS = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Default": 0n,
                    "DefaultCallContext": 1n,
                    "DefaultTLS": 2n
                };
            }
            static $h = 8627468;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":8627468,"n":"Default","d":8627468,"h":4303594764,"f":4194337},{"t":8627468,"n":"DefaultCallContext","d":8627468,"h":8598562060,"f":4194337},{"t":8627468,"n":"DefaultTLS","d":8627468,"h":12893529356,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":8627468,"h":17188496652,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":8627468}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Transactions.TxLookup`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateActive", ($self) => class TransactionStateActive extends $.$stl.System.Transactions.EnlistableStates
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
            }
            /*void */ BeginCommit(/*InternalTransaction*/ tx, /*bool*/ asyncCommit, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                tx._asyncCommit = asyncCommit;
                tx._asyncCallback = asyncCallback;
                tx._asyncState = asyncState;
                $.$stl.System.Transactions.TransactionState.TransactionStatePhase0.EnterState(tx);
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                tx._innerException ??= e;
                $.$stl.System.Transactions.TransactionState.TransactionStateAborted.EnterState(tx);
            }
            /*Enlistment */ EnlistVolatile(/*InternalTransaction*/ tx, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                /*Enlistment*/ let enlistment = new $.$stl.System.Transactions.Enlistment().$ctor$5(tx, enlistmentNotification, null, atomicTransaction, enlistmentOptions);
                if ((enlistmentOptions & 1/*EnlistmentOptions.EnlistDuringPrepareRequired*/) !== 0)
                {
                    $.$stl.System.Transactions.TransactionState.AddVolatileEnlistment($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase0Volatiles, ($v) => tx._phase0Volatiles = $v, null), enlistment);
                }
                else 
                {
                    $.$stl.System.Transactions.TransactionState.AddVolatileEnlistment($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase1Volatiles, ($v) => tx._phase1Volatiles = $v, null), enlistment);
                }
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionstateEnlist$1(enlistment.InternalEnlistment.EnlistmentTraceId, 0/*EnlistmentType.Volatile*/, enlistmentOptions);
                }
                return enlistment;
            }
            /*Enlistment */ EnlistVolatile$1(/*InternalTransaction*/ tx, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                /*Enlistment*/ let enlistment = new $.$stl.System.Transactions.Enlistment().$ctor$5(tx, enlistmentNotification, enlistmentNotification, atomicTransaction, enlistmentOptions);
                if ((enlistmentOptions & 1/*EnlistmentOptions.EnlistDuringPrepareRequired*/) !== 0)
                {
                    $.$stl.System.Transactions.TransactionState.AddVolatileEnlistment($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase0Volatiles, ($v) => tx._phase0Volatiles = $v, null), enlistment);
                }
                else 
                {
                    $.$stl.System.Transactions.TransactionState.AddVolatileEnlistment($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase1Volatiles, ($v) => tx._phase1Volatiles = $v, null), enlistment);
                }
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionstateEnlist$1(enlistment.InternalEnlistment.EnlistmentTraceId, 0/*EnlistmentType.Volatile*/, enlistmentOptions);
                }
                return enlistment;
            }
            /*bool */ EnlistPromotableSinglePhase(/*InternalTransaction*/ tx, /*IPromotableSinglePhaseNotification*/ promotableSinglePhaseNotification, /*Transaction*/ atomicTransaction, /*Guid*/ promoterType)
            {
                if (tx._durableEnlistment !== null)
                {
                    return false;
                }
                $.$stl.System.Transactions.TransactionState.TransactionStatePSPEOperation.PSPEInitialize(tx, promotableSinglePhaseNotification, promoterType);
                /*Enlistment*/ let en = new $.$stl.System.Transactions.Enlistment().$ctor$6(tx, promotableSinglePhaseNotification, atomicTransaction);
                tx._durableEnlistment = en.InternalEnlistment;
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionstateEnlist$1(tx._durableEnlistment.EnlistmentTraceId, 2/*EnlistmentType.PromotableSinglePhase*/, 0/*EnlistmentOptions.None*/);
                }
                tx._promoter = promotableSinglePhaseNotification;
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Guid.op_Inequality(tx._promoterType, $.$$.System.Guid.Empty), "InternalTransaction.PromoterType was not set in PSPEInitialize");
                if ($.$$.System.Guid.op_Equality(tx._promoterType, $.$stl.System.Transactions.TransactionInterop.PromoterTypeDtc))
                {
                    tx._promoteState = $.$stl.System.Transactions.TransactionState.TransactionStateDelegated;
                }
                else 
                {
                    tx._promoteState = $.$stl.System.Transactions.TransactionState.TransactionStateDelegatedNonMSDTC;
                }
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentActive.EnterState(tx._durableEnlistment);
                return true;
            }
            /*void */ Phase0VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ Phase1VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ DisposeRoot(/*InternalTransaction*/ tx)
            {
                tx.State.Rollback(tx, null);
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 5874956;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1680652,"m":[{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"EnterState","d":5874956,"h":4300842252,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"asyncCommit","p":262145},{"n":"asyncCallback","p":14548993},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":5874956,"h":8595809548,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"e","p":47251457}],"n":"Rollback","d":5874956,"h":12890776844,"f":16809992},{"r":1746188,"p":[{"n":"tx","p":2794764},{"n":"enlistmentNotification","p":2598156},{"n":"enlistmentOptions","p":1877260},{"n":"atomicTransaction","p":4302092}],"n":"EnlistVolatile","d":5874956,"h":17185744140,"f":16809992},{"r":1746188,"p":[{"n":"tx","p":2794764},{"n":"enlistmentNotification","p":3056908},{"n":"enlistmentOptions","p":1877260},{"n":"atomicTransaction","p":4302092}],"n":"EnlistVolatile","o":"@$1","d":5874956,"h":21480711436,"f":16809992},{"r":262145,"p":[{"n":"tx","p":2794764},{"n":"promotableSinglePhaseNotification","p":2860300},{"n":"atomicTransaction","p":4302092},{"n":"promoterType","p":56229889}],"n":"EnlistPromotableSinglePhase","d":5874956,"h":25775678732,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"Phase0VolatilePrepareDone","d":5874956,"h":30070646028,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"Phase1VolatilePrepareDone","d":5874956,"h":34365613324,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"DisposeRoot","d":5874956,"h":38660580620,"f":16809992}],"c":[{"n":".ctor","o":"$ctor$4","d":5874956,"h":42955547916,"f":16777217}],"h":5874956}; }
            static get $b() { return $.$stl.System.Transactions.EnlistableStates; }
            static get $fullName() { return `System.Transactions.TransactionStateActive`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePhase0", ($self) => class TransactionStatePhase0 extends $.$stl.System.Transactions.EnlistableStates
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                /*int*/ let volatileCount = tx._phase0Volatiles._volatileEnlistmentCount;
                /*int*/ let dependentCount = tx._phase0Volatiles._dependentClones;
                tx._phase0VolatileWaveCount = volatileCount;
                if (tx._phase0Volatiles._preparedVolatileEnlistments < ((volatileCount + dependentCount) | 0))
                {
                    for(/*int*/ let i = 0; i < volatileCount; i++)
                    {
                        $.$$.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i)._twoPhaseState.ChangeStatePreparing($.$$.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i));
                        if (!tx.State.ContinuePhase0Prepares())
                        {
                            break;
                        }
                    }
                }
                else 
                {
                    $.$stl.System.Transactions.TransactionState.TransactionStateVolatilePhase1.EnterState(tx);
                }
            }
            /*Enlistment */ EnlistDurable(/*InternalTransaction*/ tx, /*Guid*/ resourceManagerIdentifier, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                tx.ThrowIfPromoterTypeIsNotMSDTC();
                /*Enlistment*/ let en = super.EnlistDurable(tx, resourceManagerIdentifier, enlistmentNotification, enlistmentOptions, atomicTransaction);
                tx.State.RestartCommitIfNeeded(tx);
                return en;
            }
            /*Enlistment */ EnlistDurable$1(/*InternalTransaction*/ tx, /*Guid*/ resourceManagerIdentifier, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                tx.ThrowIfPromoterTypeIsNotMSDTC();
                /*Enlistment*/ let en = super.EnlistDurable$1(tx, resourceManagerIdentifier, enlistmentNotification, enlistmentOptions, atomicTransaction);
                tx.State.RestartCommitIfNeeded(tx);
                return en;
            }
            /*Enlistment */ EnlistVolatile(/*InternalTransaction*/ tx, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                /*Enlistment*/ let enlistment = new $.$stl.System.Transactions.Enlistment().$ctor$5(tx, enlistmentNotification, null, atomicTransaction, enlistmentOptions);
                if ((enlistmentOptions & 1/*EnlistmentOptions.EnlistDuringPrepareRequired*/) !== 0)
                {
                    $.$stl.System.Transactions.TransactionState.AddVolatileEnlistment($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase0Volatiles, ($v) => tx._phase0Volatiles = $v, null), enlistment);
                }
                else 
                {
                    $.$stl.System.Transactions.TransactionState.AddVolatileEnlistment($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase1Volatiles, ($v) => tx._phase1Volatiles = $v, null), enlistment);
                }
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionstateEnlist$1(enlistment.InternalEnlistment.EnlistmentTraceId, 0/*EnlistmentType.Volatile*/, enlistmentOptions);
                }
                return enlistment;
            }
            /*Enlistment */ EnlistVolatile$1(/*InternalTransaction*/ tx, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                /*Enlistment*/ let enlistment = new $.$stl.System.Transactions.Enlistment().$ctor$5(tx, enlistmentNotification, enlistmentNotification, atomicTransaction, enlistmentOptions);
                if ((enlistmentOptions & 1/*EnlistmentOptions.EnlistDuringPrepareRequired*/) !== 0)
                {
                    $.$stl.System.Transactions.TransactionState.AddVolatileEnlistment($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase0Volatiles, ($v) => tx._phase0Volatiles = $v, null), enlistment);
                }
                else 
                {
                    $.$stl.System.Transactions.TransactionState.AddVolatileEnlistment($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase1Volatiles, ($v) => tx._phase1Volatiles = $v, null), enlistment);
                }
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionstateEnlist$1(enlistment.InternalEnlistment.EnlistmentTraceId, 0/*EnlistmentType.Volatile*/, enlistmentOptions);
                }
                return enlistment;
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                this.ChangeStateTransactionAborted(tx, e);
            }
            /*bool */ EnlistPromotableSinglePhase(/*InternalTransaction*/ tx, /*IPromotableSinglePhaseNotification*/ promotableSinglePhaseNotification, /*Transaction*/ atomicTransaction, /*Guid*/ promoterType)
            {
                if (tx._durableEnlistment !== null)
                {
                    return false;
                }
                $.$stl.System.Transactions.TransactionState.TransactionStatePSPEOperation.Phase0PSPEInitialize(tx, promotableSinglePhaseNotification, promoterType);
                /*Enlistment*/ let en = new $.$stl.System.Transactions.Enlistment().$ctor$6(tx, promotableSinglePhaseNotification, atomicTransaction);
                tx._durableEnlistment = en.InternalEnlistment;
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionstateEnlist$1(tx._durableEnlistment.EnlistmentTraceId, 2/*EnlistmentType.PromotableSinglePhase*/, 0/*EnlistmentOptions.None*/);
                }
                tx._promoter = promotableSinglePhaseNotification;
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Guid.op_Inequality(tx._promoterType, $.$$.System.Guid.Empty), "InternalTransaction.PromoterType was not set in Phase0PSPEInitialize");
                if ($.$$.System.Guid.op_Equality(tx._promoterType, $.$stl.System.Transactions.TransactionInterop.PromoterTypeDtc))
                {
                    tx._promoteState = $.$stl.System.Transactions.TransactionState.TransactionStateDelegated;
                }
                else 
                {
                    tx._promoteState = $.$stl.System.Transactions.TransactionState.TransactionStateDelegatedNonMSDTC;
                }
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentActive.EnterState(tx._durableEnlistment);
                return true;
            }
            /*void */ Phase0VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
                /*int*/ let volatileCount = tx._phase0Volatiles._volatileEnlistmentCount;
                /*int*/ let dependentCount = tx._phase0Volatiles._dependentClones;
                tx._phase0VolatileWaveCount = volatileCount;
                if (tx._phase0Volatiles._preparedVolatileEnlistments < ((volatileCount + dependentCount) | 0))
                {
                    for(/*int*/ let i = 0; i < volatileCount; i++)
                    {
                        $.$$.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i)._twoPhaseState.ChangeStatePreparing($.$$.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i));
                        if (!tx.State.ContinuePhase0Prepares())
                        {
                            break;
                        }
                    }
                }
                else 
                {
                    $.$stl.System.Transactions.TransactionState.TransactionStateVolatilePhase1.EnterState(tx);
                }
            }
            /*void */ Phase1VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ RestartCommitIfNeeded(/*InternalTransaction*/ tx)
            {
            }
            /*bool */ ContinuePhase0Prepares()
            {
                return true;
            }
            /*void */ Promote(/*InternalTransaction*/ tx)
            {
                tx._promoteState.EnterState(tx);
                tx.State.CheckForFinishedTransaction(tx);
                tx.State.RestartCommitIfNeeded(tx);
            }
            /*void */ ChangeStateTransactionAborted(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                tx._innerException ??= e;
                $.$stl.System.Transactions.TransactionState.TransactionStateAborted.EnterState(tx);
            }
            /*void */ GetObjectData(/*InternalTransaction*/ tx, /*SerializationInfo*/ serializationInfo, /*StreamingContext*/ context)
            {
                tx.ThrowIfPromoterTypeIsNotMSDTC();
                tx._promoteState.EnterState(tx);
                tx.State.GetObjectData(tx, serializationInfo, context);
                tx.State.RestartCommitIfNeeded(tx);
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 6661388;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1680652,"m":[{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"EnterState","d":6661388,"h":4301628684,"f":16809992},{"r":1746188,"p":[{"n":"tx","p":2794764},{"n":"resourceManagerIdentifier","p":56229889},{"n":"enlistmentNotification","p":2598156},{"n":"enlistmentOptions","p":1877260},{"n":"atomicTransaction","p":4302092}],"n":"EnlistDurable","d":6661388,"h":8596595980,"f":16809992},{"r":1746188,"p":[{"n":"tx","p":2794764},{"n":"resourceManagerIdentifier","p":56229889},{"n":"enlistmentNotification","p":3056908},{"n":"enlistmentOptions","p":1877260},{"n":"atomicTransaction","p":4302092}],"n":"EnlistDurable","o":"@$1","d":6661388,"h":12891563276,"f":16809992},{"r":1746188,"p":[{"n":"tx","p":2794764},{"n":"enlistmentNotification","p":2598156},{"n":"enlistmentOptions","p":1877260},{"n":"atomicTransaction","p":4302092}],"n":"EnlistVolatile","d":6661388,"h":17186530572,"f":16809992},{"r":1746188,"p":[{"n":"tx","p":2794764},{"n":"enlistmentNotification","p":3056908},{"n":"enlistmentOptions","p":1877260},{"n":"atomicTransaction","p":4302092}],"n":"EnlistVolatile","o":"@$1","d":6661388,"h":21481497868,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"e","p":47251457}],"n":"Rollback","d":6661388,"h":25776465164,"f":16809992},{"r":262145,"p":[{"n":"tx","p":2794764},{"n":"promotableSinglePhaseNotification","p":2860300},{"n":"atomicTransaction","p":4302092},{"n":"promoterType","p":56229889}],"n":"EnlistPromotableSinglePhase","d":6661388,"h":30071432460,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"Phase0VolatilePrepareDone","d":6661388,"h":34366399756,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"Phase1VolatilePrepareDone","d":6661388,"h":38661367052,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"RestartCommitIfNeeded","d":6661388,"h":42956334348,"f":16809992},{"r":262145,"n":"ContinuePhase0Prepares","d":6661388,"h":47251301644,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"Promote","d":6661388,"h":51546268940,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"e","p":47251457}],"n":"ChangeStateTransactionAborted","d":6661388,"h":55841236236,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"serializationInfo","p":113836033},{"n":"context","p":113967105}],"n":"GetObjectData","d":6661388,"h":60136203532,"f":16809992}],"c":[{"n":".ctor","o":"$ctor$4","d":6661388,"h":64431170828,"f":16777217}],"h":6661388}; }
            static get $b() { return $.$stl.System.Transactions.EnlistableStates; }
            static get $fullName() { return `System.Transactions.TransactionStatePhase0`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedP0Aborting", ($self) => class TransactionStatePromotedP0Aborting extends $.$stl.System.Transactions.TransactionStatePromotedAborting
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                this.ChangeStatePromotedAborted(tx);
                if (tx._phase0Volatiles.VolatileDemux._preparingEnlistment !== null)
                {
                    $.$$.System.Threading.Monitor.Exit(tx);
                    try
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(tx._phase0Volatiles.VolatileDemux._promotedEnlistment !== null, "tx._phase0Volatiles.VolatileDemux._promotedEnlistment != null");
                        tx._phase0Volatiles.VolatileDemux._promotedEnlistment.System$Transactions$IPromotedEnlistment$ForceRollback();
                    }
                    finally
                    {
                        {
                            $.$$.System.Threading.Monitor.Enter$1(tx);
                        }
                    }
                }
                else 
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(tx.PromotedTransaction !== null, "tx.PromotedTransaction != null");
                    tx.PromotedTransaction.Rollback();
                }
            }
            /*void */ Phase0VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 7775500;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6857996,"m":[{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"EnterState","d":7775500,"h":4302742796,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"Phase0VolatilePrepareDone","d":7775500,"h":8597710092,"f":16809992}],"c":[{"n":".ctor","o":"$ctor$4","d":7775500,"h":12892677388,"f":16777217}],"h":7775500}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedAborting; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedP0Aborting`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedP1Aborting", ($self) => class TransactionStatePromotedP1Aborting extends $.$stl.System.Transactions.TransactionStatePromotedAborting
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                $.$$.System.Diagnostics.Debug.Assert$2(tx._phase1Volatiles.VolatileDemux !== null, "Volatile Demux must exist.");
                this.ChangeStatePromotedAborted(tx);
                $.$$.System.Threading.Monitor.Exit(tx);
                try
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(tx._phase1Volatiles.VolatileDemux._promotedEnlistment !== null, "tx._phase1Volatiles.VolatileDemux._promotedEnlistment != null");
                    tx._phase1Volatiles.VolatileDemux._promotedEnlistment.System$Transactions$IPromotedEnlistment$ForceRollback();
                }
                finally
                {
                    {
                        $.$$.System.Threading.Monitor.Enter$1(tx);
                    }
                }
            }
            /*void */ Phase1VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 7906572;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6857996,"m":[{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"EnterState","d":7906572,"h":4302873868,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"Phase1VolatilePrepareDone","d":7906572,"h":8597841164,"f":16809992}],"c":[{"n":".ctor","o":"$ctor$4","d":7906572,"h":12892808460,"f":16777217}],"h":7906572}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedAborting; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedP1Aborting`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedAborted", ($self) => class TransactionStatePromotedAborted extends $.$stl.System.Transactions.TransactionStatePromotedEnded
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                super.EnterState(tx);
                if (tx._phase1Volatiles.VolatileDemux !== null)
                {
                    $.$stl.System.Transactions.VolatileDemultiplexer.BroadcastRollback($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase1Volatiles, ($v) => tx._phase1Volatiles = $v, null));
                }
                if (tx._phase0Volatiles.VolatileDemux !== null)
                {
                    $.$stl.System.Transactions.VolatileDemultiplexer.BroadcastRollback($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase0Volatiles, ($v) => tx._phase0Volatiles = $v, null));
                }
                tx.FireCompletion();
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionAborted(1/*TraceSourceType.TraceSourceLtm*/, tx.TransactionTraceId);
                }
            }
            /*TransactionStatus */ get_Status(/*InternalTransaction*/ tx)
            {
                return 2/*TransactionStatus.Aborted*/;
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
            }
            /*void */ BeginCommit(/*InternalTransaction*/ tx, /*bool*/ asyncCommit, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw $.$stl.System.Transactions.TransactionAbortedException.Create$3($.$stl.System.SR.TransactionAborted, tx._innerException, tx.DistributedTxId);
            }
            /*void */ CreateBlockingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionAbortedException.Create$3($.$stl.System.SR.TransactionAborted, tx._innerException, tx.DistributedTxId);
            }
            /*void */ CreateAbortingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionAbortedException.Create$3($.$stl.System.SR.TransactionAborted, tx._innerException, tx.DistributedTxId);
            }
            /*void */ RestartCommitIfNeeded(/*InternalTransaction*/ tx)
            {
            }
            /*void */ Phase0VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ Phase1VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ ChangeStatePromotedPhase0(/*InternalTransaction*/ tx)
            {
                throw new $.$stl.System.Transactions.TransactionAbortedException().$ctor$14(tx._innerException, tx.DistributedTxId);
            }
            /*void */ ChangeStatePromotedPhase1(/*InternalTransaction*/ tx)
            {
                throw new $.$stl.System.Transactions.TransactionAbortedException().$ctor$14(tx._innerException, tx.DistributedTxId);
            }
            /*void */ ChangeStatePromotedAborted(/*InternalTransaction*/ tx)
            {
            }
            /*void */ ChangeStateTransactionAborted(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
            }
            /*void */ PromotedTransactionOutcome(/*InternalTransaction*/ tx)
            {
                if ((null === tx._innerException) && (null !== tx.PromotedTransaction))
                {
                    tx._innerException = tx.PromotedTransaction.InnerException;
                }
                throw $.$stl.System.Transactions.TransactionAbortedException.Create$3($.$stl.System.SR.TransactionAborted, tx._innerException, tx.DistributedTxId);
            }
            /*void */ CheckForFinishedTransaction(/*InternalTransaction*/ tx)
            {
                throw new $.$stl.System.Transactions.TransactionAbortedException().$ctor$14(tx._innerException, tx.DistributedTxId);
            }
            /*void */ GetObjectData(/*InternalTransaction*/ tx, /*SerializationInfo*/ serializationInfo, /*StreamingContext*/ context)
            {
                throw $.$stl.System.Transactions.TransactionAbortedException.Create$3($.$stl.System.SR.TransactionAborted, tx._innerException, tx.DistributedTxId);
            }
            /*void */ InDoubtFromDtc(/*InternalTransaction*/ tx)
            {
            }
            /*void */ InDoubtFromEnlistment(/*InternalTransaction*/ tx)
            {
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 6792460;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7120140,"m":[{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"EnterState","d":6792460,"h":4301759756,"f":16809992},{"r":8430860,"p":[{"n":"tx","p":2794764}],"n":"get_Status","d":6792460,"h":8596727052,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"e","p":47251457}],"n":"Rollback","d":6792460,"h":12891694348,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"asyncCommit","p":262145},{"n":"asyncCallback","p":14548993},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":6792460,"h":17186661644,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"CreateBlockingClone","d":6792460,"h":21481628940,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"CreateAbortingClone","d":6792460,"h":25776596236,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"RestartCommitIfNeeded","d":6792460,"h":30071563532,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"Phase0VolatilePrepareDone","d":6792460,"h":34366530828,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"Phase1VolatilePrepareDone","d":6792460,"h":38661498124,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"ChangeStatePromotedPhase0","d":6792460,"h":42956465420,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"ChangeStatePromotedPhase1","d":6792460,"h":47251432716,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"ChangeStatePromotedAborted","d":6792460,"h":51546400012,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"e","p":47251457}],"n":"ChangeStateTransactionAborted","d":6792460,"h":55841367308,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"PromotedTransactionOutcome","d":6792460,"h":60136334604,"f":16809988},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"CheckForFinishedTransaction","d":6792460,"h":64431301900,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"serializationInfo","p":113836033},{"n":"context","p":113967105}],"n":"GetObjectData","d":6792460,"h":68726269196,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"InDoubtFromDtc","d":6792460,"h":73021236492,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"InDoubtFromEnlistment","d":6792460,"h":77316203788,"f":16809992}],"c":[{"n":".ctor","o":"$ctor$4","d":6792460,"h":81611171084,"f":16777217}],"h":6792460}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedEnded; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedAborted`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedCommitted", ($self) => class TransactionStatePromotedCommitted extends $.$stl.System.Transactions.TransactionStatePromotedEnded
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                super.EnterState(tx);
                if (tx._phase1Volatiles.VolatileDemux !== null)
                {
                    $.$stl.System.Transactions.VolatileDemultiplexer.BroadcastCommitted($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase1Volatiles, ($v) => tx._phase1Volatiles = $v, null));
                }
                if (tx._phase0Volatiles.VolatileDemux !== null)
                {
                    $.$stl.System.Transactions.VolatileDemultiplexer.BroadcastCommitted($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase0Volatiles, ($v) => tx._phase0Volatiles = $v, null));
                }
                tx.FireCompletion();
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionCommitted(1/*TraceSourceType.TraceSourceLtm*/, tx.TransactionTraceId);
                }
            }
            /*TransactionStatus */ get_Status(/*InternalTransaction*/ tx)
            {
                return 1/*TransactionStatus.Committed*/;
            }
            /*void */ ChangeStatePromotedCommitted(/*InternalTransaction*/ tx)
            {
            }
            /*void */ PromotedTransactionOutcome(/*InternalTransaction*/ tx)
            {
            }
            /*void */ InDoubtFromDtc(/*InternalTransaction*/ tx)
            {
            }
            /*void */ InDoubtFromEnlistment(/*InternalTransaction*/ tx)
            {
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 6989068;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7120140,"m":[{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"EnterState","d":6989068,"h":4301956364,"f":16809992},{"r":8430860,"p":[{"n":"tx","p":2794764}],"n":"get_Status","d":6989068,"h":8596923660,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"ChangeStatePromotedCommitted","d":6989068,"h":12891890956,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"PromotedTransactionOutcome","d":6989068,"h":17186858252,"f":16809988},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"InDoubtFromDtc","d":6989068,"h":21481825548,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"InDoubtFromEnlistment","d":6989068,"h":25776792844,"f":16809992}],"c":[{"n":".ctor","o":"$ctor$4","d":6989068,"h":30071760140,"f":16777217}],"h":6989068}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedEnded; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedCommitted`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedIndoubt", ($self) => class TransactionStatePromotedIndoubt extends $.$stl.System.Transactions.TransactionStatePromotedEnded
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                super.EnterState(tx);
                if (tx._phase1Volatiles.VolatileDemux !== null)
                {
                    $.$stl.System.Transactions.VolatileDemultiplexer.BroadcastInDoubt($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase1Volatiles, ($v) => tx._phase1Volatiles = $v, null));
                }
                if (tx._phase0Volatiles.VolatileDemux !== null)
                {
                    $.$stl.System.Transactions.VolatileDemultiplexer.BroadcastInDoubt($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase0Volatiles, ($v) => tx._phase0Volatiles = $v, null));
                }
                tx.FireCompletion();
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionInDoubt(1/*TraceSourceType.TraceSourceLtm*/, tx.TransactionTraceId);
                }
            }
            /*TransactionStatus */ get_Status(/*InternalTransaction*/ tx)
            {
                return 3/*TransactionStatus.InDoubt*/;
            }
            /*void */ RestartCommitIfNeeded(/*InternalTransaction*/ tx)
            {
            }
            /*void */ ChangeStatePromotedPhase0(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionInDoubtException.Create$3(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionIndoubt, tx._innerException, tx.DistributedTxId);
            }
            /*void */ ChangeStatePromotedPhase1(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionInDoubtException.Create$3(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionIndoubt, tx._innerException, tx.DistributedTxId);
            }
            /*void */ InDoubtFromDtc(/*InternalTransaction*/ tx)
            {
            }
            /*void */ InDoubtFromEnlistment(/*InternalTransaction*/ tx)
            {
            }
            /*void */ PromotedTransactionOutcome(/*InternalTransaction*/ tx)
            {
                if ((null === tx._innerException) && (null !== tx.PromotedTransaction))
                {
                    tx._innerException = tx.PromotedTransaction.InnerException;
                }
                throw $.$stl.System.Transactions.TransactionInDoubtException.Create$3(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionIndoubt, tx._innerException, tx.DistributedTxId);
            }
            /*void */ CheckForFinishedTransaction(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionInDoubtException.Create$3(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionIndoubt, tx._innerException, tx.DistributedTxId);
            }
            /*void */ GetObjectData(/*InternalTransaction*/ tx, /*SerializationInfo*/ serializationInfo, /*StreamingContext*/ context)
            {
                throw $.$stl.System.Transactions.TransactionInDoubtException.Create$3(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionIndoubt, tx._innerException, tx.DistributedTxId);
            }
            /*void */ ChangeStatePromotedAborted(/*InternalTransaction*/ tx)
            {
            }
            /*void */ ChangeStatePromotedCommitted(/*InternalTransaction*/ tx)
            {
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 7185676;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7120140,"m":[{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"EnterState","d":7185676,"h":4302152972,"f":16809992},{"r":8430860,"p":[{"n":"tx","p":2794764}],"n":"get_Status","d":7185676,"h":8597120268,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"RestartCommitIfNeeded","d":7185676,"h":12892087564,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"ChangeStatePromotedPhase0","d":7185676,"h":17187054860,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"ChangeStatePromotedPhase1","d":7185676,"h":21482022156,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"InDoubtFromDtc","d":7185676,"h":25776989452,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"InDoubtFromEnlistment","d":7185676,"h":30071956748,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"PromotedTransactionOutcome","d":7185676,"h":34366924044,"f":16809988},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"CheckForFinishedTransaction","d":7185676,"h":38661891340,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"serializationInfo","p":113836033},{"n":"context","p":113967105}],"n":"GetObjectData","d":7185676,"h":42956858636,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"ChangeStatePromotedAborted","d":7185676,"h":47251825932,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"ChangeStatePromotedCommitted","d":7185676,"h":51546793228,"f":16809992}],"c":[{"n":".ctor","o":"$ctor$4","d":7185676,"h":55841760524,"f":16777217}],"h":7185676}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedEnded; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedIndoubt`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateDelegatedBase", ($self) => class TransactionStateDelegatedBase extends $.$stl.System.Transactions.TransactionStatePromoted
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                if (tx._outcomeSource._isoLevel === 4/*IsolationLevel.Snapshot*/)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.CannotPromoteSnapshot, null, tx.DistributedTxId);
                }
                this.CommonEnterState(tx);
                /*Oletx.OletxTransaction?*/ let distributedTx = null;
                try
                {
                    if (tx._durableEnlistment !== null)
                    {
                        /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                        if (etwLog.IsEnabled())
                        {
                            etwLog.EnlistmentStatus(1/*TraceSourceType.TraceSourceLtm*/, tx._durableEnlistment.EnlistmentTraceId, 5/*NotificationCall.Promote*/);
                        }
                    }
                    distributedTx = $.$stl.System.Transactions.TransactionState.TransactionStatePSPEOperation.PSPEPromote(tx);
                }
                catch(e)
                {
                    tx._innerException = e;
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.ExceptionConsumed(e);
                    }
                }
                finally
                {
                    {
                        if ((distributedTx) === null)
                        {
                            tx.State.ChangeStateAbortedDuringPromotion(tx);
                        }
                    }
                }
                if ((distributedTx) === null)
                {
                    return;
                }
                if (tx.PromotedTransaction !== distributedTx)
                {
                    tx.PromotedTransaction = distributedTx;
                    /*Hashtable*/ let promotedTransactionTable = $.$stl.System.Transactions.TransactionManager.PromotedTransactionTable;
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1(promotedTransactionTable)
                        {
                            tx._finalizedObject = new $.$stl.System.Transactions.FinalizedObject().$ctor$1(tx, tx.PromotedTransaction.Identifier);
                            /*WeakReference*/ let weakRef = new $.$$.System.WeakReference().$ctor$1(tx._outcomeSource, false);
                            promotedTransactionTable.set_Item(tx.PromotedTransaction.Identifier, weakRef);
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit(promotedTransactionTable)
                    }
                    $.$stl.System.Transactions.TransactionManager.FireDistributedTransactionStarted(tx._outcomeSource);
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.TransactionPromoted$1(tx.TransactionTraceId, distributedTx.TransactionTraceId);
                    }
                    this.PromoteEnlistmentsAndOutcome(tx);
                }
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 6137100;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6726924,"m":[{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"EnterState","d":6137100,"h":4301104396,"f":16809992}],"c":[{"n":".ctor","o":"$ctor$4","d":6137100,"h":8596071692,"f":16777220}],"h":6137100}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromoted; }
            static get $fullName() { return `System.Transactions.TransactionStateDelegatedBase`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedNonMSDTCAborted", ($self) => class TransactionStatePromotedNonMSDTCAborted extends $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCEnded
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                super.EnterState(tx);
                for(/*int*/ let i = 0; i < tx._phase0Volatiles._volatileEnlistmentCount; i++)
                {
                    $.$$.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i)._twoPhaseState.InternalAborted($.$$.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i));
                }
                for(/*int*/ let i = 0; i < tx._phase1Volatiles._volatileEnlistmentCount; i++)
                {
                    $.$$.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i)._twoPhaseState.InternalAborted($.$$.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i));
                }
                tx._durableEnlistment?.State.InternalAborted(tx._durableEnlistment);
                tx.FireCompletion();
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionAborted(1/*TraceSourceType.TraceSourceLtm*/, tx.TransactionTraceId);
                }
            }
            /*TransactionStatus */ get_Status(/*InternalTransaction*/ tx)
            {
                return 2/*TransactionStatus.Aborted*/;
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
            }
            /*void */ BeginCommit(/*InternalTransaction*/ tx, /*bool*/ asyncCommit, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw $.$stl.System.Transactions.TransactionAbortedException.Create$3($.$stl.System.SR.TransactionAborted, tx._innerException, tx.DistributedTxId);
            }
            /*void */ CreateBlockingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionAbortedException.Create$3($.$stl.System.SR.TransactionAborted, tx._innerException, tx.DistributedTxId);
            }
            /*void */ CreateAbortingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionAbortedException.Create$3($.$stl.System.SR.TransactionAborted, tx._innerException, tx.DistributedTxId);
            }
            /*void */ Phase0VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ Phase1VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ ChangeStateTransactionAborted(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
            }
            /*void */ PromotedTransactionOutcome(/*InternalTransaction*/ tx)
            {
                if ((null === tx._innerException) && (null !== tx.PromotedTransaction))
                {
                    tx._innerException = tx.PromotedTransaction.InnerException;
                }
                throw $.$stl.System.Transactions.TransactionAbortedException.Create$3($.$stl.System.SR.TransactionAborted, tx._innerException, tx.DistributedTxId);
            }
            /*void */ CheckForFinishedTransaction(/*InternalTransaction*/ tx)
            {
                throw new $.$stl.System.Transactions.TransactionAbortedException().$ctor$14(tx._innerException, tx.DistributedTxId);
            }
            /*void */ GetObjectData(/*InternalTransaction*/ tx, /*SerializationInfo*/ serializationInfo, /*StreamingContext*/ context)
            {
                throw $.$stl.System.Transactions.TransactionAbortedException.Create$3($.$stl.System.SR.TransactionAborted, tx._innerException, tx.DistributedTxId);
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 7251212;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7447820,"m":[{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"EnterState","d":7251212,"h":4302218508,"f":16809992},{"r":8430860,"p":[{"n":"tx","p":2794764}],"n":"get_Status","d":7251212,"h":8597185804,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"e","p":47251457}],"n":"Rollback","d":7251212,"h":12892153100,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"asyncCommit","p":262145},{"n":"asyncCallback","p":14548993},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":7251212,"h":17187120396,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"CreateBlockingClone","d":7251212,"h":21482087692,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"CreateAbortingClone","d":7251212,"h":25777054988,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"Phase0VolatilePrepareDone","d":7251212,"h":30072022284,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"Phase1VolatilePrepareDone","d":7251212,"h":34366989580,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"e","p":47251457}],"n":"ChangeStateTransactionAborted","d":7251212,"h":38661956876,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"PromotedTransactionOutcome","d":7251212,"h":42956924172,"f":16809988},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"CheckForFinishedTransaction","d":7251212,"h":47251891468,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"serializationInfo","p":113836033},{"n":"context","p":113967105}],"n":"GetObjectData","d":7251212,"h":51546858764,"f":16809992}],"c":[{"n":".ctor","o":"$ctor$4","d":7251212,"h":55841826060,"f":16777217}],"h":7251212}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCEnded; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedNonMSDTCAborted`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedNonMSDTCCommitted", ($self) => class TransactionStatePromotedNonMSDTCCommitted extends $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCEnded
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                super.EnterState(tx);
                for(/*int*/ let i = 0; i < tx._phase0Volatiles._volatileEnlistmentCount; i++)
                {
                    $.$$.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i)._twoPhaseState.InternalCommitted($.$$.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i));
                }
                for(/*int*/ let i = 0; i < tx._phase1Volatiles._volatileEnlistmentCount; i++)
                {
                    $.$$.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i)._twoPhaseState.InternalCommitted($.$$.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i));
                }
                tx.FireCompletion();
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionCommitted(1/*TraceSourceType.TraceSourceLtm*/, tx.TransactionTraceId);
                }
            }
            /*TransactionStatus */ get_Status(/*InternalTransaction*/ tx)
            {
                return 1/*TransactionStatus.Committed*/;
            }
            /*void */ PromotedTransactionOutcome(/*InternalTransaction*/ tx)
            {
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 7382284;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7447820,"m":[{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"EnterState","d":7382284,"h":4302349580,"f":16809992},{"r":8430860,"p":[{"n":"tx","p":2794764}],"n":"get_Status","d":7382284,"h":8597316876,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"PromotedTransactionOutcome","d":7382284,"h":12892284172,"f":16809988}],"c":[{"n":".ctor","o":"$ctor$4","d":7382284,"h":17187251468,"f":16777217}],"h":7382284}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCEnded; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedNonMSDTCCommitted`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedNonMSDTCIndoubt", ($self) => class TransactionStatePromotedNonMSDTCIndoubt extends $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCEnded
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                super.EnterState(tx);
                for(/*int*/ let i = 0; i < tx._phase0Volatiles._volatileEnlistmentCount; i++)
                {
                    $.$$.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i)._twoPhaseState.InternalIndoubt($.$$.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i));
                }
                for(/*int*/ let i = 0; i < tx._phase1Volatiles._volatileEnlistmentCount; i++)
                {
                    $.$$.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i)._twoPhaseState.InternalIndoubt($.$$.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i));
                }
                tx.FireCompletion();
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionInDoubt(1/*TraceSourceType.TraceSourceLtm*/, tx.TransactionTraceId);
                }
            }
            /*TransactionStatus */ get_Status(/*InternalTransaction*/ tx)
            {
                return 3/*TransactionStatus.InDoubt*/;
            }
            /*void */ ChangeStatePromotedPhase0(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionInDoubtException.Create$3(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionIndoubt, tx._innerException, tx.DistributedTxId);
            }
            /*void */ ChangeStatePromotedPhase1(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionInDoubtException.Create$3(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionIndoubt, tx._innerException, tx.DistributedTxId);
            }
            /*void */ PromotedTransactionOutcome(/*InternalTransaction*/ tx)
            {
                if ((null === tx._innerException) && (null !== tx.PromotedTransaction))
                {
                    tx._innerException = tx.PromotedTransaction.InnerException;
                }
                throw $.$stl.System.Transactions.TransactionInDoubtException.Create$3(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionIndoubt, tx._innerException, tx.DistributedTxId);
            }
            /*void */ CheckForFinishedTransaction(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionInDoubtException.Create$3(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionIndoubt, tx._innerException, tx.DistributedTxId);
            }
            /*void */ GetObjectData(/*InternalTransaction*/ tx, /*SerializationInfo*/ serializationInfo, /*StreamingContext*/ context)
            {
                throw $.$stl.System.Transactions.TransactionInDoubtException.Create$3(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionIndoubt, tx._innerException, tx.DistributedTxId);
            }
            /*void */ CreateBlockingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.Create($.$stl.System.SR.TransactionAborted, tx._innerException, tx.DistributedTxId);
            }
            /*void */ CreateAbortingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.Create($.$stl.System.SR.TransactionAborted, tx._innerException, tx.DistributedTxId);
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 7513356;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7447820,"m":[{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"EnterState","d":7513356,"h":4302480652,"f":16809992},{"r":8430860,"p":[{"n":"tx","p":2794764}],"n":"get_Status","d":7513356,"h":8597447948,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"ChangeStatePromotedPhase0","d":7513356,"h":12892415244,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"ChangeStatePromotedPhase1","d":7513356,"h":17187382540,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"PromotedTransactionOutcome","d":7513356,"h":21482349836,"f":16809988},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"CheckForFinishedTransaction","d":7513356,"h":25777317132,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"serializationInfo","p":113836033},{"n":"context","p":113967105}],"n":"GetObjectData","d":7513356,"h":30072284428,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"CreateBlockingClone","d":7513356,"h":34367251724,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"CreateAbortingClone","d":7513356,"h":38662219020,"f":16809992}],"c":[{"n":".ctor","o":"$ctor$4","d":7513356,"h":42957186316,"f":16777217}],"h":7513356}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCEnded; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedNonMSDTCIndoubt`; }
        });
        
        $asm.$cls("$stl.System.Transactions.PreparingEnlistment", ($self) => class PreparingEnlistment extends $.$stl.System.Transactions.Enlistment
        {
            $ctor$7(/*InternalEnlistment*/ enlistment)
            {
                super.$ctor$4(enlistment);
                {
                }
                return this;
            }
            /*void */ Prepared()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "Prepared");
                    etwLog.EnlistmentPrepared$1(this._internalEnlistment);
                }
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this._internalEnlistment.SyncRoot)
                    {
                        this._internalEnlistment.State.Prepared(this._internalEnlistment);
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this._internalEnlistment.SyncRoot)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "Prepared");
                }
            }
            /*void */ ForceRollback()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "ForceRollback");
                    etwLog.EnlistmentForceRollback$1(this._internalEnlistment);
                }
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this._internalEnlistment.SyncRoot)
                    {
                        this._internalEnlistment.State.ForceRollback(this._internalEnlistment, null);
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this._internalEnlistment.SyncRoot)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "ForceRollback");
                }
            }
            /*void */ ForceRollback$1(/*Exception?*/ e)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "ForceRollback");
                    etwLog.EnlistmentForceRollback$1(this._internalEnlistment);
                }
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this._internalEnlistment.SyncRoot)
                    {
                        this._internalEnlistment.State.ForceRollback(this._internalEnlistment, e);
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this._internalEnlistment.SyncRoot)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "ForceRollback");
                }
            }
            /*byte[] */ RecoveryInformation()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "RecoveryInformation");
                }
                try
                {
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1(this._internalEnlistment.SyncRoot)
                        {
                            return this._internalEnlistment.State.RecoveryInformation(this._internalEnlistment);
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit(this._internalEnlistment.SyncRoot)
                    }
                }
                finally
                {
                    {
                        if (etwLog.IsEnabled())
                        {
                            etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "RecoveryInformation");
                        }
                    }
                }
            }
            static $h = 3908876;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1746188,"m":[{"r":65537,"n":"Prepared","d":3908876,"h":8593843468,"f":16777217},{"r":65537,"n":"ForceRollback","d":3908876,"h":12888810764,"f":16777217},{"r":65537,"p":[{"n":"e","p":47251457}],"n":"ForceRollback","o":"@$1","d":3908876,"h":17183778060,"f":16777217},{"r":$.$typeArray($.$$.System.Byte).$h,"n":"RecoveryInformation","d":3908876,"h":21478745356,"f":16777217}],"c":[{"p":[{"n":"enlistment","p":2729228}],"n":".ctor","o":"$ctor$7","d":3908876,"h":4298876172,"f":16777224}],"h":3908876}; }
            static get $b() { return $.$stl.System.Transactions.Enlistment; }
            static get $fullName() { return `System.Transactions.PreparingEnlistment`; }
        });
        
        $asm.$cls("$stl.System.Transactions.SinglePhaseEnlistment", ($self) => class SinglePhaseEnlistment extends $.$stl.System.Transactions.Enlistment
        {
            $ctor$7(/*InternalEnlistment*/ enlistment)
            {
                super.$ctor$4(enlistment);
                {
                }
                return this;
            }
            /*void */ Aborted()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "Aborted");
                    etwLog.EnlistmentAborted$1(this._internalEnlistment);
                }
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this._internalEnlistment.SyncRoot)
                    {
                        this._internalEnlistment.State.Aborted(this._internalEnlistment, null);
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this._internalEnlistment.SyncRoot)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "Aborted");
                }
            }
            /*void */ Aborted$1(/*Exception?*/ e)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "Aborted");
                    etwLog.EnlistmentAborted$1(this._internalEnlistment);
                }
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this._internalEnlistment.SyncRoot)
                    {
                        this._internalEnlistment.State.Aborted(this._internalEnlistment, e);
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this._internalEnlistment.SyncRoot)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "Aborted");
                }
            }
            /*void */ Committed()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "Committed");
                    etwLog.EnlistmentCommitted$1(this._internalEnlistment);
                }
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this._internalEnlistment.SyncRoot)
                    {
                        this._internalEnlistment.State.Committed(this._internalEnlistment);
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this._internalEnlistment.SyncRoot)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "Committed");
                }
            }
            /*void */ InDoubt()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "InDoubt");
                }
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this._internalEnlistment.SyncRoot)
                    {
                        if (etwLog.IsEnabled())
                        {
                            etwLog.EnlistmentInDoubt$1(this._internalEnlistment);
                        }
                        this._internalEnlistment.State.InDoubt(this._internalEnlistment, null);
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this._internalEnlistment.SyncRoot)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "InDoubt");
                }
            }
            /*void */ InDoubt$1(/*Exception?*/ e)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "InDoubt");
                }
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this._internalEnlistment.SyncRoot)
                    {
                        if (etwLog.IsEnabled())
                        {
                            etwLog.EnlistmentInDoubt$1(this._internalEnlistment);
                        }
                        this._internalEnlistment.State.InDoubt(this._internalEnlistment, e);
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this._internalEnlistment.SyncRoot)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "InDoubt");
                }
            }
            static $h = 4105484;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1746188,"m":[{"r":65537,"n":"Aborted","d":4105484,"h":8594040076,"f":16777217},{"r":65537,"p":[{"n":"e","p":47251457}],"n":"Aborted","o":"@$1","d":4105484,"h":12889007372,"f":16777217},{"r":65537,"n":"Committed","d":4105484,"h":17183974668,"f":16777217},{"r":65537,"n":"InDoubt","d":4105484,"h":21478941964,"f":16777217},{"r":65537,"p":[{"n":"e","p":47251457}],"n":"InDoubt","o":"@$1","d":4105484,"h":25773909260,"f":16777217}],"c":[{"p":[{"n":"enlistment","p":2729228}],"n":".ctor","o":"$ctor$7","d":4105484,"h":4299072780,"f":16777224}],"h":4105484}; }
            static get $b() { return $.$stl.System.Transactions.Enlistment; }
            static get $fullName() { return `System.Transactions.SinglePhaseEnlistment`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionEventArgs", ($self) => class TransactionEventArgs extends $.$$.System.EventArgs
        {
            /*Transaction?*/ _transaction = null;
            /*Transaction? */ get Transaction()
            {
                return this._transaction;
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 4498700;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46989313,"p":[{"p":4302092,"g":{"r":0,"d":0,"h":12889400588,"f":50331649},"n":"Transaction","d":4498700,"h":8594433292,"f":2097153}],"l":[{"t":4302092,"n":"_transaction","d":4498700,"h":4299465996,"f":4194312}],"c":[{"n":".ctor","o":"$ctor$2","d":4498700,"h":17184367884,"f":16777217}],"h":4498700}; }
            static get $b() { return $.$$.System.EventArgs; }
            static get $fullName() { return `System.Transactions.TransactionEventArgs`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionsEtwProvider", ($self) => class TransactionsEtwProvider extends $.$$.System.Diagnostics.Tracing.EventSource
        {
            /*TransactionsEtwProvider*/ static Log = null;
            $ctor$10()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*EventKeywords*/ static ALL_KEYWORDS = -1n;
            /*int*/ static CONFIGURED_DEFAULT_TIMEOUT_ADJUSTED_EVENTID = 1;
            /*int*/ static ENLISTMENT_ABORTED_EVENTID = 2;
            /*int*/ static ENLISTMENT_COMMITTED_EVENTID = 3;
            /*int*/ static ENLISTMENT_DONE_EVENTID = 4;
            /*int*/ static ENLISTMENT_LTM_EVENTID = 5;
            /*int*/ static ENLISTMENT_FORCEROLLBACK_EVENTID = 6;
            /*int*/ static ENLISTMENT_INDOUBT_EVENTID = 7;
            /*int*/ static ENLISTMENT_PREPARED_EVENTID = 8;
            /*int*/ static EXCEPTION_CONSUMED_BASE_EVENTID = 9;
            /*int*/ static EXCEPTION_CONSUMED_LTM_EVENTID = 10;
            /*int*/ static METHOD_ENTER_LTM_EVENTID = 11;
            /*int*/ static METHOD_EXIT_LTM_EVENTID = 12;
            /*int*/ static METHOD_ENTER_BASE_EVENTID = 13;
            /*int*/ static METHOD_EXIT_BASE_EVENTID = 14;
            /*int*/ static METHOD_ENTER_OLETX_EVENTID = 15;
            /*int*/ static METHOD_EXIT_OLETX_EVENTID = 16;
            /*int*/ static TRANSACTION_ABORTED_LTM_EVENTID = 17;
            /*int*/ static TRANSACTION_CLONECREATE_EVENTID = 18;
            /*int*/ static TRANSACTION_COMMIT_LTM_EVENTID = 19;
            /*int*/ static TRANSACTION_COMMITTED_LTM_EVENTID = 20;
            /*int*/ static TRANSACTION_CREATED_LTM_EVENTID = 21;
            /*int*/ static TRANSACTION_DEPENDENT_CLONE_COMPLETE_LTM_EVENTID = 22;
            /*int*/ static TRANSACTION_EXCEPTION_LTM_EVENTID = 23;
            /*int*/ static TRANSACTION_EXCEPTION_BASE_EVENTID = 24;
            /*int*/ static TRANSACTION_INDOUBT_LTM_EVENTID = 25;
            /*int*/ static TRANSACTION_INVALID_OPERATION_EVENTID = 26;
            /*int*/ static TRANSACTION_PROMOTED_EVENTID = 27;
            /*int*/ static TRANSACTION_ROLLBACK_LTM_EVENTID = 28;
            /*int*/ static TRANSACTION_SERIALIZED_EVENTID = 29;
            /*int*/ static TRANSACTION_TIMEOUT_EVENTID = 30;
            /*int*/ static TRANSACTIONMANAGER_RECOVERY_COMPLETE_EVENTID = 31;
            /*int*/ static TRANSACTIONMANAGER_REENLIST_EVENTID = 32;
            /*int*/ static TRANSACTIONSCOPE_CREATED_EVENTID = 33;
            /*int*/ static TRANSACTIONSCOPE_CURRENT_CHANGED_EVENTID = 34;
            /*int*/ static TRANSACTIONSCOPE_DISPOSED_EVENTID = 35;
            /*int*/ static TRANSACTIONSCOPE_INCOMPLETE_EVENTID = 36;
            /*int*/ static INTERNAL_ERROR_EVENTID = 37;
            /*int*/ static TRANSACTIONSCOPE_NESTED_INCORRECTLY_EVENTID = 38;
            /*int*/ static TRANSACTIONSCOPE_TIMEOUT_EVENTID = 39;
            /*int*/ static TRANSACTIONSTATE_ENLIST_EVENTID = 40;
            /*int*/ static TRANSACTION_COMMIT_OLETX_EVENTID = 41;
            /*int*/ static TRANSACTION_ROLLBACK_OLETX_EVENTID = 42;
            /*int*/ static EXCEPTION_CONSUMED_OLETX_EVENTID = 43;
            /*int*/ static TRANSACTION_COMMITTED_OLETX_EVENTID = 44;
            /*int*/ static TRANSACTION_ABORTED_OLETX_EVENTID = 45;
            /*int*/ static TRANSACTION_INDOUBT_OLETX_EVENTID = 46;
            /*int*/ static TRANSACTION_DEPENDENT_CLONE_COMPLETE_OLETX_EVENTID = 47;
            /*int*/ static TRANSACTION_DEPENDENT_CLONE_CREATE_LTM_EVENTID = 48;
            /*int*/ static TRANSACTION_DEPENDENT_CLONE_CREATE_OLETX_EVENTID = 49;
            /*int*/ static TRANSACTION_DESERIALIZED_EVENTID = 50;
            /*int*/ static TRANSACTION_CREATED_OLETX_EVENTID = 51;
            /*int*/ static ENLISTMENT_OLETX_EVENTID = 52;
            /*int*/ static ENLISTMENT_CALLBACK_POSITIVE_EVENTID = 53;
            /*int*/ static ENLISTMENT_CALLBACK_NEGATIVE_EVENTID = 54;
            /*int*/ static ENLISTMENT_CREATED_LTM_EVENTID = 55;
            /*int*/ static ENLISTMENT_CREATED_OLETX_EVENTID = 56;
            /*int*/ static TRANSACTIONMANAGER_CREATE_OLETX_EVENTID = 57;
            /*string*/ static NullInstance = null;
            static /*string */ IdOf(/*object?*/ value)
            {
                return value !== null ? $.$$.System.Object.GetType.call(value).Name + "#" + $.$stl.System.Transactions.TransactionsEtwProvider.GetHashCode$1(value) : "(null)"/*NullInstance*/;
            }
            static /*int */ GetHashCode$1(/*object?*/ value)
            {
                const $t1 = value;
                return $.$ifnn($t1, ($t) => $.$$.System.Object.GetHashCode.call($t)) ?? 0;
            }
            /*void */ TransactionCreated(/*TraceSourceType*/ traceSource, /*TransactionTraceIdentifier*/ txTraceId, /*string?*/ type)
            {
                if (this.IsEnabled$2(4/*EventLevel.Informational*/, -1n))
                {
                    if (traceSource === 1/*TraceSourceType.TraceSourceLtm*/)
                    {
                        this.TransactionCreatedLtm(txTraceId.TransactionIdentifier, type);
                    }
                    else if (traceSource === 2/*TraceSourceType.TraceSourceOleTx*/)
                    {
                        this.TransactionCreatedOleTx(txTraceId.TransactionIdentifier, type);
                    }
                }
            }
            /*void */ TransactionCreatedLtm(/*string*/ transactionIdentifier, /*string?*/ type)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionIdentifier);
                this.WriteEvent$16(21/*TRANSACTION_CREATED_LTM_EVENTID*/, transactionIdentifier, type);
            }
            /*void */ TransactionCreatedOleTx(/*string*/ transactionIdentifier, /*string?*/ type)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionIdentifier);
                this.WriteEvent$16(51/*TRANSACTION_CREATED_OLETX_EVENTID*/, transactionIdentifier, type);
            }
            /*void */ TransactionCloneCreate$1(/*Transaction*/ transaction, /*string*/ type)
            {
                $.$$.System.Diagnostics.Debug.Assert$2($.$stl.System.Transactions.Transaction.op_Inequality(transaction, null), "Transaction needed for the ETW event.");
                if (this.IsEnabled$2(4/*EventLevel.Informational*/, -1n))
                {
                    if ($.$stl.System.Transactions.Transaction.op_Inequality(transaction, null) && $.$$.System.String.op_Inequality(transaction.TransactionTraceId.TransactionIdentifier, null))
                    {
                        this.TransactionCloneCreate(transaction.TransactionTraceId.TransactionIdentifier, type);
                    }
                    else 
                    {
                        this.TransactionCloneCreate($.$$.System.String.Empty, type);
                    }
                }
            }
            /*void */ TransactionCloneCreate(/*string*/ transactionIdentifier, /*string*/ type)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionIdentifier);
                this.WriteEvent$16(18/*TRANSACTION_CLONECREATE_EVENTID*/, transactionIdentifier, type);
            }
            /*void */ TransactionSerialized$1(/*TransactionTraceIdentifier*/ transactionTraceId)
            {
                if (this.IsEnabled$2(4/*EventLevel.Informational*/, -1n))
                {
                    this.TransactionSerialized(transactionTraceId.TransactionIdentifier);
                }
            }
            /*void */ TransactionSerialized(/*string*/ transactionIdentifier)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionIdentifier);
                this.WriteEvent$17(29/*TRANSACTION_SERIALIZED_EVENTID*/, transactionIdentifier);
            }
            /*void */ TransactionDeserialized$1(/*TransactionTraceIdentifier*/ transactionTraceId)
            {
                if (this.IsEnabled$2(5/*EventLevel.Verbose*/, -1n))
                {
                    this.TransactionDeserialized(transactionTraceId.TransactionIdentifier);
                }
            }
            /*void */ TransactionDeserialized(/*string*/ transactionIdentifier)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionIdentifier);
                this.WriteEvent$17(50/*TRANSACTION_DESERIALIZED_EVENTID*/, transactionIdentifier);
            }
            /*void */ TransactionExceptionTrace(/*TraceSourceType*/ traceSource, /*TransactionExceptionType*/ type, /*string?*/ message, /*string?*/ innerExceptionStr)
            {
                if (this.IsEnabled$2(2/*EventLevel.Error*/, -1n))
                {
                    if (traceSource === 0/*TraceSourceType.TraceSourceBase*/)
                    {
                        this.TransactionExceptionBase($.$$.System.Enum.ToStringT($.$stl.System.Transactions.TransactionExceptionType, $.$$.System.UInt32, type), message, innerExceptionStr);
                    }
                    else 
                    {
                        this.TransactionExceptionLtm($.$$.System.Enum.ToStringT($.$stl.System.Transactions.TransactionExceptionType, $.$$.System.UInt32, type), message, innerExceptionStr);
                    }
                }
            }
            /*void */ TransactionExceptionTrace$1(/*TransactionExceptionType*/ type, /*string?*/ message, /*string?*/ innerExceptionStr)
            {
                if (this.IsEnabled$2(2/*EventLevel.Error*/, -1n))
                {
                    this.TransactionExceptionLtm($.$$.System.Enum.ToStringT($.$stl.System.Transactions.TransactionExceptionType, $.$$.System.UInt32, type), message, innerExceptionStr);
                }
            }
            /*void */ TransactionExceptionBase(/*string?*/ type, /*string?*/ message, /*string?*/ innerExceptionStr)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$$.System.String.Empty);
                this.WriteEvent$15(24/*TRANSACTION_EXCEPTION_BASE_EVENTID*/, type, message, innerExceptionStr);
            }
            /*void */ TransactionExceptionLtm(/*string?*/ type, /*string?*/ message, /*string?*/ innerExceptionStr)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$$.System.String.Empty);
                this.WriteEvent$15(23/*TRANSACTION_EXCEPTION_LTM_EVENTID*/, type, message, innerExceptionStr);
            }
            /*void */ InvalidOperation(/*string?*/ type, /*string?*/ operation)
            {
                if (this.IsEnabled$2(2/*EventLevel.Error*/, -1n))
                {
                    this.TransactionInvalidOperation($.$$.System.String.Empty, type, operation);
                }
            }
            /*void */ TransactionInvalidOperation(/*string?*/ transactionIdentifier, /*string?*/ type, /*string?*/ operation)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$$.System.String.Empty);
                this.WriteEvent$15(26/*TRANSACTION_INVALID_OPERATION_EVENTID*/, transactionIdentifier, type, operation);
            }
            /*void */ TransactionRollback(/*TraceSourceType*/ traceSource, /*TransactionTraceIdentifier*/ txTraceId, /*string?*/ type)
            {
                if (this.IsEnabled$2(3/*EventLevel.Warning*/, -1n))
                {
                    if (traceSource === 1/*TraceSourceType.TraceSourceLtm*/)
                    {
                        this.TransactionRollbackLtm(txTraceId.TransactionIdentifier, type);
                    }
                    else if (traceSource === 2/*TraceSourceType.TraceSourceOleTx*/)
                    {
                        this.TransactionRollbackOleTx(txTraceId.TransactionIdentifier, type);
                    }
                }
            }
            /*void */ TransactionRollbackLtm(/*string*/ transactionIdentifier, /*string?*/ type)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionIdentifier);
                this.WriteEvent$16(28/*TRANSACTION_ROLLBACK_LTM_EVENTID*/, transactionIdentifier, type);
            }
            /*void */ TransactionRollbackOleTx(/*string*/ transactionIdentifier, /*string?*/ type)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionIdentifier);
                this.WriteEvent$16(42/*TRANSACTION_ROLLBACK_OLETX_EVENTID*/, transactionIdentifier, type);
            }
            /*void */ TransactionDependentCloneCreate(/*TraceSourceType*/ traceSource, /*TransactionTraceIdentifier*/ txTraceId, /*DependentCloneOption*/ option)
            {
                if (this.IsEnabled$2(4/*EventLevel.Informational*/, -1n))
                {
                    if (traceSource === 1/*TraceSourceType.TraceSourceLtm*/)
                    {
                        this.TransactionDependentCloneCreateLtm(txTraceId.TransactionIdentifier, $.$$.System.Enum.ToStringT($.$stl.System.Transactions.DependentCloneOption, $.$$.System.UInt32, option));
                    }
                    else if (traceSource === 2/*TraceSourceType.TraceSourceOleTx*/)
                    {
                        this.TransactionDependentCloneCreateOleTx(txTraceId.TransactionIdentifier, $.$$.System.Enum.ToStringT($.$stl.System.Transactions.DependentCloneOption, $.$$.System.UInt32, option));
                    }
                }
            }
            /*void */ TransactionDependentCloneCreateLtm(/*string*/ transactionIdentifier, /*string?*/ option)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionIdentifier);
                this.WriteEvent$16(48/*TRANSACTION_DEPENDENT_CLONE_CREATE_LTM_EVENTID*/, transactionIdentifier, option);
            }
            /*void */ TransactionDependentCloneCreateOleTx(/*string*/ transactionIdentifier, /*string?*/ option)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionIdentifier);
                this.WriteEvent$16(49/*TRANSACTION_DEPENDENT_CLONE_CREATE_OLETX_EVENTID*/, transactionIdentifier, option);
            }
            /*void */ TransactionDependentCloneComplete(/*TraceSourceType*/ traceSource, /*TransactionTraceIdentifier*/ txTraceId, /*string?*/ type)
            {
                if (this.IsEnabled$2(4/*EventLevel.Informational*/, -1n))
                {
                    if (traceSource === 1/*TraceSourceType.TraceSourceLtm*/)
                    {
                        this.TransactionDependentCloneCompleteLtm(txTraceId.TransactionIdentifier, type);
                    }
                    else if (traceSource === 2/*TraceSourceType.TraceSourceOleTx*/)
                    {
                        this.TransactionDependentCloneCompleteOleTx(txTraceId.TransactionIdentifier, type);
                    }
                }
            }
            /*void */ TransactionDependentCloneCompleteLtm(/*string*/ transactionIdentifier, /*string?*/ type)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionIdentifier);
                this.WriteEvent$16(22/*TRANSACTION_DEPENDENT_CLONE_COMPLETE_LTM_EVENTID*/, transactionIdentifier, type);
            }
            /*void */ TransactionDependentCloneCompleteOleTx(/*string*/ transactionIdentifier, /*string?*/ type)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionIdentifier);
                this.WriteEvent$16(47/*TRANSACTION_DEPENDENT_CLONE_COMPLETE_OLETX_EVENTID*/, transactionIdentifier, type);
            }
            /*void */ TransactionCommit(/*TraceSourceType*/ traceSource, /*TransactionTraceIdentifier*/ txTraceId, /*string?*/ type)
            {
                if (this.IsEnabled$2(5/*EventLevel.Verbose*/, -1n))
                {
                    if (traceSource === 1/*TraceSourceType.TraceSourceLtm*/)
                    {
                        this.TransactionCommitLtm(txTraceId.TransactionIdentifier, type);
                    }
                    else if (traceSource === 2/*TraceSourceType.TraceSourceOleTx*/)
                    {
                        this.TransactionCommitOleTx(txTraceId.TransactionIdentifier, type);
                    }
                }
            }
            /*void */ TransactionCommitLtm(/*string*/ transactionIdentifier, /*string?*/ type)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionIdentifier);
                this.WriteEvent$16(19/*TRANSACTION_COMMIT_LTM_EVENTID*/, transactionIdentifier, type);
            }
            /*void */ TransactionCommitOleTx(/*string*/ transactionIdentifier, /*string?*/ type)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionIdentifier);
                this.WriteEvent$16(41/*TRANSACTION_COMMIT_OLETX_EVENTID*/, transactionIdentifier, type);
            }
            /*void */ EnlistmentStatus(/*TraceSourceType*/ traceSource, /*EnlistmentTraceIdentifier*/ enlistmentTraceId, /*NotificationCall*/ notificationCall)
            {
                if (this.IsEnabled$2(5/*EventLevel.Verbose*/, -1n))
                {
                    if (traceSource === 1/*TraceSourceType.TraceSourceLtm*/)
                    {
                        this.EnlistmentStatusLtm(enlistmentTraceId.EnlistmentIdentifier, $.$$.System.Enum.ToStringT($.$stl.System.Transactions.NotificationCall, $.$$.System.UInt32, notificationCall));
                    }
                    else if (traceSource === 2/*TraceSourceType.TraceSourceOleTx*/)
                    {
                        this.EnlistmentStatusOleTx(enlistmentTraceId.EnlistmentIdentifier, $.$$.System.Enum.ToStringT($.$stl.System.Transactions.NotificationCall, $.$$.System.UInt32, notificationCall));
                    }
                }
            }
            /*void */ EnlistmentStatusLtm(/*int*/ enlistmentIdentifier, /*string*/ notificationCall)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$$.System.String.Empty);
                this.WriteEvent$4(5/*ENLISTMENT_LTM_EVENTID*/, enlistmentIdentifier, notificationCall);
            }
            /*void */ EnlistmentStatusOleTx(/*int*/ enlistmentIdentifier, /*string*/ notificationCall)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$$.System.String.Empty);
                this.WriteEvent$4(52/*ENLISTMENT_OLETX_EVENTID*/, enlistmentIdentifier, notificationCall);
            }
            /*void */ EnlistmentCreated(/*TraceSourceType*/ traceSource, /*EnlistmentTraceIdentifier*/ enlistmentTraceId, /*EnlistmentType*/ enlistmentType, /*EnlistmentOptions*/ enlistmentOptions)
            {
                if (this.IsEnabled$2(4/*EventLevel.Informational*/, -1n))
                {
                    if (traceSource === 1/*TraceSourceType.TraceSourceLtm*/)
                    {
                        this.EnlistmentCreatedLtm(enlistmentTraceId.EnlistmentIdentifier, $.$$.System.Enum.ToStringT($.$stl.System.Transactions.EnlistmentType, $.$$.System.UInt32, enlistmentType), $.$$.System.Enum.ToStringT($.$stl.System.Transactions.EnlistmentOptions, $.$$.System.UInt32, enlistmentOptions));
                    }
                    else if (traceSource === 2/*TraceSourceType.TraceSourceOleTx*/)
                    {
                        this.EnlistmentCreatedOleTx(enlistmentTraceId.EnlistmentIdentifier, $.$$.System.Enum.ToStringT($.$stl.System.Transactions.EnlistmentType, $.$$.System.UInt32, enlistmentType), $.$$.System.Enum.ToStringT($.$stl.System.Transactions.EnlistmentOptions, $.$$.System.UInt32, enlistmentOptions));
                    }
                }
            }
            /*void */ EnlistmentCreatedLtm(/*int*/ enlistmentIdentifier, /*string*/ enlistmentType, /*string*/ enlistmentOptions)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$$.System.String.Empty);
                this.WriteEvent$1(55/*ENLISTMENT_CREATED_LTM_EVENTID*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive), [ $.$$.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$10(enlistmentIdentifier), $.$$.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$15(enlistmentType), $.$$.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$15(enlistmentOptions) ], null, null));
            }
            /*void */ EnlistmentCreatedOleTx(/*int*/ enlistmentIdentifier, /*string*/ enlistmentType, /*string*/ enlistmentOptions)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$$.System.String.Empty);
                this.WriteEvent$1(56/*ENLISTMENT_CREATED_OLETX_EVENTID*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive), [ $.$$.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$10(enlistmentIdentifier), $.$$.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$15(enlistmentType), $.$$.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$15(enlistmentOptions) ], null, null));
            }
            /*void */ EnlistmentDone$1(/*InternalEnlistment*/ enlistment)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(enlistment !== null, "Enlistment needed for the ETW event.");
                if (this.IsEnabled$2(5/*EventLevel.Verbose*/, -1n))
                {
                    if (enlistment !== null && enlistment.EnlistmentTraceId.EnlistmentIdentifier !== 0)
                    {
                        this.EnlistmentDone(enlistment.EnlistmentTraceId.EnlistmentIdentifier);
                    }
                    else 
                    {
                        this.EnlistmentDone(0);
                    }
                }
            }
            /*void */ EnlistmentDone(/*int*/ enlistmentIdentifier)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$$.System.String.Empty);
                this.WriteEvent$5(4/*ENLISTMENT_DONE_EVENTID*/, enlistmentIdentifier);
            }
            /*void */ EnlistmentPrepared$1(/*InternalEnlistment*/ enlistment)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(enlistment !== null, "Enlistment needed for the ETW event.");
                if (this.IsEnabled$2(5/*EventLevel.Verbose*/, -1n))
                {
                    if (enlistment !== null && enlistment.EnlistmentTraceId.EnlistmentIdentifier !== 0)
                    {
                        this.EnlistmentPrepared(enlistment.EnlistmentTraceId.EnlistmentIdentifier);
                    }
                    else 
                    {
                        this.EnlistmentPrepared(0);
                    }
                }
            }
            /*void */ EnlistmentPrepared(/*int*/ enlistmentIdentifier)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$$.System.String.Empty);
                this.WriteEvent$5(8/*ENLISTMENT_PREPARED_EVENTID*/, enlistmentIdentifier);
            }
            /*void */ EnlistmentForceRollback$1(/*InternalEnlistment*/ enlistment)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(enlistment !== null, "Enlistment needed for the ETW event.");
                if (this.IsEnabled$2(3/*EventLevel.Warning*/, -1n))
                {
                    if (enlistment !== null && enlistment.EnlistmentTraceId.EnlistmentIdentifier !== 0)
                    {
                        this.EnlistmentForceRollback(enlistment.EnlistmentTraceId.EnlistmentIdentifier);
                    }
                    else 
                    {
                        this.EnlistmentForceRollback(0);
                    }
                }
            }
            /*void */ EnlistmentForceRollback(/*int*/ enlistmentIdentifier)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$$.System.String.Empty);
                this.WriteEvent$5(6/*ENLISTMENT_FORCEROLLBACK_EVENTID*/, enlistmentIdentifier);
            }
            /*void */ EnlistmentAborted$1(/*InternalEnlistment*/ enlistment)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(enlistment !== null, "Enlistment needed for the ETW event.");
                if (this.IsEnabled$2(3/*EventLevel.Warning*/, -1n))
                {
                    if (enlistment !== null && enlistment.EnlistmentTraceId.EnlistmentIdentifier !== 0)
                    {
                        this.EnlistmentAborted(enlistment.EnlistmentTraceId.EnlistmentIdentifier);
                    }
                    else 
                    {
                        this.EnlistmentAborted(0);
                    }
                }
            }
            /*void */ EnlistmentAborted(/*int*/ enlistmentIdentifier)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$$.System.String.Empty);
                this.WriteEvent$5(2/*ENLISTMENT_ABORTED_EVENTID*/, enlistmentIdentifier);
            }
            /*void */ EnlistmentCommitted$1(/*InternalEnlistment*/ enlistment)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(enlistment !== null, "Enlistment needed for the ETW event.");
                if (this.IsEnabled$2(5/*EventLevel.Verbose*/, -1n))
                {
                    if (enlistment !== null && enlistment.EnlistmentTraceId.EnlistmentIdentifier !== 0)
                    {
                        this.EnlistmentCommitted(enlistment.EnlistmentTraceId.EnlistmentIdentifier);
                    }
                    else 
                    {
                        this.EnlistmentCommitted(0);
                    }
                }
            }
            /*void */ EnlistmentCommitted(/*int*/ enlistmentIdentifier)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$$.System.String.Empty);
                this.WriteEvent$5(3/*ENLISTMENT_COMMITTED_EVENTID*/, enlistmentIdentifier);
            }
            /*void */ EnlistmentInDoubt$1(/*InternalEnlistment*/ enlistment)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(enlistment !== null, "Enlistment needed for the ETW event.");
                if (this.IsEnabled$2(3/*EventLevel.Warning*/, -1n))
                {
                    if (enlistment !== null && enlistment.EnlistmentTraceId.EnlistmentIdentifier !== 0)
                    {
                        this.EnlistmentInDoubt(enlistment.EnlistmentTraceId.EnlistmentIdentifier);
                    }
                    else 
                    {
                        this.EnlistmentInDoubt(0);
                    }
                }
            }
            /*void */ EnlistmentInDoubt(/*int*/ enlistmentIdentifier)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$$.System.String.Empty);
                this.WriteEvent$5(7/*ENLISTMENT_INDOUBT_EVENTID*/, enlistmentIdentifier);
            }
            /*void */ EnlistmentCallbackPositive$1(/*EnlistmentTraceIdentifier*/ enlistmentTraceIdentifier, /*EnlistmentCallback*/ callback)
            {
                if (this.IsEnabled$2(5/*EventLevel.Verbose*/, -1n))
                {
                    this.EnlistmentCallbackPositive(enlistmentTraceIdentifier.EnlistmentIdentifier, $.$$.System.Enum.ToStringT($.$stl.System.Transactions.EnlistmentCallback, $.$$.System.UInt32, callback));
                }
            }
            /*void */ EnlistmentCallbackPositive(/*int*/ enlistmentIdentifier, /*string?*/ callback)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$$.System.String.Empty);
                this.WriteEvent$4(53/*ENLISTMENT_CALLBACK_POSITIVE_EVENTID*/, enlistmentIdentifier, callback);
            }
            /*void */ EnlistmentCallbackNegative$1(/*EnlistmentTraceIdentifier*/ enlistmentTraceIdentifier, /*EnlistmentCallback*/ callback)
            {
                if (this.IsEnabled$2(3/*EventLevel.Warning*/, -1n))
                {
                    this.EnlistmentCallbackNegative(enlistmentTraceIdentifier.EnlistmentIdentifier, $.$$.System.Enum.ToStringT($.$stl.System.Transactions.EnlistmentCallback, $.$$.System.UInt32, callback));
                }
            }
            /*void */ EnlistmentCallbackNegative(/*int*/ enlistmentIdentifier, /*string?*/ callback)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$$.System.String.Empty);
                this.WriteEvent$4(54/*ENLISTMENT_CALLBACK_NEGATIVE_EVENTID*/, enlistmentIdentifier, callback);
            }
            /*void */ MethodEnter(/*TraceSourceType*/ traceSource, /*object?*/ thisOrContextObject, /*string?*/ methodname)
            {
                if (this.IsEnabled$2(5/*EventLevel.Verbose*/, -1n))
                {
                    if (traceSource === 1/*TraceSourceType.TraceSourceLtm*/)
                    {
                        this.MethodEnterTraceLtm($.$stl.System.Transactions.TransactionsEtwProvider.IdOf(thisOrContextObject), methodname);
                    }
                    else if (traceSource === 0/*TraceSourceType.TraceSourceBase*/)
                    {
                        this.MethodEnterTraceBase($.$stl.System.Transactions.TransactionsEtwProvider.IdOf(thisOrContextObject), methodname);
                    }
                    else if (traceSource === 2/*TraceSourceType.TraceSourceOleTx*/)
                    {
                        this.MethodEnterTraceDistributed($.$stl.System.Transactions.TransactionsEtwProvider.IdOf(thisOrContextObject), methodname);
                    }
                }
            }
            /*void */ MethodEnter$1(/*TraceSourceType*/ traceSource, /*string?*/ methodname)
            {
                if (this.IsEnabled$2(5/*EventLevel.Verbose*/, -1n))
                {
                    if (traceSource === 1/*TraceSourceType.TraceSourceLtm*/)
                    {
                        this.MethodEnterTraceLtm($.$$.System.String.Empty, methodname);
                    }
                    else if (traceSource === 0/*TraceSourceType.TraceSourceBase*/)
                    {
                        this.MethodEnterTraceBase($.$$.System.String.Empty, methodname);
                    }
                    else if (traceSource === 2/*TraceSourceType.TraceSourceOleTx*/)
                    {
                        this.MethodEnterTraceDistributed($.$$.System.String.Empty, methodname);
                    }
                }
            }
            /*void */ MethodEnterTraceLtm(/*string*/ thisOrContextObject, /*string?*/ methodname)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$$.System.String.Empty);
                this.WriteEvent$16(11/*METHOD_ENTER_LTM_EVENTID*/, thisOrContextObject, methodname);
            }
            /*void */ MethodEnterTraceBase(/*string*/ thisOrContextObject, /*string?*/ methodname)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$$.System.String.Empty);
                this.WriteEvent$16(13/*METHOD_ENTER_BASE_EVENTID*/, thisOrContextObject, methodname);
            }
            /*void */ MethodEnterTraceDistributed(/*string*/ thisOrContextObject, /*string?*/ methodname)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$$.System.String.Empty);
                this.WriteEvent$16(15/*METHOD_ENTER_OLETX_EVENTID*/, thisOrContextObject, methodname);
            }
            /*void */ MethodExit(/*TraceSourceType*/ traceSource, /*object?*/ thisOrContextObject, /*string?*/ methodname)
            {
                if (this.IsEnabled$2(5/*EventLevel.Verbose*/, -1n))
                {
                    if (traceSource === 1/*TraceSourceType.TraceSourceLtm*/)
                    {
                        this.MethodExitTraceLtm($.$stl.System.Transactions.TransactionsEtwProvider.IdOf(thisOrContextObject), methodname);
                    }
                    else if (traceSource === 0/*TraceSourceType.TraceSourceBase*/)
                    {
                        this.MethodExitTraceBase($.$stl.System.Transactions.TransactionsEtwProvider.IdOf(thisOrContextObject), methodname);
                    }
                    else if (traceSource === 2/*TraceSourceType.TraceSourceOleTx*/)
                    {
                        this.MethodExitTraceDistributed($.$stl.System.Transactions.TransactionsEtwProvider.IdOf(thisOrContextObject), methodname);
                    }
                }
            }
            /*void */ MethodExit$1(/*TraceSourceType*/ traceSource, /*string?*/ methodname)
            {
                if (this.IsEnabled$2(5/*EventLevel.Verbose*/, -1n))
                {
                    if (traceSource === 1/*TraceSourceType.TraceSourceLtm*/)
                    {
                        this.MethodExitTraceLtm($.$$.System.String.Empty, methodname);
                    }
                    else if (traceSource === 0/*TraceSourceType.TraceSourceBase*/)
                    {
                        this.MethodExitTraceBase($.$$.System.String.Empty, methodname);
                    }
                    else if (traceSource === 2/*TraceSourceType.TraceSourceOleTx*/)
                    {
                        this.MethodExitTraceDistributed($.$$.System.String.Empty, methodname);
                    }
                }
            }
            /*void */ MethodExitTraceLtm(/*string*/ thisOrContextObject, /*string?*/ methodname)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$$.System.String.Empty);
                this.WriteEvent$16(12/*METHOD_EXIT_LTM_EVENTID*/, thisOrContextObject, methodname);
            }
            /*void */ MethodExitTraceBase(/*string*/ thisOrContextObject, /*string?*/ methodname)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$$.System.String.Empty);
                this.WriteEvent$16(14/*METHOD_EXIT_BASE_EVENTID*/, thisOrContextObject, methodname);
            }
            /*void */ MethodExitTraceDistributed(/*string*/ thisOrContextObject, /*string?*/ methodname)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$$.System.String.Empty);
                this.WriteEvent$16(16/*METHOD_EXIT_OLETX_EVENTID*/, thisOrContextObject, methodname);
            }
            /*void */ ExceptionConsumed$1(/*TraceSourceType*/ traceSource, /*Exception*/ exception)
            {
                if (this.IsEnabled$2(5/*EventLevel.Verbose*/, -1n))
                {
                    switch(traceSource)
                    {
                        case 0/*TraceSourceType.TraceSourceBase*/:
                        this.ExceptionConsumedBase($.$$.System.Exception.ToString.call(exception));
                        return;
                        case 1/*TraceSourceType.TraceSourceLtm*/:
                        this.ExceptionConsumedLtm($.$$.System.Exception.ToString.call(exception));
                        return;
                        case 2/*TraceSourceType.TraceSourceOleTx*/:
                        this.ExceptionConsumedOleTx($.$$.System.Exception.ToString.call(exception));
                        return;
                    }
                }
            }
            /*void */ ExceptionConsumed(/*Exception*/ exception)
            {
                if (this.IsEnabled$2(5/*EventLevel.Verbose*/, -1n))
                {
                    this.ExceptionConsumedLtm($.$$.System.Exception.ToString.call(exception));
                }
            }
            /*void */ ExceptionConsumedBase(/*string*/ exceptionStr)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$$.System.String.Empty);
                this.WriteEvent$17(9/*EXCEPTION_CONSUMED_BASE_EVENTID*/, exceptionStr);
            }
            /*void */ ExceptionConsumedLtm(/*string*/ exceptionStr)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$$.System.String.Empty);
                this.WriteEvent$17(10/*EXCEPTION_CONSUMED_LTM_EVENTID*/, exceptionStr);
            }
            /*void */ ExceptionConsumedOleTx(/*string*/ exceptionStr)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$$.System.String.Empty);
                this.WriteEvent$17(43/*EXCEPTION_CONSUMED_OLETX_EVENTID*/, exceptionStr);
            }
            /*void */ OleTxTransactionManagerCreate$1(/*Type*/ tmType, /*string?*/ nodeName)
            {
                if (this.IsEnabled$2(5/*EventLevel.Verbose*/, -1n))
                {
                    this.OleTxTransactionManagerCreate($.$$.System.Type.ToString.call(tmType), nodeName);
                }
            }
            /*void */ OleTxTransactionManagerCreate(/*string*/ tmType, /*string?*/ nodeName)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$$.System.String.Empty);
                this.WriteEvent$16(57/*TRANSACTIONMANAGER_CREATE_OLETX_EVENTID*/, tmType, nodeName);
            }
            /*void */ TransactionManagerReenlist(/*Guid*/ resourceManagerID)
            {
                if (this.IsEnabled$2(4/*EventLevel.Informational*/, -1n))
                {
                    this.TransactionManagerReenlistTrace($.$$.System.Guid.ToString.call(resourceManagerID));
                }
            }
            /*void */ TransactionManagerReenlistTrace(/*string*/ rmID)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$$.System.String.Empty);
                this.WriteEvent$17(32/*TRANSACTIONMANAGER_REENLIST_EVENTID*/, rmID);
            }
            /*void */ TransactionManagerRecoveryComplete(/*Guid*/ resourceManagerID)
            {
                if (this.IsEnabled$2(4/*EventLevel.Informational*/, -1n))
                {
                    this.TransactionManagerRecoveryComplete$1($.$$.System.Guid.ToString.call(resourceManagerID));
                }
            }
            /*void */ TransactionManagerRecoveryComplete$1(/*string*/ rmID)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$$.System.String.Empty);
                this.WriteEvent$17(31/*TRANSACTIONMANAGER_RECOVERY_COMPLETE_EVENTID*/, rmID);
            }
            /*void */ ConfiguredDefaultTimeoutAdjusted()
            {
                if (this.IsEnabled$2(3/*EventLevel.Warning*/, -1n))
                {
                    this.ConfiguredDefaultTimeoutAdjustedTrace();
                }
            }
            /*void */ ConfiguredDefaultTimeoutAdjustedTrace()
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$$.System.String.Empty);
                this.WriteEvent$18(1/*CONFIGURED_DEFAULT_TIMEOUT_ADJUSTED_EVENTID*/);
            }
            /*void */ TransactionScopeCreated$1(/*TransactionTraceIdentifier*/ transactionID, /*TransactionScopeResult*/ transactionScopeResult)
            {
                if (this.IsEnabled$2(4/*EventLevel.Informational*/, -1n))
                {
                    this.TransactionScopeCreated(transactionID.TransactionIdentifier ?? $.$$.System.String.Empty, transactionScopeResult);
                }
            }
            /*void */ TransactionScopeCreated(/*string*/ transactionID, /*TransactionScopeResult*/ transactionScopeResult)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionID);
                this.WriteEvent$1(33/*TRANSACTIONSCOPE_CREATED_EVENTID*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive), [ $.$$.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$15(transactionID), $.$$.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$7($.$box(transactionScopeResult, $.$stl.System.Transactions.TransactionScopeResult)) ], null, null));
            }
            /*void */ TransactionScopeCurrentChanged$1(/*TransactionTraceIdentifier*/ currenttransactionID, /*TransactionTraceIdentifier*/ newtransactionID)
            {
                if (this.IsEnabled$2(3/*EventLevel.Warning*/, -1n))
                {
                    /*string*/ let currentId = $.$$.System.String.Empty;
                    /*string*/ let newId = $.$$.System.String.Empty;
                    if ($.$$.System.String.op_Inequality(currenttransactionID.TransactionIdentifier, null))
                    {
                        currentId = $.$$.System.String.ToString.call(currenttransactionID.TransactionIdentifier);
                    }
                    if ($.$$.System.String.op_Inequality(newtransactionID.TransactionIdentifier, null))
                    {
                        newId = $.$$.System.String.ToString.call(newtransactionID.TransactionIdentifier);
                    }
                    this.TransactionScopeCurrentChanged(currentId, newId);
                }
            }
            /*void */ TransactionScopeCurrentChanged(/*string*/ currenttransactionID, /*string*/ newtransactionID)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(newtransactionID);
                this.WriteEvent$16(34/*TRANSACTIONSCOPE_CURRENT_CHANGED_EVENTID*/, currenttransactionID, newtransactionID);
            }
            /*void */ TransactionScopeNestedIncorrectly$1(/*TransactionTraceIdentifier*/ transactionID)
            {
                if (this.IsEnabled$2(3/*EventLevel.Warning*/, -1n))
                {
                    this.TransactionScopeNestedIncorrectly(transactionID.TransactionIdentifier ?? $.$$.System.String.Empty);
                }
            }
            /*void */ TransactionScopeNestedIncorrectly(/*string*/ transactionID)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionID);
                this.WriteEvent$17(38/*TRANSACTIONSCOPE_NESTED_INCORRECTLY_EVENTID*/, transactionID);
            }
            /*void */ TransactionScopeDisposed$1(/*TransactionTraceIdentifier*/ transactionID)
            {
                if (this.IsEnabled$2(4/*EventLevel.Informational*/, -1n))
                {
                    this.TransactionScopeDisposed(transactionID.TransactionIdentifier ?? $.$$.System.String.Empty);
                }
            }
            /*void */ TransactionScopeDisposed(/*string*/ transactionID)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionID);
                this.WriteEvent$17(35/*TRANSACTIONSCOPE_DISPOSED_EVENTID*/, transactionID);
            }
            /*void */ TransactionScopeIncomplete$1(/*TransactionTraceIdentifier*/ transactionID)
            {
                if (this.IsEnabled$2(3/*EventLevel.Warning*/, -1n))
                {
                    this.TransactionScopeIncomplete(transactionID.TransactionIdentifier ?? $.$$.System.String.Empty);
                }
            }
            /*void */ TransactionScopeIncomplete(/*string*/ transactionID)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionID);
                this.WriteEvent$17(36/*TRANSACTIONSCOPE_INCOMPLETE_EVENTID*/, transactionID);
            }
            /*void */ TransactionScopeTimeout$1(/*TransactionTraceIdentifier*/ transactionID)
            {
                if (this.IsEnabled$2(3/*EventLevel.Warning*/, -1n))
                {
                    this.TransactionScopeTimeout(transactionID.TransactionIdentifier ?? $.$$.System.String.Empty);
                }
            }
            /*void */ TransactionScopeTimeout(/*string*/ transactionID)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionID);
                this.WriteEvent$17(39/*TRANSACTIONSCOPE_TIMEOUT_EVENTID*/, transactionID);
            }
            /*void */ TransactionTimeout$1(/*TransactionTraceIdentifier*/ transactionID)
            {
                if (this.IsEnabled$2(3/*EventLevel.Warning*/, -1n))
                {
                    this.TransactionTimeout(transactionID.TransactionIdentifier ?? $.$$.System.String.Empty);
                }
            }
            /*void */ TransactionTimeout(/*string*/ transactionID)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionID);
                this.WriteEvent$17(30/*TRANSACTION_TIMEOUT_EVENTID*/, transactionID);
            }
            /*void */ TransactionstateEnlist$1(/*EnlistmentTraceIdentifier*/ enlistmentID, /*EnlistmentType*/ enlistmentType, /*EnlistmentOptions*/ enlistmentOption)
            {
                if (this.IsEnabled$2(4/*EventLevel.Informational*/, -1n))
                {
                    if (enlistmentID.EnlistmentIdentifier !== 0)
                    {
                        this.TransactionstateEnlist($.$$.System.Int32.ToString.call(enlistmentID.EnlistmentIdentifier), $.$$.System.Enum.ToStringT($.$stl.System.Transactions.EnlistmentType, $.$$.System.UInt32, enlistmentType), $.$$.System.Enum.ToStringT($.$stl.System.Transactions.EnlistmentOptions, $.$$.System.UInt32, enlistmentOption));
                    }
                    else 
                    {
                        this.TransactionstateEnlist($.$$.System.String.Empty, $.$$.System.Enum.ToStringT($.$stl.System.Transactions.EnlistmentType, $.$$.System.UInt32, enlistmentType), $.$$.System.Enum.ToStringT($.$stl.System.Transactions.EnlistmentOptions, $.$$.System.UInt32, enlistmentOption));
                    }
                }
            }
            /*void */ TransactionstateEnlist(/*string*/ enlistmentID, /*string*/ type, /*string*/ option)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$$.System.String.Empty);
                this.WriteEvent$15(40/*TRANSACTIONSTATE_ENLIST_EVENTID*/, enlistmentID, type, option);
            }
            /*void */ TransactionCommitted(/*TraceSourceType*/ traceSource, /*TransactionTraceIdentifier*/ transactionID)
            {
                if (this.IsEnabled$2(5/*EventLevel.Verbose*/, -1n))
                {
                    if (traceSource === 1/*TraceSourceType.TraceSourceLtm*/)
                    {
                        this.TransactionCommittedLtm(transactionID.TransactionIdentifier ?? $.$$.System.String.Empty);
                    }
                    else if (traceSource === 2/*TraceSourceType.TraceSourceOleTx*/)
                    {
                        this.TransactionCommittedOleTx(transactionID.TransactionIdentifier ?? $.$$.System.String.Empty);
                    }
                }
            }
            /*void */ TransactionCommittedLtm(/*string*/ transactionID)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionID);
                this.WriteEvent$17(20/*TRANSACTION_COMMITTED_LTM_EVENTID*/, transactionID);
            }
            /*void */ TransactionCommittedOleTx(/*string*/ transactionID)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionID);
                this.WriteEvent$17(44/*TRANSACTION_COMMITTED_OLETX_EVENTID*/, transactionID);
            }
            /*void */ TransactionInDoubt(/*TraceSourceType*/ traceSource, /*TransactionTraceIdentifier*/ transactionID)
            {
                if (this.IsEnabled$2(3/*EventLevel.Warning*/, -1n))
                {
                    if (traceSource === 1/*TraceSourceType.TraceSourceLtm*/)
                    {
                        this.TransactionInDoubtLtm(transactionID.TransactionIdentifier ?? $.$$.System.String.Empty);
                    }
                    else if (traceSource === 2/*TraceSourceType.TraceSourceOleTx*/)
                    {
                        this.TransactionInDoubtOleTx(transactionID.TransactionIdentifier ?? $.$$.System.String.Empty);
                    }
                }
            }
            /*void */ TransactionInDoubtLtm(/*string*/ transactionID)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionID);
                this.WriteEvent$17(25/*TRANSACTION_INDOUBT_LTM_EVENTID*/, transactionID);
            }
            /*void */ TransactionInDoubtOleTx(/*string*/ transactionID)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionID);
                this.WriteEvent$17(46/*TRANSACTION_INDOUBT_OLETX_EVENTID*/, transactionID);
            }
            /*void */ TransactionPromoted$1(/*TransactionTraceIdentifier*/ transactionID, /*TransactionTraceIdentifier*/ distributedTxID)
            {
                if (this.IsEnabled$2(4/*EventLevel.Informational*/, -1n))
                {
                    this.TransactionPromoted(transactionID.TransactionIdentifier ?? $.$$.System.String.Empty, distributedTxID.TransactionIdentifier ?? $.$$.System.String.Empty);
                }
            }
            /*void */ TransactionPromoted(/*string*/ transactionID, /*string*/ distributedTxID)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionID);
                this.WriteEvent$16(27/*TRANSACTION_PROMOTED_EVENTID*/, transactionID, distributedTxID);
            }
            /*void */ TransactionAborted(/*TraceSourceType*/ traceSource, /*TransactionTraceIdentifier*/ transactionID)
            {
                if (this.IsEnabled$2(3/*EventLevel.Warning*/, -1n))
                {
                    if (traceSource === 1/*TraceSourceType.TraceSourceLtm*/)
                    {
                        this.TransactionAbortedLtm(transactionID.TransactionIdentifier ?? $.$$.System.String.Empty);
                    }
                    else if (traceSource === 2/*TraceSourceType.TraceSourceOleTx*/)
                    {
                        this.TransactionAbortedOleTx(transactionID.TransactionIdentifier ?? $.$$.System.String.Empty);
                    }
                }
            }
            /*void */ TransactionAbortedLtm(/*string*/ transactionID)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionID);
                this.WriteEvent$17(17/*TRANSACTION_ABORTED_LTM_EVENTID*/, transactionID);
            }
            /*void */ TransactionAbortedOleTx(/*string*/ transactionID)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionID);
                this.WriteEvent$17(45/*TRANSACTION_ABORTED_OLETX_EVENTID*/, transactionID);
            }
            /*void */ InternalError(/*string?*/ error)
            {
                if (this.IsEnabled$2(1/*EventLevel.Critical*/, -1n))
                {
                    this.InternalErrorTrace(error);
                }
            }
            /*void */ InternalErrorTrace(/*string?*/ error)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$$.System.String.Empty);
                this.WriteEvent$17(37/*INTERNAL_ERROR_EVENTID*/, error);
            }
            static $_Opcodes;
            static get Opcodes()
            {
                let $cls = $.$stl.System.Transactions.TransactionsEtwProvider;
                return $cls.$_Opcodes ??= $asm.$ncls("$stl.System.Transactions.TransactionsEtwProvider.Opcodes", ($self) => class Opcodes
                {
                    /*EventOpcode*/ static Aborted = 100;
                    /*EventOpcode*/ static Activity = 101;
                    /*EventOpcode*/ static Adjusted = 102;
                    /*EventOpcode*/ static CloneCreate = 103;
                    /*EventOpcode*/ static Commit = 104;
                    /*EventOpcode*/ static Committed = 105;
                    /*EventOpcode*/ static Create = 106;
                    /*EventOpcode*/ static Created = 107;
                    /*EventOpcode*/ static CurrentChanged = 108;
                    /*EventOpcode*/ static DependentCloneComplete = 109;
                    /*EventOpcode*/ static Disposed = 110;
                    /*EventOpcode*/ static Done = 111;
                    /*EventOpcode*/ static Enlist = 112;
                    /*EventOpcode*/ static Enter = 113;
                    /*EventOpcode*/ static ExceptionConsumed = 114;
                    /*EventOpcode*/ static Exit = 115;
                    /*EventOpcode*/ static ForceRollback = 116;
                    /*EventOpcode*/ static Incomplete = 117;
                    /*EventOpcode*/ static InDoubt = 118;
                    /*EventOpcode*/ static InternalError = 119;
                    /*EventOpcode*/ static InvalidOperation = 120;
                    /*EventOpcode*/ static NestedIncorrectly = 121;
                    /*EventOpcode*/ static Prepared = 122;
                    /*EventOpcode*/ static Promoted = 123;
                    /*EventOpcode*/ static RecoveryComplete = 124;
                    /*EventOpcode*/ static Reenlist = 125;
                    /*EventOpcode*/ static Rollback = 126;
                    /*EventOpcode*/ static Serialized = 127;
                    /*EventOpcode*/ static Timeout = 128;
                    /*EventOpcode*/ static CallbackPositive = 129;
                    /*EventOpcode*/ static CallbackNegative = 130;
                    static $h = 5547276;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":41156609,"n":"Aborted","d":5547276,"h":4300514572,"f":4194337},{"t":41156609,"n":"Activity","d":5547276,"h":8595481868,"f":4194337},{"t":41156609,"n":"Adjusted","d":5547276,"h":12890449164,"f":4194337},{"t":41156609,"n":"CloneCreate","d":5547276,"h":17185416460,"f":4194337},{"t":41156609,"n":"Commit","d":5547276,"h":21480383756,"f":4194337},{"t":41156609,"n":"Committed","d":5547276,"h":25775351052,"f":4194337},{"t":41156609,"n":"Create","d":5547276,"h":30070318348,"f":4194337},{"t":41156609,"n":"Created","d":5547276,"h":34365285644,"f":4194337},{"t":41156609,"n":"CurrentChanged","d":5547276,"h":38660252940,"f":4194337},{"t":41156609,"n":"DependentCloneComplete","d":5547276,"h":42955220236,"f":4194337},{"t":41156609,"n":"Disposed","d":5547276,"h":47250187532,"f":4194337},{"t":41156609,"n":"Done","d":5547276,"h":51545154828,"f":4194337},{"t":41156609,"n":"Enlist","d":5547276,"h":55840122124,"f":4194337},{"t":41156609,"n":"Enter","d":5547276,"h":60135089420,"f":4194337},{"t":41156609,"n":"ExceptionConsumed","d":5547276,"h":64430056716,"f":4194337},{"t":41156609,"n":"Exit","d":5547276,"h":68725024012,"f":4194337},{"t":41156609,"n":"ForceRollback","d":5547276,"h":73019991308,"f":4194337},{"t":41156609,"n":"Incomplete","d":5547276,"h":77314958604,"f":4194337},{"t":41156609,"n":"InDoubt","d":5547276,"h":81609925900,"f":4194337},{"t":41156609,"n":"InternalError","d":5547276,"h":85904893196,"f":4194337},{"t":41156609,"n":"InvalidOperation","d":5547276,"h":90199860492,"f":4194337},{"t":41156609,"n":"NestedIncorrectly","d":5547276,"h":94494827788,"f":4194337},{"t":41156609,"n":"Prepared","d":5547276,"h":98789795084,"f":4194337},{"t":41156609,"n":"Promoted","d":5547276,"h":103084762380,"f":4194337},{"t":41156609,"n":"RecoveryComplete","d":5547276,"h":107379729676,"f":4194337},{"t":41156609,"n":"Reenlist","d":5547276,"h":111674696972,"f":4194337},{"t":41156609,"n":"Rollback","d":5547276,"h":115969664268,"f":4194337},{"t":41156609,"n":"Serialized","d":5547276,"h":120264631564,"f":4194337},{"t":41156609,"n":"Timeout","d":5547276,"h":124559598860,"f":4194337},{"t":41156609,"n":"CallbackPositive","d":5547276,"h":128854566156,"f":4194337},{"t":41156609,"n":"CallbackNegative","d":5547276,"h":133149533452,"f":4194337}],"d":5416204,"h":5547276}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Transactions.TransactionsEtwProvider.Opcodes`; }
                }, $cls, ($v) => $cls.$_Opcodes = $v);
            }
            static $_Tasks;
            static get Tasks()
            {
                let $cls = $.$stl.System.Transactions.TransactionsEtwProvider;
                return $cls.$_Tasks ??= $asm.$ncls("$stl.System.Transactions.TransactionsEtwProvider.Tasks", ($self) => class Tasks
                {
                    /*EventTask*/ static ConfiguredDefaultTimeout = 1;
                    /*EventTask*/ static Enlistment = 2;
                    /*EventTask*/ static ResourceManager = 3;
                    /*EventTask*/ static Method = 4;
                    /*EventTask*/ static Transaction = 5;
                    /*EventTask*/ static TransactionException = 6;
                    /*EventTask*/ static TransactionManager = 7;
                    /*EventTask*/ static TransactionScope = 8;
                    /*EventTask*/ static TransactionState = 9;
                    static $h = 5612812;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":42598401,"n":"ConfiguredDefaultTimeout","d":5612812,"h":4300580108,"f":4194337},{"t":42598401,"n":"Enlistment","d":5612812,"h":8595547404,"f":4194337},{"t":42598401,"n":"ResourceManager","d":5612812,"h":12890514700,"f":4194337},{"t":42598401,"n":"Method","d":5612812,"h":17185481996,"f":4194337},{"t":42598401,"n":"Transaction","d":5612812,"h":21480449292,"f":4194337},{"t":42598401,"n":"TransactionManager","d":5612812,"h":30070383884,"f":4194337},{"t":42598401,"n":"TransactionScope","d":5612812,"h":34365351180,"f":4194337},{"t":42598401,"n":"TransactionState","d":5612812,"h":38660318476,"f":4194337}],"d":5416204,"h":5612812}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Transactions.TransactionsEtwProvider.Tasks`; }
                }, $cls, ($v) => $cls.$_Tasks = $v);
            }
            static $_Keywords;
            static get Keywords()
            {
                let $cls = $.$stl.System.Transactions.TransactionsEtwProvider;
                return $cls.$_Keywords ??= $asm.$ncls("$stl.System.Transactions.TransactionsEtwProvider.Keywords", ($self) => class Keywords
                {
                    /*EventKeywords*/ static TraceBase = 1n;
                    /*EventKeywords*/ static TraceLtm = 2n;
                    /*EventKeywords*/ static TraceOleTx = 4n;
                    static $h = 5481740;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":40894465,"n":"TraceBase","d":5481740,"h":4300449036,"f":4194337},{"t":40894465,"n":"TraceLtm","d":5481740,"h":8595416332,"f":4194337},{"t":40894465,"n":"TraceOleTx","d":5481740,"h":12890383628,"f":4194337}],"d":5416204,"h":5481740}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Transactions.TransactionsEtwProvider.Keywords`; }
                }, $cls, ($v) => $cls.$_Keywords = $v);
            }
            static /*void */ SetActivityId(/*string*/ str)
            {
                /*Guid*/ let guid = $.$$.System.Guid.Empty;
                if ($.$$.System.String.Contains$1.call(str, /*-*/ 45))
                {
                    if (str.length >= 36)
                    {
                        $.$$.System.Guid.TryParse$3($.$$.System.MemoryExtensions.AsSpan$1(str, 0, 36), $.$ref(() => guid, ($v) => guid = $v, $.$$.System.Guid));
                    }
                }
                else 
                {
                    if (str.length >= 32)
                    {
                        $.$$.System.Guid.TryParse$3($.$$.System.MemoryExtensions.AsSpan$1(str, 0, 32), $.$ref(() => guid, ($v) => guid = $v, $.$$.System.Guid));
                    }
                }
                $.$$.System.Diagnostics.Tracing.EventSource.SetCurrentThreadActivityId$1(guid);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Log = new $.$stl.System.Transactions.TransactionsEtwProvider().$ctor$10();
                }
                {
                    this.NullInstance = "(null)";
                }
            }
            static $h = 5416204;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":41746433,"m":[{"r":1310721,"p":[{"n":"value","p":131073}],"n":"IdOf","d":5416204,"h":266293388556,"f":16777249,"a":[{"t":44302337,"c":4339269633}]},{"r":655361,"p":[{"n":"value","p":131073}],"n":"GetHashCode","o":"@$1","d":5416204,"h":270588355852,"f":16777249,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"traceSource","p":4236556},{"n":"txTraceId","p":8561932},{"n":"type","p":1310721}],"n":"TransactionCreated","d":5416204,"h":274883323148,"f":16777224,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"transactionIdentifier","p":1310721},{"n":"type","p":1310721}],"n":"TransactionCreatedLtm","d":5416204,"h":279178290444,"f":16777218,"a":[{"t":39976961,"c":4334944257,"a":[{"v":21,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":4,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":106,"t":41156609},{"n":"Message","v":"Transaction Created (LTM). ID is {0}, type is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionIdentifier","p":1310721},{"n":"type","p":1310721}],"n":"TransactionCreatedOleTx","d":5416204,"h":283473257740,"f":16777218,"a":[{"t":39976961,"c":4334944257,"a":[{"v":51,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40894465},{"n":"Level","v":4,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":106,"t":41156609},{"n":"Message","v":"Transaction Created (OLETX). ID is {0}, type is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"transaction","p":4302092},{"n":"type","p":1310721}],"n":"TransactionCloneCreate","o":"@$1","d":5416204,"h":287768225036,"f":16777224,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"transactionIdentifier","p":1310721},{"n":"type","p":1310721}],"n":"TransactionCloneCreate","d":5416204,"h":292063192332,"f":16777218,"a":[{"t":39976961,"c":4334944257,"a":[{"v":18,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":4,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":103,"t":41156609},{"n":"Message","v":"Transaction Clone Created. ID is {0}, type is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionTraceId","p":8561932}],"n":"TransactionSerialized","o":"@$1","d":5416204,"h":296358159628,"f":16777224,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"transactionIdentifier","p":1310721}],"n":"TransactionSerialized","d":5416204,"h":300653126924,"f":16777218,"a":[{"t":39976961,"c":4334944257,"a":[{"v":29,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40894465},{"n":"Level","v":4,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":127,"t":41156609},{"n":"Message","v":"Transaction Serialized. ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionTraceId","p":8561932}],"n":"TransactionDeserialized","o":"@$1","d":5416204,"h":304948094220,"f":16777224,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"transactionIdentifier","p":1310721}],"n":"TransactionDeserialized","d":5416204,"h":309243061516,"f":16777218,"a":[{"t":39976961,"c":4334944257,"a":[{"v":50,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40894465},{"n":"Level","v":5,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":127,"t":41156609},{"n":"Message","v":"Transaction Deserialized. ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"traceSource","p":4236556},{"n":"type","p":4629772},{"n":"message","p":1310721},{"n":"innerExceptionStr","p":1310721}],"n":"TransactionExceptionTrace","d":5416204,"h":313538028812,"f":16777224,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"type","p":4629772},{"n":"message","p":1310721},{"n":"innerExceptionStr","p":1310721}],"n":"TransactionExceptionTrace","o":"@$1","d":5416204,"h":317832996108,"f":16777224,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"type","p":1310721},{"n":"message","p":1310721},{"n":"innerExceptionStr","p":1310721}],"n":"TransactionExceptionBase","d":5416204,"h":322127963404,"f":16777218,"a":[{"t":39976961,"c":4334944257,"a":[{"v":24,"t":655361}],"n":[{"n":"Keywords","v":1,"t":40894465},{"n":"Level","v":2,"t":40960001},{"n":"Task","v":6,"t":42598401},{"n":"Message","v":"Transaction Exception. Type is {0}, message is {1}, InnerException is {2}","t":1310721}]}]},{"r":65537,"p":[{"n":"type","p":1310721},{"n":"message","p":1310721},{"n":"innerExceptionStr","p":1310721}],"n":"TransactionExceptionLtm","d":5416204,"h":326422930700,"f":16777218,"a":[{"t":39976961,"c":4334944257,"a":[{"v":23,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":2,"t":40960001},{"n":"Task","v":6,"t":42598401},{"n":"Message","v":"Transaction Exception. Type is {0}, message is {1}, InnerException is {2}","t":1310721}]}]},{"r":65537,"p":[{"n":"type","p":1310721},{"n":"operation","p":1310721}],"n":"InvalidOperation","d":5416204,"h":330717897996,"f":16777224,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"transactionIdentifier","p":1310721},{"n":"type","p":1310721},{"n":"operation","p":1310721}],"n":"TransactionInvalidOperation","d":5416204,"h":335012865292,"f":16777218,"a":[{"t":39976961,"c":4334944257,"a":[{"v":26,"t":655361}],"n":[{"n":"Keywords","v":1,"t":40894465},{"n":"Level","v":2,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":120,"t":41156609},{"n":"Message","v":"Transaction Invalid Operation. ID is {0}, type is {1} and operation is {2}","t":1310721}]}]},{"r":65537,"p":[{"n":"traceSource","p":4236556},{"n":"txTraceId","p":8561932},{"n":"type","p":1310721}],"n":"TransactionRollback","d":5416204,"h":339307832588,"f":16777224,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"transactionIdentifier","p":1310721},{"n":"type","p":1310721}],"n":"TransactionRollbackLtm","d":5416204,"h":343602799884,"f":16777218,"a":[{"t":39976961,"c":4334944257,"a":[{"v":28,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":3,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":126,"t":41156609},{"n":"Message","v":"Transaction LTM Rollback. ID is {0}, type is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionIdentifier","p":1310721},{"n":"type","p":1310721}],"n":"TransactionRollbackOleTx","d":5416204,"h":347897767180,"f":16777218,"a":[{"t":39976961,"c":4334944257,"a":[{"v":42,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40894465},{"n":"Level","v":3,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":126,"t":41156609},{"n":"Message","v":"Transaction OleTx Rollback. ID is {0}, type is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"traceSource","p":4236556},{"n":"txTraceId","p":8561932},{"n":"option","p":1090828}],"n":"TransactionDependentCloneCreate","d":5416204,"h":352192734476,"f":16777224,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"transactionIdentifier","p":1310721},{"n":"option","p":1310721}],"n":"TransactionDependentCloneCreateLtm","d":5416204,"h":356487701772,"f":16777218,"a":[{"t":39976961,"c":4334944257,"a":[{"v":48,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":4,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":109,"t":41156609},{"n":"Message","v":"Transaction Dependent Clone Created (LTM). ID is {0}, option is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionIdentifier","p":1310721},{"n":"option","p":1310721}],"n":"TransactionDependentCloneCreateOleTx","d":5416204,"h":360782669068,"f":16777218,"a":[{"t":39976961,"c":4334944257,"a":[{"v":49,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40894465},{"n":"Level","v":4,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":109,"t":41156609},{"n":"Message","v":"Transaction Dependent Clone Created (OLETX). ID is {0}, option is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"traceSource","p":4236556},{"n":"txTraceId","p":8561932},{"n":"type","p":1310721}],"n":"TransactionDependentCloneComplete","d":5416204,"h":365077636364,"f":16777224,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"transactionIdentifier","p":1310721},{"n":"type","p":1310721}],"n":"TransactionDependentCloneCompleteLtm","d":5416204,"h":369372603660,"f":16777218,"a":[{"t":39976961,"c":4334944257,"a":[{"v":22,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":4,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":109,"t":41156609},{"n":"Message","v":"Transaction Dependent Clone Completed (LTM). ID is {0}, type is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionIdentifier","p":1310721},{"n":"type","p":1310721}],"n":"TransactionDependentCloneCompleteOleTx","d":5416204,"h":373667570956,"f":16777218,"a":[{"t":39976961,"c":4334944257,"a":[{"v":47,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40894465},{"n":"Level","v":4,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":109,"t":41156609},{"n":"Message","v":"Transaction Dependent Clone Completed (OLETX). ID is {0}, type is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"traceSource","p":4236556},{"n":"txTraceId","p":8561932},{"n":"type","p":1310721}],"n":"TransactionCommit","d":5416204,"h":377962538252,"f":16777224,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"transactionIdentifier","p":1310721},{"n":"type","p":1310721}],"n":"TransactionCommitLtm","d":5416204,"h":382257505548,"f":16777218,"a":[{"t":39976961,"c":4334944257,"a":[{"v":19,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":5,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":104,"t":41156609},{"n":"Message","v":"Transaction LTM Commit: ID is {0}, type is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionIdentifier","p":1310721},{"n":"type","p":1310721}],"n":"TransactionCommitOleTx","d":5416204,"h":386552472844,"f":16777218,"a":[{"t":39976961,"c":4334944257,"a":[{"v":41,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40894465},{"n":"Level","v":5,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":104,"t":41156609},{"n":"Message","v":"Transaction OleTx Commit: ID is {0}, type is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"traceSource","p":4236556},{"n":"enlistmentTraceId","p":2073868},{"n":"notificationCall","p":3319052}],"n":"EnlistmentStatus","d":5416204,"h":390847440140,"f":16777224,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"enlistmentIdentifier","p":655361},{"n":"notificationCall","p":1310721}],"n":"EnlistmentStatusLtm","d":5416204,"h":395142407436,"f":16777218,"a":[{"t":39976961,"c":4334944257,"a":[{"v":5,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":5,"t":40960001},{"n":"Task","v":2,"t":42598401},{"n":"Message","v":"Enlistment status (LTM): ID is {0}, notificationcall is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"enlistmentIdentifier","p":655361},{"n":"notificationCall","p":1310721}],"n":"EnlistmentStatusOleTx","d":5416204,"h":399437374732,"f":16777218,"a":[{"t":39976961,"c":4334944257,"a":[{"v":52,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40894465},{"n":"Level","v":5,"t":40960001},{"n":"Task","v":2,"t":42598401},{"n":"Message","v":"Enlistment status (OLETX): ID is {0}, notificationcall is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"traceSource","p":4236556},{"n":"enlistmentTraceId","p":2073868},{"n":"enlistmentType","p":2139404},{"n":"enlistmentOptions","p":1877260}],"n":"EnlistmentCreated","d":5416204,"h":403732342028,"f":16777224,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"enlistmentIdentifier","p":655361},{"n":"enlistmentType","p":1310721},{"n":"enlistmentOptions","p":1310721}],"n":"EnlistmentCreatedLtm","d":5416204,"h":408027309324,"f":16777218,"a":[{"t":39976961,"c":4334944257,"a":[{"v":55,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":4,"t":40960001},{"n":"Task","v":2,"t":42598401},{"n":"Opcode","v":106,"t":41156609},{"n":"Message","v":"Enlistment Created (LTM). ID is {0}, type is {1}, options is {2}","t":1310721}]}]},{"r":65537,"p":[{"n":"enlistmentIdentifier","p":655361},{"n":"enlistmentType","p":1310721},{"n":"enlistmentOptions","p":1310721}],"n":"EnlistmentCreatedOleTx","d":5416204,"h":412322276620,"f":16777218,"a":[{"t":39976961,"c":4334944257,"a":[{"v":56,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40894465},{"n":"Level","v":4,"t":40960001},{"n":"Task","v":2,"t":42598401},{"n":"Opcode","v":106,"t":41156609},{"n":"Message","v":"Enlistment Created (OLETX). ID is {0}, type is {1}, options is {2}","t":1310721}]}]},{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"EnlistmentDone","o":"@$1","d":5416204,"h":416617243916,"f":16777224,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"enlistmentIdentifier","p":655361}],"n":"EnlistmentDone","d":5416204,"h":420912211212,"f":16777218,"a":[{"t":39976961,"c":4334944257,"a":[{"v":4,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":5,"t":40960001},{"n":"Task","v":2,"t":42598401},{"n":"Opcode","v":111,"t":41156609},{"n":"Message","v":"Enlistment.Done: ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"EnlistmentPrepared","o":"@$1","d":5416204,"h":425207178508,"f":16777224,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"enlistmentIdentifier","p":655361}],"n":"EnlistmentPrepared","d":5416204,"h":429502145804,"f":16777218,"a":[{"t":39976961,"c":4334944257,"a":[{"v":8,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":5,"t":40960001},{"n":"Task","v":2,"t":42598401},{"n":"Opcode","v":122,"t":41156609},{"n":"Message","v":"PreparingEnlistment.Prepared: ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"EnlistmentForceRollback","o":"@$1","d":5416204,"h":433797113100,"f":16777224,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"enlistmentIdentifier","p":655361}],"n":"EnlistmentForceRollback","d":5416204,"h":438092080396,"f":16777218,"a":[{"t":39976961,"c":4334944257,"a":[{"v":6,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":3,"t":40960001},{"n":"Task","v":2,"t":42598401},{"n":"Opcode","v":116,"t":41156609},{"n":"Message","v":"Enlistment forceRollback: ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"EnlistmentAborted","o":"@$1","d":5416204,"h":442387047692,"f":16777224,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"enlistmentIdentifier","p":655361}],"n":"EnlistmentAborted","d":5416204,"h":446682014988,"f":16777218,"a":[{"t":39976961,"c":4334944257,"a":[{"v":2,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":3,"t":40960001},{"n":"Task","v":2,"t":42598401},{"n":"Opcode","v":100,"t":41156609},{"n":"Message","v":"Enlistment SinglePhase Aborted: ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"EnlistmentCommitted","o":"@$1","d":5416204,"h":450976982284,"f":16777224,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"enlistmentIdentifier","p":655361}],"n":"EnlistmentCommitted","d":5416204,"h":455271949580,"f":16777218,"a":[{"t":39976961,"c":4334944257,"a":[{"v":3,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":5,"t":40960001},{"n":"Task","v":2,"t":42598401},{"n":"Opcode","v":105,"t":41156609},{"n":"Message","v":"Enlistment Committed: ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"EnlistmentInDoubt","o":"@$1","d":5416204,"h":459566916876,"f":16777224,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"enlistmentIdentifier","p":655361}],"n":"EnlistmentInDoubt","d":5416204,"h":463861884172,"f":16777218,"a":[{"t":39976961,"c":4334944257,"a":[{"v":7,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":3,"t":40960001},{"n":"Task","v":2,"t":42598401},{"n":"Opcode","v":118,"t":41156609},{"n":"Message","v":"Enlistment SinglePhase InDoubt: ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"enlistmentTraceIdentifier","p":2073868},{"n":"callback","p":1811724}],"n":"EnlistmentCallbackPositive","o":"@$1","d":5416204,"h":468156851468,"f":16777224,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"enlistmentIdentifier","p":655361},{"n":"callback","p":1310721}],"n":"EnlistmentCallbackPositive","d":5416204,"h":472451818764,"f":16777218,"a":[{"t":39976961,"c":4334944257,"a":[{"v":53,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40894465},{"n":"Level","v":5,"t":40960001},{"n":"Task","v":2,"t":42598401},{"n":"Opcode","v":129,"t":41156609},{"n":"Message","v":"Enlistment callback positive: ID is {0}, callback is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"enlistmentTraceIdentifier","p":2073868},{"n":"callback","p":1811724}],"n":"EnlistmentCallbackNegative","o":"@$1","d":5416204,"h":476746786060,"f":16777224,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"enlistmentIdentifier","p":655361},{"n":"callback","p":1310721}],"n":"EnlistmentCallbackNegative","d":5416204,"h":481041753356,"f":16777218,"a":[{"t":39976961,"c":4334944257,"a":[{"v":54,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40894465},{"n":"Level","v":3,"t":40960001},{"n":"Task","v":2,"t":42598401},{"n":"Opcode","v":130,"t":41156609},{"n":"Message","v":"Enlistment callback negative: ID is {0}, callback is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"traceSource","p":4236556},{"n":"thisOrContextObject","p":131073},{"n":"methodname","p":1310721,"f":65,"a":[{"t":88014849,"c":4382982145}]}],"n":"MethodEnter","d":5416204,"h":485336720652,"f":16777224,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"traceSource","p":4236556},{"n":"methodname","p":1310721,"f":65,"a":[{"t":88014849,"c":4382982145}]}],"n":"MethodEnter","o":"@$1","d":5416204,"h":489631687948,"f":16777224,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"thisOrContextObject","p":1310721},{"n":"methodname","p":1310721}],"n":"MethodEnterTraceLtm","d":5416204,"h":493926655244,"f":16777218,"a":[{"t":39976961,"c":4334944257,"a":[{"v":11,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":5,"t":40960001},{"n":"Task","v":4,"t":42598401},{"n":"Opcode","v":113,"t":41156609},{"n":"Message","v":"Enter method : {0}.{1}","t":1310721}]}]},{"r":65537,"p":[{"n":"thisOrContextObject","p":1310721},{"n":"methodname","p":1310721}],"n":"MethodEnterTraceBase","d":5416204,"h":498221622540,"f":16777218,"a":[{"t":39976961,"c":4334944257,"a":[{"v":13,"t":655361}],"n":[{"n":"Keywords","v":1,"t":40894465},{"n":"Level","v":5,"t":40960001},{"n":"Task","v":4,"t":42598401},{"n":"Opcode","v":113,"t":41156609},{"n":"Message","v":"Enter method : {0}.{1}","t":1310721}]}]},{"r":65537,"p":[{"n":"thisOrContextObject","p":1310721},{"n":"methodname","p":1310721}],"n":"MethodEnterTraceDistributed","d":5416204,"h":502516589836,"f":16777218,"a":[{"t":39976961,"c":4334944257,"a":[{"v":15,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40894465},{"n":"Level","v":5,"t":40960001},{"n":"Task","v":4,"t":42598401},{"n":"Opcode","v":113,"t":41156609},{"n":"Message","v":"Enter method : {0}.{1}","t":1310721}]}]},{"r":65537,"p":[{"n":"traceSource","p":4236556},{"n":"thisOrContextObject","p":131073},{"n":"methodname","p":1310721,"f":65,"a":[{"t":88014849,"c":4382982145}]}],"n":"MethodExit","d":5416204,"h":506811557132,"f":16777224,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"traceSource","p":4236556},{"n":"methodname","p":1310721,"f":65,"a":[{"t":88014849,"c":4382982145}]}],"n":"MethodExit","o":"@$1","d":5416204,"h":511106524428,"f":16777224,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"thisOrContextObject","p":1310721},{"n":"methodname","p":1310721}],"n":"MethodExitTraceLtm","d":5416204,"h":515401491724,"f":16777218,"a":[{"t":39976961,"c":4334944257,"a":[{"v":12,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":5,"t":40960001},{"n":"Task","v":4,"t":42598401},{"n":"Opcode","v":115,"t":41156609},{"n":"Message","v":"Exit method: {0}.{1}","t":1310721}]}]},{"r":65537,"p":[{"n":"thisOrContextObject","p":1310721},{"n":"methodname","p":1310721}],"n":"MethodExitTraceBase","d":5416204,"h":519696459020,"f":16777218,"a":[{"t":39976961,"c":4334944257,"a":[{"v":14,"t":655361}],"n":[{"n":"Keywords","v":1,"t":40894465},{"n":"Level","v":5,"t":40960001},{"n":"Task","v":4,"t":42598401},{"n":"Opcode","v":115,"t":41156609},{"n":"Message","v":"Exit method: {0}.{1}","t":1310721}]}]},{"r":65537,"p":[{"n":"thisOrContextObject","p":1310721},{"n":"methodname","p":1310721}],"n":"MethodExitTraceDistributed","d":5416204,"h":523991426316,"f":16777218,"a":[{"t":39976961,"c":4334944257,"a":[{"v":16,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40894465},{"n":"Level","v":5,"t":40960001},{"n":"Task","v":4,"t":42598401},{"n":"Opcode","v":115,"t":41156609},{"n":"Message","v":"Exit method: {0}.{1}","t":1310721}]}]},{"r":65537,"p":[{"n":"traceSource","p":4236556},{"n":"exception","p":47251457}],"n":"ExceptionConsumed","o":"@$1","d":5416204,"h":528286393612,"f":16777224,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"exception","p":47251457}],"n":"ExceptionConsumed","d":5416204,"h":532581360908,"f":16777224,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"exceptionStr","p":1310721}],"n":"ExceptionConsumedBase","d":5416204,"h":536876328204,"f":16777218,"a":[{"t":39976961,"c":4334944257,"a":[{"v":9,"t":655361}],"n":[{"n":"Keywords","v":1,"t":40894465},{"n":"Level","v":5,"t":40960001},{"n":"Opcode","v":114,"t":41156609},{"n":"Message","v":"Exception consumed: {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"exceptionStr","p":1310721}],"n":"ExceptionConsumedLtm","d":5416204,"h":541171295500,"f":16777218,"a":[{"t":39976961,"c":4334944257,"a":[{"v":10,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":5,"t":40960001},{"n":"Opcode","v":114,"t":41156609},{"n":"Message","v":"Exception consumed: {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"exceptionStr","p":1310721}],"n":"ExceptionConsumedOleTx","d":5416204,"h":545466262796,"f":16777218,"a":[{"t":39976961,"c":4334944257,"a":[{"v":43,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40894465},{"n":"Level","v":5,"t":40960001},{"n":"Opcode","v":114,"t":41156609},{"n":"Message","v":"Exception consumed: {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"tmType","p":142475265},{"n":"nodeName","p":1310721}],"n":"OleTxTransactionManagerCreate","o":"@$1","d":5416204,"h":549761230092,"f":16777224,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"tmType","p":1310721},{"n":"nodeName","p":1310721}],"n":"OleTxTransactionManagerCreate","d":5416204,"h":554056197388,"f":16777218,"a":[{"t":39976961,"c":4334944257,"a":[{"v":57,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40894465},{"n":"Level","v":5,"t":40960001},{"n":"Task","v":7,"t":42598401},{"n":"Opcode","v":107,"t":41156609},{"n":"Message","v":"Created OleTx transaction manager, type is {0}, node name is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"resourceManagerID","p":56229889}],"n":"TransactionManagerReenlist","d":5416204,"h":558351164684,"f":16777224,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"rmID","p":1310721}],"n":"TransactionManagerReenlistTrace","d":5416204,"h":562646131980,"f":16777218,"a":[{"t":39976961,"c":4334944257,"a":[{"v":32,"t":655361}],"n":[{"n":"Keywords","v":1,"t":40894465},{"n":"Level","v":4,"t":40960001},{"n":"Task","v":7,"t":42598401},{"n":"Opcode","v":125,"t":41156609},{"n":"Message","v":"Reenlist in: {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"resourceManagerID","p":56229889}],"n":"TransactionManagerRecoveryComplete","d":5416204,"h":566941099276,"f":16777224,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"rmID","p":1310721}],"n":"TransactionManagerRecoveryComplete","o":"@$1","d":5416204,"h":571236066572,"f":16777218,"a":[{"t":39976961,"c":4334944257,"a":[{"v":31,"t":655361}],"n":[{"n":"Keywords","v":1,"t":40894465},{"n":"Level","v":4,"t":40960001},{"n":"Task","v":7,"t":42598401},{"n":"Opcode","v":124,"t":41156609},{"n":"Message","v":"Recovery complete: {0}","t":1310721}]}]},{"r":65537,"n":"ConfiguredDefaultTimeoutAdjusted","d":5416204,"h":575531033868,"f":16777224,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"n":"ConfiguredDefaultTimeoutAdjustedTrace","d":5416204,"h":579826001164,"f":16777218,"a":[{"t":39976961,"c":4334944257,"a":[{"v":1,"t":655361}],"n":[{"n":"Keywords","v":1,"t":40894465},{"n":"Level","v":3,"t":40960001},{"n":"Task","v":1,"t":42598401},{"n":"Opcode","v":102,"t":41156609},{"n":"Message","v":"Configured Default Timeout Adjusted","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionID","p":8561932},{"n":"transactionScopeResult","p":5350668}],"n":"TransactionScopeCreated","o":"@$1","d":5416204,"h":584120968460,"f":16777224,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"transactionID","p":1310721},{"n":"transactionScopeResult","p":5350668}],"n":"TransactionScopeCreated","d":5416204,"h":588415935756,"f":16777218,"a":[{"t":39976961,"c":4334944257,"a":[{"v":33,"t":655361}],"n":[{"n":"Keywords","v":1,"t":40894465},{"n":"Level","v":4,"t":40960001},{"n":"Task","v":8,"t":42598401},{"n":"Opcode","v":107,"t":41156609},{"n":"Message","v":"Transactionscope was created: Transaction ID is {0}, TransactionScope Result is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"currenttransactionID","p":8561932},{"n":"newtransactionID","p":8561932}],"n":"TransactionScopeCurrentChanged","o":"@$1","d":5416204,"h":592710903052,"f":16777224,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"currenttransactionID","p":1310721},{"n":"newtransactionID","p":1310721}],"n":"TransactionScopeCurrentChanged","d":5416204,"h":597005870348,"f":16777218,"a":[{"t":39976961,"c":4334944257,"a":[{"v":34,"t":655361}],"n":[{"n":"Keywords","v":1,"t":40894465},{"n":"Level","v":3,"t":40960001},{"n":"Task","v":8,"t":42598401},{"n":"Opcode","v":108,"t":41156609},{"n":"Message","v":"Transactionscope current transaction ID changed from {0} to {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionID","p":8561932}],"n":"TransactionScopeNestedIncorrectly","o":"@$1","d":5416204,"h":601300837644,"f":16777224,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"transactionID","p":1310721}],"n":"TransactionScopeNestedIncorrectly","d":5416204,"h":605595804940,"f":16777218,"a":[{"t":39976961,"c":4334944257,"a":[{"v":38,"t":655361}],"n":[{"n":"Keywords","v":1,"t":40894465},{"n":"Level","v":3,"t":40960001},{"n":"Task","v":8,"t":42598401},{"n":"Opcode","v":121,"t":41156609},{"n":"Message","v":"Transactionscope nested incorrectly: transaction ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionID","p":8561932}],"n":"TransactionScopeDisposed","o":"@$1","d":5416204,"h":609890772236,"f":16777224,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"transactionID","p":1310721}],"n":"TransactionScopeDisposed","d":5416204,"h":614185739532,"f":16777218,"a":[{"t":39976961,"c":4334944257,"a":[{"v":35,"t":655361}],"n":[{"n":"Keywords","v":1,"t":40894465},{"n":"Level","v":4,"t":40960001},{"n":"Task","v":8,"t":42598401},{"n":"Opcode","v":110,"t":41156609},{"n":"Message","v":"Transactionscope disposed: transaction ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionID","p":8561932}],"n":"TransactionScopeIncomplete","o":"@$1","d":5416204,"h":618480706828,"f":16777224,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"transactionID","p":1310721}],"n":"TransactionScopeIncomplete","d":5416204,"h":622775674124,"f":16777218,"a":[{"t":39976961,"c":4334944257,"a":[{"v":36,"t":655361}],"n":[{"n":"Keywords","v":1,"t":40894465},{"n":"Level","v":3,"t":40960001},{"n":"Task","v":8,"t":42598401},{"n":"Opcode","v":117,"t":41156609},{"n":"Message","v":"Transactionscope incomplete: transaction ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionID","p":8561932}],"n":"TransactionScopeTimeout","o":"@$1","d":5416204,"h":627070641420,"f":16777224,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"transactionID","p":1310721}],"n":"TransactionScopeTimeout","d":5416204,"h":631365608716,"f":16777218,"a":[{"t":39976961,"c":4334944257,"a":[{"v":39,"t":655361}],"n":[{"n":"Keywords","v":1,"t":40894465},{"n":"Level","v":3,"t":40960001},{"n":"Task","v":8,"t":42598401},{"n":"Opcode","v":128,"t":41156609},{"n":"Message","v":"Transactionscope timeout: transaction ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionID","p":8561932}],"n":"TransactionTimeout","o":"@$1","d":5416204,"h":635660576012,"f":16777224,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"transactionID","p":1310721}],"n":"TransactionTimeout","d":5416204,"h":639955543308,"f":16777218,"a":[{"t":39976961,"c":4334944257,"a":[{"v":30,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":3,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":128,"t":41156609},{"n":"Message","v":"Transaction timeout: transaction ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"enlistmentID","p":2073868},{"n":"enlistmentType","p":2139404},{"n":"enlistmentOption","p":1877260}],"n":"TransactionstateEnlist","o":"@$1","d":5416204,"h":644250510604,"f":16777224,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"enlistmentID","p":1310721},{"n":"type","p":1310721},{"n":"option","p":1310721}],"n":"TransactionstateEnlist","d":5416204,"h":648545477900,"f":16777218,"a":[{"t":39976961,"c":4334944257,"a":[{"v":40,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":4,"t":40960001},{"n":"Task","v":9,"t":42598401},{"n":"Opcode","v":112,"t":41156609},{"n":"Message","v":"Transactionstate enlist: Enlistment ID is {0}, type is {1} and options is {2}","t":1310721}]}]},{"r":65537,"p":[{"n":"traceSource","p":4236556},{"n":"transactionID","p":8561932}],"n":"TransactionCommitted","d":5416204,"h":652840445196,"f":16777224,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"transactionID","p":1310721}],"n":"TransactionCommittedLtm","d":5416204,"h":657135412492,"f":16777218,"a":[{"t":39976961,"c":4334944257,"a":[{"v":20,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":5,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":105,"t":41156609},{"n":"Message","v":"Transaction committed LTM: transaction ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionID","p":1310721}],"n":"TransactionCommittedOleTx","d":5416204,"h":661430379788,"f":16777218,"a":[{"t":39976961,"c":4334944257,"a":[{"v":44,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40894465},{"n":"Level","v":5,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":105,"t":41156609},{"n":"Message","v":"Transaction committed OleTx: transaction ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"traceSource","p":4236556},{"n":"transactionID","p":8561932}],"n":"TransactionInDoubt","d":5416204,"h":665725347084,"f":16777224,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"transactionID","p":1310721}],"n":"TransactionInDoubtLtm","d":5416204,"h":670020314380,"f":16777218,"a":[{"t":39976961,"c":4334944257,"a":[{"v":25,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":3,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":118,"t":41156609},{"n":"Message","v":"Transaction indoubt LTM: transaction ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionID","p":1310721}],"n":"TransactionInDoubtOleTx","d":5416204,"h":674315281676,"f":16777218,"a":[{"t":39976961,"c":4334944257,"a":[{"v":46,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40894465},{"n":"Level","v":3,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":118,"t":41156609},{"n":"Message","v":"Transaction indoubt OleTx: transaction ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionID","p":8561932},{"n":"distributedTxID","p":8561932}],"n":"TransactionPromoted","o":"@$1","d":5416204,"h":678610248972,"f":16777224,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"transactionID","p":1310721},{"n":"distributedTxID","p":1310721}],"n":"TransactionPromoted","d":5416204,"h":682905216268,"f":16777218,"a":[{"t":39976961,"c":4334944257,"a":[{"v":27,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":4,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":123,"t":41156609},{"n":"Message","v":"Transaction promoted: transaction ID is {0} and distributed transaction ID is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"traceSource","p":4236556},{"n":"transactionID","p":8561932}],"n":"TransactionAborted","d":5416204,"h":687200183564,"f":16777224,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"transactionID","p":1310721}],"n":"TransactionAbortedLtm","d":5416204,"h":691495150860,"f":16777218,"a":[{"t":39976961,"c":4334944257,"a":[{"v":17,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":3,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":100,"t":41156609},{"n":"Message","v":"Transaction aborted LTM: transaction ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionID","p":1310721}],"n":"TransactionAbortedOleTx","d":5416204,"h":695790118156,"f":16777218,"a":[{"t":39976961,"c":4334944257,"a":[{"v":45,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40894465},{"n":"Level","v":3,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":100,"t":41156609},{"n":"Message","v":"Transaction aborted OleTx: transaction ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"error","p":1310721,"f":65}],"n":"InternalError","d":5416204,"h":700085085452,"f":16777224,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"error","p":1310721}],"n":"InternalErrorTrace","d":5416204,"h":704380052748,"f":16777218,"a":[{"t":39976961,"c":4334944257,"a":[{"v":37,"t":655361}],"n":[{"n":"Keywords","v":1,"t":40894465},{"n":"Level","v":1,"t":40960001},{"n":"Task","v":8,"t":42598401},{"n":"Opcode","v":119,"t":41156609},{"n":"Message","v":"Transactionscope internal error: {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"str","p":1310721}],"n":"SetActivityId","d":5416204,"h":721559921932,"f":16777250}],"l":[{"t":5416204,"n":"Log","d":5416204,"h":4300383500,"f":4194344},{"t":40894465,"n":"ALL_KEYWORDS","d":5416204,"h":12890318092,"f":4194338},{"t":655361,"n":"CONFIGURED_DEFAULT_TIMEOUT_ADJUSTED_EVENTID","d":5416204,"h":17185285388,"f":4194338},{"t":655361,"n":"ENLISTMENT_ABORTED_EVENTID","d":5416204,"h":21480252684,"f":4194338},{"t":655361,"n":"ENLISTMENT_COMMITTED_EVENTID","d":5416204,"h":25775219980,"f":4194338},{"t":655361,"n":"ENLISTMENT_DONE_EVENTID","d":5416204,"h":30070187276,"f":4194338},{"t":655361,"n":"ENLISTMENT_LTM_EVENTID","d":5416204,"h":34365154572,"f":4194338},{"t":655361,"n":"ENLISTMENT_FORCEROLLBACK_EVENTID","d":5416204,"h":38660121868,"f":4194338},{"t":655361,"n":"ENLISTMENT_INDOUBT_EVENTID","d":5416204,"h":42955089164,"f":4194338},{"t":655361,"n":"ENLISTMENT_PREPARED_EVENTID","d":5416204,"h":47250056460,"f":4194338},{"t":655361,"n":"EXCEPTION_CONSUMED_BASE_EVENTID","d":5416204,"h":51545023756,"f":4194338},{"t":655361,"n":"EXCEPTION_CONSUMED_LTM_EVENTID","d":5416204,"h":55839991052,"f":4194338},{"t":655361,"n":"METHOD_ENTER_LTM_EVENTID","d":5416204,"h":60134958348,"f":4194338},{"t":655361,"n":"METHOD_EXIT_LTM_EVENTID","d":5416204,"h":64429925644,"f":4194338},{"t":655361,"n":"METHOD_ENTER_BASE_EVENTID","d":5416204,"h":68724892940,"f":4194338},{"t":655361,"n":"METHOD_EXIT_BASE_EVENTID","d":5416204,"h":73019860236,"f":4194338},{"t":655361,"n":"METHOD_ENTER_OLETX_EVENTID","d":5416204,"h":77314827532,"f":4194338},{"t":655361,"n":"METHOD_EXIT_OLETX_EVENTID","d":5416204,"h":81609794828,"f":4194338},{"t":655361,"n":"TRANSACTION_ABORTED_LTM_EVENTID","d":5416204,"h":85904762124,"f":4194338},{"t":655361,"n":"TRANSACTION_CLONECREATE_EVENTID","d":5416204,"h":90199729420,"f":4194338},{"t":655361,"n":"TRANSACTION_COMMIT_LTM_EVENTID","d":5416204,"h":94494696716,"f":4194338},{"t":655361,"n":"TRANSACTION_COMMITTED_LTM_EVENTID","d":5416204,"h":98789664012,"f":4194338},{"t":655361,"n":"TRANSACTION_CREATED_LTM_EVENTID","d":5416204,"h":103084631308,"f":4194338},{"t":655361,"n":"TRANSACTION_DEPENDENT_CLONE_COMPLETE_LTM_EVENTID","d":5416204,"h":107379598604,"f":4194338},{"t":655361,"n":"TRANSACTION_EXCEPTION_LTM_EVENTID","d":5416204,"h":111674565900,"f":4194338},{"t":655361,"n":"TRANSACTION_EXCEPTION_BASE_EVENTID","d":5416204,"h":115969533196,"f":4194338},{"t":655361,"n":"TRANSACTION_INDOUBT_LTM_EVENTID","d":5416204,"h":120264500492,"f":4194338},{"t":655361,"n":"TRANSACTION_INVALID_OPERATION_EVENTID","d":5416204,"h":124559467788,"f":4194338},{"t":655361,"n":"TRANSACTION_PROMOTED_EVENTID","d":5416204,"h":128854435084,"f":4194338},{"t":655361,"n":"TRANSACTION_ROLLBACK_LTM_EVENTID","d":5416204,"h":133149402380,"f":4194338},{"t":655361,"n":"TRANSACTION_SERIALIZED_EVENTID","d":5416204,"h":137444369676,"f":4194338},{"t":655361,"n":"TRANSACTION_TIMEOUT_EVENTID","d":5416204,"h":141739336972,"f":4194338},{"t":655361,"n":"TRANSACTIONMANAGER_RECOVERY_COMPLETE_EVENTID","d":5416204,"h":146034304268,"f":4194338},{"t":655361,"n":"TRANSACTIONMANAGER_REENLIST_EVENTID","d":5416204,"h":150329271564,"f":4194338},{"t":655361,"n":"TRANSACTIONSCOPE_CREATED_EVENTID","d":5416204,"h":154624238860,"f":4194338},{"t":655361,"n":"TRANSACTIONSCOPE_CURRENT_CHANGED_EVENTID","d":5416204,"h":158919206156,"f":4194338},{"t":655361,"n":"TRANSACTIONSCOPE_DISPOSED_EVENTID","d":5416204,"h":163214173452,"f":4194338},{"t":655361,"n":"TRANSACTIONSCOPE_INCOMPLETE_EVENTID","d":5416204,"h":167509140748,"f":4194338},{"t":655361,"n":"INTERNAL_ERROR_EVENTID","d":5416204,"h":171804108044,"f":4194338},{"t":655361,"n":"TRANSACTIONSCOPE_NESTED_INCORRECTLY_EVENTID","d":5416204,"h":176099075340,"f":4194338},{"t":655361,"n":"TRANSACTIONSCOPE_TIMEOUT_EVENTID","d":5416204,"h":180394042636,"f":4194338},{"t":655361,"n":"TRANSACTIONSTATE_ENLIST_EVENTID","d":5416204,"h":184689009932,"f":4194338},{"t":655361,"n":"TRANSACTION_COMMIT_OLETX_EVENTID","d":5416204,"h":188983977228,"f":4194338},{"t":655361,"n":"TRANSACTION_ROLLBACK_OLETX_EVENTID","d":5416204,"h":193278944524,"f":4194338},{"t":655361,"n":"EXCEPTION_CONSUMED_OLETX_EVENTID","d":5416204,"h":197573911820,"f":4194338},{"t":655361,"n":"TRANSACTION_COMMITTED_OLETX_EVENTID","d":5416204,"h":201868879116,"f":4194338},{"t":655361,"n":"TRANSACTION_ABORTED_OLETX_EVENTID","d":5416204,"h":206163846412,"f":4194338},{"t":655361,"n":"TRANSACTION_INDOUBT_OLETX_EVENTID","d":5416204,"h":210458813708,"f":4194338},{"t":655361,"n":"TRANSACTION_DEPENDENT_CLONE_COMPLETE_OLETX_EVENTID","d":5416204,"h":214753781004,"f":4194338},{"t":655361,"n":"TRANSACTION_DEPENDENT_CLONE_CREATE_LTM_EVENTID","d":5416204,"h":219048748300,"f":4194338},{"t":655361,"n":"TRANSACTION_DEPENDENT_CLONE_CREATE_OLETX_EVENTID","d":5416204,"h":223343715596,"f":4194338},{"t":655361,"n":"TRANSACTION_DESERIALIZED_EVENTID","d":5416204,"h":227638682892,"f":4194338},{"t":655361,"n":"TRANSACTION_CREATED_OLETX_EVENTID","d":5416204,"h":231933650188,"f":4194338},{"t":655361,"n":"ENLISTMENT_OLETX_EVENTID","d":5416204,"h":236228617484,"f":4194338},{"t":655361,"n":"ENLISTMENT_CALLBACK_POSITIVE_EVENTID","d":5416204,"h":240523584780,"f":4194338},{"t":655361,"n":"ENLISTMENT_CALLBACK_NEGATIVE_EVENTID","d":5416204,"h":244818552076,"f":4194338},{"t":655361,"n":"ENLISTMENT_CREATED_LTM_EVENTID","d":5416204,"h":249113519372,"f":4194338},{"t":655361,"n":"ENLISTMENT_CREATED_OLETX_EVENTID","d":5416204,"h":253408486668,"f":4194338},{"t":655361,"n":"TRANSACTIONMANAGER_CREATE_OLETX_EVENTID","d":5416204,"h":257703453964,"f":4194338},{"t":1310721,"n":"NullInstance","d":5416204,"h":261998421260,"f":4194338}],"c":[{"n":".ctor","o":"$ctor$10","d":5416204,"h":8595350796,"f":16777218}],"i":[57540609],"j":[5547276,5612812,5481740],"h":5416204,"a":[{"t":42074113,"c":55876648961,"n":[{"n":"Name","v":"System.Transactions.TransactionsEventSource","t":1310721},{"n":"Guid","v":"8ac2d80a-1f1a-431b-ace4-bff8824aef0b","t":1310721}]}]}; }
            static get $b() { return $.$$.System.Diagnostics.Tracing.EventSource; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.Transactions.TransactionsEtwProvider`; }
        });
        
        $asm.$cls("$stl.System.Transactions.Oletx.OletxDependentTransaction", ($self) => class OletxDependentTransaction extends $.$stl.System.Transactions.Oletx.OletxTransaction
        {
            /*void */ Complete()
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransaction.NotSupported();
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 3450124;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":3515660,"m":[{"r":65537,"n":"Complete","d":3450124,"h":4298417420,"f":16777224}],"c":[{"n":".ctor","o":"$ctor$3","d":3450124,"h":8593384716,"f":16777217}],"i":[113246209],"h":3450124}; }
            static get $b() { return $.$stl.System.Transactions.Oletx.OletxTransaction; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Transactions.Oletx.OletxDependentTransaction`; }
        });
        
        $asm.$cls("$stl.System.Transactions.Oletx.OletxCommittableTransaction", ($self) => class OletxCommittableTransaction extends $.$stl.System.Transactions.Oletx.OletxTransaction
        {
            /*void */ BeginCommit(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransaction.NotSupported();
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 3384588;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":3515660,"m":[{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"BeginCommit","d":3384588,"h":4298351884,"f":16777224}],"c":[{"n":".ctor","o":"$ctor$3","d":3384588,"h":8593319180,"f":16777217}],"i":[113246209],"h":3384588}; }
            static get $b() { return $.$stl.System.Transactions.Oletx.OletxTransaction; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Transactions.Oletx.OletxCommittableTransaction`; }
        });
        
        $asm.$cls("$stl.System.Transactions.SubordinateTransaction", ($self) => class SubordinateTransaction extends $.$stl.System.Transactions.Transaction
        {
            $ctor$5(/*IsolationLevel*/ isoLevel, /*ISimpleTransactionSuperior*/ superior)
            {
                super.$ctor$3(isoLevel, superior);
                {
                }
                return this;
            }
            static $h = 4171020;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":4302092,"c":[{"p":[{"n":"isoLevel","p":3187980},{"n":"superior","p":2991372}],"n":".ctor","o":"$ctor$5","d":4171020,"h":4299138316,"f":16777217}],"i":[57540609,113246209],"h":4171020}; }
            static get $b() { return $.$stl.System.Transactions.Transaction; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable, $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Transactions.SubordinateTransaction`; }
        });
        
        $asm.$cls("$stl.System.Transactions.DependentTransaction", ($self) => class DependentTransaction extends $.$stl.System.Transactions.Transaction
        {
            /*bool*/ _blocking = false;
            $ctor$5(/*IsolationLevel*/ isoLevel, /*InternalTransaction*/ internalTransaction, /*bool*/ blocking)
            {
                super.$ctor$2(isoLevel, internalTransaction);
                {
                    this._blocking = blocking;
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1(this._internalTransaction)
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                            if (blocking)
                            {
                                this._internalTransaction.State.CreateBlockingClone(this._internalTransaction);
                            }
                            else 
                            {
                                this._internalTransaction.State.CreateAbortingClone(this._internalTransaction);
                            }
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit(this._internalTransaction)
                    }
                }
                return this;
            }
            /*void */ Complete()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "Complete");
                }
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this._internalTransaction)
                    {
                        $.$$.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                        if (this._complete)
                        {
                            throw $.$stl.System.Transactions.TransactionException.CreateTransactionCompletedException(this.DistributedTxId);
                        }
                        this._complete = true;
                        $.$$.System.Diagnostics.Debug.Assert$2(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        if (this._blocking)
                        {
                            this._internalTransaction.State.CompleteBlockingClone(this._internalTransaction);
                        }
                        else 
                        {
                            this._internalTransaction.State.CompleteAbortingClone(this._internalTransaction);
                        }
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this._internalTransaction)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionDependentCloneComplete(1/*TraceSourceType.TraceSourceLtm*/, this.TransactionTraceId, "DependentTransaction");
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "Complete");
                }
            }
            static $h = 1156364;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":4302092,"m":[{"r":65537,"n":"Complete","d":1156364,"h":12886058252,"f":16777217}],"l":[{"t":262145,"n":"_blocking","d":1156364,"h":4296123660,"f":4194306}],"c":[{"p":[{"n":"isoLevel","p":3187980},{"n":"internalTransaction","p":2794764},{"n":"blocking","p":262145}],"n":".ctor","o":"$ctor$5","d":1156364,"h":8591090956,"f":16777224}],"i":[57540609,113246209],"h":1156364}; }
            static get $b() { return $.$stl.System.Transactions.Transaction; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable, $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Transactions.DependentTransaction`; }
        });
        
        $asm.$cls("$stl.System.Transactions.DurableInternalEnlistment", ($self) => class DurableInternalEnlistment extends $.$stl.System.Transactions.InternalEnlistment
        {
            /*Guid*/ _resourceManagerIdentifier;
            $ctor$5(/*Enlistment*/ enlistment, /*Guid*/ resourceManagerIdentifier, /*InternalTransaction*/ transaction, /*IEnlistmentNotification*/ twoPhaseNotifications, /*ISinglePhaseNotification?*/ singlePhaseNotifications, /*Transaction*/ atomicTransaction)
            {
                super.$ctor$3(enlistment, transaction, twoPhaseNotifications, singlePhaseNotifications, atomicTransaction);
                {
                    this._resourceManagerIdentifier = resourceManagerIdentifier;
                }
                return this;
            }
            $ctor$6(/*Enlistment*/ enlistment, /*IEnlistmentNotification*/ twoPhaseNotifications)
            {
                super.$ctor$2(enlistment, twoPhaseNotifications);
                {
                }
                return this;
            }
            /*Guid */ get ResourceManagerIdentifier()
            {
                return this._resourceManagerIdentifier;
            }
            //default member initializer
            constructor()
            {
                super();
                this._resourceManagerIdentifier = $.$default($.$$.System.Guid);
            }
            static $h = 1615116;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2729228,"p":[{"p":56229889,"g":{"r":0,"d":0,"h":21476451596,"f":50364424},"n":"ResourceManagerIdentifier","d":1615116,"h":17181484300,"f":2129928}],"l":[{"t":56229889,"n":"_resourceManagerIdentifier","d":1615116,"h":4296582412,"f":4194312}],"c":[{"p":[{"n":"enlistment","p":1746188},{"n":"resourceManagerIdentifier","p":56229889},{"n":"transaction","p":2794764},{"n":"twoPhaseNotifications","p":2598156},{"n":"singlePhaseNotifications","p":3056908},{"n":"atomicTransaction","p":4302092}],"n":".ctor","o":"$ctor$5","d":1615116,"h":8591549708,"f":16777224},{"p":[{"n":"enlistment","p":1746188},{"n":"twoPhaseNotifications","p":2598156}],"n":".ctor","o":"$ctor$6","d":1615116,"h":12886517004,"f":16777220}],"i":[3122444,2663692],"h":1615116}; }
            static get $b() { return $.$stl.System.Transactions.InternalEnlistment; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stl.System.Transactions.ISinglePhaseNotificationInternal, $.$stl.System.Transactions.IEnlistmentNotificationInternal ]; }
            static get $fullName() { return `System.Transactions.DurableInternalEnlistment`; }
        });
        
        $asm.$cls("$stl.System.Transactions.PromotableInternalEnlistment", ($self) => class PromotableInternalEnlistment extends $.$stl.System.Transactions.InternalEnlistment
        {
            /*IPromotableSinglePhaseNotification*/ _promotableNotificationInterface = null;
            $ctor$5(/*Enlistment*/ enlistment, /*InternalTransaction*/ transaction, /*IPromotableSinglePhaseNotification*/ promotableSinglePhaseNotification, /*Transaction*/ atomicTransaction)
            {
                super.$ctor$4(enlistment, transaction, atomicTransaction);
                {
                    this._promotableNotificationInterface = promotableSinglePhaseNotification;
                }
                return this;
            }
            /*IPromotableSinglePhaseNotification */ get PromotableSinglePhaseNotification()
            {
                return this._promotableNotificationInterface;
            }
            static $h = 3974412;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2729228,"p":[{"p":2860300,"g":{"r":0,"d":0,"h":17183843596,"f":50364424},"n":"PromotableSinglePhaseNotification","d":3974412,"h":12888876300,"f":2129928}],"l":[{"t":2860300,"n":"_promotableNotificationInterface","d":3974412,"h":4298941708,"f":4194306}],"c":[{"p":[{"n":"enlistment","p":1746188},{"n":"transaction","p":2794764},{"n":"promotableSinglePhaseNotification","p":2860300},{"n":"atomicTransaction","p":4302092}],"n":".ctor","o":"$ctor$5","d":3974412,"h":8593909004,"f":16777224}],"i":[3122444,2663692],"h":3974412}; }
            static get $b() { return $.$stl.System.Transactions.InternalEnlistment; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stl.System.Transactions.ISinglePhaseNotificationInternal, $.$stl.System.Transactions.IEnlistmentNotificationInternal ]; }
            static get $fullName() { return `System.Transactions.PromotableInternalEnlistment`; }
        });
        
        $asm.$cls("$stl.System.Transactions.Phase1VolatileEnlistment", ($self) => class Phase1VolatileEnlistment extends $.$stl.System.Transactions.InternalEnlistment
        {
            $ctor$5(/*Enlistment*/ enlistment, /*InternalTransaction*/ transaction, /*IEnlistmentNotification*/ twoPhaseNotifications, /*ISinglePhaseNotification?*/ singlePhaseNotifications, /*Transaction*/ atomicTransaction)
            {
                super.$ctor$3(enlistment, transaction, twoPhaseNotifications, singlePhaseNotifications, atomicTransaction);
                {
                }
                return this;
            }
            /*void */ FinishEnlistment()
            {
                this._transaction._phase1Volatiles._preparedVolatileEnlistments++;
                this.CheckComplete();
            }
            /*void */ CheckComplete()
            {
                $.$$.System.Diagnostics.Debug.Assert$2(this._transaction._phase1Volatiles._preparedVolatileEnlistments <= ((this._transaction._phase1Volatiles._volatileEnlistmentCount + this._transaction._phase1Volatiles._dependentClones) | 0), "_transaction._phase1Volatiles._preparedVolatileEnlistments <=\r\n                _transaction._phase1Volatiles._volatileEnlistmentCount +\r\n                _transaction._phase1Volatiles._dependentClones");
                if (this._transaction._phase1Volatiles._preparedVolatileEnlistments === ((this._transaction._phase1Volatiles._volatileEnlistmentCount + this._transaction._phase1Volatiles._dependentClones) | 0))
                {
                    this._transaction.State.Phase1VolatilePrepareDone(this._transaction);
                }
            }
            static $h = 3843340;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2729228,"m":[{"r":65537,"n":"FinishEnlistment","d":3843340,"h":8593777932,"f":16809992},{"r":65537,"n":"CheckComplete","d":3843340,"h":12888745228,"f":16809992}],"c":[{"p":[{"n":"enlistment","p":1746188},{"n":"transaction","p":2794764},{"n":"twoPhaseNotifications","p":2598156},{"n":"singlePhaseNotifications","p":3056908},{"n":"atomicTransaction","p":4302092}],"n":".ctor","o":"$ctor$5","d":3843340,"h":4298810636,"f":16777217}],"i":[3122444,2663692],"h":3843340}; }
            static get $b() { return $.$stl.System.Transactions.InternalEnlistment; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stl.System.Transactions.ISinglePhaseNotificationInternal, $.$stl.System.Transactions.IEnlistmentNotificationInternal ]; }
            static get $fullName() { return `System.Transactions.Phase1VolatileEnlistment`; }
        });
        
        $asm.$cls("$stl.System.Transactions.CommittableTransaction", ($self) => class CommittableTransaction extends $.$stl.System.Transactions.Transaction
        {
            $ctor$5()
            {
                this.$ctor$7($.$stl.System.Transactions.TransactionManager.DefaultIsolationLevel, $.$stl.System.Transactions.TransactionManager.DefaultTimeout);
                {
                }
                return this;
            }
            $ctor$6(/*TimeSpan*/ timeout)
            {
                this.$ctor$7($.$stl.System.Transactions.TransactionManager.DefaultIsolationLevel, timeout);
                {
                }
                return this;
            }
            $ctor$8(/*TransactionOptions*/ options)
            {
                this.$ctor$7(options.IsolationLevel, options.Timeout);
                {
                }
                return this;
            }
            $ctor$7(/*IsolationLevel*/ isoLevel, /*TimeSpan*/ timeout)
            {
                super.$ctor$2(isoLevel, null);
                {
                    this._internalTransaction = new $.$stl.System.Transactions.InternalTransaction().$ctor$1(timeout, this);
                    this._internalTransaction._cloneCount = 1;
                    this._cloneId = 1;
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.TransactionCreated(1/*TraceSourceType.TraceSourceLtm*/, this.TransactionTraceId, "CommittableTransaction");
                    }
                }
                return this;
            }
            /*IAsyncResult */ BeginCommit(/*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "BeginCommit");
                    etwLog.TransactionCommit(1/*TraceSourceType.TraceSourceLtm*/, this.TransactionTraceId, "CommittableTransaction");
                }
                $.$$.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this._internalTransaction)
                    {
                        if (this._complete)
                        {
                            throw $.$stl.System.Transactions.TransactionException.CreateTransactionCompletedException(this.DistributedTxId);
                        }
                        $.$$.System.Diagnostics.Debug.Assert$2(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        this._internalTransaction.State.BeginCommit(this._internalTransaction, true, asyncCallback, asyncState);
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this._internalTransaction)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "BeginCommit");
                }
                return this;
            }
            /*void */ Commit()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "Commit");
                    etwLog.TransactionCommit(1/*TraceSourceType.TraceSourceLtm*/, this.TransactionTraceId, "CommittableTransaction");
                }
                $.$$.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this._internalTransaction)
                    {
                        if (this._complete)
                        {
                            throw $.$stl.System.Transactions.TransactionException.CreateTransactionCompletedException(this.DistributedTxId);
                        }
                        $.$$.System.Diagnostics.Debug.Assert$2(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        this._internalTransaction.State.BeginCommit(this._internalTransaction, false, null, null);
                        do
                        {
                            if (this._internalTransaction.State.IsCompleted(this._internalTransaction))
                            {
                                break;
                            }
                        }
                        while($.$$.System.Threading.Monitor.Wait$4(this._internalTransaction));
                        this._internalTransaction.State.EndCommit(this._internalTransaction);
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this._internalTransaction)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "Commit");
                }
            }
            /*void */ InternalDispose()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "InternalDispose");
                }
                if ($.$$.System.Threading.Interlocked.Exchange$3($.$ref(() => this._disposed, ($v) => this._disposed = $v, $.$$.System.Int32), 1/*Transaction._disposedTrueValue*/) === 1/*Transaction._disposedTrueValue*/)
                {
                    return;
                }
                $.$$.System.Diagnostics.Debug.Assert$2(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                if (this._internalTransaction.State.get_Status(this._internalTransaction) === 0/*TransactionStatus.Active*/)
                {
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1(this._internalTransaction)
                        {
                            this._internalTransaction.State.DisposeRoot(this._internalTransaction);
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit(this._internalTransaction)
                    }
                }
                /*long*/ let remainingITx = BigInt($.$$.System.Threading.Interlocked.Decrement($.$ref(() => this._internalTransaction._cloneCount, ($v) => this._internalTransaction._cloneCount = $v, $.$$.System.Int32)));
                if (remainingITx === 0n)
                {
                    this._internalTransaction.Dispose();
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "InternalDispose");
                }
            }
            /*void */ EndCommit(/*IAsyncResult*/ asyncResult)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "EndCommit");
                }
                if (asyncResult !== ($.$cast(this, $.$$.System.Object)))
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$stl.System.SR.BadAsyncResult, "asyncResult");
                }
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this._internalTransaction)
                    {
                        do
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                            if (this._internalTransaction.State.IsCompleted(this._internalTransaction))
                            {
                                break;
                            }
                        }
                        while($.$$.System.Threading.Monitor.Wait$4(this._internalTransaction));
                        this._internalTransaction.State.EndCommit(this._internalTransaction);
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this._internalTransaction)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "EndCommit");
                }
            }
            /*object? */ get System$IAsyncResult$AsyncState()
            {
                return this._internalTransaction._asyncState;
            }
            /*bool */ get System$IAsyncResult$CompletedSynchronously()
            {
                return false;
            }
            /*WaitHandle */ get System$IAsyncResult$AsyncWaitHandle()
            {
                if (this._internalTransaction._asyncResultEvent === null)
                {
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1(this._internalTransaction)
                        {
                            if (this._internalTransaction._asyncResultEvent === null)
                            {
                                $.$$.System.Diagnostics.Debug.Assert$2(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                                /*ManualResetEvent*/ let temp = new $.$$.System.Threading.ManualResetEvent().$ctor$8(this._internalTransaction.State.get_Status(this._internalTransaction) !== 0/*TransactionStatus.Active*/);
                                this._internalTransaction._asyncResultEvent = temp;
                            }
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit(this._internalTransaction)
                    }
                }
                return this._internalTransaction._asyncResultEvent;
            }
            /*bool */ get System$IAsyncResult$IsCompleted()
            {
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this._internalTransaction)
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        return this._internalTransaction.State.get_Status(this._internalTransaction) !== 0/*TransactionStatus.Active*/;
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this._internalTransaction)
                }
            }
            static $h = 566540;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":4302092,"p":[{"p":131073,"g":{"r":0,"d":0,"h":42950239500,"f":50331650},"n":"{57016321}.AsyncState","o":"System$IAsyncResult$AsyncState","d":566540,"h":38655272204,"f":2097154},{"p":262145,"g":{"r":0,"d":0,"h":51540174092,"f":50331650},"n":"{57016321}.CompletedSynchronously","o":"System$IAsyncResult$CompletedSynchronously","d":566540,"h":47245206796,"f":2097154},{"p":139001857,"g":{"r":0,"d":0,"h":60130108684,"f":50331650},"n":"{57016321}.AsyncWaitHandle","o":"System$IAsyncResult$AsyncWaitHandle","d":566540,"h":55835141388,"f":2097154},{"p":262145,"g":{"r":0,"d":0,"h":68720043276,"f":50331650},"n":"{57016321}.IsCompleted","o":"System$IAsyncResult$IsCompleted","d":566540,"h":64425075980,"f":2097154}],"m":[{"r":57016321,"p":[{"n":"asyncCallback","p":14548993},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":566540,"h":21475403020,"f":16777217},{"r":65537,"n":"Commit","d":566540,"h":25770370316,"f":16777217},{"r":65537,"n":"InternalDispose","d":566540,"h":30065337612,"f":16809992},{"r":65537,"p":[{"n":"asyncResult","p":57016321}],"n":"EndCommit","d":566540,"h":34360304908,"f":16777217}],"c":[{"n":".ctor","o":"$ctor$5","d":566540,"h":4295533836,"f":16777217},{"p":[{"n":"timeout","p":140574721}],"n":".ctor","o":"$ctor$6","d":566540,"h":8590501132,"f":16777217},{"p":[{"n":"options","p":5022988}],"n":".ctor","o":"$ctor$8","d":566540,"h":12885468428,"f":16777217},{"p":[{"n":"isoLevel","p":3187980},{"n":"timeout","p":140574721}],"n":".ctor","o":"$ctor$7","d":566540,"h":17180435724,"f":16777224}],"i":[57540609,113246209,57016321],"h":566540,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"browser","t":1310721}]}]}; }
            static get $b() { return $.$stl.System.Transactions.Transaction; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable, $.$$.System.Runtime.Serialization.ISerializable, $.$$.System.IAsyncResult ]; }
            static get $fullName() { return `System.Transactions.CommittableTransaction`; }
        });
        
        $asm.$cls("$stl.System.Transactions.VolatileEnlistmentDone", ($self) => class VolatileEnlistmentDone extends $.$stl.System.Transactions.VolatileEnlistmentEnded
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                enlistment.State = this;
            }
            /*void */ ChangeStatePreparing(/*InternalEnlistment*/ enlistment)
            {
                enlistment.CheckComplete();
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 8955148;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":9020684,"m":[{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"EnterState","d":8955148,"h":4303922444,"f":16809992},{"r":65537,"p":[{"n":"enlistment","p":2729228}],"n":"ChangeStatePreparing","d":8955148,"h":8598889740,"f":16809992}],"c":[{"n":".ctor","o":"$ctor$4","d":8955148,"h":12893857036,"f":16777217}],"h":8955148}; }
            static get $b() { return $.$stl.System.Transactions.VolatileEnlistmentEnded; }
            static get $fullName() { return `System.Transactions.VolatileEnlistmentDone`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedPhase0", ($self) => class TransactionStatePromotedPhase0 extends $.$stl.System.Transactions.TransactionStatePromotedCommitting
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                /*int*/ let volatileCount = tx._phase0Volatiles._volatileEnlistmentCount;
                /*int*/ let dependentCount = tx._phase0Volatiles._dependentClones;
                tx._phase0VolatileWaveCount = volatileCount;
                if (tx._phase0Volatiles._preparedVolatileEnlistments < ((volatileCount + dependentCount) | 0))
                {
                    for(/*int*/ let i = 0; i < volatileCount; i++)
                    {
                        $.$$.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i)._twoPhaseState.ChangeStatePreparing($.$$.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i));
                        if (!tx.State.ContinuePhase0Prepares())
                        {
                            break;
                        }
                    }
                }
                else 
                {
                    this.Phase0VolatilePrepareDone(tx);
                }
            }
            /*void */ Phase0VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(tx._phase0Volatiles.VolatileDemux !== null, "Volatile Demux must exist for VolatilePrepareDone when promoted.");
                $.$$.System.Threading.Monitor.Exit(tx);
                try
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(tx._phase0Volatiles.VolatileDemux._promotedEnlistment !== null, "tx._phase0Volatiles.VolatileDemux._promotedEnlistment != null");
                    tx._phase0Volatiles.VolatileDemux._promotedEnlistment.System$Transactions$IPromotedEnlistment$Prepared();
                }
                finally
                {
                    {
                        $.$$.System.Threading.Monitor.Enter$1(tx);
                    }
                }
            }
            /*bool */ ContinuePhase0Prepares()
            {
                return true;
            }
            /*void */ ChangeStateTransactionAborted(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                tx._innerException ??= e;
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedP0Aborting.EnterState(tx);
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 7972108;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7054604,"m":[{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"EnterState","d":7972108,"h":4302939404,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"Phase0VolatilePrepareDone","d":7972108,"h":8597906700,"f":16809992},{"r":262145,"n":"ContinuePhase0Prepares","d":7972108,"h":12892873996,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"e","p":47251457}],"n":"ChangeStateTransactionAborted","d":7972108,"h":17187841292,"f":16809992}],"c":[{"n":".ctor","o":"$ctor$4","d":7972108,"h":21482808588,"f":16777217}],"h":7972108}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedCommitting; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedPhase0`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedPhase1", ($self) => class TransactionStatePromotedPhase1 extends $.$stl.System.Transactions.TransactionStatePromotedCommitting
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                if (tx._committableTransaction !== null)
                {
                    tx._committableTransaction._complete = true;
                }
                if (tx._phase1Volatiles._dependentClones !== 0)
                {
                    tx.State.ChangeStateTransactionAborted(tx, null);
                    return;
                }
                /*int*/ let volatileCount = tx._phase1Volatiles._volatileEnlistmentCount;
                if (tx._phase1Volatiles._preparedVolatileEnlistments < volatileCount)
                {
                    for(/*int*/ let i = 0; i < volatileCount; i++)
                    {
                        $.$$.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i)._twoPhaseState.ChangeStatePreparing($.$$.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i));
                        if (!tx.State.ContinuePhase1Prepares())
                        {
                            break;
                        }
                    }
                }
                else 
                {
                    this.Phase1VolatilePrepareDone(tx);
                }
            }
            /*void */ CreateBlockingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException(tx._innerException, tx.DistributedTxId);
            }
            /*void */ CreateAbortingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException(tx._innerException, tx.DistributedTxId);
            }
            /*void */ ChangeStateTransactionAborted(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                tx._innerException ??= e;
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedP1Aborting.EnterState(tx);
            }
            /*void */ Phase1VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(tx._phase1Volatiles.VolatileDemux !== null, "Volatile Demux must exist for VolatilePrepareDone when promoted.");
                $.$$.System.Threading.Monitor.Exit(tx);
                try
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(tx._phase1Volatiles.VolatileDemux._promotedEnlistment !== null, "tx._phase1Volatiles.VolatileDemux._promotedEnlistment != null");
                    tx._phase1Volatiles.VolatileDemux._promotedEnlistment.System$Transactions$IPromotedEnlistment$Prepared();
                }
                finally
                {
                    {
                        $.$$.System.Threading.Monitor.Enter$1(tx);
                    }
                }
            }
            /*bool */ ContinuePhase1Prepares()
            {
                return true;
            }
            /*Enlistment */ EnlistVolatile(/*InternalTransaction*/ tx, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                throw $.$stl.System.Transactions.TransactionException.Create$2($.$stl.System.SR.TooLate, tx === null ? $.$$.System.Guid.Empty : tx.DistributedTxId);
            }
            /*Enlistment */ EnlistVolatile$1(/*InternalTransaction*/ tx, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                throw $.$stl.System.Transactions.TransactionException.Create$2($.$stl.System.SR.TooLate, tx === null ? $.$$.System.Guid.Empty : tx.DistributedTxId);
            }
            /*Enlistment */ EnlistDurable(/*InternalTransaction*/ tx, /*Guid*/ resourceManagerIdentifier, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                throw $.$stl.System.Transactions.TransactionException.Create$2($.$stl.System.SR.TooLate, tx === null ? $.$$.System.Guid.Empty : tx.DistributedTxId);
            }
            /*Enlistment */ EnlistDurable$1(/*InternalTransaction*/ tx, /*Guid*/ resourceManagerIdentifier, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                throw $.$stl.System.Transactions.TransactionException.Create$2($.$stl.System.SR.TooLate, tx === null ? $.$$.System.Guid.Empty : tx.DistributedTxId);
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 8037644;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7054604,"m":[{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"EnterState","d":8037644,"h":4303004940,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"CreateBlockingClone","d":8037644,"h":8597972236,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"CreateAbortingClone","d":8037644,"h":12892939532,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"e","p":47251457}],"n":"ChangeStateTransactionAborted","d":8037644,"h":17187906828,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"Phase1VolatilePrepareDone","d":8037644,"h":21482874124,"f":16809992},{"r":262145,"n":"ContinuePhase1Prepares","d":8037644,"h":25777841420,"f":16809992},{"r":1746188,"p":[{"n":"tx","p":2794764},{"n":"enlistmentNotification","p":2598156},{"n":"enlistmentOptions","p":1877260},{"n":"atomicTransaction","p":4302092}],"n":"EnlistVolatile","d":8037644,"h":30072808716,"f":16809992},{"r":1746188,"p":[{"n":"tx","p":2794764},{"n":"enlistmentNotification","p":3056908},{"n":"enlistmentOptions","p":1877260},{"n":"atomicTransaction","p":4302092}],"n":"EnlistVolatile","o":"@$1","d":8037644,"h":34367776012,"f":16809992},{"r":1746188,"p":[{"n":"tx","p":2794764},{"n":"resourceManagerIdentifier","p":56229889},{"n":"enlistmentNotification","p":2598156},{"n":"enlistmentOptions","p":1877260},{"n":"atomicTransaction","p":4302092}],"n":"EnlistDurable","d":8037644,"h":38662743308,"f":16809992},{"r":1746188,"p":[{"n":"tx","p":2794764},{"n":"resourceManagerIdentifier","p":56229889},{"n":"enlistmentNotification","p":3056908},{"n":"enlistmentOptions","p":1877260},{"n":"atomicTransaction","p":4302092}],"n":"EnlistDurable","o":"@$1","d":8037644,"h":42957710604,"f":16809992}],"c":[{"n":".ctor","o":"$ctor$4","d":8037644,"h":47252677900,"f":16777217}],"h":8037644}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedCommitting; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedPhase1`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateDelegatedP0Wave", ($self) => class TransactionStateDelegatedP0Wave extends $.$stl.System.Transactions.TransactionStatePromotedP0Wave
        {
            /*void */ Phase0VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStateDelegatedCommitting.EnterState(tx);
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 6333708;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7841036,"m":[{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"Phase0VolatilePrepareDone","d":6333708,"h":4301301004,"f":16809992}],"c":[{"n":".ctor","o":"$ctor$4","d":6333708,"h":8596268300,"f":16777217}],"h":6333708}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedP0Wave; }
            static get $fullName() { return `System.Transactions.TransactionStateDelegatedP0Wave`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateDelegatedCommitting", ($self) => class TransactionStateDelegatedCommitting extends $.$stl.System.Transactions.TransactionStatePromotedCommitting
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                $.$$.System.Threading.Monitor.Exit(tx);
                $.$$.System.Diagnostics.Debug.Assert$2(tx._durableEnlistment !== null, "tx._durableEnlistment != null");
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.EnlistmentStatus(1/*TraceSourceType.TraceSourceLtm*/, tx._durableEnlistment.EnlistmentTraceId, 4/*NotificationCall.SinglePhaseCommit*/);
                }
                try
                {
                    tx._durableEnlistment.PromotableSinglePhaseNotification.System$Transactions$IPromotableSinglePhaseNotification$SinglePhaseCommit(tx._durableEnlistment.SinglePhaseEnlistment);
                }
                finally
                {
                    {
                        $.$$.System.Threading.Monitor.Enter$1(tx);
                    }
                }
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 6202636;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7054604,"m":[{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"EnterState","d":6202636,"h":4301169932,"f":16809992}],"c":[{"n":".ctor","o":"$ctor$4","d":6202636,"h":8596137228,"f":16777217}],"h":6202636}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedCommitting; }
            static get $fullName() { return `System.Transactions.TransactionStateDelegatedCommitting`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateSubordinateActive", ($self) => class TransactionStateSubordinateActive extends $.$stl.System.Transactions.TransactionStateActive
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                $.$$.System.Diagnostics.Debug.Assert$2(tx._promoter !== null, "Transaction Promoter is Null entering SubordinateActive");
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                tx._innerException ??= e;
                $.$$.System.Diagnostics.Debug.Assert$2(tx._promoter !== null, "tx._promoter != null");
                ($.$cast(tx._promoter, $.$stl.System.Transactions.ISimpleTransactionSuperior)).System$Transactions$ISimpleTransactionSuperior$Rollback();
                $.$stl.System.Transactions.TransactionState.TransactionStateAborted.EnterState(tx);
            }
            /*Enlistment */ EnlistVolatile(/*InternalTransaction*/ tx, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                tx._promoteState.EnterState(tx);
                return tx.State.EnlistVolatile(tx, enlistmentNotification, enlistmentOptions, atomicTransaction);
            }
            /*Enlistment */ EnlistVolatile$1(/*InternalTransaction*/ tx, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                tx._promoteState.EnterState(tx);
                return tx.State.EnlistVolatile$1(tx, enlistmentNotification, enlistmentOptions, atomicTransaction);
            }
            /*TransactionStatus */ get_Status(/*InternalTransaction*/ tx)
            {
                tx._promoteState.EnterState(tx);
                return tx.State.get_Status(tx);
            }
            /*void */ AddOutcomeRegistrant(/*InternalTransaction*/ tx, /*TransactionCompletedEventHandler?*/ transactionCompletedDelegate)
            {
                tx._promoteState.EnterState(tx);
                tx.State.AddOutcomeRegistrant(tx, transactionCompletedDelegate);
            }
            /*bool */ EnlistPromotableSinglePhase(/*InternalTransaction*/ tx, /*IPromotableSinglePhaseNotification*/ promotableSinglePhaseNotification, /*Transaction*/ atomicTransaction, /*Guid*/ promoterType)
            {
                return false;
            }
            /*void */ CreateBlockingClone(/*InternalTransaction*/ tx)
            {
                tx._promoteState.EnterState(tx);
                tx.State.CreateBlockingClone(tx);
            }
            /*void */ CreateAbortingClone(/*InternalTransaction*/ tx)
            {
                tx._promoteState.EnterState(tx);
                tx.State.CreateAbortingClone(tx);
            }
            //default reference type constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                return this;
            }
            static $h = 8234252;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":5874956,"m":[{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"EnterState","d":8234252,"h":4303201548,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"e","p":47251457}],"n":"Rollback","d":8234252,"h":8598168844,"f":16809992},{"r":1746188,"p":[{"n":"tx","p":2794764},{"n":"enlistmentNotification","p":2598156},{"n":"enlistmentOptions","p":1877260},{"n":"atomicTransaction","p":4302092}],"n":"EnlistVolatile","d":8234252,"h":12893136140,"f":16809992},{"r":1746188,"p":[{"n":"tx","p":2794764},{"n":"enlistmentNotification","p":3056908},{"n":"enlistmentOptions","p":1877260},{"n":"atomicTransaction","p":4302092}],"n":"EnlistVolatile","o":"@$1","d":8234252,"h":17188103436,"f":16809992},{"r":8430860,"p":[{"n":"tx","p":2794764}],"n":"get_Status","d":8234252,"h":21483070732,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"transactionCompletedDelegate","p":4433164}],"n":"AddOutcomeRegistrant","d":8234252,"h":25778038028,"f":16809992},{"r":262145,"p":[{"n":"tx","p":2794764},{"n":"promotableSinglePhaseNotification","p":2860300},{"n":"atomicTransaction","p":4302092},{"n":"promoterType","p":56229889}],"n":"EnlistPromotableSinglePhase","d":8234252,"h":30073005324,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"CreateBlockingClone","d":8234252,"h":34367972620,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"CreateAbortingClone","d":8234252,"h":38662939916,"f":16809992}],"c":[{"n":".ctor","o":"$ctor$5","d":8234252,"h":42957907212,"f":16777217}],"h":8234252}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStateActive; }
            static get $fullName() { return `System.Transactions.TransactionStateSubordinateActive`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateDelegated", ($self) => class TransactionStateDelegated extends $.$stl.System.Transactions.TransactionStateDelegatedBase
        {
            /*void */ BeginCommit(/*InternalTransaction*/ tx, /*bool*/ asyncCommit, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                tx._asyncCommit = asyncCommit;
                tx._asyncCallback = asyncCallback;
                tx._asyncState = asyncState;
                $.$stl.System.Transactions.TransactionState.TransactionStateDelegatedCommitting.EnterState(tx);
            }
            /*bool */ PromoteDurable(/*InternalTransaction*/ tx)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(tx._durableEnlistment !== null, "tx._durableEnlistment != null");
                tx._durableEnlistment.State.ChangeStateDelegated(tx._durableEnlistment);
                return true;
            }
            /*void */ RestartCommitIfNeeded(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStateDelegatedP0Wave.EnterState(tx);
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                tx._innerException ??= e;
                $.$stl.System.Transactions.TransactionState.TransactionStateDelegatedAborting.EnterState(tx);
            }
            //default reference type constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                return this;
            }
            static $h = 6006028;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6137100,"m":[{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"asyncCommit","p":262145},{"n":"asyncCallback","p":14548993},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":6006028,"h":4300973324,"f":16809992},{"r":262145,"p":[{"n":"tx","p":2794764}],"n":"PromoteDurable","d":6006028,"h":8595940620,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"RestartCommitIfNeeded","d":6006028,"h":12890907916,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"e","p":47251457}],"n":"Rollback","d":6006028,"h":17185875212,"f":16809992}],"c":[{"n":".ctor","o":"$ctor$5","d":6006028,"h":21480842508,"f":16777217}],"h":6006028}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStateDelegatedBase; }
            static get $fullName() { return `System.Transactions.TransactionStateDelegated`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateDelegatedSubordinate", ($self) => class TransactionStateDelegatedSubordinate extends $.$stl.System.Transactions.TransactionStateDelegatedBase
        {
            /*bool */ PromoteDurable(/*InternalTransaction*/ tx)
            {
                return true;
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                tx._innerException ??= e;
                $.$$.System.Diagnostics.Debug.Assert$2(tx.PromotedTransaction !== null, "tx.PromotedTransaction != null");
                tx.PromotedTransaction.Rollback();
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedAborted.EnterState(tx);
            }
            /*void */ ChangeStatePromotedPhase0(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedPhase0.EnterState(tx);
            }
            /*void */ ChangeStatePromotedPhase1(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedPhase1.EnterState(tx);
            }
            //default reference type constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                return this;
            }
            static $h = 6399244;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6137100,"m":[{"r":262145,"p":[{"n":"tx","p":2794764}],"n":"PromoteDurable","d":6399244,"h":4301366540,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"e","p":47251457}],"n":"Rollback","d":6399244,"h":8596333836,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"ChangeStatePromotedPhase0","d":6399244,"h":12891301132,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"ChangeStatePromotedPhase1","d":6399244,"h":17186268428,"f":16809992}],"c":[{"n":".ctor","o":"$ctor$5","d":6399244,"h":21481235724,"f":16777217}],"h":6399244}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStateDelegatedBase; }
            static get $fullName() { return `System.Transactions.TransactionStateDelegatedSubordinate`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateDelegatedAborting", ($self) => class TransactionStateDelegatedAborting extends $.$stl.System.Transactions.TransactionStatePromotedAborted
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                $.$$.System.Threading.Monitor.Exit(tx);
                try
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(tx._durableEnlistment !== null, "tx._durableEnlistment != null");
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.EnlistmentStatus(1/*TraceSourceType.TraceSourceLtm*/, tx._durableEnlistment.EnlistmentTraceId, 2/*NotificationCall.Rollback*/);
                    }
                    tx._durableEnlistment.PromotableSinglePhaseNotification.System$Transactions$IPromotableSinglePhaseNotification$Rollback(tx._durableEnlistment.SinglePhaseEnlistment);
                }
                finally
                {
                    {
                        $.$$.System.Threading.Monitor.Enter$1(tx);
                    }
                }
            }
            /*void */ BeginCommit(/*InternalTransaction*/ tx, /*bool*/ asyncCommit, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException(tx._innerException, tx.DistributedTxId);
            }
            /*void */ ChangeStatePromotedAborted(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedAborted.EnterState(tx);
            }
            //default reference type constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                return this;
            }
            static $h = 6071564;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6792460,"m":[{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"EnterState","d":6071564,"h":4301038860,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764},{"n":"asyncCommit","p":262145},{"n":"asyncCallback","p":14548993},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":6071564,"h":8596006156,"f":16809992},{"r":65537,"p":[{"n":"tx","p":2794764}],"n":"ChangeStatePromotedAborted","d":6071564,"h":12890973452,"f":16809992}],"c":[{"n":".ctor","o":"$ctor$5","d":6071564,"h":17185940748,"f":16777217}],"h":6071564}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedAborted; }
            static get $fullName() { return `System.Transactions.TransactionStateDelegatedAborting`; }
        });
        
        $asm.$cls("$stl.System.Transactions.RecoveringInternalEnlistment", ($self) => class RecoveringInternalEnlistment extends $.$stl.System.Transactions.DurableInternalEnlistment
        {
            /*object*/ _syncRoot = null;
            $ctor$7(/*Enlistment*/ enlistment, /*IEnlistmentNotification*/ twoPhaseNotifications, /*object*/ syncRoot)
            {
                super.$ctor$6(enlistment, twoPhaseNotifications);
                {
                    this._syncRoot = syncRoot;
                }
                return this;
            }
            /*object */ get SyncRoot()
            {
                return this._syncRoot;
            }
            static $h = 4039948;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1615116,"p":[{"p":131073,"g":{"r":0,"d":0,"h":17183909132,"f":50364424},"n":"SyncRoot","d":4039948,"h":12888941836,"f":2129928}],"l":[{"t":131073,"n":"_syncRoot","d":4039948,"h":4299007244,"f":4194306}],"c":[{"p":[{"n":"enlistment","p":1746188},{"n":"twoPhaseNotifications","p":2598156},{"n":"syncRoot","p":131073}],"n":".ctor","o":"$ctor$7","d":4039948,"h":8593974540,"f":16777224}],"i":[3122444,2663692],"h":4039948}; }
            static get $b() { return $.$stl.System.Transactions.DurableInternalEnlistment; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stl.System.Transactions.ISinglePhaseNotificationInternal, $.$stl.System.Transactions.IEnlistmentNotificationInternal ]; }
            static get $fullName() { return `System.Transactions.RecoveringInternalEnlistment`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionException", ($self) => class TransactionException extends $.$$.System.SystemException
        {
            static /*bool */ IncludeDistributedTxId(/*Guid*/ distributedTxId)
            {
                return ($.$$.System.Guid.op_Inequality(distributedTxId, $.$$.System.Guid.Empty) && $.$stl.System.Transactions.Configuration.AppSettings.IncludeDistributedTxIdInExceptionMessage);
            }
            static /*TransactionException */ Create$1(/*string?*/ message, /*Exception?*/ innerException)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace$1(2/*TransactionExceptionType.TransactionException*/, message, innerException === null ? $.$$.System.String.Empty : $.$$.System.Exception.ToString.call(innerException));
                }
                return new $.$stl.System.Transactions.TransactionException().$ctor$11(message, innerException);
            }
            static /*TransactionException */ CreateTransactionStateException$1(/*Exception?*/ innerException)
            {
                return $.$stl.System.Transactions.TransactionException.Create$1($.$stl.System.SR.TransactionStateException, innerException);
            }
            static /*Exception */ CreateEnlistmentStateException(/*Exception?*/ innerException, /*Guid*/ distributedTxId)
            {
                /*string*/ let messagewithTxId = $.$stl.System.SR.EnlistmentStateException;
                if ($.$stl.System.Transactions.TransactionException.IncludeDistributedTxId(distributedTxId))
                {
                    messagewithTxId = $.$stl.System.SR.Format$5($.$stl.System.SR.DistributedTxIDInTransactionException, messagewithTxId, distributedTxId);
                }
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace$1(0/*TransactionExceptionType.InvalidOperationException*/, messagewithTxId, innerException === null ? $.$$.System.String.Empty : $.$$.System.Exception.ToString.call(innerException));
                }
                return new $.$$.System.InvalidOperationException().$ctor$11(messagewithTxId, innerException);
            }
            static /*Exception */ CreateInvalidOperationException$1(/*TraceSourceType*/ traceSource, /*string?*/ message, /*Exception?*/ innerException)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace(traceSource, 0/*TransactionExceptionType.InvalidOperationException*/, message, innerException === null ? $.$$.System.String.Empty : $.$$.System.Exception.ToString.call(innerException));
                }
                return new $.$$.System.InvalidOperationException().$ctor$11(message, innerException);
            }
            $ctor$9()
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            $ctor$12(/*string?*/ message)
            {
                super.$ctor$8(message);
                {
                }
                return this;
            }
            $ctor$11(/*string?*/ message, /*Exception?*/ innerException)
            {
                super.$ctor$7(message, innerException);
                {
                }
                return this;
            }
            $ctor$10(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor$6(info, context);
                {
                }
                return this;
            }
            static /*TransactionException */ Create$2(/*string?*/ message, /*Guid*/ distributedTxId)
            {
                if ($.$stl.System.Transactions.TransactionException.IncludeDistributedTxId(distributedTxId))
                {
                    return new $.$stl.System.Transactions.TransactionException().$ctor$12($.$stl.System.SR.Format$5($.$stl.System.SR.DistributedTxIDInTransactionException, message, distributedTxId));
                }
                return new $.$stl.System.Transactions.TransactionException().$ctor$12(message);
            }
            static /*TransactionException */ Create(/*string?*/ message, /*Exception?*/ innerException, /*Guid*/ distributedTxId)
            {
                /*string?*/ let messagewithTxId = message;
                if ($.$stl.System.Transactions.TransactionException.IncludeDistributedTxId(distributedTxId))
                {
                    messagewithTxId = $.$stl.System.SR.Format$5($.$stl.System.SR.DistributedTxIDInTransactionException, messagewithTxId, distributedTxId);
                }
                return $.$stl.System.Transactions.TransactionException.Create$1(messagewithTxId, innerException);
            }
            static /*TransactionException */ CreateTransactionStateException(/*Exception?*/ innerException, /*Guid*/ distributedTxId)
            {
                return $.$stl.System.Transactions.TransactionException.Create($.$stl.System.SR.TransactionStateException, innerException, distributedTxId);
            }
            static /*Exception */ CreateTransactionCompletedException(/*Guid*/ distributedTxId)
            {
                /*string*/ let messagewithTxId = $.$stl.System.SR.TransactionAlreadyCompleted;
                if ($.$stl.System.Transactions.TransactionException.IncludeDistributedTxId(distributedTxId))
                {
                    messagewithTxId = $.$stl.System.SR.Format$5($.$stl.System.SR.DistributedTxIDInTransactionException, messagewithTxId, distributedTxId);
                }
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace$1(0/*TransactionExceptionType.InvalidOperationException*/, messagewithTxId, $.$$.System.String.Empty);
                }
                return new $.$$.System.InvalidOperationException().$ctor$12(messagewithTxId);
            }
            static /*Exception */ CreateInvalidOperationException(/*TraceSourceType*/ traceSource, /*string?*/ message, /*Exception?*/ innerException, /*Guid*/ distributedTxId)
            {
                /*string?*/ let messagewithTxId = message;
                if ($.$stl.System.Transactions.TransactionException.IncludeDistributedTxId(distributedTxId))
                {
                    messagewithTxId = $.$stl.System.SR.Format$5($.$stl.System.SR.DistributedTxIDInTransactionException, messagewithTxId, distributedTxId);
                }
                return $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException$1(traceSource, messagewithTxId, innerException);
            }
            static $h = 4564236;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":119537665,"h":4564236}; }
            static get $b() { return $.$$.System.SystemException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Transactions.TransactionException`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionAbortedException", ($self) => class TransactionAbortedException extends $.$stl.System.Transactions.TransactionException
        {
            static /*TransactionAbortedException */ Create$3(/*string?*/ message, /*Exception?*/ innerException, /*Guid*/ distributedTxId)
            {
                /*string?*/ let messagewithTxId = message;
                if ($.$stl.System.Transactions.TransactionException.IncludeDistributedTxId(distributedTxId))
                {
                    messagewithTxId = $.$stl.System.SR.Format$5($.$stl.System.SR.DistributedTxIDInTransactionException, messagewithTxId, distributedTxId);
                }
                return $.$stl.System.Transactions.TransactionAbortedException.Create$4(messagewithTxId, innerException);
            }
            static /*TransactionAbortedException */ Create$4(/*string?*/ message, /*Exception?*/ innerException)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace$1(1/*TransactionExceptionType.TransactionAbortedException*/, message, innerException === null ? $.$$.System.String.Empty : $.$$.System.Exception.ToString.call(innerException));
                }
                return new $.$stl.System.Transactions.TransactionAbortedException().$ctor$17(message, innerException);
            }
            $ctor$13()
            {
                super.$ctor$12($.$stl.System.SR.TransactionAborted);
                {
                }
                return this;
            }
            $ctor$18(/*string?*/ message)
            {
                super.$ctor$12(message ?? $.$stl.System.SR.TransactionAborted);
                {
                }
                return this;
            }
            $ctor$17(/*string?*/ message, /*Exception?*/ innerException)
            {
                super.$ctor$11(message ?? $.$stl.System.SR.TransactionAborted, innerException);
                {
                }
                return this;
            }
            $ctor$15(/*Exception?*/ innerException)
            {
                super.$ctor$11($.$stl.System.SR.TransactionAborted, innerException);
                {
                }
                return this;
            }
            $ctor$14(/*Exception?*/ innerException, /*Guid*/ distributedTxId)
            {
                super.$ctor$11($.$stl.System.Transactions.TransactionException.IncludeDistributedTxId(distributedTxId) ? $.$stl.System.SR.Format$5($.$stl.System.SR.DistributedTxIDInTransactionException, $.$stl.System.SR.TransactionAborted, distributedTxId) : $.$stl.System.SR.TransactionAborted, innerException);
                {
                }
                return this;
            }
            $ctor$16(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor$10(info, context);
                {
                }
                return this;
            }
            static $h = 4367628;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":4564236,"h":4367628}; }
            static get $b() { return $.$stl.System.Transactions.TransactionException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Transactions.TransactionAbortedException`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionInDoubtException", ($self) => class TransactionInDoubtException extends $.$stl.System.Transactions.TransactionException
        {
            static /*TransactionInDoubtException */ Create$3(/*TraceSourceType*/ traceSource, /*string?*/ message, /*Exception?*/ innerException, /*Guid*/ distributedTxId)
            {
                /*string?*/ let messagewithTxId = message;
                if ($.$stl.System.Transactions.TransactionException.IncludeDistributedTxId(distributedTxId))
                {
                    messagewithTxId = $.$stl.System.SR.Format$5($.$stl.System.SR.DistributedTxIDInTransactionException, messagewithTxId, distributedTxId);
                }
                return $.$stl.System.Transactions.TransactionInDoubtException.Create$4(traceSource, messagewithTxId, innerException);
            }
            static /*TransactionInDoubtException */ Create$4(/*TraceSourceType*/ traceSource, /*string?*/ message, /*Exception?*/ innerException)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace(traceSource, 3/*TransactionExceptionType.TransactionInDoubtException*/, message, innerException === null ? $.$$.System.String.Empty : $.$$.System.Exception.ToString.call(innerException));
                }
                return new $.$stl.System.Transactions.TransactionInDoubtException().$ctor$15(message, innerException);
            }
            $ctor$13()
            {
                super.$ctor$12($.$stl.System.SR.TransactionIndoubt);
                {
                }
                return this;
            }
            $ctor$16(/*string?*/ message)
            {
                super.$ctor$12(message ?? $.$stl.System.SR.TransactionIndoubt);
                {
                }
                return this;
            }
            $ctor$15(/*string?*/ message, /*Exception?*/ innerException)
            {
                super.$ctor$11(message ?? $.$stl.System.SR.TransactionIndoubt, innerException);
                {
                }
                return this;
            }
            $ctor$14(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor$10(info, context);
                {
                }
                return this;
            }
            static $h = 4695308;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":4564236,"h":4695308}; }
            static get $b() { return $.$stl.System.Transactions.TransactionException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Transactions.TransactionInDoubtException`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionManagerCommunicationException", ($self) => class TransactionManagerCommunicationException extends $.$stl.System.Transactions.TransactionException
        {
            static /*TransactionManagerCommunicationException */ Create$4(/*string?*/ message, /*Exception?*/ innerException)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace$1(4/*TransactionExceptionType.TransactionManagerCommunicationException*/, message, innerException === null ? $.$$.System.String.Empty : $.$$.System.Exception.ToString.call(innerException));
                }
                return new $.$stl.System.Transactions.TransactionManagerCommunicationException().$ctor$15(message, innerException);
            }
            static /*TransactionManagerCommunicationException */ Create$3(/*Exception?*/ innerException)
            {
                return $.$stl.System.Transactions.TransactionManagerCommunicationException.Create$4($.$stl.System.SR.TransactionManagerCommunicationException, innerException);
            }
            $ctor$13()
            {
                super.$ctor$12($.$stl.System.SR.TransactionManagerCommunicationException);
                {
                }
                return this;
            }
            $ctor$16(/*string?*/ message)
            {
                super.$ctor$12(message ?? $.$stl.System.SR.TransactionManagerCommunicationException);
                {
                }
                return this;
            }
            $ctor$15(/*string?*/ message, /*Exception?*/ innerException)
            {
                super.$ctor$11(message ?? $.$stl.System.SR.TransactionManagerCommunicationException, innerException);
                {
                }
                return this;
            }
            $ctor$14(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor$10(info, context);
                {
                }
                return this;
            }
            static $h = 4957452;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":4564236,"h":4957452}; }
            static get $b() { return $.$stl.System.Transactions.TransactionException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Transactions.TransactionManagerCommunicationException`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionPromotionException", ($self) => class TransactionPromotionException extends $.$stl.System.Transactions.TransactionException
        {
            $ctor$13()
            {
                this.$ctor$16($.$stl.System.SR.PromotionFailed);
                {
                }
                return this;
            }
            $ctor$16(/*string?*/ message)
            {
                super.$ctor$12(message ?? $.$stl.System.SR.PromotionFailed);
                {
                }
                return this;
            }
            $ctor$15(/*string?*/ message, /*Exception?*/ innerException)
            {
                super.$ctor$11(message ?? $.$stl.System.SR.PromotionFailed, innerException);
                {
                }
                return this;
            }
            $ctor$14(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor$10(info, context);
                {
                }
                return this;
            }
            static $h = 5088524;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":4564236,"h":5088524}; }
            static get $b() { return $.$stl.System.Transactions.TransactionException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Transactions.TransactionPromotionException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Collections.NonGeneric", "NetJs.System.Threading.Thread", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.Threading.Overlapped", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Xml.ReaderWriter"))