
(function ($global, $, $spc, $mwp, $sc, $sm, $spu, $sr, $sdt, $st, $scc, $sris, $scn, $stt, $ssc, $sspw, $ssa, $mwr, $snv, $sri, $sl, $sci, $scm, $so, $scp, $scs, $stee, $scsl, $sttp, $sdd, $sdf, $sifd, $sto, $sip, $sdpc, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $sxr) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Transactions.Local", 
    {"h":42245,"f":"System.Transactions.Local","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B99807a3edea449997cda60d38046fed69821a2f6","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Transactions.Local","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Transactions.Local","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$stl.System.Transactions.IDtcTransaction", ($self) => class IDtcTransaction
        {
            static $h = 2532613;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"p":[{"n":"retaining","p":655361},{"n":"commitType","p":655361,"a":[{"t":105709569,"c":8695644161,"a":[{"v":7,"t":110886913}]}]},{"n":"reserved","p":655361}],"n":"Commit","o":"System$Transactions$IDtcTransaction$Commit","d":2532613,"h":4297499909,"f":257},{"r":65537,"p":[{"n":"reason","p":786433},{"n":"retaining","p":655361},{"n":"async","p":655361}],"n":"Abort","o":"System$Transactions$IDtcTransaction$Abort","d":2532613,"h":8592467205,"f":257},{"r":65537,"p":[{"n":"transactionInformation","p":786433}],"n":"GetTransactionInfo","o":"System$Transactions$IDtcTransaction$GetTransactionInfo","d":2532613,"h":12887434501,"f":257}],"h":2532613,"a":[{"t":99155969,"c":4394123265},{"t":104398849,"c":4399366145,"a":[{"v":"0fb15084-af41-11ce-bd2b-204c4f4f5020","t":1310721}]},{"t":104923137,"c":4399890433,"a":[{"v":1,"t":99221505}]}]}; }
            static get $fullName() { return `System.Transactions.IDtcTransaction`; }
        });
        
        $asm.$cls("$stl.System.Transactions.ITransactionPromoter", ($self) => class ITransactionPromoter
        {
            static $h = 3253509;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":0,"n":"Promote","o":"System$Transactions$ITransactionPromoter$Promote","d":3253509,"h":4298220805,"f":257}],"h":3253509}; }
            static get $fullName() { return `System.Transactions.ITransactionPromoter`; }
        });
        
        $asm.$cls("$stl.System.Transactions.IEnlistmentNotificationInternal", ($self) => class IEnlistmentNotificationInternal
        {
            static $h = 2663685;
            static $f = 0b100100;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"p":[{"n":"preparingEnlistment","p":2925829}],"n":"Prepare","o":"System$Transactions$IEnlistmentNotificationInternal$Prepare","d":2663685,"h":4297630981,"f":257},{"r":65537,"p":[{"n":"enlistment","p":2925829}],"n":"Commit","o":"System$Transactions$IEnlistmentNotificationInternal$Commit","d":2663685,"h":8592598277,"f":257},{"r":65537,"p":[{"n":"enlistment","p":2925829}],"n":"Rollback","o":"System$Transactions$IEnlistmentNotificationInternal$Rollback","d":2663685,"h":12887565573,"f":257},{"r":65537,"p":[{"n":"enlistment","p":2925829}],"n":"InDoubt","o":"System$Transactions$IEnlistmentNotificationInternal$InDoubt","d":2663685,"h":17182532869,"f":257}],"h":2663685}; }
            static get $fullName() { return `System.Transactions.IEnlistmentNotificationInternal`; }
        });
        
        $asm.$cls("$stl.System.Transactions.IEnlistmentNotification", ($self) => class IEnlistmentNotification
        {
            static $h = 2598149;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"p":[{"n":"preparingEnlistment","p":3908869}],"n":"Prepare","o":"System$Transactions$IEnlistmentNotification$Prepare","d":2598149,"h":4297565445,"f":257},{"r":65537,"p":[{"n":"enlistment","p":1746181}],"n":"Commit","o":"System$Transactions$IEnlistmentNotification$Commit","d":2598149,"h":8592532741,"f":257},{"r":65537,"p":[{"n":"enlistment","p":1746181}],"n":"Rollback","o":"System$Transactions$IEnlistmentNotification$Rollback","d":2598149,"h":12887500037,"f":257},{"r":65537,"p":[{"n":"enlistment","p":1746181}],"n":"InDoubt","o":"System$Transactions$IEnlistmentNotification$InDoubt","d":2598149,"h":17182467333,"f":257}],"h":2598149}; }
            static get $fullName() { return `System.Transactions.IEnlistmentNotification`; }
        });
        
        $asm.$cls("$stl.System.Transactions.IPromotedEnlistment", ($self) => class IPromotedEnlistment
        {
            static $h = 2925829;
            static $f = 0b100100;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":2729221,"g":{"r":0,"d":0,"h":51542533381,"f":257},"s":{"r":0,"d":0,"h":55837500677,"f":257},"n":"InternalEnlistment","o":"System$Transactions$IPromotedEnlistment$InternalEnlistment","d":2925829,"h":47247566085,"f":257}],"m":[{"r":65537,"n":"EnlistmentDone","o":"System$Transactions$IPromotedEnlistment$EnlistmentDone","d":2925829,"h":4297893125,"f":257},{"r":65537,"n":"Prepared","o":"System$Transactions$IPromotedEnlistment$Prepared","d":2925829,"h":8592860421,"f":257},{"r":65537,"n":"ForceRollback","o":"System$Transactions$IPromotedEnlistment$ForceRollback","d":2925829,"h":12887827717,"f":257},{"r":65537,"p":[{"n":"e","p":47251457}],"n":"ForceRollback","o":"System$Transactions$IPromotedEnlistment$ForceRollback$1","d":2925829,"h":17182795013,"f":257},{"r":65537,"n":"Committed","o":"System$Transactions$IPromotedEnlistment$Committed","d":2925829,"h":21477762309,"f":257},{"r":65537,"n":"Aborted","o":"System$Transactions$IPromotedEnlistment$Aborted","d":2925829,"h":25772729605,"f":257},{"r":65537,"p":[{"n":"e","p":47251457}],"n":"Aborted","o":"System$Transactions$IPromotedEnlistment$Aborted$1","d":2925829,"h":30067696901,"f":257},{"r":65537,"n":"InDoubt","o":"System$Transactions$IPromotedEnlistment$InDoubt","d":2925829,"h":34362664197,"f":257},{"r":65537,"p":[{"n":"e","p":47251457}],"n":"InDoubt","o":"System$Transactions$IPromotedEnlistment$InDoubt$1","d":2925829,"h":38657631493,"f":257},{"r":0,"n":"GetRecoveryInformation","o":"System$Transactions$IPromotedEnlistment$GetRecoveryInformation","d":2925829,"h":42952598789,"f":257}],"h":2925829}; }
            static get $fullName() { return `System.Transactions.IPromotedEnlistment`; }
        });
        
        $asm.$cls("$stl.System.Transactions.IPromotableSinglePhaseNotification", ($self) => class IPromotableSinglePhaseNotification
        {
            static $h = 2860293;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"n":"Initialize","o":"System$Transactions$IPromotableSinglePhaseNotification$Initialize","d":2860293,"h":4297827589,"f":257},{"r":65537,"p":[{"n":"singlePhaseEnlistment","p":4105477}],"n":"SinglePhaseCommit","o":"System$Transactions$IPromotableSinglePhaseNotification$SinglePhaseCommit","d":2860293,"h":8592794885,"f":257},{"r":65537,"p":[{"n":"singlePhaseEnlistment","p":4105477}],"n":"Rollback","o":"System$Transactions$IPromotableSinglePhaseNotification$Rollback","d":2860293,"h":12887762181,"f":257}],"i":[3253509],"h":2860293}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stl.System.Transactions.ITransactionPromoter ]; }
            static get $fullName() { return `System.Transactions.IPromotableSinglePhaseNotification`; }
        });
        
        $asm.$cls("$stl.System.Transactions.ISinglePhaseNotificationInternal", ($self) => class ISinglePhaseNotificationInternal
        {
            static $h = 3122437;
            static $f = 0b100100;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"p":[{"n":"singlePhaseEnlistment","p":2925829}],"n":"SinglePhaseCommit","o":"System$Transactions$ISinglePhaseNotificationInternal$SinglePhaseCommit","d":3122437,"h":4298089733,"f":257}],"i":[2663685],"h":3122437}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stl.System.Transactions.IEnlistmentNotificationInternal ]; }
            static get $fullName() { return `System.Transactions.ISinglePhaseNotificationInternal`; }
        });
        
        $asm.$cls("$stl.System.Transactions.ISimpleTransactionSuperior", ($self) => class ISimpleTransactionSuperior
        {
            static $h = 2991365;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"n":"Rollback","o":"System$Transactions$ISimpleTransactionSuperior$Rollback","d":2991365,"h":4297958661,"f":257}],"i":[3253509],"h":2991365}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stl.System.Transactions.ITransactionPromoter ]; }
            static get $fullName() { return `System.Transactions.ISimpleTransactionSuperior`; }
        });
        
        $asm.$cls("$stl.System.Transactions.ISinglePhaseNotification", ($self) => class ISinglePhaseNotification
        {
            static $h = 3056901;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"p":[{"n":"singlePhaseEnlistment","p":4105477}],"n":"SinglePhaseCommit","o":"System$Transactions$ISinglePhaseNotification$SinglePhaseCommit","d":3056901,"h":4298024197,"f":257}],"i":[2598149],"h":3056901}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stl.System.Transactions.IEnlistmentNotification ]; }
            static get $fullName() { return `System.Transactions.ISinglePhaseNotification`; }
        });
        
        $asm.$cls("$stl.System.Transactions.EnlistmentState", ($self) => class EnlistmentState extends $.$spc.System.Object
        {
            /*EnlistmentStatePromoted?*/ static _enlistmentStatePromoted = null;
            /*object?*/ static s_classSyncObject = null;
            static /*EnlistmentStatePromoted */ get EnlistmentStatePromoted()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.EnlistmentStatePromoted, $.$ref(() => $.$stl.System.Transactions.EnlistmentState._enlistmentStatePromoted, ($v) => $.$stl.System.Transactions.EnlistmentState._enlistmentStatePromoted = $v, $.$stl.System.Transactions.EnlistmentStatePromoted), $.$ref(() => $.$stl.System.Transactions.EnlistmentState.s_classSyncObject, ($v) => $.$stl.System.Transactions.EnlistmentState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.EnlistmentStatePromoted))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.EnlistmentStatePromoted().$ctor$2();
                }, {"r":2008325,"n":"","d":1942789,"h":0,"f":1048578}));
            }
            /*void */ EnlistmentDone(/*InternalEnlistment*/ enlistment)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateEnlistmentStateException(null, enlistment === null ? $.$spc.System.Guid.Empty : enlistment.DistributedTxId);
            }
            /*void */ Prepared(/*InternalEnlistment*/ enlistment)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateEnlistmentStateException(null, enlistment === null ? $.$spc.System.Guid.Empty : enlistment.DistributedTxId);
            }
            /*void */ ForceRollback(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateEnlistmentStateException(null, enlistment === null ? $.$spc.System.Guid.Empty : enlistment.DistributedTxId);
            }
            /*void */ Committed(/*InternalEnlistment*/ enlistment)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateEnlistmentStateException(null, enlistment === null ? $.$spc.System.Guid.Empty : enlistment.DistributedTxId);
            }
            /*void */ Aborted(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateEnlistmentStateException(null, enlistment === null ? $.$spc.System.Guid.Empty : enlistment.DistributedTxId);
            }
            /*void */ InDoubt(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateEnlistmentStateException(null, enlistment === null ? $.$spc.System.Guid.Empty : enlistment.DistributedTxId);
            }
            /*byte[] */ RecoveryInformation(/*InternalEnlistment*/ enlistment)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateEnlistmentStateException(null, enlistment === null ? $.$spc.System.Guid.Empty : enlistment.DistributedTxId);
            }
            /*void */ InternalAborted(/*InternalEnlistment*/ enlistment)
            {
                $.$spc.System.Diagnostics.Debug.Fail(`Invalid Event for InternalEnlistment State; Current State: ${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))}`);
                throw $.$stl.System.Transactions.TransactionException.CreateEnlistmentStateException(null, enlistment === null ? $.$spc.System.Guid.Empty : enlistment.DistributedTxId);
            }
            /*void */ InternalCommitted(/*InternalEnlistment*/ enlistment)
            {
                $.$spc.System.Diagnostics.Debug.Fail(`Invalid Event for InternalEnlistment State; Current State: ${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))}`);
                throw $.$stl.System.Transactions.TransactionException.CreateEnlistmentStateException(null, enlistment === null ? $.$spc.System.Guid.Empty : enlistment.DistributedTxId);
            }
            /*void */ InternalIndoubt(/*InternalEnlistment*/ enlistment)
            {
                $.$spc.System.Diagnostics.Debug.Fail(`Invalid Event for InternalEnlistment State; Current State: ${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))}`);
                throw $.$stl.System.Transactions.TransactionException.CreateEnlistmentStateException(null, enlistment === null ? $.$spc.System.Guid.Empty : enlistment.DistributedTxId);
            }
            /*void */ ChangeStateCommitting(/*InternalEnlistment*/ enlistment)
            {
                $.$spc.System.Diagnostics.Debug.Fail(`Invalid Event for InternalEnlistment State; Current State: ${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))}`);
                throw $.$stl.System.Transactions.TransactionException.CreateEnlistmentStateException(null, enlistment === null ? $.$spc.System.Guid.Empty : enlistment.DistributedTxId);
            }
            /*void */ ChangeStatePromoted(/*InternalEnlistment*/ enlistment, /*IPromotedEnlistment*/ promotedEnlistment)
            {
                $.$spc.System.Diagnostics.Debug.Fail(`Invalid Event for InternalEnlistment State; Current State: ${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))}`);
                throw $.$stl.System.Transactions.TransactionException.CreateEnlistmentStateException(null, enlistment === null ? $.$spc.System.Guid.Empty : enlistment.DistributedTxId);
            }
            /*void */ ChangeStateDelegated(/*InternalEnlistment*/ enlistment)
            {
                $.$spc.System.Diagnostics.Debug.Fail(`Invalid Event for InternalEnlistment State; Current State: ${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))}`);
                throw $.$stl.System.Transactions.TransactionException.CreateEnlistmentStateException(null, enlistment === null ? $.$spc.System.Guid.Empty : enlistment.DistributedTxId);
            }
            /*void */ ChangeStatePreparing(/*InternalEnlistment*/ enlistment)
            {
                $.$spc.System.Diagnostics.Debug.Fail(`Invalid Event for InternalEnlistment State; Current State: ${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))}`);
                throw $.$stl.System.Transactions.TransactionException.CreateEnlistmentStateException(null, enlistment === null ? $.$spc.System.Guid.Empty : enlistment.DistributedTxId);
            }
            /*void */ ChangeStateSinglePhaseCommit(/*InternalEnlistment*/ enlistment)
            {
                $.$spc.System.Diagnostics.Debug.Fail(`Invalid Event for InternalEnlistment State; Current State: ${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))}`);
                throw $.$stl.System.Transactions.TransactionException.CreateEnlistmentStateException(null, enlistment === null ? $.$spc.System.Guid.Empty : enlistment.DistributedTxId);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 1942789;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":2008325,"g":{"r":0,"d":0,"h":21476779269,"f":40},"n":"EnlistmentStatePromoted","d":1942789,"h":17181811973,"f":40}],"m":[{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"EnterState","d":1942789,"h":4296910085,"f":264},{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"EnlistmentDone","d":1942789,"h":25771746565,"f":136},{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"Prepared","d":1942789,"h":30066713861,"f":136},{"r":65537,"p":[{"n":"enlistment","p":2729221},{"n":"e","p":47251457}],"n":"ForceRollback","d":1942789,"h":34361681157,"f":136},{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"Committed","d":1942789,"h":38656648453,"f":136},{"r":65537,"p":[{"n":"enlistment","p":2729221},{"n":"e","p":47251457}],"n":"Aborted","d":1942789,"h":42951615749,"f":136},{"r":65537,"p":[{"n":"enlistment","p":2729221},{"n":"e","p":47251457}],"n":"InDoubt","d":1942789,"h":47246583045,"f":136},{"r":0,"p":[{"n":"enlistment","p":2729221}],"n":"RecoveryInformation","d":1942789,"h":51541550341,"f":136},{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"InternalAborted","d":1942789,"h":55836517637,"f":136},{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"InternalCommitted","d":1942789,"h":60131484933,"f":136},{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"InternalIndoubt","d":1942789,"h":64426452229,"f":136},{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"ChangeStateCommitting","d":1942789,"h":68721419525,"f":136},{"r":65537,"p":[{"n":"enlistment","p":2729221},{"n":"promotedEnlistment","p":2925829}],"n":"ChangeStatePromoted","d":1942789,"h":73016386821,"f":136},{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"ChangeStateDelegated","d":1942789,"h":77311354117,"f":136},{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"ChangeStatePreparing","d":1942789,"h":81606321413,"f":136},{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"ChangeStateSinglePhaseCommit","d":1942789,"h":85901288709,"f":136}],"l":[{"t":2008325,"n":"_enlistmentStatePromoted","d":1942789,"h":8591877381,"f":40},{"t":131073,"n":"s_classSyncObject","d":1942789,"h":12886844677,"f":34}],"c":[{"n":".ctor","o":"$ctor$1","d":1942789,"h":90196256005,"f":4}],"h":1942789}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Transactions.EnlistmentState`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionState", ($self) => class TransactionState extends $.$spc.System.Object
        {
            /*TransactionStateActive?*/ static s_transactionStateActive = null;
            /*TransactionStateSubordinateActive?*/ static s_transactionStateSubordinateActive = null;
            /*TransactionStatePhase0?*/ static s_transactionStatePhase0 = null;
            /*TransactionStateVolatilePhase1?*/ static s_transactionStateVolatilePhase1 = null;
            /*TransactionStateVolatileSPC?*/ static s_transactionStateVolatileSPC = null;
            /*TransactionStateSPC?*/ static s_transactionStateSPC = null;
            /*TransactionStateAborted?*/ static s_transactionStateAborted = null;
            /*TransactionStateCommitted?*/ static s_transactionStateCommitted = null;
            /*TransactionStateInDoubt?*/ static s_transactionStateInDoubt = null;
            /*TransactionStatePromoted?*/ static s_transactionStatePromoted = null;
            /*TransactionStateNonCommittablePromoted?*/ static s_transactionStateNonCommittablePromoted = null;
            /*TransactionStatePromotedP0Wave?*/ static s_transactionStatePromotedP0Wave = null;
            /*TransactionStatePromotedCommitting?*/ static s_transactionStatePromotedCommitting = null;
            /*TransactionStatePromotedPhase0?*/ static s_transactionStatePromotedPhase0 = null;
            /*TransactionStatePromotedPhase1?*/ static s_transactionStatePromotedPhase1 = null;
            /*TransactionStatePromotedP0Aborting?*/ static s_transactionStatePromotedP0Aborting = null;
            /*TransactionStatePromotedP1Aborting?*/ static s_transactionStatePromotedP1Aborting = null;
            /*TransactionStatePromotedAborted?*/ static s_transactionStatePromotedAborted = null;
            /*TransactionStatePromotedCommitted?*/ static s_transactionStatePromotedCommitted = null;
            /*TransactionStatePromotedIndoubt?*/ static s_transactionStatePromotedIndoubt = null;
            /*TransactionStateDelegated?*/ static s_transactionStateDelegated = null;
            /*TransactionStateDelegatedSubordinate?*/ static s_transactionStateDelegatedSubordinate = null;
            /*TransactionStateDelegatedP0Wave?*/ static s_transactionStateDelegatedP0Wave = null;
            /*TransactionStateDelegatedCommitting?*/ static s_transactionStateDelegatedCommitting = null;
            /*TransactionStateDelegatedAborting?*/ static s_transactionStateDelegatedAborting = null;
            /*TransactionStatePSPEOperation?*/ static s_transactionStatePSPEOperation = null;
            /*TransactionStateDelegatedNonMSDTC?*/ static s_transactionStateDelegatedNonMSDTC = null;
            /*TransactionStatePromotedNonMSDTCPhase0?*/ static s_transactionStatePromotedNonMSDTCPhase0 = null;
            /*TransactionStatePromotedNonMSDTCVolatilePhase1?*/ static s_transactionStatePromotedNonMSDTCVolatilePhase1 = null;
            /*TransactionStatePromotedNonMSDTCSinglePhaseCommit?*/ static s_transactionStatePromotedNonMSDTCSinglePhaseCommit = null;
            /*TransactionStatePromotedNonMSDTCAborted?*/ static s_transactionStatePromotedNonMSDTCAborted = null;
            /*TransactionStatePromotedNonMSDTCCommitted?*/ static s_transactionStatePromotedNonMSDTCCommitted = null;
            /*TransactionStatePromotedNonMSDTCIndoubt?*/ static s_transactionStatePromotedNonMSDTCIndoubt = null;
            /*object?*/ static s_classSyncObject = null;
            static /*TransactionStateActive */ get TransactionStateActive()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStateActive, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStateActive, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStateActive = $v, $.$stl.System.Transactions.TransactionStateActive), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStateActive))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStateActive().$ctor$4();
                }, {"r":5874949,"n":"","d":5743877,"h":0,"f":1048578}));
            }
            static /*TransactionStateSubordinateActive */ get TransactionStateSubordinateActive()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStateSubordinateActive, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStateSubordinateActive, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStateSubordinateActive = $v, $.$stl.System.Transactions.TransactionStateSubordinateActive), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStateSubordinateActive))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStateSubordinateActive().$ctor$5();
                }, {"r":8234245,"n":"","d":5743877,"h":0,"f":1048578}));
            }
            static /*TransactionStatePSPEOperation */ get TransactionStatePSPEOperation()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStatePSPEOperation, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePSPEOperation, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePSPEOperation = $v, $.$stl.System.Transactions.TransactionStatePSPEOperation), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStatePSPEOperation))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePSPEOperation().$ctor$2();
                }, {"r":8103173,"n":"","d":5743877,"h":0,"f":1048578}));
            }
            static /*TransactionStatePhase0 */ get TransactionStatePhase0()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStatePhase0, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePhase0, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePhase0 = $v, $.$stl.System.Transactions.TransactionStatePhase0), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStatePhase0))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePhase0().$ctor$4();
                }, {"r":6661381,"n":"","d":5743877,"h":0,"f":1048578}));
            }
            static /*TransactionStateVolatilePhase1 */ get TransactionStateVolatilePhase1()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStateVolatilePhase1, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStateVolatilePhase1, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStateVolatilePhase1 = $v, $.$stl.System.Transactions.TransactionStateVolatilePhase1), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStateVolatilePhase1))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStateVolatilePhase1().$ctor$3();
                }, {"r":8299781,"n":"","d":5743877,"h":0,"f":1048578}));
            }
            static /*TransactionStateVolatileSPC */ get TransactionStateVolatileSPC()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStateVolatileSPC, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStateVolatileSPC, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStateVolatileSPC = $v, $.$stl.System.Transactions.TransactionStateVolatileSPC), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStateVolatileSPC))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStateVolatileSPC().$ctor$3();
                }, {"r":8365317,"n":"","d":5743877,"h":0,"f":1048578}));
            }
            static /*TransactionStateSPC */ get TransactionStateSPC()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStateSPC, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStateSPC, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStateSPC = $v, $.$stl.System.Transactions.TransactionStateSPC), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStateSPC))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStateSPC().$ctor$3();
                }, {"r":8168709,"n":"","d":5743877,"h":0,"f":1048578}));
            }
            static /*TransactionStateAborted */ get TransactionStateAborted()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStateAborted, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStateAborted, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStateAborted = $v, $.$stl.System.Transactions.TransactionStateAborted), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStateAborted))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStateAborted().$ctor$3();
                }, {"r":5809413,"n":"","d":5743877,"h":0,"f":1048578}));
            }
            static /*TransactionStateCommitted */ get TransactionStateCommitted()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStateCommitted, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStateCommitted, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStateCommitted = $v, $.$stl.System.Transactions.TransactionStateCommitted), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStateCommitted))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStateCommitted().$ctor$3();
                }, {"r":5940485,"n":"","d":5743877,"h":0,"f":1048578}));
            }
            static /*TransactionStateInDoubt */ get TransactionStateInDoubt()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStateInDoubt, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStateInDoubt, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStateInDoubt = $v, $.$stl.System.Transactions.TransactionStateInDoubt), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStateInDoubt))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStateInDoubt().$ctor$3();
                }, {"r":6530309,"n":"","d":5743877,"h":0,"f":1048578}));
            }
            static /*TransactionStatePromoted */ get TransactionStatePromoted()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStatePromoted, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromoted, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromoted = $v, $.$stl.System.Transactions.TransactionStatePromoted), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStatePromoted))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromoted().$ctor$3();
                }, {"r":6726917,"n":"","d":5743877,"h":0,"f":1048578}));
            }
            static /*TransactionStateNonCommittablePromoted */ get TransactionStateNonCommittablePromoted()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStateNonCommittablePromoted, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStateNonCommittablePromoted, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStateNonCommittablePromoted = $v, $.$stl.System.Transactions.TransactionStateNonCommittablePromoted), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStateNonCommittablePromoted))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStateNonCommittablePromoted().$ctor$3();
                }, {"r":6595845,"n":"","d":5743877,"h":0,"f":1048578}));
            }
            static /*TransactionStatePromotedP0Wave */ get TransactionStatePromotedP0Wave()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStatePromotedP0Wave, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedP0Wave, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedP0Wave = $v, $.$stl.System.Transactions.TransactionStatePromotedP0Wave), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStatePromotedP0Wave))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromotedP0Wave().$ctor$3();
                }, {"r":7841029,"n":"","d":5743877,"h":0,"f":1048578}));
            }
            static /*TransactionStatePromotedCommitting */ get TransactionStatePromotedCommitting()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStatePromotedCommitting, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedCommitting, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedCommitting = $v, $.$stl.System.Transactions.TransactionStatePromotedCommitting), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStatePromotedCommitting))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromotedCommitting().$ctor$3();
                }, {"r":7054597,"n":"","d":5743877,"h":0,"f":1048578}));
            }
            static /*TransactionStatePromotedPhase0 */ get TransactionStatePromotedPhase0()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStatePromotedPhase0, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedPhase0, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedPhase0 = $v, $.$stl.System.Transactions.TransactionStatePromotedPhase0), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStatePromotedPhase0))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromotedPhase0().$ctor$4();
                }, {"r":7972101,"n":"","d":5743877,"h":0,"f":1048578}));
            }
            static /*TransactionStatePromotedPhase1 */ get TransactionStatePromotedPhase1()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStatePromotedPhase1, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedPhase1, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedPhase1 = $v, $.$stl.System.Transactions.TransactionStatePromotedPhase1), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStatePromotedPhase1))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromotedPhase1().$ctor$4();
                }, {"r":8037637,"n":"","d":5743877,"h":0,"f":1048578}));
            }
            static /*TransactionStatePromotedP0Aborting */ get TransactionStatePromotedP0Aborting()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStatePromotedP0Aborting, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedP0Aborting, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedP0Aborting = $v, $.$stl.System.Transactions.TransactionStatePromotedP0Aborting), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStatePromotedP0Aborting))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromotedP0Aborting().$ctor$4();
                }, {"r":7775493,"n":"","d":5743877,"h":0,"f":1048578}));
            }
            static /*TransactionStatePromotedP1Aborting */ get TransactionStatePromotedP1Aborting()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStatePromotedP1Aborting, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedP1Aborting, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedP1Aborting = $v, $.$stl.System.Transactions.TransactionStatePromotedP1Aborting), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStatePromotedP1Aborting))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromotedP1Aborting().$ctor$4();
                }, {"r":7906565,"n":"","d":5743877,"h":0,"f":1048578}));
            }
            static /*TransactionStatePromotedAborted */ get TransactionStatePromotedAborted()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStatePromotedAborted, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedAborted, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedAborted = $v, $.$stl.System.Transactions.TransactionStatePromotedAborted), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStatePromotedAborted))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromotedAborted().$ctor$4();
                }, {"r":6792453,"n":"","d":5743877,"h":0,"f":1048578}));
            }
            static /*TransactionStatePromotedCommitted */ get TransactionStatePromotedCommitted()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStatePromotedCommitted, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedCommitted, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedCommitted = $v, $.$stl.System.Transactions.TransactionStatePromotedCommitted), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStatePromotedCommitted))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromotedCommitted().$ctor$4();
                }, {"r":6989061,"n":"","d":5743877,"h":0,"f":1048578}));
            }
            static /*TransactionStatePromotedIndoubt */ get TransactionStatePromotedIndoubt()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStatePromotedIndoubt, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedIndoubt, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedIndoubt = $v, $.$stl.System.Transactions.TransactionStatePromotedIndoubt), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStatePromotedIndoubt))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromotedIndoubt().$ctor$4();
                }, {"r":7185669,"n":"","d":5743877,"h":0,"f":1048578}));
            }
            static /*TransactionStateDelegated */ get TransactionStateDelegated()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStateDelegated, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStateDelegated, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStateDelegated = $v, $.$stl.System.Transactions.TransactionStateDelegated), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStateDelegated))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStateDelegated().$ctor$5();
                }, {"r":6006021,"n":"","d":5743877,"h":0,"f":1048578}));
            }
            static /*TransactionStateDelegatedSubordinate */ get TransactionStateDelegatedSubordinate()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStateDelegatedSubordinate, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStateDelegatedSubordinate, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStateDelegatedSubordinate = $v, $.$stl.System.Transactions.TransactionStateDelegatedSubordinate), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStateDelegatedSubordinate))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStateDelegatedSubordinate().$ctor$5();
                }, {"r":6399237,"n":"","d":5743877,"h":0,"f":1048578}));
            }
            static /*TransactionStateDelegatedP0Wave */ get TransactionStateDelegatedP0Wave()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStateDelegatedP0Wave, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStateDelegatedP0Wave, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStateDelegatedP0Wave = $v, $.$stl.System.Transactions.TransactionStateDelegatedP0Wave), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStateDelegatedP0Wave))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStateDelegatedP0Wave().$ctor$4();
                }, {"r":6333701,"n":"","d":5743877,"h":0,"f":1048578}));
            }
            static /*TransactionStateDelegatedCommitting */ get TransactionStateDelegatedCommitting()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStateDelegatedCommitting, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStateDelegatedCommitting, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStateDelegatedCommitting = $v, $.$stl.System.Transactions.TransactionStateDelegatedCommitting), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStateDelegatedCommitting))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStateDelegatedCommitting().$ctor$4();
                }, {"r":6202629,"n":"","d":5743877,"h":0,"f":1048578}));
            }
            static /*TransactionStateDelegatedAborting */ get TransactionStateDelegatedAborting()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStateDelegatedAborting, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStateDelegatedAborting, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStateDelegatedAborting = $v, $.$stl.System.Transactions.TransactionStateDelegatedAborting), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStateDelegatedAborting))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStateDelegatedAborting().$ctor$5();
                }, {"r":6071557,"n":"","d":5743877,"h":0,"f":1048578}));
            }
            static /*TransactionStateDelegatedNonMSDTC */ get TransactionStateDelegatedNonMSDTC()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStateDelegatedNonMSDTC, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStateDelegatedNonMSDTC, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStateDelegatedNonMSDTC = $v, $.$stl.System.Transactions.TransactionStateDelegatedNonMSDTC), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStateDelegatedNonMSDTC))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStateDelegatedNonMSDTC().$ctor$3();
                }, {"r":6268165,"n":"","d":5743877,"h":0,"f":1048578}));
            }
            static /*TransactionStatePromotedNonMSDTCPhase0 */ get TransactionStatePromotedNonMSDTCPhase0()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStatePromotedNonMSDTCPhase0, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedNonMSDTCPhase0, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedNonMSDTCPhase0 = $v, $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCPhase0), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStatePromotedNonMSDTCPhase0))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCPhase0().$ctor$3();
                }, {"r":7578885,"n":"","d":5743877,"h":0,"f":1048578}));
            }
            static /*TransactionStatePromotedNonMSDTCVolatilePhase1 */ get TransactionStatePromotedNonMSDTCVolatilePhase1()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStatePromotedNonMSDTCVolatilePhase1, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedNonMSDTCVolatilePhase1, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedNonMSDTCVolatilePhase1 = $v, $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCVolatilePhase1), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStatePromotedNonMSDTCVolatilePhase1))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCVolatilePhase1().$ctor$3();
                }, {"r":7709957,"n":"","d":5743877,"h":0,"f":1048578}));
            }
            static /*TransactionStatePromotedNonMSDTCSinglePhaseCommit */ get TransactionStatePromotedNonMSDTCSinglePhaseCommit()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStatePromotedNonMSDTCSinglePhaseCommit, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedNonMSDTCSinglePhaseCommit, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedNonMSDTCSinglePhaseCommit = $v, $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCSinglePhaseCommit), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStatePromotedNonMSDTCSinglePhaseCommit))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCSinglePhaseCommit().$ctor$3();
                }, {"r":7644421,"n":"","d":5743877,"h":0,"f":1048578}));
            }
            static /*TransactionStatePromotedNonMSDTCAborted */ get TransactionStatePromotedNonMSDTCAborted()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStatePromotedNonMSDTCAborted, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedNonMSDTCAborted, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedNonMSDTCAborted = $v, $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCAborted), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStatePromotedNonMSDTCAborted))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCAborted().$ctor$4();
                }, {"r":7251205,"n":"","d":5743877,"h":0,"f":1048578}));
            }
            static /*TransactionStatePromotedNonMSDTCCommitted */ get TransactionStatePromotedNonMSDTCCommitted()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStatePromotedNonMSDTCCommitted, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedNonMSDTCCommitted, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedNonMSDTCCommitted = $v, $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCCommitted), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStatePromotedNonMSDTCCommitted))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCCommitted().$ctor$4();
                }, {"r":7382277,"n":"","d":5743877,"h":0,"f":1048578}));
            }
            static /*TransactionStatePromotedNonMSDTCIndoubt */ get TransactionStatePromotedNonMSDTCIndoubt()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStatePromotedNonMSDTCIndoubt, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedNonMSDTCIndoubt, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedNonMSDTCIndoubt = $v, $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCIndoubt), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStatePromotedNonMSDTCIndoubt))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCIndoubt().$ctor$4();
                }, {"r":7513349,"n":"","d":5743877,"h":0,"f":1048578}));
            }
            /*void */ CommonEnterState(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(tx.State !== this, "Changing to the same state.");
                tx.State = this;
                $.$spc.System.Array.$WriteT1.call(tx._stateHistory, this, tx._currentStateHist);
                if (++tx._currentStateHist > 20/*InternalTransaction.MaxStateHist*/)
                {
                    tx._currentStateHist = 0;
                }
            }
            /*void */ BeginCommit(/*InternalTransaction*/ tx, /*bool*/ asyncCommit, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ EndCommit(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Fail(`Invalid Event for State; Current State: ${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))}`);
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*Enlistment */ EnlistDurable(/*InternalTransaction*/ tx, /*Guid*/ resourceManagerIdentifier, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*Enlistment */ EnlistDurable$1(/*InternalTransaction*/ tx, /*Guid*/ resourceManagerIdentifier, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*Enlistment */ EnlistVolatile(/*InternalTransaction*/ tx, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*Enlistment */ EnlistVolatile$1(/*InternalTransaction*/ tx, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ CheckForFinishedTransaction(/*InternalTransaction*/ tx)
            {
            }
            /*Guid */ get_Identifier(/*InternalTransaction*/ tx)
            {
                return $.$spc.System.Guid.Empty;
            }
            /*void */ AddOutcomeRegistrant(/*InternalTransaction*/ tx, /*TransactionCompletedEventHandler?*/ transactionCompletedDelegate)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ GetObjectData(/*InternalTransaction*/ tx, /*SerializationInfo*/ serializationInfo, /*StreamingContext*/ context)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*bool */ EnlistPromotableSinglePhase(/*InternalTransaction*/ tx, /*IPromotableSinglePhaseNotification*/ promotableSinglePhaseNotification, /*Transaction*/ atomicTransaction, /*Guid*/ promoterType)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ CompleteBlockingClone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ CompleteAbortingClone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ CreateBlockingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ CreateAbortingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ ChangeStateTransactionAborted(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                $.$spc.System.Diagnostics.Debug.Fail(`Invalid Event for State; Current State: ${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))}`);
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace$1(0/*TransactionExceptionType.InvalidOperationException*/, (tx?.TransactionTraceId.TransactionIdentifier ?? null) ?? $.$spc.System.String.Empty, $.$spc.System.Exception.ToString.call(e));
                }
                throw new $.$spc.System.InvalidOperationException().$ctor$9();
            }
            /*void */ ChangeStateTransactionCommitted(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Fail(`Invalid Event for State; Current State: ${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))}`);
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace$1(0/*TransactionExceptionType.InvalidOperationException*/, (tx?.TransactionTraceId.TransactionIdentifier ?? null) ?? $.$spc.System.String.Empty, $.$spc.System.String.Empty);
                }
                throw new $.$spc.System.InvalidOperationException().$ctor$9();
            }
            /*void */ InDoubtFromEnlistment(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Fail(`Invalid Event for State; Current State: ${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))}`);
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace$1(0/*TransactionExceptionType.InvalidOperationException*/, (tx?.TransactionTraceId.TransactionIdentifier ?? null) ?? $.$spc.System.String.Empty, $.$spc.System.String.Empty);
                }
                throw new $.$spc.System.InvalidOperationException().$ctor$9();
            }
            /*void */ ChangeStatePromotedAborted(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Fail(`Invalid Event for State; Current State: ${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))}`);
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace$1(0/*TransactionExceptionType.InvalidOperationException*/, (tx?.TransactionTraceId.TransactionIdentifier ?? null) ?? $.$spc.System.String.Empty, $.$spc.System.String.Empty);
                }
                throw new $.$spc.System.InvalidOperationException().$ctor$9();
            }
            /*void */ ChangeStatePromotedCommitted(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Fail(`Invalid Event for State; Current State: ${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))}`);
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace$1(0/*TransactionExceptionType.InvalidOperationException*/, (tx?.TransactionTraceId.TransactionIdentifier ?? null) ?? $.$spc.System.String.Empty, $.$spc.System.String.Empty);
                }
                throw new $.$spc.System.InvalidOperationException().$ctor$9();
            }
            /*void */ InDoubtFromDtc(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Fail(`Invalid Event for State; Current State: ${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))}`);
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace$1(0/*TransactionExceptionType.InvalidOperationException*/, (tx?.TransactionTraceId.TransactionIdentifier ?? null) ?? $.$spc.System.String.Empty, $.$spc.System.String.Empty);
                }
                throw new $.$spc.System.InvalidOperationException().$ctor$9();
            }
            /*void */ ChangeStatePromotedPhase0(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Fail(`Invalid Event for State; Current State: ${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))}`);
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace$1(0/*TransactionExceptionType.InvalidOperationException*/, (tx?.TransactionTraceId.TransactionIdentifier ?? null) ?? $.$spc.System.String.Empty, $.$spc.System.String.Empty);
                }
                throw new $.$spc.System.InvalidOperationException().$ctor$9();
            }
            /*void */ ChangeStatePromotedPhase1(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Fail(`Invalid Event for State; Current State: ${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))}`);
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace$1(0/*TransactionExceptionType.InvalidOperationException*/, (tx?.TransactionTraceId.TransactionIdentifier ?? null) ?? $.$spc.System.String.Empty, $.$spc.System.String.Empty);
                }
                throw new $.$spc.System.InvalidOperationException().$ctor$9();
            }
            /*void */ ChangeStateAbortedDuringPromotion(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Fail(`Invalid Event for State; Current State: ${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))}`);
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace$1(0/*TransactionExceptionType.InvalidOperationException*/, (tx?.TransactionTraceId.TransactionIdentifier ?? null) ?? $.$spc.System.String.Empty, $.$spc.System.String.Empty);
                }
                throw new $.$spc.System.InvalidOperationException().$ctor$9();
            }
            /*void */ Timeout(/*InternalTransaction*/ tx)
            {
            }
            /*void */ Phase0VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Fail(`Invalid Event for State; Current State: ${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))}`);
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ Phase1VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Fail(`Invalid Event for State; Current State: ${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))}`);
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ RestartCommitIfNeeded(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Fail(`Invalid Event for State; Current State: ${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))}`);
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace$1(0/*TransactionExceptionType.InvalidOperationException*/, (tx?.TransactionTraceId.TransactionIdentifier ?? null) ?? $.$spc.System.String.Empty, $.$spc.System.String.Empty);
                }
                throw new $.$spc.System.InvalidOperationException().$ctor$9();
            }
            /*bool */ ContinuePhase0Prepares()
            {
                return false;
            }
            /*bool */ ContinuePhase1Prepares()
            {
                return false;
            }
            /*void */ Promote(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*byte[] */ PromotedToken(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*Enlistment */ PromoteAndEnlistDurable(/*InternalTransaction*/ tx, /*Guid*/ resourceManagerIdentifier, /*IPromotableSinglePhaseNotification*/ promotableNotification, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ SetDistributedTransactionId(/*InternalTransaction*/ tx, /*IPromotableSinglePhaseNotification*/ promotableNotification, /*Guid*/ distributedTransactionIdentifier)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ DisposeRoot(/*InternalTransaction*/ tx)
            {
            }
            /*bool */ IsCompleted(/*InternalTransaction*/ tx)
            {
                tx._needPulse = true;
                return false;
            }
            static /*void */ AddVolatileEnlistment(/*ref VolatileEnlistmentSet*/ enlistments, /*Enlistment*/ enlistment)
            {
                if (enlistments.$v._volatileEnlistmentCount === enlistments.$v._volatileEnlistmentSize)
                {
                    /*InternalEnlistment[]*/ let newEnlistments = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$stl.System.Transactions.InternalEnlistment), null, [((enlistments.$v._volatileEnlistmentSize + 8/*InternalTransaction.VolatileArrayIncrement*/) | 0)], null);
                    if (enlistments.$v._volatileEnlistmentSize > 0)
                    {
                        $.$spc.System.Array.Copy$1(enlistments.$v._volatileEnlistments, 0, newEnlistments, 0, enlistments.$v._volatileEnlistmentSize);
                    }
                    enlistments.$v._volatileEnlistmentSize += 8/*InternalTransaction.VolatileArrayIncrement*/;
                    enlistments.$v._volatileEnlistments = newEnlistments;
                }
                $.$spc.System.Array.$WriteT1.call(enlistments.$v._volatileEnlistments, enlistment.InternalEnlistment, enlistments.$v._volatileEnlistmentCount);
                enlistments.$v._volatileEnlistmentCount++;
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentActive.EnterState($.$spc.System.Array.$ReadT1.call(enlistments.$v._volatileEnlistments, ((enlistments.$v._volatileEnlistmentCount - 1) | 0)));
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 5743877;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":5874949,"g":{"r":0,"d":0,"h":154624566533,"f":40},"n":"TransactionStateActive","d":5743877,"h":150329599237,"f":40},{"p":8234245,"g":{"r":0,"d":0,"h":163214501125,"f":40},"n":"TransactionStateSubordinateActive","d":5743877,"h":158919533829,"f":40},{"p":8103173,"g":{"r":0,"d":0,"h":171804435717,"f":40},"n":"TransactionStatePSPEOperation","d":5743877,"h":167509468421,"f":40},{"p":6661381,"g":{"r":0,"d":0,"h":180394370309,"f":36},"n":"TransactionStatePhase0","d":5743877,"h":176099403013,"f":36},{"p":8299781,"g":{"r":0,"d":0,"h":188984304901,"f":36},"n":"TransactionStateVolatilePhase1","d":5743877,"h":184689337605,"f":36},{"p":8365317,"g":{"r":0,"d":0,"h":197574239493,"f":36},"n":"TransactionStateVolatileSPC","d":5743877,"h":193279272197,"f":36},{"p":8168709,"g":{"r":0,"d":0,"h":206164174085,"f":36},"n":"TransactionStateSPC","d":5743877,"h":201869206789,"f":36},{"p":5809413,"g":{"r":0,"d":0,"h":214754108677,"f":36},"n":"TransactionStateAborted","d":5743877,"h":210459141381,"f":36},{"p":5940485,"g":{"r":0,"d":0,"h":223344043269,"f":36},"n":"TransactionStateCommitted","d":5743877,"h":219049075973,"f":36},{"p":6530309,"g":{"r":0,"d":0,"h":231933977861,"f":36},"n":"TransactionStateInDoubt","d":5743877,"h":227639010565,"f":36},{"p":6726917,"g":{"r":0,"d":0,"h":240523912453,"f":40},"n":"TransactionStatePromoted","d":5743877,"h":236228945157,"f":40},{"p":6595845,"g":{"r":0,"d":0,"h":249113847045,"f":40},"n":"TransactionStateNonCommittablePromoted","d":5743877,"h":244818879749,"f":40},{"p":7841029,"g":{"r":0,"d":0,"h":257703781637,"f":36},"n":"TransactionStatePromotedP0Wave","d":5743877,"h":253408814341,"f":36},{"p":7054597,"g":{"r":0,"d":0,"h":266293716229,"f":36},"n":"TransactionStatePromotedCommitting","d":5743877,"h":261998748933,"f":36},{"p":7972101,"g":{"r":0,"d":0,"h":274883650821,"f":36},"n":"TransactionStatePromotedPhase0","d":5743877,"h":270588683525,"f":36},{"p":8037637,"g":{"r":0,"d":0,"h":283473585413,"f":36},"n":"TransactionStatePromotedPhase1","d":5743877,"h":279178618117,"f":36},{"p":7775493,"g":{"r":0,"d":0,"h":292063520005,"f":36},"n":"TransactionStatePromotedP0Aborting","d":5743877,"h":287768552709,"f":36},{"p":7906565,"g":{"r":0,"d":0,"h":300653454597,"f":36},"n":"TransactionStatePromotedP1Aborting","d":5743877,"h":296358487301,"f":36},{"p":6792453,"g":{"r":0,"d":0,"h":309243389189,"f":36},"n":"TransactionStatePromotedAborted","d":5743877,"h":304948421893,"f":36},{"p":6989061,"g":{"r":0,"d":0,"h":317833323781,"f":36},"n":"TransactionStatePromotedCommitted","d":5743877,"h":313538356485,"f":36},{"p":7185669,"g":{"r":0,"d":0,"h":326423258373,"f":36},"n":"TransactionStatePromotedIndoubt","d":5743877,"h":322128291077,"f":36},{"p":6006021,"g":{"r":0,"d":0,"h":335013192965,"f":36},"n":"TransactionStateDelegated","d":5743877,"h":330718225669,"f":36},{"p":6399237,"g":{"r":0,"d":0,"h":343603127557,"f":40},"n":"TransactionStateDelegatedSubordinate","d":5743877,"h":339308160261,"f":40},{"p":6333701,"g":{"r":0,"d":0,"h":352193062149,"f":36},"n":"TransactionStateDelegatedP0Wave","d":5743877,"h":347898094853,"f":36},{"p":6202629,"g":{"r":0,"d":0,"h":360782996741,"f":36},"n":"TransactionStateDelegatedCommitting","d":5743877,"h":356488029445,"f":36},{"p":6071557,"g":{"r":0,"d":0,"h":369372931333,"f":36},"n":"TransactionStateDelegatedAborting","d":5743877,"h":365077964037,"f":36},{"p":6268165,"g":{"r":0,"d":0,"h":377962865925,"f":36},"n":"TransactionStateDelegatedNonMSDTC","d":5743877,"h":373667898629,"f":36},{"p":7578885,"g":{"r":0,"d":0,"h":386552800517,"f":36},"n":"TransactionStatePromotedNonMSDTCPhase0","d":5743877,"h":382257833221,"f":36},{"p":7709957,"g":{"r":0,"d":0,"h":395142735109,"f":36},"n":"TransactionStatePromotedNonMSDTCVolatilePhase1","d":5743877,"h":390847767813,"f":36},{"p":7644421,"g":{"r":0,"d":0,"h":403732669701,"f":36},"n":"TransactionStatePromotedNonMSDTCSinglePhaseCommit","d":5743877,"h":399437702405,"f":36},{"p":7251205,"g":{"r":0,"d":0,"h":412322604293,"f":36},"n":"TransactionStatePromotedNonMSDTCAborted","d":5743877,"h":408027636997,"f":36},{"p":7382277,"g":{"r":0,"d":0,"h":420912538885,"f":36},"n":"TransactionStatePromotedNonMSDTCCommitted","d":5743877,"h":416617571589,"f":36},{"p":7513349,"g":{"r":0,"d":0,"h":429502473477,"f":36},"n":"TransactionStatePromotedNonMSDTCIndoubt","d":5743877,"h":425207506181,"f":36}],"m":[{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"CommonEnterState","d":5743877,"h":433797440773,"f":8},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"EnterState","d":5743877,"h":438092408069,"f":264},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"asyncCommit","p":262145},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":5743877,"h":442387375365,"f":136},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"EndCommit","d":5743877,"h":446682342661,"f":136},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"e","p":47251457}],"n":"Rollback","d":5743877,"h":450977309957,"f":136},{"r":1746181,"p":[{"n":"tx","p":2794757},{"n":"resourceManagerIdentifier","p":56229889},{"n":"enlistmentNotification","p":2598149},{"n":"enlistmentOptions","p":1877253},{"n":"atomicTransaction","p":4302085}],"n":"EnlistDurable","d":5743877,"h":455272277253,"f":136},{"r":1746181,"p":[{"n":"tx","p":2794757},{"n":"resourceManagerIdentifier","p":56229889},{"n":"enlistmentNotification","p":3056901},{"n":"enlistmentOptions","p":1877253},{"n":"atomicTransaction","p":4302085}],"n":"EnlistDurable","o":"@$1","d":5743877,"h":459567244549,"f":136},{"r":1746181,"p":[{"n":"tx","p":2794757},{"n":"enlistmentNotification","p":2598149},{"n":"enlistmentOptions","p":1877253},{"n":"atomicTransaction","p":4302085}],"n":"EnlistVolatile","d":5743877,"h":463862211845,"f":136},{"r":1746181,"p":[{"n":"tx","p":2794757},{"n":"enlistmentNotification","p":3056901},{"n":"enlistmentOptions","p":1877253},{"n":"atomicTransaction","p":4302085}],"n":"EnlistVolatile","o":"@$1","d":5743877,"h":468157179141,"f":136},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"CheckForFinishedTransaction","d":5743877,"h":472452146437,"f":136},{"r":56229889,"p":[{"n":"tx","p":2794757}],"n":"get_Identifier","d":5743877,"h":476747113733,"f":136},{"r":8430853,"p":[{"n":"tx","p":2794757}],"n":"get_Status","d":5743877,"h":481042081029,"f":264},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"transactionCompletedDelegate","p":4433157}],"n":"AddOutcomeRegistrant","d":5743877,"h":485337048325,"f":136},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"serializationInfo","p":113967105},{"n":"context","p":114098177}],"n":"GetObjectData","d":5743877,"h":489632015621,"f":136},{"r":262145,"p":[{"n":"tx","p":2794757},{"n":"promotableSinglePhaseNotification","p":2860293},{"n":"atomicTransaction","p":4302085},{"n":"promoterType","p":56229889}],"n":"EnlistPromotableSinglePhase","d":5743877,"h":493926982917,"f":136},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"CompleteBlockingClone","d":5743877,"h":498221950213,"f":136},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"CompleteAbortingClone","d":5743877,"h":502516917509,"f":136},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"CreateBlockingClone","d":5743877,"h":506811884805,"f":136},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"CreateAbortingClone","d":5743877,"h":511106852101,"f":136},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"e","p":47251457}],"n":"ChangeStateTransactionAborted","d":5743877,"h":515401819397,"f":136},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"ChangeStateTransactionCommitted","d":5743877,"h":519696786693,"f":136},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"InDoubtFromEnlistment","d":5743877,"h":523991753989,"f":136},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"ChangeStatePromotedAborted","d":5743877,"h":528286721285,"f":136},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"ChangeStatePromotedCommitted","d":5743877,"h":532581688581,"f":136},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"InDoubtFromDtc","d":5743877,"h":536876655877,"f":136},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"ChangeStatePromotedPhase0","d":5743877,"h":541171623173,"f":136},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"ChangeStatePromotedPhase1","d":5743877,"h":545466590469,"f":136},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"ChangeStateAbortedDuringPromotion","d":5743877,"h":549761557765,"f":136},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"Timeout","d":5743877,"h":554056525061,"f":136},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"Phase0VolatilePrepareDone","d":5743877,"h":558351492357,"f":136},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"Phase1VolatilePrepareDone","d":5743877,"h":562646459653,"f":136},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"RestartCommitIfNeeded","d":5743877,"h":566941426949,"f":136},{"r":262145,"n":"ContinuePhase0Prepares","d":5743877,"h":571236394245,"f":136},{"r":262145,"n":"ContinuePhase1Prepares","d":5743877,"h":575531361541,"f":136},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"Promote","d":5743877,"h":579826328837,"f":136},{"r":0,"p":[{"n":"tx","p":2794757}],"n":"PromotedToken","d":5743877,"h":584121296133,"f":136},{"r":1746181,"p":[{"n":"tx","p":2794757},{"n":"resourceManagerIdentifier","p":56229889},{"n":"promotableNotification","p":2860293},{"n":"enlistmentNotification","p":3056901},{"n":"enlistmentOptions","p":1877253},{"n":"atomicTransaction","p":4302085}],"n":"PromoteAndEnlistDurable","d":5743877,"h":588416263429,"f":136},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"promotableNotification","p":2860293},{"n":"distributedTransactionIdentifier","p":56229889}],"n":"SetDistributedTransactionId","d":5743877,"h":592711230725,"f":136},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"DisposeRoot","d":5743877,"h":597006198021,"f":136},{"r":262145,"p":[{"n":"tx","p":2794757}],"n":"IsCompleted","d":5743877,"h":601301165317,"f":136},{"r":65537,"p":[{"n":"enlistments","p":9348357,"f":4},{"n":"enlistment","p":1746181}],"n":"AddVolatileEnlistment","d":5743877,"h":605596132613,"f":36}],"l":[{"t":5874949,"n":"s_transactionStateActive","d":5743877,"h":4300711173,"f":34},{"t":8234245,"n":"s_transactionStateSubordinateActive","d":5743877,"h":8595678469,"f":34},{"t":6661381,"n":"s_transactionStatePhase0","d":5743877,"h":12890645765,"f":34},{"t":8299781,"n":"s_transactionStateVolatilePhase1","d":5743877,"h":17185613061,"f":34},{"t":8365317,"n":"s_transactionStateVolatileSPC","d":5743877,"h":21480580357,"f":34},{"t":8168709,"n":"s_transactionStateSPC","d":5743877,"h":25775547653,"f":34},{"t":5809413,"n":"s_transactionStateAborted","d":5743877,"h":30070514949,"f":34},{"t":5940485,"n":"s_transactionStateCommitted","d":5743877,"h":34365482245,"f":34},{"t":6530309,"n":"s_transactionStateInDoubt","d":5743877,"h":38660449541,"f":34},{"t":6726917,"n":"s_transactionStatePromoted","d":5743877,"h":42955416837,"f":34},{"t":6595845,"n":"s_transactionStateNonCommittablePromoted","d":5743877,"h":47250384133,"f":34},{"t":7841029,"n":"s_transactionStatePromotedP0Wave","d":5743877,"h":51545351429,"f":34},{"t":7054597,"n":"s_transactionStatePromotedCommitting","d":5743877,"h":55840318725,"f":34},{"t":7972101,"n":"s_transactionStatePromotedPhase0","d":5743877,"h":60135286021,"f":34},{"t":8037637,"n":"s_transactionStatePromotedPhase1","d":5743877,"h":64430253317,"f":34},{"t":7775493,"n":"s_transactionStatePromotedP0Aborting","d":5743877,"h":68725220613,"f":34},{"t":7906565,"n":"s_transactionStatePromotedP1Aborting","d":5743877,"h":73020187909,"f":34},{"t":6792453,"n":"s_transactionStatePromotedAborted","d":5743877,"h":77315155205,"f":34},{"t":6989061,"n":"s_transactionStatePromotedCommitted","d":5743877,"h":81610122501,"f":34},{"t":7185669,"n":"s_transactionStatePromotedIndoubt","d":5743877,"h":85905089797,"f":34},{"t":6006021,"n":"s_transactionStateDelegated","d":5743877,"h":90200057093,"f":34},{"t":6399237,"n":"s_transactionStateDelegatedSubordinate","d":5743877,"h":94495024389,"f":34},{"t":6333701,"n":"s_transactionStateDelegatedP0Wave","d":5743877,"h":98789991685,"f":34},{"t":6202629,"n":"s_transactionStateDelegatedCommitting","d":5743877,"h":103084958981,"f":34},{"t":6071557,"n":"s_transactionStateDelegatedAborting","d":5743877,"h":107379926277,"f":34},{"t":8103173,"n":"s_transactionStatePSPEOperation","d":5743877,"h":111674893573,"f":34},{"t":6268165,"n":"s_transactionStateDelegatedNonMSDTC","d":5743877,"h":115969860869,"f":34},{"t":7578885,"n":"s_transactionStatePromotedNonMSDTCPhase0","d":5743877,"h":120264828165,"f":34},{"t":7709957,"n":"s_transactionStatePromotedNonMSDTCVolatilePhase1","d":5743877,"h":124559795461,"f":34},{"t":7644421,"n":"s_transactionStatePromotedNonMSDTCSinglePhaseCommit","d":5743877,"h":128854762757,"f":34},{"t":7251205,"n":"s_transactionStatePromotedNonMSDTCAborted","d":5743877,"h":133149730053,"f":34},{"t":7382277,"n":"s_transactionStatePromotedNonMSDTCCommitted","d":5743877,"h":137444697349,"f":34},{"t":7513349,"n":"s_transactionStatePromotedNonMSDTCIndoubt","d":5743877,"h":141739664645,"f":34},{"t":131073,"n":"s_classSyncObject","d":5743877,"h":146034631941,"f":40}],"c":[{"n":".ctor","o":"$ctor$1","d":5743877,"h":609891099909,"f":4}],"h":5743877}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Transactions.TransactionState`; }
        });
        
        $asm.$cls("$stl.System.Transactions.VolatileDemultiplexer", ($self) => class VolatileDemultiplexer extends $.$spc.System.Object
        {
            /*InternalTransaction*/ _transaction = null;
            /*IPromotedEnlistment?*/ _promotedEnlistment = null;
            /*IPromotedEnlistment?*/ _preparingEnlistment = null;
            $ctor$1(/*InternalTransaction*/ transaction)
            {
                super.$ctor();
                {
                    this._transaction = transaction;
                }
                return this;
            }
            static /*void */ BroadcastCommitted(/*ref VolatileEnlistmentSet*/ volatiles)
            {
                for(/*int*/ let i = 0; i < volatiles.$v._volatileEnlistmentCount; i++)
                {
                    $.$spc.System.Array.$ReadT1.call(volatiles.$v._volatileEnlistments, i)._twoPhaseState.InternalCommitted($.$spc.System.Array.$ReadT1.call(volatiles.$v._volatileEnlistments, i));
                }
            }
            static /*void */ BroadcastRollback(/*ref VolatileEnlistmentSet*/ volatiles)
            {
                for(/*int*/ let i = 0; i < volatiles.$v._volatileEnlistmentCount; i++)
                {
                    $.$spc.System.Array.$ReadT1.call(volatiles.$v._volatileEnlistments, i)._twoPhaseState.InternalAborted($.$spc.System.Array.$ReadT1.call(volatiles.$v._volatileEnlistments, i));
                }
            }
            static /*void */ BroadcastInDoubt(/*ref VolatileEnlistmentSet*/ volatiles)
            {
                for(/*int*/ let i = 0; i < volatiles.$v._volatileEnlistmentCount; i++)
                {
                    $.$spc.System.Array.$ReadT1.call(volatiles.$v._volatileEnlistments, i)._twoPhaseState.InternalIndoubt($.$spc.System.Array.$ReadT1.call(volatiles.$v._volatileEnlistments, i));
                }
            }
            /*object?*/ static s_classSyncObject = null;
            static /*object */ get ClassSyncObject()
            {
                if ($.$stl.System.Transactions.VolatileDemultiplexer.s_classSyncObject === null)
                {
                    /*object*/ let o = new $.$spc.System.Object().$ctor();
                    $.$spc.System.Threading.Interlocked.CompareExchange$2($.$ref(() => $.$stl.System.Transactions.VolatileDemultiplexer.s_classSyncObject, ($v) => $.$stl.System.Transactions.VolatileDemultiplexer.s_classSyncObject = $v, $.$spc.System.Object), o, null);
                }
                return $.$stl.System.Transactions.VolatileDemultiplexer.s_classSyncObject;
            }
            /*WaitCallback?*/ static s_prepareCallback = null;
            static /*WaitCallback */ get PrepareCallback()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$spc.System.Threading.WaitCallback, $.$ref(() => $.$stl.System.Transactions.VolatileDemultiplexer.s_prepareCallback, ($v) => $.$stl.System.Transactions.VolatileDemultiplexer.s_prepareCallback = $v, $.$spc.System.Threading.WaitCallback), $.$ref(() => $.$stl.System.Transactions.VolatileDemultiplexer.s_classSyncObject, ($v) => $.$stl.System.Transactions.VolatileDemultiplexer.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$spc.System.Threading.WaitCallback))().$ctor(this,  () =>
                {
                    return new $.$spc.System.Threading.WaitCallback().$ctor($.$stl.System.Transactions.VolatileDemultiplexer, $.$stl.System.Transactions.VolatileDemultiplexer.PoolablePrepare);
                }, {"r":139067393,"n":"","d":8692997,"h":0,"f":1048578}));
            }
            static /*void */ PoolablePrepare(/*object*/ state)
            {
                /*VolatileDemultiplexer*/ let demux = $.$cast(state, $.$stl.System.Transactions.VolatileDemultiplexer);
                /*bool*/ let tookLock = false;
                try
                {
                    $.$spc.System.Threading.Monitor.TryEnter$3(demux._transaction, 250, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Boolean, () => tookLock, ($v) => tookLock = $v, null));
                    if (tookLock)
                    {
                        demux.InternalPrepare();
                    }
                    else 
                    {
                        if (!$.$spc.System.Threading.ThreadPool.QueueUserWorkItem$1($.$stl.System.Transactions.VolatileDemultiplexer.PrepareCallback, demux))
                        {
                            throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.UnexpectedFailureOfThreadPool, null);
                        }
                    }
                }
                finally
                {
                    {
                        if (tookLock)
                        {
                            $.$spc.System.Threading.Monitor.Exit(demux._transaction);
                        }
                    }
                }
            }
            /*WaitCallback?*/ static s_commitCallback = null;
            static /*WaitCallback */ get CommitCallback()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$spc.System.Threading.WaitCallback, $.$ref(() => $.$stl.System.Transactions.VolatileDemultiplexer.s_commitCallback, ($v) => $.$stl.System.Transactions.VolatileDemultiplexer.s_commitCallback = $v, $.$spc.System.Threading.WaitCallback), $.$ref(() => $.$stl.System.Transactions.VolatileDemultiplexer.s_classSyncObject, ($v) => $.$stl.System.Transactions.VolatileDemultiplexer.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$spc.System.Threading.WaitCallback))().$ctor(this,  () =>
                {
                    return new $.$spc.System.Threading.WaitCallback().$ctor($.$stl.System.Transactions.VolatileDemultiplexer, $.$stl.System.Transactions.VolatileDemultiplexer.PoolableCommit);
                }, {"r":139067393,"n":"","d":8692997,"h":0,"f":1048578}));
            }
            static /*void */ PoolableCommit(/*object*/ state)
            {
                /*VolatileDemultiplexer*/ let demux = $.$cast(state, $.$stl.System.Transactions.VolatileDemultiplexer);
                /*bool*/ let tookLock = false;
                try
                {
                    $.$spc.System.Threading.Monitor.TryEnter$3(demux._transaction, 250, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Boolean, () => tookLock, ($v) => tookLock = $v, null));
                    if (tookLock)
                    {
                        demux.InternalCommit();
                    }
                    else 
                    {
                        if (!$.$spc.System.Threading.ThreadPool.QueueUserWorkItem$1($.$stl.System.Transactions.VolatileDemultiplexer.CommitCallback, demux))
                        {
                            throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.UnexpectedFailureOfThreadPool, null);
                        }
                    }
                }
                finally
                {
                    {
                        if (tookLock)
                        {
                            $.$spc.System.Threading.Monitor.Exit(demux._transaction);
                        }
                    }
                }
            }
            /*WaitCallback?*/ static s_rollbackCallback = null;
            static /*WaitCallback */ get RollbackCallback()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$spc.System.Threading.WaitCallback, $.$ref(() => $.$stl.System.Transactions.VolatileDemultiplexer.s_rollbackCallback, ($v) => $.$stl.System.Transactions.VolatileDemultiplexer.s_rollbackCallback = $v, $.$spc.System.Threading.WaitCallback), $.$ref(() => $.$stl.System.Transactions.VolatileDemultiplexer.s_classSyncObject, ($v) => $.$stl.System.Transactions.VolatileDemultiplexer.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$spc.System.Threading.WaitCallback))().$ctor(this,  () =>
                {
                    return new $.$spc.System.Threading.WaitCallback().$ctor($.$stl.System.Transactions.VolatileDemultiplexer, $.$stl.System.Transactions.VolatileDemultiplexer.PoolableRollback);
                }, {"r":139067393,"n":"","d":8692997,"h":0,"f":1048578}));
            }
            static /*void */ PoolableRollback(/*object*/ state)
            {
                /*VolatileDemultiplexer*/ let demux = $.$cast(state, $.$stl.System.Transactions.VolatileDemultiplexer);
                /*bool*/ let tookLock = false;
                try
                {
                    $.$spc.System.Threading.Monitor.TryEnter$3(demux._transaction, 250, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Boolean, () => tookLock, ($v) => tookLock = $v, null));
                    if (tookLock)
                    {
                        demux.InternalRollback();
                    }
                    else 
                    {
                        if (!$.$spc.System.Threading.ThreadPool.QueueUserWorkItem$1($.$stl.System.Transactions.VolatileDemultiplexer.RollbackCallback, demux))
                        {
                            throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.UnexpectedFailureOfThreadPool, null);
                        }
                    }
                }
                finally
                {
                    {
                        if (tookLock)
                        {
                            $.$spc.System.Threading.Monitor.Exit(demux._transaction);
                        }
                    }
                }
            }
            /*WaitCallback?*/ static s_inDoubtCallback = null;
            static /*WaitCallback */ get InDoubtCallback()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$spc.System.Threading.WaitCallback, $.$ref(() => $.$stl.System.Transactions.VolatileDemultiplexer.s_inDoubtCallback, ($v) => $.$stl.System.Transactions.VolatileDemultiplexer.s_inDoubtCallback = $v, $.$spc.System.Threading.WaitCallback), $.$ref(() => $.$stl.System.Transactions.VolatileDemultiplexer.s_classSyncObject, ($v) => $.$stl.System.Transactions.VolatileDemultiplexer.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$spc.System.Threading.WaitCallback))().$ctor(this,  () =>
                {
                    return new $.$spc.System.Threading.WaitCallback().$ctor($.$stl.System.Transactions.VolatileDemultiplexer, $.$stl.System.Transactions.VolatileDemultiplexer.PoolableInDoubt);
                }, {"r":139067393,"n":"","d":8692997,"h":0,"f":1048578}));
            }
            static /*void */ PoolableInDoubt(/*object*/ state)
            {
                /*VolatileDemultiplexer*/ let demux = $.$cast(state, $.$stl.System.Transactions.VolatileDemultiplexer);
                /*bool*/ let tookLock = false;
                try
                {
                    $.$spc.System.Threading.Monitor.TryEnter$3(demux._transaction, 250, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Boolean, () => tookLock, ($v) => tookLock = $v, null));
                    if (tookLock)
                    {
                        demux.InternalInDoubt();
                    }
                    else 
                    {
                        if (!$.$spc.System.Threading.ThreadPool.QueueUserWorkItem$1($.$stl.System.Transactions.VolatileDemultiplexer.InDoubtCallback, demux))
                        {
                            throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.UnexpectedFailureOfThreadPool, null);
                        }
                    }
                }
                finally
                {
                    {
                        if (tookLock)
                        {
                            $.$spc.System.Threading.Monitor.Exit(demux._transaction);
                        }
                    }
                }
            }
            //Generated interface implemetation for System.Transactions.IEnlistmentNotificationInternal.Prepare(System.Transactions.IPromotedEnlistment)
            System$Transactions$IEnlistmentNotificationInternal$Prepare()
            {
                return this.Prepare(...arguments);
            }
            //Generated interface implemetation for System.Transactions.IEnlistmentNotificationInternal.Commit(System.Transactions.IPromotedEnlistment)
            System$Transactions$IEnlistmentNotificationInternal$Commit()
            {
                return this.Commit(...arguments);
            }
            //Generated interface implemetation for System.Transactions.IEnlistmentNotificationInternal.Rollback(System.Transactions.IPromotedEnlistment)
            System$Transactions$IEnlistmentNotificationInternal$Rollback()
            {
                return this.Rollback(...arguments);
            }
            //Generated interface implemetation for System.Transactions.IEnlistmentNotificationInternal.InDoubt(System.Transactions.IPromotedEnlistment)
            System$Transactions$IEnlistmentNotificationInternal$InDoubt()
            {
                return this.InDoubt(...arguments);
            }
            static $h = 8692997;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":131073,"g":{"r":0,"d":0,"h":42958365957,"f":40},"n":"ClassSyncObject","d":8692997,"h":38663398661,"f":40},{"p":139067393,"g":{"r":0,"d":0,"h":55843267845,"f":34},"n":"PrepareCallback","d":8692997,"h":51548300549,"f":34},{"p":139067393,"g":{"r":0,"d":0,"h":73023137029,"f":34},"n":"CommitCallback","d":8692997,"h":68728169733,"f":34},{"p":139067393,"g":{"r":0,"d":0,"h":90203006213,"f":34},"n":"RollbackCallback","d":8692997,"h":85908038917,"f":34},{"p":139067393,"g":{"r":0,"d":0,"h":107382875397,"f":34},"n":"InDoubtCallback","d":8692997,"h":103087908101,"f":34}],"m":[{"r":65537,"p":[{"n":"volatiles","p":9348357,"f":4}],"n":"BroadcastCommitted","d":8692997,"h":21483529477,"f":40},{"r":65537,"p":[{"n":"volatiles","p":9348357,"f":4}],"n":"BroadcastRollback","d":8692997,"h":25778496773,"f":40},{"r":65537,"p":[{"n":"volatiles","p":9348357,"f":4}],"n":"BroadcastInDoubt","d":8692997,"h":30073464069,"f":40},{"r":65537,"p":[{"n":"state","p":131073}],"n":"PoolablePrepare","d":8692997,"h":60138235141,"f":36},{"r":65537,"p":[{"n":"state","p":131073}],"n":"PoolableCommit","d":8692997,"h":77318104325,"f":36},{"r":65537,"p":[{"n":"state","p":131073}],"n":"PoolableRollback","d":8692997,"h":94497973509,"f":36},{"r":65537,"p":[{"n":"state","p":131073}],"n":"PoolableInDoubt","d":8692997,"h":111677842693,"f":36},{"r":65537,"n":"InternalPrepare","d":8692997,"h":115972809989,"f":260},{"r":65537,"n":"InternalCommit","d":8692997,"h":120267777285,"f":260},{"r":65537,"n":"InternalRollback","d":8692997,"h":124562744581,"f":260},{"r":65537,"n":"InternalInDoubt","d":8692997,"h":128857711877,"f":260},{"r":65537,"p":[{"n":"en","p":2925829}],"n":"Prepare","d":8692997,"h":133152679173,"f":257},{"r":65537,"p":[{"n":"en","p":2925829}],"n":"Commit","d":8692997,"h":137447646469,"f":257},{"r":65537,"p":[{"n":"en","p":2925829}],"n":"Rollback","d":8692997,"h":141742613765,"f":257},{"r":65537,"p":[{"n":"en","p":2925829}],"n":"InDoubt","d":8692997,"h":146037581061,"f":257}],"l":[{"t":2794757,"n":"_transaction","d":8692997,"h":4303660293,"f":4},{"t":2925829,"n":"_promotedEnlistment","d":8692997,"h":8598627589,"f":8},{"t":2925829,"n":"_preparingEnlistment","d":8692997,"h":12893594885,"f":8},{"t":131073,"n":"s_classSyncObject","d":8692997,"h":34368431365,"f":34},{"t":139067393,"n":"s_prepareCallback","d":8692997,"h":47253333253,"f":34},{"t":139067393,"n":"s_commitCallback","d":8692997,"h":64433202437,"f":34},{"t":139067393,"n":"s_rollbackCallback","d":8692997,"h":81613071621,"f":34},{"t":139067393,"n":"s_inDoubtCallback","d":8692997,"h":98792940805,"f":34}],"c":[{"p":[{"n":"transaction","p":2794757}],"n":".ctor","o":"$ctor$1","d":8692997,"h":17188562181,"f":1}],"i":[2663685],"h":8692997}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stl.System.Transactions.IEnlistmentNotificationInternal ]; }
            static get $fullName() { return `System.Transactions.VolatileDemultiplexer`; }
        });
        
        $asm.$cls("$stl.System.Transactions.DurableEnlistmentState", ($self) => class DurableEnlistmentState extends $.$stl.System.Transactions.EnlistmentState
        {
            /*DurableEnlistmentActive?*/ static s_durableEnlistmentActive = null;
            /*DurableEnlistmentAborting?*/ static s_durableEnlistmentAborting = null;
            /*DurableEnlistmentCommitting?*/ static s_durableEnlistmentCommitting = null;
            /*DurableEnlistmentDelegated?*/ static s_durableEnlistmentDelegated = null;
            /*DurableEnlistmentEnded?*/ static s_durableEnlistmentEnded = null;
            /*object?*/ static s_classSyncObject = null;
            static /*DurableEnlistmentActive */ get DurableEnlistmentActive()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.DurableEnlistmentActive, $.$ref(() => $.$stl.System.Transactions.DurableEnlistmentState.s_durableEnlistmentActive, ($v) => $.$stl.System.Transactions.DurableEnlistmentState.s_durableEnlistmentActive = $v, $.$stl.System.Transactions.DurableEnlistmentActive), $.$ref(() => $.$stl.System.Transactions.DurableEnlistmentState.s_classSyncObject, ($v) => $.$stl.System.Transactions.DurableEnlistmentState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.DurableEnlistmentActive))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.DurableEnlistmentActive().$ctor$3();
                }, {"r":1287429,"n":"","d":1549573,"h":0,"f":1048578}));
            }
            static /*DurableEnlistmentAborting */ get DurableEnlistmentAborting()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.DurableEnlistmentAborting, $.$ref(() => $.$stl.System.Transactions.DurableEnlistmentState.s_durableEnlistmentAborting, ($v) => $.$stl.System.Transactions.DurableEnlistmentState.s_durableEnlistmentAborting = $v, $.$stl.System.Transactions.DurableEnlistmentAborting), $.$ref(() => $.$stl.System.Transactions.DurableEnlistmentState.s_classSyncObject, ($v) => $.$stl.System.Transactions.DurableEnlistmentState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.DurableEnlistmentAborting))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.DurableEnlistmentAborting().$ctor$3();
                }, {"r":1221893,"n":"","d":1549573,"h":0,"f":1048578}));
            }
            static /*DurableEnlistmentCommitting */ get DurableEnlistmentCommitting()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.DurableEnlistmentCommitting, $.$ref(() => $.$stl.System.Transactions.DurableEnlistmentState.s_durableEnlistmentCommitting, ($v) => $.$stl.System.Transactions.DurableEnlistmentState.s_durableEnlistmentCommitting = $v, $.$stl.System.Transactions.DurableEnlistmentCommitting), $.$ref(() => $.$stl.System.Transactions.DurableEnlistmentState.s_classSyncObject, ($v) => $.$stl.System.Transactions.DurableEnlistmentState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.DurableEnlistmentCommitting))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.DurableEnlistmentCommitting().$ctor$3();
                }, {"r":1352965,"n":"","d":1549573,"h":0,"f":1048578}));
            }
            static /*DurableEnlistmentDelegated */ get DurableEnlistmentDelegated()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.DurableEnlistmentDelegated, $.$ref(() => $.$stl.System.Transactions.DurableEnlistmentState.s_durableEnlistmentDelegated, ($v) => $.$stl.System.Transactions.DurableEnlistmentState.s_durableEnlistmentDelegated = $v, $.$stl.System.Transactions.DurableEnlistmentDelegated), $.$ref(() => $.$stl.System.Transactions.DurableEnlistmentState.s_classSyncObject, ($v) => $.$stl.System.Transactions.DurableEnlistmentState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.DurableEnlistmentDelegated))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.DurableEnlistmentDelegated().$ctor$3();
                }, {"r":1418501,"n":"","d":1549573,"h":0,"f":1048578}));
            }
            static /*DurableEnlistmentEnded */ get DurableEnlistmentEnded()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.DurableEnlistmentEnded, $.$ref(() => $.$stl.System.Transactions.DurableEnlistmentState.s_durableEnlistmentEnded, ($v) => $.$stl.System.Transactions.DurableEnlistmentState.s_durableEnlistmentEnded = $v, $.$stl.System.Transactions.DurableEnlistmentEnded), $.$ref(() => $.$stl.System.Transactions.DurableEnlistmentState.s_classSyncObject, ($v) => $.$stl.System.Transactions.DurableEnlistmentState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.DurableEnlistmentEnded))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.DurableEnlistmentEnded().$ctor$3();
                }, {"r":1484037,"n":"","d":1549573,"h":0,"f":1048578}));
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 1549573;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1942789,"p":[{"p":1287429,"g":{"r":0,"d":0,"h":34361287941,"f":40},"n":"DurableEnlistmentActive","d":1549573,"h":30066320645,"f":40},{"p":1221893,"g":{"r":0,"d":0,"h":42951222533,"f":36},"n":"DurableEnlistmentAborting","d":1549573,"h":38656255237,"f":36},{"p":1352965,"g":{"r":0,"d":0,"h":51541157125,"f":36},"n":"DurableEnlistmentCommitting","d":1549573,"h":47246189829,"f":36},{"p":1418501,"g":{"r":0,"d":0,"h":60131091717,"f":36},"n":"DurableEnlistmentDelegated","d":1549573,"h":55836124421,"f":36},{"p":1484037,"g":{"r":0,"d":0,"h":68721026309,"f":36},"n":"DurableEnlistmentEnded","d":1549573,"h":64426059013,"f":36}],"l":[{"t":1287429,"n":"s_durableEnlistmentActive","d":1549573,"h":4296516869,"f":34},{"t":1221893,"n":"s_durableEnlistmentAborting","d":1549573,"h":8591484165,"f":34},{"t":1352965,"n":"s_durableEnlistmentCommitting","d":1549573,"h":12886451461,"f":34},{"t":1418501,"n":"s_durableEnlistmentDelegated","d":1549573,"h":17181418757,"f":34},{"t":1484037,"n":"s_durableEnlistmentEnded","d":1549573,"h":21476386053,"f":34},{"t":131073,"n":"s_classSyncObject","d":1549573,"h":25771353349,"f":34}],"c":[{"n":".ctor","o":"$ctor$2","d":1549573,"h":73015993605,"f":4}],"h":1549573}; }
            static get $b() { return $.$stl.System.Transactions.EnlistmentState; }
            static get $fullName() { return `System.Transactions.DurableEnlistmentState`; }
        });
        
        $asm.$cls("$stl.System.Transactions.VolatileEnlistmentState", ($self) => class VolatileEnlistmentState extends $.$stl.System.Transactions.EnlistmentState
        {
            /*VolatileEnlistmentActive?*/ static s_volatileEnlistmentActive = null;
            /*VolatileEnlistmentPreparing?*/ static s_volatileEnlistmentPreparing = null;
            /*VolatileEnlistmentPrepared?*/ static s_volatileEnlistmentPrepared = null;
            /*VolatileEnlistmentSPC?*/ static s_volatileEnlistmentSPC = null;
            /*VolatileEnlistmentPreparingAborting?*/ static s_volatileEnlistmentPreparingAborting = null;
            /*VolatileEnlistmentAborting?*/ static s_volatileEnlistmentAborting = null;
            /*VolatileEnlistmentCommitting?*/ static s_volatileEnlistmentCommitting = null;
            /*VolatileEnlistmentInDoubt?*/ static s_volatileEnlistmentInDoubt = null;
            /*VolatileEnlistmentEnded?*/ static s_volatileEnlistmentEnded = null;
            /*VolatileEnlistmentDone?*/ static s_volatileEnlistmentDone = null;
            /*object?*/ static s_classSyncObject = null;
            static /*VolatileEnlistmentActive */ get VolatileEnlistmentActive()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.VolatileEnlistmentActive, $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentActive, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentActive = $v, $.$stl.System.Transactions.VolatileEnlistmentActive), $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.VolatileEnlistmentActive))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.VolatileEnlistmentActive().$ctor$3();
                }, {"r":8824069,"n":"","d":9479429,"h":0,"f":1048578}));
            }
            static /*VolatileEnlistmentPreparing */ get VolatileEnlistmentPreparing()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.VolatileEnlistmentPreparing, $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentPreparing, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentPreparing = $v, $.$stl.System.Transactions.VolatileEnlistmentPreparing), $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.VolatileEnlistmentPreparing))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.VolatileEnlistmentPreparing().$ctor$3();
                }, {"r":9217285,"n":"","d":9479429,"h":0,"f":1048578}));
            }
            static /*VolatileEnlistmentPrepared */ get VolatileEnlistmentPrepared()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.VolatileEnlistmentPrepared, $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentPrepared, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentPrepared = $v, $.$stl.System.Transactions.VolatileEnlistmentPrepared), $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.VolatileEnlistmentPrepared))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.VolatileEnlistmentPrepared().$ctor$3();
                }, {"r":9151749,"n":"","d":9479429,"h":0,"f":1048578}));
            }
            static /*VolatileEnlistmentSPC */ get VolatileEnlistmentSPC()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.VolatileEnlistmentSPC, $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentSPC, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentSPC = $v, $.$stl.System.Transactions.VolatileEnlistmentSPC), $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.VolatileEnlistmentSPC))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.VolatileEnlistmentSPC().$ctor$3();
                }, {"r":9413893,"n":"","d":9479429,"h":0,"f":1048578}));
            }
            static /*VolatileEnlistmentPreparingAborting */ get VolatileEnlistmentPreparingAborting()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.VolatileEnlistmentPreparingAborting, $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentPreparingAborting, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentPreparingAborting = $v, $.$stl.System.Transactions.VolatileEnlistmentPreparingAborting), $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.VolatileEnlistmentPreparingAborting))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.VolatileEnlistmentPreparingAborting().$ctor$3();
                }, {"r":9282821,"n":"","d":9479429,"h":0,"f":1048578}));
            }
            static /*VolatileEnlistmentAborting */ get VolatileEnlistmentAborting()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.VolatileEnlistmentAborting, $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentAborting, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentAborting = $v, $.$stl.System.Transactions.VolatileEnlistmentAborting), $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.VolatileEnlistmentAborting))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.VolatileEnlistmentAborting().$ctor$3();
                }, {"r":8758533,"n":"","d":9479429,"h":0,"f":1048578}));
            }
            static /*VolatileEnlistmentCommitting */ get VolatileEnlistmentCommitting()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.VolatileEnlistmentCommitting, $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentCommitting, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentCommitting = $v, $.$stl.System.Transactions.VolatileEnlistmentCommitting), $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.VolatileEnlistmentCommitting))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.VolatileEnlistmentCommitting().$ctor$3();
                }, {"r":8889605,"n":"","d":9479429,"h":0,"f":1048578}));
            }
            static /*VolatileEnlistmentInDoubt */ get VolatileEnlistmentInDoubt()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.VolatileEnlistmentInDoubt, $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentInDoubt, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentInDoubt = $v, $.$stl.System.Transactions.VolatileEnlistmentInDoubt), $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.VolatileEnlistmentInDoubt))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.VolatileEnlistmentInDoubt().$ctor$3();
                }, {"r":9086213,"n":"","d":9479429,"h":0,"f":1048578}));
            }
            static /*VolatileEnlistmentEnded */ get VolatileEnlistmentEnded()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.VolatileEnlistmentEnded, $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentEnded, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentEnded = $v, $.$stl.System.Transactions.VolatileEnlistmentEnded), $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.VolatileEnlistmentEnded))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.VolatileEnlistmentEnded().$ctor$3();
                }, {"r":9020677,"n":"","d":9479429,"h":0,"f":1048578}));
            }
            static /*VolatileEnlistmentDone */ get VolatileEnlistmentDone()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.VolatileEnlistmentDone, $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentDone, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentDone = $v, $.$stl.System.Transactions.VolatileEnlistmentDone), $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.VolatileEnlistmentDone))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.VolatileEnlistmentDone().$ctor$4();
                }, {"r":8955141,"n":"","d":9479429,"h":0,"f":1048578}));
            }
            /*byte[] */ RecoveryInformation(/*InternalEnlistment*/ enlistment)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException$1(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.VolEnlistNoRecoveryInfo, null, enlistment === null ? $.$spc.System.Guid.Empty : enlistment.DistributedTxId);
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 9479429;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1942789,"p":[{"p":8824069,"g":{"r":0,"d":0,"h":55844054277,"f":40},"n":"VolatileEnlistmentActive","d":9479429,"h":51549086981,"f":40},{"p":9217285,"g":{"r":0,"d":0,"h":64433988869,"f":36},"n":"VolatileEnlistmentPreparing","d":9479429,"h":60139021573,"f":36},{"p":9151749,"g":{"r":0,"d":0,"h":73023923461,"f":36},"n":"VolatileEnlistmentPrepared","d":9479429,"h":68728956165,"f":36},{"p":9413893,"g":{"r":0,"d":0,"h":81613858053,"f":36},"n":"VolatileEnlistmentSPC","d":9479429,"h":77318890757,"f":36},{"p":9282821,"g":{"r":0,"d":0,"h":90203792645,"f":36},"n":"VolatileEnlistmentPreparingAborting","d":9479429,"h":85908825349,"f":36},{"p":8758533,"g":{"r":0,"d":0,"h":98793727237,"f":36},"n":"VolatileEnlistmentAborting","d":9479429,"h":94498759941,"f":36},{"p":8889605,"g":{"r":0,"d":0,"h":107383661829,"f":36},"n":"VolatileEnlistmentCommitting","d":9479429,"h":103088694533,"f":36},{"p":9086213,"g":{"r":0,"d":0,"h":115973596421,"f":36},"n":"VolatileEnlistmentInDoubt","d":9479429,"h":111678629125,"f":36},{"p":9020677,"g":{"r":0,"d":0,"h":124563531013,"f":36},"n":"VolatileEnlistmentEnded","d":9479429,"h":120268563717,"f":36},{"p":8955141,"g":{"r":0,"d":0,"h":133153465605,"f":36},"n":"VolatileEnlistmentDone","d":9479429,"h":128858498309,"f":36}],"m":[{"r":0,"p":[{"n":"enlistment","p":2729221}],"n":"RecoveryInformation","d":9479429,"h":137448432901,"f":32776}],"l":[{"t":8824069,"n":"s_volatileEnlistmentActive","d":9479429,"h":4304446725,"f":34},{"t":9217285,"n":"s_volatileEnlistmentPreparing","d":9479429,"h":8599414021,"f":34},{"t":9151749,"n":"s_volatileEnlistmentPrepared","d":9479429,"h":12894381317,"f":34},{"t":9413893,"n":"s_volatileEnlistmentSPC","d":9479429,"h":17189348613,"f":34},{"t":9282821,"n":"s_volatileEnlistmentPreparingAborting","d":9479429,"h":21484315909,"f":34},{"t":8758533,"n":"s_volatileEnlistmentAborting","d":9479429,"h":25779283205,"f":34},{"t":8889605,"n":"s_volatileEnlistmentCommitting","d":9479429,"h":30074250501,"f":34},{"t":9086213,"n":"s_volatileEnlistmentInDoubt","d":9479429,"h":34369217797,"f":34},{"t":9020677,"n":"s_volatileEnlistmentEnded","d":9479429,"h":38664185093,"f":34},{"t":8955141,"n":"s_volatileEnlistmentDone","d":9479429,"h":42959152389,"f":34},{"t":131073,"n":"s_classSyncObject","d":9479429,"h":47254119685,"f":34}],"c":[{"n":".ctor","o":"$ctor$2","d":9479429,"h":141743400197,"f":4}],"h":9479429}; }
            static get $b() { return $.$stl.System.Transactions.EnlistmentState; }
            static get $fullName() { return `System.Transactions.VolatileEnlistmentState`; }
        });
        
        $asm.$cls("$stl.System.Transactions.ActiveStates", ($self) => class ActiveStates extends $.$stl.System.Transactions.TransactionState
        {
            /*TransactionStatus */ get_Status(/*InternalTransaction*/ tx)
            {
                return 0/*TransactionStatus.Active*/;
            }
            /*void */ AddOutcomeRegistrant(/*InternalTransaction*/ tx, /*TransactionCompletedEventHandler?*/ transactionCompletedDelegate)
            {
                tx._transactionCompletedDelegate = $.$cast($.$spc.System.Delegate.Combine(tx._transactionCompletedDelegate, transactionCompletedDelegate), $.$stl.System.Transactions.TransactionCompletedEventHandler);
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 238853;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":5743877,"m":[{"r":8430853,"p":[{"n":"tx","p":2794757}],"n":"get_Status","d":238853,"h":4295206149,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"transactionCompletedDelegate","p":4433157}],"n":"AddOutcomeRegistrant","d":238853,"h":8590173445,"f":32776}],"c":[{"n":".ctor","o":"$ctor$2","d":238853,"h":12885140741,"f":4}],"h":238853}; }
            static get $b() { return $.$stl.System.Transactions.TransactionState; }
            static get $fullName() { return `System.Transactions.ActiveStates`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateEnded", ($self) => class TransactionStateEnded extends $.$stl.System.Transactions.TransactionState
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                if (tx._needPulse)
                {
                    $.$spc.System.Threading.Monitor.Pulse(tx);
                }
            }
            /*void */ AddOutcomeRegistrant(/*InternalTransaction*/ tx, /*TransactionCompletedEventHandler?*/ transactionCompletedDelegate)
            {
                if (transactionCompletedDelegate !== null)
                {
                    /*TransactionEventArgs*/ let args = new $.$stl.System.Transactions.TransactionEventArgs().$ctor$2();
                    args._transaction = tx._outcomeSource.InternalClone();
                    transactionCompletedDelegate.Invoke(args._transaction, args);
                }
            }
            /*bool */ IsCompleted(/*InternalTransaction*/ tx)
            {
                return true;
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 6464773;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":5743877,"m":[{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"EnterState","d":6464773,"h":4301432069,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"transactionCompletedDelegate","p":4433157}],"n":"AddOutcomeRegistrant","d":6464773,"h":8596399365,"f":32776},{"r":262145,"p":[{"n":"tx","p":2794757}],"n":"IsCompleted","d":6464773,"h":12891366661,"f":32776}],"c":[{"n":".ctor","o":"$ctor$2","d":6464773,"h":17186333957,"f":4}],"h":6464773}; }
            static get $b() { return $.$stl.System.Transactions.TransactionState; }
            static get $fullName() { return `System.Transactions.TransactionStateEnded`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedBase", ($self) => class TransactionStatePromotedBase extends $.$stl.System.Transactions.TransactionState
        {
            /*TransactionStatus */ get_Status(/*InternalTransaction*/ tx)
            {
                return 0/*TransactionStatus.Active*/;
            }
            /*Enlistment */ EnlistVolatile(/*InternalTransaction*/ tx, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(tx.PromotedTransaction !== null, "Promoted state not valid for transaction.");
                $.$spc.System.Threading.Monitor.Exit(tx);
                try
                {
                    /*Enlistment*/ let en = new $.$stl.System.Transactions.Enlistment().$ctor$5(enlistmentNotification, tx, atomicTransaction);
                    $.$stl.System.Transactions.EnlistmentState.EnlistmentStatePromoted.EnterState(en.InternalEnlistment);
                    en.InternalEnlistment.PromotedEnlistment = tx.PromotedTransaction.EnlistVolatile(en.InternalEnlistment, enlistmentOptions);
                    return en;
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(tx);
                    }
                }
            }
            /*Enlistment */ EnlistVolatile$1(/*InternalTransaction*/ tx, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(tx.PromotedTransaction !== null, "Promoted state not valid for transaction.");
                $.$spc.System.Threading.Monitor.Exit(tx);
                try
                {
                    /*Enlistment*/ let en = new $.$stl.System.Transactions.Enlistment().$ctor$5(enlistmentNotification, tx, atomicTransaction);
                    $.$stl.System.Transactions.EnlistmentState.EnlistmentStatePromoted.EnterState(en.InternalEnlistment);
                    en.InternalEnlistment.PromotedEnlistment = tx.PromotedTransaction.EnlistVolatile(en.InternalEnlistment, enlistmentOptions);
                    return en;
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(tx);
                    }
                }
            }
            /*Enlistment */ EnlistDurable(/*InternalTransaction*/ tx, /*Guid*/ resourceManagerIdentifier, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(tx.PromotedTransaction !== null, "Promoted state not valid for transaction.");
                tx.ThrowIfPromoterTypeIsNotMSDTC();
                $.$spc.System.Threading.Monitor.Exit(tx);
                try
                {
                    /*Enlistment*/ let en = new $.$stl.System.Transactions.Enlistment().$ctor$2(resourceManagerIdentifier, tx, enlistmentNotification, null, atomicTransaction);
                    $.$stl.System.Transactions.EnlistmentState.EnlistmentStatePromoted.EnterState(en.InternalEnlistment);
                    en.InternalEnlistment.PromotedEnlistment = tx.PromotedTransaction.EnlistDurable(resourceManagerIdentifier, $.$cast(en.InternalEnlistment, $.$stl.System.Transactions.DurableInternalEnlistment), false, enlistmentOptions);
                    return en;
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(tx);
                    }
                }
            }
            /*Enlistment */ EnlistDurable$1(/*InternalTransaction*/ tx, /*Guid*/ resourceManagerIdentifier, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(tx.PromotedTransaction !== null, "Promoted state not valid for transaction.");
                tx.ThrowIfPromoterTypeIsNotMSDTC();
                $.$spc.System.Threading.Monitor.Exit(tx);
                try
                {
                    /*Enlistment*/ let en = new $.$stl.System.Transactions.Enlistment().$ctor$2(resourceManagerIdentifier, tx, enlistmentNotification, enlistmentNotification, atomicTransaction);
                    $.$stl.System.Transactions.EnlistmentState.EnlistmentStatePromoted.EnterState(en.InternalEnlistment);
                    en.InternalEnlistment.PromotedEnlistment = tx.PromotedTransaction.EnlistDurable(resourceManagerIdentifier, $.$cast(en.InternalEnlistment, $.$stl.System.Transactions.DurableInternalEnlistment), true, enlistmentOptions);
                    return en;
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(tx);
                    }
                }
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(tx.PromotedTransaction !== null, "Promoted state not valid for transaction.");
                tx._innerException ??= e;
                $.$spc.System.Threading.Monitor.Exit(tx);
                try
                {
                    tx.PromotedTransaction.Rollback();
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(tx);
                    }
                }
            }
            /*Guid */ get_Identifier(/*InternalTransaction?*/ tx)
            {
                if (tx !== null && tx.PromotedTransaction !== null)
                {
                    return tx.PromotedTransaction.Identifier;
                }
                else 
                {
                    return $.$spc.System.Guid.Empty;
                }
            }
            /*void */ AddOutcomeRegistrant(/*InternalTransaction*/ tx, /*TransactionCompletedEventHandler?*/ transactionCompletedDelegate)
            {
                tx._transactionCompletedDelegate = $.$cast($.$spc.System.Delegate.Combine(tx._transactionCompletedDelegate, transactionCompletedDelegate), $.$stl.System.Transactions.TransactionCompletedEventHandler);
            }
            /*void */ BeginCommit(/*InternalTransaction*/ tx, /*bool*/ asyncCommit, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                tx._asyncCommit = asyncCommit;
                tx._asyncCallback = asyncCallback;
                tx._asyncState = asyncState;
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedCommitting.EnterState(tx);
            }
            /*void */ RestartCommitIfNeeded(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedP0Wave.EnterState(tx);
            }
            /*bool */ EnlistPromotableSinglePhase(/*InternalTransaction*/ tx, /*IPromotableSinglePhaseNotification*/ promotableSinglePhaseNotification, /*Transaction*/ atomicTransaction, /*Guid*/ promoterType)
            {
                return false;
            }
            /*void */ CompleteBlockingClone(/*InternalTransaction*/ tx)
            {
                if (tx._phase0Volatiles._dependentClones > 0)
                {
                    tx._phase0Volatiles._dependentClones--;
                    $.$spc.System.Diagnostics.Debug.Assert$1(tx._phase0Volatiles._preparedVolatileEnlistments <= ((tx._phase0Volatiles._volatileEnlistmentCount + tx._phase0Volatiles._dependentClones) | 0), "tx._phase0Volatiles._preparedVolatileEnlistments <=\r\n                    tx._phase0Volatiles._volatileEnlistmentCount + tx._phase0Volatiles._dependentClones");
                    if (tx._phase0Volatiles._preparedVolatileEnlistments === ((tx._phase0VolatileWaveCount + tx._phase0Volatiles._dependentClones) | 0))
                    {
                        tx.State.Phase0VolatilePrepareDone(tx);
                    }
                }
                else 
                {
                    tx._phase0WaveDependentCloneCount--;
                    $.$spc.System.Diagnostics.Debug.Assert$1(tx._phase0WaveDependentCloneCount >= 0, "tx._phase0WaveDependentCloneCount >= 0");
                    if (tx._phase0WaveDependentCloneCount === 0)
                    {
                        /*OletxDependentTransaction*/ let dtx = tx._phase0WaveDependentClone;
                        tx._phase0WaveDependentClone = null;
                        $.$spc.System.Threading.Monitor.Exit(tx);
                        try
                        {
                            try
                            {
                                dtx.Complete();
                            }
                            finally
                            {
                                {
                                    dtx.Dispose();
                                }
                            }
                        }
                        finally
                        {
                            {
                                $.$spc.System.Threading.Monitor.Enter(tx);
                            }
                        }
                    }
                }
            }
            /*void */ CompleteAbortingClone(/*InternalTransaction*/ tx)
            {
                if (null !== tx._phase1Volatiles.VolatileDemux)
                {
                    tx._phase1Volatiles._dependentClones--;
                    $.$spc.System.Diagnostics.Debug.Assert$1(tx._phase1Volatiles._dependentClones >= 0, "tx._phase1Volatiles._dependentClones >= 0");
                }
                else 
                {
                    tx._abortingDependentCloneCount--;
                    $.$spc.System.Diagnostics.Debug.Assert$1(0 <= tx._abortingDependentCloneCount, "0 <= tx._abortingDependentCloneCount");
                    if (0 === tx._abortingDependentCloneCount)
                    {
                        /*OletxDependentTransaction*/ let dtx = tx._abortingDependentClone;
                        tx._abortingDependentClone = null;
                        $.$spc.System.Threading.Monitor.Exit(tx);
                        try
                        {
                            try
                            {
                                dtx.Complete();
                            }
                            finally
                            {
                                {
                                    dtx.Dispose();
                                }
                            }
                        }
                        finally
                        {
                            {
                                $.$spc.System.Threading.Monitor.Enter(tx);
                            }
                        }
                    }
                }
            }
            /*void */ CreateBlockingClone(/*InternalTransaction*/ tx)
            {
                if (tx._phase0WaveDependentClone === null)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(tx.PromotedTransaction !== null, "tx.PromotedTransaction != null");
                    tx._phase0WaveDependentClone = tx.PromotedTransaction.DependentClone(true);
                }
                tx._phase0WaveDependentCloneCount++;
            }
            /*void */ CreateAbortingClone(/*InternalTransaction*/ tx)
            {
                if (null !== tx._phase1Volatiles.VolatileDemux)
                {
                    tx._phase1Volatiles._dependentClones++;
                }
                else 
                {
                    if (null === tx._abortingDependentClone)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(tx.PromotedTransaction !== null, "tx.PromotedTransaction != null");
                        tx._abortingDependentClone = tx.PromotedTransaction.DependentClone(false);
                    }
                    tx._abortingDependentCloneCount++;
                }
            }
            /*bool */ ContinuePhase0Prepares()
            {
                return true;
            }
            /*void */ GetObjectData(/*InternalTransaction*/ tx, /*SerializationInfo*/ serializationInfo, /*StreamingContext*/ context)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(tx.PromotedTransaction !== null, "Promoted state not valid for transaction.");
                tx.ThrowIfPromoterTypeIsNotMSDTC();
                /*OletxTransaction*/ let serializableTx = tx.PromotedTransaction;
                if (serializableTx === null)
                {
                    throw new $.$spc.System.NotSupportedException().$ctor$9();
                }
                serializationInfo.FullTypeName = $.$spc.System.Object.GetType.call(serializableTx).FullName;
                serializableTx.GetObjectData(serializationInfo, context);
            }
            /*void */ ChangeStatePromotedAborted(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedAborted.EnterState(tx);
            }
            /*void */ ChangeStatePromotedCommitted(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedCommitted.EnterState(tx);
            }
            /*void */ InDoubtFromDtc(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedIndoubt.EnterState(tx);
            }
            /*void */ InDoubtFromEnlistment(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedIndoubt.EnterState(tx);
            }
            /*void */ ChangeStateAbortedDuringPromotion(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStateAborted.EnterState(tx);
            }
            /*void */ Timeout(/*InternalTransaction*/ tx)
            {
                try
                {
                    tx._innerException ??= new $.$spc.System.TimeoutException().$ctor$10($.$stl.System.SR.TraceTransactionTimeout);
                    $.$spc.System.Diagnostics.Debug.Assert$1(tx.PromotedTransaction !== null, "tx.PromotedTransaction != null");
                    tx.PromotedTransaction.Rollback();
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.TransactionTimeout(tx.TransactionTraceId);
                    }
                }
                catch(te)
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.ExceptionConsumed$1(te);
                    }
                }
            }
            /*void */ Promote(/*InternalTransaction*/ tx)
            {
            }
            /*byte[] */ PromotedToken(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(tx.promotedToken !== null, "InternalTransaction.promotedToken is null in TransactionStateDelegatedNonMSDTCBase or one of its derived classes.");
                return tx.promotedToken;
            }
            /*void */ Phase0VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ Phase1VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 6923525;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":5743877,"m":[{"r":8430853,"p":[{"n":"tx","p":2794757}],"n":"get_Status","d":6923525,"h":4301890821,"f":32776},{"r":1746181,"p":[{"n":"tx","p":2794757},{"n":"enlistmentNotification","p":2598149},{"n":"enlistmentOptions","p":1877253},{"n":"atomicTransaction","p":4302085}],"n":"EnlistVolatile","d":6923525,"h":8596858117,"f":32776},{"r":1746181,"p":[{"n":"tx","p":2794757},{"n":"enlistmentNotification","p":3056901},{"n":"enlistmentOptions","p":1877253},{"n":"atomicTransaction","p":4302085}],"n":"EnlistVolatile","o":"@$1","d":6923525,"h":12891825413,"f":32776},{"r":1746181,"p":[{"n":"tx","p":2794757},{"n":"resourceManagerIdentifier","p":56229889},{"n":"enlistmentNotification","p":2598149},{"n":"enlistmentOptions","p":1877253},{"n":"atomicTransaction","p":4302085}],"n":"EnlistDurable","d":6923525,"h":17186792709,"f":32776},{"r":1746181,"p":[{"n":"tx","p":2794757},{"n":"resourceManagerIdentifier","p":56229889},{"n":"enlistmentNotification","p":3056901},{"n":"enlistmentOptions","p":1877253},{"n":"atomicTransaction","p":4302085}],"n":"EnlistDurable","o":"@$1","d":6923525,"h":21481760005,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"e","p":47251457}],"n":"Rollback","d":6923525,"h":25776727301,"f":32776},{"r":56229889,"p":[{"n":"tx","p":2794757}],"n":"get_Identifier","d":6923525,"h":30071694597,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"transactionCompletedDelegate","p":4433157}],"n":"AddOutcomeRegistrant","d":6923525,"h":34366661893,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"asyncCommit","p":262145},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":6923525,"h":38661629189,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"RestartCommitIfNeeded","d":6923525,"h":42956596485,"f":32776},{"r":262145,"p":[{"n":"tx","p":2794757},{"n":"promotableSinglePhaseNotification","p":2860293},{"n":"atomicTransaction","p":4302085},{"n":"promoterType","p":56229889}],"n":"EnlistPromotableSinglePhase","d":6923525,"h":47251563781,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"CompleteBlockingClone","d":6923525,"h":51546531077,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"CompleteAbortingClone","d":6923525,"h":55841498373,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"CreateBlockingClone","d":6923525,"h":60136465669,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"CreateAbortingClone","d":6923525,"h":64431432965,"f":32776},{"r":262145,"n":"ContinuePhase0Prepares","d":6923525,"h":68726400261,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"serializationInfo","p":113967105},{"n":"context","p":114098177}],"n":"GetObjectData","d":6923525,"h":73021367557,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"ChangeStatePromotedAborted","d":6923525,"h":77316334853,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"ChangeStatePromotedCommitted","d":6923525,"h":81611302149,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"InDoubtFromDtc","d":6923525,"h":85906269445,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"InDoubtFromEnlistment","d":6923525,"h":90201236741,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"ChangeStateAbortedDuringPromotion","d":6923525,"h":94496204037,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"Timeout","d":6923525,"h":98791171333,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"Promote","d":6923525,"h":103086138629,"f":32776},{"r":0,"p":[{"n":"tx","p":2794757}],"n":"PromotedToken","d":6923525,"h":107381105925,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"Phase0VolatilePrepareDone","d":6923525,"h":111676073221,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"Phase1VolatilePrepareDone","d":6923525,"h":115971040517,"f":32776}],"c":[{"n":".ctor","o":"$ctor$2","d":6923525,"h":120266007813,"f":4}],"h":6923525}; }
            static get $b() { return $.$stl.System.Transactions.TransactionState; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedBase`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedNonMSDTCBase", ($self) => class TransactionStatePromotedNonMSDTCBase extends $.$stl.System.Transactions.TransactionState
        {
            /*TransactionStatus */ get_Status(/*InternalTransaction*/ tx)
            {
                return 0/*TransactionStatus.Active*/;
            }
            /*Enlistment */ EnlistVolatile(/*InternalTransaction*/ tx, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                /*Enlistment*/ let enlistment = new $.$stl.System.Transactions.Enlistment().$ctor$3(tx, enlistmentNotification, null, atomicTransaction, enlistmentOptions);
                if ((enlistmentOptions & 1/*EnlistmentOptions.EnlistDuringPrepareRequired*/) !== 0)
                {
                    $.$stl.System.Transactions.TransactionState.AddVolatileEnlistment($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase0Volatiles, ($v) => tx._phase0Volatiles = $v, null), enlistment);
                }
                else 
                {
                    $.$stl.System.Transactions.TransactionState.AddVolatileEnlistment($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase1Volatiles, ($v) => tx._phase1Volatiles = $v, null), enlistment);
                }
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionstateEnlist(enlistment.InternalEnlistment.EnlistmentTraceId, 0/*EnlistmentType.Volatile*/, enlistmentOptions);
                }
                return enlistment;
            }
            /*Enlistment */ EnlistVolatile$1(/*InternalTransaction*/ tx, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                /*Enlistment*/ let enlistment = new $.$stl.System.Transactions.Enlistment().$ctor$3(tx, enlistmentNotification, enlistmentNotification, atomicTransaction, enlistmentOptions);
                if ((enlistmentOptions & 1/*EnlistmentOptions.EnlistDuringPrepareRequired*/) !== 0)
                {
                    $.$stl.System.Transactions.TransactionState.AddVolatileEnlistment($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase0Volatiles, ($v) => tx._phase0Volatiles = $v, null), enlistment);
                }
                else 
                {
                    $.$stl.System.Transactions.TransactionState.AddVolatileEnlistment($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase1Volatiles, ($v) => tx._phase1Volatiles = $v, null), enlistment);
                }
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionstateEnlist(enlistment.InternalEnlistment.EnlistmentTraceId, 0/*EnlistmentType.Volatile*/, enlistmentOptions);
                }
                return enlistment;
            }
            /*Enlistment */ EnlistDurable(/*InternalTransaction*/ tx, /*Guid*/ resourceManagerIdentifier, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                throw new $.$stl.System.Transactions.TransactionPromotionException().$ctor$15($.$stl.System.SR.Format($.$stl.System.SR.PromoterTypeUnrecognized, $.$spc.System.Guid.ToString.call(tx._promoterType)), tx._innerException);
            }
            /*Enlistment */ EnlistDurable$1(/*InternalTransaction*/ tx, /*Guid*/ resourceManagerIdentifier, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                throw new $.$stl.System.Transactions.TransactionPromotionException().$ctor$15($.$stl.System.SR.Format($.$stl.System.SR.PromoterTypeUnrecognized, $.$spc.System.Guid.ToString.call(tx._promoterType)), tx._innerException);
            }
            /*bool */ EnlistPromotableSinglePhase(/*InternalTransaction*/ tx, /*IPromotableSinglePhaseNotification*/ promotableSinglePhaseNotification, /*Transaction*/ atomicTransaction, /*Guid*/ promoterType)
            {
                return false;
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(tx._durableEnlistment !== null, "PromotedNonMSDTC state is not valid for transaction");
                tx._innerException ??= e;
                $.$stl.System.Transactions.TransactionState.TransactionStateAborted.EnterState(tx);
            }
            /*Guid */ get_Identifier(/*InternalTransaction*/ tx)
            {
                return tx._distributedTransactionIdentifierNonMSDTC;
            }
            /*void */ AddOutcomeRegistrant(/*InternalTransaction*/ tx, /*TransactionCompletedEventHandler?*/ transactionCompletedDelegate)
            {
                tx._transactionCompletedDelegate = $.$cast($.$spc.System.Delegate.Combine(tx._transactionCompletedDelegate, transactionCompletedDelegate), $.$stl.System.Transactions.TransactionCompletedEventHandler);
            }
            /*void */ BeginCommit(/*InternalTransaction*/ tx, /*bool*/ asyncCommit, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                tx._asyncCommit = asyncCommit;
                tx._asyncCallback = asyncCallback;
                tx._asyncState = asyncState;
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedNonMSDTCPhase0.EnterState(tx);
            }
            /*void */ CompleteBlockingClone(/*InternalTransaction*/ tx)
            {
                if (tx._phase0Volatiles._dependentClones > 0)
                {
                    tx._phase0Volatiles._dependentClones--;
                    $.$spc.System.Diagnostics.Debug.Assert$1(tx._phase0Volatiles._preparedVolatileEnlistments <= ((tx._phase0Volatiles._volatileEnlistmentCount + tx._phase0Volatiles._dependentClones) | 0), "tx._phase0Volatiles._preparedVolatileEnlistments <=\r\n                    tx._phase0Volatiles._volatileEnlistmentCount + tx._phase0Volatiles._dependentClones");
                    if (tx._phase0Volatiles._preparedVolatileEnlistments === ((tx._phase0VolatileWaveCount + tx._phase0Volatiles._dependentClones) | 0))
                    {
                        tx.State.Phase0VolatilePrepareDone(tx);
                    }
                }
            }
            /*void */ CompleteAbortingClone(/*InternalTransaction*/ tx)
            {
                tx._phase1Volatiles._dependentClones--;
                $.$spc.System.Diagnostics.Debug.Assert$1(tx._phase1Volatiles._dependentClones >= 0, "tx._phase1Volatiles._dependentClones >= 0");
            }
            /*void */ CreateBlockingClone(/*InternalTransaction*/ tx)
            {
                tx._phase0Volatiles._dependentClones++;
            }
            /*void */ CreateAbortingClone(/*InternalTransaction*/ tx)
            {
                tx._phase1Volatiles._dependentClones++;
            }
            /*bool */ ContinuePhase0Prepares()
            {
                return true;
            }
            /*void */ GetObjectData(/*InternalTransaction*/ tx, /*SerializationInfo*/ serializationInfo, /*StreamingContext*/ context)
            {
                throw new $.$stl.System.Transactions.TransactionPromotionException().$ctor$15($.$stl.System.SR.Format($.$stl.System.SR.PromoterTypeUnrecognized, $.$spc.System.Guid.ToString.call(tx._promoterType)), tx._innerException);
            }
            /*void */ ChangeStateTransactionAborted(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                tx._innerException ??= e;
                $.$stl.System.Transactions.TransactionState.TransactionStateAborted.EnterState(tx);
            }
            /*void */ InDoubtFromEnlistment(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedNonMSDTCIndoubt.EnterState(tx);
            }
            /*void */ ChangeStateAbortedDuringPromotion(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStateAborted.EnterState(tx);
            }
            /*void */ Timeout(/*InternalTransaction*/ tx)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionTimeout(tx.TransactionTraceId);
                }
                /*TimeoutException*/ let e = new $.$spc.System.TimeoutException().$ctor$10($.$stl.System.SR.TraceTransactionTimeout);
                this.Rollback(tx, e);
            }
            /*void */ Promote(/*InternalTransaction*/ tx)
            {
            }
            /*void */ Phase0VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ Phase1VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            /*byte[] */ PromotedToken(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(tx.promotedToken !== null, "InternalTransaction.promotedToken is null in TransactionStateDelegatedNonMSDTCBase or one of its derived classes.");
                return tx.promotedToken;
            }
            /*void */ DisposeRoot(/*InternalTransaction*/ tx)
            {
                tx.State.Rollback(tx, null);
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 7316741;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":5743877,"m":[{"r":8430853,"p":[{"n":"tx","p":2794757}],"n":"get_Status","d":7316741,"h":4302284037,"f":32776},{"r":1746181,"p":[{"n":"tx","p":2794757},{"n":"enlistmentNotification","p":2598149},{"n":"enlistmentOptions","p":1877253},{"n":"atomicTransaction","p":4302085}],"n":"EnlistVolatile","d":7316741,"h":8597251333,"f":32776},{"r":1746181,"p":[{"n":"tx","p":2794757},{"n":"enlistmentNotification","p":3056901},{"n":"enlistmentOptions","p":1877253},{"n":"atomicTransaction","p":4302085}],"n":"EnlistVolatile","o":"@$1","d":7316741,"h":12892218629,"f":32776},{"r":1746181,"p":[{"n":"tx","p":2794757},{"n":"resourceManagerIdentifier","p":56229889},{"n":"enlistmentNotification","p":2598149},{"n":"enlistmentOptions","p":1877253},{"n":"atomicTransaction","p":4302085}],"n":"EnlistDurable","d":7316741,"h":17187185925,"f":32776},{"r":1746181,"p":[{"n":"tx","p":2794757},{"n":"resourceManagerIdentifier","p":56229889},{"n":"enlistmentNotification","p":3056901},{"n":"enlistmentOptions","p":1877253},{"n":"atomicTransaction","p":4302085}],"n":"EnlistDurable","o":"@$1","d":7316741,"h":21482153221,"f":32776},{"r":262145,"p":[{"n":"tx","p":2794757},{"n":"promotableSinglePhaseNotification","p":2860293},{"n":"atomicTransaction","p":4302085},{"n":"promoterType","p":56229889}],"n":"EnlistPromotableSinglePhase","d":7316741,"h":25777120517,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"e","p":47251457}],"n":"Rollback","d":7316741,"h":30072087813,"f":32776},{"r":56229889,"p":[{"n":"tx","p":2794757}],"n":"get_Identifier","d":7316741,"h":34367055109,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"transactionCompletedDelegate","p":4433157}],"n":"AddOutcomeRegistrant","d":7316741,"h":38662022405,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"asyncCommit","p":262145},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":7316741,"h":42956989701,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"CompleteBlockingClone","d":7316741,"h":47251956997,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"CompleteAbortingClone","d":7316741,"h":51546924293,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"CreateBlockingClone","d":7316741,"h":55841891589,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"CreateAbortingClone","d":7316741,"h":60136858885,"f":32776},{"r":262145,"n":"ContinuePhase0Prepares","d":7316741,"h":64431826181,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"serializationInfo","p":113967105},{"n":"context","p":114098177}],"n":"GetObjectData","d":7316741,"h":68726793477,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"e","p":47251457}],"n":"ChangeStateTransactionAborted","d":7316741,"h":73021760773,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"InDoubtFromEnlistment","d":7316741,"h":77316728069,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"ChangeStateAbortedDuringPromotion","d":7316741,"h":81611695365,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"Timeout","d":7316741,"h":85906662661,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"Promote","d":7316741,"h":90201629957,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"Phase0VolatilePrepareDone","d":7316741,"h":94496597253,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"Phase1VolatilePrepareDone","d":7316741,"h":98791564549,"f":32776},{"r":0,"p":[{"n":"tx","p":2794757}],"n":"PromotedToken","d":7316741,"h":103086531845,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"DisposeRoot","d":7316741,"h":107381499141,"f":32776}],"c":[{"n":".ctor","o":"$ctor$2","d":7316741,"h":111676466437,"f":4}],"h":7316741}; }
            static get $b() { return $.$stl.System.Transactions.TransactionState; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedNonMSDTCBase`; }
        });
        
        $asm.$cls("$stl.System.Transactions.EnlistableStates", ($self) => class EnlistableStates extends $.$stl.System.Transactions.ActiveStates
        {
            /*Enlistment */ EnlistDurable(/*InternalTransaction*/ tx, /*Guid*/ resourceManagerIdentifier, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                tx.ThrowIfPromoterTypeIsNotMSDTC();
                tx._promoteState.EnterState(tx);
                return tx.State.EnlistDurable(tx, resourceManagerIdentifier, enlistmentNotification, enlistmentOptions, atomicTransaction);
            }
            /*Enlistment */ EnlistDurable$1(/*InternalTransaction*/ tx, /*Guid*/ resourceManagerIdentifier, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                tx.ThrowIfPromoterTypeIsNotMSDTC();
                if (tx._durableEnlistment !== null || (enlistmentOptions & 1/*EnlistmentOptions.EnlistDuringPrepareRequired*/) !== 0)
                {
                    tx._promoteState.EnterState(tx);
                    return tx.State.EnlistDurable$1(tx, resourceManagerIdentifier, enlistmentNotification, enlistmentOptions, atomicTransaction);
                }
                /*Enlistment*/ let en = new $.$stl.System.Transactions.Enlistment().$ctor$2(resourceManagerIdentifier, tx, enlistmentNotification, enlistmentNotification, atomicTransaction);
                tx._durableEnlistment = en.InternalEnlistment;
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentActive.EnterState(tx._durableEnlistment);
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionstateEnlist(tx._durableEnlistment.EnlistmentTraceId, 1/*EnlistmentType.Durable*/, 0/*EnlistmentOptions.None*/);
                }
                return en;
            }
            /*void */ Timeout(/*InternalTransaction*/ tx)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionTimeout(tx.TransactionTraceId);
                }
                /*TimeoutException*/ let e = new $.$spc.System.TimeoutException().$ctor$10($.$stl.System.SR.TraceTransactionTimeout);
                this.Rollback(tx, e);
            }
            /*void */ GetObjectData(/*InternalTransaction*/ tx, /*SerializationInfo*/ serializationInfo, /*StreamingContext*/ context)
            {
                tx.ThrowIfPromoterTypeIsNotMSDTC();
                tx._promoteState.EnterState(tx);
                tx.State.GetObjectData(tx, serializationInfo, context);
            }
            /*void */ CompleteBlockingClone(/*InternalTransaction*/ tx)
            {
                tx._phase0Volatiles._dependentClones--;
                $.$spc.System.Diagnostics.Debug.Assert$1(tx._phase0Volatiles._dependentClones >= 0, "tx._phase0Volatiles._dependentClones >= 0");
                $.$spc.System.Diagnostics.Debug.Assert$1(tx._phase0Volatiles._preparedVolatileEnlistments <= ((tx._phase0Volatiles._volatileEnlistmentCount + tx._phase0Volatiles._dependentClones) | 0), "tx._phase0Volatiles._preparedVolatileEnlistments <=\r\n                tx._phase0Volatiles._volatileEnlistmentCount + tx._phase0Volatiles._dependentClones");
                if (tx._phase0Volatiles._preparedVolatileEnlistments === ((tx._phase0VolatileWaveCount + tx._phase0Volatiles._dependentClones) | 0))
                {
                    tx.State.Phase0VolatilePrepareDone(tx);
                }
            }
            /*void */ CompleteAbortingClone(/*InternalTransaction*/ tx)
            {
                tx._phase1Volatiles._dependentClones--;
                $.$spc.System.Diagnostics.Debug.Assert$1(tx._phase1Volatiles._dependentClones >= 0, "tx._phase1Volatiles._dependentClones >= 0");
            }
            /*void */ CreateBlockingClone(/*InternalTransaction*/ tx)
            {
                tx._phase0Volatiles._dependentClones++;
            }
            /*void */ CreateAbortingClone(/*InternalTransaction*/ tx)
            {
                tx._phase1Volatiles._dependentClones++;
            }
            /*void */ Promote(/*InternalTransaction*/ tx)
            {
                tx._promoteState.EnterState(tx);
                tx.State.CheckForFinishedTransaction(tx);
            }
            /*byte[] */ PromotedToken(/*InternalTransaction*/ tx)
            {
                if (tx.promotedToken === null)
                {
                    tx._promoteState.EnterState(tx);
                    tx.State.CheckForFinishedTransaction(tx);
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(tx.promotedToken !== null, "tx.promotedToken != null");
                return tx.promotedToken;
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 1680645;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":238853,"m":[{"r":1746181,"p":[{"n":"tx","p":2794757},{"n":"resourceManagerIdentifier","p":56229889},{"n":"enlistmentNotification","p":2598149},{"n":"enlistmentOptions","p":1877253},{"n":"atomicTransaction","p":4302085}],"n":"EnlistDurable","d":1680645,"h":4296647941,"f":32776},{"r":1746181,"p":[{"n":"tx","p":2794757},{"n":"resourceManagerIdentifier","p":56229889},{"n":"enlistmentNotification","p":3056901},{"n":"enlistmentOptions","p":1877253},{"n":"atomicTransaction","p":4302085}],"n":"EnlistDurable","o":"@$1","d":1680645,"h":8591615237,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"Timeout","d":1680645,"h":12886582533,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"serializationInfo","p":113967105},{"n":"context","p":114098177}],"n":"GetObjectData","d":1680645,"h":17181549829,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"CompleteBlockingClone","d":1680645,"h":21476517125,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"CompleteAbortingClone","d":1680645,"h":25771484421,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"CreateBlockingClone","d":1680645,"h":30066451717,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"CreateAbortingClone","d":1680645,"h":34361419013,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"Promote","d":1680645,"h":38656386309,"f":32776},{"r":0,"p":[{"n":"tx","p":2794757}],"n":"PromotedToken","d":1680645,"h":42951353605,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":1680645,"h":47246320901,"f":4}],"h":1680645}; }
            static get $b() { return $.$stl.System.Transactions.ActiveStates; }
            static get $fullName() { return `System.Transactions.EnlistableStates`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedAborting", ($self) => class TransactionStatePromotedAborting extends $.$stl.System.Transactions.TransactionStatePromotedBase
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
            }
            /*TransactionStatus */ get_Status(/*InternalTransaction*/ tx)
            {
                return 2/*TransactionStatus.Aborted*/;
            }
            /*void */ BeginCommit(/*InternalTransaction*/ tx, /*bool*/ asyncCommit, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ CreateBlockingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ CreateAbortingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ ChangeStatePromotedAborted(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedAborted.EnterState(tx);
            }
            /*void */ ChangeStateTransactionAborted(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
            }
            /*void */ RestartCommitIfNeeded(/*InternalTransaction*/ tx)
            {
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 6857989;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6923525,"m":[{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"EnterState","d":6857989,"h":4301825285,"f":32776},{"r":8430853,"p":[{"n":"tx","p":2794757}],"n":"get_Status","d":6857989,"h":8596792581,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"asyncCommit","p":262145},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":6857989,"h":12891759877,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"CreateBlockingClone","d":6857989,"h":17186727173,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"CreateAbortingClone","d":6857989,"h":21481694469,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"ChangeStatePromotedAborted","d":6857989,"h":25776661765,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"e","p":47251457}],"n":"ChangeStateTransactionAborted","d":6857989,"h":30071629061,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"RestartCommitIfNeeded","d":6857989,"h":34366596357,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":6857989,"h":38661563653,"f":4}],"h":6857989}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedBase; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedAborting`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedEnded", ($self) => class TransactionStatePromotedEnded extends $.$stl.System.Transactions.TransactionStateEnded
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                super.EnterState(tx);
                this.CommonEnterState(tx);
                if (!$.$spc.System.Threading.ThreadPool.QueueUserWorkItem$1($.$stl.System.Transactions.TransactionStatePromotedEnded.SignalMethod, tx))
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException$1(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.UnexpectedFailureOfThreadPool, null, tx === null ? $.$spc.System.Guid.Empty : tx.DistributedTxId);
                }
            }
            /*void */ AddOutcomeRegistrant(/*InternalTransaction*/ tx, /*TransactionCompletedEventHandler?*/ transactionCompletedDelegate)
            {
                if (transactionCompletedDelegate !== null)
                {
                    /*TransactionEventArgs*/ let args = new $.$stl.System.Transactions.TransactionEventArgs().$ctor$2();
                    args._transaction = tx._outcomeSource.InternalClone();
                    transactionCompletedDelegate.Invoke(args._transaction, args);
                }
            }
            /*void */ EndCommit(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(tx.PromotedTransaction !== null, "Promoted state not valid for transaction.");
                this.PromotedTransactionOutcome(tx);
            }
            /*void */ CompleteBlockingClone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ CompleteAbortingClone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ CreateBlockingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ CreateAbortingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*Guid */ get_Identifier(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(tx.PromotedTransaction !== null, "tx.PromotedTransaction != null");
                return tx.PromotedTransaction.Identifier;
            }
            /*void */ Promote(/*InternalTransaction*/ tx)
            {
            }
            /*WaitCallback?*/ static s_signalMethod = null;
            static /*WaitCallback */ get SignalMethod()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$spc.System.Threading.WaitCallback, $.$ref(() => $.$stl.System.Transactions.TransactionStatePromotedEnded.s_signalMethod, ($v) => $.$stl.System.Transactions.TransactionStatePromotedEnded.s_signalMethod = $v, $.$spc.System.Threading.WaitCallback), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$spc.System.Threading.WaitCallback))().$ctor(this,  () =>
                {
                    return new $.$spc.System.Threading.WaitCallback().$ctor($.$stl.System.Transactions.TransactionStatePromotedEnded, $.$stl.System.Transactions.TransactionStatePromotedEnded.SignalCallback);
                }, {"r":139067393,"n":"","d":7120133,"h":0,"f":1048578}));
            }
            static /*void */ SignalCallback(/*object*/ state)
            {
                /*InternalTransaction*/ let tx = $.$cast(state, $.$stl.System.Transactions.InternalTransaction);
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(tx)
                    {
                        tx.SignalAsyncCompletion();
                        $.$stl.System.Transactions.TransactionTable.Remove(tx);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(tx)
                }
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 7120133;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6464773,"p":[{"p":139067393,"g":{"r":0,"d":0,"h":55841694981,"f":34},"n":"SignalMethod","d":7120133,"h":51546727685,"f":34}],"m":[{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"EnterState","d":7120133,"h":4302087429,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"transactionCompletedDelegate","p":4433157}],"n":"AddOutcomeRegistrant","d":7120133,"h":8597054725,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"EndCommit","d":7120133,"h":12892022021,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"CompleteBlockingClone","d":7120133,"h":17186989317,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"CompleteAbortingClone","d":7120133,"h":21481956613,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"CreateBlockingClone","d":7120133,"h":25776923909,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"CreateAbortingClone","d":7120133,"h":30071891205,"f":32776},{"r":56229889,"p":[{"n":"tx","p":2794757}],"n":"get_Identifier","d":7120133,"h":34366858501,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"Promote","d":7120133,"h":38661825797,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"PromotedTransactionOutcome","d":7120133,"h":42956793093,"f":260},{"r":65537,"p":[{"n":"state","p":131073}],"n":"SignalCallback","d":7120133,"h":60136662277,"f":34}],"l":[{"t":139067393,"n":"s_signalMethod","d":7120133,"h":47251760389,"f":34}],"c":[{"n":".ctor","o":"$ctor$3","d":7120133,"h":64431629573,"f":4}],"h":7120133}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStateEnded; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedEnded`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedNonMSDTCEnded", ($self) => class TransactionStatePromotedNonMSDTCEnded extends $.$stl.System.Transactions.TransactionStateEnded
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                super.EnterState(tx);
                this.CommonEnterState(tx);
                if (!$.$spc.System.Threading.ThreadPool.QueueUserWorkItem$1($.$stl.System.Transactions.TransactionStatePromotedNonMSDTCEnded.SignalMethod, tx))
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException$1(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.UnexpectedFailureOfThreadPool, null, tx === null ? $.$spc.System.Guid.Empty : tx.DistributedTxId);
                }
            }
            /*void */ AddOutcomeRegistrant(/*InternalTransaction*/ tx, /*TransactionCompletedEventHandler?*/ transactionCompletedDelegate)
            {
                if (transactionCompletedDelegate !== null)
                {
                    /*TransactionEventArgs*/ let args = new $.$stl.System.Transactions.TransactionEventArgs().$ctor$2();
                    args._transaction = tx._outcomeSource.InternalClone();
                    transactionCompletedDelegate.Invoke(args._transaction, args);
                }
            }
            /*void */ EndCommit(/*InternalTransaction*/ tx)
            {
                this.PromotedTransactionOutcome(tx);
            }
            /*void */ CompleteBlockingClone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ CompleteAbortingClone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ CreateBlockingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ CreateAbortingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*Guid */ get_Identifier(/*InternalTransaction*/ tx)
            {
                return tx._distributedTransactionIdentifierNonMSDTC;
            }
            /*void */ Promote(/*InternalTransaction*/ tx)
            {
            }
            /*WaitCallback?*/ static s_signalMethod = null;
            static /*WaitCallback */ get SignalMethod()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$spc.System.Threading.WaitCallback, $.$ref(() => $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCEnded.s_signalMethod, ($v) => $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCEnded.s_signalMethod = $v, $.$spc.System.Threading.WaitCallback), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$spc.System.Threading.WaitCallback))().$ctor(this,  () =>
                {
                    return new $.$spc.System.Threading.WaitCallback().$ctor($.$stl.System.Transactions.TransactionStatePromotedNonMSDTCEnded, $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCEnded.SignalCallback);
                }, {"r":139067393,"n":"","d":7447813,"h":0,"f":1048578}));
            }
            static /*void */ SignalCallback(/*object*/ state)
            {
                /*InternalTransaction*/ let tx = $.$cast(state, $.$stl.System.Transactions.InternalTransaction);
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(tx)
                    {
                        tx.SignalAsyncCompletion();
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(tx)
                }
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 7447813;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6464773,"p":[{"p":139067393,"g":{"r":0,"d":0,"h":55842022661,"f":34},"n":"SignalMethod","d":7447813,"h":51547055365,"f":34}],"m":[{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"EnterState","d":7447813,"h":4302415109,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"transactionCompletedDelegate","p":4433157}],"n":"AddOutcomeRegistrant","d":7447813,"h":8597382405,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"EndCommit","d":7447813,"h":12892349701,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"CompleteBlockingClone","d":7447813,"h":17187316997,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"CompleteAbortingClone","d":7447813,"h":21482284293,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"CreateBlockingClone","d":7447813,"h":25777251589,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"CreateAbortingClone","d":7447813,"h":30072218885,"f":32776},{"r":56229889,"p":[{"n":"tx","p":2794757}],"n":"get_Identifier","d":7447813,"h":34367186181,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"Promote","d":7447813,"h":38662153477,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"PromotedTransactionOutcome","d":7447813,"h":42957120773,"f":260},{"r":65537,"p":[{"n":"state","p":131073}],"n":"SignalCallback","d":7447813,"h":60136989957,"f":34}],"l":[{"t":139067393,"n":"s_signalMethod","d":7447813,"h":47252088069,"f":34}],"c":[{"n":".ctor","o":"$ctor$3","d":7447813,"h":64431957253,"f":4}],"h":7447813}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStateEnded; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedNonMSDTCEnded`; }
        });
        
        $asm.$cls("$stl.System.Transactions.EnterpriseServices", ($self) => class EnterpriseServices
        {
            static /*bool */ get EnterpriseServicesOk()
            {
                return false;
            }
            static /*void */ VerifyEnterpriseServicesOk()
            {
                if (!$.$stl.System.Transactions.EnterpriseServices.EnterpriseServicesOk)
                {
                    $.$stl.System.Transactions.EnterpriseServices.ThrowNotSupported();
                }
            }
            static /*Transaction? */ GetContextTransaction()
            {
                if ($.$stl.System.Transactions.EnterpriseServices.EnterpriseServicesOk)
                {
                    $.$stl.System.Transactions.EnterpriseServices.ThrowNotSupported();
                }
                return null;
            }
            /*bool*/ static CreatedServiceDomain = false;
            static /*bool */ UseServiceDomainForCurrent()
            {
                return false;
            }
            static /*void */ PushServiceDomain()
            {
                $.$stl.System.Transactions.EnterpriseServices.ThrowNotSupported();
            }
            static /*void */ LeaveServiceDomain()
            {
                $.$stl.System.Transactions.EnterpriseServices.ThrowNotSupported();
            }
            static /*void */ ThrowNotSupported()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$14($.$stl.System.SR.EsNotSupported);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.CreatedServiceDomain = false;
                }
            }
            static $h = 2204933;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":8592139525,"f":40},"n":"EnterpriseServicesOk","d":2204933,"h":4297172229,"f":40},{"p":262145,"g":{"r":0,"d":0,"h":30066976005,"f":40},"s":{"r":0,"d":0,"h":34361943301,"f":40},"n":"CreatedServiceDomain","d":2204933,"h":25772008709,"f":40}],"m":[{"r":65537,"n":"VerifyEnterpriseServicesOk","d":2204933,"h":12887106821,"f":40},{"r":4302085,"n":"GetContextTransaction","d":2204933,"h":17182074117,"f":40},{"r":262145,"n":"UseServiceDomainForCurrent","d":2204933,"h":38656910597,"f":40},{"r":65537,"n":"PushServiceDomain","d":2204933,"h":42951877893,"f":40},{"r":65537,"n":"LeaveServiceDomain","d":2204933,"h":47246845189,"f":40},{"r":65537,"n":"ThrowNotSupported","d":2204933,"h":51541812485,"f":34}],"h":2204933}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Transactions.EnterpriseServices`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionInformation", ($self) => class TransactionInformation extends $.$spc.System.Object
        {
            /*InternalTransaction*/ _internalTransaction = null;
            $ctor$1(/*InternalTransaction*/ internalTransaction)
            {
                super.$ctor();
                {
                    this._internalTransaction = internalTransaction;
                }
                return this;
            }
            /*string */ get LocalIdentifier()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "LocalIdentifier");
                }
                try
                {
                    return this._internalTransaction.TransactionTraceId.TransactionIdentifier;
                }
                finally
                {
                    {
                        if (etwLog.IsEnabled())
                        {
                            etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "LocalIdentifier");
                        }
                    }
                }
            }
            /*Guid */ get DistributedIdentifier()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "DistributedIdentifier");
                }
                try
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                            return this._internalTransaction.State.get_Identifier(this._internalTransaction);
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                    }
                }
                finally
                {
                    {
                        if (etwLog.IsEnabled())
                        {
                            etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "DistributedIdentifier");
                        }
                    }
                }
            }
            /*DateTime */ get CreationTime()
            {
                return new $.$spc.System.DateTime().$ctor$2(this._internalTransaction.CreationTime);
            }
            /*TransactionStatus */ get Status()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "Status");
                }
                try
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                    return this._internalTransaction.State.get_Status(this._internalTransaction);
                }
                finally
                {
                    {
                        if (etwLog.IsEnabled())
                        {
                            etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "Status");
                        }
                    }
                }
            }
            static $h = 4760837;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17184630021,"f":1},"n":"LocalIdentifier","d":4760837,"h":12889662725,"f":1},{"p":56229889,"g":{"r":0,"d":0,"h":25774564613,"f":1},"n":"DistributedIdentifier","d":4760837,"h":21479597317,"f":1},{"p":34209793,"g":{"r":0,"d":0,"h":34364499205,"f":1},"n":"CreationTime","d":4760837,"h":30069531909,"f":1},{"p":8430853,"g":{"r":0,"d":0,"h":42954433797,"f":1},"n":"Status","d":4760837,"h":38659466501,"f":1}],"l":[{"t":2794757,"n":"_internalTransaction","d":4760837,"h":4299728133,"f":2}],"c":[{"p":[{"n":"internalTransaction","p":2794757}],"n":".ctor","o":"$ctor$1","d":4760837,"h":8594695429,"f":8}],"h":4760837}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Transactions.TransactionInformation`; }
        });
        
        $asm.$cls("$stl.System.Transactions.Configuration.ConfigurationStrings", ($self) => class ConfigurationStrings
        {
            /*string*/ static DefaultDistributedTransactionManagerName = null;
            /*string*/ static DefaultMaxTimeout = null;
            /*string*/ static DefaultTimeout = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.DefaultDistributedTransactionManagerName = "";
                }
                {
                    this.DefaultMaxTimeout = "00:10:00";
                }
                {
                    this.DefaultTimeout = "00:01:00";
                }
            }
            static $h = 697605;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"DefaultDistributedTransactionManagerName","d":697605,"h":4295664901,"f":40},{"t":1310721,"n":"DefaultMaxTimeout","d":697605,"h":8590632197,"f":40},{"t":1310721,"n":"DefaultTimeout","d":697605,"h":12885599493,"f":40}],"h":697605}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Transactions.Configuration.ConfigurationStrings`; }
        });
        
        $asm.$cls("$stl.System.Transactions.Configuration.AppSettings", ($self) => class AppSettings
        {
            /*bool*/ static s_settingsInitialized = false;
            /*object*/ static s_appSettingsLock = null;
            /*bool*/ static s_includeDistributedTxIdInExceptionMessage = false;
            static /*void */ EnsureSettingsLoaded()
            {
                if (!$.$stl.System.Transactions.Configuration.AppSettings.s_settingsInitialized)
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter($.$stl.System.Transactions.Configuration.AppSettings.s_appSettingsLock)
                        {
                            if (!$.$stl.System.Transactions.Configuration.AppSettings.s_settingsInitialized)
                            {
                                $.$stl.System.Transactions.Configuration.AppSettings.s_includeDistributedTxIdInExceptionMessage = false;
                                $.$stl.System.Transactions.Configuration.AppSettings.s_settingsInitialized = true;
                            }
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit($.$stl.System.Transactions.Configuration.AppSettings.s_appSettingsLock)
                    }
                }
            }
            static /*bool */ get IncludeDistributedTxIdInExceptionMessage()
            {
                $.$stl.System.Transactions.Configuration.AppSettings.EnsureSettingsLoaded();
                return $.$stl.System.Transactions.Configuration.AppSettings.s_includeDistributedTxIdInExceptionMessage;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_appSettingsLock = new $.$spc.System.Object().$ctor();
                }
            }
            static $h = 632069;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":25770435845,"f":40},"n":"IncludeDistributedTxIdInExceptionMessage","d":632069,"h":21475468549,"f":40}],"m":[{"r":65537,"n":"EnsureSettingsLoaded","d":632069,"h":17180501253,"f":34}],"l":[{"t":262145,"n":"s_settingsInitialized","d":632069,"h":4295599365,"f":34},{"t":131073,"n":"s_appSettingsLock","d":632069,"h":8590566661,"f":34},{"t":262145,"n":"s_includeDistributedTxIdInExceptionMessage","d":632069,"h":12885533957,"f":34}],"h":632069}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Transactions.Configuration.AppSettings`; }
        });
        
        $asm.$cls("$stl.System.Transactions.Configuration.DefaultSettingsSection", ($self) => class DefaultSettingsSection extends $.$spc.System.Object
        {
            /*DefaultSettingsSection*/ static s_section = null;
            /*TimeSpan*/ static s_timeout;
            static /*DefaultSettingsSection */ GetSection()
            {
                return $.$stl.System.Transactions.Configuration.DefaultSettingsSection.s_section;
            }
            /*string*/ static DistributedTransactionManagerName = null;
            static /*TimeSpan */ get Timeout()
            {
                return $.$stl.System.Transactions.Configuration.DefaultSettingsSection.s_timeout;
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_section = new $.$stl.System.Transactions.Configuration.DefaultSettingsSection().$ctor$1();
                }
                {
                    this.s_timeout = $.$spc.System.TimeSpan.Parse("00:01:00"/*ConfigurationStrings.DefaultTimeout*/);
                }
                {
                    this.DistributedTransactionManagerName = "";
                }
            }
            static $h = 763141;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":25770566917,"f":33},"s":{"r":0,"d":0,"h":30065534213,"f":33},"n":"DistributedTransactionManagerName","d":763141,"h":21475599621,"f":33},{"p":140705793,"g":{"r":0,"d":0,"h":38655468805,"f":33},"n":"Timeout","d":763141,"h":34360501509,"f":33}],"m":[{"r":763141,"n":"GetSection","d":763141,"h":12885665029,"f":40}],"l":[{"t":763141,"n":"s_section","d":763141,"h":4295730437,"f":34},{"t":140705793,"n":"s_timeout","d":763141,"h":8590697733,"f":34}],"c":[{"n":".ctor","o":"$ctor$1","d":763141,"h":42950436101,"f":1}],"h":763141}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Transactions.Configuration.DefaultSettingsSection`; }
        });
        
        $asm.$cls("$stl.System.Transactions.Configuration.MachineSettingsSection", ($self) => class MachineSettingsSection extends $.$spc.System.Object
        {
            /*MachineSettingsSection*/ static s_section = null;
            /*TimeSpan*/ static s_maxTimeout;
            static /*MachineSettingsSection */ GetSection()
            {
                return $.$stl.System.Transactions.Configuration.MachineSettingsSection.s_section;
            }
            static /*TimeSpan */ get MaxTimeout()
            {
                return $.$stl.System.Transactions.Configuration.MachineSettingsSection.s_maxTimeout;
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_section = new $.$stl.System.Transactions.Configuration.MachineSettingsSection().$ctor$1();
                }
                {
                    this.s_maxTimeout = $.$spc.System.TimeSpan.Parse("00:10:00"/*ConfigurationStrings.DefaultMaxTimeout*/);
                }
            }
            static $h = 828677;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":140705793,"g":{"r":0,"d":0,"h":21475665157,"f":33},"n":"MaxTimeout","d":828677,"h":17180697861,"f":33}],"m":[{"r":828677,"n":"GetSection","d":828677,"h":12885730565,"f":40}],"l":[{"t":828677,"n":"s_section","d":828677,"h":4295795973,"f":34},{"t":140705793,"n":"s_maxTimeout","d":828677,"h":8590763269,"f":34}],"c":[{"n":".ctor","o":"$ctor$1","d":828677,"h":25770632453,"f":1}],"h":828677}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Transactions.Configuration.MachineSettingsSection`; }
        });
        
        $asm.$cls("$stl.System.Obsoletions", ($self) => class Obsoletions
        {
            /*string*/ static SharedUrlFormat = null;
            /*string*/ static SystemTextEncodingUTF7Message = null;
            /*string*/ static SystemTextEncodingUTF7DiagId = null;
            /*string*/ static PrincipalPermissionAttributeMessage = null;
            /*string*/ static PrincipalPermissionAttributeDiagId = null;
            /*string*/ static CodeAccessSecurityMessage = null;
            /*string*/ static CodeAccessSecurityDiagId = null;
            /*string*/ static ConstrainedExecutionRegionMessage = null;
            /*string*/ static ConstrainedExecutionRegionDiagId = null;
            /*string*/ static GlobalAssemblyCacheMessage = null;
            /*string*/ static GlobalAssemblyCacheDiagId = null;
            /*string*/ static ThreadAbortMessage = null;
            /*string*/ static ThreadResetAbortMessage = null;
            /*string*/ static ThreadAbortDiagId = null;
            /*string*/ static DefaultCryptoAlgorithmsMessage = null;
            /*string*/ static DefaultCryptoAlgorithmsDiagId = null;
            /*string*/ static CreatePdbGeneratorMessage = null;
            /*string*/ static CreatePdbGeneratorDiagId = null;
            /*string*/ static AuthenticationManagerMessage = null;
            /*string*/ static AuthenticationManagerDiagId = null;
            /*string*/ static RemotingApisMessage = null;
            /*string*/ static RemotingApisDiagId = null;
            /*string*/ static BinaryFormatterMessage = null;
            /*string*/ static BinaryFormatterDiagId = null;
            /*string*/ static CodeBaseMessage = null;
            /*string*/ static CodeBaseDiagId = null;
            /*string*/ static EscapeUriStringMessage = null;
            /*string*/ static EscapeUriStringDiagId = null;
            /*string*/ static WebRequestMessage = null;
            /*string*/ static WebRequestDiagId = null;
            /*string*/ static DisablePrivateReflectionAttributeMessage = null;
            /*string*/ static DisablePrivateReflectionAttributeDiagId = null;
            /*string*/ static GetContextInfoMessage = null;
            /*string*/ static GetContextInfoDiagId = null;
            /*string*/ static StrongNameKeyPairMessage = null;
            /*string*/ static StrongNameKeyPairDiagId = null;
            /*string*/ static ReflectionOnlyLoadingMessage = null;
            /*string*/ static ReflectionOnlyLoadingDiagId = null;
            /*string*/ static RuntimeEnvironmentMessage = null;
            /*string*/ static RuntimeEnvironmentDiagId = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesMessage = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesDiagId = null;
            /*string*/ static DerivedCryptographicTypesMessage = null;
            /*string*/ static DerivedCryptographicTypesDiagId = null;
            /*string*/ static RijndaelMessage = null;
            /*string*/ static RijndaelDiagId = null;
            /*string*/ static RNGCryptoServiceProviderMessage = null;
            /*string*/ static RNGCryptoServiceProviderDiagId = null;
            /*string*/ static AppDomainCreateUnloadMessage = null;
            /*string*/ static AppDomainCreateUnloadDiagId = null;
            /*string*/ static SuppressIldasmAttributeMessage = null;
            /*string*/ static SuppressIldasmAttributeDiagId = null;
            /*string*/ static X509CertificateImmutableMessage = null;
            /*string*/ static X509CertificateImmutableDiagId = null;
            /*string*/ static PublicKeyPropertyMessage = null;
            /*string*/ static PublicKeyPropertyDiagId = null;
            /*string*/ static X509CertificatePrivateKeyMessage = null;
            /*string*/ static X509CertificatePrivateKeyDiagId = null;
            /*string*/ static ProduceLegacyHmacValuesMessage = null;
            /*string*/ static ProduceLegacyHmacValuesDiagId = null;
            /*string*/ static UseManagedSha1Message = null;
            /*string*/ static UseManagedSha1DiagId = null;
            /*string*/ static CryptoConfigEncodeOIDMessage = null;
            /*string*/ static CryptoConfigEncodeOIDDiagId = null;
            /*string*/ static CorruptedStateRecoveryMessage = null;
            /*string*/ static CorruptedStateRecoveryDiagId = null;
            /*string*/ static Rfc2898CryptDeriveKeyMessage = null;
            /*string*/ static Rfc2898CryptDeriveKeyDiagId = null;
            /*string*/ static CmsSignerCspParamsCtorMessage = null;
            /*string*/ static CmsSignerCspParamsCtorDiagId = null;
            /*string*/ static SignerInfoCounterSigMessage = null;
            /*string*/ static SignerInfoCounterSigDiagId = null;
            /*string*/ static RegexCompileToAssemblyMessage = null;
            /*string*/ static RegexCompileToAssemblyDiagId = null;
            /*string*/ static AssemblyNameMembersMessage = null;
            /*string*/ static AssemblyNameMembersDiagId = null;
            /*string*/ static SystemDataSerializationFormatBinaryMessage = null;
            /*string*/ static SystemDataSerializationFormatBinaryDiagId = null;
            /*string*/ static TlsVersion10and11Message = null;
            /*string*/ static TlsVersion10and11DiagId = null;
            /*string*/ static EncryptionPolicyMessage = null;
            /*string*/ static EncryptionPolicyDiagId = null;
            /*string*/ static EccXmlExportImportMessage = null;
            /*string*/ static EccXmlExportImportDiagId = null;
            /*string*/ static EcDhPublicKeyBlobMessage = null;
            /*string*/ static EcDhPublicKeyBlobDiagId = null;
            /*string*/ static AssemblyNameCodeBaseMessage = null;
            /*string*/ static AssemblyNameCodeBaseDiagId = null;
            /*string*/ static CryptoStringFactoryMessage = null;
            /*string*/ static CryptoStringFactoryDiagId = null;
            /*string*/ static ControlledExecutionRunMessage = null;
            /*string*/ static ControlledExecutionRunDiagId = null;
            /*string*/ static XmlSecureResolverMessage = null;
            /*string*/ static XmlSecureResolverDiagId = null;
            /*string*/ static RsaEncryptDecryptValueMessage = null;
            /*string*/ static RsaEncryptDecryptDiagId = null;
            /*string*/ static JsonSerializerOptionsAddContextMessage = null;
            /*string*/ static JsonSerializerOptionsAddContextDiagId = null;
            /*string*/ static LegacyFormatterMessage = null;
            /*string*/ static LegacyFormatterDiagId = null;
            /*string*/ static LegacyFormatterImplMessage = null;
            /*string*/ static LegacyFormatterImplDiagId = null;
            /*string*/ static RegexExtensibilityImplMessage = null;
            /*string*/ static RegexExtensibilityDiagId = null;
            /*string*/ static AesGcmTagConstructorMessage = null;
            /*string*/ static AesGcmTagConstructorDiagId = null;
            /*string*/ static ThreadVolatileReadWriteMessage = null;
            /*string*/ static ThreadVolatileReadWriteDiagId = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationMessage = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationDiagId = null;
            /*string*/ static LoadFromHashAlgorithmMessage = null;
            /*string*/ static LoadFromHashAlgorithmDiagId = null;
            /*string*/ static X509CtorCertDataObsoleteMessage = null;
            /*string*/ static X509CtorCertDataObsoleteDiagId = null;
            /*string*/ static TlsCipherAlgorithmEnumsMessage = null;
            /*string*/ static TlsCipherAlgorithmEnumsDiagId = null;
            /*string*/ static SystemEventsEventsThreadShutdownMessage = null;
            /*string*/ static SystemEventsEventsThreadShutdownDiagId = null;
            /*string*/ static Rfc2898DeriveBytesCtorMessage = null;
            /*string*/ static Rfc2898DeriveBytesCtorDiagId = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteMessage = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteDiagId = null;
            /*string*/ static XsltSettingsEnableScriptMessage = null;
            /*string*/ static XsltSettingsEnableScriptDiagId = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                }
                {
                    this.SystemTextEncodingUTF7Message = "The UTF-7 encoding is insecure and should not be used. Consider using UTF-8 instead.";
                }
                {
                    this.SystemTextEncodingUTF7DiagId = "SYSLIB0001";
                }
                {
                    this.PrincipalPermissionAttributeMessage = "PrincipalPermissionAttribute is not honored by the runtime and must not be used.";
                }
                {
                    this.PrincipalPermissionAttributeDiagId = "SYSLIB0002";
                }
                {
                    this.CodeAccessSecurityMessage = "Code Access Security is not supported or honored by the runtime.";
                }
                {
                    this.CodeAccessSecurityDiagId = "SYSLIB0003";
                }
                {
                    this.ConstrainedExecutionRegionMessage = "The Constrained Execution Region (CER) feature is not supported.";
                }
                {
                    this.ConstrainedExecutionRegionDiagId = "SYSLIB0004";
                }
                {
                    this.GlobalAssemblyCacheMessage = "The Global Assembly Cache is not supported.";
                }
                {
                    this.GlobalAssemblyCacheDiagId = "SYSLIB0005";
                }
                {
                    this.ThreadAbortMessage = "Thread.Abort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadResetAbortMessage = "Thread.ResetAbort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadAbortDiagId = "SYSLIB0006";
                }
                {
                    this.DefaultCryptoAlgorithmsMessage = "The default implementation of this cryptography algorithm is not supported.";
                }
                {
                    this.DefaultCryptoAlgorithmsDiagId = "SYSLIB0007";
                }
                {
                    this.CreatePdbGeneratorMessage = "The CreatePdbGenerator API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.CreatePdbGeneratorDiagId = "SYSLIB0008";
                }
                {
                    this.AuthenticationManagerMessage = "AuthenticationManager is not supported. Methods will no-op or throw PlatformNotSupportedException.";
                }
                {
                    this.AuthenticationManagerDiagId = "SYSLIB0009";
                }
                {
                    this.RemotingApisMessage = "This Remoting API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.RemotingApisDiagId = "SYSLIB0010";
                }
                {
                    this.BinaryFormatterMessage = "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.";
                }
                {
                    this.BinaryFormatterDiagId = "SYSLIB0011";
                }
                {
                    this.CodeBaseMessage = "Assembly.CodeBase and Assembly.EscapedCodeBase are only included for .NET Framework compatibility. Use Assembly.Location instead.";
                }
                {
                    this.CodeBaseDiagId = "SYSLIB0012";
                }
                {
                    this.EscapeUriStringMessage = "Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.";
                }
                {
                    this.EscapeUriStringDiagId = "SYSLIB0013";
                }
                {
                    this.WebRequestMessage = "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.";
                }
                {
                    this.WebRequestDiagId = "SYSLIB0014";
                }
                {
                    this.DisablePrivateReflectionAttributeMessage = "DisablePrivateReflectionAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.DisablePrivateReflectionAttributeDiagId = "SYSLIB0015";
                }
                {
                    this.GetContextInfoMessage = "Use the Graphics.GetContextInfo overloads that accept arguments for better performance and fewer allocations.";
                }
                {
                    this.GetContextInfoDiagId = "SYSLIB0016";
                }
                {
                    this.StrongNameKeyPairMessage = "Strong name signing is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.StrongNameKeyPairDiagId = "SYSLIB0017";
                }
                {
                    this.ReflectionOnlyLoadingMessage = "ReflectionOnly loading is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ReflectionOnlyLoadingDiagId = "SYSLIB0018";
                }
                {
                    this.RuntimeEnvironmentMessage = "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.";
                }
                {
                    this.RuntimeEnvironmentDiagId = "SYSLIB0019";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesMessage = "JsonSerializerOptions.IgnoreNullValues is obsolete. To ignore null values when serializing, set DefaultIgnoreCondition to JsonIgnoreCondition.WhenWritingNull.";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesDiagId = "SYSLIB0020";
                }
                {
                    this.DerivedCryptographicTypesMessage = "Derived cryptographic types are obsolete. Use the Create method on the base type instead.";
                }
                {
                    this.DerivedCryptographicTypesDiagId = "SYSLIB0021";
                }
                {
                    this.RijndaelMessage = "The Rijndael and RijndaelManaged types are obsolete. Use Aes instead.";
                }
                {
                    this.RijndaelDiagId = "SYSLIB0022";
                }
                {
                    this.RNGCryptoServiceProviderMessage = "RNGCryptoServiceProvider is obsolete. To generate a random number, use one of the RandomNumberGenerator static methods instead.";
                }
                {
                    this.RNGCryptoServiceProviderDiagId = "SYSLIB0023";
                }
                {
                    this.AppDomainCreateUnloadMessage = "Creating and unloading AppDomains is not supported and throws an exception.";
                }
                {
                    this.AppDomainCreateUnloadDiagId = "SYSLIB0024";
                }
                {
                    this.SuppressIldasmAttributeMessage = "SuppressIldasmAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.SuppressIldasmAttributeDiagId = "SYSLIB0025";
                }
                {
                    this.X509CertificateImmutableMessage = "X509Certificate and X509Certificate2 are immutable. Use X509CertificateLoader to create a new certificate.";
                }
                {
                    this.X509CertificateImmutableDiagId = "SYSLIB0026";
                }
                {
                    this.PublicKeyPropertyMessage = "PublicKey.Key is obsolete. Use the appropriate method to get the public key, such as GetRSAPublicKey.";
                }
                {
                    this.PublicKeyPropertyDiagId = "SYSLIB0027";
                }
                {
                    this.X509CertificatePrivateKeyMessage = "X509Certificate2.PrivateKey is obsolete. Use the appropriate method to get the private key, such as GetRSAPrivateKey, or use the CopyWithPrivateKey method to create a new instance with a private key.";
                }
                {
                    this.X509CertificatePrivateKeyDiagId = "SYSLIB0028";
                }
                {
                    this.ProduceLegacyHmacValuesMessage = "ProduceLegacyHmacValues is obsolete. Producing legacy HMAC values is not supported.";
                }
                {
                    this.ProduceLegacyHmacValuesDiagId = "SYSLIB0029";
                }
                {
                    this.UseManagedSha1Message = "HMACSHA1 always uses the algorithm implementation provided by the platform. Use a constructor without the useManagedSha1 parameter.";
                }
                {
                    this.UseManagedSha1DiagId = "SYSLIB0030";
                }
                {
                    this.CryptoConfigEncodeOIDMessage = "EncodeOID is obsolete. Use the ASN.1 functionality provided in System.Formats.Asn1.";
                }
                {
                    this.CryptoConfigEncodeOIDDiagId = "SYSLIB0031";
                }
                {
                    this.CorruptedStateRecoveryMessage = "Recovery from corrupted process state exceptions is not supported; HandleProcessCorruptedStateExceptionsAttribute is ignored.";
                }
                {
                    this.CorruptedStateRecoveryDiagId = "SYSLIB0032";
                }
                {
                    this.Rfc2898CryptDeriveKeyMessage = "Rfc2898DeriveBytes.CryptDeriveKey is obsolete and is not supported. Use PasswordDeriveBytes.CryptDeriveKey instead.";
                }
                {
                    this.Rfc2898CryptDeriveKeyDiagId = "SYSLIB0033";
                }
                {
                    this.CmsSignerCspParamsCtorMessage = "CmsSigner(CspParameters) is obsolete and is not supported. Use an alternative constructor instead.";
                }
                {
                    this.CmsSignerCspParamsCtorDiagId = "SYSLIB0034";
                }
                {
                    this.SignerInfoCounterSigMessage = "ComputeCounterSignature without specifying a CmsSigner is obsolete and is not supported. Use the overload that accepts a CmsSigner.";
                }
                {
                    this.SignerInfoCounterSigDiagId = "SYSLIB0035";
                }
                {
                    this.RegexCompileToAssemblyMessage = "Regex.CompileToAssembly is obsolete and not supported. Use the GeneratedRegexAttribute with the regular expression source generator instead.";
                }
                {
                    this.RegexCompileToAssemblyDiagId = "SYSLIB0036";
                }
                {
                    this.AssemblyNameMembersMessage = "AssemblyName members HashAlgorithm, ProcessorArchitecture, and VersionCompatibility are obsolete and not supported.";
                }
                {
                    this.AssemblyNameMembersDiagId = "SYSLIB0037";
                }
                {
                    this.SystemDataSerializationFormatBinaryMessage = "SerializationFormat.Binary is obsolete and should not be used. See https://aka.ms/serializationformat-binary-obsolete for more information.";
                }
                {
                    this.SystemDataSerializationFormatBinaryDiagId = "SYSLIB0038";
                }
                {
                    this.TlsVersion10and11Message = "TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.";
                }
                {
                    this.TlsVersion10and11DiagId = "SYSLIB0039";
                }
                {
                    this.EncryptionPolicyMessage = "EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.";
                }
                {
                    this.EncryptionPolicyDiagId = "SYSLIB0040";
                }
                {
                    this.EccXmlExportImportMessage = "ToXmlString and FromXmlString have no implementation for ECC types, and are obsolete. Use a standard import and export format such as ExportSubjectPublicKeyInfo or ImportSubjectPublicKeyInfo for public keys and ExportPkcs8PrivateKey or ImportPkcs8PrivateKey for private keys.";
                }
                {
                    this.EccXmlExportImportDiagId = "SYSLIB0042";
                }
                {
                    this.EcDhPublicKeyBlobMessage = "ECDiffieHellmanPublicKey.ToByteArray() and the associated constructor do not have a consistent and interoperable implementation on all platforms. Use ECDiffieHellmanPublicKey.ExportSubjectPublicKeyInfo() instead.";
                }
                {
                    this.EcDhPublicKeyBlobDiagId = "SYSLIB0043";
                }
                {
                    this.AssemblyNameCodeBaseMessage = "AssemblyName.CodeBase and AssemblyName.EscapedCodeBase are obsolete. Using them for loading an assembly is not supported.";
                }
                {
                    this.AssemblyNameCodeBaseDiagId = "SYSLIB0044";
                }
                {
                    this.CryptoStringFactoryMessage = "Cryptographic factory methods accepting an algorithm name are obsolete. Use the parameterless Create factory method on the algorithm type instead.";
                }
                {
                    this.CryptoStringFactoryDiagId = "SYSLIB0045";
                }
                {
                    this.ControlledExecutionRunMessage = "ControlledExecution.Run method may corrupt the process and should not be used in production code.";
                }
                {
                    this.ControlledExecutionRunDiagId = "SYSLIB0046";
                }
                {
                    this.XmlSecureResolverMessage = "XmlSecureResolver is obsolete. Use XmlResolver.ThrowingResolver instead when attempting to forbid XML external entity resolution.";
                }
                {
                    this.XmlSecureResolverDiagId = "SYSLIB0047";
                }
                {
                    this.RsaEncryptDecryptValueMessage = "RSA.EncryptValue and DecryptValue are not supported and throw NotSupportedException. Use RSA.Encrypt and RSA.Decrypt instead.";
                }
                {
                    this.RsaEncryptDecryptDiagId = "SYSLIB0048";
                }
                {
                    this.JsonSerializerOptionsAddContextMessage = "JsonSerializerOptions.AddContext is obsolete. To register a JsonSerializerContext, use either the TypeInfoResolver or TypeInfoResolverChain properties.";
                }
                {
                    this.JsonSerializerOptionsAddContextDiagId = "SYSLIB0049";
                }
                {
                    this.LegacyFormatterMessage = "Formatter-based serialization is obsolete and should not be used.";
                }
                {
                    this.LegacyFormatterDiagId = "SYSLIB0050";
                }
                {
                    this.LegacyFormatterImplMessage = "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.";
                }
                {
                    this.LegacyFormatterImplDiagId = "SYSLIB0051";
                }
                {
                    this.RegexExtensibilityImplMessage = "This API supports obsolete mechanisms for Regex extensibility. It is not supported.";
                }
                {
                    this.RegexExtensibilityDiagId = "SYSLIB0052";
                }
                {
                    this.AesGcmTagConstructorMessage = "AesGcm should indicate the required tag size for encryption and decryption. Use a constructor that accepts the tag size.";
                }
                {
                    this.AesGcmTagConstructorDiagId = "SYSLIB0053";
                }
                {
                    this.ThreadVolatileReadWriteMessage = "Thread.VolatileRead and Thread.VolatileWrite are obsolete. Use Volatile.Read or Volatile.Write respectively instead.";
                }
                {
                    this.ThreadVolatileReadWriteDiagId = "SYSLIB0054";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationMessage = "The underlying hardware instruction does not perform a signed saturate narrowing operation, and it always returns an unsigned result. Use the unsigned overload instead.";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationDiagId = "SYSLIB0055";
                }
                {
                    this.LoadFromHashAlgorithmMessage = "LoadFrom with a custom AssemblyHashAlgorithm is obsolete. Use overloads without an AssemblyHashAlgorithm.";
                }
                {
                    this.LoadFromHashAlgorithmDiagId = "SYSLIB0056";
                }
                {
                    this.X509CtorCertDataObsoleteMessage = "Loading certificate data through the constructor or Import is obsolete. Use X509CertificateLoader instead to load certificates.";
                }
                {
                    this.X509CtorCertDataObsoleteDiagId = "SYSLIB0057";
                }
                {
                    this.TlsCipherAlgorithmEnumsMessage = "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.";
                }
                {
                    this.TlsCipherAlgorithmEnumsDiagId = "SYSLIB0058";
                }
                {
                    this.SystemEventsEventsThreadShutdownMessage = "SystemEvents.EventsThreadShutdown callbacks are not run before the process exits. Use AppDomain.ProcessExit instead.";
                }
                {
                    this.SystemEventsEventsThreadShutdownDiagId = "SYSLIB0059";
                }
                {
                    this.Rfc2898DeriveBytesCtorMessage = "The constructors on Rfc2898DeriveBytes are obsolete. Use the static Pbkdf2 method instead.";
                }
                {
                    this.Rfc2898DeriveBytesCtorDiagId = "SYSLIB0060";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteMessage = "The Queryable MinBy and MaxBy taking an IComparer<TSource> are obsolete. Use the new ones that take an IComparer<TKey>.";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteDiagId = "SYSLIB0061";
                }
                {
                    this.XsltSettingsEnableScriptMessage = "XSLT Script blocks are not supported.";
                }
                {
                    this.XsltSettingsEnableScriptDiagId = "SYSLIB0062";
                }
            }
            static $h = 107781;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"SharedUrlFormat","d":107781,"h":4295075077,"f":40},{"t":1310721,"n":"SystemTextEncodingUTF7Message","d":107781,"h":8590042373,"f":40},{"t":1310721,"n":"SystemTextEncodingUTF7DiagId","d":107781,"h":12885009669,"f":40},{"t":1310721,"n":"PrincipalPermissionAttributeMessage","d":107781,"h":17179976965,"f":40},{"t":1310721,"n":"PrincipalPermissionAttributeDiagId","d":107781,"h":21474944261,"f":40},{"t":1310721,"n":"CodeAccessSecurityMessage","d":107781,"h":25769911557,"f":40},{"t":1310721,"n":"CodeAccessSecurityDiagId","d":107781,"h":30064878853,"f":40},{"t":1310721,"n":"ConstrainedExecutionRegionMessage","d":107781,"h":34359846149,"f":40},{"t":1310721,"n":"ConstrainedExecutionRegionDiagId","d":107781,"h":38654813445,"f":40},{"t":1310721,"n":"GlobalAssemblyCacheMessage","d":107781,"h":42949780741,"f":40},{"t":1310721,"n":"GlobalAssemblyCacheDiagId","d":107781,"h":47244748037,"f":40},{"t":1310721,"n":"ThreadAbortMessage","d":107781,"h":51539715333,"f":40},{"t":1310721,"n":"ThreadResetAbortMessage","d":107781,"h":55834682629,"f":40},{"t":1310721,"n":"ThreadAbortDiagId","d":107781,"h":60129649925,"f":40},{"t":1310721,"n":"DefaultCryptoAlgorithmsMessage","d":107781,"h":64424617221,"f":40},{"t":1310721,"n":"DefaultCryptoAlgorithmsDiagId","d":107781,"h":68719584517,"f":40},{"t":1310721,"n":"CreatePdbGeneratorMessage","d":107781,"h":73014551813,"f":40},{"t":1310721,"n":"CreatePdbGeneratorDiagId","d":107781,"h":77309519109,"f":40},{"t":1310721,"n":"AuthenticationManagerMessage","d":107781,"h":81604486405,"f":40},{"t":1310721,"n":"AuthenticationManagerDiagId","d":107781,"h":85899453701,"f":40},{"t":1310721,"n":"RemotingApisMessage","d":107781,"h":90194420997,"f":40},{"t":1310721,"n":"RemotingApisDiagId","d":107781,"h":94489388293,"f":40},{"t":1310721,"n":"BinaryFormatterMessage","d":107781,"h":98784355589,"f":40},{"t":1310721,"n":"BinaryFormatterDiagId","d":107781,"h":103079322885,"f":40},{"t":1310721,"n":"CodeBaseMessage","d":107781,"h":107374290181,"f":40},{"t":1310721,"n":"CodeBaseDiagId","d":107781,"h":111669257477,"f":40},{"t":1310721,"n":"EscapeUriStringMessage","d":107781,"h":115964224773,"f":40},{"t":1310721,"n":"EscapeUriStringDiagId","d":107781,"h":120259192069,"f":40},{"t":1310721,"n":"WebRequestMessage","d":107781,"h":124554159365,"f":40},{"t":1310721,"n":"WebRequestDiagId","d":107781,"h":128849126661,"f":40},{"t":1310721,"n":"DisablePrivateReflectionAttributeMessage","d":107781,"h":133144093957,"f":40},{"t":1310721,"n":"DisablePrivateReflectionAttributeDiagId","d":107781,"h":137439061253,"f":40},{"t":1310721,"n":"GetContextInfoMessage","d":107781,"h":141734028549,"f":40},{"t":1310721,"n":"GetContextInfoDiagId","d":107781,"h":146028995845,"f":40},{"t":1310721,"n":"StrongNameKeyPairMessage","d":107781,"h":150323963141,"f":40},{"t":1310721,"n":"StrongNameKeyPairDiagId","d":107781,"h":154618930437,"f":40},{"t":1310721,"n":"ReflectionOnlyLoadingMessage","d":107781,"h":158913897733,"f":40},{"t":1310721,"n":"ReflectionOnlyLoadingDiagId","d":107781,"h":163208865029,"f":40},{"t":1310721,"n":"RuntimeEnvironmentMessage","d":107781,"h":167503832325,"f":40},{"t":1310721,"n":"RuntimeEnvironmentDiagId","d":107781,"h":171798799621,"f":40},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesMessage","d":107781,"h":176093766917,"f":40},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesDiagId","d":107781,"h":180388734213,"f":40},{"t":1310721,"n":"DerivedCryptographicTypesMessage","d":107781,"h":184683701509,"f":40},{"t":1310721,"n":"DerivedCryptographicTypesDiagId","d":107781,"h":188978668805,"f":40},{"t":1310721,"n":"RijndaelMessage","d":107781,"h":193273636101,"f":40},{"t":1310721,"n":"RijndaelDiagId","d":107781,"h":197568603397,"f":40},{"t":1310721,"n":"RNGCryptoServiceProviderMessage","d":107781,"h":201863570693,"f":40},{"t":1310721,"n":"RNGCryptoServiceProviderDiagId","d":107781,"h":206158537989,"f":40},{"t":1310721,"n":"AppDomainCreateUnloadMessage","d":107781,"h":210453505285,"f":40},{"t":1310721,"n":"AppDomainCreateUnloadDiagId","d":107781,"h":214748472581,"f":40},{"t":1310721,"n":"SuppressIldasmAttributeMessage","d":107781,"h":219043439877,"f":40},{"t":1310721,"n":"SuppressIldasmAttributeDiagId","d":107781,"h":223338407173,"f":40},{"t":1310721,"n":"X509CertificateImmutableMessage","d":107781,"h":227633374469,"f":40},{"t":1310721,"n":"X509CertificateImmutableDiagId","d":107781,"h":231928341765,"f":40},{"t":1310721,"n":"PublicKeyPropertyMessage","d":107781,"h":236223309061,"f":40},{"t":1310721,"n":"PublicKeyPropertyDiagId","d":107781,"h":240518276357,"f":40},{"t":1310721,"n":"X509CertificatePrivateKeyMessage","d":107781,"h":244813243653,"f":40},{"t":1310721,"n":"X509CertificatePrivateKeyDiagId","d":107781,"h":249108210949,"f":40},{"t":1310721,"n":"ProduceLegacyHmacValuesMessage","d":107781,"h":253403178245,"f":40},{"t":1310721,"n":"ProduceLegacyHmacValuesDiagId","d":107781,"h":257698145541,"f":40},{"t":1310721,"n":"UseManagedSha1Message","d":107781,"h":261993112837,"f":40},{"t":1310721,"n":"UseManagedSha1DiagId","d":107781,"h":266288080133,"f":40},{"t":1310721,"n":"CryptoConfigEncodeOIDMessage","d":107781,"h":270583047429,"f":40},{"t":1310721,"n":"CryptoConfigEncodeOIDDiagId","d":107781,"h":274878014725,"f":40},{"t":1310721,"n":"CorruptedStateRecoveryMessage","d":107781,"h":279172982021,"f":40},{"t":1310721,"n":"CorruptedStateRecoveryDiagId","d":107781,"h":283467949317,"f":40},{"t":1310721,"n":"Rfc2898CryptDeriveKeyMessage","d":107781,"h":287762916613,"f":40},{"t":1310721,"n":"Rfc2898CryptDeriveKeyDiagId","d":107781,"h":292057883909,"f":40},{"t":1310721,"n":"CmsSignerCspParamsCtorMessage","d":107781,"h":296352851205,"f":40},{"t":1310721,"n":"CmsSignerCspParamsCtorDiagId","d":107781,"h":300647818501,"f":40},{"t":1310721,"n":"SignerInfoCounterSigMessage","d":107781,"h":304942785797,"f":40},{"t":1310721,"n":"SignerInfoCounterSigDiagId","d":107781,"h":309237753093,"f":40},{"t":1310721,"n":"RegexCompileToAssemblyMessage","d":107781,"h":313532720389,"f":40},{"t":1310721,"n":"RegexCompileToAssemblyDiagId","d":107781,"h":317827687685,"f":40},{"t":1310721,"n":"AssemblyNameMembersMessage","d":107781,"h":322122654981,"f":40},{"t":1310721,"n":"AssemblyNameMembersDiagId","d":107781,"h":326417622277,"f":40},{"t":1310721,"n":"SystemDataSerializationFormatBinaryMessage","d":107781,"h":330712589573,"f":40},{"t":1310721,"n":"SystemDataSerializationFormatBinaryDiagId","d":107781,"h":335007556869,"f":40},{"t":1310721,"n":"TlsVersion10and11Message","d":107781,"h":339302524165,"f":40},{"t":1310721,"n":"TlsVersion10and11DiagId","d":107781,"h":343597491461,"f":40},{"t":1310721,"n":"EncryptionPolicyMessage","d":107781,"h":347892458757,"f":40},{"t":1310721,"n":"EncryptionPolicyDiagId","d":107781,"h":352187426053,"f":40},{"t":1310721,"n":"EccXmlExportImportMessage","d":107781,"h":356482393349,"f":40},{"t":1310721,"n":"EccXmlExportImportDiagId","d":107781,"h":360777360645,"f":40},{"t":1310721,"n":"EcDhPublicKeyBlobMessage","d":107781,"h":365072327941,"f":40},{"t":1310721,"n":"EcDhPublicKeyBlobDiagId","d":107781,"h":369367295237,"f":40},{"t":1310721,"n":"AssemblyNameCodeBaseMessage","d":107781,"h":373662262533,"f":40},{"t":1310721,"n":"AssemblyNameCodeBaseDiagId","d":107781,"h":377957229829,"f":40},{"t":1310721,"n":"CryptoStringFactoryMessage","d":107781,"h":382252197125,"f":40},{"t":1310721,"n":"CryptoStringFactoryDiagId","d":107781,"h":386547164421,"f":40},{"t":1310721,"n":"ControlledExecutionRunMessage","d":107781,"h":390842131717,"f":40},{"t":1310721,"n":"ControlledExecutionRunDiagId","d":107781,"h":395137099013,"f":40},{"t":1310721,"n":"XmlSecureResolverMessage","d":107781,"h":399432066309,"f":40},{"t":1310721,"n":"XmlSecureResolverDiagId","d":107781,"h":403727033605,"f":40},{"t":1310721,"n":"RsaEncryptDecryptValueMessage","d":107781,"h":408022000901,"f":40},{"t":1310721,"n":"RsaEncryptDecryptDiagId","d":107781,"h":412316968197,"f":40},{"t":1310721,"n":"JsonSerializerOptionsAddContextMessage","d":107781,"h":416611935493,"f":40},{"t":1310721,"n":"JsonSerializerOptionsAddContextDiagId","d":107781,"h":420906902789,"f":40},{"t":1310721,"n":"LegacyFormatterMessage","d":107781,"h":425201870085,"f":40},{"t":1310721,"n":"LegacyFormatterDiagId","d":107781,"h":429496837381,"f":40},{"t":1310721,"n":"LegacyFormatterImplMessage","d":107781,"h":433791804677,"f":40},{"t":1310721,"n":"LegacyFormatterImplDiagId","d":107781,"h":438086771973,"f":40},{"t":1310721,"n":"RegexExtensibilityImplMessage","d":107781,"h":442381739269,"f":40},{"t":1310721,"n":"RegexExtensibilityDiagId","d":107781,"h":446676706565,"f":40},{"t":1310721,"n":"AesGcmTagConstructorMessage","d":107781,"h":450971673861,"f":40},{"t":1310721,"n":"AesGcmTagConstructorDiagId","d":107781,"h":455266641157,"f":40},{"t":1310721,"n":"ThreadVolatileReadWriteMessage","d":107781,"h":459561608453,"f":40},{"t":1310721,"n":"ThreadVolatileReadWriteDiagId","d":107781,"h":463856575749,"f":40},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationMessage","d":107781,"h":468151543045,"f":40},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationDiagId","d":107781,"h":472446510341,"f":40},{"t":1310721,"n":"LoadFromHashAlgorithmMessage","d":107781,"h":476741477637,"f":40},{"t":1310721,"n":"LoadFromHashAlgorithmDiagId","d":107781,"h":481036444933,"f":40},{"t":1310721,"n":"X509CtorCertDataObsoleteMessage","d":107781,"h":485331412229,"f":40},{"t":1310721,"n":"X509CtorCertDataObsoleteDiagId","d":107781,"h":489626379525,"f":40},{"t":1310721,"n":"TlsCipherAlgorithmEnumsMessage","d":107781,"h":493921346821,"f":40},{"t":1310721,"n":"TlsCipherAlgorithmEnumsDiagId","d":107781,"h":498216314117,"f":40},{"t":1310721,"n":"SystemEventsEventsThreadShutdownMessage","d":107781,"h":502511281413,"f":40},{"t":1310721,"n":"SystemEventsEventsThreadShutdownDiagId","d":107781,"h":506806248709,"f":40},{"t":1310721,"n":"Rfc2898DeriveBytesCtorMessage","d":107781,"h":511101216005,"f":40},{"t":1310721,"n":"Rfc2898DeriveBytesCtorDiagId","d":107781,"h":515396183301,"f":40},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteMessage","d":107781,"h":519691150597,"f":40},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteDiagId","d":107781,"h":523986117893,"f":40},{"t":1310721,"n":"XsltSettingsEnableScriptMessage","d":107781,"h":528281085189,"f":40},{"t":1310721,"n":"XsltSettingsEnableScriptDiagId","d":107781,"h":532576052485,"f":40}],"h":107781}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Obsoletions`; }
        });
        
        $asm.$cls("$stl.System.Transactions.Oletx.OletxTransactionManager", ($self) => class OletxTransactionManager extends $.$spc.System.Object
        {
            /*object?*/ NodeName = null;
            $ctor$1(/*string*/ nodeName)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*IPromotedEnlistment */ ReenlistTransaction(/*Guid*/ resourceManagerIdentifier, /*byte[]*/ resourceManagerRecoveryInformation, /*RecoveringInternalEnlistment*/ internalEnlistment)
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransactionManager.NotSupported();
            }
            /*OletxCommittableTransaction */ CreateTransaction(/*TransactionOptions*/ options)
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransactionManager.NotSupported();
            }
            /*void */ ResourceManagerRecoveryComplete(/*Guid*/ resourceManagerIdentifier)
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransactionManager.NotSupported();
            }
            static /*byte[] */ GetWhereabouts()
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransactionManager.NotSupported();
            }
            static /*Transaction */ GetTransactionFromDtcTransaction(/*IDtcTransaction*/ transactionNative)
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransactionManager.NotSupported();
            }
            static /*OletxTransaction */ GetTransactionFromExportCookie(/*byte[]*/ cookie, /*Guid*/ txId)
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransactionManager.NotSupported();
            }
            static /*OletxTransaction */ GetOletxTransactionFromTransmitterPropagationToken(/*byte[]*/ propagationToken)
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransactionManager.NotSupported();
            }
            static /*Exception */ NotSupported()
            {
                return new $.$spc.System.PlatformNotSupportedException().$ctor$14($.$stl.System.SR.DistributedNotSupported);
            }
            static $h = 3646725;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":131073,"g":{"r":0,"d":0,"h":12888548613,"f":8},"s":{"r":0,"d":0,"h":17183515909,"f":8},"n":"NodeName","d":3646725,"h":8593581317,"f":8}],"m":[{"r":2925829,"p":[{"n":"resourceManagerIdentifier","p":56229889},{"n":"resourceManagerRecoveryInformation","p":0},{"n":"internalEnlistment","p":4039941}],"n":"ReenlistTransaction","d":3646725,"h":25773450501,"f":8},{"r":3384581,"p":[{"n":"options","p":5022981}],"n":"CreateTransaction","d":3646725,"h":30068417797,"f":8},{"r":65537,"p":[{"n":"resourceManagerIdentifier","p":56229889}],"n":"ResourceManagerRecoveryComplete","d":3646725,"h":34363385093,"f":8},{"r":0,"n":"GetWhereabouts","d":3646725,"h":38658352389,"f":40},{"r":4302085,"p":[{"n":"transactionNative","p":2532613}],"n":"GetTransactionFromDtcTransaction","d":3646725,"h":42953319685,"f":40},{"r":3515653,"p":[{"n":"cookie","p":0},{"n":"txId","p":56229889}],"n":"GetTransactionFromExportCookie","d":3646725,"h":47248286981,"f":40},{"r":3515653,"p":[{"n":"propagationToken","p":0}],"n":"GetOletxTransactionFromTransmitterPropagationToken","d":3646725,"h":51543254277,"f":40},{"r":47251457,"n":"NotSupported","d":3646725,"h":55838221573,"f":40}],"c":[{"p":[{"n":"nodeName","p":1310721}],"n":".ctor","o":"$ctor$1","d":3646725,"h":21478483205,"f":8}],"h":3646725}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Transactions.Oletx.OletxTransactionManager`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionInterop", ($self) => class TransactionInterop
        {
            static /*OletxTransaction */ ConvertToOletxTransaction(/*Transaction*/ transaction)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(transaction, "transaction");
                $.$spc.System.ObjectDisposedException.ThrowIf(transaction.Disposed, transaction);
                if (transaction._complete)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateTransactionCompletedException(transaction.DistributedTxId);
                }
                /*OletxTransaction?*/ let distributedTx = transaction.Promote();
                if (distributedTx === null)
                {
                    throw $.$stl.System.Transactions.Oletx.OletxTransaction.NotSupported();
                }
                return distributedTx;
            }
            /*Guid*/ static PromoterTypeDtc;
            static /*byte[] */ GetExportCookie(/*Transaction*/ transaction, /*byte[]*/ whereabouts)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(transaction, "transaction");
                $.$spc.System.ArgumentNullException.ThrowIfNull(whereabouts, "whereabouts");
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetExportCookie");
                }
                /*var*/ let whereaboutsCopy = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [whereabouts.length], null);
                $.$spc.System.Buffer.BlockCopy(whereabouts, 0, whereaboutsCopy, 0, whereabouts.length);
                $.$stl.System.Transactions.TransactionInterop.ConvertToOletxTransaction(transaction);
                /*byte[]*/ let cookie = $.$stl.System.Transactions.Oletx.OletxTransaction.GetExportCookie(whereaboutsCopy);
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetExportCookie");
                }
                return cookie;
            }
            static /*Transaction */ GetTransactionFromExportCookie(/*byte[]*/ cookie)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(cookie, "cookie");
                if (cookie.length < 32)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$stl.System.SR.InvalidArgument, "cookie");
                }
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetTransactionFromExportCookie");
                }
                /*var*/ let cookieCopy = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [cookie.length], null);
                $.$spc.System.Buffer.BlockCopy(cookie, 0, cookieCopy, 0, cookie.length);
                cookie = cookieCopy;
                /*var*/ let txId = new $.$spc.System.Guid().$ctor$3($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.Byte, cookie, 16, 16)));
                /*Transaction?*/ let transaction = $.$stl.System.Transactions.TransactionManager.FindPromotedTransaction(txId);
                if ($.$stl.System.Transactions.Transaction.op_Inequality(transaction, null))
                {
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodExit$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetTransactionFromExportCookie");
                    }
                    return transaction;
                }
                /*OletxTransaction*/ let dTx = $.$stl.System.Transactions.Oletx.OletxTransactionManager.GetTransactionFromExportCookie(cookieCopy, txId);
                transaction = $.$stl.System.Transactions.TransactionManager.FindOrCreatePromotedTransaction(txId, dTx);
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetTransactionFromExportCookie");
                }
                return transaction;
            }
            static /*byte[] */ GetTransmitterPropagationToken(/*Transaction*/ transaction)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(transaction, "transaction");
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetTransmitterPropagationToken");
                }
                $.$stl.System.Transactions.TransactionInterop.ConvertToOletxTransaction(transaction);
                /*byte[]*/ let token = $.$stl.System.Transactions.Oletx.OletxTransaction.GetTransmitterPropagationToken();
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetTransmitterPropagationToken");
                }
                return token;
            }
            static /*Transaction */ GetTransactionFromTransmitterPropagationToken(/*byte[]*/ propagationToken)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(propagationToken, "propagationToken");
                if (propagationToken.length < 24)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$stl.System.SR.InvalidArgument, "propagationToken");
                }
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetTransactionFromTransmitterPropagationToken");
                }
                /*var*/ let txId = new $.$spc.System.Guid().$ctor$3($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.Byte, propagationToken, 8, 16)));
                /*Transaction?*/ let tx = $.$stl.System.Transactions.TransactionManager.FindPromotedTransaction(txId);
                if ($.$stl.System.Transactions.Transaction.op_Inequality(null, tx))
                {
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodExit$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetTransactionFromTransmitterPropagationToken");
                    }
                    return tx;
                }
                /*OletxTransaction*/ let dTx = $.$stl.System.Transactions.TransactionInterop.GetOletxTransactionFromTransmitterPropagationToken(propagationToken);
                /*Transaction*/ let returnValue = $.$stl.System.Transactions.TransactionManager.FindOrCreatePromotedTransaction(txId, dTx);
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetTransactionFromTransmitterPropagationToken");
                }
                return returnValue;
            }
            static /*IDtcTransaction */ GetDtcTransaction(/*Transaction*/ transaction)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(transaction, "transaction");
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetDtcTransaction");
                }
                $.$stl.System.Transactions.TransactionInterop.ConvertToOletxTransaction(transaction);
                /*IDtcTransaction*/ let transactionNative = $.$stl.System.Transactions.Oletx.OletxTransaction.GetDtcTransaction();
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetDtcTransaction");
                }
                return transactionNative;
            }
            static /*Transaction */ GetTransactionFromDtcTransaction(/*IDtcTransaction*/ transactionNative)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(transactionNative, "transactionNative");
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetTransactionFromDtcTransaction");
                }
                /*Transaction*/ let transaction = $.$stl.System.Transactions.Oletx.OletxTransactionManager.GetTransactionFromDtcTransaction(transactionNative);
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetTransactionFromDtcTransaction");
                }
                return transaction;
            }
            static /*byte[] */ GetWhereabouts()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetWhereabouts");
                }
                /*byte[]*/ let returnValue = $.$stl.System.Transactions.Oletx.OletxTransactionManager.GetWhereabouts();
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetWhereabouts");
                }
                return returnValue;
            }
            static /*OletxTransaction */ GetOletxTransactionFromTransmitterPropagationToken(/*byte[]*/ propagationToken)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(propagationToken, "propagationToken");
                if (propagationToken.length < 24)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$stl.System.SR.InvalidArgument, "propagationToken");
                }
                /*byte[]*/ let propagationTokenCopy = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [propagationToken.length], null);
                $.$spc.System.Array.Copy(propagationToken, propagationTokenCopy, propagationToken.length);
                return $.$stl.System.Transactions.Oletx.OletxTransactionManager.GetOletxTransactionFromTransmitterPropagationToken(propagationTokenCopy);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.PromoterTypeDtc = new $.$spc.System.Guid().$ctor$8("14229753-FFE1-428D-82B7-DF73045CB8DA");
                }
            }
            static $h = 4826373;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":3515653,"p":[{"n":"transaction","p":4302085}],"n":"ConvertToOletxTransaction","d":4826373,"h":4299793669,"f":40},{"r":0,"p":[{"n":"transaction","p":4302085},{"n":"whereabouts","p":0}],"n":"GetExportCookie","d":4826373,"h":12889728261,"f":33},{"r":4302085,"p":[{"n":"cookie","p":0}],"n":"GetTransactionFromExportCookie","d":4826373,"h":17184695557,"f":33},{"r":0,"p":[{"n":"transaction","p":4302085}],"n":"GetTransmitterPropagationToken","d":4826373,"h":21479662853,"f":33},{"r":4302085,"p":[{"n":"propagationToken","p":0}],"n":"GetTransactionFromTransmitterPropagationToken","d":4826373,"h":25774630149,"f":33},{"r":2532613,"p":[{"n":"transaction","p":4302085}],"n":"GetDtcTransaction","d":4826373,"h":30069597445,"f":33},{"r":4302085,"p":[{"n":"transactionNative","p":2532613}],"n":"GetTransactionFromDtcTransaction","d":4826373,"h":34364564741,"f":33},{"r":0,"n":"GetWhereabouts","d":4826373,"h":38659532037,"f":33},{"r":3515653,"p":[{"n":"propagationToken","p":0}],"n":"GetOletxTransactionFromTransmitterPropagationToken","d":4826373,"h":42954499333,"f":40}],"l":[{"t":56229889,"n":"PromoterTypeDtc","d":4826373,"h":8594760965,"f":33}],"h":4826373}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Transactions.TransactionInterop`; }
        });
        
        $asm.$cls("$stl.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$stl.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("System.Transactions.Local", $.$stl.System.SR.$type.Assembly);
                    $.$stl.System.SR.s_resourceManager = temp;
                }
                return $.$stl.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$stl.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$stl.System.SR.resourceCulture = value;
            }
            static /*string */ get AsyncFlowAndESInteropNotSupported()
            {
                return "TransactionScope with TransactionScopeAsyncFlowOption.Enabled option is not supported when the TransactionScope is used within Enterprise Service context with Automatic or Full EnterpriseServicesInteropOption enabled in parent scope.";
            }
            static /*string */ get BadAsyncResult()
            {
                return "The IAsyncResult parameter must be the same parameter returned by BeginCommit.";
            }
            static /*string */ get BadResourceManagerId()
            {
                return "Resource Manager Identifiers cannot be Guid.Empty.";
            }
            static /*string */ get CannotPromoteSnapshot()
            {
                return "Transactions with IsolationLevel Snapshot cannot be promoted.";
            }
            static /*string */ get CannotSetCurrent()
            {
                return "Current cannot be set directly when Com+ Interop is enabled.";
            }
            static /*string */ get CurrentDelegateSet()
            {
                return "The delegate for an external current can only be set once.";
            }
            static /*string */ get DisposeScope()
            {
                return "The current TransactionScope is already complete. You should dispose the TransactionScope.";
            }
            static /*string */ get EnlistmentStateException()
            {
                return "The operation is not valid for the current state of the enlistment.";
            }
            static /*string */ get EsNotSupported()
            {
                return "Com+ Interop features cannot be supported.";
            }
            static /*string */ get InternalError()
            {
                return "Internal Error";
            }
            static /*string */ get InvalidArgument()
            {
                return "The argument is invalid.";
            }
            static /*string */ get InvalidIPromotableSinglePhaseNotificationSpecified()
            {
                return "The specified IPromotableSinglePhaseNotification is not the same as the one provided to EnlistPromotableSinglePhase.";
            }
            static /*string */ get InvalidRecoveryInformation()
            {
                return "Transaction Manager in the Recovery Information does not match the configured transaction manager.";
            }
            static /*string */ get InvalidScopeThread()
            {
                return "A TransactionScope must be disposed on the same thread that it was created.";
            }
            static /*string */ get PromotionFailed()
            {
                return "There was an error promoting the transaction to a distributed transaction.";
            }
            static /*string */ get PromotedReturnedInvalidValue()
            {
                return "The Promote method returned an invalid value for the distributed transaction.";
            }
            static /*string */ get PromotedTransactionExists()
            {
                return "The transaction returned from Promote already exists as a distributed transaction.";
            }
            static /*string */ get TooLate()
            {
                return "It is too late to add enlistments to this transaction.";
            }
            static /*string */ get TraceTransactionTimeout()
            {
                return "Transaction Timeout";
            }
            static /*string */ get TransactionAborted()
            {
                return "The transaction has aborted.";
            }
            static /*string */ get TransactionAlreadyCompleted()
            {
                return "DependentTransaction.Complete or CommittableTransaction.Commit has already been called for this transaction.";
            }
            static /*string */ get TransactionIndoubt()
            {
                return "The transaction is in doubt.";
            }
            static /*string */ get TransactionManagerCommunicationException()
            {
                return "Communication with the underlying transaction manager has failed.";
            }
            static /*string */ get TransactionScopeComplete()
            {
                return "The current TransactionScope is already complete.";
            }
            static /*string */ get TransactionScopeIncorrectCurrent()
            {
                return "Transaction.Current has changed inside of the TransactionScope.";
            }
            static /*string */ get TransactionScopeInvalidNesting()
            {
                return "TransactionScope nested incorrectly.";
            }
            static /*string */ get TransactionScopeIsolationLevelDifferentFromTransaction()
            {
                return "The transaction specified for TransactionScope has a different IsolationLevel than the value requested for the scope.";
            }
            static /*string */ get TransactionScopeTimerObjectInvalid()
            {
                return "TransactionScope timer object is invalid.";
            }
            static /*string */ get TransactionStateException()
            {
                return "The operation is not valid for the state of the transaction.";
            }
            static /*string */ get UnexpectedFailureOfThreadPool()
            {
                return "There was an unexpected failure of QueueUserWorkItem.";
            }
            static /*string */ get UnexpectedTimerFailure()
            {
                return "There was an unexpected failure of a timer.";
            }
            static /*string */ get UnrecognizedRecoveryInformation()
            {
                return "The RecoveryInformation provided is not recognized by this version of System.Transactions.";
            }
            static /*string */ get VolEnlistNoRecoveryInfo()
            {
                return "Volatile enlistments do not generate recovery information.";
            }
            static /*string */ get DistributedTxIDInTransactionException()
            {
                return "{0} Distributed Transaction ID is {1}";
            }
            static /*string */ FormatDistributedTxIDInTransactionException(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("{0} Distributed Transaction ID is {1}", arg1, arg2);
            }
            static /*string */ get PromoterTypeInvalid()
            {
                return "The specified PromoterType is invalid.";
            }
            static /*string */ get PromoterTypeUnrecognized()
            {
                return "There is a promotable enlistment for the transaction which has a PromoterType value that is not recognized by System.Transactions. {0}";
            }
            static /*string */ FormatPromoterTypeUnrecognized(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("There is a promotable enlistment for the transaction which has a PromoterType value that is not recognized by System.Transactions. {0}", arg1);
            }
            static /*string */ get DistributedNotSupported()
            {
                return "This platform does not support distributed transactions.";
            }
            static /*string */ get TraceSourceOletx()
            {
                return "[Distributed]";
            }
            static /*string */ get TraceConfiguredDefaultTimeoutAdjusted()
            {
                return "Configured DefaultTimeout is greater than configured DefaultMaximumTimeout - adjusting down to DefaultMaximumTimeout";
            }
            static /*string */ get TraceMethodEntered()
            {
                return "Method Entered";
            }
            static /*string */ get TraceMethodExited()
            {
                return "Method Exited";
            }
            static /*string */ get OperationInvalidOnAnEmptyDocument()
            {
                return "The operation is invalid because the document is empty.";
            }
            static /*string */ get CannotAddToClosedDocument()
            {
                return "Cannot add an element to a closed document.";
            }
            static /*string */ get TextNodeAlreadyPopulated()
            {
                return "The text node already has a value.";
            }
            static /*string */ get TraceEnlistment()
            {
                return "Enlistment Created";
            }
            static /*string */ get TraceTransactionPromoted()
            {
                return "Transaction Promoted";
            }
            static /*string */ get TraceEnlistmentNotificationCall()
            {
                return "Enlistment Notification Call";
            }
            static /*string */ get TraceEnlistmentCallbackPositive()
            {
                return "Enlistment Callback Positive";
            }
            static /*string */ get TraceEnlistmentCallbackNegative()
            {
                return "Enlistment Callback Negative";
            }
            static /*string */ get DocumentAlreadyClosed()
            {
                return "Cannot close an element on a closed document.";
            }
            static /*string */ get TraceInternalError()
            {
                return "Internal Error";
            }
            static /*string */ get TraceInvalidOperationException()
            {
                return "InvalidOperationException Thrown";
            }
            static /*string */ get TraceExceptionConsumed()
            {
                return "Exception Consumed";
            }
            static /*string */ get TraceTransactionException()
            {
                return "TransactionException Thrown";
            }
            static /*string */ get TraceTransactionDeserialized()
            {
                return "Transaction Deserialized";
            }
            static /*string */ get TraceTransactionSerialized()
            {
                return "Transaction Serialized";
            }
            static /*string */ get TraceTransactionManagerCreated()
            {
                return "Transaction Manager Instance Created";
            }
            static /*string */ get TraceReenlist()
            {
                return "TransactionManager.Reenlist Called";
            }
            static /*string */ get TraceTransactionCreated()
            {
                return "Transaction Created";
            }
            static /*string */ get TraceTransactionCommitCalled()
            {
                return "CommittableTransaction.Commit Called";
            }
            static /*string */ get TraceTransactionCommitted()
            {
                return "Transaction Committed";
            }
            static /*string */ get TraceTransactionAborted()
            {
                return "Transaction Aborted";
            }
            static /*string */ get TraceTransactionInDoubt()
            {
                return "Transaction InDoubt";
            }
            static /*string */ get TraceTransactionScopeCreated()
            {
                return "TransactionScope Created";
            }
            static /*string */ get TraceTransactionScopeDisposed()
            {
                return "TransactionScope Disposed";
            }
            static /*string */ get ProxyCannotSupportMultipleNodeNames()
            {
                return "MSDTC Proxy cannot support specification of different node names in the same process.";
            }
            static /*string */ get CannotSupportNodeNameSpecification()
            {
                return "Cannot support specification of node name for the distributed transaction manager through System.Transactions due to MSDTC Proxy version.";
            }
            static /*string */ get FailedToCreateTraceSource()
            {
                return "Failed to create trace source.";
            }
            static /*string */ get FailedToInitializeTraceSource()
            {
                return "Failed to initialize trace source.";
            }
            static /*string */ get TraceRecoveryComplete()
            {
                return "TransactionManager.RecoveryComplete Called";
            }
            static /*string */ get TraceCloneCreated()
            {
                return "Clone Created";
            }
            static /*string */ get TraceDependentCloneComplete()
            {
                return "Dependent Clone Completed";
            }
            static /*string */ get TraceDependentCloneCreated()
            {
                return "Dependent Clone Created";
            }
            static /*string */ get TraceTransactionScopeTimeout()
            {
                return "TransactionScope Timeout";
            }
            static /*string */ get TraceTransactionRollbackCalled()
            {
                return "Transaction.Rollback Called";
            }
            static /*string */ get TraceFailure()
            {
                return "Trace Event Type: {0}\\nTrace Code: {1}\\nTrace Description {2}\\nObject: {3}";
            }
            static /*string */ FormatTraceFailure(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3, /*object*/ arg4)
            {
                return $.$spc.System.String.Format$4("Trace Event Type: {0}\\nTrace Code: {1}\\nTrace Description {2}\\nObject: {3}", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ arg1, arg2, arg3, arg4 ]));
            }
            static /*string */ get OletxEnlistmentUnexpectedTransactionStatus()
            {
                return "Internal Error - Unexpected transaction status value in enlistment constructor.";
            }
            static /*string */ get UnableToDeserializeTransaction()
            {
                return "Unable to deserialize the transaction.";
            }
            static /*string */ get UnableToDeserializeTransactionInternalError()
            {
                return "Internal Error - Unable to deserialize the transaction.";
            }
            static /*string */ get TransactionAlreadyOver()
            {
                return "The transaction has already been implicitly or explicitly committed or aborted.";
            }
            static /*string */ get EventLogValue()
            {
                return "Process Name: {0}\\nProcess Id: {1}\\nCode: {2}\\nDescription: {3}";
            }
            static /*string */ FormatEventLogValue(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3, /*object*/ arg4)
            {
                return $.$spc.System.String.Format$4("Process Name: {0}\\nProcess Id: {1}\\nCode: {2}\\nDescription: {3}", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ arg1, arg2, arg3, arg4 ]));
            }
            static /*string */ get EventLogSourceValue()
            {
                return "Source: {0}";
            }
            static /*string */ FormatEventLogSourceValue(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Source: {0}", arg1);
            }
            static /*string */ get EventLogExceptionValue()
            {
                return "Exception: {0}";
            }
            static /*string */ FormatEventLogExceptionValue(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Exception: {0}", arg1);
            }
            static /*string */ get EventLogEventIdValue()
            {
                return "Event ID: {0}";
            }
            static /*string */ FormatEventLogEventIdValue(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Event ID: {0}", arg1);
            }
            static /*string */ get EventLogTraceValue()
            {
                return "Other information : {0}";
            }
            static /*string */ FormatEventLogTraceValue(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Other information : {0}", arg1);
            }
            static /*string */ get TraceTransactionScopeCurrentTransactionChanged()
            {
                return "TransactionScope Current Transaction Changed";
            }
            static /*string */ get TraceTransactionScopeNestedIncorrectly()
            {
                return "TransactionScope Nested Incorrectly";
            }
            static /*string */ get TraceTransactionScopeIncomplete()
            {
                return "TransactionScope Incomplete";
            }
            static /*string */ get UnableToGetNotificationShimFactory()
            {
                return "Distributed transaction manager is unable to create the NotificationShimFactory object.";
            }
            static /*string */ get CannotGetTransactionIdentifier()
            {
                return "Unable to obtain the transaction identifier.";
            }
            static /*string */ get ReenlistAfterRecoveryComplete()
            {
                return "Calling TransactionManager.Reenlist is not allowed after TransactionManager.RecoveryComplete is called for a given resource manager identifier.";
            }
            static /*string */ get DuplicateRecoveryComplete()
            {
                return "RecoveryComplete must not be called twice by the same resource manager identifier instance.";
            }
            static /*string */ get DtcTransactionManagerUnavailable()
            {
                return "MSDTC Transaction Manager is unavailable.";
            }
            static /*string */ get NetworkTransactionsDisabled()
            {
                return "Network access for Distributed Transaction Manager (MSDTC) has been disabled. Please enable DTC for network access in the security configuration for MSDTC using the Component Services Administrative tool.";
            }
            static /*string */ get TraceSourceLtm()
            {
                return "[Lightweight]";
            }
            static /*string */ get TraceCodeAppDomainUnloading()
            {
                return "AppDomain unloading.";
            }
            static /*string */ get UnhandledException()
            {
                return "Unhandled Exception";
            }
            static /*string */ get ResourceManagerIdDoesNotMatchRecoveryInformation()
            {
                return "The resourceManagerIdentifier does not match the contents of the specified recovery information.";
            }
            static /*string */ get OletxTooManyEnlistments()
            {
                return "The distributed transaction manager does not allow any more durable enlistments on the transaction.";
            }
            static /*string */ get FailedToTraceEvent()
            {
                return "Failed to trace event: {0}.";
            }
            static /*string */ FormatFailedToTraceEvent(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Failed to trace event: {0}.", arg1);
            }
            static /*string */ get TraceSourceBase()
            {
                return "[Base]";
            }
            static /*string */ get DistributedNotSupportedOn32Bits()
            {
                return "Distributed transactions are currently unsupported in 32-bit processes.";
            }
            static /*string */ get ImplicitDistributedTransactionsDisabled()
            {
                return "Implicit distributed transactions have not been enabled. If you're intentionally starting a distributed transaction, set TransactionManager.ImplicitDistributedTransactions to true.";
            }
            static /*string */ get ImplicitDistributedTransactionsCannotBeChanged()
            {
                return "TransactionManager.ImplicitDistributedTransaction cannot be changed once set, or once System.Transactions distributed transactions have been initialized. Set this flag once at the start of your program.";
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$stl.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$stl.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$stl.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$stl.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$stl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$stl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$stl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$stl.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$stl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$stl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$stl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$stl.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$stl.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 173317;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":173317}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionManager", ($self) => class TransactionManager
        {
            /*int*/ static RecoveryInformationVersion1 = 1;
            /*int*/ static CurrentRecoveryVersion = 1;
            /*Hashtable?*/ static s_promotedTransactionTable = null;
            /*TransactionTable?*/ static s_transactionTable = null;
            /*TransactionStartedEventHandler?*/ static s_distributedTransactionStartedDelegate = null;
            /*string*/ static DistributedTransactionTrimmingWarning = null;
            /*TransactionStartedEventHandler?*/static  add_DistributedTransactionStarted(value)
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter($.$stl.System.Transactions.TransactionManager.ClassSyncObject)
                    {
                        $.$stl.System.Transactions.TransactionManager.s_distributedTransactionStartedDelegate = $.$cast($.$spc.System.Delegate.Combine($.$stl.System.Transactions.TransactionManager.s_distributedTransactionStartedDelegate, value), $.$stl.System.Transactions.TransactionStartedEventHandler);
                        if (value !== null)
                        {
                            $.$stl.System.Transactions.TransactionManager.ProcessExistingTransactions(value);
                        }
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit($.$stl.System.Transactions.TransactionManager.ClassSyncObject)
                }
            }
            /*TransactionStartedEventHandler?*/static  remove_DistributedTransactionStarted(value)
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter($.$stl.System.Transactions.TransactionManager.ClassSyncObject)
                    {
                        $.$stl.System.Transactions.TransactionManager.s_distributedTransactionStartedDelegate = $.$cast($.$spc.System.Delegate.Remove($.$stl.System.Transactions.TransactionManager.s_distributedTransactionStartedDelegate, value), $.$stl.System.Transactions.TransactionStartedEventHandler);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit($.$stl.System.Transactions.TransactionManager.ClassSyncObject)
                }
            }
            static /*void */ ProcessExistingTransactions(/*TransactionStartedEventHandler*/ eventHandler)
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter($.$stl.System.Transactions.TransactionManager.PromotedTransactionTable)
                    {
                        /*IDictionaryEnumerator*/ let e = $.$stl.System.Transactions.TransactionManager.PromotedTransactionTable.GetEnumerator();
                        while(e.System$Collections$IEnumerator$MoveNext())
                        {
                            /*WeakReference*/ let weakRef = $.$cast(e.System$Collections$IDictionaryEnumerator$Value, $.$spc.System.WeakReference);
                            let tx;
                            if ($.$is(weakRef.Target, $.$stl.System.Transactions.Transaction, { set $v(v){ tx = v; } }))
                            {
                                /*TransactionEventArgs*/ let args = new $.$stl.System.Transactions.TransactionEventArgs().$ctor$2();
                                args._transaction = tx.InternalClone();
                                eventHandler.Invoke(args._transaction, args);
                            }
                        }
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit($.$stl.System.Transactions.TransactionManager.PromotedTransactionTable)
                }
            }
            static /*void */ FireDistributedTransactionStarted(/*Transaction*/ transaction)
            {
                /*TransactionStartedEventHandler?*/ let localStartedEventHandler = null;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter($.$stl.System.Transactions.TransactionManager.ClassSyncObject)
                    {
                        localStartedEventHandler = $.$stl.System.Transactions.TransactionManager.s_distributedTransactionStartedDelegate;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit($.$stl.System.Transactions.TransactionManager.ClassSyncObject)
                }
                if (null !== localStartedEventHandler)
                {
                    /*TransactionEventArgs*/ let args = new $.$stl.System.Transactions.TransactionEventArgs().$ctor$2();
                    args._transaction = transaction.InternalClone();
                    localStartedEventHandler.Invoke(args._transaction, args);
                }
            }
            /*HostCurrentTransactionCallback?*/ static s_currentDelegate = null;
            /*bool*/ static s_currentDelegateSet = false;
            static /*HostCurrentTransactionCallback? */ get HostCurrentCallback()
            {
                return $.$stl.System.Transactions.TransactionManager.s_currentDelegate;
            }
            static /*HostCurrentTransactionCallback? */ set HostCurrentCallback(value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter($.$stl.System.Transactions.TransactionManager.ClassSyncObject)
                    {
                        if ($.$stl.System.Transactions.TransactionManager.s_currentDelegateSet)
                        {
                            throw new $.$spc.System.InvalidOperationException().$ctor$10($.$stl.System.SR.CurrentDelegateSet);
                        }
                        $.$stl.System.Transactions.TransactionManager.s_currentDelegateSet = true;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit($.$stl.System.Transactions.TransactionManager.ClassSyncObject)
                }
                $.$stl.System.Transactions.TransactionManager.s_currentDelegate = value;
            }
            static /*Enlistment */ Reenlist(/*Guid*/ resourceManagerIdentifier, /*byte[]*/ recoveryInformation, /*IEnlistmentNotification*/ enlistmentNotification)
            {
                if ($.$spc.System.Guid.op_Equality(resourceManagerIdentifier, $.$spc.System.Guid.Empty))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$stl.System.SR.BadResourceManagerId, "resourceManagerIdentifier");
                }
                $.$spc.System.ArgumentNullException.ThrowIfNull(recoveryInformation, "recoveryInformation");
                $.$spc.System.ArgumentNullException.ThrowIfNull(enlistmentNotification, "enlistmentNotification");
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(0/*TraceSourceType.TraceSourceBase*/, "TransactionManager.Reenlist");
                    etwLog.TransactionManagerReenlist(resourceManagerIdentifier);
                }
                /*MemoryStream*/ let stream = new $.$spc.System.IO.MemoryStream().$ctor$5(recoveryInformation);
                /*int*/ let recoveryInformationVersion;
                /*string?*/ let nodeName;
                /*byte[]?*/ let resourceManagerRecoveryInformation = null;
                try
                {
                    /*BinaryReader*/ let reader = new $.$spc.System.IO.BinaryReader().$ctor$1(stream);
                    recoveryInformationVersion = reader.ReadInt32();
                    if (recoveryInformationVersion === 1/*TransactionManager.RecoveryInformationVersion1*/)
                    {
                        nodeName = reader.ReadString();
                        resourceManagerRecoveryInformation = reader.ReadBytes(((recoveryInformation.length - $.$cast(stream.Position, $.$spc.System.Int32)) | 0));
                    }
                    else 
                    {
                        if (etwLog.IsEnabled())
                        {
                            etwLog.TransactionExceptionTrace(0/*TraceSourceType.TraceSourceBase*/, 5/*TransactionExceptionType.UnrecognizedRecoveryInformation*/, "recoveryInformation", $.$spc.System.String.Empty);
                        }
                        throw new $.$spc.System.ArgumentException().$ctor$13($.$stl.System.SR.UnrecognizedRecoveryInformation, "recoveryInformation");
                    }
                }
                catch($e)
                {
                    if ($e instanceof $.$spc.System.IO.EndOfStreamException)
                    {
                        let e = $e;
                        if (etwLog.IsEnabled())
                        {
                            etwLog.TransactionExceptionTrace(0/*TraceSourceType.TraceSourceBase*/, 5/*TransactionExceptionType.UnrecognizedRecoveryInformation*/, "recoveryInformation", $.$spc.System.Exception.ToString.call(e));
                        }
                        throw new $.$spc.System.ArgumentException().$ctor$12($.$stl.System.SR.UnrecognizedRecoveryInformation, "recoveryInformation", e);
                    }
                    else if ($e instanceof $.$spc.System.FormatException)
                    {
                        let e = $e;
                        if (etwLog.IsEnabled())
                        {
                            etwLog.TransactionExceptionTrace(0/*TraceSourceType.TraceSourceBase*/, 5/*TransactionExceptionType.UnrecognizedRecoveryInformation*/, "recoveryInformation", $.$spc.System.Exception.ToString.call(e));
                        }
                        throw new $.$spc.System.ArgumentException().$ctor$12($.$stl.System.SR.UnrecognizedRecoveryInformation, "recoveryInformation", e);
                    }
                    else
                    {
                        throw $e;
                    }
                }
                finally
                {
                    {
                        stream.Dispose();
                    }
                }
                /*object*/ let syncRoot = new $.$spc.System.Object().$ctor();
                /*Enlistment*/ let returnValue = new $.$stl.System.Transactions.Enlistment().$ctor$6(enlistmentNotification, syncRoot);
                $.$stl.System.Transactions.EnlistmentState.EnlistmentStatePromoted.EnterState(returnValue.InternalEnlistment);
                returnValue.InternalEnlistment.PromotedEnlistment = $.$stl.System.Transactions.TransactionManager.DistributedTransactionManager.ReenlistTransaction(resourceManagerIdentifier, resourceManagerRecoveryInformation, $.$cast(returnValue.InternalEnlistment, $.$stl.System.Transactions.RecoveringInternalEnlistment));
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(0/*TraceSourceType.TraceSourceBase*/, "TransactionManager.Reenlist");
                }
                return returnValue;
            }
            static /*OletxTransactionManager */ CheckTransactionManager(/*string?*/ nodeName)
            {
                /*OletxTransactionManager*/ let tm = $.$stl.System.Transactions.TransactionManager.DistributedTransactionManager;
                if (!((tm.NodeName === null && $.$spc.System.String.IsNullOrEmpty(nodeName)) || (tm.NodeName !== null && $.$spc.System.Object.Equals.call(tm.NodeName, nodeName))))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$stl.System.SR.InvalidRecoveryInformation, "recoveryInformation");
                }
                return tm;
            }
            static /*void */ RecoveryComplete(/*Guid*/ resourceManagerIdentifier)
            {
                if ($.$spc.System.Guid.op_Equality(resourceManagerIdentifier, $.$spc.System.Guid.Empty))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$stl.System.SR.BadResourceManagerId, "resourceManagerIdentifier");
                }
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(0/*TraceSourceType.TraceSourceBase*/, "TransactionManager.RecoveryComplete");
                    etwLog.TransactionManagerRecoveryComplete(resourceManagerIdentifier);
                }
                $.$stl.System.Transactions.TransactionManager.DistributedTransactionManager.ResourceManagerRecoveryComplete(resourceManagerIdentifier);
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(0/*TraceSourceType.TraceSourceBase*/, "TransactionManager.RecoveryComplete");
                }
            }
            /*object?*/ static s_classSyncObject = null;
            static /*object */ get ClassSyncObject()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized($.$spc.System.Object, $.$ref(() => $.$stl.System.Transactions.TransactionManager.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionManager.s_classSyncObject = $v, $.$spc.System.Object));
            }
            static /*IsolationLevel */ get DefaultIsolationLevel()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(0/*TraceSourceType.TraceSourceBase*/, "TransactionManager.get_DefaultIsolationLevel");
                    etwLog.MethodExit$1(0/*TraceSourceType.TraceSourceBase*/, "TransactionManager.get_DefaultIsolationLevel");
                }
                return 0/*IsolationLevel.Serializable*/;
            }
            /*DefaultSettingsSection*/ static DefaultSettings$ = null;
            static /*DefaultSettingsSection */ get DefaultSettings()
            {
                return $.$stl.System.Transactions.TransactionManager.DefaultSettings$ ??= $.$stl.System.Transactions.Configuration.DefaultSettingsSection.GetSection();
            }
            /*MachineSettingsSection*/ static MachineSettings$ = null;
            static /*MachineSettingsSection */ get MachineSettings()
            {
                return $.$stl.System.Transactions.TransactionManager.MachineSettings$ ??= $.$stl.System.Transactions.Configuration.MachineSettingsSection.GetSection();
            }
            /*bool*/ static s_defaultTimeoutValidated = false;
            /*long*/ static s_defaultTimeoutTicks = 0n;
            static /*TimeSpan */ get DefaultTimeout()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(0/*TraceSourceType.TraceSourceBase*/, "TransactionManager.get_DefaultTimeout");
                }
                if (!$.$stl.System.Transactions.TransactionManager.s_defaultTimeoutValidated)
                {
                    $.$spc.System.Threading.LazyInitializer.EnsureInitialized$3($.$spc.System.Int64, $.$ref(() => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks, ($v) => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks = $v, $.$spc.System.Int64), $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Boolean, () => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutValidated, ($v) => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutValidated = $v, null), $.$ref(() => $.$stl.System.Transactions.TransactionManager.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionManager.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$spc.System.Int64))().$ctor(this,  () =>
                    {
                        return $.$stl.System.Transactions.TransactionManager.ValidateTimeout($.$stl.System.Transactions.Configuration.DefaultSettingsSection.Timeout).Ticks;
                    }, {"r":917505,"n":"","d":4891909,"h":0,"f":1048578}));
                    if ($.$spc.System.Threading.Interlocked.Read($.$ref(() => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks, ($v) => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks = $v, $.$spc.System.Int64)) !== $.$stl.System.Transactions.Configuration.DefaultSettingsSection.Timeout.Ticks)
                    {
                        if (etwLog.IsEnabled())
                        {
                            etwLog.ConfiguredDefaultTimeoutAdjusted();
                        }
                    }
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(0/*TraceSourceType.TraceSourceBase*/, "TransactionManager.get_DefaultTimeout");
                }
                return new $.$spc.System.TimeSpan().$ctor$2($.$spc.System.Threading.Interlocked.Read($.$ref(() => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks, ($v) => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks = $v, $.$spc.System.Int64)));
            }
            static /*TimeSpan */ set DefaultTimeout(value)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(0/*TraceSourceType.TraceSourceBase*/, "TransactionManager.set_DefaultTimeout");
                }
                $.$spc.System.Threading.Interlocked.Exchange$3($.$ref(() => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks, ($v) => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks = $v, $.$spc.System.Int64), $.$stl.System.Transactions.TransactionManager.ValidateTimeout(value).Ticks);
                if ($.$spc.System.Threading.Interlocked.Read($.$ref(() => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks, ($v) => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks = $v, $.$spc.System.Int64)) !== value.Ticks)
                {
                    if (etwLog.IsEnabled())
                    {
                        etwLog.ConfiguredDefaultTimeoutAdjusted();
                    }
                }
                $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutValidated = true;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(0/*TraceSourceType.TraceSourceBase*/, "TransactionManager.set_DefaultTimeout");
                }
            }
            /*bool*/ static s_cachedMaxTimeout = false;
            /*TimeSpan*/ static s_maximumTimeout;
            static /*TimeSpan */ get MaximumTimeout()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(0/*TraceSourceType.TraceSourceBase*/, "TransactionManager.get_DefaultMaximumTimeout");
                }
                $.$spc.System.Threading.LazyInitializer.EnsureInitialized$3($.$spc.System.TimeSpan, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.TimeSpan, () => $.$stl.System.Transactions.TransactionManager.s_maximumTimeout, ($v) => $.$stl.System.Transactions.TransactionManager.s_maximumTimeout = $v, null), $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Boolean, () => $.$stl.System.Transactions.TransactionManager.s_cachedMaxTimeout, ($v) => $.$stl.System.Transactions.TransactionManager.s_cachedMaxTimeout = $v, null), $.$ref(() => $.$stl.System.Transactions.TransactionManager.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionManager.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$spc.System.TimeSpan))().$ctor(this,  () =>
                {
                    return $.$stl.System.Transactions.Configuration.MachineSettingsSection.MaxTimeout;
                }, {"r":140705793,"n":"","d":4891909,"h":0,"f":1048578}));
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(0/*TraceSourceType.TraceSourceBase*/, "TransactionManager.get_DefaultMaximumTimeout");
                }
                return $.$stl.System.Transactions.TransactionManager.s_maximumTimeout;
            }
            static /*TimeSpan */ set MaximumTimeout(value)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(0/*TraceSourceType.TraceSourceBase*/, "TransactionManager.set_DefaultMaximumTimeout");
                }
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfLessThan($.$spc.System.TimeSpan, value, $.$spc.System.TimeSpan.Zero, "value");
                $.$stl.System.Transactions.TransactionManager.s_cachedMaxTimeout = true;
                $.$stl.System.Transactions.TransactionManager.s_maximumTimeout = value;
                $.$spc.System.Threading.LazyInitializer.EnsureInitialized$3($.$spc.System.Int64, $.$ref(() => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks, ($v) => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks = $v, $.$spc.System.Int64), $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Boolean, () => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutValidated, ($v) => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutValidated = $v, null), $.$ref(() => $.$stl.System.Transactions.TransactionManager.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionManager.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$spc.System.Int64))().$ctor(this,  () =>
                {
                    return $.$stl.System.Transactions.Configuration.DefaultSettingsSection.Timeout.Ticks;
                }, {"r":917505,"n":"","d":4891909,"h":0,"f":1048578}));
                /*long*/ let defaultTimeoutTicks = $.$spc.System.Threading.Interlocked.Read($.$ref(() => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks, ($v) => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks = $v, $.$spc.System.Int64));
                $.$spc.System.Threading.Interlocked.Exchange$3($.$ref(() => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks, ($v) => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks = $v, $.$spc.System.Int64), $.$stl.System.Transactions.TransactionManager.ValidateTimeout(new $.$spc.System.TimeSpan().$ctor$2(defaultTimeoutTicks)).Ticks);
                if ($.$spc.System.Threading.Interlocked.Read($.$ref(() => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks, ($v) => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks = $v, $.$spc.System.Int64)) !== defaultTimeoutTicks)
                {
                    if (etwLog.IsEnabled())
                    {
                        etwLog.ConfiguredDefaultTimeoutAdjusted();
                    }
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(0/*TraceSourceType.TraceSourceBase*/, "TransactionManager.set_DefaultMaximumTimeout");
                }
            }
            static /*bool */ get ImplicitDistributedTransactions()
            {
                return false;
            }
            static /*bool */ set ImplicitDistributedTransactions(value)
            {
                if (value)
                {
                    throw new $.$spc.System.PlatformNotSupportedException().$ctor$14($.$stl.System.SR.DistributedNotSupported);
                }
            }
            static /*byte[] */ GetRecoveryInformation(/*string?*/ startupInfo, /*byte[]*/ resourceManagerRecoveryInformation)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(2/*TraceSourceType.TraceSourceOleTx*/, `${"TransactionManager"}.${"GetRecoveryInformation"}`);
                }
                /*MemoryStream*/ let stream = new $.$spc.System.IO.MemoryStream().$ctor$3();
                /*byte[]?*/ let returnValue = null;
                try
                {
                    /*BinaryWriter*/ let writer = new $.$spc.System.IO.BinaryWriter().$ctor$2(stream);
                    writer.Write$12(1/*CurrentRecoveryVersion*/);
                    if ($.$spc.System.String.op_Inequality(startupInfo, null))
                    {
                        writer.Write$18(startupInfo);
                    }
                    else 
                    {
                        writer.Write$18("");
                    }
                    writer.Write$3(resourceManagerRecoveryInformation);
                    writer.Flush();
                    returnValue = stream.ToArray();
                }
                finally
                {
                    {
                        stream.Close();
                    }
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(2/*TraceSourceType.TraceSourceOleTx*/, `${"TransactionManager"}.${"GetRecoveryInformation"}`);
                }
                return returnValue;
            }
            static /*void */ ValidateIsolationLevel(/*IsolationLevel*/ transactionIsolationLevel)
            {
                switch(transactionIsolationLevel)
                {
                    case 0/*IsolationLevel.Serializable*/:
                    case 1/*IsolationLevel.RepeatableRead*/:
                    case 2/*IsolationLevel.ReadCommitted*/:
                    case 3/*IsolationLevel.ReadUncommitted*/:
                    case 6/*IsolationLevel.Unspecified*/:
                    case 5/*IsolationLevel.Chaos*/:
                    case 4/*IsolationLevel.Snapshot*/:
                    break;
                    default:
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("transactionIsolationLevel");
                }
            }
            static /*TimeSpan */ ValidateTimeout(/*TimeSpan*/ transactionTimeout)
            {
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfLessThan($.$spc.System.TimeSpan, transactionTimeout, $.$spc.System.TimeSpan.Zero, "transactionTimeout");
                if ($.$spc.System.TimeSpan.op_Inequality($.$stl.System.Transactions.TransactionManager.MaximumTimeout, $.$spc.System.TimeSpan.Zero))
                {
                    if ($.$spc.System.TimeSpan.op_GreaterThan(transactionTimeout, $.$stl.System.Transactions.TransactionManager.MaximumTimeout) || $.$spc.System.TimeSpan.op_Equality(transactionTimeout, $.$spc.System.TimeSpan.Zero))
                    {
                        return $.$stl.System.Transactions.TransactionManager.MaximumTimeout;
                    }
                }
                return transactionTimeout;
            }
            static /*Transaction? */ FindPromotedTransaction(/*Guid*/ transactionIdentifier)
            {
                /*Hashtable*/ let promotedTransactionTable = $.$stl.System.Transactions.TransactionManager.PromotedTransactionTable;
                /*WeakReference?*/ let weakRef = $.$cast(promotedTransactionTable.get_Item(transactionIdentifier), $.$spc.System.WeakReference);
                if (null !== weakRef)
                {
                    let tx;
                    if ($.$is(weakRef.Target, $.$stl.System.Transactions.Transaction, { set $v(v){ tx = v; } }))
                    {
                        return tx.InternalClone();
                    }
                    else 
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(promotedTransactionTable)
                            {
                                promotedTransactionTable.Remove(transactionIdentifier);
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(promotedTransactionTable)
                        }
                    }
                }
                return null;
            }
            static /*Transaction */ FindOrCreatePromotedTransaction(/*Guid*/ transactionIdentifier, /*OletxTransaction*/ dtx)
            {
                /*Transaction?*/ let tx = null;
                /*Hashtable*/ let promotedTransactionTable = $.$stl.System.Transactions.TransactionManager.PromotedTransactionTable;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(promotedTransactionTable)
                    {
                        /*WeakReference?*/ let weakRef = $.$cast(promotedTransactionTable.get_Item(transactionIdentifier), $.$spc.System.WeakReference);
                        if (null !== weakRef)
                        {
                            tx = $.$as(weakRef.Target, $.$stl.System.Transactions.Transaction);
                            if ($.$stl.System.Transactions.Transaction.op_Inequality(null, tx))
                            {
                                return tx.InternalClone();
                            }
                            else 
                            {
                                //lock
                                try
                                {
                                    $.$spc.System.Threading.Monitor.Enter(promotedTransactionTable)
                                    {
                                        promotedTransactionTable.Remove(transactionIdentifier);
                                    }
                                }
                                finally
                                {
                                    $.$spc.System.Threading.Monitor.Exit(promotedTransactionTable)
                                }
                            }
                        }
                        tx = new $.$stl.System.Transactions.Transaction().$ctor$3(dtx);
                        tx._internalTransaction._finalizedObject = new $.$stl.System.Transactions.FinalizedObject().$ctor$1(tx._internalTransaction, dtx.Identifier);
                        weakRef = new $.$spc.System.WeakReference().$ctor$2(tx, false);
                        promotedTransactionTable.set_Item(dtx.Identifier, weakRef);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(promotedTransactionTable)
                }
                dtx.SavedLtmPromotedTransaction = tx;
                $.$stl.System.Transactions.TransactionManager.FireDistributedTransactionStarted(tx);
                return tx;
            }
            static /*Hashtable */ get PromotedTransactionTable()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$spc.System.Collections.Hashtable, $.$ref(() => $.$stl.System.Transactions.TransactionManager.s_promotedTransactionTable, ($v) => $.$stl.System.Transactions.TransactionManager.s_promotedTransactionTable = $v, $.$spc.System.Collections.Hashtable), $.$ref(() => $.$stl.System.Transactions.TransactionManager.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionManager.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$spc.System.Collections.Hashtable))().$ctor(this,  () =>
                {
                    return new $.$spc.System.Collections.Hashtable().$ctor$3(100);
                }, {"r":30998529,"n":"","d":4891909,"h":0,"f":1048578}));
            }
            static /*TransactionTable */ get TransactionTable()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionTable, $.$ref(() => $.$stl.System.Transactions.TransactionManager.s_transactionTable, ($v) => $.$stl.System.Transactions.TransactionManager.s_transactionTable = $v, $.$stl.System.Transactions.TransactionTable), $.$ref(() => $.$stl.System.Transactions.TransactionManager.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionManager.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionTable))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionTable().$ctor$1();
                }, {"r":8496389,"n":"","d":4891909,"h":0,"f":1048578}));
            }
            /*OletxTransactionManager?*/ static distributedTransactionManager = null;
            static /*OletxTransactionManager */ get DistributedTransactionManager()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.Oletx.OletxTransactionManager, $.$ref(() => $.$stl.System.Transactions.TransactionManager.distributedTransactionManager, ($v) => $.$stl.System.Transactions.TransactionManager.distributedTransactionManager = $v, $.$stl.System.Transactions.Oletx.OletxTransactionManager), $.$ref(() => $.$stl.System.Transactions.TransactionManager.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionManager.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.Oletx.OletxTransactionManager))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.Oletx.OletxTransactionManager().$ctor$1($.$stl.System.Transactions.Configuration.DefaultSettingsSection.DistributedTransactionManagerName);
                }, {"r":3646725,"n":"","d":4891909,"h":0,"f":1048578}));
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.DistributedTransactionTrimmingWarning = "Distributed transactions support may not be compatible with trimming. If your program creates a distributed transaction via System.Transactions, the correctness of the application cannot be guaranteed after trimming.";
                }
                {
                    this.s_maximumTimeout = $.$default($.$spc.System.TimeSpan);
                }
            }
            static $h = 4891909;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":2467077,"g":{"r":0,"d":0,"h":64429401349,"f":33},"s":{"r":0,"d":0,"h":68724368645,"f":33},"n":"HostCurrentCallback","d":4891909,"h":60134434053,"f":33},{"p":131073,"g":{"r":0,"d":0,"h":94494172421,"f":34},"n":"ClassSyncObject","d":4891909,"h":90199205125,"f":34},{"p":3187973,"g":{"r":0,"d":0,"h":103084107013,"f":40},"n":"DefaultIsolationLevel","d":4891909,"h":98789139717,"f":40},{"p":763141,"g":{"r":0,"d":0,"h":115969008901,"f":34},"n":"DefaultSettings","d":4891909,"h":111674041605,"f":34},{"p":828677,"g":{"r":0,"d":0,"h":128853910789,"f":34},"n":"MachineSettings","d":4891909,"h":124558943493,"f":34},{"p":140705793,"g":{"r":0,"d":0,"h":146033779973,"f":33},"s":{"r":0,"d":0,"h":150328747269,"f":33},"n":"DefaultTimeout","d":4891909,"h":141738812677,"f":33},{"p":140705793,"g":{"r":0,"d":0,"h":167508616453,"f":33},"s":{"r":0,"d":0,"h":171803583749,"f":33},"n":"MaximumTimeout","d":4891909,"h":163213649157,"f":33},{"p":262145,"g":{"r":0,"d":0,"h":180393518341,"f":33},"s":{"r":0,"d":0,"h":184688485637,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},"n":"ImplicitDistributedTransactions","d":4891909,"h":176098551045,"f":33},{"p":30998529,"g":{"r":0,"d":0,"h":214753256709,"f":40},"n":"PromotedTransactionTable","d":4891909,"h":210458289413,"f":40},{"p":8496389,"g":{"r":0,"d":0,"h":223343191301,"f":40},"n":"TransactionTable","d":4891909,"h":219048224005,"f":40},{"p":3646725,"g":{"r":0,"d":0,"h":236228093189,"f":40},"n":"DistributedTransactionManager","d":4891909,"h":231933125893,"f":40}],"m":[{"r":65537,"p":[{"n":"eventHandler","p":5678341}],"n":"ProcessExistingTransactions","d":4891909,"h":42954564869,"f":40},{"r":65537,"p":[{"n":"transaction","p":4302085}],"n":"FireDistributedTransactionStarted","d":4891909,"h":47249532165,"f":40},{"r":1746181,"p":[{"n":"resourceManagerIdentifier","p":56229889},{"n":"recoveryInformation","p":0},{"n":"enlistmentNotification","p":2598149}],"n":"Reenlist","d":4891909,"h":73019335941,"f":33},{"r":3646725,"p":[{"n":"nodeName","p":1310721}],"n":"CheckTransactionManager","d":4891909,"h":77314303237,"f":34},{"r":65537,"p":[{"n":"resourceManagerIdentifier","p":56229889}],"n":"RecoveryComplete","d":4891909,"h":81609270533,"f":33},{"r":0,"p":[{"n":"startupInfo","p":1310721},{"n":"resourceManagerRecoveryInformation","p":0}],"n":"GetRecoveryInformation","d":4891909,"h":188983452933,"f":40},{"r":65537,"p":[{"n":"transactionIsolationLevel","p":3187973}],"n":"ValidateIsolationLevel","d":4891909,"h":193278420229,"f":40},{"r":140705793,"p":[{"n":"transactionTimeout","p":140705793}],"n":"ValidateTimeout","d":4891909,"h":197573387525,"f":40},{"r":4302085,"p":[{"n":"transactionIdentifier","p":56229889}],"n":"FindPromotedTransaction","d":4891909,"h":201868354821,"f":40},{"r":4302085,"p":[{"n":"transactionIdentifier","p":56229889},{"n":"dtx","p":3515653}],"n":"FindOrCreatePromotedTransaction","d":4891909,"h":206163322117,"f":40}],"l":[{"t":655361,"n":"RecoveryInformationVersion1","d":4891909,"h":4299859205,"f":34},{"t":655361,"n":"CurrentRecoveryVersion","d":4891909,"h":8594826501,"f":34},{"t":30998529,"n":"s_promotedTransactionTable","d":4891909,"h":12889793797,"f":34},{"t":8496389,"n":"s_transactionTable","d":4891909,"h":17184761093,"f":34},{"t":5678341,"n":"s_distributedTransactionStartedDelegate","d":4891909,"h":21479728389,"f":34},{"t":1310721,"n":"DistributedTransactionTrimmingWarning","d":4891909,"h":25774695685,"f":40},{"t":2467077,"n":"s_currentDelegate","d":4891909,"h":51544499461,"f":40},{"t":262145,"n":"s_currentDelegateSet","d":4891909,"h":55839466757,"f":40},{"t":131073,"n":"s_classSyncObject","d":4891909,"h":85904237829,"f":34},{"t":262145,"n":"s_defaultTimeoutValidated","d":4891909,"h":133148878085,"f":34},{"t":917505,"n":"s_defaultTimeoutTicks","d":4891909,"h":137443845381,"f":34},{"t":262145,"n":"s_cachedMaxTimeout","d":4891909,"h":154623714565,"f":34},{"t":140705793,"n":"s_maximumTimeout","d":4891909,"h":158918681861,"f":34},{"t":3646725,"n":"distributedTransactionManager","d":4891909,"h":227638158597,"f":40}],"e":[{"e":5678341,"m":{"r":65537,"p":[{"n":"value","p":5678341}],"n":"add_DistributedTransactionStarted","d":4891909,"h":34364630277,"f":33},"r":{"r":65537,"p":[{"n":"value","p":5678341}],"n":"remove_DistributedTransactionStarted","d":4891909,"h":38659597573,"f":33},"n":"DistributedTransactionStarted","d":4891909,"h":30069662981,"f":33}],"h":4891909}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Transactions.TransactionManager`; }
        });
        
        $asm.$cls("$stl.System.Transactions.CheapUnfairReaderWriterLock", ($self) => class CheapUnfairReaderWriterLock extends $.$spc.System.Object
        {
            /*object?*/ _writerFinishedEvent = null;
            /*int*/ _readersIn = 0;
            /*int*/ _readersOut = 0;
            /*bool*/ _writerPresent = false;
            /*object?*/ _syncRoot = null;
            /*int*/ static MAX_SPIN_COUNT = 100;
            /*int*/ static SLEEP_TIME = 500;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*object */ get SyncRoot()
            {
                if (this._syncRoot === null)
                {
                    $.$spc.System.Threading.Interlocked.CompareExchange$2($.$ref(() => this._syncRoot, ($v) => this._syncRoot = $v, $.$spc.System.Object), new $.$spc.System.Object().$ctor(), null);
                }
                return this._syncRoot;
            }
            /*bool */ get ReadersPresent()
            {
                return this._readersIn !== this._readersOut;
            }
            /*ManualResetEvent */ get WriterFinishedEvent()
            {
                if (this._writerFinishedEvent === null)
                {
                    $.$spc.System.Threading.Interlocked.CompareExchange$2($.$ref(() => this._writerFinishedEvent, ($v) => this._writerFinishedEvent = $v, $.$spc.System.Object), new $.$spc.System.Threading.ManualResetEvent().$ctor$8(true), null);
                }
                return $.$cast(this._writerFinishedEvent, $.$spc.System.Threading.ManualResetEvent);
            }
            /*int */ EnterReadLock()
            {
                /*int*/ let readerIndex;
                do
                {
                    if (this._writerPresent)
                    {
                        this.WriterFinishedEvent.WaitOne$2();
                    }
                    readerIndex = $.$spc.System.Threading.Interlocked.Increment($.$ref(() => this._readersIn, ($v) => this._readersIn = $v, $.$spc.System.Int32));
                    if (!this._writerPresent)
                    {
                        break;
                    }
                    $.$spc.System.Threading.Interlocked.Decrement($.$ref(() => this._readersIn, ($v) => this._readersIn = $v, $.$spc.System.Int32));
                }
                while(true);
                return readerIndex;
            }
            /*void */ EnterWriteLock()
            {
                $.$spc.System.Threading.Monitor.Enter(this.SyncRoot);
                this._writerPresent = true;
                this.WriterFinishedEvent.Reset();
                do
                {
                    /*int*/ let i = 0;
                    while(this.ReadersPresent && i < 100/*MAX_SPIN_COUNT*/)
                    {
                        $.$spc.System.Threading.Thread.Sleep(0);
                        i++;
                    }
                    if (this.ReadersPresent)
                    {
                        $.$spc.System.Threading.Thread.Sleep(500/*SLEEP_TIME*/);
                    }
                }
                while(this.ReadersPresent);
            }
            /*void */ ExitReadLock()
            {
                $.$spc.System.Threading.Interlocked.Increment($.$ref(() => this._readersOut, ($v) => this._readersOut = $v, $.$spc.System.Int32));
            }
            /*void */ ExitWriteLock()
            {
                try
                {
                    this._writerPresent = false;
                    this.WriterFinishedEvent.Set$1();
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Exit(this.SyncRoot);
                    }
                }
            }
            static $h = 500997;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":131073,"g":{"r":0,"d":0,"h":42950173957,"f":2},"n":"SyncRoot","d":500997,"h":38655206661,"f":2},{"p":262145,"g":{"r":0,"d":0,"h":51540108549,"f":2},"n":"ReadersPresent","d":500997,"h":47245141253,"f":2},{"p":128319489,"g":{"r":0,"d":0,"h":60130043141,"f":2},"n":"WriterFinishedEvent","d":500997,"h":55835075845,"f":2}],"m":[{"r":655361,"n":"EnterReadLock","d":500997,"h":64425010437,"f":1},{"r":65537,"n":"EnterWriteLock","d":500997,"h":68719977733,"f":1},{"r":65537,"n":"ExitReadLock","d":500997,"h":73014945029,"f":1},{"r":65537,"n":"ExitWriteLock","d":500997,"h":77309912325,"f":1}],"l":[{"t":131073,"n":"_writerFinishedEvent","d":500997,"h":4295468293,"f":2},{"t":655361,"n":"_readersIn","d":500997,"h":8590435589,"f":2},{"t":655361,"n":"_readersOut","d":500997,"h":12885402885,"f":2},{"t":262145,"n":"_writerPresent","d":500997,"h":17180370181,"f":2},{"t":131073,"n":"_syncRoot","d":500997,"h":21475337477,"f":2},{"t":655361,"n":"MAX_SPIN_COUNT","d":500997,"h":25770304773,"f":34},{"t":655361,"n":"SLEEP_TIME","d":500997,"h":30065272069,"f":34}],"c":[{"n":".ctor","o":"$ctor$1","d":500997,"h":34360239365,"f":1}],"h":500997}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Transactions.CheapUnfairReaderWriterLock`; }
        });
        
        $asm.$cls("$stl.System.Transactions.Enlistment", ($self) => class Enlistment extends $.$spc.System.Object
        {
            /*InternalEnlistment*/ _internalEnlistment = null;
            $ctor$1(/*InternalEnlistment*/ internalEnlistment)
            {
                super.$ctor();
                {
                    this._internalEnlistment = internalEnlistment;
                }
                return this;
            }
            $ctor$2(/*Guid*/ resourceManagerIdentifier, /*InternalTransaction*/ transaction, /*IEnlistmentNotification*/ twoPhaseNotifications, /*ISinglePhaseNotification?*/ singlePhaseNotifications, /*Transaction*/ atomicTransaction)
            {
                super.$ctor();
                {
                    this._internalEnlistment = new $.$stl.System.Transactions.DurableInternalEnlistment().$ctor$5(this, resourceManagerIdentifier, transaction, twoPhaseNotifications, singlePhaseNotifications, atomicTransaction);
                }
                return this;
            }
            $ctor$3(/*InternalTransaction*/ transaction, /*IEnlistmentNotification*/ twoPhaseNotifications, /*ISinglePhaseNotification?*/ singlePhaseNotifications, /*Transaction*/ atomicTransaction, /*EnlistmentOptions*/ enlistmentOptions)
            {
                super.$ctor();
                {
                    if ((enlistmentOptions & 1/*EnlistmentOptions.EnlistDuringPrepareRequired*/) !== 0)
                    {
                        this._internalEnlistment = new $.$stl.System.Transactions.InternalEnlistment().$ctor$3(this, transaction, twoPhaseNotifications, singlePhaseNotifications, atomicTransaction);
                    }
                    else 
                    {
                        this._internalEnlistment = new $.$stl.System.Transactions.Phase1VolatileEnlistment().$ctor$5(this, transaction, twoPhaseNotifications, singlePhaseNotifications, atomicTransaction);
                    }
                }
                return this;
            }
            $ctor$4(/*InternalTransaction*/ transaction, /*IPromotableSinglePhaseNotification*/ promotableSinglePhaseNotification, /*Transaction*/ atomicTransaction)
            {
                super.$ctor();
                {
                    this._internalEnlistment = new $.$stl.System.Transactions.PromotableInternalEnlistment().$ctor$5(this, transaction, promotableSinglePhaseNotification, atomicTransaction);
                }
                return this;
            }
            $ctor$5(/*IEnlistmentNotification*/ twoPhaseNotifications, /*InternalTransaction*/ transaction, /*Transaction*/ atomicTransaction)
            {
                super.$ctor();
                {
                    this._internalEnlistment = new $.$stl.System.Transactions.InternalEnlistment().$ctor$4(this, twoPhaseNotifications, transaction, atomicTransaction);
                }
                return this;
            }
            $ctor$6(/*IEnlistmentNotification*/ twoPhaseNotifications, /*object*/ syncRoot)
            {
                super.$ctor();
                {
                    this._internalEnlistment = new $.$stl.System.Transactions.RecoveringInternalEnlistment().$ctor$7(this, twoPhaseNotifications, syncRoot);
                }
                return this;
            }
            /*void */ Done()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "Done");
                    etwLog.EnlistmentDone(this._internalEnlistment);
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalEnlistment.SyncRoot)
                    {
                        this._internalEnlistment.State.EnlistmentDone(this._internalEnlistment);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalEnlistment.SyncRoot)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "Done");
                }
            }
            /*InternalEnlistment */ get InternalEnlistment()
            {
                return this._internalEnlistment;
            }
            static $h = 1746181;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":2729221,"g":{"r":0,"d":0,"h":42951419141,"f":8},"n":"InternalEnlistment","d":1746181,"h":38656451845,"f":8}],"m":[{"r":65537,"n":"Done","d":1746181,"h":34361484549,"f":1}],"l":[{"t":2729221,"n":"_internalEnlistment","d":1746181,"h":4296713477,"f":8}],"c":[{"p":[{"n":"internalEnlistment","p":2729221}],"n":".ctor","o":"$ctor$1","d":1746181,"h":8591680773,"f":8},{"p":[{"n":"resourceManagerIdentifier","p":56229889},{"n":"transaction","p":2794757},{"n":"twoPhaseNotifications","p":2598149},{"n":"singlePhaseNotifications","p":3056901},{"n":"atomicTransaction","p":4302085}],"n":".ctor","o":"$ctor$2","d":1746181,"h":12886648069,"f":8},{"p":[{"n":"transaction","p":2794757},{"n":"twoPhaseNotifications","p":2598149},{"n":"singlePhaseNotifications","p":3056901},{"n":"atomicTransaction","p":4302085},{"n":"enlistmentOptions","p":1877253}],"n":".ctor","o":"$ctor$3","d":1746181,"h":17181615365,"f":8},{"p":[{"n":"transaction","p":2794757},{"n":"promotableSinglePhaseNotification","p":2860293},{"n":"atomicTransaction","p":4302085}],"n":".ctor","o":"$ctor$4","d":1746181,"h":21476582661,"f":8},{"p":[{"n":"twoPhaseNotifications","p":2598149},{"n":"transaction","p":2794757},{"n":"atomicTransaction","p":4302085}],"n":".ctor","o":"$ctor$5","d":1746181,"h":25771549957,"f":8},{"p":[{"n":"twoPhaseNotifications","p":2598149},{"n":"syncRoot","p":131073}],"n":".ctor","o":"$ctor$6","d":1746181,"h":30066517253,"f":8}],"h":1746181}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Transactions.Enlistment`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionTable", ($self) => class TransactionTable extends $.$spc.System.Object
        {
            /*Timer*/ _timer = null;
            /*bool*/ _timerEnabled = false;
            /*int*/ static timerInternalExponent = 9;
            /*int*/ _timerInterval = 0;
            /*long*/ _ticks = 0n;
            /*long*/ _lastTimerTime = 0n;
            /*BucketSet*/ _headBucketSet = null;
            /*CheapUnfairReaderWriterLock*/ _rwLock = null;
            $ctor$1()
            {
                super.$ctor();
                {
                    this._timer = new $.$spc.System.Threading.Timer().$ctor$2(new $.$spc.System.Threading.TimerCallback().$ctor(this, this.ThreadTimer), null, -1/*Timeout.Infinite*/, this._timerInterval);
                    this._timerEnabled = false;
                    this._timerInterval = 1 << 9/*TransactionTable.timerInternalExponent*/;
                    this._ticks = 0n;
                    this._headBucketSet = new $.$stl.System.Transactions.BucketSet().$ctor$1(this, 9223372036854775807n);
                    this._rwLock = new $.$stl.System.Transactions.CheapUnfairReaderWriterLock().$ctor$1();
                }
                return this;
            }
            /*long */ TimeoutTicks(/*TimeSpan*/ timeout)
            {
                if ($.$spc.System.TimeSpan.op_Inequality(timeout, $.$spc.System.TimeSpan.Zero))
                {
                    /*long*/ let timeoutTicks = ((timeout.Ticks / 10000n) >> BigInt(9/*TransactionTable.timerInternalExponent*/)) + this._ticks;
                    return timeoutTicks + 2n;
                }
                else 
                {
                    return 9223372036854775807n;
                }
            }
            /*TimeSpan */ RecalcTimeout(/*InternalTransaction*/ tx)
            {
                return $.$spc.System.TimeSpan.FromMilliseconds((tx.AbsoluteTimeout - this._ticks) * BigInt(this._timerInterval));
            }
            /*long */ get CurrentTime()
            {
                if (this._timerEnabled)
                {
                    return this._lastTimerTime;
                }
                else 
                {
                    return $.$spc.System.DateTime.UtcNow.Ticks;
                }
            }
            /*int */ Add(/*InternalTransaction*/ txNew)
            {
                /*int*/ let readerIndex;
                readerIndex = this._rwLock.EnterReadLock();
                try
                {
                    if (txNew.AbsoluteTimeout !== 9223372036854775807n)
                    {
                        if (!this._timerEnabled)
                        {
                            if (!this._timer.Change(this._timerInterval, this._timerInterval))
                            {
                                throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.UnexpectedTimerFailure, null);
                            }
                            this._lastTimerTime = $.$spc.System.DateTime.UtcNow.Ticks;
                            this._timerEnabled = true;
                        }
                    }
                    txNew.CreationTime = this.CurrentTime;
                    this.AddIter(txNew);
                }
                finally
                {
                    {
                        this._rwLock.ExitReadLock();
                    }
                }
                return readerIndex;
            }
            /*void */ AddIter(/*InternalTransaction*/ txNew)
            {
                /*BucketSet*/ let currentBucketSet = this._headBucketSet;
                while(currentBucketSet.AbsoluteTimeout !== txNew.AbsoluteTimeout)
                {
                    /*BucketSet?*/ let lastBucketSet = null;
                    do
                    {
                        /*WeakReference?*/ let nextSetWeak = $.$cast(currentBucketSet.nextSetWeak, $.$spc.System.WeakReference);
                        /*BucketSet?*/ let nextBucketSet = null;
                        if (nextSetWeak !== null)
                        {
                            nextBucketSet = $.$cast(nextSetWeak.Target, $.$stl.System.Transactions.BucketSet);
                        }
                        if (nextBucketSet === null)
                        {
                            /*BucketSet*/ let newBucketSet = new $.$stl.System.Transactions.BucketSet().$ctor$1(this, txNew.AbsoluteTimeout);
                            /*WeakReference*/ let newSetWeak = new $.$spc.System.WeakReference().$ctor$1(newBucketSet);
                            /*WeakReference?*/ let oldNextSetWeak = $.$cast($.$spc.System.Threading.Interlocked.CompareExchange$2($.$ref(() => currentBucketSet.nextSetWeak, ($v) => currentBucketSet.nextSetWeak = $v, $.$spc.System.Object), newSetWeak, nextSetWeak), $.$spc.System.WeakReference);
                            if (oldNextSetWeak === nextSetWeak)
                            {
                                newBucketSet.prevSet = currentBucketSet;
                            }
                        }
                        else 
                        {
                            lastBucketSet = currentBucketSet;
                            currentBucketSet = nextBucketSet;
                        }
                    }
                    while(currentBucketSet.AbsoluteTimeout > txNew.AbsoluteTimeout);
                    if (currentBucketSet.AbsoluteTimeout !== txNew.AbsoluteTimeout)
                    {
                        /*BucketSet*/ let newBucketSet = new $.$stl.System.Transactions.BucketSet().$ctor$1(this, txNew.AbsoluteTimeout);
                        /*WeakReference*/ let newSetWeak = new $.$spc.System.WeakReference().$ctor$1(newBucketSet);
                        $.$spc.System.Diagnostics.Debug.Assert$1(lastBucketSet !== null, "lastBucketSet != null");
                        newBucketSet.nextSetWeak = lastBucketSet.nextSetWeak;
                        /*WeakReference?*/ let oldNextSetWeak = $.$cast($.$spc.System.Threading.Interlocked.CompareExchange$2($.$ref(() => lastBucketSet.nextSetWeak, ($v) => lastBucketSet.nextSetWeak = $v, $.$spc.System.Object), newSetWeak, newBucketSet.nextSetWeak), $.$spc.System.WeakReference);
                        if (oldNextSetWeak === newBucketSet.nextSetWeak)
                        {
                            if (oldNextSetWeak !== null)
                            {
                                /*BucketSet?*/ let oldSet = $.$cast(oldNextSetWeak.Target, $.$stl.System.Transactions.BucketSet);
                                if (oldSet !== null)
                                {
                                    oldSet.prevSet = newBucketSet;
                                }
                            }
                            newBucketSet.prevSet = lastBucketSet;
                        }
                        currentBucketSet = lastBucketSet;
                    }
                }
                currentBucketSet.Add(txNew);
            }
            static /*void */ Remove(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(tx._tableBucket !== null, "tx._tableBucket != null");
                tx._tableBucket.Remove(tx);
                tx._tableBucket = null;
            }
            /*void */ ThreadTimer(/*object?*/ state)
            {
                if (!this._timerEnabled)
                {
                    return;
                }
                this._ticks++;
                this._lastTimerTime = $.$spc.System.DateTime.UtcNow.Ticks;
                /*BucketSet?*/ let lastBucketSet;
                /*BucketSet*/ let currentBucketSet = this._headBucketSet;
                /*WeakReference?*/ let nextWeakSet;
                /*BucketSet?*/ let nextBucketSet = null;
                nextWeakSet = $.$cast(currentBucketSet.nextSetWeak, $.$spc.System.WeakReference);
                if (nextWeakSet !== null)
                {
                    nextBucketSet = $.$cast(nextWeakSet.Target, $.$stl.System.Transactions.BucketSet);
                }
                if (nextBucketSet === null)
                {
                    this._rwLock.EnterWriteLock();
                    try
                    {
                        nextWeakSet = $.$cast(currentBucketSet.nextSetWeak, $.$spc.System.WeakReference);
                        if (nextWeakSet !== null)
                        {
                            nextBucketSet = $.$cast(nextWeakSet.Target, $.$stl.System.Transactions.BucketSet);
                        }
                        if (nextBucketSet === null)
                        {
                            if (!this._timer.Change(-1/*Timeout.Infinite*/, -1/*Timeout.Infinite*/))
                            {
                                throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.UnexpectedTimerFailure, null);
                            }
                            this._timerEnabled = false;
                            return;
                        }
                    }
                    finally
                    {
                        {
                            this._rwLock.ExitWriteLock();
                        }
                    }
                }
                do
                {
                    do
                    {
                        nextWeakSet = $.$cast(currentBucketSet.nextSetWeak, $.$spc.System.WeakReference);
                        if (nextWeakSet === null)
                        {
                            return;
                        }
                        nextBucketSet = $.$cast(nextWeakSet.Target, $.$stl.System.Transactions.BucketSet);
                        if (nextBucketSet === null)
                        {
                            return;
                        }
                        lastBucketSet = currentBucketSet;
                        currentBucketSet = nextBucketSet;
                    }
                    while(currentBucketSet.AbsoluteTimeout > this._ticks);
                    /*WeakReference?*/ let abortingSetsWeak = $.$cast($.$spc.System.Threading.Interlocked.CompareExchange$2($.$ref(() => lastBucketSet.nextSetWeak, ($v) => lastBucketSet.nextSetWeak = $v, $.$spc.System.Object), null, nextWeakSet), $.$spc.System.WeakReference);
                    if (abortingSetsWeak === nextWeakSet)
                    {
                        /*BucketSet?*/ let abortingBucketSets;
                        do
                        {
                            if (abortingSetsWeak !== null)
                            {
                                abortingBucketSets = $.$cast(abortingSetsWeak.Target, $.$stl.System.Transactions.BucketSet);
                            }
                            else 
                            {
                                abortingBucketSets = null;
                            }
                            if (abortingBucketSets !== null)
                            {
                                abortingBucketSets.TimeoutTransactions();
                                abortingSetsWeak = $.$cast(abortingBucketSets.nextSetWeak, $.$spc.System.WeakReference);
                            }
                        }
                        while(abortingBucketSets !== null);
                        break;
                    }
                    currentBucketSet = lastBucketSet;
                }
                while(true);
            }
            static $h = 8496389;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":917505,"g":{"r":0,"d":0,"h":55843071237,"f":2},"n":"CurrentTime","d":8496389,"h":51548103941,"f":2}],"m":[{"r":917505,"p":[{"n":"timeout","p":140705793}],"n":"TimeoutTicks","d":8496389,"h":42958169349,"f":8},{"r":140705793,"p":[{"n":"tx","p":2794757}],"n":"RecalcTimeout","d":8496389,"h":47253136645,"f":8},{"r":655361,"p":[{"n":"txNew","p":2794757}],"n":"Add","d":8496389,"h":60138038533,"f":8},{"r":65537,"p":[{"n":"txNew","p":2794757}],"n":"AddIter","d":8496389,"h":64433005829,"f":2},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"Remove","d":8496389,"h":68727973125,"f":40},{"r":65537,"p":[{"n":"state","p":131073}],"n":"ThreadTimer","d":8496389,"h":73022940421,"f":2}],"l":[{"t":138543105,"n":"_timer","d":8496389,"h":4303463685,"f":2},{"t":262145,"n":"_timerEnabled","d":8496389,"h":8598430981,"f":2},{"t":655361,"n":"timerInternalExponent","d":8496389,"h":12893398277,"f":34},{"t":655361,"n":"_timerInterval","d":8496389,"h":17188365573,"f":2},{"t":917505,"n":"_ticks","d":8496389,"h":21483332869,"f":2},{"t":917505,"n":"_lastTimerTime","d":8496389,"h":25778300165,"f":2},{"t":369925,"n":"_headBucketSet","d":8496389,"h":30073267461,"f":2},{"t":500997,"n":"_rwLock","d":8496389,"h":34368234757,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":8496389,"h":38663202053,"f":8}],"h":8496389}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Transactions.TransactionTable`; }
        });
        
        $asm.$cls("$stl.System.Transactions.BucketSet", ($self) => class BucketSet extends $.$spc.System.Object
        {
            /*object?*/ nextSetWeak = null;
            /*BucketSet?*/ prevSet = null;
            /*TransactionTable*/ _table = null;
            /*long*/ _absoluteTimeout = 0n;
            /*Bucket*/ headBucket = null;
            $ctor$1(/*TransactionTable*/ table, /*long*/ absoluteTimeout)
            {
                super.$ctor();
                {
                    this.headBucket = new $.$stl.System.Transactions.Bucket().$ctor$1(this);
                    this._table = table;
                    this._absoluteTimeout = absoluteTimeout;
                }
                return this;
            }
            /*long */ get AbsoluteTimeout()
            {
                return this._absoluteTimeout;
            }
            /*void */ Add(/*InternalTransaction*/ newTx)
            {
                while(!this.headBucket.Add(newTx))
                {
                }
            }
            /*void */ TimeoutTransactions()
            {
                /*Bucket?*/ let currentBucket = this.headBucket;
                do
                {
                    currentBucket.TimeoutTransactions();
                    /*WeakReference?*/ let nextWeakBucket = currentBucket.nextBucketWeak;
                    if (nextWeakBucket !== null)
                    {
                        currentBucket = $.$cast(nextWeakBucket.Target, $.$stl.System.Transactions.Bucket);
                    }
                    else 
                    {
                        currentBucket = null;
                    }
                }
                while(currentBucket !== null);
            }
            static $h = 369925;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":917505,"g":{"r":0,"d":0,"h":34360108293,"f":8},"n":"AbsoluteTimeout","d":369925,"h":30065140997,"f":8}],"m":[{"r":65537,"p":[{"n":"newTx","p":2794757}],"n":"Add","d":369925,"h":38655075589,"f":8},{"r":65537,"n":"TimeoutTransactions","d":369925,"h":42950042885,"f":8}],"l":[{"t":131073,"n":"nextSetWeak","d":369925,"h":4295337221,"f":8},{"t":369925,"n":"prevSet","d":369925,"h":8590304517,"f":8},{"t":8496389,"n":"_table","d":369925,"h":12885271813,"f":2},{"t":917505,"n":"_absoluteTimeout","d":369925,"h":17180239109,"f":2},{"t":304389,"n":"headBucket","d":369925,"h":21475206405,"f":8}],"c":[{"p":[{"n":"table","p":8496389},{"n":"absoluteTimeout","p":917505}],"n":".ctor","o":"$ctor$1","d":369925,"h":25770173701,"f":8}],"h":369925}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Transactions.BucketSet`; }
        });
        
        $asm.$cls("$stl.System.Transactions.Bucket", ($self) => class Bucket extends $.$spc.System.Object
        {
            /*bool*/ _timedOut = false;
            /*int*/ _index = 0;
            /*int*/ _size = 0;
            /*InternalTransaction?[]*/ _transactions = null;
            /*WeakReference?*/ nextBucketWeak = null;
            /*Bucket?*/ _previous = null;
            /*BucketSet*/ _owningSet = null;
            $ctor$1(/*BucketSet*/ owningSet)
            {
                super.$ctor();
                {
                    this._timedOut = false;
                    this._index = -1;
                    this._size = 1024;
                    this._transactions = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$stl.System.Transactions.InternalTransaction), null, [this._size], null);
                    this._owningSet = owningSet;
                }
                return this;
            }
            /*bool */ Add(/*InternalTransaction*/ tx)
            {
                /*int*/ let currentIndex = $.$spc.System.Threading.Interlocked.Increment($.$ref(() => this._index, ($v) => this._index = $v, $.$spc.System.Int32));
                if (currentIndex < this._size)
                {
                    tx._tableBucket = this;
                    tx._bucketIndex = currentIndex;
                    $.$spc.System.Threading.Interlocked.MemoryBarrier();
                    $.$spc.System.Array.$WriteT1.call(this._transactions, tx, currentIndex);
                    if (this._timedOut)
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(tx)
                            {
                                tx.State.Timeout(tx);
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(tx)
                        }
                    }
                }
                else 
                {
                    /*Bucket*/ let newBucket = new $.$stl.System.Transactions.Bucket().$ctor$1(this._owningSet);
                    newBucket.nextBucketWeak = new $.$spc.System.WeakReference().$ctor$1(this);
                    /*Bucket*/ let oldBucket = $.$spc.System.Threading.Interlocked.CompareExchange$14($.$stl.System.Transactions.Bucket, $.$ref(() => this._owningSet.headBucket, ($v) => this._owningSet.headBucket = $v, $.$stl.System.Transactions.Bucket), newBucket, this);
                    if (oldBucket === this)
                    {
                        this._previous = newBucket;
                    }
                    return false;
                }
                return true;
            }
            /*void */ Remove(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Array.$WriteT1.call(this._transactions, null, tx._bucketIndex);
            }
            /*void */ TimeoutTransactions()
            {
                /*int*/ let i;
                /*int*/ let transactionCount = this._index;
                this._timedOut = true;
                $.$spc.System.Threading.Interlocked.MemoryBarrier();
                for(i = 0; i <= transactionCount && i < this._size; i++)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(transactionCount === this._index, "Index changed timing out transactions");
                    /*InternalTransaction?*/ let tx = $.$spc.System.Array.$ReadT1.call(this._transactions, i);
                    if (tx !== null)
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(tx)
                            {
                                tx.State.Timeout(tx);
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(tx)
                        }
                    }
                }
            }
            static $h = 304389;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"tx","p":2794757}],"n":"Add","d":304389,"h":38655010053,"f":8},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"Remove","d":304389,"h":42949977349,"f":8},{"r":65537,"n":"TimeoutTransactions","d":304389,"h":47244944645,"f":8}],"l":[{"t":262145,"n":"_timedOut","d":304389,"h":4295271685,"f":2},{"t":655361,"n":"_index","d":304389,"h":8590238981,"f":2},{"t":655361,"n":"_size","d":304389,"h":12885206277,"f":2},{"t":0,"n":"_transactions","d":304389,"h":17180173573,"f":2},{"t":144769025,"n":"nextBucketWeak","d":304389,"h":21475140869,"f":8},{"t":304389,"n":"_previous","d":304389,"h":25770108165,"f":2},{"t":369925,"n":"_owningSet","d":304389,"h":30065075461,"f":2}],"c":[{"p":[{"n":"owningSet","p":369925}],"n":".ctor","o":"$ctor$1","d":304389,"h":34360042757,"f":8}],"h":304389}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Transactions.Bucket`; }
        });
        
        $asm.$cls("$stl.System.Transactions.CallContextCurrentData", ($self) => class CallContextCurrentData
        {
            /*AsyncLocal<ContextKey?>*/ static s_currentTransaction = null;
            /*ConditionalWeakTable<ContextKey, ContextData>*/ static s_contextDataTable = null;
            static /*ContextData */ CreateOrGetCurrentData(/*ContextKey*/ contextKey)
            {
                $.$stl.System.Transactions.CallContextCurrentData.s_currentTransaction.Value = contextKey;
                return $.$stl.System.Transactions.CallContextCurrentData.s_contextDataTable.GetValue(contextKey, new $.$spc.System.Runtime.CompilerServices.ConditionalWeakTable$$$($.$stl.System.Transactions.ContextKey, $.$stl.System.Transactions.ContextData).CreateValueCallback().$ctor(this,  (/*env*/ env) =>
                {
                    return new $.$stl.System.Transactions.ContextData().$ctor$1(true);
                }, {"r":894213,"p":[{"n":"env","p":959749}],"n":"","d":435461,"h":0,"f":1048578}));
            }
            static /*void */ ClearCurrentData(/*ContextKey?*/ contextKey, /*bool*/ removeContextData)
            {
                /*ContextKey?*/ let key = $.$stl.System.Transactions.CallContextCurrentData.s_currentTransaction.Value;
                if (contextKey !== null || key !== null)
                {
                    if (removeContextData)
                    {
                        $.$stl.System.Transactions.CallContextCurrentData.s_contextDataTable.Remove(contextKey ?? key);
                    }
                    if (key !== null)
                    {
                        $.$stl.System.Transactions.CallContextCurrentData.s_currentTransaction.Value = null;
                    }
                }
            }
            static /*bool */ TryGetCurrentData(/*out ContextData?*/ currentData)
            {
                currentData.$v = null;
                /*ContextKey?*/ let contextKey = $.$stl.System.Transactions.CallContextCurrentData.s_currentTransaction.Value;
                if (contextKey === null)
                {
                    return false;
                }
                else 
                {
                    return $.$stl.System.Transactions.CallContextCurrentData.s_contextDataTable.TryGetValue(contextKey, currentData);
                }
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_currentTransaction = new ($.$spc.System.Threading.AsyncLocal$$($.$stl.System.Transactions.ContextKey))().$ctor$1();
                }
                {
                    this.s_contextDataTable = new ($.$spc.System.Runtime.CompilerServices.ConditionalWeakTable$$$($.$stl.System.Transactions.ContextKey, $.$stl.System.Transactions.ContextData))().$ctor$1();
                }
            }
            static $h = 435461;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":894213,"p":[{"n":"contextKey","p":959749}],"n":"CreateOrGetCurrentData","d":435461,"h":12885337349,"f":33},{"r":65537,"p":[{"n":"contextKey","p":959749},{"n":"removeContextData","p":262145}],"n":"ClearCurrentData","d":435461,"h":17180304645,"f":33},{"r":262145,"p":[{"n":"currentData","p":894213,"f":2}],"n":"TryGetCurrentData","d":435461,"h":21475271941,"f":33}],"l":[{"t":$.$spc.System.Threading.AsyncLocal$$($.$stl.System.Transactions.ContextKey).$h,"n":"s_currentTransaction","d":435461,"h":4295402757,"f":34},{"t":$.$spc.System.Runtime.CompilerServices.ConditionalWeakTable$$$($.$stl.System.Transactions.ContextKey, $.$stl.System.Transactions.ContextData).$h,"n":"s_contextDataTable","d":435461,"h":8590370053,"f":34}],"h":435461}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Transactions.CallContextCurrentData`; }
        });
        
        $asm.$cls("$stl.System.Transactions.ContextKey", ($self) => class ContextKey extends $.$spc.System.Object
        {
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 959749;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"c":[{"n":".ctor","o":"$ctor$1","d":959749,"h":4295927045,"f":1}],"h":959749}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Transactions.ContextKey`; }
        });
        
        $asm.$cls("$stl.System.Transactions.ContextData", ($self) => class ContextData extends $.$spc.System.Object
        {
            /*TransactionScope?*/ CurrentScope = null;
            /*Transaction?*/ CurrentTransaction = null;
            /*DefaultComContextState*/ DefaultComContextState = 0;
            /*WeakReference?*/ WeakDefaultComContext = null;
            /*bool*/ _asyncFlow = false;
            /*ContextData?*/ static t_staticData = null;
            $ctor$1(/*bool*/ asyncFlow)
            {
                super.$ctor();
                {
                    this._asyncFlow = asyncFlow;
                }
                return this;
            }
            static /*ContextData */ get TLSCurrentData()
            {
                return $.$stl.System.Transactions.ContextData.t_staticData ??= new $.$stl.System.Transactions.ContextData().$ctor$1(false);
            }
            static /*ContextData */ set TLSCurrentData(value)
            {
                if (value === null && $.$stl.System.Transactions.ContextData.t_staticData !== null)
                {
                    $.$stl.System.Transactions.ContextData.t_staticData.CurrentScope = null;
                    $.$stl.System.Transactions.ContextData.t_staticData.CurrentTransaction = null;
                    $.$stl.System.Transactions.ContextData.t_staticData.DefaultComContextState = 0/*DefaultComContextState.Unknown*/;
                    $.$stl.System.Transactions.ContextData.t_staticData.WeakDefaultComContext = null;
                }
                else 
                {
                    $.$stl.System.Transactions.ContextData.t_staticData = value;
                }
            }
            static /*ContextData */ LookupContextData(/*TxLookup*/ defaultLookup)
            {
                /*ContextData?*/ let currentData;
                if ($.$stl.System.Transactions.CallContextCurrentData.TryGetCurrentData($.$ref(() => currentData, ($v) => currentData = $v, $.$stl.System.Transactions.ContextData)))
                {
                    if (currentData.CurrentScope === null && $.$stl.System.Transactions.Transaction.op_Equality(currentData.CurrentTransaction, null) && defaultLookup !== 1/*TxLookup.DefaultCallContext*/)
                    {
                        $.$stl.System.Transactions.CallContextCurrentData.ClearCurrentData(null, true);
                        return $.$stl.System.Transactions.ContextData.TLSCurrentData;
                    }
                    return currentData;
                }
                else 
                {
                    return $.$stl.System.Transactions.ContextData.TLSCurrentData;
                }
            }
            static $h = 894213;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":894213,"g":{"r":0,"d":0,"h":38655599877,"f":40},"s":{"r":0,"d":0,"h":42950567173,"f":40},"n":"TLSCurrentData","d":894213,"h":34360632581,"f":40}],"m":[{"r":894213,"p":[{"n":"defaultLookup","p":8627461}],"n":"LookupContextData","d":894213,"h":47245534469,"f":40}],"l":[{"t":5154053,"n":"CurrentScope","d":894213,"h":4295861509,"f":8},{"t":4302085,"n":"CurrentTransaction","d":894213,"h":8590828805,"f":8},{"t":1025285,"n":"DefaultComContextState","d":894213,"h":12885796101,"f":8},{"t":144769025,"n":"WeakDefaultComContext","d":894213,"h":17180763397,"f":8},{"t":262145,"n":"_asyncFlow","d":894213,"h":21475730693,"f":8},{"t":894213,"n":"t_staticData","d":894213,"h":25770697989,"f":34,"a":[{"t":140181505,"c":4435148801}]}],"c":[{"p":[{"n":"asyncFlow","p":262145}],"n":".ctor","o":"$ctor$1","d":894213,"h":30065665285,"f":8}],"h":894213}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Transactions.ContextData`; }
        });
        
        $asm.$cls("$stl.System.Transactions.Oletx.OletxTransaction", ($self) => class OletxTransaction extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*SerializationInfo*/ serializationInfo, /*StreamingContext*/ context)
            {
                super.$ctor();
                {
                    throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                }
                return this;
            }
            /*Exception?*/ InnerException = null;
            /*Guid*/ Identifier;
            /*RealOletxTransaction?*/ RealTransaction = null;
            /*TransactionTraceIdentifier*/ TransactionTraceId;
            /*IsolationLevel*/ IsolationLevel = 0;
            /*Transaction?*/ SavedLtmPromotedTransaction = null;
            /*IPromotedEnlistment */ EnlistVolatile(/*InternalEnlistment*/ internalEnlistment, /*EnlistmentOptions*/ enlistmentOptions)
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransaction.NotSupported();
            }
            /*IPromotedEnlistment */ EnlistDurable(/*Guid*/ resourceManagerIdentifier, /*DurableInternalEnlistment*/ internalEnlistment, /*bool*/ v, /*EnlistmentOptions*/ enlistmentOptions)
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransaction.NotSupported();
            }
            /*void */ Rollback()
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransaction.NotSupported();
            }
            /*OletxDependentTransaction */ DependentClone(/*bool*/ delayCommit)
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransaction.NotSupported();
            }
            /*IPromotedEnlistment */ EnlistVolatile$1(/*VolatileDemultiplexer*/ volatileDemux, /*EnlistmentOptions*/ enlistmentOptions)
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransaction.NotSupported();
            }
            static /*byte[] */ GetExportCookie(/*byte[]*/ whereaboutsCopy)
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransaction.NotSupported();
            }
            static /*byte[] */ GetTransmitterPropagationToken()
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransaction.NotSupported();
            }
            static /*IDtcTransaction */ GetDtcTransaction()
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransaction.NotSupported();
            }
            /*void */ GetObjectData(/*SerializationInfo*/ serializationInfo, /*StreamingContext*/ context)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose()
            {
            }
            static /*Exception */ NotSupported()
            {
                return new $.$spc.System.PlatformNotSupportedException().$ctor$14($.$stl.System.SR.DistributedNotSupported);
            }
            static $_RealOletxTransaction;
            static get RealOletxTransaction()
            {
                let $cls = $.$stl.System.Transactions.Oletx.OletxTransaction;
                return $cls.$_RealOletxTransaction ??= $asm.$ncls("$stl.System.Transactions.Oletx.OletxTransaction.RealOletxTransaction", ($self) => class RealOletxTransaction extends $.$spc.System.Object
                {
                    /*InternalTransaction?*/ InternalTransaction = null;
                    //default reference type constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        return this;
                    }
                    static $h = 3581189;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":2794757,"g":{"r":0,"d":0,"h":12888483077,"f":8},"s":{"r":0,"d":0,"h":17183450373,"f":8},"n":"InternalTransaction","d":3581189,"h":8593515781,"f":8}],"c":[{"n":".ctor","o":"$ctor$1","d":3581189,"h":21478417669,"f":1}],"d":3515653,"h":3581189}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Transactions.Oletx.OletxTransaction.RealOletxTransaction`; }
                }, $cls, ($v) => $cls.$_RealOletxTransaction = $v);
            }
            //Generated interface implemetation for System.Runtime.Serialization.ISerializable.GetObjectData(System.Runtime.Serialization.SerializationInfo, System.Runtime.Serialization.StreamingContext)
            System$Runtime$Serialization$ISerializable$GetObjectData()
            {
                return this.GetObjectData(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this.Identifier = $.$default($.$spc.System.Guid);
                this.TransactionTraceId = $.$default($.$stl.System.Transactions.TransactionTraceIdentifier);
                this.IsolationLevel = 0;
            }
            static $h = 3515653;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":56229889,"g":{"r":0,"d":0,"h":38658221317,"f":8},"s":{"r":0,"d":0,"h":42953188613,"f":8},"n":"Identifier","d":3515653,"h":34363254021,"f":8},{"p":3581189,"g":{"r":0,"d":0,"h":55838090501,"f":8},"s":{"r":0,"d":0,"h":60133057797,"f":8},"n":"RealTransaction","d":3515653,"h":51543123205,"f":8},{"p":8561925,"g":{"r":0,"d":0,"h":73017959685,"f":8},"s":{"r":0,"d":0,"h":77312926981,"f":8},"n":"TransactionTraceId","d":3515653,"h":68722992389,"f":8},{"p":3187973,"g":{"r":0,"d":0,"h":90197828869,"f":8},"s":{"r":0,"d":0,"h":94492796165,"f":8},"n":"IsolationLevel","d":3515653,"h":85902861573,"f":8},{"p":4302085,"g":{"r":0,"d":0,"h":107377698053,"f":8},"s":{"r":0,"d":0,"h":111672665349,"f":8},"n":"SavedLtmPromotedTransaction","d":3515653,"h":103082730757,"f":8}],"m":[{"r":2925829,"p":[{"n":"internalEnlistment","p":2729221},{"n":"enlistmentOptions","p":1877253}],"n":"EnlistVolatile","d":3515653,"h":115967632645,"f":8},{"r":2925829,"p":[{"n":"resourceManagerIdentifier","p":56229889},{"n":"internalEnlistment","p":1615109},{"n":"v","p":262145},{"n":"enlistmentOptions","p":1877253}],"n":"EnlistDurable","d":3515653,"h":120262599941,"f":8},{"r":65537,"n":"Rollback","d":3515653,"h":124557567237,"f":8},{"r":3450117,"p":[{"n":"delayCommit","p":262145}],"n":"DependentClone","d":3515653,"h":128852534533,"f":8},{"r":2925829,"p":[{"n":"volatileDemux","p":8692997},{"n":"enlistmentOptions","p":1877253}],"n":"EnlistVolatile","o":"@$1","d":3515653,"h":133147501829,"f":8},{"r":0,"p":[{"n":"whereaboutsCopy","p":0}],"n":"GetExportCookie","d":3515653,"h":137442469125,"f":40},{"r":0,"n":"GetTransmitterPropagationToken","d":3515653,"h":141737436421,"f":40},{"r":2532613,"n":"GetDtcTransaction","d":3515653,"h":146032403717,"f":40},{"r":65537,"p":[{"n":"serializationInfo","p":113967105},{"n":"context","p":114098177}],"n":"GetObjectData","d":3515653,"h":150327371013,"f":1},{"r":65537,"n":"Dispose","d":3515653,"h":154622338309,"f":8},{"r":47251457,"n":"NotSupported","d":3515653,"h":158917305605,"f":40}],"c":[{"n":".ctor","o":"$ctor$1","d":3515653,"h":4298482949,"f":8},{"p":[{"n":"serializationInfo","p":113967105},{"n":"context","p":114098177}],"n":".ctor","o":"$ctor$2","d":3515653,"h":8593450245,"f":4}],"i":[113377281],"j":[3581189],"h":3515653}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Transactions.Oletx.OletxTransaction`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionScope", ($self) => class TransactionScope extends $.$spc.System.Object
        {
            $ctor$1()
            {
                this.$ctor$2(0/*TransactionScopeOption.Required*/);
                {
                }
                return this;
            }
            $ctor$2(/*TransactionScopeOption*/ scopeOption)
            {
                this.$ctor$4(scopeOption, 0/*TransactionScopeAsyncFlowOption.Suppress*/);
                {
                }
                return this;
            }
            $ctor$3(/*TransactionScopeAsyncFlowOption*/ asyncFlowOption)
            {
                this.$ctor$4(0/*TransactionScopeOption.Required*/, asyncFlowOption);
                {
                }
                return this;
            }
            $ctor$4(/*TransactionScopeOption*/ scopeOption, /*TransactionScopeAsyncFlowOption*/ asyncFlowOption)
            {
                super.$ctor();
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodEnter(0/*TraceSourceType.TraceSourceBase*/, this, "TransactionScope");
                    }
                    this.ValidateAndSetAsyncFlowOption(asyncFlowOption);
                    if (this.NeedToCreateTransaction(scopeOption))
                    {
                        this._committableTransaction = new $.$stl.System.Transactions.CommittableTransaction().$ctor$5();
                        this._expectedCurrent = this._committableTransaction.Clone();
                    }
                    if ($.$stl.System.Transactions.Transaction.op_Equality(null, this._expectedCurrent))
                    {
                        if (etwLog.IsEnabled())
                        {
                            etwLog.TransactionScopeCreated($.$stl.System.Transactions.TransactionTraceIdentifier.Empty, 4/*TransactionScopeResult.NoTransaction*/);
                        }
                    }
                    else 
                    {
                        /*TransactionScopeResult*/ let scopeResult;
                        if ($.$stl.System.Transactions.Transaction.op_Equality(null, this._committableTransaction))
                        {
                            scopeResult = 1/*TransactionScopeResult.UsingExistingCurrent*/;
                        }
                        else 
                        {
                            scopeResult = 0/*TransactionScopeResult.CreatedTransaction*/;
                        }
                        if (etwLog.IsEnabled())
                        {
                            etwLog.TransactionScopeCreated(this._expectedCurrent.TransactionTraceId, scopeResult);
                        }
                    }
                    this.PushScope();
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodExit(0/*TraceSourceType.TraceSourceBase*/, this, "TransactionScope");
                    }
                }
                return this;
            }
            $ctor$5(/*TransactionScopeOption*/ scopeOption, /*TimeSpan*/ scopeTimeout)
            {
                this.$ctor$6(scopeOption, scopeTimeout, 0/*TransactionScopeAsyncFlowOption.Suppress*/);
                {
                }
                return this;
            }
            $ctor$6(/*TransactionScopeOption*/ scopeOption, /*TimeSpan*/ scopeTimeout, /*TransactionScopeAsyncFlowOption*/ asyncFlowOption)
            {
                super.$ctor();
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodEnter(0/*TraceSourceType.TraceSourceBase*/, this, "TransactionScope");
                    }
                    $.$stl.System.Transactions.TransactionScope.ValidateScopeTimeout("scopeTimeout", scopeTimeout);
                    /*TimeSpan*/ let txTimeout = $.$stl.System.Transactions.TransactionManager.ValidateTimeout(scopeTimeout);
                    this.ValidateAndSetAsyncFlowOption(asyncFlowOption);
                    if (this.NeedToCreateTransaction(scopeOption))
                    {
                        this._committableTransaction = new $.$stl.System.Transactions.CommittableTransaction().$ctor$6(txTimeout);
                        this._expectedCurrent = this._committableTransaction.Clone();
                    }
                    if (($.$stl.System.Transactions.Transaction.op_Inequality(null, this._expectedCurrent)) && ($.$stl.System.Transactions.Transaction.op_Equality(null, this._committableTransaction)) && ($.$spc.System.TimeSpan.op_Inequality($.$spc.System.TimeSpan.Zero, scopeTimeout)))
                    {
                        this._scopeTimer = new $.$spc.System.Threading.Timer().$ctor$4(new $.$spc.System.Threading.TimerCallback().$ctor($.$stl.System.Transactions.TransactionScope, $.$stl.System.Transactions.TransactionScope.TimerCallback), this, scopeTimeout, $.$spc.System.TimeSpan.Zero);
                    }
                    if ($.$stl.System.Transactions.Transaction.op_Equality(null, this._expectedCurrent))
                    {
                        if (etwLog.IsEnabled())
                        {
                            etwLog.TransactionScopeCreated($.$stl.System.Transactions.TransactionTraceIdentifier.Empty, 4/*TransactionScopeResult.NoTransaction*/);
                        }
                    }
                    else 
                    {
                        /*TransactionScopeResult*/ let scopeResult;
                        if ($.$stl.System.Transactions.Transaction.op_Equality(null, this._committableTransaction))
                        {
                            scopeResult = 1/*TransactionScopeResult.UsingExistingCurrent*/;
                        }
                        else 
                        {
                            scopeResult = 0/*TransactionScopeResult.CreatedTransaction*/;
                        }
                        if (etwLog.IsEnabled())
                        {
                            etwLog.TransactionScopeCreated(this._expectedCurrent.TransactionTraceId, scopeResult);
                        }
                    }
                    this.PushScope();
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodExit(0/*TraceSourceType.TraceSourceBase*/, this, "TransactionScope");
                    }
                }
                return this;
            }
            $ctor$7(/*TransactionScopeOption*/ scopeOption, /*TransactionOptions*/ transactionOptions)
            {
                this.$ctor$8(scopeOption, transactionOptions.Clone(), 0/*TransactionScopeAsyncFlowOption.Suppress*/);
                {
                }
                return this;
            }
            $ctor$8(/*TransactionScopeOption*/ scopeOption, /*TransactionOptions*/ transactionOptions, /*TransactionScopeAsyncFlowOption*/ asyncFlowOption)
            {
                super.$ctor();
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodEnter(0/*TraceSourceType.TraceSourceBase*/, this, "TransactionScope");
                    }
                    $.$stl.System.Transactions.TransactionScope.ValidateScopeTimeout("transactionOptions.Timeout", transactionOptions.Timeout);
                    /*TimeSpan*/ let scopeTimeout = transactionOptions.Timeout;
                    transactionOptions.Timeout = $.$stl.System.Transactions.TransactionManager.ValidateTimeout(transactionOptions.Timeout);
                    $.$stl.System.Transactions.TransactionManager.ValidateIsolationLevel(transactionOptions.IsolationLevel);
                    this.ValidateAndSetAsyncFlowOption(asyncFlowOption);
                    if (this.NeedToCreateTransaction(scopeOption))
                    {
                        this._committableTransaction = new $.$stl.System.Transactions.CommittableTransaction().$ctor$7(transactionOptions.Clone());
                        this._expectedCurrent = this._committableTransaction.Clone();
                    }
                    else 
                    {
                        if ($.$stl.System.Transactions.Transaction.op_Inequality(null, this._expectedCurrent))
                        {
                            if ((6/*IsolationLevel.Unspecified*/ !== transactionOptions.IsolationLevel) && (this._expectedCurrent.IsolationLevel !== transactionOptions.IsolationLevel))
                            {
                                throw new $.$spc.System.ArgumentException().$ctor$13($.$stl.System.SR.TransactionScopeIsolationLevelDifferentFromTransaction, "transactionOptions");
                            }
                        }
                    }
                    if (($.$stl.System.Transactions.Transaction.op_Inequality(null, this._expectedCurrent)) && ($.$stl.System.Transactions.Transaction.op_Equality(null, this._committableTransaction)) && ($.$spc.System.TimeSpan.op_Inequality($.$spc.System.TimeSpan.Zero, scopeTimeout)))
                    {
                        this._scopeTimer = new $.$spc.System.Threading.Timer().$ctor$4(new $.$spc.System.Threading.TimerCallback().$ctor($.$stl.System.Transactions.TransactionScope, $.$stl.System.Transactions.TransactionScope.TimerCallback), this, scopeTimeout, $.$spc.System.TimeSpan.Zero);
                    }
                    if ($.$stl.System.Transactions.Transaction.op_Equality(null, this._expectedCurrent))
                    {
                        if (etwLog.IsEnabled())
                        {
                            etwLog.TransactionScopeCreated($.$stl.System.Transactions.TransactionTraceIdentifier.Empty, 4/*TransactionScopeResult.NoTransaction*/);
                        }
                    }
                    else 
                    {
                        /*TransactionScopeResult*/ let scopeResult;
                        if ($.$stl.System.Transactions.Transaction.op_Equality(null, this._committableTransaction))
                        {
                            scopeResult = 1/*TransactionScopeResult.UsingExistingCurrent*/;
                        }
                        else 
                        {
                            scopeResult = 0/*TransactionScopeResult.CreatedTransaction*/;
                        }
                        if (etwLog.IsEnabled())
                        {
                            etwLog.TransactionScopeCreated(this._expectedCurrent.TransactionTraceId, scopeResult);
                        }
                    }
                    this.PushScope();
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodExit(0/*TraceSourceType.TraceSourceBase*/, this, "TransactionScope");
                    }
                }
                return this;
            }
            $ctor$9(/*TransactionScopeOption*/ scopeOption, /*TransactionOptions*/ transactionOptions, /*EnterpriseServicesInteropOption*/ interopOption)
            {
                super.$ctor();
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodEnter(0/*TraceSourceType.TraceSourceBase*/, this, "TransactionScope");
                    }
                    $.$stl.System.Transactions.TransactionScope.ValidateScopeTimeout("transactionOptions.Timeout", transactionOptions.Timeout);
                    /*TimeSpan*/ let scopeTimeout = transactionOptions.Timeout;
                    transactionOptions.Timeout = $.$stl.System.Transactions.TransactionManager.ValidateTimeout(transactionOptions.Timeout);
                    $.$stl.System.Transactions.TransactionManager.ValidateIsolationLevel(transactionOptions.IsolationLevel);
                    $.$stl.System.Transactions.TransactionScope.ValidateInteropOption(interopOption);
                    this._interopModeSpecified = true;
                    this._interopOption = interopOption;
                    if (this.NeedToCreateTransaction(scopeOption))
                    {
                        this._committableTransaction = new $.$stl.System.Transactions.CommittableTransaction().$ctor$7(transactionOptions.Clone());
                        this._expectedCurrent = this._committableTransaction.Clone();
                    }
                    else 
                    {
                        if ($.$stl.System.Transactions.Transaction.op_Inequality(null, this._expectedCurrent))
                        {
                            if ((6/*IsolationLevel.Unspecified*/ !== transactionOptions.IsolationLevel) && (this._expectedCurrent.IsolationLevel !== transactionOptions.IsolationLevel))
                            {
                                throw new $.$spc.System.ArgumentException().$ctor$13($.$stl.System.SR.TransactionScopeIsolationLevelDifferentFromTransaction, "transactionOptions");
                            }
                        }
                    }
                    if (($.$stl.System.Transactions.Transaction.op_Inequality(null, this._expectedCurrent)) && ($.$stl.System.Transactions.Transaction.op_Equality(null, this._committableTransaction)) && ($.$spc.System.TimeSpan.op_Inequality($.$spc.System.TimeSpan.Zero, scopeTimeout)))
                    {
                        this._scopeTimer = new $.$spc.System.Threading.Timer().$ctor$4(new $.$spc.System.Threading.TimerCallback().$ctor($.$stl.System.Transactions.TransactionScope, $.$stl.System.Transactions.TransactionScope.TimerCallback), this, scopeTimeout, $.$spc.System.TimeSpan.Zero);
                    }
                    if ($.$stl.System.Transactions.Transaction.op_Equality(null, this._expectedCurrent))
                    {
                        if (etwLog.IsEnabled())
                        {
                            etwLog.TransactionScopeCreated($.$stl.System.Transactions.TransactionTraceIdentifier.Empty, 4/*TransactionScopeResult.NoTransaction*/);
                        }
                    }
                    else 
                    {
                        /*TransactionScopeResult*/ let scopeResult;
                        if ($.$stl.System.Transactions.Transaction.op_Equality(null, this._committableTransaction))
                        {
                            scopeResult = 1/*TransactionScopeResult.UsingExistingCurrent*/;
                        }
                        else 
                        {
                            scopeResult = 0/*TransactionScopeResult.CreatedTransaction*/;
                        }
                        if (etwLog.IsEnabled())
                        {
                            etwLog.TransactionScopeCreated(this._expectedCurrent.TransactionTraceId, scopeResult);
                        }
                    }
                    this.PushScope();
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodExit(0/*TraceSourceType.TraceSourceBase*/, this, "TransactionScope");
                    }
                }
                return this;
            }
            $ctor$10(/*Transaction*/ transactionToUse)
            {
                this.$ctor$11(transactionToUse, 0/*TransactionScopeAsyncFlowOption.Suppress*/);
                {
                }
                return this;
            }
            $ctor$11(/*Transaction*/ transactionToUse, /*TransactionScopeAsyncFlowOption*/ asyncFlowOption)
            {
                super.$ctor();
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodEnter(0/*TraceSourceType.TraceSourceBase*/, this, "TransactionScope");
                    }
                    this.ValidateAndSetAsyncFlowOption(asyncFlowOption);
                    this.Initialize(transactionToUse, $.$spc.System.TimeSpan.Zero, false);
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodExit(0/*TraceSourceType.TraceSourceBase*/, this, "TransactionScope");
                    }
                }
                return this;
            }
            $ctor$12(/*Transaction*/ transactionToUse, /*TimeSpan*/ scopeTimeout)
            {
                this.$ctor$13(transactionToUse, scopeTimeout, 0/*TransactionScopeAsyncFlowOption.Suppress*/);
                {
                }
                return this;
            }
            $ctor$13(/*Transaction*/ transactionToUse, /*TimeSpan*/ scopeTimeout, /*TransactionScopeAsyncFlowOption*/ asyncFlowOption)
            {
                super.$ctor();
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodEnter(0/*TraceSourceType.TraceSourceBase*/, this, "TransactionScope");
                    }
                    this.ValidateAndSetAsyncFlowOption(asyncFlowOption);
                    this.Initialize(transactionToUse, scopeTimeout, false);
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodExit(0/*TraceSourceType.TraceSourceBase*/, this, "TransactionScope");
                    }
                }
                return this;
            }
            $ctor$14(/*Transaction*/ transactionToUse, /*TimeSpan*/ scopeTimeout, /*EnterpriseServicesInteropOption*/ interopOption)
            {
                super.$ctor();
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodEnter(0/*TraceSourceType.TraceSourceBase*/, this, "TransactionScope");
                    }
                    $.$stl.System.Transactions.TransactionScope.ValidateInteropOption(interopOption);
                    this._interopOption = interopOption;
                    this.Initialize(transactionToUse, scopeTimeout, true);
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodExit(0/*TraceSourceType.TraceSourceBase*/, this, "TransactionScope");
                    }
                }
                return this;
            }
            /*bool */ NeedToCreateTransaction(/*TransactionScopeOption*/ scopeOption)
            {
                /*bool*/ let retVal = false;
                this.CommonInitialize();
                switch(scopeOption)
                {
                    case 2/*TransactionScopeOption.Suppress*/:
                    this._expectedCurrent = null;
                    retVal = false;
                    break;
                    case 0/*TransactionScopeOption.Required*/:
                    this._expectedCurrent = this._savedCurrent;
                    if ($.$stl.System.Transactions.Transaction.op_Equality(null, this._expectedCurrent))
                    {
                        retVal = true;
                    }
                    break;
                    case 1/*TransactionScopeOption.RequiresNew*/:
                    retVal = true;
                    break;
                    default:
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("scopeOption");
                }
                return retVal;
            }
            /*void */ Initialize(/*Transaction*/ transactionToUse, /*TimeSpan*/ scopeTimeout, /*bool*/ interopModeSpecified)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(transactionToUse, "transactionToUse");
                $.$stl.System.Transactions.TransactionScope.ValidateScopeTimeout("scopeTimeout", scopeTimeout);
                this.CommonInitialize();
                if ($.$spc.System.TimeSpan.op_Inequality($.$spc.System.TimeSpan.Zero, scopeTimeout))
                {
                    this._scopeTimer = new $.$spc.System.Threading.Timer().$ctor$4(new $.$spc.System.Threading.TimerCallback().$ctor($.$stl.System.Transactions.TransactionScope, $.$stl.System.Transactions.TransactionScope.TimerCallback), this, scopeTimeout, $.$spc.System.TimeSpan.Zero);
                }
                this._expectedCurrent = transactionToUse;
                this._interopModeSpecified = interopModeSpecified;
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionScopeCreated(this._expectedCurrent.TransactionTraceId, 2/*TransactionScopeResult.TransactionPassed*/);
                }
                this.PushScope();
            }
            /*void */ Dispose()
            {
                /*bool*/ let successful = false;
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(0/*TraceSourceType.TraceSourceBase*/, this, "Dispose");
                }
                if (this._disposed)
                {
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodExit(0/*TraceSourceType.TraceSourceBase*/, this, "Dispose");
                    }
                    return;
                }
                if ((this._scopeThread !== $.$spc.System.Threading.Thread.CurrentThread) && !this.AsyncFlowEnabled)
                {
                    if (etwLog.IsEnabled())
                    {
                        etwLog.InvalidOperation("TransactionScope", "InvalidScopeThread");
                    }
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$stl.System.SR.InvalidScopeThread);
                }
                /*Exception?*/ let exToThrow = null;
                try
                {
                    this._disposed = true;
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._threadContextData !== null, "_threadContextData != null");
                    /*TransactionScope?*/ let actualCurrentScope = this._threadContextData.CurrentScope;
                    /*Transaction?*/ let contextTransaction = null;
                    /*Transaction?*/ let current = $.$stl.System.Transactions.Transaction.FastGetTransaction(actualCurrentScope, this._threadContextData, $.$ref(() => contextTransaction, ($v) => contextTransaction = $v, $.$stl.System.Transactions.Transaction));
                    if (!$.$spc.System.Object.Equals.call(this, actualCurrentScope))
                    {
                        if (actualCurrentScope === null)
                        {
                            /*Transaction?*/ let rollbackTransaction = this._committableTransaction ?? this._dependentTransaction;
                            $.$spc.System.Diagnostics.Debug.Assert$1($.$stl.System.Transactions.Transaction.op_Inequality(rollbackTransaction, null), "rollbackTransaction != null");
                            rollbackTransaction.Rollback();
                            successful = true;
                            throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException$1(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionScopeInvalidNesting, null, rollbackTransaction.DistributedTxId);
                        }
                        else if (0/*EnterpriseServicesInteropOption.None*/ === actualCurrentScope._interopOption)
                        {
                            if ((($.$stl.System.Transactions.Transaction.op_Inequality(null, actualCurrentScope._expectedCurrent)) && (!$.$stl.System.Transactions.Transaction.Equals.call(actualCurrentScope._expectedCurrent, current))) || (($.$stl.System.Transactions.Transaction.op_Inequality(null, current)) && ($.$stl.System.Transactions.Transaction.op_Equality(null, actualCurrentScope._expectedCurrent))))
                            {
                                /*TransactionTraceIdentifier*/ let myId;
                                /*TransactionTraceIdentifier*/ let currentId;
                                if ($.$stl.System.Transactions.Transaction.op_Equality(null, current))
                                {
                                    currentId = $.$stl.System.Transactions.TransactionTraceIdentifier.Empty;
                                }
                                else 
                                {
                                    currentId = current.TransactionTraceId;
                                }
                                if ($.$stl.System.Transactions.Transaction.op_Equality(null, this._expectedCurrent))
                                {
                                    myId = $.$stl.System.Transactions.TransactionTraceIdentifier.Empty;
                                }
                                else 
                                {
                                    myId = this._expectedCurrent.TransactionTraceId;
                                }
                                if (etwLog.IsEnabled())
                                {
                                    etwLog.TransactionScopeCurrentChanged(currentId, myId);
                                }
                                exToThrow = $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException$1(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionScopeIncorrectCurrent, null, $.$stl.System.Transactions.Transaction.op_Equality(current, null) ? $.$spc.System.Guid.Empty : current.DistributedTxId);
                                if ($.$stl.System.Transactions.Transaction.op_Inequality(null, current))
                                {
                                    try
                                    {
                                        current.Rollback();
                                    }
                                    catch($e)
                                    {
                                        if ($e instanceof $.$stl.System.Transactions.TransactionException)
                                        {
                                        }
                                        else if ($e instanceof $.$spc.System.ObjectDisposedException)
                                        {
                                        }
                                        else
                                        {
                                            throw $e;
                                        }
                                    }
                                }
                            }
                        }
                        while(!$.$spc.System.Object.Equals.call(this, actualCurrentScope))
                        {
                            if (null === exToThrow)
                            {
                                exToThrow = $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException$1(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionScopeInvalidNesting, null, $.$stl.System.Transactions.Transaction.op_Equality(current, null) ? $.$spc.System.Guid.Empty : current.DistributedTxId);
                            }
                            if ($.$stl.System.Transactions.Transaction.op_Equality(null, actualCurrentScope._expectedCurrent))
                            {
                                if (etwLog.IsEnabled())
                                {
                                    etwLog.TransactionScopeNestedIncorrectly($.$stl.System.Transactions.TransactionTraceIdentifier.Empty);
                                }
                            }
                            else 
                            {
                                if (etwLog.IsEnabled())
                                {
                                    etwLog.TransactionScopeNestedIncorrectly(actualCurrentScope._expectedCurrent.TransactionTraceId);
                                }
                            }
                            actualCurrentScope._complete = false;
                            try
                            {
                                actualCurrentScope.InternalDispose();
                            }
                            catch($e)
                            {
                            }
                            actualCurrentScope = this._threadContextData.CurrentScope;
                            this._complete = false;
                        }
                    }
                    else 
                    {
                        if (0/*EnterpriseServicesInteropOption.None*/ === this._interopOption)
                        {
                            if ((($.$stl.System.Transactions.Transaction.op_Inequality(null, this._expectedCurrent)) && (!$.$stl.System.Transactions.Transaction.Equals.call(this._expectedCurrent, current))) || (($.$stl.System.Transactions.Transaction.op_Inequality(null, current)) && ($.$stl.System.Transactions.Transaction.op_Equality(null, this._expectedCurrent))))
                            {
                                /*TransactionTraceIdentifier*/ let myId;
                                /*TransactionTraceIdentifier*/ let currentId;
                                if ($.$stl.System.Transactions.Transaction.op_Equality(null, current))
                                {
                                    currentId = $.$stl.System.Transactions.TransactionTraceIdentifier.Empty;
                                }
                                else 
                                {
                                    currentId = current.TransactionTraceId;
                                }
                                if ($.$stl.System.Transactions.Transaction.op_Equality(null, this._expectedCurrent))
                                {
                                    myId = $.$stl.System.Transactions.TransactionTraceIdentifier.Empty;
                                }
                                else 
                                {
                                    myId = this._expectedCurrent.TransactionTraceId;
                                }
                                if (etwLog.IsEnabled())
                                {
                                    etwLog.TransactionScopeCurrentChanged(currentId, myId);
                                }
                                if (null === exToThrow)
                                {
                                    exToThrow = $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException$1(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionScopeIncorrectCurrent, null, $.$stl.System.Transactions.Transaction.op_Equality(current, null) ? $.$spc.System.Guid.Empty : current.DistributedTxId);
                                }
                                if ($.$stl.System.Transactions.Transaction.op_Inequality(null, current))
                                {
                                    try
                                    {
                                        current.Rollback();
                                    }
                                    catch($e)
                                    {
                                        if ($e instanceof $.$stl.System.Transactions.TransactionException)
                                        {
                                        }
                                        else if ($e instanceof $.$spc.System.ObjectDisposedException)
                                        {
                                        }
                                        else
                                        {
                                            throw $e;
                                        }
                                    }
                                }
                                this._complete = false;
                            }
                        }
                    }
                    successful = true;
                }
                finally
                {
                    {
                        if (!successful)
                        {
                            this.PopScope();
                        }
                    }
                }
                this.InternalDispose();
                if (null !== exToThrow)
                {
                    throw exToThrow;
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(0/*TraceSourceType.TraceSourceBase*/, this, "Dispose");
                }
            }
            /*void */ InternalDispose()
            {
                this._disposed = true;
                try
                {
                    this.PopScope();
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if ($.$stl.System.Transactions.Transaction.op_Equality(null, this._expectedCurrent))
                    {
                        if (etwLog.IsEnabled())
                        {
                            etwLog.TransactionScopeDisposed($.$stl.System.Transactions.TransactionTraceIdentifier.Empty);
                        }
                    }
                    else 
                    {
                        if (etwLog.IsEnabled())
                        {
                            etwLog.TransactionScopeDisposed(this._expectedCurrent.TransactionTraceId);
                        }
                    }
                    if ($.$stl.System.Transactions.Transaction.op_Inequality(null, this._expectedCurrent))
                    {
                        if (!this._complete)
                        {
                            if (etwLog.IsEnabled())
                            {
                                etwLog.TransactionScopeIncomplete(this._expectedCurrent.TransactionTraceId);
                            }
                            /*Transaction?*/ let rollbackTransaction = this._committableTransaction ?? this._dependentTransaction;
                            $.$spc.System.Diagnostics.Debug.Assert$1($.$stl.System.Transactions.Transaction.op_Inequality(rollbackTransaction, null), "rollbackTransaction != null");
                            rollbackTransaction.Rollback();
                        }
                        else 
                        {
                            if ($.$stl.System.Transactions.Transaction.op_Inequality(null, this._committableTransaction))
                            {
                                this._committableTransaction.Commit();
                            }
                            else 
                            {
                                $.$spc.System.Diagnostics.Debug.Assert$1($.$stl.System.Transactions.Transaction.op_Inequality(null, this._dependentTransaction), "null != this.dependentTransaction");
                                this._dependentTransaction.Complete();
                            }
                        }
                    }
                }
                finally
                {
                    {
                        this._scopeTimer?.Dispose$1();
                        if ($.$stl.System.Transactions.Transaction.op_Inequality(null, this._committableTransaction))
                        {
                            this._committableTransaction.Dispose();
                            $.$spc.System.Diagnostics.Debug.Assert$1($.$stl.System.Transactions.Transaction.op_Inequality(this._expectedCurrent, null), "_expectedCurrent != null");
                            this._expectedCurrent.Dispose();
                        }
                        this._dependentTransaction?.Dispose();
                    }
                }
            }
            /*void */ Complete()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(0/*TraceSourceType.TraceSourceBase*/, this, "Complete");
                }
                $.$spc.System.ObjectDisposedException.ThrowIf(this._disposed, this);
                if (this._complete)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.DisposeScope, null);
                }
                this._complete = true;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(0/*TraceSourceType.TraceSourceBase*/, this, "Complete");
                }
            }
            static /*void */ TimerCallback(/*object?*/ state)
            {
                /*TransactionScope?*/ let scope = $.$as(state, $.$stl.System.Transactions.TransactionScope);
                if (null === scope)
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.InternalError("TransactionScopeTimerObjectInvalid");
                    }
                    throw $.$stl.System.Transactions.TransactionException.Create($.$stl.System.SR.InternalError + $.$stl.System.SR.TransactionScopeTimerObjectInvalid, null);
                }
                scope.Timeout();
            }
            /*void */ Timeout()
            {
                if ((!this._complete) && ($.$stl.System.Transactions.Transaction.op_Inequality(null, this._expectedCurrent)))
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.TransactionScopeTimeout(this._expectedCurrent.TransactionTraceId);
                    }
                    try
                    {
                        this._expectedCurrent.Rollback();
                    }
                    catch($e)
                    {
                        if ($e instanceof $.$spc.System.ObjectDisposedException)
                        {
                            let ex = $e;
                            if (etwLog.IsEnabled())
                            {
                                etwLog.ExceptionConsumed(0/*TraceSourceType.TraceSourceBase*/, ex);
                            }
                        }
                        else if ($e instanceof $.$stl.System.Transactions.TransactionException)
                        {
                            let txEx = $e;
                            if (etwLog.IsEnabled())
                            {
                                etwLog.ExceptionConsumed(0/*TraceSourceType.TraceSourceBase*/, txEx);
                            }
                        }
                        else
                        {
                            throw $e;
                        }
                    }
                }
            }
            /*void */ CommonInitialize()
            {
                this.ContextKey = new $.$stl.System.Transactions.ContextKey().$ctor$1();
                this._complete = false;
                this._dependentTransaction = null;
                this._disposed = false;
                this._committableTransaction = null;
                this._expectedCurrent = null;
                this._scopeTimer = null;
                this._scopeThread = $.$spc.System.Threading.Thread.CurrentThread;
                $.$stl.System.Transactions.Transaction.GetCurrentTransactionAndScope(this.AsyncFlowEnabled ? 1/*TxLookup.DefaultCallContext*/ : 2/*TxLookup.DefaultTLS*/, $.$ref(() => this._savedCurrent, ($v) => this._savedCurrent = $v, $.$stl.System.Transactions.Transaction), $.$ref(() => this._savedCurrentScope, ($v) => this._savedCurrentScope = $v, $.$stl.System.Transactions.TransactionScope), $.$ref(() => this._contextTransaction, ($v) => this._contextTransaction = $v, $.$stl.System.Transactions.Transaction));
                this.ValidateAsyncFlowOptionAndESInteropOption();
            }
            /*void */ PushScope()
            {
                if (!this._interopModeSpecified)
                {
                    this._interopOption = $.$stl.System.Transactions.Transaction.InteropMode(this._savedCurrentScope);
                }
                this.SaveTLSContextData();
                if (this.AsyncFlowEnabled)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(this.ContextKey !== null, "ContextKey != null");
                    this._threadContextData = $.$stl.System.Transactions.CallContextCurrentData.CreateOrGetCurrentData(this.ContextKey);
                    if (this._savedCurrentScope === null && $.$stl.System.Transactions.Transaction.op_Equality(this._savedCurrent, null))
                    {
                        $.$stl.System.Transactions.ContextData.TLSCurrentData = null;
                    }
                }
                else 
                {
                    this._threadContextData = $.$stl.System.Transactions.ContextData.TLSCurrentData;
                    $.$stl.System.Transactions.CallContextCurrentData.ClearCurrentData(this.ContextKey, false);
                }
                this.SetCurrent(this._expectedCurrent);
                this._threadContextData.CurrentScope = this;
            }
            /*void */ PopScope()
            {
                /*bool*/ let shouldRestoreContextData = true;
                if (this.AsyncFlowEnabled)
                {
                    $.$stl.System.Transactions.CallContextCurrentData.ClearCurrentData(this.ContextKey, true);
                }
                if (this._scopeThread === $.$spc.System.Threading.Thread.CurrentThread)
                {
                    this.RestoreSavedTLSContextData();
                }
                if (this._savedCurrentScope !== null)
                {
                    if (this._savedCurrentScope.AsyncFlowEnabled)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._savedCurrentScope.ContextKey !== null, "_savedCurrentScope.ContextKey != null");
                        this._threadContextData = $.$stl.System.Transactions.CallContextCurrentData.CreateOrGetCurrentData(this._savedCurrentScope.ContextKey);
                    }
                    else 
                    {
                        if (this._savedCurrentScope._scopeThread !== $.$spc.System.Threading.Thread.CurrentThread)
                        {
                            shouldRestoreContextData = false;
                            $.$stl.System.Transactions.ContextData.TLSCurrentData = null;
                        }
                        else 
                        {
                            this._threadContextData = $.$stl.System.Transactions.ContextData.TLSCurrentData;
                        }
                        $.$stl.System.Transactions.CallContextCurrentData.ClearCurrentData(this._savedCurrentScope.ContextKey, false);
                    }
                }
                else 
                {
                    $.$stl.System.Transactions.CallContextCurrentData.ClearCurrentData(null, false);
                    if (this._scopeThread !== $.$spc.System.Threading.Thread.CurrentThread)
                    {
                        shouldRestoreContextData = false;
                        $.$stl.System.Transactions.ContextData.TLSCurrentData = null;
                    }
                    else 
                    {
                        $.$stl.System.Transactions.ContextData.TLSCurrentData = this._threadContextData;
                    }
                }
                if (shouldRestoreContextData)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._threadContextData !== null, "_threadContextData != null");
                    this._threadContextData.CurrentScope = this._savedCurrentScope;
                    this.RestoreCurrent();
                }
            }
            /*void */ SetCurrent(/*Transaction?*/ newCurrent)
            {
                if (this._dependentTransaction === null && this._committableTransaction === null)
                {
                    if ($.$stl.System.Transactions.Transaction.op_Inequality(newCurrent, null))
                    {
                        this._dependentTransaction = newCurrent.DependentClone(1/*DependentCloneOption.RollbackIfNotComplete*/);
                    }
                }
                switch(this._interopOption)
                {
                    case 0/*EnterpriseServicesInteropOption.None*/:
                    this._threadContextData.CurrentTransaction = newCurrent;
                    break;
                    case 1/*EnterpriseServicesInteropOption.Automatic*/:
                    $.$stl.System.Transactions.EnterpriseServices.VerifyEnterpriseServicesOk();
                    if ($.$stl.System.Transactions.EnterpriseServices.UseServiceDomainForCurrent())
                    {
                        $.$stl.System.Transactions.EnterpriseServices.PushServiceDomain();
                    }
                    else 
                    {
                        this._threadContextData.CurrentTransaction = newCurrent;
                    }
                    break;
                    case 2/*EnterpriseServicesInteropOption.Full*/:
                    $.$stl.System.Transactions.EnterpriseServices.VerifyEnterpriseServicesOk();
                    $.$stl.System.Transactions.EnterpriseServices.PushServiceDomain();
                    break;
                }
            }
            /*void */ SaveTLSContextData()
            {
                this._savedTLSContextData ??= new $.$stl.System.Transactions.ContextData().$ctor$1(false);
                this._savedTLSContextData.CurrentScope = $.$stl.System.Transactions.ContextData.TLSCurrentData.CurrentScope;
                this._savedTLSContextData.CurrentTransaction = $.$stl.System.Transactions.ContextData.TLSCurrentData.CurrentTransaction;
                this._savedTLSContextData.DefaultComContextState = $.$stl.System.Transactions.ContextData.TLSCurrentData.DefaultComContextState;
                this._savedTLSContextData.WeakDefaultComContext = $.$stl.System.Transactions.ContextData.TLSCurrentData.WeakDefaultComContext;
            }
            /*void */ RestoreSavedTLSContextData()
            {
                if (this._savedTLSContextData !== null)
                {
                    $.$stl.System.Transactions.ContextData.TLSCurrentData.CurrentScope = this._savedTLSContextData.CurrentScope;
                    $.$stl.System.Transactions.ContextData.TLSCurrentData.CurrentTransaction = this._savedTLSContextData.CurrentTransaction;
                    $.$stl.System.Transactions.ContextData.TLSCurrentData.DefaultComContextState = this._savedTLSContextData.DefaultComContextState;
                    $.$stl.System.Transactions.ContextData.TLSCurrentData.WeakDefaultComContext = this._savedTLSContextData.WeakDefaultComContext;
                }
            }
            /*void */ RestoreCurrent()
            {
                if ($.$stl.System.Transactions.EnterpriseServices.CreatedServiceDomain)
                {
                    $.$stl.System.Transactions.EnterpriseServices.LeaveServiceDomain();
                }
                this._threadContextData.CurrentTransaction = this._contextTransaction;
            }
            static /*void */ ValidateInteropOption(/*EnterpriseServicesInteropOption*/ interopOption)
            {
                if (interopOption < 0/*EnterpriseServicesInteropOption.None*/ || interopOption > 2/*EnterpriseServicesInteropOption.Full*/)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("interopOption");
                }
            }
            static /*void */ ValidateScopeTimeout(/*string?*/ paramName, /*TimeSpan*/ scopeTimeout)
            {
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfLessThan($.$spc.System.TimeSpan, scopeTimeout, $.$spc.System.TimeSpan.Zero, paramName);
            }
            /*void */ ValidateAndSetAsyncFlowOption(/*TransactionScopeAsyncFlowOption*/ asyncFlowOption)
            {
                if (asyncFlowOption < 0/*TransactionScopeAsyncFlowOption.Suppress*/ || asyncFlowOption > 1/*TransactionScopeAsyncFlowOption.Enabled*/)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("asyncFlowOption");
                }
                if (asyncFlowOption === 1/*TransactionScopeAsyncFlowOption.Enabled*/)
                {
                    this.AsyncFlowEnabled = true;
                }
            }
            /*void */ ValidateAsyncFlowOptionAndESInteropOption()
            {
                if (this.AsyncFlowEnabled)
                {
                    /*EnterpriseServicesInteropOption*/ let currentInteropOption = this._interopOption;
                    if (!this._interopModeSpecified)
                    {
                        currentInteropOption = $.$stl.System.Transactions.Transaction.InteropMode(this._savedCurrentScope);
                    }
                    if (currentInteropOption !== 0/*EnterpriseServicesInteropOption.None*/)
                    {
                        throw new $.$spc.System.NotSupportedException().$ctor$10($.$stl.System.SR.AsyncFlowAndESInteropNotSupported);
                    }
                }
            }
            /*bool*/ _complete = false;
            /*bool */ get ScopeComplete()
            {
                return this._complete;
            }
            /*Transaction?*/ _savedCurrent = null;
            /*Transaction?*/ _contextTransaction = null;
            /*TransactionScope?*/ _savedCurrentScope = null;
            /*ContextData?*/ _threadContextData = null;
            /*ContextData?*/ _savedTLSContextData = null;
            /*Transaction?*/ _expectedCurrent = null;
            /*CommittableTransaction?*/ _committableTransaction = null;
            /*DependentTransaction?*/ _dependentTransaction = null;
            /*bool*/ _disposed = false;
            /*Timer?*/ _scopeTimer = null;
            /*Thread?*/ _scopeThread = null;
            /*bool*/ _interopModeSpecified = false;
            /*EnterpriseServicesInteropOption*/ _interopOption = 0;
            /*EnterpriseServicesInteropOption */ get InteropMode()
            {
                return this._interopOption;
            }
            /*ContextKey?*/ ContextKey = null;
            /*bool*/ AsyncFlowEnabled = false;
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this.AsyncFlowEnabled = false;
            }
            static $h = 5154053;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":150329009413,"f":8},"n":"ScopeComplete","d":5154053,"h":146034042117,"f":8},{"p":2270469,"g":{"r":0,"d":0,"h":214753518853,"f":8},"n":"InteropMode","d":5154053,"h":210458551557,"f":8},{"p":959749,"g":{"r":0,"d":0,"h":227638420741,"f":8},"s":{"r":0,"d":0,"h":231933388037,"f":2},"n":"ContextKey","d":5154053,"h":223343453445,"f":8},{"p":262145,"g":{"r":0,"d":0,"h":244818289925,"f":8},"s":{"r":0,"d":0,"h":249113257221,"f":2},"n":"AsyncFlowEnabled","d":5154053,"h":240523322629,"f":8}],"m":[{"r":262145,"p":[{"n":"scopeOption","p":5285125}],"n":"NeedToCreateTransaction","d":5154053,"h":64429663493,"f":2},{"r":65537,"p":[{"n":"transactionToUse","p":4302085},{"n":"scopeTimeout","p":140705793},{"n":"interopModeSpecified","p":262145}],"n":"Initialize","d":5154053,"h":68724630789,"f":2},{"r":65537,"n":"Dispose","d":5154053,"h":73019598085,"f":1},{"r":65537,"n":"InternalDispose","d":5154053,"h":77314565381,"f":2},{"r":65537,"n":"Complete","d":5154053,"h":81609532677,"f":1},{"r":65537,"p":[{"n":"state","p":131073}],"n":"TimerCallback","d":5154053,"h":85904499973,"f":34},{"r":65537,"n":"Timeout","d":5154053,"h":90199467269,"f":2},{"r":65537,"n":"CommonInitialize","d":5154053,"h":94494434565,"f":2},{"r":65537,"n":"PushScope","d":5154053,"h":98789401861,"f":2},{"r":65537,"n":"PopScope","d":5154053,"h":103084369157,"f":2},{"r":65537,"p":[{"n":"newCurrent","p":4302085}],"n":"SetCurrent","d":5154053,"h":107379336453,"f":2},{"r":65537,"n":"SaveTLSContextData","d":5154053,"h":111674303749,"f":2},{"r":65537,"n":"RestoreSavedTLSContextData","d":5154053,"h":115969271045,"f":2},{"r":65537,"n":"RestoreCurrent","d":5154053,"h":120264238341,"f":2},{"r":65537,"p":[{"n":"interopOption","p":2270469}],"n":"ValidateInteropOption","d":5154053,"h":124559205637,"f":34},{"r":65537,"p":[{"n":"paramName","p":1310721},{"n":"scopeTimeout","p":140705793}],"n":"ValidateScopeTimeout","d":5154053,"h":128854172933,"f":34},{"r":65537,"p":[{"n":"asyncFlowOption","p":5219589}],"n":"ValidateAndSetAsyncFlowOption","d":5154053,"h":133149140229,"f":2},{"r":65537,"n":"ValidateAsyncFlowOptionAndESInteropOption","d":5154053,"h":137444107525,"f":2}],"l":[{"t":262145,"n":"_complete","d":5154053,"h":141739074821,"f":2},{"t":4302085,"n":"_savedCurrent","d":5154053,"h":154623976709,"f":2},{"t":4302085,"n":"_contextTransaction","d":5154053,"h":158918944005,"f":2},{"t":5154053,"n":"_savedCurrentScope","d":5154053,"h":163213911301,"f":2},{"t":894213,"n":"_threadContextData","d":5154053,"h":167508878597,"f":2},{"t":894213,"n":"_savedTLSContextData","d":5154053,"h":171803845893,"f":2},{"t":4302085,"n":"_expectedCurrent","d":5154053,"h":176098813189,"f":2},{"t":566533,"n":"_committableTransaction","d":5154053,"h":180393780485,"f":2},{"t":1156357,"n":"_dependentTransaction","d":5154053,"h":184688747781,"f":2},{"t":262145,"n":"_disposed","d":5154053,"h":188983715077,"f":2},{"t":138543105,"n":"_scopeTimer","d":5154053,"h":193278682373,"f":2},{"t":136445953,"n":"_scopeThread","d":5154053,"h":197573649669,"f":2},{"t":262145,"n":"_interopModeSpecified","d":5154053,"h":201868616965,"f":2},{"t":2270469,"n":"_interopOption","d":5154053,"h":206163584261,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":5154053,"h":4300121349,"f":1},{"p":[{"n":"scopeOption","p":5285125}],"n":".ctor","o":"$ctor$2","d":5154053,"h":8595088645,"f":1},{"p":[{"n":"asyncFlowOption","p":5219589}],"n":".ctor","o":"$ctor$3","d":5154053,"h":12890055941,"f":1},{"p":[{"n":"scopeOption","p":5285125},{"n":"asyncFlowOption","p":5219589}],"n":".ctor","o":"$ctor$4","d":5154053,"h":17185023237,"f":1},{"p":[{"n":"scopeOption","p":5285125},{"n":"scopeTimeout","p":140705793}],"n":".ctor","o":"$ctor$5","d":5154053,"h":21479990533,"f":1},{"p":[{"n":"scopeOption","p":5285125},{"n":"scopeTimeout","p":140705793},{"n":"asyncFlowOption","p":5219589}],"n":".ctor","o":"$ctor$6","d":5154053,"h":25774957829,"f":1},{"p":[{"n":"scopeOption","p":5285125},{"n":"transactionOptions","p":5022981}],"n":".ctor","o":"$ctor$7","d":5154053,"h":30069925125,"f":1},{"p":[{"n":"scopeOption","p":5285125},{"n":"transactionOptions","p":5022981},{"n":"asyncFlowOption","p":5219589}],"n":".ctor","o":"$ctor$8","d":5154053,"h":34364892421,"f":1},{"p":[{"n":"scopeOption","p":5285125},{"n":"transactionOptions","p":5022981},{"n":"interopOption","p":2270469}],"n":".ctor","o":"$ctor$9","d":5154053,"h":38659859717,"f":1},{"p":[{"n":"transactionToUse","p":4302085}],"n":".ctor","o":"$ctor$10","d":5154053,"h":42954827013,"f":1},{"p":[{"n":"transactionToUse","p":4302085},{"n":"asyncFlowOption","p":5219589}],"n":".ctor","o":"$ctor$11","d":5154053,"h":47249794309,"f":1},{"p":[{"n":"transactionToUse","p":4302085},{"n":"scopeTimeout","p":140705793}],"n":".ctor","o":"$ctor$12","d":5154053,"h":51544761605,"f":1},{"p":[{"n":"transactionToUse","p":4302085},{"n":"scopeTimeout","p":140705793},{"n":"asyncFlowOption","p":5219589}],"n":".ctor","o":"$ctor$13","d":5154053,"h":55839728901,"f":1},{"p":[{"n":"transactionToUse","p":4302085},{"n":"scopeTimeout","p":140705793},{"n":"interopOption","p":2270469}],"n":".ctor","o":"$ctor$14","d":5154053,"h":60134696197,"f":1}],"i":[57540609],"h":5154053,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Transactions.TransactionScope`; }
        });
        
        $asm.$cls("$stl.System.Transactions.InternalTransaction", ($self) => class InternalTransaction extends $.$spc.System.Object
        {
            /*TransactionState?*/ _transactionState = null;
            /*TransactionState? */ get State()
            {
                return this._transactionState;
            }
            /*TransactionState? */ set State(value)
            {
                this._transactionState = value;
            }
            /*TransactionState*/ _promoteState = null;
            /*Guid*/ _promoterType;
            /*byte[]?*/ promotedToken = null;
            /*Guid*/ _distributedTransactionIdentifierNonMSDTC;
            /*int*/ static MaxStateHist = 20;
            /*TransactionState[]*/ _stateHistory = null;
            /*int*/ _currentStateHist = 0;
            /*FinalizedObject?*/ _finalizedObject = null;
            /*int*/ _transactionHash = 0;
            /*int */ get TransactionHash()
            {
                return this._transactionHash;
            }
            /*int*/ static _nextHash = 0;
            /*long*/ _absoluteTimeout = 0n;
            /*long */ get AbsoluteTimeout()
            {
                return this._absoluteTimeout;
            }
            /*long*/ _creationTime = 0n;
            /*long */ get CreationTime()
            {
                return this._creationTime;
            }
            /*long */ set CreationTime(value)
            {
                this._creationTime = value;
            }
            /*InternalEnlistment?*/ _durableEnlistment = null;
            /*VolatileEnlistmentSet*/ _phase0Volatiles;
            /*VolatileEnlistmentSet*/ _phase1Volatiles;
            /*int*/ _phase0VolatileWaveCount = 0;
            /*OletxDependentTransaction?*/ _phase0WaveDependentClone = null;
            /*int*/ _phase0WaveDependentCloneCount = 0;
            /*OletxDependentTransaction?*/ _abortingDependentClone = null;
            /*int*/ _abortingDependentCloneCount = 0;
            /*int*/ static VolatileArrayIncrement = 8;
            /*Bucket?*/ _tableBucket = null;
            /*int*/ _bucketIndex = 0;
            /*TransactionCompletedEventHandler?*/ _transactionCompletedDelegate = null;
            /*OletxTransaction?*/ _promotedTransaction = null;
            /*OletxTransaction? */ get PromotedTransaction()
            {
                return this._promotedTransaction;
            }
            /*OletxTransaction? */ set PromotedTransaction(value)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._promotedTransaction === null, "A transaction can only be promoted once!");
                this._promotedTransaction = value;
            }
            /*Exception?*/ _innerException = null;
            /*int*/ _cloneCount = 0;
            /*int*/ _enlistmentCount = 0;
            /*ManualResetEvent?*/ _asyncResultEvent = null;
            /*bool*/ _asyncCommit = false;
            /*AsyncCallback?*/ _asyncCallback = null;
            /*object?*/ _asyncState = null;
            /*bool*/ _needPulse = false;
            /*TransactionInformation?*/ _transactionInformation = null;
            /*CommittableTransaction?*/ _committableTransaction = null;
            /*Transaction*/ _outcomeSource = null;
            /*object?*/ static s_classSyncObject = null;
            /*Guid */ get DistributedTxId()
            {
                return this.State.get_Identifier(this);
            }
            /*string?*/ static s_instanceIdentifier = null;
            static /*string */ get InstanceIdentifier()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$spc.System.String, $.$ref(() => $.$stl.System.Transactions.InternalTransaction.s_instanceIdentifier, ($v) => $.$stl.System.Transactions.InternalTransaction.s_instanceIdentifier = $v, $.$spc.System.String), $.$ref(() => $.$stl.System.Transactions.InternalTransaction.s_classSyncObject, ($v) => $.$stl.System.Transactions.InternalTransaction.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$spc.System.String))().$ctor(this,  () =>
                {
                    return `${$.$spc.System.Guid.ToString.call($.$spc.System.Guid.NewGuid())}:`;
                }, {"r":1310721,"n":"","d":2794757,"h":0,"f":1048578}));
            }
            /*bool*/ _traceIdentifierInited = false;
            /*TransactionTraceIdentifier*/ _traceIdentifier;
            /*TransactionTraceIdentifier */ get TransactionTraceId()
            {
                if (!this._traceIdentifierInited)
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter(this)
                        {
                            if (!this._traceIdentifierInited)
                            {
                                /*TransactionTraceIdentifier*/ let temp = new $.$stl.System.Transactions.TransactionTraceIdentifier().$ctor$2($.$spc.System.String.Create$9($.$spc.System.Globalization.CultureInfo.InvariantCulture, `${$.$stl.System.Transactions.InternalTransaction.InstanceIdentifier}${this._transactionHash}`), 0);
                                this._traceIdentifier = temp;
                                this._traceIdentifierInited = true;
                            }
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit(this)
                    }
                }
                return this._traceIdentifier;
            }
            /*ITransactionPromoter?*/ _promoter = null;
            /*bool*/ _attemptingPSPEPromote = false;
            /*void */ SetPromoterTypeToMSDTC()
            {
                if (($.$spc.System.Guid.op_Inequality(this._promoterType, $.$spc.System.Guid.Empty)) && ($.$spc.System.Guid.op_Inequality(this._promoterType, $.$stl.System.Transactions.TransactionInterop.PromoterTypeDtc)))
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$stl.System.SR.PromoterTypeInvalid);
                }
                this._promoterType = $.$stl.System.Transactions.TransactionInterop.PromoterTypeDtc;
            }
            /*void */ ThrowIfPromoterTypeIsNotMSDTC()
            {
                if (($.$spc.System.Guid.op_Inequality(this._promoterType, $.$spc.System.Guid.Empty)) && ($.$spc.System.Guid.op_Inequality(this._promoterType, $.$stl.System.Transactions.TransactionInterop.PromoterTypeDtc)))
                {
                    throw new $.$stl.System.Transactions.TransactionPromotionException().$ctor$15($.$stl.System.SR.Format($.$stl.System.SR.PromoterTypeUnrecognized, $.$spc.System.Guid.ToString.call(this._promoterType)), this._innerException);
                }
            }
            $ctor$1(/*TimeSpan*/ timeout, /*CommittableTransaction*/ committableTransaction)
            {
                super.$ctor();
                {
                    this._absoluteTimeout = $.$stl.System.Transactions.TransactionManager.TransactionTable.TimeoutTicks(timeout);
                    $.$stl.System.Transactions.TransactionState.TransactionStateActive.EnterState(this);
                    this._promoteState = $.$stl.System.Transactions.TransactionState.TransactionStatePromoted;
                    this._committableTransaction = committableTransaction;
                    this._outcomeSource = committableTransaction;
                    this._transactionHash = $.$stl.System.Transactions.TransactionManager.TransactionTable.Add(this);
                }
                return this;
            }
            $ctor$2(/*Transaction*/ outcomeSource, /*OletxTransaction*/ distributedTx)
            {
                super.$ctor();
                {
                    this._promotedTransaction = distributedTx;
                    this._absoluteTimeout = 9223372036854775807n;
                    this._outcomeSource = outcomeSource;
                    this._transactionHash = $.$stl.System.Transactions.TransactionManager.TransactionTable.Add(this);
                    $.$stl.System.Transactions.TransactionState.TransactionStateNonCommittablePromoted.EnterState(this);
                    this._promoteState = $.$stl.System.Transactions.TransactionState.TransactionStateNonCommittablePromoted;
                }
                return this;
            }
            $ctor$3(/*Transaction*/ outcomeSource, /*ITransactionPromoter*/ promoter)
            {
                super.$ctor();
                {
                    this._absoluteTimeout = 9223372036854775807n;
                    this._outcomeSource = outcomeSource;
                    this._transactionHash = $.$stl.System.Transactions.TransactionManager.TransactionTable.Add(this);
                    this._promoter = promoter;
                    $.$stl.System.Transactions.TransactionState.TransactionStateSubordinateActive.EnterState(this);
                    this._promoteState = $.$stl.System.Transactions.TransactionState.TransactionStateDelegatedSubordinate;
                }
                return this;
            }
            static /*void */ DistributedTransactionOutcome(/*InternalTransaction*/ tx, /*TransactionStatus*/ status)
            {
                /*FinalizedObject?*/ let fo = null;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(tx)
                    {
                        if (null === tx._innerException)
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(tx.PromotedTransaction !== null, "tx.PromotedTransaction != null");
                            tx._innerException = tx.PromotedTransaction.InnerException;
                        }
                        $.$spc.System.Diagnostics.Debug.Assert$1(tx.State !== null, "tx.State!= null");
                        switch(status)
                        {
                            case 1/*TransactionStatus.Committed*/:
                            {
                                tx.State.ChangeStatePromotedCommitted(tx);
                                break;
                            }
                            case 2/*TransactionStatus.Aborted*/:
                            {
                                tx.State.ChangeStatePromotedAborted(tx);
                                break;
                            }
                            case 3/*TransactionStatus.InDoubt*/:
                            {
                                tx.State.InDoubtFromDtc(tx);
                                break;
                            }
                            default:
                            {
                                $.$spc.System.Diagnostics.Debug.Fail("InternalTransaction.DistributedTransactionOutcome - Unexpected TransactionStatus");
                                $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException$1(1/*TraceSourceType.TraceSourceLtm*/, "", null, tx.DistributedTxId);
                                break;
                            }
                        }
                        fo = tx._finalizedObject;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(tx)
                }
                fo?.Dispose$1();
            }
            /*void */ SignalAsyncCompletion()
            {
                this._asyncResultEvent?.Set$1();
                if (this._asyncCallback !== null)
                {
                    $.$spc.System.Threading.Monitor.Exit(this);
                    try
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._committableTransaction !== null, "_committableTransaction != null");
                        this._asyncCallback.Invoke(this._committableTransaction);
                    }
                    finally
                    {
                        {
                            $.$spc.System.Threading.Monitor.Enter(this);
                        }
                    }
                }
            }
            /*void */ FireCompletion()
            {
                /*TransactionCompletedEventHandler?*/ let eventHandlers = this._transactionCompletedDelegate;
                if (eventHandlers !== null)
                {
                    /*TransactionEventArgs*/ let args = new $.$stl.System.Transactions.TransactionEventArgs().$ctor$2();
                    args._transaction = this._outcomeSource.InternalClone();
                    eventHandlers.Invoke(args._transaction, args);
                }
            }
            /*void */ Dispose()
            {
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this._promoterType = $.$spc.System.Guid.Empty;
                this._distributedTransactionIdentifierNonMSDTC = $.$spc.System.Guid.Empty;
                this._stateHistory = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$stl.System.Transactions.TransactionState), null, [20/*MaxStateHist*/], null);
                this._phase0Volatiles = $.$default($.$stl.System.Transactions.VolatileEnlistmentSet);
                this._phase1Volatiles = $.$default($.$stl.System.Transactions.VolatileEnlistmentSet);
                this._traceIdentifier = $.$default($.$stl.System.Transactions.TransactionTraceIdentifier);
            }
            static $h = 2794757;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":5743877,"g":{"r":0,"d":0,"h":12887696645,"f":8},"s":{"r":0,"d":0,"h":17182663941,"f":8},"n":"State","d":2794757,"h":8592729349,"f":8},{"p":655361,"g":{"r":0,"d":0,"h":64427304197,"f":8},"n":"TransactionHash","d":2794757,"h":60132336901,"f":8},{"p":917505,"g":{"r":0,"d":0,"h":81607173381,"f":8},"n":"AbsoluteTimeout","d":2794757,"h":77312206085,"f":8},{"p":917505,"g":{"r":0,"d":0,"h":94492075269,"f":8},"s":{"r":0,"d":0,"h":98787042565,"f":8},"n":"CreationTime","d":2794757,"h":90197107973,"f":8},{"p":3515653,"g":{"r":0,"d":0,"h":163211552005,"f":8},"s":{"r":0,"d":0,"h":167506519301,"f":8},"n":"PromotedTransaction","d":2794757,"h":158916584709,"f":8},{"p":56229889,"g":{"r":0,"d":0,"h":227636061445,"f":8},"n":"DistributedTxId","d":2794757,"h":223341094149,"f":8},{"p":1310721,"g":{"r":0,"d":0,"h":240520963333,"f":40},"n":"InstanceIdentifier","d":2794757,"h":236225996037,"f":40},{"p":8561925,"g":{"r":0,"d":0,"h":257700832517,"f":8},"n":"TransactionTraceId","d":2794757,"h":253405865221,"f":8}],"m":[{"r":65537,"n":"SetPromoterTypeToMSDTC","d":2794757,"h":270585734405,"f":8},{"r":65537,"n":"ThrowIfPromoterTypeIsNotMSDTC","d":2794757,"h":274880701701,"f":8},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"status","p":8430853}],"n":"DistributedTransactionOutcome","d":2794757,"h":292060570885,"f":40},{"r":65537,"n":"SignalAsyncCompletion","d":2794757,"h":296355538181,"f":8},{"r":65537,"n":"FireCompletion","d":2794757,"h":300650505477,"f":8},{"r":65537,"n":"Dispose","d":2794757,"h":304945472773,"f":1}],"l":[{"t":5743877,"n":"_transactionState","d":2794757,"h":4297762053,"f":2},{"t":5743877,"n":"_promoteState","d":2794757,"h":21477631237,"f":8},{"t":56229889,"n":"_promoterType","d":2794757,"h":25772598533,"f":8},{"t":0,"n":"promotedToken","d":2794757,"h":30067565829,"f":8},{"t":56229889,"n":"_distributedTransactionIdentifierNonMSDTC","d":2794757,"h":34362533125,"f":8},{"t":655361,"n":"MaxStateHist","d":2794757,"h":38657500421,"f":40},{"t":0,"n":"_stateHistory","d":2794757,"h":42952467717,"f":8},{"t":655361,"n":"_currentStateHist","d":2794757,"h":47247435013,"f":8},{"t":2336005,"n":"_finalizedObject","d":2794757,"h":51542402309,"f":8},{"t":655361,"n":"_transactionHash","d":2794757,"h":55837369605,"f":8},{"t":655361,"n":"_nextHash","d":2794757,"h":68722271493,"f":40},{"t":917505,"n":"_absoluteTimeout","d":2794757,"h":73017238789,"f":2},{"t":917505,"n":"_creationTime","d":2794757,"h":85902140677,"f":2},{"t":2729221,"n":"_durableEnlistment","d":2794757,"h":103082009861,"f":8},{"t":9348357,"n":"_phase0Volatiles","d":2794757,"h":107376977157,"f":8},{"t":9348357,"n":"_phase1Volatiles","d":2794757,"h":111671944453,"f":8},{"t":655361,"n":"_phase0VolatileWaveCount","d":2794757,"h":115966911749,"f":8},{"t":3450117,"n":"_phase0WaveDependentClone","d":2794757,"h":120261879045,"f":8},{"t":655361,"n":"_phase0WaveDependentCloneCount","d":2794757,"h":124556846341,"f":8},{"t":3450117,"n":"_abortingDependentClone","d":2794757,"h":128851813637,"f":8},{"t":655361,"n":"_abortingDependentCloneCount","d":2794757,"h":133146780933,"f":8},{"t":655361,"n":"VolatileArrayIncrement","d":2794757,"h":137441748229,"f":40},{"t":304389,"n":"_tableBucket","d":2794757,"h":141736715525,"f":8},{"t":655361,"n":"_bucketIndex","d":2794757,"h":146031682821,"f":8},{"t":4433157,"n":"_transactionCompletedDelegate","d":2794757,"h":150326650117,"f":8},{"t":3515653,"n":"_promotedTransaction","d":2794757,"h":154621617413,"f":2},{"t":655361,"n":"_cloneCount","d":2794757,"h":176096453893,"f":8},{"t":655361,"n":"_enlistmentCount","d":2794757,"h":180391421189,"f":8},{"t":128319489,"n":"_asyncResultEvent","d":2794757,"h":184686388485,"f":8},{"t":262145,"n":"_asyncCommit","d":2794757,"h":188981355781,"f":8},{"t":14483457,"n":"_asyncCallback","d":2794757,"h":193276323077,"f":8},{"t":131073,"n":"_asyncState","d":2794757,"h":197571290373,"f":8},{"t":262145,"n":"_needPulse","d":2794757,"h":201866257669,"f":8},{"t":4760837,"n":"_transactionInformation","d":2794757,"h":206161224965,"f":8},{"t":566533,"n":"_committableTransaction","d":2794757,"h":210456192261,"f":8},{"t":4302085,"n":"_outcomeSource","d":2794757,"h":214751159557,"f":8},{"t":131073,"n":"s_classSyncObject","d":2794757,"h":219046126853,"f":34},{"t":1310721,"n":"s_instanceIdentifier","d":2794757,"h":231931028741,"f":34},{"t":262145,"n":"_traceIdentifierInited","d":2794757,"h":244815930629,"f":2},{"t":8561925,"n":"_traceIdentifier","d":2794757,"h":249110897925,"f":2},{"t":3253509,"n":"_promoter","d":2794757,"h":261995799813,"f":8},{"t":262145,"n":"_attemptingPSPEPromote","d":2794757,"h":266290767109,"f":8}],"c":[{"p":[{"n":"timeout","p":140705793},{"n":"committableTransaction","p":566533}],"n":".ctor","o":"$ctor$1","d":2794757,"h":279175668997,"f":8},{"p":[{"n":"outcomeSource","p":4302085},{"n":"distributedTx","p":3515653}],"n":".ctor","o":"$ctor$2","d":2794757,"h":283470636293,"f":8},{"p":[{"n":"outcomeSource","p":4302085},{"n":"promoter","p":3253509}],"n":".ctor","o":"$ctor$3","d":2794757,"h":287765603589,"f":8}],"i":[57540609],"h":2794757}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Transactions.InternalTransaction`; }
        });
        
        $asm.$cls("$stl.System.Transactions.FinalizedObject", ($self) => class FinalizedObject extends $.$spc.System.Object
        {
            /*Guid*/ _identifier;
            /*InternalTransaction*/ _internalTransaction = null;
            $ctor$1(/*InternalTransaction*/ internalTransaction, /*Guid*/ identifier)
            {
                super.$ctor();
                {
                    this._internalTransaction = internalTransaction;
                    this._identifier = identifier;
                }
                return this;
            }
            /*void */ Dispose(/*bool*/ disposing)
            {
                if (disposing)
                {
                    $.$spc.System.GC.SuppressFinalize(this);
                }
                /*Hashtable*/ let promotedTransactionTable = $.$stl.System.Transactions.TransactionManager.PromotedTransactionTable;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(promotedTransactionTable)
                    {
                        /*WeakReference?*/ let weakRef = $.$cast(promotedTransactionTable.get_Item(this._identifier), $.$spc.System.WeakReference);
                        if (null !== weakRef)
                        {
                            if (weakRef.Target !== null)
                            {
                                weakRef.Target = null;
                            }
                        }
                        promotedTransactionTable.Remove(this._identifier);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(promotedTransactionTable)
                }
            }
            /*void */ Dispose$1()
            {
                this.Dispose(true);
            }
            $dtor()
            {
                this.Dispose(false);
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose$1(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this._identifier = $.$default($.$spc.System.Guid);
                $.$finalizer(this);
            }
            static $h = 2336005;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","d":2336005,"h":17182205189,"f":2},{"r":65537,"n":"Dispose","o":"@$1","d":2336005,"h":21477172485,"f":1}],"l":[{"t":56229889,"n":"_identifier","d":2336005,"h":4297303301,"f":2},{"t":2794757,"n":"_internalTransaction","d":2336005,"h":8592270597,"f":2}],"c":[{"p":[{"n":"internalTransaction","p":2794757},{"n":"identifier","p":56229889}],"n":".ctor","o":"$ctor$1","d":2336005,"h":12887237893,"f":8}],"i":[57540609],"h":2336005}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Transactions.FinalizedObject`; }
        });
        
        $asm.$cls("$stl.System.Transactions.InternalEnlistment", ($self) => class InternalEnlistment extends $.$spc.System.Object
        {
            /*EnlistmentState?*/ _twoPhaseState = null;
            /*IEnlistmentNotification?*/ _twoPhaseNotifications = null;
            /*ISinglePhaseNotification?*/ _singlePhaseNotifications = null;
            /*InternalTransaction*/ _transaction = null;
            /*Transaction?*/ _atomicTransaction = null;
            /*EnlistmentTraceIdentifier*/ _traceIdentifier;
            /*int*/ _enlistmentId = 0;
            /*Guid */ get DistributedTxId()
            {
                /*Guid*/ let returnValue = $.$spc.System.Guid.Empty;
                if (this.Transaction !== null)
                {
                    returnValue = this.Transaction.DistributedTxId;
                }
                return returnValue;
            }
            /*Enlistment*/ _enlistment = null;
            /*PreparingEnlistment?*/ _preparingEnlistment = null;
            /*SinglePhaseEnlistment?*/ _singlePhaseEnlistment = null;
            /*IPromotedEnlistment?*/ _promotedEnlistment = null;
            $ctor$1(/*Enlistment*/ enlistment, /*IEnlistmentNotification*/ twoPhaseNotifications)
            {
                super.$ctor();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1($.$is(this, $.$stl.System.Transactions.RecoveringInternalEnlistment), "this is RecoveringInternalEnlistment");
                    this._enlistment = enlistment;
                    this._twoPhaseNotifications = twoPhaseNotifications;
                    this._enlistmentId = 1;
                    this._traceIdentifier = $.$stl.System.Transactions.EnlistmentTraceIdentifier.Empty;
                }
                return this;
            }
            $ctor$2(/*Enlistment*/ enlistment, /*InternalTransaction*/ transaction, /*Transaction*/ atomicTransaction)
            {
                super.$ctor();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1($.$is(this, $.$stl.System.Transactions.PromotableInternalEnlistment), "this is PromotableInternalEnlistment");
                    this._enlistment = enlistment;
                    this._transaction = transaction;
                    this._atomicTransaction = atomicTransaction;
                    this._enlistmentId = transaction._enlistmentCount++;
                    this._traceIdentifier = $.$stl.System.Transactions.EnlistmentTraceIdentifier.Empty;
                }
                return this;
            }
            $ctor$3(/*Enlistment*/ enlistment, /*InternalTransaction*/ transaction, /*IEnlistmentNotification*/ twoPhaseNotifications, /*ISinglePhaseNotification?*/ singlePhaseNotifications, /*Transaction*/ atomicTransaction)
            {
                super.$ctor();
                {
                    this._enlistment = enlistment;
                    this._transaction = transaction;
                    this._twoPhaseNotifications = twoPhaseNotifications;
                    this._singlePhaseNotifications = singlePhaseNotifications;
                    this._atomicTransaction = atomicTransaction;
                    this._enlistmentId = transaction._enlistmentCount++;
                    this._traceIdentifier = $.$stl.System.Transactions.EnlistmentTraceIdentifier.Empty;
                }
                return this;
            }
            $ctor$4(/*Enlistment*/ enlistment, /*IEnlistmentNotification*/ twoPhaseNotifications, /*InternalTransaction*/ transaction, /*Transaction*/ atomicTransaction)
            {
                super.$ctor();
                {
                    this._enlistment = enlistment;
                    this._twoPhaseNotifications = twoPhaseNotifications;
                    this._transaction = transaction;
                    this._atomicTransaction = atomicTransaction;
                }
                return this;
            }
            /*EnlistmentState */ get State()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._twoPhaseState !== null, "_twoPhaseState != null");
                return this._twoPhaseState;
            }
            /*EnlistmentState */ set State(value)
            {
                this._twoPhaseState = value;
            }
            /*Enlistment */ get Enlistment()
            {
                return this._enlistment;
            }
            /*PreparingEnlistment */ get PreparingEnlistment()
            {
                return this._preparingEnlistment ??= new $.$stl.System.Transactions.PreparingEnlistment().$ctor$7(this);
            }
            /*SinglePhaseEnlistment */ get SinglePhaseEnlistment()
            {
                return this._singlePhaseEnlistment ??= new $.$stl.System.Transactions.SinglePhaseEnlistment().$ctor$7(this);
            }
            /*InternalTransaction */ get Transaction()
            {
                return this._transaction;
            }
            /*object */ get SyncRoot()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._transaction !== null, "this.transaction != null");
                return this._transaction;
            }
            /*IEnlistmentNotification? */ get EnlistmentNotification()
            {
                return this._twoPhaseNotifications;
            }
            /*ISinglePhaseNotification? */ get SinglePhaseNotification()
            {
                return this._singlePhaseNotifications;
            }
            /*IPromotableSinglePhaseNotification */ get PromotableSinglePhaseNotification()
            {
                $.$spc.System.Diagnostics.Debug.Fail("PromotableSinglePhaseNotification called for a non promotable enlistment.");
                throw new $.$spc.System.NotImplementedException().$ctor$9();
            }
            /*IPromotedEnlistment? */ get PromotedEnlistment()
            {
                return this._promotedEnlistment;
            }
            /*IPromotedEnlistment? */ set PromotedEnlistment(value)
            {
                this._promotedEnlistment = value;
            }
            /*EnlistmentTraceIdentifier */ get EnlistmentTraceId()
            {
                if ($.$stl.System.Transactions.EnlistmentTraceIdentifier.op_Equality(this._traceIdentifier, $.$stl.System.Transactions.EnlistmentTraceIdentifier.Empty))
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter(this.SyncRoot)
                        {
                            if ($.$stl.System.Transactions.EnlistmentTraceIdentifier.op_Equality(this._traceIdentifier, $.$stl.System.Transactions.EnlistmentTraceIdentifier.Empty))
                            {
                                /*EnlistmentTraceIdentifier*/ let temp;
                                if ($.$stl.System.Transactions.Transaction.op_Inequality(null, this._atomicTransaction))
                                {
                                    temp = new $.$stl.System.Transactions.EnlistmentTraceIdentifier().$ctor$2($.$spc.System.Guid.Empty, this._atomicTransaction.TransactionTraceId, this._enlistmentId);
                                }
                                else 
                                {
                                    temp = new $.$stl.System.Transactions.EnlistmentTraceIdentifier().$ctor$2($.$spc.System.Guid.Empty, new $.$stl.System.Transactions.TransactionTraceIdentifier().$ctor$2($.$spc.System.String.Create$9($.$spc.System.Globalization.CultureInfo.InvariantCulture, `${$.$stl.System.Transactions.InternalTransaction.InstanceIdentifier}${$.$spc.System.Threading.Interlocked.Increment($.$ref(() => $.$stl.System.Transactions.InternalTransaction._nextHash, ($v) => $.$stl.System.Transactions.InternalTransaction._nextHash = $v, $.$spc.System.Int32))}`), 0), this._enlistmentId);
                                }
                                $.$spc.System.Threading.Interlocked.MemoryBarrier();
                                this._traceIdentifier = temp;
                            }
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit(this.SyncRoot)
                    }
                }
                return this._traceIdentifier;
            }
            /*void */ FinishEnlistment()
            {
                this.Transaction._phase0Volatiles._preparedVolatileEnlistments++;
                this.CheckComplete();
            }
            /*void */ CheckComplete()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this.Transaction._phase0Volatiles._preparedVolatileEnlistments <= ((this.Transaction._phase0Volatiles._volatileEnlistmentCount + this.Transaction._phase0Volatiles._dependentClones) | 0), "Transaction._phase0Volatiles._preparedVolatileEnlistments <=\r\n                Transaction._phase0Volatiles._volatileEnlistmentCount + Transaction._phase0Volatiles._dependentClones");
                if (this.Transaction._phase0Volatiles._preparedVolatileEnlistments === ((this.Transaction._phase0VolatileWaveCount + this.Transaction._phase0Volatiles._dependentClones) | 0))
                {
                    this.Transaction.State.Phase0VolatilePrepareDone(this.Transaction);
                }
            }
            /*Guid */ get ResourceManagerIdentifier()
            {
                $.$spc.System.Diagnostics.Debug.Fail("ResourceManagerIdentifier called for non durable enlistment");
                throw new $.$spc.System.NotImplementedException().$ctor$9();
            }
            /*void */ System$Transactions$ISinglePhaseNotificationInternal$SinglePhaseCommit(/*IPromotedEnlistment*/ singlePhaseEnlistment)
            {
                /*bool*/ let spcCommitted = false;
                this._promotedEnlistment = singlePhaseEnlistment;
                try
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._singlePhaseNotifications !== null, "_singlePhaseNotifications != null");
                    this._singlePhaseNotifications.System$Transactions$ISinglePhaseNotification$SinglePhaseCommit(this.SinglePhaseEnlistment);
                    spcCommitted = true;
                }
                finally
                {
                    {
                        if (!spcCommitted)
                        {
                            this.SinglePhaseEnlistment.InDoubt();
                        }
                    }
                }
            }
            /*void */ System$Transactions$IEnlistmentNotificationInternal$Prepare(/*IPromotedEnlistment*/ preparingEnlistment)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._twoPhaseNotifications !== null, "_twoPhaseNotifications != null");
                this._promotedEnlistment = preparingEnlistment;
                this._twoPhaseNotifications.System$Transactions$IEnlistmentNotification$Prepare(this.PreparingEnlistment);
            }
            /*void */ System$Transactions$IEnlistmentNotificationInternal$Commit(/*IPromotedEnlistment*/ enlistment)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._twoPhaseNotifications !== null, "_twoPhaseNotifications != null");
                this._promotedEnlistment = enlistment;
                this._twoPhaseNotifications.System$Transactions$IEnlistmentNotification$Commit(this.Enlistment);
            }
            /*void */ System$Transactions$IEnlistmentNotificationInternal$Rollback(/*IPromotedEnlistment*/ enlistment)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._twoPhaseNotifications !== null, "_twoPhaseNotifications != null");
                this._promotedEnlistment = enlistment;
                this._twoPhaseNotifications.System$Transactions$IEnlistmentNotification$Rollback(this.Enlistment);
            }
            /*void */ System$Transactions$IEnlistmentNotificationInternal$InDoubt(/*IPromotedEnlistment*/ enlistment)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._twoPhaseNotifications !== null, "_twoPhaseNotifications != null");
                this._promotedEnlistment = enlistment;
                this._twoPhaseNotifications.System$Transactions$IEnlistmentNotification$InDoubt(this.Enlistment);
            }
            //default member initializer
            constructor()
            {
                super();
                this._transaction = null;
                this._traceIdentifier = $.$default($.$stl.System.Transactions.EnlistmentTraceIdentifier);
            }
            static $h = 2729221;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":56229889,"g":{"r":0,"d":0,"h":38657434885,"f":8},"n":"DistributedTxId","d":2729221,"h":34362467589,"f":8},{"p":1942789,"g":{"r":0,"d":0,"h":81607107845,"f":8},"s":{"r":0,"d":0,"h":85902075141,"f":8},"n":"State","d":2729221,"h":77312140549,"f":8},{"p":1746181,"g":{"r":0,"d":0,"h":94492009733,"f":8},"n":"Enlistment","d":2729221,"h":90197042437,"f":8},{"p":3908869,"g":{"r":0,"d":0,"h":103081944325,"f":8},"n":"PreparingEnlistment","d":2729221,"h":98786977029,"f":8},{"p":4105477,"g":{"r":0,"d":0,"h":111671878917,"f":8},"n":"SinglePhaseEnlistment","d":2729221,"h":107376911621,"f":8},{"p":2794757,"g":{"r":0,"d":0,"h":120261813509,"f":8},"n":"Transaction","d":2729221,"h":115966846213,"f":8},{"p":131073,"g":{"r":0,"d":0,"h":128851748101,"f":136},"n":"SyncRoot","d":2729221,"h":124556780805,"f":136},{"p":2598149,"g":{"r":0,"d":0,"h":137441682693,"f":8},"n":"EnlistmentNotification","d":2729221,"h":133146715397,"f":8},{"p":3056901,"g":{"r":0,"d":0,"h":146031617285,"f":8},"n":"SinglePhaseNotification","d":2729221,"h":141736649989,"f":8},{"p":2860293,"g":{"r":0,"d":0,"h":154621551877,"f":136},"n":"PromotableSinglePhaseNotification","d":2729221,"h":150326584581,"f":136},{"p":2925829,"g":{"r":0,"d":0,"h":163211486469,"f":8},"s":{"r":0,"d":0,"h":167506453765,"f":8},"n":"PromotedEnlistment","d":2729221,"h":158916519173,"f":8},{"p":2073861,"g":{"r":0,"d":0,"h":176096388357,"f":8},"n":"EnlistmentTraceId","d":2729221,"h":171801421061,"f":8},{"p":56229889,"g":{"r":0,"d":0,"h":193276257541,"f":136},"n":"ResourceManagerIdentifier","d":2729221,"h":188981290245,"f":136}],"m":[{"r":65537,"n":"FinishEnlistment","d":2729221,"h":180391355653,"f":136},{"r":65537,"n":"CheckComplete","d":2729221,"h":184686322949,"f":136}],"l":[{"t":1942789,"n":"_twoPhaseState","d":2729221,"h":4297696517,"f":8},{"t":2598149,"n":"_twoPhaseNotifications","d":2729221,"h":8592663813,"f":4},{"t":3056901,"n":"_singlePhaseNotifications","d":2729221,"h":12887631109,"f":4},{"t":2794757,"n":"_transaction","d":2729221,"h":17182598405,"f":4},{"t":4302085,"n":"_atomicTransaction","d":2729221,"h":21477565701,"f":2},{"t":2073861,"n":"_traceIdentifier","d":2729221,"h":25772532997,"f":2},{"t":655361,"n":"_enlistmentId","d":2729221,"h":30067500293,"f":2},{"t":1746181,"n":"_enlistment","d":2729221,"h":42952402181,"f":2},{"t":3908869,"n":"_preparingEnlistment","d":2729221,"h":47247369477,"f":2},{"t":4105477,"n":"_singlePhaseEnlistment","d":2729221,"h":51542336773,"f":2},{"t":2925829,"n":"_promotedEnlistment","d":2729221,"h":55837304069,"f":2}],"c":[{"p":[{"n":"enlistment","p":1746181},{"n":"twoPhaseNotifications","p":2598149}],"n":".ctor","o":"$ctor$1","d":2729221,"h":60132271365,"f":4},{"p":[{"n":"enlistment","p":1746181},{"n":"transaction","p":2794757},{"n":"atomicTransaction","p":4302085}],"n":".ctor","o":"$ctor$2","d":2729221,"h":64427238661,"f":4},{"p":[{"n":"enlistment","p":1746181},{"n":"transaction","p":2794757},{"n":"twoPhaseNotifications","p":2598149},{"n":"singlePhaseNotifications","p":3056901},{"n":"atomicTransaction","p":4302085}],"n":".ctor","o":"$ctor$3","d":2729221,"h":68722205957,"f":8},{"p":[{"n":"enlistment","p":1746181},{"n":"twoPhaseNotifications","p":2598149},{"n":"transaction","p":2794757},{"n":"atomicTransaction","p":4302085}],"n":".ctor","o":"$ctor$4","d":2729221,"h":73017173253,"f":8}],"i":[3122437,2663685],"h":2729221}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stl.System.Transactions.ISinglePhaseNotificationInternal, $.$stl.System.Transactions.IEnlistmentNotificationInternal ]; }
            static get $fullName() { return `System.Transactions.InternalEnlistment`; }
        });
        
        $asm.$cls("$stl.System.Transactions.Transaction", ($self) => class Transaction extends $.$spc.System.Object
        {
            static /*bool */ UseServiceDomainForCurrent()
            {
                return false;
            }
            static /*EnterpriseServicesInteropOption */ InteropMode(/*TransactionScope?*/ currentScope)
            {
                if (currentScope !== null)
                {
                    return currentScope.InteropMode;
                }
                return 0/*EnterpriseServicesInteropOption.None*/;
            }
            static /*Transaction? */ FastGetTransaction(/*TransactionScope?*/ currentScope, /*ContextData*/ contextData, /*out Transaction?*/ contextTransaction)
            {
                /*Transaction?*/ let current = null;
                contextTransaction.$v = contextData.CurrentTransaction;
                let $switch1 = $.$stl.System.Transactions.Transaction.InteropMode(currentScope);
                switch($switch1)
                {
                    case 0/*EnterpriseServicesInteropOption.None*/:
                    current = contextTransaction.$v;
                    if ($.$stl.System.Transactions.Transaction.op_Equality(current, null) && currentScope === null)
                    {
                        if ($.$stl.System.Transactions.TransactionManager.s_currentDelegateSet)
                        {
                            current = $.$stl.System.Transactions.TransactionManager.$.$stl.System.Transactions.TransactionManager.s_currentDelegate.Invoke();
                        }
                        else 
                        {
                            current = $.$stl.System.Transactions.EnterpriseServices.GetContextTransaction();
                        }
                    }
                    break;
                    case 2/*EnterpriseServicesInteropOption.Full*/:
                    current = $.$stl.System.Transactions.EnterpriseServices.GetContextTransaction();
                    break;
                    case 1/*EnterpriseServicesInteropOption.Automatic*/:
                    if ($.$stl.System.Transactions.EnterpriseServices.UseServiceDomainForCurrent())
                    {
                        current = $.$stl.System.Transactions.EnterpriseServices.GetContextTransaction();
                    }
                    else 
                    {
                        current = contextData.CurrentTransaction;
                    }
                    break;
                }
                return current;
            }
            static /*void */ GetCurrentTransactionAndScope(/*TxLookup*/ defaultLookup, /*out Transaction?*/ current, /*out TransactionScope?*/ currentScope, /*out Transaction?*/ contextTransaction)
            {
                current.$v = null;
                currentScope.$v = null;
                contextTransaction.$v = null;
                /*ContextData*/ let contextData = $.$stl.System.Transactions.ContextData.LookupContextData(defaultLookup);
                if (contextData !== null)
                {
                    currentScope.$v = contextData.CurrentScope;
                    current.$v = $.$stl.System.Transactions.Transaction.FastGetTransaction(currentScope.$v, contextData, contextTransaction);
                }
            }
            static /*Transaction? */ get Current()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(0/*TraceSourceType.TraceSourceBase*/, "Transaction.get_Current");
                }
                /*Transaction?*/ let current;
                /*TransactionScope?*/ let currentScope;
                $.$stl.System.Transactions.Transaction.GetCurrentTransactionAndScope(0/*TxLookup.Default*/, $.$ref(() => current, ($v) => current = $v, $.$stl.System.Transactions.Transaction), $.$ref(() => currentScope, ($v) => currentScope = $v, $.$stl.System.Transactions.TransactionScope), $.$discardRef());
                if (currentScope !== null)
                {
                    if (currentScope.ScopeComplete)
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$stl.System.SR.TransactionScopeComplete);
                    }
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(0/*TraceSourceType.TraceSourceBase*/, "Transaction.get_Current");
                }
                return current;
            }
            static /*Transaction? */ set Current(value)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(0/*TraceSourceType.TraceSourceBase*/, "Transaction.set_Current");
                }
                if ($.$stl.System.Transactions.Transaction.InteropMode($.$stl.System.Transactions.ContextData.TLSCurrentData.CurrentScope) !== 0/*EnterpriseServicesInteropOption.None*/)
                {
                    if (etwLog.IsEnabled())
                    {
                        etwLog.InvalidOperation("Transaction", "Transaction.set_Current");
                    }
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$stl.System.SR.CannotSetCurrent);
                }
                $.$stl.System.Transactions.ContextData.TLSCurrentData.CurrentTransaction = value;
                $.$stl.System.Transactions.CallContextCurrentData.ClearCurrentData(null, false);
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(0/*TraceSourceType.TraceSourceBase*/, "Transaction.set_Current");
                }
            }
            /*IsolationLevel*/ _isoLevel = 0;
            /*bool*/ _complete = false;
            /*int*/ _cloneId = 0;
            /*int*/ static _disposedTrueValue = 1;
            /*int*/ _disposed = 0;
            /*bool */ get Disposed()
            {
                return this._disposed === 1/*Transaction._disposedTrueValue*/;
            }
            /*Guid */ get DistributedTxId()
            {
                /*Guid*/ let returnValue = $.$spc.System.Guid.Empty;
                if (this._internalTransaction !== null)
                {
                    returnValue = this._internalTransaction.DistributedTxId;
                }
                return returnValue;
            }
            /*InternalTransaction*/ _internalTransaction = null;
            /*TransactionTraceIdentifier*/ _traceIdentifier;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*IsolationLevel*/ isoLevel, /*InternalTransaction?*/ internalTransaction)
            {
                super.$ctor();
                {
                    $.$stl.System.Transactions.TransactionManager.ValidateIsolationLevel(isoLevel);
                    this._isoLevel = isoLevel;
                    if (6/*IsolationLevel.Unspecified*/ === this._isoLevel)
                    {
                        this._isoLevel = $.$stl.System.Transactions.TransactionManager.DefaultIsolationLevel;
                    }
                    if (internalTransaction !== null)
                    {
                        this._internalTransaction = internalTransaction;
                        this._cloneId = $.$spc.System.Threading.Interlocked.Increment($.$ref(() => this._internalTransaction._cloneCount, ($v) => this._internalTransaction._cloneCount = $v, $.$spc.System.Int32));
                    }
                    else 
                    {
                    }
                }
                return this;
            }
            $ctor$3(/*OletxTransaction*/ distributedTransaction)
            {
                super.$ctor();
                {
                    this._isoLevel = distributedTransaction.IsolationLevel;
                    this._internalTransaction = new $.$stl.System.Transactions.InternalTransaction().$ctor$2(this, distributedTransaction);
                    this._cloneId = $.$spc.System.Threading.Interlocked.Increment($.$ref(() => this._internalTransaction._cloneCount, ($v) => this._internalTransaction._cloneCount = $v, $.$spc.System.Int32));
                }
                return this;
            }
            $ctor$4(/*IsolationLevel*/ isoLevel, /*ISimpleTransactionSuperior*/ superior)
            {
                super.$ctor();
                {
                    $.$stl.System.Transactions.TransactionManager.ValidateIsolationLevel(isoLevel);
                    $.$spc.System.ArgumentNullException.ThrowIfNull(superior, "superior");
                    this._isoLevel = isoLevel;
                    if (6/*IsolationLevel.Unspecified*/ === this._isoLevel)
                    {
                        this._isoLevel = $.$stl.System.Transactions.TransactionManager.DefaultIsolationLevel;
                    }
                    this._internalTransaction = new $.$stl.System.Transactions.InternalTransaction().$ctor$3(this, superior);
                    this._internalTransaction.SetPromoterTypeToMSDTC();
                    this._cloneId = 1;
                }
                return this;
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return this._internalTransaction.TransactionHash;
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$stl.System.Transactions.Transaction.GetHashCode.apply(this, arguments); }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                let transaction;
                return $.$is(obj, $.$stl.System.Transactions.Transaction, { set $v(v){ transaction = v; } }) && this._internalTransaction.TransactionHash === transaction._internalTransaction.TransactionHash;
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$stl.System.Transactions.Transaction.Equals.apply(this, arguments); }
            static /*bool */ op_Equality(/*Transaction?*/ x, /*Transaction?*/ y)
            {
                if ((x) !== null)
                {
                    return $.$stl.System.Transactions.Transaction.Equals.call(x, y);
                }
                return (y) === null;
            }
            static /*bool */ op_Inequality(/*Transaction?*/ x, /*Transaction?*/ y)
            {
                if ((x) !== null)
                {
                    return !$.$stl.System.Transactions.Transaction.Equals.call(x, y);
                }
                return (y) !== null;
            }
            /*TransactionInformation */ get TransactionInformation()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "TransactionInformation");
                }
                $.$spc.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                /*TransactionInformation?*/ let txInfo = this._internalTransaction._transactionInformation;
                if (txInfo === null)
                {
                    txInfo = new $.$stl.System.Transactions.TransactionInformation().$ctor$1(this._internalTransaction);
                    this._internalTransaction._transactionInformation = txInfo;
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "TransactionInformation");
                }
                return txInfo;
            }
            /*IsolationLevel */ get IsolationLevel()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "IsolationLevel");
                }
                $.$spc.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "IsolationLevel");
                }
                return this._isoLevel;
            }
            /*Guid */ get PromoterType()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "PromoterType");
                }
                $.$spc.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                    {
                        return this._internalTransaction._promoterType;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                }
            }
            /*byte[] */ GetPromotedToken()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "GetPromotedToken");
                }
                $.$spc.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                /*byte[]*/ let internalPromotedToken;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        internalPromotedToken = this._internalTransaction.State.PromotedToken(this._internalTransaction);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                }
                /*byte[]*/ let toReturn = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [internalPromotedToken.length], null);
                $.$spc.System.Array.Copy(internalPromotedToken, toReturn, toReturn.length);
                return toReturn;
            }
            /*Enlistment */ EnlistDurable(/*Guid*/ resourceManagerIdentifier, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "EnlistDurable");
                }
                $.$spc.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                if ($.$spc.System.Guid.op_Equality(resourceManagerIdentifier, $.$spc.System.Guid.Empty))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$stl.System.SR.BadResourceManagerId, "resourceManagerIdentifier");
                }
                $.$spc.System.ArgumentNullException.ThrowIfNull(enlistmentNotification, "enlistmentNotification");
                if (enlistmentOptions !== 0/*EnlistmentOptions.None*/ && enlistmentOptions !== 1/*EnlistmentOptions.EnlistDuringPrepareRequired*/)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("enlistmentOptions");
                }
                if (this._complete)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateTransactionCompletedException(this.DistributedTxId);
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        /*Enlistment*/ let enlistment = this._internalTransaction.State.EnlistDurable(this._internalTransaction, resourceManagerIdentifier, enlistmentNotification, enlistmentOptions, this);
                        if (etwLog.IsEnabled())
                        {
                            etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "EnlistDurable");
                        }
                        return enlistment;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                }
            }
            /*Enlistment */ EnlistDurable$1(/*Guid*/ resourceManagerIdentifier, /*ISinglePhaseNotification*/ singlePhaseNotification, /*EnlistmentOptions*/ enlistmentOptions)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "EnlistDurable");
                }
                $.$spc.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                if ($.$spc.System.Guid.op_Equality(resourceManagerIdentifier, $.$spc.System.Guid.Empty))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$stl.System.SR.BadResourceManagerId, "resourceManagerIdentifier");
                }
                $.$spc.System.ArgumentNullException.ThrowIfNull(singlePhaseNotification, "singlePhaseNotification");
                if (enlistmentOptions !== 0/*EnlistmentOptions.None*/ && enlistmentOptions !== 1/*EnlistmentOptions.EnlistDuringPrepareRequired*/)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("enlistmentOptions");
                }
                if (this._complete)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateTransactionCompletedException(this.DistributedTxId);
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        /*Enlistment*/ let enlistment = this._internalTransaction.State.EnlistDurable$1(this._internalTransaction, resourceManagerIdentifier, singlePhaseNotification, enlistmentOptions, this);
                        if (etwLog.IsEnabled())
                        {
                            etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "EnlistDurable");
                        }
                        return enlistment;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                }
            }
            /*void */ Rollback()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "Rollback");
                    etwLog.TransactionRollback(1/*TraceSourceType.TraceSourceLtm*/, this.TransactionTraceId, "Transaction");
                }
                $.$spc.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        this._internalTransaction.State.Rollback(this._internalTransaction, null);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "Rollback");
                }
            }
            /*void */ Rollback$1(/*Exception?*/ e)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "Rollback");
                    etwLog.TransactionRollback(1/*TraceSourceType.TraceSourceLtm*/, this.TransactionTraceId, "Transaction");
                }
                $.$spc.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        this._internalTransaction.State.Rollback(this._internalTransaction, e);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "Rollback");
                }
            }
            /*Enlistment */ EnlistVolatile(/*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "EnlistVolatile");
                }
                $.$spc.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                $.$spc.System.ArgumentNullException.ThrowIfNull(enlistmentNotification, "enlistmentNotification");
                if (enlistmentOptions !== 0/*EnlistmentOptions.None*/ && enlistmentOptions !== 1/*EnlistmentOptions.EnlistDuringPrepareRequired*/)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("enlistmentOptions");
                }
                if (this._complete)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateTransactionCompletedException(this.DistributedTxId);
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        /*Enlistment*/ let enlistment = this._internalTransaction.State.EnlistVolatile(this._internalTransaction, enlistmentNotification, enlistmentOptions, this);
                        if (etwLog.IsEnabled())
                        {
                            etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "EnlistVolatile");
                        }
                        return enlistment;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                }
            }
            /*Enlistment */ EnlistVolatile$1(/*ISinglePhaseNotification*/ singlePhaseNotification, /*EnlistmentOptions*/ enlistmentOptions)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "EnlistVolatile");
                }
                $.$spc.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                $.$spc.System.ArgumentNullException.ThrowIfNull(singlePhaseNotification, "singlePhaseNotification");
                if (enlistmentOptions !== 0/*EnlistmentOptions.None*/ && enlistmentOptions !== 1/*EnlistmentOptions.EnlistDuringPrepareRequired*/)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("enlistmentOptions");
                }
                if (this._complete)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateTransactionCompletedException(this.DistributedTxId);
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        /*Enlistment*/ let enlistment = this._internalTransaction.State.EnlistVolatile$1(this._internalTransaction, singlePhaseNotification, enlistmentOptions, this);
                        if (etwLog.IsEnabled())
                        {
                            etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "EnlistVolatile");
                        }
                        return enlistment;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                }
            }
            /*Transaction */ Clone()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "Clone");
                }
                $.$spc.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                if (this._complete)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateTransactionCompletedException(this.DistributedTxId);
                }
                /*Transaction*/ let clone = this.InternalClone();
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "Clone");
                }
                return clone;
            }
            /*Transaction */ InternalClone()
            {
                /*Transaction*/ let clone = new $.$stl.System.Transactions.Transaction().$ctor$2(this._isoLevel, this._internalTransaction);
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionCloneCreate(clone, "Transaction");
                }
                return clone;
            }
            /*DependentTransaction */ DependentClone(/*DependentCloneOption*/ cloneOption)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "DependentClone");
                }
                if (cloneOption !== 0/*DependentCloneOption.BlockCommitUntilComplete*/ && cloneOption !== 1/*DependentCloneOption.RollbackIfNotComplete*/)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("cloneOption");
                }
                $.$spc.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                if (this._complete)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateTransactionCompletedException(this.DistributedTxId);
                }
                /*DependentTransaction*/ let clone = new $.$stl.System.Transactions.DependentTransaction().$ctor$5(this._isoLevel, this._internalTransaction, cloneOption === 0/*DependentCloneOption.BlockCommitUntilComplete*/);
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionCloneCreate(clone, "DependentTransaction");
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "DependentClone");
                }
                return clone;
            }
            /*TransactionTraceIdentifier */ get TransactionTraceId()
            {
                if ($.$stl.System.Transactions.TransactionTraceIdentifier.op_Equality(this._traceIdentifier, $.$stl.System.Transactions.TransactionTraceIdentifier.Empty))
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                        {
                            if ($.$stl.System.Transactions.TransactionTraceIdentifier.op_Equality(this._traceIdentifier, $.$stl.System.Transactions.TransactionTraceIdentifier.Empty))
                            {
                                /*TransactionTraceIdentifier*/ let temp = new $.$stl.System.Transactions.TransactionTraceIdentifier().$ctor$2(this._internalTransaction.TransactionTraceId.TransactionIdentifier, this._cloneId);
                                $.$spc.System.Threading.Interlocked.MemoryBarrier();
                                this._traceIdentifier = temp;
                            }
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                    }
                }
                return this._traceIdentifier;
            }
            /*TransactionCompletedEventHandler?*/ add_TransactionCompleted(value)
            {
                $.$spc.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        this._internalTransaction.State.AddOutcomeRegistrant(this._internalTransaction, value);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                }
            }
            /*TransactionCompletedEventHandler?*/ remove_TransactionCompleted(value)
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                    {
                        this._internalTransaction._transactionCompletedDelegate = $.$cast($.$spc.System.Delegate.Remove(this._internalTransaction._transactionCompletedDelegate, value), $.$stl.System.Transactions.TransactionCompletedEventHandler);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                }
            }
            /*void */ Dispose()
            {
                this.InternalDispose();
            }
            /*void */ InternalDispose()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "InternalDispose");
                }
                if ($.$spc.System.Threading.Interlocked.Exchange($.$ref(() => this._disposed, ($v) => this._disposed = $v, $.$spc.System.Int32), 1/*Transaction._disposedTrueValue*/) === 1/*Transaction._disposedTrueValue*/)
                {
                    return;
                }
                /*long*/ let remainingITx = BigInt($.$spc.System.Threading.Interlocked.Decrement($.$ref(() => this._internalTransaction._cloneCount, ($v) => this._internalTransaction._cloneCount = $v, $.$spc.System.Int32)));
                if (remainingITx === 0n)
                {
                    this._internalTransaction.Dispose();
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "InternalDispose");
                }
            }
            /*void */ System$Runtime$Serialization$ISerializable$GetObjectData(/*SerializationInfo*/ serializationInfo, /*StreamingContext*/ context)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ EnlistPromotableSinglePhase(/*IPromotableSinglePhaseNotification*/ promotableSinglePhaseNotification)
            {
                return this.EnlistPromotableSinglePhase$1(promotableSinglePhaseNotification, $.$stl.System.Transactions.TransactionInterop.PromoterTypeDtc);
            }
            /*bool */ EnlistPromotableSinglePhase$1(/*IPromotableSinglePhaseNotification*/ promotableSinglePhaseNotification, /*Guid*/ promoterType)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "EnlistPromotableSinglePhase");
                }
                $.$spc.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                $.$spc.System.ArgumentNullException.ThrowIfNull(promotableSinglePhaseNotification, "promotableSinglePhaseNotification");
                if ($.$spc.System.Guid.op_Equality(promoterType, $.$spc.System.Guid.Empty))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$stl.System.SR.PromoterTypeInvalid, "promoterType");
                }
                if (this._complete)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateTransactionCompletedException(this.DistributedTxId);
                }
                /*bool*/ let succeeded = false;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        succeeded = this._internalTransaction.State.EnlistPromotableSinglePhase(this._internalTransaction, promotableSinglePhaseNotification, this, promoterType);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "EnlistPromotableSinglePhase");
                }
                return succeeded;
            }
            /*Enlistment */ PromoteAndEnlistDurable(/*Guid*/ resourceManagerIdentifier, /*IPromotableSinglePhaseNotification*/ promotableNotification, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(2/*TraceSourceType.TraceSourceOleTx*/, this, "PromoteAndEnlistDurable");
                }
                $.$spc.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                if ($.$spc.System.Guid.op_Equality(resourceManagerIdentifier, $.$spc.System.Guid.Empty))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$stl.System.SR.BadResourceManagerId, "resourceManagerIdentifier");
                }
                $.$spc.System.ArgumentNullException.ThrowIfNull(promotableNotification, "promotableNotification");
                $.$spc.System.ArgumentNullException.ThrowIfNull(enlistmentNotification, "enlistmentNotification");
                if (enlistmentOptions !== 0/*EnlistmentOptions.None*/ && enlistmentOptions !== 1/*EnlistmentOptions.EnlistDuringPrepareRequired*/)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("enlistmentOptions");
                }
                if (this._complete)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateTransactionCompletedException(this.DistributedTxId);
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        /*Enlistment*/ let enlistment = this._internalTransaction.State.PromoteAndEnlistDurable(this._internalTransaction, resourceManagerIdentifier, promotableNotification, enlistmentNotification, enlistmentOptions, this);
                        if (etwLog.IsEnabled())
                        {
                            etwLog.MethodExit(2/*TraceSourceType.TraceSourceOleTx*/, this, "PromoteAndEnlistDurable");
                        }
                        return enlistment;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                }
            }
            /*void */ SetDistributedTransactionIdentifier(/*IPromotableSinglePhaseNotification*/ promotableNotification, /*Guid*/ distributedTransactionIdentifier)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "SetDistributedTransactionIdentifier");
                }
                $.$spc.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                $.$spc.System.ArgumentNullException.ThrowIfNull(promotableNotification, "promotableNotification");
                if ($.$spc.System.Guid.op_Equality(distributedTransactionIdentifier, $.$spc.System.Guid.Empty))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13(null, "distributedTransactionIdentifier");
                }
                if (this._complete)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateTransactionCompletedException(this.DistributedTxId);
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        this._internalTransaction.State.SetDistributedTransactionId(this._internalTransaction, promotableNotification, distributedTransactionIdentifier);
                        if (etwLog.IsEnabled())
                        {
                            etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "SetDistributedTransactionIdentifier");
                        }
                        return;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                }
            }
            /*OletxTransaction? */ Promote()
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        this._internalTransaction.ThrowIfPromoterTypeIsNotMSDTC();
                        this._internalTransaction.State.Promote(this._internalTransaction);
                        return this._internalTransaction.PromotedTransaction;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                }
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this._internalTransaction = null;
                this._traceIdentifier = $.$default($.$stl.System.Transactions.TransactionTraceIdentifier);
            }
            static $h = 4302085;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":4302085,"g":{"r":0,"d":0,"h":25774105861,"f":33},"s":{"r":0,"d":0,"h":30069073157,"f":33},"n":"Current","d":4302085,"h":21479138565,"f":33},{"p":262145,"g":{"r":0,"d":0,"h":60133844229,"f":8},"n":"Disposed","d":4302085,"h":55838876933,"f":8},{"p":56229889,"g":{"r":0,"d":0,"h":68723778821,"f":8},"n":"DistributedTxId","d":4302085,"h":64428811525,"f":8},{"p":4760837,"g":{"r":0,"d":0,"h":120263386373,"f":1},"n":"TransactionInformation","d":4302085,"h":115968419077,"f":1},{"p":3187973,"g":{"r":0,"d":0,"h":128853320965,"f":1},"n":"IsolationLevel","d":4302085,"h":124558353669,"f":1},{"p":56229889,"g":{"r":0,"d":0,"h":137443255557,"f":1},"n":"PromoterType","d":4302085,"h":133148288261,"f":1},{"p":8561925,"g":{"r":0,"d":0,"h":188982863109,"f":8},"n":"TransactionTraceId","d":4302085,"h":184687895813,"f":8}],"m":[{"r":262145,"n":"UseServiceDomainForCurrent","d":4302085,"h":4299269381,"f":40},{"r":2270469,"p":[{"n":"currentScope","p":5154053}],"n":"InteropMode","d":4302085,"h":8594236677,"f":40},{"r":4302085,"p":[{"n":"currentScope","p":5154053},{"n":"contextData","p":894213},{"n":"contextTransaction","p":4302085,"f":2}],"n":"FastGetTransaction","d":4302085,"h":12889203973,"f":40},{"r":65537,"p":[{"n":"defaultLookup","p":8627461},{"n":"current","p":4302085,"f":2},{"n":"currentScope","p":5154053,"f":2},{"n":"contextTransaction","p":4302085,"f":2}],"n":"GetCurrentTransactionAndScope","d":4302085,"h":17184171269,"f":40},{"r":655361,"n":"GetHashCode","d":4302085,"h":98788549893,"f":32769},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":4302085,"h":103083517189,"f":32769},{"r":0,"n":"GetPromotedToken","d":4302085,"h":141738222853,"f":1},{"r":1746181,"p":[{"n":"resourceManagerIdentifier","p":56229889},{"n":"enlistmentNotification","p":2598149},{"n":"enlistmentOptions","p":1877253}],"n":"EnlistDurable","d":4302085,"h":146033190149,"f":1},{"r":1746181,"p":[{"n":"resourceManagerIdentifier","p":56229889},{"n":"singlePhaseNotification","p":3056901},{"n":"enlistmentOptions","p":1877253}],"n":"EnlistDurable","o":"@$1","d":4302085,"h":150328157445,"f":1},{"r":65537,"n":"Rollback","d":4302085,"h":154623124741,"f":1},{"r":65537,"p":[{"n":"e","p":47251457}],"n":"Rollback","o":"@$1","d":4302085,"h":158918092037,"f":1},{"r":1746181,"p":[{"n":"enlistmentNotification","p":2598149},{"n":"enlistmentOptions","p":1877253}],"n":"EnlistVolatile","d":4302085,"h":163213059333,"f":1},{"r":1746181,"p":[{"n":"singlePhaseNotification","p":3056901},{"n":"enlistmentOptions","p":1877253}],"n":"EnlistVolatile","o":"@$1","d":4302085,"h":167508026629,"f":1},{"r":4302085,"n":"Clone","d":4302085,"h":171802993925,"f":1},{"r":4302085,"n":"InternalClone","d":4302085,"h":176097961221,"f":8},{"r":1156357,"p":[{"n":"cloneOption","p":1090821}],"n":"DependentClone","d":4302085,"h":180392928517,"f":1},{"r":65537,"n":"Dispose","d":4302085,"h":206162732293,"f":1},{"r":65537,"n":"InternalDispose","d":4302085,"h":210457699589,"f":136},{"r":262145,"p":[{"n":"promotableSinglePhaseNotification","p":2860293}],"n":"EnlistPromotableSinglePhase","d":4302085,"h":219047634181,"f":1},{"r":262145,"p":[{"n":"promotableSinglePhaseNotification","p":2860293},{"n":"promoterType","p":56229889}],"n":"EnlistPromotableSinglePhase","o":"@$1","d":4302085,"h":223342601477,"f":1},{"r":1746181,"p":[{"n":"resourceManagerIdentifier","p":56229889},{"n":"promotableNotification","p":2860293},{"n":"enlistmentNotification","p":3056901},{"n":"enlistmentOptions","p":1877253}],"n":"PromoteAndEnlistDurable","d":4302085,"h":227637568773,"f":1},{"r":65537,"p":[{"n":"promotableNotification","p":2860293},{"n":"distributedTransactionIdentifier","p":56229889}],"n":"SetDistributedTransactionIdentifier","d":4302085,"h":231932536069,"f":1},{"r":3515653,"n":"Promote","d":4302085,"h":236227503365,"f":8}],"l":[{"t":3187973,"n":"_isoLevel","d":4302085,"h":34364040453,"f":8},{"t":262145,"n":"_complete","d":4302085,"h":38659007749,"f":8},{"t":655361,"n":"_cloneId","d":4302085,"h":42953975045,"f":8},{"t":655361,"n":"_disposedTrueValue","d":4302085,"h":47248942341,"f":40},{"t":655361,"n":"_disposed","d":4302085,"h":51543909637,"f":8},{"t":2794757,"n":"_internalTransaction","d":4302085,"h":73018746117,"f":8},{"t":8561925,"n":"_traceIdentifier","d":4302085,"h":77313713413,"f":8}],"c":[{"n":".ctor","o":"$ctor$1","d":4302085,"h":81608680709,"f":2},{"p":[{"n":"isoLevel","p":3187973},{"n":"internalTransaction","p":2794757}],"n":".ctor","o":"$ctor$2","d":4302085,"h":85903648005,"f":8},{"p":[{"n":"distributedTransaction","p":3515653}],"n":".ctor","o":"$ctor$3","d":4302085,"h":90198615301,"f":8},{"p":[{"n":"isoLevel","p":3187973},{"n":"superior","p":2991365}],"n":".ctor","o":"$ctor$4","d":4302085,"h":94493582597,"f":8}],"e":[{"e":4433157,"m":{"r":65537,"p":[{"n":"value","p":4433157}],"n":"add_TransactionCompleted","d":4302085,"h":197572797701,"f":1},"r":{"r":65537,"p":[{"n":"value","p":4433157}],"n":"remove_TransactionCompleted","d":4302085,"h":201867764997,"f":1},"n":"TransactionCompleted","d":4302085,"h":193277830405,"f":1}],"i":[57540609,113377281],"h":4302085}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Transactions.Transaction`; }
        });
        
        $asm.$cls("$stl.System.Transactions.EnlistmentStatePromoted", ($self) => class EnlistmentStatePromoted extends $.$stl.System.Transactions.EnlistmentState
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                enlistment.State = this;
            }
            /*void */ EnlistmentDone(/*InternalEnlistment*/ enlistment)
            {
                $.$spc.System.Threading.Monitor.Exit(enlistment.SyncRoot);
                try
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.PromotedEnlistment !== null, "enlistment.PromotedEnlistment != null");
                    enlistment.PromotedEnlistment.System$Transactions$IPromotedEnlistment$EnlistmentDone();
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(enlistment.SyncRoot);
                    }
                }
            }
            /*void */ Prepared(/*InternalEnlistment*/ enlistment)
            {
                $.$spc.System.Threading.Monitor.Exit(enlistment.SyncRoot);
                try
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.PromotedEnlistment !== null, "enlistment.PromotedEnlistment != null");
                    enlistment.PromotedEnlistment.System$Transactions$IPromotedEnlistment$Prepared();
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(enlistment.SyncRoot);
                    }
                }
            }
            /*void */ ForceRollback(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
                $.$spc.System.Threading.Monitor.Exit(enlistment.SyncRoot);
                try
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.PromotedEnlistment !== null, "enlistment.PromotedEnlistment != null");
                    enlistment.PromotedEnlistment.System$Transactions$IPromotedEnlistment$ForceRollback$1(e);
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(enlistment.SyncRoot);
                    }
                }
            }
            /*void */ Committed(/*InternalEnlistment*/ enlistment)
            {
                $.$spc.System.Threading.Monitor.Exit(enlistment.SyncRoot);
                try
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.PromotedEnlistment !== null, "enlistment.PromotedEnlistment != null");
                    enlistment.PromotedEnlistment.System$Transactions$IPromotedEnlistment$Committed();
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(enlistment.SyncRoot);
                    }
                }
            }
            /*void */ Aborted(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
                $.$spc.System.Threading.Monitor.Exit(enlistment.SyncRoot);
                try
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.PromotedEnlistment !== null, "enlistment.PromotedEnlistment != null");
                    enlistment.PromotedEnlistment.System$Transactions$IPromotedEnlistment$Aborted$1(e);
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(enlistment.SyncRoot);
                    }
                }
            }
            /*void */ InDoubt(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
                $.$spc.System.Threading.Monitor.Exit(enlistment.SyncRoot);
                try
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.PromotedEnlistment !== null, "enlistment.PromotedEnlistment != null");
                    enlistment.PromotedEnlistment.System$Transactions$IPromotedEnlistment$InDoubt$1(e);
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(enlistment.SyncRoot);
                    }
                }
            }
            /*byte[] */ RecoveryInformation(/*InternalEnlistment*/ enlistment)
            {
                $.$spc.System.Threading.Monitor.Exit(enlistment.SyncRoot);
                try
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.PromotedEnlistment !== null, "enlistment.PromotedEnlistment != null");
                    return enlistment.PromotedEnlistment.System$Transactions$IPromotedEnlistment$GetRecoveryInformation();
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(enlistment.SyncRoot);
                    }
                }
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 2008325;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1942789,"m":[{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"EnterState","d":2008325,"h":4296975621,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"EnlistmentDone","d":2008325,"h":8591942917,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"Prepared","d":2008325,"h":12886910213,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2729221},{"n":"e","p":47251457}],"n":"ForceRollback","d":2008325,"h":17181877509,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"Committed","d":2008325,"h":21476844805,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2729221},{"n":"e","p":47251457}],"n":"Aborted","d":2008325,"h":25771812101,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2729221},{"n":"e","p":47251457}],"n":"InDoubt","d":2008325,"h":30066779397,"f":32776},{"r":0,"p":[{"n":"enlistment","p":2729221}],"n":"RecoveryInformation","d":2008325,"h":34361746693,"f":32776}],"c":[{"n":".ctor","o":"$ctor$2","d":2008325,"h":38656713989,"f":1}],"h":2008325}; }
            static get $b() { return $.$stl.System.Transactions.EnlistmentState; }
            static get $fullName() { return `System.Transactions.EnlistmentStatePromoted`; }
        });
        
        $asm.$str("$stl.System.Transactions.VolatileEnlistmentSet", ($self) => class VolatileEnlistmentSet extends $.$spc.System.ValueType
        {
            /*InternalEnlistment[]*/  get _volatileEnlistments() { return this.$getField(0, 4); }
            /*InternalEnlistment[]*/  set _volatileEnlistments(value) { this.$setField(0, 4, value); }
            /*int*/  get _volatileEnlistmentCount() { return this.$getField(4, 4); }
            /*int*/  set _volatileEnlistmentCount(value) { this.$setField(4, 4, value); }
            /*int*/  get _volatileEnlistmentSize() { return this.$getField(8, 4); }
            /*int*/  set _volatileEnlistmentSize(value) { this.$setField(8, 4, value); }
            /*int*/  get _dependentClones() { return this.$getField(12, 4); }
            /*int*/  set _dependentClones(value) { this.$setField(12, 4, value); }
            /*int*/  get _preparedVolatileEnlistments() { return this.$getField(16, 4); }
            /*int*/  set _preparedVolatileEnlistments(value) { this.$setField(16, 4, value); }
            /*VolatileDemultiplexer*/  get _volatileDemux() { return this.$getField(20, 4); }
            /*VolatileDemultiplexer*/  set _volatileDemux(value) { this.$setField(20, 4, value); }
            /*VolatileDemultiplexer */ get VolatileDemux()
            {
                return this._volatileDemux;
            }
            /*VolatileDemultiplexer */ set VolatileDemux(value)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._volatileDemux === null, "volatileDemux can only be set once.");
                this._volatileDemux = value;
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._volatileEnlistments = this._volatileEnlistments;
                copy._volatileEnlistmentCount = this._volatileEnlistmentCount;
                copy._volatileEnlistmentSize = this._volatileEnlistmentSize;
                copy._dependentClones = this._dependentClones;
                copy._preparedVolatileEnlistments = this._preparedVolatileEnlistments;
                copy._volatileDemux = this._volatileDemux;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._volatileEnlistments = null;
                this._volatileEnlistmentCount = 0;
                this._volatileEnlistmentSize = 0;
                this._dependentClones = 0;
                this._preparedVolatileEnlistments = 0;
                this._volatileDemux = null;
            }
            static $h = 9348357;
            static $z = 24;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":8692997,"g":{"r":0,"d":0,"h":34369086725,"f":8},"s":{"r":0,"d":0,"h":38664054021,"f":8},"n":"VolatileDemux","d":9348357,"h":30074119429,"f":8}],"l":[{"t":0,"n":"_volatileEnlistments","d":9348357,"h":4304315653,"f":8},{"t":655361,"n":"_volatileEnlistmentCount","d":9348357,"h":8599282949,"f":8},{"t":655361,"n":"_volatileEnlistmentSize","d":9348357,"h":12894250245,"f":8},{"t":655361,"n":"_dependentClones","d":9348357,"h":17189217541,"f":8},{"t":655361,"n":"_preparedVolatileEnlistments","d":9348357,"h":21484184837,"f":8},{"t":8692997,"n":"_volatileDemux","d":9348357,"h":25779152133,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":9348357,"h":42959021317,"f":1}],"h":9348357}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Transactions.VolatileEnlistmentSet`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePSPEOperation", ($self) => class TransactionStatePSPEOperation extends $.$stl.System.Transactions.TransactionState
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                throw new $.$spc.System.InvalidOperationException().$ctor$9();
            }
            /*TransactionStatus */ get_Status(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ PSPEInitialize(/*InternalTransaction*/ tx, /*IPromotableSinglePhaseNotification*/ promotableSinglePhaseNotification, /*Guid*/ promoterType)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(tx.State === $.$stl.System.Transactions.TransactionState.TransactionStateActive, "PSPEPromote called from state other than TransactionStateActive");
                this.CommonEnterState(tx);
                try
                {
                    promotableSinglePhaseNotification.System$Transactions$IPromotableSinglePhaseNotification$Initialize();
                    tx._promoterType = promoterType;
                }
                finally
                {
                    {
                        $.$stl.System.Transactions.TransactionState.TransactionStateActive.CommonEnterState(tx);
                    }
                }
            }
            /*void */ Phase0PSPEInitialize(/*InternalTransaction*/ tx, /*IPromotableSinglePhaseNotification*/ promotableSinglePhaseNotification, /*Guid*/ promoterType)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(tx.State === $.$stl.System.Transactions.TransactionState.TransactionStatePhase0, "Phase0PSPEInitialize called from state other than TransactionStatePhase0");
                this.CommonEnterState(tx);
                try
                {
                    promotableSinglePhaseNotification.System$Transactions$IPromotableSinglePhaseNotification$Initialize();
                    tx._promoterType = promoterType;
                }
                finally
                {
                    {
                        $.$stl.System.Transactions.TransactionState.TransactionStatePhase0.CommonEnterState(tx);
                    }
                }
            }
            /*Oletx.OletxTransaction? */ PSPEPromote(/*InternalTransaction*/ tx)
            {
                /*bool*/ let changeToReturnState = true;
                /*TransactionState?*/ let returnState = tx.State;
                $.$spc.System.Diagnostics.Debug.Assert$1(returnState === $.$stl.System.Transactions.TransactionState.TransactionStateDelegated || returnState === $.$stl.System.Transactions.TransactionState.TransactionStateDelegatedSubordinate || returnState === $.$stl.System.Transactions.TransactionState.TransactionStateDelegatedNonMSDTC, "PSPEPromote called from state other than TransactionStateDelegated[NonMSDTC]");
                this.CommonEnterState(tx);
                /*Oletx.OletxTransaction?*/ let distributedTx = null;
                try
                {
                    if (tx._attemptingPSPEPromote)
                    {
                        throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException$1(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.PromotedReturnedInvalidValue, null, tx.DistributedTxId);
                    }
                    tx._attemptingPSPEPromote = true;
                    $.$spc.System.Diagnostics.Debug.Assert$1(tx._promoter !== null, "tx._promoter != null");
                    /*byte[]?*/ let propagationToken = tx._promoter.System$Transactions$ITransactionPromoter$Promote();
                    if ($.$spc.System.Guid.op_Inequality(tx._promoterType, $.$stl.System.Transactions.TransactionInterop.PromoterTypeDtc))
                    {
                        if (propagationToken === null)
                        {
                            throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException$1(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.PromotedReturnedInvalidValue, null, tx.DistributedTxId);
                        }
                        tx.promotedToken = propagationToken;
                        return null;
                    }
                    if (propagationToken === null)
                    {
                        if (tx.PromotedTransaction === null)
                        {
                            throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException$1(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.PromotedReturnedInvalidValue, null, tx.DistributedTxId);
                        }
                        changeToReturnState = false;
                        distributedTx = tx.PromotedTransaction;
                    }
                    if (distributedTx === null)
                    {
                        try
                        {
                            distributedTx = $.$stl.System.Transactions.TransactionInterop.GetOletxTransactionFromTransmitterPropagationToken(propagationToken);
                        }
                        catch(e)
                        {
                            throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException$1(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.PromotedReturnedInvalidValue, e, tx.DistributedTxId);
                        }
                        if ($.$stl.System.Transactions.Transaction.op_Inequality($.$stl.System.Transactions.TransactionManager.FindPromotedTransaction(distributedTx.Identifier), null))
                        {
                            throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException$1(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.PromotedTransactionExists, null, tx.DistributedTxId);
                        }
                    }
                }
                finally
                {
                    {
                        tx._attemptingPSPEPromote = false;
                        if (changeToReturnState)
                        {
                            returnState.CommonEnterState(tx);
                        }
                    }
                }
                return distributedTx;
            }
            /*Enlistment */ PromoteAndEnlistDurable(/*InternalTransaction*/ tx, /*Guid*/ resourceManagerIdentifier, /*IPromotableSinglePhaseNotification*/ promotableNotification, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                if (!tx._attemptingPSPEPromote)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
                }
                if (promotableNotification !== tx._promoter)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException$1(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.InvalidIPromotableSinglePhaseNotificationSpecified, null, tx.DistributedTxId);
                }
                /*Enlistment*/ let enlistment;
                tx._durableEnlistment = null;
                tx._promoteState = $.$stl.System.Transactions.TransactionState.TransactionStatePromoted;
                tx._promoteState.EnterState(tx);
                enlistment = tx.State.EnlistDurable$1(tx, resourceManagerIdentifier, enlistmentNotification, enlistmentOptions, atomicTransaction);
                tx._durableEnlistment = enlistment.InternalEnlistment;
                return enlistment;
            }
            /*void */ SetDistributedTransactionId(/*InternalTransaction*/ tx, /*IPromotableSinglePhaseNotification*/ promotableNotification, /*Guid*/ distributedTransactionIdentifier)
            {
                if (!tx._attemptingPSPEPromote)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
                }
                if (promotableNotification !== tx._promoter)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException$1(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.InvalidIPromotableSinglePhaseNotificationSpecified, null, tx.DistributedTxId);
                }
                tx._distributedTransactionIdentifierNonMSDTC = distributedTransactionIdentifier;
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 8103173;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":5743877,"m":[{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"EnterState","d":8103173,"h":4303070469,"f":32776},{"r":8430853,"p":[{"n":"tx","p":2794757}],"n":"get_Status","d":8103173,"h":8598037765,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"promotableSinglePhaseNotification","p":2860293},{"n":"promoterType","p":56229889}],"n":"PSPEInitialize","d":8103173,"h":12893005061,"f":8},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"promotableSinglePhaseNotification","p":2860293},{"n":"promoterType","p":56229889}],"n":"Phase0PSPEInitialize","d":8103173,"h":17187972357,"f":8},{"r":3515653,"p":[{"n":"tx","p":2794757}],"n":"PSPEPromote","d":8103173,"h":21482939653,"f":8},{"r":1746181,"p":[{"n":"tx","p":2794757},{"n":"resourceManagerIdentifier","p":56229889},{"n":"promotableNotification","p":2860293},{"n":"enlistmentNotification","p":3056901},{"n":"enlistmentOptions","p":1877253},{"n":"atomicTransaction","p":4302085}],"n":"PromoteAndEnlistDurable","d":8103173,"h":25777906949,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"promotableNotification","p":2860293},{"n":"distributedTransactionIdentifier","p":56229889}],"n":"SetDistributedTransactionId","d":8103173,"h":30072874245,"f":32776}],"c":[{"n":".ctor","o":"$ctor$2","d":8103173,"h":34367841541,"f":1}],"h":8103173}; }
            static get $b() { return $.$stl.System.Transactions.TransactionState; }
            static get $fullName() { return `System.Transactions.TransactionStatePSPEOperation`; }
        });
        
        $asm.$str("$stl.System.Transactions.TransactionOptions", ($self) => class TransactionOptions extends $.$spc.System.ValueType
        {
            /*TimeSpan*/  get _timeout() { return this.$getField(0, $.$spc.System.TimeSpan); }
            /*TimeSpan*/  set _timeout(value) { this.$setField(0, $.$spc.System.TimeSpan, value); }
            /*IsolationLevel*/  get _isolationLevel() { return this.$getField(8, $.$stl.System.Transactions.IsolationLevel); }
            /*IsolationLevel*/  set _isolationLevel(value) { this.$setField(8, $.$stl.System.Transactions.IsolationLevel, value); }
            /*TimeSpan */ get Timeout()
            {
                return this._timeout;
            }
            /*TimeSpan */ set Timeout(value)
            {
                this._timeout = value;
            }
            /*IsolationLevel */ get IsolationLevel()
            {
                return this._isolationLevel;
            }
            /*IsolationLevel */ set IsolationLevel(value)
            {
                this._isolationLevel = value;
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$spc.System.ValueType.GetHashCode.call(this);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$stl.System.Transactions.TransactionOptions.GetHashCode.apply(this, arguments); }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                let transactionOptions;
                return $.$is(obj, $.$stl.System.Transactions.TransactionOptions, { set $v(v){ transactionOptions = v; } }) && this.Equals$2(transactionOptions.Clone());
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$stl.System.Transactions.TransactionOptions.Equals.apply(this, arguments); }
            /*bool */ Equals$2(/*TransactionOptions*/ other)
            {
                return $.$spc.System.TimeSpan.op_Equality(this._timeout, other._timeout) && this._isolationLevel === other._isolationLevel;
            }
            static /*bool */ op_Equality(/*TransactionOptions*/ x, /*TransactionOptions*/ y)
            {
                return x.Equals$2(y.Clone());
            }
            static /*bool */ op_Inequality(/*TransactionOptions*/ x, /*TransactionOptions*/ y)
            {
                return !x.Equals$2(y.Clone());
            }
            //Generated interface implemetation for System.IEquatable<System.Transactions.TransactionOptions>.Equals(System.Transactions.TransactionOptions)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._timeout = this._timeout.Clone();
                copy._isolationLevel = this._isolationLevel;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._timeout = $.$default($.$spc.System.TimeSpan);
                this._isolationLevel = 0;
            }
            static $h = 5022981;
            static $z = 12;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":140705793,"g":{"r":0,"d":0,"h":17184892165,"f":1},"s":{"r":0,"d":0,"h":21479859461,"f":1},"n":"Timeout","d":5022981,"h":12889924869,"f":1},{"p":3187973,"g":{"r":0,"d":0,"h":30069794053,"f":1},"s":{"r":0,"d":0,"h":34364761349,"f":1},"n":"IsolationLevel","d":5022981,"h":25774826757,"f":1}],"m":[{"r":655361,"n":"GetHashCode","d":5022981,"h":38659728645,"f":32769},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":5022981,"h":42954695941,"f":32769},{"r":262145,"p":[{"n":"other","p":5022981}],"n":"Equals","o":"@$2","d":5022981,"h":47249663237,"f":1}],"l":[{"t":140705793,"n":"_timeout","d":5022981,"h":4299990277,"f":2},{"t":3187973,"n":"_isolationLevel","d":5022981,"h":8594957573,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":5022981,"h":60134565125,"f":1}],"i":[$.$spc.System.IEquatable$$($.$stl.System.Transactions.TransactionOptions).$h],"h":5022981}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$stl.System.Transactions.TransactionOptions) ]; }
            static get $fullName() { return `System.Transactions.TransactionOptions`; }
        });
        
        $asm.$str("$stl.System.Transactions.EnlistmentTraceIdentifier", ($self) => class EnlistmentTraceIdentifier extends $.$spc.System.ValueType
        {
            static /*EnlistmentTraceIdentifier */ get Empty()
            {
                return new $.$stl.System.Transactions.EnlistmentTraceIdentifier();
            }
            $ctor$2(/*Guid*/ resourceManagerIdentifier, /*TransactionTraceIdentifier*/ transactionTraceId, /*int*/ enlistmentIdentifier)
            {
                super.$ctor$1();
                {
                    this._resourceManagerIdentifier = resourceManagerIdentifier;
                    this._transactionTraceIdentifier = transactionTraceId;
                    this._enlistmentIdentifier = enlistmentIdentifier;
                }
                return this;
            }
            /*Guid*/  get _resourceManagerIdentifier() { return this.$getField(0, 16); }
            /*Guid*/  set _resourceManagerIdentifier(value) { this.$setField(0, 16, value); }
            /*Guid */ get ResourceManagerIdentifier()
            {
                return this._resourceManagerIdentifier;
            }
            /*TransactionTraceIdentifier*/  get _transactionTraceIdentifier() { return this.$getField(16, 8); }
            /*TransactionTraceIdentifier*/  set _transactionTraceIdentifier(value) { this.$setField(16, 8, value); }
            /*TransactionTraceIdentifier */ get TransactionTraceId()
            {
                return this._transactionTraceIdentifier;
            }
            /*int*/  get _enlistmentIdentifier() { return this.$getField(24, 4); }
            /*int*/  set _enlistmentIdentifier(value) { this.$setField(24, 4, value); }
            /*int */ get EnlistmentIdentifier()
            {
                return this._enlistmentIdentifier;
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$spc.System.ValueType.GetHashCode.call(this);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$stl.System.Transactions.EnlistmentTraceIdentifier.GetHashCode.apply(this, arguments); }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                let enlistmentTraceId;
                return $.$is(obj, $.$stl.System.Transactions.EnlistmentTraceIdentifier, { set $v(v){ enlistmentTraceId = v; } }) && this.Equals$2(enlistmentTraceId);
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$stl.System.Transactions.EnlistmentTraceIdentifier.Equals.apply(this, arguments); }
            /*bool */ Equals$2(/*EnlistmentTraceIdentifier*/ other)
            {
                return this._enlistmentIdentifier === other._enlistmentIdentifier && $.$spc.System.Guid.op_Equality(this._resourceManagerIdentifier, other._resourceManagerIdentifier) && $.$stl.System.Transactions.TransactionTraceIdentifier.op_Equality(this._transactionTraceIdentifier, other._transactionTraceIdentifier);
            }
            static /*bool */ op_Equality(/*EnlistmentTraceIdentifier*/ left, /*EnlistmentTraceIdentifier*/ right)
            {
                return left.Equals$2(right);
            }
            static /*bool */ op_Inequality(/*EnlistmentTraceIdentifier*/ left, /*EnlistmentTraceIdentifier*/ right)
            {
                return !left.Equals$2(right);
            }
            //Generated interface implemetation for System.IEquatable<System.Transactions.EnlistmentTraceIdentifier>.Equals(System.Transactions.EnlistmentTraceIdentifier)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._resourceManagerIdentifier = this._resourceManagerIdentifier.Clone();
                copy._transactionTraceIdentifier = this._transactionTraceIdentifier.Clone();
                copy._enlistmentIdentifier = this._enlistmentIdentifier;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._resourceManagerIdentifier = $.$default($.$spc.System.Guid);
                this._transactionTraceIdentifier = $.$default($.$stl.System.Transactions.TransactionTraceIdentifier);
                this._enlistmentIdentifier = 0;
            }
            static $h = 2073861;
            static $z = 28;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":2073861,"g":{"r":0,"d":0,"h":8592008453,"f":33},"n":"Empty","d":2073861,"h":4297041157,"f":33},{"p":56229889,"g":{"r":0,"d":0,"h":25771877637,"f":1},"n":"ResourceManagerIdentifier","d":2073861,"h":21476910341,"f":1},{"p":8561925,"g":{"r":0,"d":0,"h":38656779525,"f":1},"n":"TransactionTraceId","d":2073861,"h":34361812229,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":51541681413,"f":1},"n":"EnlistmentIdentifier","d":2073861,"h":47246714117,"f":1}],"m":[{"r":655361,"n":"GetHashCode","d":2073861,"h":55836648709,"f":32769},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":2073861,"h":60131616005,"f":32769},{"r":262145,"p":[{"n":"other","p":2073861}],"n":"Equals","o":"@$2","d":2073861,"h":64426583301,"f":1}],"l":[{"t":56229889,"n":"_resourceManagerIdentifier","d":2073861,"h":17181943045,"f":2},{"t":8561925,"n":"_transactionTraceIdentifier","d":2073861,"h":30066844933,"f":2},{"t":655361,"n":"_enlistmentIdentifier","d":2073861,"h":42951746821,"f":2}],"c":[{"p":[{"n":"resourceManagerIdentifier","p":56229889},{"n":"transactionTraceId","p":8561925},{"n":"enlistmentIdentifier","p":655361}],"n":".ctor","o":"$ctor$2","d":2073861,"h":12886975749,"f":1},{"n":".ctor","o":"$ctor$3","d":2073861,"h":77311485189,"f":1}],"i":[$.$spc.System.IEquatable$$($.$stl.System.Transactions.EnlistmentTraceIdentifier).$h],"h":2073861}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$stl.System.Transactions.EnlistmentTraceIdentifier) ]; }
            static get $fullName() { return `System.Transactions.EnlistmentTraceIdentifier`; }
        });
        
        $asm.$str("$stl.System.Transactions.TransactionTraceIdentifier", ($self) => class TransactionTraceIdentifier extends $.$spc.System.ValueType
        {
            static /*TransactionTraceIdentifier */ get Empty()
            {
                return new $.$stl.System.Transactions.TransactionTraceIdentifier();
            }
            $ctor$2(/*string*/ transactionIdentifier, /*int*/ cloneIdentifier)
            {
                super.$ctor$1();
                {
                    this._transactionIdentifier = transactionIdentifier;
                    this._cloneIdentifier = cloneIdentifier;
                }
                return this;
            }
            /*string*/  get _transactionIdentifier() { return this.$getField(0, 4); }
            /*string*/  set _transactionIdentifier(value) { this.$setField(0, 4, value); }
            /*string */ get TransactionIdentifier()
            {
                return this._transactionIdentifier;
            }
            /*int*/  get _cloneIdentifier() { return this.$getField(4, 4); }
            /*int*/  set _cloneIdentifier(value) { this.$setField(4, 4, value); }
            /*int */ get CloneIdentifier()
            {
                return this._cloneIdentifier;
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$spc.System.ValueType.GetHashCode.call(this);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$stl.System.Transactions.TransactionTraceIdentifier.GetHashCode.apply(this, arguments); }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                let transactionTraceId;
                return $.$is(obj, $.$stl.System.Transactions.TransactionTraceIdentifier, { set $v(v){ transactionTraceId = v; } }) && this.Equals$2(transactionTraceId);
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$stl.System.Transactions.TransactionTraceIdentifier.Equals.apply(this, arguments); }
            /*bool */ Equals$2(/*TransactionTraceIdentifier*/ other)
            {
                return this._cloneIdentifier === other._cloneIdentifier && $.$spc.System.String.op_Equality(this._transactionIdentifier, other._transactionIdentifier);
            }
            static /*bool */ op_Equality(/*TransactionTraceIdentifier*/ left, /*TransactionTraceIdentifier*/ right)
            {
                return left.Equals$2(right);
            }
            static /*bool */ op_Inequality(/*TransactionTraceIdentifier*/ left, /*TransactionTraceIdentifier*/ right)
            {
                return !left.Equals$2(right);
            }
            //Generated interface implemetation for System.IEquatable<System.Transactions.TransactionTraceIdentifier>.Equals(System.Transactions.TransactionTraceIdentifier)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._transactionIdentifier = this._transactionIdentifier;
                copy._cloneIdentifier = this._cloneIdentifier;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._transactionIdentifier = null;
                this._cloneIdentifier = 0;
            }
            static $h = 8561925;
            static $z = 8;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":8561925,"g":{"r":0,"d":0,"h":8598496517,"f":33},"n":"Empty","d":8561925,"h":4303529221,"f":33},{"p":1310721,"g":{"r":0,"d":0,"h":25778365701,"f":1},"n":"TransactionIdentifier","d":8561925,"h":21483398405,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":38663267589,"f":1},"n":"CloneIdentifier","d":8561925,"h":34368300293,"f":1}],"m":[{"r":655361,"n":"GetHashCode","d":8561925,"h":42958234885,"f":32769},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":8561925,"h":47253202181,"f":32769},{"r":262145,"p":[{"n":"other","p":8561925}],"n":"Equals","o":"@$2","d":8561925,"h":51548169477,"f":1}],"l":[{"t":1310721,"n":"_transactionIdentifier","d":8561925,"h":17188431109,"f":2},{"t":655361,"n":"_cloneIdentifier","d":8561925,"h":30073332997,"f":2}],"c":[{"p":[{"n":"transactionIdentifier","p":1310721},{"n":"cloneIdentifier","p":655361}],"n":".ctor","o":"$ctor$2","d":8561925,"h":12893463813,"f":1},{"n":".ctor","o":"$ctor$3","d":8561925,"h":64433071365,"f":1}],"i":[$.$spc.System.IEquatable$$($.$stl.System.Transactions.TransactionTraceIdentifier).$h],"h":8561925}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$stl.System.Transactions.TransactionTraceIdentifier) ]; }
            static get $fullName() { return `System.Transactions.TransactionTraceIdentifier`; }
        });
        
        $asm.$cls("$stl.System.Transactions.Phase0VolatileDemultiplexer", ($self) => class Phase0VolatileDemultiplexer extends $.$stl.System.Transactions.VolatileDemultiplexer
        {
            $ctor$2(/*InternalTransaction*/ transaction)
            {
                super.$ctor$1(transaction);
                {
                }
                return this;
            }
            /*void */ InternalPrepare()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._promotedEnlistment !== null && this._transaction.State !== null, "_promotedEnlistment != null && _transaction.State != null");
                try
                {
                    this._transaction.State.ChangeStatePromotedPhase0(this._transaction);
                }
                catch($e)
                {
                    if ($e instanceof $.$stl.System.Transactions.TransactionAbortedException)
                    {
                        let e = $e;
                        this._promotedEnlistment.System$Transactions$IPromotedEnlistment$ForceRollback$1(e);
                        /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                        if (etwLog.IsEnabled())
                        {
                            etwLog.ExceptionConsumed$1(e);
                        }
                    }
                    else if ($e instanceof $.$stl.System.Transactions.TransactionInDoubtException)
                    {
                        let e = $e;
                        this._promotedEnlistment.System$Transactions$IPromotedEnlistment$EnlistmentDone();
                        /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                        if (etwLog.IsEnabled())
                        {
                            etwLog.ExceptionConsumed$1(e);
                        }
                    }
                    else
                    {
                        throw $e;
                    }
                }
            }
            /*void */ InternalCommit()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._promotedEnlistment !== null && this._transaction.State !== null, "_promotedEnlistment != null && _transaction.State != null");
                this._promotedEnlistment.System$Transactions$IPromotedEnlistment$EnlistmentDone();
                this._transaction.State.ChangeStatePromotedCommitted(this._transaction);
            }
            /*void */ InternalRollback()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._promotedEnlistment !== null && this._transaction.State !== null, "_promotedEnlistment != null && _transaction.State != null");
                this._promotedEnlistment.System$Transactions$IPromotedEnlistment$EnlistmentDone();
                this._transaction.State.ChangeStatePromotedAborted(this._transaction);
            }
            /*void */ InternalInDoubt()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._transaction.State !== null, "_transaction.State != null");
                this._transaction.State.InDoubtFromDtc(this._transaction);
            }
            /*void */ Prepare(/*IPromotedEnlistment*/ en)
            {
                this._preparingEnlistment = en;
                $.$stl.System.Transactions.VolatileDemultiplexer.PoolablePrepare(this);
            }
            /*void */ Commit(/*IPromotedEnlistment*/ en)
            {
                this._promotedEnlistment = en;
                $.$stl.System.Transactions.VolatileDemultiplexer.PoolableCommit(this);
            }
            /*void */ Rollback(/*IPromotedEnlistment*/ en)
            {
                this._promotedEnlistment = en;
                $.$stl.System.Transactions.VolatileDemultiplexer.PoolableRollback(this);
            }
            /*void */ InDoubt(/*IPromotedEnlistment*/ en)
            {
                this._promotedEnlistment = en;
                $.$stl.System.Transactions.VolatileDemultiplexer.PoolableInDoubt(this);
            }
            static $h = 3712261;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":8692997,"m":[{"r":65537,"n":"InternalPrepare","d":3712261,"h":8593646853,"f":32772},{"r":65537,"n":"InternalCommit","d":3712261,"h":12888614149,"f":32772},{"r":65537,"n":"InternalRollback","d":3712261,"h":17183581445,"f":32772},{"r":65537,"n":"InternalInDoubt","d":3712261,"h":21478548741,"f":32772},{"r":65537,"p":[{"n":"en","p":2925829}],"n":"Prepare","d":3712261,"h":25773516037,"f":32769},{"r":65537,"p":[{"n":"en","p":2925829}],"n":"Commit","d":3712261,"h":30068483333,"f":32769},{"r":65537,"p":[{"n":"en","p":2925829}],"n":"Rollback","d":3712261,"h":34363450629,"f":32769},{"r":65537,"p":[{"n":"en","p":2925829}],"n":"InDoubt","d":3712261,"h":38658417925,"f":32769}],"c":[{"p":[{"n":"transaction","p":2794757}],"n":".ctor","o":"$ctor$2","d":3712261,"h":4298679557,"f":1}],"i":[2663685],"h":3712261}; }
            static get $b() { return $.$stl.System.Transactions.VolatileDemultiplexer; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stl.System.Transactions.IEnlistmentNotificationInternal ]; }
            static get $fullName() { return `System.Transactions.Phase0VolatileDemultiplexer`; }
        });
        
        $asm.$cls("$stl.System.Transactions.Phase1VolatileDemultiplexer", ($self) => class Phase1VolatileDemultiplexer extends $.$stl.System.Transactions.VolatileDemultiplexer
        {
            $ctor$2(/*InternalTransaction*/ transaction)
            {
                super.$ctor$1(transaction);
                {
                }
                return this;
            }
            /*void */ InternalPrepare()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._promotedEnlistment !== null && this._transaction.State !== null, "_promotedEnlistment != null && _transaction.State != null");
                try
                {
                    this._transaction.State.ChangeStatePromotedPhase1(this._transaction);
                }
                catch($e)
                {
                    if ($e instanceof $.$stl.System.Transactions.TransactionAbortedException)
                    {
                        let e = $e;
                        this._promotedEnlistment.System$Transactions$IPromotedEnlistment$ForceRollback$1(e);
                        /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                        if (etwLog.IsEnabled())
                        {
                            etwLog.ExceptionConsumed$1(e);
                        }
                    }
                    else if ($e instanceof $.$stl.System.Transactions.TransactionInDoubtException)
                    {
                        let e = $e;
                        this._promotedEnlistment.System$Transactions$IPromotedEnlistment$EnlistmentDone();
                        /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                        if (etwLog.IsEnabled())
                        {
                            etwLog.ExceptionConsumed$1(e);
                        }
                    }
                    else
                    {
                        throw $e;
                    }
                }
            }
            /*void */ InternalCommit()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._promotedEnlistment !== null && this._transaction.State !== null, "_promotedEnlistment != null && _transaction.State != null");
                this._promotedEnlistment.System$Transactions$IPromotedEnlistment$EnlistmentDone();
                this._transaction.State.ChangeStatePromotedCommitted(this._transaction);
            }
            /*void */ InternalRollback()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._promotedEnlistment !== null && this._transaction.State !== null, "_promotedEnlistment != null && _transaction.State != null");
                this._promotedEnlistment.System$Transactions$IPromotedEnlistment$EnlistmentDone();
                this._transaction.State.ChangeStatePromotedAborted(this._transaction);
            }
            /*void */ InternalInDoubt()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._transaction.State !== null, "_transaction.State != null");
                this._transaction.State.InDoubtFromDtc(this._transaction);
            }
            /*void */ Prepare(/*IPromotedEnlistment*/ en)
            {
                this._preparingEnlistment = en;
                $.$stl.System.Transactions.VolatileDemultiplexer.PoolablePrepare(this);
            }
            /*void */ Commit(/*IPromotedEnlistment*/ en)
            {
                this._promotedEnlistment = en;
                $.$stl.System.Transactions.VolatileDemultiplexer.PoolableCommit(this);
            }
            /*void */ Rollback(/*IPromotedEnlistment*/ en)
            {
                this._promotedEnlistment = en;
                $.$stl.System.Transactions.VolatileDemultiplexer.PoolableRollback(this);
            }
            /*void */ InDoubt(/*IPromotedEnlistment*/ en)
            {
                this._promotedEnlistment = en;
                $.$stl.System.Transactions.VolatileDemultiplexer.PoolableInDoubt(this);
            }
            static $h = 3777797;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":8692997,"m":[{"r":65537,"n":"InternalPrepare","d":3777797,"h":8593712389,"f":32772},{"r":65537,"n":"InternalCommit","d":3777797,"h":12888679685,"f":32772},{"r":65537,"n":"InternalRollback","d":3777797,"h":17183646981,"f":32772},{"r":65537,"n":"InternalInDoubt","d":3777797,"h":21478614277,"f":32772},{"r":65537,"p":[{"n":"en","p":2925829}],"n":"Prepare","d":3777797,"h":25773581573,"f":32769},{"r":65537,"p":[{"n":"en","p":2925829}],"n":"Commit","d":3777797,"h":30068548869,"f":32769},{"r":65537,"p":[{"n":"en","p":2925829}],"n":"Rollback","d":3777797,"h":34363516165,"f":32769},{"r":65537,"p":[{"n":"en","p":2925829}],"n":"InDoubt","d":3777797,"h":38658483461,"f":32769}],"c":[{"p":[{"n":"transaction","p":2794757}],"n":".ctor","o":"$ctor$2","d":3777797,"h":4298745093,"f":1}],"i":[2663685],"h":3777797}; }
            static get $b() { return $.$stl.System.Transactions.VolatileDemultiplexer; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stl.System.Transactions.IEnlistmentNotificationInternal ]; }
            static get $fullName() { return `System.Transactions.Phase1VolatileDemultiplexer`; }
        });
        
        $asm.$cls("$stl.System.Transactions.DurableEnlistmentActive", ($self) => class DurableEnlistmentActive extends $.$stl.System.Transactions.DurableEnlistmentState
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                enlistment.State = this;
            }
            /*void */ EnlistmentDone(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentEnded.EnterState(enlistment);
            }
            /*void */ InternalAborted(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentAborting.EnterState(enlistment);
            }
            /*void */ ChangeStateCommitting(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentCommitting.EnterState(enlistment);
            }
            /*void */ ChangeStatePromoted(/*InternalEnlistment*/ enlistment, /*IPromotedEnlistment*/ promotedEnlistment)
            {
                enlistment.PromotedEnlistment = promotedEnlistment;
                $.$stl.System.Transactions.EnlistmentState.EnlistmentStatePromoted.EnterState(enlistment);
            }
            /*void */ ChangeStateDelegated(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentDelegated.EnterState(enlistment);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 1287429;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1549573,"m":[{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"EnterState","d":1287429,"h":4296254725,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"EnlistmentDone","d":1287429,"h":8591222021,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"InternalAborted","d":1287429,"h":12886189317,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"ChangeStateCommitting","d":1287429,"h":17181156613,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2729221},{"n":"promotedEnlistment","p":2925829}],"n":"ChangeStatePromoted","d":1287429,"h":21476123909,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"ChangeStateDelegated","d":1287429,"h":25771091205,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":1287429,"h":30066058501,"f":1}],"h":1287429}; }
            static get $b() { return $.$stl.System.Transactions.DurableEnlistmentState; }
            static get $fullName() { return `System.Transactions.DurableEnlistmentActive`; }
        });
        
        $asm.$cls("$stl.System.Transactions.DurableEnlistmentAborting", ($self) => class DurableEnlistmentAborting extends $.$stl.System.Transactions.DurableEnlistmentState
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                enlistment.State = this;
                $.$spc.System.Threading.Monitor.Exit(enlistment.Transaction);
                try
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.EnlistmentStatus(1/*TraceSourceType.TraceSourceLtm*/, enlistment.EnlistmentTraceId, 2/*NotificationCall.Rollback*/);
                    }
                    if (enlistment.SinglePhaseNotification !== null)
                    {
                        enlistment.SinglePhaseNotification.System$Transactions$IEnlistmentNotification$Rollback(enlistment.SinglePhaseEnlistment);
                    }
                    else 
                    {
                        enlistment.PromotableSinglePhaseNotification.System$Transactions$IPromotableSinglePhaseNotification$Rollback(enlistment.SinglePhaseEnlistment);
                    }
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(enlistment.Transaction);
                    }
                }
            }
            /*void */ Aborted(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
                enlistment.Transaction._innerException ??= e;
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentEnded.EnterState(enlistment);
            }
            /*void */ EnlistmentDone(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentEnded.EnterState(enlistment);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 1221893;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1549573,"m":[{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"EnterState","d":1221893,"h":4296189189,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2729221},{"n":"e","p":47251457}],"n":"Aborted","d":1221893,"h":8591156485,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"EnlistmentDone","d":1221893,"h":12886123781,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":1221893,"h":17181091077,"f":1}],"h":1221893}; }
            static get $b() { return $.$stl.System.Transactions.DurableEnlistmentState; }
            static get $fullName() { return `System.Transactions.DurableEnlistmentAborting`; }
        });
        
        $asm.$cls("$stl.System.Transactions.VolatileEnlistmentActive", ($self) => class VolatileEnlistmentActive extends $.$stl.System.Transactions.VolatileEnlistmentState
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                enlistment.State = this;
            }
            /*void */ EnlistmentDone(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentDone.EnterState(enlistment);
                enlistment.FinishEnlistment();
            }
            /*void */ ChangeStatePreparing(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentPreparing.EnterState(enlistment);
            }
            /*void */ ChangeStateSinglePhaseCommit(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentSPC.EnterState(enlistment);
            }
            /*void */ InternalAborted(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentAborting.EnterState(enlistment);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 8824069;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":9479429,"m":[{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"EnterState","d":8824069,"h":4303791365,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"EnlistmentDone","d":8824069,"h":8598758661,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"ChangeStatePreparing","d":8824069,"h":12893725957,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"ChangeStateSinglePhaseCommit","d":8824069,"h":17188693253,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"InternalAborted","d":8824069,"h":21483660549,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":8824069,"h":25778627845,"f":1}],"h":8824069}; }
            static get $b() { return $.$stl.System.Transactions.VolatileEnlistmentState; }
            static get $fullName() { return `System.Transactions.VolatileEnlistmentActive`; }
        });
        
        $asm.$cls("$stl.System.Transactions.DurableEnlistmentCommitting", ($self) => class DurableEnlistmentCommitting extends $.$stl.System.Transactions.DurableEnlistmentState
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                /*bool*/ let spcCommitted = false;
                enlistment.State = this;
                $.$spc.System.Threading.Monitor.Exit(enlistment.Transaction);
                try
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.EnlistmentStatus(1/*TraceSourceType.TraceSourceLtm*/, enlistment.EnlistmentTraceId, 4/*NotificationCall.SinglePhaseCommit*/);
                    }
                    if (enlistment.SinglePhaseNotification !== null)
                    {
                        enlistment.SinglePhaseNotification.System$Transactions$ISinglePhaseNotification$SinglePhaseCommit(enlistment.SinglePhaseEnlistment);
                    }
                    else 
                    {
                        enlistment.PromotableSinglePhaseNotification.System$Transactions$IPromotableSinglePhaseNotification$SinglePhaseCommit(enlistment.SinglePhaseEnlistment);
                    }
                    spcCommitted = true;
                }
                finally
                {
                    {
                        if (!spcCommitted)
                        {
                            enlistment.SinglePhaseEnlistment.InDoubt();
                        }
                        $.$spc.System.Threading.Monitor.Enter(enlistment.Transaction);
                    }
                }
            }
            /*void */ EnlistmentDone(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentEnded.EnterState(enlistment);
                $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.Transaction.State !== null, "enlistment.Transaction.State != null");
                enlistment.Transaction.State.ChangeStateTransactionCommitted(enlistment.Transaction);
            }
            /*void */ Committed(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentEnded.EnterState(enlistment);
                $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.Transaction.State !== null, "enlistment.Transaction.State != null");
                enlistment.Transaction.State.ChangeStateTransactionCommitted(enlistment.Transaction);
            }
            /*void */ Aborted(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentEnded.EnterState(enlistment);
                $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.Transaction.State !== null, "enlistment.Transaction.State != null");
                enlistment.Transaction.State.ChangeStateTransactionAborted(enlistment.Transaction, e);
            }
            /*void */ InDoubt(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentEnded.EnterState(enlistment);
                enlistment.Transaction._innerException ??= e;
                $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.Transaction.State !== null, "enlistment.Transaction.State != null");
                enlistment.Transaction.State.InDoubtFromEnlistment(enlistment.Transaction);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 1352965;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1549573,"m":[{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"EnterState","d":1352965,"h":4296320261,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"EnlistmentDone","d":1352965,"h":8591287557,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"Committed","d":1352965,"h":12886254853,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2729221},{"n":"e","p":47251457}],"n":"Aborted","d":1352965,"h":17181222149,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2729221},{"n":"e","p":47251457}],"n":"InDoubt","d":1352965,"h":21476189445,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":1352965,"h":25771156741,"f":1}],"h":1352965}; }
            static get $b() { return $.$stl.System.Transactions.DurableEnlistmentState; }
            static get $fullName() { return `System.Transactions.DurableEnlistmentCommitting`; }
        });
        
        $asm.$cls("$stl.System.Transactions.VolatileEnlistmentPreparing", ($self) => class VolatileEnlistmentPreparing extends $.$stl.System.Transactions.VolatileEnlistmentState
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                enlistment.State = this;
                $.$spc.System.Threading.Monitor.Exit(enlistment.Transaction);
                try
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.EnlistmentStatus(1/*TraceSourceType.TraceSourceLtm*/, enlistment.EnlistmentTraceId, 0/*NotificationCall.Prepare*/);
                    }
                    $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.EnlistmentNotification !== null, "enlistment.EnlistmentNotification != null");
                    enlistment.EnlistmentNotification.System$Transactions$IEnlistmentNotification$Prepare(enlistment.PreparingEnlistment);
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(enlistment.Transaction);
                    }
                }
            }
            /*void */ EnlistmentDone(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentDone.EnterState(enlistment);
                enlistment.FinishEnlistment();
            }
            /*void */ Prepared(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentPrepared.EnterState(enlistment);
                enlistment.FinishEnlistment();
            }
            /*void */ ForceRollback(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentEnded.EnterState(enlistment);
                $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.Transaction.State !== null, "enlistment.Transaction.State != null");
                enlistment.Transaction.State.ChangeStateTransactionAborted(enlistment.Transaction, e);
                enlistment.FinishEnlistment();
            }
            /*void */ ChangeStatePreparing(/*InternalEnlistment*/ enlistment)
            {
            }
            /*void */ InternalAborted(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentPreparingAborting.EnterState(enlistment);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 9217285;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":9479429,"m":[{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"EnterState","d":9217285,"h":4304184581,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"EnlistmentDone","d":9217285,"h":8599151877,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"Prepared","d":9217285,"h":12894119173,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2729221},{"n":"e","p":47251457}],"n":"ForceRollback","d":9217285,"h":17189086469,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"ChangeStatePreparing","d":9217285,"h":21484053765,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"InternalAborted","d":9217285,"h":25779021061,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":9217285,"h":30073988357,"f":1}],"h":9217285}; }
            static get $b() { return $.$stl.System.Transactions.VolatileEnlistmentState; }
            static get $fullName() { return `System.Transactions.VolatileEnlistmentPreparing`; }
        });
        
        $asm.$cls("$stl.System.Transactions.VolatileEnlistmentSPC", ($self) => class VolatileEnlistmentSPC extends $.$stl.System.Transactions.VolatileEnlistmentState
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                /*bool*/ let spcCommitted = false;
                enlistment.State = this;
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.EnlistmentStatus(1/*TraceSourceType.TraceSourceLtm*/, enlistment.EnlistmentTraceId, 4/*NotificationCall.SinglePhaseCommit*/);
                }
                $.$spc.System.Threading.Monitor.Exit(enlistment.Transaction);
                try
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.SinglePhaseNotification !== null, "enlistment.SinglePhaseNotification != null");
                    enlistment.SinglePhaseNotification.System$Transactions$ISinglePhaseNotification$SinglePhaseCommit(enlistment.SinglePhaseEnlistment);
                    spcCommitted = true;
                }
                finally
                {
                    {
                        if (!spcCommitted)
                        {
                            enlistment.SinglePhaseEnlistment.InDoubt();
                        }
                        $.$spc.System.Threading.Monitor.Enter(enlistment.Transaction);
                    }
                }
            }
            /*void */ EnlistmentDone(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentEnded.EnterState(enlistment);
                $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.Transaction.State !== null, "enlistment.Transaction.State != null");
                enlistment.Transaction.State.ChangeStateTransactionCommitted(enlistment.Transaction);
            }
            /*void */ Committed(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentEnded.EnterState(enlistment);
                $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.Transaction.State !== null, "enlistment.Transaction.State != null");
                enlistment.Transaction.State.ChangeStateTransactionCommitted(enlistment.Transaction);
            }
            /*void */ Aborted(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentEnded.EnterState(enlistment);
                $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.Transaction.State !== null, "enlistment.Transaction.State != null");
                enlistment.Transaction.State.ChangeStateTransactionAborted(enlistment.Transaction, e);
            }
            /*void */ InDoubt(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentEnded.EnterState(enlistment);
                enlistment.Transaction._innerException ??= e;
                $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.Transaction.State !== null, "enlistment.Transaction.State != null");
                enlistment.Transaction.State.InDoubtFromEnlistment(enlistment.Transaction);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 9413893;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":9479429,"m":[{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"EnterState","d":9413893,"h":4304381189,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"EnlistmentDone","d":9413893,"h":8599348485,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"Committed","d":9413893,"h":12894315781,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2729221},{"n":"e","p":47251457}],"n":"Aborted","d":9413893,"h":17189283077,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2729221},{"n":"e","p":47251457}],"n":"InDoubt","d":9413893,"h":21484250373,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":9413893,"h":25779217669,"f":1}],"h":9413893}; }
            static get $b() { return $.$stl.System.Transactions.VolatileEnlistmentState; }
            static get $fullName() { return `System.Transactions.VolatileEnlistmentSPC`; }
        });
        
        $asm.$cls("$stl.System.Transactions.DurableEnlistmentDelegated", ($self) => class DurableEnlistmentDelegated extends $.$stl.System.Transactions.DurableEnlistmentState
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                enlistment.State = this;
                $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.PromotableSinglePhaseNotification !== null, "enlistment.PromotableSinglePhaseNotification != null");
            }
            /*void */ Committed(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentEnded.EnterState(enlistment);
                $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.Transaction.State !== null, "enlistment.Transaction.State != null");
                enlistment.Transaction.State.ChangeStatePromotedCommitted(enlistment.Transaction);
            }
            /*void */ Aborted(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentEnded.EnterState(enlistment);
                enlistment.Transaction._innerException ??= e;
                $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.Transaction.State !== null, "enlistment.Transaction.State != null");
                enlistment.Transaction.State.ChangeStatePromotedAborted(enlistment.Transaction);
            }
            /*void */ InDoubt(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentEnded.EnterState(enlistment);
                enlistment.Transaction._innerException ??= e;
                $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.Transaction.State !== null, "enlistment.Transaction.State != null");
                enlistment.Transaction.State.InDoubtFromEnlistment(enlistment.Transaction);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 1418501;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1549573,"m":[{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"EnterState","d":1418501,"h":4296385797,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"Committed","d":1418501,"h":8591353093,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2729221},{"n":"e","p":47251457}],"n":"Aborted","d":1418501,"h":12886320389,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2729221},{"n":"e","p":47251457}],"n":"InDoubt","d":1418501,"h":17181287685,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":1418501,"h":21476254981,"f":1}],"h":1418501}; }
            static get $b() { return $.$stl.System.Transactions.DurableEnlistmentState; }
            static get $fullName() { return `System.Transactions.DurableEnlistmentDelegated`; }
        });
        
        $asm.$cls("$stl.System.Transactions.VolatileEnlistmentPrepared", ($self) => class VolatileEnlistmentPrepared extends $.$stl.System.Transactions.VolatileEnlistmentState
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                enlistment.State = this;
            }
            /*void */ InternalAborted(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentAborting.EnterState(enlistment);
            }
            /*void */ InternalCommitted(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentCommitting.EnterState(enlistment);
            }
            /*void */ InternalIndoubt(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentInDoubt.EnterState(enlistment);
            }
            /*void */ ChangeStatePreparing(/*InternalEnlistment*/ enlistment)
            {
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 9151749;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":9479429,"m":[{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"EnterState","d":9151749,"h":4304119045,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"InternalAborted","d":9151749,"h":8599086341,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"InternalCommitted","d":9151749,"h":12894053637,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"InternalIndoubt","d":9151749,"h":17189020933,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"ChangeStatePreparing","d":9151749,"h":21483988229,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":9151749,"h":25778955525,"f":1}],"h":9151749}; }
            static get $b() { return $.$stl.System.Transactions.VolatileEnlistmentState; }
            static get $fullName() { return `System.Transactions.VolatileEnlistmentPrepared`; }
        });
        
        $asm.$cls("$stl.System.Transactions.VolatileEnlistmentPreparingAborting", ($self) => class VolatileEnlistmentPreparingAborting extends $.$stl.System.Transactions.VolatileEnlistmentState
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                enlistment.State = this;
            }
            /*void */ EnlistmentDone(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentEnded.EnterState(enlistment);
            }
            /*void */ Prepared(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentAborting.EnterState(enlistment);
                enlistment.FinishEnlistment();
            }
            /*void */ ForceRollback(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentEnded.EnterState(enlistment);
                if (enlistment.Transaction._innerException === null)
                {
                    enlistment.Transaction._innerException = e;
                }
                enlistment.FinishEnlistment();
            }
            /*void */ InternalAborted(/*InternalEnlistment*/ enlistment)
            {
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 9282821;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":9479429,"m":[{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"EnterState","d":9282821,"h":4304250117,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"EnlistmentDone","d":9282821,"h":8599217413,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"Prepared","d":9282821,"h":12894184709,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2729221},{"n":"e","p":47251457}],"n":"ForceRollback","d":9282821,"h":17189152005,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"InternalAborted","d":9282821,"h":21484119301,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":9282821,"h":25779086597,"f":1}],"h":9282821}; }
            static get $b() { return $.$stl.System.Transactions.VolatileEnlistmentState; }
            static get $fullName() { return `System.Transactions.VolatileEnlistmentPreparingAborting`; }
        });
        
        $asm.$cls("$stl.System.Transactions.DurableEnlistmentEnded", ($self) => class DurableEnlistmentEnded extends $.$stl.System.Transactions.DurableEnlistmentState
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                enlistment.State = this;
            }
            /*void */ InternalAborted(/*InternalEnlistment*/ enlistment)
            {
            }
            /*void */ InDoubt(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 1484037;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1549573,"m":[{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"EnterState","d":1484037,"h":4296451333,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"InternalAborted","d":1484037,"h":8591418629,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2729221},{"n":"e","p":47251457}],"n":"InDoubt","d":1484037,"h":12886385925,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":1484037,"h":17181353221,"f":1}],"h":1484037}; }
            static get $b() { return $.$stl.System.Transactions.DurableEnlistmentState; }
            static get $fullName() { return `System.Transactions.DurableEnlistmentEnded`; }
        });
        
        $asm.$cls("$stl.System.Transactions.VolatileEnlistmentAborting", ($self) => class VolatileEnlistmentAborting extends $.$stl.System.Transactions.VolatileEnlistmentState
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                enlistment.State = this;
                $.$spc.System.Threading.Monitor.Exit(enlistment.Transaction);
                try
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.EnlistmentStatus(1/*TraceSourceType.TraceSourceLtm*/, enlistment.EnlistmentTraceId, 2/*NotificationCall.Rollback*/);
                    }
                    $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.EnlistmentNotification !== null, "enlistment.EnlistmentNotification != null");
                    enlistment.EnlistmentNotification.System$Transactions$IEnlistmentNotification$Rollback(enlistment.SinglePhaseEnlistment);
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(enlistment.Transaction);
                    }
                }
            }
            /*void */ ChangeStatePreparing(/*InternalEnlistment*/ enlistment)
            {
            }
            /*void */ EnlistmentDone(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentEnded.EnterState(enlistment);
            }
            /*void */ InternalAborted(/*InternalEnlistment*/ enlistment)
            {
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 8758533;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":9479429,"m":[{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"EnterState","d":8758533,"h":4303725829,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"ChangeStatePreparing","d":8758533,"h":8598693125,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"EnlistmentDone","d":8758533,"h":12893660421,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"InternalAborted","d":8758533,"h":17188627717,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":8758533,"h":21483595013,"f":1}],"h":8758533}; }
            static get $b() { return $.$stl.System.Transactions.VolatileEnlistmentState; }
            static get $fullName() { return `System.Transactions.VolatileEnlistmentAborting`; }
        });
        
        $asm.$cls("$stl.System.Transactions.VolatileEnlistmentCommitting", ($self) => class VolatileEnlistmentCommitting extends $.$stl.System.Transactions.VolatileEnlistmentState
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                enlistment.State = this;
                $.$spc.System.Threading.Monitor.Exit(enlistment.Transaction);
                try
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.EnlistmentStatus(1/*TraceSourceType.TraceSourceLtm*/, enlistment.EnlistmentTraceId, 1/*NotificationCall.Commit*/);
                    }
                    $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.EnlistmentNotification !== null, "enlistment.EnlistmentNotification != null");
                    enlistment.EnlistmentNotification.System$Transactions$IEnlistmentNotification$Commit(enlistment.Enlistment);
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(enlistment.Transaction);
                    }
                }
            }
            /*void */ EnlistmentDone(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentEnded.EnterState(enlistment);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 8889605;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":9479429,"m":[{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"EnterState","d":8889605,"h":4303856901,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"EnlistmentDone","d":8889605,"h":8598824197,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":8889605,"h":12893791493,"f":1}],"h":8889605}; }
            static get $b() { return $.$stl.System.Transactions.VolatileEnlistmentState; }
            static get $fullName() { return `System.Transactions.VolatileEnlistmentCommitting`; }
        });
        
        $asm.$cls("$stl.System.Transactions.VolatileEnlistmentInDoubt", ($self) => class VolatileEnlistmentInDoubt extends $.$stl.System.Transactions.VolatileEnlistmentState
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                enlistment.State = this;
                $.$spc.System.Threading.Monitor.Exit(enlistment.Transaction);
                try
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.EnlistmentStatus(1/*TraceSourceType.TraceSourceLtm*/, enlistment.EnlistmentTraceId, 3/*NotificationCall.InDoubt*/);
                    }
                    $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.EnlistmentNotification !== null, "enlistment.EnlistmentNotification != null");
                    enlistment.EnlistmentNotification.System$Transactions$IEnlistmentNotification$InDoubt(enlistment.PreparingEnlistment);
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(enlistment.Transaction);
                    }
                }
            }
            /*void */ EnlistmentDone(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentEnded.EnterState(enlistment);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 9086213;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":9479429,"m":[{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"EnterState","d":9086213,"h":4304053509,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"EnlistmentDone","d":9086213,"h":8599020805,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":9086213,"h":12893988101,"f":1}],"h":9086213}; }
            static get $b() { return $.$stl.System.Transactions.VolatileEnlistmentState; }
            static get $fullName() { return `System.Transactions.VolatileEnlistmentInDoubt`; }
        });
        
        $asm.$cls("$stl.System.Transactions.VolatileEnlistmentEnded", ($self) => class VolatileEnlistmentEnded extends $.$stl.System.Transactions.VolatileEnlistmentState
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                enlistment.State = this;
            }
            /*void */ ChangeStatePreparing(/*InternalEnlistment*/ enlistment)
            {
            }
            /*void */ InternalAborted(/*InternalEnlistment*/ enlistment)
            {
            }
            /*void */ InternalCommitted(/*InternalEnlistment*/ enlistment)
            {
            }
            /*void */ InternalIndoubt(/*InternalEnlistment*/ enlistment)
            {
            }
            /*void */ InDoubt(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 9020677;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":9479429,"m":[{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"EnterState","d":9020677,"h":4303987973,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"ChangeStatePreparing","d":9020677,"h":8598955269,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"InternalAborted","d":9020677,"h":12893922565,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"InternalCommitted","d":9020677,"h":17188889861,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"InternalIndoubt","d":9020677,"h":21483857157,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2729221},{"n":"e","p":47251457}],"n":"InDoubt","d":9020677,"h":25778824453,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":9020677,"h":30073791749,"f":1}],"h":9020677}; }
            static get $b() { return $.$stl.System.Transactions.VolatileEnlistmentState; }
            static get $fullName() { return `System.Transactions.VolatileEnlistmentEnded`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateVolatilePhase1", ($self) => class TransactionStateVolatilePhase1 extends $.$stl.System.Transactions.ActiveStates
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                $.$spc.System.Diagnostics.Debug.Assert$1(tx._committableTransaction !== null, "tx._committableTransaction != null");
                tx._committableTransaction._complete = true;
                if (tx._phase1Volatiles._dependentClones !== 0)
                {
                    $.$stl.System.Transactions.TransactionState.TransactionStateAborted.EnterState(tx);
                    return;
                }
                if (tx._phase1Volatiles._volatileEnlistmentCount === 1 && tx._durableEnlistment === null && $.$spc.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, 0).SinglePhaseNotification !== null)
                {
                    $.$stl.System.Transactions.TransactionState.TransactionStateVolatileSPC.EnterState(tx);
                }
                else if (tx._phase1Volatiles._volatileEnlistmentCount > 0)
                {
                    for(/*int*/ let i = 0; i < tx._phase1Volatiles._volatileEnlistmentCount; i++)
                    {
                        $.$spc.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i)._twoPhaseState.ChangeStatePreparing($.$spc.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i));
                        if (!tx.State.ContinuePhase1Prepares())
                        {
                            break;
                        }
                    }
                }
                else 
                {
                    $.$stl.System.Transactions.TransactionState.TransactionStateSPC.EnterState(tx);
                }
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                this.ChangeStateTransactionAborted(tx, e);
            }
            /*void */ ChangeStateTransactionAborted(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                tx._innerException ??= e;
                $.$stl.System.Transactions.TransactionState.TransactionStateAborted.EnterState(tx);
            }
            /*void */ Phase1VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStateSPC.EnterState(tx);
            }
            /*bool */ ContinuePhase1Prepares()
            {
                return true;
            }
            /*void */ Timeout(/*InternalTransaction*/ tx)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionTimeout(tx.TransactionTraceId);
                }
                /*TimeoutException*/ let e = new $.$spc.System.TimeoutException().$ctor$10($.$stl.System.SR.TraceTransactionTimeout);
                this.Rollback(tx, e);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 8299781;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":238853,"m":[{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"EnterState","d":8299781,"h":4303267077,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"e","p":47251457}],"n":"Rollback","d":8299781,"h":8598234373,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"e","p":47251457}],"n":"ChangeStateTransactionAborted","d":8299781,"h":12893201669,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"Phase1VolatilePrepareDone","d":8299781,"h":17188168965,"f":32776},{"r":262145,"n":"ContinuePhase1Prepares","d":8299781,"h":21483136261,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"Timeout","d":8299781,"h":25778103557,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":8299781,"h":30073070853,"f":1}],"h":8299781}; }
            static get $b() { return $.$stl.System.Transactions.ActiveStates; }
            static get $fullName() { return `System.Transactions.TransactionStateVolatilePhase1`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateVolatileSPC", ($self) => class TransactionStateVolatileSPC extends $.$stl.System.Transactions.ActiveStates
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                $.$spc.System.Diagnostics.Debug.Assert$1(tx._phase1Volatiles._volatileEnlistmentCount === 1, "There must be exactly 1 phase 1 volatile enlistment for TransactionStateVolatileSPC");
                $.$spc.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, 0)._twoPhaseState.ChangeStateSinglePhaseCommit($.$spc.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, 0));
            }
            /*void */ ChangeStateTransactionCommitted(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStateCommitted.EnterState(tx);
            }
            /*void */ InDoubtFromEnlistment(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStateInDoubt.EnterState(tx);
            }
            /*void */ ChangeStateTransactionAborted(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                tx._innerException ??= e;
                $.$stl.System.Transactions.TransactionState.TransactionStateAborted.EnterState(tx);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 8365317;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":238853,"m":[{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"EnterState","d":8365317,"h":4303332613,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"ChangeStateTransactionCommitted","d":8365317,"h":8598299909,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"InDoubtFromEnlistment","d":8365317,"h":12893267205,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"e","p":47251457}],"n":"ChangeStateTransactionAborted","d":8365317,"h":17188234501,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":8365317,"h":21483201797,"f":1}],"h":8365317}; }
            static get $b() { return $.$stl.System.Transactions.ActiveStates; }
            static get $fullName() { return `System.Transactions.TransactionStateVolatileSPC`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateSPC", ($self) => class TransactionStateSPC extends $.$stl.System.Transactions.ActiveStates
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                if (tx._durableEnlistment !== null)
                {
                    tx._durableEnlistment.State.ChangeStateCommitting(tx._durableEnlistment);
                }
                else 
                {
                    $.$stl.System.Transactions.TransactionState.TransactionStateCommitted.EnterState(tx);
                }
            }
            /*void */ ChangeStateTransactionCommitted(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStateCommitted.EnterState(tx);
            }
            /*void */ InDoubtFromEnlistment(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStateInDoubt.EnterState(tx);
            }
            /*void */ ChangeStateTransactionAborted(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                tx._innerException ??= e;
                $.$stl.System.Transactions.TransactionState.TransactionStateAborted.EnterState(tx);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 8168709;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":238853,"m":[{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"EnterState","d":8168709,"h":4303136005,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"ChangeStateTransactionCommitted","d":8168709,"h":8598103301,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"InDoubtFromEnlistment","d":8168709,"h":12893070597,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"e","p":47251457}],"n":"ChangeStateTransactionAborted","d":8168709,"h":17188037893,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":8168709,"h":21483005189,"f":1}],"h":8168709}; }
            static get $b() { return $.$stl.System.Transactions.ActiveStates; }
            static get $fullName() { return `System.Transactions.TransactionStateSPC`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateAborted", ($self) => class TransactionStateAborted extends $.$stl.System.Transactions.TransactionStateEnded
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                super.EnterState(tx);
                this.CommonEnterState(tx);
                for(/*int*/ let i = 0; i < tx._phase0Volatiles._volatileEnlistmentCount; i++)
                {
                    $.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i)._twoPhaseState.InternalAborted($.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i));
                }
                for(/*int*/ let i = 0; i < tx._phase1Volatiles._volatileEnlistmentCount; i++)
                {
                    $.$spc.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i)._twoPhaseState.InternalAborted($.$spc.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i));
                }
                tx._durableEnlistment?.State.InternalAborted(tx._durableEnlistment);
                $.$stl.System.Transactions.TransactionTable.Remove(tx);
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionTimeout(tx.TransactionTraceId);
                }
                tx.FireCompletion();
                if (tx._asyncCommit)
                {
                    tx.SignalAsyncCompletion();
                }
            }
            /*TransactionStatus */ get_Status(/*InternalTransaction*/ tx)
            {
                return 2/*TransactionStatus.Aborted*/;
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
            }
            /*void */ BeginCommit(/*InternalTransaction*/ tx, /*bool*/ asyncCommit, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw $.$stl.System.Transactions.TransactionStateAborted.CreateTransactionAbortedException(tx);
            }
            /*void */ EndCommit(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionStateAborted.CreateTransactionAbortedException(tx);
            }
            /*void */ RestartCommitIfNeeded(/*InternalTransaction*/ tx)
            {
            }
            /*void */ Timeout(/*InternalTransaction*/ tx)
            {
            }
            /*void */ Phase0VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ Phase1VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ ChangeStateTransactionAborted(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
            }
            /*void */ ChangeStatePromotedAborted(/*InternalTransaction*/ tx)
            {
            }
            /*void */ ChangeStateAbortedDuringPromotion(/*InternalTransaction*/ tx)
            {
            }
            /*void */ CreateBlockingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionStateAborted.CreateTransactionAbortedException(tx);
            }
            /*void */ CreateAbortingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionStateAborted.CreateTransactionAbortedException(tx);
            }
            /*void */ GetObjectData(/*InternalTransaction*/ tx, /*SerializationInfo*/ serializationInfo, /*StreamingContext*/ context)
            {
                throw $.$stl.System.Transactions.TransactionStateAborted.CreateTransactionAbortedException(tx);
            }
            /*void */ CheckForFinishedTransaction(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionStateAborted.CreateTransactionAbortedException(tx);
            }
            static /*TransactionAbortedException */ CreateTransactionAbortedException(/*InternalTransaction*/ tx)
            {
                return $.$stl.System.Transactions.TransactionAbortedException.Create$3($.$stl.System.SR.TransactionAborted, tx._innerException, tx.DistributedTxId);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 5809413;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6464773,"m":[{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"EnterState","d":5809413,"h":4300776709,"f":32776},{"r":8430853,"p":[{"n":"tx","p":2794757}],"n":"get_Status","d":5809413,"h":8595744005,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"e","p":47251457}],"n":"Rollback","d":5809413,"h":12890711301,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"asyncCommit","p":262145},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":5809413,"h":17185678597,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"EndCommit","d":5809413,"h":21480645893,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"RestartCommitIfNeeded","d":5809413,"h":25775613189,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"Timeout","d":5809413,"h":30070580485,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"Phase0VolatilePrepareDone","d":5809413,"h":34365547781,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"Phase1VolatilePrepareDone","d":5809413,"h":38660515077,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"e","p":47251457}],"n":"ChangeStateTransactionAborted","d":5809413,"h":42955482373,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"ChangeStatePromotedAborted","d":5809413,"h":47250449669,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"ChangeStateAbortedDuringPromotion","d":5809413,"h":51545416965,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"CreateBlockingClone","d":5809413,"h":55840384261,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"CreateAbortingClone","d":5809413,"h":60135351557,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"serializationInfo","p":113967105},{"n":"context","p":114098177}],"n":"GetObjectData","d":5809413,"h":64430318853,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"CheckForFinishedTransaction","d":5809413,"h":68725286149,"f":32776},{"r":4367621,"p":[{"n":"tx","p":2794757}],"n":"CreateTransactionAbortedException","d":5809413,"h":73020253445,"f":34}],"c":[{"n":".ctor","o":"$ctor$3","d":5809413,"h":77315220741,"f":1}],"h":5809413}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStateEnded; }
            static get $fullName() { return `System.Transactions.TransactionStateAborted`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateCommitted", ($self) => class TransactionStateCommitted extends $.$stl.System.Transactions.TransactionStateEnded
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                super.EnterState(tx);
                this.CommonEnterState(tx);
                for(/*int*/ let i = 0; i < tx._phase0Volatiles._volatileEnlistmentCount; i++)
                {
                    $.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i)._twoPhaseState.InternalCommitted($.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i));
                }
                for(/*int*/ let i = 0; i < tx._phase1Volatiles._volatileEnlistmentCount; i++)
                {
                    $.$spc.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i)._twoPhaseState.InternalCommitted($.$spc.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i));
                }
                $.$stl.System.Transactions.TransactionTable.Remove(tx);
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionCommitted(1/*TraceSourceType.TraceSourceLtm*/, tx.TransactionTraceId);
                }
                tx.FireCompletion();
                if (tx._asyncCommit)
                {
                    tx.SignalAsyncCompletion();
                }
            }
            /*TransactionStatus */ get_Status(/*InternalTransaction*/ tx)
            {
                return 1/*TransactionStatus.Committed*/;
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ EndCommit(/*InternalTransaction*/ tx)
            {
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 5940485;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6464773,"m":[{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"EnterState","d":5940485,"h":4300907781,"f":32776},{"r":8430853,"p":[{"n":"tx","p":2794757}],"n":"get_Status","d":5940485,"h":8595875077,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"e","p":47251457}],"n":"Rollback","d":5940485,"h":12890842373,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"EndCommit","d":5940485,"h":17185809669,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":5940485,"h":21480776965,"f":1}],"h":5940485}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStateEnded; }
            static get $fullName() { return `System.Transactions.TransactionStateCommitted`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateInDoubt", ($self) => class TransactionStateInDoubt extends $.$stl.System.Transactions.TransactionStateEnded
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                super.EnterState(tx);
                this.CommonEnterState(tx);
                for(/*int*/ let i = 0; i < tx._phase0Volatiles._volatileEnlistmentCount; i++)
                {
                    $.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i)._twoPhaseState.InternalIndoubt($.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i));
                }
                for(/*int*/ let i = 0; i < tx._phase1Volatiles._volatileEnlistmentCount; i++)
                {
                    $.$spc.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i)._twoPhaseState.InternalIndoubt($.$spc.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i));
                }
                $.$stl.System.Transactions.TransactionTable.Remove(tx);
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionInDoubt(1/*TraceSourceType.TraceSourceLtm*/, tx.TransactionTraceId);
                }
                tx.FireCompletion();
                if (tx._asyncCommit)
                {
                    tx.SignalAsyncCompletion();
                }
            }
            /*TransactionStatus */ get_Status(/*InternalTransaction*/ tx)
            {
                return 3/*TransactionStatus.InDoubt*/;
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ EndCommit(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionInDoubtException.Create$3(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionIndoubt, tx._innerException, tx.DistributedTxId);
            }
            /*void */ CheckForFinishedTransaction(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionInDoubtException.Create$3(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionIndoubt, tx._innerException, tx.DistributedTxId);
            }
            /*void */ GetObjectData(/*InternalTransaction*/ tx, /*SerializationInfo*/ serializationInfo, /*StreamingContext*/ context)
            {
                throw $.$stl.System.Transactions.TransactionInDoubtException.Create$3(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionIndoubt, tx._innerException, tx.DistributedTxId);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 6530309;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6464773,"m":[{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"EnterState","d":6530309,"h":4301497605,"f":32776},{"r":8430853,"p":[{"n":"tx","p":2794757}],"n":"get_Status","d":6530309,"h":8596464901,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"e","p":47251457}],"n":"Rollback","d":6530309,"h":12891432197,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"EndCommit","d":6530309,"h":17186399493,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"CheckForFinishedTransaction","d":6530309,"h":21481366789,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"serializationInfo","p":113967105},{"n":"context","p":114098177}],"n":"GetObjectData","d":6530309,"h":25776334085,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":6530309,"h":30071301381,"f":1}],"h":6530309}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStateEnded; }
            static get $fullName() { return `System.Transactions.TransactionStateInDoubt`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateNonCommittablePromoted", ($self) => class TransactionStateNonCommittablePromoted extends $.$stl.System.Transactions.TransactionStatePromotedBase
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                $.$spc.System.Diagnostics.Debug.Assert$1(tx.PromotedTransaction !== null && tx.PromotedTransaction.RealTransaction !== null, "tx.PromotedTransaction != null && tx.PromotedTransaction.RealTransaction != null");
                tx.PromotedTransaction.RealTransaction.InternalTransaction = tx;
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 6595845;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6923525,"m":[{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"EnterState","d":6595845,"h":4301563141,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":6595845,"h":8596530437,"f":1}],"h":6595845}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedBase; }
            static get $fullName() { return `System.Transactions.TransactionStateNonCommittablePromoted`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromoted", ($self) => class TransactionStatePromoted extends $.$stl.System.Transactions.TransactionStatePromotedBase
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(($.$spc.System.Guid.op_Equality(tx._promoterType, $.$spc.System.Guid.Empty)) || ($.$spc.System.Guid.op_Equality(tx._promoterType, $.$stl.System.Transactions.TransactionInterop.PromoterTypeDtc)), "Promoted to MSTC but PromoterType is not TransactionInterop.PromoterTypeDtc");
                tx.SetPromoterTypeToMSDTC();
                if (tx._outcomeSource._isoLevel === 4/*IsolationLevel.Snapshot*/)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.CannotPromoteSnapshot, null);
                }
                this.CommonEnterState(tx);
                /*OletxCommittableTransaction?*/ let distributedTx = null;
                try
                {
                    /*TimeSpan*/ let newTimeout;
                    if (tx.AbsoluteTimeout === 9223372036854775807n)
                    {
                        newTimeout = $.$spc.System.TimeSpan.Zero;
                    }
                    else 
                    {
                        newTimeout = $.$stl.System.Transactions.TransactionManager.TransactionTable.RecalcTimeout(tx);
                        if ($.$spc.System.TimeSpan.op_LessThanOrEqual(newTimeout, $.$spc.System.TimeSpan.Zero))
                        {
                            return;
                        }
                    }
                    /*TransactionOptions*/ let options = new $.$stl.System.Transactions.TransactionOptions();
                    options.IsolationLevel = tx._outcomeSource._isoLevel;
                    options.Timeout = newTimeout;
                    distributedTx = $.$stl.System.Transactions.TransactionManager.DistributedTransactionManager.CreateTransaction(options.Clone());
                    distributedTx.SavedLtmPromotedTransaction = tx._outcomeSource;
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.TransactionPromoted(tx.TransactionTraceId, distributedTx.TransactionTraceId);
                    }
                }
                catch(te)
                {
                    tx._innerException = te;
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.ExceptionConsumed$1(te);
                    }
                    return;
                }
                finally
                {
                    {
                        if (distributedTx === null)
                        {
                            tx.State.ChangeStateAbortedDuringPromotion(tx);
                        }
                    }
                }
                tx.PromotedTransaction = distributedTx;
                /*Hashtable*/ let promotedTransactionTable = $.$stl.System.Transactions.TransactionManager.PromotedTransactionTable;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(promotedTransactionTable)
                    {
                        tx._finalizedObject = new $.$stl.System.Transactions.FinalizedObject().$ctor$1(tx, distributedTx.Identifier);
                        /*WeakReference*/ let weakRef = new $.$spc.System.WeakReference().$ctor$2(tx._outcomeSource, false);
                        promotedTransactionTable.set_Item(distributedTx.Identifier, weakRef);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(promotedTransactionTable)
                }
                $.$stl.System.Transactions.TransactionManager.FireDistributedTransactionStarted(tx._outcomeSource);
                this.PromoteEnlistmentsAndOutcome(tx);
            }
            static /*bool */ PromotePhaseVolatiles(/*InternalTransaction*/ tx, /*ref VolatileEnlistmentSet*/ volatiles, /*bool*/ phase0)
            {
                if (((volatiles.$v._volatileEnlistmentCount + volatiles.$v._dependentClones) | 0) > 0)
                {
                    if (phase0)
                    {
                        volatiles.$v.VolatileDemux = new $.$stl.System.Transactions.Phase0VolatileDemultiplexer().$ctor$2(tx);
                    }
                    else 
                    {
                        volatiles.$v.VolatileDemux = new $.$stl.System.Transactions.Phase1VolatileDemultiplexer().$ctor$2(tx);
                    }
                    $.$spc.System.Diagnostics.Debug.Assert$1(tx.PromotedTransaction !== null, "tx.PromotedTransaction != null");
                    volatiles.$v.VolatileDemux._promotedEnlistment = tx.PromotedTransaction.EnlistVolatile$1(volatiles.$v.VolatileDemux, phase0 ? 1/*EnlistmentOptions.EnlistDuringPrepareRequired*/ : 0/*EnlistmentOptions.None*/);
                }
                return true;
            }
            /*bool */ PromoteDurable(/*InternalTransaction*/ tx)
            {
                if (tx._durableEnlistment !== null)
                {
                    /*InternalEnlistment*/ let enlistment = tx._durableEnlistment;
                    $.$spc.System.Diagnostics.Debug.Assert$1(tx.PromotedTransaction !== null, "tx.PromotedTransaction != null");
                    /*IPromotedEnlistment*/ let promotedEnlistment = tx.PromotedTransaction.EnlistDurable(enlistment.ResourceManagerIdentifier, $.$cast(enlistment, $.$stl.System.Transactions.DurableInternalEnlistment), enlistment.SinglePhaseNotification !== null, 0/*EnlistmentOptions.None*/);
                    tx._durableEnlistment.State.ChangeStatePromoted(tx._durableEnlistment, promotedEnlistment);
                }
                return true;
            }
            /*void */ PromoteEnlistmentsAndOutcome(/*InternalTransaction*/ tx)
            {
                /*bool*/ let enlistmentsPromoted = false;
                $.$spc.System.Diagnostics.Debug.Assert$1(tx.PromotedTransaction !== null && tx.PromotedTransaction.RealTransaction !== null, "tx.PromotedTransaction != null && tx.PromotedTransaction.RealTransaction != null");
                tx.PromotedTransaction.RealTransaction.InternalTransaction = tx;
                $.$spc.System.Diagnostics.Debug.Assert$1(tx.State !== null, "tx.State != null");
                try
                {
                    enlistmentsPromoted = $.$stl.System.Transactions.TransactionStatePromoted.PromotePhaseVolatiles(tx, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase0Volatiles, ($v) => tx._phase0Volatiles = $v, null), true);
                }
                catch(te)
                {
                    tx._innerException = te;
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.ExceptionConsumed$1(te);
                    }
                    return;
                }
                finally
                {
                    {
                        if (!enlistmentsPromoted)
                        {
                            tx.PromotedTransaction.Rollback();
                            tx.State.ChangeStateAbortedDuringPromotion(tx);
                        }
                    }
                }
                enlistmentsPromoted = false;
                try
                {
                    enlistmentsPromoted = $.$stl.System.Transactions.TransactionStatePromoted.PromotePhaseVolatiles(tx, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase1Volatiles, ($v) => tx._phase1Volatiles = $v, null), false);
                }
                catch(te)
                {
                    tx._innerException = te;
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.ExceptionConsumed$1(te);
                    }
                    return;
                }
                finally
                {
                    {
                        if (!enlistmentsPromoted)
                        {
                            tx.PromotedTransaction.Rollback();
                            tx.State.ChangeStateAbortedDuringPromotion(tx);
                        }
                    }
                }
                enlistmentsPromoted = false;
                try
                {
                    enlistmentsPromoted = this.PromoteDurable(tx);
                }
                catch(te)
                {
                    tx._innerException = te;
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.ExceptionConsumed$1(te);
                    }
                    return;
                }
                finally
                {
                    {
                        if (!enlistmentsPromoted)
                        {
                            tx.PromotedTransaction.Rollback();
                            tx.State.ChangeStateAbortedDuringPromotion(tx);
                        }
                    }
                }
            }
            /*void */ DisposeRoot(/*InternalTransaction*/ tx)
            {
                tx.State.Rollback(tx, null);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 6726917;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6923525,"m":[{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"EnterState","d":6726917,"h":4301694213,"f":32776},{"r":262145,"p":[{"n":"tx","p":2794757},{"n":"volatiles","p":9348357,"f":4},{"n":"phase0","p":262145}],"n":"PromotePhaseVolatiles","d":6726917,"h":8596661509,"f":36},{"r":262145,"p":[{"n":"tx","p":2794757}],"n":"PromoteDurable","d":6726917,"h":12891628805,"f":136},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"PromoteEnlistmentsAndOutcome","d":6726917,"h":17186596101,"f":136},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"DisposeRoot","d":6726917,"h":21481563397,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":6726917,"h":25776530693,"f":1}],"h":6726917}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedBase; }
            static get $fullName() { return `System.Transactions.TransactionStatePromoted`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedP0Wave", ($self) => class TransactionStatePromotedP0Wave extends $.$stl.System.Transactions.TransactionStatePromotedBase
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
            }
            /*void */ BeginCommit(/*InternalTransaction*/ tx, /*bool*/ asyncCommit, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ Phase0VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
                try
                {
                    $.$stl.System.Transactions.TransactionState.TransactionStatePromotedCommitting.EnterState(tx);
                }
                catch(e)
                {
                    tx._innerException ??= e;
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.ExceptionConsumed$1(e);
                    }
                }
            }
            /*bool */ ContinuePhase0Prepares()
            {
                return true;
            }
            /*void */ ChangeStateTransactionAborted(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                tx._innerException ??= e;
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedP0Aborting.EnterState(tx);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 7841029;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6923525,"m":[{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"EnterState","d":7841029,"h":4302808325,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"asyncCommit","p":262145},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":7841029,"h":8597775621,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"Phase0VolatilePrepareDone","d":7841029,"h":12892742917,"f":32776},{"r":262145,"n":"ContinuePhase0Prepares","d":7841029,"h":17187710213,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"e","p":47251457}],"n":"ChangeStateTransactionAborted","d":7841029,"h":21482677509,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":7841029,"h":25777644805,"f":1}],"h":7841029}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedBase; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedP0Wave`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedCommitting", ($self) => class TransactionStatePromotedCommitting extends $.$stl.System.Transactions.TransactionStatePromotedBase
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                /*OletxCommittableTransaction*/ let ctx = $.$cast(tx.PromotedTransaction, $.$stl.System.Transactions.Oletx.OletxCommittableTransaction);
                ctx.BeginCommit(tx);
            }
            /*void */ BeginCommit(/*InternalTransaction*/ tx, /*bool*/ asyncCommit, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ ChangeStatePromotedPhase0(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedPhase0.EnterState(tx);
            }
            /*void */ ChangeStatePromotedPhase1(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedPhase1.EnterState(tx);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 7054597;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6923525,"m":[{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"EnterState","d":7054597,"h":4302021893,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"asyncCommit","p":262145},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":7054597,"h":8596989189,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"ChangeStatePromotedPhase0","d":7054597,"h":12891956485,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"ChangeStatePromotedPhase1","d":7054597,"h":17186923781,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":7054597,"h":21481891077,"f":1}],"h":7054597}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedBase; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedCommitting`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedNonMSDTCPhase0", ($self) => class TransactionStatePromotedNonMSDTCPhase0 extends $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCBase
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                /*int*/ let volatileCount = tx._phase0Volatiles._volatileEnlistmentCount;
                /*int*/ let dependentCount = tx._phase0Volatiles._dependentClones;
                tx._phase0VolatileWaveCount = volatileCount;
                if (tx._phase0Volatiles._preparedVolatileEnlistments < ((volatileCount + dependentCount) | 0))
                {
                    for(/*int*/ let i = 0; i < volatileCount; i++)
                    {
                        $.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i)._twoPhaseState.ChangeStatePreparing($.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i));
                        if (!tx.State.ContinuePhase0Prepares())
                        {
                            break;
                        }
                    }
                }
                else 
                {
                    $.$stl.System.Transactions.TransactionState.TransactionStatePromotedNonMSDTCVolatilePhase1.EnterState(tx);
                }
            }
            /*void */ BeginCommit(/*InternalTransaction*/ tx, /*bool*/ asyncCommit, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                this.ChangeStateTransactionAborted(tx, e);
            }
            /*void */ Phase0VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
                /*int*/ let volatileCount = tx._phase0Volatiles._volatileEnlistmentCount;
                /*int*/ let dependentCount = tx._phase0Volatiles._dependentClones;
                tx._phase0VolatileWaveCount = volatileCount;
                if (tx._phase0Volatiles._preparedVolatileEnlistments < ((volatileCount + dependentCount) | 0))
                {
                    for(/*int*/ let i = 0; i < volatileCount; i++)
                    {
                        $.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i)._twoPhaseState.ChangeStatePreparing($.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i));
                        if (!tx.State.ContinuePhase0Prepares())
                        {
                            break;
                        }
                    }
                }
                else 
                {
                    $.$stl.System.Transactions.TransactionState.TransactionStatePromotedNonMSDTCVolatilePhase1.EnterState(tx);
                }
            }
            /*void */ Phase1VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            /*bool */ ContinuePhase0Prepares()
            {
                return true;
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 7578885;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7316741,"m":[{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"EnterState","d":7578885,"h":4302546181,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"asyncCommit","p":262145},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":7578885,"h":8597513477,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"e","p":47251457}],"n":"Rollback","d":7578885,"h":12892480773,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"Phase0VolatilePrepareDone","d":7578885,"h":17187448069,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"Phase1VolatilePrepareDone","d":7578885,"h":21482415365,"f":32776},{"r":262145,"n":"ContinuePhase0Prepares","d":7578885,"h":25777382661,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":7578885,"h":30072349957,"f":1}],"h":7578885}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCBase; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedNonMSDTCPhase0`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedNonMSDTCVolatilePhase1", ($self) => class TransactionStatePromotedNonMSDTCVolatilePhase1 extends $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCBase
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                $.$spc.System.Diagnostics.Debug.Assert$1(tx._committableTransaction !== null, "tx._committableTransaction != null");
                tx._committableTransaction._complete = true;
                if (tx._phase1Volatiles._dependentClones !== 0)
                {
                    this.ChangeStateTransactionAborted(tx, null);
                    return;
                }
                if (tx._phase1Volatiles._volatileEnlistmentCount > 0)
                {
                    for(/*int*/ let i = 0; i < tx._phase1Volatiles._volatileEnlistmentCount; i++)
                    {
                        $.$spc.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i)._twoPhaseState.ChangeStatePreparing($.$spc.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i));
                        if (!tx.State.ContinuePhase1Prepares())
                        {
                            break;
                        }
                    }
                }
                else 
                {
                    $.$stl.System.Transactions.TransactionState.TransactionStatePromotedNonMSDTCSinglePhaseCommit.EnterState(tx);
                }
            }
            /*void */ BeginCommit(/*InternalTransaction*/ tx, /*bool*/ asyncCommit, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                this.ChangeStateTransactionAborted(tx, e);
            }
            /*void */ Phase1VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedNonMSDTCSinglePhaseCommit.EnterState(tx);
            }
            /*bool */ ContinuePhase1Prepares()
            {
                return true;
            }
            /*Enlistment */ EnlistVolatile(/*InternalTransaction*/ tx, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                throw $.$stl.System.Transactions.TransactionException.Create$1($.$stl.System.SR.TooLate, tx === null ? $.$spc.System.Guid.Empty : tx.DistributedTxId);
            }
            /*Enlistment */ EnlistVolatile$1(/*InternalTransaction*/ tx, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                throw $.$stl.System.Transactions.TransactionException.Create$1($.$stl.System.SR.TooLate, tx === null ? $.$spc.System.Guid.Empty : tx.DistributedTxId);
            }
            /*bool */ EnlistPromotableSinglePhase(/*InternalTransaction*/ tx, /*IPromotableSinglePhaseNotification*/ promotableSinglePhaseNotification, /*Transaction*/ atomicTransaction, /*Guid*/ promoterType)
            {
                throw $.$stl.System.Transactions.TransactionException.Create$1($.$stl.System.SR.TooLate, tx === null ? $.$spc.System.Guid.Empty : tx.DistributedTxId);
            }
            /*void */ CreateBlockingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.Create$1($.$stl.System.SR.TooLate, tx === null ? $.$spc.System.Guid.Empty : tx.DistributedTxId);
            }
            /*void */ CreateAbortingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.Create$1($.$stl.System.SR.TooLate, tx === null ? $.$spc.System.Guid.Empty : tx.DistributedTxId);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 7709957;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7316741,"m":[{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"EnterState","d":7709957,"h":4302677253,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"asyncCommit","p":262145},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":7709957,"h":8597644549,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"e","p":47251457}],"n":"Rollback","d":7709957,"h":12892611845,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"Phase1VolatilePrepareDone","d":7709957,"h":17187579141,"f":32776},{"r":262145,"n":"ContinuePhase1Prepares","d":7709957,"h":21482546437,"f":32776},{"r":1746181,"p":[{"n":"tx","p":2794757},{"n":"enlistmentNotification","p":2598149},{"n":"enlistmentOptions","p":1877253},{"n":"atomicTransaction","p":4302085}],"n":"EnlistVolatile","d":7709957,"h":25777513733,"f":32776},{"r":1746181,"p":[{"n":"tx","p":2794757},{"n":"enlistmentNotification","p":3056901},{"n":"enlistmentOptions","p":1877253},{"n":"atomicTransaction","p":4302085}],"n":"EnlistVolatile","o":"@$1","d":7709957,"h":30072481029,"f":32776},{"r":262145,"p":[{"n":"tx","p":2794757},{"n":"promotableSinglePhaseNotification","p":2860293},{"n":"atomicTransaction","p":4302085},{"n":"promoterType","p":56229889}],"n":"EnlistPromotableSinglePhase","d":7709957,"h":34367448325,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"CreateBlockingClone","d":7709957,"h":38662415621,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"CreateAbortingClone","d":7709957,"h":42957382917,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":7709957,"h":47252350213,"f":1}],"h":7709957}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCBase; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedNonMSDTCVolatilePhase1`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedNonMSDTCSinglePhaseCommit", ($self) => class TransactionStatePromotedNonMSDTCSinglePhaseCommit extends $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCBase
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                $.$spc.System.Diagnostics.Debug.Assert$1(tx._durableEnlistment !== null, "tx._durableEnlistment != null");
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.EnlistmentStatus(1/*TraceSourceType.TraceSourceLtm*/, tx._durableEnlistment.EnlistmentTraceId, 4/*NotificationCall.SinglePhaseCommit*/);
                }
                $.$stl.System.Transactions.TransactionTable.Remove(tx);
                tx._durableEnlistment.State.ChangeStateCommitting(tx._durableEnlistment);
            }
            /*void */ BeginCommit(/*InternalTransaction*/ tx, /*bool*/ asyncCommit, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ ChangeStateTransactionCommitted(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedNonMSDTCCommitted.EnterState(tx);
            }
            /*void */ InDoubtFromEnlistment(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedNonMSDTCIndoubt.EnterState(tx);
            }
            /*void */ ChangeStateTransactionAborted(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                tx._innerException ??= e;
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedNonMSDTCAborted.EnterState(tx);
            }
            /*void */ ChangeStateAbortedDuringPromotion(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStateAborted.EnterState(tx);
            }
            /*Enlistment */ EnlistVolatile(/*InternalTransaction*/ tx, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                throw $.$stl.System.Transactions.TransactionException.Create$1($.$stl.System.SR.TooLate, tx === null ? $.$spc.System.Guid.Empty : tx.DistributedTxId);
            }
            /*Enlistment */ EnlistVolatile$1(/*InternalTransaction*/ tx, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                throw $.$stl.System.Transactions.TransactionException.Create$1($.$stl.System.SR.TooLate, tx === null ? $.$spc.System.Guid.Empty : tx.DistributedTxId);
            }
            /*bool */ EnlistPromotableSinglePhase(/*InternalTransaction*/ tx, /*IPromotableSinglePhaseNotification*/ promotableSinglePhaseNotification, /*Transaction*/ atomicTransaction, /*Guid*/ promoterType)
            {
                throw $.$stl.System.Transactions.TransactionException.Create$1($.$stl.System.SR.TooLate, tx === null ? $.$spc.System.Guid.Empty : tx.DistributedTxId);
            }
            /*void */ CreateBlockingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.Create$1($.$stl.System.SR.TooLate, tx === null ? $.$spc.System.Guid.Empty : tx.DistributedTxId);
            }
            /*void */ CreateAbortingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.Create$1($.$stl.System.SR.TooLate, tx === null ? $.$spc.System.Guid.Empty : tx.DistributedTxId);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 7644421;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7316741,"m":[{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"EnterState","d":7644421,"h":4302611717,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"asyncCommit","p":262145},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":7644421,"h":8597579013,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"e","p":47251457}],"n":"Rollback","d":7644421,"h":12892546309,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"ChangeStateTransactionCommitted","d":7644421,"h":17187513605,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"InDoubtFromEnlistment","d":7644421,"h":21482480901,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"e","p":47251457}],"n":"ChangeStateTransactionAborted","d":7644421,"h":25777448197,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"ChangeStateAbortedDuringPromotion","d":7644421,"h":30072415493,"f":32776},{"r":1746181,"p":[{"n":"tx","p":2794757},{"n":"enlistmentNotification","p":2598149},{"n":"enlistmentOptions","p":1877253},{"n":"atomicTransaction","p":4302085}],"n":"EnlistVolatile","d":7644421,"h":34367382789,"f":32776},{"r":1746181,"p":[{"n":"tx","p":2794757},{"n":"enlistmentNotification","p":3056901},{"n":"enlistmentOptions","p":1877253},{"n":"atomicTransaction","p":4302085}],"n":"EnlistVolatile","o":"@$1","d":7644421,"h":38662350085,"f":32776},{"r":262145,"p":[{"n":"tx","p":2794757},{"n":"promotableSinglePhaseNotification","p":2860293},{"n":"atomicTransaction","p":4302085},{"n":"promoterType","p":56229889}],"n":"EnlistPromotableSinglePhase","d":7644421,"h":42957317381,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"CreateBlockingClone","d":7644421,"h":47252284677,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"CreateAbortingClone","d":7644421,"h":51547251973,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":7644421,"h":55842219269,"f":1}],"h":7644421}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCBase; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedNonMSDTCSinglePhaseCommit`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateDelegatedNonMSDTC", ($self) => class TransactionStateDelegatedNonMSDTC extends $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCBase
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                /*OletxTransaction?*/ let distributedTx;
                try
                {
                    if (tx._durableEnlistment !== null)
                    {
                        /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                        if (etwLog.IsEnabled())
                        {
                            etwLog.EnlistmentStatus(1/*TraceSourceType.TraceSourceLtm*/, tx._durableEnlistment.EnlistmentTraceId, 5/*NotificationCall.Promote*/);
                        }
                    }
                    distributedTx = $.$stl.System.Transactions.TransactionState.TransactionStatePSPEOperation.PSPEPromote(tx);
                    $.$spc.System.Diagnostics.Debug.Assert$1((distributedTx === null), "PSPEPromote for non-MSDTC promotion returned a distributed transaction.");
                    $.$spc.System.Diagnostics.Debug.Assert$1((tx.promotedToken !== null), "PSPEPromote for non-MSDTC promotion did not set InternalTransaction.PromotedToken.");
                }
                catch(e)
                {
                    tx._innerException = e;
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.ExceptionConsumed$1(e);
                    }
                }
                finally
                {
                    {
                        if (tx.promotedToken === null)
                        {
                            tx.State.ChangeStateAbortedDuringPromotion(tx);
                        }
                    }
                }
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 6268165;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7316741,"m":[{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"EnterState","d":6268165,"h":4301235461,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":6268165,"h":8596202757,"f":1}],"h":6268165}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCBase; }
            static get $fullName() { return `System.Transactions.TransactionStateDelegatedNonMSDTC`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionCompletedEventHandler", ($self) => class TransactionCompletedEventHandler extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*void*/ Invoke(/*$.$spc.System.Nullable$$*/ sender, /**/ e)
            {
                return this.$nativeFunction.call(this.$target, sender, e);
            }
            static $h = 4433157;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":4498693}],"n":"Invoke","d":4433157,"h":8594367749,"f":129},{"r":57016321,"p":[{"n":"sender","p":131073},{"n":"e","p":4498693},{"n":"callback","p":14483457},{"n":"object","p":131073}],"n":"BeginInvoke","d":4433157,"h":12889335045,"f":129},{"r":65537,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":4433157,"h":17184302341,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":4433157,"h":4299400453,"f":1}],"i":[57212929,113377281],"h":4433157}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Transactions.TransactionCompletedEventHandler`; }
        });
        
        $asm.$cls("$stl.System.Transactions.FinishVolatileDelegate", ($self) => class FinishVolatileDelegate extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*void*/ Invoke(/**/ enlistment)
            {
                return this.$nativeFunction.call(this.$target, enlistment);
            }
            static $h = 2401541;
            static $f = 0b10000000;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"Invoke","d":2401541,"h":8592336133,"f":129},{"r":57016321,"p":[{"n":"enlistment","p":2729221},{"n":"callback","p":14483457},{"n":"object","p":131073}],"n":"BeginInvoke","d":2401541,"h":12887303429,"f":129},{"r":65537,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":2401541,"h":17182270725,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":2401541,"h":4297368837,"f":1}],"i":[57212929,113377281],"h":2401541}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Transactions.FinishVolatileDelegate`; }
        });
        
        $asm.$cls("$stl.System.Transactions.HostCurrentTransactionCallback", ($self) => class HostCurrentTransactionCallback extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*Transaction?*/ Invoke()
            {
                return this.$nativeFunction.call(this.$target, );
            }
            static $h = 2467077;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":4302085,"n":"Invoke","d":2467077,"h":8592401669,"f":129},{"r":57016321,"p":[{"n":"callback","p":14483457},{"n":"object","p":131073}],"n":"BeginInvoke","d":2467077,"h":12887368965,"f":129},{"r":4302085,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":2467077,"h":17182336261,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":2467077,"h":4297434373,"f":1}],"i":[57212929,113377281],"h":2467077}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Transactions.HostCurrentTransactionCallback`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStartedEventHandler", ($self) => class TransactionStartedEventHandler extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*void*/ Invoke(/*$.$spc.System.Nullable$$*/ sender, /**/ e)
            {
                return this.$nativeFunction.call(this.$target, sender, e);
            }
            static $h = 5678341;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":4498693}],"n":"Invoke","d":5678341,"h":8595612933,"f":129},{"r":57016321,"p":[{"n":"sender","p":131073},{"n":"e","p":4498693},{"n":"callback","p":14483457},{"n":"object","p":131073}],"n":"BeginInvoke","d":5678341,"h":12890580229,"f":129},{"r":65537,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":5678341,"h":17185547525,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":5678341,"h":4300645637,"f":1}],"i":[57212929,113377281],"h":5678341}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Transactions.TransactionStartedEventHandler`; }
        });
        
        $asm.$str("$stl.System.Transactions.IsolationLevel", ($self) => class IsolationLevel extends $.$spc.System.Enum
        {
            static Serializable = 0;
            static RepeatableRead = 1;
            static ReadCommitted = 2;
            static ReadUncommitted = 3;
            static Snapshot = 4;
            static Chaos = 5;
            static Unspecified = 6;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Serializable": 0n,
                    "RepeatableRead": 1n,
                    "ReadCommitted": 2n,
                    "ReadUncommitted": 3n,
                    "Snapshot": 4n,
                    "Chaos": 5n,
                    "Unspecified": 6n
                };
            }
            static $h = 3187973;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":3187973,"n":"Serializable","d":3187973,"h":4298155269,"f":33},{"t":3187973,"n":"RepeatableRead","d":3187973,"h":8593122565,"f":33},{"t":3187973,"n":"ReadCommitted","d":3187973,"h":12888089861,"f":33},{"t":3187973,"n":"ReadUncommitted","d":3187973,"h":17183057157,"f":33},{"t":3187973,"n":"Snapshot","d":3187973,"h":21478024453,"f":33},{"t":3187973,"n":"Chaos","d":3187973,"h":25772991749,"f":33},{"t":3187973,"n":"Unspecified","d":3187973,"h":30067959045,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":3187973,"h":34362926341,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":3187973}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Transactions.IsolationLevel`; }
        });
        
        $asm.$str("$stl.System.Transactions.TransactionStatus", ($self) => class TransactionStatus extends $.$spc.System.Enum
        {
            static Active = 0;
            static Committed = 1;
            static Aborted = 2;
            static InDoubt = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Active": 0n,
                    "Committed": 1n,
                    "Aborted": 2n,
                    "InDoubt": 3n
                };
            }
            static $h = 8430853;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":8430853,"n":"Active","d":8430853,"h":4303398149,"f":33},{"t":8430853,"n":"Committed","d":8430853,"h":8598365445,"f":33},{"t":8430853,"n":"Aborted","d":8430853,"h":12893332741,"f":33},{"t":8430853,"n":"InDoubt","d":8430853,"h":17188300037,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":8430853,"h":21483267333,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":8430853}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Transactions.TransactionStatus`; }
        });
        
        $asm.$str("$stl.System.Transactions.DependentCloneOption", ($self) => class DependentCloneOption extends $.$spc.System.Enum
        {
            static BlockCommitUntilComplete = 0;
            static RollbackIfNotComplete = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "BlockCommitUntilComplete": 0n,
                    "RollbackIfNotComplete": 1n
                };
            }
            static $h = 1090821;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1090821,"n":"BlockCommitUntilComplete","d":1090821,"h":4296058117,"f":33},{"t":1090821,"n":"RollbackIfNotComplete","d":1090821,"h":8591025413,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1090821,"h":12885992709,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1090821}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Transactions.DependentCloneOption`; }
        });
        
        $asm.$str("$stl.System.Transactions.EnlistmentOptions", ($self) => class EnlistmentOptions extends $.$spc.System.Enum
        {
            static None = 0;
            static EnlistDuringPrepareRequired = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "EnlistDuringPrepareRequired": 1n
                };
            }
            static $h = 1877253;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1877253,"n":"None","d":1877253,"h":4296844549,"f":33},{"t":1877253,"n":"EnlistDuringPrepareRequired","d":1877253,"h":8591811845,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1877253,"h":12886779141,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1877253,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Transactions.EnlistmentOptions`; }
        });
        
        $asm.$str("$stl.System.Transactions.EnlistmentType", ($self) => class EnlistmentType extends $.$spc.System.Enum
        {
            static Volatile = 0;
            static Durable = 1;
            static PromotableSinglePhase = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Volatile": 0n,
                    "Durable": 1n,
                    "PromotableSinglePhase": 2n
                };
            }
            static $h = 2139397;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2139397,"n":"Volatile","d":2139397,"h":4297106693,"f":33},{"t":2139397,"n":"Durable","d":2139397,"h":8592073989,"f":33},{"t":2139397,"n":"PromotableSinglePhase","d":2139397,"h":12887041285,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2139397,"h":17182008581,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":2139397}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Transactions.EnlistmentType`; }
        });
        
        $asm.$str("$stl.System.Transactions.NotificationCall", ($self) => class NotificationCall extends $.$spc.System.Enum
        {
            static Prepare = 0;
            static Commit = 1;
            static Rollback = 2;
            static InDoubt = 3;
            static SinglePhaseCommit = 4;
            static Promote = 5;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Prepare": 0n,
                    "Commit": 1n,
                    "Rollback": 2n,
                    "InDoubt": 3n,
                    "SinglePhaseCommit": 4n,
                    "Promote": 5n
                };
            }
            static $h = 3319045;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":3319045,"n":"Prepare","d":3319045,"h":4298286341,"f":33},{"t":3319045,"n":"Commit","d":3319045,"h":8593253637,"f":33},{"t":3319045,"n":"Rollback","d":3319045,"h":12888220933,"f":33},{"t":3319045,"n":"InDoubt","d":3319045,"h":17183188229,"f":33},{"t":3319045,"n":"SinglePhaseCommit","d":3319045,"h":21478155525,"f":33},{"t":3319045,"n":"Promote","d":3319045,"h":25773122821,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":3319045,"h":30068090117,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":3319045}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Transactions.NotificationCall`; }
        });
        
        $asm.$str("$stl.System.Transactions.EnlistmentCallback", ($self) => class EnlistmentCallback extends $.$spc.System.Enum
        {
            static Done = 0;
            static Prepared = 1;
            static ForceRollback = 2;
            static Committed = 3;
            static Aborted = 4;
            static InDoubt = 5;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Done": 0n,
                    "Prepared": 1n,
                    "ForceRollback": 2n,
                    "Committed": 3n,
                    "Aborted": 4n,
                    "InDoubt": 5n
                };
            }
            static $h = 1811717;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1811717,"n":"Done","d":1811717,"h":4296779013,"f":33},{"t":1811717,"n":"Prepared","d":1811717,"h":8591746309,"f":33},{"t":1811717,"n":"ForceRollback","d":1811717,"h":12886713605,"f":33},{"t":1811717,"n":"Committed","d":1811717,"h":17181680901,"f":33},{"t":1811717,"n":"Aborted","d":1811717,"h":21476648197,"f":33},{"t":1811717,"n":"InDoubt","d":1811717,"h":25771615493,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1811717,"h":30066582789,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1811717}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Transactions.EnlistmentCallback`; }
        });
        
        $asm.$str("$stl.System.Transactions.TransactionScopeResult", ($self) => class TransactionScopeResult extends $.$spc.System.Enum
        {
            static CreatedTransaction = 0;
            static UsingExistingCurrent = 1;
            static TransactionPassed = 2;
            static DependentTransactionPassed = 3;
            static NoTransaction = 4;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "CreatedTransaction": 0n,
                    "UsingExistingCurrent": 1n,
                    "TransactionPassed": 2n,
                    "DependentTransactionPassed": 3n,
                    "NoTransaction": 4n
                };
            }
            static $h = 5350661;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":5350661,"n":"CreatedTransaction","d":5350661,"h":4300317957,"f":33},{"t":5350661,"n":"UsingExistingCurrent","d":5350661,"h":8595285253,"f":33},{"t":5350661,"n":"TransactionPassed","d":5350661,"h":12890252549,"f":33},{"t":5350661,"n":"DependentTransactionPassed","d":5350661,"h":17185219845,"f":33},{"t":5350661,"n":"NoTransaction","d":5350661,"h":21480187141,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":5350661,"h":25775154437,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":5350661}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Transactions.TransactionScopeResult`; }
        });
        
        $asm.$str("$stl.System.Transactions.TransactionExceptionType", ($self) => class TransactionExceptionType extends $.$spc.System.Enum
        {
            static InvalidOperationException = 0;
            static TransactionAbortedException = 1;
            static TransactionException = 2;
            static TransactionInDoubtException = 3;
            static TransactionManagerCommunicationException = 4;
            static UnrecognizedRecoveryInformation = 5;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "InvalidOperationException": 0n,
                    "TransactionAbortedException": 1n,
                    "TransactionException": 2n,
                    "TransactionInDoubtException": 3n,
                    "TransactionManagerCommunicationException": 4n,
                    "UnrecognizedRecoveryInformation": 5n
                };
            }
            static $h = 4629765;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":4629765,"n":"UnrecognizedRecoveryInformation","d":4629765,"h":25774433541,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":4629765,"h":30069400837,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":4629765}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Transactions.TransactionExceptionType`; }
        });
        
        $asm.$str("$stl.System.Transactions.TraceSourceType", ($self) => class TraceSourceType extends $.$spc.System.Enum
        {
            static TraceSourceBase = 0;
            static TraceSourceLtm = 1;
            static TraceSourceOleTx = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "TraceSourceBase": 0n,
                    "TraceSourceLtm": 1n,
                    "TraceSourceOleTx": 2n
                };
            }
            static $h = 4236549;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":4236549,"n":"TraceSourceBase","d":4236549,"h":4299203845,"f":33},{"t":4236549,"n":"TraceSourceLtm","d":4236549,"h":8594171141,"f":33},{"t":4236549,"n":"TraceSourceOleTx","d":4236549,"h":12889138437,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":4236549,"h":17184105733,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":4236549}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Transactions.TraceSourceType`; }
        });
        
        $asm.$str("$stl.System.Transactions.TransactionScopeOption", ($self) => class TransactionScopeOption extends $.$spc.System.Enum
        {
            static Required = 0;
            static RequiresNew = 1;
            static Suppress = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Required": 0n,
                    "RequiresNew": 1n,
                    "Suppress": 2n
                };
            }
            static $h = 5285125;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":5285125,"n":"Required","d":5285125,"h":4300252421,"f":33},{"t":5285125,"n":"RequiresNew","d":5285125,"h":8595219717,"f":33},{"t":5285125,"n":"Suppress","d":5285125,"h":12890187013,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":5285125,"h":17185154309,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":5285125}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Transactions.TransactionScopeOption`; }
        });
        
        $asm.$str("$stl.System.Transactions.TransactionScopeAsyncFlowOption", ($self) => class TransactionScopeAsyncFlowOption extends $.$spc.System.Enum
        {
            static Suppress = 0;
            static Enabled = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Suppress": 0n,
                    "Enabled": 1n
                };
            }
            static $h = 5219589;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":5219589,"n":"Suppress","d":5219589,"h":4300186885,"f":33},{"t":5219589,"n":"Enabled","d":5219589,"h":8595154181,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":5219589,"h":12890121477,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":5219589}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Transactions.TransactionScopeAsyncFlowOption`; }
        });
        
        $asm.$str("$stl.System.Transactions.EnterpriseServicesInteropOption", ($self) => class EnterpriseServicesInteropOption extends $.$spc.System.Enum
        {
            static None = 0;
            static Automatic = 1;
            static Full = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "Automatic": 1n,
                    "Full": 2n
                };
            }
            static $h = 2270469;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2270469,"n":"None","d":2270469,"h":4297237765,"f":33},{"t":2270469,"n":"Automatic","d":2270469,"h":8592205061,"f":33},{"t":2270469,"n":"Full","d":2270469,"h":12887172357,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2270469,"h":17182139653,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":2270469}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Transactions.EnterpriseServicesInteropOption`; }
        });
        
        $asm.$str("$stl.System.Transactions.DefaultComContextState", ($self) => class DefaultComContextState extends $.$spc.System.Enum
        {
            static Unknown = 0;
            static Unavailable = -1;
            static Available = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unknown": 0n,
                    "Unavailable": -1n,
                    "Available": 1n
                };
            }
            static $h = 1025285;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1025285,"n":"Unknown","d":1025285,"h":4295992581,"f":33},{"t":1025285,"n":"Unavailable","d":1025285,"h":8590959877,"f":33},{"t":1025285,"n":"Available","d":1025285,"h":12885927173,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1025285,"h":17180894469,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1025285}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Transactions.DefaultComContextState`; }
        });
        
        $asm.$str("$stl.System.Transactions.TxLookup", ($self) => class TxLookup extends $.$spc.System.Enum
        {
            static Default = 0;
            static DefaultCallContext = 1;
            static DefaultTLS = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Default": 0n,
                    "DefaultCallContext": 1n,
                    "DefaultTLS": 2n
                };
            }
            static $h = 8627461;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":8627461,"n":"Default","d":8627461,"h":4303594757,"f":33},{"t":8627461,"n":"DefaultCallContext","d":8627461,"h":8598562053,"f":33},{"t":8627461,"n":"DefaultTLS","d":8627461,"h":12893529349,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":8627461,"h":17188496645,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":8627461}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Transactions.TxLookup`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateActive", ($self) => class TransactionStateActive extends $.$stl.System.Transactions.EnlistableStates
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
            }
            /*void */ BeginCommit(/*InternalTransaction*/ tx, /*bool*/ asyncCommit, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                tx._asyncCommit = asyncCommit;
                tx._asyncCallback = asyncCallback;
                tx._asyncState = asyncState;
                $.$stl.System.Transactions.TransactionState.TransactionStatePhase0.EnterState(tx);
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                tx._innerException ??= e;
                $.$stl.System.Transactions.TransactionState.TransactionStateAborted.EnterState(tx);
            }
            /*Enlistment */ EnlistVolatile(/*InternalTransaction*/ tx, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                /*Enlistment*/ let enlistment = new $.$stl.System.Transactions.Enlistment().$ctor$3(tx, enlistmentNotification, null, atomicTransaction, enlistmentOptions);
                if ((enlistmentOptions & 1/*EnlistmentOptions.EnlistDuringPrepareRequired*/) !== 0)
                {
                    $.$stl.System.Transactions.TransactionState.AddVolatileEnlistment($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase0Volatiles, ($v) => tx._phase0Volatiles = $v, null), enlistment);
                }
                else 
                {
                    $.$stl.System.Transactions.TransactionState.AddVolatileEnlistment($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase1Volatiles, ($v) => tx._phase1Volatiles = $v, null), enlistment);
                }
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionstateEnlist(enlistment.InternalEnlistment.EnlistmentTraceId, 0/*EnlistmentType.Volatile*/, enlistmentOptions);
                }
                return enlistment;
            }
            /*Enlistment */ EnlistVolatile$1(/*InternalTransaction*/ tx, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                /*Enlistment*/ let enlistment = new $.$stl.System.Transactions.Enlistment().$ctor$3(tx, enlistmentNotification, enlistmentNotification, atomicTransaction, enlistmentOptions);
                if ((enlistmentOptions & 1/*EnlistmentOptions.EnlistDuringPrepareRequired*/) !== 0)
                {
                    $.$stl.System.Transactions.TransactionState.AddVolatileEnlistment($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase0Volatiles, ($v) => tx._phase0Volatiles = $v, null), enlistment);
                }
                else 
                {
                    $.$stl.System.Transactions.TransactionState.AddVolatileEnlistment($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase1Volatiles, ($v) => tx._phase1Volatiles = $v, null), enlistment);
                }
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionstateEnlist(enlistment.InternalEnlistment.EnlistmentTraceId, 0/*EnlistmentType.Volatile*/, enlistmentOptions);
                }
                return enlistment;
            }
            /*bool */ EnlistPromotableSinglePhase(/*InternalTransaction*/ tx, /*IPromotableSinglePhaseNotification*/ promotableSinglePhaseNotification, /*Transaction*/ atomicTransaction, /*Guid*/ promoterType)
            {
                if (tx._durableEnlistment !== null)
                {
                    return false;
                }
                $.$stl.System.Transactions.TransactionState.TransactionStatePSPEOperation.PSPEInitialize(tx, promotableSinglePhaseNotification, promoterType);
                /*Enlistment*/ let en = new $.$stl.System.Transactions.Enlistment().$ctor$4(tx, promotableSinglePhaseNotification, atomicTransaction);
                tx._durableEnlistment = en.InternalEnlistment;
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionstateEnlist(tx._durableEnlistment.EnlistmentTraceId, 2/*EnlistmentType.PromotableSinglePhase*/, 0/*EnlistmentOptions.None*/);
                }
                tx._promoter = promotableSinglePhaseNotification;
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Guid.op_Inequality(tx._promoterType, $.$spc.System.Guid.Empty), "InternalTransaction.PromoterType was not set in PSPEInitialize");
                if ($.$spc.System.Guid.op_Equality(tx._promoterType, $.$stl.System.Transactions.TransactionInterop.PromoterTypeDtc))
                {
                    tx._promoteState = $.$stl.System.Transactions.TransactionState.TransactionStateDelegated;
                }
                else 
                {
                    tx._promoteState = $.$stl.System.Transactions.TransactionState.TransactionStateDelegatedNonMSDTC;
                }
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentActive.EnterState(tx._durableEnlistment);
                return true;
            }
            /*void */ Phase0VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ Phase1VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ DisposeRoot(/*InternalTransaction*/ tx)
            {
                tx.State.Rollback(tx, null);
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 5874949;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1680645,"m":[{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"EnterState","d":5874949,"h":4300842245,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"asyncCommit","p":262145},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":5874949,"h":8595809541,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"e","p":47251457}],"n":"Rollback","d":5874949,"h":12890776837,"f":32776},{"r":1746181,"p":[{"n":"tx","p":2794757},{"n":"enlistmentNotification","p":2598149},{"n":"enlistmentOptions","p":1877253},{"n":"atomicTransaction","p":4302085}],"n":"EnlistVolatile","d":5874949,"h":17185744133,"f":32776},{"r":1746181,"p":[{"n":"tx","p":2794757},{"n":"enlistmentNotification","p":3056901},{"n":"enlistmentOptions","p":1877253},{"n":"atomicTransaction","p":4302085}],"n":"EnlistVolatile","o":"@$1","d":5874949,"h":21480711429,"f":32776},{"r":262145,"p":[{"n":"tx","p":2794757},{"n":"promotableSinglePhaseNotification","p":2860293},{"n":"atomicTransaction","p":4302085},{"n":"promoterType","p":56229889}],"n":"EnlistPromotableSinglePhase","d":5874949,"h":25775678725,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"Phase0VolatilePrepareDone","d":5874949,"h":30070646021,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"Phase1VolatilePrepareDone","d":5874949,"h":34365613317,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"DisposeRoot","d":5874949,"h":38660580613,"f":32776}],"c":[{"n":".ctor","o":"$ctor$4","d":5874949,"h":42955547909,"f":1}],"h":5874949}; }
            static get $b() { return $.$stl.System.Transactions.EnlistableStates; }
            static get $fullName() { return `System.Transactions.TransactionStateActive`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePhase0", ($self) => class TransactionStatePhase0 extends $.$stl.System.Transactions.EnlistableStates
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                /*int*/ let volatileCount = tx._phase0Volatiles._volatileEnlistmentCount;
                /*int*/ let dependentCount = tx._phase0Volatiles._dependentClones;
                tx._phase0VolatileWaveCount = volatileCount;
                if (tx._phase0Volatiles._preparedVolatileEnlistments < ((volatileCount + dependentCount) | 0))
                {
                    for(/*int*/ let i = 0; i < volatileCount; i++)
                    {
                        $.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i)._twoPhaseState.ChangeStatePreparing($.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i));
                        if (!tx.State.ContinuePhase0Prepares())
                        {
                            break;
                        }
                    }
                }
                else 
                {
                    $.$stl.System.Transactions.TransactionState.TransactionStateVolatilePhase1.EnterState(tx);
                }
            }
            /*Enlistment */ EnlistDurable(/*InternalTransaction*/ tx, /*Guid*/ resourceManagerIdentifier, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                tx.ThrowIfPromoterTypeIsNotMSDTC();
                /*Enlistment*/ let en = super.EnlistDurable(tx, resourceManagerIdentifier, enlistmentNotification, enlistmentOptions, atomicTransaction);
                tx.State.RestartCommitIfNeeded(tx);
                return en;
            }
            /*Enlistment */ EnlistDurable$1(/*InternalTransaction*/ tx, /*Guid*/ resourceManagerIdentifier, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                tx.ThrowIfPromoterTypeIsNotMSDTC();
                /*Enlistment*/ let en = super.EnlistDurable$1(tx, resourceManagerIdentifier, enlistmentNotification, enlistmentOptions, atomicTransaction);
                tx.State.RestartCommitIfNeeded(tx);
                return en;
            }
            /*Enlistment */ EnlistVolatile(/*InternalTransaction*/ tx, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                /*Enlistment*/ let enlistment = new $.$stl.System.Transactions.Enlistment().$ctor$3(tx, enlistmentNotification, null, atomicTransaction, enlistmentOptions);
                if ((enlistmentOptions & 1/*EnlistmentOptions.EnlistDuringPrepareRequired*/) !== 0)
                {
                    $.$stl.System.Transactions.TransactionState.AddVolatileEnlistment($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase0Volatiles, ($v) => tx._phase0Volatiles = $v, null), enlistment);
                }
                else 
                {
                    $.$stl.System.Transactions.TransactionState.AddVolatileEnlistment($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase1Volatiles, ($v) => tx._phase1Volatiles = $v, null), enlistment);
                }
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionstateEnlist(enlistment.InternalEnlistment.EnlistmentTraceId, 0/*EnlistmentType.Volatile*/, enlistmentOptions);
                }
                return enlistment;
            }
            /*Enlistment */ EnlistVolatile$1(/*InternalTransaction*/ tx, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                /*Enlistment*/ let enlistment = new $.$stl.System.Transactions.Enlistment().$ctor$3(tx, enlistmentNotification, enlistmentNotification, atomicTransaction, enlistmentOptions);
                if ((enlistmentOptions & 1/*EnlistmentOptions.EnlistDuringPrepareRequired*/) !== 0)
                {
                    $.$stl.System.Transactions.TransactionState.AddVolatileEnlistment($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase0Volatiles, ($v) => tx._phase0Volatiles = $v, null), enlistment);
                }
                else 
                {
                    $.$stl.System.Transactions.TransactionState.AddVolatileEnlistment($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase1Volatiles, ($v) => tx._phase1Volatiles = $v, null), enlistment);
                }
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionstateEnlist(enlistment.InternalEnlistment.EnlistmentTraceId, 0/*EnlistmentType.Volatile*/, enlistmentOptions);
                }
                return enlistment;
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                this.ChangeStateTransactionAborted(tx, e);
            }
            /*bool */ EnlistPromotableSinglePhase(/*InternalTransaction*/ tx, /*IPromotableSinglePhaseNotification*/ promotableSinglePhaseNotification, /*Transaction*/ atomicTransaction, /*Guid*/ promoterType)
            {
                if (tx._durableEnlistment !== null)
                {
                    return false;
                }
                $.$stl.System.Transactions.TransactionState.TransactionStatePSPEOperation.Phase0PSPEInitialize(tx, promotableSinglePhaseNotification, promoterType);
                /*Enlistment*/ let en = new $.$stl.System.Transactions.Enlistment().$ctor$4(tx, promotableSinglePhaseNotification, atomicTransaction);
                tx._durableEnlistment = en.InternalEnlistment;
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionstateEnlist(tx._durableEnlistment.EnlistmentTraceId, 2/*EnlistmentType.PromotableSinglePhase*/, 0/*EnlistmentOptions.None*/);
                }
                tx._promoter = promotableSinglePhaseNotification;
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Guid.op_Inequality(tx._promoterType, $.$spc.System.Guid.Empty), "InternalTransaction.PromoterType was not set in Phase0PSPEInitialize");
                if ($.$spc.System.Guid.op_Equality(tx._promoterType, $.$stl.System.Transactions.TransactionInterop.PromoterTypeDtc))
                {
                    tx._promoteState = $.$stl.System.Transactions.TransactionState.TransactionStateDelegated;
                }
                else 
                {
                    tx._promoteState = $.$stl.System.Transactions.TransactionState.TransactionStateDelegatedNonMSDTC;
                }
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentActive.EnterState(tx._durableEnlistment);
                return true;
            }
            /*void */ Phase0VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
                /*int*/ let volatileCount = tx._phase0Volatiles._volatileEnlistmentCount;
                /*int*/ let dependentCount = tx._phase0Volatiles._dependentClones;
                tx._phase0VolatileWaveCount = volatileCount;
                if (tx._phase0Volatiles._preparedVolatileEnlistments < ((volatileCount + dependentCount) | 0))
                {
                    for(/*int*/ let i = 0; i < volatileCount; i++)
                    {
                        $.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i)._twoPhaseState.ChangeStatePreparing($.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i));
                        if (!tx.State.ContinuePhase0Prepares())
                        {
                            break;
                        }
                    }
                }
                else 
                {
                    $.$stl.System.Transactions.TransactionState.TransactionStateVolatilePhase1.EnterState(tx);
                }
            }
            /*void */ Phase1VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ RestartCommitIfNeeded(/*InternalTransaction*/ tx)
            {
            }
            /*bool */ ContinuePhase0Prepares()
            {
                return true;
            }
            /*void */ Promote(/*InternalTransaction*/ tx)
            {
                tx._promoteState.EnterState(tx);
                tx.State.CheckForFinishedTransaction(tx);
                tx.State.RestartCommitIfNeeded(tx);
            }
            /*void */ ChangeStateTransactionAborted(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                tx._innerException ??= e;
                $.$stl.System.Transactions.TransactionState.TransactionStateAborted.EnterState(tx);
            }
            /*void */ GetObjectData(/*InternalTransaction*/ tx, /*SerializationInfo*/ serializationInfo, /*StreamingContext*/ context)
            {
                tx.ThrowIfPromoterTypeIsNotMSDTC();
                tx._promoteState.EnterState(tx);
                tx.State.GetObjectData(tx, serializationInfo, context);
                tx.State.RestartCommitIfNeeded(tx);
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 6661381;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1680645,"m":[{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"EnterState","d":6661381,"h":4301628677,"f":32776},{"r":1746181,"p":[{"n":"tx","p":2794757},{"n":"resourceManagerIdentifier","p":56229889},{"n":"enlistmentNotification","p":2598149},{"n":"enlistmentOptions","p":1877253},{"n":"atomicTransaction","p":4302085}],"n":"EnlistDurable","d":6661381,"h":8596595973,"f":32776},{"r":1746181,"p":[{"n":"tx","p":2794757},{"n":"resourceManagerIdentifier","p":56229889},{"n":"enlistmentNotification","p":3056901},{"n":"enlistmentOptions","p":1877253},{"n":"atomicTransaction","p":4302085}],"n":"EnlistDurable","o":"@$1","d":6661381,"h":12891563269,"f":32776},{"r":1746181,"p":[{"n":"tx","p":2794757},{"n":"enlistmentNotification","p":2598149},{"n":"enlistmentOptions","p":1877253},{"n":"atomicTransaction","p":4302085}],"n":"EnlistVolatile","d":6661381,"h":17186530565,"f":32776},{"r":1746181,"p":[{"n":"tx","p":2794757},{"n":"enlistmentNotification","p":3056901},{"n":"enlistmentOptions","p":1877253},{"n":"atomicTransaction","p":4302085}],"n":"EnlistVolatile","o":"@$1","d":6661381,"h":21481497861,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"e","p":47251457}],"n":"Rollback","d":6661381,"h":25776465157,"f":32776},{"r":262145,"p":[{"n":"tx","p":2794757},{"n":"promotableSinglePhaseNotification","p":2860293},{"n":"atomicTransaction","p":4302085},{"n":"promoterType","p":56229889}],"n":"EnlistPromotableSinglePhase","d":6661381,"h":30071432453,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"Phase0VolatilePrepareDone","d":6661381,"h":34366399749,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"Phase1VolatilePrepareDone","d":6661381,"h":38661367045,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"RestartCommitIfNeeded","d":6661381,"h":42956334341,"f":32776},{"r":262145,"n":"ContinuePhase0Prepares","d":6661381,"h":47251301637,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"Promote","d":6661381,"h":51546268933,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"e","p":47251457}],"n":"ChangeStateTransactionAborted","d":6661381,"h":55841236229,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"serializationInfo","p":113967105},{"n":"context","p":114098177}],"n":"GetObjectData","d":6661381,"h":60136203525,"f":32776}],"c":[{"n":".ctor","o":"$ctor$4","d":6661381,"h":64431170821,"f":1}],"h":6661381}; }
            static get $b() { return $.$stl.System.Transactions.EnlistableStates; }
            static get $fullName() { return `System.Transactions.TransactionStatePhase0`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedP0Aborting", ($self) => class TransactionStatePromotedP0Aborting extends $.$stl.System.Transactions.TransactionStatePromotedAborting
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                this.ChangeStatePromotedAborted(tx);
                if (tx._phase0Volatiles.VolatileDemux._preparingEnlistment !== null)
                {
                    $.$spc.System.Threading.Monitor.Exit(tx);
                    try
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(tx._phase0Volatiles.VolatileDemux._promotedEnlistment !== null, "tx._phase0Volatiles.VolatileDemux._promotedEnlistment != null");
                        tx._phase0Volatiles.VolatileDemux._promotedEnlistment.System$Transactions$IPromotedEnlistment$ForceRollback();
                    }
                    finally
                    {
                        {
                            $.$spc.System.Threading.Monitor.Enter(tx);
                        }
                    }
                }
                else 
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(tx.PromotedTransaction !== null, "tx.PromotedTransaction != null");
                    tx.PromotedTransaction.Rollback();
                }
            }
            /*void */ Phase0VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 7775493;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6857989,"m":[{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"EnterState","d":7775493,"h":4302742789,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"Phase0VolatilePrepareDone","d":7775493,"h":8597710085,"f":32776}],"c":[{"n":".ctor","o":"$ctor$4","d":7775493,"h":12892677381,"f":1}],"h":7775493}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedAborting; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedP0Aborting`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedP1Aborting", ($self) => class TransactionStatePromotedP1Aborting extends $.$stl.System.Transactions.TransactionStatePromotedAborting
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                $.$spc.System.Diagnostics.Debug.Assert$1(tx._phase1Volatiles.VolatileDemux !== null, "Volatile Demux must exist.");
                this.ChangeStatePromotedAborted(tx);
                $.$spc.System.Threading.Monitor.Exit(tx);
                try
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(tx._phase1Volatiles.VolatileDemux._promotedEnlistment !== null, "tx._phase1Volatiles.VolatileDemux._promotedEnlistment != null");
                    tx._phase1Volatiles.VolatileDemux._promotedEnlistment.System$Transactions$IPromotedEnlistment$ForceRollback();
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(tx);
                    }
                }
            }
            /*void */ Phase1VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 7906565;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6857989,"m":[{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"EnterState","d":7906565,"h":4302873861,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"Phase1VolatilePrepareDone","d":7906565,"h":8597841157,"f":32776}],"c":[{"n":".ctor","o":"$ctor$4","d":7906565,"h":12892808453,"f":1}],"h":7906565}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedAborting; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedP1Aborting`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedAborted", ($self) => class TransactionStatePromotedAborted extends $.$stl.System.Transactions.TransactionStatePromotedEnded
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                super.EnterState(tx);
                if (tx._phase1Volatiles.VolatileDemux !== null)
                {
                    $.$stl.System.Transactions.VolatileDemultiplexer.BroadcastRollback($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase1Volatiles, ($v) => tx._phase1Volatiles = $v, null));
                }
                if (tx._phase0Volatiles.VolatileDemux !== null)
                {
                    $.$stl.System.Transactions.VolatileDemultiplexer.BroadcastRollback($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase0Volatiles, ($v) => tx._phase0Volatiles = $v, null));
                }
                tx.FireCompletion();
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionAborted(1/*TraceSourceType.TraceSourceLtm*/, tx.TransactionTraceId);
                }
            }
            /*TransactionStatus */ get_Status(/*InternalTransaction*/ tx)
            {
                return 2/*TransactionStatus.Aborted*/;
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
            }
            /*void */ BeginCommit(/*InternalTransaction*/ tx, /*bool*/ asyncCommit, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw $.$stl.System.Transactions.TransactionAbortedException.Create$3($.$stl.System.SR.TransactionAborted, tx._innerException, tx.DistributedTxId);
            }
            /*void */ CreateBlockingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionAbortedException.Create$3($.$stl.System.SR.TransactionAborted, tx._innerException, tx.DistributedTxId);
            }
            /*void */ CreateAbortingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionAbortedException.Create$3($.$stl.System.SR.TransactionAborted, tx._innerException, tx.DistributedTxId);
            }
            /*void */ RestartCommitIfNeeded(/*InternalTransaction*/ tx)
            {
            }
            /*void */ Phase0VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ Phase1VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ ChangeStatePromotedPhase0(/*InternalTransaction*/ tx)
            {
                throw new $.$stl.System.Transactions.TransactionAbortedException().$ctor$17(tx._innerException, tx.DistributedTxId);
            }
            /*void */ ChangeStatePromotedPhase1(/*InternalTransaction*/ tx)
            {
                throw new $.$stl.System.Transactions.TransactionAbortedException().$ctor$17(tx._innerException, tx.DistributedTxId);
            }
            /*void */ ChangeStatePromotedAborted(/*InternalTransaction*/ tx)
            {
            }
            /*void */ ChangeStateTransactionAborted(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
            }
            /*void */ PromotedTransactionOutcome(/*InternalTransaction*/ tx)
            {
                if ((null === tx._innerException) && (null !== tx.PromotedTransaction))
                {
                    tx._innerException = tx.PromotedTransaction.InnerException;
                }
                throw $.$stl.System.Transactions.TransactionAbortedException.Create$3($.$stl.System.SR.TransactionAborted, tx._innerException, tx.DistributedTxId);
            }
            /*void */ CheckForFinishedTransaction(/*InternalTransaction*/ tx)
            {
                throw new $.$stl.System.Transactions.TransactionAbortedException().$ctor$17(tx._innerException, tx.DistributedTxId);
            }
            /*void */ GetObjectData(/*InternalTransaction*/ tx, /*SerializationInfo*/ serializationInfo, /*StreamingContext*/ context)
            {
                throw $.$stl.System.Transactions.TransactionAbortedException.Create$3($.$stl.System.SR.TransactionAborted, tx._innerException, tx.DistributedTxId);
            }
            /*void */ InDoubtFromDtc(/*InternalTransaction*/ tx)
            {
            }
            /*void */ InDoubtFromEnlistment(/*InternalTransaction*/ tx)
            {
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 6792453;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7120133,"m":[{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"EnterState","d":6792453,"h":4301759749,"f":32776},{"r":8430853,"p":[{"n":"tx","p":2794757}],"n":"get_Status","d":6792453,"h":8596727045,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"e","p":47251457}],"n":"Rollback","d":6792453,"h":12891694341,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"asyncCommit","p":262145},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":6792453,"h":17186661637,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"CreateBlockingClone","d":6792453,"h":21481628933,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"CreateAbortingClone","d":6792453,"h":25776596229,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"RestartCommitIfNeeded","d":6792453,"h":30071563525,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"Phase0VolatilePrepareDone","d":6792453,"h":34366530821,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"Phase1VolatilePrepareDone","d":6792453,"h":38661498117,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"ChangeStatePromotedPhase0","d":6792453,"h":42956465413,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"ChangeStatePromotedPhase1","d":6792453,"h":47251432709,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"ChangeStatePromotedAborted","d":6792453,"h":51546400005,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"e","p":47251457}],"n":"ChangeStateTransactionAborted","d":6792453,"h":55841367301,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"PromotedTransactionOutcome","d":6792453,"h":60136334597,"f":32772},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"CheckForFinishedTransaction","d":6792453,"h":64431301893,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"serializationInfo","p":113967105},{"n":"context","p":114098177}],"n":"GetObjectData","d":6792453,"h":68726269189,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"InDoubtFromDtc","d":6792453,"h":73021236485,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"InDoubtFromEnlistment","d":6792453,"h":77316203781,"f":32776}],"c":[{"n":".ctor","o":"$ctor$4","d":6792453,"h":81611171077,"f":1}],"h":6792453}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedEnded; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedAborted`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedCommitted", ($self) => class TransactionStatePromotedCommitted extends $.$stl.System.Transactions.TransactionStatePromotedEnded
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                super.EnterState(tx);
                if (tx._phase1Volatiles.VolatileDemux !== null)
                {
                    $.$stl.System.Transactions.VolatileDemultiplexer.BroadcastCommitted($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase1Volatiles, ($v) => tx._phase1Volatiles = $v, null));
                }
                if (tx._phase0Volatiles.VolatileDemux !== null)
                {
                    $.$stl.System.Transactions.VolatileDemultiplexer.BroadcastCommitted($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase0Volatiles, ($v) => tx._phase0Volatiles = $v, null));
                }
                tx.FireCompletion();
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionCommitted(1/*TraceSourceType.TraceSourceLtm*/, tx.TransactionTraceId);
                }
            }
            /*TransactionStatus */ get_Status(/*InternalTransaction*/ tx)
            {
                return 1/*TransactionStatus.Committed*/;
            }
            /*void */ ChangeStatePromotedCommitted(/*InternalTransaction*/ tx)
            {
            }
            /*void */ PromotedTransactionOutcome(/*InternalTransaction*/ tx)
            {
            }
            /*void */ InDoubtFromDtc(/*InternalTransaction*/ tx)
            {
            }
            /*void */ InDoubtFromEnlistment(/*InternalTransaction*/ tx)
            {
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 6989061;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7120133,"m":[{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"EnterState","d":6989061,"h":4301956357,"f":32776},{"r":8430853,"p":[{"n":"tx","p":2794757}],"n":"get_Status","d":6989061,"h":8596923653,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"ChangeStatePromotedCommitted","d":6989061,"h":12891890949,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"PromotedTransactionOutcome","d":6989061,"h":17186858245,"f":32772},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"InDoubtFromDtc","d":6989061,"h":21481825541,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"InDoubtFromEnlistment","d":6989061,"h":25776792837,"f":32776}],"c":[{"n":".ctor","o":"$ctor$4","d":6989061,"h":30071760133,"f":1}],"h":6989061}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedEnded; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedCommitted`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedIndoubt", ($self) => class TransactionStatePromotedIndoubt extends $.$stl.System.Transactions.TransactionStatePromotedEnded
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                super.EnterState(tx);
                if (tx._phase1Volatiles.VolatileDemux !== null)
                {
                    $.$stl.System.Transactions.VolatileDemultiplexer.BroadcastInDoubt($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase1Volatiles, ($v) => tx._phase1Volatiles = $v, null));
                }
                if (tx._phase0Volatiles.VolatileDemux !== null)
                {
                    $.$stl.System.Transactions.VolatileDemultiplexer.BroadcastInDoubt($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase0Volatiles, ($v) => tx._phase0Volatiles = $v, null));
                }
                tx.FireCompletion();
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionInDoubt(1/*TraceSourceType.TraceSourceLtm*/, tx.TransactionTraceId);
                }
            }
            /*TransactionStatus */ get_Status(/*InternalTransaction*/ tx)
            {
                return 3/*TransactionStatus.InDoubt*/;
            }
            /*void */ RestartCommitIfNeeded(/*InternalTransaction*/ tx)
            {
            }
            /*void */ ChangeStatePromotedPhase0(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionInDoubtException.Create$3(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionIndoubt, tx._innerException, tx.DistributedTxId);
            }
            /*void */ ChangeStatePromotedPhase1(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionInDoubtException.Create$3(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionIndoubt, tx._innerException, tx.DistributedTxId);
            }
            /*void */ InDoubtFromDtc(/*InternalTransaction*/ tx)
            {
            }
            /*void */ InDoubtFromEnlistment(/*InternalTransaction*/ tx)
            {
            }
            /*void */ PromotedTransactionOutcome(/*InternalTransaction*/ tx)
            {
                if ((null === tx._innerException) && (null !== tx.PromotedTransaction))
                {
                    tx._innerException = tx.PromotedTransaction.InnerException;
                }
                throw $.$stl.System.Transactions.TransactionInDoubtException.Create$3(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionIndoubt, tx._innerException, tx.DistributedTxId);
            }
            /*void */ CheckForFinishedTransaction(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionInDoubtException.Create$3(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionIndoubt, tx._innerException, tx.DistributedTxId);
            }
            /*void */ GetObjectData(/*InternalTransaction*/ tx, /*SerializationInfo*/ serializationInfo, /*StreamingContext*/ context)
            {
                throw $.$stl.System.Transactions.TransactionInDoubtException.Create$3(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionIndoubt, tx._innerException, tx.DistributedTxId);
            }
            /*void */ ChangeStatePromotedAborted(/*InternalTransaction*/ tx)
            {
            }
            /*void */ ChangeStatePromotedCommitted(/*InternalTransaction*/ tx)
            {
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 7185669;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7120133,"m":[{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"EnterState","d":7185669,"h":4302152965,"f":32776},{"r":8430853,"p":[{"n":"tx","p":2794757}],"n":"get_Status","d":7185669,"h":8597120261,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"RestartCommitIfNeeded","d":7185669,"h":12892087557,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"ChangeStatePromotedPhase0","d":7185669,"h":17187054853,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"ChangeStatePromotedPhase1","d":7185669,"h":21482022149,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"InDoubtFromDtc","d":7185669,"h":25776989445,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"InDoubtFromEnlistment","d":7185669,"h":30071956741,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"PromotedTransactionOutcome","d":7185669,"h":34366924037,"f":32772},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"CheckForFinishedTransaction","d":7185669,"h":38661891333,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"serializationInfo","p":113967105},{"n":"context","p":114098177}],"n":"GetObjectData","d":7185669,"h":42956858629,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"ChangeStatePromotedAborted","d":7185669,"h":47251825925,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"ChangeStatePromotedCommitted","d":7185669,"h":51546793221,"f":32776}],"c":[{"n":".ctor","o":"$ctor$4","d":7185669,"h":55841760517,"f":1}],"h":7185669}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedEnded; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedIndoubt`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateDelegatedBase", ($self) => class TransactionStateDelegatedBase extends $.$stl.System.Transactions.TransactionStatePromoted
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                if (tx._outcomeSource._isoLevel === 4/*IsolationLevel.Snapshot*/)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException$1(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.CannotPromoteSnapshot, null, tx.DistributedTxId);
                }
                this.CommonEnterState(tx);
                /*Oletx.OletxTransaction?*/ let distributedTx = null;
                try
                {
                    if (tx._durableEnlistment !== null)
                    {
                        /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                        if (etwLog.IsEnabled())
                        {
                            etwLog.EnlistmentStatus(1/*TraceSourceType.TraceSourceLtm*/, tx._durableEnlistment.EnlistmentTraceId, 5/*NotificationCall.Promote*/);
                        }
                    }
                    distributedTx = $.$stl.System.Transactions.TransactionState.TransactionStatePSPEOperation.PSPEPromote(tx);
                }
                catch(e)
                {
                    tx._innerException = e;
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.ExceptionConsumed$1(e);
                    }
                }
                finally
                {
                    {
                        if ((distributedTx) === null)
                        {
                            tx.State.ChangeStateAbortedDuringPromotion(tx);
                        }
                    }
                }
                if ((distributedTx) === null)
                {
                    return;
                }
                if (tx.PromotedTransaction !== distributedTx)
                {
                    tx.PromotedTransaction = distributedTx;
                    /*Hashtable*/ let promotedTransactionTable = $.$stl.System.Transactions.TransactionManager.PromotedTransactionTable;
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter(promotedTransactionTable)
                        {
                            tx._finalizedObject = new $.$stl.System.Transactions.FinalizedObject().$ctor$1(tx, tx.PromotedTransaction.Identifier);
                            /*WeakReference*/ let weakRef = new $.$spc.System.WeakReference().$ctor$2(tx._outcomeSource, false);
                            promotedTransactionTable.set_Item(tx.PromotedTransaction.Identifier, weakRef);
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit(promotedTransactionTable)
                    }
                    $.$stl.System.Transactions.TransactionManager.FireDistributedTransactionStarted(tx._outcomeSource);
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.TransactionPromoted(tx.TransactionTraceId, distributedTx.TransactionTraceId);
                    }
                    this.PromoteEnlistmentsAndOutcome(tx);
                }
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 6137093;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6726917,"m":[{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"EnterState","d":6137093,"h":4301104389,"f":32776}],"c":[{"n":".ctor","o":"$ctor$4","d":6137093,"h":8596071685,"f":4}],"h":6137093}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromoted; }
            static get $fullName() { return `System.Transactions.TransactionStateDelegatedBase`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedNonMSDTCAborted", ($self) => class TransactionStatePromotedNonMSDTCAborted extends $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCEnded
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                super.EnterState(tx);
                for(/*int*/ let i = 0; i < tx._phase0Volatiles._volatileEnlistmentCount; i++)
                {
                    $.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i)._twoPhaseState.InternalAborted($.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i));
                }
                for(/*int*/ let i = 0; i < tx._phase1Volatiles._volatileEnlistmentCount; i++)
                {
                    $.$spc.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i)._twoPhaseState.InternalAborted($.$spc.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i));
                }
                tx._durableEnlistment?.State.InternalAborted(tx._durableEnlistment);
                tx.FireCompletion();
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionAborted(1/*TraceSourceType.TraceSourceLtm*/, tx.TransactionTraceId);
                }
            }
            /*TransactionStatus */ get_Status(/*InternalTransaction*/ tx)
            {
                return 2/*TransactionStatus.Aborted*/;
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
            }
            /*void */ BeginCommit(/*InternalTransaction*/ tx, /*bool*/ asyncCommit, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw $.$stl.System.Transactions.TransactionAbortedException.Create$3($.$stl.System.SR.TransactionAborted, tx._innerException, tx.DistributedTxId);
            }
            /*void */ CreateBlockingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionAbortedException.Create$3($.$stl.System.SR.TransactionAborted, tx._innerException, tx.DistributedTxId);
            }
            /*void */ CreateAbortingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionAbortedException.Create$3($.$stl.System.SR.TransactionAborted, tx._innerException, tx.DistributedTxId);
            }
            /*void */ Phase0VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ Phase1VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ ChangeStateTransactionAborted(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
            }
            /*void */ PromotedTransactionOutcome(/*InternalTransaction*/ tx)
            {
                if ((null === tx._innerException) && (null !== tx.PromotedTransaction))
                {
                    tx._innerException = tx.PromotedTransaction.InnerException;
                }
                throw $.$stl.System.Transactions.TransactionAbortedException.Create$3($.$stl.System.SR.TransactionAborted, tx._innerException, tx.DistributedTxId);
            }
            /*void */ CheckForFinishedTransaction(/*InternalTransaction*/ tx)
            {
                throw new $.$stl.System.Transactions.TransactionAbortedException().$ctor$17(tx._innerException, tx.DistributedTxId);
            }
            /*void */ GetObjectData(/*InternalTransaction*/ tx, /*SerializationInfo*/ serializationInfo, /*StreamingContext*/ context)
            {
                throw $.$stl.System.Transactions.TransactionAbortedException.Create$3($.$stl.System.SR.TransactionAborted, tx._innerException, tx.DistributedTxId);
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 7251205;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7447813,"m":[{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"EnterState","d":7251205,"h":4302218501,"f":32776},{"r":8430853,"p":[{"n":"tx","p":2794757}],"n":"get_Status","d":7251205,"h":8597185797,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"e","p":47251457}],"n":"Rollback","d":7251205,"h":12892153093,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"asyncCommit","p":262145},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":7251205,"h":17187120389,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"CreateBlockingClone","d":7251205,"h":21482087685,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"CreateAbortingClone","d":7251205,"h":25777054981,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"Phase0VolatilePrepareDone","d":7251205,"h":30072022277,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"Phase1VolatilePrepareDone","d":7251205,"h":34366989573,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"e","p":47251457}],"n":"ChangeStateTransactionAborted","d":7251205,"h":38661956869,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"PromotedTransactionOutcome","d":7251205,"h":42956924165,"f":32772},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"CheckForFinishedTransaction","d":7251205,"h":47251891461,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"serializationInfo","p":113967105},{"n":"context","p":114098177}],"n":"GetObjectData","d":7251205,"h":51546858757,"f":32776}],"c":[{"n":".ctor","o":"$ctor$4","d":7251205,"h":55841826053,"f":1}],"h":7251205}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCEnded; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedNonMSDTCAborted`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedNonMSDTCCommitted", ($self) => class TransactionStatePromotedNonMSDTCCommitted extends $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCEnded
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                super.EnterState(tx);
                for(/*int*/ let i = 0; i < tx._phase0Volatiles._volatileEnlistmentCount; i++)
                {
                    $.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i)._twoPhaseState.InternalCommitted($.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i));
                }
                for(/*int*/ let i = 0; i < tx._phase1Volatiles._volatileEnlistmentCount; i++)
                {
                    $.$spc.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i)._twoPhaseState.InternalCommitted($.$spc.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i));
                }
                tx.FireCompletion();
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionCommitted(1/*TraceSourceType.TraceSourceLtm*/, tx.TransactionTraceId);
                }
            }
            /*TransactionStatus */ get_Status(/*InternalTransaction*/ tx)
            {
                return 1/*TransactionStatus.Committed*/;
            }
            /*void */ PromotedTransactionOutcome(/*InternalTransaction*/ tx)
            {
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 7382277;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7447813,"m":[{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"EnterState","d":7382277,"h":4302349573,"f":32776},{"r":8430853,"p":[{"n":"tx","p":2794757}],"n":"get_Status","d":7382277,"h":8597316869,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"PromotedTransactionOutcome","d":7382277,"h":12892284165,"f":32772}],"c":[{"n":".ctor","o":"$ctor$4","d":7382277,"h":17187251461,"f":1}],"h":7382277}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCEnded; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedNonMSDTCCommitted`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedNonMSDTCIndoubt", ($self) => class TransactionStatePromotedNonMSDTCIndoubt extends $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCEnded
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                super.EnterState(tx);
                for(/*int*/ let i = 0; i < tx._phase0Volatiles._volatileEnlistmentCount; i++)
                {
                    $.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i)._twoPhaseState.InternalIndoubt($.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i));
                }
                for(/*int*/ let i = 0; i < tx._phase1Volatiles._volatileEnlistmentCount; i++)
                {
                    $.$spc.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i)._twoPhaseState.InternalIndoubt($.$spc.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i));
                }
                tx.FireCompletion();
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionInDoubt(1/*TraceSourceType.TraceSourceLtm*/, tx.TransactionTraceId);
                }
            }
            /*TransactionStatus */ get_Status(/*InternalTransaction*/ tx)
            {
                return 3/*TransactionStatus.InDoubt*/;
            }
            /*void */ ChangeStatePromotedPhase0(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionInDoubtException.Create$3(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionIndoubt, tx._innerException, tx.DistributedTxId);
            }
            /*void */ ChangeStatePromotedPhase1(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionInDoubtException.Create$3(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionIndoubt, tx._innerException, tx.DistributedTxId);
            }
            /*void */ PromotedTransactionOutcome(/*InternalTransaction*/ tx)
            {
                if ((null === tx._innerException) && (null !== tx.PromotedTransaction))
                {
                    tx._innerException = tx.PromotedTransaction.InnerException;
                }
                throw $.$stl.System.Transactions.TransactionInDoubtException.Create$3(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionIndoubt, tx._innerException, tx.DistributedTxId);
            }
            /*void */ CheckForFinishedTransaction(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionInDoubtException.Create$3(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionIndoubt, tx._innerException, tx.DistributedTxId);
            }
            /*void */ GetObjectData(/*InternalTransaction*/ tx, /*SerializationInfo*/ serializationInfo, /*StreamingContext*/ context)
            {
                throw $.$stl.System.Transactions.TransactionInDoubtException.Create$3(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionIndoubt, tx._innerException, tx.DistributedTxId);
            }
            /*void */ CreateBlockingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.Create$2($.$stl.System.SR.TransactionAborted, tx._innerException, tx.DistributedTxId);
            }
            /*void */ CreateAbortingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.Create$2($.$stl.System.SR.TransactionAborted, tx._innerException, tx.DistributedTxId);
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 7513349;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7447813,"m":[{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"EnterState","d":7513349,"h":4302480645,"f":32776},{"r":8430853,"p":[{"n":"tx","p":2794757}],"n":"get_Status","d":7513349,"h":8597447941,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"ChangeStatePromotedPhase0","d":7513349,"h":12892415237,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"ChangeStatePromotedPhase1","d":7513349,"h":17187382533,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"PromotedTransactionOutcome","d":7513349,"h":21482349829,"f":32772},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"CheckForFinishedTransaction","d":7513349,"h":25777317125,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"serializationInfo","p":113967105},{"n":"context","p":114098177}],"n":"GetObjectData","d":7513349,"h":30072284421,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"CreateBlockingClone","d":7513349,"h":34367251717,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"CreateAbortingClone","d":7513349,"h":38662219013,"f":32776}],"c":[{"n":".ctor","o":"$ctor$4","d":7513349,"h":42957186309,"f":1}],"h":7513349}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCEnded; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedNonMSDTCIndoubt`; }
        });
        
        $asm.$cls("$stl.System.Transactions.PreparingEnlistment", ($self) => class PreparingEnlistment extends $.$stl.System.Transactions.Enlistment
        {
            $ctor$7(/*InternalEnlistment*/ enlistment)
            {
                super.$ctor$1(enlistment);
                {
                }
                return this;
            }
            /*void */ Prepared()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "Prepared");
                    etwLog.EnlistmentPrepared(this._internalEnlistment);
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalEnlistment.SyncRoot)
                    {
                        this._internalEnlistment.State.Prepared(this._internalEnlistment);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalEnlistment.SyncRoot)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "Prepared");
                }
            }
            /*void */ ForceRollback()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "ForceRollback");
                    etwLog.EnlistmentForceRollback(this._internalEnlistment);
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalEnlistment.SyncRoot)
                    {
                        this._internalEnlistment.State.ForceRollback(this._internalEnlistment, null);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalEnlistment.SyncRoot)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "ForceRollback");
                }
            }
            /*void */ ForceRollback$1(/*Exception?*/ e)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "ForceRollback");
                    etwLog.EnlistmentForceRollback(this._internalEnlistment);
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalEnlistment.SyncRoot)
                    {
                        this._internalEnlistment.State.ForceRollback(this._internalEnlistment, e);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalEnlistment.SyncRoot)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "ForceRollback");
                }
            }
            /*byte[] */ RecoveryInformation()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "RecoveryInformation");
                }
                try
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter(this._internalEnlistment.SyncRoot)
                        {
                            return this._internalEnlistment.State.RecoveryInformation(this._internalEnlistment);
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit(this._internalEnlistment.SyncRoot)
                    }
                }
                finally
                {
                    {
                        if (etwLog.IsEnabled())
                        {
                            etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "RecoveryInformation");
                        }
                    }
                }
            }
            static $h = 3908869;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1746181,"m":[{"r":65537,"n":"Prepared","d":3908869,"h":8593843461,"f":1},{"r":65537,"n":"ForceRollback","d":3908869,"h":12888810757,"f":1},{"r":65537,"p":[{"n":"e","p":47251457}],"n":"ForceRollback","o":"@$1","d":3908869,"h":17183778053,"f":1},{"r":0,"n":"RecoveryInformation","d":3908869,"h":21478745349,"f":1}],"c":[{"p":[{"n":"enlistment","p":2729221}],"n":".ctor","o":"$ctor$7","d":3908869,"h":4298876165,"f":8}],"h":3908869}; }
            static get $b() { return $.$stl.System.Transactions.Enlistment; }
            static get $fullName() { return `System.Transactions.PreparingEnlistment`; }
        });
        
        $asm.$cls("$stl.System.Transactions.SinglePhaseEnlistment", ($self) => class SinglePhaseEnlistment extends $.$stl.System.Transactions.Enlistment
        {
            $ctor$7(/*InternalEnlistment*/ enlistment)
            {
                super.$ctor$1(enlistment);
                {
                }
                return this;
            }
            /*void */ Aborted()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "Aborted");
                    etwLog.EnlistmentAborted(this._internalEnlistment);
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalEnlistment.SyncRoot)
                    {
                        this._internalEnlistment.State.Aborted(this._internalEnlistment, null);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalEnlistment.SyncRoot)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "Aborted");
                }
            }
            /*void */ Aborted$1(/*Exception?*/ e)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "Aborted");
                    etwLog.EnlistmentAborted(this._internalEnlistment);
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalEnlistment.SyncRoot)
                    {
                        this._internalEnlistment.State.Aborted(this._internalEnlistment, e);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalEnlistment.SyncRoot)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "Aborted");
                }
            }
            /*void */ Committed()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "Committed");
                    etwLog.EnlistmentCommitted(this._internalEnlistment);
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalEnlistment.SyncRoot)
                    {
                        this._internalEnlistment.State.Committed(this._internalEnlistment);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalEnlistment.SyncRoot)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "Committed");
                }
            }
            /*void */ InDoubt()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "InDoubt");
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalEnlistment.SyncRoot)
                    {
                        if (etwLog.IsEnabled())
                        {
                            etwLog.EnlistmentInDoubt(this._internalEnlistment);
                        }
                        this._internalEnlistment.State.InDoubt(this._internalEnlistment, null);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalEnlistment.SyncRoot)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "InDoubt");
                }
            }
            /*void */ InDoubt$1(/*Exception?*/ e)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "InDoubt");
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalEnlistment.SyncRoot)
                    {
                        if (etwLog.IsEnabled())
                        {
                            etwLog.EnlistmentInDoubt(this._internalEnlistment);
                        }
                        this._internalEnlistment.State.InDoubt(this._internalEnlistment, e);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalEnlistment.SyncRoot)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "InDoubt");
                }
            }
            static $h = 4105477;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1746181,"m":[{"r":65537,"n":"Aborted","d":4105477,"h":8594040069,"f":1},{"r":65537,"p":[{"n":"e","p":47251457}],"n":"Aborted","o":"@$1","d":4105477,"h":12889007365,"f":1},{"r":65537,"n":"Committed","d":4105477,"h":17183974661,"f":1},{"r":65537,"n":"InDoubt","d":4105477,"h":21478941957,"f":1},{"r":65537,"p":[{"n":"e","p":47251457}],"n":"InDoubt","o":"@$1","d":4105477,"h":25773909253,"f":1}],"c":[{"p":[{"n":"enlistment","p":2729221}],"n":".ctor","o":"$ctor$7","d":4105477,"h":4299072773,"f":8}],"h":4105477}; }
            static get $b() { return $.$stl.System.Transactions.Enlistment; }
            static get $fullName() { return `System.Transactions.SinglePhaseEnlistment`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionEventArgs", ($self) => class TransactionEventArgs extends $.$spc.System.EventArgs
        {
            /*Transaction?*/ _transaction = null;
            /*Transaction? */ get Transaction()
            {
                return this._transaction;
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 4498693;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46989313,"p":[{"p":4302085,"g":{"r":0,"d":0,"h":12889400581,"f":1},"n":"Transaction","d":4498693,"h":8594433285,"f":1}],"l":[{"t":4302085,"n":"_transaction","d":4498693,"h":4299465989,"f":8}],"c":[{"n":".ctor","o":"$ctor$2","d":4498693,"h":17184367877,"f":1}],"h":4498693}; }
            static get $b() { return $.$spc.System.EventArgs; }
            static get $fullName() { return `System.Transactions.TransactionEventArgs`; }
        });
        
        $asm.$cls("$stl.System.Transactions.Oletx.OletxDependentTransaction", ($self) => class OletxDependentTransaction extends $.$stl.System.Transactions.Oletx.OletxTransaction
        {
            /*void */ Complete()
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransaction.NotSupported();
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 3450117;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":3515653,"m":[{"r":65537,"n":"Complete","d":3450117,"h":4298417413,"f":8}],"c":[{"n":".ctor","o":"$ctor$3","d":3450117,"h":8593384709,"f":1}],"i":[113377281],"h":3450117}; }
            static get $b() { return $.$stl.System.Transactions.Oletx.OletxTransaction; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Transactions.Oletx.OletxDependentTransaction`; }
        });
        
        $asm.$cls("$stl.System.Transactions.Oletx.OletxCommittableTransaction", ($self) => class OletxCommittableTransaction extends $.$stl.System.Transactions.Oletx.OletxTransaction
        {
            /*void */ BeginCommit(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransaction.NotSupported();
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 3384581;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":3515653,"m":[{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"BeginCommit","d":3384581,"h":4298351877,"f":8}],"c":[{"n":".ctor","o":"$ctor$3","d":3384581,"h":8593319173,"f":1}],"i":[113377281],"h":3384581}; }
            static get $b() { return $.$stl.System.Transactions.Oletx.OletxTransaction; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Transactions.Oletx.OletxCommittableTransaction`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionsEtwProvider", ($self) => class TransactionsEtwProvider extends $.$spc.System.Diagnostics.Tracing.EventSource
        {
            /*TransactionsEtwProvider*/ static Log = null;
            $ctor$8()
            {
                super.$ctor$4();
                {
                }
                return this;
            }
            /*EventKeywords*/ static ALL_KEYWORDS = -1n;
            /*int*/ static CONFIGURED_DEFAULT_TIMEOUT_ADJUSTED_EVENTID = 1;
            /*int*/ static ENLISTMENT_ABORTED_EVENTID = 2;
            /*int*/ static ENLISTMENT_COMMITTED_EVENTID = 3;
            /*int*/ static ENLISTMENT_DONE_EVENTID = 4;
            /*int*/ static ENLISTMENT_LTM_EVENTID = 5;
            /*int*/ static ENLISTMENT_FORCEROLLBACK_EVENTID = 6;
            /*int*/ static ENLISTMENT_INDOUBT_EVENTID = 7;
            /*int*/ static ENLISTMENT_PREPARED_EVENTID = 8;
            /*int*/ static EXCEPTION_CONSUMED_BASE_EVENTID = 9;
            /*int*/ static EXCEPTION_CONSUMED_LTM_EVENTID = 10;
            /*int*/ static METHOD_ENTER_LTM_EVENTID = 11;
            /*int*/ static METHOD_EXIT_LTM_EVENTID = 12;
            /*int*/ static METHOD_ENTER_BASE_EVENTID = 13;
            /*int*/ static METHOD_EXIT_BASE_EVENTID = 14;
            /*int*/ static METHOD_ENTER_OLETX_EVENTID = 15;
            /*int*/ static METHOD_EXIT_OLETX_EVENTID = 16;
            /*int*/ static TRANSACTION_ABORTED_LTM_EVENTID = 17;
            /*int*/ static TRANSACTION_CLONECREATE_EVENTID = 18;
            /*int*/ static TRANSACTION_COMMIT_LTM_EVENTID = 19;
            /*int*/ static TRANSACTION_COMMITTED_LTM_EVENTID = 20;
            /*int*/ static TRANSACTION_CREATED_LTM_EVENTID = 21;
            /*int*/ static TRANSACTION_DEPENDENT_CLONE_COMPLETE_LTM_EVENTID = 22;
            /*int*/ static TRANSACTION_EXCEPTION_LTM_EVENTID = 23;
            /*int*/ static TRANSACTION_EXCEPTION_BASE_EVENTID = 24;
            /*int*/ static TRANSACTION_INDOUBT_LTM_EVENTID = 25;
            /*int*/ static TRANSACTION_INVALID_OPERATION_EVENTID = 26;
            /*int*/ static TRANSACTION_PROMOTED_EVENTID = 27;
            /*int*/ static TRANSACTION_ROLLBACK_LTM_EVENTID = 28;
            /*int*/ static TRANSACTION_SERIALIZED_EVENTID = 29;
            /*int*/ static TRANSACTION_TIMEOUT_EVENTID = 30;
            /*int*/ static TRANSACTIONMANAGER_RECOVERY_COMPLETE_EVENTID = 31;
            /*int*/ static TRANSACTIONMANAGER_REENLIST_EVENTID = 32;
            /*int*/ static TRANSACTIONSCOPE_CREATED_EVENTID = 33;
            /*int*/ static TRANSACTIONSCOPE_CURRENT_CHANGED_EVENTID = 34;
            /*int*/ static TRANSACTIONSCOPE_DISPOSED_EVENTID = 35;
            /*int*/ static TRANSACTIONSCOPE_INCOMPLETE_EVENTID = 36;
            /*int*/ static INTERNAL_ERROR_EVENTID = 37;
            /*int*/ static TRANSACTIONSCOPE_NESTED_INCORRECTLY_EVENTID = 38;
            /*int*/ static TRANSACTIONSCOPE_TIMEOUT_EVENTID = 39;
            /*int*/ static TRANSACTIONSTATE_ENLIST_EVENTID = 40;
            /*int*/ static TRANSACTION_COMMIT_OLETX_EVENTID = 41;
            /*int*/ static TRANSACTION_ROLLBACK_OLETX_EVENTID = 42;
            /*int*/ static EXCEPTION_CONSUMED_OLETX_EVENTID = 43;
            /*int*/ static TRANSACTION_COMMITTED_OLETX_EVENTID = 44;
            /*int*/ static TRANSACTION_ABORTED_OLETX_EVENTID = 45;
            /*int*/ static TRANSACTION_INDOUBT_OLETX_EVENTID = 46;
            /*int*/ static TRANSACTION_DEPENDENT_CLONE_COMPLETE_OLETX_EVENTID = 47;
            /*int*/ static TRANSACTION_DEPENDENT_CLONE_CREATE_LTM_EVENTID = 48;
            /*int*/ static TRANSACTION_DEPENDENT_CLONE_CREATE_OLETX_EVENTID = 49;
            /*int*/ static TRANSACTION_DESERIALIZED_EVENTID = 50;
            /*int*/ static TRANSACTION_CREATED_OLETX_EVENTID = 51;
            /*int*/ static ENLISTMENT_OLETX_EVENTID = 52;
            /*int*/ static ENLISTMENT_CALLBACK_POSITIVE_EVENTID = 53;
            /*int*/ static ENLISTMENT_CALLBACK_NEGATIVE_EVENTID = 54;
            /*int*/ static ENLISTMENT_CREATED_LTM_EVENTID = 55;
            /*int*/ static ENLISTMENT_CREATED_OLETX_EVENTID = 56;
            /*int*/ static TRANSACTIONMANAGER_CREATE_OLETX_EVENTID = 57;
            /*string*/ static NullInstance = null;
            static /*string */ IdOf(/*object?*/ value)
            {
                return value !== null ? $.$spc.System.Object.GetType.call(value).Name + "#" + $.$stl.System.Transactions.TransactionsEtwProvider.GetHashCode$1(value) : "(null)"/*NullInstance*/;
            }
            static /*int */ GetHashCode$1(/*object?*/ value)
            {
                const $t1 = value;
                return $.$ifnn($t1, ($t) => $.$spc.System.Object.GetHashCode.call($t)) ?? 0;
            }
            /*void */ TransactionCreated(/*TraceSourceType*/ traceSource, /*TransactionTraceIdentifier*/ txTraceId, /*string?*/ type)
            {
                if (this.IsEnabled$1(4/*EventLevel.Informational*/, -1n))
                {
                    if (traceSource === 1/*TraceSourceType.TraceSourceLtm*/)
                    {
                        this.TransactionCreatedLtm(txTraceId.TransactionIdentifier, type);
                    }
                    else if (traceSource === 2/*TraceSourceType.TraceSourceOleTx*/)
                    {
                        this.TransactionCreatedOleTx(txTraceId.TransactionIdentifier, type);
                    }
                }
            }
            /*void */ TransactionCreatedLtm(/*string*/ transactionIdentifier, /*string?*/ type)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionIdentifier);
                this.WriteEvent$8(21/*TRANSACTION_CREATED_LTM_EVENTID*/, transactionIdentifier, type);
            }
            /*void */ TransactionCreatedOleTx(/*string*/ transactionIdentifier, /*string?*/ type)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionIdentifier);
                this.WriteEvent$8(51/*TRANSACTION_CREATED_OLETX_EVENTID*/, transactionIdentifier, type);
            }
            /*void */ TransactionCloneCreate(/*Transaction*/ transaction, /*string*/ type)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$stl.System.Transactions.Transaction.op_Inequality(transaction, null), "Transaction needed for the ETW event.");
                if (this.IsEnabled$1(4/*EventLevel.Informational*/, -1n))
                {
                    if ($.$stl.System.Transactions.Transaction.op_Inequality(transaction, null) && $.$spc.System.String.op_Inequality(transaction.TransactionTraceId.TransactionIdentifier, null))
                    {
                        this.TransactionCloneCreate$1(transaction.TransactionTraceId.TransactionIdentifier, type);
                    }
                    else 
                    {
                        this.TransactionCloneCreate$1($.$spc.System.String.Empty, type);
                    }
                }
            }
            /*void */ TransactionCloneCreate$1(/*string*/ transactionIdentifier, /*string*/ type)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionIdentifier);
                this.WriteEvent$8(18/*TRANSACTION_CLONECREATE_EVENTID*/, transactionIdentifier, type);
            }
            /*void */ TransactionSerialized(/*TransactionTraceIdentifier*/ transactionTraceId)
            {
                if (this.IsEnabled$1(4/*EventLevel.Informational*/, -1n))
                {
                    this.TransactionSerialized$1(transactionTraceId.TransactionIdentifier);
                }
            }
            /*void */ TransactionSerialized$1(/*string*/ transactionIdentifier)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionIdentifier);
                this.WriteEvent$7(29/*TRANSACTION_SERIALIZED_EVENTID*/, transactionIdentifier);
            }
            /*void */ TransactionDeserialized(/*TransactionTraceIdentifier*/ transactionTraceId)
            {
                if (this.IsEnabled$1(5/*EventLevel.Verbose*/, -1n))
                {
                    this.TransactionDeserialized$1(transactionTraceId.TransactionIdentifier);
                }
            }
            /*void */ TransactionDeserialized$1(/*string*/ transactionIdentifier)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionIdentifier);
                this.WriteEvent$7(50/*TRANSACTION_DESERIALIZED_EVENTID*/, transactionIdentifier);
            }
            /*void */ TransactionExceptionTrace(/*TraceSourceType*/ traceSource, /*TransactionExceptionType*/ type, /*string?*/ message, /*string?*/ innerExceptionStr)
            {
                if (this.IsEnabled$1(2/*EventLevel.Error*/, -1n))
                {
                    if (traceSource === 0/*TraceSourceType.TraceSourceBase*/)
                    {
                        this.TransactionExceptionBase($.$spc.System.Enum.ToStringT($.$stl.System.Transactions.TransactionExceptionType, $.$spc.System.UInt32, type), message, innerExceptionStr);
                    }
                    else 
                    {
                        this.TransactionExceptionLtm($.$spc.System.Enum.ToStringT($.$stl.System.Transactions.TransactionExceptionType, $.$spc.System.UInt32, type), message, innerExceptionStr);
                    }
                }
            }
            /*void */ TransactionExceptionTrace$1(/*TransactionExceptionType*/ type, /*string?*/ message, /*string?*/ innerExceptionStr)
            {
                if (this.IsEnabled$1(2/*EventLevel.Error*/, -1n))
                {
                    this.TransactionExceptionLtm($.$spc.System.Enum.ToStringT($.$stl.System.Transactions.TransactionExceptionType, $.$spc.System.UInt32, type), message, innerExceptionStr);
                }
            }
            /*void */ TransactionExceptionBase(/*string?*/ type, /*string?*/ message, /*string?*/ innerExceptionStr)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$9(24/*TRANSACTION_EXCEPTION_BASE_EVENTID*/, type, message, innerExceptionStr);
            }
            /*void */ TransactionExceptionLtm(/*string?*/ type, /*string?*/ message, /*string?*/ innerExceptionStr)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$9(23/*TRANSACTION_EXCEPTION_LTM_EVENTID*/, type, message, innerExceptionStr);
            }
            /*void */ InvalidOperation(/*string?*/ type, /*string?*/ operation)
            {
                if (this.IsEnabled$1(2/*EventLevel.Error*/, -1n))
                {
                    this.TransactionInvalidOperation($.$spc.System.String.Empty, type, operation);
                }
            }
            /*void */ TransactionInvalidOperation(/*string?*/ transactionIdentifier, /*string?*/ type, /*string?*/ operation)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$9(26/*TRANSACTION_INVALID_OPERATION_EVENTID*/, transactionIdentifier, type, operation);
            }
            /*void */ TransactionRollback(/*TraceSourceType*/ traceSource, /*TransactionTraceIdentifier*/ txTraceId, /*string?*/ type)
            {
                if (this.IsEnabled$1(3/*EventLevel.Warning*/, -1n))
                {
                    if (traceSource === 1/*TraceSourceType.TraceSourceLtm*/)
                    {
                        this.TransactionRollbackLtm(txTraceId.TransactionIdentifier, type);
                    }
                    else if (traceSource === 2/*TraceSourceType.TraceSourceOleTx*/)
                    {
                        this.TransactionRollbackOleTx(txTraceId.TransactionIdentifier, type);
                    }
                }
            }
            /*void */ TransactionRollbackLtm(/*string*/ transactionIdentifier, /*string?*/ type)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionIdentifier);
                this.WriteEvent$8(28/*TRANSACTION_ROLLBACK_LTM_EVENTID*/, transactionIdentifier, type);
            }
            /*void */ TransactionRollbackOleTx(/*string*/ transactionIdentifier, /*string?*/ type)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionIdentifier);
                this.WriteEvent$8(42/*TRANSACTION_ROLLBACK_OLETX_EVENTID*/, transactionIdentifier, type);
            }
            /*void */ TransactionDependentCloneCreate(/*TraceSourceType*/ traceSource, /*TransactionTraceIdentifier*/ txTraceId, /*DependentCloneOption*/ option)
            {
                if (this.IsEnabled$1(4/*EventLevel.Informational*/, -1n))
                {
                    if (traceSource === 1/*TraceSourceType.TraceSourceLtm*/)
                    {
                        this.TransactionDependentCloneCreateLtm(txTraceId.TransactionIdentifier, $.$spc.System.Enum.ToStringT($.$stl.System.Transactions.DependentCloneOption, $.$spc.System.UInt32, option));
                    }
                    else if (traceSource === 2/*TraceSourceType.TraceSourceOleTx*/)
                    {
                        this.TransactionDependentCloneCreateOleTx(txTraceId.TransactionIdentifier, $.$spc.System.Enum.ToStringT($.$stl.System.Transactions.DependentCloneOption, $.$spc.System.UInt32, option));
                    }
                }
            }
            /*void */ TransactionDependentCloneCreateLtm(/*string*/ transactionIdentifier, /*string?*/ option)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionIdentifier);
                this.WriteEvent$8(48/*TRANSACTION_DEPENDENT_CLONE_CREATE_LTM_EVENTID*/, transactionIdentifier, option);
            }
            /*void */ TransactionDependentCloneCreateOleTx(/*string*/ transactionIdentifier, /*string?*/ option)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionIdentifier);
                this.WriteEvent$8(49/*TRANSACTION_DEPENDENT_CLONE_CREATE_OLETX_EVENTID*/, transactionIdentifier, option);
            }
            /*void */ TransactionDependentCloneComplete(/*TraceSourceType*/ traceSource, /*TransactionTraceIdentifier*/ txTraceId, /*string?*/ type)
            {
                if (this.IsEnabled$1(4/*EventLevel.Informational*/, -1n))
                {
                    if (traceSource === 1/*TraceSourceType.TraceSourceLtm*/)
                    {
                        this.TransactionDependentCloneCompleteLtm(txTraceId.TransactionIdentifier, type);
                    }
                    else if (traceSource === 2/*TraceSourceType.TraceSourceOleTx*/)
                    {
                        this.TransactionDependentCloneCompleteOleTx(txTraceId.TransactionIdentifier, type);
                    }
                }
            }
            /*void */ TransactionDependentCloneCompleteLtm(/*string*/ transactionIdentifier, /*string?*/ type)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionIdentifier);
                this.WriteEvent$8(22/*TRANSACTION_DEPENDENT_CLONE_COMPLETE_LTM_EVENTID*/, transactionIdentifier, type);
            }
            /*void */ TransactionDependentCloneCompleteOleTx(/*string*/ transactionIdentifier, /*string?*/ type)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionIdentifier);
                this.WriteEvent$8(47/*TRANSACTION_DEPENDENT_CLONE_COMPLETE_OLETX_EVENTID*/, transactionIdentifier, type);
            }
            /*void */ TransactionCommit(/*TraceSourceType*/ traceSource, /*TransactionTraceIdentifier*/ txTraceId, /*string?*/ type)
            {
                if (this.IsEnabled$1(5/*EventLevel.Verbose*/, -1n))
                {
                    if (traceSource === 1/*TraceSourceType.TraceSourceLtm*/)
                    {
                        this.TransactionCommitLtm(txTraceId.TransactionIdentifier, type);
                    }
                    else if (traceSource === 2/*TraceSourceType.TraceSourceOleTx*/)
                    {
                        this.TransactionCommitOleTx(txTraceId.TransactionIdentifier, type);
                    }
                }
            }
            /*void */ TransactionCommitLtm(/*string*/ transactionIdentifier, /*string?*/ type)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionIdentifier);
                this.WriteEvent$8(19/*TRANSACTION_COMMIT_LTM_EVENTID*/, transactionIdentifier, type);
            }
            /*void */ TransactionCommitOleTx(/*string*/ transactionIdentifier, /*string?*/ type)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionIdentifier);
                this.WriteEvent$8(41/*TRANSACTION_COMMIT_OLETX_EVENTID*/, transactionIdentifier, type);
            }
            /*void */ EnlistmentStatus(/*TraceSourceType*/ traceSource, /*EnlistmentTraceIdentifier*/ enlistmentTraceId, /*NotificationCall*/ notificationCall)
            {
                if (this.IsEnabled$1(5/*EventLevel.Verbose*/, -1n))
                {
                    if (traceSource === 1/*TraceSourceType.TraceSourceLtm*/)
                    {
                        this.EnlistmentStatusLtm(enlistmentTraceId.EnlistmentIdentifier, $.$spc.System.Enum.ToStringT($.$stl.System.Transactions.NotificationCall, $.$spc.System.UInt32, notificationCall));
                    }
                    else if (traceSource === 2/*TraceSourceType.TraceSourceOleTx*/)
                    {
                        this.EnlistmentStatusOleTx(enlistmentTraceId.EnlistmentIdentifier, $.$spc.System.Enum.ToStringT($.$stl.System.Transactions.NotificationCall, $.$spc.System.UInt32, notificationCall));
                    }
                }
            }
            /*void */ EnlistmentStatusLtm(/*int*/ enlistmentIdentifier, /*string*/ notificationCall)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$14(5/*ENLISTMENT_LTM_EVENTID*/, enlistmentIdentifier, notificationCall);
            }
            /*void */ EnlistmentStatusOleTx(/*int*/ enlistmentIdentifier, /*string*/ notificationCall)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$14(52/*ENLISTMENT_OLETX_EVENTID*/, enlistmentIdentifier, notificationCall);
            }
            /*void */ EnlistmentCreated(/*TraceSourceType*/ traceSource, /*EnlistmentTraceIdentifier*/ enlistmentTraceId, /*EnlistmentType*/ enlistmentType, /*EnlistmentOptions*/ enlistmentOptions)
            {
                if (this.IsEnabled$1(4/*EventLevel.Informational*/, -1n))
                {
                    if (traceSource === 1/*TraceSourceType.TraceSourceLtm*/)
                    {
                        this.EnlistmentCreatedLtm(enlistmentTraceId.EnlistmentIdentifier, $.$spc.System.Enum.ToStringT($.$stl.System.Transactions.EnlistmentType, $.$spc.System.UInt32, enlistmentType), $.$spc.System.Enum.ToStringT($.$stl.System.Transactions.EnlistmentOptions, $.$spc.System.UInt32, enlistmentOptions));
                    }
                    else if (traceSource === 2/*TraceSourceType.TraceSourceOleTx*/)
                    {
                        this.EnlistmentCreatedOleTx(enlistmentTraceId.EnlistmentIdentifier, $.$spc.System.Enum.ToStringT($.$stl.System.Transactions.EnlistmentType, $.$spc.System.UInt32, enlistmentType), $.$spc.System.Enum.ToStringT($.$stl.System.Transactions.EnlistmentOptions, $.$spc.System.UInt32, enlistmentOptions));
                    }
                }
            }
            /*void */ EnlistmentCreatedLtm(/*int*/ enlistmentIdentifier, /*string*/ enlistmentType, /*string*/ enlistmentOptions)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$17(55/*ENLISTMENT_CREATED_LTM_EVENTID*/, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive), [ $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$3(enlistmentIdentifier), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(enlistmentType), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(enlistmentOptions) ], null, null));
            }
            /*void */ EnlistmentCreatedOleTx(/*int*/ enlistmentIdentifier, /*string*/ enlistmentType, /*string*/ enlistmentOptions)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$17(56/*ENLISTMENT_CREATED_OLETX_EVENTID*/, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive), [ $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$3(enlistmentIdentifier), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(enlistmentType), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(enlistmentOptions) ], null, null));
            }
            /*void */ EnlistmentDone(/*InternalEnlistment*/ enlistment)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(enlistment !== null, "Enlistment needed for the ETW event.");
                if (this.IsEnabled$1(5/*EventLevel.Verbose*/, -1n))
                {
                    if (enlistment !== null && enlistment.EnlistmentTraceId.EnlistmentIdentifier !== 0)
                    {
                        this.EnlistmentDone$1(enlistment.EnlistmentTraceId.EnlistmentIdentifier);
                    }
                    else 
                    {
                        this.EnlistmentDone$1(0);
                    }
                }
            }
            /*void */ EnlistmentDone$1(/*int*/ enlistmentIdentifier)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$1(4/*ENLISTMENT_DONE_EVENTID*/, enlistmentIdentifier);
            }
            /*void */ EnlistmentPrepared(/*InternalEnlistment*/ enlistment)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(enlistment !== null, "Enlistment needed for the ETW event.");
                if (this.IsEnabled$1(5/*EventLevel.Verbose*/, -1n))
                {
                    if (enlistment !== null && enlistment.EnlistmentTraceId.EnlistmentIdentifier !== 0)
                    {
                        this.EnlistmentPrepared$1(enlistment.EnlistmentTraceId.EnlistmentIdentifier);
                    }
                    else 
                    {
                        this.EnlistmentPrepared$1(0);
                    }
                }
            }
            /*void */ EnlistmentPrepared$1(/*int*/ enlistmentIdentifier)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$1(8/*ENLISTMENT_PREPARED_EVENTID*/, enlistmentIdentifier);
            }
            /*void */ EnlistmentForceRollback(/*InternalEnlistment*/ enlistment)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(enlistment !== null, "Enlistment needed for the ETW event.");
                if (this.IsEnabled$1(3/*EventLevel.Warning*/, -1n))
                {
                    if (enlistment !== null && enlistment.EnlistmentTraceId.EnlistmentIdentifier !== 0)
                    {
                        this.EnlistmentForceRollback$1(enlistment.EnlistmentTraceId.EnlistmentIdentifier);
                    }
                    else 
                    {
                        this.EnlistmentForceRollback$1(0);
                    }
                }
            }
            /*void */ EnlistmentForceRollback$1(/*int*/ enlistmentIdentifier)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$1(6/*ENLISTMENT_FORCEROLLBACK_EVENTID*/, enlistmentIdentifier);
            }
            /*void */ EnlistmentAborted(/*InternalEnlistment*/ enlistment)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(enlistment !== null, "Enlistment needed for the ETW event.");
                if (this.IsEnabled$1(3/*EventLevel.Warning*/, -1n))
                {
                    if (enlistment !== null && enlistment.EnlistmentTraceId.EnlistmentIdentifier !== 0)
                    {
                        this.EnlistmentAborted$1(enlistment.EnlistmentTraceId.EnlistmentIdentifier);
                    }
                    else 
                    {
                        this.EnlistmentAborted$1(0);
                    }
                }
            }
            /*void */ EnlistmentAborted$1(/*int*/ enlistmentIdentifier)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$1(2/*ENLISTMENT_ABORTED_EVENTID*/, enlistmentIdentifier);
            }
            /*void */ EnlistmentCommitted(/*InternalEnlistment*/ enlistment)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(enlistment !== null, "Enlistment needed for the ETW event.");
                if (this.IsEnabled$1(5/*EventLevel.Verbose*/, -1n))
                {
                    if (enlistment !== null && enlistment.EnlistmentTraceId.EnlistmentIdentifier !== 0)
                    {
                        this.EnlistmentCommitted$1(enlistment.EnlistmentTraceId.EnlistmentIdentifier);
                    }
                    else 
                    {
                        this.EnlistmentCommitted$1(0);
                    }
                }
            }
            /*void */ EnlistmentCommitted$1(/*int*/ enlistmentIdentifier)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$1(3/*ENLISTMENT_COMMITTED_EVENTID*/, enlistmentIdentifier);
            }
            /*void */ EnlistmentInDoubt(/*InternalEnlistment*/ enlistment)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(enlistment !== null, "Enlistment needed for the ETW event.");
                if (this.IsEnabled$1(3/*EventLevel.Warning*/, -1n))
                {
                    if (enlistment !== null && enlistment.EnlistmentTraceId.EnlistmentIdentifier !== 0)
                    {
                        this.EnlistmentInDoubt$1(enlistment.EnlistmentTraceId.EnlistmentIdentifier);
                    }
                    else 
                    {
                        this.EnlistmentInDoubt$1(0);
                    }
                }
            }
            /*void */ EnlistmentInDoubt$1(/*int*/ enlistmentIdentifier)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$1(7/*ENLISTMENT_INDOUBT_EVENTID*/, enlistmentIdentifier);
            }
            /*void */ EnlistmentCallbackPositive(/*EnlistmentTraceIdentifier*/ enlistmentTraceIdentifier, /*EnlistmentCallback*/ callback)
            {
                if (this.IsEnabled$1(5/*EventLevel.Verbose*/, -1n))
                {
                    this.EnlistmentCallbackPositive$1(enlistmentTraceIdentifier.EnlistmentIdentifier, $.$spc.System.Enum.ToStringT($.$stl.System.Transactions.EnlistmentCallback, $.$spc.System.UInt32, callback));
                }
            }
            /*void */ EnlistmentCallbackPositive$1(/*int*/ enlistmentIdentifier, /*string?*/ callback)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$14(53/*ENLISTMENT_CALLBACK_POSITIVE_EVENTID*/, enlistmentIdentifier, callback);
            }
            /*void */ EnlistmentCallbackNegative(/*EnlistmentTraceIdentifier*/ enlistmentTraceIdentifier, /*EnlistmentCallback*/ callback)
            {
                if (this.IsEnabled$1(3/*EventLevel.Warning*/, -1n))
                {
                    this.EnlistmentCallbackNegative$1(enlistmentTraceIdentifier.EnlistmentIdentifier, $.$spc.System.Enum.ToStringT($.$stl.System.Transactions.EnlistmentCallback, $.$spc.System.UInt32, callback));
                }
            }
            /*void */ EnlistmentCallbackNegative$1(/*int*/ enlistmentIdentifier, /*string?*/ callback)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$14(54/*ENLISTMENT_CALLBACK_NEGATIVE_EVENTID*/, enlistmentIdentifier, callback);
            }
            /*void */ MethodEnter(/*TraceSourceType*/ traceSource, /*object?*/ thisOrContextObject, /*string?*/ methodname)
            {
                if (this.IsEnabled$1(5/*EventLevel.Verbose*/, -1n))
                {
                    if (traceSource === 1/*TraceSourceType.TraceSourceLtm*/)
                    {
                        this.MethodEnterTraceLtm($.$stl.System.Transactions.TransactionsEtwProvider.IdOf(thisOrContextObject), methodname);
                    }
                    else if (traceSource === 0/*TraceSourceType.TraceSourceBase*/)
                    {
                        this.MethodEnterTraceBase($.$stl.System.Transactions.TransactionsEtwProvider.IdOf(thisOrContextObject), methodname);
                    }
                    else if (traceSource === 2/*TraceSourceType.TraceSourceOleTx*/)
                    {
                        this.MethodEnterTraceDistributed($.$stl.System.Transactions.TransactionsEtwProvider.IdOf(thisOrContextObject), methodname);
                    }
                }
            }
            /*void */ MethodEnter$1(/*TraceSourceType*/ traceSource, /*string?*/ methodname)
            {
                if (this.IsEnabled$1(5/*EventLevel.Verbose*/, -1n))
                {
                    if (traceSource === 1/*TraceSourceType.TraceSourceLtm*/)
                    {
                        this.MethodEnterTraceLtm($.$spc.System.String.Empty, methodname);
                    }
                    else if (traceSource === 0/*TraceSourceType.TraceSourceBase*/)
                    {
                        this.MethodEnterTraceBase($.$spc.System.String.Empty, methodname);
                    }
                    else if (traceSource === 2/*TraceSourceType.TraceSourceOleTx*/)
                    {
                        this.MethodEnterTraceDistributed($.$spc.System.String.Empty, methodname);
                    }
                }
            }
            /*void */ MethodEnterTraceLtm(/*string*/ thisOrContextObject, /*string?*/ methodname)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$8(11/*METHOD_ENTER_LTM_EVENTID*/, thisOrContextObject, methodname);
            }
            /*void */ MethodEnterTraceBase(/*string*/ thisOrContextObject, /*string?*/ methodname)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$8(13/*METHOD_ENTER_BASE_EVENTID*/, thisOrContextObject, methodname);
            }
            /*void */ MethodEnterTraceDistributed(/*string*/ thisOrContextObject, /*string?*/ methodname)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$8(15/*METHOD_ENTER_OLETX_EVENTID*/, thisOrContextObject, methodname);
            }
            /*void */ MethodExit(/*TraceSourceType*/ traceSource, /*object?*/ thisOrContextObject, /*string?*/ methodname)
            {
                if (this.IsEnabled$1(5/*EventLevel.Verbose*/, -1n))
                {
                    if (traceSource === 1/*TraceSourceType.TraceSourceLtm*/)
                    {
                        this.MethodExitTraceLtm($.$stl.System.Transactions.TransactionsEtwProvider.IdOf(thisOrContextObject), methodname);
                    }
                    else if (traceSource === 0/*TraceSourceType.TraceSourceBase*/)
                    {
                        this.MethodExitTraceBase($.$stl.System.Transactions.TransactionsEtwProvider.IdOf(thisOrContextObject), methodname);
                    }
                    else if (traceSource === 2/*TraceSourceType.TraceSourceOleTx*/)
                    {
                        this.MethodExitTraceDistributed($.$stl.System.Transactions.TransactionsEtwProvider.IdOf(thisOrContextObject), methodname);
                    }
                }
            }
            /*void */ MethodExit$1(/*TraceSourceType*/ traceSource, /*string?*/ methodname)
            {
                if (this.IsEnabled$1(5/*EventLevel.Verbose*/, -1n))
                {
                    if (traceSource === 1/*TraceSourceType.TraceSourceLtm*/)
                    {
                        this.MethodExitTraceLtm($.$spc.System.String.Empty, methodname);
                    }
                    else if (traceSource === 0/*TraceSourceType.TraceSourceBase*/)
                    {
                        this.MethodExitTraceBase($.$spc.System.String.Empty, methodname);
                    }
                    else if (traceSource === 2/*TraceSourceType.TraceSourceOleTx*/)
                    {
                        this.MethodExitTraceDistributed($.$spc.System.String.Empty, methodname);
                    }
                }
            }
            /*void */ MethodExitTraceLtm(/*string*/ thisOrContextObject, /*string?*/ methodname)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$8(12/*METHOD_EXIT_LTM_EVENTID*/, thisOrContextObject, methodname);
            }
            /*void */ MethodExitTraceBase(/*string*/ thisOrContextObject, /*string?*/ methodname)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$8(14/*METHOD_EXIT_BASE_EVENTID*/, thisOrContextObject, methodname);
            }
            /*void */ MethodExitTraceDistributed(/*string*/ thisOrContextObject, /*string?*/ methodname)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$8(16/*METHOD_EXIT_OLETX_EVENTID*/, thisOrContextObject, methodname);
            }
            /*void */ ExceptionConsumed(/*TraceSourceType*/ traceSource, /*Exception*/ exception)
            {
                if (this.IsEnabled$1(5/*EventLevel.Verbose*/, -1n))
                {
                    switch(traceSource)
                    {
                        case 0/*TraceSourceType.TraceSourceBase*/:
                        this.ExceptionConsumedBase($.$spc.System.Exception.ToString.call(exception));
                        return;
                        case 1/*TraceSourceType.TraceSourceLtm*/:
                        this.ExceptionConsumedLtm($.$spc.System.Exception.ToString.call(exception));
                        return;
                        case 2/*TraceSourceType.TraceSourceOleTx*/:
                        this.ExceptionConsumedOleTx($.$spc.System.Exception.ToString.call(exception));
                        return;
                    }
                }
            }
            /*void */ ExceptionConsumed$1(/*Exception*/ exception)
            {
                if (this.IsEnabled$1(5/*EventLevel.Verbose*/, -1n))
                {
                    this.ExceptionConsumedLtm($.$spc.System.Exception.ToString.call(exception));
                }
            }
            /*void */ ExceptionConsumedBase(/*string*/ exceptionStr)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$7(9/*EXCEPTION_CONSUMED_BASE_EVENTID*/, exceptionStr);
            }
            /*void */ ExceptionConsumedLtm(/*string*/ exceptionStr)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$7(10/*EXCEPTION_CONSUMED_LTM_EVENTID*/, exceptionStr);
            }
            /*void */ ExceptionConsumedOleTx(/*string*/ exceptionStr)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$7(43/*EXCEPTION_CONSUMED_OLETX_EVENTID*/, exceptionStr);
            }
            /*void */ OleTxTransactionManagerCreate(/*Type*/ tmType, /*string?*/ nodeName)
            {
                if (this.IsEnabled$1(5/*EventLevel.Verbose*/, -1n))
                {
                    this.OleTxTransactionManagerCreate$1($.$spc.System.Type.ToString.call(tmType), nodeName);
                }
            }
            /*void */ OleTxTransactionManagerCreate$1(/*string*/ tmType, /*string?*/ nodeName)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$8(57/*TRANSACTIONMANAGER_CREATE_OLETX_EVENTID*/, tmType, nodeName);
            }
            /*void */ TransactionManagerReenlist(/*Guid*/ resourceManagerID)
            {
                if (this.IsEnabled$1(4/*EventLevel.Informational*/, -1n))
                {
                    this.TransactionManagerReenlistTrace($.$spc.System.Guid.ToString.call(resourceManagerID));
                }
            }
            /*void */ TransactionManagerReenlistTrace(/*string*/ rmID)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$7(32/*TRANSACTIONMANAGER_REENLIST_EVENTID*/, rmID);
            }
            /*void */ TransactionManagerRecoveryComplete(/*Guid*/ resourceManagerID)
            {
                if (this.IsEnabled$1(4/*EventLevel.Informational*/, -1n))
                {
                    this.TransactionManagerRecoveryComplete$1($.$spc.System.Guid.ToString.call(resourceManagerID));
                }
            }
            /*void */ TransactionManagerRecoveryComplete$1(/*string*/ rmID)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$7(31/*TRANSACTIONMANAGER_RECOVERY_COMPLETE_EVENTID*/, rmID);
            }
            /*void */ ConfiguredDefaultTimeoutAdjusted()
            {
                if (this.IsEnabled$1(3/*EventLevel.Warning*/, -1n))
                {
                    this.ConfiguredDefaultTimeoutAdjustedTrace();
                }
            }
            /*void */ ConfiguredDefaultTimeoutAdjustedTrace()
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent(1/*CONFIGURED_DEFAULT_TIMEOUT_ADJUSTED_EVENTID*/);
            }
            /*void */ TransactionScopeCreated(/*TransactionTraceIdentifier*/ transactionID, /*TransactionScopeResult*/ transactionScopeResult)
            {
                if (this.IsEnabled$1(4/*EventLevel.Informational*/, -1n))
                {
                    this.TransactionScopeCreated$1(transactionID.TransactionIdentifier ?? $.$spc.System.String.Empty, transactionScopeResult);
                }
            }
            /*void */ TransactionScopeCreated$1(/*string*/ transactionID, /*TransactionScopeResult*/ transactionScopeResult)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionID);
                this.WriteEvent$17(33/*TRANSACTIONSCOPE_CREATED_EVENTID*/, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive), [ $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(transactionID), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$19($.$box(transactionScopeResult, $.$stl.System.Transactions.TransactionScopeResult)) ], null, null));
            }
            /*void */ TransactionScopeCurrentChanged(/*TransactionTraceIdentifier*/ currenttransactionID, /*TransactionTraceIdentifier*/ newtransactionID)
            {
                if (this.IsEnabled$1(3/*EventLevel.Warning*/, -1n))
                {
                    /*string*/ let currentId = $.$spc.System.String.Empty;
                    /*string*/ let newId = $.$spc.System.String.Empty;
                    if ($.$spc.System.String.op_Inequality(currenttransactionID.TransactionIdentifier, null))
                    {
                        currentId = $.$spc.System.String.ToString.call(currenttransactionID.TransactionIdentifier);
                    }
                    if ($.$spc.System.String.op_Inequality(newtransactionID.TransactionIdentifier, null))
                    {
                        newId = $.$spc.System.String.ToString.call(newtransactionID.TransactionIdentifier);
                    }
                    this.TransactionScopeCurrentChanged$1(currentId, newId);
                }
            }
            /*void */ TransactionScopeCurrentChanged$1(/*string*/ currenttransactionID, /*string*/ newtransactionID)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(newtransactionID);
                this.WriteEvent$8(34/*TRANSACTIONSCOPE_CURRENT_CHANGED_EVENTID*/, currenttransactionID, newtransactionID);
            }
            /*void */ TransactionScopeNestedIncorrectly(/*TransactionTraceIdentifier*/ transactionID)
            {
                if (this.IsEnabled$1(3/*EventLevel.Warning*/, -1n))
                {
                    this.TransactionScopeNestedIncorrectly$1(transactionID.TransactionIdentifier ?? $.$spc.System.String.Empty);
                }
            }
            /*void */ TransactionScopeNestedIncorrectly$1(/*string*/ transactionID)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionID);
                this.WriteEvent$7(38/*TRANSACTIONSCOPE_NESTED_INCORRECTLY_EVENTID*/, transactionID);
            }
            /*void */ TransactionScopeDisposed(/*TransactionTraceIdentifier*/ transactionID)
            {
                if (this.IsEnabled$1(4/*EventLevel.Informational*/, -1n))
                {
                    this.TransactionScopeDisposed$1(transactionID.TransactionIdentifier ?? $.$spc.System.String.Empty);
                }
            }
            /*void */ TransactionScopeDisposed$1(/*string*/ transactionID)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionID);
                this.WriteEvent$7(35/*TRANSACTIONSCOPE_DISPOSED_EVENTID*/, transactionID);
            }
            /*void */ TransactionScopeIncomplete(/*TransactionTraceIdentifier*/ transactionID)
            {
                if (this.IsEnabled$1(3/*EventLevel.Warning*/, -1n))
                {
                    this.TransactionScopeIncomplete$1(transactionID.TransactionIdentifier ?? $.$spc.System.String.Empty);
                }
            }
            /*void */ TransactionScopeIncomplete$1(/*string*/ transactionID)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionID);
                this.WriteEvent$7(36/*TRANSACTIONSCOPE_INCOMPLETE_EVENTID*/, transactionID);
            }
            /*void */ TransactionScopeTimeout(/*TransactionTraceIdentifier*/ transactionID)
            {
                if (this.IsEnabled$1(3/*EventLevel.Warning*/, -1n))
                {
                    this.TransactionScopeTimeout$1(transactionID.TransactionIdentifier ?? $.$spc.System.String.Empty);
                }
            }
            /*void */ TransactionScopeTimeout$1(/*string*/ transactionID)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionID);
                this.WriteEvent$7(39/*TRANSACTIONSCOPE_TIMEOUT_EVENTID*/, transactionID);
            }
            /*void */ TransactionTimeout(/*TransactionTraceIdentifier*/ transactionID)
            {
                if (this.IsEnabled$1(3/*EventLevel.Warning*/, -1n))
                {
                    this.TransactionTimeout$1(transactionID.TransactionIdentifier ?? $.$spc.System.String.Empty);
                }
            }
            /*void */ TransactionTimeout$1(/*string*/ transactionID)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionID);
                this.WriteEvent$7(30/*TRANSACTION_TIMEOUT_EVENTID*/, transactionID);
            }
            /*void */ TransactionstateEnlist(/*EnlistmentTraceIdentifier*/ enlistmentID, /*EnlistmentType*/ enlistmentType, /*EnlistmentOptions*/ enlistmentOption)
            {
                if (this.IsEnabled$1(4/*EventLevel.Informational*/, -1n))
                {
                    if (enlistmentID.EnlistmentIdentifier !== 0)
                    {
                        this.TransactionstateEnlist$1($.$spc.System.Int32.ToString.call(enlistmentID.EnlistmentIdentifier), $.$spc.System.Enum.ToStringT($.$stl.System.Transactions.EnlistmentType, $.$spc.System.UInt32, enlistmentType), $.$spc.System.Enum.ToStringT($.$stl.System.Transactions.EnlistmentOptions, $.$spc.System.UInt32, enlistmentOption));
                    }
                    else 
                    {
                        this.TransactionstateEnlist$1($.$spc.System.String.Empty, $.$spc.System.Enum.ToStringT($.$stl.System.Transactions.EnlistmentType, $.$spc.System.UInt32, enlistmentType), $.$spc.System.Enum.ToStringT($.$stl.System.Transactions.EnlistmentOptions, $.$spc.System.UInt32, enlistmentOption));
                    }
                }
            }
            /*void */ TransactionstateEnlist$1(/*string*/ enlistmentID, /*string*/ type, /*string*/ option)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$9(40/*TRANSACTIONSTATE_ENLIST_EVENTID*/, enlistmentID, type, option);
            }
            /*void */ TransactionCommitted(/*TraceSourceType*/ traceSource, /*TransactionTraceIdentifier*/ transactionID)
            {
                if (this.IsEnabled$1(5/*EventLevel.Verbose*/, -1n))
                {
                    if (traceSource === 1/*TraceSourceType.TraceSourceLtm*/)
                    {
                        this.TransactionCommittedLtm(transactionID.TransactionIdentifier ?? $.$spc.System.String.Empty);
                    }
                    else if (traceSource === 2/*TraceSourceType.TraceSourceOleTx*/)
                    {
                        this.TransactionCommittedOleTx(transactionID.TransactionIdentifier ?? $.$spc.System.String.Empty);
                    }
                }
            }
            /*void */ TransactionCommittedLtm(/*string*/ transactionID)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionID);
                this.WriteEvent$7(20/*TRANSACTION_COMMITTED_LTM_EVENTID*/, transactionID);
            }
            /*void */ TransactionCommittedOleTx(/*string*/ transactionID)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionID);
                this.WriteEvent$7(44/*TRANSACTION_COMMITTED_OLETX_EVENTID*/, transactionID);
            }
            /*void */ TransactionInDoubt(/*TraceSourceType*/ traceSource, /*TransactionTraceIdentifier*/ transactionID)
            {
                if (this.IsEnabled$1(3/*EventLevel.Warning*/, -1n))
                {
                    if (traceSource === 1/*TraceSourceType.TraceSourceLtm*/)
                    {
                        this.TransactionInDoubtLtm(transactionID.TransactionIdentifier ?? $.$spc.System.String.Empty);
                    }
                    else if (traceSource === 2/*TraceSourceType.TraceSourceOleTx*/)
                    {
                        this.TransactionInDoubtOleTx(transactionID.TransactionIdentifier ?? $.$spc.System.String.Empty);
                    }
                }
            }
            /*void */ TransactionInDoubtLtm(/*string*/ transactionID)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionID);
                this.WriteEvent$7(25/*TRANSACTION_INDOUBT_LTM_EVENTID*/, transactionID);
            }
            /*void */ TransactionInDoubtOleTx(/*string*/ transactionID)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionID);
                this.WriteEvent$7(46/*TRANSACTION_INDOUBT_OLETX_EVENTID*/, transactionID);
            }
            /*void */ TransactionPromoted(/*TransactionTraceIdentifier*/ transactionID, /*TransactionTraceIdentifier*/ distributedTxID)
            {
                if (this.IsEnabled$1(4/*EventLevel.Informational*/, -1n))
                {
                    this.TransactionPromoted$1(transactionID.TransactionIdentifier ?? $.$spc.System.String.Empty, distributedTxID.TransactionIdentifier ?? $.$spc.System.String.Empty);
                }
            }
            /*void */ TransactionPromoted$1(/*string*/ transactionID, /*string*/ distributedTxID)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionID);
                this.WriteEvent$8(27/*TRANSACTION_PROMOTED_EVENTID*/, transactionID, distributedTxID);
            }
            /*void */ TransactionAborted(/*TraceSourceType*/ traceSource, /*TransactionTraceIdentifier*/ transactionID)
            {
                if (this.IsEnabled$1(3/*EventLevel.Warning*/, -1n))
                {
                    if (traceSource === 1/*TraceSourceType.TraceSourceLtm*/)
                    {
                        this.TransactionAbortedLtm(transactionID.TransactionIdentifier ?? $.$spc.System.String.Empty);
                    }
                    else if (traceSource === 2/*TraceSourceType.TraceSourceOleTx*/)
                    {
                        this.TransactionAbortedOleTx(transactionID.TransactionIdentifier ?? $.$spc.System.String.Empty);
                    }
                }
            }
            /*void */ TransactionAbortedLtm(/*string*/ transactionID)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionID);
                this.WriteEvent$7(17/*TRANSACTION_ABORTED_LTM_EVENTID*/, transactionID);
            }
            /*void */ TransactionAbortedOleTx(/*string*/ transactionID)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionID);
                this.WriteEvent$7(45/*TRANSACTION_ABORTED_OLETX_EVENTID*/, transactionID);
            }
            /*void */ InternalError(/*string?*/ error)
            {
                if (this.IsEnabled$1(1/*EventLevel.Critical*/, -1n))
                {
                    this.InternalErrorTrace(error);
                }
            }
            /*void */ InternalErrorTrace(/*string?*/ error)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$7(37/*INTERNAL_ERROR_EVENTID*/, error);
            }
            static $_Opcodes;
            static get Opcodes()
            {
                let $cls = $.$stl.System.Transactions.TransactionsEtwProvider;
                return $cls.$_Opcodes ??= $asm.$ncls("$stl.System.Transactions.TransactionsEtwProvider.Opcodes", ($self) => class Opcodes
                {
                    /*EventOpcode*/ static Aborted = 100;
                    /*EventOpcode*/ static Activity = 101;
                    /*EventOpcode*/ static Adjusted = 102;
                    /*EventOpcode*/ static CloneCreate = 103;
                    /*EventOpcode*/ static Commit = 104;
                    /*EventOpcode*/ static Committed = 105;
                    /*EventOpcode*/ static Create = 106;
                    /*EventOpcode*/ static Created = 107;
                    /*EventOpcode*/ static CurrentChanged = 108;
                    /*EventOpcode*/ static DependentCloneComplete = 109;
                    /*EventOpcode*/ static Disposed = 110;
                    /*EventOpcode*/ static Done = 111;
                    /*EventOpcode*/ static Enlist = 112;
                    /*EventOpcode*/ static Enter = 113;
                    /*EventOpcode*/ static ExceptionConsumed = 114;
                    /*EventOpcode*/ static Exit = 115;
                    /*EventOpcode*/ static ForceRollback = 116;
                    /*EventOpcode*/ static Incomplete = 117;
                    /*EventOpcode*/ static InDoubt = 118;
                    /*EventOpcode*/ static InternalError = 119;
                    /*EventOpcode*/ static InvalidOperation = 120;
                    /*EventOpcode*/ static NestedIncorrectly = 121;
                    /*EventOpcode*/ static Prepared = 122;
                    /*EventOpcode*/ static Promoted = 123;
                    /*EventOpcode*/ static RecoveryComplete = 124;
                    /*EventOpcode*/ static Reenlist = 125;
                    /*EventOpcode*/ static Rollback = 126;
                    /*EventOpcode*/ static Serialized = 127;
                    /*EventOpcode*/ static Timeout = 128;
                    /*EventOpcode*/ static CallbackPositive = 129;
                    /*EventOpcode*/ static CallbackNegative = 130;
                    static $h = 5547269;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":41156609,"n":"Aborted","d":5547269,"h":4300514565,"f":33},{"t":41156609,"n":"Activity","d":5547269,"h":8595481861,"f":33},{"t":41156609,"n":"Adjusted","d":5547269,"h":12890449157,"f":33},{"t":41156609,"n":"CloneCreate","d":5547269,"h":17185416453,"f":33},{"t":41156609,"n":"Commit","d":5547269,"h":21480383749,"f":33},{"t":41156609,"n":"Committed","d":5547269,"h":25775351045,"f":33},{"t":41156609,"n":"Create","d":5547269,"h":30070318341,"f":33},{"t":41156609,"n":"Created","d":5547269,"h":34365285637,"f":33},{"t":41156609,"n":"CurrentChanged","d":5547269,"h":38660252933,"f":33},{"t":41156609,"n":"DependentCloneComplete","d":5547269,"h":42955220229,"f":33},{"t":41156609,"n":"Disposed","d":5547269,"h":47250187525,"f":33},{"t":41156609,"n":"Done","d":5547269,"h":51545154821,"f":33},{"t":41156609,"n":"Enlist","d":5547269,"h":55840122117,"f":33},{"t":41156609,"n":"Enter","d":5547269,"h":60135089413,"f":33},{"t":41156609,"n":"ExceptionConsumed","d":5547269,"h":64430056709,"f":33},{"t":41156609,"n":"Exit","d":5547269,"h":68725024005,"f":33},{"t":41156609,"n":"ForceRollback","d":5547269,"h":73019991301,"f":33},{"t":41156609,"n":"Incomplete","d":5547269,"h":77314958597,"f":33},{"t":41156609,"n":"InDoubt","d":5547269,"h":81609925893,"f":33},{"t":41156609,"n":"InternalError","d":5547269,"h":85904893189,"f":33},{"t":41156609,"n":"InvalidOperation","d":5547269,"h":90199860485,"f":33},{"t":41156609,"n":"NestedIncorrectly","d":5547269,"h":94494827781,"f":33},{"t":41156609,"n":"Prepared","d":5547269,"h":98789795077,"f":33},{"t":41156609,"n":"Promoted","d":5547269,"h":103084762373,"f":33},{"t":41156609,"n":"RecoveryComplete","d":5547269,"h":107379729669,"f":33},{"t":41156609,"n":"Reenlist","d":5547269,"h":111674696965,"f":33},{"t":41156609,"n":"Rollback","d":5547269,"h":115969664261,"f":33},{"t":41156609,"n":"Serialized","d":5547269,"h":120264631557,"f":33},{"t":41156609,"n":"Timeout","d":5547269,"h":124559598853,"f":33},{"t":41156609,"n":"CallbackPositive","d":5547269,"h":128854566149,"f":33},{"t":41156609,"n":"CallbackNegative","d":5547269,"h":133149533445,"f":33}],"d":5416197,"h":5547269}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Transactions.TransactionsEtwProvider.Opcodes`; }
                }, $cls, ($v) => $cls.$_Opcodes = $v);
            }
            static $_Tasks;
            static get Tasks()
            {
                let $cls = $.$stl.System.Transactions.TransactionsEtwProvider;
                return $cls.$_Tasks ??= $asm.$ncls("$stl.System.Transactions.TransactionsEtwProvider.Tasks", ($self) => class Tasks
                {
                    /*EventTask*/ static ConfiguredDefaultTimeout = 1;
                    /*EventTask*/ static Enlistment = 2;
                    /*EventTask*/ static ResourceManager = 3;
                    /*EventTask*/ static Method = 4;
                    /*EventTask*/ static Transaction = 5;
                    /*EventTask*/ static TransactionException = 6;
                    /*EventTask*/ static TransactionManager = 7;
                    /*EventTask*/ static TransactionScope = 8;
                    /*EventTask*/ static TransactionState = 9;
                    static $h = 5612805;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":42598401,"n":"ConfiguredDefaultTimeout","d":5612805,"h":4300580101,"f":33},{"t":42598401,"n":"Enlistment","d":5612805,"h":8595547397,"f":33},{"t":42598401,"n":"ResourceManager","d":5612805,"h":12890514693,"f":33},{"t":42598401,"n":"Method","d":5612805,"h":17185481989,"f":33},{"t":42598401,"n":"Transaction","d":5612805,"h":21480449285,"f":33},{"t":42598401,"n":"TransactionManager","d":5612805,"h":30070383877,"f":33},{"t":42598401,"n":"TransactionScope","d":5612805,"h":34365351173,"f":33},{"t":42598401,"n":"TransactionState","d":5612805,"h":38660318469,"f":33}],"d":5416197,"h":5612805}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Transactions.TransactionsEtwProvider.Tasks`; }
                }, $cls, ($v) => $cls.$_Tasks = $v);
            }
            static $_Keywords;
            static get Keywords()
            {
                let $cls = $.$stl.System.Transactions.TransactionsEtwProvider;
                return $cls.$_Keywords ??= $asm.$ncls("$stl.System.Transactions.TransactionsEtwProvider.Keywords", ($self) => class Keywords
                {
                    /*EventKeywords*/ static TraceBase = 1n;
                    /*EventKeywords*/ static TraceLtm = 2n;
                    /*EventKeywords*/ static TraceOleTx = 4n;
                    static $h = 5481733;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":40894465,"n":"TraceBase","d":5481733,"h":4300449029,"f":33},{"t":40894465,"n":"TraceLtm","d":5481733,"h":8595416325,"f":33},{"t":40894465,"n":"TraceOleTx","d":5481733,"h":12890383621,"f":33}],"d":5416197,"h":5481733}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Transactions.TransactionsEtwProvider.Keywords`; }
                }, $cls, ($v) => $cls.$_Keywords = $v);
            }
            static /*void */ SetActivityId(/*string*/ str)
            {
                /*Guid*/ let guid = $.$spc.System.Guid.Empty;
                if ($.$spc.System.String.Contains$2.call(str, /*-*/ 45))
                {
                    if (str.length >= 36)
                    {
                        $.$spc.System.Guid.TryParse$1($.$spc.System.MemoryExtensions.AsSpan$7(str, 0, 36), $.$ref(() => guid, ($v) => guid = $v, $.$spc.System.Guid));
                    }
                }
                else 
                {
                    if (str.length >= 32)
                    {
                        $.$spc.System.Guid.TryParse$1($.$spc.System.MemoryExtensions.AsSpan$7(str, 0, 32), $.$ref(() => guid, ($v) => guid = $v, $.$spc.System.Guid));
                    }
                }
                $.$spc.System.Diagnostics.Tracing.EventSource.SetCurrentThreadActivityId(guid);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Log = new $.$stl.System.Transactions.TransactionsEtwProvider().$ctor$8();
                }
                {
                    this.NullInstance = "(null)";
                }
            }
            static $h = 5416197;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":41746433,"m":[{"r":1310721,"p":[{"n":"value","p":131073}],"n":"IdOf","d":5416197,"h":266293388549,"f":33,"a":[{"t":44302337,"c":4339269633}]},{"r":655361,"p":[{"n":"value","p":131073}],"n":"GetHashCode","o":"@$1","d":5416197,"h":270588355845,"f":33,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"traceSource","p":4236549},{"n":"txTraceId","p":8561925},{"n":"type","p":1310721}],"n":"TransactionCreated","d":5416197,"h":274883323141,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"transactionIdentifier","p":1310721},{"n":"type","p":1310721}],"n":"TransactionCreatedLtm","d":5416197,"h":279178290437,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":21,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":4,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":106,"t":41156609},{"n":"Message","v":"Transaction Created (LTM). ID is {0}, type is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionIdentifier","p":1310721},{"n":"type","p":1310721}],"n":"TransactionCreatedOleTx","d":5416197,"h":283473257733,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":51,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40894465},{"n":"Level","v":4,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":106,"t":41156609},{"n":"Message","v":"Transaction Created (OLETX). ID is {0}, type is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"transaction","p":4302085},{"n":"type","p":1310721}],"n":"TransactionCloneCreate","d":5416197,"h":287768225029,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"transactionIdentifier","p":1310721},{"n":"type","p":1310721}],"n":"TransactionCloneCreate","o":"@$1","d":5416197,"h":292063192325,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":18,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":4,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":103,"t":41156609},{"n":"Message","v":"Transaction Clone Created. ID is {0}, type is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionTraceId","p":8561925}],"n":"TransactionSerialized","d":5416197,"h":296358159621,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"transactionIdentifier","p":1310721}],"n":"TransactionSerialized","o":"@$1","d":5416197,"h":300653126917,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":29,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40894465},{"n":"Level","v":4,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":127,"t":41156609},{"n":"Message","v":"Transaction Serialized. ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionTraceId","p":8561925}],"n":"TransactionDeserialized","d":5416197,"h":304948094213,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"transactionIdentifier","p":1310721}],"n":"TransactionDeserialized","o":"@$1","d":5416197,"h":309243061509,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":50,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40894465},{"n":"Level","v":5,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":127,"t":41156609},{"n":"Message","v":"Transaction Deserialized. ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"traceSource","p":4236549},{"n":"type","p":4629765},{"n":"message","p":1310721},{"n":"innerExceptionStr","p":1310721}],"n":"TransactionExceptionTrace","d":5416197,"h":313538028805,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"type","p":4629765},{"n":"message","p":1310721},{"n":"innerExceptionStr","p":1310721}],"n":"TransactionExceptionTrace","o":"@$1","d":5416197,"h":317832996101,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"type","p":1310721},{"n":"message","p":1310721},{"n":"innerExceptionStr","p":1310721}],"n":"TransactionExceptionBase","d":5416197,"h":322127963397,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":24,"t":655361}],"n":[{"n":"Keywords","v":1,"t":40894465},{"n":"Level","v":2,"t":40960001},{"n":"Task","v":6,"t":42598401},{"n":"Message","v":"Transaction Exception. Type is {0}, message is {1}, InnerException is {2}","t":1310721}]}]},{"r":65537,"p":[{"n":"type","p":1310721},{"n":"message","p":1310721},{"n":"innerExceptionStr","p":1310721}],"n":"TransactionExceptionLtm","d":5416197,"h":326422930693,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":23,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":2,"t":40960001},{"n":"Task","v":6,"t":42598401},{"n":"Message","v":"Transaction Exception. Type is {0}, message is {1}, InnerException is {2}","t":1310721}]}]},{"r":65537,"p":[{"n":"type","p":1310721},{"n":"operation","p":1310721}],"n":"InvalidOperation","d":5416197,"h":330717897989,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"transactionIdentifier","p":1310721},{"n":"type","p":1310721},{"n":"operation","p":1310721}],"n":"TransactionInvalidOperation","d":5416197,"h":335012865285,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":26,"t":655361}],"n":[{"n":"Keywords","v":1,"t":40894465},{"n":"Level","v":2,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":120,"t":41156609},{"n":"Message","v":"Transaction Invalid Operation. ID is {0}, type is {1} and operation is {2}","t":1310721}]}]},{"r":65537,"p":[{"n":"traceSource","p":4236549},{"n":"txTraceId","p":8561925},{"n":"type","p":1310721}],"n":"TransactionRollback","d":5416197,"h":339307832581,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"transactionIdentifier","p":1310721},{"n":"type","p":1310721}],"n":"TransactionRollbackLtm","d":5416197,"h":343602799877,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":28,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":3,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":126,"t":41156609},{"n":"Message","v":"Transaction LTM Rollback. ID is {0}, type is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionIdentifier","p":1310721},{"n":"type","p":1310721}],"n":"TransactionRollbackOleTx","d":5416197,"h":347897767173,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":42,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40894465},{"n":"Level","v":3,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":126,"t":41156609},{"n":"Message","v":"Transaction OleTx Rollback. ID is {0}, type is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"traceSource","p":4236549},{"n":"txTraceId","p":8561925},{"n":"option","p":1090821}],"n":"TransactionDependentCloneCreate","d":5416197,"h":352192734469,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"transactionIdentifier","p":1310721},{"n":"option","p":1310721}],"n":"TransactionDependentCloneCreateLtm","d":5416197,"h":356487701765,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":48,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":4,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":109,"t":41156609},{"n":"Message","v":"Transaction Dependent Clone Created (LTM). ID is {0}, option is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionIdentifier","p":1310721},{"n":"option","p":1310721}],"n":"TransactionDependentCloneCreateOleTx","d":5416197,"h":360782669061,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":49,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40894465},{"n":"Level","v":4,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":109,"t":41156609},{"n":"Message","v":"Transaction Dependent Clone Created (OLETX). ID is {0}, option is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"traceSource","p":4236549},{"n":"txTraceId","p":8561925},{"n":"type","p":1310721}],"n":"TransactionDependentCloneComplete","d":5416197,"h":365077636357,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"transactionIdentifier","p":1310721},{"n":"type","p":1310721}],"n":"TransactionDependentCloneCompleteLtm","d":5416197,"h":369372603653,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":22,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":4,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":109,"t":41156609},{"n":"Message","v":"Transaction Dependent Clone Completed (LTM). ID is {0}, type is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionIdentifier","p":1310721},{"n":"type","p":1310721}],"n":"TransactionDependentCloneCompleteOleTx","d":5416197,"h":373667570949,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":47,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40894465},{"n":"Level","v":4,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":109,"t":41156609},{"n":"Message","v":"Transaction Dependent Clone Completed (OLETX). ID is {0}, type is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"traceSource","p":4236549},{"n":"txTraceId","p":8561925},{"n":"type","p":1310721}],"n":"TransactionCommit","d":5416197,"h":377962538245,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"transactionIdentifier","p":1310721},{"n":"type","p":1310721}],"n":"TransactionCommitLtm","d":5416197,"h":382257505541,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":19,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":5,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":104,"t":41156609},{"n":"Message","v":"Transaction LTM Commit: ID is {0}, type is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionIdentifier","p":1310721},{"n":"type","p":1310721}],"n":"TransactionCommitOleTx","d":5416197,"h":386552472837,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":41,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40894465},{"n":"Level","v":5,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":104,"t":41156609},{"n":"Message","v":"Transaction OleTx Commit: ID is {0}, type is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"traceSource","p":4236549},{"n":"enlistmentTraceId","p":2073861},{"n":"notificationCall","p":3319045}],"n":"EnlistmentStatus","d":5416197,"h":390847440133,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"enlistmentIdentifier","p":655361},{"n":"notificationCall","p":1310721}],"n":"EnlistmentStatusLtm","d":5416197,"h":395142407429,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":5,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":5,"t":40960001},{"n":"Task","v":2,"t":42598401},{"n":"Message","v":"Enlistment status (LTM): ID is {0}, notificationcall is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"enlistmentIdentifier","p":655361},{"n":"notificationCall","p":1310721}],"n":"EnlistmentStatusOleTx","d":5416197,"h":399437374725,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":52,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40894465},{"n":"Level","v":5,"t":40960001},{"n":"Task","v":2,"t":42598401},{"n":"Message","v":"Enlistment status (OLETX): ID is {0}, notificationcall is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"traceSource","p":4236549},{"n":"enlistmentTraceId","p":2073861},{"n":"enlistmentType","p":2139397},{"n":"enlistmentOptions","p":1877253}],"n":"EnlistmentCreated","d":5416197,"h":403732342021,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"enlistmentIdentifier","p":655361},{"n":"enlistmentType","p":1310721},{"n":"enlistmentOptions","p":1310721}],"n":"EnlistmentCreatedLtm","d":5416197,"h":408027309317,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":55,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":4,"t":40960001},{"n":"Task","v":2,"t":42598401},{"n":"Opcode","v":106,"t":41156609},{"n":"Message","v":"Enlistment Created (LTM). ID is {0}, type is {1}, options is {2}","t":1310721}]}]},{"r":65537,"p":[{"n":"enlistmentIdentifier","p":655361},{"n":"enlistmentType","p":1310721},{"n":"enlistmentOptions","p":1310721}],"n":"EnlistmentCreatedOleTx","d":5416197,"h":412322276613,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":56,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40894465},{"n":"Level","v":4,"t":40960001},{"n":"Task","v":2,"t":42598401},{"n":"Opcode","v":106,"t":41156609},{"n":"Message","v":"Enlistment Created (OLETX). ID is {0}, type is {1}, options is {2}","t":1310721}]}]},{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"EnlistmentDone","d":5416197,"h":416617243909,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"enlistmentIdentifier","p":655361}],"n":"EnlistmentDone","o":"@$1","d":5416197,"h":420912211205,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":4,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":5,"t":40960001},{"n":"Task","v":2,"t":42598401},{"n":"Opcode","v":111,"t":41156609},{"n":"Message","v":"Enlistment.Done: ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"EnlistmentPrepared","d":5416197,"h":425207178501,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"enlistmentIdentifier","p":655361}],"n":"EnlistmentPrepared","o":"@$1","d":5416197,"h":429502145797,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":8,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":5,"t":40960001},{"n":"Task","v":2,"t":42598401},{"n":"Opcode","v":122,"t":41156609},{"n":"Message","v":"PreparingEnlistment.Prepared: ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"EnlistmentForceRollback","d":5416197,"h":433797113093,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"enlistmentIdentifier","p":655361}],"n":"EnlistmentForceRollback","o":"@$1","d":5416197,"h":438092080389,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":6,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":3,"t":40960001},{"n":"Task","v":2,"t":42598401},{"n":"Opcode","v":116,"t":41156609},{"n":"Message","v":"Enlistment forceRollback: ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"EnlistmentAborted","d":5416197,"h":442387047685,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"enlistmentIdentifier","p":655361}],"n":"EnlistmentAborted","o":"@$1","d":5416197,"h":446682014981,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":2,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":3,"t":40960001},{"n":"Task","v":2,"t":42598401},{"n":"Opcode","v":100,"t":41156609},{"n":"Message","v":"Enlistment SinglePhase Aborted: ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"EnlistmentCommitted","d":5416197,"h":450976982277,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"enlistmentIdentifier","p":655361}],"n":"EnlistmentCommitted","o":"@$1","d":5416197,"h":455271949573,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":3,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":5,"t":40960001},{"n":"Task","v":2,"t":42598401},{"n":"Opcode","v":105,"t":41156609},{"n":"Message","v":"Enlistment Committed: ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"EnlistmentInDoubt","d":5416197,"h":459566916869,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"enlistmentIdentifier","p":655361}],"n":"EnlistmentInDoubt","o":"@$1","d":5416197,"h":463861884165,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":7,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":3,"t":40960001},{"n":"Task","v":2,"t":42598401},{"n":"Opcode","v":118,"t":41156609},{"n":"Message","v":"Enlistment SinglePhase InDoubt: ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"enlistmentTraceIdentifier","p":2073861},{"n":"callback","p":1811717}],"n":"EnlistmentCallbackPositive","d":5416197,"h":468156851461,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"enlistmentIdentifier","p":655361},{"n":"callback","p":1310721}],"n":"EnlistmentCallbackPositive","o":"@$1","d":5416197,"h":472451818757,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":53,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40894465},{"n":"Level","v":5,"t":40960001},{"n":"Task","v":2,"t":42598401},{"n":"Opcode","v":129,"t":41156609},{"n":"Message","v":"Enlistment callback positive: ID is {0}, callback is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"enlistmentTraceIdentifier","p":2073861},{"n":"callback","p":1811717}],"n":"EnlistmentCallbackNegative","d":5416197,"h":476746786053,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"enlistmentIdentifier","p":655361},{"n":"callback","p":1310721}],"n":"EnlistmentCallbackNegative","o":"@$1","d":5416197,"h":481041753349,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":54,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40894465},{"n":"Level","v":3,"t":40960001},{"n":"Task","v":2,"t":42598401},{"n":"Opcode","v":130,"t":41156609},{"n":"Message","v":"Enlistment callback negative: ID is {0}, callback is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"traceSource","p":4236549},{"n":"thisOrContextObject","p":131073},{"n":"methodname","p":1310721,"f":65,"a":[{"t":88145921,"c":4383113217}]}],"n":"MethodEnter","d":5416197,"h":485336720645,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"traceSource","p":4236549},{"n":"methodname","p":1310721,"f":65,"a":[{"t":88145921,"c":4383113217}]}],"n":"MethodEnter","o":"@$1","d":5416197,"h":489631687941,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"thisOrContextObject","p":1310721},{"n":"methodname","p":1310721}],"n":"MethodEnterTraceLtm","d":5416197,"h":493926655237,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":11,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":5,"t":40960001},{"n":"Task","v":4,"t":42598401},{"n":"Opcode","v":113,"t":41156609},{"n":"Message","v":"Enter method : {0}.{1}","t":1310721}]}]},{"r":65537,"p":[{"n":"thisOrContextObject","p":1310721},{"n":"methodname","p":1310721}],"n":"MethodEnterTraceBase","d":5416197,"h":498221622533,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":13,"t":655361}],"n":[{"n":"Keywords","v":1,"t":40894465},{"n":"Level","v":5,"t":40960001},{"n":"Task","v":4,"t":42598401},{"n":"Opcode","v":113,"t":41156609},{"n":"Message","v":"Enter method : {0}.{1}","t":1310721}]}]},{"r":65537,"p":[{"n":"thisOrContextObject","p":1310721},{"n":"methodname","p":1310721}],"n":"MethodEnterTraceDistributed","d":5416197,"h":502516589829,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":15,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40894465},{"n":"Level","v":5,"t":40960001},{"n":"Task","v":4,"t":42598401},{"n":"Opcode","v":113,"t":41156609},{"n":"Message","v":"Enter method : {0}.{1}","t":1310721}]}]},{"r":65537,"p":[{"n":"traceSource","p":4236549},{"n":"thisOrContextObject","p":131073},{"n":"methodname","p":1310721,"f":65,"a":[{"t":88145921,"c":4383113217}]}],"n":"MethodExit","d":5416197,"h":506811557125,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"traceSource","p":4236549},{"n":"methodname","p":1310721,"f":65,"a":[{"t":88145921,"c":4383113217}]}],"n":"MethodExit","o":"@$1","d":5416197,"h":511106524421,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"thisOrContextObject","p":1310721},{"n":"methodname","p":1310721}],"n":"MethodExitTraceLtm","d":5416197,"h":515401491717,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":12,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":5,"t":40960001},{"n":"Task","v":4,"t":42598401},{"n":"Opcode","v":115,"t":41156609},{"n":"Message","v":"Exit method: {0}.{1}","t":1310721}]}]},{"r":65537,"p":[{"n":"thisOrContextObject","p":1310721},{"n":"methodname","p":1310721}],"n":"MethodExitTraceBase","d":5416197,"h":519696459013,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":14,"t":655361}],"n":[{"n":"Keywords","v":1,"t":40894465},{"n":"Level","v":5,"t":40960001},{"n":"Task","v":4,"t":42598401},{"n":"Opcode","v":115,"t":41156609},{"n":"Message","v":"Exit method: {0}.{1}","t":1310721}]}]},{"r":65537,"p":[{"n":"thisOrContextObject","p":1310721},{"n":"methodname","p":1310721}],"n":"MethodExitTraceDistributed","d":5416197,"h":523991426309,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":16,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40894465},{"n":"Level","v":5,"t":40960001},{"n":"Task","v":4,"t":42598401},{"n":"Opcode","v":115,"t":41156609},{"n":"Message","v":"Exit method: {0}.{1}","t":1310721}]}]},{"r":65537,"p":[{"n":"traceSource","p":4236549},{"n":"exception","p":47251457}],"n":"ExceptionConsumed","d":5416197,"h":528286393605,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"exception","p":47251457}],"n":"ExceptionConsumed","o":"@$1","d":5416197,"h":532581360901,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"exceptionStr","p":1310721}],"n":"ExceptionConsumedBase","d":5416197,"h":536876328197,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":9,"t":655361}],"n":[{"n":"Keywords","v":1,"t":40894465},{"n":"Level","v":5,"t":40960001},{"n":"Opcode","v":114,"t":41156609},{"n":"Message","v":"Exception consumed: {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"exceptionStr","p":1310721}],"n":"ExceptionConsumedLtm","d":5416197,"h":541171295493,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":10,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":5,"t":40960001},{"n":"Opcode","v":114,"t":41156609},{"n":"Message","v":"Exception consumed: {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"exceptionStr","p":1310721}],"n":"ExceptionConsumedOleTx","d":5416197,"h":545466262789,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":43,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40894465},{"n":"Level","v":5,"t":40960001},{"n":"Opcode","v":114,"t":41156609},{"n":"Message","v":"Exception consumed: {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"tmType","p":142606337},{"n":"nodeName","p":1310721}],"n":"OleTxTransactionManagerCreate","d":5416197,"h":549761230085,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"tmType","p":1310721},{"n":"nodeName","p":1310721}],"n":"OleTxTransactionManagerCreate","o":"@$1","d":5416197,"h":554056197381,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":57,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40894465},{"n":"Level","v":5,"t":40960001},{"n":"Task","v":7,"t":42598401},{"n":"Opcode","v":107,"t":41156609},{"n":"Message","v":"Created OleTx transaction manager, type is {0}, node name is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"resourceManagerID","p":56229889}],"n":"TransactionManagerReenlist","d":5416197,"h":558351164677,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"rmID","p":1310721}],"n":"TransactionManagerReenlistTrace","d":5416197,"h":562646131973,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":32,"t":655361}],"n":[{"n":"Keywords","v":1,"t":40894465},{"n":"Level","v":4,"t":40960001},{"n":"Task","v":7,"t":42598401},{"n":"Opcode","v":125,"t":41156609},{"n":"Message","v":"Reenlist in: {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"resourceManagerID","p":56229889}],"n":"TransactionManagerRecoveryComplete","d":5416197,"h":566941099269,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"rmID","p":1310721}],"n":"TransactionManagerRecoveryComplete","o":"@$1","d":5416197,"h":571236066565,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":31,"t":655361}],"n":[{"n":"Keywords","v":1,"t":40894465},{"n":"Level","v":4,"t":40960001},{"n":"Task","v":7,"t":42598401},{"n":"Opcode","v":124,"t":41156609},{"n":"Message","v":"Recovery complete: {0}","t":1310721}]}]},{"r":65537,"n":"ConfiguredDefaultTimeoutAdjusted","d":5416197,"h":575531033861,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"n":"ConfiguredDefaultTimeoutAdjustedTrace","d":5416197,"h":579826001157,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":1,"t":655361}],"n":[{"n":"Keywords","v":1,"t":40894465},{"n":"Level","v":3,"t":40960001},{"n":"Task","v":1,"t":42598401},{"n":"Opcode","v":102,"t":41156609},{"n":"Message","v":"Configured Default Timeout Adjusted","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionID","p":8561925},{"n":"transactionScopeResult","p":5350661}],"n":"TransactionScopeCreated","d":5416197,"h":584120968453,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"transactionID","p":1310721},{"n":"transactionScopeResult","p":5350661}],"n":"TransactionScopeCreated","o":"@$1","d":5416197,"h":588415935749,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":33,"t":655361}],"n":[{"n":"Keywords","v":1,"t":40894465},{"n":"Level","v":4,"t":40960001},{"n":"Task","v":8,"t":42598401},{"n":"Opcode","v":107,"t":41156609},{"n":"Message","v":"Transactionscope was created: Transaction ID is {0}, TransactionScope Result is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"currenttransactionID","p":8561925},{"n":"newtransactionID","p":8561925}],"n":"TransactionScopeCurrentChanged","d":5416197,"h":592710903045,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"currenttransactionID","p":1310721},{"n":"newtransactionID","p":1310721}],"n":"TransactionScopeCurrentChanged","o":"@$1","d":5416197,"h":597005870341,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":34,"t":655361}],"n":[{"n":"Keywords","v":1,"t":40894465},{"n":"Level","v":3,"t":40960001},{"n":"Task","v":8,"t":42598401},{"n":"Opcode","v":108,"t":41156609},{"n":"Message","v":"Transactionscope current transaction ID changed from {0} to {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionID","p":8561925}],"n":"TransactionScopeNestedIncorrectly","d":5416197,"h":601300837637,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"transactionID","p":1310721}],"n":"TransactionScopeNestedIncorrectly","o":"@$1","d":5416197,"h":605595804933,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":38,"t":655361}],"n":[{"n":"Keywords","v":1,"t":40894465},{"n":"Level","v":3,"t":40960001},{"n":"Task","v":8,"t":42598401},{"n":"Opcode","v":121,"t":41156609},{"n":"Message","v":"Transactionscope nested incorrectly: transaction ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionID","p":8561925}],"n":"TransactionScopeDisposed","d":5416197,"h":609890772229,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"transactionID","p":1310721}],"n":"TransactionScopeDisposed","o":"@$1","d":5416197,"h":614185739525,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":35,"t":655361}],"n":[{"n":"Keywords","v":1,"t":40894465},{"n":"Level","v":4,"t":40960001},{"n":"Task","v":8,"t":42598401},{"n":"Opcode","v":110,"t":41156609},{"n":"Message","v":"Transactionscope disposed: transaction ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionID","p":8561925}],"n":"TransactionScopeIncomplete","d":5416197,"h":618480706821,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"transactionID","p":1310721}],"n":"TransactionScopeIncomplete","o":"@$1","d":5416197,"h":622775674117,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":36,"t":655361}],"n":[{"n":"Keywords","v":1,"t":40894465},{"n":"Level","v":3,"t":40960001},{"n":"Task","v":8,"t":42598401},{"n":"Opcode","v":117,"t":41156609},{"n":"Message","v":"Transactionscope incomplete: transaction ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionID","p":8561925}],"n":"TransactionScopeTimeout","d":5416197,"h":627070641413,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"transactionID","p":1310721}],"n":"TransactionScopeTimeout","o":"@$1","d":5416197,"h":631365608709,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":39,"t":655361}],"n":[{"n":"Keywords","v":1,"t":40894465},{"n":"Level","v":3,"t":40960001},{"n":"Task","v":8,"t":42598401},{"n":"Opcode","v":128,"t":41156609},{"n":"Message","v":"Transactionscope timeout: transaction ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionID","p":8561925}],"n":"TransactionTimeout","d":5416197,"h":635660576005,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"transactionID","p":1310721}],"n":"TransactionTimeout","o":"@$1","d":5416197,"h":639955543301,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":30,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":3,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":128,"t":41156609},{"n":"Message","v":"Transaction timeout: transaction ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"enlistmentID","p":2073861},{"n":"enlistmentType","p":2139397},{"n":"enlistmentOption","p":1877253}],"n":"TransactionstateEnlist","d":5416197,"h":644250510597,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"enlistmentID","p":1310721},{"n":"type","p":1310721},{"n":"option","p":1310721}],"n":"TransactionstateEnlist","o":"@$1","d":5416197,"h":648545477893,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":40,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":4,"t":40960001},{"n":"Task","v":9,"t":42598401},{"n":"Opcode","v":112,"t":41156609},{"n":"Message","v":"Transactionstate enlist: Enlistment ID is {0}, type is {1} and options is {2}","t":1310721}]}]},{"r":65537,"p":[{"n":"traceSource","p":4236549},{"n":"transactionID","p":8561925}],"n":"TransactionCommitted","d":5416197,"h":652840445189,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"transactionID","p":1310721}],"n":"TransactionCommittedLtm","d":5416197,"h":657135412485,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":20,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":5,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":105,"t":41156609},{"n":"Message","v":"Transaction committed LTM: transaction ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionID","p":1310721}],"n":"TransactionCommittedOleTx","d":5416197,"h":661430379781,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":44,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40894465},{"n":"Level","v":5,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":105,"t":41156609},{"n":"Message","v":"Transaction committed OleTx: transaction ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"traceSource","p":4236549},{"n":"transactionID","p":8561925}],"n":"TransactionInDoubt","d":5416197,"h":665725347077,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"transactionID","p":1310721}],"n":"TransactionInDoubtLtm","d":5416197,"h":670020314373,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":25,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":3,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":118,"t":41156609},{"n":"Message","v":"Transaction indoubt LTM: transaction ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionID","p":1310721}],"n":"TransactionInDoubtOleTx","d":5416197,"h":674315281669,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":46,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40894465},{"n":"Level","v":3,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":118,"t":41156609},{"n":"Message","v":"Transaction indoubt OleTx: transaction ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionID","p":8561925},{"n":"distributedTxID","p":8561925}],"n":"TransactionPromoted","d":5416197,"h":678610248965,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"transactionID","p":1310721},{"n":"distributedTxID","p":1310721}],"n":"TransactionPromoted","o":"@$1","d":5416197,"h":682905216261,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":27,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":4,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":123,"t":41156609},{"n":"Message","v":"Transaction promoted: transaction ID is {0} and distributed transaction ID is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"traceSource","p":4236549},{"n":"transactionID","p":8561925}],"n":"TransactionAborted","d":5416197,"h":687200183557,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"transactionID","p":1310721}],"n":"TransactionAbortedLtm","d":5416197,"h":691495150853,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":17,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":3,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":100,"t":41156609},{"n":"Message","v":"Transaction aborted LTM: transaction ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionID","p":1310721}],"n":"TransactionAbortedOleTx","d":5416197,"h":695790118149,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":45,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40894465},{"n":"Level","v":3,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":100,"t":41156609},{"n":"Message","v":"Transaction aborted OleTx: transaction ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"error","p":1310721,"f":65}],"n":"InternalError","d":5416197,"h":700085085445,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"error","p":1310721}],"n":"InternalErrorTrace","d":5416197,"h":704380052741,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":37,"t":655361}],"n":[{"n":"Keywords","v":1,"t":40894465},{"n":"Level","v":1,"t":40960001},{"n":"Task","v":8,"t":42598401},{"n":"Opcode","v":119,"t":41156609},{"n":"Message","v":"Transactionscope internal error: {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"str","p":1310721}],"n":"SetActivityId","d":5416197,"h":721559921925,"f":34}],"l":[{"t":5416197,"n":"Log","d":5416197,"h":4300383493,"f":40},{"t":40894465,"n":"ALL_KEYWORDS","d":5416197,"h":12890318085,"f":34},{"t":655361,"n":"CONFIGURED_DEFAULT_TIMEOUT_ADJUSTED_EVENTID","d":5416197,"h":17185285381,"f":34},{"t":655361,"n":"ENLISTMENT_ABORTED_EVENTID","d":5416197,"h":21480252677,"f":34},{"t":655361,"n":"ENLISTMENT_COMMITTED_EVENTID","d":5416197,"h":25775219973,"f":34},{"t":655361,"n":"ENLISTMENT_DONE_EVENTID","d":5416197,"h":30070187269,"f":34},{"t":655361,"n":"ENLISTMENT_LTM_EVENTID","d":5416197,"h":34365154565,"f":34},{"t":655361,"n":"ENLISTMENT_FORCEROLLBACK_EVENTID","d":5416197,"h":38660121861,"f":34},{"t":655361,"n":"ENLISTMENT_INDOUBT_EVENTID","d":5416197,"h":42955089157,"f":34},{"t":655361,"n":"ENLISTMENT_PREPARED_EVENTID","d":5416197,"h":47250056453,"f":34},{"t":655361,"n":"EXCEPTION_CONSUMED_BASE_EVENTID","d":5416197,"h":51545023749,"f":34},{"t":655361,"n":"EXCEPTION_CONSUMED_LTM_EVENTID","d":5416197,"h":55839991045,"f":34},{"t":655361,"n":"METHOD_ENTER_LTM_EVENTID","d":5416197,"h":60134958341,"f":34},{"t":655361,"n":"METHOD_EXIT_LTM_EVENTID","d":5416197,"h":64429925637,"f":34},{"t":655361,"n":"METHOD_ENTER_BASE_EVENTID","d":5416197,"h":68724892933,"f":34},{"t":655361,"n":"METHOD_EXIT_BASE_EVENTID","d":5416197,"h":73019860229,"f":34},{"t":655361,"n":"METHOD_ENTER_OLETX_EVENTID","d":5416197,"h":77314827525,"f":34},{"t":655361,"n":"METHOD_EXIT_OLETX_EVENTID","d":5416197,"h":81609794821,"f":34},{"t":655361,"n":"TRANSACTION_ABORTED_LTM_EVENTID","d":5416197,"h":85904762117,"f":34},{"t":655361,"n":"TRANSACTION_CLONECREATE_EVENTID","d":5416197,"h":90199729413,"f":34},{"t":655361,"n":"TRANSACTION_COMMIT_LTM_EVENTID","d":5416197,"h":94494696709,"f":34},{"t":655361,"n":"TRANSACTION_COMMITTED_LTM_EVENTID","d":5416197,"h":98789664005,"f":34},{"t":655361,"n":"TRANSACTION_CREATED_LTM_EVENTID","d":5416197,"h":103084631301,"f":34},{"t":655361,"n":"TRANSACTION_DEPENDENT_CLONE_COMPLETE_LTM_EVENTID","d":5416197,"h":107379598597,"f":34},{"t":655361,"n":"TRANSACTION_EXCEPTION_LTM_EVENTID","d":5416197,"h":111674565893,"f":34},{"t":655361,"n":"TRANSACTION_EXCEPTION_BASE_EVENTID","d":5416197,"h":115969533189,"f":34},{"t":655361,"n":"TRANSACTION_INDOUBT_LTM_EVENTID","d":5416197,"h":120264500485,"f":34},{"t":655361,"n":"TRANSACTION_INVALID_OPERATION_EVENTID","d":5416197,"h":124559467781,"f":34},{"t":655361,"n":"TRANSACTION_PROMOTED_EVENTID","d":5416197,"h":128854435077,"f":34},{"t":655361,"n":"TRANSACTION_ROLLBACK_LTM_EVENTID","d":5416197,"h":133149402373,"f":34},{"t":655361,"n":"TRANSACTION_SERIALIZED_EVENTID","d":5416197,"h":137444369669,"f":34},{"t":655361,"n":"TRANSACTION_TIMEOUT_EVENTID","d":5416197,"h":141739336965,"f":34},{"t":655361,"n":"TRANSACTIONMANAGER_RECOVERY_COMPLETE_EVENTID","d":5416197,"h":146034304261,"f":34},{"t":655361,"n":"TRANSACTIONMANAGER_REENLIST_EVENTID","d":5416197,"h":150329271557,"f":34},{"t":655361,"n":"TRANSACTIONSCOPE_CREATED_EVENTID","d":5416197,"h":154624238853,"f":34},{"t":655361,"n":"TRANSACTIONSCOPE_CURRENT_CHANGED_EVENTID","d":5416197,"h":158919206149,"f":34},{"t":655361,"n":"TRANSACTIONSCOPE_DISPOSED_EVENTID","d":5416197,"h":163214173445,"f":34},{"t":655361,"n":"TRANSACTIONSCOPE_INCOMPLETE_EVENTID","d":5416197,"h":167509140741,"f":34},{"t":655361,"n":"INTERNAL_ERROR_EVENTID","d":5416197,"h":171804108037,"f":34},{"t":655361,"n":"TRANSACTIONSCOPE_NESTED_INCORRECTLY_EVENTID","d":5416197,"h":176099075333,"f":34},{"t":655361,"n":"TRANSACTIONSCOPE_TIMEOUT_EVENTID","d":5416197,"h":180394042629,"f":34},{"t":655361,"n":"TRANSACTIONSTATE_ENLIST_EVENTID","d":5416197,"h":184689009925,"f":34},{"t":655361,"n":"TRANSACTION_COMMIT_OLETX_EVENTID","d":5416197,"h":188983977221,"f":34},{"t":655361,"n":"TRANSACTION_ROLLBACK_OLETX_EVENTID","d":5416197,"h":193278944517,"f":34},{"t":655361,"n":"EXCEPTION_CONSUMED_OLETX_EVENTID","d":5416197,"h":197573911813,"f":34},{"t":655361,"n":"TRANSACTION_COMMITTED_OLETX_EVENTID","d":5416197,"h":201868879109,"f":34},{"t":655361,"n":"TRANSACTION_ABORTED_OLETX_EVENTID","d":5416197,"h":206163846405,"f":34},{"t":655361,"n":"TRANSACTION_INDOUBT_OLETX_EVENTID","d":5416197,"h":210458813701,"f":34},{"t":655361,"n":"TRANSACTION_DEPENDENT_CLONE_COMPLETE_OLETX_EVENTID","d":5416197,"h":214753780997,"f":34},{"t":655361,"n":"TRANSACTION_DEPENDENT_CLONE_CREATE_LTM_EVENTID","d":5416197,"h":219048748293,"f":34},{"t":655361,"n":"TRANSACTION_DEPENDENT_CLONE_CREATE_OLETX_EVENTID","d":5416197,"h":223343715589,"f":34},{"t":655361,"n":"TRANSACTION_DESERIALIZED_EVENTID","d":5416197,"h":227638682885,"f":34},{"t":655361,"n":"TRANSACTION_CREATED_OLETX_EVENTID","d":5416197,"h":231933650181,"f":34},{"t":655361,"n":"ENLISTMENT_OLETX_EVENTID","d":5416197,"h":236228617477,"f":34},{"t":655361,"n":"ENLISTMENT_CALLBACK_POSITIVE_EVENTID","d":5416197,"h":240523584773,"f":34},{"t":655361,"n":"ENLISTMENT_CALLBACK_NEGATIVE_EVENTID","d":5416197,"h":244818552069,"f":34},{"t":655361,"n":"ENLISTMENT_CREATED_LTM_EVENTID","d":5416197,"h":249113519365,"f":34},{"t":655361,"n":"ENLISTMENT_CREATED_OLETX_EVENTID","d":5416197,"h":253408486661,"f":34},{"t":655361,"n":"TRANSACTIONMANAGER_CREATE_OLETX_EVENTID","d":5416197,"h":257703453957,"f":34},{"t":1310721,"n":"NullInstance","d":5416197,"h":261998421253,"f":34}],"c":[{"n":".ctor","o":"$ctor$8","d":5416197,"h":8595350789,"f":2}],"i":[57540609],"j":[5547269,5612805,5481733],"h":5416197,"a":[{"t":42074113,"c":55876648961,"n":[{"n":"Name","v":"System.Transactions.TransactionsEventSource","t":1310721},{"n":"Guid","v":"8ac2d80a-1f1a-431b-ace4-bff8824aef0b","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Diagnostics.Tracing.EventSource; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Transactions.TransactionsEtwProvider`; }
        });
        
        $asm.$cls("$stl.System.Transactions.DependentTransaction", ($self) => class DependentTransaction extends $.$stl.System.Transactions.Transaction
        {
            /*bool*/ _blocking = false;
            $ctor$5(/*IsolationLevel*/ isoLevel, /*InternalTransaction*/ internalTransaction, /*bool*/ blocking)
            {
                super.$ctor$2(isoLevel, internalTransaction);
                {
                    this._blocking = blocking;
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                            if (blocking)
                            {
                                this._internalTransaction.State.CreateBlockingClone(this._internalTransaction);
                            }
                            else 
                            {
                                this._internalTransaction.State.CreateAbortingClone(this._internalTransaction);
                            }
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                    }
                }
                return this;
            }
            /*void */ Complete()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "Complete");
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                    {
                        $.$spc.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                        if (this._complete)
                        {
                            throw $.$stl.System.Transactions.TransactionException.CreateTransactionCompletedException(this.DistributedTxId);
                        }
                        this._complete = true;
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        if (this._blocking)
                        {
                            this._internalTransaction.State.CompleteBlockingClone(this._internalTransaction);
                        }
                        else 
                        {
                            this._internalTransaction.State.CompleteAbortingClone(this._internalTransaction);
                        }
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionDependentCloneComplete(1/*TraceSourceType.TraceSourceLtm*/, this.TransactionTraceId, "DependentTransaction");
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "Complete");
                }
            }
            static $h = 1156357;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":4302085,"m":[{"r":65537,"n":"Complete","d":1156357,"h":12886058245,"f":1}],"l":[{"t":262145,"n":"_blocking","d":1156357,"h":4296123653,"f":2}],"c":[{"p":[{"n":"isoLevel","p":3187973},{"n":"internalTransaction","p":2794757},{"n":"blocking","p":262145}],"n":".ctor","o":"$ctor$5","d":1156357,"h":8591090949,"f":8}],"i":[57540609,113377281],"h":1156357}; }
            static get $b() { return $.$stl.System.Transactions.Transaction; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Transactions.DependentTransaction`; }
        });
        
        $asm.$cls("$stl.System.Transactions.SubordinateTransaction", ($self) => class SubordinateTransaction extends $.$stl.System.Transactions.Transaction
        {
            $ctor$5(/*IsolationLevel*/ isoLevel, /*ISimpleTransactionSuperior*/ superior)
            {
                super.$ctor$4(isoLevel, superior);
                {
                }
                return this;
            }
            static $h = 4171013;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":4302085,"c":[{"p":[{"n":"isoLevel","p":3187973},{"n":"superior","p":2991365}],"n":".ctor","o":"$ctor$5","d":4171013,"h":4299138309,"f":1}],"i":[57540609,113377281],"h":4171013}; }
            static get $b() { return $.$stl.System.Transactions.Transaction; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Transactions.SubordinateTransaction`; }
        });
        
        $asm.$cls("$stl.System.Transactions.DurableInternalEnlistment", ($self) => class DurableInternalEnlistment extends $.$stl.System.Transactions.InternalEnlistment
        {
            /*Guid*/ _resourceManagerIdentifier;
            $ctor$5(/*Enlistment*/ enlistment, /*Guid*/ resourceManagerIdentifier, /*InternalTransaction*/ transaction, /*IEnlistmentNotification*/ twoPhaseNotifications, /*ISinglePhaseNotification?*/ singlePhaseNotifications, /*Transaction*/ atomicTransaction)
            {
                super.$ctor$3(enlistment, transaction, twoPhaseNotifications, singlePhaseNotifications, atomicTransaction);
                {
                    this._resourceManagerIdentifier = resourceManagerIdentifier;
                }
                return this;
            }
            $ctor$6(/*Enlistment*/ enlistment, /*IEnlistmentNotification*/ twoPhaseNotifications)
            {
                super.$ctor$1(enlistment, twoPhaseNotifications);
                {
                }
                return this;
            }
            /*Guid */ get ResourceManagerIdentifier()
            {
                return this._resourceManagerIdentifier;
            }
            //default member initializer
            constructor()
            {
                super();
                this._resourceManagerIdentifier = $.$default($.$spc.System.Guid);
            }
            static $h = 1615109;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2729221,"p":[{"p":56229889,"g":{"r":0,"d":0,"h":21476451589,"f":32776},"n":"ResourceManagerIdentifier","d":1615109,"h":17181484293,"f":32776}],"l":[{"t":56229889,"n":"_resourceManagerIdentifier","d":1615109,"h":4296582405,"f":8}],"c":[{"p":[{"n":"enlistment","p":1746181},{"n":"resourceManagerIdentifier","p":56229889},{"n":"transaction","p":2794757},{"n":"twoPhaseNotifications","p":2598149},{"n":"singlePhaseNotifications","p":3056901},{"n":"atomicTransaction","p":4302085}],"n":".ctor","o":"$ctor$5","d":1615109,"h":8591549701,"f":8},{"p":[{"n":"enlistment","p":1746181},{"n":"twoPhaseNotifications","p":2598149}],"n":".ctor","o":"$ctor$6","d":1615109,"h":12886516997,"f":4}],"i":[3122437,2663685],"h":1615109}; }
            static get $b() { return $.$stl.System.Transactions.InternalEnlistment; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stl.System.Transactions.ISinglePhaseNotificationInternal, $.$stl.System.Transactions.IEnlistmentNotificationInternal ]; }
            static get $fullName() { return `System.Transactions.DurableInternalEnlistment`; }
        });
        
        $asm.$cls("$stl.System.Transactions.PromotableInternalEnlistment", ($self) => class PromotableInternalEnlistment extends $.$stl.System.Transactions.InternalEnlistment
        {
            /*IPromotableSinglePhaseNotification*/ _promotableNotificationInterface = null;
            $ctor$5(/*Enlistment*/ enlistment, /*InternalTransaction*/ transaction, /*IPromotableSinglePhaseNotification*/ promotableSinglePhaseNotification, /*Transaction*/ atomicTransaction)
            {
                super.$ctor$2(enlistment, transaction, atomicTransaction);
                {
                    this._promotableNotificationInterface = promotableSinglePhaseNotification;
                }
                return this;
            }
            /*IPromotableSinglePhaseNotification */ get PromotableSinglePhaseNotification()
            {
                return this._promotableNotificationInterface;
            }
            static $h = 3974405;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2729221,"p":[{"p":2860293,"g":{"r":0,"d":0,"h":17183843589,"f":32776},"n":"PromotableSinglePhaseNotification","d":3974405,"h":12888876293,"f":32776}],"l":[{"t":2860293,"n":"_promotableNotificationInterface","d":3974405,"h":4298941701,"f":2}],"c":[{"p":[{"n":"enlistment","p":1746181},{"n":"transaction","p":2794757},{"n":"promotableSinglePhaseNotification","p":2860293},{"n":"atomicTransaction","p":4302085}],"n":".ctor","o":"$ctor$5","d":3974405,"h":8593908997,"f":8}],"i":[3122437,2663685],"h":3974405}; }
            static get $b() { return $.$stl.System.Transactions.InternalEnlistment; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stl.System.Transactions.ISinglePhaseNotificationInternal, $.$stl.System.Transactions.IEnlistmentNotificationInternal ]; }
            static get $fullName() { return `System.Transactions.PromotableInternalEnlistment`; }
        });
        
        $asm.$cls("$stl.System.Transactions.Phase1VolatileEnlistment", ($self) => class Phase1VolatileEnlistment extends $.$stl.System.Transactions.InternalEnlistment
        {
            $ctor$5(/*Enlistment*/ enlistment, /*InternalTransaction*/ transaction, /*IEnlistmentNotification*/ twoPhaseNotifications, /*ISinglePhaseNotification?*/ singlePhaseNotifications, /*Transaction*/ atomicTransaction)
            {
                super.$ctor$3(enlistment, transaction, twoPhaseNotifications, singlePhaseNotifications, atomicTransaction);
                {
                }
                return this;
            }
            /*void */ FinishEnlistment()
            {
                this._transaction._phase1Volatiles._preparedVolatileEnlistments++;
                this.CheckComplete();
            }
            /*void */ CheckComplete()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._transaction._phase1Volatiles._preparedVolatileEnlistments <= ((this._transaction._phase1Volatiles._volatileEnlistmentCount + this._transaction._phase1Volatiles._dependentClones) | 0), "_transaction._phase1Volatiles._preparedVolatileEnlistments <=\r\n                _transaction._phase1Volatiles._volatileEnlistmentCount +\r\n                _transaction._phase1Volatiles._dependentClones");
                if (this._transaction._phase1Volatiles._preparedVolatileEnlistments === ((this._transaction._phase1Volatiles._volatileEnlistmentCount + this._transaction._phase1Volatiles._dependentClones) | 0))
                {
                    this._transaction.State.Phase1VolatilePrepareDone(this._transaction);
                }
            }
            static $h = 3843333;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2729221,"m":[{"r":65537,"n":"FinishEnlistment","d":3843333,"h":8593777925,"f":32776},{"r":65537,"n":"CheckComplete","d":3843333,"h":12888745221,"f":32776}],"c":[{"p":[{"n":"enlistment","p":1746181},{"n":"transaction","p":2794757},{"n":"twoPhaseNotifications","p":2598149},{"n":"singlePhaseNotifications","p":3056901},{"n":"atomicTransaction","p":4302085}],"n":".ctor","o":"$ctor$5","d":3843333,"h":4298810629,"f":1}],"i":[3122437,2663685],"h":3843333}; }
            static get $b() { return $.$stl.System.Transactions.InternalEnlistment; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stl.System.Transactions.ISinglePhaseNotificationInternal, $.$stl.System.Transactions.IEnlistmentNotificationInternal ]; }
            static get $fullName() { return `System.Transactions.Phase1VolatileEnlistment`; }
        });
        
        $asm.$cls("$stl.System.Transactions.CommittableTransaction", ($self) => class CommittableTransaction extends $.$stl.System.Transactions.Transaction
        {
            $ctor$5()
            {
                this.$ctor$8($.$stl.System.Transactions.TransactionManager.DefaultIsolationLevel, $.$stl.System.Transactions.TransactionManager.DefaultTimeout);
                {
                }
                return this;
            }
            $ctor$6(/*TimeSpan*/ timeout)
            {
                this.$ctor$8($.$stl.System.Transactions.TransactionManager.DefaultIsolationLevel, timeout);
                {
                }
                return this;
            }
            $ctor$7(/*TransactionOptions*/ options)
            {
                this.$ctor$8(options.IsolationLevel, options.Timeout);
                {
                }
                return this;
            }
            $ctor$8(/*IsolationLevel*/ isoLevel, /*TimeSpan*/ timeout)
            {
                super.$ctor$2(isoLevel, null);
                {
                    this._internalTransaction = new $.$stl.System.Transactions.InternalTransaction().$ctor$1(timeout, this);
                    this._internalTransaction._cloneCount = 1;
                    this._cloneId = 1;
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.TransactionCreated(1/*TraceSourceType.TraceSourceLtm*/, this.TransactionTraceId, "CommittableTransaction");
                    }
                }
                return this;
            }
            /*IAsyncResult */ BeginCommit(/*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "BeginCommit");
                    etwLog.TransactionCommit(1/*TraceSourceType.TraceSourceLtm*/, this.TransactionTraceId, "CommittableTransaction");
                }
                $.$spc.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                    {
                        if (this._complete)
                        {
                            throw $.$stl.System.Transactions.TransactionException.CreateTransactionCompletedException(this.DistributedTxId);
                        }
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        this._internalTransaction.State.BeginCommit(this._internalTransaction, true, asyncCallback, asyncState);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "BeginCommit");
                }
                return this;
            }
            /*void */ Commit()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "Commit");
                    etwLog.TransactionCommit(1/*TraceSourceType.TraceSourceLtm*/, this.TransactionTraceId, "CommittableTransaction");
                }
                $.$spc.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                    {
                        if (this._complete)
                        {
                            throw $.$stl.System.Transactions.TransactionException.CreateTransactionCompletedException(this.DistributedTxId);
                        }
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        this._internalTransaction.State.BeginCommit(this._internalTransaction, false, null, null);
                        do
                        {
                            if (this._internalTransaction.State.IsCompleted(this._internalTransaction))
                            {
                                break;
                            }
                        }
                        while($.$spc.System.Threading.Monitor.Wait$2(this._internalTransaction));
                        this._internalTransaction.State.EndCommit(this._internalTransaction);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "Commit");
                }
            }
            /*void */ InternalDispose()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "InternalDispose");
                }
                if ($.$spc.System.Threading.Interlocked.Exchange($.$ref(() => this._disposed, ($v) => this._disposed = $v, $.$spc.System.Int32), 1/*Transaction._disposedTrueValue*/) === 1/*Transaction._disposedTrueValue*/)
                {
                    return;
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                if (this._internalTransaction.State.get_Status(this._internalTransaction) === 0/*TransactionStatus.Active*/)
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                        {
                            this._internalTransaction.State.DisposeRoot(this._internalTransaction);
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                    }
                }
                /*long*/ let remainingITx = BigInt($.$spc.System.Threading.Interlocked.Decrement($.$ref(() => this._internalTransaction._cloneCount, ($v) => this._internalTransaction._cloneCount = $v, $.$spc.System.Int32)));
                if (remainingITx === 0n)
                {
                    this._internalTransaction.Dispose();
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "InternalDispose");
                }
            }
            /*void */ EndCommit(/*IAsyncResult*/ asyncResult)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "EndCommit");
                }
                if (asyncResult !== ($.$cast(this, $.$spc.System.Object)))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$stl.System.SR.BadAsyncResult, "asyncResult");
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                    {
                        do
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                            if (this._internalTransaction.State.IsCompleted(this._internalTransaction))
                            {
                                break;
                            }
                        }
                        while($.$spc.System.Threading.Monitor.Wait$2(this._internalTransaction));
                        this._internalTransaction.State.EndCommit(this._internalTransaction);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "EndCommit");
                }
            }
            /*object? */ get System$IAsyncResult$AsyncState()
            {
                return this._internalTransaction._asyncState;
            }
            /*bool */ get System$IAsyncResult$CompletedSynchronously()
            {
                return false;
            }
            /*WaitHandle */ get System$IAsyncResult$AsyncWaitHandle()
            {
                if (this._internalTransaction._asyncResultEvent === null)
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                        {
                            if (this._internalTransaction._asyncResultEvent === null)
                            {
                                $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                                /*ManualResetEvent*/ let temp = new $.$spc.System.Threading.ManualResetEvent().$ctor$8(this._internalTransaction.State.get_Status(this._internalTransaction) !== 0/*TransactionStatus.Active*/);
                                this._internalTransaction._asyncResultEvent = temp;
                            }
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                    }
                }
                return this._internalTransaction._asyncResultEvent;
            }
            /*bool */ get System$IAsyncResult$IsCompleted()
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        return this._internalTransaction.State.get_Status(this._internalTransaction) !== 0/*TransactionStatus.Active*/;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                }
            }
            static $h = 566533;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":4302085,"p":[{"p":131073,"g":{"r":0,"d":0,"h":42950239493,"f":2},"n":"{57016321}.AsyncState","o":"System$IAsyncResult$AsyncState","d":566533,"h":38655272197,"f":2},{"p":262145,"g":{"r":0,"d":0,"h":51540174085,"f":2},"n":"{57016321}.CompletedSynchronously","o":"System$IAsyncResult$CompletedSynchronously","d":566533,"h":47245206789,"f":2},{"p":139132929,"g":{"r":0,"d":0,"h":60130108677,"f":2},"n":"{57016321}.AsyncWaitHandle","o":"System$IAsyncResult$AsyncWaitHandle","d":566533,"h":55835141381,"f":2},{"p":262145,"g":{"r":0,"d":0,"h":68720043269,"f":2},"n":"{57016321}.IsCompleted","o":"System$IAsyncResult$IsCompleted","d":566533,"h":64425075973,"f":2}],"m":[{"r":57016321,"p":[{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":566533,"h":21475403013,"f":1},{"r":65537,"n":"Commit","d":566533,"h":25770370309,"f":1},{"r":65537,"n":"InternalDispose","d":566533,"h":30065337605,"f":32776},{"r":65537,"p":[{"n":"asyncResult","p":57016321}],"n":"EndCommit","d":566533,"h":34360304901,"f":1}],"c":[{"n":".ctor","o":"$ctor$5","d":566533,"h":4295533829,"f":1},{"p":[{"n":"timeout","p":140705793}],"n":".ctor","o":"$ctor$6","d":566533,"h":8590501125,"f":1},{"p":[{"n":"options","p":5022981}],"n":".ctor","o":"$ctor$7","d":566533,"h":12885468421,"f":1},{"p":[{"n":"isoLevel","p":3187973},{"n":"timeout","p":140705793}],"n":".ctor","o":"$ctor$8","d":566533,"h":17180435717,"f":8}],"i":[57540609,113377281,57016321],"h":566533,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]}]}; }
            static get $b() { return $.$stl.System.Transactions.Transaction; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.Runtime.Serialization.ISerializable, $.$spc.System.IAsyncResult ]; }
            static get $fullName() { return `System.Transactions.CommittableTransaction`; }
        });
        
        $asm.$cls("$stl.System.Transactions.VolatileEnlistmentDone", ($self) => class VolatileEnlistmentDone extends $.$stl.System.Transactions.VolatileEnlistmentEnded
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                enlistment.State = this;
            }
            /*void */ ChangeStatePreparing(/*InternalEnlistment*/ enlistment)
            {
                enlistment.CheckComplete();
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 8955141;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":9020677,"m":[{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"EnterState","d":8955141,"h":4303922437,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2729221}],"n":"ChangeStatePreparing","d":8955141,"h":8598889733,"f":32776}],"c":[{"n":".ctor","o":"$ctor$4","d":8955141,"h":12893857029,"f":1}],"h":8955141}; }
            static get $b() { return $.$stl.System.Transactions.VolatileEnlistmentEnded; }
            static get $fullName() { return `System.Transactions.VolatileEnlistmentDone`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedPhase0", ($self) => class TransactionStatePromotedPhase0 extends $.$stl.System.Transactions.TransactionStatePromotedCommitting
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                /*int*/ let volatileCount = tx._phase0Volatiles._volatileEnlistmentCount;
                /*int*/ let dependentCount = tx._phase0Volatiles._dependentClones;
                tx._phase0VolatileWaveCount = volatileCount;
                if (tx._phase0Volatiles._preparedVolatileEnlistments < ((volatileCount + dependentCount) | 0))
                {
                    for(/*int*/ let i = 0; i < volatileCount; i++)
                    {
                        $.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i)._twoPhaseState.ChangeStatePreparing($.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i));
                        if (!tx.State.ContinuePhase0Prepares())
                        {
                            break;
                        }
                    }
                }
                else 
                {
                    this.Phase0VolatilePrepareDone(tx);
                }
            }
            /*void */ Phase0VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(tx._phase0Volatiles.VolatileDemux !== null, "Volatile Demux must exist for VolatilePrepareDone when promoted.");
                $.$spc.System.Threading.Monitor.Exit(tx);
                try
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(tx._phase0Volatiles.VolatileDemux._promotedEnlistment !== null, "tx._phase0Volatiles.VolatileDemux._promotedEnlistment != null");
                    tx._phase0Volatiles.VolatileDemux._promotedEnlistment.System$Transactions$IPromotedEnlistment$Prepared();
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(tx);
                    }
                }
            }
            /*bool */ ContinuePhase0Prepares()
            {
                return true;
            }
            /*void */ ChangeStateTransactionAborted(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                tx._innerException ??= e;
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedP0Aborting.EnterState(tx);
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 7972101;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7054597,"m":[{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"EnterState","d":7972101,"h":4302939397,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"Phase0VolatilePrepareDone","d":7972101,"h":8597906693,"f":32776},{"r":262145,"n":"ContinuePhase0Prepares","d":7972101,"h":12892873989,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"e","p":47251457}],"n":"ChangeStateTransactionAborted","d":7972101,"h":17187841285,"f":32776}],"c":[{"n":".ctor","o":"$ctor$4","d":7972101,"h":21482808581,"f":1}],"h":7972101}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedCommitting; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedPhase0`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedPhase1", ($self) => class TransactionStatePromotedPhase1 extends $.$stl.System.Transactions.TransactionStatePromotedCommitting
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                if (tx._committableTransaction !== null)
                {
                    tx._committableTransaction._complete = true;
                }
                if (tx._phase1Volatiles._dependentClones !== 0)
                {
                    tx.State.ChangeStateTransactionAborted(tx, null);
                    return;
                }
                /*int*/ let volatileCount = tx._phase1Volatiles._volatileEnlistmentCount;
                if (tx._phase1Volatiles._preparedVolatileEnlistments < volatileCount)
                {
                    for(/*int*/ let i = 0; i < volatileCount; i++)
                    {
                        $.$spc.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i)._twoPhaseState.ChangeStatePreparing($.$spc.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i));
                        if (!tx.State.ContinuePhase1Prepares())
                        {
                            break;
                        }
                    }
                }
                else 
                {
                    this.Phase1VolatilePrepareDone(tx);
                }
            }
            /*void */ CreateBlockingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ CreateAbortingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ ChangeStateTransactionAborted(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                tx._innerException ??= e;
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedP1Aborting.EnterState(tx);
            }
            /*void */ Phase1VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(tx._phase1Volatiles.VolatileDemux !== null, "Volatile Demux must exist for VolatilePrepareDone when promoted.");
                $.$spc.System.Threading.Monitor.Exit(tx);
                try
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(tx._phase1Volatiles.VolatileDemux._promotedEnlistment !== null, "tx._phase1Volatiles.VolatileDemux._promotedEnlistment != null");
                    tx._phase1Volatiles.VolatileDemux._promotedEnlistment.System$Transactions$IPromotedEnlistment$Prepared();
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(tx);
                    }
                }
            }
            /*bool */ ContinuePhase1Prepares()
            {
                return true;
            }
            /*Enlistment */ EnlistVolatile(/*InternalTransaction*/ tx, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                throw $.$stl.System.Transactions.TransactionException.Create$1($.$stl.System.SR.TooLate, tx === null ? $.$spc.System.Guid.Empty : tx.DistributedTxId);
            }
            /*Enlistment */ EnlistVolatile$1(/*InternalTransaction*/ tx, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                throw $.$stl.System.Transactions.TransactionException.Create$1($.$stl.System.SR.TooLate, tx === null ? $.$spc.System.Guid.Empty : tx.DistributedTxId);
            }
            /*Enlistment */ EnlistDurable(/*InternalTransaction*/ tx, /*Guid*/ resourceManagerIdentifier, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                throw $.$stl.System.Transactions.TransactionException.Create$1($.$stl.System.SR.TooLate, tx === null ? $.$spc.System.Guid.Empty : tx.DistributedTxId);
            }
            /*Enlistment */ EnlistDurable$1(/*InternalTransaction*/ tx, /*Guid*/ resourceManagerIdentifier, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                throw $.$stl.System.Transactions.TransactionException.Create$1($.$stl.System.SR.TooLate, tx === null ? $.$spc.System.Guid.Empty : tx.DistributedTxId);
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 8037637;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7054597,"m":[{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"EnterState","d":8037637,"h":4303004933,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"CreateBlockingClone","d":8037637,"h":8597972229,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"CreateAbortingClone","d":8037637,"h":12892939525,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"e","p":47251457}],"n":"ChangeStateTransactionAborted","d":8037637,"h":17187906821,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"Phase1VolatilePrepareDone","d":8037637,"h":21482874117,"f":32776},{"r":262145,"n":"ContinuePhase1Prepares","d":8037637,"h":25777841413,"f":32776},{"r":1746181,"p":[{"n":"tx","p":2794757},{"n":"enlistmentNotification","p":2598149},{"n":"enlistmentOptions","p":1877253},{"n":"atomicTransaction","p":4302085}],"n":"EnlistVolatile","d":8037637,"h":30072808709,"f":32776},{"r":1746181,"p":[{"n":"tx","p":2794757},{"n":"enlistmentNotification","p":3056901},{"n":"enlistmentOptions","p":1877253},{"n":"atomicTransaction","p":4302085}],"n":"EnlistVolatile","o":"@$1","d":8037637,"h":34367776005,"f":32776},{"r":1746181,"p":[{"n":"tx","p":2794757},{"n":"resourceManagerIdentifier","p":56229889},{"n":"enlistmentNotification","p":2598149},{"n":"enlistmentOptions","p":1877253},{"n":"atomicTransaction","p":4302085}],"n":"EnlistDurable","d":8037637,"h":38662743301,"f":32776},{"r":1746181,"p":[{"n":"tx","p":2794757},{"n":"resourceManagerIdentifier","p":56229889},{"n":"enlistmentNotification","p":3056901},{"n":"enlistmentOptions","p":1877253},{"n":"atomicTransaction","p":4302085}],"n":"EnlistDurable","o":"@$1","d":8037637,"h":42957710597,"f":32776}],"c":[{"n":".ctor","o":"$ctor$4","d":8037637,"h":47252677893,"f":1}],"h":8037637}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedCommitting; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedPhase1`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateDelegatedP0Wave", ($self) => class TransactionStateDelegatedP0Wave extends $.$stl.System.Transactions.TransactionStatePromotedP0Wave
        {
            /*void */ Phase0VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStateDelegatedCommitting.EnterState(tx);
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 6333701;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7841029,"m":[{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"Phase0VolatilePrepareDone","d":6333701,"h":4301300997,"f":32776}],"c":[{"n":".ctor","o":"$ctor$4","d":6333701,"h":8596268293,"f":1}],"h":6333701}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedP0Wave; }
            static get $fullName() { return `System.Transactions.TransactionStateDelegatedP0Wave`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateDelegatedCommitting", ($self) => class TransactionStateDelegatedCommitting extends $.$stl.System.Transactions.TransactionStatePromotedCommitting
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                $.$spc.System.Threading.Monitor.Exit(tx);
                $.$spc.System.Diagnostics.Debug.Assert$1(tx._durableEnlistment !== null, "tx._durableEnlistment != null");
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.EnlistmentStatus(1/*TraceSourceType.TraceSourceLtm*/, tx._durableEnlistment.EnlistmentTraceId, 4/*NotificationCall.SinglePhaseCommit*/);
                }
                try
                {
                    tx._durableEnlistment.PromotableSinglePhaseNotification.System$Transactions$IPromotableSinglePhaseNotification$SinglePhaseCommit(tx._durableEnlistment.SinglePhaseEnlistment);
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(tx);
                    }
                }
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 6202629;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7054597,"m":[{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"EnterState","d":6202629,"h":4301169925,"f":32776}],"c":[{"n":".ctor","o":"$ctor$4","d":6202629,"h":8596137221,"f":1}],"h":6202629}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedCommitting; }
            static get $fullName() { return `System.Transactions.TransactionStateDelegatedCommitting`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateSubordinateActive", ($self) => class TransactionStateSubordinateActive extends $.$stl.System.Transactions.TransactionStateActive
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                $.$spc.System.Diagnostics.Debug.Assert$1(tx._promoter !== null, "Transaction Promoter is Null entering SubordinateActive");
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                tx._innerException ??= e;
                $.$spc.System.Diagnostics.Debug.Assert$1(tx._promoter !== null, "tx._promoter != null");
                ($.$cast(tx._promoter, $.$stl.System.Transactions.ISimpleTransactionSuperior)).System$Transactions$ISimpleTransactionSuperior$Rollback();
                $.$stl.System.Transactions.TransactionState.TransactionStateAborted.EnterState(tx);
            }
            /*Enlistment */ EnlistVolatile(/*InternalTransaction*/ tx, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                tx._promoteState.EnterState(tx);
                return tx.State.EnlistVolatile(tx, enlistmentNotification, enlistmentOptions, atomicTransaction);
            }
            /*Enlistment */ EnlistVolatile$1(/*InternalTransaction*/ tx, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                tx._promoteState.EnterState(tx);
                return tx.State.EnlistVolatile$1(tx, enlistmentNotification, enlistmentOptions, atomicTransaction);
            }
            /*TransactionStatus */ get_Status(/*InternalTransaction*/ tx)
            {
                tx._promoteState.EnterState(tx);
                return tx.State.get_Status(tx);
            }
            /*void */ AddOutcomeRegistrant(/*InternalTransaction*/ tx, /*TransactionCompletedEventHandler?*/ transactionCompletedDelegate)
            {
                tx._promoteState.EnterState(tx);
                tx.State.AddOutcomeRegistrant(tx, transactionCompletedDelegate);
            }
            /*bool */ EnlistPromotableSinglePhase(/*InternalTransaction*/ tx, /*IPromotableSinglePhaseNotification*/ promotableSinglePhaseNotification, /*Transaction*/ atomicTransaction, /*Guid*/ promoterType)
            {
                return false;
            }
            /*void */ CreateBlockingClone(/*InternalTransaction*/ tx)
            {
                tx._promoteState.EnterState(tx);
                tx.State.CreateBlockingClone(tx);
            }
            /*void */ CreateAbortingClone(/*InternalTransaction*/ tx)
            {
                tx._promoteState.EnterState(tx);
                tx.State.CreateAbortingClone(tx);
            }
            //default reference type constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                return this;
            }
            static $h = 8234245;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":5874949,"m":[{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"EnterState","d":8234245,"h":4303201541,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"e","p":47251457}],"n":"Rollback","d":8234245,"h":8598168837,"f":32776},{"r":1746181,"p":[{"n":"tx","p":2794757},{"n":"enlistmentNotification","p":2598149},{"n":"enlistmentOptions","p":1877253},{"n":"atomicTransaction","p":4302085}],"n":"EnlistVolatile","d":8234245,"h":12893136133,"f":32776},{"r":1746181,"p":[{"n":"tx","p":2794757},{"n":"enlistmentNotification","p":3056901},{"n":"enlistmentOptions","p":1877253},{"n":"atomicTransaction","p":4302085}],"n":"EnlistVolatile","o":"@$1","d":8234245,"h":17188103429,"f":32776},{"r":8430853,"p":[{"n":"tx","p":2794757}],"n":"get_Status","d":8234245,"h":21483070725,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"transactionCompletedDelegate","p":4433157}],"n":"AddOutcomeRegistrant","d":8234245,"h":25778038021,"f":32776},{"r":262145,"p":[{"n":"tx","p":2794757},{"n":"promotableSinglePhaseNotification","p":2860293},{"n":"atomicTransaction","p":4302085},{"n":"promoterType","p":56229889}],"n":"EnlistPromotableSinglePhase","d":8234245,"h":30073005317,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"CreateBlockingClone","d":8234245,"h":34367972613,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"CreateAbortingClone","d":8234245,"h":38662939909,"f":32776}],"c":[{"n":".ctor","o":"$ctor$5","d":8234245,"h":42957907205,"f":1}],"h":8234245}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStateActive; }
            static get $fullName() { return `System.Transactions.TransactionStateSubordinateActive`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateDelegated", ($self) => class TransactionStateDelegated extends $.$stl.System.Transactions.TransactionStateDelegatedBase
        {
            /*void */ BeginCommit(/*InternalTransaction*/ tx, /*bool*/ asyncCommit, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                tx._asyncCommit = asyncCommit;
                tx._asyncCallback = asyncCallback;
                tx._asyncState = asyncState;
                $.$stl.System.Transactions.TransactionState.TransactionStateDelegatedCommitting.EnterState(tx);
            }
            /*bool */ PromoteDurable(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(tx._durableEnlistment !== null, "tx._durableEnlistment != null");
                tx._durableEnlistment.State.ChangeStateDelegated(tx._durableEnlistment);
                return true;
            }
            /*void */ RestartCommitIfNeeded(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStateDelegatedP0Wave.EnterState(tx);
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                tx._innerException ??= e;
                $.$stl.System.Transactions.TransactionState.TransactionStateDelegatedAborting.EnterState(tx);
            }
            //default reference type constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                return this;
            }
            static $h = 6006021;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6137093,"m":[{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"asyncCommit","p":262145},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":6006021,"h":4300973317,"f":32776},{"r":262145,"p":[{"n":"tx","p":2794757}],"n":"PromoteDurable","d":6006021,"h":8595940613,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"RestartCommitIfNeeded","d":6006021,"h":12890907909,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"e","p":47251457}],"n":"Rollback","d":6006021,"h":17185875205,"f":32776}],"c":[{"n":".ctor","o":"$ctor$5","d":6006021,"h":21480842501,"f":1}],"h":6006021}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStateDelegatedBase; }
            static get $fullName() { return `System.Transactions.TransactionStateDelegated`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateDelegatedSubordinate", ($self) => class TransactionStateDelegatedSubordinate extends $.$stl.System.Transactions.TransactionStateDelegatedBase
        {
            /*bool */ PromoteDurable(/*InternalTransaction*/ tx)
            {
                return true;
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                tx._innerException ??= e;
                $.$spc.System.Diagnostics.Debug.Assert$1(tx.PromotedTransaction !== null, "tx.PromotedTransaction != null");
                tx.PromotedTransaction.Rollback();
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedAborted.EnterState(tx);
            }
            /*void */ ChangeStatePromotedPhase0(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedPhase0.EnterState(tx);
            }
            /*void */ ChangeStatePromotedPhase1(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedPhase1.EnterState(tx);
            }
            //default reference type constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                return this;
            }
            static $h = 6399237;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6137093,"m":[{"r":262145,"p":[{"n":"tx","p":2794757}],"n":"PromoteDurable","d":6399237,"h":4301366533,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"e","p":47251457}],"n":"Rollback","d":6399237,"h":8596333829,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"ChangeStatePromotedPhase0","d":6399237,"h":12891301125,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"ChangeStatePromotedPhase1","d":6399237,"h":17186268421,"f":32776}],"c":[{"n":".ctor","o":"$ctor$5","d":6399237,"h":21481235717,"f":1}],"h":6399237}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStateDelegatedBase; }
            static get $fullName() { return `System.Transactions.TransactionStateDelegatedSubordinate`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateDelegatedAborting", ($self) => class TransactionStateDelegatedAborting extends $.$stl.System.Transactions.TransactionStatePromotedAborted
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                $.$spc.System.Threading.Monitor.Exit(tx);
                try
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(tx._durableEnlistment !== null, "tx._durableEnlistment != null");
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.EnlistmentStatus(1/*TraceSourceType.TraceSourceLtm*/, tx._durableEnlistment.EnlistmentTraceId, 2/*NotificationCall.Rollback*/);
                    }
                    tx._durableEnlistment.PromotableSinglePhaseNotification.System$Transactions$IPromotableSinglePhaseNotification$Rollback(tx._durableEnlistment.SinglePhaseEnlistment);
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(tx);
                    }
                }
            }
            /*void */ BeginCommit(/*InternalTransaction*/ tx, /*bool*/ asyncCommit, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ ChangeStatePromotedAborted(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedAborted.EnterState(tx);
            }
            //default reference type constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                return this;
            }
            static $h = 6071557;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6792453,"m":[{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"EnterState","d":6071557,"h":4301038853,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757},{"n":"asyncCommit","p":262145},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":6071557,"h":8596006149,"f":32776},{"r":65537,"p":[{"n":"tx","p":2794757}],"n":"ChangeStatePromotedAborted","d":6071557,"h":12890973445,"f":32776}],"c":[{"n":".ctor","o":"$ctor$5","d":6071557,"h":17185940741,"f":1}],"h":6071557}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedAborted; }
            static get $fullName() { return `System.Transactions.TransactionStateDelegatedAborting`; }
        });
        
        $asm.$cls("$stl.System.Transactions.RecoveringInternalEnlistment", ($self) => class RecoveringInternalEnlistment extends $.$stl.System.Transactions.DurableInternalEnlistment
        {
            /*object*/ _syncRoot = null;
            $ctor$7(/*Enlistment*/ enlistment, /*IEnlistmentNotification*/ twoPhaseNotifications, /*object*/ syncRoot)
            {
                super.$ctor$6(enlistment, twoPhaseNotifications);
                {
                    this._syncRoot = syncRoot;
                }
                return this;
            }
            /*object */ get SyncRoot()
            {
                return this._syncRoot;
            }
            static $h = 4039941;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1615109,"p":[{"p":131073,"g":{"r":0,"d":0,"h":17183909125,"f":32776},"n":"SyncRoot","d":4039941,"h":12888941829,"f":32776}],"l":[{"t":131073,"n":"_syncRoot","d":4039941,"h":4299007237,"f":2}],"c":[{"p":[{"n":"enlistment","p":1746181},{"n":"twoPhaseNotifications","p":2598149},{"n":"syncRoot","p":131073}],"n":".ctor","o":"$ctor$7","d":4039941,"h":8593974533,"f":8}],"i":[3122437,2663685],"h":4039941}; }
            static get $b() { return $.$stl.System.Transactions.DurableInternalEnlistment; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stl.System.Transactions.ISinglePhaseNotificationInternal, $.$stl.System.Transactions.IEnlistmentNotificationInternal ]; }
            static get $fullName() { return `System.Transactions.RecoveringInternalEnlistment`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionException", ($self) => class TransactionException extends $.$spc.System.SystemException
        {
            static /*bool */ IncludeDistributedTxId(/*Guid*/ distributedTxId)
            {
                return ($.$spc.System.Guid.op_Inequality(distributedTxId, $.$spc.System.Guid.Empty) && $.$stl.System.Transactions.Configuration.AppSettings.IncludeDistributedTxIdInExceptionMessage);
            }
            static /*TransactionException */ Create(/*string?*/ message, /*Exception?*/ innerException)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace$1(2/*TransactionExceptionType.TransactionException*/, message, innerException === null ? $.$spc.System.String.Empty : $.$spc.System.Exception.ToString.call(innerException));
                }
                return new $.$stl.System.Transactions.TransactionException().$ctor$11(message, innerException);
            }
            static /*TransactionException */ CreateTransactionStateException(/*Exception?*/ innerException)
            {
                return $.$stl.System.Transactions.TransactionException.Create($.$stl.System.SR.TransactionStateException, innerException);
            }
            static /*Exception */ CreateEnlistmentStateException(/*Exception?*/ innerException, /*Guid*/ distributedTxId)
            {
                /*string*/ let messagewithTxId = $.$stl.System.SR.EnlistmentStateException;
                if ($.$stl.System.Transactions.TransactionException.IncludeDistributedTxId(distributedTxId))
                {
                    messagewithTxId = $.$stl.System.SR.Format$1($.$stl.System.SR.DistributedTxIDInTransactionException, messagewithTxId, distributedTxId);
                }
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace$1(0/*TransactionExceptionType.InvalidOperationException*/, messagewithTxId, innerException === null ? $.$spc.System.String.Empty : $.$spc.System.Exception.ToString.call(innerException));
                }
                return new $.$spc.System.InvalidOperationException().$ctor$11(messagewithTxId, innerException);
            }
            static /*Exception */ CreateInvalidOperationException(/*TraceSourceType*/ traceSource, /*string?*/ message, /*Exception?*/ innerException)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace(traceSource, 0/*TransactionExceptionType.InvalidOperationException*/, message, innerException === null ? $.$spc.System.String.Empty : $.$spc.System.Exception.ToString.call(innerException));
                }
                return new $.$spc.System.InvalidOperationException().$ctor$11(message, innerException);
            }
            $ctor$9()
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            $ctor$10(/*string?*/ message)
            {
                super.$ctor$6(message);
                {
                }
                return this;
            }
            $ctor$11(/*string?*/ message, /*Exception?*/ innerException)
            {
                super.$ctor$7(message, innerException);
                {
                }
                return this;
            }
            $ctor$12(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor$8(info, context);
                {
                }
                return this;
            }
            static /*TransactionException */ Create$1(/*string?*/ message, /*Guid*/ distributedTxId)
            {
                if ($.$stl.System.Transactions.TransactionException.IncludeDistributedTxId(distributedTxId))
                {
                    return new $.$stl.System.Transactions.TransactionException().$ctor$10($.$stl.System.SR.Format$1($.$stl.System.SR.DistributedTxIDInTransactionException, message, distributedTxId));
                }
                return new $.$stl.System.Transactions.TransactionException().$ctor$10(message);
            }
            static /*TransactionException */ Create$2(/*string?*/ message, /*Exception?*/ innerException, /*Guid*/ distributedTxId)
            {
                /*string?*/ let messagewithTxId = message;
                if ($.$stl.System.Transactions.TransactionException.IncludeDistributedTxId(distributedTxId))
                {
                    messagewithTxId = $.$stl.System.SR.Format$1($.$stl.System.SR.DistributedTxIDInTransactionException, messagewithTxId, distributedTxId);
                }
                return $.$stl.System.Transactions.TransactionException.Create(messagewithTxId, innerException);
            }
            static /*TransactionException */ CreateTransactionStateException$1(/*Exception?*/ innerException, /*Guid*/ distributedTxId)
            {
                return $.$stl.System.Transactions.TransactionException.Create$2($.$stl.System.SR.TransactionStateException, innerException, distributedTxId);
            }
            static /*Exception */ CreateTransactionCompletedException(/*Guid*/ distributedTxId)
            {
                /*string*/ let messagewithTxId = $.$stl.System.SR.TransactionAlreadyCompleted;
                if ($.$stl.System.Transactions.TransactionException.IncludeDistributedTxId(distributedTxId))
                {
                    messagewithTxId = $.$stl.System.SR.Format$1($.$stl.System.SR.DistributedTxIDInTransactionException, messagewithTxId, distributedTxId);
                }
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace$1(0/*TransactionExceptionType.InvalidOperationException*/, messagewithTxId, $.$spc.System.String.Empty);
                }
                return new $.$spc.System.InvalidOperationException().$ctor$10(messagewithTxId);
            }
            static /*Exception */ CreateInvalidOperationException$1(/*TraceSourceType*/ traceSource, /*string?*/ message, /*Exception?*/ innerException, /*Guid*/ distributedTxId)
            {
                /*string?*/ let messagewithTxId = message;
                if ($.$stl.System.Transactions.TransactionException.IncludeDistributedTxId(distributedTxId))
                {
                    messagewithTxId = $.$stl.System.SR.Format$1($.$stl.System.SR.DistributedTxIDInTransactionException, messagewithTxId, distributedTxId);
                }
                return $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException(traceSource, messagewithTxId, innerException);
            }
            static $h = 4564229;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":119668737,"h":4564229}; }
            static get $b() { return $.$spc.System.SystemException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Transactions.TransactionException`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionAbortedException", ($self) => class TransactionAbortedException extends $.$stl.System.Transactions.TransactionException
        {
            static /*TransactionAbortedException */ Create$3(/*string?*/ message, /*Exception?*/ innerException, /*Guid*/ distributedTxId)
            {
                /*string?*/ let messagewithTxId = message;
                if ($.$stl.System.Transactions.TransactionException.IncludeDistributedTxId(distributedTxId))
                {
                    messagewithTxId = $.$stl.System.SR.Format$1($.$stl.System.SR.DistributedTxIDInTransactionException, messagewithTxId, distributedTxId);
                }
                return $.$stl.System.Transactions.TransactionAbortedException.Create$4(messagewithTxId, innerException);
            }
            static /*TransactionAbortedException */ Create$4(/*string?*/ message, /*Exception?*/ innerException)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace$1(1/*TransactionExceptionType.TransactionAbortedException*/, message, innerException === null ? $.$spc.System.String.Empty : $.$spc.System.Exception.ToString.call(innerException));
                }
                return new $.$stl.System.Transactions.TransactionAbortedException().$ctor$15(message, innerException);
            }
            $ctor$13()
            {
                super.$ctor$10($.$stl.System.SR.TransactionAborted);
                {
                }
                return this;
            }
            $ctor$14(/*string?*/ message)
            {
                super.$ctor$10(message ?? $.$stl.System.SR.TransactionAborted);
                {
                }
                return this;
            }
            $ctor$15(/*string?*/ message, /*Exception?*/ innerException)
            {
                super.$ctor$11(message ?? $.$stl.System.SR.TransactionAborted, innerException);
                {
                }
                return this;
            }
            $ctor$16(/*Exception?*/ innerException)
            {
                super.$ctor$11($.$stl.System.SR.TransactionAborted, innerException);
                {
                }
                return this;
            }
            $ctor$17(/*Exception?*/ innerException, /*Guid*/ distributedTxId)
            {
                super.$ctor$11($.$stl.System.Transactions.TransactionException.IncludeDistributedTxId(distributedTxId) ? $.$stl.System.SR.Format$1($.$stl.System.SR.DistributedTxIDInTransactionException, $.$stl.System.SR.TransactionAborted, distributedTxId) : $.$stl.System.SR.TransactionAborted, innerException);
                {
                }
                return this;
            }
            $ctor$18(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor$12(info, context);
                {
                }
                return this;
            }
            static $h = 4367621;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":4564229,"h":4367621}; }
            static get $b() { return $.$stl.System.Transactions.TransactionException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Transactions.TransactionAbortedException`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionInDoubtException", ($self) => class TransactionInDoubtException extends $.$stl.System.Transactions.TransactionException
        {
            static /*TransactionInDoubtException */ Create$3(/*TraceSourceType*/ traceSource, /*string?*/ message, /*Exception?*/ innerException, /*Guid*/ distributedTxId)
            {
                /*string?*/ let messagewithTxId = message;
                if ($.$stl.System.Transactions.TransactionException.IncludeDistributedTxId(distributedTxId))
                {
                    messagewithTxId = $.$stl.System.SR.Format$1($.$stl.System.SR.DistributedTxIDInTransactionException, messagewithTxId, distributedTxId);
                }
                return $.$stl.System.Transactions.TransactionInDoubtException.Create$4(traceSource, messagewithTxId, innerException);
            }
            static /*TransactionInDoubtException */ Create$4(/*TraceSourceType*/ traceSource, /*string?*/ message, /*Exception?*/ innerException)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace(traceSource, 3/*TransactionExceptionType.TransactionInDoubtException*/, message, innerException === null ? $.$spc.System.String.Empty : $.$spc.System.Exception.ToString.call(innerException));
                }
                return new $.$stl.System.Transactions.TransactionInDoubtException().$ctor$15(message, innerException);
            }
            $ctor$13()
            {
                super.$ctor$10($.$stl.System.SR.TransactionIndoubt);
                {
                }
                return this;
            }
            $ctor$14(/*string?*/ message)
            {
                super.$ctor$10(message ?? $.$stl.System.SR.TransactionIndoubt);
                {
                }
                return this;
            }
            $ctor$15(/*string?*/ message, /*Exception?*/ innerException)
            {
                super.$ctor$11(message ?? $.$stl.System.SR.TransactionIndoubt, innerException);
                {
                }
                return this;
            }
            $ctor$16(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor$12(info, context);
                {
                }
                return this;
            }
            static $h = 4695301;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":4564229,"h":4695301}; }
            static get $b() { return $.$stl.System.Transactions.TransactionException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Transactions.TransactionInDoubtException`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionManagerCommunicationException", ($self) => class TransactionManagerCommunicationException extends $.$stl.System.Transactions.TransactionException
        {
            static /*TransactionManagerCommunicationException */ Create$3(/*string?*/ message, /*Exception?*/ innerException)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace$1(4/*TransactionExceptionType.TransactionManagerCommunicationException*/, message, innerException === null ? $.$spc.System.String.Empty : $.$spc.System.Exception.ToString.call(innerException));
                }
                return new $.$stl.System.Transactions.TransactionManagerCommunicationException().$ctor$15(message, innerException);
            }
            static /*TransactionManagerCommunicationException */ Create$4(/*Exception?*/ innerException)
            {
                return $.$stl.System.Transactions.TransactionManagerCommunicationException.Create$3($.$stl.System.SR.TransactionManagerCommunicationException, innerException);
            }
            $ctor$13()
            {
                super.$ctor$10($.$stl.System.SR.TransactionManagerCommunicationException);
                {
                }
                return this;
            }
            $ctor$14(/*string?*/ message)
            {
                super.$ctor$10(message ?? $.$stl.System.SR.TransactionManagerCommunicationException);
                {
                }
                return this;
            }
            $ctor$15(/*string?*/ message, /*Exception?*/ innerException)
            {
                super.$ctor$11(message ?? $.$stl.System.SR.TransactionManagerCommunicationException, innerException);
                {
                }
                return this;
            }
            $ctor$16(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor$12(info, context);
                {
                }
                return this;
            }
            static $h = 4957445;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":4564229,"h":4957445}; }
            static get $b() { return $.$stl.System.Transactions.TransactionException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Transactions.TransactionManagerCommunicationException`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionPromotionException", ($self) => class TransactionPromotionException extends $.$stl.System.Transactions.TransactionException
        {
            $ctor$13()
            {
                this.$ctor$14($.$stl.System.SR.PromotionFailed);
                {
                }
                return this;
            }
            $ctor$14(/*string?*/ message)
            {
                super.$ctor$10(message ?? $.$stl.System.SR.PromotionFailed);
                {
                }
                return this;
            }
            $ctor$15(/*string?*/ message, /*Exception?*/ innerException)
            {
                super.$ctor$11(message ?? $.$stl.System.SR.PromotionFailed, innerException);
                {
                }
                return this;
            }
            $ctor$16(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor$12(info, context);
                {
                }
                return this;
            }
            static $h = 5088517;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":4564229,"h":5088517}; }
            static get $b() { return $.$stl.System.Transactions.TransactionException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Transactions.TransactionPromotionException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Collections.NonGeneric", "NetJs.System.Threading.Thread", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.Threading.Overlapped", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Xml.ReaderWriter"))