
(function ($global, $, $spc, $mwp, $sc, $sdt, $sm, $snv, $spu, $srei, $srel, $srp, $sri, $srl, $stee, $st, $sto, $stt, $sttp, $sr, $scc, $scn, $scm, $so, $srn, $ssc, $sris, $stc, $scp, $scsl, $sdf, $sfa, $sic, $sifd, $sim, $sl, $snp, $sspw, $srij, $scs, $sicb, $sci, $sdd, $ssa, $sdts, $srm, $snnr, $mwr, $sip, $sds, $sre, $sns, $sdpc, $sscr, $sle, $str, $snn, $snsc, $snq, $snh, $spx, $sxr) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Transactions.Local", 
    {"h":47660,"f":"System.Transactions.Local","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B760b8187d87d291733fdcda9f4d484d24d61a938","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Transactions.Local","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Transactions.Local","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$stl.System.Transactions.IPromotedEnlistment", ($self) => class IPromotedEnlistment
        {
            static $h = 2931244;
            static $f = 0b100100;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":2734636,"g":{"r":0,"d":0,"h":51542538796,"f":257},"s":{"r":0,"d":0,"h":55837506092,"f":257},"n":"InternalEnlistment","o":"System$Transactions$IPromotedEnlistment$InternalEnlistment","d":2931244,"h":47247571500,"f":257}],"m":[{"r":65537,"n":"EnlistmentDone","o":"System$Transactions$IPromotedEnlistment$EnlistmentDone","d":2931244,"h":4297898540,"f":257},{"r":65537,"n":"Prepared","o":"System$Transactions$IPromotedEnlistment$Prepared","d":2931244,"h":8592865836,"f":257},{"r":65537,"n":"ForceRollback","o":"System$Transactions$IPromotedEnlistment$ForceRollback","d":2931244,"h":12887833132,"f":257},{"r":65537,"p":[{"n":"e","p":47185921}],"n":"ForceRollback","o":"System$Transactions$IPromotedEnlistment$ForceRollback$1","d":2931244,"h":17182800428,"f":257},{"r":65537,"n":"Committed","o":"System$Transactions$IPromotedEnlistment$Committed","d":2931244,"h":21477767724,"f":257},{"r":65537,"n":"Aborted","o":"System$Transactions$IPromotedEnlistment$Aborted","d":2931244,"h":25772735020,"f":257},{"r":65537,"p":[{"n":"e","p":47185921}],"n":"Aborted","o":"System$Transactions$IPromotedEnlistment$Aborted$1","d":2931244,"h":30067702316,"f":257},{"r":65537,"n":"InDoubt","o":"System$Transactions$IPromotedEnlistment$InDoubt","d":2931244,"h":34362669612,"f":257},{"r":65537,"p":[{"n":"e","p":47185921}],"n":"InDoubt","o":"System$Transactions$IPromotedEnlistment$InDoubt$1","d":2931244,"h":38657636908,"f":257},{"r":0,"n":"GetRecoveryInformation","o":"System$Transactions$IPromotedEnlistment$GetRecoveryInformation","d":2931244,"h":42952604204,"f":257}],"h":2931244}; }
            static get $fullName() { return `System.Transactions.IPromotedEnlistment`; }
        });
        
        $asm.$cls("$stl.System.Transactions.IDtcTransaction", ($self) => class IDtcTransaction
        {
            static $h = 2538028;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"p":[{"n":"retaining","p":655361},{"n":"commitType","p":655361,"a":[{"t":105709569,"c":8695644161,"a":[{"v":7,"t":110886913}]}]},{"n":"reserved","p":655361}],"n":"Commit","o":"System$Transactions$IDtcTransaction$Commit","d":2538028,"h":4297505324,"f":257},{"r":65537,"p":[{"n":"reason","p":786433},{"n":"retaining","p":655361},{"n":"async","p":655361}],"n":"Abort","o":"System$Transactions$IDtcTransaction$Abort","d":2538028,"h":8592472620,"f":257},{"r":65537,"p":[{"n":"transactionInformation","p":786433}],"n":"GetTransactionInfo","o":"System$Transactions$IDtcTransaction$GetTransactionInfo","d":2538028,"h":12887439916,"f":257}],"h":2538028,"a":[{"t":99155969,"c":4394123265},{"t":104398849,"c":4399366145,"a":[{"v":"0fb15084-af41-11ce-bd2b-204c4f4f5020","t":1310721}]},{"t":104923137,"c":4399890433,"a":[{"v":1,"t":99221505}]}]}; }
            static get $fullName() { return `System.Transactions.IDtcTransaction`; }
        });
        
        $asm.$cls("$stl.System.Transactions.IEnlistmentNotificationInternal", ($self) => class IEnlistmentNotificationInternal
        {
            static $h = 2669100;
            static $f = 0b100100;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"p":[{"n":"preparingEnlistment","p":2931244}],"n":"Prepare","o":"System$Transactions$IEnlistmentNotificationInternal$Prepare","d":2669100,"h":4297636396,"f":257},{"r":65537,"p":[{"n":"enlistment","p":2931244}],"n":"Commit","o":"System$Transactions$IEnlistmentNotificationInternal$Commit","d":2669100,"h":8592603692,"f":257},{"r":65537,"p":[{"n":"enlistment","p":2931244}],"n":"Rollback","o":"System$Transactions$IEnlistmentNotificationInternal$Rollback","d":2669100,"h":12887570988,"f":257},{"r":65537,"p":[{"n":"enlistment","p":2931244}],"n":"InDoubt","o":"System$Transactions$IEnlistmentNotificationInternal$InDoubt","d":2669100,"h":17182538284,"f":257}],"h":2669100}; }
            static get $fullName() { return `System.Transactions.IEnlistmentNotificationInternal`; }
        });
        
        $asm.$cls("$stl.System.Transactions.IEnlistmentNotification", ($self) => class IEnlistmentNotification
        {
            static $h = 2603564;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"p":[{"n":"preparingEnlistment","p":3914284}],"n":"Prepare","o":"System$Transactions$IEnlistmentNotification$Prepare","d":2603564,"h":4297570860,"f":257},{"r":65537,"p":[{"n":"enlistment","p":1751596}],"n":"Commit","o":"System$Transactions$IEnlistmentNotification$Commit","d":2603564,"h":8592538156,"f":257},{"r":65537,"p":[{"n":"enlistment","p":1751596}],"n":"Rollback","o":"System$Transactions$IEnlistmentNotification$Rollback","d":2603564,"h":12887505452,"f":257},{"r":65537,"p":[{"n":"enlistment","p":1751596}],"n":"InDoubt","o":"System$Transactions$IEnlistmentNotification$InDoubt","d":2603564,"h":17182472748,"f":257}],"h":2603564}; }
            static get $fullName() { return `System.Transactions.IEnlistmentNotification`; }
        });
        
        $asm.$cls("$stl.System.Transactions.ITransactionPromoter", ($self) => class ITransactionPromoter
        {
            static $h = 3258924;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":0,"n":"Promote","o":"System$Transactions$ITransactionPromoter$Promote","d":3258924,"h":4298226220,"f":257}],"h":3258924}; }
            static get $fullName() { return `System.Transactions.ITransactionPromoter`; }
        });
        
        $asm.$cls("$stl.System.Transactions.IPromotableSinglePhaseNotification", ($self) => class IPromotableSinglePhaseNotification
        {
            static $h = 2865708;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"n":"Initialize","o":"System$Transactions$IPromotableSinglePhaseNotification$Initialize","d":2865708,"h":4297833004,"f":257},{"r":65537,"p":[{"n":"singlePhaseEnlistment","p":4110892}],"n":"SinglePhaseCommit","o":"System$Transactions$IPromotableSinglePhaseNotification$SinglePhaseCommit","d":2865708,"h":8592800300,"f":257},{"r":65537,"p":[{"n":"singlePhaseEnlistment","p":4110892}],"n":"Rollback","o":"System$Transactions$IPromotableSinglePhaseNotification$Rollback","d":2865708,"h":12887767596,"f":257}],"i":[3258924],"h":2865708}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stl.System.Transactions.ITransactionPromoter ]; }
            static get $fullName() { return `System.Transactions.IPromotableSinglePhaseNotification`; }
        });
        
        $asm.$cls("$stl.System.Transactions.ISimpleTransactionSuperior", ($self) => class ISimpleTransactionSuperior
        {
            static $h = 2996780;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"n":"Rollback","o":"System$Transactions$ISimpleTransactionSuperior$Rollback","d":2996780,"h":4297964076,"f":257}],"i":[3258924],"h":2996780}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stl.System.Transactions.ITransactionPromoter ]; }
            static get $fullName() { return `System.Transactions.ISimpleTransactionSuperior`; }
        });
        
        $asm.$cls("$stl.System.Transactions.ISinglePhaseNotificationInternal", ($self) => class ISinglePhaseNotificationInternal
        {
            static $h = 3127852;
            static $f = 0b100100;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"p":[{"n":"singlePhaseEnlistment","p":2931244}],"n":"SinglePhaseCommit","o":"System$Transactions$ISinglePhaseNotificationInternal$SinglePhaseCommit","d":3127852,"h":4298095148,"f":257}],"i":[2669100],"h":3127852}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stl.System.Transactions.IEnlistmentNotificationInternal ]; }
            static get $fullName() { return `System.Transactions.ISinglePhaseNotificationInternal`; }
        });
        
        $asm.$cls("$stl.System.Transactions.ISinglePhaseNotification", ($self) => class ISinglePhaseNotification
        {
            static $h = 3062316;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"p":[{"n":"singlePhaseEnlistment","p":4110892}],"n":"SinglePhaseCommit","o":"System$Transactions$ISinglePhaseNotification$SinglePhaseCommit","d":3062316,"h":4298029612,"f":257}],"i":[2603564],"h":3062316}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stl.System.Transactions.IEnlistmentNotification ]; }
            static get $fullName() { return `System.Transactions.ISinglePhaseNotification`; }
        });
        
        $asm.$cls("$stl.System.Transactions.EnlistmentState", ($self) => class EnlistmentState extends $.$spc.System.Object
        {
            /*EnlistmentStatePromoted?*/ static _enlistmentStatePromoted = null;
            /*object?*/ static s_classSyncObject = null;
            static /*EnlistmentStatePromoted */ get EnlistmentStatePromoted()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.EnlistmentStatePromoted, $.$ref(() => $.$stl.System.Transactions.EnlistmentState._enlistmentStatePromoted, ($v) => $.$stl.System.Transactions.EnlistmentState._enlistmentStatePromoted = $v, $.$stl.System.Transactions.EnlistmentStatePromoted), $.$ref(() => $.$stl.System.Transactions.EnlistmentState.s_classSyncObject, ($v) => $.$stl.System.Transactions.EnlistmentState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.EnlistmentStatePromoted))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.EnlistmentStatePromoted().$ctor$2();
                }));
            }
            /*void */ EnlistmentDone(/*InternalEnlistment*/ enlistment)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateEnlistmentStateException(null, enlistment === null ? $.$spc.System.Guid.Empty : enlistment.DistributedTxId);
            }
            /*void */ Prepared(/*InternalEnlistment*/ enlistment)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateEnlistmentStateException(null, enlistment === null ? $.$spc.System.Guid.Empty : enlistment.DistributedTxId);
            }
            /*void */ ForceRollback(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateEnlistmentStateException(null, enlistment === null ? $.$spc.System.Guid.Empty : enlistment.DistributedTxId);
            }
            /*void */ Committed(/*InternalEnlistment*/ enlistment)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateEnlistmentStateException(null, enlistment === null ? $.$spc.System.Guid.Empty : enlistment.DistributedTxId);
            }
            /*void */ Aborted(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateEnlistmentStateException(null, enlistment === null ? $.$spc.System.Guid.Empty : enlistment.DistributedTxId);
            }
            /*void */ InDoubt(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateEnlistmentStateException(null, enlistment === null ? $.$spc.System.Guid.Empty : enlistment.DistributedTxId);
            }
            /*byte[] */ RecoveryInformation(/*InternalEnlistment*/ enlistment)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateEnlistmentStateException(null, enlistment === null ? $.$spc.System.Guid.Empty : enlistment.DistributedTxId);
            }
            /*void */ InternalAborted(/*InternalEnlistment*/ enlistment)
            {
                $.$spc.System.Diagnostics.Debug.Fail(`Invalid Event for InternalEnlistment State; Current State: ${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))}`);
                throw $.$stl.System.Transactions.TransactionException.CreateEnlistmentStateException(null, enlistment === null ? $.$spc.System.Guid.Empty : enlistment.DistributedTxId);
            }
            /*void */ InternalCommitted(/*InternalEnlistment*/ enlistment)
            {
                $.$spc.System.Diagnostics.Debug.Fail(`Invalid Event for InternalEnlistment State; Current State: ${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))}`);
                throw $.$stl.System.Transactions.TransactionException.CreateEnlistmentStateException(null, enlistment === null ? $.$spc.System.Guid.Empty : enlistment.DistributedTxId);
            }
            /*void */ InternalIndoubt(/*InternalEnlistment*/ enlistment)
            {
                $.$spc.System.Diagnostics.Debug.Fail(`Invalid Event for InternalEnlistment State; Current State: ${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))}`);
                throw $.$stl.System.Transactions.TransactionException.CreateEnlistmentStateException(null, enlistment === null ? $.$spc.System.Guid.Empty : enlistment.DistributedTxId);
            }
            /*void */ ChangeStateCommitting(/*InternalEnlistment*/ enlistment)
            {
                $.$spc.System.Diagnostics.Debug.Fail(`Invalid Event for InternalEnlistment State; Current State: ${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))}`);
                throw $.$stl.System.Transactions.TransactionException.CreateEnlistmentStateException(null, enlistment === null ? $.$spc.System.Guid.Empty : enlistment.DistributedTxId);
            }
            /*void */ ChangeStatePromoted(/*InternalEnlistment*/ enlistment, /*IPromotedEnlistment*/ promotedEnlistment)
            {
                $.$spc.System.Diagnostics.Debug.Fail(`Invalid Event for InternalEnlistment State; Current State: ${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))}`);
                throw $.$stl.System.Transactions.TransactionException.CreateEnlistmentStateException(null, enlistment === null ? $.$spc.System.Guid.Empty : enlistment.DistributedTxId);
            }
            /*void */ ChangeStateDelegated(/*InternalEnlistment*/ enlistment)
            {
                $.$spc.System.Diagnostics.Debug.Fail(`Invalid Event for InternalEnlistment State; Current State: ${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))}`);
                throw $.$stl.System.Transactions.TransactionException.CreateEnlistmentStateException(null, enlistment === null ? $.$spc.System.Guid.Empty : enlistment.DistributedTxId);
            }
            /*void */ ChangeStatePreparing(/*InternalEnlistment*/ enlistment)
            {
                $.$spc.System.Diagnostics.Debug.Fail(`Invalid Event for InternalEnlistment State; Current State: ${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))}`);
                throw $.$stl.System.Transactions.TransactionException.CreateEnlistmentStateException(null, enlistment === null ? $.$spc.System.Guid.Empty : enlistment.DistributedTxId);
            }
            /*void */ ChangeStateSinglePhaseCommit(/*InternalEnlistment*/ enlistment)
            {
                $.$spc.System.Diagnostics.Debug.Fail(`Invalid Event for InternalEnlistment State; Current State: ${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))}`);
                throw $.$stl.System.Transactions.TransactionException.CreateEnlistmentStateException(null, enlistment === null ? $.$spc.System.Guid.Empty : enlistment.DistributedTxId);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 1948204;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":2013740,"g":{"r":0,"d":0,"h":21476784684,"f":40},"n":"EnlistmentStatePromoted","d":1948204,"h":17181817388,"f":40}],"m":[{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"EnterState","d":1948204,"h":4296915500,"f":264},{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"EnlistmentDone","d":1948204,"h":25771751980,"f":136},{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"Prepared","d":1948204,"h":30066719276,"f":136},{"r":65537,"p":[{"n":"enlistment","p":2734636},{"n":"e","p":47185921}],"n":"ForceRollback","d":1948204,"h":34361686572,"f":136},{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"Committed","d":1948204,"h":38656653868,"f":136},{"r":65537,"p":[{"n":"enlistment","p":2734636},{"n":"e","p":47185921}],"n":"Aborted","d":1948204,"h":42951621164,"f":136},{"r":65537,"p":[{"n":"enlistment","p":2734636},{"n":"e","p":47185921}],"n":"InDoubt","d":1948204,"h":47246588460,"f":136},{"r":0,"p":[{"n":"enlistment","p":2734636}],"n":"RecoveryInformation","d":1948204,"h":51541555756,"f":136},{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"InternalAborted","d":1948204,"h":55836523052,"f":136},{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"InternalCommitted","d":1948204,"h":60131490348,"f":136},{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"InternalIndoubt","d":1948204,"h":64426457644,"f":136},{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"ChangeStateCommitting","d":1948204,"h":68721424940,"f":136},{"r":65537,"p":[{"n":"enlistment","p":2734636},{"n":"promotedEnlistment","p":2931244}],"n":"ChangeStatePromoted","d":1948204,"h":73016392236,"f":136},{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"ChangeStateDelegated","d":1948204,"h":77311359532,"f":136},{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"ChangeStatePreparing","d":1948204,"h":81606326828,"f":136},{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"ChangeStateSinglePhaseCommit","d":1948204,"h":85901294124,"f":136}],"l":[{"t":2013740,"n":"_enlistmentStatePromoted","d":1948204,"h":8591882796,"f":40},{"t":131073,"n":"s_classSyncObject","d":1948204,"h":12886850092,"f":34}],"c":[{"n":".ctor","o":"$ctor$1","d":1948204,"h":90196261420,"f":4}],"h":1948204}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Transactions.EnlistmentState`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionState", ($self) => class TransactionState extends $.$spc.System.Object
        {
            /*TransactionStateActive?*/ static s_transactionStateActive = null;
            /*TransactionStateSubordinateActive?*/ static s_transactionStateSubordinateActive = null;
            /*TransactionStatePhase0?*/ static s_transactionStatePhase0 = null;
            /*TransactionStateVolatilePhase1?*/ static s_transactionStateVolatilePhase1 = null;
            /*TransactionStateVolatileSPC?*/ static s_transactionStateVolatileSPC = null;
            /*TransactionStateSPC?*/ static s_transactionStateSPC = null;
            /*TransactionStateAborted?*/ static s_transactionStateAborted = null;
            /*TransactionStateCommitted?*/ static s_transactionStateCommitted = null;
            /*TransactionStateInDoubt?*/ static s_transactionStateInDoubt = null;
            /*TransactionStatePromoted?*/ static s_transactionStatePromoted = null;
            /*TransactionStateNonCommittablePromoted?*/ static s_transactionStateNonCommittablePromoted = null;
            /*TransactionStatePromotedP0Wave?*/ static s_transactionStatePromotedP0Wave = null;
            /*TransactionStatePromotedCommitting?*/ static s_transactionStatePromotedCommitting = null;
            /*TransactionStatePromotedPhase0?*/ static s_transactionStatePromotedPhase0 = null;
            /*TransactionStatePromotedPhase1?*/ static s_transactionStatePromotedPhase1 = null;
            /*TransactionStatePromotedP0Aborting?*/ static s_transactionStatePromotedP0Aborting = null;
            /*TransactionStatePromotedP1Aborting?*/ static s_transactionStatePromotedP1Aborting = null;
            /*TransactionStatePromotedAborted?*/ static s_transactionStatePromotedAborted = null;
            /*TransactionStatePromotedCommitted?*/ static s_transactionStatePromotedCommitted = null;
            /*TransactionStatePromotedIndoubt?*/ static s_transactionStatePromotedIndoubt = null;
            /*TransactionStateDelegated?*/ static s_transactionStateDelegated = null;
            /*TransactionStateDelegatedSubordinate?*/ static s_transactionStateDelegatedSubordinate = null;
            /*TransactionStateDelegatedP0Wave?*/ static s_transactionStateDelegatedP0Wave = null;
            /*TransactionStateDelegatedCommitting?*/ static s_transactionStateDelegatedCommitting = null;
            /*TransactionStateDelegatedAborting?*/ static s_transactionStateDelegatedAborting = null;
            /*TransactionStatePSPEOperation?*/ static s_transactionStatePSPEOperation = null;
            /*TransactionStateDelegatedNonMSDTC?*/ static s_transactionStateDelegatedNonMSDTC = null;
            /*TransactionStatePromotedNonMSDTCPhase0?*/ static s_transactionStatePromotedNonMSDTCPhase0 = null;
            /*TransactionStatePromotedNonMSDTCVolatilePhase1?*/ static s_transactionStatePromotedNonMSDTCVolatilePhase1 = null;
            /*TransactionStatePromotedNonMSDTCSinglePhaseCommit?*/ static s_transactionStatePromotedNonMSDTCSinglePhaseCommit = null;
            /*TransactionStatePromotedNonMSDTCAborted?*/ static s_transactionStatePromotedNonMSDTCAborted = null;
            /*TransactionStatePromotedNonMSDTCCommitted?*/ static s_transactionStatePromotedNonMSDTCCommitted = null;
            /*TransactionStatePromotedNonMSDTCIndoubt?*/ static s_transactionStatePromotedNonMSDTCIndoubt = null;
            /*object?*/ static s_classSyncObject = null;
            static /*TransactionStateActive */ get TransactionStateActive()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStateActive, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStateActive, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStateActive = $v, $.$stl.System.Transactions.TransactionStateActive), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStateActive))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStateActive().$ctor$4();
                }));
            }
            static /*TransactionStateSubordinateActive */ get TransactionStateSubordinateActive()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStateSubordinateActive, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStateSubordinateActive, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStateSubordinateActive = $v, $.$stl.System.Transactions.TransactionStateSubordinateActive), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStateSubordinateActive))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStateSubordinateActive().$ctor$5();
                }));
            }
            static /*TransactionStatePSPEOperation */ get TransactionStatePSPEOperation()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStatePSPEOperation, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePSPEOperation, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePSPEOperation = $v, $.$stl.System.Transactions.TransactionStatePSPEOperation), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStatePSPEOperation))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePSPEOperation().$ctor$2();
                }));
            }
            static /*TransactionStatePhase0 */ get TransactionStatePhase0()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStatePhase0, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePhase0, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePhase0 = $v, $.$stl.System.Transactions.TransactionStatePhase0), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStatePhase0))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePhase0().$ctor$4();
                }));
            }
            static /*TransactionStateVolatilePhase1 */ get TransactionStateVolatilePhase1()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStateVolatilePhase1, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStateVolatilePhase1, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStateVolatilePhase1 = $v, $.$stl.System.Transactions.TransactionStateVolatilePhase1), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStateVolatilePhase1))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStateVolatilePhase1().$ctor$3();
                }));
            }
            static /*TransactionStateVolatileSPC */ get TransactionStateVolatileSPC()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStateVolatileSPC, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStateVolatileSPC, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStateVolatileSPC = $v, $.$stl.System.Transactions.TransactionStateVolatileSPC), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStateVolatileSPC))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStateVolatileSPC().$ctor$3();
                }));
            }
            static /*TransactionStateSPC */ get TransactionStateSPC()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStateSPC, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStateSPC, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStateSPC = $v, $.$stl.System.Transactions.TransactionStateSPC), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStateSPC))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStateSPC().$ctor$3();
                }));
            }
            static /*TransactionStateAborted */ get TransactionStateAborted()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStateAborted, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStateAborted, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStateAborted = $v, $.$stl.System.Transactions.TransactionStateAborted), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStateAborted))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStateAborted().$ctor$3();
                }));
            }
            static /*TransactionStateCommitted */ get TransactionStateCommitted()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStateCommitted, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStateCommitted, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStateCommitted = $v, $.$stl.System.Transactions.TransactionStateCommitted), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStateCommitted))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStateCommitted().$ctor$3();
                }));
            }
            static /*TransactionStateInDoubt */ get TransactionStateInDoubt()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStateInDoubt, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStateInDoubt, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStateInDoubt = $v, $.$stl.System.Transactions.TransactionStateInDoubt), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStateInDoubt))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStateInDoubt().$ctor$3();
                }));
            }
            static /*TransactionStatePromoted */ get TransactionStatePromoted()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStatePromoted, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromoted, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromoted = $v, $.$stl.System.Transactions.TransactionStatePromoted), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStatePromoted))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromoted().$ctor$3();
                }));
            }
            static /*TransactionStateNonCommittablePromoted */ get TransactionStateNonCommittablePromoted()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStateNonCommittablePromoted, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStateNonCommittablePromoted, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStateNonCommittablePromoted = $v, $.$stl.System.Transactions.TransactionStateNonCommittablePromoted), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStateNonCommittablePromoted))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStateNonCommittablePromoted().$ctor$3();
                }));
            }
            static /*TransactionStatePromotedP0Wave */ get TransactionStatePromotedP0Wave()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStatePromotedP0Wave, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedP0Wave, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedP0Wave = $v, $.$stl.System.Transactions.TransactionStatePromotedP0Wave), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStatePromotedP0Wave))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromotedP0Wave().$ctor$3();
                }));
            }
            static /*TransactionStatePromotedCommitting */ get TransactionStatePromotedCommitting()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStatePromotedCommitting, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedCommitting, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedCommitting = $v, $.$stl.System.Transactions.TransactionStatePromotedCommitting), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStatePromotedCommitting))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromotedCommitting().$ctor$3();
                }));
            }
            static /*TransactionStatePromotedPhase0 */ get TransactionStatePromotedPhase0()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStatePromotedPhase0, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedPhase0, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedPhase0 = $v, $.$stl.System.Transactions.TransactionStatePromotedPhase0), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStatePromotedPhase0))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromotedPhase0().$ctor$4();
                }));
            }
            static /*TransactionStatePromotedPhase1 */ get TransactionStatePromotedPhase1()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStatePromotedPhase1, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedPhase1, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedPhase1 = $v, $.$stl.System.Transactions.TransactionStatePromotedPhase1), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStatePromotedPhase1))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromotedPhase1().$ctor$4();
                }));
            }
            static /*TransactionStatePromotedP0Aborting */ get TransactionStatePromotedP0Aborting()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStatePromotedP0Aborting, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedP0Aborting, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedP0Aborting = $v, $.$stl.System.Transactions.TransactionStatePromotedP0Aborting), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStatePromotedP0Aborting))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromotedP0Aborting().$ctor$4();
                }));
            }
            static /*TransactionStatePromotedP1Aborting */ get TransactionStatePromotedP1Aborting()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStatePromotedP1Aborting, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedP1Aborting, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedP1Aborting = $v, $.$stl.System.Transactions.TransactionStatePromotedP1Aborting), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStatePromotedP1Aborting))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromotedP1Aborting().$ctor$4();
                }));
            }
            static /*TransactionStatePromotedAborted */ get TransactionStatePromotedAborted()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStatePromotedAborted, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedAborted, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedAborted = $v, $.$stl.System.Transactions.TransactionStatePromotedAborted), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStatePromotedAborted))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromotedAborted().$ctor$4();
                }));
            }
            static /*TransactionStatePromotedCommitted */ get TransactionStatePromotedCommitted()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStatePromotedCommitted, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedCommitted, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedCommitted = $v, $.$stl.System.Transactions.TransactionStatePromotedCommitted), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStatePromotedCommitted))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromotedCommitted().$ctor$4();
                }));
            }
            static /*TransactionStatePromotedIndoubt */ get TransactionStatePromotedIndoubt()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStatePromotedIndoubt, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedIndoubt, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedIndoubt = $v, $.$stl.System.Transactions.TransactionStatePromotedIndoubt), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStatePromotedIndoubt))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromotedIndoubt().$ctor$4();
                }));
            }
            static /*TransactionStateDelegated */ get TransactionStateDelegated()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStateDelegated, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStateDelegated, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStateDelegated = $v, $.$stl.System.Transactions.TransactionStateDelegated), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStateDelegated))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStateDelegated().$ctor$5();
                }));
            }
            static /*TransactionStateDelegatedSubordinate */ get TransactionStateDelegatedSubordinate()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStateDelegatedSubordinate, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStateDelegatedSubordinate, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStateDelegatedSubordinate = $v, $.$stl.System.Transactions.TransactionStateDelegatedSubordinate), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStateDelegatedSubordinate))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStateDelegatedSubordinate().$ctor$5();
                }));
            }
            static /*TransactionStateDelegatedP0Wave */ get TransactionStateDelegatedP0Wave()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStateDelegatedP0Wave, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStateDelegatedP0Wave, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStateDelegatedP0Wave = $v, $.$stl.System.Transactions.TransactionStateDelegatedP0Wave), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStateDelegatedP0Wave))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStateDelegatedP0Wave().$ctor$4();
                }));
            }
            static /*TransactionStateDelegatedCommitting */ get TransactionStateDelegatedCommitting()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStateDelegatedCommitting, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStateDelegatedCommitting, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStateDelegatedCommitting = $v, $.$stl.System.Transactions.TransactionStateDelegatedCommitting), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStateDelegatedCommitting))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStateDelegatedCommitting().$ctor$4();
                }));
            }
            static /*TransactionStateDelegatedAborting */ get TransactionStateDelegatedAborting()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStateDelegatedAborting, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStateDelegatedAborting, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStateDelegatedAborting = $v, $.$stl.System.Transactions.TransactionStateDelegatedAborting), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStateDelegatedAborting))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStateDelegatedAborting().$ctor$5();
                }));
            }
            static /*TransactionStateDelegatedNonMSDTC */ get TransactionStateDelegatedNonMSDTC()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStateDelegatedNonMSDTC, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStateDelegatedNonMSDTC, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStateDelegatedNonMSDTC = $v, $.$stl.System.Transactions.TransactionStateDelegatedNonMSDTC), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStateDelegatedNonMSDTC))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStateDelegatedNonMSDTC().$ctor$3();
                }));
            }
            static /*TransactionStatePromotedNonMSDTCPhase0 */ get TransactionStatePromotedNonMSDTCPhase0()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStatePromotedNonMSDTCPhase0, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedNonMSDTCPhase0, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedNonMSDTCPhase0 = $v, $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCPhase0), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStatePromotedNonMSDTCPhase0))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCPhase0().$ctor$3();
                }));
            }
            static /*TransactionStatePromotedNonMSDTCVolatilePhase1 */ get TransactionStatePromotedNonMSDTCVolatilePhase1()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStatePromotedNonMSDTCVolatilePhase1, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedNonMSDTCVolatilePhase1, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedNonMSDTCVolatilePhase1 = $v, $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCVolatilePhase1), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStatePromotedNonMSDTCVolatilePhase1))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCVolatilePhase1().$ctor$3();
                }));
            }
            static /*TransactionStatePromotedNonMSDTCSinglePhaseCommit */ get TransactionStatePromotedNonMSDTCSinglePhaseCommit()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStatePromotedNonMSDTCSinglePhaseCommit, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedNonMSDTCSinglePhaseCommit, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedNonMSDTCSinglePhaseCommit = $v, $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCSinglePhaseCommit), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStatePromotedNonMSDTCSinglePhaseCommit))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCSinglePhaseCommit().$ctor$3();
                }));
            }
            static /*TransactionStatePromotedNonMSDTCAborted */ get TransactionStatePromotedNonMSDTCAborted()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStatePromotedNonMSDTCAborted, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedNonMSDTCAborted, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedNonMSDTCAborted = $v, $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCAborted), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStatePromotedNonMSDTCAborted))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCAborted().$ctor$4();
                }));
            }
            static /*TransactionStatePromotedNonMSDTCCommitted */ get TransactionStatePromotedNonMSDTCCommitted()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStatePromotedNonMSDTCCommitted, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedNonMSDTCCommitted, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedNonMSDTCCommitted = $v, $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCCommitted), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStatePromotedNonMSDTCCommitted))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCCommitted().$ctor$4();
                }));
            }
            static /*TransactionStatePromotedNonMSDTCIndoubt */ get TransactionStatePromotedNonMSDTCIndoubt()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStatePromotedNonMSDTCIndoubt, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedNonMSDTCIndoubt, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedNonMSDTCIndoubt = $v, $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCIndoubt), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStatePromotedNonMSDTCIndoubt))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCIndoubt().$ctor$4();
                }));
            }
            /*void */ CommonEnterState(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(tx.State !== this, "Changing to the same state.");
                tx.State = this;
                $.$spc.System.Array.$WriteT1.call(tx._stateHistory, this, tx._currentStateHist);
                if (++tx._currentStateHist > 20/*InternalTransaction.MaxStateHist*/)
                {
                    tx._currentStateHist = 0;
                }
            }
            /*void */ BeginCommit(/*InternalTransaction*/ tx, /*bool*/ asyncCommit, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ EndCommit(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Fail(`Invalid Event for State; Current State: ${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))}`);
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*Enlistment */ EnlistDurable(/*InternalTransaction*/ tx, /*Guid*/ resourceManagerIdentifier, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*Enlistment */ EnlistDurable$1(/*InternalTransaction*/ tx, /*Guid*/ resourceManagerIdentifier, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*Enlistment */ EnlistVolatile(/*InternalTransaction*/ tx, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*Enlistment */ EnlistVolatile$1(/*InternalTransaction*/ tx, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ CheckForFinishedTransaction(/*InternalTransaction*/ tx)
            {
            }
            /*Guid */ get_Identifier(/*InternalTransaction*/ tx)
            {
                return $.$spc.System.Guid.Empty;
            }
            /*void */ AddOutcomeRegistrant(/*InternalTransaction*/ tx, /*TransactionCompletedEventHandler?*/ transactionCompletedDelegate)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ GetObjectData(/*InternalTransaction*/ tx, /*SerializationInfo*/ serializationInfo, /*StreamingContext*/ context)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*bool */ EnlistPromotableSinglePhase(/*InternalTransaction*/ tx, /*IPromotableSinglePhaseNotification*/ promotableSinglePhaseNotification, /*Transaction*/ atomicTransaction, /*Guid*/ promoterType)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ CompleteBlockingClone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ CompleteAbortingClone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ CreateBlockingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ CreateAbortingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ ChangeStateTransactionAborted(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                $.$spc.System.Diagnostics.Debug.Fail(`Invalid Event for State; Current State: ${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))}`);
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace$1(0/*TransactionExceptionType.InvalidOperationException*/, (tx?.TransactionTraceId.TransactionIdentifier ?? null) ?? $.$spc.System.String.Empty, $.$spc.System.Exception.ToString.call(e));
                }
                throw new $.$spc.System.InvalidOperationException().$ctor$9();
            }
            /*void */ ChangeStateTransactionCommitted(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Fail(`Invalid Event for State; Current State: ${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))}`);
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace$1(0/*TransactionExceptionType.InvalidOperationException*/, (tx?.TransactionTraceId.TransactionIdentifier ?? null) ?? $.$spc.System.String.Empty, $.$spc.System.String.Empty);
                }
                throw new $.$spc.System.InvalidOperationException().$ctor$9();
            }
            /*void */ InDoubtFromEnlistment(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Fail(`Invalid Event for State; Current State: ${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))}`);
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace$1(0/*TransactionExceptionType.InvalidOperationException*/, (tx?.TransactionTraceId.TransactionIdentifier ?? null) ?? $.$spc.System.String.Empty, $.$spc.System.String.Empty);
                }
                throw new $.$spc.System.InvalidOperationException().$ctor$9();
            }
            /*void */ ChangeStatePromotedAborted(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Fail(`Invalid Event for State; Current State: ${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))}`);
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace$1(0/*TransactionExceptionType.InvalidOperationException*/, (tx?.TransactionTraceId.TransactionIdentifier ?? null) ?? $.$spc.System.String.Empty, $.$spc.System.String.Empty);
                }
                throw new $.$spc.System.InvalidOperationException().$ctor$9();
            }
            /*void */ ChangeStatePromotedCommitted(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Fail(`Invalid Event for State; Current State: ${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))}`);
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace$1(0/*TransactionExceptionType.InvalidOperationException*/, (tx?.TransactionTraceId.TransactionIdentifier ?? null) ?? $.$spc.System.String.Empty, $.$spc.System.String.Empty);
                }
                throw new $.$spc.System.InvalidOperationException().$ctor$9();
            }
            /*void */ InDoubtFromDtc(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Fail(`Invalid Event for State; Current State: ${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))}`);
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace$1(0/*TransactionExceptionType.InvalidOperationException*/, (tx?.TransactionTraceId.TransactionIdentifier ?? null) ?? $.$spc.System.String.Empty, $.$spc.System.String.Empty);
                }
                throw new $.$spc.System.InvalidOperationException().$ctor$9();
            }
            /*void */ ChangeStatePromotedPhase0(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Fail(`Invalid Event for State; Current State: ${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))}`);
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace$1(0/*TransactionExceptionType.InvalidOperationException*/, (tx?.TransactionTraceId.TransactionIdentifier ?? null) ?? $.$spc.System.String.Empty, $.$spc.System.String.Empty);
                }
                throw new $.$spc.System.InvalidOperationException().$ctor$9();
            }
            /*void */ ChangeStatePromotedPhase1(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Fail(`Invalid Event for State; Current State: ${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))}`);
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace$1(0/*TransactionExceptionType.InvalidOperationException*/, (tx?.TransactionTraceId.TransactionIdentifier ?? null) ?? $.$spc.System.String.Empty, $.$spc.System.String.Empty);
                }
                throw new $.$spc.System.InvalidOperationException().$ctor$9();
            }
            /*void */ ChangeStateAbortedDuringPromotion(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Fail(`Invalid Event for State; Current State: ${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))}`);
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace$1(0/*TransactionExceptionType.InvalidOperationException*/, (tx?.TransactionTraceId.TransactionIdentifier ?? null) ?? $.$spc.System.String.Empty, $.$spc.System.String.Empty);
                }
                throw new $.$spc.System.InvalidOperationException().$ctor$9();
            }
            /*void */ Timeout(/*InternalTransaction*/ tx)
            {
            }
            /*void */ Phase0VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Fail(`Invalid Event for State; Current State: ${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))}`);
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ Phase1VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Fail(`Invalid Event for State; Current State: ${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))}`);
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ RestartCommitIfNeeded(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Fail(`Invalid Event for State; Current State: ${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))}`);
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace$1(0/*TransactionExceptionType.InvalidOperationException*/, (tx?.TransactionTraceId.TransactionIdentifier ?? null) ?? $.$spc.System.String.Empty, $.$spc.System.String.Empty);
                }
                throw new $.$spc.System.InvalidOperationException().$ctor$9();
            }
            /*bool */ ContinuePhase0Prepares()
            {
                return false;
            }
            /*bool */ ContinuePhase1Prepares()
            {
                return false;
            }
            /*void */ Promote(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*byte[] */ PromotedToken(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*Enlistment */ PromoteAndEnlistDurable(/*InternalTransaction*/ tx, /*Guid*/ resourceManagerIdentifier, /*IPromotableSinglePhaseNotification*/ promotableNotification, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ SetDistributedTransactionId(/*InternalTransaction*/ tx, /*IPromotableSinglePhaseNotification*/ promotableNotification, /*Guid*/ distributedTransactionIdentifier)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ DisposeRoot(/*InternalTransaction*/ tx)
            {
            }
            /*bool */ IsCompleted(/*InternalTransaction*/ tx)
            {
                tx._needPulse = true;
                return false;
            }
            static /*void */ AddVolatileEnlistment(/*ref VolatileEnlistmentSet*/ enlistments, /*Enlistment*/ enlistment)
            {
                if (enlistments.$v._volatileEnlistmentCount === enlistments.$v._volatileEnlistmentSize)
                {
                    /*InternalEnlistment[]*/ let newEnlistments = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$stl.System.Transactions.InternalEnlistment), null, [((enlistments.$v._volatileEnlistmentSize + 8/*InternalTransaction.VolatileArrayIncrement*/) | 0)], null);
                    if (enlistments.$v._volatileEnlistmentSize > 0)
                    {
                        $.$spc.System.Array.Copy$1(enlistments.$v._volatileEnlistments, 0, newEnlistments, 0, enlistments.$v._volatileEnlistmentSize);
                    }
                    enlistments.$v._volatileEnlistmentSize += 8/*InternalTransaction.VolatileArrayIncrement*/;
                    enlistments.$v._volatileEnlistments = newEnlistments;
                }
                $.$spc.System.Array.$WriteT1.call(enlistments.$v._volatileEnlistments, enlistment.InternalEnlistment, enlistments.$v._volatileEnlistmentCount);
                enlistments.$v._volatileEnlistmentCount++;
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentActive.EnterState($.$spc.System.Array.$ReadT1.call(enlistments.$v._volatileEnlistments, ((enlistments.$v._volatileEnlistmentCount - 1) | 0)));
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 5749292;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":5880364,"g":{"r":0,"d":0,"h":154624571948,"f":40},"n":"TransactionStateActive","d":5749292,"h":150329604652,"f":40},{"p":8239660,"g":{"r":0,"d":0,"h":163214506540,"f":40},"n":"TransactionStateSubordinateActive","d":5749292,"h":158919539244,"f":40},{"p":8108588,"g":{"r":0,"d":0,"h":171804441132,"f":40},"n":"TransactionStatePSPEOperation","d":5749292,"h":167509473836,"f":40},{"p":6666796,"g":{"r":0,"d":0,"h":180394375724,"f":36},"n":"TransactionStatePhase0","d":5749292,"h":176099408428,"f":36},{"p":8305196,"g":{"r":0,"d":0,"h":188984310316,"f":36},"n":"TransactionStateVolatilePhase1","d":5749292,"h":184689343020,"f":36},{"p":8370732,"g":{"r":0,"d":0,"h":197574244908,"f":36},"n":"TransactionStateVolatileSPC","d":5749292,"h":193279277612,"f":36},{"p":8174124,"g":{"r":0,"d":0,"h":206164179500,"f":36},"n":"TransactionStateSPC","d":5749292,"h":201869212204,"f":36},{"p":5814828,"g":{"r":0,"d":0,"h":214754114092,"f":36},"n":"TransactionStateAborted","d":5749292,"h":210459146796,"f":36},{"p":5945900,"g":{"r":0,"d":0,"h":223344048684,"f":36},"n":"TransactionStateCommitted","d":5749292,"h":219049081388,"f":36},{"p":6535724,"g":{"r":0,"d":0,"h":231933983276,"f":36},"n":"TransactionStateInDoubt","d":5749292,"h":227639015980,"f":36},{"p":6732332,"g":{"r":0,"d":0,"h":240523917868,"f":40},"n":"TransactionStatePromoted","d":5749292,"h":236228950572,"f":40},{"p":6601260,"g":{"r":0,"d":0,"h":249113852460,"f":40},"n":"TransactionStateNonCommittablePromoted","d":5749292,"h":244818885164,"f":40},{"p":7846444,"g":{"r":0,"d":0,"h":257703787052,"f":36},"n":"TransactionStatePromotedP0Wave","d":5749292,"h":253408819756,"f":36},{"p":7060012,"g":{"r":0,"d":0,"h":266293721644,"f":36},"n":"TransactionStatePromotedCommitting","d":5749292,"h":261998754348,"f":36},{"p":7977516,"g":{"r":0,"d":0,"h":274883656236,"f":36},"n":"TransactionStatePromotedPhase0","d":5749292,"h":270588688940,"f":36},{"p":8043052,"g":{"r":0,"d":0,"h":283473590828,"f":36},"n":"TransactionStatePromotedPhase1","d":5749292,"h":279178623532,"f":36},{"p":7780908,"g":{"r":0,"d":0,"h":292063525420,"f":36},"n":"TransactionStatePromotedP0Aborting","d":5749292,"h":287768558124,"f":36},{"p":7911980,"g":{"r":0,"d":0,"h":300653460012,"f":36},"n":"TransactionStatePromotedP1Aborting","d":5749292,"h":296358492716,"f":36},{"p":6797868,"g":{"r":0,"d":0,"h":309243394604,"f":36},"n":"TransactionStatePromotedAborted","d":5749292,"h":304948427308,"f":36},{"p":6994476,"g":{"r":0,"d":0,"h":317833329196,"f":36},"n":"TransactionStatePromotedCommitted","d":5749292,"h":313538361900,"f":36},{"p":7191084,"g":{"r":0,"d":0,"h":326423263788,"f":36},"n":"TransactionStatePromotedIndoubt","d":5749292,"h":322128296492,"f":36},{"p":6011436,"g":{"r":0,"d":0,"h":335013198380,"f":36},"n":"TransactionStateDelegated","d":5749292,"h":330718231084,"f":36},{"p":6404652,"g":{"r":0,"d":0,"h":343603132972,"f":40},"n":"TransactionStateDelegatedSubordinate","d":5749292,"h":339308165676,"f":40},{"p":6339116,"g":{"r":0,"d":0,"h":352193067564,"f":36},"n":"TransactionStateDelegatedP0Wave","d":5749292,"h":347898100268,"f":36},{"p":6208044,"g":{"r":0,"d":0,"h":360783002156,"f":36},"n":"TransactionStateDelegatedCommitting","d":5749292,"h":356488034860,"f":36},{"p":6076972,"g":{"r":0,"d":0,"h":369372936748,"f":36},"n":"TransactionStateDelegatedAborting","d":5749292,"h":365077969452,"f":36},{"p":6273580,"g":{"r":0,"d":0,"h":377962871340,"f":36},"n":"TransactionStateDelegatedNonMSDTC","d":5749292,"h":373667904044,"f":36},{"p":7584300,"g":{"r":0,"d":0,"h":386552805932,"f":36},"n":"TransactionStatePromotedNonMSDTCPhase0","d":5749292,"h":382257838636,"f":36},{"p":7715372,"g":{"r":0,"d":0,"h":395142740524,"f":36},"n":"TransactionStatePromotedNonMSDTCVolatilePhase1","d":5749292,"h":390847773228,"f":36},{"p":7649836,"g":{"r":0,"d":0,"h":403732675116,"f":36},"n":"TransactionStatePromotedNonMSDTCSinglePhaseCommit","d":5749292,"h":399437707820,"f":36},{"p":7256620,"g":{"r":0,"d":0,"h":412322609708,"f":36},"n":"TransactionStatePromotedNonMSDTCAborted","d":5749292,"h":408027642412,"f":36},{"p":7387692,"g":{"r":0,"d":0,"h":420912544300,"f":36},"n":"TransactionStatePromotedNonMSDTCCommitted","d":5749292,"h":416617577004,"f":36},{"p":7518764,"g":{"r":0,"d":0,"h":429502478892,"f":36},"n":"TransactionStatePromotedNonMSDTCIndoubt","d":5749292,"h":425207511596,"f":36}],"m":[{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"CommonEnterState","d":5749292,"h":433797446188,"f":8},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"EnterState","d":5749292,"h":438092413484,"f":264},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"asyncCommit","p":262145},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":5749292,"h":442387380780,"f":136},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"EndCommit","d":5749292,"h":446682348076,"f":136},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"e","p":47185921}],"n":"Rollback","d":5749292,"h":450977315372,"f":136},{"r":1751596,"p":[{"n":"tx","p":2800172},{"n":"resourceManagerIdentifier","p":56164353},{"n":"enlistmentNotification","p":2603564},{"n":"enlistmentOptions","p":1882668},{"n":"atomicTransaction","p":4307500}],"n":"EnlistDurable","d":5749292,"h":455272282668,"f":136},{"r":1751596,"p":[{"n":"tx","p":2800172},{"n":"resourceManagerIdentifier","p":56164353},{"n":"enlistmentNotification","p":3062316},{"n":"enlistmentOptions","p":1882668},{"n":"atomicTransaction","p":4307500}],"n":"EnlistDurable","o":"@$1","d":5749292,"h":459567249964,"f":136},{"r":1751596,"p":[{"n":"tx","p":2800172},{"n":"enlistmentNotification","p":2603564},{"n":"enlistmentOptions","p":1882668},{"n":"atomicTransaction","p":4307500}],"n":"EnlistVolatile","d":5749292,"h":463862217260,"f":136},{"r":1751596,"p":[{"n":"tx","p":2800172},{"n":"enlistmentNotification","p":3062316},{"n":"enlistmentOptions","p":1882668},{"n":"atomicTransaction","p":4307500}],"n":"EnlistVolatile","o":"@$1","d":5749292,"h":468157184556,"f":136},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"CheckForFinishedTransaction","d":5749292,"h":472452151852,"f":136},{"r":56164353,"p":[{"n":"tx","p":2800172}],"n":"get_Identifier","d":5749292,"h":476747119148,"f":136},{"r":8436268,"p":[{"n":"tx","p":2800172}],"n":"get_Status","d":5749292,"h":481042086444,"f":264},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"transactionCompletedDelegate","p":4438572}],"n":"AddOutcomeRegistrant","d":5749292,"h":485337053740,"f":136},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"serializationInfo","p":113967105},{"n":"context","p":114098177}],"n":"GetObjectData","d":5749292,"h":489632021036,"f":136},{"r":262145,"p":[{"n":"tx","p":2800172},{"n":"promotableSinglePhaseNotification","p":2865708},{"n":"atomicTransaction","p":4307500},{"n":"promoterType","p":56164353}],"n":"EnlistPromotableSinglePhase","d":5749292,"h":493926988332,"f":136},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"CompleteBlockingClone","d":5749292,"h":498221955628,"f":136},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"CompleteAbortingClone","d":5749292,"h":502516922924,"f":136},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"CreateBlockingClone","d":5749292,"h":506811890220,"f":136},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"CreateAbortingClone","d":5749292,"h":511106857516,"f":136},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"e","p":47185921}],"n":"ChangeStateTransactionAborted","d":5749292,"h":515401824812,"f":136},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"ChangeStateTransactionCommitted","d":5749292,"h":519696792108,"f":136},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"InDoubtFromEnlistment","d":5749292,"h":523991759404,"f":136},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"ChangeStatePromotedAborted","d":5749292,"h":528286726700,"f":136},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"ChangeStatePromotedCommitted","d":5749292,"h":532581693996,"f":136},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"InDoubtFromDtc","d":5749292,"h":536876661292,"f":136},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"ChangeStatePromotedPhase0","d":5749292,"h":541171628588,"f":136},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"ChangeStatePromotedPhase1","d":5749292,"h":545466595884,"f":136},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"ChangeStateAbortedDuringPromotion","d":5749292,"h":549761563180,"f":136},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"Timeout","d":5749292,"h":554056530476,"f":136},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"Phase0VolatilePrepareDone","d":5749292,"h":558351497772,"f":136},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"Phase1VolatilePrepareDone","d":5749292,"h":562646465068,"f":136},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"RestartCommitIfNeeded","d":5749292,"h":566941432364,"f":136},{"r":262145,"n":"ContinuePhase0Prepares","d":5749292,"h":571236399660,"f":136},{"r":262145,"n":"ContinuePhase1Prepares","d":5749292,"h":575531366956,"f":136},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"Promote","d":5749292,"h":579826334252,"f":136},{"r":0,"p":[{"n":"tx","p":2800172}],"n":"PromotedToken","d":5749292,"h":584121301548,"f":136},{"r":1751596,"p":[{"n":"tx","p":2800172},{"n":"resourceManagerIdentifier","p":56164353},{"n":"promotableNotification","p":2865708},{"n":"enlistmentNotification","p":3062316},{"n":"enlistmentOptions","p":1882668},{"n":"atomicTransaction","p":4307500}],"n":"PromoteAndEnlistDurable","d":5749292,"h":588416268844,"f":136},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"promotableNotification","p":2865708},{"n":"distributedTransactionIdentifier","p":56164353}],"n":"SetDistributedTransactionId","d":5749292,"h":592711236140,"f":136},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"DisposeRoot","d":5749292,"h":597006203436,"f":136},{"r":262145,"p":[{"n":"tx","p":2800172}],"n":"IsCompleted","d":5749292,"h":601301170732,"f":136},{"r":65537,"p":[{"n":"enlistments","p":9353772,"f":4},{"n":"enlistment","p":1751596}],"n":"AddVolatileEnlistment","d":5749292,"h":605596138028,"f":36}],"l":[{"t":5880364,"n":"s_transactionStateActive","d":5749292,"h":4300716588,"f":34},{"t":8239660,"n":"s_transactionStateSubordinateActive","d":5749292,"h":8595683884,"f":34},{"t":6666796,"n":"s_transactionStatePhase0","d":5749292,"h":12890651180,"f":34},{"t":8305196,"n":"s_transactionStateVolatilePhase1","d":5749292,"h":17185618476,"f":34},{"t":8370732,"n":"s_transactionStateVolatileSPC","d":5749292,"h":21480585772,"f":34},{"t":8174124,"n":"s_transactionStateSPC","d":5749292,"h":25775553068,"f":34},{"t":5814828,"n":"s_transactionStateAborted","d":5749292,"h":30070520364,"f":34},{"t":5945900,"n":"s_transactionStateCommitted","d":5749292,"h":34365487660,"f":34},{"t":6535724,"n":"s_transactionStateInDoubt","d":5749292,"h":38660454956,"f":34},{"t":6732332,"n":"s_transactionStatePromoted","d":5749292,"h":42955422252,"f":34},{"t":6601260,"n":"s_transactionStateNonCommittablePromoted","d":5749292,"h":47250389548,"f":34},{"t":7846444,"n":"s_transactionStatePromotedP0Wave","d":5749292,"h":51545356844,"f":34},{"t":7060012,"n":"s_transactionStatePromotedCommitting","d":5749292,"h":55840324140,"f":34},{"t":7977516,"n":"s_transactionStatePromotedPhase0","d":5749292,"h":60135291436,"f":34},{"t":8043052,"n":"s_transactionStatePromotedPhase1","d":5749292,"h":64430258732,"f":34},{"t":7780908,"n":"s_transactionStatePromotedP0Aborting","d":5749292,"h":68725226028,"f":34},{"t":7911980,"n":"s_transactionStatePromotedP1Aborting","d":5749292,"h":73020193324,"f":34},{"t":6797868,"n":"s_transactionStatePromotedAborted","d":5749292,"h":77315160620,"f":34},{"t":6994476,"n":"s_transactionStatePromotedCommitted","d":5749292,"h":81610127916,"f":34},{"t":7191084,"n":"s_transactionStatePromotedIndoubt","d":5749292,"h":85905095212,"f":34},{"t":6011436,"n":"s_transactionStateDelegated","d":5749292,"h":90200062508,"f":34},{"t":6404652,"n":"s_transactionStateDelegatedSubordinate","d":5749292,"h":94495029804,"f":34},{"t":6339116,"n":"s_transactionStateDelegatedP0Wave","d":5749292,"h":98789997100,"f":34},{"t":6208044,"n":"s_transactionStateDelegatedCommitting","d":5749292,"h":103084964396,"f":34},{"t":6076972,"n":"s_transactionStateDelegatedAborting","d":5749292,"h":107379931692,"f":34},{"t":8108588,"n":"s_transactionStatePSPEOperation","d":5749292,"h":111674898988,"f":34},{"t":6273580,"n":"s_transactionStateDelegatedNonMSDTC","d":5749292,"h":115969866284,"f":34},{"t":7584300,"n":"s_transactionStatePromotedNonMSDTCPhase0","d":5749292,"h":120264833580,"f":34},{"t":7715372,"n":"s_transactionStatePromotedNonMSDTCVolatilePhase1","d":5749292,"h":124559800876,"f":34},{"t":7649836,"n":"s_transactionStatePromotedNonMSDTCSinglePhaseCommit","d":5749292,"h":128854768172,"f":34},{"t":7256620,"n":"s_transactionStatePromotedNonMSDTCAborted","d":5749292,"h":133149735468,"f":34},{"t":7387692,"n":"s_transactionStatePromotedNonMSDTCCommitted","d":5749292,"h":137444702764,"f":34},{"t":7518764,"n":"s_transactionStatePromotedNonMSDTCIndoubt","d":5749292,"h":141739670060,"f":34},{"t":131073,"n":"s_classSyncObject","d":5749292,"h":146034637356,"f":40}],"c":[{"n":".ctor","o":"$ctor$1","d":5749292,"h":609891105324,"f":4}],"h":5749292}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Transactions.TransactionState`; }
        });
        
        $asm.$cls("$stl.System.Transactions.VolatileDemultiplexer", ($self) => class VolatileDemultiplexer extends $.$spc.System.Object
        {
            /*InternalTransaction*/ _transaction = null;
            /*IPromotedEnlistment?*/ _promotedEnlistment = null;
            /*IPromotedEnlistment?*/ _preparingEnlistment = null;
            $ctor$1(/*InternalTransaction*/ transaction)
            {
                super.$ctor();
                {
                    this._transaction = transaction;
                }
                return this;
            }
            static /*void */ BroadcastCommitted(/*ref VolatileEnlistmentSet*/ volatiles)
            {
                for(/*int*/ let i = 0; i < volatiles.$v._volatileEnlistmentCount; i++)
                {
                    $.$spc.System.Array.$ReadT1.call(volatiles.$v._volatileEnlistments, i)._twoPhaseState.InternalCommitted($.$spc.System.Array.$ReadT1.call(volatiles.$v._volatileEnlistments, i));
                }
            }
            static /*void */ BroadcastRollback(/*ref VolatileEnlistmentSet*/ volatiles)
            {
                for(/*int*/ let i = 0; i < volatiles.$v._volatileEnlistmentCount; i++)
                {
                    $.$spc.System.Array.$ReadT1.call(volatiles.$v._volatileEnlistments, i)._twoPhaseState.InternalAborted($.$spc.System.Array.$ReadT1.call(volatiles.$v._volatileEnlistments, i));
                }
            }
            static /*void */ BroadcastInDoubt(/*ref VolatileEnlistmentSet*/ volatiles)
            {
                for(/*int*/ let i = 0; i < volatiles.$v._volatileEnlistmentCount; i++)
                {
                    $.$spc.System.Array.$ReadT1.call(volatiles.$v._volatileEnlistments, i)._twoPhaseState.InternalIndoubt($.$spc.System.Array.$ReadT1.call(volatiles.$v._volatileEnlistments, i));
                }
            }
            /*object?*/ static s_classSyncObject = null;
            static /*object */ get ClassSyncObject()
            {
                if ($.$stl.System.Transactions.VolatileDemultiplexer.s_classSyncObject === null)
                {
                    /*object*/ let o = new $.$spc.System.Object().$ctor();
                    $.$spc.System.Threading.Interlocked.CompareExchange$2($.$ref(() => $.$stl.System.Transactions.VolatileDemultiplexer.s_classSyncObject, ($v) => $.$stl.System.Transactions.VolatileDemultiplexer.s_classSyncObject = $v, $.$spc.System.Object), o, null);
                }
                return $.$stl.System.Transactions.VolatileDemultiplexer.s_classSyncObject;
            }
            /*WaitCallback?*/ static s_prepareCallback = null;
            static /*WaitCallback */ get PrepareCallback()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$spc.System.Threading.WaitCallback, $.$ref(() => $.$stl.System.Transactions.VolatileDemultiplexer.s_prepareCallback, ($v) => $.$stl.System.Transactions.VolatileDemultiplexer.s_prepareCallback = $v, $.$spc.System.Threading.WaitCallback), $.$ref(() => $.$stl.System.Transactions.VolatileDemultiplexer.s_classSyncObject, ($v) => $.$stl.System.Transactions.VolatileDemultiplexer.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$spc.System.Threading.WaitCallback))().$ctor(this,  () =>
                {
                    return new $.$spc.System.Threading.WaitCallback().$ctor(null, $.$stl.System.Transactions.VolatileDemultiplexer.PoolablePrepare);
                }));
            }
            static /*void */ PoolablePrepare(/*object*/ state)
            {
                /*VolatileDemultiplexer*/ let demux = $.$cast(state, $.$stl.System.Transactions.VolatileDemultiplexer);
                /*bool*/ let tookLock = false;
                try
                {
                    $.$spc.System.Threading.Monitor.TryEnter$3(demux._transaction, 250, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Boolean, () => tookLock, ($v) => tookLock = $v, null));
                    if (tookLock)
                    {
                        demux.InternalPrepare();
                    }
                    else 
                    {
                        if (!$.$spc.System.Threading.ThreadPool.QueueUserWorkItem$1($.$stl.System.Transactions.VolatileDemultiplexer.PrepareCallback, demux))
                        {
                            throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.UnexpectedFailureOfThreadPool, null);
                        }
                    }
                }
                finally
                {
                    {
                        if (tookLock)
                        {
                            $.$spc.System.Threading.Monitor.Exit(demux._transaction);
                        }
                    }
                }
            }
            /*WaitCallback?*/ static s_commitCallback = null;
            static /*WaitCallback */ get CommitCallback()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$spc.System.Threading.WaitCallback, $.$ref(() => $.$stl.System.Transactions.VolatileDemultiplexer.s_commitCallback, ($v) => $.$stl.System.Transactions.VolatileDemultiplexer.s_commitCallback = $v, $.$spc.System.Threading.WaitCallback), $.$ref(() => $.$stl.System.Transactions.VolatileDemultiplexer.s_classSyncObject, ($v) => $.$stl.System.Transactions.VolatileDemultiplexer.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$spc.System.Threading.WaitCallback))().$ctor(this,  () =>
                {
                    return new $.$spc.System.Threading.WaitCallback().$ctor(null, $.$stl.System.Transactions.VolatileDemultiplexer.PoolableCommit);
                }));
            }
            static /*void */ PoolableCommit(/*object*/ state)
            {
                /*VolatileDemultiplexer*/ let demux = $.$cast(state, $.$stl.System.Transactions.VolatileDemultiplexer);
                /*bool*/ let tookLock = false;
                try
                {
                    $.$spc.System.Threading.Monitor.TryEnter$3(demux._transaction, 250, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Boolean, () => tookLock, ($v) => tookLock = $v, null));
                    if (tookLock)
                    {
                        demux.InternalCommit();
                    }
                    else 
                    {
                        if (!$.$spc.System.Threading.ThreadPool.QueueUserWorkItem$1($.$stl.System.Transactions.VolatileDemultiplexer.CommitCallback, demux))
                        {
                            throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.UnexpectedFailureOfThreadPool, null);
                        }
                    }
                }
                finally
                {
                    {
                        if (tookLock)
                        {
                            $.$spc.System.Threading.Monitor.Exit(demux._transaction);
                        }
                    }
                }
            }
            /*WaitCallback?*/ static s_rollbackCallback = null;
            static /*WaitCallback */ get RollbackCallback()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$spc.System.Threading.WaitCallback, $.$ref(() => $.$stl.System.Transactions.VolatileDemultiplexer.s_rollbackCallback, ($v) => $.$stl.System.Transactions.VolatileDemultiplexer.s_rollbackCallback = $v, $.$spc.System.Threading.WaitCallback), $.$ref(() => $.$stl.System.Transactions.VolatileDemultiplexer.s_classSyncObject, ($v) => $.$stl.System.Transactions.VolatileDemultiplexer.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$spc.System.Threading.WaitCallback))().$ctor(this,  () =>
                {
                    return new $.$spc.System.Threading.WaitCallback().$ctor(null, $.$stl.System.Transactions.VolatileDemultiplexer.PoolableRollback);
                }));
            }
            static /*void */ PoolableRollback(/*object*/ state)
            {
                /*VolatileDemultiplexer*/ let demux = $.$cast(state, $.$stl.System.Transactions.VolatileDemultiplexer);
                /*bool*/ let tookLock = false;
                try
                {
                    $.$spc.System.Threading.Monitor.TryEnter$3(demux._transaction, 250, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Boolean, () => tookLock, ($v) => tookLock = $v, null));
                    if (tookLock)
                    {
                        demux.InternalRollback();
                    }
                    else 
                    {
                        if (!$.$spc.System.Threading.ThreadPool.QueueUserWorkItem$1($.$stl.System.Transactions.VolatileDemultiplexer.RollbackCallback, demux))
                        {
                            throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.UnexpectedFailureOfThreadPool, null);
                        }
                    }
                }
                finally
                {
                    {
                        if (tookLock)
                        {
                            $.$spc.System.Threading.Monitor.Exit(demux._transaction);
                        }
                    }
                }
            }
            /*WaitCallback?*/ static s_inDoubtCallback = null;
            static /*WaitCallback */ get InDoubtCallback()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$spc.System.Threading.WaitCallback, $.$ref(() => $.$stl.System.Transactions.VolatileDemultiplexer.s_inDoubtCallback, ($v) => $.$stl.System.Transactions.VolatileDemultiplexer.s_inDoubtCallback = $v, $.$spc.System.Threading.WaitCallback), $.$ref(() => $.$stl.System.Transactions.VolatileDemultiplexer.s_classSyncObject, ($v) => $.$stl.System.Transactions.VolatileDemultiplexer.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$spc.System.Threading.WaitCallback))().$ctor(this,  () =>
                {
                    return new $.$spc.System.Threading.WaitCallback().$ctor(null, $.$stl.System.Transactions.VolatileDemultiplexer.PoolableInDoubt);
                }));
            }
            static /*void */ PoolableInDoubt(/*object*/ state)
            {
                /*VolatileDemultiplexer*/ let demux = $.$cast(state, $.$stl.System.Transactions.VolatileDemultiplexer);
                /*bool*/ let tookLock = false;
                try
                {
                    $.$spc.System.Threading.Monitor.TryEnter$3(demux._transaction, 250, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Boolean, () => tookLock, ($v) => tookLock = $v, null));
                    if (tookLock)
                    {
                        demux.InternalInDoubt();
                    }
                    else 
                    {
                        if (!$.$spc.System.Threading.ThreadPool.QueueUserWorkItem$1($.$stl.System.Transactions.VolatileDemultiplexer.InDoubtCallback, demux))
                        {
                            throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.UnexpectedFailureOfThreadPool, null);
                        }
                    }
                }
                finally
                {
                    {
                        if (tookLock)
                        {
                            $.$spc.System.Threading.Monitor.Exit(demux._transaction);
                        }
                    }
                }
            }
            //Generated interface implemetation for System.Transactions.IEnlistmentNotificationInternal.Prepare(System.Transactions.IPromotedEnlistment)
            System$Transactions$IEnlistmentNotificationInternal$Prepare()
            {
                return this.Prepare(...arguments);
            }
            //Generated interface implemetation for System.Transactions.IEnlistmentNotificationInternal.Commit(System.Transactions.IPromotedEnlistment)
            System$Transactions$IEnlistmentNotificationInternal$Commit()
            {
                return this.Commit(...arguments);
            }
            //Generated interface implemetation for System.Transactions.IEnlistmentNotificationInternal.Rollback(System.Transactions.IPromotedEnlistment)
            System$Transactions$IEnlistmentNotificationInternal$Rollback()
            {
                return this.Rollback(...arguments);
            }
            //Generated interface implemetation for System.Transactions.IEnlistmentNotificationInternal.InDoubt(System.Transactions.IPromotedEnlistment)
            System$Transactions$IEnlistmentNotificationInternal$InDoubt()
            {
                return this.InDoubt(...arguments);
            }
            static $h = 8698412;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":131073,"g":{"r":0,"d":0,"h":42958371372,"f":40},"n":"ClassSyncObject","d":8698412,"h":38663404076,"f":40},{"p":139067393,"g":{"r":0,"d":0,"h":55843273260,"f":34},"n":"PrepareCallback","d":8698412,"h":51548305964,"f":34},{"p":139067393,"g":{"r":0,"d":0,"h":73023142444,"f":34},"n":"CommitCallback","d":8698412,"h":68728175148,"f":34},{"p":139067393,"g":{"r":0,"d":0,"h":90203011628,"f":34},"n":"RollbackCallback","d":8698412,"h":85908044332,"f":34},{"p":139067393,"g":{"r":0,"d":0,"h":107382880812,"f":34},"n":"InDoubtCallback","d":8698412,"h":103087913516,"f":34}],"m":[{"r":65537,"p":[{"n":"volatiles","p":9353772,"f":4}],"n":"BroadcastCommitted","d":8698412,"h":21483534892,"f":40},{"r":65537,"p":[{"n":"volatiles","p":9353772,"f":4}],"n":"BroadcastRollback","d":8698412,"h":25778502188,"f":40},{"r":65537,"p":[{"n":"volatiles","p":9353772,"f":4}],"n":"BroadcastInDoubt","d":8698412,"h":30073469484,"f":40},{"r":65537,"p":[{"n":"state","p":131073}],"n":"PoolablePrepare","d":8698412,"h":60138240556,"f":36},{"r":65537,"p":[{"n":"state","p":131073}],"n":"PoolableCommit","d":8698412,"h":77318109740,"f":36},{"r":65537,"p":[{"n":"state","p":131073}],"n":"PoolableRollback","d":8698412,"h":94497978924,"f":36},{"r":65537,"p":[{"n":"state","p":131073}],"n":"PoolableInDoubt","d":8698412,"h":111677848108,"f":36},{"r":65537,"n":"InternalPrepare","d":8698412,"h":115972815404,"f":260},{"r":65537,"n":"InternalCommit","d":8698412,"h":120267782700,"f":260},{"r":65537,"n":"InternalRollback","d":8698412,"h":124562749996,"f":260},{"r":65537,"n":"InternalInDoubt","d":8698412,"h":128857717292,"f":260},{"r":65537,"p":[{"n":"en","p":2931244}],"n":"Prepare","d":8698412,"h":133152684588,"f":257},{"r":65537,"p":[{"n":"en","p":2931244}],"n":"Commit","d":8698412,"h":137447651884,"f":257},{"r":65537,"p":[{"n":"en","p":2931244}],"n":"Rollback","d":8698412,"h":141742619180,"f":257},{"r":65537,"p":[{"n":"en","p":2931244}],"n":"InDoubt","d":8698412,"h":146037586476,"f":257}],"l":[{"t":2800172,"n":"_transaction","d":8698412,"h":4303665708,"f":4},{"t":2931244,"n":"_promotedEnlistment","d":8698412,"h":8598633004,"f":8},{"t":2931244,"n":"_preparingEnlistment","d":8698412,"h":12893600300,"f":8},{"t":131073,"n":"s_classSyncObject","d":8698412,"h":34368436780,"f":34},{"t":139067393,"n":"s_prepareCallback","d":8698412,"h":47253338668,"f":34},{"t":139067393,"n":"s_commitCallback","d":8698412,"h":64433207852,"f":34},{"t":139067393,"n":"s_rollbackCallback","d":8698412,"h":81613077036,"f":34},{"t":139067393,"n":"s_inDoubtCallback","d":8698412,"h":98792946220,"f":34}],"c":[{"p":[{"n":"transaction","p":2800172}],"n":".ctor","o":"$ctor$1","d":8698412,"h":17188567596,"f":1}],"i":[2669100],"h":8698412}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stl.System.Transactions.IEnlistmentNotificationInternal ]; }
            static get $fullName() { return `System.Transactions.VolatileDemultiplexer`; }
        });
        
        $asm.$cls("$stl.System.Transactions.DurableEnlistmentState", ($self) => class DurableEnlistmentState extends $.$stl.System.Transactions.EnlistmentState
        {
            /*DurableEnlistmentActive?*/ static s_durableEnlistmentActive = null;
            /*DurableEnlistmentAborting?*/ static s_durableEnlistmentAborting = null;
            /*DurableEnlistmentCommitting?*/ static s_durableEnlistmentCommitting = null;
            /*DurableEnlistmentDelegated?*/ static s_durableEnlistmentDelegated = null;
            /*DurableEnlistmentEnded?*/ static s_durableEnlistmentEnded = null;
            /*object?*/ static s_classSyncObject = null;
            static /*DurableEnlistmentActive */ get DurableEnlistmentActive()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.DurableEnlistmentActive, $.$ref(() => $.$stl.System.Transactions.DurableEnlistmentState.s_durableEnlistmentActive, ($v) => $.$stl.System.Transactions.DurableEnlistmentState.s_durableEnlistmentActive = $v, $.$stl.System.Transactions.DurableEnlistmentActive), $.$ref(() => $.$stl.System.Transactions.DurableEnlistmentState.s_classSyncObject, ($v) => $.$stl.System.Transactions.DurableEnlistmentState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.DurableEnlistmentActive))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.DurableEnlistmentActive().$ctor$3();
                }));
            }
            static /*DurableEnlistmentAborting */ get DurableEnlistmentAborting()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.DurableEnlistmentAborting, $.$ref(() => $.$stl.System.Transactions.DurableEnlistmentState.s_durableEnlistmentAborting, ($v) => $.$stl.System.Transactions.DurableEnlistmentState.s_durableEnlistmentAborting = $v, $.$stl.System.Transactions.DurableEnlistmentAborting), $.$ref(() => $.$stl.System.Transactions.DurableEnlistmentState.s_classSyncObject, ($v) => $.$stl.System.Transactions.DurableEnlistmentState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.DurableEnlistmentAborting))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.DurableEnlistmentAborting().$ctor$3();
                }));
            }
            static /*DurableEnlistmentCommitting */ get DurableEnlistmentCommitting()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.DurableEnlistmentCommitting, $.$ref(() => $.$stl.System.Transactions.DurableEnlistmentState.s_durableEnlistmentCommitting, ($v) => $.$stl.System.Transactions.DurableEnlistmentState.s_durableEnlistmentCommitting = $v, $.$stl.System.Transactions.DurableEnlistmentCommitting), $.$ref(() => $.$stl.System.Transactions.DurableEnlistmentState.s_classSyncObject, ($v) => $.$stl.System.Transactions.DurableEnlistmentState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.DurableEnlistmentCommitting))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.DurableEnlistmentCommitting().$ctor$3();
                }));
            }
            static /*DurableEnlistmentDelegated */ get DurableEnlistmentDelegated()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.DurableEnlistmentDelegated, $.$ref(() => $.$stl.System.Transactions.DurableEnlistmentState.s_durableEnlistmentDelegated, ($v) => $.$stl.System.Transactions.DurableEnlistmentState.s_durableEnlistmentDelegated = $v, $.$stl.System.Transactions.DurableEnlistmentDelegated), $.$ref(() => $.$stl.System.Transactions.DurableEnlistmentState.s_classSyncObject, ($v) => $.$stl.System.Transactions.DurableEnlistmentState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.DurableEnlistmentDelegated))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.DurableEnlistmentDelegated().$ctor$3();
                }));
            }
            static /*DurableEnlistmentEnded */ get DurableEnlistmentEnded()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.DurableEnlistmentEnded, $.$ref(() => $.$stl.System.Transactions.DurableEnlistmentState.s_durableEnlistmentEnded, ($v) => $.$stl.System.Transactions.DurableEnlistmentState.s_durableEnlistmentEnded = $v, $.$stl.System.Transactions.DurableEnlistmentEnded), $.$ref(() => $.$stl.System.Transactions.DurableEnlistmentState.s_classSyncObject, ($v) => $.$stl.System.Transactions.DurableEnlistmentState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.DurableEnlistmentEnded))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.DurableEnlistmentEnded().$ctor$3();
                }));
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 1554988;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1948204,"p":[{"p":1292844,"g":{"r":0,"d":0,"h":34361293356,"f":40},"n":"DurableEnlistmentActive","d":1554988,"h":30066326060,"f":40},{"p":1227308,"g":{"r":0,"d":0,"h":42951227948,"f":36},"n":"DurableEnlistmentAborting","d":1554988,"h":38656260652,"f":36},{"p":1358380,"g":{"r":0,"d":0,"h":51541162540,"f":36},"n":"DurableEnlistmentCommitting","d":1554988,"h":47246195244,"f":36},{"p":1423916,"g":{"r":0,"d":0,"h":60131097132,"f":36},"n":"DurableEnlistmentDelegated","d":1554988,"h":55836129836,"f":36},{"p":1489452,"g":{"r":0,"d":0,"h":68721031724,"f":36},"n":"DurableEnlistmentEnded","d":1554988,"h":64426064428,"f":36}],"l":[{"t":1292844,"n":"s_durableEnlistmentActive","d":1554988,"h":4296522284,"f":34},{"t":1227308,"n":"s_durableEnlistmentAborting","d":1554988,"h":8591489580,"f":34},{"t":1358380,"n":"s_durableEnlistmentCommitting","d":1554988,"h":12886456876,"f":34},{"t":1423916,"n":"s_durableEnlistmentDelegated","d":1554988,"h":17181424172,"f":34},{"t":1489452,"n":"s_durableEnlistmentEnded","d":1554988,"h":21476391468,"f":34},{"t":131073,"n":"s_classSyncObject","d":1554988,"h":25771358764,"f":34}],"c":[{"n":".ctor","o":"$ctor$2","d":1554988,"h":73015999020,"f":4}],"h":1554988}; }
            static get $b() { return $.$stl.System.Transactions.EnlistmentState; }
            static get $fullName() { return `System.Transactions.DurableEnlistmentState`; }
        });
        
        $asm.$cls("$stl.System.Transactions.VolatileEnlistmentState", ($self) => class VolatileEnlistmentState extends $.$stl.System.Transactions.EnlistmentState
        {
            /*VolatileEnlistmentActive?*/ static s_volatileEnlistmentActive = null;
            /*VolatileEnlistmentPreparing?*/ static s_volatileEnlistmentPreparing = null;
            /*VolatileEnlistmentPrepared?*/ static s_volatileEnlistmentPrepared = null;
            /*VolatileEnlistmentSPC?*/ static s_volatileEnlistmentSPC = null;
            /*VolatileEnlistmentPreparingAborting?*/ static s_volatileEnlistmentPreparingAborting = null;
            /*VolatileEnlistmentAborting?*/ static s_volatileEnlistmentAborting = null;
            /*VolatileEnlistmentCommitting?*/ static s_volatileEnlistmentCommitting = null;
            /*VolatileEnlistmentInDoubt?*/ static s_volatileEnlistmentInDoubt = null;
            /*VolatileEnlistmentEnded?*/ static s_volatileEnlistmentEnded = null;
            /*VolatileEnlistmentDone?*/ static s_volatileEnlistmentDone = null;
            /*object?*/ static s_classSyncObject = null;
            static /*VolatileEnlistmentActive */ get VolatileEnlistmentActive()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.VolatileEnlistmentActive, $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentActive, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentActive = $v, $.$stl.System.Transactions.VolatileEnlistmentActive), $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.VolatileEnlistmentActive))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.VolatileEnlistmentActive().$ctor$3();
                }));
            }
            static /*VolatileEnlistmentPreparing */ get VolatileEnlistmentPreparing()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.VolatileEnlistmentPreparing, $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentPreparing, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentPreparing = $v, $.$stl.System.Transactions.VolatileEnlistmentPreparing), $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.VolatileEnlistmentPreparing))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.VolatileEnlistmentPreparing().$ctor$3();
                }));
            }
            static /*VolatileEnlistmentPrepared */ get VolatileEnlistmentPrepared()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.VolatileEnlistmentPrepared, $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentPrepared, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentPrepared = $v, $.$stl.System.Transactions.VolatileEnlistmentPrepared), $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.VolatileEnlistmentPrepared))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.VolatileEnlistmentPrepared().$ctor$3();
                }));
            }
            static /*VolatileEnlistmentSPC */ get VolatileEnlistmentSPC()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.VolatileEnlistmentSPC, $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentSPC, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentSPC = $v, $.$stl.System.Transactions.VolatileEnlistmentSPC), $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.VolatileEnlistmentSPC))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.VolatileEnlistmentSPC().$ctor$3();
                }));
            }
            static /*VolatileEnlistmentPreparingAborting */ get VolatileEnlistmentPreparingAborting()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.VolatileEnlistmentPreparingAborting, $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentPreparingAborting, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentPreparingAborting = $v, $.$stl.System.Transactions.VolatileEnlistmentPreparingAborting), $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.VolatileEnlistmentPreparingAborting))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.VolatileEnlistmentPreparingAborting().$ctor$3();
                }));
            }
            static /*VolatileEnlistmentAborting */ get VolatileEnlistmentAborting()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.VolatileEnlistmentAborting, $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentAborting, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentAborting = $v, $.$stl.System.Transactions.VolatileEnlistmentAborting), $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.VolatileEnlistmentAborting))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.VolatileEnlistmentAborting().$ctor$3();
                }));
            }
            static /*VolatileEnlistmentCommitting */ get VolatileEnlistmentCommitting()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.VolatileEnlistmentCommitting, $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentCommitting, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentCommitting = $v, $.$stl.System.Transactions.VolatileEnlistmentCommitting), $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.VolatileEnlistmentCommitting))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.VolatileEnlistmentCommitting().$ctor$3();
                }));
            }
            static /*VolatileEnlistmentInDoubt */ get VolatileEnlistmentInDoubt()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.VolatileEnlistmentInDoubt, $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentInDoubt, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentInDoubt = $v, $.$stl.System.Transactions.VolatileEnlistmentInDoubt), $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.VolatileEnlistmentInDoubt))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.VolatileEnlistmentInDoubt().$ctor$3();
                }));
            }
            static /*VolatileEnlistmentEnded */ get VolatileEnlistmentEnded()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.VolatileEnlistmentEnded, $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentEnded, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentEnded = $v, $.$stl.System.Transactions.VolatileEnlistmentEnded), $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.VolatileEnlistmentEnded))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.VolatileEnlistmentEnded().$ctor$3();
                }));
            }
            static /*VolatileEnlistmentDone */ get VolatileEnlistmentDone()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.VolatileEnlistmentDone, $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentDone, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentDone = $v, $.$stl.System.Transactions.VolatileEnlistmentDone), $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.VolatileEnlistmentDone))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.VolatileEnlistmentDone().$ctor$4();
                }));
            }
            /*byte[] */ RecoveryInformation(/*InternalEnlistment*/ enlistment)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException$1(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.VolEnlistNoRecoveryInfo, null, enlistment === null ? $.$spc.System.Guid.Empty : enlistment.DistributedTxId);
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 9484844;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1948204,"p":[{"p":8829484,"g":{"r":0,"d":0,"h":55844059692,"f":40},"n":"VolatileEnlistmentActive","d":9484844,"h":51549092396,"f":40},{"p":9222700,"g":{"r":0,"d":0,"h":64433994284,"f":36},"n":"VolatileEnlistmentPreparing","d":9484844,"h":60139026988,"f":36},{"p":9157164,"g":{"r":0,"d":0,"h":73023928876,"f":36},"n":"VolatileEnlistmentPrepared","d":9484844,"h":68728961580,"f":36},{"p":9419308,"g":{"r":0,"d":0,"h":81613863468,"f":36},"n":"VolatileEnlistmentSPC","d":9484844,"h":77318896172,"f":36},{"p":9288236,"g":{"r":0,"d":0,"h":90203798060,"f":36},"n":"VolatileEnlistmentPreparingAborting","d":9484844,"h":85908830764,"f":36},{"p":8763948,"g":{"r":0,"d":0,"h":98793732652,"f":36},"n":"VolatileEnlistmentAborting","d":9484844,"h":94498765356,"f":36},{"p":8895020,"g":{"r":0,"d":0,"h":107383667244,"f":36},"n":"VolatileEnlistmentCommitting","d":9484844,"h":103088699948,"f":36},{"p":9091628,"g":{"r":0,"d":0,"h":115973601836,"f":36},"n":"VolatileEnlistmentInDoubt","d":9484844,"h":111678634540,"f":36},{"p":9026092,"g":{"r":0,"d":0,"h":124563536428,"f":36},"n":"VolatileEnlistmentEnded","d":9484844,"h":120268569132,"f":36},{"p":8960556,"g":{"r":0,"d":0,"h":133153471020,"f":36},"n":"VolatileEnlistmentDone","d":9484844,"h":128858503724,"f":36}],"m":[{"r":0,"p":[{"n":"enlistment","p":2734636}],"n":"RecoveryInformation","d":9484844,"h":137448438316,"f":32776}],"l":[{"t":8829484,"n":"s_volatileEnlistmentActive","d":9484844,"h":4304452140,"f":34},{"t":9222700,"n":"s_volatileEnlistmentPreparing","d":9484844,"h":8599419436,"f":34},{"t":9157164,"n":"s_volatileEnlistmentPrepared","d":9484844,"h":12894386732,"f":34},{"t":9419308,"n":"s_volatileEnlistmentSPC","d":9484844,"h":17189354028,"f":34},{"t":9288236,"n":"s_volatileEnlistmentPreparingAborting","d":9484844,"h":21484321324,"f":34},{"t":8763948,"n":"s_volatileEnlistmentAborting","d":9484844,"h":25779288620,"f":34},{"t":8895020,"n":"s_volatileEnlistmentCommitting","d":9484844,"h":30074255916,"f":34},{"t":9091628,"n":"s_volatileEnlistmentInDoubt","d":9484844,"h":34369223212,"f":34},{"t":9026092,"n":"s_volatileEnlistmentEnded","d":9484844,"h":38664190508,"f":34},{"t":8960556,"n":"s_volatileEnlistmentDone","d":9484844,"h":42959157804,"f":34},{"t":131073,"n":"s_classSyncObject","d":9484844,"h":47254125100,"f":34}],"c":[{"n":".ctor","o":"$ctor$2","d":9484844,"h":141743405612,"f":4}],"h":9484844}; }
            static get $b() { return $.$stl.System.Transactions.EnlistmentState; }
            static get $fullName() { return `System.Transactions.VolatileEnlistmentState`; }
        });
        
        $asm.$cls("$stl.System.Transactions.ActiveStates", ($self) => class ActiveStates extends $.$stl.System.Transactions.TransactionState
        {
            /*TransactionStatus */ get_Status(/*InternalTransaction*/ tx)
            {
                return 0/*TransactionStatus.Active*/;
            }
            /*void */ AddOutcomeRegistrant(/*InternalTransaction*/ tx, /*TransactionCompletedEventHandler?*/ transactionCompletedDelegate)
            {
                tx._transactionCompletedDelegate = $.$cast($.$spc.System.Delegate.Combine(tx._transactionCompletedDelegate, transactionCompletedDelegate), $.$stl.System.Transactions.TransactionCompletedEventHandler);
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 244268;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":5749292,"m":[{"r":8436268,"p":[{"n":"tx","p":2800172}],"n":"get_Status","d":244268,"h":4295211564,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"transactionCompletedDelegate","p":4438572}],"n":"AddOutcomeRegistrant","d":244268,"h":8590178860,"f":32776}],"c":[{"n":".ctor","o":"$ctor$2","d":244268,"h":12885146156,"f":4}],"h":244268}; }
            static get $b() { return $.$stl.System.Transactions.TransactionState; }
            static get $fullName() { return `System.Transactions.ActiveStates`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateEnded", ($self) => class TransactionStateEnded extends $.$stl.System.Transactions.TransactionState
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                if (tx._needPulse)
                {
                    $.$spc.System.Threading.Monitor.Pulse(tx);
                }
            }
            /*void */ AddOutcomeRegistrant(/*InternalTransaction*/ tx, /*TransactionCompletedEventHandler?*/ transactionCompletedDelegate)
            {
                if (transactionCompletedDelegate !== null)
                {
                    /*TransactionEventArgs*/ let args = new $.$stl.System.Transactions.TransactionEventArgs().$ctor$2();
                    args._transaction = tx._outcomeSource.InternalClone();
                    transactionCompletedDelegate.Invoke(args._transaction, args);
                }
            }
            /*bool */ IsCompleted(/*InternalTransaction*/ tx)
            {
                return true;
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 6470188;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":5749292,"m":[{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"EnterState","d":6470188,"h":4301437484,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"transactionCompletedDelegate","p":4438572}],"n":"AddOutcomeRegistrant","d":6470188,"h":8596404780,"f":32776},{"r":262145,"p":[{"n":"tx","p":2800172}],"n":"IsCompleted","d":6470188,"h":12891372076,"f":32776}],"c":[{"n":".ctor","o":"$ctor$2","d":6470188,"h":17186339372,"f":4}],"h":6470188}; }
            static get $b() { return $.$stl.System.Transactions.TransactionState; }
            static get $fullName() { return `System.Transactions.TransactionStateEnded`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedBase", ($self) => class TransactionStatePromotedBase extends $.$stl.System.Transactions.TransactionState
        {
            /*TransactionStatus */ get_Status(/*InternalTransaction*/ tx)
            {
                return 0/*TransactionStatus.Active*/;
            }
            /*Enlistment */ EnlistVolatile(/*InternalTransaction*/ tx, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(tx.PromotedTransaction !== null, "Promoted state not valid for transaction.");
                $.$spc.System.Threading.Monitor.Exit(tx);
                try
                {
                    /*Enlistment*/ let en = new $.$stl.System.Transactions.Enlistment().$ctor$5(enlistmentNotification, tx, atomicTransaction);
                    $.$stl.System.Transactions.EnlistmentState.EnlistmentStatePromoted.EnterState(en.InternalEnlistment);
                    en.InternalEnlistment.PromotedEnlistment = tx.PromotedTransaction.EnlistVolatile(en.InternalEnlistment, enlistmentOptions);
                    return en;
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(tx);
                    }
                }
            }
            /*Enlistment */ EnlistVolatile$1(/*InternalTransaction*/ tx, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(tx.PromotedTransaction !== null, "Promoted state not valid for transaction.");
                $.$spc.System.Threading.Monitor.Exit(tx);
                try
                {
                    /*Enlistment*/ let en = new $.$stl.System.Transactions.Enlistment().$ctor$5(enlistmentNotification, tx, atomicTransaction);
                    $.$stl.System.Transactions.EnlistmentState.EnlistmentStatePromoted.EnterState(en.InternalEnlistment);
                    en.InternalEnlistment.PromotedEnlistment = tx.PromotedTransaction.EnlistVolatile(en.InternalEnlistment, enlistmentOptions);
                    return en;
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(tx);
                    }
                }
            }
            /*Enlistment */ EnlistDurable(/*InternalTransaction*/ tx, /*Guid*/ resourceManagerIdentifier, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(tx.PromotedTransaction !== null, "Promoted state not valid for transaction.");
                tx.ThrowIfPromoterTypeIsNotMSDTC();
                $.$spc.System.Threading.Monitor.Exit(tx);
                try
                {
                    /*Enlistment*/ let en = new $.$stl.System.Transactions.Enlistment().$ctor$2(resourceManagerIdentifier, tx, enlistmentNotification, null, atomicTransaction);
                    $.$stl.System.Transactions.EnlistmentState.EnlistmentStatePromoted.EnterState(en.InternalEnlistment);
                    en.InternalEnlistment.PromotedEnlistment = tx.PromotedTransaction.EnlistDurable(resourceManagerIdentifier, $.$cast(en.InternalEnlistment, $.$stl.System.Transactions.DurableInternalEnlistment), false, enlistmentOptions);
                    return en;
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(tx);
                    }
                }
            }
            /*Enlistment */ EnlistDurable$1(/*InternalTransaction*/ tx, /*Guid*/ resourceManagerIdentifier, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(tx.PromotedTransaction !== null, "Promoted state not valid for transaction.");
                tx.ThrowIfPromoterTypeIsNotMSDTC();
                $.$spc.System.Threading.Monitor.Exit(tx);
                try
                {
                    /*Enlistment*/ let en = new $.$stl.System.Transactions.Enlistment().$ctor$2(resourceManagerIdentifier, tx, enlistmentNotification, enlistmentNotification, atomicTransaction);
                    $.$stl.System.Transactions.EnlistmentState.EnlistmentStatePromoted.EnterState(en.InternalEnlistment);
                    en.InternalEnlistment.PromotedEnlistment = tx.PromotedTransaction.EnlistDurable(resourceManagerIdentifier, $.$cast(en.InternalEnlistment, $.$stl.System.Transactions.DurableInternalEnlistment), true, enlistmentOptions);
                    return en;
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(tx);
                    }
                }
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(tx.PromotedTransaction !== null, "Promoted state not valid for transaction.");
                tx._innerException ??= e;
                $.$spc.System.Threading.Monitor.Exit(tx);
                try
                {
                    tx.PromotedTransaction.Rollback();
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(tx);
                    }
                }
            }
            /*Guid */ get_Identifier(/*InternalTransaction?*/ tx)
            {
                if (tx !== null && tx.PromotedTransaction !== null)
                {
                    return tx.PromotedTransaction.Identifier;
                }
                else 
                {
                    return $.$spc.System.Guid.Empty;
                }
            }
            /*void */ AddOutcomeRegistrant(/*InternalTransaction*/ tx, /*TransactionCompletedEventHandler?*/ transactionCompletedDelegate)
            {
                tx._transactionCompletedDelegate = $.$cast($.$spc.System.Delegate.Combine(tx._transactionCompletedDelegate, transactionCompletedDelegate), $.$stl.System.Transactions.TransactionCompletedEventHandler);
            }
            /*void */ BeginCommit(/*InternalTransaction*/ tx, /*bool*/ asyncCommit, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                tx._asyncCommit = asyncCommit;
                tx._asyncCallback = asyncCallback;
                tx._asyncState = asyncState;
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedCommitting.EnterState(tx);
            }
            /*void */ RestartCommitIfNeeded(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedP0Wave.EnterState(tx);
            }
            /*bool */ EnlistPromotableSinglePhase(/*InternalTransaction*/ tx, /*IPromotableSinglePhaseNotification*/ promotableSinglePhaseNotification, /*Transaction*/ atomicTransaction, /*Guid*/ promoterType)
            {
                return false;
            }
            /*void */ CompleteBlockingClone(/*InternalTransaction*/ tx)
            {
                if (tx._phase0Volatiles._dependentClones > 0)
                {
                    tx._phase0Volatiles._dependentClones--;
                    $.$spc.System.Diagnostics.Debug.Assert$1(tx._phase0Volatiles._preparedVolatileEnlistments <= ((tx._phase0Volatiles._volatileEnlistmentCount + tx._phase0Volatiles._dependentClones) | 0), "tx._phase0Volatiles._preparedVolatileEnlistments <=\r\n                    tx._phase0Volatiles._volatileEnlistmentCount + tx._phase0Volatiles._dependentClones");
                    if (tx._phase0Volatiles._preparedVolatileEnlistments === ((tx._phase0VolatileWaveCount + tx._phase0Volatiles._dependentClones) | 0))
                    {
                        tx.State.Phase0VolatilePrepareDone(tx);
                    }
                }
                else 
                {
                    tx._phase0WaveDependentCloneCount--;
                    $.$spc.System.Diagnostics.Debug.Assert$1(tx._phase0WaveDependentCloneCount >= 0, "tx._phase0WaveDependentCloneCount >= 0");
                    if (tx._phase0WaveDependentCloneCount === 0)
                    {
                        /*OletxDependentTransaction*/ let dtx = tx._phase0WaveDependentClone;
                        tx._phase0WaveDependentClone = null;
                        $.$spc.System.Threading.Monitor.Exit(tx);
                        try
                        {
                            try
                            {
                                dtx.Complete();
                            }
                            finally
                            {
                                {
                                    dtx.Dispose();
                                }
                            }
                        }
                        finally
                        {
                            {
                                $.$spc.System.Threading.Monitor.Enter(tx);
                            }
                        }
                    }
                }
            }
            /*void */ CompleteAbortingClone(/*InternalTransaction*/ tx)
            {
                if (null !== tx._phase1Volatiles.VolatileDemux)
                {
                    tx._phase1Volatiles._dependentClones--;
                    $.$spc.System.Diagnostics.Debug.Assert$1(tx._phase1Volatiles._dependentClones >= 0, "tx._phase1Volatiles._dependentClones >= 0");
                }
                else 
                {
                    tx._abortingDependentCloneCount--;
                    $.$spc.System.Diagnostics.Debug.Assert$1(0 <= tx._abortingDependentCloneCount, "0 <= tx._abortingDependentCloneCount");
                    if (0 === tx._abortingDependentCloneCount)
                    {
                        /*OletxDependentTransaction*/ let dtx = tx._abortingDependentClone;
                        tx._abortingDependentClone = null;
                        $.$spc.System.Threading.Monitor.Exit(tx);
                        try
                        {
                            try
                            {
                                dtx.Complete();
                            }
                            finally
                            {
                                {
                                    dtx.Dispose();
                                }
                            }
                        }
                        finally
                        {
                            {
                                $.$spc.System.Threading.Monitor.Enter(tx);
                            }
                        }
                    }
                }
            }
            /*void */ CreateBlockingClone(/*InternalTransaction*/ tx)
            {
                if (tx._phase0WaveDependentClone === null)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(tx.PromotedTransaction !== null, "tx.PromotedTransaction != null");
                    tx._phase0WaveDependentClone = tx.PromotedTransaction.DependentClone(true);
                }
                tx._phase0WaveDependentCloneCount++;
            }
            /*void */ CreateAbortingClone(/*InternalTransaction*/ tx)
            {
                if (null !== tx._phase1Volatiles.VolatileDemux)
                {
                    tx._phase1Volatiles._dependentClones++;
                }
                else 
                {
                    if (null === tx._abortingDependentClone)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(tx.PromotedTransaction !== null, "tx.PromotedTransaction != null");
                        tx._abortingDependentClone = tx.PromotedTransaction.DependentClone(false);
                    }
                    tx._abortingDependentCloneCount++;
                }
            }
            /*bool */ ContinuePhase0Prepares()
            {
                return true;
            }
            /*void */ GetObjectData(/*InternalTransaction*/ tx, /*SerializationInfo*/ serializationInfo, /*StreamingContext*/ context)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(tx.PromotedTransaction !== null, "Promoted state not valid for transaction.");
                tx.ThrowIfPromoterTypeIsNotMSDTC();
                /*OletxTransaction*/ let serializableTx = tx.PromotedTransaction;
                if (serializableTx === null)
                {
                    throw new $.$spc.System.NotSupportedException().$ctor$9();
                }
                serializationInfo.FullTypeName = $.$spc.System.Object.GetType.call(serializableTx).FullName;
                serializableTx.GetObjectData(serializationInfo, context);
            }
            /*void */ ChangeStatePromotedAborted(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedAborted.EnterState(tx);
            }
            /*void */ ChangeStatePromotedCommitted(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedCommitted.EnterState(tx);
            }
            /*void */ InDoubtFromDtc(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedIndoubt.EnterState(tx);
            }
            /*void */ InDoubtFromEnlistment(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedIndoubt.EnterState(tx);
            }
            /*void */ ChangeStateAbortedDuringPromotion(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStateAborted.EnterState(tx);
            }
            /*void */ Timeout(/*InternalTransaction*/ tx)
            {
                try
                {
                    tx._innerException ??= new $.$spc.System.TimeoutException().$ctor$10($.$stl.System.SR.TraceTransactionTimeout);
                    $.$spc.System.Diagnostics.Debug.Assert$1(tx.PromotedTransaction !== null, "tx.PromotedTransaction != null");
                    tx.PromotedTransaction.Rollback();
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.TransactionTimeout(tx.TransactionTraceId);
                    }
                }
                catch(te)
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.ExceptionConsumed$1(te);
                    }
                }
            }
            /*void */ Promote(/*InternalTransaction*/ tx)
            {
            }
            /*byte[] */ PromotedToken(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(tx.promotedToken !== null, "InternalTransaction.promotedToken is null in TransactionStateDelegatedNonMSDTCBase or one of its derived classes.");
                return tx.promotedToken;
            }
            /*void */ Phase0VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ Phase1VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 6928940;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":5749292,"m":[{"r":8436268,"p":[{"n":"tx","p":2800172}],"n":"get_Status","d":6928940,"h":4301896236,"f":32776},{"r":1751596,"p":[{"n":"tx","p":2800172},{"n":"enlistmentNotification","p":2603564},{"n":"enlistmentOptions","p":1882668},{"n":"atomicTransaction","p":4307500}],"n":"EnlistVolatile","d":6928940,"h":8596863532,"f":32776},{"r":1751596,"p":[{"n":"tx","p":2800172},{"n":"enlistmentNotification","p":3062316},{"n":"enlistmentOptions","p":1882668},{"n":"atomicTransaction","p":4307500}],"n":"EnlistVolatile","o":"@$1","d":6928940,"h":12891830828,"f":32776},{"r":1751596,"p":[{"n":"tx","p":2800172},{"n":"resourceManagerIdentifier","p":56164353},{"n":"enlistmentNotification","p":2603564},{"n":"enlistmentOptions","p":1882668},{"n":"atomicTransaction","p":4307500}],"n":"EnlistDurable","d":6928940,"h":17186798124,"f":32776},{"r":1751596,"p":[{"n":"tx","p":2800172},{"n":"resourceManagerIdentifier","p":56164353},{"n":"enlistmentNotification","p":3062316},{"n":"enlistmentOptions","p":1882668},{"n":"atomicTransaction","p":4307500}],"n":"EnlistDurable","o":"@$1","d":6928940,"h":21481765420,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"e","p":47185921}],"n":"Rollback","d":6928940,"h":25776732716,"f":32776},{"r":56164353,"p":[{"n":"tx","p":2800172}],"n":"get_Identifier","d":6928940,"h":30071700012,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"transactionCompletedDelegate","p":4438572}],"n":"AddOutcomeRegistrant","d":6928940,"h":34366667308,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"asyncCommit","p":262145},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":6928940,"h":38661634604,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"RestartCommitIfNeeded","d":6928940,"h":42956601900,"f":32776},{"r":262145,"p":[{"n":"tx","p":2800172},{"n":"promotableSinglePhaseNotification","p":2865708},{"n":"atomicTransaction","p":4307500},{"n":"promoterType","p":56164353}],"n":"EnlistPromotableSinglePhase","d":6928940,"h":47251569196,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"CompleteBlockingClone","d":6928940,"h":51546536492,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"CompleteAbortingClone","d":6928940,"h":55841503788,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"CreateBlockingClone","d":6928940,"h":60136471084,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"CreateAbortingClone","d":6928940,"h":64431438380,"f":32776},{"r":262145,"n":"ContinuePhase0Prepares","d":6928940,"h":68726405676,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"serializationInfo","p":113967105},{"n":"context","p":114098177}],"n":"GetObjectData","d":6928940,"h":73021372972,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"ChangeStatePromotedAborted","d":6928940,"h":77316340268,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"ChangeStatePromotedCommitted","d":6928940,"h":81611307564,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"InDoubtFromDtc","d":6928940,"h":85906274860,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"InDoubtFromEnlistment","d":6928940,"h":90201242156,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"ChangeStateAbortedDuringPromotion","d":6928940,"h":94496209452,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"Timeout","d":6928940,"h":98791176748,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"Promote","d":6928940,"h":103086144044,"f":32776},{"r":0,"p":[{"n":"tx","p":2800172}],"n":"PromotedToken","d":6928940,"h":107381111340,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"Phase0VolatilePrepareDone","d":6928940,"h":111676078636,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"Phase1VolatilePrepareDone","d":6928940,"h":115971045932,"f":32776}],"c":[{"n":".ctor","o":"$ctor$2","d":6928940,"h":120266013228,"f":4}],"h":6928940}; }
            static get $b() { return $.$stl.System.Transactions.TransactionState; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedBase`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedNonMSDTCBase", ($self) => class TransactionStatePromotedNonMSDTCBase extends $.$stl.System.Transactions.TransactionState
        {
            /*TransactionStatus */ get_Status(/*InternalTransaction*/ tx)
            {
                return 0/*TransactionStatus.Active*/;
            }
            /*Enlistment */ EnlistVolatile(/*InternalTransaction*/ tx, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                /*Enlistment*/ let enlistment = new $.$stl.System.Transactions.Enlistment().$ctor$3(tx, enlistmentNotification, null, atomicTransaction, enlistmentOptions);
                if ((enlistmentOptions & 1/*EnlistmentOptions.EnlistDuringPrepareRequired*/) !== 0)
                {
                    $.$stl.System.Transactions.TransactionState.AddVolatileEnlistment($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase0Volatiles, ($v) => tx._phase0Volatiles = $v, null), enlistment);
                }
                else 
                {
                    $.$stl.System.Transactions.TransactionState.AddVolatileEnlistment($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase1Volatiles, ($v) => tx._phase1Volatiles = $v, null), enlistment);
                }
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionstateEnlist(enlistment.InternalEnlistment.EnlistmentTraceId, 0/*EnlistmentType.Volatile*/, enlistmentOptions);
                }
                return enlistment;
            }
            /*Enlistment */ EnlistVolatile$1(/*InternalTransaction*/ tx, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                /*Enlistment*/ let enlistment = new $.$stl.System.Transactions.Enlistment().$ctor$3(tx, enlistmentNotification, enlistmentNotification, atomicTransaction, enlistmentOptions);
                if ((enlistmentOptions & 1/*EnlistmentOptions.EnlistDuringPrepareRequired*/) !== 0)
                {
                    $.$stl.System.Transactions.TransactionState.AddVolatileEnlistment($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase0Volatiles, ($v) => tx._phase0Volatiles = $v, null), enlistment);
                }
                else 
                {
                    $.$stl.System.Transactions.TransactionState.AddVolatileEnlistment($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase1Volatiles, ($v) => tx._phase1Volatiles = $v, null), enlistment);
                }
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionstateEnlist(enlistment.InternalEnlistment.EnlistmentTraceId, 0/*EnlistmentType.Volatile*/, enlistmentOptions);
                }
                return enlistment;
            }
            /*Enlistment */ EnlistDurable(/*InternalTransaction*/ tx, /*Guid*/ resourceManagerIdentifier, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                throw new $.$stl.System.Transactions.TransactionPromotionException().$ctor$15($.$stl.System.SR.Format($.$stl.System.SR.PromoterTypeUnrecognized, $.$spc.System.Guid.ToString.call(tx._promoterType)), tx._innerException);
            }
            /*Enlistment */ EnlistDurable$1(/*InternalTransaction*/ tx, /*Guid*/ resourceManagerIdentifier, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                throw new $.$stl.System.Transactions.TransactionPromotionException().$ctor$15($.$stl.System.SR.Format($.$stl.System.SR.PromoterTypeUnrecognized, $.$spc.System.Guid.ToString.call(tx._promoterType)), tx._innerException);
            }
            /*bool */ EnlistPromotableSinglePhase(/*InternalTransaction*/ tx, /*IPromotableSinglePhaseNotification*/ promotableSinglePhaseNotification, /*Transaction*/ atomicTransaction, /*Guid*/ promoterType)
            {
                return false;
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(tx._durableEnlistment !== null, "PromotedNonMSDTC state is not valid for transaction");
                tx._innerException ??= e;
                $.$stl.System.Transactions.TransactionState.TransactionStateAborted.EnterState(tx);
            }
            /*Guid */ get_Identifier(/*InternalTransaction*/ tx)
            {
                return tx._distributedTransactionIdentifierNonMSDTC;
            }
            /*void */ AddOutcomeRegistrant(/*InternalTransaction*/ tx, /*TransactionCompletedEventHandler?*/ transactionCompletedDelegate)
            {
                tx._transactionCompletedDelegate = $.$cast($.$spc.System.Delegate.Combine(tx._transactionCompletedDelegate, transactionCompletedDelegate), $.$stl.System.Transactions.TransactionCompletedEventHandler);
            }
            /*void */ BeginCommit(/*InternalTransaction*/ tx, /*bool*/ asyncCommit, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                tx._asyncCommit = asyncCommit;
                tx._asyncCallback = asyncCallback;
                tx._asyncState = asyncState;
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedNonMSDTCPhase0.EnterState(tx);
            }
            /*void */ CompleteBlockingClone(/*InternalTransaction*/ tx)
            {
                if (tx._phase0Volatiles._dependentClones > 0)
                {
                    tx._phase0Volatiles._dependentClones--;
                    $.$spc.System.Diagnostics.Debug.Assert$1(tx._phase0Volatiles._preparedVolatileEnlistments <= ((tx._phase0Volatiles._volatileEnlistmentCount + tx._phase0Volatiles._dependentClones) | 0), "tx._phase0Volatiles._preparedVolatileEnlistments <=\r\n                    tx._phase0Volatiles._volatileEnlistmentCount + tx._phase0Volatiles._dependentClones");
                    if (tx._phase0Volatiles._preparedVolatileEnlistments === ((tx._phase0VolatileWaveCount + tx._phase0Volatiles._dependentClones) | 0))
                    {
                        tx.State.Phase0VolatilePrepareDone(tx);
                    }
                }
            }
            /*void */ CompleteAbortingClone(/*InternalTransaction*/ tx)
            {
                tx._phase1Volatiles._dependentClones--;
                $.$spc.System.Diagnostics.Debug.Assert$1(tx._phase1Volatiles._dependentClones >= 0, "tx._phase1Volatiles._dependentClones >= 0");
            }
            /*void */ CreateBlockingClone(/*InternalTransaction*/ tx)
            {
                tx._phase0Volatiles._dependentClones++;
            }
            /*void */ CreateAbortingClone(/*InternalTransaction*/ tx)
            {
                tx._phase1Volatiles._dependentClones++;
            }
            /*bool */ ContinuePhase0Prepares()
            {
                return true;
            }
            /*void */ GetObjectData(/*InternalTransaction*/ tx, /*SerializationInfo*/ serializationInfo, /*StreamingContext*/ context)
            {
                throw new $.$stl.System.Transactions.TransactionPromotionException().$ctor$15($.$stl.System.SR.Format($.$stl.System.SR.PromoterTypeUnrecognized, $.$spc.System.Guid.ToString.call(tx._promoterType)), tx._innerException);
            }
            /*void */ ChangeStateTransactionAborted(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                tx._innerException ??= e;
                $.$stl.System.Transactions.TransactionState.TransactionStateAborted.EnterState(tx);
            }
            /*void */ InDoubtFromEnlistment(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedNonMSDTCIndoubt.EnterState(tx);
            }
            /*void */ ChangeStateAbortedDuringPromotion(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStateAborted.EnterState(tx);
            }
            /*void */ Timeout(/*InternalTransaction*/ tx)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionTimeout(tx.TransactionTraceId);
                }
                /*TimeoutException*/ let e = new $.$spc.System.TimeoutException().$ctor$10($.$stl.System.SR.TraceTransactionTimeout);
                this.Rollback(tx, e);
            }
            /*void */ Promote(/*InternalTransaction*/ tx)
            {
            }
            /*void */ Phase0VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ Phase1VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            /*byte[] */ PromotedToken(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(tx.promotedToken !== null, "InternalTransaction.promotedToken is null in TransactionStateDelegatedNonMSDTCBase or one of its derived classes.");
                return tx.promotedToken;
            }
            /*void */ DisposeRoot(/*InternalTransaction*/ tx)
            {
                tx.State.Rollback(tx, null);
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 7322156;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":5749292,"m":[{"r":8436268,"p":[{"n":"tx","p":2800172}],"n":"get_Status","d":7322156,"h":4302289452,"f":32776},{"r":1751596,"p":[{"n":"tx","p":2800172},{"n":"enlistmentNotification","p":2603564},{"n":"enlistmentOptions","p":1882668},{"n":"atomicTransaction","p":4307500}],"n":"EnlistVolatile","d":7322156,"h":8597256748,"f":32776},{"r":1751596,"p":[{"n":"tx","p":2800172},{"n":"enlistmentNotification","p":3062316},{"n":"enlistmentOptions","p":1882668},{"n":"atomicTransaction","p":4307500}],"n":"EnlistVolatile","o":"@$1","d":7322156,"h":12892224044,"f":32776},{"r":1751596,"p":[{"n":"tx","p":2800172},{"n":"resourceManagerIdentifier","p":56164353},{"n":"enlistmentNotification","p":2603564},{"n":"enlistmentOptions","p":1882668},{"n":"atomicTransaction","p":4307500}],"n":"EnlistDurable","d":7322156,"h":17187191340,"f":32776},{"r":1751596,"p":[{"n":"tx","p":2800172},{"n":"resourceManagerIdentifier","p":56164353},{"n":"enlistmentNotification","p":3062316},{"n":"enlistmentOptions","p":1882668},{"n":"atomicTransaction","p":4307500}],"n":"EnlistDurable","o":"@$1","d":7322156,"h":21482158636,"f":32776},{"r":262145,"p":[{"n":"tx","p":2800172},{"n":"promotableSinglePhaseNotification","p":2865708},{"n":"atomicTransaction","p":4307500},{"n":"promoterType","p":56164353}],"n":"EnlistPromotableSinglePhase","d":7322156,"h":25777125932,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"e","p":47185921}],"n":"Rollback","d":7322156,"h":30072093228,"f":32776},{"r":56164353,"p":[{"n":"tx","p":2800172}],"n":"get_Identifier","d":7322156,"h":34367060524,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"transactionCompletedDelegate","p":4438572}],"n":"AddOutcomeRegistrant","d":7322156,"h":38662027820,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"asyncCommit","p":262145},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":7322156,"h":42956995116,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"CompleteBlockingClone","d":7322156,"h":47251962412,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"CompleteAbortingClone","d":7322156,"h":51546929708,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"CreateBlockingClone","d":7322156,"h":55841897004,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"CreateAbortingClone","d":7322156,"h":60136864300,"f":32776},{"r":262145,"n":"ContinuePhase0Prepares","d":7322156,"h":64431831596,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"serializationInfo","p":113967105},{"n":"context","p":114098177}],"n":"GetObjectData","d":7322156,"h":68726798892,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"e","p":47185921}],"n":"ChangeStateTransactionAborted","d":7322156,"h":73021766188,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"InDoubtFromEnlistment","d":7322156,"h":77316733484,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"ChangeStateAbortedDuringPromotion","d":7322156,"h":81611700780,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"Timeout","d":7322156,"h":85906668076,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"Promote","d":7322156,"h":90201635372,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"Phase0VolatilePrepareDone","d":7322156,"h":94496602668,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"Phase1VolatilePrepareDone","d":7322156,"h":98791569964,"f":32776},{"r":0,"p":[{"n":"tx","p":2800172}],"n":"PromotedToken","d":7322156,"h":103086537260,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"DisposeRoot","d":7322156,"h":107381504556,"f":32776}],"c":[{"n":".ctor","o":"$ctor$2","d":7322156,"h":111676471852,"f":4}],"h":7322156}; }
            static get $b() { return $.$stl.System.Transactions.TransactionState; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedNonMSDTCBase`; }
        });
        
        $asm.$cls("$stl.System.Transactions.EnlistableStates", ($self) => class EnlistableStates extends $.$stl.System.Transactions.ActiveStates
        {
            /*Enlistment */ EnlistDurable(/*InternalTransaction*/ tx, /*Guid*/ resourceManagerIdentifier, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                tx.ThrowIfPromoterTypeIsNotMSDTC();
                tx._promoteState.EnterState(tx);
                return tx.State.EnlistDurable(tx, resourceManagerIdentifier, enlistmentNotification, enlistmentOptions, atomicTransaction);
            }
            /*Enlistment */ EnlistDurable$1(/*InternalTransaction*/ tx, /*Guid*/ resourceManagerIdentifier, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                tx.ThrowIfPromoterTypeIsNotMSDTC();
                if (tx._durableEnlistment !== null || (enlistmentOptions & 1/*EnlistmentOptions.EnlistDuringPrepareRequired*/) !== 0)
                {
                    tx._promoteState.EnterState(tx);
                    return tx.State.EnlistDurable$1(tx, resourceManagerIdentifier, enlistmentNotification, enlistmentOptions, atomicTransaction);
                }
                /*Enlistment*/ let en = new $.$stl.System.Transactions.Enlistment().$ctor$2(resourceManagerIdentifier, tx, enlistmentNotification, enlistmentNotification, atomicTransaction);
                tx._durableEnlistment = en.InternalEnlistment;
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentActive.EnterState(tx._durableEnlistment);
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionstateEnlist(tx._durableEnlistment.EnlistmentTraceId, 1/*EnlistmentType.Durable*/, 0/*EnlistmentOptions.None*/);
                }
                return en;
            }
            /*void */ Timeout(/*InternalTransaction*/ tx)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionTimeout(tx.TransactionTraceId);
                }
                /*TimeoutException*/ let e = new $.$spc.System.TimeoutException().$ctor$10($.$stl.System.SR.TraceTransactionTimeout);
                this.Rollback(tx, e);
            }
            /*void */ GetObjectData(/*InternalTransaction*/ tx, /*SerializationInfo*/ serializationInfo, /*StreamingContext*/ context)
            {
                tx.ThrowIfPromoterTypeIsNotMSDTC();
                tx._promoteState.EnterState(tx);
                tx.State.GetObjectData(tx, serializationInfo, context);
            }
            /*void */ CompleteBlockingClone(/*InternalTransaction*/ tx)
            {
                tx._phase0Volatiles._dependentClones--;
                $.$spc.System.Diagnostics.Debug.Assert$1(tx._phase0Volatiles._dependentClones >= 0, "tx._phase0Volatiles._dependentClones >= 0");
                $.$spc.System.Diagnostics.Debug.Assert$1(tx._phase0Volatiles._preparedVolatileEnlistments <= ((tx._phase0Volatiles._volatileEnlistmentCount + tx._phase0Volatiles._dependentClones) | 0), "tx._phase0Volatiles._preparedVolatileEnlistments <=\r\n                tx._phase0Volatiles._volatileEnlistmentCount + tx._phase0Volatiles._dependentClones");
                if (tx._phase0Volatiles._preparedVolatileEnlistments === ((tx._phase0VolatileWaveCount + tx._phase0Volatiles._dependentClones) | 0))
                {
                    tx.State.Phase0VolatilePrepareDone(tx);
                }
            }
            /*void */ CompleteAbortingClone(/*InternalTransaction*/ tx)
            {
                tx._phase1Volatiles._dependentClones--;
                $.$spc.System.Diagnostics.Debug.Assert$1(tx._phase1Volatiles._dependentClones >= 0, "tx._phase1Volatiles._dependentClones >= 0");
            }
            /*void */ CreateBlockingClone(/*InternalTransaction*/ tx)
            {
                tx._phase0Volatiles._dependentClones++;
            }
            /*void */ CreateAbortingClone(/*InternalTransaction*/ tx)
            {
                tx._phase1Volatiles._dependentClones++;
            }
            /*void */ Promote(/*InternalTransaction*/ tx)
            {
                tx._promoteState.EnterState(tx);
                tx.State.CheckForFinishedTransaction(tx);
            }
            /*byte[] */ PromotedToken(/*InternalTransaction*/ tx)
            {
                if (tx.promotedToken === null)
                {
                    tx._promoteState.EnterState(tx);
                    tx.State.CheckForFinishedTransaction(tx);
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(tx.promotedToken !== null, "tx.promotedToken != null");
                return tx.promotedToken;
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 1686060;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":244268,"m":[{"r":1751596,"p":[{"n":"tx","p":2800172},{"n":"resourceManagerIdentifier","p":56164353},{"n":"enlistmentNotification","p":2603564},{"n":"enlistmentOptions","p":1882668},{"n":"atomicTransaction","p":4307500}],"n":"EnlistDurable","d":1686060,"h":4296653356,"f":32776},{"r":1751596,"p":[{"n":"tx","p":2800172},{"n":"resourceManagerIdentifier","p":56164353},{"n":"enlistmentNotification","p":3062316},{"n":"enlistmentOptions","p":1882668},{"n":"atomicTransaction","p":4307500}],"n":"EnlistDurable","o":"@$1","d":1686060,"h":8591620652,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"Timeout","d":1686060,"h":12886587948,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"serializationInfo","p":113967105},{"n":"context","p":114098177}],"n":"GetObjectData","d":1686060,"h":17181555244,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"CompleteBlockingClone","d":1686060,"h":21476522540,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"CompleteAbortingClone","d":1686060,"h":25771489836,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"CreateBlockingClone","d":1686060,"h":30066457132,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"CreateAbortingClone","d":1686060,"h":34361424428,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"Promote","d":1686060,"h":38656391724,"f":32776},{"r":0,"p":[{"n":"tx","p":2800172}],"n":"PromotedToken","d":1686060,"h":42951359020,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":1686060,"h":47246326316,"f":4}],"h":1686060}; }
            static get $b() { return $.$stl.System.Transactions.ActiveStates; }
            static get $fullName() { return `System.Transactions.EnlistableStates`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedAborting", ($self) => class TransactionStatePromotedAborting extends $.$stl.System.Transactions.TransactionStatePromotedBase
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
            }
            /*TransactionStatus */ get_Status(/*InternalTransaction*/ tx)
            {
                return 2/*TransactionStatus.Aborted*/;
            }
            /*void */ BeginCommit(/*InternalTransaction*/ tx, /*bool*/ asyncCommit, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ CreateBlockingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ CreateAbortingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ ChangeStatePromotedAborted(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedAborted.EnterState(tx);
            }
            /*void */ ChangeStateTransactionAborted(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
            }
            /*void */ RestartCommitIfNeeded(/*InternalTransaction*/ tx)
            {
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 6863404;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6928940,"m":[{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"EnterState","d":6863404,"h":4301830700,"f":32776},{"r":8436268,"p":[{"n":"tx","p":2800172}],"n":"get_Status","d":6863404,"h":8596797996,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"asyncCommit","p":262145},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":6863404,"h":12891765292,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"CreateBlockingClone","d":6863404,"h":17186732588,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"CreateAbortingClone","d":6863404,"h":21481699884,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"ChangeStatePromotedAborted","d":6863404,"h":25776667180,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"e","p":47185921}],"n":"ChangeStateTransactionAborted","d":6863404,"h":30071634476,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"RestartCommitIfNeeded","d":6863404,"h":34366601772,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":6863404,"h":38661569068,"f":4}],"h":6863404}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedBase; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedAborting`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedEnded", ($self) => class TransactionStatePromotedEnded extends $.$stl.System.Transactions.TransactionStateEnded
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                super.EnterState(tx);
                this.CommonEnterState(tx);
                if (!$.$spc.System.Threading.ThreadPool.QueueUserWorkItem$1($.$stl.System.Transactions.TransactionStatePromotedEnded.SignalMethod, tx))
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException$1(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.UnexpectedFailureOfThreadPool, null, tx === null ? $.$spc.System.Guid.Empty : tx.DistributedTxId);
                }
            }
            /*void */ AddOutcomeRegistrant(/*InternalTransaction*/ tx, /*TransactionCompletedEventHandler?*/ transactionCompletedDelegate)
            {
                if (transactionCompletedDelegate !== null)
                {
                    /*TransactionEventArgs*/ let args = new $.$stl.System.Transactions.TransactionEventArgs().$ctor$2();
                    args._transaction = tx._outcomeSource.InternalClone();
                    transactionCompletedDelegate.Invoke(args._transaction, args);
                }
            }
            /*void */ EndCommit(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(tx.PromotedTransaction !== null, "Promoted state not valid for transaction.");
                this.PromotedTransactionOutcome(tx);
            }
            /*void */ CompleteBlockingClone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ CompleteAbortingClone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ CreateBlockingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ CreateAbortingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*Guid */ get_Identifier(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(tx.PromotedTransaction !== null, "tx.PromotedTransaction != null");
                return tx.PromotedTransaction.Identifier;
            }
            /*void */ Promote(/*InternalTransaction*/ tx)
            {
            }
            /*WaitCallback?*/ static s_signalMethod = null;
            static /*WaitCallback */ get SignalMethod()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$spc.System.Threading.WaitCallback, $.$ref(() => $.$stl.System.Transactions.TransactionStatePromotedEnded.s_signalMethod, ($v) => $.$stl.System.Transactions.TransactionStatePromotedEnded.s_signalMethod = $v, $.$spc.System.Threading.WaitCallback), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$spc.System.Threading.WaitCallback))().$ctor(this,  () =>
                {
                    return new $.$spc.System.Threading.WaitCallback().$ctor(null, $.$stl.System.Transactions.TransactionStatePromotedEnded.SignalCallback);
                }));
            }
            static /*void */ SignalCallback(/*object*/ state)
            {
                /*InternalTransaction*/ let tx = $.$cast(state, $.$stl.System.Transactions.InternalTransaction);
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(tx)
                    {
                        tx.SignalAsyncCompletion();
                        $.$stl.System.Transactions.TransactionTable.Remove(tx);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(tx)
                }
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 7125548;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6470188,"p":[{"p":139067393,"g":{"r":0,"d":0,"h":55841700396,"f":34},"n":"SignalMethod","d":7125548,"h":51546733100,"f":34}],"m":[{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"EnterState","d":7125548,"h":4302092844,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"transactionCompletedDelegate","p":4438572}],"n":"AddOutcomeRegistrant","d":7125548,"h":8597060140,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"EndCommit","d":7125548,"h":12892027436,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"CompleteBlockingClone","d":7125548,"h":17186994732,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"CompleteAbortingClone","d":7125548,"h":21481962028,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"CreateBlockingClone","d":7125548,"h":25776929324,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"CreateAbortingClone","d":7125548,"h":30071896620,"f":32776},{"r":56164353,"p":[{"n":"tx","p":2800172}],"n":"get_Identifier","d":7125548,"h":34366863916,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"Promote","d":7125548,"h":38661831212,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"PromotedTransactionOutcome","d":7125548,"h":42956798508,"f":260},{"r":65537,"p":[{"n":"state","p":131073}],"n":"SignalCallback","d":7125548,"h":60136667692,"f":34}],"l":[{"t":139067393,"n":"s_signalMethod","d":7125548,"h":47251765804,"f":34}],"c":[{"n":".ctor","o":"$ctor$3","d":7125548,"h":64431634988,"f":4}],"h":7125548}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStateEnded; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedEnded`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedNonMSDTCEnded", ($self) => class TransactionStatePromotedNonMSDTCEnded extends $.$stl.System.Transactions.TransactionStateEnded
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                super.EnterState(tx);
                this.CommonEnterState(tx);
                if (!$.$spc.System.Threading.ThreadPool.QueueUserWorkItem$1($.$stl.System.Transactions.TransactionStatePromotedNonMSDTCEnded.SignalMethod, tx))
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException$1(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.UnexpectedFailureOfThreadPool, null, tx === null ? $.$spc.System.Guid.Empty : tx.DistributedTxId);
                }
            }
            /*void */ AddOutcomeRegistrant(/*InternalTransaction*/ tx, /*TransactionCompletedEventHandler?*/ transactionCompletedDelegate)
            {
                if (transactionCompletedDelegate !== null)
                {
                    /*TransactionEventArgs*/ let args = new $.$stl.System.Transactions.TransactionEventArgs().$ctor$2();
                    args._transaction = tx._outcomeSource.InternalClone();
                    transactionCompletedDelegate.Invoke(args._transaction, args);
                }
            }
            /*void */ EndCommit(/*InternalTransaction*/ tx)
            {
                this.PromotedTransactionOutcome(tx);
            }
            /*void */ CompleteBlockingClone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ CompleteAbortingClone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ CreateBlockingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ CreateAbortingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*Guid */ get_Identifier(/*InternalTransaction*/ tx)
            {
                return tx._distributedTransactionIdentifierNonMSDTC;
            }
            /*void */ Promote(/*InternalTransaction*/ tx)
            {
            }
            /*WaitCallback?*/ static s_signalMethod = null;
            static /*WaitCallback */ get SignalMethod()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$spc.System.Threading.WaitCallback, $.$ref(() => $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCEnded.s_signalMethod, ($v) => $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCEnded.s_signalMethod = $v, $.$spc.System.Threading.WaitCallback), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$spc.System.Threading.WaitCallback))().$ctor(this,  () =>
                {
                    return new $.$spc.System.Threading.WaitCallback().$ctor(null, $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCEnded.SignalCallback);
                }));
            }
            static /*void */ SignalCallback(/*object*/ state)
            {
                /*InternalTransaction*/ let tx = $.$cast(state, $.$stl.System.Transactions.InternalTransaction);
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(tx)
                    {
                        tx.SignalAsyncCompletion();
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(tx)
                }
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 7453228;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6470188,"p":[{"p":139067393,"g":{"r":0,"d":0,"h":55842028076,"f":34},"n":"SignalMethod","d":7453228,"h":51547060780,"f":34}],"m":[{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"EnterState","d":7453228,"h":4302420524,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"transactionCompletedDelegate","p":4438572}],"n":"AddOutcomeRegistrant","d":7453228,"h":8597387820,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"EndCommit","d":7453228,"h":12892355116,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"CompleteBlockingClone","d":7453228,"h":17187322412,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"CompleteAbortingClone","d":7453228,"h":21482289708,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"CreateBlockingClone","d":7453228,"h":25777257004,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"CreateAbortingClone","d":7453228,"h":30072224300,"f":32776},{"r":56164353,"p":[{"n":"tx","p":2800172}],"n":"get_Identifier","d":7453228,"h":34367191596,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"Promote","d":7453228,"h":38662158892,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"PromotedTransactionOutcome","d":7453228,"h":42957126188,"f":260},{"r":65537,"p":[{"n":"state","p":131073}],"n":"SignalCallback","d":7453228,"h":60136995372,"f":34}],"l":[{"t":139067393,"n":"s_signalMethod","d":7453228,"h":47252093484,"f":34}],"c":[{"n":".ctor","o":"$ctor$3","d":7453228,"h":64431962668,"f":4}],"h":7453228}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStateEnded; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedNonMSDTCEnded`; }
        });
        
        $asm.$cls("$stl.System.Transactions.EnterpriseServices", ($self) => class EnterpriseServices
        {
            static /*bool */ get EnterpriseServicesOk()
            {
                return false;
            }
            static /*void */ VerifyEnterpriseServicesOk()
            {
                if (!$.$stl.System.Transactions.EnterpriseServices.EnterpriseServicesOk)
                {
                    $.$stl.System.Transactions.EnterpriseServices.ThrowNotSupported();
                }
            }
            static /*Transaction? */ GetContextTransaction()
            {
                if ($.$stl.System.Transactions.EnterpriseServices.EnterpriseServicesOk)
                {
                    $.$stl.System.Transactions.EnterpriseServices.ThrowNotSupported();
                }
                return null;
            }
            /*bool*/ static CreatedServiceDomain = false;
            static /*bool */ UseServiceDomainForCurrent()
            {
                return false;
            }
            static /*void */ PushServiceDomain()
            {
                $.$stl.System.Transactions.EnterpriseServices.ThrowNotSupported();
            }
            static /*void */ LeaveServiceDomain()
            {
                $.$stl.System.Transactions.EnterpriseServices.ThrowNotSupported();
            }
            static /*void */ ThrowNotSupported()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$14($.$stl.System.SR.EsNotSupported);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.CreatedServiceDomain = false;
                }
            }
            static $h = 2210348;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":8592144940,"f":40},"n":"EnterpriseServicesOk","d":2210348,"h":4297177644,"f":40},{"p":262145,"g":{"r":0,"d":0,"h":30066981420,"f":40},"s":{"r":0,"d":0,"h":34361948716,"f":40},"n":"CreatedServiceDomain","d":2210348,"h":25772014124,"f":40}],"m":[{"r":65537,"n":"VerifyEnterpriseServicesOk","d":2210348,"h":12887112236,"f":40},{"r":4307500,"n":"GetContextTransaction","d":2210348,"h":17182079532,"f":40},{"r":262145,"n":"UseServiceDomainForCurrent","d":2210348,"h":38656916012,"f":40},{"r":65537,"n":"PushServiceDomain","d":2210348,"h":42951883308,"f":40},{"r":65537,"n":"LeaveServiceDomain","d":2210348,"h":47246850604,"f":40},{"r":65537,"n":"ThrowNotSupported","d":2210348,"h":51541817900,"f":34}],"h":2210348}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Transactions.EnterpriseServices`; }
        });
        
        $asm.$cls("$stl.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$stl.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("System.Transactions.Local", $.$stl.System.SR.$type.Assembly);
                    $.$stl.System.SR.s_resourceManager = temp;
                }
                return $.$stl.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$stl.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$stl.System.SR.resourceCulture = value;
            }
            static /*string */ get AsyncFlowAndESInteropNotSupported()
            {
                return "TransactionScope with TransactionScopeAsyncFlowOption.Enabled option is not supported when the TransactionScope is used within Enterprise Service context with Automatic or Full EnterpriseServicesInteropOption enabled in parent scope.";
            }
            static /*string */ get BadAsyncResult()
            {
                return "The IAsyncResult parameter must be the same parameter returned by BeginCommit.";
            }
            static /*string */ get BadResourceManagerId()
            {
                return "Resource Manager Identifiers cannot be Guid.Empty.";
            }
            static /*string */ get CannotPromoteSnapshot()
            {
                return "Transactions with IsolationLevel Snapshot cannot be promoted.";
            }
            static /*string */ get CannotSetCurrent()
            {
                return "Current cannot be set directly when Com+ Interop is enabled.";
            }
            static /*string */ get CurrentDelegateSet()
            {
                return "The delegate for an external current can only be set once.";
            }
            static /*string */ get DisposeScope()
            {
                return "The current TransactionScope is already complete. You should dispose the TransactionScope.";
            }
            static /*string */ get EnlistmentStateException()
            {
                return "The operation is not valid for the current state of the enlistment.";
            }
            static /*string */ get EsNotSupported()
            {
                return "Com+ Interop features cannot be supported.";
            }
            static /*string */ get InternalError()
            {
                return "Internal Error";
            }
            static /*string */ get InvalidArgument()
            {
                return "The argument is invalid.";
            }
            static /*string */ get InvalidIPromotableSinglePhaseNotificationSpecified()
            {
                return "The specified IPromotableSinglePhaseNotification is not the same as the one provided to EnlistPromotableSinglePhase.";
            }
            static /*string */ get InvalidRecoveryInformation()
            {
                return "Transaction Manager in the Recovery Information does not match the configured transaction manager.";
            }
            static /*string */ get InvalidScopeThread()
            {
                return "A TransactionScope must be disposed on the same thread that it was created.";
            }
            static /*string */ get PromotionFailed()
            {
                return "There was an error promoting the transaction to a distributed transaction.";
            }
            static /*string */ get PromotedReturnedInvalidValue()
            {
                return "The Promote method returned an invalid value for the distributed transaction.";
            }
            static /*string */ get PromotedTransactionExists()
            {
                return "The transaction returned from Promote already exists as a distributed transaction.";
            }
            static /*string */ get TooLate()
            {
                return "It is too late to add enlistments to this transaction.";
            }
            static /*string */ get TraceTransactionTimeout()
            {
                return "Transaction Timeout";
            }
            static /*string */ get TransactionAborted()
            {
                return "The transaction has aborted.";
            }
            static /*string */ get TransactionAlreadyCompleted()
            {
                return "DependentTransaction.Complete or CommittableTransaction.Commit has already been called for this transaction.";
            }
            static /*string */ get TransactionIndoubt()
            {
                return "The transaction is in doubt.";
            }
            static /*string */ get TransactionManagerCommunicationException()
            {
                return "Communication with the underlying transaction manager has failed.";
            }
            static /*string */ get TransactionScopeComplete()
            {
                return "The current TransactionScope is already complete.";
            }
            static /*string */ get TransactionScopeIncorrectCurrent()
            {
                return "Transaction.Current has changed inside of the TransactionScope.";
            }
            static /*string */ get TransactionScopeInvalidNesting()
            {
                return "TransactionScope nested incorrectly.";
            }
            static /*string */ get TransactionScopeIsolationLevelDifferentFromTransaction()
            {
                return "The transaction specified for TransactionScope has a different IsolationLevel than the value requested for the scope.";
            }
            static /*string */ get TransactionScopeTimerObjectInvalid()
            {
                return "TransactionScope timer object is invalid.";
            }
            static /*string */ get TransactionStateException()
            {
                return "The operation is not valid for the state of the transaction.";
            }
            static /*string */ get UnexpectedFailureOfThreadPool()
            {
                return "There was an unexpected failure of QueueUserWorkItem.";
            }
            static /*string */ get UnexpectedTimerFailure()
            {
                return "There was an unexpected failure of a timer.";
            }
            static /*string */ get UnrecognizedRecoveryInformation()
            {
                return "The RecoveryInformation provided is not recognized by this version of System.Transactions.";
            }
            static /*string */ get VolEnlistNoRecoveryInfo()
            {
                return "Volatile enlistments do not generate recovery information.";
            }
            static /*string */ get DistributedTxIDInTransactionException()
            {
                return "{0} Distributed Transaction ID is {1}";
            }
            static /*string */ FormatDistributedTxIDInTransactionException(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("{0} Distributed Transaction ID is {1}", arg1, arg2);
            }
            static /*string */ get PromoterTypeInvalid()
            {
                return "The specified PromoterType is invalid.";
            }
            static /*string */ get PromoterTypeUnrecognized()
            {
                return "There is a promotable enlistment for the transaction which has a PromoterType value that is not recognized by System.Transactions. {0}";
            }
            static /*string */ FormatPromoterTypeUnrecognized(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("There is a promotable enlistment for the transaction which has a PromoterType value that is not recognized by System.Transactions. {0}", arg1);
            }
            static /*string */ get DistributedNotSupported()
            {
                return "This platform does not support distributed transactions.";
            }
            static /*string */ get TraceSourceOletx()
            {
                return "[Distributed]";
            }
            static /*string */ get TraceConfiguredDefaultTimeoutAdjusted()
            {
                return "Configured DefaultTimeout is greater than configured DefaultMaximumTimeout - adjusting down to DefaultMaximumTimeout";
            }
            static /*string */ get TraceMethodEntered()
            {
                return "Method Entered";
            }
            static /*string */ get TraceMethodExited()
            {
                return "Method Exited";
            }
            static /*string */ get OperationInvalidOnAnEmptyDocument()
            {
                return "The operation is invalid because the document is empty.";
            }
            static /*string */ get CannotAddToClosedDocument()
            {
                return "Cannot add an element to a closed document.";
            }
            static /*string */ get TextNodeAlreadyPopulated()
            {
                return "The text node already has a value.";
            }
            static /*string */ get TraceEnlistment()
            {
                return "Enlistment Created";
            }
            static /*string */ get TraceTransactionPromoted()
            {
                return "Transaction Promoted";
            }
            static /*string */ get TraceEnlistmentNotificationCall()
            {
                return "Enlistment Notification Call";
            }
            static /*string */ get TraceEnlistmentCallbackPositive()
            {
                return "Enlistment Callback Positive";
            }
            static /*string */ get TraceEnlistmentCallbackNegative()
            {
                return "Enlistment Callback Negative";
            }
            static /*string */ get DocumentAlreadyClosed()
            {
                return "Cannot close an element on a closed document.";
            }
            static /*string */ get TraceInternalError()
            {
                return "Internal Error";
            }
            static /*string */ get TraceInvalidOperationException()
            {
                return "InvalidOperationException Thrown";
            }
            static /*string */ get TraceExceptionConsumed()
            {
                return "Exception Consumed";
            }
            static /*string */ get TraceTransactionException()
            {
                return "TransactionException Thrown";
            }
            static /*string */ get TraceTransactionDeserialized()
            {
                return "Transaction Deserialized";
            }
            static /*string */ get TraceTransactionSerialized()
            {
                return "Transaction Serialized";
            }
            static /*string */ get TraceTransactionManagerCreated()
            {
                return "Transaction Manager Instance Created";
            }
            static /*string */ get TraceReenlist()
            {
                return "TransactionManager.Reenlist Called";
            }
            static /*string */ get TraceTransactionCreated()
            {
                return "Transaction Created";
            }
            static /*string */ get TraceTransactionCommitCalled()
            {
                return "CommittableTransaction.Commit Called";
            }
            static /*string */ get TraceTransactionCommitted()
            {
                return "Transaction Committed";
            }
            static /*string */ get TraceTransactionAborted()
            {
                return "Transaction Aborted";
            }
            static /*string */ get TraceTransactionInDoubt()
            {
                return "Transaction InDoubt";
            }
            static /*string */ get TraceTransactionScopeCreated()
            {
                return "TransactionScope Created";
            }
            static /*string */ get TraceTransactionScopeDisposed()
            {
                return "TransactionScope Disposed";
            }
            static /*string */ get ProxyCannotSupportMultipleNodeNames()
            {
                return "MSDTC Proxy cannot support specification of different node names in the same process.";
            }
            static /*string */ get CannotSupportNodeNameSpecification()
            {
                return "Cannot support specification of node name for the distributed transaction manager through System.Transactions due to MSDTC Proxy version.";
            }
            static /*string */ get FailedToCreateTraceSource()
            {
                return "Failed to create trace source.";
            }
            static /*string */ get FailedToInitializeTraceSource()
            {
                return "Failed to initialize trace source.";
            }
            static /*string */ get TraceRecoveryComplete()
            {
                return "TransactionManager.RecoveryComplete Called";
            }
            static /*string */ get TraceCloneCreated()
            {
                return "Clone Created";
            }
            static /*string */ get TraceDependentCloneComplete()
            {
                return "Dependent Clone Completed";
            }
            static /*string */ get TraceDependentCloneCreated()
            {
                return "Dependent Clone Created";
            }
            static /*string */ get TraceTransactionScopeTimeout()
            {
                return "TransactionScope Timeout";
            }
            static /*string */ get TraceTransactionRollbackCalled()
            {
                return "Transaction.Rollback Called";
            }
            static /*string */ get TraceFailure()
            {
                return "Trace Event Type: {0}\\nTrace Code: {1}\\nTrace Description {2}\\nObject: {3}";
            }
            static /*string */ FormatTraceFailure(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3, /*object*/ arg4)
            {
                return $.$spc.System.String.Format$4("Trace Event Type: {0}\\nTrace Code: {1}\\nTrace Description {2}\\nObject: {3}", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ arg1, arg2, arg3, arg4 ]));
            }
            static /*string */ get OletxEnlistmentUnexpectedTransactionStatus()
            {
                return "Internal Error - Unexpected transaction status value in enlistment constructor.";
            }
            static /*string */ get UnableToDeserializeTransaction()
            {
                return "Unable to deserialize the transaction.";
            }
            static /*string */ get UnableToDeserializeTransactionInternalError()
            {
                return "Internal Error - Unable to deserialize the transaction.";
            }
            static /*string */ get TransactionAlreadyOver()
            {
                return "The transaction has already been implicitly or explicitly committed or aborted.";
            }
            static /*string */ get EventLogValue()
            {
                return "Process Name: {0}\\nProcess Id: {1}\\nCode: {2}\\nDescription: {3}";
            }
            static /*string */ FormatEventLogValue(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3, /*object*/ arg4)
            {
                return $.$spc.System.String.Format$4("Process Name: {0}\\nProcess Id: {1}\\nCode: {2}\\nDescription: {3}", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ arg1, arg2, arg3, arg4 ]));
            }
            static /*string */ get EventLogSourceValue()
            {
                return "Source: {0}";
            }
            static /*string */ FormatEventLogSourceValue(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Source: {0}", arg1);
            }
            static /*string */ get EventLogExceptionValue()
            {
                return "Exception: {0}";
            }
            static /*string */ FormatEventLogExceptionValue(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Exception: {0}", arg1);
            }
            static /*string */ get EventLogEventIdValue()
            {
                return "Event ID: {0}";
            }
            static /*string */ FormatEventLogEventIdValue(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Event ID: {0}", arg1);
            }
            static /*string */ get EventLogTraceValue()
            {
                return "Other information : {0}";
            }
            static /*string */ FormatEventLogTraceValue(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Other information : {0}", arg1);
            }
            static /*string */ get TraceTransactionScopeCurrentTransactionChanged()
            {
                return "TransactionScope Current Transaction Changed";
            }
            static /*string */ get TraceTransactionScopeNestedIncorrectly()
            {
                return "TransactionScope Nested Incorrectly";
            }
            static /*string */ get TraceTransactionScopeIncomplete()
            {
                return "TransactionScope Incomplete";
            }
            static /*string */ get UnableToGetNotificationShimFactory()
            {
                return "Distributed transaction manager is unable to create the NotificationShimFactory object.";
            }
            static /*string */ get CannotGetTransactionIdentifier()
            {
                return "Unable to obtain the transaction identifier.";
            }
            static /*string */ get ReenlistAfterRecoveryComplete()
            {
                return "Calling TransactionManager.Reenlist is not allowed after TransactionManager.RecoveryComplete is called for a given resource manager identifier.";
            }
            static /*string */ get DuplicateRecoveryComplete()
            {
                return "RecoveryComplete must not be called twice by the same resource manager identifier instance.";
            }
            static /*string */ get DtcTransactionManagerUnavailable()
            {
                return "MSDTC Transaction Manager is unavailable.";
            }
            static /*string */ get NetworkTransactionsDisabled()
            {
                return "Network access for Distributed Transaction Manager (MSDTC) has been disabled. Please enable DTC for network access in the security configuration for MSDTC using the Component Services Administrative tool.";
            }
            static /*string */ get TraceSourceLtm()
            {
                return "[Lightweight]";
            }
            static /*string */ get TraceCodeAppDomainUnloading()
            {
                return "AppDomain unloading.";
            }
            static /*string */ get UnhandledException()
            {
                return "Unhandled Exception";
            }
            static /*string */ get ResourceManagerIdDoesNotMatchRecoveryInformation()
            {
                return "The resourceManagerIdentifier does not match the contents of the specified recovery information.";
            }
            static /*string */ get OletxTooManyEnlistments()
            {
                return "The distributed transaction manager does not allow any more durable enlistments on the transaction.";
            }
            static /*string */ get FailedToTraceEvent()
            {
                return "Failed to trace event: {0}.";
            }
            static /*string */ FormatFailedToTraceEvent(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Failed to trace event: {0}.", arg1);
            }
            static /*string */ get TraceSourceBase()
            {
                return "[Base]";
            }
            static /*string */ get DistributedNotSupportedOn32Bits()
            {
                return "Distributed transactions are currently unsupported in 32-bit processes.";
            }
            static /*string */ get ImplicitDistributedTransactionsDisabled()
            {
                return "Implicit distributed transactions have not been enabled. If you're intentionally starting a distributed transaction, set TransactionManager.ImplicitDistributedTransactions to true.";
            }
            static /*string */ get ImplicitDistributedTransactionsCannotBeChanged()
            {
                return "TransactionManager.ImplicitDistributedTransaction cannot be changed once set, or once System.Transactions distributed transactions have been initialized. Set this flag once at the start of your program.";
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$stl.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$stl.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$stl.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$stl.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$stl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$stl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$stl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$stl.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$stl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$stl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$stl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$stl.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$stl.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 178732;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":178732}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionInformation", ($self) => class TransactionInformation extends $.$spc.System.Object
        {
            /*InternalTransaction*/ _internalTransaction = null;
            $ctor$1(/*InternalTransaction*/ internalTransaction)
            {
                super.$ctor();
                {
                    this._internalTransaction = internalTransaction;
                }
                return this;
            }
            /*string */ get LocalIdentifier()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "LocalIdentifier");
                }
                try
                {
                    return this._internalTransaction.TransactionTraceId.TransactionIdentifier;
                }
                finally
                {
                    {
                        if (etwLog.IsEnabled())
                        {
                            etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "LocalIdentifier");
                        }
                    }
                }
            }
            /*Guid */ get DistributedIdentifier()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "DistributedIdentifier");
                }
                try
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                            return this._internalTransaction.State.get_Identifier(this._internalTransaction);
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                    }
                }
                finally
                {
                    {
                        if (etwLog.IsEnabled())
                        {
                            etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "DistributedIdentifier");
                        }
                    }
                }
            }
            /*DateTime */ get CreationTime()
            {
                return new $.$spc.System.DateTime().$ctor$2(this._internalTransaction.CreationTime);
            }
            /*TransactionStatus */ get Status()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "Status");
                }
                try
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                    return this._internalTransaction.State.get_Status(this._internalTransaction);
                }
                finally
                {
                    {
                        if (etwLog.IsEnabled())
                        {
                            etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "Status");
                        }
                    }
                }
            }
            static $h = 4766252;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17184635436,"f":1},"n":"LocalIdentifier","d":4766252,"h":12889668140,"f":1},{"p":56164353,"g":{"r":0,"d":0,"h":25774570028,"f":1},"n":"DistributedIdentifier","d":4766252,"h":21479602732,"f":1},{"p":34144257,"g":{"r":0,"d":0,"h":34364504620,"f":1},"n":"CreationTime","d":4766252,"h":30069537324,"f":1},{"p":8436268,"g":{"r":0,"d":0,"h":42954439212,"f":1},"n":"Status","d":4766252,"h":38659471916,"f":1}],"l":[{"t":2800172,"n":"_internalTransaction","d":4766252,"h":4299733548,"f":2}],"c":[{"p":[{"n":"internalTransaction","p":2800172}],"n":".ctor","o":"$ctor$1","d":4766252,"h":8594700844,"f":8}],"h":4766252}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Transactions.TransactionInformation`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionManager", ($self) => class TransactionManager
        {
            /*int*/ static RecoveryInformationVersion1 = 1;
            /*int*/ static CurrentRecoveryVersion = 1;
            /*Hashtable?*/ static s_promotedTransactionTable = null;
            /*TransactionTable?*/ static s_transactionTable = null;
            /*TransactionStartedEventHandler?*/ static s_distributedTransactionStartedDelegate = null;
            /*string*/ static DistributedTransactionTrimmingWarning = null;
            /*TransactionStartedEventHandler?*/static  add_DistributedTransactionStarted(value)
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter($.$stl.System.Transactions.TransactionManager.ClassSyncObject)
                    {
                        $.$stl.System.Transactions.TransactionManager.s_distributedTransactionStartedDelegate = $.$cast($.$spc.System.Delegate.Combine($.$stl.System.Transactions.TransactionManager.s_distributedTransactionStartedDelegate, value), $.$stl.System.Transactions.TransactionStartedEventHandler);
                        if (value !== null)
                        {
                            $.$stl.System.Transactions.TransactionManager.ProcessExistingTransactions(value);
                        }
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit($.$stl.System.Transactions.TransactionManager.ClassSyncObject)
                }
            }
            /*TransactionStartedEventHandler?*/static  remove_DistributedTransactionStarted(value)
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter($.$stl.System.Transactions.TransactionManager.ClassSyncObject)
                    {
                        $.$stl.System.Transactions.TransactionManager.s_distributedTransactionStartedDelegate = $.$cast($.$spc.System.Delegate.Remove($.$stl.System.Transactions.TransactionManager.s_distributedTransactionStartedDelegate, value), $.$stl.System.Transactions.TransactionStartedEventHandler);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit($.$stl.System.Transactions.TransactionManager.ClassSyncObject)
                }
            }
            static /*void */ ProcessExistingTransactions(/*TransactionStartedEventHandler*/ eventHandler)
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter($.$stl.System.Transactions.TransactionManager.PromotedTransactionTable)
                    {
                        /*IDictionaryEnumerator*/ let e = $.$stl.System.Transactions.TransactionManager.PromotedTransactionTable.GetEnumerator();
                        while(e.System$Collections$IEnumerator$MoveNext())
                        {
                            /*WeakReference*/ let weakRef = $.$cast(e.System$Collections$IDictionaryEnumerator$Value, $.$spc.System.WeakReference);
                            let tx;
                            if ($.$is(weakRef.Target, $.$stl.System.Transactions.Transaction, { set $v(v){ tx = v; } }))
                            {
                                /*TransactionEventArgs*/ let args = new $.$stl.System.Transactions.TransactionEventArgs().$ctor$2();
                                args._transaction = tx.InternalClone();
                                eventHandler.Invoke(args._transaction, args);
                            }
                        }
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit($.$stl.System.Transactions.TransactionManager.PromotedTransactionTable)
                }
            }
            static /*void */ FireDistributedTransactionStarted(/*Transaction*/ transaction)
            {
                /*TransactionStartedEventHandler?*/ let localStartedEventHandler = null;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter($.$stl.System.Transactions.TransactionManager.ClassSyncObject)
                    {
                        localStartedEventHandler = $.$stl.System.Transactions.TransactionManager.s_distributedTransactionStartedDelegate;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit($.$stl.System.Transactions.TransactionManager.ClassSyncObject)
                }
                if (null !== localStartedEventHandler)
                {
                    /*TransactionEventArgs*/ let args = new $.$stl.System.Transactions.TransactionEventArgs().$ctor$2();
                    args._transaction = transaction.InternalClone();
                    localStartedEventHandler.Invoke(args._transaction, args);
                }
            }
            /*HostCurrentTransactionCallback?*/ static s_currentDelegate = null;
            /*bool*/ static s_currentDelegateSet = false;
            static /*HostCurrentTransactionCallback? */ get HostCurrentCallback()
            {
                return $.$stl.System.Transactions.TransactionManager.s_currentDelegate;
            }
            static /*HostCurrentTransactionCallback? */ set HostCurrentCallback(value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter($.$stl.System.Transactions.TransactionManager.ClassSyncObject)
                    {
                        if ($.$stl.System.Transactions.TransactionManager.s_currentDelegateSet)
                        {
                            throw new $.$spc.System.InvalidOperationException().$ctor$10($.$stl.System.SR.CurrentDelegateSet);
                        }
                        $.$stl.System.Transactions.TransactionManager.s_currentDelegateSet = true;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit($.$stl.System.Transactions.TransactionManager.ClassSyncObject)
                }
                $.$stl.System.Transactions.TransactionManager.s_currentDelegate = value;
            }
            static /*Enlistment */ Reenlist(/*Guid*/ resourceManagerIdentifier, /*byte[]*/ recoveryInformation, /*IEnlistmentNotification*/ enlistmentNotification)
            {
                if ($.$spc.System.Guid.op_Equality(resourceManagerIdentifier, $.$spc.System.Guid.Empty))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$stl.System.SR.BadResourceManagerId, "resourceManagerIdentifier");
                }
                $.$spc.System.ArgumentNullException.ThrowIfNull(recoveryInformation, "recoveryInformation");
                $.$spc.System.ArgumentNullException.ThrowIfNull(enlistmentNotification, "enlistmentNotification");
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(0/*TraceSourceType.TraceSourceBase*/, "TransactionManager.Reenlist");
                    etwLog.TransactionManagerReenlist(resourceManagerIdentifier);
                }
                /*MemoryStream*/ let stream = new $.$spc.System.IO.MemoryStream().$ctor$5(recoveryInformation);
                /*int*/ let recoveryInformationVersion;
                /*string?*/ let nodeName;
                /*byte[]?*/ let resourceManagerRecoveryInformation = null;
                try
                {
                    /*BinaryReader*/ let reader = new $.$spc.System.IO.BinaryReader().$ctor$1(stream);
                    recoveryInformationVersion = reader.ReadInt32();
                    if (recoveryInformationVersion === 1/*TransactionManager.RecoveryInformationVersion1*/)
                    {
                        nodeName = reader.ReadString();
                        resourceManagerRecoveryInformation = reader.ReadBytes(((recoveryInformation.length - $.$cast(stream.Position, $.$spc.System.Int32)) | 0));
                    }
                    else 
                    {
                        if (etwLog.IsEnabled())
                        {
                            etwLog.TransactionExceptionTrace(0/*TraceSourceType.TraceSourceBase*/, 5/*TransactionExceptionType.UnrecognizedRecoveryInformation*/, "recoveryInformation", $.$spc.System.String.Empty);
                        }
                        throw new $.$spc.System.ArgumentException().$ctor$13($.$stl.System.SR.UnrecognizedRecoveryInformation, "recoveryInformation");
                    }
                }
                catch($e)
                {
                    if ($e instanceof $.$spc.System.IO.EndOfStreamException)
                    {
                        let e = $e;
                        if (etwLog.IsEnabled())
                        {
                            etwLog.TransactionExceptionTrace(0/*TraceSourceType.TraceSourceBase*/, 5/*TransactionExceptionType.UnrecognizedRecoveryInformation*/, "recoveryInformation", $.$spc.System.Exception.ToString.call(e));
                        }
                        throw new $.$spc.System.ArgumentException().$ctor$12($.$stl.System.SR.UnrecognizedRecoveryInformation, "recoveryInformation", e);
                    }
                    else if ($e instanceof $.$spc.System.FormatException)
                    {
                        let e = $e;
                        if (etwLog.IsEnabled())
                        {
                            etwLog.TransactionExceptionTrace(0/*TraceSourceType.TraceSourceBase*/, 5/*TransactionExceptionType.UnrecognizedRecoveryInformation*/, "recoveryInformation", $.$spc.System.Exception.ToString.call(e));
                        }
                        throw new $.$spc.System.ArgumentException().$ctor$12($.$stl.System.SR.UnrecognizedRecoveryInformation, "recoveryInformation", e);
                    }
                    else
                    {
                        throw $e;
                    }
                }
                finally
                {
                    {
                        stream.Dispose();
                    }
                }
                /*object*/ let syncRoot = new $.$spc.System.Object().$ctor();
                /*Enlistment*/ let returnValue = new $.$stl.System.Transactions.Enlistment().$ctor$6(enlistmentNotification, syncRoot);
                $.$stl.System.Transactions.EnlistmentState.EnlistmentStatePromoted.EnterState(returnValue.InternalEnlistment);
                returnValue.InternalEnlistment.PromotedEnlistment = $.$stl.System.Transactions.TransactionManager.DistributedTransactionManager.ReenlistTransaction(resourceManagerIdentifier, resourceManagerRecoveryInformation, $.$cast(returnValue.InternalEnlistment, $.$stl.System.Transactions.RecoveringInternalEnlistment));
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(0/*TraceSourceType.TraceSourceBase*/, "TransactionManager.Reenlist");
                }
                return returnValue;
            }
            static /*OletxTransactionManager */ CheckTransactionManager(/*string?*/ nodeName)
            {
                /*OletxTransactionManager*/ let tm = $.$stl.System.Transactions.TransactionManager.DistributedTransactionManager;
                if (!((tm.NodeName === null && $.$spc.System.String.IsNullOrEmpty(nodeName)) || (tm.NodeName !== null && $.$spc.System.Object.Equals.call(tm.NodeName, nodeName))))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$stl.System.SR.InvalidRecoveryInformation, "recoveryInformation");
                }
                return tm;
            }
            static /*void */ RecoveryComplete(/*Guid*/ resourceManagerIdentifier)
            {
                if ($.$spc.System.Guid.op_Equality(resourceManagerIdentifier, $.$spc.System.Guid.Empty))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$stl.System.SR.BadResourceManagerId, "resourceManagerIdentifier");
                }
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(0/*TraceSourceType.TraceSourceBase*/, "TransactionManager.RecoveryComplete");
                    etwLog.TransactionManagerRecoveryComplete(resourceManagerIdentifier);
                }
                $.$stl.System.Transactions.TransactionManager.DistributedTransactionManager.ResourceManagerRecoveryComplete(resourceManagerIdentifier);
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(0/*TraceSourceType.TraceSourceBase*/, "TransactionManager.RecoveryComplete");
                }
            }
            /*object?*/ static s_classSyncObject = null;
            static /*object */ get ClassSyncObject()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized($.$spc.System.Object, $.$ref(() => $.$stl.System.Transactions.TransactionManager.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionManager.s_classSyncObject = $v, $.$spc.System.Object));
            }
            static /*IsolationLevel */ get DefaultIsolationLevel()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(0/*TraceSourceType.TraceSourceBase*/, "TransactionManager.get_DefaultIsolationLevel");
                    etwLog.MethodExit$1(0/*TraceSourceType.TraceSourceBase*/, "TransactionManager.get_DefaultIsolationLevel");
                }
                return 0/*IsolationLevel.Serializable*/;
            }
            /*DefaultSettingsSection*/ static DefaultSettings$ = null;
            static /*DefaultSettingsSection */ get DefaultSettings()
            {
                return $.$stl.System.Transactions.TransactionManager.DefaultSettings$ ??= $.$stl.System.Transactions.Configuration.DefaultSettingsSection.GetSection();
            }
            /*MachineSettingsSection*/ static MachineSettings$ = null;
            static /*MachineSettingsSection */ get MachineSettings()
            {
                return $.$stl.System.Transactions.TransactionManager.MachineSettings$ ??= $.$stl.System.Transactions.Configuration.MachineSettingsSection.GetSection();
            }
            /*bool*/ static s_defaultTimeoutValidated = false;
            /*long*/ static s_defaultTimeoutTicks = 0n;
            static /*TimeSpan */ get DefaultTimeout()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(0/*TraceSourceType.TraceSourceBase*/, "TransactionManager.get_DefaultTimeout");
                }
                if (!$.$stl.System.Transactions.TransactionManager.s_defaultTimeoutValidated)
                {
                    $.$spc.System.Threading.LazyInitializer.EnsureInitialized$3($.$spc.System.Int64, $.$ref(() => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks, ($v) => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks = $v, $.$spc.System.Int64), $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Boolean, () => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutValidated, ($v) => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutValidated = $v, null), $.$ref(() => $.$stl.System.Transactions.TransactionManager.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionManager.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$spc.System.Int64))().$ctor(this,  () =>
                    {
                        return $.$stl.System.Transactions.TransactionManager.ValidateTimeout($.$stl.System.Transactions.Configuration.DefaultSettingsSection.Timeout).Ticks;
                    }));
                    if ($.$spc.System.Threading.Interlocked.Read($.$ref(() => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks, ($v) => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks = $v, $.$spc.System.Int64)) !== $.$stl.System.Transactions.Configuration.DefaultSettingsSection.Timeout.Ticks)
                    {
                        if (etwLog.IsEnabled())
                        {
                            etwLog.ConfiguredDefaultTimeoutAdjusted();
                        }
                    }
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(0/*TraceSourceType.TraceSourceBase*/, "TransactionManager.get_DefaultTimeout");
                }
                return new $.$spc.System.TimeSpan().$ctor$2($.$spc.System.Threading.Interlocked.Read($.$ref(() => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks, ($v) => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks = $v, $.$spc.System.Int64)));
            }
            static /*TimeSpan */ set DefaultTimeout(value)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(0/*TraceSourceType.TraceSourceBase*/, "TransactionManager.set_DefaultTimeout");
                }
                $.$spc.System.Threading.Interlocked.Exchange$3($.$ref(() => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks, ($v) => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks = $v, $.$spc.System.Int64), $.$stl.System.Transactions.TransactionManager.ValidateTimeout(value).Ticks);
                if ($.$spc.System.Threading.Interlocked.Read($.$ref(() => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks, ($v) => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks = $v, $.$spc.System.Int64)) !== value.Ticks)
                {
                    if (etwLog.IsEnabled())
                    {
                        etwLog.ConfiguredDefaultTimeoutAdjusted();
                    }
                }
                $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutValidated = true;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(0/*TraceSourceType.TraceSourceBase*/, "TransactionManager.set_DefaultTimeout");
                }
            }
            /*bool*/ static s_cachedMaxTimeout = false;
            /*TimeSpan*/ static s_maximumTimeout;
            static /*TimeSpan */ get MaximumTimeout()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(0/*TraceSourceType.TraceSourceBase*/, "TransactionManager.get_DefaultMaximumTimeout");
                }
                $.$spc.System.Threading.LazyInitializer.EnsureInitialized$3($.$spc.System.TimeSpan, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.TimeSpan, () => $.$stl.System.Transactions.TransactionManager.s_maximumTimeout, ($v) => $.$stl.System.Transactions.TransactionManager.s_maximumTimeout = $v, null), $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Boolean, () => $.$stl.System.Transactions.TransactionManager.s_cachedMaxTimeout, ($v) => $.$stl.System.Transactions.TransactionManager.s_cachedMaxTimeout = $v, null), $.$ref(() => $.$stl.System.Transactions.TransactionManager.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionManager.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$spc.System.TimeSpan))().$ctor(this,  () =>
                {
                    return $.$stl.System.Transactions.Configuration.MachineSettingsSection.MaxTimeout;
                }));
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(0/*TraceSourceType.TraceSourceBase*/, "TransactionManager.get_DefaultMaximumTimeout");
                }
                return $.$stl.System.Transactions.TransactionManager.s_maximumTimeout;
            }
            static /*TimeSpan */ set MaximumTimeout(value)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(0/*TraceSourceType.TraceSourceBase*/, "TransactionManager.set_DefaultMaximumTimeout");
                }
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfLessThan($.$spc.System.TimeSpan, value, $.$spc.System.TimeSpan.Zero, "value");
                $.$stl.System.Transactions.TransactionManager.s_cachedMaxTimeout = true;
                $.$stl.System.Transactions.TransactionManager.s_maximumTimeout = value;
                $.$spc.System.Threading.LazyInitializer.EnsureInitialized$3($.$spc.System.Int64, $.$ref(() => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks, ($v) => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks = $v, $.$spc.System.Int64), $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Boolean, () => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutValidated, ($v) => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutValidated = $v, null), $.$ref(() => $.$stl.System.Transactions.TransactionManager.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionManager.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$spc.System.Int64))().$ctor(this,  () =>
                {
                    return $.$stl.System.Transactions.Configuration.DefaultSettingsSection.Timeout.Ticks;
                }));
                /*long*/ let defaultTimeoutTicks = $.$spc.System.Threading.Interlocked.Read($.$ref(() => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks, ($v) => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks = $v, $.$spc.System.Int64));
                $.$spc.System.Threading.Interlocked.Exchange$3($.$ref(() => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks, ($v) => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks = $v, $.$spc.System.Int64), $.$stl.System.Transactions.TransactionManager.ValidateTimeout(new $.$spc.System.TimeSpan().$ctor$2(defaultTimeoutTicks)).Ticks);
                if ($.$spc.System.Threading.Interlocked.Read($.$ref(() => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks, ($v) => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks = $v, $.$spc.System.Int64)) !== defaultTimeoutTicks)
                {
                    if (etwLog.IsEnabled())
                    {
                        etwLog.ConfiguredDefaultTimeoutAdjusted();
                    }
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(0/*TraceSourceType.TraceSourceBase*/, "TransactionManager.set_DefaultMaximumTimeout");
                }
            }
            static /*bool */ get ImplicitDistributedTransactions()
            {
                return false;
            }
            static /*bool */ set ImplicitDistributedTransactions(value)
            {
                if (value)
                {
                    throw new $.$spc.System.PlatformNotSupportedException().$ctor$14($.$stl.System.SR.DistributedNotSupported);
                }
            }
            static /*byte[] */ GetRecoveryInformation(/*string?*/ startupInfo, /*byte[]*/ resourceManagerRecoveryInformation)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(2/*TraceSourceType.TraceSourceOleTx*/, `${"TransactionManager"}.${"GetRecoveryInformation"}`);
                }
                /*MemoryStream*/ let stream = new $.$spc.System.IO.MemoryStream().$ctor$3();
                /*byte[]?*/ let returnValue = null;
                try
                {
                    /*BinaryWriter*/ let writer = new $.$spc.System.IO.BinaryWriter().$ctor$2(stream);
                    writer.Write$12(1/*CurrentRecoveryVersion*/);
                    if ($.$spc.System.String.op_Inequality(startupInfo, null))
                    {
                        writer.Write$18(startupInfo);
                    }
                    else 
                    {
                        writer.Write$18("");
                    }
                    writer.Write$3(resourceManagerRecoveryInformation);
                    writer.Flush();
                    returnValue = stream.ToArray();
                }
                finally
                {
                    {
                        stream.Close();
                    }
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(2/*TraceSourceType.TraceSourceOleTx*/, `${"TransactionManager"}.${"GetRecoveryInformation"}`);
                }
                return returnValue;
            }
            static /*void */ ValidateIsolationLevel(/*IsolationLevel*/ transactionIsolationLevel)
            {
                switch(transactionIsolationLevel)
                {
                    case 0/*IsolationLevel.Serializable*/:
                    case 1/*IsolationLevel.RepeatableRead*/:
                    case 2/*IsolationLevel.ReadCommitted*/:
                    case 3/*IsolationLevel.ReadUncommitted*/:
                    case 6/*IsolationLevel.Unspecified*/:
                    case 5/*IsolationLevel.Chaos*/:
                    case 4/*IsolationLevel.Snapshot*/:
                    break;
                    default:
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("transactionIsolationLevel");
                }
            }
            static /*TimeSpan */ ValidateTimeout(/*TimeSpan*/ transactionTimeout)
            {
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfLessThan($.$spc.System.TimeSpan, transactionTimeout, $.$spc.System.TimeSpan.Zero, "transactionTimeout");
                if ($.$spc.System.TimeSpan.op_Inequality($.$stl.System.Transactions.TransactionManager.MaximumTimeout, $.$spc.System.TimeSpan.Zero))
                {
                    if ($.$spc.System.TimeSpan.op_GreaterThan(transactionTimeout, $.$stl.System.Transactions.TransactionManager.MaximumTimeout) || $.$spc.System.TimeSpan.op_Equality(transactionTimeout, $.$spc.System.TimeSpan.Zero))
                    {
                        return $.$stl.System.Transactions.TransactionManager.MaximumTimeout;
                    }
                }
                return transactionTimeout;
            }
            static /*Transaction? */ FindPromotedTransaction(/*Guid*/ transactionIdentifier)
            {
                /*Hashtable*/ let promotedTransactionTable = $.$stl.System.Transactions.TransactionManager.PromotedTransactionTable;
                /*WeakReference?*/ let weakRef = $.$cast(promotedTransactionTable.get_Item(transactionIdentifier), $.$spc.System.WeakReference);
                if (null !== weakRef)
                {
                    let tx;
                    if ($.$is(weakRef.Target, $.$stl.System.Transactions.Transaction, { set $v(v){ tx = v; } }))
                    {
                        return tx.InternalClone();
                    }
                    else 
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(promotedTransactionTable)
                            {
                                promotedTransactionTable.Remove(transactionIdentifier);
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(promotedTransactionTable)
                        }
                    }
                }
                return null;
            }
            static /*Transaction */ FindOrCreatePromotedTransaction(/*Guid*/ transactionIdentifier, /*OletxTransaction*/ dtx)
            {
                /*Transaction?*/ let tx = null;
                /*Hashtable*/ let promotedTransactionTable = $.$stl.System.Transactions.TransactionManager.PromotedTransactionTable;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(promotedTransactionTable)
                    {
                        /*WeakReference?*/ let weakRef = $.$cast(promotedTransactionTable.get_Item(transactionIdentifier), $.$spc.System.WeakReference);
                        if (null !== weakRef)
                        {
                            tx = $.$as(weakRef.Target, $.$stl.System.Transactions.Transaction);
                            if ($.$stl.System.Transactions.Transaction.op_Inequality(null, tx))
                            {
                                return tx.InternalClone();
                            }
                            else 
                            {
                                //lock
                                try
                                {
                                    $.$spc.System.Threading.Monitor.Enter(promotedTransactionTable)
                                    {
                                        promotedTransactionTable.Remove(transactionIdentifier);
                                    }
                                }
                                finally
                                {
                                    $.$spc.System.Threading.Monitor.Exit(promotedTransactionTable)
                                }
                            }
                        }
                        tx = new $.$stl.System.Transactions.Transaction().$ctor$3(dtx);
                        tx._internalTransaction._finalizedObject = new $.$stl.System.Transactions.FinalizedObject().$ctor$1(tx._internalTransaction, dtx.Identifier);
                        weakRef = new $.$spc.System.WeakReference().$ctor$2(tx, false);
                        promotedTransactionTable.set_Item(dtx.Identifier, weakRef);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(promotedTransactionTable)
                }
                dtx.SavedLtmPromotedTransaction = tx;
                $.$stl.System.Transactions.TransactionManager.FireDistributedTransactionStarted(tx);
                return tx;
            }
            static /*Hashtable */ get PromotedTransactionTable()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$spc.System.Collections.Hashtable, $.$ref(() => $.$stl.System.Transactions.TransactionManager.s_promotedTransactionTable, ($v) => $.$stl.System.Transactions.TransactionManager.s_promotedTransactionTable = $v, $.$spc.System.Collections.Hashtable), $.$ref(() => $.$stl.System.Transactions.TransactionManager.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionManager.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$spc.System.Collections.Hashtable))().$ctor(this,  () =>
                {
                    return new $.$spc.System.Collections.Hashtable().$ctor$3(100);
                }));
            }
            static /*TransactionTable */ get TransactionTable()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionTable, $.$ref(() => $.$stl.System.Transactions.TransactionManager.s_transactionTable, ($v) => $.$stl.System.Transactions.TransactionManager.s_transactionTable = $v, $.$stl.System.Transactions.TransactionTable), $.$ref(() => $.$stl.System.Transactions.TransactionManager.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionManager.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionTable))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionTable().$ctor$1();
                }));
            }
            /*OletxTransactionManager?*/ static distributedTransactionManager = null;
            static /*OletxTransactionManager */ get DistributedTransactionManager()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.Oletx.OletxTransactionManager, $.$ref(() => $.$stl.System.Transactions.TransactionManager.distributedTransactionManager, ($v) => $.$stl.System.Transactions.TransactionManager.distributedTransactionManager = $v, $.$stl.System.Transactions.Oletx.OletxTransactionManager), $.$ref(() => $.$stl.System.Transactions.TransactionManager.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionManager.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.Oletx.OletxTransactionManager))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.Oletx.OletxTransactionManager().$ctor$1($.$stl.System.Transactions.Configuration.DefaultSettingsSection.DistributedTransactionManagerName);
                }));
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.DistributedTransactionTrimmingWarning = "Distributed transactions support may not be compatible with trimming. If your program creates a distributed transaction via System.Transactions, the correctness of the application cannot be guaranteed after trimming.";
                }
                {
                    this.s_maximumTimeout = $.$default($.$spc.System.TimeSpan);
                }
            }
            static $h = 4897324;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":2472492,"g":{"r":0,"d":0,"h":64429406764,"f":33},"s":{"r":0,"d":0,"h":68724374060,"f":33},"n":"HostCurrentCallback","d":4897324,"h":60134439468,"f":33},{"p":131073,"g":{"r":0,"d":0,"h":94494177836,"f":34},"n":"ClassSyncObject","d":4897324,"h":90199210540,"f":34},{"p":3193388,"g":{"r":0,"d":0,"h":103084112428,"f":40},"n":"DefaultIsolationLevel","d":4897324,"h":98789145132,"f":40},{"p":768556,"g":{"r":0,"d":0,"h":115969014316,"f":34},"n":"DefaultSettings","d":4897324,"h":111674047020,"f":34},{"p":834092,"g":{"r":0,"d":0,"h":128853916204,"f":34},"n":"MachineSettings","d":4897324,"h":124558948908,"f":34},{"p":140705793,"g":{"r":0,"d":0,"h":146033785388,"f":33},"s":{"r":0,"d":0,"h":150328752684,"f":33},"n":"DefaultTimeout","d":4897324,"h":141738818092,"f":33},{"p":140705793,"g":{"r":0,"d":0,"h":167508621868,"f":33},"s":{"r":0,"d":0,"h":171803589164,"f":33},"n":"MaximumTimeout","d":4897324,"h":163213654572,"f":33},{"p":262145,"g":{"r":0,"d":0,"h":180393523756,"f":33},"s":{"r":0,"d":0,"h":184688491052,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},"n":"ImplicitDistributedTransactions","d":4897324,"h":176098556460,"f":33},{"p":30932993,"g":{"r":0,"d":0,"h":214753262124,"f":40},"n":"PromotedTransactionTable","d":4897324,"h":210458294828,"f":40},{"p":8501804,"g":{"r":0,"d":0,"h":223343196716,"f":40},"n":"TransactionTable","d":4897324,"h":219048229420,"f":40},{"p":3652140,"g":{"r":0,"d":0,"h":236228098604,"f":40},"n":"DistributedTransactionManager","d":4897324,"h":231933131308,"f":40}],"m":[{"r":65537,"p":[{"n":"eventHandler","p":5683756}],"n":"ProcessExistingTransactions","d":4897324,"h":42954570284,"f":40},{"r":65537,"p":[{"n":"transaction","p":4307500}],"n":"FireDistributedTransactionStarted","d":4897324,"h":47249537580,"f":40},{"r":1751596,"p":[{"n":"resourceManagerIdentifier","p":56164353},{"n":"recoveryInformation","p":0},{"n":"enlistmentNotification","p":2603564}],"n":"Reenlist","d":4897324,"h":73019341356,"f":33},{"r":3652140,"p":[{"n":"nodeName","p":1310721}],"n":"CheckTransactionManager","d":4897324,"h":77314308652,"f":34},{"r":65537,"p":[{"n":"resourceManagerIdentifier","p":56164353}],"n":"RecoveryComplete","d":4897324,"h":81609275948,"f":33},{"r":0,"p":[{"n":"startupInfo","p":1310721},{"n":"resourceManagerRecoveryInformation","p":0}],"n":"GetRecoveryInformation","d":4897324,"h":188983458348,"f":40},{"r":65537,"p":[{"n":"transactionIsolationLevel","p":3193388}],"n":"ValidateIsolationLevel","d":4897324,"h":193278425644,"f":40},{"r":140705793,"p":[{"n":"transactionTimeout","p":140705793}],"n":"ValidateTimeout","d":4897324,"h":197573392940,"f":40},{"r":4307500,"p":[{"n":"transactionIdentifier","p":56164353}],"n":"FindPromotedTransaction","d":4897324,"h":201868360236,"f":40},{"r":4307500,"p":[{"n":"transactionIdentifier","p":56164353},{"n":"dtx","p":3521068}],"n":"FindOrCreatePromotedTransaction","d":4897324,"h":206163327532,"f":40}],"l":[{"t":655361,"n":"RecoveryInformationVersion1","d":4897324,"h":4299864620,"f":34},{"t":655361,"n":"CurrentRecoveryVersion","d":4897324,"h":8594831916,"f":34},{"t":30932993,"n":"s_promotedTransactionTable","d":4897324,"h":12889799212,"f":34},{"t":8501804,"n":"s_transactionTable","d":4897324,"h":17184766508,"f":34},{"t":5683756,"n":"s_distributedTransactionStartedDelegate","d":4897324,"h":21479733804,"f":34},{"t":1310721,"n":"DistributedTransactionTrimmingWarning","d":4897324,"h":25774701100,"f":40},{"t":2472492,"n":"s_currentDelegate","d":4897324,"h":51544504876,"f":40},{"t":262145,"n":"s_currentDelegateSet","d":4897324,"h":55839472172,"f":40},{"t":131073,"n":"s_classSyncObject","d":4897324,"h":85904243244,"f":34},{"t":262145,"n":"s_defaultTimeoutValidated","d":4897324,"h":133148883500,"f":34},{"t":917505,"n":"s_defaultTimeoutTicks","d":4897324,"h":137443850796,"f":34},{"t":262145,"n":"s_cachedMaxTimeout","d":4897324,"h":154623719980,"f":34},{"t":140705793,"n":"s_maximumTimeout","d":4897324,"h":158918687276,"f":34},{"t":3652140,"n":"distributedTransactionManager","d":4897324,"h":227638164012,"f":40}],"e":[{"e":5683756,"m":{"r":65537,"p":[{"n":"value","p":5683756}],"n":"add_DistributedTransactionStarted","d":4897324,"h":34364635692,"f":33},"r":{"r":65537,"p":[{"n":"value","p":5683756}],"n":"remove_DistributedTransactionStarted","d":4897324,"h":38659602988,"f":33},"n":"DistributedTransactionStarted","d":4897324,"h":30069668396,"f":33}],"h":4897324}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Transactions.TransactionManager`; }
        });
        
        $asm.$cls("$stl.System.Transactions.Configuration.AppSettings", ($self) => class AppSettings
        {
            /*bool*/ static s_settingsInitialized = false;
            /*object*/ static s_appSettingsLock = null;
            /*bool*/ static s_includeDistributedTxIdInExceptionMessage = false;
            static /*void */ EnsureSettingsLoaded()
            {
                if (!$.$stl.System.Transactions.Configuration.AppSettings.s_settingsInitialized)
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter($.$stl.System.Transactions.Configuration.AppSettings.s_appSettingsLock)
                        {
                            if (!$.$stl.System.Transactions.Configuration.AppSettings.s_settingsInitialized)
                            {
                                $.$stl.System.Transactions.Configuration.AppSettings.s_includeDistributedTxIdInExceptionMessage = false;
                                $.$stl.System.Transactions.Configuration.AppSettings.s_settingsInitialized = true;
                            }
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit($.$stl.System.Transactions.Configuration.AppSettings.s_appSettingsLock)
                    }
                }
            }
            static /*bool */ get IncludeDistributedTxIdInExceptionMessage()
            {
                $.$stl.System.Transactions.Configuration.AppSettings.EnsureSettingsLoaded();
                return $.$stl.System.Transactions.Configuration.AppSettings.s_includeDistributedTxIdInExceptionMessage;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_appSettingsLock = new $.$spc.System.Object().$ctor();
                }
            }
            static $h = 637484;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":25770441260,"f":40},"n":"IncludeDistributedTxIdInExceptionMessage","d":637484,"h":21475473964,"f":40}],"m":[{"r":65537,"n":"EnsureSettingsLoaded","d":637484,"h":17180506668,"f":34}],"l":[{"t":262145,"n":"s_settingsInitialized","d":637484,"h":4295604780,"f":34},{"t":131073,"n":"s_appSettingsLock","d":637484,"h":8590572076,"f":34},{"t":262145,"n":"s_includeDistributedTxIdInExceptionMessage","d":637484,"h":12885539372,"f":34}],"h":637484}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Transactions.Configuration.AppSettings`; }
        });
        
        $asm.$cls("$stl.System.Transactions.Configuration.ConfigurationStrings", ($self) => class ConfigurationStrings
        {
            /*string*/ static DefaultDistributedTransactionManagerName = null;
            /*string*/ static DefaultMaxTimeout = null;
            /*string*/ static DefaultTimeout = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.DefaultDistributedTransactionManagerName = "";
                }
                {
                    this.DefaultMaxTimeout = "00:10:00";
                }
                {
                    this.DefaultTimeout = "00:01:00";
                }
            }
            static $h = 703020;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"DefaultDistributedTransactionManagerName","d":703020,"h":4295670316,"f":40},{"t":1310721,"n":"DefaultMaxTimeout","d":703020,"h":8590637612,"f":40},{"t":1310721,"n":"DefaultTimeout","d":703020,"h":12885604908,"f":40}],"h":703020}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Transactions.Configuration.ConfigurationStrings`; }
        });
        
        $asm.$cls("$stl.System.Transactions.Configuration.DefaultSettingsSection", ($self) => class DefaultSettingsSection extends $.$spc.System.Object
        {
            /*DefaultSettingsSection*/ static s_section = null;
            /*TimeSpan*/ static s_timeout;
            static /*DefaultSettingsSection */ GetSection()
            {
                return $.$stl.System.Transactions.Configuration.DefaultSettingsSection.s_section;
            }
            /*string*/ static DistributedTransactionManagerName = null;
            static /*TimeSpan */ get Timeout()
            {
                return $.$stl.System.Transactions.Configuration.DefaultSettingsSection.s_timeout;
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_section = new $.$stl.System.Transactions.Configuration.DefaultSettingsSection().$ctor$1();
                }
                {
                    this.s_timeout = $.$spc.System.TimeSpan.Parse("00:01:00"/*ConfigurationStrings.DefaultTimeout*/);
                }
                {
                    this.DistributedTransactionManagerName = "";
                }
            }
            static $h = 768556;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":25770572332,"f":33},"s":{"r":0,"d":0,"h":30065539628,"f":33},"n":"DistributedTransactionManagerName","d":768556,"h":21475605036,"f":33},{"p":140705793,"g":{"r":0,"d":0,"h":38655474220,"f":33},"n":"Timeout","d":768556,"h":34360506924,"f":33}],"m":[{"r":768556,"n":"GetSection","d":768556,"h":12885670444,"f":40}],"l":[{"t":768556,"n":"s_section","d":768556,"h":4295735852,"f":34},{"t":140705793,"n":"s_timeout","d":768556,"h":8590703148,"f":34}],"c":[{"n":".ctor","o":"$ctor$1","d":768556,"h":42950441516,"f":1}],"h":768556}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Transactions.Configuration.DefaultSettingsSection`; }
        });
        
        $asm.$cls("$stl.System.Transactions.Configuration.MachineSettingsSection", ($self) => class MachineSettingsSection extends $.$spc.System.Object
        {
            /*MachineSettingsSection*/ static s_section = null;
            /*TimeSpan*/ static s_maxTimeout;
            static /*MachineSettingsSection */ GetSection()
            {
                return $.$stl.System.Transactions.Configuration.MachineSettingsSection.s_section;
            }
            static /*TimeSpan */ get MaxTimeout()
            {
                return $.$stl.System.Transactions.Configuration.MachineSettingsSection.s_maxTimeout;
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_section = new $.$stl.System.Transactions.Configuration.MachineSettingsSection().$ctor$1();
                }
                {
                    this.s_maxTimeout = $.$spc.System.TimeSpan.Parse("00:10:00"/*ConfigurationStrings.DefaultMaxTimeout*/);
                }
            }
            static $h = 834092;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":140705793,"g":{"r":0,"d":0,"h":21475670572,"f":33},"n":"MaxTimeout","d":834092,"h":17180703276,"f":33}],"m":[{"r":834092,"n":"GetSection","d":834092,"h":12885735980,"f":40}],"l":[{"t":834092,"n":"s_section","d":834092,"h":4295801388,"f":34},{"t":140705793,"n":"s_maxTimeout","d":834092,"h":8590768684,"f":34}],"c":[{"n":".ctor","o":"$ctor$1","d":834092,"h":25770637868,"f":1}],"h":834092}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Transactions.Configuration.MachineSettingsSection`; }
        });
        
        $asm.$cls("$stl.System.Transactions.Enlistment", ($self) => class Enlistment extends $.$spc.System.Object
        {
            /*InternalEnlistment*/ _internalEnlistment = null;
            $ctor$1(/*InternalEnlistment*/ internalEnlistment)
            {
                super.$ctor();
                {
                    this._internalEnlistment = internalEnlistment;
                }
                return this;
            }
            $ctor$2(/*Guid*/ resourceManagerIdentifier, /*InternalTransaction*/ transaction, /*IEnlistmentNotification*/ twoPhaseNotifications, /*ISinglePhaseNotification?*/ singlePhaseNotifications, /*Transaction*/ atomicTransaction)
            {
                super.$ctor();
                {
                    this._internalEnlistment = new $.$stl.System.Transactions.DurableInternalEnlistment().$ctor$5(this, resourceManagerIdentifier, transaction, twoPhaseNotifications, singlePhaseNotifications, atomicTransaction);
                }
                return this;
            }
            $ctor$3(/*InternalTransaction*/ transaction, /*IEnlistmentNotification*/ twoPhaseNotifications, /*ISinglePhaseNotification?*/ singlePhaseNotifications, /*Transaction*/ atomicTransaction, /*EnlistmentOptions*/ enlistmentOptions)
            {
                super.$ctor();
                {
                    if ((enlistmentOptions & 1/*EnlistmentOptions.EnlistDuringPrepareRequired*/) !== 0)
                    {
                        this._internalEnlistment = new $.$stl.System.Transactions.InternalEnlistment().$ctor$3(this, transaction, twoPhaseNotifications, singlePhaseNotifications, atomicTransaction);
                    }
                    else 
                    {
                        this._internalEnlistment = new $.$stl.System.Transactions.Phase1VolatileEnlistment().$ctor$5(this, transaction, twoPhaseNotifications, singlePhaseNotifications, atomicTransaction);
                    }
                }
                return this;
            }
            $ctor$4(/*InternalTransaction*/ transaction, /*IPromotableSinglePhaseNotification*/ promotableSinglePhaseNotification, /*Transaction*/ atomicTransaction)
            {
                super.$ctor();
                {
                    this._internalEnlistment = new $.$stl.System.Transactions.PromotableInternalEnlistment().$ctor$5(this, transaction, promotableSinglePhaseNotification, atomicTransaction);
                }
                return this;
            }
            $ctor$5(/*IEnlistmentNotification*/ twoPhaseNotifications, /*InternalTransaction*/ transaction, /*Transaction*/ atomicTransaction)
            {
                super.$ctor();
                {
                    this._internalEnlistment = new $.$stl.System.Transactions.InternalEnlistment().$ctor$4(this, twoPhaseNotifications, transaction, atomicTransaction);
                }
                return this;
            }
            $ctor$6(/*IEnlistmentNotification*/ twoPhaseNotifications, /*object*/ syncRoot)
            {
                super.$ctor();
                {
                    this._internalEnlistment = new $.$stl.System.Transactions.RecoveringInternalEnlistment().$ctor$7(this, twoPhaseNotifications, syncRoot);
                }
                return this;
            }
            /*void */ Done()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "Done");
                    etwLog.EnlistmentDone(this._internalEnlistment);
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalEnlistment.SyncRoot)
                    {
                        this._internalEnlistment.State.EnlistmentDone(this._internalEnlistment);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalEnlistment.SyncRoot)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "Done");
                }
            }
            /*InternalEnlistment */ get InternalEnlistment()
            {
                return this._internalEnlistment;
            }
            static $h = 1751596;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":2734636,"g":{"r":0,"d":0,"h":42951424556,"f":8},"n":"InternalEnlistment","d":1751596,"h":38656457260,"f":8}],"m":[{"r":65537,"n":"Done","d":1751596,"h":34361489964,"f":1}],"l":[{"t":2734636,"n":"_internalEnlistment","d":1751596,"h":4296718892,"f":8}],"c":[{"p":[{"n":"internalEnlistment","p":2734636}],"n":".ctor","o":"$ctor$1","d":1751596,"h":8591686188,"f":8},{"p":[{"n":"resourceManagerIdentifier","p":56164353},{"n":"transaction","p":2800172},{"n":"twoPhaseNotifications","p":2603564},{"n":"singlePhaseNotifications","p":3062316},{"n":"atomicTransaction","p":4307500}],"n":".ctor","o":"$ctor$2","d":1751596,"h":12886653484,"f":8},{"p":[{"n":"transaction","p":2800172},{"n":"twoPhaseNotifications","p":2603564},{"n":"singlePhaseNotifications","p":3062316},{"n":"atomicTransaction","p":4307500},{"n":"enlistmentOptions","p":1882668}],"n":".ctor","o":"$ctor$3","d":1751596,"h":17181620780,"f":8},{"p":[{"n":"transaction","p":2800172},{"n":"promotableSinglePhaseNotification","p":2865708},{"n":"atomicTransaction","p":4307500}],"n":".ctor","o":"$ctor$4","d":1751596,"h":21476588076,"f":8},{"p":[{"n":"twoPhaseNotifications","p":2603564},{"n":"transaction","p":2800172},{"n":"atomicTransaction","p":4307500}],"n":".ctor","o":"$ctor$5","d":1751596,"h":25771555372,"f":8},{"p":[{"n":"twoPhaseNotifications","p":2603564},{"n":"syncRoot","p":131073}],"n":".ctor","o":"$ctor$6","d":1751596,"h":30066522668,"f":8}],"h":1751596}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Transactions.Enlistment`; }
        });
        
        $asm.$cls("$stl.System.Obsoletions", ($self) => class Obsoletions
        {
            /*string*/ static SharedUrlFormat = null;
            /*string*/ static SystemTextEncodingUTF7Message = null;
            /*string*/ static SystemTextEncodingUTF7DiagId = null;
            /*string*/ static PrincipalPermissionAttributeMessage = null;
            /*string*/ static PrincipalPermissionAttributeDiagId = null;
            /*string*/ static CodeAccessSecurityMessage = null;
            /*string*/ static CodeAccessSecurityDiagId = null;
            /*string*/ static ConstrainedExecutionRegionMessage = null;
            /*string*/ static ConstrainedExecutionRegionDiagId = null;
            /*string*/ static GlobalAssemblyCacheMessage = null;
            /*string*/ static GlobalAssemblyCacheDiagId = null;
            /*string*/ static ThreadAbortMessage = null;
            /*string*/ static ThreadResetAbortMessage = null;
            /*string*/ static ThreadAbortDiagId = null;
            /*string*/ static DefaultCryptoAlgorithmsMessage = null;
            /*string*/ static DefaultCryptoAlgorithmsDiagId = null;
            /*string*/ static CreatePdbGeneratorMessage = null;
            /*string*/ static CreatePdbGeneratorDiagId = null;
            /*string*/ static AuthenticationManagerMessage = null;
            /*string*/ static AuthenticationManagerDiagId = null;
            /*string*/ static RemotingApisMessage = null;
            /*string*/ static RemotingApisDiagId = null;
            /*string*/ static BinaryFormatterMessage = null;
            /*string*/ static BinaryFormatterDiagId = null;
            /*string*/ static CodeBaseMessage = null;
            /*string*/ static CodeBaseDiagId = null;
            /*string*/ static EscapeUriStringMessage = null;
            /*string*/ static EscapeUriStringDiagId = null;
            /*string*/ static WebRequestMessage = null;
            /*string*/ static WebRequestDiagId = null;
            /*string*/ static DisablePrivateReflectionAttributeMessage = null;
            /*string*/ static DisablePrivateReflectionAttributeDiagId = null;
            /*string*/ static GetContextInfoMessage = null;
            /*string*/ static GetContextInfoDiagId = null;
            /*string*/ static StrongNameKeyPairMessage = null;
            /*string*/ static StrongNameKeyPairDiagId = null;
            /*string*/ static ReflectionOnlyLoadingMessage = null;
            /*string*/ static ReflectionOnlyLoadingDiagId = null;
            /*string*/ static RuntimeEnvironmentMessage = null;
            /*string*/ static RuntimeEnvironmentDiagId = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesMessage = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesDiagId = null;
            /*string*/ static DerivedCryptographicTypesMessage = null;
            /*string*/ static DerivedCryptographicTypesDiagId = null;
            /*string*/ static RijndaelMessage = null;
            /*string*/ static RijndaelDiagId = null;
            /*string*/ static RNGCryptoServiceProviderMessage = null;
            /*string*/ static RNGCryptoServiceProviderDiagId = null;
            /*string*/ static AppDomainCreateUnloadMessage = null;
            /*string*/ static AppDomainCreateUnloadDiagId = null;
            /*string*/ static SuppressIldasmAttributeMessage = null;
            /*string*/ static SuppressIldasmAttributeDiagId = null;
            /*string*/ static X509CertificateImmutableMessage = null;
            /*string*/ static X509CertificateImmutableDiagId = null;
            /*string*/ static PublicKeyPropertyMessage = null;
            /*string*/ static PublicKeyPropertyDiagId = null;
            /*string*/ static X509CertificatePrivateKeyMessage = null;
            /*string*/ static X509CertificatePrivateKeyDiagId = null;
            /*string*/ static ProduceLegacyHmacValuesMessage = null;
            /*string*/ static ProduceLegacyHmacValuesDiagId = null;
            /*string*/ static UseManagedSha1Message = null;
            /*string*/ static UseManagedSha1DiagId = null;
            /*string*/ static CryptoConfigEncodeOIDMessage = null;
            /*string*/ static CryptoConfigEncodeOIDDiagId = null;
            /*string*/ static CorruptedStateRecoveryMessage = null;
            /*string*/ static CorruptedStateRecoveryDiagId = null;
            /*string*/ static Rfc2898CryptDeriveKeyMessage = null;
            /*string*/ static Rfc2898CryptDeriveKeyDiagId = null;
            /*string*/ static CmsSignerCspParamsCtorMessage = null;
            /*string*/ static CmsSignerCspParamsCtorDiagId = null;
            /*string*/ static SignerInfoCounterSigMessage = null;
            /*string*/ static SignerInfoCounterSigDiagId = null;
            /*string*/ static RegexCompileToAssemblyMessage = null;
            /*string*/ static RegexCompileToAssemblyDiagId = null;
            /*string*/ static AssemblyNameMembersMessage = null;
            /*string*/ static AssemblyNameMembersDiagId = null;
            /*string*/ static SystemDataSerializationFormatBinaryMessage = null;
            /*string*/ static SystemDataSerializationFormatBinaryDiagId = null;
            /*string*/ static TlsVersion10and11Message = null;
            /*string*/ static TlsVersion10and11DiagId = null;
            /*string*/ static EncryptionPolicyMessage = null;
            /*string*/ static EncryptionPolicyDiagId = null;
            /*string*/ static EccXmlExportImportMessage = null;
            /*string*/ static EccXmlExportImportDiagId = null;
            /*string*/ static EcDhPublicKeyBlobMessage = null;
            /*string*/ static EcDhPublicKeyBlobDiagId = null;
            /*string*/ static AssemblyNameCodeBaseMessage = null;
            /*string*/ static AssemblyNameCodeBaseDiagId = null;
            /*string*/ static CryptoStringFactoryMessage = null;
            /*string*/ static CryptoStringFactoryDiagId = null;
            /*string*/ static ControlledExecutionRunMessage = null;
            /*string*/ static ControlledExecutionRunDiagId = null;
            /*string*/ static XmlSecureResolverMessage = null;
            /*string*/ static XmlSecureResolverDiagId = null;
            /*string*/ static RsaEncryptDecryptValueMessage = null;
            /*string*/ static RsaEncryptDecryptDiagId = null;
            /*string*/ static JsonSerializerOptionsAddContextMessage = null;
            /*string*/ static JsonSerializerOptionsAddContextDiagId = null;
            /*string*/ static LegacyFormatterMessage = null;
            /*string*/ static LegacyFormatterDiagId = null;
            /*string*/ static LegacyFormatterImplMessage = null;
            /*string*/ static LegacyFormatterImplDiagId = null;
            /*string*/ static RegexExtensibilityImplMessage = null;
            /*string*/ static RegexExtensibilityDiagId = null;
            /*string*/ static AesGcmTagConstructorMessage = null;
            /*string*/ static AesGcmTagConstructorDiagId = null;
            /*string*/ static ThreadVolatileReadWriteMessage = null;
            /*string*/ static ThreadVolatileReadWriteDiagId = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationMessage = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationDiagId = null;
            /*string*/ static LoadFromHashAlgorithmMessage = null;
            /*string*/ static LoadFromHashAlgorithmDiagId = null;
            /*string*/ static X509CtorCertDataObsoleteMessage = null;
            /*string*/ static X509CtorCertDataObsoleteDiagId = null;
            /*string*/ static TlsCipherAlgorithmEnumsMessage = null;
            /*string*/ static TlsCipherAlgorithmEnumsDiagId = null;
            /*string*/ static SystemEventsEventsThreadShutdownMessage = null;
            /*string*/ static SystemEventsEventsThreadShutdownDiagId = null;
            /*string*/ static Rfc2898DeriveBytesCtorMessage = null;
            /*string*/ static Rfc2898DeriveBytesCtorDiagId = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteMessage = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteDiagId = null;
            /*string*/ static XsltSettingsEnableScriptMessage = null;
            /*string*/ static XsltSettingsEnableScriptDiagId = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                }
                {
                    this.SystemTextEncodingUTF7Message = "The UTF-7 encoding is insecure and should not be used. Consider using UTF-8 instead.";
                }
                {
                    this.SystemTextEncodingUTF7DiagId = "SYSLIB0001";
                }
                {
                    this.PrincipalPermissionAttributeMessage = "PrincipalPermissionAttribute is not honored by the runtime and must not be used.";
                }
                {
                    this.PrincipalPermissionAttributeDiagId = "SYSLIB0002";
                }
                {
                    this.CodeAccessSecurityMessage = "Code Access Security is not supported or honored by the runtime.";
                }
                {
                    this.CodeAccessSecurityDiagId = "SYSLIB0003";
                }
                {
                    this.ConstrainedExecutionRegionMessage = "The Constrained Execution Region (CER) feature is not supported.";
                }
                {
                    this.ConstrainedExecutionRegionDiagId = "SYSLIB0004";
                }
                {
                    this.GlobalAssemblyCacheMessage = "The Global Assembly Cache is not supported.";
                }
                {
                    this.GlobalAssemblyCacheDiagId = "SYSLIB0005";
                }
                {
                    this.ThreadAbortMessage = "Thread.Abort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadResetAbortMessage = "Thread.ResetAbort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadAbortDiagId = "SYSLIB0006";
                }
                {
                    this.DefaultCryptoAlgorithmsMessage = "The default implementation of this cryptography algorithm is not supported.";
                }
                {
                    this.DefaultCryptoAlgorithmsDiagId = "SYSLIB0007";
                }
                {
                    this.CreatePdbGeneratorMessage = "The CreatePdbGenerator API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.CreatePdbGeneratorDiagId = "SYSLIB0008";
                }
                {
                    this.AuthenticationManagerMessage = "AuthenticationManager is not supported. Methods will no-op or throw PlatformNotSupportedException.";
                }
                {
                    this.AuthenticationManagerDiagId = "SYSLIB0009";
                }
                {
                    this.RemotingApisMessage = "This Remoting API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.RemotingApisDiagId = "SYSLIB0010";
                }
                {
                    this.BinaryFormatterMessage = "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.";
                }
                {
                    this.BinaryFormatterDiagId = "SYSLIB0011";
                }
                {
                    this.CodeBaseMessage = "Assembly.CodeBase and Assembly.EscapedCodeBase are only included for .NET Framework compatibility. Use Assembly.Location instead.";
                }
                {
                    this.CodeBaseDiagId = "SYSLIB0012";
                }
                {
                    this.EscapeUriStringMessage = "Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.";
                }
                {
                    this.EscapeUriStringDiagId = "SYSLIB0013";
                }
                {
                    this.WebRequestMessage = "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.";
                }
                {
                    this.WebRequestDiagId = "SYSLIB0014";
                }
                {
                    this.DisablePrivateReflectionAttributeMessage = "DisablePrivateReflectionAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.DisablePrivateReflectionAttributeDiagId = "SYSLIB0015";
                }
                {
                    this.GetContextInfoMessage = "Use the Graphics.GetContextInfo overloads that accept arguments for better performance and fewer allocations.";
                }
                {
                    this.GetContextInfoDiagId = "SYSLIB0016";
                }
                {
                    this.StrongNameKeyPairMessage = "Strong name signing is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.StrongNameKeyPairDiagId = "SYSLIB0017";
                }
                {
                    this.ReflectionOnlyLoadingMessage = "ReflectionOnly loading is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ReflectionOnlyLoadingDiagId = "SYSLIB0018";
                }
                {
                    this.RuntimeEnvironmentMessage = "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.";
                }
                {
                    this.RuntimeEnvironmentDiagId = "SYSLIB0019";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesMessage = "JsonSerializerOptions.IgnoreNullValues is obsolete. To ignore null values when serializing, set DefaultIgnoreCondition to JsonIgnoreCondition.WhenWritingNull.";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesDiagId = "SYSLIB0020";
                }
                {
                    this.DerivedCryptographicTypesMessage = "Derived cryptographic types are obsolete. Use the Create method on the base type instead.";
                }
                {
                    this.DerivedCryptographicTypesDiagId = "SYSLIB0021";
                }
                {
                    this.RijndaelMessage = "The Rijndael and RijndaelManaged types are obsolete. Use Aes instead.";
                }
                {
                    this.RijndaelDiagId = "SYSLIB0022";
                }
                {
                    this.RNGCryptoServiceProviderMessage = "RNGCryptoServiceProvider is obsolete. To generate a random number, use one of the RandomNumberGenerator static methods instead.";
                }
                {
                    this.RNGCryptoServiceProviderDiagId = "SYSLIB0023";
                }
                {
                    this.AppDomainCreateUnloadMessage = "Creating and unloading AppDomains is not supported and throws an exception.";
                }
                {
                    this.AppDomainCreateUnloadDiagId = "SYSLIB0024";
                }
                {
                    this.SuppressIldasmAttributeMessage = "SuppressIldasmAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.SuppressIldasmAttributeDiagId = "SYSLIB0025";
                }
                {
                    this.X509CertificateImmutableMessage = "X509Certificate and X509Certificate2 are immutable. Use X509CertificateLoader to create a new certificate.";
                }
                {
                    this.X509CertificateImmutableDiagId = "SYSLIB0026";
                }
                {
                    this.PublicKeyPropertyMessage = "PublicKey.Key is obsolete. Use the appropriate method to get the public key, such as GetRSAPublicKey.";
                }
                {
                    this.PublicKeyPropertyDiagId = "SYSLIB0027";
                }
                {
                    this.X509CertificatePrivateKeyMessage = "X509Certificate2.PrivateKey is obsolete. Use the appropriate method to get the private key, such as GetRSAPrivateKey, or use the CopyWithPrivateKey method to create a new instance with a private key.";
                }
                {
                    this.X509CertificatePrivateKeyDiagId = "SYSLIB0028";
                }
                {
                    this.ProduceLegacyHmacValuesMessage = "ProduceLegacyHmacValues is obsolete. Producing legacy HMAC values is not supported.";
                }
                {
                    this.ProduceLegacyHmacValuesDiagId = "SYSLIB0029";
                }
                {
                    this.UseManagedSha1Message = "HMACSHA1 always uses the algorithm implementation provided by the platform. Use a constructor without the useManagedSha1 parameter.";
                }
                {
                    this.UseManagedSha1DiagId = "SYSLIB0030";
                }
                {
                    this.CryptoConfigEncodeOIDMessage = "EncodeOID is obsolete. Use the ASN.1 functionality provided in System.Formats.Asn1.";
                }
                {
                    this.CryptoConfigEncodeOIDDiagId = "SYSLIB0031";
                }
                {
                    this.CorruptedStateRecoveryMessage = "Recovery from corrupted process state exceptions is not supported; HandleProcessCorruptedStateExceptionsAttribute is ignored.";
                }
                {
                    this.CorruptedStateRecoveryDiagId = "SYSLIB0032";
                }
                {
                    this.Rfc2898CryptDeriveKeyMessage = "Rfc2898DeriveBytes.CryptDeriveKey is obsolete and is not supported. Use PasswordDeriveBytes.CryptDeriveKey instead.";
                }
                {
                    this.Rfc2898CryptDeriveKeyDiagId = "SYSLIB0033";
                }
                {
                    this.CmsSignerCspParamsCtorMessage = "CmsSigner(CspParameters) is obsolete and is not supported. Use an alternative constructor instead.";
                }
                {
                    this.CmsSignerCspParamsCtorDiagId = "SYSLIB0034";
                }
                {
                    this.SignerInfoCounterSigMessage = "ComputeCounterSignature without specifying a CmsSigner is obsolete and is not supported. Use the overload that accepts a CmsSigner.";
                }
                {
                    this.SignerInfoCounterSigDiagId = "SYSLIB0035";
                }
                {
                    this.RegexCompileToAssemblyMessage = "Regex.CompileToAssembly is obsolete and not supported. Use the GeneratedRegexAttribute with the regular expression source generator instead.";
                }
                {
                    this.RegexCompileToAssemblyDiagId = "SYSLIB0036";
                }
                {
                    this.AssemblyNameMembersMessage = "AssemblyName members HashAlgorithm, ProcessorArchitecture, and VersionCompatibility are obsolete and not supported.";
                }
                {
                    this.AssemblyNameMembersDiagId = "SYSLIB0037";
                }
                {
                    this.SystemDataSerializationFormatBinaryMessage = "SerializationFormat.Binary is obsolete and should not be used. See https://aka.ms/serializationformat-binary-obsolete for more information.";
                }
                {
                    this.SystemDataSerializationFormatBinaryDiagId = "SYSLIB0038";
                }
                {
                    this.TlsVersion10and11Message = "TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.";
                }
                {
                    this.TlsVersion10and11DiagId = "SYSLIB0039";
                }
                {
                    this.EncryptionPolicyMessage = "EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.";
                }
                {
                    this.EncryptionPolicyDiagId = "SYSLIB0040";
                }
                {
                    this.EccXmlExportImportMessage = "ToXmlString and FromXmlString have no implementation for ECC types, and are obsolete. Use a standard import and export format such as ExportSubjectPublicKeyInfo or ImportSubjectPublicKeyInfo for public keys and ExportPkcs8PrivateKey or ImportPkcs8PrivateKey for private keys.";
                }
                {
                    this.EccXmlExportImportDiagId = "SYSLIB0042";
                }
                {
                    this.EcDhPublicKeyBlobMessage = "ECDiffieHellmanPublicKey.ToByteArray() and the associated constructor do not have a consistent and interoperable implementation on all platforms. Use ECDiffieHellmanPublicKey.ExportSubjectPublicKeyInfo() instead.";
                }
                {
                    this.EcDhPublicKeyBlobDiagId = "SYSLIB0043";
                }
                {
                    this.AssemblyNameCodeBaseMessage = "AssemblyName.CodeBase and AssemblyName.EscapedCodeBase are obsolete. Using them for loading an assembly is not supported.";
                }
                {
                    this.AssemblyNameCodeBaseDiagId = "SYSLIB0044";
                }
                {
                    this.CryptoStringFactoryMessage = "Cryptographic factory methods accepting an algorithm name are obsolete. Use the parameterless Create factory method on the algorithm type instead.";
                }
                {
                    this.CryptoStringFactoryDiagId = "SYSLIB0045";
                }
                {
                    this.ControlledExecutionRunMessage = "ControlledExecution.Run method may corrupt the process and should not be used in production code.";
                }
                {
                    this.ControlledExecutionRunDiagId = "SYSLIB0046";
                }
                {
                    this.XmlSecureResolverMessage = "XmlSecureResolver is obsolete. Use XmlResolver.ThrowingResolver instead when attempting to forbid XML external entity resolution.";
                }
                {
                    this.XmlSecureResolverDiagId = "SYSLIB0047";
                }
                {
                    this.RsaEncryptDecryptValueMessage = "RSA.EncryptValue and DecryptValue are not supported and throw NotSupportedException. Use RSA.Encrypt and RSA.Decrypt instead.";
                }
                {
                    this.RsaEncryptDecryptDiagId = "SYSLIB0048";
                }
                {
                    this.JsonSerializerOptionsAddContextMessage = "JsonSerializerOptions.AddContext is obsolete. To register a JsonSerializerContext, use either the TypeInfoResolver or TypeInfoResolverChain properties.";
                }
                {
                    this.JsonSerializerOptionsAddContextDiagId = "SYSLIB0049";
                }
                {
                    this.LegacyFormatterMessage = "Formatter-based serialization is obsolete and should not be used.";
                }
                {
                    this.LegacyFormatterDiagId = "SYSLIB0050";
                }
                {
                    this.LegacyFormatterImplMessage = "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.";
                }
                {
                    this.LegacyFormatterImplDiagId = "SYSLIB0051";
                }
                {
                    this.RegexExtensibilityImplMessage = "This API supports obsolete mechanisms for Regex extensibility. It is not supported.";
                }
                {
                    this.RegexExtensibilityDiagId = "SYSLIB0052";
                }
                {
                    this.AesGcmTagConstructorMessage = "AesGcm should indicate the required tag size for encryption and decryption. Use a constructor that accepts the tag size.";
                }
                {
                    this.AesGcmTagConstructorDiagId = "SYSLIB0053";
                }
                {
                    this.ThreadVolatileReadWriteMessage = "Thread.VolatileRead and Thread.VolatileWrite are obsolete. Use Volatile.Read or Volatile.Write respectively instead.";
                }
                {
                    this.ThreadVolatileReadWriteDiagId = "SYSLIB0054";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationMessage = "The underlying hardware instruction does not perform a signed saturate narrowing operation, and it always returns an unsigned result. Use the unsigned overload instead.";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationDiagId = "SYSLIB0055";
                }
                {
                    this.LoadFromHashAlgorithmMessage = "LoadFrom with a custom AssemblyHashAlgorithm is obsolete. Use overloads without an AssemblyHashAlgorithm.";
                }
                {
                    this.LoadFromHashAlgorithmDiagId = "SYSLIB0056";
                }
                {
                    this.X509CtorCertDataObsoleteMessage = "Loading certificate data through the constructor or Import is obsolete. Use X509CertificateLoader instead to load certificates.";
                }
                {
                    this.X509CtorCertDataObsoleteDiagId = "SYSLIB0057";
                }
                {
                    this.TlsCipherAlgorithmEnumsMessage = "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.";
                }
                {
                    this.TlsCipherAlgorithmEnumsDiagId = "SYSLIB0058";
                }
                {
                    this.SystemEventsEventsThreadShutdownMessage = "SystemEvents.EventsThreadShutdown callbacks are not run before the process exits. Use AppDomain.ProcessExit instead.";
                }
                {
                    this.SystemEventsEventsThreadShutdownDiagId = "SYSLIB0059";
                }
                {
                    this.Rfc2898DeriveBytesCtorMessage = "The constructors on Rfc2898DeriveBytes are obsolete. Use the static Pbkdf2 method instead.";
                }
                {
                    this.Rfc2898DeriveBytesCtorDiagId = "SYSLIB0060";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteMessage = "The Queryable MinBy and MaxBy taking an IComparer<TSource> are obsolete. Use the new ones that take an IComparer<TKey>.";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteDiagId = "SYSLIB0061";
                }
                {
                    this.XsltSettingsEnableScriptMessage = "XSLT Script blocks are not supported.";
                }
                {
                    this.XsltSettingsEnableScriptDiagId = "SYSLIB0062";
                }
            }
            static $h = 113196;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"SharedUrlFormat","d":113196,"h":4295080492,"f":40},{"t":1310721,"n":"SystemTextEncodingUTF7Message","d":113196,"h":8590047788,"f":40},{"t":1310721,"n":"SystemTextEncodingUTF7DiagId","d":113196,"h":12885015084,"f":40},{"t":1310721,"n":"PrincipalPermissionAttributeMessage","d":113196,"h":17179982380,"f":40},{"t":1310721,"n":"PrincipalPermissionAttributeDiagId","d":113196,"h":21474949676,"f":40},{"t":1310721,"n":"CodeAccessSecurityMessage","d":113196,"h":25769916972,"f":40},{"t":1310721,"n":"CodeAccessSecurityDiagId","d":113196,"h":30064884268,"f":40},{"t":1310721,"n":"ConstrainedExecutionRegionMessage","d":113196,"h":34359851564,"f":40},{"t":1310721,"n":"ConstrainedExecutionRegionDiagId","d":113196,"h":38654818860,"f":40},{"t":1310721,"n":"GlobalAssemblyCacheMessage","d":113196,"h":42949786156,"f":40},{"t":1310721,"n":"GlobalAssemblyCacheDiagId","d":113196,"h":47244753452,"f":40},{"t":1310721,"n":"ThreadAbortMessage","d":113196,"h":51539720748,"f":40},{"t":1310721,"n":"ThreadResetAbortMessage","d":113196,"h":55834688044,"f":40},{"t":1310721,"n":"ThreadAbortDiagId","d":113196,"h":60129655340,"f":40},{"t":1310721,"n":"DefaultCryptoAlgorithmsMessage","d":113196,"h":64424622636,"f":40},{"t":1310721,"n":"DefaultCryptoAlgorithmsDiagId","d":113196,"h":68719589932,"f":40},{"t":1310721,"n":"CreatePdbGeneratorMessage","d":113196,"h":73014557228,"f":40},{"t":1310721,"n":"CreatePdbGeneratorDiagId","d":113196,"h":77309524524,"f":40},{"t":1310721,"n":"AuthenticationManagerMessage","d":113196,"h":81604491820,"f":40},{"t":1310721,"n":"AuthenticationManagerDiagId","d":113196,"h":85899459116,"f":40},{"t":1310721,"n":"RemotingApisMessage","d":113196,"h":90194426412,"f":40},{"t":1310721,"n":"RemotingApisDiagId","d":113196,"h":94489393708,"f":40},{"t":1310721,"n":"BinaryFormatterMessage","d":113196,"h":98784361004,"f":40},{"t":1310721,"n":"BinaryFormatterDiagId","d":113196,"h":103079328300,"f":40},{"t":1310721,"n":"CodeBaseMessage","d":113196,"h":107374295596,"f":40},{"t":1310721,"n":"CodeBaseDiagId","d":113196,"h":111669262892,"f":40},{"t":1310721,"n":"EscapeUriStringMessage","d":113196,"h":115964230188,"f":40},{"t":1310721,"n":"EscapeUriStringDiagId","d":113196,"h":120259197484,"f":40},{"t":1310721,"n":"WebRequestMessage","d":113196,"h":124554164780,"f":40},{"t":1310721,"n":"WebRequestDiagId","d":113196,"h":128849132076,"f":40},{"t":1310721,"n":"DisablePrivateReflectionAttributeMessage","d":113196,"h":133144099372,"f":40},{"t":1310721,"n":"DisablePrivateReflectionAttributeDiagId","d":113196,"h":137439066668,"f":40},{"t":1310721,"n":"GetContextInfoMessage","d":113196,"h":141734033964,"f":40},{"t":1310721,"n":"GetContextInfoDiagId","d":113196,"h":146029001260,"f":40},{"t":1310721,"n":"StrongNameKeyPairMessage","d":113196,"h":150323968556,"f":40},{"t":1310721,"n":"StrongNameKeyPairDiagId","d":113196,"h":154618935852,"f":40},{"t":1310721,"n":"ReflectionOnlyLoadingMessage","d":113196,"h":158913903148,"f":40},{"t":1310721,"n":"ReflectionOnlyLoadingDiagId","d":113196,"h":163208870444,"f":40},{"t":1310721,"n":"RuntimeEnvironmentMessage","d":113196,"h":167503837740,"f":40},{"t":1310721,"n":"RuntimeEnvironmentDiagId","d":113196,"h":171798805036,"f":40},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesMessage","d":113196,"h":176093772332,"f":40},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesDiagId","d":113196,"h":180388739628,"f":40},{"t":1310721,"n":"DerivedCryptographicTypesMessage","d":113196,"h":184683706924,"f":40},{"t":1310721,"n":"DerivedCryptographicTypesDiagId","d":113196,"h":188978674220,"f":40},{"t":1310721,"n":"RijndaelMessage","d":113196,"h":193273641516,"f":40},{"t":1310721,"n":"RijndaelDiagId","d":113196,"h":197568608812,"f":40},{"t":1310721,"n":"RNGCryptoServiceProviderMessage","d":113196,"h":201863576108,"f":40},{"t":1310721,"n":"RNGCryptoServiceProviderDiagId","d":113196,"h":206158543404,"f":40},{"t":1310721,"n":"AppDomainCreateUnloadMessage","d":113196,"h":210453510700,"f":40},{"t":1310721,"n":"AppDomainCreateUnloadDiagId","d":113196,"h":214748477996,"f":40},{"t":1310721,"n":"SuppressIldasmAttributeMessage","d":113196,"h":219043445292,"f":40},{"t":1310721,"n":"SuppressIldasmAttributeDiagId","d":113196,"h":223338412588,"f":40},{"t":1310721,"n":"X509CertificateImmutableMessage","d":113196,"h":227633379884,"f":40},{"t":1310721,"n":"X509CertificateImmutableDiagId","d":113196,"h":231928347180,"f":40},{"t":1310721,"n":"PublicKeyPropertyMessage","d":113196,"h":236223314476,"f":40},{"t":1310721,"n":"PublicKeyPropertyDiagId","d":113196,"h":240518281772,"f":40},{"t":1310721,"n":"X509CertificatePrivateKeyMessage","d":113196,"h":244813249068,"f":40},{"t":1310721,"n":"X509CertificatePrivateKeyDiagId","d":113196,"h":249108216364,"f":40},{"t":1310721,"n":"ProduceLegacyHmacValuesMessage","d":113196,"h":253403183660,"f":40},{"t":1310721,"n":"ProduceLegacyHmacValuesDiagId","d":113196,"h":257698150956,"f":40},{"t":1310721,"n":"UseManagedSha1Message","d":113196,"h":261993118252,"f":40},{"t":1310721,"n":"UseManagedSha1DiagId","d":113196,"h":266288085548,"f":40},{"t":1310721,"n":"CryptoConfigEncodeOIDMessage","d":113196,"h":270583052844,"f":40},{"t":1310721,"n":"CryptoConfigEncodeOIDDiagId","d":113196,"h":274878020140,"f":40},{"t":1310721,"n":"CorruptedStateRecoveryMessage","d":113196,"h":279172987436,"f":40},{"t":1310721,"n":"CorruptedStateRecoveryDiagId","d":113196,"h":283467954732,"f":40},{"t":1310721,"n":"Rfc2898CryptDeriveKeyMessage","d":113196,"h":287762922028,"f":40},{"t":1310721,"n":"Rfc2898CryptDeriveKeyDiagId","d":113196,"h":292057889324,"f":40},{"t":1310721,"n":"CmsSignerCspParamsCtorMessage","d":113196,"h":296352856620,"f":40},{"t":1310721,"n":"CmsSignerCspParamsCtorDiagId","d":113196,"h":300647823916,"f":40},{"t":1310721,"n":"SignerInfoCounterSigMessage","d":113196,"h":304942791212,"f":40},{"t":1310721,"n":"SignerInfoCounterSigDiagId","d":113196,"h":309237758508,"f":40},{"t":1310721,"n":"RegexCompileToAssemblyMessage","d":113196,"h":313532725804,"f":40},{"t":1310721,"n":"RegexCompileToAssemblyDiagId","d":113196,"h":317827693100,"f":40},{"t":1310721,"n":"AssemblyNameMembersMessage","d":113196,"h":322122660396,"f":40},{"t":1310721,"n":"AssemblyNameMembersDiagId","d":113196,"h":326417627692,"f":40},{"t":1310721,"n":"SystemDataSerializationFormatBinaryMessage","d":113196,"h":330712594988,"f":40},{"t":1310721,"n":"SystemDataSerializationFormatBinaryDiagId","d":113196,"h":335007562284,"f":40},{"t":1310721,"n":"TlsVersion10and11Message","d":113196,"h":339302529580,"f":40},{"t":1310721,"n":"TlsVersion10and11DiagId","d":113196,"h":343597496876,"f":40},{"t":1310721,"n":"EncryptionPolicyMessage","d":113196,"h":347892464172,"f":40},{"t":1310721,"n":"EncryptionPolicyDiagId","d":113196,"h":352187431468,"f":40},{"t":1310721,"n":"EccXmlExportImportMessage","d":113196,"h":356482398764,"f":40},{"t":1310721,"n":"EccXmlExportImportDiagId","d":113196,"h":360777366060,"f":40},{"t":1310721,"n":"EcDhPublicKeyBlobMessage","d":113196,"h":365072333356,"f":40},{"t":1310721,"n":"EcDhPublicKeyBlobDiagId","d":113196,"h":369367300652,"f":40},{"t":1310721,"n":"AssemblyNameCodeBaseMessage","d":113196,"h":373662267948,"f":40},{"t":1310721,"n":"AssemblyNameCodeBaseDiagId","d":113196,"h":377957235244,"f":40},{"t":1310721,"n":"CryptoStringFactoryMessage","d":113196,"h":382252202540,"f":40},{"t":1310721,"n":"CryptoStringFactoryDiagId","d":113196,"h":386547169836,"f":40},{"t":1310721,"n":"ControlledExecutionRunMessage","d":113196,"h":390842137132,"f":40},{"t":1310721,"n":"ControlledExecutionRunDiagId","d":113196,"h":395137104428,"f":40},{"t":1310721,"n":"XmlSecureResolverMessage","d":113196,"h":399432071724,"f":40},{"t":1310721,"n":"XmlSecureResolverDiagId","d":113196,"h":403727039020,"f":40},{"t":1310721,"n":"RsaEncryptDecryptValueMessage","d":113196,"h":408022006316,"f":40},{"t":1310721,"n":"RsaEncryptDecryptDiagId","d":113196,"h":412316973612,"f":40},{"t":1310721,"n":"JsonSerializerOptionsAddContextMessage","d":113196,"h":416611940908,"f":40},{"t":1310721,"n":"JsonSerializerOptionsAddContextDiagId","d":113196,"h":420906908204,"f":40},{"t":1310721,"n":"LegacyFormatterMessage","d":113196,"h":425201875500,"f":40},{"t":1310721,"n":"LegacyFormatterDiagId","d":113196,"h":429496842796,"f":40},{"t":1310721,"n":"LegacyFormatterImplMessage","d":113196,"h":433791810092,"f":40},{"t":1310721,"n":"LegacyFormatterImplDiagId","d":113196,"h":438086777388,"f":40},{"t":1310721,"n":"RegexExtensibilityImplMessage","d":113196,"h":442381744684,"f":40},{"t":1310721,"n":"RegexExtensibilityDiagId","d":113196,"h":446676711980,"f":40},{"t":1310721,"n":"AesGcmTagConstructorMessage","d":113196,"h":450971679276,"f":40},{"t":1310721,"n":"AesGcmTagConstructorDiagId","d":113196,"h":455266646572,"f":40},{"t":1310721,"n":"ThreadVolatileReadWriteMessage","d":113196,"h":459561613868,"f":40},{"t":1310721,"n":"ThreadVolatileReadWriteDiagId","d":113196,"h":463856581164,"f":40},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationMessage","d":113196,"h":468151548460,"f":40},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationDiagId","d":113196,"h":472446515756,"f":40},{"t":1310721,"n":"LoadFromHashAlgorithmMessage","d":113196,"h":476741483052,"f":40},{"t":1310721,"n":"LoadFromHashAlgorithmDiagId","d":113196,"h":481036450348,"f":40},{"t":1310721,"n":"X509CtorCertDataObsoleteMessage","d":113196,"h":485331417644,"f":40},{"t":1310721,"n":"X509CtorCertDataObsoleteDiagId","d":113196,"h":489626384940,"f":40},{"t":1310721,"n":"TlsCipherAlgorithmEnumsMessage","d":113196,"h":493921352236,"f":40},{"t":1310721,"n":"TlsCipherAlgorithmEnumsDiagId","d":113196,"h":498216319532,"f":40},{"t":1310721,"n":"SystemEventsEventsThreadShutdownMessage","d":113196,"h":502511286828,"f":40},{"t":1310721,"n":"SystemEventsEventsThreadShutdownDiagId","d":113196,"h":506806254124,"f":40},{"t":1310721,"n":"Rfc2898DeriveBytesCtorMessage","d":113196,"h":511101221420,"f":40},{"t":1310721,"n":"Rfc2898DeriveBytesCtorDiagId","d":113196,"h":515396188716,"f":40},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteMessage","d":113196,"h":519691156012,"f":40},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteDiagId","d":113196,"h":523986123308,"f":40},{"t":1310721,"n":"XsltSettingsEnableScriptMessage","d":113196,"h":528281090604,"f":40},{"t":1310721,"n":"XsltSettingsEnableScriptDiagId","d":113196,"h":532576057900,"f":40}],"h":113196}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Obsoletions`; }
        });
        
        $asm.$cls("$stl.System.Transactions.Oletx.OletxTransactionManager", ($self) => class OletxTransactionManager extends $.$spc.System.Object
        {
            /*object?*/ NodeName = null;
            $ctor$1(/*string*/ nodeName)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*IPromotedEnlistment */ ReenlistTransaction(/*Guid*/ resourceManagerIdentifier, /*byte[]*/ resourceManagerRecoveryInformation, /*RecoveringInternalEnlistment*/ internalEnlistment)
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransactionManager.NotSupported();
            }
            /*OletxCommittableTransaction */ CreateTransaction(/*TransactionOptions*/ options)
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransactionManager.NotSupported();
            }
            /*void */ ResourceManagerRecoveryComplete(/*Guid*/ resourceManagerIdentifier)
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransactionManager.NotSupported();
            }
            static /*byte[] */ GetWhereabouts()
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransactionManager.NotSupported();
            }
            static /*Transaction */ GetTransactionFromDtcTransaction(/*IDtcTransaction*/ transactionNative)
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransactionManager.NotSupported();
            }
            static /*OletxTransaction */ GetTransactionFromExportCookie(/*byte[]*/ cookie, /*Guid*/ txId)
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransactionManager.NotSupported();
            }
            static /*OletxTransaction */ GetOletxTransactionFromTransmitterPropagationToken(/*byte[]*/ propagationToken)
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransactionManager.NotSupported();
            }
            static /*Exception */ NotSupported()
            {
                return new $.$spc.System.PlatformNotSupportedException().$ctor$14($.$stl.System.SR.DistributedNotSupported);
            }
            static $h = 3652140;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":131073,"g":{"r":0,"d":0,"h":12888554028,"f":8},"s":{"r":0,"d":0,"h":17183521324,"f":8},"n":"NodeName","d":3652140,"h":8593586732,"f":8}],"m":[{"r":2931244,"p":[{"n":"resourceManagerIdentifier","p":56164353},{"n":"resourceManagerRecoveryInformation","p":0},{"n":"internalEnlistment","p":4045356}],"n":"ReenlistTransaction","d":3652140,"h":25773455916,"f":8},{"r":3389996,"p":[{"n":"options","p":5028396}],"n":"CreateTransaction","d":3652140,"h":30068423212,"f":8},{"r":65537,"p":[{"n":"resourceManagerIdentifier","p":56164353}],"n":"ResourceManagerRecoveryComplete","d":3652140,"h":34363390508,"f":8},{"r":0,"n":"GetWhereabouts","d":3652140,"h":38658357804,"f":40},{"r":4307500,"p":[{"n":"transactionNative","p":2538028}],"n":"GetTransactionFromDtcTransaction","d":3652140,"h":42953325100,"f":40},{"r":3521068,"p":[{"n":"cookie","p":0},{"n":"txId","p":56164353}],"n":"GetTransactionFromExportCookie","d":3652140,"h":47248292396,"f":40},{"r":3521068,"p":[{"n":"propagationToken","p":0}],"n":"GetOletxTransactionFromTransmitterPropagationToken","d":3652140,"h":51543259692,"f":40},{"r":47185921,"n":"NotSupported","d":3652140,"h":55838226988,"f":40}],"c":[{"p":[{"n":"nodeName","p":1310721}],"n":".ctor","o":"$ctor$1","d":3652140,"h":21478488620,"f":8}],"h":3652140}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Transactions.Oletx.OletxTransactionManager`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionInterop", ($self) => class TransactionInterop
        {
            static /*OletxTransaction */ ConvertToOletxTransaction(/*Transaction*/ transaction)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(transaction, "transaction");
                $.$spc.System.ObjectDisposedException.ThrowIf(transaction.Disposed, transaction);
                if (transaction._complete)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateTransactionCompletedException(transaction.DistributedTxId);
                }
                /*OletxTransaction?*/ let distributedTx = transaction.Promote();
                if (distributedTx === null)
                {
                    throw $.$stl.System.Transactions.Oletx.OletxTransaction.NotSupported();
                }
                return distributedTx;
            }
            /*Guid*/ static PromoterTypeDtc;
            static /*byte[] */ GetExportCookie(/*Transaction*/ transaction, /*byte[]*/ whereabouts)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(transaction, "transaction");
                $.$spc.System.ArgumentNullException.ThrowIfNull(whereabouts, "whereabouts");
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetExportCookie");
                }
                /*var*/ let whereaboutsCopy = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [whereabouts.length], null);
                $.$spc.System.Buffer.BlockCopy(whereabouts, 0, whereaboutsCopy, 0, whereabouts.length);
                $.$stl.System.Transactions.TransactionInterop.ConvertToOletxTransaction(transaction);
                /*byte[]*/ let cookie = $.$stl.System.Transactions.Oletx.OletxTransaction.GetExportCookie(whereaboutsCopy);
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetExportCookie");
                }
                return cookie;
            }
            static /*Transaction */ GetTransactionFromExportCookie(/*byte[]*/ cookie)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(cookie, "cookie");
                if (cookie.length < 32)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$stl.System.SR.InvalidArgument, "cookie");
                }
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetTransactionFromExportCookie");
                }
                /*var*/ let cookieCopy = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [cookie.length], null);
                $.$spc.System.Buffer.BlockCopy(cookie, 0, cookieCopy, 0, cookie.length);
                cookie = cookieCopy;
                /*var*/ let txId = new $.$spc.System.Guid().$ctor$3($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.Byte, cookie, 16, 16)));
                /*Transaction?*/ let transaction = $.$stl.System.Transactions.TransactionManager.FindPromotedTransaction(txId);
                if ($.$stl.System.Transactions.Transaction.op_Inequality(transaction, null))
                {
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodExit$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetTransactionFromExportCookie");
                    }
                    return transaction;
                }
                /*OletxTransaction*/ let dTx = $.$stl.System.Transactions.Oletx.OletxTransactionManager.GetTransactionFromExportCookie(cookieCopy, txId);
                transaction = $.$stl.System.Transactions.TransactionManager.FindOrCreatePromotedTransaction(txId, dTx);
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetTransactionFromExportCookie");
                }
                return transaction;
            }
            static /*byte[] */ GetTransmitterPropagationToken(/*Transaction*/ transaction)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(transaction, "transaction");
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetTransmitterPropagationToken");
                }
                $.$stl.System.Transactions.TransactionInterop.ConvertToOletxTransaction(transaction);
                /*byte[]*/ let token = $.$stl.System.Transactions.Oletx.OletxTransaction.GetTransmitterPropagationToken();
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetTransmitterPropagationToken");
                }
                return token;
            }
            static /*Transaction */ GetTransactionFromTransmitterPropagationToken(/*byte[]*/ propagationToken)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(propagationToken, "propagationToken");
                if (propagationToken.length < 24)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$stl.System.SR.InvalidArgument, "propagationToken");
                }
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetTransactionFromTransmitterPropagationToken");
                }
                /*var*/ let txId = new $.$spc.System.Guid().$ctor$3($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.Byte, propagationToken, 8, 16)));
                /*Transaction?*/ let tx = $.$stl.System.Transactions.TransactionManager.FindPromotedTransaction(txId);
                if ($.$stl.System.Transactions.Transaction.op_Inequality(null, tx))
                {
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodExit$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetTransactionFromTransmitterPropagationToken");
                    }
                    return tx;
                }
                /*OletxTransaction*/ let dTx = $.$stl.System.Transactions.TransactionInterop.GetOletxTransactionFromTransmitterPropagationToken(propagationToken);
                /*Transaction*/ let returnValue = $.$stl.System.Transactions.TransactionManager.FindOrCreatePromotedTransaction(txId, dTx);
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetTransactionFromTransmitterPropagationToken");
                }
                return returnValue;
            }
            static /*IDtcTransaction */ GetDtcTransaction(/*Transaction*/ transaction)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(transaction, "transaction");
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetDtcTransaction");
                }
                $.$stl.System.Transactions.TransactionInterop.ConvertToOletxTransaction(transaction);
                /*IDtcTransaction*/ let transactionNative = $.$stl.System.Transactions.Oletx.OletxTransaction.GetDtcTransaction();
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetDtcTransaction");
                }
                return transactionNative;
            }
            static /*Transaction */ GetTransactionFromDtcTransaction(/*IDtcTransaction*/ transactionNative)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(transactionNative, "transactionNative");
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetTransactionFromDtcTransaction");
                }
                /*Transaction*/ let transaction = $.$stl.System.Transactions.Oletx.OletxTransactionManager.GetTransactionFromDtcTransaction(transactionNative);
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetTransactionFromDtcTransaction");
                }
                return transaction;
            }
            static /*byte[] */ GetWhereabouts()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetWhereabouts");
                }
                /*byte[]*/ let returnValue = $.$stl.System.Transactions.Oletx.OletxTransactionManager.GetWhereabouts();
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetWhereabouts");
                }
                return returnValue;
            }
            static /*OletxTransaction */ GetOletxTransactionFromTransmitterPropagationToken(/*byte[]*/ propagationToken)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(propagationToken, "propagationToken");
                if (propagationToken.length < 24)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$stl.System.SR.InvalidArgument, "propagationToken");
                }
                /*byte[]*/ let propagationTokenCopy = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [propagationToken.length], null);
                $.$spc.System.Array.Copy(propagationToken, propagationTokenCopy, propagationToken.length);
                return $.$stl.System.Transactions.Oletx.OletxTransactionManager.GetOletxTransactionFromTransmitterPropagationToken(propagationTokenCopy);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.PromoterTypeDtc = new $.$spc.System.Guid().$ctor$8("14229753-FFE1-428D-82B7-DF73045CB8DA");
                }
            }
            static $h = 4831788;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":3521068,"p":[{"n":"transaction","p":4307500}],"n":"ConvertToOletxTransaction","d":4831788,"h":4299799084,"f":40},{"r":0,"p":[{"n":"transaction","p":4307500},{"n":"whereabouts","p":0}],"n":"GetExportCookie","d":4831788,"h":12889733676,"f":33},{"r":4307500,"p":[{"n":"cookie","p":0}],"n":"GetTransactionFromExportCookie","d":4831788,"h":17184700972,"f":33},{"r":0,"p":[{"n":"transaction","p":4307500}],"n":"GetTransmitterPropagationToken","d":4831788,"h":21479668268,"f":33},{"r":4307500,"p":[{"n":"propagationToken","p":0}],"n":"GetTransactionFromTransmitterPropagationToken","d":4831788,"h":25774635564,"f":33},{"r":2538028,"p":[{"n":"transaction","p":4307500}],"n":"GetDtcTransaction","d":4831788,"h":30069602860,"f":33},{"r":4307500,"p":[{"n":"transactionNative","p":2538028}],"n":"GetTransactionFromDtcTransaction","d":4831788,"h":34364570156,"f":33},{"r":0,"n":"GetWhereabouts","d":4831788,"h":38659537452,"f":33},{"r":3521068,"p":[{"n":"propagationToken","p":0}],"n":"GetOletxTransactionFromTransmitterPropagationToken","d":4831788,"h":42954504748,"f":40}],"l":[{"t":56164353,"n":"PromoterTypeDtc","d":4831788,"h":8594766380,"f":33}],"h":4831788}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Transactions.TransactionInterop`; }
        });
        
        $asm.$cls("$stl.System.Transactions.CallContextCurrentData", ($self) => class CallContextCurrentData
        {
            /*AsyncLocal<ContextKey?>*/ static s_currentTransaction = null;
            /*ConditionalWeakTable<ContextKey, ContextData>*/ static s_contextDataTable = null;
            static /*ContextData */ CreateOrGetCurrentData(/*ContextKey*/ contextKey)
            {
                $.$stl.System.Transactions.CallContextCurrentData.s_currentTransaction.Value = contextKey;
                return $.$stl.System.Transactions.CallContextCurrentData.s_contextDataTable.GetValue(contextKey, new $.$spc.System.Runtime.CompilerServices.ConditionalWeakTable$$$($.$stl.System.Transactions.ContextKey, $.$stl.System.Transactions.ContextData).CreateValueCallback().$ctor(this,  (/*env*/ env) =>
                {
                    return new $.$stl.System.Transactions.ContextData().$ctor$1(true);
                }));
            }
            static /*void */ ClearCurrentData(/*ContextKey?*/ contextKey, /*bool*/ removeContextData)
            {
                /*ContextKey?*/ let key = $.$stl.System.Transactions.CallContextCurrentData.s_currentTransaction.Value;
                if (contextKey !== null || key !== null)
                {
                    if (removeContextData)
                    {
                        $.$stl.System.Transactions.CallContextCurrentData.s_contextDataTable.Remove(contextKey ?? key);
                    }
                    if (key !== null)
                    {
                        $.$stl.System.Transactions.CallContextCurrentData.s_currentTransaction.Value = null;
                    }
                }
            }
            static /*bool */ TryGetCurrentData(/*out ContextData?*/ currentData)
            {
                currentData.$v = null;
                /*ContextKey?*/ let contextKey = $.$stl.System.Transactions.CallContextCurrentData.s_currentTransaction.Value;
                if (contextKey === null)
                {
                    return false;
                }
                else 
                {
                    return $.$stl.System.Transactions.CallContextCurrentData.s_contextDataTable.TryGetValue(contextKey, currentData);
                }
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_currentTransaction = new ($.$spc.System.Threading.AsyncLocal$$($.$stl.System.Transactions.ContextKey))().$ctor$1();
                }
                {
                    this.s_contextDataTable = new ($.$spc.System.Runtime.CompilerServices.ConditionalWeakTable$$$($.$stl.System.Transactions.ContextKey, $.$stl.System.Transactions.ContextData))().$ctor$1();
                }
            }
            static $h = 440876;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":899628,"p":[{"n":"contextKey","p":965164}],"n":"CreateOrGetCurrentData","d":440876,"h":12885342764,"f":33},{"r":65537,"p":[{"n":"contextKey","p":965164},{"n":"removeContextData","p":262145}],"n":"ClearCurrentData","d":440876,"h":17180310060,"f":33},{"r":262145,"p":[{"n":"currentData","p":899628,"f":2}],"n":"TryGetCurrentData","d":440876,"h":21475277356,"f":33}],"l":[{"t":$.$spc.System.Threading.AsyncLocal$$($.$stl.System.Transactions.ContextKey).$h,"n":"s_currentTransaction","d":440876,"h":4295408172,"f":34},{"t":$.$spc.System.Runtime.CompilerServices.ConditionalWeakTable$$$($.$stl.System.Transactions.ContextKey, $.$stl.System.Transactions.ContextData).$h,"n":"s_contextDataTable","d":440876,"h":8590375468,"f":34}],"h":440876}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Transactions.CallContextCurrentData`; }
        });
        
        $asm.$cls("$stl.System.Transactions.ContextKey", ($self) => class ContextKey extends $.$spc.System.Object
        {
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 965164;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"c":[{"n":".ctor","o":"$ctor$1","d":965164,"h":4295932460,"f":1}],"h":965164}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Transactions.ContextKey`; }
        });
        
        $asm.$cls("$stl.System.Transactions.ContextData", ($self) => class ContextData extends $.$spc.System.Object
        {
            /*TransactionScope?*/ CurrentScope = null;
            /*Transaction?*/ CurrentTransaction = null;
            /*DefaultComContextState*/ DefaultComContextState = 0;
            /*WeakReference?*/ WeakDefaultComContext = null;
            /*bool*/ _asyncFlow = false;
            /*ContextData?*/ static t_staticData = null;
            $ctor$1(/*bool*/ asyncFlow)
            {
                super.$ctor();
                {
                    this._asyncFlow = asyncFlow;
                }
                return this;
            }
            static /*ContextData */ get TLSCurrentData()
            {
                return $.$stl.System.Transactions.ContextData.t_staticData ??= new $.$stl.System.Transactions.ContextData().$ctor$1(false);
            }
            static /*ContextData */ set TLSCurrentData(value)
            {
                if (value === null && $.$stl.System.Transactions.ContextData.t_staticData !== null)
                {
                    $.$stl.System.Transactions.ContextData.t_staticData.CurrentScope = null;
                    $.$stl.System.Transactions.ContextData.t_staticData.CurrentTransaction = null;
                    $.$stl.System.Transactions.ContextData.t_staticData.DefaultComContextState = 0/*DefaultComContextState.Unknown*/;
                    $.$stl.System.Transactions.ContextData.t_staticData.WeakDefaultComContext = null;
                }
                else 
                {
                    $.$stl.System.Transactions.ContextData.t_staticData = value;
                }
            }
            static /*ContextData */ LookupContextData(/*TxLookup*/ defaultLookup)
            {
                /*ContextData?*/ let currentData;
                if ($.$stl.System.Transactions.CallContextCurrentData.TryGetCurrentData($.$ref(() => currentData, ($v) => currentData = $v, $.$stl.System.Transactions.ContextData)))
                {
                    if (currentData.CurrentScope === null && $.$stl.System.Transactions.Transaction.op_Equality(currentData.CurrentTransaction, null) && defaultLookup !== 1/*TxLookup.DefaultCallContext*/)
                    {
                        $.$stl.System.Transactions.CallContextCurrentData.ClearCurrentData(null, true);
                        return $.$stl.System.Transactions.ContextData.TLSCurrentData;
                    }
                    return currentData;
                }
                else 
                {
                    return $.$stl.System.Transactions.ContextData.TLSCurrentData;
                }
            }
            static $h = 899628;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":899628,"g":{"r":0,"d":0,"h":38655605292,"f":40},"s":{"r":0,"d":0,"h":42950572588,"f":40},"n":"TLSCurrentData","d":899628,"h":34360637996,"f":40}],"m":[{"r":899628,"p":[{"n":"defaultLookup","p":8632876}],"n":"LookupContextData","d":899628,"h":47245539884,"f":40}],"l":[{"t":5159468,"n":"CurrentScope","d":899628,"h":4295866924,"f":8},{"t":4307500,"n":"CurrentTransaction","d":899628,"h":8590834220,"f":8},{"t":1030700,"n":"DefaultComContextState","d":899628,"h":12885801516,"f":8},{"t":144769025,"n":"WeakDefaultComContext","d":899628,"h":17180768812,"f":8},{"t":262145,"n":"_asyncFlow","d":899628,"h":21475736108,"f":8},{"t":899628,"n":"t_staticData","d":899628,"h":25770703404,"f":34,"a":[{"t":140181505,"c":4435148801}]}],"c":[{"p":[{"n":"asyncFlow","p":262145}],"n":".ctor","o":"$ctor$1","d":899628,"h":30065670700,"f":8}],"h":899628}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Transactions.ContextData`; }
        });
        
        $asm.$cls("$stl.System.Transactions.CheapUnfairReaderWriterLock", ($self) => class CheapUnfairReaderWriterLock extends $.$spc.System.Object
        {
            /*object?*/ _writerFinishedEvent = null;
            /*int*/ _readersIn = 0;
            /*int*/ _readersOut = 0;
            /*bool*/ _writerPresent = false;
            /*object?*/ _syncRoot = null;
            /*int*/ static MAX_SPIN_COUNT = 100;
            /*int*/ static SLEEP_TIME = 500;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*object */ get SyncRoot()
            {
                if (this._syncRoot === null)
                {
                    $.$spc.System.Threading.Interlocked.CompareExchange$2($.$ref(() => this._syncRoot, ($v) => this._syncRoot = $v, $.$spc.System.Object), new $.$spc.System.Object().$ctor(), null);
                }
                return this._syncRoot;
            }
            /*bool */ get ReadersPresent()
            {
                return this._readersIn !== this._readersOut;
            }
            /*ManualResetEvent */ get WriterFinishedEvent()
            {
                if (this._writerFinishedEvent === null)
                {
                    $.$spc.System.Threading.Interlocked.CompareExchange$2($.$ref(() => this._writerFinishedEvent, ($v) => this._writerFinishedEvent = $v, $.$spc.System.Object), new $.$spc.System.Threading.ManualResetEvent().$ctor$8(true), null);
                }
                return $.$cast(this._writerFinishedEvent, $.$spc.System.Threading.ManualResetEvent);
            }
            /*int */ EnterReadLock()
            {
                /*int*/ let readerIndex;
                do
                {
                    if (this._writerPresent)
                    {
                        this.WriterFinishedEvent.WaitOne$2();
                    }
                    readerIndex = $.$spc.System.Threading.Interlocked.Increment($.$ref(() => this._readersIn, ($v) => this._readersIn = $v, $.$spc.System.Int32));
                    if (!this._writerPresent)
                    {
                        break;
                    }
                    $.$spc.System.Threading.Interlocked.Decrement($.$ref(() => this._readersIn, ($v) => this._readersIn = $v, $.$spc.System.Int32));
                }
                while(true);
                return readerIndex;
            }
            /*void */ EnterWriteLock()
            {
                $.$spc.System.Threading.Monitor.Enter(this.SyncRoot);
                this._writerPresent = true;
                this.WriterFinishedEvent.Reset();
                do
                {
                    /*int*/ let i = 0;
                    while(this.ReadersPresent && i < 100/*MAX_SPIN_COUNT*/)
                    {
                        $.$spc.System.Threading.Thread.Sleep(0);
                        i++;
                    }
                    if (this.ReadersPresent)
                    {
                        $.$spc.System.Threading.Thread.Sleep(500/*SLEEP_TIME*/);
                    }
                }
                while(this.ReadersPresent);
            }
            /*void */ ExitReadLock()
            {
                $.$spc.System.Threading.Interlocked.Increment($.$ref(() => this._readersOut, ($v) => this._readersOut = $v, $.$spc.System.Int32));
            }
            /*void */ ExitWriteLock()
            {
                try
                {
                    this._writerPresent = false;
                    this.WriterFinishedEvent.Set$1();
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Exit(this.SyncRoot);
                    }
                }
            }
            static $h = 506412;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":131073,"g":{"r":0,"d":0,"h":42950179372,"f":2},"n":"SyncRoot","d":506412,"h":38655212076,"f":2},{"p":262145,"g":{"r":0,"d":0,"h":51540113964,"f":2},"n":"ReadersPresent","d":506412,"h":47245146668,"f":2},{"p":128319489,"g":{"r":0,"d":0,"h":60130048556,"f":2},"n":"WriterFinishedEvent","d":506412,"h":55835081260,"f":2}],"m":[{"r":655361,"n":"EnterReadLock","d":506412,"h":64425015852,"f":1},{"r":65537,"n":"EnterWriteLock","d":506412,"h":68719983148,"f":1},{"r":65537,"n":"ExitReadLock","d":506412,"h":73014950444,"f":1},{"r":65537,"n":"ExitWriteLock","d":506412,"h":77309917740,"f":1}],"l":[{"t":131073,"n":"_writerFinishedEvent","d":506412,"h":4295473708,"f":2},{"t":655361,"n":"_readersIn","d":506412,"h":8590441004,"f":2},{"t":655361,"n":"_readersOut","d":506412,"h":12885408300,"f":2},{"t":262145,"n":"_writerPresent","d":506412,"h":17180375596,"f":2},{"t":131073,"n":"_syncRoot","d":506412,"h":21475342892,"f":2},{"t":655361,"n":"MAX_SPIN_COUNT","d":506412,"h":25770310188,"f":34},{"t":655361,"n":"SLEEP_TIME","d":506412,"h":30065277484,"f":34}],"c":[{"n":".ctor","o":"$ctor$1","d":506412,"h":34360244780,"f":1}],"h":506412}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Transactions.CheapUnfairReaderWriterLock`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionTable", ($self) => class TransactionTable extends $.$spc.System.Object
        {
            /*Timer*/ _timer = null;
            /*bool*/ _timerEnabled = false;
            /*int*/ static timerInternalExponent = 9;
            /*int*/ _timerInterval = 0;
            /*long*/ _ticks = 0n;
            /*long*/ _lastTimerTime = 0n;
            /*BucketSet*/ _headBucketSet = null;
            /*CheapUnfairReaderWriterLock*/ _rwLock = null;
            $ctor$1()
            {
                super.$ctor();
                {
                    this._timer = new $.$spc.System.Threading.Timer().$ctor$2(new $.$spc.System.Threading.TimerCallback().$ctor(this, this.ThreadTimer), null, -1/*Timeout.Infinite*/, this._timerInterval);
                    this._timerEnabled = false;
                    this._timerInterval = 1 << 9/*TransactionTable.timerInternalExponent*/;
                    this._ticks = 0n;
                    this._headBucketSet = new $.$stl.System.Transactions.BucketSet().$ctor$1(this, 9223372036854775807n);
                    this._rwLock = new $.$stl.System.Transactions.CheapUnfairReaderWriterLock().$ctor$1();
                }
                return this;
            }
            /*long */ TimeoutTicks(/*TimeSpan*/ timeout)
            {
                if ($.$spc.System.TimeSpan.op_Inequality(timeout, $.$spc.System.TimeSpan.Zero))
                {
                    /*long*/ let timeoutTicks = ((timeout.Ticks / 10000n) >> BigInt(9/*TransactionTable.timerInternalExponent*/)) + this._ticks;
                    return timeoutTicks + 2n;
                }
                else 
                {
                    return 9223372036854775807n;
                }
            }
            /*TimeSpan */ RecalcTimeout(/*InternalTransaction*/ tx)
            {
                return $.$spc.System.TimeSpan.FromMilliseconds((tx.AbsoluteTimeout - this._ticks) * BigInt(this._timerInterval));
            }
            /*long */ get CurrentTime()
            {
                if (this._timerEnabled)
                {
                    return this._lastTimerTime;
                }
                else 
                {
                    return $.$spc.System.DateTime.UtcNow.Ticks;
                }
            }
            /*int */ Add(/*InternalTransaction*/ txNew)
            {
                /*int*/ let readerIndex;
                readerIndex = this._rwLock.EnterReadLock();
                try
                {
                    if (txNew.AbsoluteTimeout !== 9223372036854775807n)
                    {
                        if (!this._timerEnabled)
                        {
                            if (!this._timer.Change(this._timerInterval, this._timerInterval))
                            {
                                throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.UnexpectedTimerFailure, null);
                            }
                            this._lastTimerTime = $.$spc.System.DateTime.UtcNow.Ticks;
                            this._timerEnabled = true;
                        }
                    }
                    txNew.CreationTime = this.CurrentTime;
                    this.AddIter(txNew);
                }
                finally
                {
                    {
                        this._rwLock.ExitReadLock();
                    }
                }
                return readerIndex;
            }
            /*void */ AddIter(/*InternalTransaction*/ txNew)
            {
                /*BucketSet*/ let currentBucketSet = this._headBucketSet;
                while(currentBucketSet.AbsoluteTimeout !== txNew.AbsoluteTimeout)
                {
                    /*BucketSet?*/ let lastBucketSet = null;
                    do
                    {
                        /*WeakReference?*/ let nextSetWeak = $.$cast(currentBucketSet.nextSetWeak, $.$spc.System.WeakReference);
                        /*BucketSet?*/ let nextBucketSet = null;
                        if (nextSetWeak !== null)
                        {
                            nextBucketSet = $.$cast(nextSetWeak.Target, $.$stl.System.Transactions.BucketSet);
                        }
                        if (nextBucketSet === null)
                        {
                            /*BucketSet*/ let newBucketSet = new $.$stl.System.Transactions.BucketSet().$ctor$1(this, txNew.AbsoluteTimeout);
                            /*WeakReference*/ let newSetWeak = new $.$spc.System.WeakReference().$ctor$1(newBucketSet);
                            /*WeakReference?*/ let oldNextSetWeak = $.$cast($.$spc.System.Threading.Interlocked.CompareExchange$2($.$ref(() => currentBucketSet.nextSetWeak, ($v) => currentBucketSet.nextSetWeak = $v, $.$spc.System.Object), newSetWeak, nextSetWeak), $.$spc.System.WeakReference);
                            if (oldNextSetWeak === nextSetWeak)
                            {
                                newBucketSet.prevSet = currentBucketSet;
                            }
                        }
                        else 
                        {
                            lastBucketSet = currentBucketSet;
                            currentBucketSet = nextBucketSet;
                        }
                    }
                    while(currentBucketSet.AbsoluteTimeout > txNew.AbsoluteTimeout);
                    if (currentBucketSet.AbsoluteTimeout !== txNew.AbsoluteTimeout)
                    {
                        /*BucketSet*/ let newBucketSet = new $.$stl.System.Transactions.BucketSet().$ctor$1(this, txNew.AbsoluteTimeout);
                        /*WeakReference*/ let newSetWeak = new $.$spc.System.WeakReference().$ctor$1(newBucketSet);
                        $.$spc.System.Diagnostics.Debug.Assert$1(lastBucketSet !== null, "lastBucketSet != null");
                        newBucketSet.nextSetWeak = lastBucketSet.nextSetWeak;
                        /*WeakReference?*/ let oldNextSetWeak = $.$cast($.$spc.System.Threading.Interlocked.CompareExchange$2($.$ref(() => lastBucketSet.nextSetWeak, ($v) => lastBucketSet.nextSetWeak = $v, $.$spc.System.Object), newSetWeak, newBucketSet.nextSetWeak), $.$spc.System.WeakReference);
                        if (oldNextSetWeak === newBucketSet.nextSetWeak)
                        {
                            if (oldNextSetWeak !== null)
                            {
                                /*BucketSet?*/ let oldSet = $.$cast(oldNextSetWeak.Target, $.$stl.System.Transactions.BucketSet);
                                if (oldSet !== null)
                                {
                                    oldSet.prevSet = newBucketSet;
                                }
                            }
                            newBucketSet.prevSet = lastBucketSet;
                        }
                        currentBucketSet = lastBucketSet;
                    }
                }
                currentBucketSet.Add(txNew);
            }
            static /*void */ Remove(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(tx._tableBucket !== null, "tx._tableBucket != null");
                tx._tableBucket.Remove(tx);
                tx._tableBucket = null;
            }
            /*void */ ThreadTimer(/*object?*/ state)
            {
                if (!this._timerEnabled)
                {
                    return;
                }
                this._ticks++;
                this._lastTimerTime = $.$spc.System.DateTime.UtcNow.Ticks;
                /*BucketSet?*/ let lastBucketSet;
                /*BucketSet*/ let currentBucketSet = this._headBucketSet;
                /*WeakReference?*/ let nextWeakSet;
                /*BucketSet?*/ let nextBucketSet = null;
                nextWeakSet = $.$cast(currentBucketSet.nextSetWeak, $.$spc.System.WeakReference);
                if (nextWeakSet !== null)
                {
                    nextBucketSet = $.$cast(nextWeakSet.Target, $.$stl.System.Transactions.BucketSet);
                }
                if (nextBucketSet === null)
                {
                    this._rwLock.EnterWriteLock();
                    try
                    {
                        nextWeakSet = $.$cast(currentBucketSet.nextSetWeak, $.$spc.System.WeakReference);
                        if (nextWeakSet !== null)
                        {
                            nextBucketSet = $.$cast(nextWeakSet.Target, $.$stl.System.Transactions.BucketSet);
                        }
                        if (nextBucketSet === null)
                        {
                            if (!this._timer.Change(-1/*Timeout.Infinite*/, -1/*Timeout.Infinite*/))
                            {
                                throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.UnexpectedTimerFailure, null);
                            }
                            this._timerEnabled = false;
                            return;
                        }
                    }
                    finally
                    {
                        {
                            this._rwLock.ExitWriteLock();
                        }
                    }
                }
                do
                {
                    do
                    {
                        nextWeakSet = $.$cast(currentBucketSet.nextSetWeak, $.$spc.System.WeakReference);
                        if (nextWeakSet === null)
                        {
                            return;
                        }
                        nextBucketSet = $.$cast(nextWeakSet.Target, $.$stl.System.Transactions.BucketSet);
                        if (nextBucketSet === null)
                        {
                            return;
                        }
                        lastBucketSet = currentBucketSet;
                        currentBucketSet = nextBucketSet;
                    }
                    while(currentBucketSet.AbsoluteTimeout > this._ticks);
                    /*WeakReference?*/ let abortingSetsWeak = $.$cast($.$spc.System.Threading.Interlocked.CompareExchange$2($.$ref(() => lastBucketSet.nextSetWeak, ($v) => lastBucketSet.nextSetWeak = $v, $.$spc.System.Object), null, nextWeakSet), $.$spc.System.WeakReference);
                    if (abortingSetsWeak === nextWeakSet)
                    {
                        /*BucketSet?*/ let abortingBucketSets;
                        do
                        {
                            if (abortingSetsWeak !== null)
                            {
                                abortingBucketSets = $.$cast(abortingSetsWeak.Target, $.$stl.System.Transactions.BucketSet);
                            }
                            else 
                            {
                                abortingBucketSets = null;
                            }
                            if (abortingBucketSets !== null)
                            {
                                abortingBucketSets.TimeoutTransactions();
                                abortingSetsWeak = $.$cast(abortingBucketSets.nextSetWeak, $.$spc.System.WeakReference);
                            }
                        }
                        while(abortingBucketSets !== null);
                        break;
                    }
                    currentBucketSet = lastBucketSet;
                }
                while(true);
            }
            static $h = 8501804;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":917505,"g":{"r":0,"d":0,"h":55843076652,"f":2},"n":"CurrentTime","d":8501804,"h":51548109356,"f":2}],"m":[{"r":917505,"p":[{"n":"timeout","p":140705793}],"n":"TimeoutTicks","d":8501804,"h":42958174764,"f":8},{"r":140705793,"p":[{"n":"tx","p":2800172}],"n":"RecalcTimeout","d":8501804,"h":47253142060,"f":8},{"r":655361,"p":[{"n":"txNew","p":2800172}],"n":"Add","d":8501804,"h":60138043948,"f":8},{"r":65537,"p":[{"n":"txNew","p":2800172}],"n":"AddIter","d":8501804,"h":64433011244,"f":2},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"Remove","d":8501804,"h":68727978540,"f":40},{"r":65537,"p":[{"n":"state","p":131073}],"n":"ThreadTimer","d":8501804,"h":73022945836,"f":2}],"l":[{"t":138543105,"n":"_timer","d":8501804,"h":4303469100,"f":2},{"t":262145,"n":"_timerEnabled","d":8501804,"h":8598436396,"f":2},{"t":655361,"n":"timerInternalExponent","d":8501804,"h":12893403692,"f":34},{"t":655361,"n":"_timerInterval","d":8501804,"h":17188370988,"f":2},{"t":917505,"n":"_ticks","d":8501804,"h":21483338284,"f":2},{"t":917505,"n":"_lastTimerTime","d":8501804,"h":25778305580,"f":2},{"t":375340,"n":"_headBucketSet","d":8501804,"h":30073272876,"f":2},{"t":506412,"n":"_rwLock","d":8501804,"h":34368240172,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":8501804,"h":38663207468,"f":8}],"h":8501804}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Transactions.TransactionTable`; }
        });
        
        $asm.$cls("$stl.System.Transactions.BucketSet", ($self) => class BucketSet extends $.$spc.System.Object
        {
            /*object?*/ nextSetWeak = null;
            /*BucketSet?*/ prevSet = null;
            /*TransactionTable*/ _table = null;
            /*long*/ _absoluteTimeout = 0n;
            /*Bucket*/ headBucket = null;
            $ctor$1(/*TransactionTable*/ table, /*long*/ absoluteTimeout)
            {
                super.$ctor();
                {
                    this.headBucket = new $.$stl.System.Transactions.Bucket().$ctor$1(this);
                    this._table = table;
                    this._absoluteTimeout = absoluteTimeout;
                }
                return this;
            }
            /*long */ get AbsoluteTimeout()
            {
                return this._absoluteTimeout;
            }
            /*void */ Add(/*InternalTransaction*/ newTx)
            {
                while(!this.headBucket.Add(newTx))
                {
                }
            }
            /*void */ TimeoutTransactions()
            {
                /*Bucket?*/ let currentBucket = this.headBucket;
                do
                {
                    currentBucket.TimeoutTransactions();
                    /*WeakReference?*/ let nextWeakBucket = currentBucket.nextBucketWeak;
                    if (nextWeakBucket !== null)
                    {
                        currentBucket = $.$cast(nextWeakBucket.Target, $.$stl.System.Transactions.Bucket);
                    }
                    else 
                    {
                        currentBucket = null;
                    }
                }
                while(currentBucket !== null);
            }
            static $h = 375340;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":917505,"g":{"r":0,"d":0,"h":34360113708,"f":8},"n":"AbsoluteTimeout","d":375340,"h":30065146412,"f":8}],"m":[{"r":65537,"p":[{"n":"newTx","p":2800172}],"n":"Add","d":375340,"h":38655081004,"f":8},{"r":65537,"n":"TimeoutTransactions","d":375340,"h":42950048300,"f":8}],"l":[{"t":131073,"n":"nextSetWeak","d":375340,"h":4295342636,"f":8},{"t":375340,"n":"prevSet","d":375340,"h":8590309932,"f":8},{"t":8501804,"n":"_table","d":375340,"h":12885277228,"f":2},{"t":917505,"n":"_absoluteTimeout","d":375340,"h":17180244524,"f":2},{"t":309804,"n":"headBucket","d":375340,"h":21475211820,"f":8}],"c":[{"p":[{"n":"table","p":8501804},{"n":"absoluteTimeout","p":917505}],"n":".ctor","o":"$ctor$1","d":375340,"h":25770179116,"f":8}],"h":375340}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Transactions.BucketSet`; }
        });
        
        $asm.$cls("$stl.System.Transactions.Bucket", ($self) => class Bucket extends $.$spc.System.Object
        {
            /*bool*/ _timedOut = false;
            /*int*/ _index = 0;
            /*int*/ _size = 0;
            /*InternalTransaction?[]*/ _transactions = null;
            /*WeakReference?*/ nextBucketWeak = null;
            /*Bucket?*/ _previous = null;
            /*BucketSet*/ _owningSet = null;
            $ctor$1(/*BucketSet*/ owningSet)
            {
                super.$ctor();
                {
                    this._timedOut = false;
                    this._index = -1;
                    this._size = 1024;
                    this._transactions = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$stl.System.Transactions.InternalTransaction), null, [this._size], null);
                    this._owningSet = owningSet;
                }
                return this;
            }
            /*bool */ Add(/*InternalTransaction*/ tx)
            {
                /*int*/ let currentIndex = $.$spc.System.Threading.Interlocked.Increment($.$ref(() => this._index, ($v) => this._index = $v, $.$spc.System.Int32));
                if (currentIndex < this._size)
                {
                    tx._tableBucket = this;
                    tx._bucketIndex = currentIndex;
                    $.$spc.System.Threading.Interlocked.MemoryBarrier();
                    $.$spc.System.Array.$WriteT1.call(this._transactions, tx, currentIndex);
                    if (this._timedOut)
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(tx)
                            {
                                tx.State.Timeout(tx);
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(tx)
                        }
                    }
                }
                else 
                {
                    /*Bucket*/ let newBucket = new $.$stl.System.Transactions.Bucket().$ctor$1(this._owningSet);
                    newBucket.nextBucketWeak = new $.$spc.System.WeakReference().$ctor$1(this);
                    /*Bucket*/ let oldBucket = $.$spc.System.Threading.Interlocked.CompareExchange$14($.$stl.System.Transactions.Bucket, $.$ref(() => this._owningSet.headBucket, ($v) => this._owningSet.headBucket = $v, $.$stl.System.Transactions.Bucket), newBucket, this);
                    if (oldBucket === this)
                    {
                        this._previous = newBucket;
                    }
                    return false;
                }
                return true;
            }
            /*void */ Remove(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Array.$WriteT1.call(this._transactions, null, tx._bucketIndex);
            }
            /*void */ TimeoutTransactions()
            {
                /*int*/ let i;
                /*int*/ let transactionCount = this._index;
                this._timedOut = true;
                $.$spc.System.Threading.Interlocked.MemoryBarrier();
                for(i = 0; i <= transactionCount && i < this._size; i++)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(transactionCount === this._index, "Index changed timing out transactions");
                    /*InternalTransaction?*/ let tx = $.$spc.System.Array.$ReadT1.call(this._transactions, i);
                    if (tx !== null)
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(tx)
                            {
                                tx.State.Timeout(tx);
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(tx)
                        }
                    }
                }
            }
            static $h = 309804;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"tx","p":2800172}],"n":"Add","d":309804,"h":38655015468,"f":8},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"Remove","d":309804,"h":42949982764,"f":8},{"r":65537,"n":"TimeoutTransactions","d":309804,"h":47244950060,"f":8}],"l":[{"t":262145,"n":"_timedOut","d":309804,"h":4295277100,"f":2},{"t":655361,"n":"_index","d":309804,"h":8590244396,"f":2},{"t":655361,"n":"_size","d":309804,"h":12885211692,"f":2},{"t":0,"n":"_transactions","d":309804,"h":17180178988,"f":2},{"t":144769025,"n":"nextBucketWeak","d":309804,"h":21475146284,"f":8},{"t":309804,"n":"_previous","d":309804,"h":25770113580,"f":2},{"t":375340,"n":"_owningSet","d":309804,"h":30065080876,"f":2}],"c":[{"p":[{"n":"owningSet","p":375340}],"n":".ctor","o":"$ctor$1","d":309804,"h":34360048172,"f":8}],"h":309804}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Transactions.Bucket`; }
        });
        
        $asm.$cls("$stl.System.Transactions.InternalTransaction", ($self) => class InternalTransaction extends $.$spc.System.Object
        {
            /*TransactionState?*/ _transactionState = null;
            /*TransactionState? */ get State()
            {
                return this._transactionState;
            }
            /*TransactionState? */ set State(value)
            {
                this._transactionState = value;
            }
            /*TransactionState*/ _promoteState = null;
            /*Guid*/ _promoterType;
            /*byte[]?*/ promotedToken = null;
            /*Guid*/ _distributedTransactionIdentifierNonMSDTC;
            /*int*/ static MaxStateHist = 20;
            /*TransactionState[]*/ _stateHistory = null;
            /*int*/ _currentStateHist = 0;
            /*FinalizedObject?*/ _finalizedObject = null;
            /*int*/ _transactionHash = 0;
            /*int */ get TransactionHash()
            {
                return this._transactionHash;
            }
            /*int*/ static _nextHash = 0;
            /*long*/ _absoluteTimeout = 0n;
            /*long */ get AbsoluteTimeout()
            {
                return this._absoluteTimeout;
            }
            /*long*/ _creationTime = 0n;
            /*long */ get CreationTime()
            {
                return this._creationTime;
            }
            /*long */ set CreationTime(value)
            {
                this._creationTime = value;
            }
            /*InternalEnlistment?*/ _durableEnlistment = null;
            /*VolatileEnlistmentSet*/ _phase0Volatiles;
            /*VolatileEnlistmentSet*/ _phase1Volatiles;
            /*int*/ _phase0VolatileWaveCount = 0;
            /*OletxDependentTransaction?*/ _phase0WaveDependentClone = null;
            /*int*/ _phase0WaveDependentCloneCount = 0;
            /*OletxDependentTransaction?*/ _abortingDependentClone = null;
            /*int*/ _abortingDependentCloneCount = 0;
            /*int*/ static VolatileArrayIncrement = 8;
            /*Bucket?*/ _tableBucket = null;
            /*int*/ _bucketIndex = 0;
            /*TransactionCompletedEventHandler?*/ _transactionCompletedDelegate = null;
            /*OletxTransaction?*/ _promotedTransaction = null;
            /*OletxTransaction? */ get PromotedTransaction()
            {
                return this._promotedTransaction;
            }
            /*OletxTransaction? */ set PromotedTransaction(value)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._promotedTransaction === null, "A transaction can only be promoted once!");
                this._promotedTransaction = value;
            }
            /*Exception?*/ _innerException = null;
            /*int*/ _cloneCount = 0;
            /*int*/ _enlistmentCount = 0;
            /*ManualResetEvent?*/ _asyncResultEvent = null;
            /*bool*/ _asyncCommit = false;
            /*AsyncCallback?*/ _asyncCallback = null;
            /*object?*/ _asyncState = null;
            /*bool*/ _needPulse = false;
            /*TransactionInformation?*/ _transactionInformation = null;
            /*CommittableTransaction?*/ _committableTransaction = null;
            /*Transaction*/ _outcomeSource = null;
            /*object?*/ static s_classSyncObject = null;
            /*Guid */ get DistributedTxId()
            {
                return this.State.get_Identifier(this);
            }
            /*string?*/ static s_instanceIdentifier = null;
            static /*string */ get InstanceIdentifier()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$spc.System.String, $.$ref(() => $.$stl.System.Transactions.InternalTransaction.s_instanceIdentifier, ($v) => $.$stl.System.Transactions.InternalTransaction.s_instanceIdentifier = $v, $.$spc.System.String), $.$ref(() => $.$stl.System.Transactions.InternalTransaction.s_classSyncObject, ($v) => $.$stl.System.Transactions.InternalTransaction.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$spc.System.String))().$ctor(this,  () =>
                {
                    return `${$.$spc.System.Guid.ToString.call($.$spc.System.Guid.NewGuid())}:`;
                }));
            }
            /*bool*/ _traceIdentifierInited = false;
            /*TransactionTraceIdentifier*/ _traceIdentifier;
            /*TransactionTraceIdentifier */ get TransactionTraceId()
            {
                if (!this._traceIdentifierInited)
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter(this)
                        {
                            if (!this._traceIdentifierInited)
                            {
                                /*TransactionTraceIdentifier*/ let temp = new $.$stl.System.Transactions.TransactionTraceIdentifier().$ctor$2($.$spc.System.String.Create$9($.$spc.System.Globalization.CultureInfo.InvariantCulture, `${$.$stl.System.Transactions.InternalTransaction.InstanceIdentifier}${this._transactionHash}`), 0);
                                this._traceIdentifier = temp;
                                this._traceIdentifierInited = true;
                            }
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit(this)
                    }
                }
                return this._traceIdentifier;
            }
            /*ITransactionPromoter?*/ _promoter = null;
            /*bool*/ _attemptingPSPEPromote = false;
            /*void */ SetPromoterTypeToMSDTC()
            {
                if (($.$spc.System.Guid.op_Inequality(this._promoterType, $.$spc.System.Guid.Empty)) && ($.$spc.System.Guid.op_Inequality(this._promoterType, $.$stl.System.Transactions.TransactionInterop.PromoterTypeDtc)))
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$stl.System.SR.PromoterTypeInvalid);
                }
                this._promoterType = $.$stl.System.Transactions.TransactionInterop.PromoterTypeDtc;
            }
            /*void */ ThrowIfPromoterTypeIsNotMSDTC()
            {
                if (($.$spc.System.Guid.op_Inequality(this._promoterType, $.$spc.System.Guid.Empty)) && ($.$spc.System.Guid.op_Inequality(this._promoterType, $.$stl.System.Transactions.TransactionInterop.PromoterTypeDtc)))
                {
                    throw new $.$stl.System.Transactions.TransactionPromotionException().$ctor$15($.$stl.System.SR.Format($.$stl.System.SR.PromoterTypeUnrecognized, $.$spc.System.Guid.ToString.call(this._promoterType)), this._innerException);
                }
            }
            $ctor$1(/*TimeSpan*/ timeout, /*CommittableTransaction*/ committableTransaction)
            {
                super.$ctor();
                {
                    this._absoluteTimeout = $.$stl.System.Transactions.TransactionManager.TransactionTable.TimeoutTicks(timeout);
                    $.$stl.System.Transactions.TransactionState.TransactionStateActive.EnterState(this);
                    this._promoteState = $.$stl.System.Transactions.TransactionState.TransactionStatePromoted;
                    this._committableTransaction = committableTransaction;
                    this._outcomeSource = committableTransaction;
                    this._transactionHash = $.$stl.System.Transactions.TransactionManager.TransactionTable.Add(this);
                }
                return this;
            }
            $ctor$2(/*Transaction*/ outcomeSource, /*OletxTransaction*/ distributedTx)
            {
                super.$ctor();
                {
                    this._promotedTransaction = distributedTx;
                    this._absoluteTimeout = 9223372036854775807n;
                    this._outcomeSource = outcomeSource;
                    this._transactionHash = $.$stl.System.Transactions.TransactionManager.TransactionTable.Add(this);
                    $.$stl.System.Transactions.TransactionState.TransactionStateNonCommittablePromoted.EnterState(this);
                    this._promoteState = $.$stl.System.Transactions.TransactionState.TransactionStateNonCommittablePromoted;
                }
                return this;
            }
            $ctor$3(/*Transaction*/ outcomeSource, /*ITransactionPromoter*/ promoter)
            {
                super.$ctor();
                {
                    this._absoluteTimeout = 9223372036854775807n;
                    this._outcomeSource = outcomeSource;
                    this._transactionHash = $.$stl.System.Transactions.TransactionManager.TransactionTable.Add(this);
                    this._promoter = promoter;
                    $.$stl.System.Transactions.TransactionState.TransactionStateSubordinateActive.EnterState(this);
                    this._promoteState = $.$stl.System.Transactions.TransactionState.TransactionStateDelegatedSubordinate;
                }
                return this;
            }
            static /*void */ DistributedTransactionOutcome(/*InternalTransaction*/ tx, /*TransactionStatus*/ status)
            {
                /*FinalizedObject?*/ let fo = null;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(tx)
                    {
                        if (null === tx._innerException)
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(tx.PromotedTransaction !== null, "tx.PromotedTransaction != null");
                            tx._innerException = tx.PromotedTransaction.InnerException;
                        }
                        $.$spc.System.Diagnostics.Debug.Assert$1(tx.State !== null, "tx.State!= null");
                        switch(status)
                        {
                            case 1/*TransactionStatus.Committed*/:
                            {
                                tx.State.ChangeStatePromotedCommitted(tx);
                                break;
                            }
                            case 2/*TransactionStatus.Aborted*/:
                            {
                                tx.State.ChangeStatePromotedAborted(tx);
                                break;
                            }
                            case 3/*TransactionStatus.InDoubt*/:
                            {
                                tx.State.InDoubtFromDtc(tx);
                                break;
                            }
                            default:
                            {
                                $.$spc.System.Diagnostics.Debug.Fail("InternalTransaction.DistributedTransactionOutcome - Unexpected TransactionStatus");
                                $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException$1(1/*TraceSourceType.TraceSourceLtm*/, "", null, tx.DistributedTxId);
                                break;
                            }
                        }
                        fo = tx._finalizedObject;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(tx)
                }
                fo?.Dispose$1();
            }
            /*void */ SignalAsyncCompletion()
            {
                this._asyncResultEvent?.Set$1();
                if (this._asyncCallback !== null)
                {
                    $.$spc.System.Threading.Monitor.Exit(this);
                    try
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._committableTransaction !== null, "_committableTransaction != null");
                        this._asyncCallback.Invoke(this._committableTransaction);
                    }
                    finally
                    {
                        {
                            $.$spc.System.Threading.Monitor.Enter(this);
                        }
                    }
                }
            }
            /*void */ FireCompletion()
            {
                /*TransactionCompletedEventHandler?*/ let eventHandlers = this._transactionCompletedDelegate;
                if (eventHandlers !== null)
                {
                    /*TransactionEventArgs*/ let args = new $.$stl.System.Transactions.TransactionEventArgs().$ctor$2();
                    args._transaction = this._outcomeSource.InternalClone();
                    eventHandlers.Invoke(args._transaction, args);
                }
            }
            /*void */ Dispose()
            {
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this._promoterType = $.$spc.System.Guid.Empty;
                this._distributedTransactionIdentifierNonMSDTC = $.$spc.System.Guid.Empty;
                this._stateHistory = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$stl.System.Transactions.TransactionState), null, [20/*MaxStateHist*/], null);
                this._phase0Volatiles = $.$default($.$stl.System.Transactions.VolatileEnlistmentSet);
                this._phase1Volatiles = $.$default($.$stl.System.Transactions.VolatileEnlistmentSet);
                this._traceIdentifier = $.$default($.$stl.System.Transactions.TransactionTraceIdentifier);
            }
            static $h = 2800172;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":5749292,"g":{"r":0,"d":0,"h":12887702060,"f":8},"s":{"r":0,"d":0,"h":17182669356,"f":8},"n":"State","d":2800172,"h":8592734764,"f":8},{"p":655361,"g":{"r":0,"d":0,"h":64427309612,"f":8},"n":"TransactionHash","d":2800172,"h":60132342316,"f":8},{"p":917505,"g":{"r":0,"d":0,"h":81607178796,"f":8},"n":"AbsoluteTimeout","d":2800172,"h":77312211500,"f":8},{"p":917505,"g":{"r":0,"d":0,"h":94492080684,"f":8},"s":{"r":0,"d":0,"h":98787047980,"f":8},"n":"CreationTime","d":2800172,"h":90197113388,"f":8},{"p":3521068,"g":{"r":0,"d":0,"h":163211557420,"f":8},"s":{"r":0,"d":0,"h":167506524716,"f":8},"n":"PromotedTransaction","d":2800172,"h":158916590124,"f":8},{"p":56164353,"g":{"r":0,"d":0,"h":227636066860,"f":8},"n":"DistributedTxId","d":2800172,"h":223341099564,"f":8},{"p":1310721,"g":{"r":0,"d":0,"h":240520968748,"f":40},"n":"InstanceIdentifier","d":2800172,"h":236226001452,"f":40},{"p":8567340,"g":{"r":0,"d":0,"h":257700837932,"f":8},"n":"TransactionTraceId","d":2800172,"h":253405870636,"f":8}],"m":[{"r":65537,"n":"SetPromoterTypeToMSDTC","d":2800172,"h":270585739820,"f":8},{"r":65537,"n":"ThrowIfPromoterTypeIsNotMSDTC","d":2800172,"h":274880707116,"f":8},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"status","p":8436268}],"n":"DistributedTransactionOutcome","d":2800172,"h":292060576300,"f":40},{"r":65537,"n":"SignalAsyncCompletion","d":2800172,"h":296355543596,"f":8},{"r":65537,"n":"FireCompletion","d":2800172,"h":300650510892,"f":8},{"r":65537,"n":"Dispose","d":2800172,"h":304945478188,"f":1}],"l":[{"t":5749292,"n":"_transactionState","d":2800172,"h":4297767468,"f":2},{"t":5749292,"n":"_promoteState","d":2800172,"h":21477636652,"f":8},{"t":56164353,"n":"_promoterType","d":2800172,"h":25772603948,"f":8},{"t":0,"n":"promotedToken","d":2800172,"h":30067571244,"f":8},{"t":56164353,"n":"_distributedTransactionIdentifierNonMSDTC","d":2800172,"h":34362538540,"f":8},{"t":655361,"n":"MaxStateHist","d":2800172,"h":38657505836,"f":40},{"t":0,"n":"_stateHistory","d":2800172,"h":42952473132,"f":8},{"t":655361,"n":"_currentStateHist","d":2800172,"h":47247440428,"f":8},{"t":2341420,"n":"_finalizedObject","d":2800172,"h":51542407724,"f":8},{"t":655361,"n":"_transactionHash","d":2800172,"h":55837375020,"f":8},{"t":655361,"n":"_nextHash","d":2800172,"h":68722276908,"f":40},{"t":917505,"n":"_absoluteTimeout","d":2800172,"h":73017244204,"f":2},{"t":917505,"n":"_creationTime","d":2800172,"h":85902146092,"f":2},{"t":2734636,"n":"_durableEnlistment","d":2800172,"h":103082015276,"f":8},{"t":9353772,"n":"_phase0Volatiles","d":2800172,"h":107376982572,"f":8},{"t":9353772,"n":"_phase1Volatiles","d":2800172,"h":111671949868,"f":8},{"t":655361,"n":"_phase0VolatileWaveCount","d":2800172,"h":115966917164,"f":8},{"t":3455532,"n":"_phase0WaveDependentClone","d":2800172,"h":120261884460,"f":8},{"t":655361,"n":"_phase0WaveDependentCloneCount","d":2800172,"h":124556851756,"f":8},{"t":3455532,"n":"_abortingDependentClone","d":2800172,"h":128851819052,"f":8},{"t":655361,"n":"_abortingDependentCloneCount","d":2800172,"h":133146786348,"f":8},{"t":655361,"n":"VolatileArrayIncrement","d":2800172,"h":137441753644,"f":40},{"t":309804,"n":"_tableBucket","d":2800172,"h":141736720940,"f":8},{"t":655361,"n":"_bucketIndex","d":2800172,"h":146031688236,"f":8},{"t":4438572,"n":"_transactionCompletedDelegate","d":2800172,"h":150326655532,"f":8},{"t":3521068,"n":"_promotedTransaction","d":2800172,"h":154621622828,"f":2},{"t":655361,"n":"_cloneCount","d":2800172,"h":176096459308,"f":8},{"t":655361,"n":"_enlistmentCount","d":2800172,"h":180391426604,"f":8},{"t":128319489,"n":"_asyncResultEvent","d":2800172,"h":184686393900,"f":8},{"t":262145,"n":"_asyncCommit","d":2800172,"h":188981361196,"f":8},{"t":14417921,"n":"_asyncCallback","d":2800172,"h":193276328492,"f":8},{"t":131073,"n":"_asyncState","d":2800172,"h":197571295788,"f":8},{"t":262145,"n":"_needPulse","d":2800172,"h":201866263084,"f":8},{"t":4766252,"n":"_transactionInformation","d":2800172,"h":206161230380,"f":8},{"t":571948,"n":"_committableTransaction","d":2800172,"h":210456197676,"f":8},{"t":4307500,"n":"_outcomeSource","d":2800172,"h":214751164972,"f":8},{"t":131073,"n":"s_classSyncObject","d":2800172,"h":219046132268,"f":34},{"t":1310721,"n":"s_instanceIdentifier","d":2800172,"h":231931034156,"f":34},{"t":262145,"n":"_traceIdentifierInited","d":2800172,"h":244815936044,"f":2},{"t":8567340,"n":"_traceIdentifier","d":2800172,"h":249110903340,"f":2},{"t":3258924,"n":"_promoter","d":2800172,"h":261995805228,"f":8},{"t":262145,"n":"_attemptingPSPEPromote","d":2800172,"h":266290772524,"f":8}],"c":[{"p":[{"n":"timeout","p":140705793},{"n":"committableTransaction","p":571948}],"n":".ctor","o":"$ctor$1","d":2800172,"h":279175674412,"f":8},{"p":[{"n":"outcomeSource","p":4307500},{"n":"distributedTx","p":3521068}],"n":".ctor","o":"$ctor$2","d":2800172,"h":283470641708,"f":8},{"p":[{"n":"outcomeSource","p":4307500},{"n":"promoter","p":3258924}],"n":".ctor","o":"$ctor$3","d":2800172,"h":287765609004,"f":8}],"i":[57475073],"h":2800172}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Transactions.InternalTransaction`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionScope", ($self) => class TransactionScope extends $.$spc.System.Object
        {
            $ctor$1()
            {
                this.$ctor$2(0/*TransactionScopeOption.Required*/);
                {
                }
                return this;
            }
            $ctor$2(/*TransactionScopeOption*/ scopeOption)
            {
                this.$ctor$4(scopeOption, 0/*TransactionScopeAsyncFlowOption.Suppress*/);
                {
                }
                return this;
            }
            $ctor$3(/*TransactionScopeAsyncFlowOption*/ asyncFlowOption)
            {
                this.$ctor$4(0/*TransactionScopeOption.Required*/, asyncFlowOption);
                {
                }
                return this;
            }
            $ctor$4(/*TransactionScopeOption*/ scopeOption, /*TransactionScopeAsyncFlowOption*/ asyncFlowOption)
            {
                super.$ctor();
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodEnter(0/*TraceSourceType.TraceSourceBase*/, this, "TransactionScope");
                    }
                    this.ValidateAndSetAsyncFlowOption(asyncFlowOption);
                    if (this.NeedToCreateTransaction(scopeOption))
                    {
                        this._committableTransaction = new $.$stl.System.Transactions.CommittableTransaction().$ctor$5();
                        this._expectedCurrent = this._committableTransaction.Clone();
                    }
                    if ($.$stl.System.Transactions.Transaction.op_Equality(null, this._expectedCurrent))
                    {
                        if (etwLog.IsEnabled())
                        {
                            etwLog.TransactionScopeCreated($.$stl.System.Transactions.TransactionTraceIdentifier.Empty, 4/*TransactionScopeResult.NoTransaction*/);
                        }
                    }
                    else 
                    {
                        /*TransactionScopeResult*/ let scopeResult;
                        if ($.$stl.System.Transactions.Transaction.op_Equality(null, this._committableTransaction))
                        {
                            scopeResult = 1/*TransactionScopeResult.UsingExistingCurrent*/;
                        }
                        else 
                        {
                            scopeResult = 0/*TransactionScopeResult.CreatedTransaction*/;
                        }
                        if (etwLog.IsEnabled())
                        {
                            etwLog.TransactionScopeCreated(this._expectedCurrent.TransactionTraceId, scopeResult);
                        }
                    }
                    this.PushScope();
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodExit(0/*TraceSourceType.TraceSourceBase*/, this, "TransactionScope");
                    }
                }
                return this;
            }
            $ctor$5(/*TransactionScopeOption*/ scopeOption, /*TimeSpan*/ scopeTimeout)
            {
                this.$ctor$6(scopeOption, scopeTimeout, 0/*TransactionScopeAsyncFlowOption.Suppress*/);
                {
                }
                return this;
            }
            $ctor$6(/*TransactionScopeOption*/ scopeOption, /*TimeSpan*/ scopeTimeout, /*TransactionScopeAsyncFlowOption*/ asyncFlowOption)
            {
                super.$ctor();
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodEnter(0/*TraceSourceType.TraceSourceBase*/, this, "TransactionScope");
                    }
                    $.$stl.System.Transactions.TransactionScope.ValidateScopeTimeout("scopeTimeout", scopeTimeout);
                    /*TimeSpan*/ let txTimeout = $.$stl.System.Transactions.TransactionManager.ValidateTimeout(scopeTimeout);
                    this.ValidateAndSetAsyncFlowOption(asyncFlowOption);
                    if (this.NeedToCreateTransaction(scopeOption))
                    {
                        this._committableTransaction = new $.$stl.System.Transactions.CommittableTransaction().$ctor$6(txTimeout);
                        this._expectedCurrent = this._committableTransaction.Clone();
                    }
                    if (($.$stl.System.Transactions.Transaction.op_Inequality(null, this._expectedCurrent)) && ($.$stl.System.Transactions.Transaction.op_Equality(null, this._committableTransaction)) && ($.$spc.System.TimeSpan.op_Inequality($.$spc.System.TimeSpan.Zero, scopeTimeout)))
                    {
                        this._scopeTimer = new $.$spc.System.Threading.Timer().$ctor$4(new $.$spc.System.Threading.TimerCallback().$ctor(null, $.$stl.System.Transactions.TransactionScope.TimerCallback), this, scopeTimeout, $.$spc.System.TimeSpan.Zero);
                    }
                    if ($.$stl.System.Transactions.Transaction.op_Equality(null, this._expectedCurrent))
                    {
                        if (etwLog.IsEnabled())
                        {
                            etwLog.TransactionScopeCreated($.$stl.System.Transactions.TransactionTraceIdentifier.Empty, 4/*TransactionScopeResult.NoTransaction*/);
                        }
                    }
                    else 
                    {
                        /*TransactionScopeResult*/ let scopeResult;
                        if ($.$stl.System.Transactions.Transaction.op_Equality(null, this._committableTransaction))
                        {
                            scopeResult = 1/*TransactionScopeResult.UsingExistingCurrent*/;
                        }
                        else 
                        {
                            scopeResult = 0/*TransactionScopeResult.CreatedTransaction*/;
                        }
                        if (etwLog.IsEnabled())
                        {
                            etwLog.TransactionScopeCreated(this._expectedCurrent.TransactionTraceId, scopeResult);
                        }
                    }
                    this.PushScope();
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodExit(0/*TraceSourceType.TraceSourceBase*/, this, "TransactionScope");
                    }
                }
                return this;
            }
            $ctor$7(/*TransactionScopeOption*/ scopeOption, /*TransactionOptions*/ transactionOptions)
            {
                this.$ctor$8(scopeOption, transactionOptions.Clone(), 0/*TransactionScopeAsyncFlowOption.Suppress*/);
                {
                }
                return this;
            }
            $ctor$8(/*TransactionScopeOption*/ scopeOption, /*TransactionOptions*/ transactionOptions, /*TransactionScopeAsyncFlowOption*/ asyncFlowOption)
            {
                super.$ctor();
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodEnter(0/*TraceSourceType.TraceSourceBase*/, this, "TransactionScope");
                    }
                    $.$stl.System.Transactions.TransactionScope.ValidateScopeTimeout("transactionOptions.Timeout", transactionOptions.Timeout);
                    /*TimeSpan*/ let scopeTimeout = transactionOptions.Timeout;
                    transactionOptions.Timeout = $.$stl.System.Transactions.TransactionManager.ValidateTimeout(transactionOptions.Timeout);
                    $.$stl.System.Transactions.TransactionManager.ValidateIsolationLevel(transactionOptions.IsolationLevel);
                    this.ValidateAndSetAsyncFlowOption(asyncFlowOption);
                    if (this.NeedToCreateTransaction(scopeOption))
                    {
                        this._committableTransaction = new $.$stl.System.Transactions.CommittableTransaction().$ctor$7(transactionOptions.Clone());
                        this._expectedCurrent = this._committableTransaction.Clone();
                    }
                    else 
                    {
                        if ($.$stl.System.Transactions.Transaction.op_Inequality(null, this._expectedCurrent))
                        {
                            if ((6/*IsolationLevel.Unspecified*/ !== transactionOptions.IsolationLevel) && (this._expectedCurrent.IsolationLevel !== transactionOptions.IsolationLevel))
                            {
                                throw new $.$spc.System.ArgumentException().$ctor$13($.$stl.System.SR.TransactionScopeIsolationLevelDifferentFromTransaction, "transactionOptions");
                            }
                        }
                    }
                    if (($.$stl.System.Transactions.Transaction.op_Inequality(null, this._expectedCurrent)) && ($.$stl.System.Transactions.Transaction.op_Equality(null, this._committableTransaction)) && ($.$spc.System.TimeSpan.op_Inequality($.$spc.System.TimeSpan.Zero, scopeTimeout)))
                    {
                        this._scopeTimer = new $.$spc.System.Threading.Timer().$ctor$4(new $.$spc.System.Threading.TimerCallback().$ctor(null, $.$stl.System.Transactions.TransactionScope.TimerCallback), this, scopeTimeout, $.$spc.System.TimeSpan.Zero);
                    }
                    if ($.$stl.System.Transactions.Transaction.op_Equality(null, this._expectedCurrent))
                    {
                        if (etwLog.IsEnabled())
                        {
                            etwLog.TransactionScopeCreated($.$stl.System.Transactions.TransactionTraceIdentifier.Empty, 4/*TransactionScopeResult.NoTransaction*/);
                        }
                    }
                    else 
                    {
                        /*TransactionScopeResult*/ let scopeResult;
                        if ($.$stl.System.Transactions.Transaction.op_Equality(null, this._committableTransaction))
                        {
                            scopeResult = 1/*TransactionScopeResult.UsingExistingCurrent*/;
                        }
                        else 
                        {
                            scopeResult = 0/*TransactionScopeResult.CreatedTransaction*/;
                        }
                        if (etwLog.IsEnabled())
                        {
                            etwLog.TransactionScopeCreated(this._expectedCurrent.TransactionTraceId, scopeResult);
                        }
                    }
                    this.PushScope();
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodExit(0/*TraceSourceType.TraceSourceBase*/, this, "TransactionScope");
                    }
                }
                return this;
            }
            $ctor$9(/*TransactionScopeOption*/ scopeOption, /*TransactionOptions*/ transactionOptions, /*EnterpriseServicesInteropOption*/ interopOption)
            {
                super.$ctor();
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodEnter(0/*TraceSourceType.TraceSourceBase*/, this, "TransactionScope");
                    }
                    $.$stl.System.Transactions.TransactionScope.ValidateScopeTimeout("transactionOptions.Timeout", transactionOptions.Timeout);
                    /*TimeSpan*/ let scopeTimeout = transactionOptions.Timeout;
                    transactionOptions.Timeout = $.$stl.System.Transactions.TransactionManager.ValidateTimeout(transactionOptions.Timeout);
                    $.$stl.System.Transactions.TransactionManager.ValidateIsolationLevel(transactionOptions.IsolationLevel);
                    $.$stl.System.Transactions.TransactionScope.ValidateInteropOption(interopOption);
                    this._interopModeSpecified = true;
                    this._interopOption = interopOption;
                    if (this.NeedToCreateTransaction(scopeOption))
                    {
                        this._committableTransaction = new $.$stl.System.Transactions.CommittableTransaction().$ctor$7(transactionOptions.Clone());
                        this._expectedCurrent = this._committableTransaction.Clone();
                    }
                    else 
                    {
                        if ($.$stl.System.Transactions.Transaction.op_Inequality(null, this._expectedCurrent))
                        {
                            if ((6/*IsolationLevel.Unspecified*/ !== transactionOptions.IsolationLevel) && (this._expectedCurrent.IsolationLevel !== transactionOptions.IsolationLevel))
                            {
                                throw new $.$spc.System.ArgumentException().$ctor$13($.$stl.System.SR.TransactionScopeIsolationLevelDifferentFromTransaction, "transactionOptions");
                            }
                        }
                    }
                    if (($.$stl.System.Transactions.Transaction.op_Inequality(null, this._expectedCurrent)) && ($.$stl.System.Transactions.Transaction.op_Equality(null, this._committableTransaction)) && ($.$spc.System.TimeSpan.op_Inequality($.$spc.System.TimeSpan.Zero, scopeTimeout)))
                    {
                        this._scopeTimer = new $.$spc.System.Threading.Timer().$ctor$4(new $.$spc.System.Threading.TimerCallback().$ctor(null, $.$stl.System.Transactions.TransactionScope.TimerCallback), this, scopeTimeout, $.$spc.System.TimeSpan.Zero);
                    }
                    if ($.$stl.System.Transactions.Transaction.op_Equality(null, this._expectedCurrent))
                    {
                        if (etwLog.IsEnabled())
                        {
                            etwLog.TransactionScopeCreated($.$stl.System.Transactions.TransactionTraceIdentifier.Empty, 4/*TransactionScopeResult.NoTransaction*/);
                        }
                    }
                    else 
                    {
                        /*TransactionScopeResult*/ let scopeResult;
                        if ($.$stl.System.Transactions.Transaction.op_Equality(null, this._committableTransaction))
                        {
                            scopeResult = 1/*TransactionScopeResult.UsingExistingCurrent*/;
                        }
                        else 
                        {
                            scopeResult = 0/*TransactionScopeResult.CreatedTransaction*/;
                        }
                        if (etwLog.IsEnabled())
                        {
                            etwLog.TransactionScopeCreated(this._expectedCurrent.TransactionTraceId, scopeResult);
                        }
                    }
                    this.PushScope();
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodExit(0/*TraceSourceType.TraceSourceBase*/, this, "TransactionScope");
                    }
                }
                return this;
            }
            $ctor$10(/*Transaction*/ transactionToUse)
            {
                this.$ctor$11(transactionToUse, 0/*TransactionScopeAsyncFlowOption.Suppress*/);
                {
                }
                return this;
            }
            $ctor$11(/*Transaction*/ transactionToUse, /*TransactionScopeAsyncFlowOption*/ asyncFlowOption)
            {
                super.$ctor();
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodEnter(0/*TraceSourceType.TraceSourceBase*/, this, "TransactionScope");
                    }
                    this.ValidateAndSetAsyncFlowOption(asyncFlowOption);
                    this.Initialize(transactionToUse, $.$spc.System.TimeSpan.Zero, false);
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodExit(0/*TraceSourceType.TraceSourceBase*/, this, "TransactionScope");
                    }
                }
                return this;
            }
            $ctor$12(/*Transaction*/ transactionToUse, /*TimeSpan*/ scopeTimeout)
            {
                this.$ctor$13(transactionToUse, scopeTimeout, 0/*TransactionScopeAsyncFlowOption.Suppress*/);
                {
                }
                return this;
            }
            $ctor$13(/*Transaction*/ transactionToUse, /*TimeSpan*/ scopeTimeout, /*TransactionScopeAsyncFlowOption*/ asyncFlowOption)
            {
                super.$ctor();
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodEnter(0/*TraceSourceType.TraceSourceBase*/, this, "TransactionScope");
                    }
                    this.ValidateAndSetAsyncFlowOption(asyncFlowOption);
                    this.Initialize(transactionToUse, scopeTimeout, false);
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodExit(0/*TraceSourceType.TraceSourceBase*/, this, "TransactionScope");
                    }
                }
                return this;
            }
            $ctor$14(/*Transaction*/ transactionToUse, /*TimeSpan*/ scopeTimeout, /*EnterpriseServicesInteropOption*/ interopOption)
            {
                super.$ctor();
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodEnter(0/*TraceSourceType.TraceSourceBase*/, this, "TransactionScope");
                    }
                    $.$stl.System.Transactions.TransactionScope.ValidateInteropOption(interopOption);
                    this._interopOption = interopOption;
                    this.Initialize(transactionToUse, scopeTimeout, true);
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodExit(0/*TraceSourceType.TraceSourceBase*/, this, "TransactionScope");
                    }
                }
                return this;
            }
            /*bool */ NeedToCreateTransaction(/*TransactionScopeOption*/ scopeOption)
            {
                /*bool*/ let retVal = false;
                this.CommonInitialize();
                switch(scopeOption)
                {
                    case 2/*TransactionScopeOption.Suppress*/:
                    this._expectedCurrent = null;
                    retVal = false;
                    break;
                    case 0/*TransactionScopeOption.Required*/:
                    this._expectedCurrent = this._savedCurrent;
                    if ($.$stl.System.Transactions.Transaction.op_Equality(null, this._expectedCurrent))
                    {
                        retVal = true;
                    }
                    break;
                    case 1/*TransactionScopeOption.RequiresNew*/:
                    retVal = true;
                    break;
                    default:
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("scopeOption");
                }
                return retVal;
            }
            /*void */ Initialize(/*Transaction*/ transactionToUse, /*TimeSpan*/ scopeTimeout, /*bool*/ interopModeSpecified)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(transactionToUse, "transactionToUse");
                $.$stl.System.Transactions.TransactionScope.ValidateScopeTimeout("scopeTimeout", scopeTimeout);
                this.CommonInitialize();
                if ($.$spc.System.TimeSpan.op_Inequality($.$spc.System.TimeSpan.Zero, scopeTimeout))
                {
                    this._scopeTimer = new $.$spc.System.Threading.Timer().$ctor$4(new $.$spc.System.Threading.TimerCallback().$ctor(null, $.$stl.System.Transactions.TransactionScope.TimerCallback), this, scopeTimeout, $.$spc.System.TimeSpan.Zero);
                }
                this._expectedCurrent = transactionToUse;
                this._interopModeSpecified = interopModeSpecified;
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionScopeCreated(this._expectedCurrent.TransactionTraceId, 2/*TransactionScopeResult.TransactionPassed*/);
                }
                this.PushScope();
            }
            /*void */ Dispose()
            {
                /*bool*/ let successful = false;
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(0/*TraceSourceType.TraceSourceBase*/, this, "Dispose");
                }
                if (this._disposed)
                {
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodExit(0/*TraceSourceType.TraceSourceBase*/, this, "Dispose");
                    }
                    return;
                }
                if ((this._scopeThread !== $.$spc.System.Threading.Thread.CurrentThread) && !this.AsyncFlowEnabled)
                {
                    if (etwLog.IsEnabled())
                    {
                        etwLog.InvalidOperation("TransactionScope", "InvalidScopeThread");
                    }
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$stl.System.SR.InvalidScopeThread);
                }
                /*Exception?*/ let exToThrow = null;
                try
                {
                    this._disposed = true;
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._threadContextData !== null, "_threadContextData != null");
                    /*TransactionScope?*/ let actualCurrentScope = this._threadContextData.CurrentScope;
                    /*Transaction?*/ let contextTransaction = null;
                    /*Transaction?*/ let current = $.$stl.System.Transactions.Transaction.FastGetTransaction(actualCurrentScope, this._threadContextData, $.$ref(() => contextTransaction, ($v) => contextTransaction = $v, $.$stl.System.Transactions.Transaction));
                    if (!$.$spc.System.Object.Equals.call(this, actualCurrentScope))
                    {
                        if (actualCurrentScope === null)
                        {
                            /*Transaction?*/ let rollbackTransaction = this._committableTransaction ?? this._dependentTransaction;
                            $.$spc.System.Diagnostics.Debug.Assert$1($.$stl.System.Transactions.Transaction.op_Inequality(rollbackTransaction, null), "rollbackTransaction != null");
                            rollbackTransaction.Rollback();
                            successful = true;
                            throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException$1(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionScopeInvalidNesting, null, rollbackTransaction.DistributedTxId);
                        }
                        else if (0/*EnterpriseServicesInteropOption.None*/ === actualCurrentScope._interopOption)
                        {
                            if ((($.$stl.System.Transactions.Transaction.op_Inequality(null, actualCurrentScope._expectedCurrent)) && (!$.$stl.System.Transactions.Transaction.Equals.call(actualCurrentScope._expectedCurrent, current))) || (($.$stl.System.Transactions.Transaction.op_Inequality(null, current)) && ($.$stl.System.Transactions.Transaction.op_Equality(null, actualCurrentScope._expectedCurrent))))
                            {
                                /*TransactionTraceIdentifier*/ let myId;
                                /*TransactionTraceIdentifier*/ let currentId;
                                if ($.$stl.System.Transactions.Transaction.op_Equality(null, current))
                                {
                                    currentId = $.$stl.System.Transactions.TransactionTraceIdentifier.Empty;
                                }
                                else 
                                {
                                    currentId = current.TransactionTraceId;
                                }
                                if ($.$stl.System.Transactions.Transaction.op_Equality(null, this._expectedCurrent))
                                {
                                    myId = $.$stl.System.Transactions.TransactionTraceIdentifier.Empty;
                                }
                                else 
                                {
                                    myId = this._expectedCurrent.TransactionTraceId;
                                }
                                if (etwLog.IsEnabled())
                                {
                                    etwLog.TransactionScopeCurrentChanged(currentId, myId);
                                }
                                exToThrow = $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException$1(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionScopeIncorrectCurrent, null, $.$stl.System.Transactions.Transaction.op_Equality(current, null) ? $.$spc.System.Guid.Empty : current.DistributedTxId);
                                if ($.$stl.System.Transactions.Transaction.op_Inequality(null, current))
                                {
                                    try
                                    {
                                        current.Rollback();
                                    }
                                    catch($e)
                                    {
                                        if ($e instanceof $.$stl.System.Transactions.TransactionException)
                                        {
                                        }
                                        else if ($e instanceof $.$spc.System.ObjectDisposedException)
                                        {
                                        }
                                        else
                                        {
                                            throw $e;
                                        }
                                    }
                                }
                            }
                        }
                        while(!$.$spc.System.Object.Equals.call(this, actualCurrentScope))
                        {
                            if (null === exToThrow)
                            {
                                exToThrow = $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException$1(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionScopeInvalidNesting, null, $.$stl.System.Transactions.Transaction.op_Equality(current, null) ? $.$spc.System.Guid.Empty : current.DistributedTxId);
                            }
                            if ($.$stl.System.Transactions.Transaction.op_Equality(null, actualCurrentScope._expectedCurrent))
                            {
                                if (etwLog.IsEnabled())
                                {
                                    etwLog.TransactionScopeNestedIncorrectly($.$stl.System.Transactions.TransactionTraceIdentifier.Empty);
                                }
                            }
                            else 
                            {
                                if (etwLog.IsEnabled())
                                {
                                    etwLog.TransactionScopeNestedIncorrectly(actualCurrentScope._expectedCurrent.TransactionTraceId);
                                }
                            }
                            actualCurrentScope._complete = false;
                            try
                            {
                                actualCurrentScope.InternalDispose();
                            }
                            catch($e)
                            {
                            }
                            actualCurrentScope = this._threadContextData.CurrentScope;
                            this._complete = false;
                        }
                    }
                    else 
                    {
                        if (0/*EnterpriseServicesInteropOption.None*/ === this._interopOption)
                        {
                            if ((($.$stl.System.Transactions.Transaction.op_Inequality(null, this._expectedCurrent)) && (!$.$stl.System.Transactions.Transaction.Equals.call(this._expectedCurrent, current))) || (($.$stl.System.Transactions.Transaction.op_Inequality(null, current)) && ($.$stl.System.Transactions.Transaction.op_Equality(null, this._expectedCurrent))))
                            {
                                /*TransactionTraceIdentifier*/ let myId;
                                /*TransactionTraceIdentifier*/ let currentId;
                                if ($.$stl.System.Transactions.Transaction.op_Equality(null, current))
                                {
                                    currentId = $.$stl.System.Transactions.TransactionTraceIdentifier.Empty;
                                }
                                else 
                                {
                                    currentId = current.TransactionTraceId;
                                }
                                if ($.$stl.System.Transactions.Transaction.op_Equality(null, this._expectedCurrent))
                                {
                                    myId = $.$stl.System.Transactions.TransactionTraceIdentifier.Empty;
                                }
                                else 
                                {
                                    myId = this._expectedCurrent.TransactionTraceId;
                                }
                                if (etwLog.IsEnabled())
                                {
                                    etwLog.TransactionScopeCurrentChanged(currentId, myId);
                                }
                                if (null === exToThrow)
                                {
                                    exToThrow = $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException$1(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionScopeIncorrectCurrent, null, $.$stl.System.Transactions.Transaction.op_Equality(current, null) ? $.$spc.System.Guid.Empty : current.DistributedTxId);
                                }
                                if ($.$stl.System.Transactions.Transaction.op_Inequality(null, current))
                                {
                                    try
                                    {
                                        current.Rollback();
                                    }
                                    catch($e)
                                    {
                                        if ($e instanceof $.$stl.System.Transactions.TransactionException)
                                        {
                                        }
                                        else if ($e instanceof $.$spc.System.ObjectDisposedException)
                                        {
                                        }
                                        else
                                        {
                                            throw $e;
                                        }
                                    }
                                }
                                this._complete = false;
                            }
                        }
                    }
                    successful = true;
                }
                finally
                {
                    {
                        if (!successful)
                        {
                            this.PopScope();
                        }
                    }
                }
                this.InternalDispose();
                if (null !== exToThrow)
                {
                    throw exToThrow;
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(0/*TraceSourceType.TraceSourceBase*/, this, "Dispose");
                }
            }
            /*void */ InternalDispose()
            {
                this._disposed = true;
                try
                {
                    this.PopScope();
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if ($.$stl.System.Transactions.Transaction.op_Equality(null, this._expectedCurrent))
                    {
                        if (etwLog.IsEnabled())
                        {
                            etwLog.TransactionScopeDisposed($.$stl.System.Transactions.TransactionTraceIdentifier.Empty);
                        }
                    }
                    else 
                    {
                        if (etwLog.IsEnabled())
                        {
                            etwLog.TransactionScopeDisposed(this._expectedCurrent.TransactionTraceId);
                        }
                    }
                    if ($.$stl.System.Transactions.Transaction.op_Inequality(null, this._expectedCurrent))
                    {
                        if (!this._complete)
                        {
                            if (etwLog.IsEnabled())
                            {
                                etwLog.TransactionScopeIncomplete(this._expectedCurrent.TransactionTraceId);
                            }
                            /*Transaction?*/ let rollbackTransaction = this._committableTransaction ?? this._dependentTransaction;
                            $.$spc.System.Diagnostics.Debug.Assert$1($.$stl.System.Transactions.Transaction.op_Inequality(rollbackTransaction, null), "rollbackTransaction != null");
                            rollbackTransaction.Rollback();
                        }
                        else 
                        {
                            if ($.$stl.System.Transactions.Transaction.op_Inequality(null, this._committableTransaction))
                            {
                                this._committableTransaction.Commit();
                            }
                            else 
                            {
                                $.$spc.System.Diagnostics.Debug.Assert$1($.$stl.System.Transactions.Transaction.op_Inequality(null, this._dependentTransaction), "null != this.dependentTransaction");
                                this._dependentTransaction.Complete();
                            }
                        }
                    }
                }
                finally
                {
                    {
                        this._scopeTimer?.Dispose$1();
                        if ($.$stl.System.Transactions.Transaction.op_Inequality(null, this._committableTransaction))
                        {
                            this._committableTransaction.Dispose();
                            $.$spc.System.Diagnostics.Debug.Assert$1($.$stl.System.Transactions.Transaction.op_Inequality(this._expectedCurrent, null), "_expectedCurrent != null");
                            this._expectedCurrent.Dispose();
                        }
                        this._dependentTransaction?.Dispose();
                    }
                }
            }
            /*void */ Complete()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(0/*TraceSourceType.TraceSourceBase*/, this, "Complete");
                }
                $.$spc.System.ObjectDisposedException.ThrowIf(this._disposed, this);
                if (this._complete)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.DisposeScope, null);
                }
                this._complete = true;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(0/*TraceSourceType.TraceSourceBase*/, this, "Complete");
                }
            }
            static /*void */ TimerCallback(/*object?*/ state)
            {
                /*TransactionScope?*/ let scope = $.$as(state, $.$stl.System.Transactions.TransactionScope);
                if (null === scope)
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.InternalError("TransactionScopeTimerObjectInvalid");
                    }
                    throw $.$stl.System.Transactions.TransactionException.Create($.$stl.System.SR.InternalError + $.$stl.System.SR.TransactionScopeTimerObjectInvalid, null);
                }
                scope.Timeout();
            }
            /*void */ Timeout()
            {
                if ((!this._complete) && ($.$stl.System.Transactions.Transaction.op_Inequality(null, this._expectedCurrent)))
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.TransactionScopeTimeout(this._expectedCurrent.TransactionTraceId);
                    }
                    try
                    {
                        this._expectedCurrent.Rollback();
                    }
                    catch($e)
                    {
                        if ($e instanceof $.$spc.System.ObjectDisposedException)
                        {
                            let ex = $e;
                            if (etwLog.IsEnabled())
                            {
                                etwLog.ExceptionConsumed(0/*TraceSourceType.TraceSourceBase*/, ex);
                            }
                        }
                        else if ($e instanceof $.$stl.System.Transactions.TransactionException)
                        {
                            let txEx = $e;
                            if (etwLog.IsEnabled())
                            {
                                etwLog.ExceptionConsumed(0/*TraceSourceType.TraceSourceBase*/, txEx);
                            }
                        }
                        else
                        {
                            throw $e;
                        }
                    }
                }
            }
            /*void */ CommonInitialize()
            {
                this.ContextKey = new $.$stl.System.Transactions.ContextKey().$ctor$1();
                this._complete = false;
                this._dependentTransaction = null;
                this._disposed = false;
                this._committableTransaction = null;
                this._expectedCurrent = null;
                this._scopeTimer = null;
                this._scopeThread = $.$spc.System.Threading.Thread.CurrentThread;
                $.$stl.System.Transactions.Transaction.GetCurrentTransactionAndScope(this.AsyncFlowEnabled ? 1/*TxLookup.DefaultCallContext*/ : 2/*TxLookup.DefaultTLS*/, $.$ref(() => this._savedCurrent, ($v) => this._savedCurrent = $v, $.$stl.System.Transactions.Transaction), $.$ref(() => this._savedCurrentScope, ($v) => this._savedCurrentScope = $v, $.$stl.System.Transactions.TransactionScope), $.$ref(() => this._contextTransaction, ($v) => this._contextTransaction = $v, $.$stl.System.Transactions.Transaction));
                this.ValidateAsyncFlowOptionAndESInteropOption();
            }
            /*void */ PushScope()
            {
                if (!this._interopModeSpecified)
                {
                    this._interopOption = $.$stl.System.Transactions.Transaction.InteropMode(this._savedCurrentScope);
                }
                this.SaveTLSContextData();
                if (this.AsyncFlowEnabled)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(this.ContextKey !== null, "ContextKey != null");
                    this._threadContextData = $.$stl.System.Transactions.CallContextCurrentData.CreateOrGetCurrentData(this.ContextKey);
                    if (this._savedCurrentScope === null && $.$stl.System.Transactions.Transaction.op_Equality(this._savedCurrent, null))
                    {
                        $.$stl.System.Transactions.ContextData.TLSCurrentData = null;
                    }
                }
                else 
                {
                    this._threadContextData = $.$stl.System.Transactions.ContextData.TLSCurrentData;
                    $.$stl.System.Transactions.CallContextCurrentData.ClearCurrentData(this.ContextKey, false);
                }
                this.SetCurrent(this._expectedCurrent);
                this._threadContextData.CurrentScope = this;
            }
            /*void */ PopScope()
            {
                /*bool*/ let shouldRestoreContextData = true;
                if (this.AsyncFlowEnabled)
                {
                    $.$stl.System.Transactions.CallContextCurrentData.ClearCurrentData(this.ContextKey, true);
                }
                if (this._scopeThread === $.$spc.System.Threading.Thread.CurrentThread)
                {
                    this.RestoreSavedTLSContextData();
                }
                if (this._savedCurrentScope !== null)
                {
                    if (this._savedCurrentScope.AsyncFlowEnabled)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._savedCurrentScope.ContextKey !== null, "_savedCurrentScope.ContextKey != null");
                        this._threadContextData = $.$stl.System.Transactions.CallContextCurrentData.CreateOrGetCurrentData(this._savedCurrentScope.ContextKey);
                    }
                    else 
                    {
                        if (this._savedCurrentScope._scopeThread !== $.$spc.System.Threading.Thread.CurrentThread)
                        {
                            shouldRestoreContextData = false;
                            $.$stl.System.Transactions.ContextData.TLSCurrentData = null;
                        }
                        else 
                        {
                            this._threadContextData = $.$stl.System.Transactions.ContextData.TLSCurrentData;
                        }
                        $.$stl.System.Transactions.CallContextCurrentData.ClearCurrentData(this._savedCurrentScope.ContextKey, false);
                    }
                }
                else 
                {
                    $.$stl.System.Transactions.CallContextCurrentData.ClearCurrentData(null, false);
                    if (this._scopeThread !== $.$spc.System.Threading.Thread.CurrentThread)
                    {
                        shouldRestoreContextData = false;
                        $.$stl.System.Transactions.ContextData.TLSCurrentData = null;
                    }
                    else 
                    {
                        $.$stl.System.Transactions.ContextData.TLSCurrentData = this._threadContextData;
                    }
                }
                if (shouldRestoreContextData)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._threadContextData !== null, "_threadContextData != null");
                    this._threadContextData.CurrentScope = this._savedCurrentScope;
                    this.RestoreCurrent();
                }
            }
            /*void */ SetCurrent(/*Transaction?*/ newCurrent)
            {
                if (this._dependentTransaction === null && this._committableTransaction === null)
                {
                    if ($.$stl.System.Transactions.Transaction.op_Inequality(newCurrent, null))
                    {
                        this._dependentTransaction = newCurrent.DependentClone(1/*DependentCloneOption.RollbackIfNotComplete*/);
                    }
                }
                switch(this._interopOption)
                {
                    case 0/*EnterpriseServicesInteropOption.None*/:
                    this._threadContextData.CurrentTransaction = newCurrent;
                    break;
                    case 1/*EnterpriseServicesInteropOption.Automatic*/:
                    $.$stl.System.Transactions.EnterpriseServices.VerifyEnterpriseServicesOk();
                    if ($.$stl.System.Transactions.EnterpriseServices.UseServiceDomainForCurrent())
                    {
                        $.$stl.System.Transactions.EnterpriseServices.PushServiceDomain();
                    }
                    else 
                    {
                        this._threadContextData.CurrentTransaction = newCurrent;
                    }
                    break;
                    case 2/*EnterpriseServicesInteropOption.Full*/:
                    $.$stl.System.Transactions.EnterpriseServices.VerifyEnterpriseServicesOk();
                    $.$stl.System.Transactions.EnterpriseServices.PushServiceDomain();
                    break;
                }
            }
            /*void */ SaveTLSContextData()
            {
                this._savedTLSContextData ??= new $.$stl.System.Transactions.ContextData().$ctor$1(false);
                this._savedTLSContextData.CurrentScope = $.$stl.System.Transactions.ContextData.TLSCurrentData.CurrentScope;
                this._savedTLSContextData.CurrentTransaction = $.$stl.System.Transactions.ContextData.TLSCurrentData.CurrentTransaction;
                this._savedTLSContextData.DefaultComContextState = $.$stl.System.Transactions.ContextData.TLSCurrentData.DefaultComContextState;
                this._savedTLSContextData.WeakDefaultComContext = $.$stl.System.Transactions.ContextData.TLSCurrentData.WeakDefaultComContext;
            }
            /*void */ RestoreSavedTLSContextData()
            {
                if (this._savedTLSContextData !== null)
                {
                    $.$stl.System.Transactions.ContextData.TLSCurrentData.CurrentScope = this._savedTLSContextData.CurrentScope;
                    $.$stl.System.Transactions.ContextData.TLSCurrentData.CurrentTransaction = this._savedTLSContextData.CurrentTransaction;
                    $.$stl.System.Transactions.ContextData.TLSCurrentData.DefaultComContextState = this._savedTLSContextData.DefaultComContextState;
                    $.$stl.System.Transactions.ContextData.TLSCurrentData.WeakDefaultComContext = this._savedTLSContextData.WeakDefaultComContext;
                }
            }
            /*void */ RestoreCurrent()
            {
                if ($.$stl.System.Transactions.EnterpriseServices.CreatedServiceDomain)
                {
                    $.$stl.System.Transactions.EnterpriseServices.LeaveServiceDomain();
                }
                this._threadContextData.CurrentTransaction = this._contextTransaction;
            }
            static /*void */ ValidateInteropOption(/*EnterpriseServicesInteropOption*/ interopOption)
            {
                if (interopOption < 0/*EnterpriseServicesInteropOption.None*/ || interopOption > 2/*EnterpriseServicesInteropOption.Full*/)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("interopOption");
                }
            }
            static /*void */ ValidateScopeTimeout(/*string?*/ paramName, /*TimeSpan*/ scopeTimeout)
            {
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfLessThan($.$spc.System.TimeSpan, scopeTimeout, $.$spc.System.TimeSpan.Zero, paramName);
            }
            /*void */ ValidateAndSetAsyncFlowOption(/*TransactionScopeAsyncFlowOption*/ asyncFlowOption)
            {
                if (asyncFlowOption < 0/*TransactionScopeAsyncFlowOption.Suppress*/ || asyncFlowOption > 1/*TransactionScopeAsyncFlowOption.Enabled*/)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("asyncFlowOption");
                }
                if (asyncFlowOption === 1/*TransactionScopeAsyncFlowOption.Enabled*/)
                {
                    this.AsyncFlowEnabled = true;
                }
            }
            /*void */ ValidateAsyncFlowOptionAndESInteropOption()
            {
                if (this.AsyncFlowEnabled)
                {
                    /*EnterpriseServicesInteropOption*/ let currentInteropOption = this._interopOption;
                    if (!this._interopModeSpecified)
                    {
                        currentInteropOption = $.$stl.System.Transactions.Transaction.InteropMode(this._savedCurrentScope);
                    }
                    if (currentInteropOption !== 0/*EnterpriseServicesInteropOption.None*/)
                    {
                        throw new $.$spc.System.NotSupportedException().$ctor$10($.$stl.System.SR.AsyncFlowAndESInteropNotSupported);
                    }
                }
            }
            /*bool*/ _complete = false;
            /*bool */ get ScopeComplete()
            {
                return this._complete;
            }
            /*Transaction?*/ _savedCurrent = null;
            /*Transaction?*/ _contextTransaction = null;
            /*TransactionScope?*/ _savedCurrentScope = null;
            /*ContextData?*/ _threadContextData = null;
            /*ContextData?*/ _savedTLSContextData = null;
            /*Transaction?*/ _expectedCurrent = null;
            /*CommittableTransaction?*/ _committableTransaction = null;
            /*DependentTransaction?*/ _dependentTransaction = null;
            /*bool*/ _disposed = false;
            /*Timer?*/ _scopeTimer = null;
            /*Thread?*/ _scopeThread = null;
            /*bool*/ _interopModeSpecified = false;
            /*EnterpriseServicesInteropOption*/ _interopOption = 0;
            /*EnterpriseServicesInteropOption */ get InteropMode()
            {
                return this._interopOption;
            }
            /*ContextKey?*/ ContextKey = null;
            /*bool*/ AsyncFlowEnabled = false;
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this.AsyncFlowEnabled = false;
            }
            static $h = 5159468;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":150329014828,"f":8},"n":"ScopeComplete","d":5159468,"h":146034047532,"f":8},{"p":2275884,"g":{"r":0,"d":0,"h":214753524268,"f":8},"n":"InteropMode","d":5159468,"h":210458556972,"f":8},{"p":965164,"g":{"r":0,"d":0,"h":227638426156,"f":8},"s":{"r":0,"d":0,"h":231933393452,"f":2},"n":"ContextKey","d":5159468,"h":223343458860,"f":8},{"p":262145,"g":{"r":0,"d":0,"h":244818295340,"f":8},"s":{"r":0,"d":0,"h":249113262636,"f":2},"n":"AsyncFlowEnabled","d":5159468,"h":240523328044,"f":8}],"m":[{"r":262145,"p":[{"n":"scopeOption","p":5290540}],"n":"NeedToCreateTransaction","d":5159468,"h":64429668908,"f":2},{"r":65537,"p":[{"n":"transactionToUse","p":4307500},{"n":"scopeTimeout","p":140705793},{"n":"interopModeSpecified","p":262145}],"n":"Initialize","d":5159468,"h":68724636204,"f":2},{"r":65537,"n":"Dispose","d":5159468,"h":73019603500,"f":1},{"r":65537,"n":"InternalDispose","d":5159468,"h":77314570796,"f":2},{"r":65537,"n":"Complete","d":5159468,"h":81609538092,"f":1},{"r":65537,"p":[{"n":"state","p":131073}],"n":"TimerCallback","d":5159468,"h":85904505388,"f":34},{"r":65537,"n":"Timeout","d":5159468,"h":90199472684,"f":2},{"r":65537,"n":"CommonInitialize","d":5159468,"h":94494439980,"f":2},{"r":65537,"n":"PushScope","d":5159468,"h":98789407276,"f":2},{"r":65537,"n":"PopScope","d":5159468,"h":103084374572,"f":2},{"r":65537,"p":[{"n":"newCurrent","p":4307500}],"n":"SetCurrent","d":5159468,"h":107379341868,"f":2},{"r":65537,"n":"SaveTLSContextData","d":5159468,"h":111674309164,"f":2},{"r":65537,"n":"RestoreSavedTLSContextData","d":5159468,"h":115969276460,"f":2},{"r":65537,"n":"RestoreCurrent","d":5159468,"h":120264243756,"f":2},{"r":65537,"p":[{"n":"interopOption","p":2275884}],"n":"ValidateInteropOption","d":5159468,"h":124559211052,"f":34},{"r":65537,"p":[{"n":"paramName","p":1310721},{"n":"scopeTimeout","p":140705793}],"n":"ValidateScopeTimeout","d":5159468,"h":128854178348,"f":34},{"r":65537,"p":[{"n":"asyncFlowOption","p":5225004}],"n":"ValidateAndSetAsyncFlowOption","d":5159468,"h":133149145644,"f":2},{"r":65537,"n":"ValidateAsyncFlowOptionAndESInteropOption","d":5159468,"h":137444112940,"f":2}],"l":[{"t":262145,"n":"_complete","d":5159468,"h":141739080236,"f":2},{"t":4307500,"n":"_savedCurrent","d":5159468,"h":154623982124,"f":2},{"t":4307500,"n":"_contextTransaction","d":5159468,"h":158918949420,"f":2},{"t":5159468,"n":"_savedCurrentScope","d":5159468,"h":163213916716,"f":2},{"t":899628,"n":"_threadContextData","d":5159468,"h":167508884012,"f":2},{"t":899628,"n":"_savedTLSContextData","d":5159468,"h":171803851308,"f":2},{"t":4307500,"n":"_expectedCurrent","d":5159468,"h":176098818604,"f":2},{"t":571948,"n":"_committableTransaction","d":5159468,"h":180393785900,"f":2},{"t":1161772,"n":"_dependentTransaction","d":5159468,"h":184688753196,"f":2},{"t":262145,"n":"_disposed","d":5159468,"h":188983720492,"f":2},{"t":138543105,"n":"_scopeTimer","d":5159468,"h":193278687788,"f":2},{"t":136445953,"n":"_scopeThread","d":5159468,"h":197573655084,"f":2},{"t":262145,"n":"_interopModeSpecified","d":5159468,"h":201868622380,"f":2},{"t":2275884,"n":"_interopOption","d":5159468,"h":206163589676,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":5159468,"h":4300126764,"f":1},{"p":[{"n":"scopeOption","p":5290540}],"n":".ctor","o":"$ctor$2","d":5159468,"h":8595094060,"f":1},{"p":[{"n":"asyncFlowOption","p":5225004}],"n":".ctor","o":"$ctor$3","d":5159468,"h":12890061356,"f":1},{"p":[{"n":"scopeOption","p":5290540},{"n":"asyncFlowOption","p":5225004}],"n":".ctor","o":"$ctor$4","d":5159468,"h":17185028652,"f":1},{"p":[{"n":"scopeOption","p":5290540},{"n":"scopeTimeout","p":140705793}],"n":".ctor","o":"$ctor$5","d":5159468,"h":21479995948,"f":1},{"p":[{"n":"scopeOption","p":5290540},{"n":"scopeTimeout","p":140705793},{"n":"asyncFlowOption","p":5225004}],"n":".ctor","o":"$ctor$6","d":5159468,"h":25774963244,"f":1},{"p":[{"n":"scopeOption","p":5290540},{"n":"transactionOptions","p":5028396}],"n":".ctor","o":"$ctor$7","d":5159468,"h":30069930540,"f":1},{"p":[{"n":"scopeOption","p":5290540},{"n":"transactionOptions","p":5028396},{"n":"asyncFlowOption","p":5225004}],"n":".ctor","o":"$ctor$8","d":5159468,"h":34364897836,"f":1},{"p":[{"n":"scopeOption","p":5290540},{"n":"transactionOptions","p":5028396},{"n":"interopOption","p":2275884}],"n":".ctor","o":"$ctor$9","d":5159468,"h":38659865132,"f":1},{"p":[{"n":"transactionToUse","p":4307500}],"n":".ctor","o":"$ctor$10","d":5159468,"h":42954832428,"f":1},{"p":[{"n":"transactionToUse","p":4307500},{"n":"asyncFlowOption","p":5225004}],"n":".ctor","o":"$ctor$11","d":5159468,"h":47249799724,"f":1},{"p":[{"n":"transactionToUse","p":4307500},{"n":"scopeTimeout","p":140705793}],"n":".ctor","o":"$ctor$12","d":5159468,"h":51544767020,"f":1},{"p":[{"n":"transactionToUse","p":4307500},{"n":"scopeTimeout","p":140705793},{"n":"asyncFlowOption","p":5225004}],"n":".ctor","o":"$ctor$13","d":5159468,"h":55839734316,"f":1},{"p":[{"n":"transactionToUse","p":4307500},{"n":"scopeTimeout","p":140705793},{"n":"interopOption","p":2275884}],"n":".ctor","o":"$ctor$14","d":5159468,"h":60134701612,"f":1}],"i":[57475073],"h":5159468,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Transactions.TransactionScope`; }
        });
        
        $asm.$cls("$stl.System.Transactions.FinalizedObject", ($self) => class FinalizedObject extends $.$spc.System.Object
        {
            /*Guid*/ _identifier;
            /*InternalTransaction*/ _internalTransaction = null;
            $ctor$1(/*InternalTransaction*/ internalTransaction, /*Guid*/ identifier)
            {
                super.$ctor();
                {
                    this._internalTransaction = internalTransaction;
                    this._identifier = identifier;
                }
                return this;
            }
            /*void */ Dispose(/*bool*/ disposing)
            {
                if (disposing)
                {
                    $.$spc.System.GC.SuppressFinalize(this);
                }
                /*Hashtable*/ let promotedTransactionTable = $.$stl.System.Transactions.TransactionManager.PromotedTransactionTable;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(promotedTransactionTable)
                    {
                        /*WeakReference?*/ let weakRef = $.$cast(promotedTransactionTable.get_Item(this._identifier), $.$spc.System.WeakReference);
                        if (null !== weakRef)
                        {
                            if (weakRef.Target !== null)
                            {
                                weakRef.Target = null;
                            }
                        }
                        promotedTransactionTable.Remove(this._identifier);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(promotedTransactionTable)
                }
            }
            /*void */ Dispose$1()
            {
                this.Dispose(true);
            }
            $dtor()
            {
                this.Dispose(false);
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose$1(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this._identifier = $.$default($.$spc.System.Guid);
                $.$finalizer(this);
            }
            static $h = 2341420;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","d":2341420,"h":17182210604,"f":2},{"r":65537,"n":"Dispose","o":"@$1","d":2341420,"h":21477177900,"f":1}],"l":[{"t":56164353,"n":"_identifier","d":2341420,"h":4297308716,"f":2},{"t":2800172,"n":"_internalTransaction","d":2341420,"h":8592276012,"f":2}],"c":[{"p":[{"n":"internalTransaction","p":2800172},{"n":"identifier","p":56164353}],"n":".ctor","o":"$ctor$1","d":2341420,"h":12887243308,"f":8}],"i":[57475073],"h":2341420}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Transactions.FinalizedObject`; }
        });
        
        $asm.$cls("$stl.System.Transactions.Oletx.OletxTransaction", ($self) => class OletxTransaction extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*SerializationInfo*/ serializationInfo, /*StreamingContext*/ context)
            {
                super.$ctor();
                {
                    throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                }
                return this;
            }
            /*Exception?*/ InnerException = null;
            /*Guid*/ Identifier;
            /*RealOletxTransaction?*/ RealTransaction = null;
            /*TransactionTraceIdentifier*/ TransactionTraceId;
            /*IsolationLevel*/ IsolationLevel = 0;
            /*Transaction?*/ SavedLtmPromotedTransaction = null;
            /*IPromotedEnlistment */ EnlistVolatile(/*InternalEnlistment*/ internalEnlistment, /*EnlistmentOptions*/ enlistmentOptions)
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransaction.NotSupported();
            }
            /*IPromotedEnlistment */ EnlistDurable(/*Guid*/ resourceManagerIdentifier, /*DurableInternalEnlistment*/ internalEnlistment, /*bool*/ v, /*EnlistmentOptions*/ enlistmentOptions)
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransaction.NotSupported();
            }
            /*void */ Rollback()
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransaction.NotSupported();
            }
            /*OletxDependentTransaction */ DependentClone(/*bool*/ delayCommit)
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransaction.NotSupported();
            }
            /*IPromotedEnlistment */ EnlistVolatile$1(/*VolatileDemultiplexer*/ volatileDemux, /*EnlistmentOptions*/ enlistmentOptions)
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransaction.NotSupported();
            }
            static /*byte[] */ GetExportCookie(/*byte[]*/ whereaboutsCopy)
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransaction.NotSupported();
            }
            static /*byte[] */ GetTransmitterPropagationToken()
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransaction.NotSupported();
            }
            static /*IDtcTransaction */ GetDtcTransaction()
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransaction.NotSupported();
            }
            /*void */ GetObjectData(/*SerializationInfo*/ serializationInfo, /*StreamingContext*/ context)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose()
            {
            }
            static /*Exception */ NotSupported()
            {
                return new $.$spc.System.PlatformNotSupportedException().$ctor$14($.$stl.System.SR.DistributedNotSupported);
            }
            static $_RealOletxTransaction;
            static get RealOletxTransaction()
            {
                let $cls = $.$stl.System.Transactions.Oletx.OletxTransaction;
                return $cls.$_RealOletxTransaction ??= $asm.$ncls("$stl.System.Transactions.Oletx.OletxTransaction.RealOletxTransaction", ($self) => class RealOletxTransaction extends $.$spc.System.Object
                {
                    /*InternalTransaction?*/ InternalTransaction = null;
                    //default reference type constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        return this;
                    }
                    static $h = 3586604;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":2800172,"g":{"r":0,"d":0,"h":12888488492,"f":8},"s":{"r":0,"d":0,"h":17183455788,"f":8},"n":"InternalTransaction","d":3586604,"h":8593521196,"f":8}],"c":[{"n":".ctor","o":"$ctor$1","d":3586604,"h":21478423084,"f":1}],"d":3521068,"h":3586604}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Transactions.Oletx.OletxTransaction.RealOletxTransaction`; }
                }, $cls, ($v) => $cls.$_RealOletxTransaction = $v);
            }
            //Generated interface implemetation for System.Runtime.Serialization.ISerializable.GetObjectData(System.Runtime.Serialization.SerializationInfo, System.Runtime.Serialization.StreamingContext)
            System$Runtime$Serialization$ISerializable$GetObjectData()
            {
                return this.GetObjectData(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this.Identifier = $.$default($.$spc.System.Guid);
                this.TransactionTraceId = $.$default($.$stl.System.Transactions.TransactionTraceIdentifier);
                this.IsolationLevel = 0;
            }
            static $h = 3521068;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":56164353,"g":{"r":0,"d":0,"h":38658226732,"f":8},"s":{"r":0,"d":0,"h":42953194028,"f":8},"n":"Identifier","d":3521068,"h":34363259436,"f":8},{"p":3586604,"g":{"r":0,"d":0,"h":55838095916,"f":8},"s":{"r":0,"d":0,"h":60133063212,"f":8},"n":"RealTransaction","d":3521068,"h":51543128620,"f":8},{"p":8567340,"g":{"r":0,"d":0,"h":73017965100,"f":8},"s":{"r":0,"d":0,"h":77312932396,"f":8},"n":"TransactionTraceId","d":3521068,"h":68722997804,"f":8},{"p":3193388,"g":{"r":0,"d":0,"h":90197834284,"f":8},"s":{"r":0,"d":0,"h":94492801580,"f":8},"n":"IsolationLevel","d":3521068,"h":85902866988,"f":8},{"p":4307500,"g":{"r":0,"d":0,"h":107377703468,"f":8},"s":{"r":0,"d":0,"h":111672670764,"f":8},"n":"SavedLtmPromotedTransaction","d":3521068,"h":103082736172,"f":8}],"m":[{"r":2931244,"p":[{"n":"internalEnlistment","p":2734636},{"n":"enlistmentOptions","p":1882668}],"n":"EnlistVolatile","d":3521068,"h":115967638060,"f":8},{"r":2931244,"p":[{"n":"resourceManagerIdentifier","p":56164353},{"n":"internalEnlistment","p":1620524},{"n":"v","p":262145},{"n":"enlistmentOptions","p":1882668}],"n":"EnlistDurable","d":3521068,"h":120262605356,"f":8},{"r":65537,"n":"Rollback","d":3521068,"h":124557572652,"f":8},{"r":3455532,"p":[{"n":"delayCommit","p":262145}],"n":"DependentClone","d":3521068,"h":128852539948,"f":8},{"r":2931244,"p":[{"n":"volatileDemux","p":8698412},{"n":"enlistmentOptions","p":1882668}],"n":"EnlistVolatile","o":"@$1","d":3521068,"h":133147507244,"f":8},{"r":0,"p":[{"n":"whereaboutsCopy","p":0}],"n":"GetExportCookie","d":3521068,"h":137442474540,"f":40},{"r":0,"n":"GetTransmitterPropagationToken","d":3521068,"h":141737441836,"f":40},{"r":2538028,"n":"GetDtcTransaction","d":3521068,"h":146032409132,"f":40},{"r":65537,"p":[{"n":"serializationInfo","p":113967105},{"n":"context","p":114098177}],"n":"GetObjectData","d":3521068,"h":150327376428,"f":1},{"r":65537,"n":"Dispose","d":3521068,"h":154622343724,"f":8},{"r":47185921,"n":"NotSupported","d":3521068,"h":158917311020,"f":40}],"c":[{"n":".ctor","o":"$ctor$1","d":3521068,"h":4298488364,"f":8},{"p":[{"n":"serializationInfo","p":113967105},{"n":"context","p":114098177}],"n":".ctor","o":"$ctor$2","d":3521068,"h":8593455660,"f":4}],"i":[113377281],"j":[3586604],"h":3521068}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Transactions.Oletx.OletxTransaction`; }
        });
        
        $asm.$cls("$stl.System.Transactions.InternalEnlistment", ($self) => class InternalEnlistment extends $.$spc.System.Object
        {
            /*EnlistmentState?*/ _twoPhaseState = null;
            /*IEnlistmentNotification?*/ _twoPhaseNotifications = null;
            /*ISinglePhaseNotification?*/ _singlePhaseNotifications = null;
            /*InternalTransaction*/ _transaction = null;
            /*Transaction?*/ _atomicTransaction = null;
            /*EnlistmentTraceIdentifier*/ _traceIdentifier;
            /*int*/ _enlistmentId = 0;
            /*Guid */ get DistributedTxId()
            {
                /*Guid*/ let returnValue = $.$spc.System.Guid.Empty;
                if (this.Transaction !== null)
                {
                    returnValue = this.Transaction.DistributedTxId;
                }
                return returnValue;
            }
            /*Enlistment*/ _enlistment = null;
            /*PreparingEnlistment?*/ _preparingEnlistment = null;
            /*SinglePhaseEnlistment?*/ _singlePhaseEnlistment = null;
            /*IPromotedEnlistment?*/ _promotedEnlistment = null;
            $ctor$1(/*Enlistment*/ enlistment, /*IEnlistmentNotification*/ twoPhaseNotifications)
            {
                super.$ctor();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1($.$is(this, $.$stl.System.Transactions.RecoveringInternalEnlistment), "this is RecoveringInternalEnlistment");
                    this._enlistment = enlistment;
                    this._twoPhaseNotifications = twoPhaseNotifications;
                    this._enlistmentId = 1;
                    this._traceIdentifier = $.$stl.System.Transactions.EnlistmentTraceIdentifier.Empty;
                }
                return this;
            }
            $ctor$2(/*Enlistment*/ enlistment, /*InternalTransaction*/ transaction, /*Transaction*/ atomicTransaction)
            {
                super.$ctor();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1($.$is(this, $.$stl.System.Transactions.PromotableInternalEnlistment), "this is PromotableInternalEnlistment");
                    this._enlistment = enlistment;
                    this._transaction = transaction;
                    this._atomicTransaction = atomicTransaction;
                    this._enlistmentId = transaction._enlistmentCount++;
                    this._traceIdentifier = $.$stl.System.Transactions.EnlistmentTraceIdentifier.Empty;
                }
                return this;
            }
            $ctor$3(/*Enlistment*/ enlistment, /*InternalTransaction*/ transaction, /*IEnlistmentNotification*/ twoPhaseNotifications, /*ISinglePhaseNotification?*/ singlePhaseNotifications, /*Transaction*/ atomicTransaction)
            {
                super.$ctor();
                {
                    this._enlistment = enlistment;
                    this._transaction = transaction;
                    this._twoPhaseNotifications = twoPhaseNotifications;
                    this._singlePhaseNotifications = singlePhaseNotifications;
                    this._atomicTransaction = atomicTransaction;
                    this._enlistmentId = transaction._enlistmentCount++;
                    this._traceIdentifier = $.$stl.System.Transactions.EnlistmentTraceIdentifier.Empty;
                }
                return this;
            }
            $ctor$4(/*Enlistment*/ enlistment, /*IEnlistmentNotification*/ twoPhaseNotifications, /*InternalTransaction*/ transaction, /*Transaction*/ atomicTransaction)
            {
                super.$ctor();
                {
                    this._enlistment = enlistment;
                    this._twoPhaseNotifications = twoPhaseNotifications;
                    this._transaction = transaction;
                    this._atomicTransaction = atomicTransaction;
                }
                return this;
            }
            /*EnlistmentState */ get State()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._twoPhaseState !== null, "_twoPhaseState != null");
                return this._twoPhaseState;
            }
            /*EnlistmentState */ set State(value)
            {
                this._twoPhaseState = value;
            }
            /*Enlistment */ get Enlistment()
            {
                return this._enlistment;
            }
            /*PreparingEnlistment */ get PreparingEnlistment()
            {
                return this._preparingEnlistment ??= new $.$stl.System.Transactions.PreparingEnlistment().$ctor$7(this);
            }
            /*SinglePhaseEnlistment */ get SinglePhaseEnlistment()
            {
                return this._singlePhaseEnlistment ??= new $.$stl.System.Transactions.SinglePhaseEnlistment().$ctor$7(this);
            }
            /*InternalTransaction */ get Transaction()
            {
                return this._transaction;
            }
            /*object */ get SyncRoot()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._transaction !== null, "this.transaction != null");
                return this._transaction;
            }
            /*IEnlistmentNotification? */ get EnlistmentNotification()
            {
                return this._twoPhaseNotifications;
            }
            /*ISinglePhaseNotification? */ get SinglePhaseNotification()
            {
                return this._singlePhaseNotifications;
            }
            /*IPromotableSinglePhaseNotification */ get PromotableSinglePhaseNotification()
            {
                $.$spc.System.Diagnostics.Debug.Fail("PromotableSinglePhaseNotification called for a non promotable enlistment.");
                throw new $.$spc.System.NotImplementedException().$ctor$9();
            }
            /*IPromotedEnlistment? */ get PromotedEnlistment()
            {
                return this._promotedEnlistment;
            }
            /*IPromotedEnlistment? */ set PromotedEnlistment(value)
            {
                this._promotedEnlistment = value;
            }
            /*EnlistmentTraceIdentifier */ get EnlistmentTraceId()
            {
                if ($.$stl.System.Transactions.EnlistmentTraceIdentifier.op_Equality(this._traceIdentifier, $.$stl.System.Transactions.EnlistmentTraceIdentifier.Empty))
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter(this.SyncRoot)
                        {
                            if ($.$stl.System.Transactions.EnlistmentTraceIdentifier.op_Equality(this._traceIdentifier, $.$stl.System.Transactions.EnlistmentTraceIdentifier.Empty))
                            {
                                /*EnlistmentTraceIdentifier*/ let temp;
                                if ($.$stl.System.Transactions.Transaction.op_Inequality(null, this._atomicTransaction))
                                {
                                    temp = new $.$stl.System.Transactions.EnlistmentTraceIdentifier().$ctor$2($.$spc.System.Guid.Empty, this._atomicTransaction.TransactionTraceId, this._enlistmentId);
                                }
                                else 
                                {
                                    temp = new $.$stl.System.Transactions.EnlistmentTraceIdentifier().$ctor$2($.$spc.System.Guid.Empty, new $.$stl.System.Transactions.TransactionTraceIdentifier().$ctor$2($.$spc.System.String.Create$9($.$spc.System.Globalization.CultureInfo.InvariantCulture, `${$.$stl.System.Transactions.InternalTransaction.InstanceIdentifier}${$.$spc.System.Threading.Interlocked.Increment($.$ref(() => $.$stl.System.Transactions.InternalTransaction._nextHash, ($v) => $.$stl.System.Transactions.InternalTransaction._nextHash = $v, $.$spc.System.Int32))}`), 0), this._enlistmentId);
                                }
                                $.$spc.System.Threading.Interlocked.MemoryBarrier();
                                this._traceIdentifier = temp;
                            }
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit(this.SyncRoot)
                    }
                }
                return this._traceIdentifier;
            }
            /*void */ FinishEnlistment()
            {
                this.Transaction._phase0Volatiles._preparedVolatileEnlistments++;
                this.CheckComplete();
            }
            /*void */ CheckComplete()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this.Transaction._phase0Volatiles._preparedVolatileEnlistments <= ((this.Transaction._phase0Volatiles._volatileEnlistmentCount + this.Transaction._phase0Volatiles._dependentClones) | 0), "Transaction._phase0Volatiles._preparedVolatileEnlistments <=\r\n                Transaction._phase0Volatiles._volatileEnlistmentCount + Transaction._phase0Volatiles._dependentClones");
                if (this.Transaction._phase0Volatiles._preparedVolatileEnlistments === ((this.Transaction._phase0VolatileWaveCount + this.Transaction._phase0Volatiles._dependentClones) | 0))
                {
                    this.Transaction.State.Phase0VolatilePrepareDone(this.Transaction);
                }
            }
            /*Guid */ get ResourceManagerIdentifier()
            {
                $.$spc.System.Diagnostics.Debug.Fail("ResourceManagerIdentifier called for non durable enlistment");
                throw new $.$spc.System.NotImplementedException().$ctor$9();
            }
            /*void */ System$Transactions$ISinglePhaseNotificationInternal$SinglePhaseCommit(/*IPromotedEnlistment*/ singlePhaseEnlistment)
            {
                /*bool*/ let spcCommitted = false;
                this._promotedEnlistment = singlePhaseEnlistment;
                try
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._singlePhaseNotifications !== null, "_singlePhaseNotifications != null");
                    this._singlePhaseNotifications.System$Transactions$ISinglePhaseNotification$SinglePhaseCommit(this.SinglePhaseEnlistment);
                    spcCommitted = true;
                }
                finally
                {
                    {
                        if (!spcCommitted)
                        {
                            this.SinglePhaseEnlistment.InDoubt();
                        }
                    }
                }
            }
            /*void */ System$Transactions$IEnlistmentNotificationInternal$Prepare(/*IPromotedEnlistment*/ preparingEnlistment)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._twoPhaseNotifications !== null, "_twoPhaseNotifications != null");
                this._promotedEnlistment = preparingEnlistment;
                this._twoPhaseNotifications.System$Transactions$IEnlistmentNotification$Prepare(this.PreparingEnlistment);
            }
            /*void */ System$Transactions$IEnlistmentNotificationInternal$Commit(/*IPromotedEnlistment*/ enlistment)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._twoPhaseNotifications !== null, "_twoPhaseNotifications != null");
                this._promotedEnlistment = enlistment;
                this._twoPhaseNotifications.System$Transactions$IEnlistmentNotification$Commit(this.Enlistment);
            }
            /*void */ System$Transactions$IEnlistmentNotificationInternal$Rollback(/*IPromotedEnlistment*/ enlistment)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._twoPhaseNotifications !== null, "_twoPhaseNotifications != null");
                this._promotedEnlistment = enlistment;
                this._twoPhaseNotifications.System$Transactions$IEnlistmentNotification$Rollback(this.Enlistment);
            }
            /*void */ System$Transactions$IEnlistmentNotificationInternal$InDoubt(/*IPromotedEnlistment*/ enlistment)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._twoPhaseNotifications !== null, "_twoPhaseNotifications != null");
                this._promotedEnlistment = enlistment;
                this._twoPhaseNotifications.System$Transactions$IEnlistmentNotification$InDoubt(this.Enlistment);
            }
            //default member initializer
            constructor()
            {
                super();
                this._transaction = null;
                this._traceIdentifier = $.$default($.$stl.System.Transactions.EnlistmentTraceIdentifier);
            }
            static $h = 2734636;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":56164353,"g":{"r":0,"d":0,"h":38657440300,"f":8},"n":"DistributedTxId","d":2734636,"h":34362473004,"f":8},{"p":1948204,"g":{"r":0,"d":0,"h":81607113260,"f":8},"s":{"r":0,"d":0,"h":85902080556,"f":8},"n":"State","d":2734636,"h":77312145964,"f":8},{"p":1751596,"g":{"r":0,"d":0,"h":94492015148,"f":8},"n":"Enlistment","d":2734636,"h":90197047852,"f":8},{"p":3914284,"g":{"r":0,"d":0,"h":103081949740,"f":8},"n":"PreparingEnlistment","d":2734636,"h":98786982444,"f":8},{"p":4110892,"g":{"r":0,"d":0,"h":111671884332,"f":8},"n":"SinglePhaseEnlistment","d":2734636,"h":107376917036,"f":8},{"p":2800172,"g":{"r":0,"d":0,"h":120261818924,"f":8},"n":"Transaction","d":2734636,"h":115966851628,"f":8},{"p":131073,"g":{"r":0,"d":0,"h":128851753516,"f":136},"n":"SyncRoot","d":2734636,"h":124556786220,"f":136},{"p":2603564,"g":{"r":0,"d":0,"h":137441688108,"f":8},"n":"EnlistmentNotification","d":2734636,"h":133146720812,"f":8},{"p":3062316,"g":{"r":0,"d":0,"h":146031622700,"f":8},"n":"SinglePhaseNotification","d":2734636,"h":141736655404,"f":8},{"p":2865708,"g":{"r":0,"d":0,"h":154621557292,"f":136},"n":"PromotableSinglePhaseNotification","d":2734636,"h":150326589996,"f":136},{"p":2931244,"g":{"r":0,"d":0,"h":163211491884,"f":8},"s":{"r":0,"d":0,"h":167506459180,"f":8},"n":"PromotedEnlistment","d":2734636,"h":158916524588,"f":8},{"p":2079276,"g":{"r":0,"d":0,"h":176096393772,"f":8},"n":"EnlistmentTraceId","d":2734636,"h":171801426476,"f":8},{"p":56164353,"g":{"r":0,"d":0,"h":193276262956,"f":136},"n":"ResourceManagerIdentifier","d":2734636,"h":188981295660,"f":136}],"m":[{"r":65537,"n":"FinishEnlistment","d":2734636,"h":180391361068,"f":136},{"r":65537,"n":"CheckComplete","d":2734636,"h":184686328364,"f":136}],"l":[{"t":1948204,"n":"_twoPhaseState","d":2734636,"h":4297701932,"f":8},{"t":2603564,"n":"_twoPhaseNotifications","d":2734636,"h":8592669228,"f":4},{"t":3062316,"n":"_singlePhaseNotifications","d":2734636,"h":12887636524,"f":4},{"t":2800172,"n":"_transaction","d":2734636,"h":17182603820,"f":4},{"t":4307500,"n":"_atomicTransaction","d":2734636,"h":21477571116,"f":2},{"t":2079276,"n":"_traceIdentifier","d":2734636,"h":25772538412,"f":2},{"t":655361,"n":"_enlistmentId","d":2734636,"h":30067505708,"f":2},{"t":1751596,"n":"_enlistment","d":2734636,"h":42952407596,"f":2},{"t":3914284,"n":"_preparingEnlistment","d":2734636,"h":47247374892,"f":2},{"t":4110892,"n":"_singlePhaseEnlistment","d":2734636,"h":51542342188,"f":2},{"t":2931244,"n":"_promotedEnlistment","d":2734636,"h":55837309484,"f":2}],"c":[{"p":[{"n":"enlistment","p":1751596},{"n":"twoPhaseNotifications","p":2603564}],"n":".ctor","o":"$ctor$1","d":2734636,"h":60132276780,"f":4},{"p":[{"n":"enlistment","p":1751596},{"n":"transaction","p":2800172},{"n":"atomicTransaction","p":4307500}],"n":".ctor","o":"$ctor$2","d":2734636,"h":64427244076,"f":4},{"p":[{"n":"enlistment","p":1751596},{"n":"transaction","p":2800172},{"n":"twoPhaseNotifications","p":2603564},{"n":"singlePhaseNotifications","p":3062316},{"n":"atomicTransaction","p":4307500}],"n":".ctor","o":"$ctor$3","d":2734636,"h":68722211372,"f":8},{"p":[{"n":"enlistment","p":1751596},{"n":"twoPhaseNotifications","p":2603564},{"n":"transaction","p":2800172},{"n":"atomicTransaction","p":4307500}],"n":".ctor","o":"$ctor$4","d":2734636,"h":73017178668,"f":8}],"i":[3127852,2669100],"h":2734636}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stl.System.Transactions.ISinglePhaseNotificationInternal, $.$stl.System.Transactions.IEnlistmentNotificationInternal ]; }
            static get $fullName() { return `System.Transactions.InternalEnlistment`; }
        });
        
        $asm.$cls("$stl.System.Transactions.Transaction", ($self) => class Transaction extends $.$spc.System.Object
        {
            static /*bool */ UseServiceDomainForCurrent()
            {
                return false;
            }
            static /*EnterpriseServicesInteropOption */ InteropMode(/*TransactionScope?*/ currentScope)
            {
                if (currentScope !== null)
                {
                    return currentScope.InteropMode;
                }
                return 0/*EnterpriseServicesInteropOption.None*/;
            }
            static /*Transaction? */ FastGetTransaction(/*TransactionScope?*/ currentScope, /*ContextData*/ contextData, /*out Transaction?*/ contextTransaction)
            {
                /*Transaction?*/ let current = null;
                contextTransaction.$v = contextData.CurrentTransaction;
                let $switch1 = $.$stl.System.Transactions.Transaction.InteropMode(currentScope);
                switch($switch1)
                {
                    case 0/*EnterpriseServicesInteropOption.None*/:
                    current = contextTransaction.$v;
                    if ($.$stl.System.Transactions.Transaction.op_Equality(current, null) && currentScope === null)
                    {
                        if ($.$stl.System.Transactions.TransactionManager.s_currentDelegateSet)
                        {
                            current = $.$stl.System.Transactions.TransactionManager.$.$stl.System.Transactions.TransactionManager.s_currentDelegate.Invoke();
                        }
                        else 
                        {
                            current = $.$stl.System.Transactions.EnterpriseServices.GetContextTransaction();
                        }
                    }
                    break;
                    case 2/*EnterpriseServicesInteropOption.Full*/:
                    current = $.$stl.System.Transactions.EnterpriseServices.GetContextTransaction();
                    break;
                    case 1/*EnterpriseServicesInteropOption.Automatic*/:
                    if ($.$stl.System.Transactions.EnterpriseServices.UseServiceDomainForCurrent())
                    {
                        current = $.$stl.System.Transactions.EnterpriseServices.GetContextTransaction();
                    }
                    else 
                    {
                        current = contextData.CurrentTransaction;
                    }
                    break;
                }
                return current;
            }
            static /*void */ GetCurrentTransactionAndScope(/*TxLookup*/ defaultLookup, /*out Transaction?*/ current, /*out TransactionScope?*/ currentScope, /*out Transaction?*/ contextTransaction)
            {
                current.$v = null;
                currentScope.$v = null;
                contextTransaction.$v = null;
                /*ContextData*/ let contextData = $.$stl.System.Transactions.ContextData.LookupContextData(defaultLookup);
                if (contextData !== null)
                {
                    currentScope.$v = contextData.CurrentScope;
                    current.$v = $.$stl.System.Transactions.Transaction.FastGetTransaction(currentScope.$v, contextData, contextTransaction);
                }
            }
            static /*Transaction? */ get Current()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(0/*TraceSourceType.TraceSourceBase*/, "Transaction.get_Current");
                }
                /*Transaction?*/ let current;
                /*TransactionScope?*/ let currentScope;
                $.$stl.System.Transactions.Transaction.GetCurrentTransactionAndScope(0/*TxLookup.Default*/, $.$ref(() => current, ($v) => current = $v, $.$stl.System.Transactions.Transaction), $.$ref(() => currentScope, ($v) => currentScope = $v, $.$stl.System.Transactions.TransactionScope), $.$discardRef());
                if (currentScope !== null)
                {
                    if (currentScope.ScopeComplete)
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$stl.System.SR.TransactionScopeComplete);
                    }
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(0/*TraceSourceType.TraceSourceBase*/, "Transaction.get_Current");
                }
                return current;
            }
            static /*Transaction? */ set Current(value)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(0/*TraceSourceType.TraceSourceBase*/, "Transaction.set_Current");
                }
                if ($.$stl.System.Transactions.Transaction.InteropMode($.$stl.System.Transactions.ContextData.TLSCurrentData.CurrentScope) !== 0/*EnterpriseServicesInteropOption.None*/)
                {
                    if (etwLog.IsEnabled())
                    {
                        etwLog.InvalidOperation("Transaction", "Transaction.set_Current");
                    }
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$stl.System.SR.CannotSetCurrent);
                }
                $.$stl.System.Transactions.ContextData.TLSCurrentData.CurrentTransaction = value;
                $.$stl.System.Transactions.CallContextCurrentData.ClearCurrentData(null, false);
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(0/*TraceSourceType.TraceSourceBase*/, "Transaction.set_Current");
                }
            }
            /*IsolationLevel*/ _isoLevel = 0;
            /*bool*/ _complete = false;
            /*int*/ _cloneId = 0;
            /*int*/ static _disposedTrueValue = 1;
            /*int*/ _disposed = 0;
            /*bool */ get Disposed()
            {
                return this._disposed === 1/*Transaction._disposedTrueValue*/;
            }
            /*Guid */ get DistributedTxId()
            {
                /*Guid*/ let returnValue = $.$spc.System.Guid.Empty;
                if (this._internalTransaction !== null)
                {
                    returnValue = this._internalTransaction.DistributedTxId;
                }
                return returnValue;
            }
            /*InternalTransaction*/ _internalTransaction = null;
            /*TransactionTraceIdentifier*/ _traceIdentifier;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*IsolationLevel*/ isoLevel, /*InternalTransaction?*/ internalTransaction)
            {
                super.$ctor();
                {
                    $.$stl.System.Transactions.TransactionManager.ValidateIsolationLevel(isoLevel);
                    this._isoLevel = isoLevel;
                    if (6/*IsolationLevel.Unspecified*/ === this._isoLevel)
                    {
                        this._isoLevel = $.$stl.System.Transactions.TransactionManager.DefaultIsolationLevel;
                    }
                    if (internalTransaction !== null)
                    {
                        this._internalTransaction = internalTransaction;
                        this._cloneId = $.$spc.System.Threading.Interlocked.Increment($.$ref(() => this._internalTransaction._cloneCount, ($v) => this._internalTransaction._cloneCount = $v, $.$spc.System.Int32));
                    }
                    else 
                    {
                    }
                }
                return this;
            }
            $ctor$3(/*OletxTransaction*/ distributedTransaction)
            {
                super.$ctor();
                {
                    this._isoLevel = distributedTransaction.IsolationLevel;
                    this._internalTransaction = new $.$stl.System.Transactions.InternalTransaction().$ctor$2(this, distributedTransaction);
                    this._cloneId = $.$spc.System.Threading.Interlocked.Increment($.$ref(() => this._internalTransaction._cloneCount, ($v) => this._internalTransaction._cloneCount = $v, $.$spc.System.Int32));
                }
                return this;
            }
            $ctor$4(/*IsolationLevel*/ isoLevel, /*ISimpleTransactionSuperior*/ superior)
            {
                super.$ctor();
                {
                    $.$stl.System.Transactions.TransactionManager.ValidateIsolationLevel(isoLevel);
                    $.$spc.System.ArgumentNullException.ThrowIfNull(superior, "superior");
                    this._isoLevel = isoLevel;
                    if (6/*IsolationLevel.Unspecified*/ === this._isoLevel)
                    {
                        this._isoLevel = $.$stl.System.Transactions.TransactionManager.DefaultIsolationLevel;
                    }
                    this._internalTransaction = new $.$stl.System.Transactions.InternalTransaction().$ctor$3(this, superior);
                    this._internalTransaction.SetPromoterTypeToMSDTC();
                    this._cloneId = 1;
                }
                return this;
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return this._internalTransaction.TransactionHash;
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$stl.System.Transactions.Transaction.GetHashCode.apply(this, arguments); }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                let transaction;
                return $.$is(obj, $.$stl.System.Transactions.Transaction, { set $v(v){ transaction = v; } }) && this._internalTransaction.TransactionHash === transaction._internalTransaction.TransactionHash;
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$stl.System.Transactions.Transaction.Equals.apply(this, arguments); }
            static /*bool */ op_Equality(/*Transaction?*/ x, /*Transaction?*/ y)
            {
                if ((x) !== null)
                {
                    return $.$stl.System.Transactions.Transaction.Equals.call(x, y);
                }
                return (y) === null;
            }
            static /*bool */ op_Inequality(/*Transaction?*/ x, /*Transaction?*/ y)
            {
                if ((x) !== null)
                {
                    return !$.$stl.System.Transactions.Transaction.Equals.call(x, y);
                }
                return (y) !== null;
            }
            /*TransactionInformation */ get TransactionInformation()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "TransactionInformation");
                }
                $.$spc.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                /*TransactionInformation?*/ let txInfo = this._internalTransaction._transactionInformation;
                if (txInfo === null)
                {
                    txInfo = new $.$stl.System.Transactions.TransactionInformation().$ctor$1(this._internalTransaction);
                    this._internalTransaction._transactionInformation = txInfo;
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "TransactionInformation");
                }
                return txInfo;
            }
            /*IsolationLevel */ get IsolationLevel()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "IsolationLevel");
                }
                $.$spc.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "IsolationLevel");
                }
                return this._isoLevel;
            }
            /*Guid */ get PromoterType()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "PromoterType");
                }
                $.$spc.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                    {
                        return this._internalTransaction._promoterType;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                }
            }
            /*byte[] */ GetPromotedToken()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "GetPromotedToken");
                }
                $.$spc.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                /*byte[]*/ let internalPromotedToken;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        internalPromotedToken = this._internalTransaction.State.PromotedToken(this._internalTransaction);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                }
                /*byte[]*/ let toReturn = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [internalPromotedToken.length], null);
                $.$spc.System.Array.Copy(internalPromotedToken, toReturn, toReturn.length);
                return toReturn;
            }
            /*Enlistment */ EnlistDurable(/*Guid*/ resourceManagerIdentifier, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "EnlistDurable");
                }
                $.$spc.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                if ($.$spc.System.Guid.op_Equality(resourceManagerIdentifier, $.$spc.System.Guid.Empty))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$stl.System.SR.BadResourceManagerId, "resourceManagerIdentifier");
                }
                $.$spc.System.ArgumentNullException.ThrowIfNull(enlistmentNotification, "enlistmentNotification");
                if (enlistmentOptions !== 0/*EnlistmentOptions.None*/ && enlistmentOptions !== 1/*EnlistmentOptions.EnlistDuringPrepareRequired*/)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("enlistmentOptions");
                }
                if (this._complete)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateTransactionCompletedException(this.DistributedTxId);
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        /*Enlistment*/ let enlistment = this._internalTransaction.State.EnlistDurable(this._internalTransaction, resourceManagerIdentifier, enlistmentNotification, enlistmentOptions, this);
                        if (etwLog.IsEnabled())
                        {
                            etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "EnlistDurable");
                        }
                        return enlistment;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                }
            }
            /*Enlistment */ EnlistDurable$1(/*Guid*/ resourceManagerIdentifier, /*ISinglePhaseNotification*/ singlePhaseNotification, /*EnlistmentOptions*/ enlistmentOptions)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "EnlistDurable");
                }
                $.$spc.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                if ($.$spc.System.Guid.op_Equality(resourceManagerIdentifier, $.$spc.System.Guid.Empty))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$stl.System.SR.BadResourceManagerId, "resourceManagerIdentifier");
                }
                $.$spc.System.ArgumentNullException.ThrowIfNull(singlePhaseNotification, "singlePhaseNotification");
                if (enlistmentOptions !== 0/*EnlistmentOptions.None*/ && enlistmentOptions !== 1/*EnlistmentOptions.EnlistDuringPrepareRequired*/)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("enlistmentOptions");
                }
                if (this._complete)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateTransactionCompletedException(this.DistributedTxId);
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        /*Enlistment*/ let enlistment = this._internalTransaction.State.EnlistDurable$1(this._internalTransaction, resourceManagerIdentifier, singlePhaseNotification, enlistmentOptions, this);
                        if (etwLog.IsEnabled())
                        {
                            etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "EnlistDurable");
                        }
                        return enlistment;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                }
            }
            /*void */ Rollback()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "Rollback");
                    etwLog.TransactionRollback(1/*TraceSourceType.TraceSourceLtm*/, this.TransactionTraceId, "Transaction");
                }
                $.$spc.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        this._internalTransaction.State.Rollback(this._internalTransaction, null);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "Rollback");
                }
            }
            /*void */ Rollback$1(/*Exception?*/ e)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "Rollback");
                    etwLog.TransactionRollback(1/*TraceSourceType.TraceSourceLtm*/, this.TransactionTraceId, "Transaction");
                }
                $.$spc.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        this._internalTransaction.State.Rollback(this._internalTransaction, e);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "Rollback");
                }
            }
            /*Enlistment */ EnlistVolatile(/*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "EnlistVolatile");
                }
                $.$spc.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                $.$spc.System.ArgumentNullException.ThrowIfNull(enlistmentNotification, "enlistmentNotification");
                if (enlistmentOptions !== 0/*EnlistmentOptions.None*/ && enlistmentOptions !== 1/*EnlistmentOptions.EnlistDuringPrepareRequired*/)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("enlistmentOptions");
                }
                if (this._complete)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateTransactionCompletedException(this.DistributedTxId);
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        /*Enlistment*/ let enlistment = this._internalTransaction.State.EnlistVolatile(this._internalTransaction, enlistmentNotification, enlistmentOptions, this);
                        if (etwLog.IsEnabled())
                        {
                            etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "EnlistVolatile");
                        }
                        return enlistment;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                }
            }
            /*Enlistment */ EnlistVolatile$1(/*ISinglePhaseNotification*/ singlePhaseNotification, /*EnlistmentOptions*/ enlistmentOptions)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "EnlistVolatile");
                }
                $.$spc.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                $.$spc.System.ArgumentNullException.ThrowIfNull(singlePhaseNotification, "singlePhaseNotification");
                if (enlistmentOptions !== 0/*EnlistmentOptions.None*/ && enlistmentOptions !== 1/*EnlistmentOptions.EnlistDuringPrepareRequired*/)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("enlistmentOptions");
                }
                if (this._complete)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateTransactionCompletedException(this.DistributedTxId);
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        /*Enlistment*/ let enlistment = this._internalTransaction.State.EnlistVolatile$1(this._internalTransaction, singlePhaseNotification, enlistmentOptions, this);
                        if (etwLog.IsEnabled())
                        {
                            etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "EnlistVolatile");
                        }
                        return enlistment;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                }
            }
            /*Transaction */ Clone()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "Clone");
                }
                $.$spc.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                if (this._complete)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateTransactionCompletedException(this.DistributedTxId);
                }
                /*Transaction*/ let clone = this.InternalClone();
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "Clone");
                }
                return clone;
            }
            /*Transaction */ InternalClone()
            {
                /*Transaction*/ let clone = new $.$stl.System.Transactions.Transaction().$ctor$2(this._isoLevel, this._internalTransaction);
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionCloneCreate(clone, "Transaction");
                }
                return clone;
            }
            /*DependentTransaction */ DependentClone(/*DependentCloneOption*/ cloneOption)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "DependentClone");
                }
                if (cloneOption !== 0/*DependentCloneOption.BlockCommitUntilComplete*/ && cloneOption !== 1/*DependentCloneOption.RollbackIfNotComplete*/)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("cloneOption");
                }
                $.$spc.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                if (this._complete)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateTransactionCompletedException(this.DistributedTxId);
                }
                /*DependentTransaction*/ let clone = new $.$stl.System.Transactions.DependentTransaction().$ctor$5(this._isoLevel, this._internalTransaction, cloneOption === 0/*DependentCloneOption.BlockCommitUntilComplete*/);
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionCloneCreate(clone, "DependentTransaction");
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "DependentClone");
                }
                return clone;
            }
            /*TransactionTraceIdentifier */ get TransactionTraceId()
            {
                if ($.$stl.System.Transactions.TransactionTraceIdentifier.op_Equality(this._traceIdentifier, $.$stl.System.Transactions.TransactionTraceIdentifier.Empty))
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                        {
                            if ($.$stl.System.Transactions.TransactionTraceIdentifier.op_Equality(this._traceIdentifier, $.$stl.System.Transactions.TransactionTraceIdentifier.Empty))
                            {
                                /*TransactionTraceIdentifier*/ let temp = new $.$stl.System.Transactions.TransactionTraceIdentifier().$ctor$2(this._internalTransaction.TransactionTraceId.TransactionIdentifier, this._cloneId);
                                $.$spc.System.Threading.Interlocked.MemoryBarrier();
                                this._traceIdentifier = temp;
                            }
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                    }
                }
                return this._traceIdentifier;
            }
            /*TransactionCompletedEventHandler?*/ add_TransactionCompleted(value)
            {
                $.$spc.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        this._internalTransaction.State.AddOutcomeRegistrant(this._internalTransaction, value);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                }
            }
            /*TransactionCompletedEventHandler?*/ remove_TransactionCompleted(value)
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                    {
                        this._internalTransaction._transactionCompletedDelegate = $.$cast($.$spc.System.Delegate.Remove(this._internalTransaction._transactionCompletedDelegate, value), $.$stl.System.Transactions.TransactionCompletedEventHandler);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                }
            }
            /*void */ Dispose()
            {
                this.InternalDispose();
            }
            /*void */ InternalDispose()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "InternalDispose");
                }
                if ($.$spc.System.Threading.Interlocked.Exchange($.$ref(() => this._disposed, ($v) => this._disposed = $v, $.$spc.System.Int32), 1/*Transaction._disposedTrueValue*/) === 1/*Transaction._disposedTrueValue*/)
                {
                    return;
                }
                /*long*/ let remainingITx = BigInt($.$spc.System.Threading.Interlocked.Decrement($.$ref(() => this._internalTransaction._cloneCount, ($v) => this._internalTransaction._cloneCount = $v, $.$spc.System.Int32)));
                if (remainingITx === 0n)
                {
                    this._internalTransaction.Dispose();
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "InternalDispose");
                }
            }
            /*void */ System$Runtime$Serialization$ISerializable$GetObjectData(/*SerializationInfo*/ serializationInfo, /*StreamingContext*/ context)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ EnlistPromotableSinglePhase(/*IPromotableSinglePhaseNotification*/ promotableSinglePhaseNotification)
            {
                return this.EnlistPromotableSinglePhase$1(promotableSinglePhaseNotification, $.$stl.System.Transactions.TransactionInterop.PromoterTypeDtc);
            }
            /*bool */ EnlistPromotableSinglePhase$1(/*IPromotableSinglePhaseNotification*/ promotableSinglePhaseNotification, /*Guid*/ promoterType)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "EnlistPromotableSinglePhase");
                }
                $.$spc.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                $.$spc.System.ArgumentNullException.ThrowIfNull(promotableSinglePhaseNotification, "promotableSinglePhaseNotification");
                if ($.$spc.System.Guid.op_Equality(promoterType, $.$spc.System.Guid.Empty))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$stl.System.SR.PromoterTypeInvalid, "promoterType");
                }
                if (this._complete)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateTransactionCompletedException(this.DistributedTxId);
                }
                /*bool*/ let succeeded = false;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        succeeded = this._internalTransaction.State.EnlistPromotableSinglePhase(this._internalTransaction, promotableSinglePhaseNotification, this, promoterType);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "EnlistPromotableSinglePhase");
                }
                return succeeded;
            }
            /*Enlistment */ PromoteAndEnlistDurable(/*Guid*/ resourceManagerIdentifier, /*IPromotableSinglePhaseNotification*/ promotableNotification, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(2/*TraceSourceType.TraceSourceOleTx*/, this, "PromoteAndEnlistDurable");
                }
                $.$spc.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                if ($.$spc.System.Guid.op_Equality(resourceManagerIdentifier, $.$spc.System.Guid.Empty))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$stl.System.SR.BadResourceManagerId, "resourceManagerIdentifier");
                }
                $.$spc.System.ArgumentNullException.ThrowIfNull(promotableNotification, "promotableNotification");
                $.$spc.System.ArgumentNullException.ThrowIfNull(enlistmentNotification, "enlistmentNotification");
                if (enlistmentOptions !== 0/*EnlistmentOptions.None*/ && enlistmentOptions !== 1/*EnlistmentOptions.EnlistDuringPrepareRequired*/)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("enlistmentOptions");
                }
                if (this._complete)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateTransactionCompletedException(this.DistributedTxId);
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        /*Enlistment*/ let enlistment = this._internalTransaction.State.PromoteAndEnlistDurable(this._internalTransaction, resourceManagerIdentifier, promotableNotification, enlistmentNotification, enlistmentOptions, this);
                        if (etwLog.IsEnabled())
                        {
                            etwLog.MethodExit(2/*TraceSourceType.TraceSourceOleTx*/, this, "PromoteAndEnlistDurable");
                        }
                        return enlistment;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                }
            }
            /*void */ SetDistributedTransactionIdentifier(/*IPromotableSinglePhaseNotification*/ promotableNotification, /*Guid*/ distributedTransactionIdentifier)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "SetDistributedTransactionIdentifier");
                }
                $.$spc.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                $.$spc.System.ArgumentNullException.ThrowIfNull(promotableNotification, "promotableNotification");
                if ($.$spc.System.Guid.op_Equality(distributedTransactionIdentifier, $.$spc.System.Guid.Empty))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13(null, "distributedTransactionIdentifier");
                }
                if (this._complete)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateTransactionCompletedException(this.DistributedTxId);
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        this._internalTransaction.State.SetDistributedTransactionId(this._internalTransaction, promotableNotification, distributedTransactionIdentifier);
                        if (etwLog.IsEnabled())
                        {
                            etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "SetDistributedTransactionIdentifier");
                        }
                        return;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                }
            }
            /*OletxTransaction? */ Promote()
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        this._internalTransaction.ThrowIfPromoterTypeIsNotMSDTC();
                        this._internalTransaction.State.Promote(this._internalTransaction);
                        return this._internalTransaction.PromotedTransaction;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                }
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this._internalTransaction = null;
                this._traceIdentifier = $.$default($.$stl.System.Transactions.TransactionTraceIdentifier);
            }
            static $h = 4307500;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":4307500,"g":{"r":0,"d":0,"h":25774111276,"f":33},"s":{"r":0,"d":0,"h":30069078572,"f":33},"n":"Current","d":4307500,"h":21479143980,"f":33},{"p":262145,"g":{"r":0,"d":0,"h":60133849644,"f":8},"n":"Disposed","d":4307500,"h":55838882348,"f":8},{"p":56164353,"g":{"r":0,"d":0,"h":68723784236,"f":8},"n":"DistributedTxId","d":4307500,"h":64428816940,"f":8},{"p":4766252,"g":{"r":0,"d":0,"h":120263391788,"f":1},"n":"TransactionInformation","d":4307500,"h":115968424492,"f":1},{"p":3193388,"g":{"r":0,"d":0,"h":128853326380,"f":1},"n":"IsolationLevel","d":4307500,"h":124558359084,"f":1},{"p":56164353,"g":{"r":0,"d":0,"h":137443260972,"f":1},"n":"PromoterType","d":4307500,"h":133148293676,"f":1},{"p":8567340,"g":{"r":0,"d":0,"h":188982868524,"f":8},"n":"TransactionTraceId","d":4307500,"h":184687901228,"f":8}],"m":[{"r":262145,"n":"UseServiceDomainForCurrent","d":4307500,"h":4299274796,"f":40},{"r":2275884,"p":[{"n":"currentScope","p":5159468}],"n":"InteropMode","d":4307500,"h":8594242092,"f":40},{"r":4307500,"p":[{"n":"currentScope","p":5159468},{"n":"contextData","p":899628},{"n":"contextTransaction","p":4307500,"f":2}],"n":"FastGetTransaction","d":4307500,"h":12889209388,"f":40},{"r":65537,"p":[{"n":"defaultLookup","p":8632876},{"n":"current","p":4307500,"f":2},{"n":"currentScope","p":5159468,"f":2},{"n":"contextTransaction","p":4307500,"f":2}],"n":"GetCurrentTransactionAndScope","d":4307500,"h":17184176684,"f":40},{"r":655361,"n":"GetHashCode","d":4307500,"h":98788555308,"f":32769},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":4307500,"h":103083522604,"f":32769},{"r":0,"n":"GetPromotedToken","d":4307500,"h":141738228268,"f":1},{"r":1751596,"p":[{"n":"resourceManagerIdentifier","p":56164353},{"n":"enlistmentNotification","p":2603564},{"n":"enlistmentOptions","p":1882668}],"n":"EnlistDurable","d":4307500,"h":146033195564,"f":1},{"r":1751596,"p":[{"n":"resourceManagerIdentifier","p":56164353},{"n":"singlePhaseNotification","p":3062316},{"n":"enlistmentOptions","p":1882668}],"n":"EnlistDurable","o":"@$1","d":4307500,"h":150328162860,"f":1},{"r":65537,"n":"Rollback","d":4307500,"h":154623130156,"f":1},{"r":65537,"p":[{"n":"e","p":47185921}],"n":"Rollback","o":"@$1","d":4307500,"h":158918097452,"f":1},{"r":1751596,"p":[{"n":"enlistmentNotification","p":2603564},{"n":"enlistmentOptions","p":1882668}],"n":"EnlistVolatile","d":4307500,"h":163213064748,"f":1},{"r":1751596,"p":[{"n":"singlePhaseNotification","p":3062316},{"n":"enlistmentOptions","p":1882668}],"n":"EnlistVolatile","o":"@$1","d":4307500,"h":167508032044,"f":1},{"r":4307500,"n":"Clone","d":4307500,"h":171802999340,"f":1},{"r":4307500,"n":"InternalClone","d":4307500,"h":176097966636,"f":8},{"r":1161772,"p":[{"n":"cloneOption","p":1096236}],"n":"DependentClone","d":4307500,"h":180392933932,"f":1},{"r":65537,"n":"Dispose","d":4307500,"h":206162737708,"f":1},{"r":65537,"n":"InternalDispose","d":4307500,"h":210457705004,"f":136},{"r":262145,"p":[{"n":"promotableSinglePhaseNotification","p":2865708}],"n":"EnlistPromotableSinglePhase","d":4307500,"h":219047639596,"f":1},{"r":262145,"p":[{"n":"promotableSinglePhaseNotification","p":2865708},{"n":"promoterType","p":56164353}],"n":"EnlistPromotableSinglePhase","o":"@$1","d":4307500,"h":223342606892,"f":1},{"r":1751596,"p":[{"n":"resourceManagerIdentifier","p":56164353},{"n":"promotableNotification","p":2865708},{"n":"enlistmentNotification","p":3062316},{"n":"enlistmentOptions","p":1882668}],"n":"PromoteAndEnlistDurable","d":4307500,"h":227637574188,"f":1},{"r":65537,"p":[{"n":"promotableNotification","p":2865708},{"n":"distributedTransactionIdentifier","p":56164353}],"n":"SetDistributedTransactionIdentifier","d":4307500,"h":231932541484,"f":1},{"r":3521068,"n":"Promote","d":4307500,"h":236227508780,"f":8}],"l":[{"t":3193388,"n":"_isoLevel","d":4307500,"h":34364045868,"f":8},{"t":262145,"n":"_complete","d":4307500,"h":38659013164,"f":8},{"t":655361,"n":"_cloneId","d":4307500,"h":42953980460,"f":8},{"t":655361,"n":"_disposedTrueValue","d":4307500,"h":47248947756,"f":40},{"t":655361,"n":"_disposed","d":4307500,"h":51543915052,"f":8},{"t":2800172,"n":"_internalTransaction","d":4307500,"h":73018751532,"f":8},{"t":8567340,"n":"_traceIdentifier","d":4307500,"h":77313718828,"f":8}],"c":[{"n":".ctor","o":"$ctor$1","d":4307500,"h":81608686124,"f":2},{"p":[{"n":"isoLevel","p":3193388},{"n":"internalTransaction","p":2800172}],"n":".ctor","o":"$ctor$2","d":4307500,"h":85903653420,"f":8},{"p":[{"n":"distributedTransaction","p":3521068}],"n":".ctor","o":"$ctor$3","d":4307500,"h":90198620716,"f":8},{"p":[{"n":"isoLevel","p":3193388},{"n":"superior","p":2996780}],"n":".ctor","o":"$ctor$4","d":4307500,"h":94493588012,"f":8}],"e":[{"e":4438572,"m":{"r":65537,"p":[{"n":"value","p":4438572}],"n":"add_TransactionCompleted","d":4307500,"h":197572803116,"f":1},"r":{"r":65537,"p":[{"n":"value","p":4438572}],"n":"remove_TransactionCompleted","d":4307500,"h":201867770412,"f":1},"n":"TransactionCompleted","d":4307500,"h":193277835820,"f":1}],"i":[57475073,113377281],"h":4307500}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Transactions.Transaction`; }
        });
        
        $asm.$cls("$stl.System.Transactions.EnlistmentStatePromoted", ($self) => class EnlistmentStatePromoted extends $.$stl.System.Transactions.EnlistmentState
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                enlistment.State = this;
            }
            /*void */ EnlistmentDone(/*InternalEnlistment*/ enlistment)
            {
                $.$spc.System.Threading.Monitor.Exit(enlistment.SyncRoot);
                try
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.PromotedEnlistment !== null, "enlistment.PromotedEnlistment != null");
                    enlistment.PromotedEnlistment.System$Transactions$IPromotedEnlistment$EnlistmentDone();
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(enlistment.SyncRoot);
                    }
                }
            }
            /*void */ Prepared(/*InternalEnlistment*/ enlistment)
            {
                $.$spc.System.Threading.Monitor.Exit(enlistment.SyncRoot);
                try
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.PromotedEnlistment !== null, "enlistment.PromotedEnlistment != null");
                    enlistment.PromotedEnlistment.System$Transactions$IPromotedEnlistment$Prepared();
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(enlistment.SyncRoot);
                    }
                }
            }
            /*void */ ForceRollback(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
                $.$spc.System.Threading.Monitor.Exit(enlistment.SyncRoot);
                try
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.PromotedEnlistment !== null, "enlistment.PromotedEnlistment != null");
                    enlistment.PromotedEnlistment.System$Transactions$IPromotedEnlistment$ForceRollback$1(e);
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(enlistment.SyncRoot);
                    }
                }
            }
            /*void */ Committed(/*InternalEnlistment*/ enlistment)
            {
                $.$spc.System.Threading.Monitor.Exit(enlistment.SyncRoot);
                try
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.PromotedEnlistment !== null, "enlistment.PromotedEnlistment != null");
                    enlistment.PromotedEnlistment.System$Transactions$IPromotedEnlistment$Committed();
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(enlistment.SyncRoot);
                    }
                }
            }
            /*void */ Aborted(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
                $.$spc.System.Threading.Monitor.Exit(enlistment.SyncRoot);
                try
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.PromotedEnlistment !== null, "enlistment.PromotedEnlistment != null");
                    enlistment.PromotedEnlistment.System$Transactions$IPromotedEnlistment$Aborted$1(e);
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(enlistment.SyncRoot);
                    }
                }
            }
            /*void */ InDoubt(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
                $.$spc.System.Threading.Monitor.Exit(enlistment.SyncRoot);
                try
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.PromotedEnlistment !== null, "enlistment.PromotedEnlistment != null");
                    enlistment.PromotedEnlistment.System$Transactions$IPromotedEnlistment$InDoubt$1(e);
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(enlistment.SyncRoot);
                    }
                }
            }
            /*byte[] */ RecoveryInformation(/*InternalEnlistment*/ enlistment)
            {
                $.$spc.System.Threading.Monitor.Exit(enlistment.SyncRoot);
                try
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.PromotedEnlistment !== null, "enlistment.PromotedEnlistment != null");
                    return enlistment.PromotedEnlistment.System$Transactions$IPromotedEnlistment$GetRecoveryInformation();
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(enlistment.SyncRoot);
                    }
                }
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 2013740;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1948204,"m":[{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"EnterState","d":2013740,"h":4296981036,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"EnlistmentDone","d":2013740,"h":8591948332,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"Prepared","d":2013740,"h":12886915628,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2734636},{"n":"e","p":47185921}],"n":"ForceRollback","d":2013740,"h":17181882924,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"Committed","d":2013740,"h":21476850220,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2734636},{"n":"e","p":47185921}],"n":"Aborted","d":2013740,"h":25771817516,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2734636},{"n":"e","p":47185921}],"n":"InDoubt","d":2013740,"h":30066784812,"f":32776},{"r":0,"p":[{"n":"enlistment","p":2734636}],"n":"RecoveryInformation","d":2013740,"h":34361752108,"f":32776}],"c":[{"n":".ctor","o":"$ctor$2","d":2013740,"h":38656719404,"f":1}],"h":2013740}; }
            static get $b() { return $.$stl.System.Transactions.EnlistmentState; }
            static get $fullName() { return `System.Transactions.EnlistmentStatePromoted`; }
        });
        
        $asm.$str("$stl.System.Transactions.VolatileEnlistmentSet", ($self) => class VolatileEnlistmentSet extends $.$spc.System.ValueType
        {
            /*InternalEnlistment[]*/  get _volatileEnlistments() { return this.$getField(0, 4); }
            /*InternalEnlistment[]*/  set _volatileEnlistments(value) { this.$setField(0, 4, value); }
            /*int*/  get _volatileEnlistmentCount() { return this.$getField(4, 4); }
            /*int*/  set _volatileEnlistmentCount(value) { this.$setField(4, 4, value); }
            /*int*/  get _volatileEnlistmentSize() { return this.$getField(8, 4); }
            /*int*/  set _volatileEnlistmentSize(value) { this.$setField(8, 4, value); }
            /*int*/  get _dependentClones() { return this.$getField(12, 4); }
            /*int*/  set _dependentClones(value) { this.$setField(12, 4, value); }
            /*int*/  get _preparedVolatileEnlistments() { return this.$getField(16, 4); }
            /*int*/  set _preparedVolatileEnlistments(value) { this.$setField(16, 4, value); }
            /*VolatileDemultiplexer*/  get _volatileDemux() { return this.$getField(20, 4); }
            /*VolatileDemultiplexer*/  set _volatileDemux(value) { this.$setField(20, 4, value); }
            /*VolatileDemultiplexer */ get VolatileDemux()
            {
                return this._volatileDemux;
            }
            /*VolatileDemultiplexer */ set VolatileDemux(value)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._volatileDemux === null, "volatileDemux can only be set once.");
                this._volatileDemux = value;
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._volatileEnlistments = this._volatileEnlistments;
                copy._volatileEnlistmentCount = this._volatileEnlistmentCount;
                copy._volatileEnlistmentSize = this._volatileEnlistmentSize;
                copy._dependentClones = this._dependentClones;
                copy._preparedVolatileEnlistments = this._preparedVolatileEnlistments;
                copy._volatileDemux = this._volatileDemux;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._volatileEnlistments = null;
                this._volatileEnlistmentCount = 0;
                this._volatileEnlistmentSize = 0;
                this._dependentClones = 0;
                this._preparedVolatileEnlistments = 0;
                this._volatileDemux = null;
            }
            static $h = 9353772;
            static $z = 24;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":8698412,"g":{"r":0,"d":0,"h":34369092140,"f":8},"s":{"r":0,"d":0,"h":38664059436,"f":8},"n":"VolatileDemux","d":9353772,"h":30074124844,"f":8}],"l":[{"t":0,"n":"_volatileEnlistments","d":9353772,"h":4304321068,"f":8},{"t":655361,"n":"_volatileEnlistmentCount","d":9353772,"h":8599288364,"f":8},{"t":655361,"n":"_volatileEnlistmentSize","d":9353772,"h":12894255660,"f":8},{"t":655361,"n":"_dependentClones","d":9353772,"h":17189222956,"f":8},{"t":655361,"n":"_preparedVolatileEnlistments","d":9353772,"h":21484190252,"f":8},{"t":8698412,"n":"_volatileDemux","d":9353772,"h":25779157548,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":9353772,"h":42959026732,"f":1}],"h":9353772}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Transactions.VolatileEnlistmentSet`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePSPEOperation", ($self) => class TransactionStatePSPEOperation extends $.$stl.System.Transactions.TransactionState
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                throw new $.$spc.System.InvalidOperationException().$ctor$9();
            }
            /*TransactionStatus */ get_Status(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ PSPEInitialize(/*InternalTransaction*/ tx, /*IPromotableSinglePhaseNotification*/ promotableSinglePhaseNotification, /*Guid*/ promoterType)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(tx.State === $.$stl.System.Transactions.TransactionState.TransactionStateActive, "PSPEPromote called from state other than TransactionStateActive");
                this.CommonEnterState(tx);
                try
                {
                    promotableSinglePhaseNotification.System$Transactions$IPromotableSinglePhaseNotification$Initialize();
                    tx._promoterType = promoterType;
                }
                finally
                {
                    {
                        $.$stl.System.Transactions.TransactionState.TransactionStateActive.CommonEnterState(tx);
                    }
                }
            }
            /*void */ Phase0PSPEInitialize(/*InternalTransaction*/ tx, /*IPromotableSinglePhaseNotification*/ promotableSinglePhaseNotification, /*Guid*/ promoterType)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(tx.State === $.$stl.System.Transactions.TransactionState.TransactionStatePhase0, "Phase0PSPEInitialize called from state other than TransactionStatePhase0");
                this.CommonEnterState(tx);
                try
                {
                    promotableSinglePhaseNotification.System$Transactions$IPromotableSinglePhaseNotification$Initialize();
                    tx._promoterType = promoterType;
                }
                finally
                {
                    {
                        $.$stl.System.Transactions.TransactionState.TransactionStatePhase0.CommonEnterState(tx);
                    }
                }
            }
            /*Oletx.OletxTransaction? */ PSPEPromote(/*InternalTransaction*/ tx)
            {
                /*bool*/ let changeToReturnState = true;
                /*TransactionState?*/ let returnState = tx.State;
                $.$spc.System.Diagnostics.Debug.Assert$1(returnState === $.$stl.System.Transactions.TransactionState.TransactionStateDelegated || returnState === $.$stl.System.Transactions.TransactionState.TransactionStateDelegatedSubordinate || returnState === $.$stl.System.Transactions.TransactionState.TransactionStateDelegatedNonMSDTC, "PSPEPromote called from state other than TransactionStateDelegated[NonMSDTC]");
                this.CommonEnterState(tx);
                /*Oletx.OletxTransaction?*/ let distributedTx = null;
                try
                {
                    if (tx._attemptingPSPEPromote)
                    {
                        throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException$1(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.PromotedReturnedInvalidValue, null, tx.DistributedTxId);
                    }
                    tx._attemptingPSPEPromote = true;
                    $.$spc.System.Diagnostics.Debug.Assert$1(tx._promoter !== null, "tx._promoter != null");
                    /*byte[]?*/ let propagationToken = tx._promoter.System$Transactions$ITransactionPromoter$Promote();
                    if ($.$spc.System.Guid.op_Inequality(tx._promoterType, $.$stl.System.Transactions.TransactionInterop.PromoterTypeDtc))
                    {
                        if (propagationToken === null)
                        {
                            throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException$1(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.PromotedReturnedInvalidValue, null, tx.DistributedTxId);
                        }
                        tx.promotedToken = propagationToken;
                        return null;
                    }
                    if (propagationToken === null)
                    {
                        if (tx.PromotedTransaction === null)
                        {
                            throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException$1(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.PromotedReturnedInvalidValue, null, tx.DistributedTxId);
                        }
                        changeToReturnState = false;
                        distributedTx = tx.PromotedTransaction;
                    }
                    if (distributedTx === null)
                    {
                        try
                        {
                            distributedTx = $.$stl.System.Transactions.TransactionInterop.GetOletxTransactionFromTransmitterPropagationToken(propagationToken);
                        }
                        catch(e)
                        {
                            throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException$1(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.PromotedReturnedInvalidValue, e, tx.DistributedTxId);
                        }
                        if ($.$stl.System.Transactions.Transaction.op_Inequality($.$stl.System.Transactions.TransactionManager.FindPromotedTransaction(distributedTx.Identifier), null))
                        {
                            throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException$1(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.PromotedTransactionExists, null, tx.DistributedTxId);
                        }
                    }
                }
                finally
                {
                    {
                        tx._attemptingPSPEPromote = false;
                        if (changeToReturnState)
                        {
                            returnState.CommonEnterState(tx);
                        }
                    }
                }
                return distributedTx;
            }
            /*Enlistment */ PromoteAndEnlistDurable(/*InternalTransaction*/ tx, /*Guid*/ resourceManagerIdentifier, /*IPromotableSinglePhaseNotification*/ promotableNotification, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                if (!tx._attemptingPSPEPromote)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
                }
                if (promotableNotification !== tx._promoter)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException$1(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.InvalidIPromotableSinglePhaseNotificationSpecified, null, tx.DistributedTxId);
                }
                /*Enlistment*/ let enlistment;
                tx._durableEnlistment = null;
                tx._promoteState = $.$stl.System.Transactions.TransactionState.TransactionStatePromoted;
                tx._promoteState.EnterState(tx);
                enlistment = tx.State.EnlistDurable$1(tx, resourceManagerIdentifier, enlistmentNotification, enlistmentOptions, atomicTransaction);
                tx._durableEnlistment = enlistment.InternalEnlistment;
                return enlistment;
            }
            /*void */ SetDistributedTransactionId(/*InternalTransaction*/ tx, /*IPromotableSinglePhaseNotification*/ promotableNotification, /*Guid*/ distributedTransactionIdentifier)
            {
                if (!tx._attemptingPSPEPromote)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
                }
                if (promotableNotification !== tx._promoter)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException$1(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.InvalidIPromotableSinglePhaseNotificationSpecified, null, tx.DistributedTxId);
                }
                tx._distributedTransactionIdentifierNonMSDTC = distributedTransactionIdentifier;
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 8108588;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":5749292,"m":[{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"EnterState","d":8108588,"h":4303075884,"f":32776},{"r":8436268,"p":[{"n":"tx","p":2800172}],"n":"get_Status","d":8108588,"h":8598043180,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"promotableSinglePhaseNotification","p":2865708},{"n":"promoterType","p":56164353}],"n":"PSPEInitialize","d":8108588,"h":12893010476,"f":8},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"promotableSinglePhaseNotification","p":2865708},{"n":"promoterType","p":56164353}],"n":"Phase0PSPEInitialize","d":8108588,"h":17187977772,"f":8},{"r":3521068,"p":[{"n":"tx","p":2800172}],"n":"PSPEPromote","d":8108588,"h":21482945068,"f":8},{"r":1751596,"p":[{"n":"tx","p":2800172},{"n":"resourceManagerIdentifier","p":56164353},{"n":"promotableNotification","p":2865708},{"n":"enlistmentNotification","p":3062316},{"n":"enlistmentOptions","p":1882668},{"n":"atomicTransaction","p":4307500}],"n":"PromoteAndEnlistDurable","d":8108588,"h":25777912364,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"promotableNotification","p":2865708},{"n":"distributedTransactionIdentifier","p":56164353}],"n":"SetDistributedTransactionId","d":8108588,"h":30072879660,"f":32776}],"c":[{"n":".ctor","o":"$ctor$2","d":8108588,"h":34367846956,"f":1}],"h":8108588}; }
            static get $b() { return $.$stl.System.Transactions.TransactionState; }
            static get $fullName() { return `System.Transactions.TransactionStatePSPEOperation`; }
        });
        
        $asm.$str("$stl.System.Transactions.EnlistmentTraceIdentifier", ($self) => class EnlistmentTraceIdentifier extends $.$spc.System.ValueType
        {
            static /*EnlistmentTraceIdentifier */ get Empty()
            {
                return new $.$stl.System.Transactions.EnlistmentTraceIdentifier();
            }
            $ctor$2(/*Guid*/ resourceManagerIdentifier, /*TransactionTraceIdentifier*/ transactionTraceId, /*int*/ enlistmentIdentifier)
            {
                super.$ctor$1();
                {
                    this._resourceManagerIdentifier = resourceManagerIdentifier;
                    this._transactionTraceIdentifier = transactionTraceId;
                    this._enlistmentIdentifier = enlistmentIdentifier;
                }
                return this;
            }
            /*Guid*/  get _resourceManagerIdentifier() { return this.$getField(0, 16); }
            /*Guid*/  set _resourceManagerIdentifier(value) { this.$setField(0, 16, value); }
            /*Guid */ get ResourceManagerIdentifier()
            {
                return this._resourceManagerIdentifier;
            }
            /*TransactionTraceIdentifier*/  get _transactionTraceIdentifier() { return this.$getField(16, 8); }
            /*TransactionTraceIdentifier*/  set _transactionTraceIdentifier(value) { this.$setField(16, 8, value); }
            /*TransactionTraceIdentifier */ get TransactionTraceId()
            {
                return this._transactionTraceIdentifier;
            }
            /*int*/  get _enlistmentIdentifier() { return this.$getField(24, 4); }
            /*int*/  set _enlistmentIdentifier(value) { this.$setField(24, 4, value); }
            /*int */ get EnlistmentIdentifier()
            {
                return this._enlistmentIdentifier;
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$spc.System.ValueType.GetHashCode.call(this);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$stl.System.Transactions.EnlistmentTraceIdentifier.GetHashCode.apply(this, arguments); }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                let enlistmentTraceId;
                return $.$is(obj, $.$stl.System.Transactions.EnlistmentTraceIdentifier, { set $v(v){ enlistmentTraceId = v; } }) && this.Equals$2(enlistmentTraceId);
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$stl.System.Transactions.EnlistmentTraceIdentifier.Equals.apply(this, arguments); }
            /*bool */ Equals$2(/*EnlistmentTraceIdentifier*/ other)
            {
                return this._enlistmentIdentifier === other._enlistmentIdentifier && $.$spc.System.Guid.op_Equality(this._resourceManagerIdentifier, other._resourceManagerIdentifier) && $.$stl.System.Transactions.TransactionTraceIdentifier.op_Equality(this._transactionTraceIdentifier, other._transactionTraceIdentifier);
            }
            static /*bool */ op_Equality(/*EnlistmentTraceIdentifier*/ left, /*EnlistmentTraceIdentifier*/ right)
            {
                return left.Equals$2(right);
            }
            static /*bool */ op_Inequality(/*EnlistmentTraceIdentifier*/ left, /*EnlistmentTraceIdentifier*/ right)
            {
                return !left.Equals$2(right);
            }
            //Generated interface implemetation for System.IEquatable<System.Transactions.EnlistmentTraceIdentifier>.Equals(System.Transactions.EnlistmentTraceIdentifier)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._resourceManagerIdentifier = this._resourceManagerIdentifier.Clone();
                copy._transactionTraceIdentifier = this._transactionTraceIdentifier.Clone();
                copy._enlistmentIdentifier = this._enlistmentIdentifier;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._resourceManagerIdentifier = $.$default($.$spc.System.Guid);
                this._transactionTraceIdentifier = $.$default($.$stl.System.Transactions.TransactionTraceIdentifier);
                this._enlistmentIdentifier = 0;
            }
            static $h = 2079276;
            static $z = 28;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":2079276,"g":{"r":0,"d":0,"h":8592013868,"f":33},"n":"Empty","d":2079276,"h":4297046572,"f":33},{"p":56164353,"g":{"r":0,"d":0,"h":25771883052,"f":1},"n":"ResourceManagerIdentifier","d":2079276,"h":21476915756,"f":1},{"p":8567340,"g":{"r":0,"d":0,"h":38656784940,"f":1},"n":"TransactionTraceId","d":2079276,"h":34361817644,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":51541686828,"f":1},"n":"EnlistmentIdentifier","d":2079276,"h":47246719532,"f":1}],"m":[{"r":655361,"n":"GetHashCode","d":2079276,"h":55836654124,"f":32769},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":2079276,"h":60131621420,"f":32769},{"r":262145,"p":[{"n":"other","p":2079276}],"n":"Equals","o":"@$2","d":2079276,"h":64426588716,"f":1}],"l":[{"t":56164353,"n":"_resourceManagerIdentifier","d":2079276,"h":17181948460,"f":2},{"t":8567340,"n":"_transactionTraceIdentifier","d":2079276,"h":30066850348,"f":2},{"t":655361,"n":"_enlistmentIdentifier","d":2079276,"h":42951752236,"f":2}],"c":[{"p":[{"n":"resourceManagerIdentifier","p":56164353},{"n":"transactionTraceId","p":8567340},{"n":"enlistmentIdentifier","p":655361}],"n":".ctor","o":"$ctor$2","d":2079276,"h":12886981164,"f":1},{"n":".ctor","o":"$ctor$3","d":2079276,"h":77311490604,"f":1}],"i":[$.$spc.System.IEquatable$$($.$stl.System.Transactions.EnlistmentTraceIdentifier).$h],"h":2079276}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$stl.System.Transactions.EnlistmentTraceIdentifier) ]; }
            static get $fullName() { return `System.Transactions.EnlistmentTraceIdentifier`; }
        });
        
        $asm.$str("$stl.System.Transactions.TransactionOptions", ($self) => class TransactionOptions extends $.$spc.System.ValueType
        {
            /*TimeSpan*/  get _timeout() { return this.$getField(0, $.$spc.System.TimeSpan); }
            /*TimeSpan*/  set _timeout(value) { this.$setField(0, $.$spc.System.TimeSpan, value); }
            /*IsolationLevel*/  get _isolationLevel() { return this.$getField(8, $.$stl.System.Transactions.IsolationLevel); }
            /*IsolationLevel*/  set _isolationLevel(value) { this.$setField(8, $.$stl.System.Transactions.IsolationLevel, value); }
            /*TimeSpan */ get Timeout()
            {
                return this._timeout;
            }
            /*TimeSpan */ set Timeout(value)
            {
                this._timeout = value;
            }
            /*IsolationLevel */ get IsolationLevel()
            {
                return this._isolationLevel;
            }
            /*IsolationLevel */ set IsolationLevel(value)
            {
                this._isolationLevel = value;
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$spc.System.ValueType.GetHashCode.call(this);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$stl.System.Transactions.TransactionOptions.GetHashCode.apply(this, arguments); }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                let transactionOptions;
                return $.$is(obj, $.$stl.System.Transactions.TransactionOptions, { set $v(v){ transactionOptions = v; } }) && this.Equals$2(transactionOptions.Clone());
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$stl.System.Transactions.TransactionOptions.Equals.apply(this, arguments); }
            /*bool */ Equals$2(/*TransactionOptions*/ other)
            {
                return $.$spc.System.TimeSpan.op_Equality(this._timeout, other._timeout) && this._isolationLevel === other._isolationLevel;
            }
            static /*bool */ op_Equality(/*TransactionOptions*/ x, /*TransactionOptions*/ y)
            {
                return x.Equals$2(y.Clone());
            }
            static /*bool */ op_Inequality(/*TransactionOptions*/ x, /*TransactionOptions*/ y)
            {
                return !x.Equals$2(y.Clone());
            }
            //Generated interface implemetation for System.IEquatable<System.Transactions.TransactionOptions>.Equals(System.Transactions.TransactionOptions)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._timeout = this._timeout.Clone();
                copy._isolationLevel = this._isolationLevel;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._timeout = $.$default($.$spc.System.TimeSpan);
                this._isolationLevel = 0;
            }
            static $h = 5028396;
            static $z = 12;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":140705793,"g":{"r":0,"d":0,"h":17184897580,"f":1},"s":{"r":0,"d":0,"h":21479864876,"f":1},"n":"Timeout","d":5028396,"h":12889930284,"f":1},{"p":3193388,"g":{"r":0,"d":0,"h":30069799468,"f":1},"s":{"r":0,"d":0,"h":34364766764,"f":1},"n":"IsolationLevel","d":5028396,"h":25774832172,"f":1}],"m":[{"r":655361,"n":"GetHashCode","d":5028396,"h":38659734060,"f":32769},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":5028396,"h":42954701356,"f":32769},{"r":262145,"p":[{"n":"other","p":5028396}],"n":"Equals","o":"@$2","d":5028396,"h":47249668652,"f":1}],"l":[{"t":140705793,"n":"_timeout","d":5028396,"h":4299995692,"f":2},{"t":3193388,"n":"_isolationLevel","d":5028396,"h":8594962988,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":5028396,"h":60134570540,"f":1}],"i":[$.$spc.System.IEquatable$$($.$stl.System.Transactions.TransactionOptions).$h],"h":5028396}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$stl.System.Transactions.TransactionOptions) ]; }
            static get $fullName() { return `System.Transactions.TransactionOptions`; }
        });
        
        $asm.$str("$stl.System.Transactions.TransactionTraceIdentifier", ($self) => class TransactionTraceIdentifier extends $.$spc.System.ValueType
        {
            static /*TransactionTraceIdentifier */ get Empty()
            {
                return new $.$stl.System.Transactions.TransactionTraceIdentifier();
            }
            $ctor$2(/*string*/ transactionIdentifier, /*int*/ cloneIdentifier)
            {
                super.$ctor$1();
                {
                    this._transactionIdentifier = transactionIdentifier;
                    this._cloneIdentifier = cloneIdentifier;
                }
                return this;
            }
            /*string*/  get _transactionIdentifier() { return this.$getField(0, 4); }
            /*string*/  set _transactionIdentifier(value) { this.$setField(0, 4, value); }
            /*string */ get TransactionIdentifier()
            {
                return this._transactionIdentifier;
            }
            /*int*/  get _cloneIdentifier() { return this.$getField(4, 4); }
            /*int*/  set _cloneIdentifier(value) { this.$setField(4, 4, value); }
            /*int */ get CloneIdentifier()
            {
                return this._cloneIdentifier;
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$spc.System.ValueType.GetHashCode.call(this);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$stl.System.Transactions.TransactionTraceIdentifier.GetHashCode.apply(this, arguments); }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                let transactionTraceId;
                return $.$is(obj, $.$stl.System.Transactions.TransactionTraceIdentifier, { set $v(v){ transactionTraceId = v; } }) && this.Equals$2(transactionTraceId);
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$stl.System.Transactions.TransactionTraceIdentifier.Equals.apply(this, arguments); }
            /*bool */ Equals$2(/*TransactionTraceIdentifier*/ other)
            {
                return this._cloneIdentifier === other._cloneIdentifier && $.$spc.System.String.op_Equality(this._transactionIdentifier, other._transactionIdentifier);
            }
            static /*bool */ op_Equality(/*TransactionTraceIdentifier*/ left, /*TransactionTraceIdentifier*/ right)
            {
                return left.Equals$2(right);
            }
            static /*bool */ op_Inequality(/*TransactionTraceIdentifier*/ left, /*TransactionTraceIdentifier*/ right)
            {
                return !left.Equals$2(right);
            }
            //Generated interface implemetation for System.IEquatable<System.Transactions.TransactionTraceIdentifier>.Equals(System.Transactions.TransactionTraceIdentifier)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._transactionIdentifier = this._transactionIdentifier;
                copy._cloneIdentifier = this._cloneIdentifier;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._transactionIdentifier = null;
                this._cloneIdentifier = 0;
            }
            static $h = 8567340;
            static $z = 8;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":8567340,"g":{"r":0,"d":0,"h":8598501932,"f":33},"n":"Empty","d":8567340,"h":4303534636,"f":33},{"p":1310721,"g":{"r":0,"d":0,"h":25778371116,"f":1},"n":"TransactionIdentifier","d":8567340,"h":21483403820,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":38663273004,"f":1},"n":"CloneIdentifier","d":8567340,"h":34368305708,"f":1}],"m":[{"r":655361,"n":"GetHashCode","d":8567340,"h":42958240300,"f":32769},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":8567340,"h":47253207596,"f":32769},{"r":262145,"p":[{"n":"other","p":8567340}],"n":"Equals","o":"@$2","d":8567340,"h":51548174892,"f":1}],"l":[{"t":1310721,"n":"_transactionIdentifier","d":8567340,"h":17188436524,"f":2},{"t":655361,"n":"_cloneIdentifier","d":8567340,"h":30073338412,"f":2}],"c":[{"p":[{"n":"transactionIdentifier","p":1310721},{"n":"cloneIdentifier","p":655361}],"n":".ctor","o":"$ctor$2","d":8567340,"h":12893469228,"f":1},{"n":".ctor","o":"$ctor$3","d":8567340,"h":64433076780,"f":1}],"i":[$.$spc.System.IEquatable$$($.$stl.System.Transactions.TransactionTraceIdentifier).$h],"h":8567340}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$stl.System.Transactions.TransactionTraceIdentifier) ]; }
            static get $fullName() { return `System.Transactions.TransactionTraceIdentifier`; }
        });
        
        $asm.$cls("$stl.System.Transactions.Phase0VolatileDemultiplexer", ($self) => class Phase0VolatileDemultiplexer extends $.$stl.System.Transactions.VolatileDemultiplexer
        {
            $ctor$2(/*InternalTransaction*/ transaction)
            {
                super.$ctor$1(transaction);
                {
                }
                return this;
            }
            /*void */ InternalPrepare()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._promotedEnlistment !== null && this._transaction.State !== null, "_promotedEnlistment != null && _transaction.State != null");
                try
                {
                    this._transaction.State.ChangeStatePromotedPhase0(this._transaction);
                }
                catch($e)
                {
                    if ($e instanceof $.$stl.System.Transactions.TransactionAbortedException)
                    {
                        let e = $e;
                        this._promotedEnlistment.System$Transactions$IPromotedEnlistment$ForceRollback$1(e);
                        /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                        if (etwLog.IsEnabled())
                        {
                            etwLog.ExceptionConsumed$1(e);
                        }
                    }
                    else if ($e instanceof $.$stl.System.Transactions.TransactionInDoubtException)
                    {
                        let e = $e;
                        this._promotedEnlistment.System$Transactions$IPromotedEnlistment$EnlistmentDone();
                        /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                        if (etwLog.IsEnabled())
                        {
                            etwLog.ExceptionConsumed$1(e);
                        }
                    }
                    else
                    {
                        throw $e;
                    }
                }
            }
            /*void */ InternalCommit()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._promotedEnlistment !== null && this._transaction.State !== null, "_promotedEnlistment != null && _transaction.State != null");
                this._promotedEnlistment.System$Transactions$IPromotedEnlistment$EnlistmentDone();
                this._transaction.State.ChangeStatePromotedCommitted(this._transaction);
            }
            /*void */ InternalRollback()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._promotedEnlistment !== null && this._transaction.State !== null, "_promotedEnlistment != null && _transaction.State != null");
                this._promotedEnlistment.System$Transactions$IPromotedEnlistment$EnlistmentDone();
                this._transaction.State.ChangeStatePromotedAborted(this._transaction);
            }
            /*void */ InternalInDoubt()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._transaction.State !== null, "_transaction.State != null");
                this._transaction.State.InDoubtFromDtc(this._transaction);
            }
            /*void */ Prepare(/*IPromotedEnlistment*/ en)
            {
                this._preparingEnlistment = en;
                $.$stl.System.Transactions.VolatileDemultiplexer.PoolablePrepare(this);
            }
            /*void */ Commit(/*IPromotedEnlistment*/ en)
            {
                this._promotedEnlistment = en;
                $.$stl.System.Transactions.VolatileDemultiplexer.PoolableCommit(this);
            }
            /*void */ Rollback(/*IPromotedEnlistment*/ en)
            {
                this._promotedEnlistment = en;
                $.$stl.System.Transactions.VolatileDemultiplexer.PoolableRollback(this);
            }
            /*void */ InDoubt(/*IPromotedEnlistment*/ en)
            {
                this._promotedEnlistment = en;
                $.$stl.System.Transactions.VolatileDemultiplexer.PoolableInDoubt(this);
            }
            static $h = 3717676;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":8698412,"m":[{"r":65537,"n":"InternalPrepare","d":3717676,"h":8593652268,"f":32772},{"r":65537,"n":"InternalCommit","d":3717676,"h":12888619564,"f":32772},{"r":65537,"n":"InternalRollback","d":3717676,"h":17183586860,"f":32772},{"r":65537,"n":"InternalInDoubt","d":3717676,"h":21478554156,"f":32772},{"r":65537,"p":[{"n":"en","p":2931244}],"n":"Prepare","d":3717676,"h":25773521452,"f":32769},{"r":65537,"p":[{"n":"en","p":2931244}],"n":"Commit","d":3717676,"h":30068488748,"f":32769},{"r":65537,"p":[{"n":"en","p":2931244}],"n":"Rollback","d":3717676,"h":34363456044,"f":32769},{"r":65537,"p":[{"n":"en","p":2931244}],"n":"InDoubt","d":3717676,"h":38658423340,"f":32769}],"c":[{"p":[{"n":"transaction","p":2800172}],"n":".ctor","o":"$ctor$2","d":3717676,"h":4298684972,"f":1}],"i":[2669100],"h":3717676}; }
            static get $b() { return $.$stl.System.Transactions.VolatileDemultiplexer; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stl.System.Transactions.IEnlistmentNotificationInternal ]; }
            static get $fullName() { return `System.Transactions.Phase0VolatileDemultiplexer`; }
        });
        
        $asm.$cls("$stl.System.Transactions.Phase1VolatileDemultiplexer", ($self) => class Phase1VolatileDemultiplexer extends $.$stl.System.Transactions.VolatileDemultiplexer
        {
            $ctor$2(/*InternalTransaction*/ transaction)
            {
                super.$ctor$1(transaction);
                {
                }
                return this;
            }
            /*void */ InternalPrepare()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._promotedEnlistment !== null && this._transaction.State !== null, "_promotedEnlistment != null && _transaction.State != null");
                try
                {
                    this._transaction.State.ChangeStatePromotedPhase1(this._transaction);
                }
                catch($e)
                {
                    if ($e instanceof $.$stl.System.Transactions.TransactionAbortedException)
                    {
                        let e = $e;
                        this._promotedEnlistment.System$Transactions$IPromotedEnlistment$ForceRollback$1(e);
                        /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                        if (etwLog.IsEnabled())
                        {
                            etwLog.ExceptionConsumed$1(e);
                        }
                    }
                    else if ($e instanceof $.$stl.System.Transactions.TransactionInDoubtException)
                    {
                        let e = $e;
                        this._promotedEnlistment.System$Transactions$IPromotedEnlistment$EnlistmentDone();
                        /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                        if (etwLog.IsEnabled())
                        {
                            etwLog.ExceptionConsumed$1(e);
                        }
                    }
                    else
                    {
                        throw $e;
                    }
                }
            }
            /*void */ InternalCommit()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._promotedEnlistment !== null && this._transaction.State !== null, "_promotedEnlistment != null && _transaction.State != null");
                this._promotedEnlistment.System$Transactions$IPromotedEnlistment$EnlistmentDone();
                this._transaction.State.ChangeStatePromotedCommitted(this._transaction);
            }
            /*void */ InternalRollback()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._promotedEnlistment !== null && this._transaction.State !== null, "_promotedEnlistment != null && _transaction.State != null");
                this._promotedEnlistment.System$Transactions$IPromotedEnlistment$EnlistmentDone();
                this._transaction.State.ChangeStatePromotedAborted(this._transaction);
            }
            /*void */ InternalInDoubt()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._transaction.State !== null, "_transaction.State != null");
                this._transaction.State.InDoubtFromDtc(this._transaction);
            }
            /*void */ Prepare(/*IPromotedEnlistment*/ en)
            {
                this._preparingEnlistment = en;
                $.$stl.System.Transactions.VolatileDemultiplexer.PoolablePrepare(this);
            }
            /*void */ Commit(/*IPromotedEnlistment*/ en)
            {
                this._promotedEnlistment = en;
                $.$stl.System.Transactions.VolatileDemultiplexer.PoolableCommit(this);
            }
            /*void */ Rollback(/*IPromotedEnlistment*/ en)
            {
                this._promotedEnlistment = en;
                $.$stl.System.Transactions.VolatileDemultiplexer.PoolableRollback(this);
            }
            /*void */ InDoubt(/*IPromotedEnlistment*/ en)
            {
                this._promotedEnlistment = en;
                $.$stl.System.Transactions.VolatileDemultiplexer.PoolableInDoubt(this);
            }
            static $h = 3783212;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":8698412,"m":[{"r":65537,"n":"InternalPrepare","d":3783212,"h":8593717804,"f":32772},{"r":65537,"n":"InternalCommit","d":3783212,"h":12888685100,"f":32772},{"r":65537,"n":"InternalRollback","d":3783212,"h":17183652396,"f":32772},{"r":65537,"n":"InternalInDoubt","d":3783212,"h":21478619692,"f":32772},{"r":65537,"p":[{"n":"en","p":2931244}],"n":"Prepare","d":3783212,"h":25773586988,"f":32769},{"r":65537,"p":[{"n":"en","p":2931244}],"n":"Commit","d":3783212,"h":30068554284,"f":32769},{"r":65537,"p":[{"n":"en","p":2931244}],"n":"Rollback","d":3783212,"h":34363521580,"f":32769},{"r":65537,"p":[{"n":"en","p":2931244}],"n":"InDoubt","d":3783212,"h":38658488876,"f":32769}],"c":[{"p":[{"n":"transaction","p":2800172}],"n":".ctor","o":"$ctor$2","d":3783212,"h":4298750508,"f":1}],"i":[2669100],"h":3783212}; }
            static get $b() { return $.$stl.System.Transactions.VolatileDemultiplexer; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stl.System.Transactions.IEnlistmentNotificationInternal ]; }
            static get $fullName() { return `System.Transactions.Phase1VolatileDemultiplexer`; }
        });
        
        $asm.$cls("$stl.System.Transactions.DurableEnlistmentActive", ($self) => class DurableEnlistmentActive extends $.$stl.System.Transactions.DurableEnlistmentState
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                enlistment.State = this;
            }
            /*void */ EnlistmentDone(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentEnded.EnterState(enlistment);
            }
            /*void */ InternalAborted(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentAborting.EnterState(enlistment);
            }
            /*void */ ChangeStateCommitting(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentCommitting.EnterState(enlistment);
            }
            /*void */ ChangeStatePromoted(/*InternalEnlistment*/ enlistment, /*IPromotedEnlistment*/ promotedEnlistment)
            {
                enlistment.PromotedEnlistment = promotedEnlistment;
                $.$stl.System.Transactions.EnlistmentState.EnlistmentStatePromoted.EnterState(enlistment);
            }
            /*void */ ChangeStateDelegated(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentDelegated.EnterState(enlistment);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 1292844;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1554988,"m":[{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"EnterState","d":1292844,"h":4296260140,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"EnlistmentDone","d":1292844,"h":8591227436,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"InternalAborted","d":1292844,"h":12886194732,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"ChangeStateCommitting","d":1292844,"h":17181162028,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2734636},{"n":"promotedEnlistment","p":2931244}],"n":"ChangeStatePromoted","d":1292844,"h":21476129324,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"ChangeStateDelegated","d":1292844,"h":25771096620,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":1292844,"h":30066063916,"f":1}],"h":1292844}; }
            static get $b() { return $.$stl.System.Transactions.DurableEnlistmentState; }
            static get $fullName() { return `System.Transactions.DurableEnlistmentActive`; }
        });
        
        $asm.$cls("$stl.System.Transactions.DurableEnlistmentAborting", ($self) => class DurableEnlistmentAborting extends $.$stl.System.Transactions.DurableEnlistmentState
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                enlistment.State = this;
                $.$spc.System.Threading.Monitor.Exit(enlistment.Transaction);
                try
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.EnlistmentStatus(1/*TraceSourceType.TraceSourceLtm*/, enlistment.EnlistmentTraceId, 2/*NotificationCall.Rollback*/);
                    }
                    if (enlistment.SinglePhaseNotification !== null)
                    {
                        enlistment.SinglePhaseNotification.System$Transactions$IEnlistmentNotification$Rollback(enlistment.SinglePhaseEnlistment);
                    }
                    else 
                    {
                        enlistment.PromotableSinglePhaseNotification.System$Transactions$IPromotableSinglePhaseNotification$Rollback(enlistment.SinglePhaseEnlistment);
                    }
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(enlistment.Transaction);
                    }
                }
            }
            /*void */ Aborted(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
                enlistment.Transaction._innerException ??= e;
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentEnded.EnterState(enlistment);
            }
            /*void */ EnlistmentDone(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentEnded.EnterState(enlistment);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 1227308;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1554988,"m":[{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"EnterState","d":1227308,"h":4296194604,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2734636},{"n":"e","p":47185921}],"n":"Aborted","d":1227308,"h":8591161900,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"EnlistmentDone","d":1227308,"h":12886129196,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":1227308,"h":17181096492,"f":1}],"h":1227308}; }
            static get $b() { return $.$stl.System.Transactions.DurableEnlistmentState; }
            static get $fullName() { return `System.Transactions.DurableEnlistmentAborting`; }
        });
        
        $asm.$cls("$stl.System.Transactions.DurableEnlistmentCommitting", ($self) => class DurableEnlistmentCommitting extends $.$stl.System.Transactions.DurableEnlistmentState
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                /*bool*/ let spcCommitted = false;
                enlistment.State = this;
                $.$spc.System.Threading.Monitor.Exit(enlistment.Transaction);
                try
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.EnlistmentStatus(1/*TraceSourceType.TraceSourceLtm*/, enlistment.EnlistmentTraceId, 4/*NotificationCall.SinglePhaseCommit*/);
                    }
                    if (enlistment.SinglePhaseNotification !== null)
                    {
                        enlistment.SinglePhaseNotification.System$Transactions$ISinglePhaseNotification$SinglePhaseCommit(enlistment.SinglePhaseEnlistment);
                    }
                    else 
                    {
                        enlistment.PromotableSinglePhaseNotification.System$Transactions$IPromotableSinglePhaseNotification$SinglePhaseCommit(enlistment.SinglePhaseEnlistment);
                    }
                    spcCommitted = true;
                }
                finally
                {
                    {
                        if (!spcCommitted)
                        {
                            enlistment.SinglePhaseEnlistment.InDoubt();
                        }
                        $.$spc.System.Threading.Monitor.Enter(enlistment.Transaction);
                    }
                }
            }
            /*void */ EnlistmentDone(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentEnded.EnterState(enlistment);
                $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.Transaction.State !== null, "enlistment.Transaction.State != null");
                enlistment.Transaction.State.ChangeStateTransactionCommitted(enlistment.Transaction);
            }
            /*void */ Committed(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentEnded.EnterState(enlistment);
                $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.Transaction.State !== null, "enlistment.Transaction.State != null");
                enlistment.Transaction.State.ChangeStateTransactionCommitted(enlistment.Transaction);
            }
            /*void */ Aborted(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentEnded.EnterState(enlistment);
                $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.Transaction.State !== null, "enlistment.Transaction.State != null");
                enlistment.Transaction.State.ChangeStateTransactionAborted(enlistment.Transaction, e);
            }
            /*void */ InDoubt(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentEnded.EnterState(enlistment);
                enlistment.Transaction._innerException ??= e;
                $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.Transaction.State !== null, "enlistment.Transaction.State != null");
                enlistment.Transaction.State.InDoubtFromEnlistment(enlistment.Transaction);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 1358380;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1554988,"m":[{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"EnterState","d":1358380,"h":4296325676,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"EnlistmentDone","d":1358380,"h":8591292972,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"Committed","d":1358380,"h":12886260268,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2734636},{"n":"e","p":47185921}],"n":"Aborted","d":1358380,"h":17181227564,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2734636},{"n":"e","p":47185921}],"n":"InDoubt","d":1358380,"h":21476194860,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":1358380,"h":25771162156,"f":1}],"h":1358380}; }
            static get $b() { return $.$stl.System.Transactions.DurableEnlistmentState; }
            static get $fullName() { return `System.Transactions.DurableEnlistmentCommitting`; }
        });
        
        $asm.$cls("$stl.System.Transactions.DurableEnlistmentDelegated", ($self) => class DurableEnlistmentDelegated extends $.$stl.System.Transactions.DurableEnlistmentState
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                enlistment.State = this;
                $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.PromotableSinglePhaseNotification !== null, "enlistment.PromotableSinglePhaseNotification != null");
            }
            /*void */ Committed(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentEnded.EnterState(enlistment);
                $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.Transaction.State !== null, "enlistment.Transaction.State != null");
                enlistment.Transaction.State.ChangeStatePromotedCommitted(enlistment.Transaction);
            }
            /*void */ Aborted(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentEnded.EnterState(enlistment);
                enlistment.Transaction._innerException ??= e;
                $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.Transaction.State !== null, "enlistment.Transaction.State != null");
                enlistment.Transaction.State.ChangeStatePromotedAborted(enlistment.Transaction);
            }
            /*void */ InDoubt(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentEnded.EnterState(enlistment);
                enlistment.Transaction._innerException ??= e;
                $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.Transaction.State !== null, "enlistment.Transaction.State != null");
                enlistment.Transaction.State.InDoubtFromEnlistment(enlistment.Transaction);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 1423916;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1554988,"m":[{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"EnterState","d":1423916,"h":4296391212,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"Committed","d":1423916,"h":8591358508,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2734636},{"n":"e","p":47185921}],"n":"Aborted","d":1423916,"h":12886325804,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2734636},{"n":"e","p":47185921}],"n":"InDoubt","d":1423916,"h":17181293100,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":1423916,"h":21476260396,"f":1}],"h":1423916}; }
            static get $b() { return $.$stl.System.Transactions.DurableEnlistmentState; }
            static get $fullName() { return `System.Transactions.DurableEnlistmentDelegated`; }
        });
        
        $asm.$cls("$stl.System.Transactions.DurableEnlistmentEnded", ($self) => class DurableEnlistmentEnded extends $.$stl.System.Transactions.DurableEnlistmentState
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                enlistment.State = this;
            }
            /*void */ InternalAborted(/*InternalEnlistment*/ enlistment)
            {
            }
            /*void */ InDoubt(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 1489452;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1554988,"m":[{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"EnterState","d":1489452,"h":4296456748,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"InternalAborted","d":1489452,"h":8591424044,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2734636},{"n":"e","p":47185921}],"n":"InDoubt","d":1489452,"h":12886391340,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":1489452,"h":17181358636,"f":1}],"h":1489452}; }
            static get $b() { return $.$stl.System.Transactions.DurableEnlistmentState; }
            static get $fullName() { return `System.Transactions.DurableEnlistmentEnded`; }
        });
        
        $asm.$cls("$stl.System.Transactions.VolatileEnlistmentActive", ($self) => class VolatileEnlistmentActive extends $.$stl.System.Transactions.VolatileEnlistmentState
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                enlistment.State = this;
            }
            /*void */ EnlistmentDone(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentDone.EnterState(enlistment);
                enlistment.FinishEnlistment();
            }
            /*void */ ChangeStatePreparing(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentPreparing.EnterState(enlistment);
            }
            /*void */ ChangeStateSinglePhaseCommit(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentSPC.EnterState(enlistment);
            }
            /*void */ InternalAborted(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentAborting.EnterState(enlistment);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 8829484;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":9484844,"m":[{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"EnterState","d":8829484,"h":4303796780,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"EnlistmentDone","d":8829484,"h":8598764076,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"ChangeStatePreparing","d":8829484,"h":12893731372,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"ChangeStateSinglePhaseCommit","d":8829484,"h":17188698668,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"InternalAborted","d":8829484,"h":21483665964,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":8829484,"h":25778633260,"f":1}],"h":8829484}; }
            static get $b() { return $.$stl.System.Transactions.VolatileEnlistmentState; }
            static get $fullName() { return `System.Transactions.VolatileEnlistmentActive`; }
        });
        
        $asm.$cls("$stl.System.Transactions.VolatileEnlistmentPreparing", ($self) => class VolatileEnlistmentPreparing extends $.$stl.System.Transactions.VolatileEnlistmentState
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                enlistment.State = this;
                $.$spc.System.Threading.Monitor.Exit(enlistment.Transaction);
                try
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.EnlistmentStatus(1/*TraceSourceType.TraceSourceLtm*/, enlistment.EnlistmentTraceId, 0/*NotificationCall.Prepare*/);
                    }
                    $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.EnlistmentNotification !== null, "enlistment.EnlistmentNotification != null");
                    enlistment.EnlistmentNotification.System$Transactions$IEnlistmentNotification$Prepare(enlistment.PreparingEnlistment);
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(enlistment.Transaction);
                    }
                }
            }
            /*void */ EnlistmentDone(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentDone.EnterState(enlistment);
                enlistment.FinishEnlistment();
            }
            /*void */ Prepared(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentPrepared.EnterState(enlistment);
                enlistment.FinishEnlistment();
            }
            /*void */ ForceRollback(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentEnded.EnterState(enlistment);
                $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.Transaction.State !== null, "enlistment.Transaction.State != null");
                enlistment.Transaction.State.ChangeStateTransactionAborted(enlistment.Transaction, e);
                enlistment.FinishEnlistment();
            }
            /*void */ ChangeStatePreparing(/*InternalEnlistment*/ enlistment)
            {
            }
            /*void */ InternalAborted(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentPreparingAborting.EnterState(enlistment);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 9222700;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":9484844,"m":[{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"EnterState","d":9222700,"h":4304189996,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"EnlistmentDone","d":9222700,"h":8599157292,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"Prepared","d":9222700,"h":12894124588,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2734636},{"n":"e","p":47185921}],"n":"ForceRollback","d":9222700,"h":17189091884,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"ChangeStatePreparing","d":9222700,"h":21484059180,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"InternalAborted","d":9222700,"h":25779026476,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":9222700,"h":30073993772,"f":1}],"h":9222700}; }
            static get $b() { return $.$stl.System.Transactions.VolatileEnlistmentState; }
            static get $fullName() { return `System.Transactions.VolatileEnlistmentPreparing`; }
        });
        
        $asm.$cls("$stl.System.Transactions.VolatileEnlistmentSPC", ($self) => class VolatileEnlistmentSPC extends $.$stl.System.Transactions.VolatileEnlistmentState
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                /*bool*/ let spcCommitted = false;
                enlistment.State = this;
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.EnlistmentStatus(1/*TraceSourceType.TraceSourceLtm*/, enlistment.EnlistmentTraceId, 4/*NotificationCall.SinglePhaseCommit*/);
                }
                $.$spc.System.Threading.Monitor.Exit(enlistment.Transaction);
                try
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.SinglePhaseNotification !== null, "enlistment.SinglePhaseNotification != null");
                    enlistment.SinglePhaseNotification.System$Transactions$ISinglePhaseNotification$SinglePhaseCommit(enlistment.SinglePhaseEnlistment);
                    spcCommitted = true;
                }
                finally
                {
                    {
                        if (!spcCommitted)
                        {
                            enlistment.SinglePhaseEnlistment.InDoubt();
                        }
                        $.$spc.System.Threading.Monitor.Enter(enlistment.Transaction);
                    }
                }
            }
            /*void */ EnlistmentDone(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentEnded.EnterState(enlistment);
                $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.Transaction.State !== null, "enlistment.Transaction.State != null");
                enlistment.Transaction.State.ChangeStateTransactionCommitted(enlistment.Transaction);
            }
            /*void */ Committed(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentEnded.EnterState(enlistment);
                $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.Transaction.State !== null, "enlistment.Transaction.State != null");
                enlistment.Transaction.State.ChangeStateTransactionCommitted(enlistment.Transaction);
            }
            /*void */ Aborted(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentEnded.EnterState(enlistment);
                $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.Transaction.State !== null, "enlistment.Transaction.State != null");
                enlistment.Transaction.State.ChangeStateTransactionAborted(enlistment.Transaction, e);
            }
            /*void */ InDoubt(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentEnded.EnterState(enlistment);
                enlistment.Transaction._innerException ??= e;
                $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.Transaction.State !== null, "enlistment.Transaction.State != null");
                enlistment.Transaction.State.InDoubtFromEnlistment(enlistment.Transaction);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 9419308;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":9484844,"m":[{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"EnterState","d":9419308,"h":4304386604,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"EnlistmentDone","d":9419308,"h":8599353900,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"Committed","d":9419308,"h":12894321196,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2734636},{"n":"e","p":47185921}],"n":"Aborted","d":9419308,"h":17189288492,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2734636},{"n":"e","p":47185921}],"n":"InDoubt","d":9419308,"h":21484255788,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":9419308,"h":25779223084,"f":1}],"h":9419308}; }
            static get $b() { return $.$stl.System.Transactions.VolatileEnlistmentState; }
            static get $fullName() { return `System.Transactions.VolatileEnlistmentSPC`; }
        });
        
        $asm.$cls("$stl.System.Transactions.VolatileEnlistmentPrepared", ($self) => class VolatileEnlistmentPrepared extends $.$stl.System.Transactions.VolatileEnlistmentState
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                enlistment.State = this;
            }
            /*void */ InternalAborted(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentAborting.EnterState(enlistment);
            }
            /*void */ InternalCommitted(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentCommitting.EnterState(enlistment);
            }
            /*void */ InternalIndoubt(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentInDoubt.EnterState(enlistment);
            }
            /*void */ ChangeStatePreparing(/*InternalEnlistment*/ enlistment)
            {
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 9157164;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":9484844,"m":[{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"EnterState","d":9157164,"h":4304124460,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"InternalAborted","d":9157164,"h":8599091756,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"InternalCommitted","d":9157164,"h":12894059052,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"InternalIndoubt","d":9157164,"h":17189026348,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"ChangeStatePreparing","d":9157164,"h":21483993644,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":9157164,"h":25778960940,"f":1}],"h":9157164}; }
            static get $b() { return $.$stl.System.Transactions.VolatileEnlistmentState; }
            static get $fullName() { return `System.Transactions.VolatileEnlistmentPrepared`; }
        });
        
        $asm.$cls("$stl.System.Transactions.VolatileEnlistmentPreparingAborting", ($self) => class VolatileEnlistmentPreparingAborting extends $.$stl.System.Transactions.VolatileEnlistmentState
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                enlistment.State = this;
            }
            /*void */ EnlistmentDone(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentEnded.EnterState(enlistment);
            }
            /*void */ Prepared(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentAborting.EnterState(enlistment);
                enlistment.FinishEnlistment();
            }
            /*void */ ForceRollback(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentEnded.EnterState(enlistment);
                if (enlistment.Transaction._innerException === null)
                {
                    enlistment.Transaction._innerException = e;
                }
                enlistment.FinishEnlistment();
            }
            /*void */ InternalAborted(/*InternalEnlistment*/ enlistment)
            {
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 9288236;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":9484844,"m":[{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"EnterState","d":9288236,"h":4304255532,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"EnlistmentDone","d":9288236,"h":8599222828,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"Prepared","d":9288236,"h":12894190124,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2734636},{"n":"e","p":47185921}],"n":"ForceRollback","d":9288236,"h":17189157420,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"InternalAborted","d":9288236,"h":21484124716,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":9288236,"h":25779092012,"f":1}],"h":9288236}; }
            static get $b() { return $.$stl.System.Transactions.VolatileEnlistmentState; }
            static get $fullName() { return `System.Transactions.VolatileEnlistmentPreparingAborting`; }
        });
        
        $asm.$cls("$stl.System.Transactions.VolatileEnlistmentAborting", ($self) => class VolatileEnlistmentAborting extends $.$stl.System.Transactions.VolatileEnlistmentState
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                enlistment.State = this;
                $.$spc.System.Threading.Monitor.Exit(enlistment.Transaction);
                try
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.EnlistmentStatus(1/*TraceSourceType.TraceSourceLtm*/, enlistment.EnlistmentTraceId, 2/*NotificationCall.Rollback*/);
                    }
                    $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.EnlistmentNotification !== null, "enlistment.EnlistmentNotification != null");
                    enlistment.EnlistmentNotification.System$Transactions$IEnlistmentNotification$Rollback(enlistment.SinglePhaseEnlistment);
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(enlistment.Transaction);
                    }
                }
            }
            /*void */ ChangeStatePreparing(/*InternalEnlistment*/ enlistment)
            {
            }
            /*void */ EnlistmentDone(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentEnded.EnterState(enlistment);
            }
            /*void */ InternalAborted(/*InternalEnlistment*/ enlistment)
            {
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 8763948;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":9484844,"m":[{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"EnterState","d":8763948,"h":4303731244,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"ChangeStatePreparing","d":8763948,"h":8598698540,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"EnlistmentDone","d":8763948,"h":12893665836,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"InternalAborted","d":8763948,"h":17188633132,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":8763948,"h":21483600428,"f":1}],"h":8763948}; }
            static get $b() { return $.$stl.System.Transactions.VolatileEnlistmentState; }
            static get $fullName() { return `System.Transactions.VolatileEnlistmentAborting`; }
        });
        
        $asm.$cls("$stl.System.Transactions.VolatileEnlistmentCommitting", ($self) => class VolatileEnlistmentCommitting extends $.$stl.System.Transactions.VolatileEnlistmentState
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                enlistment.State = this;
                $.$spc.System.Threading.Monitor.Exit(enlistment.Transaction);
                try
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.EnlistmentStatus(1/*TraceSourceType.TraceSourceLtm*/, enlistment.EnlistmentTraceId, 1/*NotificationCall.Commit*/);
                    }
                    $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.EnlistmentNotification !== null, "enlistment.EnlistmentNotification != null");
                    enlistment.EnlistmentNotification.System$Transactions$IEnlistmentNotification$Commit(enlistment.Enlistment);
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(enlistment.Transaction);
                    }
                }
            }
            /*void */ EnlistmentDone(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentEnded.EnterState(enlistment);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 8895020;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":9484844,"m":[{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"EnterState","d":8895020,"h":4303862316,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"EnlistmentDone","d":8895020,"h":8598829612,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":8895020,"h":12893796908,"f":1}],"h":8895020}; }
            static get $b() { return $.$stl.System.Transactions.VolatileEnlistmentState; }
            static get $fullName() { return `System.Transactions.VolatileEnlistmentCommitting`; }
        });
        
        $asm.$cls("$stl.System.Transactions.VolatileEnlistmentInDoubt", ($self) => class VolatileEnlistmentInDoubt extends $.$stl.System.Transactions.VolatileEnlistmentState
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                enlistment.State = this;
                $.$spc.System.Threading.Monitor.Exit(enlistment.Transaction);
                try
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.EnlistmentStatus(1/*TraceSourceType.TraceSourceLtm*/, enlistment.EnlistmentTraceId, 3/*NotificationCall.InDoubt*/);
                    }
                    $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.EnlistmentNotification !== null, "enlistment.EnlistmentNotification != null");
                    enlistment.EnlistmentNotification.System$Transactions$IEnlistmentNotification$InDoubt(enlistment.PreparingEnlistment);
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(enlistment.Transaction);
                    }
                }
            }
            /*void */ EnlistmentDone(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentEnded.EnterState(enlistment);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 9091628;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":9484844,"m":[{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"EnterState","d":9091628,"h":4304058924,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"EnlistmentDone","d":9091628,"h":8599026220,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":9091628,"h":12893993516,"f":1}],"h":9091628}; }
            static get $b() { return $.$stl.System.Transactions.VolatileEnlistmentState; }
            static get $fullName() { return `System.Transactions.VolatileEnlistmentInDoubt`; }
        });
        
        $asm.$cls("$stl.System.Transactions.VolatileEnlistmentEnded", ($self) => class VolatileEnlistmentEnded extends $.$stl.System.Transactions.VolatileEnlistmentState
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                enlistment.State = this;
            }
            /*void */ ChangeStatePreparing(/*InternalEnlistment*/ enlistment)
            {
            }
            /*void */ InternalAborted(/*InternalEnlistment*/ enlistment)
            {
            }
            /*void */ InternalCommitted(/*InternalEnlistment*/ enlistment)
            {
            }
            /*void */ InternalIndoubt(/*InternalEnlistment*/ enlistment)
            {
            }
            /*void */ InDoubt(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 9026092;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":9484844,"m":[{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"EnterState","d":9026092,"h":4303993388,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"ChangeStatePreparing","d":9026092,"h":8598960684,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"InternalAborted","d":9026092,"h":12893927980,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"InternalCommitted","d":9026092,"h":17188895276,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"InternalIndoubt","d":9026092,"h":21483862572,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2734636},{"n":"e","p":47185921}],"n":"InDoubt","d":9026092,"h":25778829868,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":9026092,"h":30073797164,"f":1}],"h":9026092}; }
            static get $b() { return $.$stl.System.Transactions.VolatileEnlistmentState; }
            static get $fullName() { return `System.Transactions.VolatileEnlistmentEnded`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateVolatilePhase1", ($self) => class TransactionStateVolatilePhase1 extends $.$stl.System.Transactions.ActiveStates
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                $.$spc.System.Diagnostics.Debug.Assert$1(tx._committableTransaction !== null, "tx._committableTransaction != null");
                tx._committableTransaction._complete = true;
                if (tx._phase1Volatiles._dependentClones !== 0)
                {
                    $.$stl.System.Transactions.TransactionState.TransactionStateAborted.EnterState(tx);
                    return;
                }
                if (tx._phase1Volatiles._volatileEnlistmentCount === 1 && tx._durableEnlistment === null && $.$spc.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, 0).SinglePhaseNotification !== null)
                {
                    $.$stl.System.Transactions.TransactionState.TransactionStateVolatileSPC.EnterState(tx);
                }
                else if (tx._phase1Volatiles._volatileEnlistmentCount > 0)
                {
                    for(/*int*/ let i = 0; i < tx._phase1Volatiles._volatileEnlistmentCount; i++)
                    {
                        $.$spc.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i)._twoPhaseState.ChangeStatePreparing($.$spc.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i));
                        if (!tx.State.ContinuePhase1Prepares())
                        {
                            break;
                        }
                    }
                }
                else 
                {
                    $.$stl.System.Transactions.TransactionState.TransactionStateSPC.EnterState(tx);
                }
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                this.ChangeStateTransactionAborted(tx, e);
            }
            /*void */ ChangeStateTransactionAborted(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                tx._innerException ??= e;
                $.$stl.System.Transactions.TransactionState.TransactionStateAborted.EnterState(tx);
            }
            /*void */ Phase1VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStateSPC.EnterState(tx);
            }
            /*bool */ ContinuePhase1Prepares()
            {
                return true;
            }
            /*void */ Timeout(/*InternalTransaction*/ tx)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionTimeout(tx.TransactionTraceId);
                }
                /*TimeoutException*/ let e = new $.$spc.System.TimeoutException().$ctor$10($.$stl.System.SR.TraceTransactionTimeout);
                this.Rollback(tx, e);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 8305196;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":244268,"m":[{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"EnterState","d":8305196,"h":4303272492,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"e","p":47185921}],"n":"Rollback","d":8305196,"h":8598239788,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"e","p":47185921}],"n":"ChangeStateTransactionAborted","d":8305196,"h":12893207084,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"Phase1VolatilePrepareDone","d":8305196,"h":17188174380,"f":32776},{"r":262145,"n":"ContinuePhase1Prepares","d":8305196,"h":21483141676,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"Timeout","d":8305196,"h":25778108972,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":8305196,"h":30073076268,"f":1}],"h":8305196}; }
            static get $b() { return $.$stl.System.Transactions.ActiveStates; }
            static get $fullName() { return `System.Transactions.TransactionStateVolatilePhase1`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateVolatileSPC", ($self) => class TransactionStateVolatileSPC extends $.$stl.System.Transactions.ActiveStates
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                $.$spc.System.Diagnostics.Debug.Assert$1(tx._phase1Volatiles._volatileEnlistmentCount === 1, "There must be exactly 1 phase 1 volatile enlistment for TransactionStateVolatileSPC");
                $.$spc.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, 0)._twoPhaseState.ChangeStateSinglePhaseCommit($.$spc.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, 0));
            }
            /*void */ ChangeStateTransactionCommitted(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStateCommitted.EnterState(tx);
            }
            /*void */ InDoubtFromEnlistment(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStateInDoubt.EnterState(tx);
            }
            /*void */ ChangeStateTransactionAborted(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                tx._innerException ??= e;
                $.$stl.System.Transactions.TransactionState.TransactionStateAborted.EnterState(tx);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 8370732;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":244268,"m":[{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"EnterState","d":8370732,"h":4303338028,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"ChangeStateTransactionCommitted","d":8370732,"h":8598305324,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"InDoubtFromEnlistment","d":8370732,"h":12893272620,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"e","p":47185921}],"n":"ChangeStateTransactionAborted","d":8370732,"h":17188239916,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":8370732,"h":21483207212,"f":1}],"h":8370732}; }
            static get $b() { return $.$stl.System.Transactions.ActiveStates; }
            static get $fullName() { return `System.Transactions.TransactionStateVolatileSPC`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateSPC", ($self) => class TransactionStateSPC extends $.$stl.System.Transactions.ActiveStates
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                if (tx._durableEnlistment !== null)
                {
                    tx._durableEnlistment.State.ChangeStateCommitting(tx._durableEnlistment);
                }
                else 
                {
                    $.$stl.System.Transactions.TransactionState.TransactionStateCommitted.EnterState(tx);
                }
            }
            /*void */ ChangeStateTransactionCommitted(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStateCommitted.EnterState(tx);
            }
            /*void */ InDoubtFromEnlistment(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStateInDoubt.EnterState(tx);
            }
            /*void */ ChangeStateTransactionAborted(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                tx._innerException ??= e;
                $.$stl.System.Transactions.TransactionState.TransactionStateAborted.EnterState(tx);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 8174124;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":244268,"m":[{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"EnterState","d":8174124,"h":4303141420,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"ChangeStateTransactionCommitted","d":8174124,"h":8598108716,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"InDoubtFromEnlistment","d":8174124,"h":12893076012,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"e","p":47185921}],"n":"ChangeStateTransactionAborted","d":8174124,"h":17188043308,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":8174124,"h":21483010604,"f":1}],"h":8174124}; }
            static get $b() { return $.$stl.System.Transactions.ActiveStates; }
            static get $fullName() { return `System.Transactions.TransactionStateSPC`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateAborted", ($self) => class TransactionStateAborted extends $.$stl.System.Transactions.TransactionStateEnded
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                super.EnterState(tx);
                this.CommonEnterState(tx);
                for(/*int*/ let i = 0; i < tx._phase0Volatiles._volatileEnlistmentCount; i++)
                {
                    $.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i)._twoPhaseState.InternalAborted($.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i));
                }
                for(/*int*/ let i = 0; i < tx._phase1Volatiles._volatileEnlistmentCount; i++)
                {
                    $.$spc.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i)._twoPhaseState.InternalAborted($.$spc.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i));
                }
                tx._durableEnlistment?.State.InternalAborted(tx._durableEnlistment);
                $.$stl.System.Transactions.TransactionTable.Remove(tx);
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionTimeout(tx.TransactionTraceId);
                }
                tx.FireCompletion();
                if (tx._asyncCommit)
                {
                    tx.SignalAsyncCompletion();
                }
            }
            /*TransactionStatus */ get_Status(/*InternalTransaction*/ tx)
            {
                return 2/*TransactionStatus.Aborted*/;
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
            }
            /*void */ BeginCommit(/*InternalTransaction*/ tx, /*bool*/ asyncCommit, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw $.$stl.System.Transactions.TransactionStateAborted.CreateTransactionAbortedException(tx);
            }
            /*void */ EndCommit(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionStateAborted.CreateTransactionAbortedException(tx);
            }
            /*void */ RestartCommitIfNeeded(/*InternalTransaction*/ tx)
            {
            }
            /*void */ Timeout(/*InternalTransaction*/ tx)
            {
            }
            /*void */ Phase0VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ Phase1VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ ChangeStateTransactionAborted(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
            }
            /*void */ ChangeStatePromotedAborted(/*InternalTransaction*/ tx)
            {
            }
            /*void */ ChangeStateAbortedDuringPromotion(/*InternalTransaction*/ tx)
            {
            }
            /*void */ CreateBlockingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionStateAborted.CreateTransactionAbortedException(tx);
            }
            /*void */ CreateAbortingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionStateAborted.CreateTransactionAbortedException(tx);
            }
            /*void */ GetObjectData(/*InternalTransaction*/ tx, /*SerializationInfo*/ serializationInfo, /*StreamingContext*/ context)
            {
                throw $.$stl.System.Transactions.TransactionStateAborted.CreateTransactionAbortedException(tx);
            }
            /*void */ CheckForFinishedTransaction(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionStateAborted.CreateTransactionAbortedException(tx);
            }
            static /*TransactionAbortedException */ CreateTransactionAbortedException(/*InternalTransaction*/ tx)
            {
                return $.$stl.System.Transactions.TransactionAbortedException.Create$3($.$stl.System.SR.TransactionAborted, tx._innerException, tx.DistributedTxId);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 5814828;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6470188,"m":[{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"EnterState","d":5814828,"h":4300782124,"f":32776},{"r":8436268,"p":[{"n":"tx","p":2800172}],"n":"get_Status","d":5814828,"h":8595749420,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"e","p":47185921}],"n":"Rollback","d":5814828,"h":12890716716,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"asyncCommit","p":262145},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":5814828,"h":17185684012,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"EndCommit","d":5814828,"h":21480651308,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"RestartCommitIfNeeded","d":5814828,"h":25775618604,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"Timeout","d":5814828,"h":30070585900,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"Phase0VolatilePrepareDone","d":5814828,"h":34365553196,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"Phase1VolatilePrepareDone","d":5814828,"h":38660520492,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"e","p":47185921}],"n":"ChangeStateTransactionAborted","d":5814828,"h":42955487788,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"ChangeStatePromotedAborted","d":5814828,"h":47250455084,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"ChangeStateAbortedDuringPromotion","d":5814828,"h":51545422380,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"CreateBlockingClone","d":5814828,"h":55840389676,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"CreateAbortingClone","d":5814828,"h":60135356972,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"serializationInfo","p":113967105},{"n":"context","p":114098177}],"n":"GetObjectData","d":5814828,"h":64430324268,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"CheckForFinishedTransaction","d":5814828,"h":68725291564,"f":32776},{"r":4373036,"p":[{"n":"tx","p":2800172}],"n":"CreateTransactionAbortedException","d":5814828,"h":73020258860,"f":34}],"c":[{"n":".ctor","o":"$ctor$3","d":5814828,"h":77315226156,"f":1}],"h":5814828}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStateEnded; }
            static get $fullName() { return `System.Transactions.TransactionStateAborted`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateCommitted", ($self) => class TransactionStateCommitted extends $.$stl.System.Transactions.TransactionStateEnded
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                super.EnterState(tx);
                this.CommonEnterState(tx);
                for(/*int*/ let i = 0; i < tx._phase0Volatiles._volatileEnlistmentCount; i++)
                {
                    $.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i)._twoPhaseState.InternalCommitted($.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i));
                }
                for(/*int*/ let i = 0; i < tx._phase1Volatiles._volatileEnlistmentCount; i++)
                {
                    $.$spc.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i)._twoPhaseState.InternalCommitted($.$spc.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i));
                }
                $.$stl.System.Transactions.TransactionTable.Remove(tx);
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionCommitted(1/*TraceSourceType.TraceSourceLtm*/, tx.TransactionTraceId);
                }
                tx.FireCompletion();
                if (tx._asyncCommit)
                {
                    tx.SignalAsyncCompletion();
                }
            }
            /*TransactionStatus */ get_Status(/*InternalTransaction*/ tx)
            {
                return 1/*TransactionStatus.Committed*/;
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ EndCommit(/*InternalTransaction*/ tx)
            {
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 5945900;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6470188,"m":[{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"EnterState","d":5945900,"h":4300913196,"f":32776},{"r":8436268,"p":[{"n":"tx","p":2800172}],"n":"get_Status","d":5945900,"h":8595880492,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"e","p":47185921}],"n":"Rollback","d":5945900,"h":12890847788,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"EndCommit","d":5945900,"h":17185815084,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":5945900,"h":21480782380,"f":1}],"h":5945900}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStateEnded; }
            static get $fullName() { return `System.Transactions.TransactionStateCommitted`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateInDoubt", ($self) => class TransactionStateInDoubt extends $.$stl.System.Transactions.TransactionStateEnded
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                super.EnterState(tx);
                this.CommonEnterState(tx);
                for(/*int*/ let i = 0; i < tx._phase0Volatiles._volatileEnlistmentCount; i++)
                {
                    $.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i)._twoPhaseState.InternalIndoubt($.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i));
                }
                for(/*int*/ let i = 0; i < tx._phase1Volatiles._volatileEnlistmentCount; i++)
                {
                    $.$spc.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i)._twoPhaseState.InternalIndoubt($.$spc.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i));
                }
                $.$stl.System.Transactions.TransactionTable.Remove(tx);
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionInDoubt(1/*TraceSourceType.TraceSourceLtm*/, tx.TransactionTraceId);
                }
                tx.FireCompletion();
                if (tx._asyncCommit)
                {
                    tx.SignalAsyncCompletion();
                }
            }
            /*TransactionStatus */ get_Status(/*InternalTransaction*/ tx)
            {
                return 3/*TransactionStatus.InDoubt*/;
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ EndCommit(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionInDoubtException.Create$3(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionIndoubt, tx._innerException, tx.DistributedTxId);
            }
            /*void */ CheckForFinishedTransaction(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionInDoubtException.Create$3(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionIndoubt, tx._innerException, tx.DistributedTxId);
            }
            /*void */ GetObjectData(/*InternalTransaction*/ tx, /*SerializationInfo*/ serializationInfo, /*StreamingContext*/ context)
            {
                throw $.$stl.System.Transactions.TransactionInDoubtException.Create$3(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionIndoubt, tx._innerException, tx.DistributedTxId);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 6535724;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6470188,"m":[{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"EnterState","d":6535724,"h":4301503020,"f":32776},{"r":8436268,"p":[{"n":"tx","p":2800172}],"n":"get_Status","d":6535724,"h":8596470316,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"e","p":47185921}],"n":"Rollback","d":6535724,"h":12891437612,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"EndCommit","d":6535724,"h":17186404908,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"CheckForFinishedTransaction","d":6535724,"h":21481372204,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"serializationInfo","p":113967105},{"n":"context","p":114098177}],"n":"GetObjectData","d":6535724,"h":25776339500,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":6535724,"h":30071306796,"f":1}],"h":6535724}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStateEnded; }
            static get $fullName() { return `System.Transactions.TransactionStateInDoubt`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateNonCommittablePromoted", ($self) => class TransactionStateNonCommittablePromoted extends $.$stl.System.Transactions.TransactionStatePromotedBase
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                $.$spc.System.Diagnostics.Debug.Assert$1(tx.PromotedTransaction !== null && tx.PromotedTransaction.RealTransaction !== null, "tx.PromotedTransaction != null && tx.PromotedTransaction.RealTransaction != null");
                tx.PromotedTransaction.RealTransaction.InternalTransaction = tx;
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 6601260;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6928940,"m":[{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"EnterState","d":6601260,"h":4301568556,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":6601260,"h":8596535852,"f":1}],"h":6601260}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedBase; }
            static get $fullName() { return `System.Transactions.TransactionStateNonCommittablePromoted`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromoted", ($self) => class TransactionStatePromoted extends $.$stl.System.Transactions.TransactionStatePromotedBase
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(($.$spc.System.Guid.op_Equality(tx._promoterType, $.$spc.System.Guid.Empty)) || ($.$spc.System.Guid.op_Equality(tx._promoterType, $.$stl.System.Transactions.TransactionInterop.PromoterTypeDtc)), "Promoted to MSTC but PromoterType is not TransactionInterop.PromoterTypeDtc");
                tx.SetPromoterTypeToMSDTC();
                if (tx._outcomeSource._isoLevel === 4/*IsolationLevel.Snapshot*/)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.CannotPromoteSnapshot, null);
                }
                this.CommonEnterState(tx);
                /*OletxCommittableTransaction?*/ let distributedTx = null;
                try
                {
                    /*TimeSpan*/ let newTimeout;
                    if (tx.AbsoluteTimeout === 9223372036854775807n)
                    {
                        newTimeout = $.$spc.System.TimeSpan.Zero;
                    }
                    else 
                    {
                        newTimeout = $.$stl.System.Transactions.TransactionManager.TransactionTable.RecalcTimeout(tx);
                        if ($.$spc.System.TimeSpan.op_LessThanOrEqual(newTimeout, $.$spc.System.TimeSpan.Zero))
                        {
                            return;
                        }
                    }
                    /*TransactionOptions*/ let options = new $.$stl.System.Transactions.TransactionOptions();
                    options.IsolationLevel = tx._outcomeSource._isoLevel;
                    options.Timeout = newTimeout;
                    distributedTx = $.$stl.System.Transactions.TransactionManager.DistributedTransactionManager.CreateTransaction(options.Clone());
                    distributedTx.SavedLtmPromotedTransaction = tx._outcomeSource;
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.TransactionPromoted(tx.TransactionTraceId, distributedTx.TransactionTraceId);
                    }
                }
                catch(te)
                {
                    tx._innerException = te;
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.ExceptionConsumed$1(te);
                    }
                    return;
                }
                finally
                {
                    {
                        if (distributedTx === null)
                        {
                            tx.State.ChangeStateAbortedDuringPromotion(tx);
                        }
                    }
                }
                tx.PromotedTransaction = distributedTx;
                /*Hashtable*/ let promotedTransactionTable = $.$stl.System.Transactions.TransactionManager.PromotedTransactionTable;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(promotedTransactionTable)
                    {
                        tx._finalizedObject = new $.$stl.System.Transactions.FinalizedObject().$ctor$1(tx, distributedTx.Identifier);
                        /*WeakReference*/ let weakRef = new $.$spc.System.WeakReference().$ctor$2(tx._outcomeSource, false);
                        promotedTransactionTable.set_Item(distributedTx.Identifier, weakRef);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(promotedTransactionTable)
                }
                $.$stl.System.Transactions.TransactionManager.FireDistributedTransactionStarted(tx._outcomeSource);
                this.PromoteEnlistmentsAndOutcome(tx);
            }
            static /*bool */ PromotePhaseVolatiles(/*InternalTransaction*/ tx, /*ref VolatileEnlistmentSet*/ volatiles, /*bool*/ phase0)
            {
                if (((volatiles.$v._volatileEnlistmentCount + volatiles.$v._dependentClones) | 0) > 0)
                {
                    if (phase0)
                    {
                        volatiles.$v.VolatileDemux = new $.$stl.System.Transactions.Phase0VolatileDemultiplexer().$ctor$2(tx);
                    }
                    else 
                    {
                        volatiles.$v.VolatileDemux = new $.$stl.System.Transactions.Phase1VolatileDemultiplexer().$ctor$2(tx);
                    }
                    $.$spc.System.Diagnostics.Debug.Assert$1(tx.PromotedTransaction !== null, "tx.PromotedTransaction != null");
                    volatiles.$v.VolatileDemux._promotedEnlistment = tx.PromotedTransaction.EnlistVolatile$1(volatiles.$v.VolatileDemux, phase0 ? 1/*EnlistmentOptions.EnlistDuringPrepareRequired*/ : 0/*EnlistmentOptions.None*/);
                }
                return true;
            }
            /*bool */ PromoteDurable(/*InternalTransaction*/ tx)
            {
                if (tx._durableEnlistment !== null)
                {
                    /*InternalEnlistment*/ let enlistment = tx._durableEnlistment;
                    $.$spc.System.Diagnostics.Debug.Assert$1(tx.PromotedTransaction !== null, "tx.PromotedTransaction != null");
                    /*IPromotedEnlistment*/ let promotedEnlistment = tx.PromotedTransaction.EnlistDurable(enlistment.ResourceManagerIdentifier, $.$cast(enlistment, $.$stl.System.Transactions.DurableInternalEnlistment), enlistment.SinglePhaseNotification !== null, 0/*EnlistmentOptions.None*/);
                    tx._durableEnlistment.State.ChangeStatePromoted(tx._durableEnlistment, promotedEnlistment);
                }
                return true;
            }
            /*void */ PromoteEnlistmentsAndOutcome(/*InternalTransaction*/ tx)
            {
                /*bool*/ let enlistmentsPromoted = false;
                $.$spc.System.Diagnostics.Debug.Assert$1(tx.PromotedTransaction !== null && tx.PromotedTransaction.RealTransaction !== null, "tx.PromotedTransaction != null && tx.PromotedTransaction.RealTransaction != null");
                tx.PromotedTransaction.RealTransaction.InternalTransaction = tx;
                $.$spc.System.Diagnostics.Debug.Assert$1(tx.State !== null, "tx.State != null");
                try
                {
                    enlistmentsPromoted = $.$stl.System.Transactions.TransactionStatePromoted.PromotePhaseVolatiles(tx, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase0Volatiles, ($v) => tx._phase0Volatiles = $v, null), true);
                }
                catch(te)
                {
                    tx._innerException = te;
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.ExceptionConsumed$1(te);
                    }
                    return;
                }
                finally
                {
                    {
                        if (!enlistmentsPromoted)
                        {
                            tx.PromotedTransaction.Rollback();
                            tx.State.ChangeStateAbortedDuringPromotion(tx);
                        }
                    }
                }
                enlistmentsPromoted = false;
                try
                {
                    enlistmentsPromoted = $.$stl.System.Transactions.TransactionStatePromoted.PromotePhaseVolatiles(tx, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase1Volatiles, ($v) => tx._phase1Volatiles = $v, null), false);
                }
                catch(te)
                {
                    tx._innerException = te;
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.ExceptionConsumed$1(te);
                    }
                    return;
                }
                finally
                {
                    {
                        if (!enlistmentsPromoted)
                        {
                            tx.PromotedTransaction.Rollback();
                            tx.State.ChangeStateAbortedDuringPromotion(tx);
                        }
                    }
                }
                enlistmentsPromoted = false;
                try
                {
                    enlistmentsPromoted = this.PromoteDurable(tx);
                }
                catch(te)
                {
                    tx._innerException = te;
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.ExceptionConsumed$1(te);
                    }
                    return;
                }
                finally
                {
                    {
                        if (!enlistmentsPromoted)
                        {
                            tx.PromotedTransaction.Rollback();
                            tx.State.ChangeStateAbortedDuringPromotion(tx);
                        }
                    }
                }
            }
            /*void */ DisposeRoot(/*InternalTransaction*/ tx)
            {
                tx.State.Rollback(tx, null);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 6732332;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6928940,"m":[{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"EnterState","d":6732332,"h":4301699628,"f":32776},{"r":262145,"p":[{"n":"tx","p":2800172},{"n":"volatiles","p":9353772,"f":4},{"n":"phase0","p":262145}],"n":"PromotePhaseVolatiles","d":6732332,"h":8596666924,"f":36},{"r":262145,"p":[{"n":"tx","p":2800172}],"n":"PromoteDurable","d":6732332,"h":12891634220,"f":136},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"PromoteEnlistmentsAndOutcome","d":6732332,"h":17186601516,"f":136},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"DisposeRoot","d":6732332,"h":21481568812,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":6732332,"h":25776536108,"f":1}],"h":6732332}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedBase; }
            static get $fullName() { return `System.Transactions.TransactionStatePromoted`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedP0Wave", ($self) => class TransactionStatePromotedP0Wave extends $.$stl.System.Transactions.TransactionStatePromotedBase
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
            }
            /*void */ BeginCommit(/*InternalTransaction*/ tx, /*bool*/ asyncCommit, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ Phase0VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
                try
                {
                    $.$stl.System.Transactions.TransactionState.TransactionStatePromotedCommitting.EnterState(tx);
                }
                catch(e)
                {
                    tx._innerException ??= e;
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.ExceptionConsumed$1(e);
                    }
                }
            }
            /*bool */ ContinuePhase0Prepares()
            {
                return true;
            }
            /*void */ ChangeStateTransactionAborted(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                tx._innerException ??= e;
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedP0Aborting.EnterState(tx);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 7846444;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6928940,"m":[{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"EnterState","d":7846444,"h":4302813740,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"asyncCommit","p":262145},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":7846444,"h":8597781036,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"Phase0VolatilePrepareDone","d":7846444,"h":12892748332,"f":32776},{"r":262145,"n":"ContinuePhase0Prepares","d":7846444,"h":17187715628,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"e","p":47185921}],"n":"ChangeStateTransactionAborted","d":7846444,"h":21482682924,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":7846444,"h":25777650220,"f":1}],"h":7846444}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedBase; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedP0Wave`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedCommitting", ($self) => class TransactionStatePromotedCommitting extends $.$stl.System.Transactions.TransactionStatePromotedBase
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                /*OletxCommittableTransaction*/ let ctx = $.$cast(tx.PromotedTransaction, $.$stl.System.Transactions.Oletx.OletxCommittableTransaction);
                ctx.BeginCommit(tx);
            }
            /*void */ BeginCommit(/*InternalTransaction*/ tx, /*bool*/ asyncCommit, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ ChangeStatePromotedPhase0(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedPhase0.EnterState(tx);
            }
            /*void */ ChangeStatePromotedPhase1(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedPhase1.EnterState(tx);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 7060012;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6928940,"m":[{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"EnterState","d":7060012,"h":4302027308,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"asyncCommit","p":262145},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":7060012,"h":8596994604,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"ChangeStatePromotedPhase0","d":7060012,"h":12891961900,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"ChangeStatePromotedPhase1","d":7060012,"h":17186929196,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":7060012,"h":21481896492,"f":1}],"h":7060012}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedBase; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedCommitting`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedNonMSDTCPhase0", ($self) => class TransactionStatePromotedNonMSDTCPhase0 extends $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCBase
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                /*int*/ let volatileCount = tx._phase0Volatiles._volatileEnlistmentCount;
                /*int*/ let dependentCount = tx._phase0Volatiles._dependentClones;
                tx._phase0VolatileWaveCount = volatileCount;
                if (tx._phase0Volatiles._preparedVolatileEnlistments < ((volatileCount + dependentCount) | 0))
                {
                    for(/*int*/ let i = 0; i < volatileCount; i++)
                    {
                        $.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i)._twoPhaseState.ChangeStatePreparing($.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i));
                        if (!tx.State.ContinuePhase0Prepares())
                        {
                            break;
                        }
                    }
                }
                else 
                {
                    $.$stl.System.Transactions.TransactionState.TransactionStatePromotedNonMSDTCVolatilePhase1.EnterState(tx);
                }
            }
            /*void */ BeginCommit(/*InternalTransaction*/ tx, /*bool*/ asyncCommit, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                this.ChangeStateTransactionAborted(tx, e);
            }
            /*void */ Phase0VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
                /*int*/ let volatileCount = tx._phase0Volatiles._volatileEnlistmentCount;
                /*int*/ let dependentCount = tx._phase0Volatiles._dependentClones;
                tx._phase0VolatileWaveCount = volatileCount;
                if (tx._phase0Volatiles._preparedVolatileEnlistments < ((volatileCount + dependentCount) | 0))
                {
                    for(/*int*/ let i = 0; i < volatileCount; i++)
                    {
                        $.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i)._twoPhaseState.ChangeStatePreparing($.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i));
                        if (!tx.State.ContinuePhase0Prepares())
                        {
                            break;
                        }
                    }
                }
                else 
                {
                    $.$stl.System.Transactions.TransactionState.TransactionStatePromotedNonMSDTCVolatilePhase1.EnterState(tx);
                }
            }
            /*void */ Phase1VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            /*bool */ ContinuePhase0Prepares()
            {
                return true;
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 7584300;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7322156,"m":[{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"EnterState","d":7584300,"h":4302551596,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"asyncCommit","p":262145},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":7584300,"h":8597518892,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"e","p":47185921}],"n":"Rollback","d":7584300,"h":12892486188,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"Phase0VolatilePrepareDone","d":7584300,"h":17187453484,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"Phase1VolatilePrepareDone","d":7584300,"h":21482420780,"f":32776},{"r":262145,"n":"ContinuePhase0Prepares","d":7584300,"h":25777388076,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":7584300,"h":30072355372,"f":1}],"h":7584300}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCBase; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedNonMSDTCPhase0`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedNonMSDTCVolatilePhase1", ($self) => class TransactionStatePromotedNonMSDTCVolatilePhase1 extends $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCBase
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                $.$spc.System.Diagnostics.Debug.Assert$1(tx._committableTransaction !== null, "tx._committableTransaction != null");
                tx._committableTransaction._complete = true;
                if (tx._phase1Volatiles._dependentClones !== 0)
                {
                    this.ChangeStateTransactionAborted(tx, null);
                    return;
                }
                if (tx._phase1Volatiles._volatileEnlistmentCount > 0)
                {
                    for(/*int*/ let i = 0; i < tx._phase1Volatiles._volatileEnlistmentCount; i++)
                    {
                        $.$spc.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i)._twoPhaseState.ChangeStatePreparing($.$spc.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i));
                        if (!tx.State.ContinuePhase1Prepares())
                        {
                            break;
                        }
                    }
                }
                else 
                {
                    $.$stl.System.Transactions.TransactionState.TransactionStatePromotedNonMSDTCSinglePhaseCommit.EnterState(tx);
                }
            }
            /*void */ BeginCommit(/*InternalTransaction*/ tx, /*bool*/ asyncCommit, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                this.ChangeStateTransactionAborted(tx, e);
            }
            /*void */ Phase1VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedNonMSDTCSinglePhaseCommit.EnterState(tx);
            }
            /*bool */ ContinuePhase1Prepares()
            {
                return true;
            }
            /*Enlistment */ EnlistVolatile(/*InternalTransaction*/ tx, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                throw $.$stl.System.Transactions.TransactionException.Create$1($.$stl.System.SR.TooLate, tx === null ? $.$spc.System.Guid.Empty : tx.DistributedTxId);
            }
            /*Enlistment */ EnlistVolatile$1(/*InternalTransaction*/ tx, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                throw $.$stl.System.Transactions.TransactionException.Create$1($.$stl.System.SR.TooLate, tx === null ? $.$spc.System.Guid.Empty : tx.DistributedTxId);
            }
            /*bool */ EnlistPromotableSinglePhase(/*InternalTransaction*/ tx, /*IPromotableSinglePhaseNotification*/ promotableSinglePhaseNotification, /*Transaction*/ atomicTransaction, /*Guid*/ promoterType)
            {
                throw $.$stl.System.Transactions.TransactionException.Create$1($.$stl.System.SR.TooLate, tx === null ? $.$spc.System.Guid.Empty : tx.DistributedTxId);
            }
            /*void */ CreateBlockingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.Create$1($.$stl.System.SR.TooLate, tx === null ? $.$spc.System.Guid.Empty : tx.DistributedTxId);
            }
            /*void */ CreateAbortingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.Create$1($.$stl.System.SR.TooLate, tx === null ? $.$spc.System.Guid.Empty : tx.DistributedTxId);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 7715372;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7322156,"m":[{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"EnterState","d":7715372,"h":4302682668,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"asyncCommit","p":262145},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":7715372,"h":8597649964,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"e","p":47185921}],"n":"Rollback","d":7715372,"h":12892617260,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"Phase1VolatilePrepareDone","d":7715372,"h":17187584556,"f":32776},{"r":262145,"n":"ContinuePhase1Prepares","d":7715372,"h":21482551852,"f":32776},{"r":1751596,"p":[{"n":"tx","p":2800172},{"n":"enlistmentNotification","p":2603564},{"n":"enlistmentOptions","p":1882668},{"n":"atomicTransaction","p":4307500}],"n":"EnlistVolatile","d":7715372,"h":25777519148,"f":32776},{"r":1751596,"p":[{"n":"tx","p":2800172},{"n":"enlistmentNotification","p":3062316},{"n":"enlistmentOptions","p":1882668},{"n":"atomicTransaction","p":4307500}],"n":"EnlistVolatile","o":"@$1","d":7715372,"h":30072486444,"f":32776},{"r":262145,"p":[{"n":"tx","p":2800172},{"n":"promotableSinglePhaseNotification","p":2865708},{"n":"atomicTransaction","p":4307500},{"n":"promoterType","p":56164353}],"n":"EnlistPromotableSinglePhase","d":7715372,"h":34367453740,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"CreateBlockingClone","d":7715372,"h":38662421036,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"CreateAbortingClone","d":7715372,"h":42957388332,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":7715372,"h":47252355628,"f":1}],"h":7715372}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCBase; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedNonMSDTCVolatilePhase1`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedNonMSDTCSinglePhaseCommit", ($self) => class TransactionStatePromotedNonMSDTCSinglePhaseCommit extends $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCBase
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                $.$spc.System.Diagnostics.Debug.Assert$1(tx._durableEnlistment !== null, "tx._durableEnlistment != null");
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.EnlistmentStatus(1/*TraceSourceType.TraceSourceLtm*/, tx._durableEnlistment.EnlistmentTraceId, 4/*NotificationCall.SinglePhaseCommit*/);
                }
                $.$stl.System.Transactions.TransactionTable.Remove(tx);
                tx._durableEnlistment.State.ChangeStateCommitting(tx._durableEnlistment);
            }
            /*void */ BeginCommit(/*InternalTransaction*/ tx, /*bool*/ asyncCommit, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ ChangeStateTransactionCommitted(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedNonMSDTCCommitted.EnterState(tx);
            }
            /*void */ InDoubtFromEnlistment(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedNonMSDTCIndoubt.EnterState(tx);
            }
            /*void */ ChangeStateTransactionAborted(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                tx._innerException ??= e;
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedNonMSDTCAborted.EnterState(tx);
            }
            /*void */ ChangeStateAbortedDuringPromotion(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStateAborted.EnterState(tx);
            }
            /*Enlistment */ EnlistVolatile(/*InternalTransaction*/ tx, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                throw $.$stl.System.Transactions.TransactionException.Create$1($.$stl.System.SR.TooLate, tx === null ? $.$spc.System.Guid.Empty : tx.DistributedTxId);
            }
            /*Enlistment */ EnlistVolatile$1(/*InternalTransaction*/ tx, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                throw $.$stl.System.Transactions.TransactionException.Create$1($.$stl.System.SR.TooLate, tx === null ? $.$spc.System.Guid.Empty : tx.DistributedTxId);
            }
            /*bool */ EnlistPromotableSinglePhase(/*InternalTransaction*/ tx, /*IPromotableSinglePhaseNotification*/ promotableSinglePhaseNotification, /*Transaction*/ atomicTransaction, /*Guid*/ promoterType)
            {
                throw $.$stl.System.Transactions.TransactionException.Create$1($.$stl.System.SR.TooLate, tx === null ? $.$spc.System.Guid.Empty : tx.DistributedTxId);
            }
            /*void */ CreateBlockingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.Create$1($.$stl.System.SR.TooLate, tx === null ? $.$spc.System.Guid.Empty : tx.DistributedTxId);
            }
            /*void */ CreateAbortingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.Create$1($.$stl.System.SR.TooLate, tx === null ? $.$spc.System.Guid.Empty : tx.DistributedTxId);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 7649836;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7322156,"m":[{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"EnterState","d":7649836,"h":4302617132,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"asyncCommit","p":262145},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":7649836,"h":8597584428,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"e","p":47185921}],"n":"Rollback","d":7649836,"h":12892551724,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"ChangeStateTransactionCommitted","d":7649836,"h":17187519020,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"InDoubtFromEnlistment","d":7649836,"h":21482486316,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"e","p":47185921}],"n":"ChangeStateTransactionAborted","d":7649836,"h":25777453612,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"ChangeStateAbortedDuringPromotion","d":7649836,"h":30072420908,"f":32776},{"r":1751596,"p":[{"n":"tx","p":2800172},{"n":"enlistmentNotification","p":2603564},{"n":"enlistmentOptions","p":1882668},{"n":"atomicTransaction","p":4307500}],"n":"EnlistVolatile","d":7649836,"h":34367388204,"f":32776},{"r":1751596,"p":[{"n":"tx","p":2800172},{"n":"enlistmentNotification","p":3062316},{"n":"enlistmentOptions","p":1882668},{"n":"atomicTransaction","p":4307500}],"n":"EnlistVolatile","o":"@$1","d":7649836,"h":38662355500,"f":32776},{"r":262145,"p":[{"n":"tx","p":2800172},{"n":"promotableSinglePhaseNotification","p":2865708},{"n":"atomicTransaction","p":4307500},{"n":"promoterType","p":56164353}],"n":"EnlistPromotableSinglePhase","d":7649836,"h":42957322796,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"CreateBlockingClone","d":7649836,"h":47252290092,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"CreateAbortingClone","d":7649836,"h":51547257388,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":7649836,"h":55842224684,"f":1}],"h":7649836}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCBase; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedNonMSDTCSinglePhaseCommit`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateDelegatedNonMSDTC", ($self) => class TransactionStateDelegatedNonMSDTC extends $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCBase
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                /*OletxTransaction?*/ let distributedTx;
                try
                {
                    if (tx._durableEnlistment !== null)
                    {
                        /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                        if (etwLog.IsEnabled())
                        {
                            etwLog.EnlistmentStatus(1/*TraceSourceType.TraceSourceLtm*/, tx._durableEnlistment.EnlistmentTraceId, 5/*NotificationCall.Promote*/);
                        }
                    }
                    distributedTx = $.$stl.System.Transactions.TransactionState.TransactionStatePSPEOperation.PSPEPromote(tx);
                    $.$spc.System.Diagnostics.Debug.Assert$1((distributedTx === null), "PSPEPromote for non-MSDTC promotion returned a distributed transaction.");
                    $.$spc.System.Diagnostics.Debug.Assert$1((tx.promotedToken !== null), "PSPEPromote for non-MSDTC promotion did not set InternalTransaction.PromotedToken.");
                }
                catch(e)
                {
                    tx._innerException = e;
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.ExceptionConsumed$1(e);
                    }
                }
                finally
                {
                    {
                        if (tx.promotedToken === null)
                        {
                            tx.State.ChangeStateAbortedDuringPromotion(tx);
                        }
                    }
                }
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 6273580;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7322156,"m":[{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"EnterState","d":6273580,"h":4301240876,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":6273580,"h":8596208172,"f":1}],"h":6273580}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCBase; }
            static get $fullName() { return `System.Transactions.TransactionStateDelegatedNonMSDTC`; }
        });
        
        $asm.$str("$stl.System.Transactions.IsolationLevel", ($self) => class IsolationLevel extends $.$spc.System.Enum
        {
            static Serializable = 0;
            static RepeatableRead = 1;
            static ReadCommitted = 2;
            static ReadUncommitted = 3;
            static Snapshot = 4;
            static Chaos = 5;
            static Unspecified = 6;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Serializable": 0n,
                    "RepeatableRead": 1n,
                    "ReadCommitted": 2n,
                    "ReadUncommitted": 3n,
                    "Snapshot": 4n,
                    "Chaos": 5n,
                    "Unspecified": 6n
                };
            }
            static $h = 3193388;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":3193388,"n":"Serializable","d":3193388,"h":4298160684,"f":33},{"t":3193388,"n":"RepeatableRead","d":3193388,"h":8593127980,"f":33},{"t":3193388,"n":"ReadCommitted","d":3193388,"h":12888095276,"f":33},{"t":3193388,"n":"ReadUncommitted","d":3193388,"h":17183062572,"f":33},{"t":3193388,"n":"Snapshot","d":3193388,"h":21478029868,"f":33},{"t":3193388,"n":"Chaos","d":3193388,"h":25772997164,"f":33},{"t":3193388,"n":"Unspecified","d":3193388,"h":30067964460,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":3193388,"h":34362931756,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":3193388}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Transactions.IsolationLevel`; }
        });
        
        $asm.$str("$stl.System.Transactions.TransactionStatus", ($self) => class TransactionStatus extends $.$spc.System.Enum
        {
            static Active = 0;
            static Committed = 1;
            static Aborted = 2;
            static InDoubt = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Active": 0n,
                    "Committed": 1n,
                    "Aborted": 2n,
                    "InDoubt": 3n
                };
            }
            static $h = 8436268;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":8436268,"n":"Active","d":8436268,"h":4303403564,"f":33},{"t":8436268,"n":"Committed","d":8436268,"h":8598370860,"f":33},{"t":8436268,"n":"Aborted","d":8436268,"h":12893338156,"f":33},{"t":8436268,"n":"InDoubt","d":8436268,"h":17188305452,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":8436268,"h":21483272748,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":8436268}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Transactions.TransactionStatus`; }
        });
        
        $asm.$str("$stl.System.Transactions.DependentCloneOption", ($self) => class DependentCloneOption extends $.$spc.System.Enum
        {
            static BlockCommitUntilComplete = 0;
            static RollbackIfNotComplete = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "BlockCommitUntilComplete": 0n,
                    "RollbackIfNotComplete": 1n
                };
            }
            static $h = 1096236;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1096236,"n":"BlockCommitUntilComplete","d":1096236,"h":4296063532,"f":33},{"t":1096236,"n":"RollbackIfNotComplete","d":1096236,"h":8591030828,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1096236,"h":12885998124,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1096236}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Transactions.DependentCloneOption`; }
        });
        
        $asm.$str("$stl.System.Transactions.EnlistmentOptions", ($self) => class EnlistmentOptions extends $.$spc.System.Enum
        {
            static None = 0;
            static EnlistDuringPrepareRequired = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "EnlistDuringPrepareRequired": 1n
                };
            }
            static $h = 1882668;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1882668,"n":"None","d":1882668,"h":4296849964,"f":33},{"t":1882668,"n":"EnlistDuringPrepareRequired","d":1882668,"h":8591817260,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1882668,"h":12886784556,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1882668,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Transactions.EnlistmentOptions`; }
        });
        
        $asm.$str("$stl.System.Transactions.TransactionScopeOption", ($self) => class TransactionScopeOption extends $.$spc.System.Enum
        {
            static Required = 0;
            static RequiresNew = 1;
            static Suppress = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Required": 0n,
                    "RequiresNew": 1n,
                    "Suppress": 2n
                };
            }
            static $h = 5290540;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":5290540,"n":"Required","d":5290540,"h":4300257836,"f":33},{"t":5290540,"n":"RequiresNew","d":5290540,"h":8595225132,"f":33},{"t":5290540,"n":"Suppress","d":5290540,"h":12890192428,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":5290540,"h":17185159724,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":5290540}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Transactions.TransactionScopeOption`; }
        });
        
        $asm.$str("$stl.System.Transactions.TransactionScopeAsyncFlowOption", ($self) => class TransactionScopeAsyncFlowOption extends $.$spc.System.Enum
        {
            static Suppress = 0;
            static Enabled = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Suppress": 0n,
                    "Enabled": 1n
                };
            }
            static $h = 5225004;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":5225004,"n":"Suppress","d":5225004,"h":4300192300,"f":33},{"t":5225004,"n":"Enabled","d":5225004,"h":8595159596,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":5225004,"h":12890126892,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":5225004}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Transactions.TransactionScopeAsyncFlowOption`; }
        });
        
        $asm.$str("$stl.System.Transactions.EnterpriseServicesInteropOption", ($self) => class EnterpriseServicesInteropOption extends $.$spc.System.Enum
        {
            static None = 0;
            static Automatic = 1;
            static Full = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "Automatic": 1n,
                    "Full": 2n
                };
            }
            static $h = 2275884;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2275884,"n":"None","d":2275884,"h":4297243180,"f":33},{"t":2275884,"n":"Automatic","d":2275884,"h":8592210476,"f":33},{"t":2275884,"n":"Full","d":2275884,"h":12887177772,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2275884,"h":17182145068,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":2275884}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Transactions.EnterpriseServicesInteropOption`; }
        });
        
        $asm.$str("$stl.System.Transactions.EnlistmentType", ($self) => class EnlistmentType extends $.$spc.System.Enum
        {
            static Volatile = 0;
            static Durable = 1;
            static PromotableSinglePhase = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Volatile": 0n,
                    "Durable": 1n,
                    "PromotableSinglePhase": 2n
                };
            }
            static $h = 2144812;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2144812,"n":"Volatile","d":2144812,"h":4297112108,"f":33},{"t":2144812,"n":"Durable","d":2144812,"h":8592079404,"f":33},{"t":2144812,"n":"PromotableSinglePhase","d":2144812,"h":12887046700,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2144812,"h":17182013996,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":2144812}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Transactions.EnlistmentType`; }
        });
        
        $asm.$str("$stl.System.Transactions.NotificationCall", ($self) => class NotificationCall extends $.$spc.System.Enum
        {
            static Prepare = 0;
            static Commit = 1;
            static Rollback = 2;
            static InDoubt = 3;
            static SinglePhaseCommit = 4;
            static Promote = 5;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Prepare": 0n,
                    "Commit": 1n,
                    "Rollback": 2n,
                    "InDoubt": 3n,
                    "SinglePhaseCommit": 4n,
                    "Promote": 5n
                };
            }
            static $h = 3324460;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":3324460,"n":"Prepare","d":3324460,"h":4298291756,"f":33},{"t":3324460,"n":"Commit","d":3324460,"h":8593259052,"f":33},{"t":3324460,"n":"Rollback","d":3324460,"h":12888226348,"f":33},{"t":3324460,"n":"InDoubt","d":3324460,"h":17183193644,"f":33},{"t":3324460,"n":"SinglePhaseCommit","d":3324460,"h":21478160940,"f":33},{"t":3324460,"n":"Promote","d":3324460,"h":25773128236,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":3324460,"h":30068095532,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":3324460}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Transactions.NotificationCall`; }
        });
        
        $asm.$str("$stl.System.Transactions.EnlistmentCallback", ($self) => class EnlistmentCallback extends $.$spc.System.Enum
        {
            static Done = 0;
            static Prepared = 1;
            static ForceRollback = 2;
            static Committed = 3;
            static Aborted = 4;
            static InDoubt = 5;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Done": 0n,
                    "Prepared": 1n,
                    "ForceRollback": 2n,
                    "Committed": 3n,
                    "Aborted": 4n,
                    "InDoubt": 5n
                };
            }
            static $h = 1817132;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1817132,"n":"Done","d":1817132,"h":4296784428,"f":33},{"t":1817132,"n":"Prepared","d":1817132,"h":8591751724,"f":33},{"t":1817132,"n":"ForceRollback","d":1817132,"h":12886719020,"f":33},{"t":1817132,"n":"Committed","d":1817132,"h":17181686316,"f":33},{"t":1817132,"n":"Aborted","d":1817132,"h":21476653612,"f":33},{"t":1817132,"n":"InDoubt","d":1817132,"h":25771620908,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1817132,"h":30066588204,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1817132}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Transactions.EnlistmentCallback`; }
        });
        
        $asm.$str("$stl.System.Transactions.TransactionScopeResult", ($self) => class TransactionScopeResult extends $.$spc.System.Enum
        {
            static CreatedTransaction = 0;
            static UsingExistingCurrent = 1;
            static TransactionPassed = 2;
            static DependentTransactionPassed = 3;
            static NoTransaction = 4;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "CreatedTransaction": 0n,
                    "UsingExistingCurrent": 1n,
                    "TransactionPassed": 2n,
                    "DependentTransactionPassed": 3n,
                    "NoTransaction": 4n
                };
            }
            static $h = 5356076;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":5356076,"n":"CreatedTransaction","d":5356076,"h":4300323372,"f":33},{"t":5356076,"n":"UsingExistingCurrent","d":5356076,"h":8595290668,"f":33},{"t":5356076,"n":"TransactionPassed","d":5356076,"h":12890257964,"f":33},{"t":5356076,"n":"DependentTransactionPassed","d":5356076,"h":17185225260,"f":33},{"t":5356076,"n":"NoTransaction","d":5356076,"h":21480192556,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":5356076,"h":25775159852,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":5356076}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Transactions.TransactionScopeResult`; }
        });
        
        $asm.$str("$stl.System.Transactions.TransactionExceptionType", ($self) => class TransactionExceptionType extends $.$spc.System.Enum
        {
            static InvalidOperationException = 0;
            static TransactionAbortedException = 1;
            static TransactionException = 2;
            static TransactionInDoubtException = 3;
            static TransactionManagerCommunicationException = 4;
            static UnrecognizedRecoveryInformation = 5;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "InvalidOperationException": 0n,
                    "TransactionAbortedException": 1n,
                    "TransactionException": 2n,
                    "TransactionInDoubtException": 3n,
                    "TransactionManagerCommunicationException": 4n,
                    "UnrecognizedRecoveryInformation": 5n
                };
            }
            static $h = 4635180;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":4635180,"n":"UnrecognizedRecoveryInformation","d":4635180,"h":25774438956,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":4635180,"h":30069406252,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":4635180}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Transactions.TransactionExceptionType`; }
        });
        
        $asm.$str("$stl.System.Transactions.TraceSourceType", ($self) => class TraceSourceType extends $.$spc.System.Enum
        {
            static TraceSourceBase = 0;
            static TraceSourceLtm = 1;
            static TraceSourceOleTx = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "TraceSourceBase": 0n,
                    "TraceSourceLtm": 1n,
                    "TraceSourceOleTx": 2n
                };
            }
            static $h = 4241964;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":4241964,"n":"TraceSourceBase","d":4241964,"h":4299209260,"f":33},{"t":4241964,"n":"TraceSourceLtm","d":4241964,"h":8594176556,"f":33},{"t":4241964,"n":"TraceSourceOleTx","d":4241964,"h":12889143852,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":4241964,"h":17184111148,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":4241964}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Transactions.TraceSourceType`; }
        });
        
        $asm.$str("$stl.System.Transactions.DefaultComContextState", ($self) => class DefaultComContextState extends $.$spc.System.Enum
        {
            static Unknown = 0;
            static Unavailable = -1;
            static Available = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unknown": 0n,
                    "Unavailable": -1n,
                    "Available": 1n
                };
            }
            static $h = 1030700;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1030700,"n":"Unknown","d":1030700,"h":4295997996,"f":33},{"t":1030700,"n":"Unavailable","d":1030700,"h":8590965292,"f":33},{"t":1030700,"n":"Available","d":1030700,"h":12885932588,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1030700,"h":17180899884,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1030700}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Transactions.DefaultComContextState`; }
        });
        
        $asm.$str("$stl.System.Transactions.TxLookup", ($self) => class TxLookup extends $.$spc.System.Enum
        {
            static Default = 0;
            static DefaultCallContext = 1;
            static DefaultTLS = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Default": 0n,
                    "DefaultCallContext": 1n,
                    "DefaultTLS": 2n
                };
            }
            static $h = 8632876;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":8632876,"n":"Default","d":8632876,"h":4303600172,"f":33},{"t":8632876,"n":"DefaultCallContext","d":8632876,"h":8598567468,"f":33},{"t":8632876,"n":"DefaultTLS","d":8632876,"h":12893534764,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":8632876,"h":17188502060,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":8632876}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Transactions.TxLookup`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateActive", ($self) => class TransactionStateActive extends $.$stl.System.Transactions.EnlistableStates
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
            }
            /*void */ BeginCommit(/*InternalTransaction*/ tx, /*bool*/ asyncCommit, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                tx._asyncCommit = asyncCommit;
                tx._asyncCallback = asyncCallback;
                tx._asyncState = asyncState;
                $.$stl.System.Transactions.TransactionState.TransactionStatePhase0.EnterState(tx);
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                tx._innerException ??= e;
                $.$stl.System.Transactions.TransactionState.TransactionStateAborted.EnterState(tx);
            }
            /*Enlistment */ EnlistVolatile(/*InternalTransaction*/ tx, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                /*Enlistment*/ let enlistment = new $.$stl.System.Transactions.Enlistment().$ctor$3(tx, enlistmentNotification, null, atomicTransaction, enlistmentOptions);
                if ((enlistmentOptions & 1/*EnlistmentOptions.EnlistDuringPrepareRequired*/) !== 0)
                {
                    $.$stl.System.Transactions.TransactionState.AddVolatileEnlistment($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase0Volatiles, ($v) => tx._phase0Volatiles = $v, null), enlistment);
                }
                else 
                {
                    $.$stl.System.Transactions.TransactionState.AddVolatileEnlistment($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase1Volatiles, ($v) => tx._phase1Volatiles = $v, null), enlistment);
                }
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionstateEnlist(enlistment.InternalEnlistment.EnlistmentTraceId, 0/*EnlistmentType.Volatile*/, enlistmentOptions);
                }
                return enlistment;
            }
            /*Enlistment */ EnlistVolatile$1(/*InternalTransaction*/ tx, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                /*Enlistment*/ let enlistment = new $.$stl.System.Transactions.Enlistment().$ctor$3(tx, enlistmentNotification, enlistmentNotification, atomicTransaction, enlistmentOptions);
                if ((enlistmentOptions & 1/*EnlistmentOptions.EnlistDuringPrepareRequired*/) !== 0)
                {
                    $.$stl.System.Transactions.TransactionState.AddVolatileEnlistment($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase0Volatiles, ($v) => tx._phase0Volatiles = $v, null), enlistment);
                }
                else 
                {
                    $.$stl.System.Transactions.TransactionState.AddVolatileEnlistment($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase1Volatiles, ($v) => tx._phase1Volatiles = $v, null), enlistment);
                }
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionstateEnlist(enlistment.InternalEnlistment.EnlistmentTraceId, 0/*EnlistmentType.Volatile*/, enlistmentOptions);
                }
                return enlistment;
            }
            /*bool */ EnlistPromotableSinglePhase(/*InternalTransaction*/ tx, /*IPromotableSinglePhaseNotification*/ promotableSinglePhaseNotification, /*Transaction*/ atomicTransaction, /*Guid*/ promoterType)
            {
                if (tx._durableEnlistment !== null)
                {
                    return false;
                }
                $.$stl.System.Transactions.TransactionState.TransactionStatePSPEOperation.PSPEInitialize(tx, promotableSinglePhaseNotification, promoterType);
                /*Enlistment*/ let en = new $.$stl.System.Transactions.Enlistment().$ctor$4(tx, promotableSinglePhaseNotification, atomicTransaction);
                tx._durableEnlistment = en.InternalEnlistment;
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionstateEnlist(tx._durableEnlistment.EnlistmentTraceId, 2/*EnlistmentType.PromotableSinglePhase*/, 0/*EnlistmentOptions.None*/);
                }
                tx._promoter = promotableSinglePhaseNotification;
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Guid.op_Inequality(tx._promoterType, $.$spc.System.Guid.Empty), "InternalTransaction.PromoterType was not set in PSPEInitialize");
                if ($.$spc.System.Guid.op_Equality(tx._promoterType, $.$stl.System.Transactions.TransactionInterop.PromoterTypeDtc))
                {
                    tx._promoteState = $.$stl.System.Transactions.TransactionState.TransactionStateDelegated;
                }
                else 
                {
                    tx._promoteState = $.$stl.System.Transactions.TransactionState.TransactionStateDelegatedNonMSDTC;
                }
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentActive.EnterState(tx._durableEnlistment);
                return true;
            }
            /*void */ Phase0VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ Phase1VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ DisposeRoot(/*InternalTransaction*/ tx)
            {
                tx.State.Rollback(tx, null);
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 5880364;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1686060,"m":[{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"EnterState","d":5880364,"h":4300847660,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"asyncCommit","p":262145},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":5880364,"h":8595814956,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"e","p":47185921}],"n":"Rollback","d":5880364,"h":12890782252,"f":32776},{"r":1751596,"p":[{"n":"tx","p":2800172},{"n":"enlistmentNotification","p":2603564},{"n":"enlistmentOptions","p":1882668},{"n":"atomicTransaction","p":4307500}],"n":"EnlistVolatile","d":5880364,"h":17185749548,"f":32776},{"r":1751596,"p":[{"n":"tx","p":2800172},{"n":"enlistmentNotification","p":3062316},{"n":"enlistmentOptions","p":1882668},{"n":"atomicTransaction","p":4307500}],"n":"EnlistVolatile","o":"@$1","d":5880364,"h":21480716844,"f":32776},{"r":262145,"p":[{"n":"tx","p":2800172},{"n":"promotableSinglePhaseNotification","p":2865708},{"n":"atomicTransaction","p":4307500},{"n":"promoterType","p":56164353}],"n":"EnlistPromotableSinglePhase","d":5880364,"h":25775684140,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"Phase0VolatilePrepareDone","d":5880364,"h":30070651436,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"Phase1VolatilePrepareDone","d":5880364,"h":34365618732,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"DisposeRoot","d":5880364,"h":38660586028,"f":32776}],"c":[{"n":".ctor","o":"$ctor$4","d":5880364,"h":42955553324,"f":1}],"h":5880364}; }
            static get $b() { return $.$stl.System.Transactions.EnlistableStates; }
            static get $fullName() { return `System.Transactions.TransactionStateActive`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePhase0", ($self) => class TransactionStatePhase0 extends $.$stl.System.Transactions.EnlistableStates
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                /*int*/ let volatileCount = tx._phase0Volatiles._volatileEnlistmentCount;
                /*int*/ let dependentCount = tx._phase0Volatiles._dependentClones;
                tx._phase0VolatileWaveCount = volatileCount;
                if (tx._phase0Volatiles._preparedVolatileEnlistments < ((volatileCount + dependentCount) | 0))
                {
                    for(/*int*/ let i = 0; i < volatileCount; i++)
                    {
                        $.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i)._twoPhaseState.ChangeStatePreparing($.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i));
                        if (!tx.State.ContinuePhase0Prepares())
                        {
                            break;
                        }
                    }
                }
                else 
                {
                    $.$stl.System.Transactions.TransactionState.TransactionStateVolatilePhase1.EnterState(tx);
                }
            }
            /*Enlistment */ EnlistDurable(/*InternalTransaction*/ tx, /*Guid*/ resourceManagerIdentifier, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                tx.ThrowIfPromoterTypeIsNotMSDTC();
                /*Enlistment*/ let en = super.EnlistDurable(tx, resourceManagerIdentifier, enlistmentNotification, enlistmentOptions, atomicTransaction);
                tx.State.RestartCommitIfNeeded(tx);
                return en;
            }
            /*Enlistment */ EnlistDurable$1(/*InternalTransaction*/ tx, /*Guid*/ resourceManagerIdentifier, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                tx.ThrowIfPromoterTypeIsNotMSDTC();
                /*Enlistment*/ let en = super.EnlistDurable$1(tx, resourceManagerIdentifier, enlistmentNotification, enlistmentOptions, atomicTransaction);
                tx.State.RestartCommitIfNeeded(tx);
                return en;
            }
            /*Enlistment */ EnlistVolatile(/*InternalTransaction*/ tx, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                /*Enlistment*/ let enlistment = new $.$stl.System.Transactions.Enlistment().$ctor$3(tx, enlistmentNotification, null, atomicTransaction, enlistmentOptions);
                if ((enlistmentOptions & 1/*EnlistmentOptions.EnlistDuringPrepareRequired*/) !== 0)
                {
                    $.$stl.System.Transactions.TransactionState.AddVolatileEnlistment($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase0Volatiles, ($v) => tx._phase0Volatiles = $v, null), enlistment);
                }
                else 
                {
                    $.$stl.System.Transactions.TransactionState.AddVolatileEnlistment($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase1Volatiles, ($v) => tx._phase1Volatiles = $v, null), enlistment);
                }
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionstateEnlist(enlistment.InternalEnlistment.EnlistmentTraceId, 0/*EnlistmentType.Volatile*/, enlistmentOptions);
                }
                return enlistment;
            }
            /*Enlistment */ EnlistVolatile$1(/*InternalTransaction*/ tx, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                /*Enlistment*/ let enlistment = new $.$stl.System.Transactions.Enlistment().$ctor$3(tx, enlistmentNotification, enlistmentNotification, atomicTransaction, enlistmentOptions);
                if ((enlistmentOptions & 1/*EnlistmentOptions.EnlistDuringPrepareRequired*/) !== 0)
                {
                    $.$stl.System.Transactions.TransactionState.AddVolatileEnlistment($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase0Volatiles, ($v) => tx._phase0Volatiles = $v, null), enlistment);
                }
                else 
                {
                    $.$stl.System.Transactions.TransactionState.AddVolatileEnlistment($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase1Volatiles, ($v) => tx._phase1Volatiles = $v, null), enlistment);
                }
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionstateEnlist(enlistment.InternalEnlistment.EnlistmentTraceId, 0/*EnlistmentType.Volatile*/, enlistmentOptions);
                }
                return enlistment;
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                this.ChangeStateTransactionAborted(tx, e);
            }
            /*bool */ EnlistPromotableSinglePhase(/*InternalTransaction*/ tx, /*IPromotableSinglePhaseNotification*/ promotableSinglePhaseNotification, /*Transaction*/ atomicTransaction, /*Guid*/ promoterType)
            {
                if (tx._durableEnlistment !== null)
                {
                    return false;
                }
                $.$stl.System.Transactions.TransactionState.TransactionStatePSPEOperation.Phase0PSPEInitialize(tx, promotableSinglePhaseNotification, promoterType);
                /*Enlistment*/ let en = new $.$stl.System.Transactions.Enlistment().$ctor$4(tx, promotableSinglePhaseNotification, atomicTransaction);
                tx._durableEnlistment = en.InternalEnlistment;
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionstateEnlist(tx._durableEnlistment.EnlistmentTraceId, 2/*EnlistmentType.PromotableSinglePhase*/, 0/*EnlistmentOptions.None*/);
                }
                tx._promoter = promotableSinglePhaseNotification;
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Guid.op_Inequality(tx._promoterType, $.$spc.System.Guid.Empty), "InternalTransaction.PromoterType was not set in Phase0PSPEInitialize");
                if ($.$spc.System.Guid.op_Equality(tx._promoterType, $.$stl.System.Transactions.TransactionInterop.PromoterTypeDtc))
                {
                    tx._promoteState = $.$stl.System.Transactions.TransactionState.TransactionStateDelegated;
                }
                else 
                {
                    tx._promoteState = $.$stl.System.Transactions.TransactionState.TransactionStateDelegatedNonMSDTC;
                }
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentActive.EnterState(tx._durableEnlistment);
                return true;
            }
            /*void */ Phase0VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
                /*int*/ let volatileCount = tx._phase0Volatiles._volatileEnlistmentCount;
                /*int*/ let dependentCount = tx._phase0Volatiles._dependentClones;
                tx._phase0VolatileWaveCount = volatileCount;
                if (tx._phase0Volatiles._preparedVolatileEnlistments < ((volatileCount + dependentCount) | 0))
                {
                    for(/*int*/ let i = 0; i < volatileCount; i++)
                    {
                        $.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i)._twoPhaseState.ChangeStatePreparing($.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i));
                        if (!tx.State.ContinuePhase0Prepares())
                        {
                            break;
                        }
                    }
                }
                else 
                {
                    $.$stl.System.Transactions.TransactionState.TransactionStateVolatilePhase1.EnterState(tx);
                }
            }
            /*void */ Phase1VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ RestartCommitIfNeeded(/*InternalTransaction*/ tx)
            {
            }
            /*bool */ ContinuePhase0Prepares()
            {
                return true;
            }
            /*void */ Promote(/*InternalTransaction*/ tx)
            {
                tx._promoteState.EnterState(tx);
                tx.State.CheckForFinishedTransaction(tx);
                tx.State.RestartCommitIfNeeded(tx);
            }
            /*void */ ChangeStateTransactionAborted(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                tx._innerException ??= e;
                $.$stl.System.Transactions.TransactionState.TransactionStateAborted.EnterState(tx);
            }
            /*void */ GetObjectData(/*InternalTransaction*/ tx, /*SerializationInfo*/ serializationInfo, /*StreamingContext*/ context)
            {
                tx.ThrowIfPromoterTypeIsNotMSDTC();
                tx._promoteState.EnterState(tx);
                tx.State.GetObjectData(tx, serializationInfo, context);
                tx.State.RestartCommitIfNeeded(tx);
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 6666796;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1686060,"m":[{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"EnterState","d":6666796,"h":4301634092,"f":32776},{"r":1751596,"p":[{"n":"tx","p":2800172},{"n":"resourceManagerIdentifier","p":56164353},{"n":"enlistmentNotification","p":2603564},{"n":"enlistmentOptions","p":1882668},{"n":"atomicTransaction","p":4307500}],"n":"EnlistDurable","d":6666796,"h":8596601388,"f":32776},{"r":1751596,"p":[{"n":"tx","p":2800172},{"n":"resourceManagerIdentifier","p":56164353},{"n":"enlistmentNotification","p":3062316},{"n":"enlistmentOptions","p":1882668},{"n":"atomicTransaction","p":4307500}],"n":"EnlistDurable","o":"@$1","d":6666796,"h":12891568684,"f":32776},{"r":1751596,"p":[{"n":"tx","p":2800172},{"n":"enlistmentNotification","p":2603564},{"n":"enlistmentOptions","p":1882668},{"n":"atomicTransaction","p":4307500}],"n":"EnlistVolatile","d":6666796,"h":17186535980,"f":32776},{"r":1751596,"p":[{"n":"tx","p":2800172},{"n":"enlistmentNotification","p":3062316},{"n":"enlistmentOptions","p":1882668},{"n":"atomicTransaction","p":4307500}],"n":"EnlistVolatile","o":"@$1","d":6666796,"h":21481503276,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"e","p":47185921}],"n":"Rollback","d":6666796,"h":25776470572,"f":32776},{"r":262145,"p":[{"n":"tx","p":2800172},{"n":"promotableSinglePhaseNotification","p":2865708},{"n":"atomicTransaction","p":4307500},{"n":"promoterType","p":56164353}],"n":"EnlistPromotableSinglePhase","d":6666796,"h":30071437868,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"Phase0VolatilePrepareDone","d":6666796,"h":34366405164,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"Phase1VolatilePrepareDone","d":6666796,"h":38661372460,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"RestartCommitIfNeeded","d":6666796,"h":42956339756,"f":32776},{"r":262145,"n":"ContinuePhase0Prepares","d":6666796,"h":47251307052,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"Promote","d":6666796,"h":51546274348,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"e","p":47185921}],"n":"ChangeStateTransactionAborted","d":6666796,"h":55841241644,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"serializationInfo","p":113967105},{"n":"context","p":114098177}],"n":"GetObjectData","d":6666796,"h":60136208940,"f":32776}],"c":[{"n":".ctor","o":"$ctor$4","d":6666796,"h":64431176236,"f":1}],"h":6666796}; }
            static get $b() { return $.$stl.System.Transactions.EnlistableStates; }
            static get $fullName() { return `System.Transactions.TransactionStatePhase0`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedP0Aborting", ($self) => class TransactionStatePromotedP0Aborting extends $.$stl.System.Transactions.TransactionStatePromotedAborting
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                this.ChangeStatePromotedAborted(tx);
                if (tx._phase0Volatiles.VolatileDemux._preparingEnlistment !== null)
                {
                    $.$spc.System.Threading.Monitor.Exit(tx);
                    try
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(tx._phase0Volatiles.VolatileDemux._promotedEnlistment !== null, "tx._phase0Volatiles.VolatileDemux._promotedEnlistment != null");
                        tx._phase0Volatiles.VolatileDemux._promotedEnlistment.System$Transactions$IPromotedEnlistment$ForceRollback();
                    }
                    finally
                    {
                        {
                            $.$spc.System.Threading.Monitor.Enter(tx);
                        }
                    }
                }
                else 
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(tx.PromotedTransaction !== null, "tx.PromotedTransaction != null");
                    tx.PromotedTransaction.Rollback();
                }
            }
            /*void */ Phase0VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 7780908;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6863404,"m":[{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"EnterState","d":7780908,"h":4302748204,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"Phase0VolatilePrepareDone","d":7780908,"h":8597715500,"f":32776}],"c":[{"n":".ctor","o":"$ctor$4","d":7780908,"h":12892682796,"f":1}],"h":7780908}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedAborting; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedP0Aborting`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedP1Aborting", ($self) => class TransactionStatePromotedP1Aborting extends $.$stl.System.Transactions.TransactionStatePromotedAborting
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                $.$spc.System.Diagnostics.Debug.Assert$1(tx._phase1Volatiles.VolatileDemux !== null, "Volatile Demux must exist.");
                this.ChangeStatePromotedAborted(tx);
                $.$spc.System.Threading.Monitor.Exit(tx);
                try
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(tx._phase1Volatiles.VolatileDemux._promotedEnlistment !== null, "tx._phase1Volatiles.VolatileDemux._promotedEnlistment != null");
                    tx._phase1Volatiles.VolatileDemux._promotedEnlistment.System$Transactions$IPromotedEnlistment$ForceRollback();
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(tx);
                    }
                }
            }
            /*void */ Phase1VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 7911980;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6863404,"m":[{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"EnterState","d":7911980,"h":4302879276,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"Phase1VolatilePrepareDone","d":7911980,"h":8597846572,"f":32776}],"c":[{"n":".ctor","o":"$ctor$4","d":7911980,"h":12892813868,"f":1}],"h":7911980}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedAborting; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedP1Aborting`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedAborted", ($self) => class TransactionStatePromotedAborted extends $.$stl.System.Transactions.TransactionStatePromotedEnded
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                super.EnterState(tx);
                if (tx._phase1Volatiles.VolatileDemux !== null)
                {
                    $.$stl.System.Transactions.VolatileDemultiplexer.BroadcastRollback($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase1Volatiles, ($v) => tx._phase1Volatiles = $v, null));
                }
                if (tx._phase0Volatiles.VolatileDemux !== null)
                {
                    $.$stl.System.Transactions.VolatileDemultiplexer.BroadcastRollback($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase0Volatiles, ($v) => tx._phase0Volatiles = $v, null));
                }
                tx.FireCompletion();
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionAborted(1/*TraceSourceType.TraceSourceLtm*/, tx.TransactionTraceId);
                }
            }
            /*TransactionStatus */ get_Status(/*InternalTransaction*/ tx)
            {
                return 2/*TransactionStatus.Aborted*/;
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
            }
            /*void */ BeginCommit(/*InternalTransaction*/ tx, /*bool*/ asyncCommit, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw $.$stl.System.Transactions.TransactionAbortedException.Create$3($.$stl.System.SR.TransactionAborted, tx._innerException, tx.DistributedTxId);
            }
            /*void */ CreateBlockingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionAbortedException.Create$3($.$stl.System.SR.TransactionAborted, tx._innerException, tx.DistributedTxId);
            }
            /*void */ CreateAbortingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionAbortedException.Create$3($.$stl.System.SR.TransactionAborted, tx._innerException, tx.DistributedTxId);
            }
            /*void */ RestartCommitIfNeeded(/*InternalTransaction*/ tx)
            {
            }
            /*void */ Phase0VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ Phase1VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ ChangeStatePromotedPhase0(/*InternalTransaction*/ tx)
            {
                throw new $.$stl.System.Transactions.TransactionAbortedException().$ctor$17(tx._innerException, tx.DistributedTxId);
            }
            /*void */ ChangeStatePromotedPhase1(/*InternalTransaction*/ tx)
            {
                throw new $.$stl.System.Transactions.TransactionAbortedException().$ctor$17(tx._innerException, tx.DistributedTxId);
            }
            /*void */ ChangeStatePromotedAborted(/*InternalTransaction*/ tx)
            {
            }
            /*void */ ChangeStateTransactionAborted(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
            }
            /*void */ PromotedTransactionOutcome(/*InternalTransaction*/ tx)
            {
                if ((null === tx._innerException) && (null !== tx.PromotedTransaction))
                {
                    tx._innerException = tx.PromotedTransaction.InnerException;
                }
                throw $.$stl.System.Transactions.TransactionAbortedException.Create$3($.$stl.System.SR.TransactionAborted, tx._innerException, tx.DistributedTxId);
            }
            /*void */ CheckForFinishedTransaction(/*InternalTransaction*/ tx)
            {
                throw new $.$stl.System.Transactions.TransactionAbortedException().$ctor$17(tx._innerException, tx.DistributedTxId);
            }
            /*void */ GetObjectData(/*InternalTransaction*/ tx, /*SerializationInfo*/ serializationInfo, /*StreamingContext*/ context)
            {
                throw $.$stl.System.Transactions.TransactionAbortedException.Create$3($.$stl.System.SR.TransactionAborted, tx._innerException, tx.DistributedTxId);
            }
            /*void */ InDoubtFromDtc(/*InternalTransaction*/ tx)
            {
            }
            /*void */ InDoubtFromEnlistment(/*InternalTransaction*/ tx)
            {
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 6797868;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7125548,"m":[{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"EnterState","d":6797868,"h":4301765164,"f":32776},{"r":8436268,"p":[{"n":"tx","p":2800172}],"n":"get_Status","d":6797868,"h":8596732460,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"e","p":47185921}],"n":"Rollback","d":6797868,"h":12891699756,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"asyncCommit","p":262145},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":6797868,"h":17186667052,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"CreateBlockingClone","d":6797868,"h":21481634348,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"CreateAbortingClone","d":6797868,"h":25776601644,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"RestartCommitIfNeeded","d":6797868,"h":30071568940,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"Phase0VolatilePrepareDone","d":6797868,"h":34366536236,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"Phase1VolatilePrepareDone","d":6797868,"h":38661503532,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"ChangeStatePromotedPhase0","d":6797868,"h":42956470828,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"ChangeStatePromotedPhase1","d":6797868,"h":47251438124,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"ChangeStatePromotedAborted","d":6797868,"h":51546405420,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"e","p":47185921}],"n":"ChangeStateTransactionAborted","d":6797868,"h":55841372716,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"PromotedTransactionOutcome","d":6797868,"h":60136340012,"f":32772},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"CheckForFinishedTransaction","d":6797868,"h":64431307308,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"serializationInfo","p":113967105},{"n":"context","p":114098177}],"n":"GetObjectData","d":6797868,"h":68726274604,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"InDoubtFromDtc","d":6797868,"h":73021241900,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"InDoubtFromEnlistment","d":6797868,"h":77316209196,"f":32776}],"c":[{"n":".ctor","o":"$ctor$4","d":6797868,"h":81611176492,"f":1}],"h":6797868}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedEnded; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedAborted`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedCommitted", ($self) => class TransactionStatePromotedCommitted extends $.$stl.System.Transactions.TransactionStatePromotedEnded
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                super.EnterState(tx);
                if (tx._phase1Volatiles.VolatileDemux !== null)
                {
                    $.$stl.System.Transactions.VolatileDemultiplexer.BroadcastCommitted($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase1Volatiles, ($v) => tx._phase1Volatiles = $v, null));
                }
                if (tx._phase0Volatiles.VolatileDemux !== null)
                {
                    $.$stl.System.Transactions.VolatileDemultiplexer.BroadcastCommitted($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase0Volatiles, ($v) => tx._phase0Volatiles = $v, null));
                }
                tx.FireCompletion();
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionCommitted(1/*TraceSourceType.TraceSourceLtm*/, tx.TransactionTraceId);
                }
            }
            /*TransactionStatus */ get_Status(/*InternalTransaction*/ tx)
            {
                return 1/*TransactionStatus.Committed*/;
            }
            /*void */ ChangeStatePromotedCommitted(/*InternalTransaction*/ tx)
            {
            }
            /*void */ PromotedTransactionOutcome(/*InternalTransaction*/ tx)
            {
            }
            /*void */ InDoubtFromDtc(/*InternalTransaction*/ tx)
            {
            }
            /*void */ InDoubtFromEnlistment(/*InternalTransaction*/ tx)
            {
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 6994476;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7125548,"m":[{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"EnterState","d":6994476,"h":4301961772,"f":32776},{"r":8436268,"p":[{"n":"tx","p":2800172}],"n":"get_Status","d":6994476,"h":8596929068,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"ChangeStatePromotedCommitted","d":6994476,"h":12891896364,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"PromotedTransactionOutcome","d":6994476,"h":17186863660,"f":32772},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"InDoubtFromDtc","d":6994476,"h":21481830956,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"InDoubtFromEnlistment","d":6994476,"h":25776798252,"f":32776}],"c":[{"n":".ctor","o":"$ctor$4","d":6994476,"h":30071765548,"f":1}],"h":6994476}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedEnded; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedCommitted`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedIndoubt", ($self) => class TransactionStatePromotedIndoubt extends $.$stl.System.Transactions.TransactionStatePromotedEnded
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                super.EnterState(tx);
                if (tx._phase1Volatiles.VolatileDemux !== null)
                {
                    $.$stl.System.Transactions.VolatileDemultiplexer.BroadcastInDoubt($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase1Volatiles, ($v) => tx._phase1Volatiles = $v, null));
                }
                if (tx._phase0Volatiles.VolatileDemux !== null)
                {
                    $.$stl.System.Transactions.VolatileDemultiplexer.BroadcastInDoubt($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase0Volatiles, ($v) => tx._phase0Volatiles = $v, null));
                }
                tx.FireCompletion();
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionInDoubt(1/*TraceSourceType.TraceSourceLtm*/, tx.TransactionTraceId);
                }
            }
            /*TransactionStatus */ get_Status(/*InternalTransaction*/ tx)
            {
                return 3/*TransactionStatus.InDoubt*/;
            }
            /*void */ RestartCommitIfNeeded(/*InternalTransaction*/ tx)
            {
            }
            /*void */ ChangeStatePromotedPhase0(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionInDoubtException.Create$3(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionIndoubt, tx._innerException, tx.DistributedTxId);
            }
            /*void */ ChangeStatePromotedPhase1(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionInDoubtException.Create$3(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionIndoubt, tx._innerException, tx.DistributedTxId);
            }
            /*void */ InDoubtFromDtc(/*InternalTransaction*/ tx)
            {
            }
            /*void */ InDoubtFromEnlistment(/*InternalTransaction*/ tx)
            {
            }
            /*void */ PromotedTransactionOutcome(/*InternalTransaction*/ tx)
            {
                if ((null === tx._innerException) && (null !== tx.PromotedTransaction))
                {
                    tx._innerException = tx.PromotedTransaction.InnerException;
                }
                throw $.$stl.System.Transactions.TransactionInDoubtException.Create$3(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionIndoubt, tx._innerException, tx.DistributedTxId);
            }
            /*void */ CheckForFinishedTransaction(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionInDoubtException.Create$3(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionIndoubt, tx._innerException, tx.DistributedTxId);
            }
            /*void */ GetObjectData(/*InternalTransaction*/ tx, /*SerializationInfo*/ serializationInfo, /*StreamingContext*/ context)
            {
                throw $.$stl.System.Transactions.TransactionInDoubtException.Create$3(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionIndoubt, tx._innerException, tx.DistributedTxId);
            }
            /*void */ ChangeStatePromotedAborted(/*InternalTransaction*/ tx)
            {
            }
            /*void */ ChangeStatePromotedCommitted(/*InternalTransaction*/ tx)
            {
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 7191084;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7125548,"m":[{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"EnterState","d":7191084,"h":4302158380,"f":32776},{"r":8436268,"p":[{"n":"tx","p":2800172}],"n":"get_Status","d":7191084,"h":8597125676,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"RestartCommitIfNeeded","d":7191084,"h":12892092972,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"ChangeStatePromotedPhase0","d":7191084,"h":17187060268,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"ChangeStatePromotedPhase1","d":7191084,"h":21482027564,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"InDoubtFromDtc","d":7191084,"h":25776994860,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"InDoubtFromEnlistment","d":7191084,"h":30071962156,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"PromotedTransactionOutcome","d":7191084,"h":34366929452,"f":32772},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"CheckForFinishedTransaction","d":7191084,"h":38661896748,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"serializationInfo","p":113967105},{"n":"context","p":114098177}],"n":"GetObjectData","d":7191084,"h":42956864044,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"ChangeStatePromotedAborted","d":7191084,"h":47251831340,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"ChangeStatePromotedCommitted","d":7191084,"h":51546798636,"f":32776}],"c":[{"n":".ctor","o":"$ctor$4","d":7191084,"h":55841765932,"f":1}],"h":7191084}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedEnded; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedIndoubt`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateDelegatedBase", ($self) => class TransactionStateDelegatedBase extends $.$stl.System.Transactions.TransactionStatePromoted
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                if (tx._outcomeSource._isoLevel === 4/*IsolationLevel.Snapshot*/)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException$1(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.CannotPromoteSnapshot, null, tx.DistributedTxId);
                }
                this.CommonEnterState(tx);
                /*Oletx.OletxTransaction?*/ let distributedTx = null;
                try
                {
                    if (tx._durableEnlistment !== null)
                    {
                        /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                        if (etwLog.IsEnabled())
                        {
                            etwLog.EnlistmentStatus(1/*TraceSourceType.TraceSourceLtm*/, tx._durableEnlistment.EnlistmentTraceId, 5/*NotificationCall.Promote*/);
                        }
                    }
                    distributedTx = $.$stl.System.Transactions.TransactionState.TransactionStatePSPEOperation.PSPEPromote(tx);
                }
                catch(e)
                {
                    tx._innerException = e;
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.ExceptionConsumed$1(e);
                    }
                }
                finally
                {
                    {
                        if ((distributedTx) === null)
                        {
                            tx.State.ChangeStateAbortedDuringPromotion(tx);
                        }
                    }
                }
                if ((distributedTx) === null)
                {
                    return;
                }
                if (tx.PromotedTransaction !== distributedTx)
                {
                    tx.PromotedTransaction = distributedTx;
                    /*Hashtable*/ let promotedTransactionTable = $.$stl.System.Transactions.TransactionManager.PromotedTransactionTable;
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter(promotedTransactionTable)
                        {
                            tx._finalizedObject = new $.$stl.System.Transactions.FinalizedObject().$ctor$1(tx, tx.PromotedTransaction.Identifier);
                            /*WeakReference*/ let weakRef = new $.$spc.System.WeakReference().$ctor$2(tx._outcomeSource, false);
                            promotedTransactionTable.set_Item(tx.PromotedTransaction.Identifier, weakRef);
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit(promotedTransactionTable)
                    }
                    $.$stl.System.Transactions.TransactionManager.FireDistributedTransactionStarted(tx._outcomeSource);
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.TransactionPromoted(tx.TransactionTraceId, distributedTx.TransactionTraceId);
                    }
                    this.PromoteEnlistmentsAndOutcome(tx);
                }
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 6142508;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6732332,"m":[{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"EnterState","d":6142508,"h":4301109804,"f":32776}],"c":[{"n":".ctor","o":"$ctor$4","d":6142508,"h":8596077100,"f":4}],"h":6142508}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromoted; }
            static get $fullName() { return `System.Transactions.TransactionStateDelegatedBase`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedNonMSDTCAborted", ($self) => class TransactionStatePromotedNonMSDTCAborted extends $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCEnded
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                super.EnterState(tx);
                for(/*int*/ let i = 0; i < tx._phase0Volatiles._volatileEnlistmentCount; i++)
                {
                    $.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i)._twoPhaseState.InternalAborted($.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i));
                }
                for(/*int*/ let i = 0; i < tx._phase1Volatiles._volatileEnlistmentCount; i++)
                {
                    $.$spc.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i)._twoPhaseState.InternalAborted($.$spc.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i));
                }
                tx._durableEnlistment?.State.InternalAborted(tx._durableEnlistment);
                tx.FireCompletion();
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionAborted(1/*TraceSourceType.TraceSourceLtm*/, tx.TransactionTraceId);
                }
            }
            /*TransactionStatus */ get_Status(/*InternalTransaction*/ tx)
            {
                return 2/*TransactionStatus.Aborted*/;
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
            }
            /*void */ BeginCommit(/*InternalTransaction*/ tx, /*bool*/ asyncCommit, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw $.$stl.System.Transactions.TransactionAbortedException.Create$3($.$stl.System.SR.TransactionAborted, tx._innerException, tx.DistributedTxId);
            }
            /*void */ CreateBlockingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionAbortedException.Create$3($.$stl.System.SR.TransactionAborted, tx._innerException, tx.DistributedTxId);
            }
            /*void */ CreateAbortingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionAbortedException.Create$3($.$stl.System.SR.TransactionAborted, tx._innerException, tx.DistributedTxId);
            }
            /*void */ Phase0VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ Phase1VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ ChangeStateTransactionAborted(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
            }
            /*void */ PromotedTransactionOutcome(/*InternalTransaction*/ tx)
            {
                if ((null === tx._innerException) && (null !== tx.PromotedTransaction))
                {
                    tx._innerException = tx.PromotedTransaction.InnerException;
                }
                throw $.$stl.System.Transactions.TransactionAbortedException.Create$3($.$stl.System.SR.TransactionAborted, tx._innerException, tx.DistributedTxId);
            }
            /*void */ CheckForFinishedTransaction(/*InternalTransaction*/ tx)
            {
                throw new $.$stl.System.Transactions.TransactionAbortedException().$ctor$17(tx._innerException, tx.DistributedTxId);
            }
            /*void */ GetObjectData(/*InternalTransaction*/ tx, /*SerializationInfo*/ serializationInfo, /*StreamingContext*/ context)
            {
                throw $.$stl.System.Transactions.TransactionAbortedException.Create$3($.$stl.System.SR.TransactionAborted, tx._innerException, tx.DistributedTxId);
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 7256620;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7453228,"m":[{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"EnterState","d":7256620,"h":4302223916,"f":32776},{"r":8436268,"p":[{"n":"tx","p":2800172}],"n":"get_Status","d":7256620,"h":8597191212,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"e","p":47185921}],"n":"Rollback","d":7256620,"h":12892158508,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"asyncCommit","p":262145},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":7256620,"h":17187125804,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"CreateBlockingClone","d":7256620,"h":21482093100,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"CreateAbortingClone","d":7256620,"h":25777060396,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"Phase0VolatilePrepareDone","d":7256620,"h":30072027692,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"Phase1VolatilePrepareDone","d":7256620,"h":34366994988,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"e","p":47185921}],"n":"ChangeStateTransactionAborted","d":7256620,"h":38661962284,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"PromotedTransactionOutcome","d":7256620,"h":42956929580,"f":32772},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"CheckForFinishedTransaction","d":7256620,"h":47251896876,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"serializationInfo","p":113967105},{"n":"context","p":114098177}],"n":"GetObjectData","d":7256620,"h":51546864172,"f":32776}],"c":[{"n":".ctor","o":"$ctor$4","d":7256620,"h":55841831468,"f":1}],"h":7256620}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCEnded; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedNonMSDTCAborted`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedNonMSDTCCommitted", ($self) => class TransactionStatePromotedNonMSDTCCommitted extends $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCEnded
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                super.EnterState(tx);
                for(/*int*/ let i = 0; i < tx._phase0Volatiles._volatileEnlistmentCount; i++)
                {
                    $.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i)._twoPhaseState.InternalCommitted($.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i));
                }
                for(/*int*/ let i = 0; i < tx._phase1Volatiles._volatileEnlistmentCount; i++)
                {
                    $.$spc.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i)._twoPhaseState.InternalCommitted($.$spc.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i));
                }
                tx.FireCompletion();
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionCommitted(1/*TraceSourceType.TraceSourceLtm*/, tx.TransactionTraceId);
                }
            }
            /*TransactionStatus */ get_Status(/*InternalTransaction*/ tx)
            {
                return 1/*TransactionStatus.Committed*/;
            }
            /*void */ PromotedTransactionOutcome(/*InternalTransaction*/ tx)
            {
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 7387692;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7453228,"m":[{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"EnterState","d":7387692,"h":4302354988,"f":32776},{"r":8436268,"p":[{"n":"tx","p":2800172}],"n":"get_Status","d":7387692,"h":8597322284,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"PromotedTransactionOutcome","d":7387692,"h":12892289580,"f":32772}],"c":[{"n":".ctor","o":"$ctor$4","d":7387692,"h":17187256876,"f":1}],"h":7387692}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCEnded; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedNonMSDTCCommitted`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedNonMSDTCIndoubt", ($self) => class TransactionStatePromotedNonMSDTCIndoubt extends $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCEnded
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                super.EnterState(tx);
                for(/*int*/ let i = 0; i < tx._phase0Volatiles._volatileEnlistmentCount; i++)
                {
                    $.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i)._twoPhaseState.InternalIndoubt($.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i));
                }
                for(/*int*/ let i = 0; i < tx._phase1Volatiles._volatileEnlistmentCount; i++)
                {
                    $.$spc.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i)._twoPhaseState.InternalIndoubt($.$spc.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i));
                }
                tx.FireCompletion();
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionInDoubt(1/*TraceSourceType.TraceSourceLtm*/, tx.TransactionTraceId);
                }
            }
            /*TransactionStatus */ get_Status(/*InternalTransaction*/ tx)
            {
                return 3/*TransactionStatus.InDoubt*/;
            }
            /*void */ ChangeStatePromotedPhase0(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionInDoubtException.Create$3(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionIndoubt, tx._innerException, tx.DistributedTxId);
            }
            /*void */ ChangeStatePromotedPhase1(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionInDoubtException.Create$3(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionIndoubt, tx._innerException, tx.DistributedTxId);
            }
            /*void */ PromotedTransactionOutcome(/*InternalTransaction*/ tx)
            {
                if ((null === tx._innerException) && (null !== tx.PromotedTransaction))
                {
                    tx._innerException = tx.PromotedTransaction.InnerException;
                }
                throw $.$stl.System.Transactions.TransactionInDoubtException.Create$3(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionIndoubt, tx._innerException, tx.DistributedTxId);
            }
            /*void */ CheckForFinishedTransaction(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionInDoubtException.Create$3(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionIndoubt, tx._innerException, tx.DistributedTxId);
            }
            /*void */ GetObjectData(/*InternalTransaction*/ tx, /*SerializationInfo*/ serializationInfo, /*StreamingContext*/ context)
            {
                throw $.$stl.System.Transactions.TransactionInDoubtException.Create$3(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionIndoubt, tx._innerException, tx.DistributedTxId);
            }
            /*void */ CreateBlockingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.Create$2($.$stl.System.SR.TransactionAborted, tx._innerException, tx.DistributedTxId);
            }
            /*void */ CreateAbortingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.Create$2($.$stl.System.SR.TransactionAborted, tx._innerException, tx.DistributedTxId);
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 7518764;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7453228,"m":[{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"EnterState","d":7518764,"h":4302486060,"f":32776},{"r":8436268,"p":[{"n":"tx","p":2800172}],"n":"get_Status","d":7518764,"h":8597453356,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"ChangeStatePromotedPhase0","d":7518764,"h":12892420652,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"ChangeStatePromotedPhase1","d":7518764,"h":17187387948,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"PromotedTransactionOutcome","d":7518764,"h":21482355244,"f":32772},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"CheckForFinishedTransaction","d":7518764,"h":25777322540,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"serializationInfo","p":113967105},{"n":"context","p":114098177}],"n":"GetObjectData","d":7518764,"h":30072289836,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"CreateBlockingClone","d":7518764,"h":34367257132,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"CreateAbortingClone","d":7518764,"h":38662224428,"f":32776}],"c":[{"n":".ctor","o":"$ctor$4","d":7518764,"h":42957191724,"f":1}],"h":7518764}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCEnded; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedNonMSDTCIndoubt`; }
        });
        
        $asm.$cls("$stl.System.Transactions.PreparingEnlistment", ($self) => class PreparingEnlistment extends $.$stl.System.Transactions.Enlistment
        {
            $ctor$7(/*InternalEnlistment*/ enlistment)
            {
                super.$ctor$1(enlistment);
                {
                }
                return this;
            }
            /*void */ Prepared()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "Prepared");
                    etwLog.EnlistmentPrepared(this._internalEnlistment);
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalEnlistment.SyncRoot)
                    {
                        this._internalEnlistment.State.Prepared(this._internalEnlistment);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalEnlistment.SyncRoot)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "Prepared");
                }
            }
            /*void */ ForceRollback()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "ForceRollback");
                    etwLog.EnlistmentForceRollback(this._internalEnlistment);
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalEnlistment.SyncRoot)
                    {
                        this._internalEnlistment.State.ForceRollback(this._internalEnlistment, null);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalEnlistment.SyncRoot)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "ForceRollback");
                }
            }
            /*void */ ForceRollback$1(/*Exception?*/ e)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "ForceRollback");
                    etwLog.EnlistmentForceRollback(this._internalEnlistment);
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalEnlistment.SyncRoot)
                    {
                        this._internalEnlistment.State.ForceRollback(this._internalEnlistment, e);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalEnlistment.SyncRoot)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "ForceRollback");
                }
            }
            /*byte[] */ RecoveryInformation()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "RecoveryInformation");
                }
                try
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter(this._internalEnlistment.SyncRoot)
                        {
                            return this._internalEnlistment.State.RecoveryInformation(this._internalEnlistment);
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit(this._internalEnlistment.SyncRoot)
                    }
                }
                finally
                {
                    {
                        if (etwLog.IsEnabled())
                        {
                            etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "RecoveryInformation");
                        }
                    }
                }
            }
            static $h = 3914284;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1751596,"m":[{"r":65537,"n":"Prepared","d":3914284,"h":8593848876,"f":1},{"r":65537,"n":"ForceRollback","d":3914284,"h":12888816172,"f":1},{"r":65537,"p":[{"n":"e","p":47185921}],"n":"ForceRollback","o":"@$1","d":3914284,"h":17183783468,"f":1},{"r":0,"n":"RecoveryInformation","d":3914284,"h":21478750764,"f":1}],"c":[{"p":[{"n":"enlistment","p":2734636}],"n":".ctor","o":"$ctor$7","d":3914284,"h":4298881580,"f":8}],"h":3914284}; }
            static get $b() { return $.$stl.System.Transactions.Enlistment; }
            static get $fullName() { return `System.Transactions.PreparingEnlistment`; }
        });
        
        $asm.$cls("$stl.System.Transactions.SinglePhaseEnlistment", ($self) => class SinglePhaseEnlistment extends $.$stl.System.Transactions.Enlistment
        {
            $ctor$7(/*InternalEnlistment*/ enlistment)
            {
                super.$ctor$1(enlistment);
                {
                }
                return this;
            }
            /*void */ Aborted()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "Aborted");
                    etwLog.EnlistmentAborted(this._internalEnlistment);
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalEnlistment.SyncRoot)
                    {
                        this._internalEnlistment.State.Aborted(this._internalEnlistment, null);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalEnlistment.SyncRoot)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "Aborted");
                }
            }
            /*void */ Aborted$1(/*Exception?*/ e)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "Aborted");
                    etwLog.EnlistmentAborted(this._internalEnlistment);
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalEnlistment.SyncRoot)
                    {
                        this._internalEnlistment.State.Aborted(this._internalEnlistment, e);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalEnlistment.SyncRoot)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "Aborted");
                }
            }
            /*void */ Committed()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "Committed");
                    etwLog.EnlistmentCommitted(this._internalEnlistment);
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalEnlistment.SyncRoot)
                    {
                        this._internalEnlistment.State.Committed(this._internalEnlistment);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalEnlistment.SyncRoot)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "Committed");
                }
            }
            /*void */ InDoubt()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "InDoubt");
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalEnlistment.SyncRoot)
                    {
                        if (etwLog.IsEnabled())
                        {
                            etwLog.EnlistmentInDoubt(this._internalEnlistment);
                        }
                        this._internalEnlistment.State.InDoubt(this._internalEnlistment, null);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalEnlistment.SyncRoot)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "InDoubt");
                }
            }
            /*void */ InDoubt$1(/*Exception?*/ e)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "InDoubt");
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalEnlistment.SyncRoot)
                    {
                        if (etwLog.IsEnabled())
                        {
                            etwLog.EnlistmentInDoubt(this._internalEnlistment);
                        }
                        this._internalEnlistment.State.InDoubt(this._internalEnlistment, e);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalEnlistment.SyncRoot)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "InDoubt");
                }
            }
            static $h = 4110892;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1751596,"m":[{"r":65537,"n":"Aborted","d":4110892,"h":8594045484,"f":1},{"r":65537,"p":[{"n":"e","p":47185921}],"n":"Aborted","o":"@$1","d":4110892,"h":12889012780,"f":1},{"r":65537,"n":"Committed","d":4110892,"h":17183980076,"f":1},{"r":65537,"n":"InDoubt","d":4110892,"h":21478947372,"f":1},{"r":65537,"p":[{"n":"e","p":47185921}],"n":"InDoubt","o":"@$1","d":4110892,"h":25773914668,"f":1}],"c":[{"p":[{"n":"enlistment","p":2734636}],"n":".ctor","o":"$ctor$7","d":4110892,"h":4299078188,"f":8}],"h":4110892}; }
            static get $b() { return $.$stl.System.Transactions.Enlistment; }
            static get $fullName() { return `System.Transactions.SinglePhaseEnlistment`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionEventArgs", ($self) => class TransactionEventArgs extends $.$spc.System.EventArgs
        {
            /*Transaction?*/ _transaction = null;
            /*Transaction? */ get Transaction()
            {
                return this._transaction;
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 4504108;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46923777,"p":[{"p":4307500,"g":{"r":0,"d":0,"h":12889405996,"f":1},"n":"Transaction","d":4504108,"h":8594438700,"f":1}],"l":[{"t":4307500,"n":"_transaction","d":4504108,"h":4299471404,"f":8}],"c":[{"n":".ctor","o":"$ctor$2","d":4504108,"h":17184373292,"f":1}],"h":4504108}; }
            static get $b() { return $.$spc.System.EventArgs; }
            static get $fullName() { return `System.Transactions.TransactionEventArgs`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionsEtwProvider", ($self) => class TransactionsEtwProvider extends $.$spc.System.Diagnostics.Tracing.EventSource
        {
            /*TransactionsEtwProvider*/ static Log = null;
            $ctor$5()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*EventKeywords*/ static ALL_KEYWORDS = -1n;
            /*int*/ static CONFIGURED_DEFAULT_TIMEOUT_ADJUSTED_EVENTID = 1;
            /*int*/ static ENLISTMENT_ABORTED_EVENTID = 2;
            /*int*/ static ENLISTMENT_COMMITTED_EVENTID = 3;
            /*int*/ static ENLISTMENT_DONE_EVENTID = 4;
            /*int*/ static ENLISTMENT_LTM_EVENTID = 5;
            /*int*/ static ENLISTMENT_FORCEROLLBACK_EVENTID = 6;
            /*int*/ static ENLISTMENT_INDOUBT_EVENTID = 7;
            /*int*/ static ENLISTMENT_PREPARED_EVENTID = 8;
            /*int*/ static EXCEPTION_CONSUMED_BASE_EVENTID = 9;
            /*int*/ static EXCEPTION_CONSUMED_LTM_EVENTID = 10;
            /*int*/ static METHOD_ENTER_LTM_EVENTID = 11;
            /*int*/ static METHOD_EXIT_LTM_EVENTID = 12;
            /*int*/ static METHOD_ENTER_BASE_EVENTID = 13;
            /*int*/ static METHOD_EXIT_BASE_EVENTID = 14;
            /*int*/ static METHOD_ENTER_OLETX_EVENTID = 15;
            /*int*/ static METHOD_EXIT_OLETX_EVENTID = 16;
            /*int*/ static TRANSACTION_ABORTED_LTM_EVENTID = 17;
            /*int*/ static TRANSACTION_CLONECREATE_EVENTID = 18;
            /*int*/ static TRANSACTION_COMMIT_LTM_EVENTID = 19;
            /*int*/ static TRANSACTION_COMMITTED_LTM_EVENTID = 20;
            /*int*/ static TRANSACTION_CREATED_LTM_EVENTID = 21;
            /*int*/ static TRANSACTION_DEPENDENT_CLONE_COMPLETE_LTM_EVENTID = 22;
            /*int*/ static TRANSACTION_EXCEPTION_LTM_EVENTID = 23;
            /*int*/ static TRANSACTION_EXCEPTION_BASE_EVENTID = 24;
            /*int*/ static TRANSACTION_INDOUBT_LTM_EVENTID = 25;
            /*int*/ static TRANSACTION_INVALID_OPERATION_EVENTID = 26;
            /*int*/ static TRANSACTION_PROMOTED_EVENTID = 27;
            /*int*/ static TRANSACTION_ROLLBACK_LTM_EVENTID = 28;
            /*int*/ static TRANSACTION_SERIALIZED_EVENTID = 29;
            /*int*/ static TRANSACTION_TIMEOUT_EVENTID = 30;
            /*int*/ static TRANSACTIONMANAGER_RECOVERY_COMPLETE_EVENTID = 31;
            /*int*/ static TRANSACTIONMANAGER_REENLIST_EVENTID = 32;
            /*int*/ static TRANSACTIONSCOPE_CREATED_EVENTID = 33;
            /*int*/ static TRANSACTIONSCOPE_CURRENT_CHANGED_EVENTID = 34;
            /*int*/ static TRANSACTIONSCOPE_DISPOSED_EVENTID = 35;
            /*int*/ static TRANSACTIONSCOPE_INCOMPLETE_EVENTID = 36;
            /*int*/ static INTERNAL_ERROR_EVENTID = 37;
            /*int*/ static TRANSACTIONSCOPE_NESTED_INCORRECTLY_EVENTID = 38;
            /*int*/ static TRANSACTIONSCOPE_TIMEOUT_EVENTID = 39;
            /*int*/ static TRANSACTIONSTATE_ENLIST_EVENTID = 40;
            /*int*/ static TRANSACTION_COMMIT_OLETX_EVENTID = 41;
            /*int*/ static TRANSACTION_ROLLBACK_OLETX_EVENTID = 42;
            /*int*/ static EXCEPTION_CONSUMED_OLETX_EVENTID = 43;
            /*int*/ static TRANSACTION_COMMITTED_OLETX_EVENTID = 44;
            /*int*/ static TRANSACTION_ABORTED_OLETX_EVENTID = 45;
            /*int*/ static TRANSACTION_INDOUBT_OLETX_EVENTID = 46;
            /*int*/ static TRANSACTION_DEPENDENT_CLONE_COMPLETE_OLETX_EVENTID = 47;
            /*int*/ static TRANSACTION_DEPENDENT_CLONE_CREATE_LTM_EVENTID = 48;
            /*int*/ static TRANSACTION_DEPENDENT_CLONE_CREATE_OLETX_EVENTID = 49;
            /*int*/ static TRANSACTION_DESERIALIZED_EVENTID = 50;
            /*int*/ static TRANSACTION_CREATED_OLETX_EVENTID = 51;
            /*int*/ static ENLISTMENT_OLETX_EVENTID = 52;
            /*int*/ static ENLISTMENT_CALLBACK_POSITIVE_EVENTID = 53;
            /*int*/ static ENLISTMENT_CALLBACK_NEGATIVE_EVENTID = 54;
            /*int*/ static ENLISTMENT_CREATED_LTM_EVENTID = 55;
            /*int*/ static ENLISTMENT_CREATED_OLETX_EVENTID = 56;
            /*int*/ static TRANSACTIONMANAGER_CREATE_OLETX_EVENTID = 57;
            /*string*/ static NullInstance = null;
            static /*string */ IdOf(/*object?*/ value)
            {
                return value !== null ? $.$spc.System.Object.GetType.call(value).Name + "#" + $.$stl.System.Transactions.TransactionsEtwProvider.GetHashCode$1(value) : "(null)"/*NullInstance*/;
            }
            static /*int */ GetHashCode$1(/*object?*/ value)
            {
                const $t1 = value;
                return $.$ifnn($t1, ($t) => $.$spc.System.Object.GetHashCode.call($t)) ?? 0;
            }
            /*void */ TransactionCreated(/*TraceSourceType*/ traceSource, /*TransactionTraceIdentifier*/ txTraceId, /*string?*/ type)
            {
                if (this.IsEnabled$1(4/*EventLevel.Informational*/, -1n))
                {
                    if (traceSource === 1/*TraceSourceType.TraceSourceLtm*/)
                    {
                        this.TransactionCreatedLtm(txTraceId.TransactionIdentifier, type);
                    }
                    else if (traceSource === 2/*TraceSourceType.TraceSourceOleTx*/)
                    {
                        this.TransactionCreatedOleTx(txTraceId.TransactionIdentifier, type);
                    }
                }
            }
            /*void */ TransactionCreatedLtm(/*string*/ transactionIdentifier, /*string?*/ type)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionIdentifier);
                this.WriteEvent$8(21/*TRANSACTION_CREATED_LTM_EVENTID*/, transactionIdentifier, type);
            }
            /*void */ TransactionCreatedOleTx(/*string*/ transactionIdentifier, /*string?*/ type)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionIdentifier);
                this.WriteEvent$8(51/*TRANSACTION_CREATED_OLETX_EVENTID*/, transactionIdentifier, type);
            }
            /*void */ TransactionCloneCreate(/*Transaction*/ transaction, /*string*/ type)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$stl.System.Transactions.Transaction.op_Inequality(transaction, null), "Transaction needed for the ETW event.");
                if (this.IsEnabled$1(4/*EventLevel.Informational*/, -1n))
                {
                    if ($.$stl.System.Transactions.Transaction.op_Inequality(transaction, null) && $.$spc.System.String.op_Inequality(transaction.TransactionTraceId.TransactionIdentifier, null))
                    {
                        this.TransactionCloneCreate$1(transaction.TransactionTraceId.TransactionIdentifier, type);
                    }
                    else 
                    {
                        this.TransactionCloneCreate$1($.$spc.System.String.Empty, type);
                    }
                }
            }
            /*void */ TransactionCloneCreate$1(/*string*/ transactionIdentifier, /*string*/ type)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionIdentifier);
                this.WriteEvent$8(18/*TRANSACTION_CLONECREATE_EVENTID*/, transactionIdentifier, type);
            }
            /*void */ TransactionSerialized(/*TransactionTraceIdentifier*/ transactionTraceId)
            {
                if (this.IsEnabled$1(4/*EventLevel.Informational*/, -1n))
                {
                    this.TransactionSerialized$1(transactionTraceId.TransactionIdentifier);
                }
            }
            /*void */ TransactionSerialized$1(/*string*/ transactionIdentifier)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionIdentifier);
                this.WriteEvent$7(29/*TRANSACTION_SERIALIZED_EVENTID*/, transactionIdentifier);
            }
            /*void */ TransactionDeserialized(/*TransactionTraceIdentifier*/ transactionTraceId)
            {
                if (this.IsEnabled$1(5/*EventLevel.Verbose*/, -1n))
                {
                    this.TransactionDeserialized$1(transactionTraceId.TransactionIdentifier);
                }
            }
            /*void */ TransactionDeserialized$1(/*string*/ transactionIdentifier)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionIdentifier);
                this.WriteEvent$7(50/*TRANSACTION_DESERIALIZED_EVENTID*/, transactionIdentifier);
            }
            /*void */ TransactionExceptionTrace(/*TraceSourceType*/ traceSource, /*TransactionExceptionType*/ type, /*string?*/ message, /*string?*/ innerExceptionStr)
            {
                if (this.IsEnabled$1(2/*EventLevel.Error*/, -1n))
                {
                    if (traceSource === 0/*TraceSourceType.TraceSourceBase*/)
                    {
                        this.TransactionExceptionBase($.$spc.System.Enum.ToStringT($.$stl.System.Transactions.TransactionExceptionType, $.$spc.System.UInt32, type), message, innerExceptionStr);
                    }
                    else 
                    {
                        this.TransactionExceptionLtm($.$spc.System.Enum.ToStringT($.$stl.System.Transactions.TransactionExceptionType, $.$spc.System.UInt32, type), message, innerExceptionStr);
                    }
                }
            }
            /*void */ TransactionExceptionTrace$1(/*TransactionExceptionType*/ type, /*string?*/ message, /*string?*/ innerExceptionStr)
            {
                if (this.IsEnabled$1(2/*EventLevel.Error*/, -1n))
                {
                    this.TransactionExceptionLtm($.$spc.System.Enum.ToStringT($.$stl.System.Transactions.TransactionExceptionType, $.$spc.System.UInt32, type), message, innerExceptionStr);
                }
            }
            /*void */ TransactionExceptionBase(/*string?*/ type, /*string?*/ message, /*string?*/ innerExceptionStr)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$9(24/*TRANSACTION_EXCEPTION_BASE_EVENTID*/, type, message, innerExceptionStr);
            }
            /*void */ TransactionExceptionLtm(/*string?*/ type, /*string?*/ message, /*string?*/ innerExceptionStr)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$9(23/*TRANSACTION_EXCEPTION_LTM_EVENTID*/, type, message, innerExceptionStr);
            }
            /*void */ InvalidOperation(/*string?*/ type, /*string?*/ operation)
            {
                if (this.IsEnabled$1(2/*EventLevel.Error*/, -1n))
                {
                    this.TransactionInvalidOperation($.$spc.System.String.Empty, type, operation);
                }
            }
            /*void */ TransactionInvalidOperation(/*string?*/ transactionIdentifier, /*string?*/ type, /*string?*/ operation)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$9(26/*TRANSACTION_INVALID_OPERATION_EVENTID*/, transactionIdentifier, type, operation);
            }
            /*void */ TransactionRollback(/*TraceSourceType*/ traceSource, /*TransactionTraceIdentifier*/ txTraceId, /*string?*/ type)
            {
                if (this.IsEnabled$1(3/*EventLevel.Warning*/, -1n))
                {
                    if (traceSource === 1/*TraceSourceType.TraceSourceLtm*/)
                    {
                        this.TransactionRollbackLtm(txTraceId.TransactionIdentifier, type);
                    }
                    else if (traceSource === 2/*TraceSourceType.TraceSourceOleTx*/)
                    {
                        this.TransactionRollbackOleTx(txTraceId.TransactionIdentifier, type);
                    }
                }
            }
            /*void */ TransactionRollbackLtm(/*string*/ transactionIdentifier, /*string?*/ type)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionIdentifier);
                this.WriteEvent$8(28/*TRANSACTION_ROLLBACK_LTM_EVENTID*/, transactionIdentifier, type);
            }
            /*void */ TransactionRollbackOleTx(/*string*/ transactionIdentifier, /*string?*/ type)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionIdentifier);
                this.WriteEvent$8(42/*TRANSACTION_ROLLBACK_OLETX_EVENTID*/, transactionIdentifier, type);
            }
            /*void */ TransactionDependentCloneCreate(/*TraceSourceType*/ traceSource, /*TransactionTraceIdentifier*/ txTraceId, /*DependentCloneOption*/ option)
            {
                if (this.IsEnabled$1(4/*EventLevel.Informational*/, -1n))
                {
                    if (traceSource === 1/*TraceSourceType.TraceSourceLtm*/)
                    {
                        this.TransactionDependentCloneCreateLtm(txTraceId.TransactionIdentifier, $.$spc.System.Enum.ToStringT($.$stl.System.Transactions.DependentCloneOption, $.$spc.System.UInt32, option));
                    }
                    else if (traceSource === 2/*TraceSourceType.TraceSourceOleTx*/)
                    {
                        this.TransactionDependentCloneCreateOleTx(txTraceId.TransactionIdentifier, $.$spc.System.Enum.ToStringT($.$stl.System.Transactions.DependentCloneOption, $.$spc.System.UInt32, option));
                    }
                }
            }
            /*void */ TransactionDependentCloneCreateLtm(/*string*/ transactionIdentifier, /*string?*/ option)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionIdentifier);
                this.WriteEvent$8(48/*TRANSACTION_DEPENDENT_CLONE_CREATE_LTM_EVENTID*/, transactionIdentifier, option);
            }
            /*void */ TransactionDependentCloneCreateOleTx(/*string*/ transactionIdentifier, /*string?*/ option)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionIdentifier);
                this.WriteEvent$8(49/*TRANSACTION_DEPENDENT_CLONE_CREATE_OLETX_EVENTID*/, transactionIdentifier, option);
            }
            /*void */ TransactionDependentCloneComplete(/*TraceSourceType*/ traceSource, /*TransactionTraceIdentifier*/ txTraceId, /*string?*/ type)
            {
                if (this.IsEnabled$1(4/*EventLevel.Informational*/, -1n))
                {
                    if (traceSource === 1/*TraceSourceType.TraceSourceLtm*/)
                    {
                        this.TransactionDependentCloneCompleteLtm(txTraceId.TransactionIdentifier, type);
                    }
                    else if (traceSource === 2/*TraceSourceType.TraceSourceOleTx*/)
                    {
                        this.TransactionDependentCloneCompleteOleTx(txTraceId.TransactionIdentifier, type);
                    }
                }
            }
            /*void */ TransactionDependentCloneCompleteLtm(/*string*/ transactionIdentifier, /*string?*/ type)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionIdentifier);
                this.WriteEvent$8(22/*TRANSACTION_DEPENDENT_CLONE_COMPLETE_LTM_EVENTID*/, transactionIdentifier, type);
            }
            /*void */ TransactionDependentCloneCompleteOleTx(/*string*/ transactionIdentifier, /*string?*/ type)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionIdentifier);
                this.WriteEvent$8(47/*TRANSACTION_DEPENDENT_CLONE_COMPLETE_OLETX_EVENTID*/, transactionIdentifier, type);
            }
            /*void */ TransactionCommit(/*TraceSourceType*/ traceSource, /*TransactionTraceIdentifier*/ txTraceId, /*string?*/ type)
            {
                if (this.IsEnabled$1(5/*EventLevel.Verbose*/, -1n))
                {
                    if (traceSource === 1/*TraceSourceType.TraceSourceLtm*/)
                    {
                        this.TransactionCommitLtm(txTraceId.TransactionIdentifier, type);
                    }
                    else if (traceSource === 2/*TraceSourceType.TraceSourceOleTx*/)
                    {
                        this.TransactionCommitOleTx(txTraceId.TransactionIdentifier, type);
                    }
                }
            }
            /*void */ TransactionCommitLtm(/*string*/ transactionIdentifier, /*string?*/ type)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionIdentifier);
                this.WriteEvent$8(19/*TRANSACTION_COMMIT_LTM_EVENTID*/, transactionIdentifier, type);
            }
            /*void */ TransactionCommitOleTx(/*string*/ transactionIdentifier, /*string?*/ type)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionIdentifier);
                this.WriteEvent$8(41/*TRANSACTION_COMMIT_OLETX_EVENTID*/, transactionIdentifier, type);
            }
            /*void */ EnlistmentStatus(/*TraceSourceType*/ traceSource, /*EnlistmentTraceIdentifier*/ enlistmentTraceId, /*NotificationCall*/ notificationCall)
            {
                if (this.IsEnabled$1(5/*EventLevel.Verbose*/, -1n))
                {
                    if (traceSource === 1/*TraceSourceType.TraceSourceLtm*/)
                    {
                        this.EnlistmentStatusLtm(enlistmentTraceId.EnlistmentIdentifier, $.$spc.System.Enum.ToStringT($.$stl.System.Transactions.NotificationCall, $.$spc.System.UInt32, notificationCall));
                    }
                    else if (traceSource === 2/*TraceSourceType.TraceSourceOleTx*/)
                    {
                        this.EnlistmentStatusOleTx(enlistmentTraceId.EnlistmentIdentifier, $.$spc.System.Enum.ToStringT($.$stl.System.Transactions.NotificationCall, $.$spc.System.UInt32, notificationCall));
                    }
                }
            }
            /*void */ EnlistmentStatusLtm(/*int*/ enlistmentIdentifier, /*string*/ notificationCall)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$14(5/*ENLISTMENT_LTM_EVENTID*/, enlistmentIdentifier, notificationCall);
            }
            /*void */ EnlistmentStatusOleTx(/*int*/ enlistmentIdentifier, /*string*/ notificationCall)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$14(52/*ENLISTMENT_OLETX_EVENTID*/, enlistmentIdentifier, notificationCall);
            }
            /*void */ EnlistmentCreated(/*TraceSourceType*/ traceSource, /*EnlistmentTraceIdentifier*/ enlistmentTraceId, /*EnlistmentType*/ enlistmentType, /*EnlistmentOptions*/ enlistmentOptions)
            {
                if (this.IsEnabled$1(4/*EventLevel.Informational*/, -1n))
                {
                    if (traceSource === 1/*TraceSourceType.TraceSourceLtm*/)
                    {
                        this.EnlistmentCreatedLtm(enlistmentTraceId.EnlistmentIdentifier, $.$spc.System.Enum.ToStringT($.$stl.System.Transactions.EnlistmentType, $.$spc.System.UInt32, enlistmentType), $.$spc.System.Enum.ToStringT($.$stl.System.Transactions.EnlistmentOptions, $.$spc.System.UInt32, enlistmentOptions));
                    }
                    else if (traceSource === 2/*TraceSourceType.TraceSourceOleTx*/)
                    {
                        this.EnlistmentCreatedOleTx(enlistmentTraceId.EnlistmentIdentifier, $.$spc.System.Enum.ToStringT($.$stl.System.Transactions.EnlistmentType, $.$spc.System.UInt32, enlistmentType), $.$spc.System.Enum.ToStringT($.$stl.System.Transactions.EnlistmentOptions, $.$spc.System.UInt32, enlistmentOptions));
                    }
                }
            }
            /*void */ EnlistmentCreatedLtm(/*int*/ enlistmentIdentifier, /*string*/ enlistmentType, /*string*/ enlistmentOptions)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$17(55/*ENLISTMENT_CREATED_LTM_EVENTID*/, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive), [ $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$3(enlistmentIdentifier), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(enlistmentType), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(enlistmentOptions) ], null, null));
            }
            /*void */ EnlistmentCreatedOleTx(/*int*/ enlistmentIdentifier, /*string*/ enlistmentType, /*string*/ enlistmentOptions)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$17(56/*ENLISTMENT_CREATED_OLETX_EVENTID*/, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive), [ $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$3(enlistmentIdentifier), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(enlistmentType), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(enlistmentOptions) ], null, null));
            }
            /*void */ EnlistmentDone(/*InternalEnlistment*/ enlistment)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(enlistment !== null, "Enlistment needed for the ETW event.");
                if (this.IsEnabled$1(5/*EventLevel.Verbose*/, -1n))
                {
                    if (enlistment !== null && enlistment.EnlistmentTraceId.EnlistmentIdentifier !== 0)
                    {
                        this.EnlistmentDone$1(enlistment.EnlistmentTraceId.EnlistmentIdentifier);
                    }
                    else 
                    {
                        this.EnlistmentDone$1(0);
                    }
                }
            }
            /*void */ EnlistmentDone$1(/*int*/ enlistmentIdentifier)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$1(4/*ENLISTMENT_DONE_EVENTID*/, enlistmentIdentifier);
            }
            /*void */ EnlistmentPrepared(/*InternalEnlistment*/ enlistment)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(enlistment !== null, "Enlistment needed for the ETW event.");
                if (this.IsEnabled$1(5/*EventLevel.Verbose*/, -1n))
                {
                    if (enlistment !== null && enlistment.EnlistmentTraceId.EnlistmentIdentifier !== 0)
                    {
                        this.EnlistmentPrepared$1(enlistment.EnlistmentTraceId.EnlistmentIdentifier);
                    }
                    else 
                    {
                        this.EnlistmentPrepared$1(0);
                    }
                }
            }
            /*void */ EnlistmentPrepared$1(/*int*/ enlistmentIdentifier)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$1(8/*ENLISTMENT_PREPARED_EVENTID*/, enlistmentIdentifier);
            }
            /*void */ EnlistmentForceRollback(/*InternalEnlistment*/ enlistment)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(enlistment !== null, "Enlistment needed for the ETW event.");
                if (this.IsEnabled$1(3/*EventLevel.Warning*/, -1n))
                {
                    if (enlistment !== null && enlistment.EnlistmentTraceId.EnlistmentIdentifier !== 0)
                    {
                        this.EnlistmentForceRollback$1(enlistment.EnlistmentTraceId.EnlistmentIdentifier);
                    }
                    else 
                    {
                        this.EnlistmentForceRollback$1(0);
                    }
                }
            }
            /*void */ EnlistmentForceRollback$1(/*int*/ enlistmentIdentifier)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$1(6/*ENLISTMENT_FORCEROLLBACK_EVENTID*/, enlistmentIdentifier);
            }
            /*void */ EnlistmentAborted(/*InternalEnlistment*/ enlistment)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(enlistment !== null, "Enlistment needed for the ETW event.");
                if (this.IsEnabled$1(3/*EventLevel.Warning*/, -1n))
                {
                    if (enlistment !== null && enlistment.EnlistmentTraceId.EnlistmentIdentifier !== 0)
                    {
                        this.EnlistmentAborted$1(enlistment.EnlistmentTraceId.EnlistmentIdentifier);
                    }
                    else 
                    {
                        this.EnlistmentAborted$1(0);
                    }
                }
            }
            /*void */ EnlistmentAborted$1(/*int*/ enlistmentIdentifier)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$1(2/*ENLISTMENT_ABORTED_EVENTID*/, enlistmentIdentifier);
            }
            /*void */ EnlistmentCommitted(/*InternalEnlistment*/ enlistment)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(enlistment !== null, "Enlistment needed for the ETW event.");
                if (this.IsEnabled$1(5/*EventLevel.Verbose*/, -1n))
                {
                    if (enlistment !== null && enlistment.EnlistmentTraceId.EnlistmentIdentifier !== 0)
                    {
                        this.EnlistmentCommitted$1(enlistment.EnlistmentTraceId.EnlistmentIdentifier);
                    }
                    else 
                    {
                        this.EnlistmentCommitted$1(0);
                    }
                }
            }
            /*void */ EnlistmentCommitted$1(/*int*/ enlistmentIdentifier)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$1(3/*ENLISTMENT_COMMITTED_EVENTID*/, enlistmentIdentifier);
            }
            /*void */ EnlistmentInDoubt(/*InternalEnlistment*/ enlistment)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(enlistment !== null, "Enlistment needed for the ETW event.");
                if (this.IsEnabled$1(3/*EventLevel.Warning*/, -1n))
                {
                    if (enlistment !== null && enlistment.EnlistmentTraceId.EnlistmentIdentifier !== 0)
                    {
                        this.EnlistmentInDoubt$1(enlistment.EnlistmentTraceId.EnlistmentIdentifier);
                    }
                    else 
                    {
                        this.EnlistmentInDoubt$1(0);
                    }
                }
            }
            /*void */ EnlistmentInDoubt$1(/*int*/ enlistmentIdentifier)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$1(7/*ENLISTMENT_INDOUBT_EVENTID*/, enlistmentIdentifier);
            }
            /*void */ EnlistmentCallbackPositive(/*EnlistmentTraceIdentifier*/ enlistmentTraceIdentifier, /*EnlistmentCallback*/ callback)
            {
                if (this.IsEnabled$1(5/*EventLevel.Verbose*/, -1n))
                {
                    this.EnlistmentCallbackPositive$1(enlistmentTraceIdentifier.EnlistmentIdentifier, $.$spc.System.Enum.ToStringT($.$stl.System.Transactions.EnlistmentCallback, $.$spc.System.UInt32, callback));
                }
            }
            /*void */ EnlistmentCallbackPositive$1(/*int*/ enlistmentIdentifier, /*string?*/ callback)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$14(53/*ENLISTMENT_CALLBACK_POSITIVE_EVENTID*/, enlistmentIdentifier, callback);
            }
            /*void */ EnlistmentCallbackNegative(/*EnlistmentTraceIdentifier*/ enlistmentTraceIdentifier, /*EnlistmentCallback*/ callback)
            {
                if (this.IsEnabled$1(3/*EventLevel.Warning*/, -1n))
                {
                    this.EnlistmentCallbackNegative$1(enlistmentTraceIdentifier.EnlistmentIdentifier, $.$spc.System.Enum.ToStringT($.$stl.System.Transactions.EnlistmentCallback, $.$spc.System.UInt32, callback));
                }
            }
            /*void */ EnlistmentCallbackNegative$1(/*int*/ enlistmentIdentifier, /*string?*/ callback)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$14(54/*ENLISTMENT_CALLBACK_NEGATIVE_EVENTID*/, enlistmentIdentifier, callback);
            }
            /*void */ MethodEnter(/*TraceSourceType*/ traceSource, /*object?*/ thisOrContextObject, /*string?*/ methodname)
            {
                if (this.IsEnabled$1(5/*EventLevel.Verbose*/, -1n))
                {
                    if (traceSource === 1/*TraceSourceType.TraceSourceLtm*/)
                    {
                        this.MethodEnterTraceLtm($.$stl.System.Transactions.TransactionsEtwProvider.IdOf(thisOrContextObject), methodname);
                    }
                    else if (traceSource === 0/*TraceSourceType.TraceSourceBase*/)
                    {
                        this.MethodEnterTraceBase($.$stl.System.Transactions.TransactionsEtwProvider.IdOf(thisOrContextObject), methodname);
                    }
                    else if (traceSource === 2/*TraceSourceType.TraceSourceOleTx*/)
                    {
                        this.MethodEnterTraceDistributed($.$stl.System.Transactions.TransactionsEtwProvider.IdOf(thisOrContextObject), methodname);
                    }
                }
            }
            /*void */ MethodEnter$1(/*TraceSourceType*/ traceSource, /*string?*/ methodname)
            {
                if (this.IsEnabled$1(5/*EventLevel.Verbose*/, -1n))
                {
                    if (traceSource === 1/*TraceSourceType.TraceSourceLtm*/)
                    {
                        this.MethodEnterTraceLtm($.$spc.System.String.Empty, methodname);
                    }
                    else if (traceSource === 0/*TraceSourceType.TraceSourceBase*/)
                    {
                        this.MethodEnterTraceBase($.$spc.System.String.Empty, methodname);
                    }
                    else if (traceSource === 2/*TraceSourceType.TraceSourceOleTx*/)
                    {
                        this.MethodEnterTraceDistributed($.$spc.System.String.Empty, methodname);
                    }
                }
            }
            /*void */ MethodEnterTraceLtm(/*string*/ thisOrContextObject, /*string?*/ methodname)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$8(11/*METHOD_ENTER_LTM_EVENTID*/, thisOrContextObject, methodname);
            }
            /*void */ MethodEnterTraceBase(/*string*/ thisOrContextObject, /*string?*/ methodname)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$8(13/*METHOD_ENTER_BASE_EVENTID*/, thisOrContextObject, methodname);
            }
            /*void */ MethodEnterTraceDistributed(/*string*/ thisOrContextObject, /*string?*/ methodname)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$8(15/*METHOD_ENTER_OLETX_EVENTID*/, thisOrContextObject, methodname);
            }
            /*void */ MethodExit(/*TraceSourceType*/ traceSource, /*object?*/ thisOrContextObject, /*string?*/ methodname)
            {
                if (this.IsEnabled$1(5/*EventLevel.Verbose*/, -1n))
                {
                    if (traceSource === 1/*TraceSourceType.TraceSourceLtm*/)
                    {
                        this.MethodExitTraceLtm($.$stl.System.Transactions.TransactionsEtwProvider.IdOf(thisOrContextObject), methodname);
                    }
                    else if (traceSource === 0/*TraceSourceType.TraceSourceBase*/)
                    {
                        this.MethodExitTraceBase($.$stl.System.Transactions.TransactionsEtwProvider.IdOf(thisOrContextObject), methodname);
                    }
                    else if (traceSource === 2/*TraceSourceType.TraceSourceOleTx*/)
                    {
                        this.MethodExitTraceDistributed($.$stl.System.Transactions.TransactionsEtwProvider.IdOf(thisOrContextObject), methodname);
                    }
                }
            }
            /*void */ MethodExit$1(/*TraceSourceType*/ traceSource, /*string?*/ methodname)
            {
                if (this.IsEnabled$1(5/*EventLevel.Verbose*/, -1n))
                {
                    if (traceSource === 1/*TraceSourceType.TraceSourceLtm*/)
                    {
                        this.MethodExitTraceLtm($.$spc.System.String.Empty, methodname);
                    }
                    else if (traceSource === 0/*TraceSourceType.TraceSourceBase*/)
                    {
                        this.MethodExitTraceBase($.$spc.System.String.Empty, methodname);
                    }
                    else if (traceSource === 2/*TraceSourceType.TraceSourceOleTx*/)
                    {
                        this.MethodExitTraceDistributed($.$spc.System.String.Empty, methodname);
                    }
                }
            }
            /*void */ MethodExitTraceLtm(/*string*/ thisOrContextObject, /*string?*/ methodname)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$8(12/*METHOD_EXIT_LTM_EVENTID*/, thisOrContextObject, methodname);
            }
            /*void */ MethodExitTraceBase(/*string*/ thisOrContextObject, /*string?*/ methodname)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$8(14/*METHOD_EXIT_BASE_EVENTID*/, thisOrContextObject, methodname);
            }
            /*void */ MethodExitTraceDistributed(/*string*/ thisOrContextObject, /*string?*/ methodname)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$8(16/*METHOD_EXIT_OLETX_EVENTID*/, thisOrContextObject, methodname);
            }
            /*void */ ExceptionConsumed(/*TraceSourceType*/ traceSource, /*Exception*/ exception)
            {
                if (this.IsEnabled$1(5/*EventLevel.Verbose*/, -1n))
                {
                    switch(traceSource)
                    {
                        case 0/*TraceSourceType.TraceSourceBase*/:
                        this.ExceptionConsumedBase($.$spc.System.Exception.ToString.call(exception));
                        return;
                        case 1/*TraceSourceType.TraceSourceLtm*/:
                        this.ExceptionConsumedLtm($.$spc.System.Exception.ToString.call(exception));
                        return;
                        case 2/*TraceSourceType.TraceSourceOleTx*/:
                        this.ExceptionConsumedOleTx($.$spc.System.Exception.ToString.call(exception));
                        return;
                    }
                }
            }
            /*void */ ExceptionConsumed$1(/*Exception*/ exception)
            {
                if (this.IsEnabled$1(5/*EventLevel.Verbose*/, -1n))
                {
                    this.ExceptionConsumedLtm($.$spc.System.Exception.ToString.call(exception));
                }
            }
            /*void */ ExceptionConsumedBase(/*string*/ exceptionStr)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$7(9/*EXCEPTION_CONSUMED_BASE_EVENTID*/, exceptionStr);
            }
            /*void */ ExceptionConsumedLtm(/*string*/ exceptionStr)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$7(10/*EXCEPTION_CONSUMED_LTM_EVENTID*/, exceptionStr);
            }
            /*void */ ExceptionConsumedOleTx(/*string*/ exceptionStr)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$7(43/*EXCEPTION_CONSUMED_OLETX_EVENTID*/, exceptionStr);
            }
            /*void */ OleTxTransactionManagerCreate(/*Type*/ tmType, /*string?*/ nodeName)
            {
                if (this.IsEnabled$1(5/*EventLevel.Verbose*/, -1n))
                {
                    this.OleTxTransactionManagerCreate$1($.$spc.System.Type.ToString.call(tmType), nodeName);
                }
            }
            /*void */ OleTxTransactionManagerCreate$1(/*string*/ tmType, /*string?*/ nodeName)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$8(57/*TRANSACTIONMANAGER_CREATE_OLETX_EVENTID*/, tmType, nodeName);
            }
            /*void */ TransactionManagerReenlist(/*Guid*/ resourceManagerID)
            {
                if (this.IsEnabled$1(4/*EventLevel.Informational*/, -1n))
                {
                    this.TransactionManagerReenlistTrace($.$spc.System.Guid.ToString.call(resourceManagerID));
                }
            }
            /*void */ TransactionManagerReenlistTrace(/*string*/ rmID)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$7(32/*TRANSACTIONMANAGER_REENLIST_EVENTID*/, rmID);
            }
            /*void */ TransactionManagerRecoveryComplete(/*Guid*/ resourceManagerID)
            {
                if (this.IsEnabled$1(4/*EventLevel.Informational*/, -1n))
                {
                    this.TransactionManagerRecoveryComplete$1($.$spc.System.Guid.ToString.call(resourceManagerID));
                }
            }
            /*void */ TransactionManagerRecoveryComplete$1(/*string*/ rmID)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$7(31/*TRANSACTIONMANAGER_RECOVERY_COMPLETE_EVENTID*/, rmID);
            }
            /*void */ ConfiguredDefaultTimeoutAdjusted()
            {
                if (this.IsEnabled$1(3/*EventLevel.Warning*/, -1n))
                {
                    this.ConfiguredDefaultTimeoutAdjustedTrace();
                }
            }
            /*void */ ConfiguredDefaultTimeoutAdjustedTrace()
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent(1/*CONFIGURED_DEFAULT_TIMEOUT_ADJUSTED_EVENTID*/);
            }
            /*void */ TransactionScopeCreated(/*TransactionTraceIdentifier*/ transactionID, /*TransactionScopeResult*/ transactionScopeResult)
            {
                if (this.IsEnabled$1(4/*EventLevel.Informational*/, -1n))
                {
                    this.TransactionScopeCreated$1(transactionID.TransactionIdentifier ?? $.$spc.System.String.Empty, transactionScopeResult);
                }
            }
            /*void */ TransactionScopeCreated$1(/*string*/ transactionID, /*TransactionScopeResult*/ transactionScopeResult)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionID);
                this.WriteEvent$17(33/*TRANSACTIONSCOPE_CREATED_EVENTID*/, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive), [ $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(transactionID), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$19($.$box(transactionScopeResult, $.$stl.System.Transactions.TransactionScopeResult)) ], null, null));
            }
            /*void */ TransactionScopeCurrentChanged(/*TransactionTraceIdentifier*/ currenttransactionID, /*TransactionTraceIdentifier*/ newtransactionID)
            {
                if (this.IsEnabled$1(3/*EventLevel.Warning*/, -1n))
                {
                    /*string*/ let currentId = $.$spc.System.String.Empty;
                    /*string*/ let newId = $.$spc.System.String.Empty;
                    if ($.$spc.System.String.op_Inequality(currenttransactionID.TransactionIdentifier, null))
                    {
                        currentId = $.$spc.System.String.ToString.call(currenttransactionID.TransactionIdentifier);
                    }
                    if ($.$spc.System.String.op_Inequality(newtransactionID.TransactionIdentifier, null))
                    {
                        newId = $.$spc.System.String.ToString.call(newtransactionID.TransactionIdentifier);
                    }
                    this.TransactionScopeCurrentChanged$1(currentId, newId);
                }
            }
            /*void */ TransactionScopeCurrentChanged$1(/*string*/ currenttransactionID, /*string*/ newtransactionID)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(newtransactionID);
                this.WriteEvent$8(34/*TRANSACTIONSCOPE_CURRENT_CHANGED_EVENTID*/, currenttransactionID, newtransactionID);
            }
            /*void */ TransactionScopeNestedIncorrectly(/*TransactionTraceIdentifier*/ transactionID)
            {
                if (this.IsEnabled$1(3/*EventLevel.Warning*/, -1n))
                {
                    this.TransactionScopeNestedIncorrectly$1(transactionID.TransactionIdentifier ?? $.$spc.System.String.Empty);
                }
            }
            /*void */ TransactionScopeNestedIncorrectly$1(/*string*/ transactionID)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionID);
                this.WriteEvent$7(38/*TRANSACTIONSCOPE_NESTED_INCORRECTLY_EVENTID*/, transactionID);
            }
            /*void */ TransactionScopeDisposed(/*TransactionTraceIdentifier*/ transactionID)
            {
                if (this.IsEnabled$1(4/*EventLevel.Informational*/, -1n))
                {
                    this.TransactionScopeDisposed$1(transactionID.TransactionIdentifier ?? $.$spc.System.String.Empty);
                }
            }
            /*void */ TransactionScopeDisposed$1(/*string*/ transactionID)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionID);
                this.WriteEvent$7(35/*TRANSACTIONSCOPE_DISPOSED_EVENTID*/, transactionID);
            }
            /*void */ TransactionScopeIncomplete(/*TransactionTraceIdentifier*/ transactionID)
            {
                if (this.IsEnabled$1(3/*EventLevel.Warning*/, -1n))
                {
                    this.TransactionScopeIncomplete$1(transactionID.TransactionIdentifier ?? $.$spc.System.String.Empty);
                }
            }
            /*void */ TransactionScopeIncomplete$1(/*string*/ transactionID)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionID);
                this.WriteEvent$7(36/*TRANSACTIONSCOPE_INCOMPLETE_EVENTID*/, transactionID);
            }
            /*void */ TransactionScopeTimeout(/*TransactionTraceIdentifier*/ transactionID)
            {
                if (this.IsEnabled$1(3/*EventLevel.Warning*/, -1n))
                {
                    this.TransactionScopeTimeout$1(transactionID.TransactionIdentifier ?? $.$spc.System.String.Empty);
                }
            }
            /*void */ TransactionScopeTimeout$1(/*string*/ transactionID)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionID);
                this.WriteEvent$7(39/*TRANSACTIONSCOPE_TIMEOUT_EVENTID*/, transactionID);
            }
            /*void */ TransactionTimeout(/*TransactionTraceIdentifier*/ transactionID)
            {
                if (this.IsEnabled$1(3/*EventLevel.Warning*/, -1n))
                {
                    this.TransactionTimeout$1(transactionID.TransactionIdentifier ?? $.$spc.System.String.Empty);
                }
            }
            /*void */ TransactionTimeout$1(/*string*/ transactionID)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionID);
                this.WriteEvent$7(30/*TRANSACTION_TIMEOUT_EVENTID*/, transactionID);
            }
            /*void */ TransactionstateEnlist(/*EnlistmentTraceIdentifier*/ enlistmentID, /*EnlistmentType*/ enlistmentType, /*EnlistmentOptions*/ enlistmentOption)
            {
                if (this.IsEnabled$1(4/*EventLevel.Informational*/, -1n))
                {
                    if (enlistmentID.EnlistmentIdentifier !== 0)
                    {
                        this.TransactionstateEnlist$1($.$spc.System.Int32.ToString.call(enlistmentID.EnlistmentIdentifier), $.$spc.System.Enum.ToStringT($.$stl.System.Transactions.EnlistmentType, $.$spc.System.UInt32, enlistmentType), $.$spc.System.Enum.ToStringT($.$stl.System.Transactions.EnlistmentOptions, $.$spc.System.UInt32, enlistmentOption));
                    }
                    else 
                    {
                        this.TransactionstateEnlist$1($.$spc.System.String.Empty, $.$spc.System.Enum.ToStringT($.$stl.System.Transactions.EnlistmentType, $.$spc.System.UInt32, enlistmentType), $.$spc.System.Enum.ToStringT($.$stl.System.Transactions.EnlistmentOptions, $.$spc.System.UInt32, enlistmentOption));
                    }
                }
            }
            /*void */ TransactionstateEnlist$1(/*string*/ enlistmentID, /*string*/ type, /*string*/ option)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$9(40/*TRANSACTIONSTATE_ENLIST_EVENTID*/, enlistmentID, type, option);
            }
            /*void */ TransactionCommitted(/*TraceSourceType*/ traceSource, /*TransactionTraceIdentifier*/ transactionID)
            {
                if (this.IsEnabled$1(5/*EventLevel.Verbose*/, -1n))
                {
                    if (traceSource === 1/*TraceSourceType.TraceSourceLtm*/)
                    {
                        this.TransactionCommittedLtm(transactionID.TransactionIdentifier ?? $.$spc.System.String.Empty);
                    }
                    else if (traceSource === 2/*TraceSourceType.TraceSourceOleTx*/)
                    {
                        this.TransactionCommittedOleTx(transactionID.TransactionIdentifier ?? $.$spc.System.String.Empty);
                    }
                }
            }
            /*void */ TransactionCommittedLtm(/*string*/ transactionID)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionID);
                this.WriteEvent$7(20/*TRANSACTION_COMMITTED_LTM_EVENTID*/, transactionID);
            }
            /*void */ TransactionCommittedOleTx(/*string*/ transactionID)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionID);
                this.WriteEvent$7(44/*TRANSACTION_COMMITTED_OLETX_EVENTID*/, transactionID);
            }
            /*void */ TransactionInDoubt(/*TraceSourceType*/ traceSource, /*TransactionTraceIdentifier*/ transactionID)
            {
                if (this.IsEnabled$1(3/*EventLevel.Warning*/, -1n))
                {
                    if (traceSource === 1/*TraceSourceType.TraceSourceLtm*/)
                    {
                        this.TransactionInDoubtLtm(transactionID.TransactionIdentifier ?? $.$spc.System.String.Empty);
                    }
                    else if (traceSource === 2/*TraceSourceType.TraceSourceOleTx*/)
                    {
                        this.TransactionInDoubtOleTx(transactionID.TransactionIdentifier ?? $.$spc.System.String.Empty);
                    }
                }
            }
            /*void */ TransactionInDoubtLtm(/*string*/ transactionID)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionID);
                this.WriteEvent$7(25/*TRANSACTION_INDOUBT_LTM_EVENTID*/, transactionID);
            }
            /*void */ TransactionInDoubtOleTx(/*string*/ transactionID)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionID);
                this.WriteEvent$7(46/*TRANSACTION_INDOUBT_OLETX_EVENTID*/, transactionID);
            }
            /*void */ TransactionPromoted(/*TransactionTraceIdentifier*/ transactionID, /*TransactionTraceIdentifier*/ distributedTxID)
            {
                if (this.IsEnabled$1(4/*EventLevel.Informational*/, -1n))
                {
                    this.TransactionPromoted$1(transactionID.TransactionIdentifier ?? $.$spc.System.String.Empty, distributedTxID.TransactionIdentifier ?? $.$spc.System.String.Empty);
                }
            }
            /*void */ TransactionPromoted$1(/*string*/ transactionID, /*string*/ distributedTxID)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionID);
                this.WriteEvent$8(27/*TRANSACTION_PROMOTED_EVENTID*/, transactionID, distributedTxID);
            }
            /*void */ TransactionAborted(/*TraceSourceType*/ traceSource, /*TransactionTraceIdentifier*/ transactionID)
            {
                if (this.IsEnabled$1(3/*EventLevel.Warning*/, -1n))
                {
                    if (traceSource === 1/*TraceSourceType.TraceSourceLtm*/)
                    {
                        this.TransactionAbortedLtm(transactionID.TransactionIdentifier ?? $.$spc.System.String.Empty);
                    }
                    else if (traceSource === 2/*TraceSourceType.TraceSourceOleTx*/)
                    {
                        this.TransactionAbortedOleTx(transactionID.TransactionIdentifier ?? $.$spc.System.String.Empty);
                    }
                }
            }
            /*void */ TransactionAbortedLtm(/*string*/ transactionID)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionID);
                this.WriteEvent$7(17/*TRANSACTION_ABORTED_LTM_EVENTID*/, transactionID);
            }
            /*void */ TransactionAbortedOleTx(/*string*/ transactionID)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionID);
                this.WriteEvent$7(45/*TRANSACTION_ABORTED_OLETX_EVENTID*/, transactionID);
            }
            /*void */ InternalError(/*string?*/ error)
            {
                if (this.IsEnabled$1(1/*EventLevel.Critical*/, -1n))
                {
                    this.InternalErrorTrace(error);
                }
            }
            /*void */ InternalErrorTrace(/*string?*/ error)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$7(37/*INTERNAL_ERROR_EVENTID*/, error);
            }
            static $_Opcodes;
            static get Opcodes()
            {
                let $cls = $.$stl.System.Transactions.TransactionsEtwProvider;
                return $cls.$_Opcodes ??= $asm.$ncls("$stl.System.Transactions.TransactionsEtwProvider.Opcodes", ($self) => class Opcodes
                {
                    /*EventOpcode*/ static Aborted = 100;
                    /*EventOpcode*/ static Activity = 101;
                    /*EventOpcode*/ static Adjusted = 102;
                    /*EventOpcode*/ static CloneCreate = 103;
                    /*EventOpcode*/ static Commit = 104;
                    /*EventOpcode*/ static Committed = 105;
                    /*EventOpcode*/ static Create = 106;
                    /*EventOpcode*/ static Created = 107;
                    /*EventOpcode*/ static CurrentChanged = 108;
                    /*EventOpcode*/ static DependentCloneComplete = 109;
                    /*EventOpcode*/ static Disposed = 110;
                    /*EventOpcode*/ static Done = 111;
                    /*EventOpcode*/ static Enlist = 112;
                    /*EventOpcode*/ static Enter = 113;
                    /*EventOpcode*/ static ExceptionConsumed = 114;
                    /*EventOpcode*/ static Exit = 115;
                    /*EventOpcode*/ static ForceRollback = 116;
                    /*EventOpcode*/ static Incomplete = 117;
                    /*EventOpcode*/ static InDoubt = 118;
                    /*EventOpcode*/ static InternalError = 119;
                    /*EventOpcode*/ static InvalidOperation = 120;
                    /*EventOpcode*/ static NestedIncorrectly = 121;
                    /*EventOpcode*/ static Prepared = 122;
                    /*EventOpcode*/ static Promoted = 123;
                    /*EventOpcode*/ static RecoveryComplete = 124;
                    /*EventOpcode*/ static Reenlist = 125;
                    /*EventOpcode*/ static Rollback = 126;
                    /*EventOpcode*/ static Serialized = 127;
                    /*EventOpcode*/ static Timeout = 128;
                    /*EventOpcode*/ static CallbackPositive = 129;
                    /*EventOpcode*/ static CallbackNegative = 130;
                    static $h = 5552684;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":41091073,"n":"Aborted","d":5552684,"h":4300519980,"f":33},{"t":41091073,"n":"Activity","d":5552684,"h":8595487276,"f":33},{"t":41091073,"n":"Adjusted","d":5552684,"h":12890454572,"f":33},{"t":41091073,"n":"CloneCreate","d":5552684,"h":17185421868,"f":33},{"t":41091073,"n":"Commit","d":5552684,"h":21480389164,"f":33},{"t":41091073,"n":"Committed","d":5552684,"h":25775356460,"f":33},{"t":41091073,"n":"Create","d":5552684,"h":30070323756,"f":33},{"t":41091073,"n":"Created","d":5552684,"h":34365291052,"f":33},{"t":41091073,"n":"CurrentChanged","d":5552684,"h":38660258348,"f":33},{"t":41091073,"n":"DependentCloneComplete","d":5552684,"h":42955225644,"f":33},{"t":41091073,"n":"Disposed","d":5552684,"h":47250192940,"f":33},{"t":41091073,"n":"Done","d":5552684,"h":51545160236,"f":33},{"t":41091073,"n":"Enlist","d":5552684,"h":55840127532,"f":33},{"t":41091073,"n":"Enter","d":5552684,"h":60135094828,"f":33},{"t":41091073,"n":"ExceptionConsumed","d":5552684,"h":64430062124,"f":33},{"t":41091073,"n":"Exit","d":5552684,"h":68725029420,"f":33},{"t":41091073,"n":"ForceRollback","d":5552684,"h":73019996716,"f":33},{"t":41091073,"n":"Incomplete","d":5552684,"h":77314964012,"f":33},{"t":41091073,"n":"InDoubt","d":5552684,"h":81609931308,"f":33},{"t":41091073,"n":"InternalError","d":5552684,"h":85904898604,"f":33},{"t":41091073,"n":"InvalidOperation","d":5552684,"h":90199865900,"f":33},{"t":41091073,"n":"NestedIncorrectly","d":5552684,"h":94494833196,"f":33},{"t":41091073,"n":"Prepared","d":5552684,"h":98789800492,"f":33},{"t":41091073,"n":"Promoted","d":5552684,"h":103084767788,"f":33},{"t":41091073,"n":"RecoveryComplete","d":5552684,"h":107379735084,"f":33},{"t":41091073,"n":"Reenlist","d":5552684,"h":111674702380,"f":33},{"t":41091073,"n":"Rollback","d":5552684,"h":115969669676,"f":33},{"t":41091073,"n":"Serialized","d":5552684,"h":120264636972,"f":33},{"t":41091073,"n":"Timeout","d":5552684,"h":124559604268,"f":33},{"t":41091073,"n":"CallbackPositive","d":5552684,"h":128854571564,"f":33},{"t":41091073,"n":"CallbackNegative","d":5552684,"h":133149538860,"f":33}],"d":5421612,"h":5552684}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Transactions.TransactionsEtwProvider.Opcodes`; }
                }, $cls, ($v) => $cls.$_Opcodes = $v);
            }
            static $_Tasks;
            static get Tasks()
            {
                let $cls = $.$stl.System.Transactions.TransactionsEtwProvider;
                return $cls.$_Tasks ??= $asm.$ncls("$stl.System.Transactions.TransactionsEtwProvider.Tasks", ($self) => class Tasks
                {
                    /*EventTask*/ static ConfiguredDefaultTimeout = 1;
                    /*EventTask*/ static Enlistment = 2;
                    /*EventTask*/ static ResourceManager = 3;
                    /*EventTask*/ static Method = 4;
                    /*EventTask*/ static Transaction = 5;
                    /*EventTask*/ static TransactionException = 6;
                    /*EventTask*/ static TransactionManager = 7;
                    /*EventTask*/ static TransactionScope = 8;
                    /*EventTask*/ static TransactionState = 9;
                    static $h = 5618220;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":42532865,"n":"ConfiguredDefaultTimeout","d":5618220,"h":4300585516,"f":33},{"t":42532865,"n":"Enlistment","d":5618220,"h":8595552812,"f":33},{"t":42532865,"n":"ResourceManager","d":5618220,"h":12890520108,"f":33},{"t":42532865,"n":"Method","d":5618220,"h":17185487404,"f":33},{"t":42532865,"n":"Transaction","d":5618220,"h":21480454700,"f":33},{"t":42532865,"n":"TransactionManager","d":5618220,"h":30070389292,"f":33},{"t":42532865,"n":"TransactionScope","d":5618220,"h":34365356588,"f":33},{"t":42532865,"n":"TransactionState","d":5618220,"h":38660323884,"f":33}],"d":5421612,"h":5618220}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Transactions.TransactionsEtwProvider.Tasks`; }
                }, $cls, ($v) => $cls.$_Tasks = $v);
            }
            static $_Keywords;
            static get Keywords()
            {
                let $cls = $.$stl.System.Transactions.TransactionsEtwProvider;
                return $cls.$_Keywords ??= $asm.$ncls("$stl.System.Transactions.TransactionsEtwProvider.Keywords", ($self) => class Keywords
                {
                    /*EventKeywords*/ static TraceBase = 1n;
                    /*EventKeywords*/ static TraceLtm = 2n;
                    /*EventKeywords*/ static TraceOleTx = 4n;
                    static $h = 5487148;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":40828929,"n":"TraceBase","d":5487148,"h":4300454444,"f":33},{"t":40828929,"n":"TraceLtm","d":5487148,"h":8595421740,"f":33},{"t":40828929,"n":"TraceOleTx","d":5487148,"h":12890389036,"f":33}],"d":5421612,"h":5487148}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Transactions.TransactionsEtwProvider.Keywords`; }
                }, $cls, ($v) => $cls.$_Keywords = $v);
            }
            static /*void */ SetActivityId(/*string*/ str)
            {
                /*Guid*/ let guid = $.$spc.System.Guid.Empty;
                if ($.$spc.System.String.Contains$2.call(str, /*-*/ 45))
                {
                    if (str.length >= 36)
                    {
                        $.$spc.System.Guid.TryParse$1($.$spc.System.MemoryExtensions.AsSpan$7(str, 0, 36), $.$ref(() => guid, ($v) => guid = $v, $.$spc.System.Guid));
                    }
                }
                else 
                {
                    if (str.length >= 32)
                    {
                        $.$spc.System.Guid.TryParse$1($.$spc.System.MemoryExtensions.AsSpan$7(str, 0, 32), $.$ref(() => guid, ($v) => guid = $v, $.$spc.System.Guid));
                    }
                }
                $.$spc.System.Diagnostics.Tracing.EventSource.SetCurrentThreadActivityId(guid);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Log = new $.$stl.System.Transactions.TransactionsEtwProvider().$ctor$5();
                }
                {
                    this.NullInstance = "(null)";
                }
            }
            static $h = 5421612;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":41680897,"m":[{"r":1310721,"p":[{"n":"value","p":131073}],"n":"IdOf","d":5421612,"h":266293393964,"f":33,"a":[{"t":44236801,"c":4339204097}]},{"r":655361,"p":[{"n":"value","p":131073}],"n":"GetHashCode","o":"@$1","d":5421612,"h":270588361260,"f":33,"a":[{"t":44236801,"c":4339204097}]},{"r":65537,"p":[{"n":"traceSource","p":4241964},{"n":"txTraceId","p":8567340},{"n":"type","p":1310721}],"n":"TransactionCreated","d":5421612,"h":274883328556,"f":8,"a":[{"t":44236801,"c":4339204097}]},{"r":65537,"p":[{"n":"transactionIdentifier","p":1310721},{"n":"type","p":1310721}],"n":"TransactionCreatedLtm","d":5421612,"h":279178295852,"f":2,"a":[{"t":39911425,"c":4334878721,"a":[{"v":21,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40828929},{"n":"Level","v":4,"t":40894465},{"n":"Task","v":5,"t":42532865},{"n":"Opcode","v":106,"t":41091073},{"n":"Message","v":"Transaction Created (LTM). ID is {0}, type is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionIdentifier","p":1310721},{"n":"type","p":1310721}],"n":"TransactionCreatedOleTx","d":5421612,"h":283473263148,"f":2,"a":[{"t":39911425,"c":4334878721,"a":[{"v":51,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40828929},{"n":"Level","v":4,"t":40894465},{"n":"Task","v":5,"t":42532865},{"n":"Opcode","v":106,"t":41091073},{"n":"Message","v":"Transaction Created (OLETX). ID is {0}, type is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"transaction","p":4307500},{"n":"type","p":1310721}],"n":"TransactionCloneCreate","d":5421612,"h":287768230444,"f":8,"a":[{"t":44236801,"c":4339204097}]},{"r":65537,"p":[{"n":"transactionIdentifier","p":1310721},{"n":"type","p":1310721}],"n":"TransactionCloneCreate","o":"@$1","d":5421612,"h":292063197740,"f":2,"a":[{"t":39911425,"c":4334878721,"a":[{"v":18,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40828929},{"n":"Level","v":4,"t":40894465},{"n":"Task","v":5,"t":42532865},{"n":"Opcode","v":103,"t":41091073},{"n":"Message","v":"Transaction Clone Created. ID is {0}, type is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionTraceId","p":8567340}],"n":"TransactionSerialized","d":5421612,"h":296358165036,"f":8,"a":[{"t":44236801,"c":4339204097}]},{"r":65537,"p":[{"n":"transactionIdentifier","p":1310721}],"n":"TransactionSerialized","o":"@$1","d":5421612,"h":300653132332,"f":2,"a":[{"t":39911425,"c":4334878721,"a":[{"v":29,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40828929},{"n":"Level","v":4,"t":40894465},{"n":"Task","v":5,"t":42532865},{"n":"Opcode","v":127,"t":41091073},{"n":"Message","v":"Transaction Serialized. ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionTraceId","p":8567340}],"n":"TransactionDeserialized","d":5421612,"h":304948099628,"f":8,"a":[{"t":44236801,"c":4339204097}]},{"r":65537,"p":[{"n":"transactionIdentifier","p":1310721}],"n":"TransactionDeserialized","o":"@$1","d":5421612,"h":309243066924,"f":2,"a":[{"t":39911425,"c":4334878721,"a":[{"v":50,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40828929},{"n":"Level","v":5,"t":40894465},{"n":"Task","v":5,"t":42532865},{"n":"Opcode","v":127,"t":41091073},{"n":"Message","v":"Transaction Deserialized. ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"traceSource","p":4241964},{"n":"type","p":4635180},{"n":"message","p":1310721},{"n":"innerExceptionStr","p":1310721}],"n":"TransactionExceptionTrace","d":5421612,"h":313538034220,"f":8,"a":[{"t":44236801,"c":4339204097}]},{"r":65537,"p":[{"n":"type","p":4635180},{"n":"message","p":1310721},{"n":"innerExceptionStr","p":1310721}],"n":"TransactionExceptionTrace","o":"@$1","d":5421612,"h":317833001516,"f":8,"a":[{"t":44236801,"c":4339204097}]},{"r":65537,"p":[{"n":"type","p":1310721},{"n":"message","p":1310721},{"n":"innerExceptionStr","p":1310721}],"n":"TransactionExceptionBase","d":5421612,"h":322127968812,"f":2,"a":[{"t":39911425,"c":4334878721,"a":[{"v":24,"t":655361}],"n":[{"n":"Keywords","v":1,"t":40828929},{"n":"Level","v":2,"t":40894465},{"n":"Task","v":6,"t":42532865},{"n":"Message","v":"Transaction Exception. Type is {0}, message is {1}, InnerException is {2}","t":1310721}]}]},{"r":65537,"p":[{"n":"type","p":1310721},{"n":"message","p":1310721},{"n":"innerExceptionStr","p":1310721}],"n":"TransactionExceptionLtm","d":5421612,"h":326422936108,"f":2,"a":[{"t":39911425,"c":4334878721,"a":[{"v":23,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40828929},{"n":"Level","v":2,"t":40894465},{"n":"Task","v":6,"t":42532865},{"n":"Message","v":"Transaction Exception. Type is {0}, message is {1}, InnerException is {2}","t":1310721}]}]},{"r":65537,"p":[{"n":"type","p":1310721},{"n":"operation","p":1310721}],"n":"InvalidOperation","d":5421612,"h":330717903404,"f":8,"a":[{"t":44236801,"c":4339204097}]},{"r":65537,"p":[{"n":"transactionIdentifier","p":1310721},{"n":"type","p":1310721},{"n":"operation","p":1310721}],"n":"TransactionInvalidOperation","d":5421612,"h":335012870700,"f":2,"a":[{"t":39911425,"c":4334878721,"a":[{"v":26,"t":655361}],"n":[{"n":"Keywords","v":1,"t":40828929},{"n":"Level","v":2,"t":40894465},{"n":"Task","v":5,"t":42532865},{"n":"Opcode","v":120,"t":41091073},{"n":"Message","v":"Transaction Invalid Operation. ID is {0}, type is {1} and operation is {2}","t":1310721}]}]},{"r":65537,"p":[{"n":"traceSource","p":4241964},{"n":"txTraceId","p":8567340},{"n":"type","p":1310721}],"n":"TransactionRollback","d":5421612,"h":339307837996,"f":8,"a":[{"t":44236801,"c":4339204097}]},{"r":65537,"p":[{"n":"transactionIdentifier","p":1310721},{"n":"type","p":1310721}],"n":"TransactionRollbackLtm","d":5421612,"h":343602805292,"f":2,"a":[{"t":39911425,"c":4334878721,"a":[{"v":28,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40828929},{"n":"Level","v":3,"t":40894465},{"n":"Task","v":5,"t":42532865},{"n":"Opcode","v":126,"t":41091073},{"n":"Message","v":"Transaction LTM Rollback. ID is {0}, type is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionIdentifier","p":1310721},{"n":"type","p":1310721}],"n":"TransactionRollbackOleTx","d":5421612,"h":347897772588,"f":2,"a":[{"t":39911425,"c":4334878721,"a":[{"v":42,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40828929},{"n":"Level","v":3,"t":40894465},{"n":"Task","v":5,"t":42532865},{"n":"Opcode","v":126,"t":41091073},{"n":"Message","v":"Transaction OleTx Rollback. ID is {0}, type is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"traceSource","p":4241964},{"n":"txTraceId","p":8567340},{"n":"option","p":1096236}],"n":"TransactionDependentCloneCreate","d":5421612,"h":352192739884,"f":8,"a":[{"t":44236801,"c":4339204097}]},{"r":65537,"p":[{"n":"transactionIdentifier","p":1310721},{"n":"option","p":1310721}],"n":"TransactionDependentCloneCreateLtm","d":5421612,"h":356487707180,"f":2,"a":[{"t":39911425,"c":4334878721,"a":[{"v":48,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40828929},{"n":"Level","v":4,"t":40894465},{"n":"Task","v":5,"t":42532865},{"n":"Opcode","v":109,"t":41091073},{"n":"Message","v":"Transaction Dependent Clone Created (LTM). ID is {0}, option is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionIdentifier","p":1310721},{"n":"option","p":1310721}],"n":"TransactionDependentCloneCreateOleTx","d":5421612,"h":360782674476,"f":2,"a":[{"t":39911425,"c":4334878721,"a":[{"v":49,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40828929},{"n":"Level","v":4,"t":40894465},{"n":"Task","v":5,"t":42532865},{"n":"Opcode","v":109,"t":41091073},{"n":"Message","v":"Transaction Dependent Clone Created (OLETX). ID is {0}, option is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"traceSource","p":4241964},{"n":"txTraceId","p":8567340},{"n":"type","p":1310721}],"n":"TransactionDependentCloneComplete","d":5421612,"h":365077641772,"f":8,"a":[{"t":44236801,"c":4339204097}]},{"r":65537,"p":[{"n":"transactionIdentifier","p":1310721},{"n":"type","p":1310721}],"n":"TransactionDependentCloneCompleteLtm","d":5421612,"h":369372609068,"f":2,"a":[{"t":39911425,"c":4334878721,"a":[{"v":22,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40828929},{"n":"Level","v":4,"t":40894465},{"n":"Task","v":5,"t":42532865},{"n":"Opcode","v":109,"t":41091073},{"n":"Message","v":"Transaction Dependent Clone Completed (LTM). ID is {0}, type is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionIdentifier","p":1310721},{"n":"type","p":1310721}],"n":"TransactionDependentCloneCompleteOleTx","d":5421612,"h":373667576364,"f":2,"a":[{"t":39911425,"c":4334878721,"a":[{"v":47,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40828929},{"n":"Level","v":4,"t":40894465},{"n":"Task","v":5,"t":42532865},{"n":"Opcode","v":109,"t":41091073},{"n":"Message","v":"Transaction Dependent Clone Completed (OLETX). ID is {0}, type is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"traceSource","p":4241964},{"n":"txTraceId","p":8567340},{"n":"type","p":1310721}],"n":"TransactionCommit","d":5421612,"h":377962543660,"f":8,"a":[{"t":44236801,"c":4339204097}]},{"r":65537,"p":[{"n":"transactionIdentifier","p":1310721},{"n":"type","p":1310721}],"n":"TransactionCommitLtm","d":5421612,"h":382257510956,"f":2,"a":[{"t":39911425,"c":4334878721,"a":[{"v":19,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40828929},{"n":"Level","v":5,"t":40894465},{"n":"Task","v":5,"t":42532865},{"n":"Opcode","v":104,"t":41091073},{"n":"Message","v":"Transaction LTM Commit: ID is {0}, type is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionIdentifier","p":1310721},{"n":"type","p":1310721}],"n":"TransactionCommitOleTx","d":5421612,"h":386552478252,"f":2,"a":[{"t":39911425,"c":4334878721,"a":[{"v":41,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40828929},{"n":"Level","v":5,"t":40894465},{"n":"Task","v":5,"t":42532865},{"n":"Opcode","v":104,"t":41091073},{"n":"Message","v":"Transaction OleTx Commit: ID is {0}, type is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"traceSource","p":4241964},{"n":"enlistmentTraceId","p":2079276},{"n":"notificationCall","p":3324460}],"n":"EnlistmentStatus","d":5421612,"h":390847445548,"f":8,"a":[{"t":44236801,"c":4339204097}]},{"r":65537,"p":[{"n":"enlistmentIdentifier","p":655361},{"n":"notificationCall","p":1310721}],"n":"EnlistmentStatusLtm","d":5421612,"h":395142412844,"f":2,"a":[{"t":39911425,"c":4334878721,"a":[{"v":5,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40828929},{"n":"Level","v":5,"t":40894465},{"n":"Task","v":2,"t":42532865},{"n":"Message","v":"Enlistment status (LTM): ID is {0}, notificationcall is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"enlistmentIdentifier","p":655361},{"n":"notificationCall","p":1310721}],"n":"EnlistmentStatusOleTx","d":5421612,"h":399437380140,"f":2,"a":[{"t":39911425,"c":4334878721,"a":[{"v":52,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40828929},{"n":"Level","v":5,"t":40894465},{"n":"Task","v":2,"t":42532865},{"n":"Message","v":"Enlistment status (OLETX): ID is {0}, notificationcall is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"traceSource","p":4241964},{"n":"enlistmentTraceId","p":2079276},{"n":"enlistmentType","p":2144812},{"n":"enlistmentOptions","p":1882668}],"n":"EnlistmentCreated","d":5421612,"h":403732347436,"f":8,"a":[{"t":44236801,"c":4339204097}]},{"r":65537,"p":[{"n":"enlistmentIdentifier","p":655361},{"n":"enlistmentType","p":1310721},{"n":"enlistmentOptions","p":1310721}],"n":"EnlistmentCreatedLtm","d":5421612,"h":408027314732,"f":2,"a":[{"t":39911425,"c":4334878721,"a":[{"v":55,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40828929},{"n":"Level","v":4,"t":40894465},{"n":"Task","v":2,"t":42532865},{"n":"Opcode","v":106,"t":41091073},{"n":"Message","v":"Enlistment Created (LTM). ID is {0}, type is {1}, options is {2}","t":1310721}]}]},{"r":65537,"p":[{"n":"enlistmentIdentifier","p":655361},{"n":"enlistmentType","p":1310721},{"n":"enlistmentOptions","p":1310721}],"n":"EnlistmentCreatedOleTx","d":5421612,"h":412322282028,"f":2,"a":[{"t":39911425,"c":4334878721,"a":[{"v":56,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40828929},{"n":"Level","v":4,"t":40894465},{"n":"Task","v":2,"t":42532865},{"n":"Opcode","v":106,"t":41091073},{"n":"Message","v":"Enlistment Created (OLETX). ID is {0}, type is {1}, options is {2}","t":1310721}]}]},{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"EnlistmentDone","d":5421612,"h":416617249324,"f":8,"a":[{"t":44236801,"c":4339204097}]},{"r":65537,"p":[{"n":"enlistmentIdentifier","p":655361}],"n":"EnlistmentDone","o":"@$1","d":5421612,"h":420912216620,"f":2,"a":[{"t":39911425,"c":4334878721,"a":[{"v":4,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40828929},{"n":"Level","v":5,"t":40894465},{"n":"Task","v":2,"t":42532865},{"n":"Opcode","v":111,"t":41091073},{"n":"Message","v":"Enlistment.Done: ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"EnlistmentPrepared","d":5421612,"h":425207183916,"f":8,"a":[{"t":44236801,"c":4339204097}]},{"r":65537,"p":[{"n":"enlistmentIdentifier","p":655361}],"n":"EnlistmentPrepared","o":"@$1","d":5421612,"h":429502151212,"f":2,"a":[{"t":39911425,"c":4334878721,"a":[{"v":8,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40828929},{"n":"Level","v":5,"t":40894465},{"n":"Task","v":2,"t":42532865},{"n":"Opcode","v":122,"t":41091073},{"n":"Message","v":"PreparingEnlistment.Prepared: ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"EnlistmentForceRollback","d":5421612,"h":433797118508,"f":8,"a":[{"t":44236801,"c":4339204097}]},{"r":65537,"p":[{"n":"enlistmentIdentifier","p":655361}],"n":"EnlistmentForceRollback","o":"@$1","d":5421612,"h":438092085804,"f":2,"a":[{"t":39911425,"c":4334878721,"a":[{"v":6,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40828929},{"n":"Level","v":3,"t":40894465},{"n":"Task","v":2,"t":42532865},{"n":"Opcode","v":116,"t":41091073},{"n":"Message","v":"Enlistment forceRollback: ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"EnlistmentAborted","d":5421612,"h":442387053100,"f":8,"a":[{"t":44236801,"c":4339204097}]},{"r":65537,"p":[{"n":"enlistmentIdentifier","p":655361}],"n":"EnlistmentAborted","o":"@$1","d":5421612,"h":446682020396,"f":2,"a":[{"t":39911425,"c":4334878721,"a":[{"v":2,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40828929},{"n":"Level","v":3,"t":40894465},{"n":"Task","v":2,"t":42532865},{"n":"Opcode","v":100,"t":41091073},{"n":"Message","v":"Enlistment SinglePhase Aborted: ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"EnlistmentCommitted","d":5421612,"h":450976987692,"f":8,"a":[{"t":44236801,"c":4339204097}]},{"r":65537,"p":[{"n":"enlistmentIdentifier","p":655361}],"n":"EnlistmentCommitted","o":"@$1","d":5421612,"h":455271954988,"f":2,"a":[{"t":39911425,"c":4334878721,"a":[{"v":3,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40828929},{"n":"Level","v":5,"t":40894465},{"n":"Task","v":2,"t":42532865},{"n":"Opcode","v":105,"t":41091073},{"n":"Message","v":"Enlistment Committed: ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"EnlistmentInDoubt","d":5421612,"h":459566922284,"f":8,"a":[{"t":44236801,"c":4339204097}]},{"r":65537,"p":[{"n":"enlistmentIdentifier","p":655361}],"n":"EnlistmentInDoubt","o":"@$1","d":5421612,"h":463861889580,"f":2,"a":[{"t":39911425,"c":4334878721,"a":[{"v":7,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40828929},{"n":"Level","v":3,"t":40894465},{"n":"Task","v":2,"t":42532865},{"n":"Opcode","v":118,"t":41091073},{"n":"Message","v":"Enlistment SinglePhase InDoubt: ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"enlistmentTraceIdentifier","p":2079276},{"n":"callback","p":1817132}],"n":"EnlistmentCallbackPositive","d":5421612,"h":468156856876,"f":8,"a":[{"t":44236801,"c":4339204097}]},{"r":65537,"p":[{"n":"enlistmentIdentifier","p":655361},{"n":"callback","p":1310721}],"n":"EnlistmentCallbackPositive","o":"@$1","d":5421612,"h":472451824172,"f":2,"a":[{"t":39911425,"c":4334878721,"a":[{"v":53,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40828929},{"n":"Level","v":5,"t":40894465},{"n":"Task","v":2,"t":42532865},{"n":"Opcode","v":129,"t":41091073},{"n":"Message","v":"Enlistment callback positive: ID is {0}, callback is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"enlistmentTraceIdentifier","p":2079276},{"n":"callback","p":1817132}],"n":"EnlistmentCallbackNegative","d":5421612,"h":476746791468,"f":8,"a":[{"t":44236801,"c":4339204097}]},{"r":65537,"p":[{"n":"enlistmentIdentifier","p":655361},{"n":"callback","p":1310721}],"n":"EnlistmentCallbackNegative","o":"@$1","d":5421612,"h":481041758764,"f":2,"a":[{"t":39911425,"c":4334878721,"a":[{"v":54,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40828929},{"n":"Level","v":3,"t":40894465},{"n":"Task","v":2,"t":42532865},{"n":"Opcode","v":130,"t":41091073},{"n":"Message","v":"Enlistment callback negative: ID is {0}, callback is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"traceSource","p":4241964},{"n":"thisOrContextObject","p":131073},{"n":"methodname","p":1310721,"f":65,"a":[{"t":88145921,"c":4383113217}]}],"n":"MethodEnter","d":5421612,"h":485336726060,"f":8,"a":[{"t":44236801,"c":4339204097}]},{"r":65537,"p":[{"n":"traceSource","p":4241964},{"n":"methodname","p":1310721,"f":65,"a":[{"t":88145921,"c":4383113217}]}],"n":"MethodEnter","o":"@$1","d":5421612,"h":489631693356,"f":8,"a":[{"t":44236801,"c":4339204097}]},{"r":65537,"p":[{"n":"thisOrContextObject","p":1310721},{"n":"methodname","p":1310721}],"n":"MethodEnterTraceLtm","d":5421612,"h":493926660652,"f":2,"a":[{"t":39911425,"c":4334878721,"a":[{"v":11,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40828929},{"n":"Level","v":5,"t":40894465},{"n":"Task","v":4,"t":42532865},{"n":"Opcode","v":113,"t":41091073},{"n":"Message","v":"Enter method : {0}.{1}","t":1310721}]}]},{"r":65537,"p":[{"n":"thisOrContextObject","p":1310721},{"n":"methodname","p":1310721}],"n":"MethodEnterTraceBase","d":5421612,"h":498221627948,"f":2,"a":[{"t":39911425,"c":4334878721,"a":[{"v":13,"t":655361}],"n":[{"n":"Keywords","v":1,"t":40828929},{"n":"Level","v":5,"t":40894465},{"n":"Task","v":4,"t":42532865},{"n":"Opcode","v":113,"t":41091073},{"n":"Message","v":"Enter method : {0}.{1}","t":1310721}]}]},{"r":65537,"p":[{"n":"thisOrContextObject","p":1310721},{"n":"methodname","p":1310721}],"n":"MethodEnterTraceDistributed","d":5421612,"h":502516595244,"f":2,"a":[{"t":39911425,"c":4334878721,"a":[{"v":15,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40828929},{"n":"Level","v":5,"t":40894465},{"n":"Task","v":4,"t":42532865},{"n":"Opcode","v":113,"t":41091073},{"n":"Message","v":"Enter method : {0}.{1}","t":1310721}]}]},{"r":65537,"p":[{"n":"traceSource","p":4241964},{"n":"thisOrContextObject","p":131073},{"n":"methodname","p":1310721,"f":65,"a":[{"t":88145921,"c":4383113217}]}],"n":"MethodExit","d":5421612,"h":506811562540,"f":8,"a":[{"t":44236801,"c":4339204097}]},{"r":65537,"p":[{"n":"traceSource","p":4241964},{"n":"methodname","p":1310721,"f":65,"a":[{"t":88145921,"c":4383113217}]}],"n":"MethodExit","o":"@$1","d":5421612,"h":511106529836,"f":8,"a":[{"t":44236801,"c":4339204097}]},{"r":65537,"p":[{"n":"thisOrContextObject","p":1310721},{"n":"methodname","p":1310721}],"n":"MethodExitTraceLtm","d":5421612,"h":515401497132,"f":2,"a":[{"t":39911425,"c":4334878721,"a":[{"v":12,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40828929},{"n":"Level","v":5,"t":40894465},{"n":"Task","v":4,"t":42532865},{"n":"Opcode","v":115,"t":41091073},{"n":"Message","v":"Exit method: {0}.{1}","t":1310721}]}]},{"r":65537,"p":[{"n":"thisOrContextObject","p":1310721},{"n":"methodname","p":1310721}],"n":"MethodExitTraceBase","d":5421612,"h":519696464428,"f":2,"a":[{"t":39911425,"c":4334878721,"a":[{"v":14,"t":655361}],"n":[{"n":"Keywords","v":1,"t":40828929},{"n":"Level","v":5,"t":40894465},{"n":"Task","v":4,"t":42532865},{"n":"Opcode","v":115,"t":41091073},{"n":"Message","v":"Exit method: {0}.{1}","t":1310721}]}]},{"r":65537,"p":[{"n":"thisOrContextObject","p":1310721},{"n":"methodname","p":1310721}],"n":"MethodExitTraceDistributed","d":5421612,"h":523991431724,"f":2,"a":[{"t":39911425,"c":4334878721,"a":[{"v":16,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40828929},{"n":"Level","v":5,"t":40894465},{"n":"Task","v":4,"t":42532865},{"n":"Opcode","v":115,"t":41091073},{"n":"Message","v":"Exit method: {0}.{1}","t":1310721}]}]},{"r":65537,"p":[{"n":"traceSource","p":4241964},{"n":"exception","p":47185921}],"n":"ExceptionConsumed","d":5421612,"h":528286399020,"f":8,"a":[{"t":44236801,"c":4339204097}]},{"r":65537,"p":[{"n":"exception","p":47185921}],"n":"ExceptionConsumed","o":"@$1","d":5421612,"h":532581366316,"f":8,"a":[{"t":44236801,"c":4339204097}]},{"r":65537,"p":[{"n":"exceptionStr","p":1310721}],"n":"ExceptionConsumedBase","d":5421612,"h":536876333612,"f":2,"a":[{"t":39911425,"c":4334878721,"a":[{"v":9,"t":655361}],"n":[{"n":"Keywords","v":1,"t":40828929},{"n":"Level","v":5,"t":40894465},{"n":"Opcode","v":114,"t":41091073},{"n":"Message","v":"Exception consumed: {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"exceptionStr","p":1310721}],"n":"ExceptionConsumedLtm","d":5421612,"h":541171300908,"f":2,"a":[{"t":39911425,"c":4334878721,"a":[{"v":10,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40828929},{"n":"Level","v":5,"t":40894465},{"n":"Opcode","v":114,"t":41091073},{"n":"Message","v":"Exception consumed: {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"exceptionStr","p":1310721}],"n":"ExceptionConsumedOleTx","d":5421612,"h":545466268204,"f":2,"a":[{"t":39911425,"c":4334878721,"a":[{"v":43,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40828929},{"n":"Level","v":5,"t":40894465},{"n":"Opcode","v":114,"t":41091073},{"n":"Message","v":"Exception consumed: {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"tmType","p":142606337},{"n":"nodeName","p":1310721}],"n":"OleTxTransactionManagerCreate","d":5421612,"h":549761235500,"f":8,"a":[{"t":44236801,"c":4339204097}]},{"r":65537,"p":[{"n":"tmType","p":1310721},{"n":"nodeName","p":1310721}],"n":"OleTxTransactionManagerCreate","o":"@$1","d":5421612,"h":554056202796,"f":2,"a":[{"t":39911425,"c":4334878721,"a":[{"v":57,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40828929},{"n":"Level","v":5,"t":40894465},{"n":"Task","v":7,"t":42532865},{"n":"Opcode","v":107,"t":41091073},{"n":"Message","v":"Created OleTx transaction manager, type is {0}, node name is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"resourceManagerID","p":56164353}],"n":"TransactionManagerReenlist","d":5421612,"h":558351170092,"f":8,"a":[{"t":44236801,"c":4339204097}]},{"r":65537,"p":[{"n":"rmID","p":1310721}],"n":"TransactionManagerReenlistTrace","d":5421612,"h":562646137388,"f":2,"a":[{"t":39911425,"c":4334878721,"a":[{"v":32,"t":655361}],"n":[{"n":"Keywords","v":1,"t":40828929},{"n":"Level","v":4,"t":40894465},{"n":"Task","v":7,"t":42532865},{"n":"Opcode","v":125,"t":41091073},{"n":"Message","v":"Reenlist in: {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"resourceManagerID","p":56164353}],"n":"TransactionManagerRecoveryComplete","d":5421612,"h":566941104684,"f":8,"a":[{"t":44236801,"c":4339204097}]},{"r":65537,"p":[{"n":"rmID","p":1310721}],"n":"TransactionManagerRecoveryComplete","o":"@$1","d":5421612,"h":571236071980,"f":2,"a":[{"t":39911425,"c":4334878721,"a":[{"v":31,"t":655361}],"n":[{"n":"Keywords","v":1,"t":40828929},{"n":"Level","v":4,"t":40894465},{"n":"Task","v":7,"t":42532865},{"n":"Opcode","v":124,"t":41091073},{"n":"Message","v":"Recovery complete: {0}","t":1310721}]}]},{"r":65537,"n":"ConfiguredDefaultTimeoutAdjusted","d":5421612,"h":575531039276,"f":8,"a":[{"t":44236801,"c":4339204097}]},{"r":65537,"n":"ConfiguredDefaultTimeoutAdjustedTrace","d":5421612,"h":579826006572,"f":2,"a":[{"t":39911425,"c":4334878721,"a":[{"v":1,"t":655361}],"n":[{"n":"Keywords","v":1,"t":40828929},{"n":"Level","v":3,"t":40894465},{"n":"Task","v":1,"t":42532865},{"n":"Opcode","v":102,"t":41091073},{"n":"Message","v":"Configured Default Timeout Adjusted","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionID","p":8567340},{"n":"transactionScopeResult","p":5356076}],"n":"TransactionScopeCreated","d":5421612,"h":584120973868,"f":8,"a":[{"t":44236801,"c":4339204097}]},{"r":65537,"p":[{"n":"transactionID","p":1310721},{"n":"transactionScopeResult","p":5356076}],"n":"TransactionScopeCreated","o":"@$1","d":5421612,"h":588415941164,"f":2,"a":[{"t":39911425,"c":4334878721,"a":[{"v":33,"t":655361}],"n":[{"n":"Keywords","v":1,"t":40828929},{"n":"Level","v":4,"t":40894465},{"n":"Task","v":8,"t":42532865},{"n":"Opcode","v":107,"t":41091073},{"n":"Message","v":"Transactionscope was created: Transaction ID is {0}, TransactionScope Result is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"currenttransactionID","p":8567340},{"n":"newtransactionID","p":8567340}],"n":"TransactionScopeCurrentChanged","d":5421612,"h":592710908460,"f":8,"a":[{"t":44236801,"c":4339204097}]},{"r":65537,"p":[{"n":"currenttransactionID","p":1310721},{"n":"newtransactionID","p":1310721}],"n":"TransactionScopeCurrentChanged","o":"@$1","d":5421612,"h":597005875756,"f":2,"a":[{"t":39911425,"c":4334878721,"a":[{"v":34,"t":655361}],"n":[{"n":"Keywords","v":1,"t":40828929},{"n":"Level","v":3,"t":40894465},{"n":"Task","v":8,"t":42532865},{"n":"Opcode","v":108,"t":41091073},{"n":"Message","v":"Transactionscope current transaction ID changed from {0} to {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionID","p":8567340}],"n":"TransactionScopeNestedIncorrectly","d":5421612,"h":601300843052,"f":8,"a":[{"t":44236801,"c":4339204097}]},{"r":65537,"p":[{"n":"transactionID","p":1310721}],"n":"TransactionScopeNestedIncorrectly","o":"@$1","d":5421612,"h":605595810348,"f":2,"a":[{"t":39911425,"c":4334878721,"a":[{"v":38,"t":655361}],"n":[{"n":"Keywords","v":1,"t":40828929},{"n":"Level","v":3,"t":40894465},{"n":"Task","v":8,"t":42532865},{"n":"Opcode","v":121,"t":41091073},{"n":"Message","v":"Transactionscope nested incorrectly: transaction ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionID","p":8567340}],"n":"TransactionScopeDisposed","d":5421612,"h":609890777644,"f":8,"a":[{"t":44236801,"c":4339204097}]},{"r":65537,"p":[{"n":"transactionID","p":1310721}],"n":"TransactionScopeDisposed","o":"@$1","d":5421612,"h":614185744940,"f":2,"a":[{"t":39911425,"c":4334878721,"a":[{"v":35,"t":655361}],"n":[{"n":"Keywords","v":1,"t":40828929},{"n":"Level","v":4,"t":40894465},{"n":"Task","v":8,"t":42532865},{"n":"Opcode","v":110,"t":41091073},{"n":"Message","v":"Transactionscope disposed: transaction ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionID","p":8567340}],"n":"TransactionScopeIncomplete","d":5421612,"h":618480712236,"f":8,"a":[{"t":44236801,"c":4339204097}]},{"r":65537,"p":[{"n":"transactionID","p":1310721}],"n":"TransactionScopeIncomplete","o":"@$1","d":5421612,"h":622775679532,"f":2,"a":[{"t":39911425,"c":4334878721,"a":[{"v":36,"t":655361}],"n":[{"n":"Keywords","v":1,"t":40828929},{"n":"Level","v":3,"t":40894465},{"n":"Task","v":8,"t":42532865},{"n":"Opcode","v":117,"t":41091073},{"n":"Message","v":"Transactionscope incomplete: transaction ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionID","p":8567340}],"n":"TransactionScopeTimeout","d":5421612,"h":627070646828,"f":8,"a":[{"t":44236801,"c":4339204097}]},{"r":65537,"p":[{"n":"transactionID","p":1310721}],"n":"TransactionScopeTimeout","o":"@$1","d":5421612,"h":631365614124,"f":2,"a":[{"t":39911425,"c":4334878721,"a":[{"v":39,"t":655361}],"n":[{"n":"Keywords","v":1,"t":40828929},{"n":"Level","v":3,"t":40894465},{"n":"Task","v":8,"t":42532865},{"n":"Opcode","v":128,"t":41091073},{"n":"Message","v":"Transactionscope timeout: transaction ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionID","p":8567340}],"n":"TransactionTimeout","d":5421612,"h":635660581420,"f":8,"a":[{"t":44236801,"c":4339204097}]},{"r":65537,"p":[{"n":"transactionID","p":1310721}],"n":"TransactionTimeout","o":"@$1","d":5421612,"h":639955548716,"f":2,"a":[{"t":39911425,"c":4334878721,"a":[{"v":30,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40828929},{"n":"Level","v":3,"t":40894465},{"n":"Task","v":5,"t":42532865},{"n":"Opcode","v":128,"t":41091073},{"n":"Message","v":"Transaction timeout: transaction ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"enlistmentID","p":2079276},{"n":"enlistmentType","p":2144812},{"n":"enlistmentOption","p":1882668}],"n":"TransactionstateEnlist","d":5421612,"h":644250516012,"f":8,"a":[{"t":44236801,"c":4339204097}]},{"r":65537,"p":[{"n":"enlistmentID","p":1310721},{"n":"type","p":1310721},{"n":"option","p":1310721}],"n":"TransactionstateEnlist","o":"@$1","d":5421612,"h":648545483308,"f":2,"a":[{"t":39911425,"c":4334878721,"a":[{"v":40,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40828929},{"n":"Level","v":4,"t":40894465},{"n":"Task","v":9,"t":42532865},{"n":"Opcode","v":112,"t":41091073},{"n":"Message","v":"Transactionstate enlist: Enlistment ID is {0}, type is {1} and options is {2}","t":1310721}]}]},{"r":65537,"p":[{"n":"traceSource","p":4241964},{"n":"transactionID","p":8567340}],"n":"TransactionCommitted","d":5421612,"h":652840450604,"f":8,"a":[{"t":44236801,"c":4339204097}]},{"r":65537,"p":[{"n":"transactionID","p":1310721}],"n":"TransactionCommittedLtm","d":5421612,"h":657135417900,"f":2,"a":[{"t":39911425,"c":4334878721,"a":[{"v":20,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40828929},{"n":"Level","v":5,"t":40894465},{"n":"Task","v":5,"t":42532865},{"n":"Opcode","v":105,"t":41091073},{"n":"Message","v":"Transaction committed LTM: transaction ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionID","p":1310721}],"n":"TransactionCommittedOleTx","d":5421612,"h":661430385196,"f":2,"a":[{"t":39911425,"c":4334878721,"a":[{"v":44,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40828929},{"n":"Level","v":5,"t":40894465},{"n":"Task","v":5,"t":42532865},{"n":"Opcode","v":105,"t":41091073},{"n":"Message","v":"Transaction committed OleTx: transaction ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"traceSource","p":4241964},{"n":"transactionID","p":8567340}],"n":"TransactionInDoubt","d":5421612,"h":665725352492,"f":8,"a":[{"t":44236801,"c":4339204097}]},{"r":65537,"p":[{"n":"transactionID","p":1310721}],"n":"TransactionInDoubtLtm","d":5421612,"h":670020319788,"f":2,"a":[{"t":39911425,"c":4334878721,"a":[{"v":25,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40828929},{"n":"Level","v":3,"t":40894465},{"n":"Task","v":5,"t":42532865},{"n":"Opcode","v":118,"t":41091073},{"n":"Message","v":"Transaction indoubt LTM: transaction ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionID","p":1310721}],"n":"TransactionInDoubtOleTx","d":5421612,"h":674315287084,"f":2,"a":[{"t":39911425,"c":4334878721,"a":[{"v":46,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40828929},{"n":"Level","v":3,"t":40894465},{"n":"Task","v":5,"t":42532865},{"n":"Opcode","v":118,"t":41091073},{"n":"Message","v":"Transaction indoubt OleTx: transaction ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionID","p":8567340},{"n":"distributedTxID","p":8567340}],"n":"TransactionPromoted","d":5421612,"h":678610254380,"f":8,"a":[{"t":44236801,"c":4339204097}]},{"r":65537,"p":[{"n":"transactionID","p":1310721},{"n":"distributedTxID","p":1310721}],"n":"TransactionPromoted","o":"@$1","d":5421612,"h":682905221676,"f":2,"a":[{"t":39911425,"c":4334878721,"a":[{"v":27,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40828929},{"n":"Level","v":4,"t":40894465},{"n":"Task","v":5,"t":42532865},{"n":"Opcode","v":123,"t":41091073},{"n":"Message","v":"Transaction promoted: transaction ID is {0} and distributed transaction ID is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"traceSource","p":4241964},{"n":"transactionID","p":8567340}],"n":"TransactionAborted","d":5421612,"h":687200188972,"f":8,"a":[{"t":44236801,"c":4339204097}]},{"r":65537,"p":[{"n":"transactionID","p":1310721}],"n":"TransactionAbortedLtm","d":5421612,"h":691495156268,"f":2,"a":[{"t":39911425,"c":4334878721,"a":[{"v":17,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40828929},{"n":"Level","v":3,"t":40894465},{"n":"Task","v":5,"t":42532865},{"n":"Opcode","v":100,"t":41091073},{"n":"Message","v":"Transaction aborted LTM: transaction ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionID","p":1310721}],"n":"TransactionAbortedOleTx","d":5421612,"h":695790123564,"f":2,"a":[{"t":39911425,"c":4334878721,"a":[{"v":45,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40828929},{"n":"Level","v":3,"t":40894465},{"n":"Task","v":5,"t":42532865},{"n":"Opcode","v":100,"t":41091073},{"n":"Message","v":"Transaction aborted OleTx: transaction ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"error","p":1310721,"f":65}],"n":"InternalError","d":5421612,"h":700085090860,"f":8,"a":[{"t":44236801,"c":4339204097}]},{"r":65537,"p":[{"n":"error","p":1310721}],"n":"InternalErrorTrace","d":5421612,"h":704380058156,"f":2,"a":[{"t":39911425,"c":4334878721,"a":[{"v":37,"t":655361}],"n":[{"n":"Keywords","v":1,"t":40828929},{"n":"Level","v":1,"t":40894465},{"n":"Task","v":8,"t":42532865},{"n":"Opcode","v":119,"t":41091073},{"n":"Message","v":"Transactionscope internal error: {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"str","p":1310721}],"n":"SetActivityId","d":5421612,"h":721559927340,"f":34}],"l":[{"t":5421612,"n":"Log","d":5421612,"h":4300388908,"f":40},{"t":40828929,"n":"ALL_KEYWORDS","d":5421612,"h":12890323500,"f":34},{"t":655361,"n":"CONFIGURED_DEFAULT_TIMEOUT_ADJUSTED_EVENTID","d":5421612,"h":17185290796,"f":34},{"t":655361,"n":"ENLISTMENT_ABORTED_EVENTID","d":5421612,"h":21480258092,"f":34},{"t":655361,"n":"ENLISTMENT_COMMITTED_EVENTID","d":5421612,"h":25775225388,"f":34},{"t":655361,"n":"ENLISTMENT_DONE_EVENTID","d":5421612,"h":30070192684,"f":34},{"t":655361,"n":"ENLISTMENT_LTM_EVENTID","d":5421612,"h":34365159980,"f":34},{"t":655361,"n":"ENLISTMENT_FORCEROLLBACK_EVENTID","d":5421612,"h":38660127276,"f":34},{"t":655361,"n":"ENLISTMENT_INDOUBT_EVENTID","d":5421612,"h":42955094572,"f":34},{"t":655361,"n":"ENLISTMENT_PREPARED_EVENTID","d":5421612,"h":47250061868,"f":34},{"t":655361,"n":"EXCEPTION_CONSUMED_BASE_EVENTID","d":5421612,"h":51545029164,"f":34},{"t":655361,"n":"EXCEPTION_CONSUMED_LTM_EVENTID","d":5421612,"h":55839996460,"f":34},{"t":655361,"n":"METHOD_ENTER_LTM_EVENTID","d":5421612,"h":60134963756,"f":34},{"t":655361,"n":"METHOD_EXIT_LTM_EVENTID","d":5421612,"h":64429931052,"f":34},{"t":655361,"n":"METHOD_ENTER_BASE_EVENTID","d":5421612,"h":68724898348,"f":34},{"t":655361,"n":"METHOD_EXIT_BASE_EVENTID","d":5421612,"h":73019865644,"f":34},{"t":655361,"n":"METHOD_ENTER_OLETX_EVENTID","d":5421612,"h":77314832940,"f":34},{"t":655361,"n":"METHOD_EXIT_OLETX_EVENTID","d":5421612,"h":81609800236,"f":34},{"t":655361,"n":"TRANSACTION_ABORTED_LTM_EVENTID","d":5421612,"h":85904767532,"f":34},{"t":655361,"n":"TRANSACTION_CLONECREATE_EVENTID","d":5421612,"h":90199734828,"f":34},{"t":655361,"n":"TRANSACTION_COMMIT_LTM_EVENTID","d":5421612,"h":94494702124,"f":34},{"t":655361,"n":"TRANSACTION_COMMITTED_LTM_EVENTID","d":5421612,"h":98789669420,"f":34},{"t":655361,"n":"TRANSACTION_CREATED_LTM_EVENTID","d":5421612,"h":103084636716,"f":34},{"t":655361,"n":"TRANSACTION_DEPENDENT_CLONE_COMPLETE_LTM_EVENTID","d":5421612,"h":107379604012,"f":34},{"t":655361,"n":"TRANSACTION_EXCEPTION_LTM_EVENTID","d":5421612,"h":111674571308,"f":34},{"t":655361,"n":"TRANSACTION_EXCEPTION_BASE_EVENTID","d":5421612,"h":115969538604,"f":34},{"t":655361,"n":"TRANSACTION_INDOUBT_LTM_EVENTID","d":5421612,"h":120264505900,"f":34},{"t":655361,"n":"TRANSACTION_INVALID_OPERATION_EVENTID","d":5421612,"h":124559473196,"f":34},{"t":655361,"n":"TRANSACTION_PROMOTED_EVENTID","d":5421612,"h":128854440492,"f":34},{"t":655361,"n":"TRANSACTION_ROLLBACK_LTM_EVENTID","d":5421612,"h":133149407788,"f":34},{"t":655361,"n":"TRANSACTION_SERIALIZED_EVENTID","d":5421612,"h":137444375084,"f":34},{"t":655361,"n":"TRANSACTION_TIMEOUT_EVENTID","d":5421612,"h":141739342380,"f":34},{"t":655361,"n":"TRANSACTIONMANAGER_RECOVERY_COMPLETE_EVENTID","d":5421612,"h":146034309676,"f":34},{"t":655361,"n":"TRANSACTIONMANAGER_REENLIST_EVENTID","d":5421612,"h":150329276972,"f":34},{"t":655361,"n":"TRANSACTIONSCOPE_CREATED_EVENTID","d":5421612,"h":154624244268,"f":34},{"t":655361,"n":"TRANSACTIONSCOPE_CURRENT_CHANGED_EVENTID","d":5421612,"h":158919211564,"f":34},{"t":655361,"n":"TRANSACTIONSCOPE_DISPOSED_EVENTID","d":5421612,"h":163214178860,"f":34},{"t":655361,"n":"TRANSACTIONSCOPE_INCOMPLETE_EVENTID","d":5421612,"h":167509146156,"f":34},{"t":655361,"n":"INTERNAL_ERROR_EVENTID","d":5421612,"h":171804113452,"f":34},{"t":655361,"n":"TRANSACTIONSCOPE_NESTED_INCORRECTLY_EVENTID","d":5421612,"h":176099080748,"f":34},{"t":655361,"n":"TRANSACTIONSCOPE_TIMEOUT_EVENTID","d":5421612,"h":180394048044,"f":34},{"t":655361,"n":"TRANSACTIONSTATE_ENLIST_EVENTID","d":5421612,"h":184689015340,"f":34},{"t":655361,"n":"TRANSACTION_COMMIT_OLETX_EVENTID","d":5421612,"h":188983982636,"f":34},{"t":655361,"n":"TRANSACTION_ROLLBACK_OLETX_EVENTID","d":5421612,"h":193278949932,"f":34},{"t":655361,"n":"EXCEPTION_CONSUMED_OLETX_EVENTID","d":5421612,"h":197573917228,"f":34},{"t":655361,"n":"TRANSACTION_COMMITTED_OLETX_EVENTID","d":5421612,"h":201868884524,"f":34},{"t":655361,"n":"TRANSACTION_ABORTED_OLETX_EVENTID","d":5421612,"h":206163851820,"f":34},{"t":655361,"n":"TRANSACTION_INDOUBT_OLETX_EVENTID","d":5421612,"h":210458819116,"f":34},{"t":655361,"n":"TRANSACTION_DEPENDENT_CLONE_COMPLETE_OLETX_EVENTID","d":5421612,"h":214753786412,"f":34},{"t":655361,"n":"TRANSACTION_DEPENDENT_CLONE_CREATE_LTM_EVENTID","d":5421612,"h":219048753708,"f":34},{"t":655361,"n":"TRANSACTION_DEPENDENT_CLONE_CREATE_OLETX_EVENTID","d":5421612,"h":223343721004,"f":34},{"t":655361,"n":"TRANSACTION_DESERIALIZED_EVENTID","d":5421612,"h":227638688300,"f":34},{"t":655361,"n":"TRANSACTION_CREATED_OLETX_EVENTID","d":5421612,"h":231933655596,"f":34},{"t":655361,"n":"ENLISTMENT_OLETX_EVENTID","d":5421612,"h":236228622892,"f":34},{"t":655361,"n":"ENLISTMENT_CALLBACK_POSITIVE_EVENTID","d":5421612,"h":240523590188,"f":34},{"t":655361,"n":"ENLISTMENT_CALLBACK_NEGATIVE_EVENTID","d":5421612,"h":244818557484,"f":34},{"t":655361,"n":"ENLISTMENT_CREATED_LTM_EVENTID","d":5421612,"h":249113524780,"f":34},{"t":655361,"n":"ENLISTMENT_CREATED_OLETX_EVENTID","d":5421612,"h":253408492076,"f":34},{"t":655361,"n":"TRANSACTIONMANAGER_CREATE_OLETX_EVENTID","d":5421612,"h":257703459372,"f":34},{"t":1310721,"n":"NullInstance","d":5421612,"h":261998426668,"f":34}],"c":[{"n":".ctor","o":"$ctor$5","d":5421612,"h":8595356204,"f":2}],"i":[57475073],"j":[5552684,5618220,5487148],"h":5421612,"a":[{"t":42008577,"c":55876583425,"n":[{"n":"Name","v":"System.Transactions.TransactionsEventSource","t":1310721},{"n":"Guid","v":"8ac2d80a-1f1a-431b-ace4-bff8824aef0b","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Diagnostics.Tracing.EventSource; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Transactions.TransactionsEtwProvider`; }
        });
        
        $asm.$cls("$stl.System.Transactions.Oletx.OletxDependentTransaction", ($self) => class OletxDependentTransaction extends $.$stl.System.Transactions.Oletx.OletxTransaction
        {
            /*void */ Complete()
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransaction.NotSupported();
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 3455532;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":3521068,"m":[{"r":65537,"n":"Complete","d":3455532,"h":4298422828,"f":8}],"c":[{"n":".ctor","o":"$ctor$3","d":3455532,"h":8593390124,"f":1}],"i":[113377281],"h":3455532}; }
            static get $b() { return $.$stl.System.Transactions.Oletx.OletxTransaction; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Transactions.Oletx.OletxDependentTransaction`; }
        });
        
        $asm.$cls("$stl.System.Transactions.Oletx.OletxCommittableTransaction", ($self) => class OletxCommittableTransaction extends $.$stl.System.Transactions.Oletx.OletxTransaction
        {
            /*void */ BeginCommit(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransaction.NotSupported();
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 3389996;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":3521068,"m":[{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"BeginCommit","d":3389996,"h":4298357292,"f":8}],"c":[{"n":".ctor","o":"$ctor$3","d":3389996,"h":8593324588,"f":1}],"i":[113377281],"h":3389996}; }
            static get $b() { return $.$stl.System.Transactions.Oletx.OletxTransaction; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Transactions.Oletx.OletxCommittableTransaction`; }
        });
        
        $asm.$cls("$stl.System.Transactions.DependentTransaction", ($self) => class DependentTransaction extends $.$stl.System.Transactions.Transaction
        {
            /*bool*/ _blocking = false;
            $ctor$5(/*IsolationLevel*/ isoLevel, /*InternalTransaction*/ internalTransaction, /*bool*/ blocking)
            {
                super.$ctor$2(isoLevel, internalTransaction);
                {
                    this._blocking = blocking;
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                            if (blocking)
                            {
                                this._internalTransaction.State.CreateBlockingClone(this._internalTransaction);
                            }
                            else 
                            {
                                this._internalTransaction.State.CreateAbortingClone(this._internalTransaction);
                            }
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                    }
                }
                return this;
            }
            /*void */ Complete()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "Complete");
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                    {
                        $.$spc.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                        if (this._complete)
                        {
                            throw $.$stl.System.Transactions.TransactionException.CreateTransactionCompletedException(this.DistributedTxId);
                        }
                        this._complete = true;
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        if (this._blocking)
                        {
                            this._internalTransaction.State.CompleteBlockingClone(this._internalTransaction);
                        }
                        else 
                        {
                            this._internalTransaction.State.CompleteAbortingClone(this._internalTransaction);
                        }
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionDependentCloneComplete(1/*TraceSourceType.TraceSourceLtm*/, this.TransactionTraceId, "DependentTransaction");
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "Complete");
                }
            }
            static $h = 1161772;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":4307500,"m":[{"r":65537,"n":"Complete","d":1161772,"h":12886063660,"f":1}],"l":[{"t":262145,"n":"_blocking","d":1161772,"h":4296129068,"f":2}],"c":[{"p":[{"n":"isoLevel","p":3193388},{"n":"internalTransaction","p":2800172},{"n":"blocking","p":262145}],"n":".ctor","o":"$ctor$5","d":1161772,"h":8591096364,"f":8}],"i":[57475073,113377281],"h":1161772}; }
            static get $b() { return $.$stl.System.Transactions.Transaction; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Transactions.DependentTransaction`; }
        });
        
        $asm.$cls("$stl.System.Transactions.SubordinateTransaction", ($self) => class SubordinateTransaction extends $.$stl.System.Transactions.Transaction
        {
            $ctor$5(/*IsolationLevel*/ isoLevel, /*ISimpleTransactionSuperior*/ superior)
            {
                super.$ctor$4(isoLevel, superior);
                {
                }
                return this;
            }
            static $h = 4176428;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":4307500,"c":[{"p":[{"n":"isoLevel","p":3193388},{"n":"superior","p":2996780}],"n":".ctor","o":"$ctor$5","d":4176428,"h":4299143724,"f":1}],"i":[57475073,113377281],"h":4176428}; }
            static get $b() { return $.$stl.System.Transactions.Transaction; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Transactions.SubordinateTransaction`; }
        });
        
        $asm.$cls("$stl.System.Transactions.DurableInternalEnlistment", ($self) => class DurableInternalEnlistment extends $.$stl.System.Transactions.InternalEnlistment
        {
            /*Guid*/ _resourceManagerIdentifier;
            $ctor$5(/*Enlistment*/ enlistment, /*Guid*/ resourceManagerIdentifier, /*InternalTransaction*/ transaction, /*IEnlistmentNotification*/ twoPhaseNotifications, /*ISinglePhaseNotification?*/ singlePhaseNotifications, /*Transaction*/ atomicTransaction)
            {
                super.$ctor$3(enlistment, transaction, twoPhaseNotifications, singlePhaseNotifications, atomicTransaction);
                {
                    this._resourceManagerIdentifier = resourceManagerIdentifier;
                }
                return this;
            }
            $ctor$6(/*Enlistment*/ enlistment, /*IEnlistmentNotification*/ twoPhaseNotifications)
            {
                super.$ctor$1(enlistment, twoPhaseNotifications);
                {
                }
                return this;
            }
            /*Guid */ get ResourceManagerIdentifier()
            {
                return this._resourceManagerIdentifier;
            }
            //default member initializer
            constructor()
            {
                super();
                this._resourceManagerIdentifier = $.$default($.$spc.System.Guid);
            }
            static $h = 1620524;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2734636,"p":[{"p":56164353,"g":{"r":0,"d":0,"h":21476457004,"f":32776},"n":"ResourceManagerIdentifier","d":1620524,"h":17181489708,"f":32776}],"l":[{"t":56164353,"n":"_resourceManagerIdentifier","d":1620524,"h":4296587820,"f":8}],"c":[{"p":[{"n":"enlistment","p":1751596},{"n":"resourceManagerIdentifier","p":56164353},{"n":"transaction","p":2800172},{"n":"twoPhaseNotifications","p":2603564},{"n":"singlePhaseNotifications","p":3062316},{"n":"atomicTransaction","p":4307500}],"n":".ctor","o":"$ctor$5","d":1620524,"h":8591555116,"f":8},{"p":[{"n":"enlistment","p":1751596},{"n":"twoPhaseNotifications","p":2603564}],"n":".ctor","o":"$ctor$6","d":1620524,"h":12886522412,"f":4}],"i":[3127852,2669100],"h":1620524}; }
            static get $b() { return $.$stl.System.Transactions.InternalEnlistment; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stl.System.Transactions.ISinglePhaseNotificationInternal, $.$stl.System.Transactions.IEnlistmentNotificationInternal ]; }
            static get $fullName() { return `System.Transactions.DurableInternalEnlistment`; }
        });
        
        $asm.$cls("$stl.System.Transactions.PromotableInternalEnlistment", ($self) => class PromotableInternalEnlistment extends $.$stl.System.Transactions.InternalEnlistment
        {
            /*IPromotableSinglePhaseNotification*/ _promotableNotificationInterface = null;
            $ctor$5(/*Enlistment*/ enlistment, /*InternalTransaction*/ transaction, /*IPromotableSinglePhaseNotification*/ promotableSinglePhaseNotification, /*Transaction*/ atomicTransaction)
            {
                super.$ctor$2(enlistment, transaction, atomicTransaction);
                {
                    this._promotableNotificationInterface = promotableSinglePhaseNotification;
                }
                return this;
            }
            /*IPromotableSinglePhaseNotification */ get PromotableSinglePhaseNotification()
            {
                return this._promotableNotificationInterface;
            }
            static $h = 3979820;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2734636,"p":[{"p":2865708,"g":{"r":0,"d":0,"h":17183849004,"f":32776},"n":"PromotableSinglePhaseNotification","d":3979820,"h":12888881708,"f":32776}],"l":[{"t":2865708,"n":"_promotableNotificationInterface","d":3979820,"h":4298947116,"f":2}],"c":[{"p":[{"n":"enlistment","p":1751596},{"n":"transaction","p":2800172},{"n":"promotableSinglePhaseNotification","p":2865708},{"n":"atomicTransaction","p":4307500}],"n":".ctor","o":"$ctor$5","d":3979820,"h":8593914412,"f":8}],"i":[3127852,2669100],"h":3979820}; }
            static get $b() { return $.$stl.System.Transactions.InternalEnlistment; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stl.System.Transactions.ISinglePhaseNotificationInternal, $.$stl.System.Transactions.IEnlistmentNotificationInternal ]; }
            static get $fullName() { return `System.Transactions.PromotableInternalEnlistment`; }
        });
        
        $asm.$cls("$stl.System.Transactions.Phase1VolatileEnlistment", ($self) => class Phase1VolatileEnlistment extends $.$stl.System.Transactions.InternalEnlistment
        {
            $ctor$5(/*Enlistment*/ enlistment, /*InternalTransaction*/ transaction, /*IEnlistmentNotification*/ twoPhaseNotifications, /*ISinglePhaseNotification?*/ singlePhaseNotifications, /*Transaction*/ atomicTransaction)
            {
                super.$ctor$3(enlistment, transaction, twoPhaseNotifications, singlePhaseNotifications, atomicTransaction);
                {
                }
                return this;
            }
            /*void */ FinishEnlistment()
            {
                this._transaction._phase1Volatiles._preparedVolatileEnlistments++;
                this.CheckComplete();
            }
            /*void */ CheckComplete()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._transaction._phase1Volatiles._preparedVolatileEnlistments <= ((this._transaction._phase1Volatiles._volatileEnlistmentCount + this._transaction._phase1Volatiles._dependentClones) | 0), "_transaction._phase1Volatiles._preparedVolatileEnlistments <=\r\n                _transaction._phase1Volatiles._volatileEnlistmentCount +\r\n                _transaction._phase1Volatiles._dependentClones");
                if (this._transaction._phase1Volatiles._preparedVolatileEnlistments === ((this._transaction._phase1Volatiles._volatileEnlistmentCount + this._transaction._phase1Volatiles._dependentClones) | 0))
                {
                    this._transaction.State.Phase1VolatilePrepareDone(this._transaction);
                }
            }
            static $h = 3848748;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2734636,"m":[{"r":65537,"n":"FinishEnlistment","d":3848748,"h":8593783340,"f":32776},{"r":65537,"n":"CheckComplete","d":3848748,"h":12888750636,"f":32776}],"c":[{"p":[{"n":"enlistment","p":1751596},{"n":"transaction","p":2800172},{"n":"twoPhaseNotifications","p":2603564},{"n":"singlePhaseNotifications","p":3062316},{"n":"atomicTransaction","p":4307500}],"n":".ctor","o":"$ctor$5","d":3848748,"h":4298816044,"f":1}],"i":[3127852,2669100],"h":3848748}; }
            static get $b() { return $.$stl.System.Transactions.InternalEnlistment; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stl.System.Transactions.ISinglePhaseNotificationInternal, $.$stl.System.Transactions.IEnlistmentNotificationInternal ]; }
            static get $fullName() { return `System.Transactions.Phase1VolatileEnlistment`; }
        });
        
        $asm.$cls("$stl.System.Transactions.CommittableTransaction", ($self) => class CommittableTransaction extends $.$stl.System.Transactions.Transaction
        {
            $ctor$5()
            {
                this.$ctor$8($.$stl.System.Transactions.TransactionManager.DefaultIsolationLevel, $.$stl.System.Transactions.TransactionManager.DefaultTimeout);
                {
                }
                return this;
            }
            $ctor$6(/*TimeSpan*/ timeout)
            {
                this.$ctor$8($.$stl.System.Transactions.TransactionManager.DefaultIsolationLevel, timeout);
                {
                }
                return this;
            }
            $ctor$7(/*TransactionOptions*/ options)
            {
                this.$ctor$8(options.IsolationLevel, options.Timeout);
                {
                }
                return this;
            }
            $ctor$8(/*IsolationLevel*/ isoLevel, /*TimeSpan*/ timeout)
            {
                super.$ctor$2(isoLevel, null);
                {
                    this._internalTransaction = new $.$stl.System.Transactions.InternalTransaction().$ctor$1(timeout, this);
                    this._internalTransaction._cloneCount = 1;
                    this._cloneId = 1;
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.TransactionCreated(1/*TraceSourceType.TraceSourceLtm*/, this.TransactionTraceId, "CommittableTransaction");
                    }
                }
                return this;
            }
            /*IAsyncResult */ BeginCommit(/*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "BeginCommit");
                    etwLog.TransactionCommit(1/*TraceSourceType.TraceSourceLtm*/, this.TransactionTraceId, "CommittableTransaction");
                }
                $.$spc.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                    {
                        if (this._complete)
                        {
                            throw $.$stl.System.Transactions.TransactionException.CreateTransactionCompletedException(this.DistributedTxId);
                        }
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        this._internalTransaction.State.BeginCommit(this._internalTransaction, true, asyncCallback, asyncState);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "BeginCommit");
                }
                return this;
            }
            /*void */ Commit()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "Commit");
                    etwLog.TransactionCommit(1/*TraceSourceType.TraceSourceLtm*/, this.TransactionTraceId, "CommittableTransaction");
                }
                $.$spc.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                    {
                        if (this._complete)
                        {
                            throw $.$stl.System.Transactions.TransactionException.CreateTransactionCompletedException(this.DistributedTxId);
                        }
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        this._internalTransaction.State.BeginCommit(this._internalTransaction, false, null, null);
                        do
                        {
                            if (this._internalTransaction.State.IsCompleted(this._internalTransaction))
                            {
                                break;
                            }
                        }
                        while($.$spc.System.Threading.Monitor.Wait$2(this._internalTransaction));
                        this._internalTransaction.State.EndCommit(this._internalTransaction);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "Commit");
                }
            }
            /*void */ InternalDispose()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "InternalDispose");
                }
                if ($.$spc.System.Threading.Interlocked.Exchange($.$ref(() => this._disposed, ($v) => this._disposed = $v, $.$spc.System.Int32), 1/*Transaction._disposedTrueValue*/) === 1/*Transaction._disposedTrueValue*/)
                {
                    return;
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                if (this._internalTransaction.State.get_Status(this._internalTransaction) === 0/*TransactionStatus.Active*/)
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                        {
                            this._internalTransaction.State.DisposeRoot(this._internalTransaction);
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                    }
                }
                /*long*/ let remainingITx = BigInt($.$spc.System.Threading.Interlocked.Decrement($.$ref(() => this._internalTransaction._cloneCount, ($v) => this._internalTransaction._cloneCount = $v, $.$spc.System.Int32)));
                if (remainingITx === 0n)
                {
                    this._internalTransaction.Dispose();
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "InternalDispose");
                }
            }
            /*void */ EndCommit(/*IAsyncResult*/ asyncResult)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "EndCommit");
                }
                if (asyncResult !== ($.$cast(this, $.$spc.System.Object)))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$stl.System.SR.BadAsyncResult, "asyncResult");
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                    {
                        do
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                            if (this._internalTransaction.State.IsCompleted(this._internalTransaction))
                            {
                                break;
                            }
                        }
                        while($.$spc.System.Threading.Monitor.Wait$2(this._internalTransaction));
                        this._internalTransaction.State.EndCommit(this._internalTransaction);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "EndCommit");
                }
            }
            /*object? */ get System$IAsyncResult$AsyncState()
            {
                return this._internalTransaction._asyncState;
            }
            /*bool */ get System$IAsyncResult$CompletedSynchronously()
            {
                return false;
            }
            /*WaitHandle */ get System$IAsyncResult$AsyncWaitHandle()
            {
                if (this._internalTransaction._asyncResultEvent === null)
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                        {
                            if (this._internalTransaction._asyncResultEvent === null)
                            {
                                $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                                /*ManualResetEvent*/ let temp = new $.$spc.System.Threading.ManualResetEvent().$ctor$8(this._internalTransaction.State.get_Status(this._internalTransaction) !== 0/*TransactionStatus.Active*/);
                                this._internalTransaction._asyncResultEvent = temp;
                            }
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                    }
                }
                return this._internalTransaction._asyncResultEvent;
            }
            /*bool */ get System$IAsyncResult$IsCompleted()
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        return this._internalTransaction.State.get_Status(this._internalTransaction) !== 0/*TransactionStatus.Active*/;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                }
            }
            static $h = 571948;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":4307500,"p":[{"p":131073,"g":{"r":0,"d":0,"h":42950244908,"f":2},"n":"{56950785}.AsyncState","o":"System$IAsyncResult$AsyncState","d":571948,"h":38655277612,"f":2},{"p":262145,"g":{"r":0,"d":0,"h":51540179500,"f":2},"n":"{56950785}.CompletedSynchronously","o":"System$IAsyncResult$CompletedSynchronously","d":571948,"h":47245212204,"f":2},{"p":139132929,"g":{"r":0,"d":0,"h":60130114092,"f":2},"n":"{56950785}.AsyncWaitHandle","o":"System$IAsyncResult$AsyncWaitHandle","d":571948,"h":55835146796,"f":2},{"p":262145,"g":{"r":0,"d":0,"h":68720048684,"f":2},"n":"{56950785}.IsCompleted","o":"System$IAsyncResult$IsCompleted","d":571948,"h":64425081388,"f":2}],"m":[{"r":56950785,"p":[{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":571948,"h":21475408428,"f":1},{"r":65537,"n":"Commit","d":571948,"h":25770375724,"f":1},{"r":65537,"n":"InternalDispose","d":571948,"h":30065343020,"f":32776},{"r":65537,"p":[{"n":"asyncResult","p":56950785}],"n":"EndCommit","d":571948,"h":34360310316,"f":1}],"c":[{"n":".ctor","o":"$ctor$5","d":571948,"h":4295539244,"f":1},{"p":[{"n":"timeout","p":140705793}],"n":".ctor","o":"$ctor$6","d":571948,"h":8590506540,"f":1},{"p":[{"n":"options","p":5028396}],"n":".ctor","o":"$ctor$7","d":571948,"h":12885473836,"f":1},{"p":[{"n":"isoLevel","p":3193388},{"n":"timeout","p":140705793}],"n":".ctor","o":"$ctor$8","d":571948,"h":17180441132,"f":8}],"i":[57475073,113377281,56950785],"h":571948,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]}]}; }
            static get $b() { return $.$stl.System.Transactions.Transaction; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.Runtime.Serialization.ISerializable, $.$spc.System.IAsyncResult ]; }
            static get $fullName() { return `System.Transactions.CommittableTransaction`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionCompletedEventHandler", ($self) => class TransactionCompletedEventHandler extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn)
            {
                this._target = target;
                this.$nativeFunction = fn;
                return this;
            }
            /*void*/ Invoke(/*$.$spc.System.Nullable$$*/ $sender, /**/ $e)
            {
                return this.$nativeFunction.apply(this._target, arguments);
            }
            static $h = 4438572;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":4504108}],"n":"Invoke","d":4438572,"h":8594373164,"f":129},{"r":56950785,"p":[{"n":"sender","p":131073},{"n":"e","p":4504108},{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":4438572,"h":12889340460,"f":129},{"r":65537,"p":[{"n":"result","p":56950785}],"n":"EndInvoke","d":4438572,"h":17184307756,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":4438572,"h":4299405868,"f":1}],"i":[57147393,113377281],"h":4438572}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Transactions.TransactionCompletedEventHandler`; }
        });
        
        $asm.$cls("$stl.System.Transactions.HostCurrentTransactionCallback", ($self) => class HostCurrentTransactionCallback extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn)
            {
                this._target = target;
                this.$nativeFunction = fn;
                return this;
            }
            /*Transaction?*/ Invoke()
            {
                return this.$nativeFunction.apply(this._target, arguments);
            }
            static $h = 2472492;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":4307500,"n":"Invoke","d":2472492,"h":8592407084,"f":129},{"r":56950785,"p":[{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":2472492,"h":12887374380,"f":129},{"r":4307500,"p":[{"n":"result","p":56950785}],"n":"EndInvoke","d":2472492,"h":17182341676,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":2472492,"h":4297439788,"f":1}],"i":[57147393,113377281],"h":2472492}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Transactions.HostCurrentTransactionCallback`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStartedEventHandler", ($self) => class TransactionStartedEventHandler extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn)
            {
                this._target = target;
                this.$nativeFunction = fn;
                return this;
            }
            /*void*/ Invoke(/*$.$spc.System.Nullable$$*/ $sender, /**/ $e)
            {
                return this.$nativeFunction.apply(this._target, arguments);
            }
            static $h = 5683756;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":4504108}],"n":"Invoke","d":5683756,"h":8595618348,"f":129},{"r":56950785,"p":[{"n":"sender","p":131073},{"n":"e","p":4504108},{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":5683756,"h":12890585644,"f":129},{"r":65537,"p":[{"n":"result","p":56950785}],"n":"EndInvoke","d":5683756,"h":17185552940,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":5683756,"h":4300651052,"f":1}],"i":[57147393,113377281],"h":5683756}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Transactions.TransactionStartedEventHandler`; }
        });
        
        $asm.$cls("$stl.System.Transactions.FinishVolatileDelegate", ($self) => class FinishVolatileDelegate extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn)
            {
                this._target = target;
                this.$nativeFunction = fn;
                return this;
            }
            /*void*/ Invoke(/**/ $enlistment)
            {
                return this.$nativeFunction.apply(this._target, arguments);
            }
            static $h = 2406956;
            static $f = 0b10000000;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"Invoke","d":2406956,"h":8592341548,"f":129},{"r":56950785,"p":[{"n":"enlistment","p":2734636},{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":2406956,"h":12887308844,"f":129},{"r":65537,"p":[{"n":"result","p":56950785}],"n":"EndInvoke","d":2406956,"h":17182276140,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":2406956,"h":4297374252,"f":1}],"i":[57147393,113377281],"h":2406956}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Transactions.FinishVolatileDelegate`; }
        });
        
        $asm.$cls("$stl.System.Transactions.VolatileEnlistmentDone", ($self) => class VolatileEnlistmentDone extends $.$stl.System.Transactions.VolatileEnlistmentEnded
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                enlistment.State = this;
            }
            /*void */ ChangeStatePreparing(/*InternalEnlistment*/ enlistment)
            {
                enlistment.CheckComplete();
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 8960556;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":9026092,"m":[{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"EnterState","d":8960556,"h":4303927852,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2734636}],"n":"ChangeStatePreparing","d":8960556,"h":8598895148,"f":32776}],"c":[{"n":".ctor","o":"$ctor$4","d":8960556,"h":12893862444,"f":1}],"h":8960556}; }
            static get $b() { return $.$stl.System.Transactions.VolatileEnlistmentEnded; }
            static get $fullName() { return `System.Transactions.VolatileEnlistmentDone`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedPhase0", ($self) => class TransactionStatePromotedPhase0 extends $.$stl.System.Transactions.TransactionStatePromotedCommitting
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                /*int*/ let volatileCount = tx._phase0Volatiles._volatileEnlistmentCount;
                /*int*/ let dependentCount = tx._phase0Volatiles._dependentClones;
                tx._phase0VolatileWaveCount = volatileCount;
                if (tx._phase0Volatiles._preparedVolatileEnlistments < ((volatileCount + dependentCount) | 0))
                {
                    for(/*int*/ let i = 0; i < volatileCount; i++)
                    {
                        $.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i)._twoPhaseState.ChangeStatePreparing($.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i));
                        if (!tx.State.ContinuePhase0Prepares())
                        {
                            break;
                        }
                    }
                }
                else 
                {
                    this.Phase0VolatilePrepareDone(tx);
                }
            }
            /*void */ Phase0VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(tx._phase0Volatiles.VolatileDemux !== null, "Volatile Demux must exist for VolatilePrepareDone when promoted.");
                $.$spc.System.Threading.Monitor.Exit(tx);
                try
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(tx._phase0Volatiles.VolatileDemux._promotedEnlistment !== null, "tx._phase0Volatiles.VolatileDemux._promotedEnlistment != null");
                    tx._phase0Volatiles.VolatileDemux._promotedEnlistment.System$Transactions$IPromotedEnlistment$Prepared();
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(tx);
                    }
                }
            }
            /*bool */ ContinuePhase0Prepares()
            {
                return true;
            }
            /*void */ ChangeStateTransactionAborted(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                tx._innerException ??= e;
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedP0Aborting.EnterState(tx);
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 7977516;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7060012,"m":[{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"EnterState","d":7977516,"h":4302944812,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"Phase0VolatilePrepareDone","d":7977516,"h":8597912108,"f":32776},{"r":262145,"n":"ContinuePhase0Prepares","d":7977516,"h":12892879404,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"e","p":47185921}],"n":"ChangeStateTransactionAborted","d":7977516,"h":17187846700,"f":32776}],"c":[{"n":".ctor","o":"$ctor$4","d":7977516,"h":21482813996,"f":1}],"h":7977516}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedCommitting; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedPhase0`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedPhase1", ($self) => class TransactionStatePromotedPhase1 extends $.$stl.System.Transactions.TransactionStatePromotedCommitting
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                if (tx._committableTransaction !== null)
                {
                    tx._committableTransaction._complete = true;
                }
                if (tx._phase1Volatiles._dependentClones !== 0)
                {
                    tx.State.ChangeStateTransactionAborted(tx, null);
                    return;
                }
                /*int*/ let volatileCount = tx._phase1Volatiles._volatileEnlistmentCount;
                if (tx._phase1Volatiles._preparedVolatileEnlistments < volatileCount)
                {
                    for(/*int*/ let i = 0; i < volatileCount; i++)
                    {
                        $.$spc.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i)._twoPhaseState.ChangeStatePreparing($.$spc.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i));
                        if (!tx.State.ContinuePhase1Prepares())
                        {
                            break;
                        }
                    }
                }
                else 
                {
                    this.Phase1VolatilePrepareDone(tx);
                }
            }
            /*void */ CreateBlockingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ CreateAbortingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ ChangeStateTransactionAborted(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                tx._innerException ??= e;
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedP1Aborting.EnterState(tx);
            }
            /*void */ Phase1VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(tx._phase1Volatiles.VolatileDemux !== null, "Volatile Demux must exist for VolatilePrepareDone when promoted.");
                $.$spc.System.Threading.Monitor.Exit(tx);
                try
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(tx._phase1Volatiles.VolatileDemux._promotedEnlistment !== null, "tx._phase1Volatiles.VolatileDemux._promotedEnlistment != null");
                    tx._phase1Volatiles.VolatileDemux._promotedEnlistment.System$Transactions$IPromotedEnlistment$Prepared();
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(tx);
                    }
                }
            }
            /*bool */ ContinuePhase1Prepares()
            {
                return true;
            }
            /*Enlistment */ EnlistVolatile(/*InternalTransaction*/ tx, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                throw $.$stl.System.Transactions.TransactionException.Create$1($.$stl.System.SR.TooLate, tx === null ? $.$spc.System.Guid.Empty : tx.DistributedTxId);
            }
            /*Enlistment */ EnlistVolatile$1(/*InternalTransaction*/ tx, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                throw $.$stl.System.Transactions.TransactionException.Create$1($.$stl.System.SR.TooLate, tx === null ? $.$spc.System.Guid.Empty : tx.DistributedTxId);
            }
            /*Enlistment */ EnlistDurable(/*InternalTransaction*/ tx, /*Guid*/ resourceManagerIdentifier, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                throw $.$stl.System.Transactions.TransactionException.Create$1($.$stl.System.SR.TooLate, tx === null ? $.$spc.System.Guid.Empty : tx.DistributedTxId);
            }
            /*Enlistment */ EnlistDurable$1(/*InternalTransaction*/ tx, /*Guid*/ resourceManagerIdentifier, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                throw $.$stl.System.Transactions.TransactionException.Create$1($.$stl.System.SR.TooLate, tx === null ? $.$spc.System.Guid.Empty : tx.DistributedTxId);
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 8043052;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7060012,"m":[{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"EnterState","d":8043052,"h":4303010348,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"CreateBlockingClone","d":8043052,"h":8597977644,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"CreateAbortingClone","d":8043052,"h":12892944940,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"e","p":47185921}],"n":"ChangeStateTransactionAborted","d":8043052,"h":17187912236,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"Phase1VolatilePrepareDone","d":8043052,"h":21482879532,"f":32776},{"r":262145,"n":"ContinuePhase1Prepares","d":8043052,"h":25777846828,"f":32776},{"r":1751596,"p":[{"n":"tx","p":2800172},{"n":"enlistmentNotification","p":2603564},{"n":"enlistmentOptions","p":1882668},{"n":"atomicTransaction","p":4307500}],"n":"EnlistVolatile","d":8043052,"h":30072814124,"f":32776},{"r":1751596,"p":[{"n":"tx","p":2800172},{"n":"enlistmentNotification","p":3062316},{"n":"enlistmentOptions","p":1882668},{"n":"atomicTransaction","p":4307500}],"n":"EnlistVolatile","o":"@$1","d":8043052,"h":34367781420,"f":32776},{"r":1751596,"p":[{"n":"tx","p":2800172},{"n":"resourceManagerIdentifier","p":56164353},{"n":"enlistmentNotification","p":2603564},{"n":"enlistmentOptions","p":1882668},{"n":"atomicTransaction","p":4307500}],"n":"EnlistDurable","d":8043052,"h":38662748716,"f":32776},{"r":1751596,"p":[{"n":"tx","p":2800172},{"n":"resourceManagerIdentifier","p":56164353},{"n":"enlistmentNotification","p":3062316},{"n":"enlistmentOptions","p":1882668},{"n":"atomicTransaction","p":4307500}],"n":"EnlistDurable","o":"@$1","d":8043052,"h":42957716012,"f":32776}],"c":[{"n":".ctor","o":"$ctor$4","d":8043052,"h":47252683308,"f":1}],"h":8043052}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedCommitting; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedPhase1`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateDelegatedP0Wave", ($self) => class TransactionStateDelegatedP0Wave extends $.$stl.System.Transactions.TransactionStatePromotedP0Wave
        {
            /*void */ Phase0VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStateDelegatedCommitting.EnterState(tx);
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 6339116;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7846444,"m":[{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"Phase0VolatilePrepareDone","d":6339116,"h":4301306412,"f":32776}],"c":[{"n":".ctor","o":"$ctor$4","d":6339116,"h":8596273708,"f":1}],"h":6339116}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedP0Wave; }
            static get $fullName() { return `System.Transactions.TransactionStateDelegatedP0Wave`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateDelegatedCommitting", ($self) => class TransactionStateDelegatedCommitting extends $.$stl.System.Transactions.TransactionStatePromotedCommitting
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                $.$spc.System.Threading.Monitor.Exit(tx);
                $.$spc.System.Diagnostics.Debug.Assert$1(tx._durableEnlistment !== null, "tx._durableEnlistment != null");
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.EnlistmentStatus(1/*TraceSourceType.TraceSourceLtm*/, tx._durableEnlistment.EnlistmentTraceId, 4/*NotificationCall.SinglePhaseCommit*/);
                }
                try
                {
                    tx._durableEnlistment.PromotableSinglePhaseNotification.System$Transactions$IPromotableSinglePhaseNotification$SinglePhaseCommit(tx._durableEnlistment.SinglePhaseEnlistment);
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(tx);
                    }
                }
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 6208044;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7060012,"m":[{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"EnterState","d":6208044,"h":4301175340,"f":32776}],"c":[{"n":".ctor","o":"$ctor$4","d":6208044,"h":8596142636,"f":1}],"h":6208044}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedCommitting; }
            static get $fullName() { return `System.Transactions.TransactionStateDelegatedCommitting`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateSubordinateActive", ($self) => class TransactionStateSubordinateActive extends $.$stl.System.Transactions.TransactionStateActive
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                $.$spc.System.Diagnostics.Debug.Assert$1(tx._promoter !== null, "Transaction Promoter is Null entering SubordinateActive");
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                tx._innerException ??= e;
                $.$spc.System.Diagnostics.Debug.Assert$1(tx._promoter !== null, "tx._promoter != null");
                ($.$cast(tx._promoter, $.$stl.System.Transactions.ISimpleTransactionSuperior)).System$Transactions$ISimpleTransactionSuperior$Rollback();
                $.$stl.System.Transactions.TransactionState.TransactionStateAborted.EnterState(tx);
            }
            /*Enlistment */ EnlistVolatile(/*InternalTransaction*/ tx, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                tx._promoteState.EnterState(tx);
                return tx.State.EnlistVolatile(tx, enlistmentNotification, enlistmentOptions, atomicTransaction);
            }
            /*Enlistment */ EnlistVolatile$1(/*InternalTransaction*/ tx, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                tx._promoteState.EnterState(tx);
                return tx.State.EnlistVolatile$1(tx, enlistmentNotification, enlistmentOptions, atomicTransaction);
            }
            /*TransactionStatus */ get_Status(/*InternalTransaction*/ tx)
            {
                tx._promoteState.EnterState(tx);
                return tx.State.get_Status(tx);
            }
            /*void */ AddOutcomeRegistrant(/*InternalTransaction*/ tx, /*TransactionCompletedEventHandler?*/ transactionCompletedDelegate)
            {
                tx._promoteState.EnterState(tx);
                tx.State.AddOutcomeRegistrant(tx, transactionCompletedDelegate);
            }
            /*bool */ EnlistPromotableSinglePhase(/*InternalTransaction*/ tx, /*IPromotableSinglePhaseNotification*/ promotableSinglePhaseNotification, /*Transaction*/ atomicTransaction, /*Guid*/ promoterType)
            {
                return false;
            }
            /*void */ CreateBlockingClone(/*InternalTransaction*/ tx)
            {
                tx._promoteState.EnterState(tx);
                tx.State.CreateBlockingClone(tx);
            }
            /*void */ CreateAbortingClone(/*InternalTransaction*/ tx)
            {
                tx._promoteState.EnterState(tx);
                tx.State.CreateAbortingClone(tx);
            }
            //default reference type constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                return this;
            }
            static $h = 8239660;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":5880364,"m":[{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"EnterState","d":8239660,"h":4303206956,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"e","p":47185921}],"n":"Rollback","d":8239660,"h":8598174252,"f":32776},{"r":1751596,"p":[{"n":"tx","p":2800172},{"n":"enlistmentNotification","p":2603564},{"n":"enlistmentOptions","p":1882668},{"n":"atomicTransaction","p":4307500}],"n":"EnlistVolatile","d":8239660,"h":12893141548,"f":32776},{"r":1751596,"p":[{"n":"tx","p":2800172},{"n":"enlistmentNotification","p":3062316},{"n":"enlistmentOptions","p":1882668},{"n":"atomicTransaction","p":4307500}],"n":"EnlistVolatile","o":"@$1","d":8239660,"h":17188108844,"f":32776},{"r":8436268,"p":[{"n":"tx","p":2800172}],"n":"get_Status","d":8239660,"h":21483076140,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"transactionCompletedDelegate","p":4438572}],"n":"AddOutcomeRegistrant","d":8239660,"h":25778043436,"f":32776},{"r":262145,"p":[{"n":"tx","p":2800172},{"n":"promotableSinglePhaseNotification","p":2865708},{"n":"atomicTransaction","p":4307500},{"n":"promoterType","p":56164353}],"n":"EnlistPromotableSinglePhase","d":8239660,"h":30073010732,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"CreateBlockingClone","d":8239660,"h":34367978028,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"CreateAbortingClone","d":8239660,"h":38662945324,"f":32776}],"c":[{"n":".ctor","o":"$ctor$5","d":8239660,"h":42957912620,"f":1}],"h":8239660}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStateActive; }
            static get $fullName() { return `System.Transactions.TransactionStateSubordinateActive`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateDelegated", ($self) => class TransactionStateDelegated extends $.$stl.System.Transactions.TransactionStateDelegatedBase
        {
            /*void */ BeginCommit(/*InternalTransaction*/ tx, /*bool*/ asyncCommit, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                tx._asyncCommit = asyncCommit;
                tx._asyncCallback = asyncCallback;
                tx._asyncState = asyncState;
                $.$stl.System.Transactions.TransactionState.TransactionStateDelegatedCommitting.EnterState(tx);
            }
            /*bool */ PromoteDurable(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(tx._durableEnlistment !== null, "tx._durableEnlistment != null");
                tx._durableEnlistment.State.ChangeStateDelegated(tx._durableEnlistment);
                return true;
            }
            /*void */ RestartCommitIfNeeded(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStateDelegatedP0Wave.EnterState(tx);
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                tx._innerException ??= e;
                $.$stl.System.Transactions.TransactionState.TransactionStateDelegatedAborting.EnterState(tx);
            }
            //default reference type constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                return this;
            }
            static $h = 6011436;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6142508,"m":[{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"asyncCommit","p":262145},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":6011436,"h":4300978732,"f":32776},{"r":262145,"p":[{"n":"tx","p":2800172}],"n":"PromoteDurable","d":6011436,"h":8595946028,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"RestartCommitIfNeeded","d":6011436,"h":12890913324,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"e","p":47185921}],"n":"Rollback","d":6011436,"h":17185880620,"f":32776}],"c":[{"n":".ctor","o":"$ctor$5","d":6011436,"h":21480847916,"f":1}],"h":6011436}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStateDelegatedBase; }
            static get $fullName() { return `System.Transactions.TransactionStateDelegated`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateDelegatedSubordinate", ($self) => class TransactionStateDelegatedSubordinate extends $.$stl.System.Transactions.TransactionStateDelegatedBase
        {
            /*bool */ PromoteDurable(/*InternalTransaction*/ tx)
            {
                return true;
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                tx._innerException ??= e;
                $.$spc.System.Diagnostics.Debug.Assert$1(tx.PromotedTransaction !== null, "tx.PromotedTransaction != null");
                tx.PromotedTransaction.Rollback();
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedAborted.EnterState(tx);
            }
            /*void */ ChangeStatePromotedPhase0(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedPhase0.EnterState(tx);
            }
            /*void */ ChangeStatePromotedPhase1(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedPhase1.EnterState(tx);
            }
            //default reference type constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                return this;
            }
            static $h = 6404652;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6142508,"m":[{"r":262145,"p":[{"n":"tx","p":2800172}],"n":"PromoteDurable","d":6404652,"h":4301371948,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"e","p":47185921}],"n":"Rollback","d":6404652,"h":8596339244,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"ChangeStatePromotedPhase0","d":6404652,"h":12891306540,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"ChangeStatePromotedPhase1","d":6404652,"h":17186273836,"f":32776}],"c":[{"n":".ctor","o":"$ctor$5","d":6404652,"h":21481241132,"f":1}],"h":6404652}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStateDelegatedBase; }
            static get $fullName() { return `System.Transactions.TransactionStateDelegatedSubordinate`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateDelegatedAborting", ($self) => class TransactionStateDelegatedAborting extends $.$stl.System.Transactions.TransactionStatePromotedAborted
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                $.$spc.System.Threading.Monitor.Exit(tx);
                try
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(tx._durableEnlistment !== null, "tx._durableEnlistment != null");
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.EnlistmentStatus(1/*TraceSourceType.TraceSourceLtm*/, tx._durableEnlistment.EnlistmentTraceId, 2/*NotificationCall.Rollback*/);
                    }
                    tx._durableEnlistment.PromotableSinglePhaseNotification.System$Transactions$IPromotableSinglePhaseNotification$Rollback(tx._durableEnlistment.SinglePhaseEnlistment);
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(tx);
                    }
                }
            }
            /*void */ BeginCommit(/*InternalTransaction*/ tx, /*bool*/ asyncCommit, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ ChangeStatePromotedAborted(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedAborted.EnterState(tx);
            }
            //default reference type constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                return this;
            }
            static $h = 6076972;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6797868,"m":[{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"EnterState","d":6076972,"h":4301044268,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172},{"n":"asyncCommit","p":262145},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":6076972,"h":8596011564,"f":32776},{"r":65537,"p":[{"n":"tx","p":2800172}],"n":"ChangeStatePromotedAborted","d":6076972,"h":12890978860,"f":32776}],"c":[{"n":".ctor","o":"$ctor$5","d":6076972,"h":17185946156,"f":1}],"h":6076972}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedAborted; }
            static get $fullName() { return `System.Transactions.TransactionStateDelegatedAborting`; }
        });
        
        $asm.$cls("$stl.System.Transactions.RecoveringInternalEnlistment", ($self) => class RecoveringInternalEnlistment extends $.$stl.System.Transactions.DurableInternalEnlistment
        {
            /*object*/ _syncRoot = null;
            $ctor$7(/*Enlistment*/ enlistment, /*IEnlistmentNotification*/ twoPhaseNotifications, /*object*/ syncRoot)
            {
                super.$ctor$6(enlistment, twoPhaseNotifications);
                {
                    this._syncRoot = syncRoot;
                }
                return this;
            }
            /*object */ get SyncRoot()
            {
                return this._syncRoot;
            }
            static $h = 4045356;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1620524,"p":[{"p":131073,"g":{"r":0,"d":0,"h":17183914540,"f":32776},"n":"SyncRoot","d":4045356,"h":12888947244,"f":32776}],"l":[{"t":131073,"n":"_syncRoot","d":4045356,"h":4299012652,"f":2}],"c":[{"p":[{"n":"enlistment","p":1751596},{"n":"twoPhaseNotifications","p":2603564},{"n":"syncRoot","p":131073}],"n":".ctor","o":"$ctor$7","d":4045356,"h":8593979948,"f":8}],"i":[3127852,2669100],"h":4045356}; }
            static get $b() { return $.$stl.System.Transactions.DurableInternalEnlistment; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stl.System.Transactions.ISinglePhaseNotificationInternal, $.$stl.System.Transactions.IEnlistmentNotificationInternal ]; }
            static get $fullName() { return `System.Transactions.RecoveringInternalEnlistment`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionException", ($self) => class TransactionException extends $.$spc.System.SystemException
        {
            static /*bool */ IncludeDistributedTxId(/*Guid*/ distributedTxId)
            {
                return ($.$spc.System.Guid.op_Inequality(distributedTxId, $.$spc.System.Guid.Empty) && $.$stl.System.Transactions.Configuration.AppSettings.IncludeDistributedTxIdInExceptionMessage);
            }
            static /*TransactionException */ Create(/*string?*/ message, /*Exception?*/ innerException)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace$1(2/*TransactionExceptionType.TransactionException*/, message, innerException === null ? $.$spc.System.String.Empty : $.$spc.System.Exception.ToString.call(innerException));
                }
                return new $.$stl.System.Transactions.TransactionException().$ctor$11(message, innerException);
            }
            static /*TransactionException */ CreateTransactionStateException(/*Exception?*/ innerException)
            {
                return $.$stl.System.Transactions.TransactionException.Create($.$stl.System.SR.TransactionStateException, innerException);
            }
            static /*Exception */ CreateEnlistmentStateException(/*Exception?*/ innerException, /*Guid*/ distributedTxId)
            {
                /*string*/ let messagewithTxId = $.$stl.System.SR.EnlistmentStateException;
                if ($.$stl.System.Transactions.TransactionException.IncludeDistributedTxId(distributedTxId))
                {
                    messagewithTxId = $.$stl.System.SR.Format$1($.$stl.System.SR.DistributedTxIDInTransactionException, messagewithTxId, distributedTxId);
                }
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace$1(0/*TransactionExceptionType.InvalidOperationException*/, messagewithTxId, innerException === null ? $.$spc.System.String.Empty : $.$spc.System.Exception.ToString.call(innerException));
                }
                return new $.$spc.System.InvalidOperationException().$ctor$11(messagewithTxId, innerException);
            }
            static /*Exception */ CreateInvalidOperationException(/*TraceSourceType*/ traceSource, /*string?*/ message, /*Exception?*/ innerException)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace(traceSource, 0/*TransactionExceptionType.InvalidOperationException*/, message, innerException === null ? $.$spc.System.String.Empty : $.$spc.System.Exception.ToString.call(innerException));
                }
                return new $.$spc.System.InvalidOperationException().$ctor$11(message, innerException);
            }
            $ctor$9()
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            $ctor$10(/*string?*/ message)
            {
                super.$ctor$6(message);
                {
                }
                return this;
            }
            $ctor$11(/*string?*/ message, /*Exception?*/ innerException)
            {
                super.$ctor$7(message, innerException);
                {
                }
                return this;
            }
            $ctor$12(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor$8(info, context);
                {
                }
                return this;
            }
            static /*TransactionException */ Create$1(/*string?*/ message, /*Guid*/ distributedTxId)
            {
                if ($.$stl.System.Transactions.TransactionException.IncludeDistributedTxId(distributedTxId))
                {
                    return new $.$stl.System.Transactions.TransactionException().$ctor$10($.$stl.System.SR.Format$1($.$stl.System.SR.DistributedTxIDInTransactionException, message, distributedTxId));
                }
                return new $.$stl.System.Transactions.TransactionException().$ctor$10(message);
            }
            static /*TransactionException */ Create$2(/*string?*/ message, /*Exception?*/ innerException, /*Guid*/ distributedTxId)
            {
                /*string?*/ let messagewithTxId = message;
                if ($.$stl.System.Transactions.TransactionException.IncludeDistributedTxId(distributedTxId))
                {
                    messagewithTxId = $.$stl.System.SR.Format$1($.$stl.System.SR.DistributedTxIDInTransactionException, messagewithTxId, distributedTxId);
                }
                return $.$stl.System.Transactions.TransactionException.Create(messagewithTxId, innerException);
            }
            static /*TransactionException */ CreateTransactionStateException$1(/*Exception?*/ innerException, /*Guid*/ distributedTxId)
            {
                return $.$stl.System.Transactions.TransactionException.Create$2($.$stl.System.SR.TransactionStateException, innerException, distributedTxId);
            }
            static /*Exception */ CreateTransactionCompletedException(/*Guid*/ distributedTxId)
            {
                /*string*/ let messagewithTxId = $.$stl.System.SR.TransactionAlreadyCompleted;
                if ($.$stl.System.Transactions.TransactionException.IncludeDistributedTxId(distributedTxId))
                {
                    messagewithTxId = $.$stl.System.SR.Format$1($.$stl.System.SR.DistributedTxIDInTransactionException, messagewithTxId, distributedTxId);
                }
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace$1(0/*TransactionExceptionType.InvalidOperationException*/, messagewithTxId, $.$spc.System.String.Empty);
                }
                return new $.$spc.System.InvalidOperationException().$ctor$10(messagewithTxId);
            }
            static /*Exception */ CreateInvalidOperationException$1(/*TraceSourceType*/ traceSource, /*string?*/ message, /*Exception?*/ innerException, /*Guid*/ distributedTxId)
            {
                /*string?*/ let messagewithTxId = message;
                if ($.$stl.System.Transactions.TransactionException.IncludeDistributedTxId(distributedTxId))
                {
                    messagewithTxId = $.$stl.System.SR.Format$1($.$stl.System.SR.DistributedTxIDInTransactionException, messagewithTxId, distributedTxId);
                }
                return $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException(traceSource, messagewithTxId, innerException);
            }
            static $h = 4569644;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":119668737,"h":4569644}; }
            static get $b() { return $.$spc.System.SystemException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Transactions.TransactionException`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionAbortedException", ($self) => class TransactionAbortedException extends $.$stl.System.Transactions.TransactionException
        {
            static /*TransactionAbortedException */ Create$3(/*string?*/ message, /*Exception?*/ innerException, /*Guid*/ distributedTxId)
            {
                /*string?*/ let messagewithTxId = message;
                if ($.$stl.System.Transactions.TransactionException.IncludeDistributedTxId(distributedTxId))
                {
                    messagewithTxId = $.$stl.System.SR.Format$1($.$stl.System.SR.DistributedTxIDInTransactionException, messagewithTxId, distributedTxId);
                }
                return $.$stl.System.Transactions.TransactionAbortedException.Create$4(messagewithTxId, innerException);
            }
            static /*TransactionAbortedException */ Create$4(/*string?*/ message, /*Exception?*/ innerException)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace$1(1/*TransactionExceptionType.TransactionAbortedException*/, message, innerException === null ? $.$spc.System.String.Empty : $.$spc.System.Exception.ToString.call(innerException));
                }
                return new $.$stl.System.Transactions.TransactionAbortedException().$ctor$15(message, innerException);
            }
            $ctor$13()
            {
                super.$ctor$10($.$stl.System.SR.TransactionAborted);
                {
                }
                return this;
            }
            $ctor$14(/*string?*/ message)
            {
                super.$ctor$10(message ?? $.$stl.System.SR.TransactionAborted);
                {
                }
                return this;
            }
            $ctor$15(/*string?*/ message, /*Exception?*/ innerException)
            {
                super.$ctor$11(message ?? $.$stl.System.SR.TransactionAborted, innerException);
                {
                }
                return this;
            }
            $ctor$16(/*Exception?*/ innerException)
            {
                super.$ctor$11($.$stl.System.SR.TransactionAborted, innerException);
                {
                }
                return this;
            }
            $ctor$17(/*Exception?*/ innerException, /*Guid*/ distributedTxId)
            {
                super.$ctor$11($.$stl.System.Transactions.TransactionException.IncludeDistributedTxId(distributedTxId) ? $.$stl.System.SR.Format$1($.$stl.System.SR.DistributedTxIDInTransactionException, $.$stl.System.SR.TransactionAborted, distributedTxId) : $.$stl.System.SR.TransactionAborted, innerException);
                {
                }
                return this;
            }
            $ctor$18(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor$12(info, context);
                {
                }
                return this;
            }
            static $h = 4373036;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":4569644,"h":4373036}; }
            static get $b() { return $.$stl.System.Transactions.TransactionException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Transactions.TransactionAbortedException`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionInDoubtException", ($self) => class TransactionInDoubtException extends $.$stl.System.Transactions.TransactionException
        {
            static /*TransactionInDoubtException */ Create$3(/*TraceSourceType*/ traceSource, /*string?*/ message, /*Exception?*/ innerException, /*Guid*/ distributedTxId)
            {
                /*string?*/ let messagewithTxId = message;
                if ($.$stl.System.Transactions.TransactionException.IncludeDistributedTxId(distributedTxId))
                {
                    messagewithTxId = $.$stl.System.SR.Format$1($.$stl.System.SR.DistributedTxIDInTransactionException, messagewithTxId, distributedTxId);
                }
                return $.$stl.System.Transactions.TransactionInDoubtException.Create$4(traceSource, messagewithTxId, innerException);
            }
            static /*TransactionInDoubtException */ Create$4(/*TraceSourceType*/ traceSource, /*string?*/ message, /*Exception?*/ innerException)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace(traceSource, 3/*TransactionExceptionType.TransactionInDoubtException*/, message, innerException === null ? $.$spc.System.String.Empty : $.$spc.System.Exception.ToString.call(innerException));
                }
                return new $.$stl.System.Transactions.TransactionInDoubtException().$ctor$15(message, innerException);
            }
            $ctor$13()
            {
                super.$ctor$10($.$stl.System.SR.TransactionIndoubt);
                {
                }
                return this;
            }
            $ctor$14(/*string?*/ message)
            {
                super.$ctor$10(message ?? $.$stl.System.SR.TransactionIndoubt);
                {
                }
                return this;
            }
            $ctor$15(/*string?*/ message, /*Exception?*/ innerException)
            {
                super.$ctor$11(message ?? $.$stl.System.SR.TransactionIndoubt, innerException);
                {
                }
                return this;
            }
            $ctor$16(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor$12(info, context);
                {
                }
                return this;
            }
            static $h = 4700716;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":4569644,"h":4700716}; }
            static get $b() { return $.$stl.System.Transactions.TransactionException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Transactions.TransactionInDoubtException`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionManagerCommunicationException", ($self) => class TransactionManagerCommunicationException extends $.$stl.System.Transactions.TransactionException
        {
            static /*TransactionManagerCommunicationException */ Create$3(/*string?*/ message, /*Exception?*/ innerException)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace$1(4/*TransactionExceptionType.TransactionManagerCommunicationException*/, message, innerException === null ? $.$spc.System.String.Empty : $.$spc.System.Exception.ToString.call(innerException));
                }
                return new $.$stl.System.Transactions.TransactionManagerCommunicationException().$ctor$15(message, innerException);
            }
            static /*TransactionManagerCommunicationException */ Create$4(/*Exception?*/ innerException)
            {
                return $.$stl.System.Transactions.TransactionManagerCommunicationException.Create$3($.$stl.System.SR.TransactionManagerCommunicationException, innerException);
            }
            $ctor$13()
            {
                super.$ctor$10($.$stl.System.SR.TransactionManagerCommunicationException);
                {
                }
                return this;
            }
            $ctor$14(/*string?*/ message)
            {
                super.$ctor$10(message ?? $.$stl.System.SR.TransactionManagerCommunicationException);
                {
                }
                return this;
            }
            $ctor$15(/*string?*/ message, /*Exception?*/ innerException)
            {
                super.$ctor$11(message ?? $.$stl.System.SR.TransactionManagerCommunicationException, innerException);
                {
                }
                return this;
            }
            $ctor$16(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor$12(info, context);
                {
                }
                return this;
            }
            static $h = 4962860;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":4569644,"h":4962860}; }
            static get $b() { return $.$stl.System.Transactions.TransactionException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Transactions.TransactionManagerCommunicationException`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionPromotionException", ($self) => class TransactionPromotionException extends $.$stl.System.Transactions.TransactionException
        {
            $ctor$13()
            {
                this.$ctor$14($.$stl.System.SR.PromotionFailed);
                {
                }
                return this;
            }
            $ctor$14(/*string?*/ message)
            {
                super.$ctor$10(message ?? $.$stl.System.SR.PromotionFailed);
                {
                }
                return this;
            }
            $ctor$15(/*string?*/ message, /*Exception?*/ innerException)
            {
                super.$ctor$11(message ?? $.$stl.System.SR.PromotionFailed, innerException);
                {
                }
                return this;
            }
            $ctor$16(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor$12(info, context);
                {
                }
                return this;
            }
            static $h = 5093932;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":4569644,"h":5093932}; }
            static get $b() { return $.$stl.System.Transactions.TransactionException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Transactions.TransactionPromotionException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Runtime.Loader", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Threading", "NetJs.System.Threading.Overlapped", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.Runtime.Numerics", "NetJs.System.Security.Claims", "NetJs.System.Runtime.InteropServices", "NetJs.System.Threading.Channels", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Console", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Linq", "NetJs.System.Net.Primitives", "NetJs.System.Security.Principal.Windows", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Collections.Specialized", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Collections.Immutable", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Security.AccessControl", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Reflection.Metadata", "NetJs.System.Net.NameResolution", "NetJs.Microsoft.Win32.Registry", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Reflection.Emit", "NetJs.System.Net.Sockets", "NetJs.System.Diagnostics.Process", "NetJs.System.Security.Cryptography", "NetJs.System.Linq.Expressions", "NetJs.System.Text.RegularExpressions", "NetJs.System.Net.NetworkInformation", "NetJs.System.Net.Security", "NetJs.System.Net.Quic", "NetJs.System.Net.Http", "NetJs.System.Private.Xml", "NetJs.System.Xml.ReaderWriter"))