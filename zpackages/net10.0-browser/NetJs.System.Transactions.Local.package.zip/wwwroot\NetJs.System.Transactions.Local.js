
(function ($global, $, $spc, $mwp, $sc, $sm, $spu, $sr, $sdt, $st, $scc, $sris, $scn, $stt, $ssc, $sspw, $ssa, $mwr, $snv, $sri, $sl, $sci, $scm, $so, $scp, $scs, $stee, $scsl, $sttp, $sdd, $sdf, $sifd, $sto, $sip, $sdpc, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $sxr) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Transactions.Local", 
    {"h":34276,"f":"System.Transactions.Local","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bf7a34a6f78fee11131301a9f55ca16a968616013","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Transactions.Local","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Transactions.Local","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$stl.System.Transactions.IDtcTransaction", ($self) => class IDtcTransaction
        {
            static $h = 2524644;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"p":[{"n":"retaining","p":655361},{"n":"commitType","p":655361,"a":[{"t":105709569,"c":8695644161,"a":[{"v":7,"t":110886913}]}]},{"n":"reserved","p":655361}],"n":"Commit","o":"System$Transactions$IDtcTransaction$Commit","d":2524644,"h":4297491940,"f":257},{"r":65537,"p":[{"n":"reason","p":786433},{"n":"retaining","p":655361},{"n":"async","p":655361}],"n":"Abort","o":"System$Transactions$IDtcTransaction$Abort","d":2524644,"h":8592459236,"f":257},{"r":65537,"p":[{"n":"transactionInformation","p":786433}],"n":"GetTransactionInfo","o":"System$Transactions$IDtcTransaction$GetTransactionInfo","d":2524644,"h":12887426532,"f":257}],"h":2524644,"a":[{"t":99155969,"c":4394123265},{"t":104398849,"c":4399366145,"a":[{"v":"0fb15084-af41-11ce-bd2b-204c4f4f5020","t":1310721}]},{"t":104923137,"c":4399890433,"a":[{"v":1,"t":99221505}]}]}; }
            static get $fullName() { return `System.Transactions.IDtcTransaction`; }
        });
        
        $asm.$cls("$stl.System.Transactions.ITransactionPromoter", ($self) => class ITransactionPromoter
        {
            static $h = 3245540;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":0,"n":"Promote","o":"System$Transactions$ITransactionPromoter$Promote","d":3245540,"h":4298212836,"f":257}],"h":3245540}; }
            static get $fullName() { return `System.Transactions.ITransactionPromoter`; }
        });
        
        $asm.$cls("$stl.System.Transactions.IEnlistmentNotificationInternal", ($self) => class IEnlistmentNotificationInternal
        {
            static $h = 2655716;
            static $f = 0b100100;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"p":[{"n":"preparingEnlistment","p":2917860}],"n":"Prepare","o":"System$Transactions$IEnlistmentNotificationInternal$Prepare","d":2655716,"h":4297623012,"f":257},{"r":65537,"p":[{"n":"enlistment","p":2917860}],"n":"Commit","o":"System$Transactions$IEnlistmentNotificationInternal$Commit","d":2655716,"h":8592590308,"f":257},{"r":65537,"p":[{"n":"enlistment","p":2917860}],"n":"Rollback","o":"System$Transactions$IEnlistmentNotificationInternal$Rollback","d":2655716,"h":12887557604,"f":257},{"r":65537,"p":[{"n":"enlistment","p":2917860}],"n":"InDoubt","o":"System$Transactions$IEnlistmentNotificationInternal$InDoubt","d":2655716,"h":17182524900,"f":257}],"h":2655716}; }
            static get $fullName() { return `System.Transactions.IEnlistmentNotificationInternal`; }
        });
        
        $asm.$cls("$stl.System.Transactions.IEnlistmentNotification", ($self) => class IEnlistmentNotification
        {
            static $h = 2590180;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"p":[{"n":"preparingEnlistment","p":3900900}],"n":"Prepare","o":"System$Transactions$IEnlistmentNotification$Prepare","d":2590180,"h":4297557476,"f":257},{"r":65537,"p":[{"n":"enlistment","p":1738212}],"n":"Commit","o":"System$Transactions$IEnlistmentNotification$Commit","d":2590180,"h":8592524772,"f":257},{"r":65537,"p":[{"n":"enlistment","p":1738212}],"n":"Rollback","o":"System$Transactions$IEnlistmentNotification$Rollback","d":2590180,"h":12887492068,"f":257},{"r":65537,"p":[{"n":"enlistment","p":1738212}],"n":"InDoubt","o":"System$Transactions$IEnlistmentNotification$InDoubt","d":2590180,"h":17182459364,"f":257}],"h":2590180}; }
            static get $fullName() { return `System.Transactions.IEnlistmentNotification`; }
        });
        
        $asm.$cls("$stl.System.Transactions.IPromotedEnlistment", ($self) => class IPromotedEnlistment
        {
            static $h = 2917860;
            static $f = 0b100100;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":2721252,"g":{"r":0,"d":0,"h":51542525412,"f":257},"s":{"r":0,"d":0,"h":55837492708,"f":257},"n":"InternalEnlistment","o":"System$Transactions$IPromotedEnlistment$InternalEnlistment","d":2917860,"h":47247558116,"f":257}],"m":[{"r":65537,"n":"EnlistmentDone","o":"System$Transactions$IPromotedEnlistment$EnlistmentDone","d":2917860,"h":4297885156,"f":257},{"r":65537,"n":"Prepared","o":"System$Transactions$IPromotedEnlistment$Prepared","d":2917860,"h":8592852452,"f":257},{"r":65537,"n":"ForceRollback","o":"System$Transactions$IPromotedEnlistment$ForceRollback","d":2917860,"h":12887819748,"f":257},{"r":65537,"p":[{"n":"e","p":47251457}],"n":"ForceRollback","o":"System$Transactions$IPromotedEnlistment$ForceRollback$1","d":2917860,"h":17182787044,"f":257},{"r":65537,"n":"Committed","o":"System$Transactions$IPromotedEnlistment$Committed","d":2917860,"h":21477754340,"f":257},{"r":65537,"n":"Aborted","o":"System$Transactions$IPromotedEnlistment$Aborted","d":2917860,"h":25772721636,"f":257},{"r":65537,"p":[{"n":"e","p":47251457}],"n":"Aborted","o":"System$Transactions$IPromotedEnlistment$Aborted$1","d":2917860,"h":30067688932,"f":257},{"r":65537,"n":"InDoubt","o":"System$Transactions$IPromotedEnlistment$InDoubt","d":2917860,"h":34362656228,"f":257},{"r":65537,"p":[{"n":"e","p":47251457}],"n":"InDoubt","o":"System$Transactions$IPromotedEnlistment$InDoubt$1","d":2917860,"h":38657623524,"f":257},{"r":0,"n":"GetRecoveryInformation","o":"System$Transactions$IPromotedEnlistment$GetRecoveryInformation","d":2917860,"h":42952590820,"f":257}],"h":2917860}; }
            static get $fullName() { return `System.Transactions.IPromotedEnlistment`; }
        });
        
        $asm.$cls("$stl.System.Transactions.ISinglePhaseNotificationInternal", ($self) => class ISinglePhaseNotificationInternal
        {
            static $h = 3114468;
            static $f = 0b100100;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"p":[{"n":"singlePhaseEnlistment","p":2917860}],"n":"SinglePhaseCommit","o":"System$Transactions$ISinglePhaseNotificationInternal$SinglePhaseCommit","d":3114468,"h":4298081764,"f":257}],"i":[2655716],"h":3114468}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stl.System.Transactions.IEnlistmentNotificationInternal ]; }
            static get $fullName() { return `System.Transactions.ISinglePhaseNotificationInternal`; }
        });
        
        $asm.$cls("$stl.System.Transactions.IPromotableSinglePhaseNotification", ($self) => class IPromotableSinglePhaseNotification
        {
            static $h = 2852324;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"n":"Initialize","o":"System$Transactions$IPromotableSinglePhaseNotification$Initialize","d":2852324,"h":4297819620,"f":257},{"r":65537,"p":[{"n":"singlePhaseEnlistment","p":4097508}],"n":"SinglePhaseCommit","o":"System$Transactions$IPromotableSinglePhaseNotification$SinglePhaseCommit","d":2852324,"h":8592786916,"f":257},{"r":65537,"p":[{"n":"singlePhaseEnlistment","p":4097508}],"n":"Rollback","o":"System$Transactions$IPromotableSinglePhaseNotification$Rollback","d":2852324,"h":12887754212,"f":257}],"i":[3245540],"h":2852324}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stl.System.Transactions.ITransactionPromoter ]; }
            static get $fullName() { return `System.Transactions.IPromotableSinglePhaseNotification`; }
        });
        
        $asm.$cls("$stl.System.Transactions.ISimpleTransactionSuperior", ($self) => class ISimpleTransactionSuperior
        {
            static $h = 2983396;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"n":"Rollback","o":"System$Transactions$ISimpleTransactionSuperior$Rollback","d":2983396,"h":4297950692,"f":257}],"i":[3245540],"h":2983396}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stl.System.Transactions.ITransactionPromoter ]; }
            static get $fullName() { return `System.Transactions.ISimpleTransactionSuperior`; }
        });
        
        $asm.$cls("$stl.System.Transactions.ISinglePhaseNotification", ($self) => class ISinglePhaseNotification
        {
            static $h = 3048932;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"p":[{"n":"singlePhaseEnlistment","p":4097508}],"n":"SinglePhaseCommit","o":"System$Transactions$ISinglePhaseNotification$SinglePhaseCommit","d":3048932,"h":4298016228,"f":257}],"i":[2590180],"h":3048932}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stl.System.Transactions.IEnlistmentNotification ]; }
            static get $fullName() { return `System.Transactions.ISinglePhaseNotification`; }
        });
        
        $asm.$cls("$stl.System.Transactions.EnlistmentState", ($self) => class EnlistmentState extends $.$spc.System.Object
        {
            /*EnlistmentStatePromoted?*/ static _enlistmentStatePromoted = null;
            /*object?*/ static s_classSyncObject = null;
            static /*EnlistmentStatePromoted */ get EnlistmentStatePromoted()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.EnlistmentStatePromoted, $.$ref(() => $.$stl.System.Transactions.EnlistmentState._enlistmentStatePromoted, ($v) => $.$stl.System.Transactions.EnlistmentState._enlistmentStatePromoted = $v, $.$stl.System.Transactions.EnlistmentStatePromoted), $.$ref(() => $.$stl.System.Transactions.EnlistmentState.s_classSyncObject, ($v) => $.$stl.System.Transactions.EnlistmentState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.EnlistmentStatePromoted))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.EnlistmentStatePromoted().$ctor$2();
                }, {"r":2000356,"n":"","d":1934820,"h":0,"f":1048578}));
            }
            /*void */ EnlistmentDone(/*InternalEnlistment*/ enlistment)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateEnlistmentStateException(null, enlistment === null ? $.$spc.System.Guid.Empty : enlistment.DistributedTxId);
            }
            /*void */ Prepared(/*InternalEnlistment*/ enlistment)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateEnlistmentStateException(null, enlistment === null ? $.$spc.System.Guid.Empty : enlistment.DistributedTxId);
            }
            /*void */ ForceRollback(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateEnlistmentStateException(null, enlistment === null ? $.$spc.System.Guid.Empty : enlistment.DistributedTxId);
            }
            /*void */ Committed(/*InternalEnlistment*/ enlistment)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateEnlistmentStateException(null, enlistment === null ? $.$spc.System.Guid.Empty : enlistment.DistributedTxId);
            }
            /*void */ Aborted(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateEnlistmentStateException(null, enlistment === null ? $.$spc.System.Guid.Empty : enlistment.DistributedTxId);
            }
            /*void */ InDoubt(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateEnlistmentStateException(null, enlistment === null ? $.$spc.System.Guid.Empty : enlistment.DistributedTxId);
            }
            /*byte[] */ RecoveryInformation(/*InternalEnlistment*/ enlistment)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateEnlistmentStateException(null, enlistment === null ? $.$spc.System.Guid.Empty : enlistment.DistributedTxId);
            }
            /*void */ InternalAborted(/*InternalEnlistment*/ enlistment)
            {
                $.$spc.System.Diagnostics.Debug.Fail(`Invalid Event for InternalEnlistment State; Current State: ${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))}`);
                throw $.$stl.System.Transactions.TransactionException.CreateEnlistmentStateException(null, enlistment === null ? $.$spc.System.Guid.Empty : enlistment.DistributedTxId);
            }
            /*void */ InternalCommitted(/*InternalEnlistment*/ enlistment)
            {
                $.$spc.System.Diagnostics.Debug.Fail(`Invalid Event for InternalEnlistment State; Current State: ${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))}`);
                throw $.$stl.System.Transactions.TransactionException.CreateEnlistmentStateException(null, enlistment === null ? $.$spc.System.Guid.Empty : enlistment.DistributedTxId);
            }
            /*void */ InternalIndoubt(/*InternalEnlistment*/ enlistment)
            {
                $.$spc.System.Diagnostics.Debug.Fail(`Invalid Event for InternalEnlistment State; Current State: ${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))}`);
                throw $.$stl.System.Transactions.TransactionException.CreateEnlistmentStateException(null, enlistment === null ? $.$spc.System.Guid.Empty : enlistment.DistributedTxId);
            }
            /*void */ ChangeStateCommitting(/*InternalEnlistment*/ enlistment)
            {
                $.$spc.System.Diagnostics.Debug.Fail(`Invalid Event for InternalEnlistment State; Current State: ${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))}`);
                throw $.$stl.System.Transactions.TransactionException.CreateEnlistmentStateException(null, enlistment === null ? $.$spc.System.Guid.Empty : enlistment.DistributedTxId);
            }
            /*void */ ChangeStatePromoted(/*InternalEnlistment*/ enlistment, /*IPromotedEnlistment*/ promotedEnlistment)
            {
                $.$spc.System.Diagnostics.Debug.Fail(`Invalid Event for InternalEnlistment State; Current State: ${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))}`);
                throw $.$stl.System.Transactions.TransactionException.CreateEnlistmentStateException(null, enlistment === null ? $.$spc.System.Guid.Empty : enlistment.DistributedTxId);
            }
            /*void */ ChangeStateDelegated(/*InternalEnlistment*/ enlistment)
            {
                $.$spc.System.Diagnostics.Debug.Fail(`Invalid Event for InternalEnlistment State; Current State: ${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))}`);
                throw $.$stl.System.Transactions.TransactionException.CreateEnlistmentStateException(null, enlistment === null ? $.$spc.System.Guid.Empty : enlistment.DistributedTxId);
            }
            /*void */ ChangeStatePreparing(/*InternalEnlistment*/ enlistment)
            {
                $.$spc.System.Diagnostics.Debug.Fail(`Invalid Event for InternalEnlistment State; Current State: ${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))}`);
                throw $.$stl.System.Transactions.TransactionException.CreateEnlistmentStateException(null, enlistment === null ? $.$spc.System.Guid.Empty : enlistment.DistributedTxId);
            }
            /*void */ ChangeStateSinglePhaseCommit(/*InternalEnlistment*/ enlistment)
            {
                $.$spc.System.Diagnostics.Debug.Fail(`Invalid Event for InternalEnlistment State; Current State: ${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))}`);
                throw $.$stl.System.Transactions.TransactionException.CreateEnlistmentStateException(null, enlistment === null ? $.$spc.System.Guid.Empty : enlistment.DistributedTxId);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 1934820;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":2000356,"g":{"r":0,"d":0,"h":21476771300,"f":40},"n":"EnlistmentStatePromoted","d":1934820,"h":17181804004,"f":40}],"m":[{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"EnterState","d":1934820,"h":4296902116,"f":264},{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"EnlistmentDone","d":1934820,"h":25771738596,"f":136},{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"Prepared","d":1934820,"h":30066705892,"f":136},{"r":65537,"p":[{"n":"enlistment","p":2721252},{"n":"e","p":47251457}],"n":"ForceRollback","d":1934820,"h":34361673188,"f":136},{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"Committed","d":1934820,"h":38656640484,"f":136},{"r":65537,"p":[{"n":"enlistment","p":2721252},{"n":"e","p":47251457}],"n":"Aborted","d":1934820,"h":42951607780,"f":136},{"r":65537,"p":[{"n":"enlistment","p":2721252},{"n":"e","p":47251457}],"n":"InDoubt","d":1934820,"h":47246575076,"f":136},{"r":0,"p":[{"n":"enlistment","p":2721252}],"n":"RecoveryInformation","d":1934820,"h":51541542372,"f":136},{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"InternalAborted","d":1934820,"h":55836509668,"f":136},{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"InternalCommitted","d":1934820,"h":60131476964,"f":136},{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"InternalIndoubt","d":1934820,"h":64426444260,"f":136},{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"ChangeStateCommitting","d":1934820,"h":68721411556,"f":136},{"r":65537,"p":[{"n":"enlistment","p":2721252},{"n":"promotedEnlistment","p":2917860}],"n":"ChangeStatePromoted","d":1934820,"h":73016378852,"f":136},{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"ChangeStateDelegated","d":1934820,"h":77311346148,"f":136},{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"ChangeStatePreparing","d":1934820,"h":81606313444,"f":136},{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"ChangeStateSinglePhaseCommit","d":1934820,"h":85901280740,"f":136}],"l":[{"t":2000356,"n":"_enlistmentStatePromoted","d":1934820,"h":8591869412,"f":40},{"t":131073,"n":"s_classSyncObject","d":1934820,"h":12886836708,"f":34}],"c":[{"n":".ctor","o":"$ctor$1","d":1934820,"h":90196248036,"f":4}],"h":1934820}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Transactions.EnlistmentState`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionState", ($self) => class TransactionState extends $.$spc.System.Object
        {
            /*TransactionStateActive?*/ static s_transactionStateActive = null;
            /*TransactionStateSubordinateActive?*/ static s_transactionStateSubordinateActive = null;
            /*TransactionStatePhase0?*/ static s_transactionStatePhase0 = null;
            /*TransactionStateVolatilePhase1?*/ static s_transactionStateVolatilePhase1 = null;
            /*TransactionStateVolatileSPC?*/ static s_transactionStateVolatileSPC = null;
            /*TransactionStateSPC?*/ static s_transactionStateSPC = null;
            /*TransactionStateAborted?*/ static s_transactionStateAborted = null;
            /*TransactionStateCommitted?*/ static s_transactionStateCommitted = null;
            /*TransactionStateInDoubt?*/ static s_transactionStateInDoubt = null;
            /*TransactionStatePromoted?*/ static s_transactionStatePromoted = null;
            /*TransactionStateNonCommittablePromoted?*/ static s_transactionStateNonCommittablePromoted = null;
            /*TransactionStatePromotedP0Wave?*/ static s_transactionStatePromotedP0Wave = null;
            /*TransactionStatePromotedCommitting?*/ static s_transactionStatePromotedCommitting = null;
            /*TransactionStatePromotedPhase0?*/ static s_transactionStatePromotedPhase0 = null;
            /*TransactionStatePromotedPhase1?*/ static s_transactionStatePromotedPhase1 = null;
            /*TransactionStatePromotedP0Aborting?*/ static s_transactionStatePromotedP0Aborting = null;
            /*TransactionStatePromotedP1Aborting?*/ static s_transactionStatePromotedP1Aborting = null;
            /*TransactionStatePromotedAborted?*/ static s_transactionStatePromotedAborted = null;
            /*TransactionStatePromotedCommitted?*/ static s_transactionStatePromotedCommitted = null;
            /*TransactionStatePromotedIndoubt?*/ static s_transactionStatePromotedIndoubt = null;
            /*TransactionStateDelegated?*/ static s_transactionStateDelegated = null;
            /*TransactionStateDelegatedSubordinate?*/ static s_transactionStateDelegatedSubordinate = null;
            /*TransactionStateDelegatedP0Wave?*/ static s_transactionStateDelegatedP0Wave = null;
            /*TransactionStateDelegatedCommitting?*/ static s_transactionStateDelegatedCommitting = null;
            /*TransactionStateDelegatedAborting?*/ static s_transactionStateDelegatedAborting = null;
            /*TransactionStatePSPEOperation?*/ static s_transactionStatePSPEOperation = null;
            /*TransactionStateDelegatedNonMSDTC?*/ static s_transactionStateDelegatedNonMSDTC = null;
            /*TransactionStatePromotedNonMSDTCPhase0?*/ static s_transactionStatePromotedNonMSDTCPhase0 = null;
            /*TransactionStatePromotedNonMSDTCVolatilePhase1?*/ static s_transactionStatePromotedNonMSDTCVolatilePhase1 = null;
            /*TransactionStatePromotedNonMSDTCSinglePhaseCommit?*/ static s_transactionStatePromotedNonMSDTCSinglePhaseCommit = null;
            /*TransactionStatePromotedNonMSDTCAborted?*/ static s_transactionStatePromotedNonMSDTCAborted = null;
            /*TransactionStatePromotedNonMSDTCCommitted?*/ static s_transactionStatePromotedNonMSDTCCommitted = null;
            /*TransactionStatePromotedNonMSDTCIndoubt?*/ static s_transactionStatePromotedNonMSDTCIndoubt = null;
            /*object?*/ static s_classSyncObject = null;
            static /*TransactionStateActive */ get TransactionStateActive()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStateActive, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStateActive, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStateActive = $v, $.$stl.System.Transactions.TransactionStateActive), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStateActive))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStateActive().$ctor$4();
                }, {"r":5866980,"n":"","d":5735908,"h":0,"f":1048578}));
            }
            static /*TransactionStateSubordinateActive */ get TransactionStateSubordinateActive()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStateSubordinateActive, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStateSubordinateActive, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStateSubordinateActive = $v, $.$stl.System.Transactions.TransactionStateSubordinateActive), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStateSubordinateActive))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStateSubordinateActive().$ctor$5();
                }, {"r":8226276,"n":"","d":5735908,"h":0,"f":1048578}));
            }
            static /*TransactionStatePSPEOperation */ get TransactionStatePSPEOperation()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStatePSPEOperation, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePSPEOperation, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePSPEOperation = $v, $.$stl.System.Transactions.TransactionStatePSPEOperation), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStatePSPEOperation))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePSPEOperation().$ctor$2();
                }, {"r":8095204,"n":"","d":5735908,"h":0,"f":1048578}));
            }
            static /*TransactionStatePhase0 */ get TransactionStatePhase0()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStatePhase0, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePhase0, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePhase0 = $v, $.$stl.System.Transactions.TransactionStatePhase0), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStatePhase0))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePhase0().$ctor$4();
                }, {"r":6653412,"n":"","d":5735908,"h":0,"f":1048578}));
            }
            static /*TransactionStateVolatilePhase1 */ get TransactionStateVolatilePhase1()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStateVolatilePhase1, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStateVolatilePhase1, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStateVolatilePhase1 = $v, $.$stl.System.Transactions.TransactionStateVolatilePhase1), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStateVolatilePhase1))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStateVolatilePhase1().$ctor$3();
                }, {"r":8291812,"n":"","d":5735908,"h":0,"f":1048578}));
            }
            static /*TransactionStateVolatileSPC */ get TransactionStateVolatileSPC()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStateVolatileSPC, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStateVolatileSPC, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStateVolatileSPC = $v, $.$stl.System.Transactions.TransactionStateVolatileSPC), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStateVolatileSPC))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStateVolatileSPC().$ctor$3();
                }, {"r":8357348,"n":"","d":5735908,"h":0,"f":1048578}));
            }
            static /*TransactionStateSPC */ get TransactionStateSPC()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStateSPC, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStateSPC, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStateSPC = $v, $.$stl.System.Transactions.TransactionStateSPC), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStateSPC))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStateSPC().$ctor$3();
                }, {"r":8160740,"n":"","d":5735908,"h":0,"f":1048578}));
            }
            static /*TransactionStateAborted */ get TransactionStateAborted()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStateAborted, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStateAborted, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStateAborted = $v, $.$stl.System.Transactions.TransactionStateAborted), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStateAborted))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStateAborted().$ctor$3();
                }, {"r":5801444,"n":"","d":5735908,"h":0,"f":1048578}));
            }
            static /*TransactionStateCommitted */ get TransactionStateCommitted()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStateCommitted, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStateCommitted, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStateCommitted = $v, $.$stl.System.Transactions.TransactionStateCommitted), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStateCommitted))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStateCommitted().$ctor$3();
                }, {"r":5932516,"n":"","d":5735908,"h":0,"f":1048578}));
            }
            static /*TransactionStateInDoubt */ get TransactionStateInDoubt()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStateInDoubt, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStateInDoubt, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStateInDoubt = $v, $.$stl.System.Transactions.TransactionStateInDoubt), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStateInDoubt))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStateInDoubt().$ctor$3();
                }, {"r":6522340,"n":"","d":5735908,"h":0,"f":1048578}));
            }
            static /*TransactionStatePromoted */ get TransactionStatePromoted()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStatePromoted, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromoted, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromoted = $v, $.$stl.System.Transactions.TransactionStatePromoted), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStatePromoted))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromoted().$ctor$3();
                }, {"r":6718948,"n":"","d":5735908,"h":0,"f":1048578}));
            }
            static /*TransactionStateNonCommittablePromoted */ get TransactionStateNonCommittablePromoted()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStateNonCommittablePromoted, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStateNonCommittablePromoted, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStateNonCommittablePromoted = $v, $.$stl.System.Transactions.TransactionStateNonCommittablePromoted), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStateNonCommittablePromoted))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStateNonCommittablePromoted().$ctor$3();
                }, {"r":6587876,"n":"","d":5735908,"h":0,"f":1048578}));
            }
            static /*TransactionStatePromotedP0Wave */ get TransactionStatePromotedP0Wave()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStatePromotedP0Wave, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedP0Wave, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedP0Wave = $v, $.$stl.System.Transactions.TransactionStatePromotedP0Wave), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStatePromotedP0Wave))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromotedP0Wave().$ctor$3();
                }, {"r":7833060,"n":"","d":5735908,"h":0,"f":1048578}));
            }
            static /*TransactionStatePromotedCommitting */ get TransactionStatePromotedCommitting()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStatePromotedCommitting, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedCommitting, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedCommitting = $v, $.$stl.System.Transactions.TransactionStatePromotedCommitting), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStatePromotedCommitting))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromotedCommitting().$ctor$3();
                }, {"r":7046628,"n":"","d":5735908,"h":0,"f":1048578}));
            }
            static /*TransactionStatePromotedPhase0 */ get TransactionStatePromotedPhase0()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStatePromotedPhase0, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedPhase0, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedPhase0 = $v, $.$stl.System.Transactions.TransactionStatePromotedPhase0), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStatePromotedPhase0))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromotedPhase0().$ctor$4();
                }, {"r":7964132,"n":"","d":5735908,"h":0,"f":1048578}));
            }
            static /*TransactionStatePromotedPhase1 */ get TransactionStatePromotedPhase1()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStatePromotedPhase1, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedPhase1, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedPhase1 = $v, $.$stl.System.Transactions.TransactionStatePromotedPhase1), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStatePromotedPhase1))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromotedPhase1().$ctor$4();
                }, {"r":8029668,"n":"","d":5735908,"h":0,"f":1048578}));
            }
            static /*TransactionStatePromotedP0Aborting */ get TransactionStatePromotedP0Aborting()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStatePromotedP0Aborting, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedP0Aborting, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedP0Aborting = $v, $.$stl.System.Transactions.TransactionStatePromotedP0Aborting), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStatePromotedP0Aborting))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromotedP0Aborting().$ctor$4();
                }, {"r":7767524,"n":"","d":5735908,"h":0,"f":1048578}));
            }
            static /*TransactionStatePromotedP1Aborting */ get TransactionStatePromotedP1Aborting()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStatePromotedP1Aborting, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedP1Aborting, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedP1Aborting = $v, $.$stl.System.Transactions.TransactionStatePromotedP1Aborting), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStatePromotedP1Aborting))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromotedP1Aborting().$ctor$4();
                }, {"r":7898596,"n":"","d":5735908,"h":0,"f":1048578}));
            }
            static /*TransactionStatePromotedAborted */ get TransactionStatePromotedAborted()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStatePromotedAborted, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedAborted, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedAborted = $v, $.$stl.System.Transactions.TransactionStatePromotedAborted), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStatePromotedAborted))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromotedAborted().$ctor$4();
                }, {"r":6784484,"n":"","d":5735908,"h":0,"f":1048578}));
            }
            static /*TransactionStatePromotedCommitted */ get TransactionStatePromotedCommitted()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStatePromotedCommitted, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedCommitted, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedCommitted = $v, $.$stl.System.Transactions.TransactionStatePromotedCommitted), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStatePromotedCommitted))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromotedCommitted().$ctor$4();
                }, {"r":6981092,"n":"","d":5735908,"h":0,"f":1048578}));
            }
            static /*TransactionStatePromotedIndoubt */ get TransactionStatePromotedIndoubt()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStatePromotedIndoubt, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedIndoubt, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedIndoubt = $v, $.$stl.System.Transactions.TransactionStatePromotedIndoubt), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStatePromotedIndoubt))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromotedIndoubt().$ctor$4();
                }, {"r":7177700,"n":"","d":5735908,"h":0,"f":1048578}));
            }
            static /*TransactionStateDelegated */ get TransactionStateDelegated()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStateDelegated, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStateDelegated, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStateDelegated = $v, $.$stl.System.Transactions.TransactionStateDelegated), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStateDelegated))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStateDelegated().$ctor$5();
                }, {"r":5998052,"n":"","d":5735908,"h":0,"f":1048578}));
            }
            static /*TransactionStateDelegatedSubordinate */ get TransactionStateDelegatedSubordinate()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStateDelegatedSubordinate, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStateDelegatedSubordinate, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStateDelegatedSubordinate = $v, $.$stl.System.Transactions.TransactionStateDelegatedSubordinate), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStateDelegatedSubordinate))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStateDelegatedSubordinate().$ctor$5();
                }, {"r":6391268,"n":"","d":5735908,"h":0,"f":1048578}));
            }
            static /*TransactionStateDelegatedP0Wave */ get TransactionStateDelegatedP0Wave()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStateDelegatedP0Wave, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStateDelegatedP0Wave, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStateDelegatedP0Wave = $v, $.$stl.System.Transactions.TransactionStateDelegatedP0Wave), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStateDelegatedP0Wave))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStateDelegatedP0Wave().$ctor$4();
                }, {"r":6325732,"n":"","d":5735908,"h":0,"f":1048578}));
            }
            static /*TransactionStateDelegatedCommitting */ get TransactionStateDelegatedCommitting()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStateDelegatedCommitting, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStateDelegatedCommitting, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStateDelegatedCommitting = $v, $.$stl.System.Transactions.TransactionStateDelegatedCommitting), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStateDelegatedCommitting))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStateDelegatedCommitting().$ctor$4();
                }, {"r":6194660,"n":"","d":5735908,"h":0,"f":1048578}));
            }
            static /*TransactionStateDelegatedAborting */ get TransactionStateDelegatedAborting()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStateDelegatedAborting, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStateDelegatedAborting, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStateDelegatedAborting = $v, $.$stl.System.Transactions.TransactionStateDelegatedAborting), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStateDelegatedAborting))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStateDelegatedAborting().$ctor$5();
                }, {"r":6063588,"n":"","d":5735908,"h":0,"f":1048578}));
            }
            static /*TransactionStateDelegatedNonMSDTC */ get TransactionStateDelegatedNonMSDTC()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStateDelegatedNonMSDTC, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStateDelegatedNonMSDTC, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStateDelegatedNonMSDTC = $v, $.$stl.System.Transactions.TransactionStateDelegatedNonMSDTC), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStateDelegatedNonMSDTC))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStateDelegatedNonMSDTC().$ctor$3();
                }, {"r":6260196,"n":"","d":5735908,"h":0,"f":1048578}));
            }
            static /*TransactionStatePromotedNonMSDTCPhase0 */ get TransactionStatePromotedNonMSDTCPhase0()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStatePromotedNonMSDTCPhase0, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedNonMSDTCPhase0, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedNonMSDTCPhase0 = $v, $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCPhase0), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStatePromotedNonMSDTCPhase0))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCPhase0().$ctor$3();
                }, {"r":7570916,"n":"","d":5735908,"h":0,"f":1048578}));
            }
            static /*TransactionStatePromotedNonMSDTCVolatilePhase1 */ get TransactionStatePromotedNonMSDTCVolatilePhase1()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStatePromotedNonMSDTCVolatilePhase1, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedNonMSDTCVolatilePhase1, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedNonMSDTCVolatilePhase1 = $v, $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCVolatilePhase1), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStatePromotedNonMSDTCVolatilePhase1))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCVolatilePhase1().$ctor$3();
                }, {"r":7701988,"n":"","d":5735908,"h":0,"f":1048578}));
            }
            static /*TransactionStatePromotedNonMSDTCSinglePhaseCommit */ get TransactionStatePromotedNonMSDTCSinglePhaseCommit()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStatePromotedNonMSDTCSinglePhaseCommit, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedNonMSDTCSinglePhaseCommit, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedNonMSDTCSinglePhaseCommit = $v, $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCSinglePhaseCommit), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStatePromotedNonMSDTCSinglePhaseCommit))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCSinglePhaseCommit().$ctor$3();
                }, {"r":7636452,"n":"","d":5735908,"h":0,"f":1048578}));
            }
            static /*TransactionStatePromotedNonMSDTCAborted */ get TransactionStatePromotedNonMSDTCAborted()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStatePromotedNonMSDTCAborted, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedNonMSDTCAborted, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedNonMSDTCAborted = $v, $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCAborted), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStatePromotedNonMSDTCAborted))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCAborted().$ctor$4();
                }, {"r":7243236,"n":"","d":5735908,"h":0,"f":1048578}));
            }
            static /*TransactionStatePromotedNonMSDTCCommitted */ get TransactionStatePromotedNonMSDTCCommitted()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStatePromotedNonMSDTCCommitted, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedNonMSDTCCommitted, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedNonMSDTCCommitted = $v, $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCCommitted), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStatePromotedNonMSDTCCommitted))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCCommitted().$ctor$4();
                }, {"r":7374308,"n":"","d":5735908,"h":0,"f":1048578}));
            }
            static /*TransactionStatePromotedNonMSDTCIndoubt */ get TransactionStatePromotedNonMSDTCIndoubt()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionStatePromotedNonMSDTCIndoubt, $.$ref(() => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedNonMSDTCIndoubt, ($v) => $.$stl.System.Transactions.TransactionState.s_transactionStatePromotedNonMSDTCIndoubt = $v, $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCIndoubt), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionStatePromotedNonMSDTCIndoubt))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCIndoubt().$ctor$4();
                }, {"r":7505380,"n":"","d":5735908,"h":0,"f":1048578}));
            }
            /*void */ CommonEnterState(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(tx.State !== this, "Changing to the same state.");
                tx.State = this;
                $.$spc.System.Array.$WriteT1.call(tx._stateHistory, this, tx._currentStateHist);
                if (++tx._currentStateHist > 20/*InternalTransaction.MaxStateHist*/)
                {
                    tx._currentStateHist = 0;
                }
            }
            /*void */ BeginCommit(/*InternalTransaction*/ tx, /*bool*/ asyncCommit, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ EndCommit(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Fail(`Invalid Event for State; Current State: ${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))}`);
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*Enlistment */ EnlistDurable(/*InternalTransaction*/ tx, /*Guid*/ resourceManagerIdentifier, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*Enlistment */ EnlistDurable$1(/*InternalTransaction*/ tx, /*Guid*/ resourceManagerIdentifier, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*Enlistment */ EnlistVolatile(/*InternalTransaction*/ tx, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*Enlistment */ EnlistVolatile$1(/*InternalTransaction*/ tx, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ CheckForFinishedTransaction(/*InternalTransaction*/ tx)
            {
            }
            /*Guid */ get_Identifier(/*InternalTransaction*/ tx)
            {
                return $.$spc.System.Guid.Empty;
            }
            /*void */ AddOutcomeRegistrant(/*InternalTransaction*/ tx, /*TransactionCompletedEventHandler?*/ transactionCompletedDelegate)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ GetObjectData(/*InternalTransaction*/ tx, /*SerializationInfo*/ serializationInfo, /*StreamingContext*/ context)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*bool */ EnlistPromotableSinglePhase(/*InternalTransaction*/ tx, /*IPromotableSinglePhaseNotification*/ promotableSinglePhaseNotification, /*Transaction*/ atomicTransaction, /*Guid*/ promoterType)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ CompleteBlockingClone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ CompleteAbortingClone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ CreateBlockingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ CreateAbortingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ ChangeStateTransactionAborted(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                $.$spc.System.Diagnostics.Debug.Fail(`Invalid Event for State; Current State: ${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))}`);
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace$1(0/*TransactionExceptionType.InvalidOperationException*/, (tx?.TransactionTraceId.TransactionIdentifier ?? null) ?? $.$spc.System.String.Empty, $.$spc.System.Exception.ToString.call(e));
                }
                throw new $.$spc.System.InvalidOperationException().$ctor$9();
            }
            /*void */ ChangeStateTransactionCommitted(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Fail(`Invalid Event for State; Current State: ${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))}`);
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace$1(0/*TransactionExceptionType.InvalidOperationException*/, (tx?.TransactionTraceId.TransactionIdentifier ?? null) ?? $.$spc.System.String.Empty, $.$spc.System.String.Empty);
                }
                throw new $.$spc.System.InvalidOperationException().$ctor$9();
            }
            /*void */ InDoubtFromEnlistment(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Fail(`Invalid Event for State; Current State: ${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))}`);
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace$1(0/*TransactionExceptionType.InvalidOperationException*/, (tx?.TransactionTraceId.TransactionIdentifier ?? null) ?? $.$spc.System.String.Empty, $.$spc.System.String.Empty);
                }
                throw new $.$spc.System.InvalidOperationException().$ctor$9();
            }
            /*void */ ChangeStatePromotedAborted(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Fail(`Invalid Event for State; Current State: ${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))}`);
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace$1(0/*TransactionExceptionType.InvalidOperationException*/, (tx?.TransactionTraceId.TransactionIdentifier ?? null) ?? $.$spc.System.String.Empty, $.$spc.System.String.Empty);
                }
                throw new $.$spc.System.InvalidOperationException().$ctor$9();
            }
            /*void */ ChangeStatePromotedCommitted(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Fail(`Invalid Event for State; Current State: ${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))}`);
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace$1(0/*TransactionExceptionType.InvalidOperationException*/, (tx?.TransactionTraceId.TransactionIdentifier ?? null) ?? $.$spc.System.String.Empty, $.$spc.System.String.Empty);
                }
                throw new $.$spc.System.InvalidOperationException().$ctor$9();
            }
            /*void */ InDoubtFromDtc(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Fail(`Invalid Event for State; Current State: ${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))}`);
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace$1(0/*TransactionExceptionType.InvalidOperationException*/, (tx?.TransactionTraceId.TransactionIdentifier ?? null) ?? $.$spc.System.String.Empty, $.$spc.System.String.Empty);
                }
                throw new $.$spc.System.InvalidOperationException().$ctor$9();
            }
            /*void */ ChangeStatePromotedPhase0(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Fail(`Invalid Event for State; Current State: ${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))}`);
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace$1(0/*TransactionExceptionType.InvalidOperationException*/, (tx?.TransactionTraceId.TransactionIdentifier ?? null) ?? $.$spc.System.String.Empty, $.$spc.System.String.Empty);
                }
                throw new $.$spc.System.InvalidOperationException().$ctor$9();
            }
            /*void */ ChangeStatePromotedPhase1(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Fail(`Invalid Event for State; Current State: ${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))}`);
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace$1(0/*TransactionExceptionType.InvalidOperationException*/, (tx?.TransactionTraceId.TransactionIdentifier ?? null) ?? $.$spc.System.String.Empty, $.$spc.System.String.Empty);
                }
                throw new $.$spc.System.InvalidOperationException().$ctor$9();
            }
            /*void */ ChangeStateAbortedDuringPromotion(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Fail(`Invalid Event for State; Current State: ${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))}`);
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace$1(0/*TransactionExceptionType.InvalidOperationException*/, (tx?.TransactionTraceId.TransactionIdentifier ?? null) ?? $.$spc.System.String.Empty, $.$spc.System.String.Empty);
                }
                throw new $.$spc.System.InvalidOperationException().$ctor$9();
            }
            /*void */ Timeout(/*InternalTransaction*/ tx)
            {
            }
            /*void */ Phase0VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Fail(`Invalid Event for State; Current State: ${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))}`);
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ Phase1VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Fail(`Invalid Event for State; Current State: ${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))}`);
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ RestartCommitIfNeeded(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Fail(`Invalid Event for State; Current State: ${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this))}`);
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace$1(0/*TransactionExceptionType.InvalidOperationException*/, (tx?.TransactionTraceId.TransactionIdentifier ?? null) ?? $.$spc.System.String.Empty, $.$spc.System.String.Empty);
                }
                throw new $.$spc.System.InvalidOperationException().$ctor$9();
            }
            /*bool */ ContinuePhase0Prepares()
            {
                return false;
            }
            /*bool */ ContinuePhase1Prepares()
            {
                return false;
            }
            /*void */ Promote(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*byte[] */ PromotedToken(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*Enlistment */ PromoteAndEnlistDurable(/*InternalTransaction*/ tx, /*Guid*/ resourceManagerIdentifier, /*IPromotableSinglePhaseNotification*/ promotableNotification, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ SetDistributedTransactionId(/*InternalTransaction*/ tx, /*IPromotableSinglePhaseNotification*/ promotableNotification, /*Guid*/ distributedTransactionIdentifier)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ DisposeRoot(/*InternalTransaction*/ tx)
            {
            }
            /*bool */ IsCompleted(/*InternalTransaction*/ tx)
            {
                tx._needPulse = true;
                return false;
            }
            static /*void */ AddVolatileEnlistment(/*ref VolatileEnlistmentSet*/ enlistments, /*Enlistment*/ enlistment)
            {
                if (enlistments.$v._volatileEnlistmentCount === enlistments.$v._volatileEnlistmentSize)
                {
                    /*InternalEnlistment[]*/ let newEnlistments = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$stl.System.Transactions.InternalEnlistment), null, [((enlistments.$v._volatileEnlistmentSize + 8/*InternalTransaction.VolatileArrayIncrement*/) | 0)], null);
                    if (enlistments.$v._volatileEnlistmentSize > 0)
                    {
                        $.$spc.System.Array.Copy$1(enlistments.$v._volatileEnlistments, 0, newEnlistments, 0, enlistments.$v._volatileEnlistmentSize);
                    }
                    enlistments.$v._volatileEnlistmentSize += 8/*InternalTransaction.VolatileArrayIncrement*/;
                    enlistments.$v._volatileEnlistments = newEnlistments;
                }
                $.$spc.System.Array.$WriteT1.call(enlistments.$v._volatileEnlistments, enlistment.InternalEnlistment, enlistments.$v._volatileEnlistmentCount);
                enlistments.$v._volatileEnlistmentCount++;
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentActive.EnterState($.$spc.System.Array.$ReadT1.call(enlistments.$v._volatileEnlistments, ((enlistments.$v._volatileEnlistmentCount - 1) | 0)));
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 5735908;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":5866980,"g":{"r":0,"d":0,"h":154624558564,"f":40},"n":"TransactionStateActive","d":5735908,"h":150329591268,"f":40},{"p":8226276,"g":{"r":0,"d":0,"h":163214493156,"f":40},"n":"TransactionStateSubordinateActive","d":5735908,"h":158919525860,"f":40},{"p":8095204,"g":{"r":0,"d":0,"h":171804427748,"f":40},"n":"TransactionStatePSPEOperation","d":5735908,"h":167509460452,"f":40},{"p":6653412,"g":{"r":0,"d":0,"h":180394362340,"f":36},"n":"TransactionStatePhase0","d":5735908,"h":176099395044,"f":36},{"p":8291812,"g":{"r":0,"d":0,"h":188984296932,"f":36},"n":"TransactionStateVolatilePhase1","d":5735908,"h":184689329636,"f":36},{"p":8357348,"g":{"r":0,"d":0,"h":197574231524,"f":36},"n":"TransactionStateVolatileSPC","d":5735908,"h":193279264228,"f":36},{"p":8160740,"g":{"r":0,"d":0,"h":206164166116,"f":36},"n":"TransactionStateSPC","d":5735908,"h":201869198820,"f":36},{"p":5801444,"g":{"r":0,"d":0,"h":214754100708,"f":36},"n":"TransactionStateAborted","d":5735908,"h":210459133412,"f":36},{"p":5932516,"g":{"r":0,"d":0,"h":223344035300,"f":36},"n":"TransactionStateCommitted","d":5735908,"h":219049068004,"f":36},{"p":6522340,"g":{"r":0,"d":0,"h":231933969892,"f":36},"n":"TransactionStateInDoubt","d":5735908,"h":227639002596,"f":36},{"p":6718948,"g":{"r":0,"d":0,"h":240523904484,"f":40},"n":"TransactionStatePromoted","d":5735908,"h":236228937188,"f":40},{"p":6587876,"g":{"r":0,"d":0,"h":249113839076,"f":40},"n":"TransactionStateNonCommittablePromoted","d":5735908,"h":244818871780,"f":40},{"p":7833060,"g":{"r":0,"d":0,"h":257703773668,"f":36},"n":"TransactionStatePromotedP0Wave","d":5735908,"h":253408806372,"f":36},{"p":7046628,"g":{"r":0,"d":0,"h":266293708260,"f":36},"n":"TransactionStatePromotedCommitting","d":5735908,"h":261998740964,"f":36},{"p":7964132,"g":{"r":0,"d":0,"h":274883642852,"f":36},"n":"TransactionStatePromotedPhase0","d":5735908,"h":270588675556,"f":36},{"p":8029668,"g":{"r":0,"d":0,"h":283473577444,"f":36},"n":"TransactionStatePromotedPhase1","d":5735908,"h":279178610148,"f":36},{"p":7767524,"g":{"r":0,"d":0,"h":292063512036,"f":36},"n":"TransactionStatePromotedP0Aborting","d":5735908,"h":287768544740,"f":36},{"p":7898596,"g":{"r":0,"d":0,"h":300653446628,"f":36},"n":"TransactionStatePromotedP1Aborting","d":5735908,"h":296358479332,"f":36},{"p":6784484,"g":{"r":0,"d":0,"h":309243381220,"f":36},"n":"TransactionStatePromotedAborted","d":5735908,"h":304948413924,"f":36},{"p":6981092,"g":{"r":0,"d":0,"h":317833315812,"f":36},"n":"TransactionStatePromotedCommitted","d":5735908,"h":313538348516,"f":36},{"p":7177700,"g":{"r":0,"d":0,"h":326423250404,"f":36},"n":"TransactionStatePromotedIndoubt","d":5735908,"h":322128283108,"f":36},{"p":5998052,"g":{"r":0,"d":0,"h":335013184996,"f":36},"n":"TransactionStateDelegated","d":5735908,"h":330718217700,"f":36},{"p":6391268,"g":{"r":0,"d":0,"h":343603119588,"f":40},"n":"TransactionStateDelegatedSubordinate","d":5735908,"h":339308152292,"f":40},{"p":6325732,"g":{"r":0,"d":0,"h":352193054180,"f":36},"n":"TransactionStateDelegatedP0Wave","d":5735908,"h":347898086884,"f":36},{"p":6194660,"g":{"r":0,"d":0,"h":360782988772,"f":36},"n":"TransactionStateDelegatedCommitting","d":5735908,"h":356488021476,"f":36},{"p":6063588,"g":{"r":0,"d":0,"h":369372923364,"f":36},"n":"TransactionStateDelegatedAborting","d":5735908,"h":365077956068,"f":36},{"p":6260196,"g":{"r":0,"d":0,"h":377962857956,"f":36},"n":"TransactionStateDelegatedNonMSDTC","d":5735908,"h":373667890660,"f":36},{"p":7570916,"g":{"r":0,"d":0,"h":386552792548,"f":36},"n":"TransactionStatePromotedNonMSDTCPhase0","d":5735908,"h":382257825252,"f":36},{"p":7701988,"g":{"r":0,"d":0,"h":395142727140,"f":36},"n":"TransactionStatePromotedNonMSDTCVolatilePhase1","d":5735908,"h":390847759844,"f":36},{"p":7636452,"g":{"r":0,"d":0,"h":403732661732,"f":36},"n":"TransactionStatePromotedNonMSDTCSinglePhaseCommit","d":5735908,"h":399437694436,"f":36},{"p":7243236,"g":{"r":0,"d":0,"h":412322596324,"f":36},"n":"TransactionStatePromotedNonMSDTCAborted","d":5735908,"h":408027629028,"f":36},{"p":7374308,"g":{"r":0,"d":0,"h":420912530916,"f":36},"n":"TransactionStatePromotedNonMSDTCCommitted","d":5735908,"h":416617563620,"f":36},{"p":7505380,"g":{"r":0,"d":0,"h":429502465508,"f":36},"n":"TransactionStatePromotedNonMSDTCIndoubt","d":5735908,"h":425207498212,"f":36}],"m":[{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"CommonEnterState","d":5735908,"h":433797432804,"f":8},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"EnterState","d":5735908,"h":438092400100,"f":264},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"asyncCommit","p":262145},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":5735908,"h":442387367396,"f":136},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"EndCommit","d":5735908,"h":446682334692,"f":136},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"e","p":47251457}],"n":"Rollback","d":5735908,"h":450977301988,"f":136},{"r":1738212,"p":[{"n":"tx","p":2786788},{"n":"resourceManagerIdentifier","p":56229889},{"n":"enlistmentNotification","p":2590180},{"n":"enlistmentOptions","p":1869284},{"n":"atomicTransaction","p":4294116}],"n":"EnlistDurable","d":5735908,"h":455272269284,"f":136},{"r":1738212,"p":[{"n":"tx","p":2786788},{"n":"resourceManagerIdentifier","p":56229889},{"n":"enlistmentNotification","p":3048932},{"n":"enlistmentOptions","p":1869284},{"n":"atomicTransaction","p":4294116}],"n":"EnlistDurable","o":"@$1","d":5735908,"h":459567236580,"f":136},{"r":1738212,"p":[{"n":"tx","p":2786788},{"n":"enlistmentNotification","p":2590180},{"n":"enlistmentOptions","p":1869284},{"n":"atomicTransaction","p":4294116}],"n":"EnlistVolatile","d":5735908,"h":463862203876,"f":136},{"r":1738212,"p":[{"n":"tx","p":2786788},{"n":"enlistmentNotification","p":3048932},{"n":"enlistmentOptions","p":1869284},{"n":"atomicTransaction","p":4294116}],"n":"EnlistVolatile","o":"@$1","d":5735908,"h":468157171172,"f":136},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"CheckForFinishedTransaction","d":5735908,"h":472452138468,"f":136},{"r":56229889,"p":[{"n":"tx","p":2786788}],"n":"get_Identifier","d":5735908,"h":476747105764,"f":136},{"r":8422884,"p":[{"n":"tx","p":2786788}],"n":"get_Status","d":5735908,"h":481042073060,"f":264},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"transactionCompletedDelegate","p":4425188}],"n":"AddOutcomeRegistrant","d":5735908,"h":485337040356,"f":136},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"serializationInfo","p":113967105},{"n":"context","p":114098177}],"n":"GetObjectData","d":5735908,"h":489632007652,"f":136},{"r":262145,"p":[{"n":"tx","p":2786788},{"n":"promotableSinglePhaseNotification","p":2852324},{"n":"atomicTransaction","p":4294116},{"n":"promoterType","p":56229889}],"n":"EnlistPromotableSinglePhase","d":5735908,"h":493926974948,"f":136},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"CompleteBlockingClone","d":5735908,"h":498221942244,"f":136},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"CompleteAbortingClone","d":5735908,"h":502516909540,"f":136},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"CreateBlockingClone","d":5735908,"h":506811876836,"f":136},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"CreateAbortingClone","d":5735908,"h":511106844132,"f":136},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"e","p":47251457}],"n":"ChangeStateTransactionAborted","d":5735908,"h":515401811428,"f":136},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"ChangeStateTransactionCommitted","d":5735908,"h":519696778724,"f":136},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"InDoubtFromEnlistment","d":5735908,"h":523991746020,"f":136},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"ChangeStatePromotedAborted","d":5735908,"h":528286713316,"f":136},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"ChangeStatePromotedCommitted","d":5735908,"h":532581680612,"f":136},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"InDoubtFromDtc","d":5735908,"h":536876647908,"f":136},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"ChangeStatePromotedPhase0","d":5735908,"h":541171615204,"f":136},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"ChangeStatePromotedPhase1","d":5735908,"h":545466582500,"f":136},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"ChangeStateAbortedDuringPromotion","d":5735908,"h":549761549796,"f":136},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"Timeout","d":5735908,"h":554056517092,"f":136},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"Phase0VolatilePrepareDone","d":5735908,"h":558351484388,"f":136},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"Phase1VolatilePrepareDone","d":5735908,"h":562646451684,"f":136},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"RestartCommitIfNeeded","d":5735908,"h":566941418980,"f":136},{"r":262145,"n":"ContinuePhase0Prepares","d":5735908,"h":571236386276,"f":136},{"r":262145,"n":"ContinuePhase1Prepares","d":5735908,"h":575531353572,"f":136},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"Promote","d":5735908,"h":579826320868,"f":136},{"r":0,"p":[{"n":"tx","p":2786788}],"n":"PromotedToken","d":5735908,"h":584121288164,"f":136},{"r":1738212,"p":[{"n":"tx","p":2786788},{"n":"resourceManagerIdentifier","p":56229889},{"n":"promotableNotification","p":2852324},{"n":"enlistmentNotification","p":3048932},{"n":"enlistmentOptions","p":1869284},{"n":"atomicTransaction","p":4294116}],"n":"PromoteAndEnlistDurable","d":5735908,"h":588416255460,"f":136},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"promotableNotification","p":2852324},{"n":"distributedTransactionIdentifier","p":56229889}],"n":"SetDistributedTransactionId","d":5735908,"h":592711222756,"f":136},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"DisposeRoot","d":5735908,"h":597006190052,"f":136},{"r":262145,"p":[{"n":"tx","p":2786788}],"n":"IsCompleted","d":5735908,"h":601301157348,"f":136},{"r":65537,"p":[{"n":"enlistments","p":9340388,"f":4},{"n":"enlistment","p":1738212}],"n":"AddVolatileEnlistment","d":5735908,"h":605596124644,"f":36}],"l":[{"t":5866980,"n":"s_transactionStateActive","d":5735908,"h":4300703204,"f":34},{"t":8226276,"n":"s_transactionStateSubordinateActive","d":5735908,"h":8595670500,"f":34},{"t":6653412,"n":"s_transactionStatePhase0","d":5735908,"h":12890637796,"f":34},{"t":8291812,"n":"s_transactionStateVolatilePhase1","d":5735908,"h":17185605092,"f":34},{"t":8357348,"n":"s_transactionStateVolatileSPC","d":5735908,"h":21480572388,"f":34},{"t":8160740,"n":"s_transactionStateSPC","d":5735908,"h":25775539684,"f":34},{"t":5801444,"n":"s_transactionStateAborted","d":5735908,"h":30070506980,"f":34},{"t":5932516,"n":"s_transactionStateCommitted","d":5735908,"h":34365474276,"f":34},{"t":6522340,"n":"s_transactionStateInDoubt","d":5735908,"h":38660441572,"f":34},{"t":6718948,"n":"s_transactionStatePromoted","d":5735908,"h":42955408868,"f":34},{"t":6587876,"n":"s_transactionStateNonCommittablePromoted","d":5735908,"h":47250376164,"f":34},{"t":7833060,"n":"s_transactionStatePromotedP0Wave","d":5735908,"h":51545343460,"f":34},{"t":7046628,"n":"s_transactionStatePromotedCommitting","d":5735908,"h":55840310756,"f":34},{"t":7964132,"n":"s_transactionStatePromotedPhase0","d":5735908,"h":60135278052,"f":34},{"t":8029668,"n":"s_transactionStatePromotedPhase1","d":5735908,"h":64430245348,"f":34},{"t":7767524,"n":"s_transactionStatePromotedP0Aborting","d":5735908,"h":68725212644,"f":34},{"t":7898596,"n":"s_transactionStatePromotedP1Aborting","d":5735908,"h":73020179940,"f":34},{"t":6784484,"n":"s_transactionStatePromotedAborted","d":5735908,"h":77315147236,"f":34},{"t":6981092,"n":"s_transactionStatePromotedCommitted","d":5735908,"h":81610114532,"f":34},{"t":7177700,"n":"s_transactionStatePromotedIndoubt","d":5735908,"h":85905081828,"f":34},{"t":5998052,"n":"s_transactionStateDelegated","d":5735908,"h":90200049124,"f":34},{"t":6391268,"n":"s_transactionStateDelegatedSubordinate","d":5735908,"h":94495016420,"f":34},{"t":6325732,"n":"s_transactionStateDelegatedP0Wave","d":5735908,"h":98789983716,"f":34},{"t":6194660,"n":"s_transactionStateDelegatedCommitting","d":5735908,"h":103084951012,"f":34},{"t":6063588,"n":"s_transactionStateDelegatedAborting","d":5735908,"h":107379918308,"f":34},{"t":8095204,"n":"s_transactionStatePSPEOperation","d":5735908,"h":111674885604,"f":34},{"t":6260196,"n":"s_transactionStateDelegatedNonMSDTC","d":5735908,"h":115969852900,"f":34},{"t":7570916,"n":"s_transactionStatePromotedNonMSDTCPhase0","d":5735908,"h":120264820196,"f":34},{"t":7701988,"n":"s_transactionStatePromotedNonMSDTCVolatilePhase1","d":5735908,"h":124559787492,"f":34},{"t":7636452,"n":"s_transactionStatePromotedNonMSDTCSinglePhaseCommit","d":5735908,"h":128854754788,"f":34},{"t":7243236,"n":"s_transactionStatePromotedNonMSDTCAborted","d":5735908,"h":133149722084,"f":34},{"t":7374308,"n":"s_transactionStatePromotedNonMSDTCCommitted","d":5735908,"h":137444689380,"f":34},{"t":7505380,"n":"s_transactionStatePromotedNonMSDTCIndoubt","d":5735908,"h":141739656676,"f":34},{"t":131073,"n":"s_classSyncObject","d":5735908,"h":146034623972,"f":40}],"c":[{"n":".ctor","o":"$ctor$1","d":5735908,"h":609891091940,"f":4}],"h":5735908}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Transactions.TransactionState`; }
        });
        
        $asm.$cls("$stl.System.Transactions.VolatileDemultiplexer", ($self) => class VolatileDemultiplexer extends $.$spc.System.Object
        {
            /*InternalTransaction*/ _transaction = null;
            /*IPromotedEnlistment?*/ _promotedEnlistment = null;
            /*IPromotedEnlistment?*/ _preparingEnlistment = null;
            $ctor$1(/*InternalTransaction*/ transaction)
            {
                super.$ctor();
                {
                    this._transaction = transaction;
                }
                return this;
            }
            static /*void */ BroadcastCommitted(/*ref VolatileEnlistmentSet*/ volatiles)
            {
                for(/*int*/ let i = 0; i < volatiles.$v._volatileEnlistmentCount; i++)
                {
                    $.$spc.System.Array.$ReadT1.call(volatiles.$v._volatileEnlistments, i)._twoPhaseState.InternalCommitted($.$spc.System.Array.$ReadT1.call(volatiles.$v._volatileEnlistments, i));
                }
            }
            static /*void */ BroadcastRollback(/*ref VolatileEnlistmentSet*/ volatiles)
            {
                for(/*int*/ let i = 0; i < volatiles.$v._volatileEnlistmentCount; i++)
                {
                    $.$spc.System.Array.$ReadT1.call(volatiles.$v._volatileEnlistments, i)._twoPhaseState.InternalAborted($.$spc.System.Array.$ReadT1.call(volatiles.$v._volatileEnlistments, i));
                }
            }
            static /*void */ BroadcastInDoubt(/*ref VolatileEnlistmentSet*/ volatiles)
            {
                for(/*int*/ let i = 0; i < volatiles.$v._volatileEnlistmentCount; i++)
                {
                    $.$spc.System.Array.$ReadT1.call(volatiles.$v._volatileEnlistments, i)._twoPhaseState.InternalIndoubt($.$spc.System.Array.$ReadT1.call(volatiles.$v._volatileEnlistments, i));
                }
            }
            /*object?*/ static s_classSyncObject = null;
            static /*object */ get ClassSyncObject()
            {
                if ($.$stl.System.Transactions.VolatileDemultiplexer.s_classSyncObject === null)
                {
                    /*object*/ let o = new $.$spc.System.Object().$ctor();
                    $.$spc.System.Threading.Interlocked.CompareExchange$2($.$ref(() => $.$stl.System.Transactions.VolatileDemultiplexer.s_classSyncObject, ($v) => $.$stl.System.Transactions.VolatileDemultiplexer.s_classSyncObject = $v, $.$spc.System.Object), o, null);
                }
                return $.$stl.System.Transactions.VolatileDemultiplexer.s_classSyncObject;
            }
            /*WaitCallback?*/ static s_prepareCallback = null;
            static /*WaitCallback */ get PrepareCallback()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$spc.System.Threading.WaitCallback, $.$ref(() => $.$stl.System.Transactions.VolatileDemultiplexer.s_prepareCallback, ($v) => $.$stl.System.Transactions.VolatileDemultiplexer.s_prepareCallback = $v, $.$spc.System.Threading.WaitCallback), $.$ref(() => $.$stl.System.Transactions.VolatileDemultiplexer.s_classSyncObject, ($v) => $.$stl.System.Transactions.VolatileDemultiplexer.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$spc.System.Threading.WaitCallback))().$ctor(this,  () =>
                {
                    return new $.$spc.System.Threading.WaitCallback().$ctor($.$stl.System.Transactions.VolatileDemultiplexer, $.$stl.System.Transactions.VolatileDemultiplexer.PoolablePrepare);
                }, {"r":139067393,"n":"","d":8685028,"h":0,"f":1048578}));
            }
            static /*void */ PoolablePrepare(/*object*/ state)
            {
                /*VolatileDemultiplexer*/ let demux = $.$cast(state, $.$stl.System.Transactions.VolatileDemultiplexer);
                /*bool*/ let tookLock = false;
                try
                {
                    $.$spc.System.Threading.Monitor.TryEnter$3(demux._transaction, 250, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Boolean, () => tookLock, ($v) => tookLock = $v, null));
                    if (tookLock)
                    {
                        demux.InternalPrepare();
                    }
                    else 
                    {
                        if (!$.$spc.System.Threading.ThreadPool.QueueUserWorkItem$1($.$stl.System.Transactions.VolatileDemultiplexer.PrepareCallback, demux))
                        {
                            throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.UnexpectedFailureOfThreadPool, null);
                        }
                    }
                }
                finally
                {
                    {
                        if (tookLock)
                        {
                            $.$spc.System.Threading.Monitor.Exit(demux._transaction);
                        }
                    }
                }
            }
            /*WaitCallback?*/ static s_commitCallback = null;
            static /*WaitCallback */ get CommitCallback()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$spc.System.Threading.WaitCallback, $.$ref(() => $.$stl.System.Transactions.VolatileDemultiplexer.s_commitCallback, ($v) => $.$stl.System.Transactions.VolatileDemultiplexer.s_commitCallback = $v, $.$spc.System.Threading.WaitCallback), $.$ref(() => $.$stl.System.Transactions.VolatileDemultiplexer.s_classSyncObject, ($v) => $.$stl.System.Transactions.VolatileDemultiplexer.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$spc.System.Threading.WaitCallback))().$ctor(this,  () =>
                {
                    return new $.$spc.System.Threading.WaitCallback().$ctor($.$stl.System.Transactions.VolatileDemultiplexer, $.$stl.System.Transactions.VolatileDemultiplexer.PoolableCommit);
                }, {"r":139067393,"n":"","d":8685028,"h":0,"f":1048578}));
            }
            static /*void */ PoolableCommit(/*object*/ state)
            {
                /*VolatileDemultiplexer*/ let demux = $.$cast(state, $.$stl.System.Transactions.VolatileDemultiplexer);
                /*bool*/ let tookLock = false;
                try
                {
                    $.$spc.System.Threading.Monitor.TryEnter$3(demux._transaction, 250, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Boolean, () => tookLock, ($v) => tookLock = $v, null));
                    if (tookLock)
                    {
                        demux.InternalCommit();
                    }
                    else 
                    {
                        if (!$.$spc.System.Threading.ThreadPool.QueueUserWorkItem$1($.$stl.System.Transactions.VolatileDemultiplexer.CommitCallback, demux))
                        {
                            throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.UnexpectedFailureOfThreadPool, null);
                        }
                    }
                }
                finally
                {
                    {
                        if (tookLock)
                        {
                            $.$spc.System.Threading.Monitor.Exit(demux._transaction);
                        }
                    }
                }
            }
            /*WaitCallback?*/ static s_rollbackCallback = null;
            static /*WaitCallback */ get RollbackCallback()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$spc.System.Threading.WaitCallback, $.$ref(() => $.$stl.System.Transactions.VolatileDemultiplexer.s_rollbackCallback, ($v) => $.$stl.System.Transactions.VolatileDemultiplexer.s_rollbackCallback = $v, $.$spc.System.Threading.WaitCallback), $.$ref(() => $.$stl.System.Transactions.VolatileDemultiplexer.s_classSyncObject, ($v) => $.$stl.System.Transactions.VolatileDemultiplexer.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$spc.System.Threading.WaitCallback))().$ctor(this,  () =>
                {
                    return new $.$spc.System.Threading.WaitCallback().$ctor($.$stl.System.Transactions.VolatileDemultiplexer, $.$stl.System.Transactions.VolatileDemultiplexer.PoolableRollback);
                }, {"r":139067393,"n":"","d":8685028,"h":0,"f":1048578}));
            }
            static /*void */ PoolableRollback(/*object*/ state)
            {
                /*VolatileDemultiplexer*/ let demux = $.$cast(state, $.$stl.System.Transactions.VolatileDemultiplexer);
                /*bool*/ let tookLock = false;
                try
                {
                    $.$spc.System.Threading.Monitor.TryEnter$3(demux._transaction, 250, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Boolean, () => tookLock, ($v) => tookLock = $v, null));
                    if (tookLock)
                    {
                        demux.InternalRollback();
                    }
                    else 
                    {
                        if (!$.$spc.System.Threading.ThreadPool.QueueUserWorkItem$1($.$stl.System.Transactions.VolatileDemultiplexer.RollbackCallback, demux))
                        {
                            throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.UnexpectedFailureOfThreadPool, null);
                        }
                    }
                }
                finally
                {
                    {
                        if (tookLock)
                        {
                            $.$spc.System.Threading.Monitor.Exit(demux._transaction);
                        }
                    }
                }
            }
            /*WaitCallback?*/ static s_inDoubtCallback = null;
            static /*WaitCallback */ get InDoubtCallback()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$spc.System.Threading.WaitCallback, $.$ref(() => $.$stl.System.Transactions.VolatileDemultiplexer.s_inDoubtCallback, ($v) => $.$stl.System.Transactions.VolatileDemultiplexer.s_inDoubtCallback = $v, $.$spc.System.Threading.WaitCallback), $.$ref(() => $.$stl.System.Transactions.VolatileDemultiplexer.s_classSyncObject, ($v) => $.$stl.System.Transactions.VolatileDemultiplexer.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$spc.System.Threading.WaitCallback))().$ctor(this,  () =>
                {
                    return new $.$spc.System.Threading.WaitCallback().$ctor($.$stl.System.Transactions.VolatileDemultiplexer, $.$stl.System.Transactions.VolatileDemultiplexer.PoolableInDoubt);
                }, {"r":139067393,"n":"","d":8685028,"h":0,"f":1048578}));
            }
            static /*void */ PoolableInDoubt(/*object*/ state)
            {
                /*VolatileDemultiplexer*/ let demux = $.$cast(state, $.$stl.System.Transactions.VolatileDemultiplexer);
                /*bool*/ let tookLock = false;
                try
                {
                    $.$spc.System.Threading.Monitor.TryEnter$3(demux._transaction, 250, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Boolean, () => tookLock, ($v) => tookLock = $v, null));
                    if (tookLock)
                    {
                        demux.InternalInDoubt();
                    }
                    else 
                    {
                        if (!$.$spc.System.Threading.ThreadPool.QueueUserWorkItem$1($.$stl.System.Transactions.VolatileDemultiplexer.InDoubtCallback, demux))
                        {
                            throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.UnexpectedFailureOfThreadPool, null);
                        }
                    }
                }
                finally
                {
                    {
                        if (tookLock)
                        {
                            $.$spc.System.Threading.Monitor.Exit(demux._transaction);
                        }
                    }
                }
            }
            //Generated interface implemetation for System.Transactions.IEnlistmentNotificationInternal.Prepare(System.Transactions.IPromotedEnlistment)
            System$Transactions$IEnlistmentNotificationInternal$Prepare()
            {
                return this.Prepare(...arguments);
            }
            //Generated interface implemetation for System.Transactions.IEnlistmentNotificationInternal.Commit(System.Transactions.IPromotedEnlistment)
            System$Transactions$IEnlistmentNotificationInternal$Commit()
            {
                return this.Commit(...arguments);
            }
            //Generated interface implemetation for System.Transactions.IEnlistmentNotificationInternal.Rollback(System.Transactions.IPromotedEnlistment)
            System$Transactions$IEnlistmentNotificationInternal$Rollback()
            {
                return this.Rollback(...arguments);
            }
            //Generated interface implemetation for System.Transactions.IEnlistmentNotificationInternal.InDoubt(System.Transactions.IPromotedEnlistment)
            System$Transactions$IEnlistmentNotificationInternal$InDoubt()
            {
                return this.InDoubt(...arguments);
            }
            static $h = 8685028;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":131073,"g":{"r":0,"d":0,"h":42958357988,"f":40},"n":"ClassSyncObject","d":8685028,"h":38663390692,"f":40},{"p":139067393,"g":{"r":0,"d":0,"h":55843259876,"f":34},"n":"PrepareCallback","d":8685028,"h":51548292580,"f":34},{"p":139067393,"g":{"r":0,"d":0,"h":73023129060,"f":34},"n":"CommitCallback","d":8685028,"h":68728161764,"f":34},{"p":139067393,"g":{"r":0,"d":0,"h":90202998244,"f":34},"n":"RollbackCallback","d":8685028,"h":85908030948,"f":34},{"p":139067393,"g":{"r":0,"d":0,"h":107382867428,"f":34},"n":"InDoubtCallback","d":8685028,"h":103087900132,"f":34}],"m":[{"r":65537,"p":[{"n":"volatiles","p":9340388,"f":4}],"n":"BroadcastCommitted","d":8685028,"h":21483521508,"f":40},{"r":65537,"p":[{"n":"volatiles","p":9340388,"f":4}],"n":"BroadcastRollback","d":8685028,"h":25778488804,"f":40},{"r":65537,"p":[{"n":"volatiles","p":9340388,"f":4}],"n":"BroadcastInDoubt","d":8685028,"h":30073456100,"f":40},{"r":65537,"p":[{"n":"state","p":131073}],"n":"PoolablePrepare","d":8685028,"h":60138227172,"f":36},{"r":65537,"p":[{"n":"state","p":131073}],"n":"PoolableCommit","d":8685028,"h":77318096356,"f":36},{"r":65537,"p":[{"n":"state","p":131073}],"n":"PoolableRollback","d":8685028,"h":94497965540,"f":36},{"r":65537,"p":[{"n":"state","p":131073}],"n":"PoolableInDoubt","d":8685028,"h":111677834724,"f":36},{"r":65537,"n":"InternalPrepare","d":8685028,"h":115972802020,"f":260},{"r":65537,"n":"InternalCommit","d":8685028,"h":120267769316,"f":260},{"r":65537,"n":"InternalRollback","d":8685028,"h":124562736612,"f":260},{"r":65537,"n":"InternalInDoubt","d":8685028,"h":128857703908,"f":260},{"r":65537,"p":[{"n":"en","p":2917860}],"n":"Prepare","d":8685028,"h":133152671204,"f":257},{"r":65537,"p":[{"n":"en","p":2917860}],"n":"Commit","d":8685028,"h":137447638500,"f":257},{"r":65537,"p":[{"n":"en","p":2917860}],"n":"Rollback","d":8685028,"h":141742605796,"f":257},{"r":65537,"p":[{"n":"en","p":2917860}],"n":"InDoubt","d":8685028,"h":146037573092,"f":257}],"l":[{"t":2786788,"n":"_transaction","d":8685028,"h":4303652324,"f":4},{"t":2917860,"n":"_promotedEnlistment","d":8685028,"h":8598619620,"f":8},{"t":2917860,"n":"_preparingEnlistment","d":8685028,"h":12893586916,"f":8},{"t":131073,"n":"s_classSyncObject","d":8685028,"h":34368423396,"f":34},{"t":139067393,"n":"s_prepareCallback","d":8685028,"h":47253325284,"f":34},{"t":139067393,"n":"s_commitCallback","d":8685028,"h":64433194468,"f":34},{"t":139067393,"n":"s_rollbackCallback","d":8685028,"h":81613063652,"f":34},{"t":139067393,"n":"s_inDoubtCallback","d":8685028,"h":98792932836,"f":34}],"c":[{"p":[{"n":"transaction","p":2786788}],"n":".ctor","o":"$ctor$1","d":8685028,"h":17188554212,"f":1}],"i":[2655716],"h":8685028}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stl.System.Transactions.IEnlistmentNotificationInternal ]; }
            static get $fullName() { return `System.Transactions.VolatileDemultiplexer`; }
        });
        
        $asm.$cls("$stl.System.Transactions.DurableEnlistmentState", ($self) => class DurableEnlistmentState extends $.$stl.System.Transactions.EnlistmentState
        {
            /*DurableEnlistmentActive?*/ static s_durableEnlistmentActive = null;
            /*DurableEnlistmentAborting?*/ static s_durableEnlistmentAborting = null;
            /*DurableEnlistmentCommitting?*/ static s_durableEnlistmentCommitting = null;
            /*DurableEnlistmentDelegated?*/ static s_durableEnlistmentDelegated = null;
            /*DurableEnlistmentEnded?*/ static s_durableEnlistmentEnded = null;
            /*object?*/ static s_classSyncObject = null;
            static /*DurableEnlistmentActive */ get DurableEnlistmentActive()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.DurableEnlistmentActive, $.$ref(() => $.$stl.System.Transactions.DurableEnlistmentState.s_durableEnlistmentActive, ($v) => $.$stl.System.Transactions.DurableEnlistmentState.s_durableEnlistmentActive = $v, $.$stl.System.Transactions.DurableEnlistmentActive), $.$ref(() => $.$stl.System.Transactions.DurableEnlistmentState.s_classSyncObject, ($v) => $.$stl.System.Transactions.DurableEnlistmentState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.DurableEnlistmentActive))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.DurableEnlistmentActive().$ctor$3();
                }, {"r":1279460,"n":"","d":1541604,"h":0,"f":1048578}));
            }
            static /*DurableEnlistmentAborting */ get DurableEnlistmentAborting()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.DurableEnlistmentAborting, $.$ref(() => $.$stl.System.Transactions.DurableEnlistmentState.s_durableEnlistmentAborting, ($v) => $.$stl.System.Transactions.DurableEnlistmentState.s_durableEnlistmentAborting = $v, $.$stl.System.Transactions.DurableEnlistmentAborting), $.$ref(() => $.$stl.System.Transactions.DurableEnlistmentState.s_classSyncObject, ($v) => $.$stl.System.Transactions.DurableEnlistmentState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.DurableEnlistmentAborting))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.DurableEnlistmentAborting().$ctor$3();
                }, {"r":1213924,"n":"","d":1541604,"h":0,"f":1048578}));
            }
            static /*DurableEnlistmentCommitting */ get DurableEnlistmentCommitting()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.DurableEnlistmentCommitting, $.$ref(() => $.$stl.System.Transactions.DurableEnlistmentState.s_durableEnlistmentCommitting, ($v) => $.$stl.System.Transactions.DurableEnlistmentState.s_durableEnlistmentCommitting = $v, $.$stl.System.Transactions.DurableEnlistmentCommitting), $.$ref(() => $.$stl.System.Transactions.DurableEnlistmentState.s_classSyncObject, ($v) => $.$stl.System.Transactions.DurableEnlistmentState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.DurableEnlistmentCommitting))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.DurableEnlistmentCommitting().$ctor$3();
                }, {"r":1344996,"n":"","d":1541604,"h":0,"f":1048578}));
            }
            static /*DurableEnlistmentDelegated */ get DurableEnlistmentDelegated()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.DurableEnlistmentDelegated, $.$ref(() => $.$stl.System.Transactions.DurableEnlistmentState.s_durableEnlistmentDelegated, ($v) => $.$stl.System.Transactions.DurableEnlistmentState.s_durableEnlistmentDelegated = $v, $.$stl.System.Transactions.DurableEnlistmentDelegated), $.$ref(() => $.$stl.System.Transactions.DurableEnlistmentState.s_classSyncObject, ($v) => $.$stl.System.Transactions.DurableEnlistmentState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.DurableEnlistmentDelegated))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.DurableEnlistmentDelegated().$ctor$3();
                }, {"r":1410532,"n":"","d":1541604,"h":0,"f":1048578}));
            }
            static /*DurableEnlistmentEnded */ get DurableEnlistmentEnded()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.DurableEnlistmentEnded, $.$ref(() => $.$stl.System.Transactions.DurableEnlistmentState.s_durableEnlistmentEnded, ($v) => $.$stl.System.Transactions.DurableEnlistmentState.s_durableEnlistmentEnded = $v, $.$stl.System.Transactions.DurableEnlistmentEnded), $.$ref(() => $.$stl.System.Transactions.DurableEnlistmentState.s_classSyncObject, ($v) => $.$stl.System.Transactions.DurableEnlistmentState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.DurableEnlistmentEnded))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.DurableEnlistmentEnded().$ctor$3();
                }, {"r":1476068,"n":"","d":1541604,"h":0,"f":1048578}));
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 1541604;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1934820,"p":[{"p":1279460,"g":{"r":0,"d":0,"h":34361279972,"f":40},"n":"DurableEnlistmentActive","d":1541604,"h":30066312676,"f":40},{"p":1213924,"g":{"r":0,"d":0,"h":42951214564,"f":36},"n":"DurableEnlistmentAborting","d":1541604,"h":38656247268,"f":36},{"p":1344996,"g":{"r":0,"d":0,"h":51541149156,"f":36},"n":"DurableEnlistmentCommitting","d":1541604,"h":47246181860,"f":36},{"p":1410532,"g":{"r":0,"d":0,"h":60131083748,"f":36},"n":"DurableEnlistmentDelegated","d":1541604,"h":55836116452,"f":36},{"p":1476068,"g":{"r":0,"d":0,"h":68721018340,"f":36},"n":"DurableEnlistmentEnded","d":1541604,"h":64426051044,"f":36}],"l":[{"t":1279460,"n":"s_durableEnlistmentActive","d":1541604,"h":4296508900,"f":34},{"t":1213924,"n":"s_durableEnlistmentAborting","d":1541604,"h":8591476196,"f":34},{"t":1344996,"n":"s_durableEnlistmentCommitting","d":1541604,"h":12886443492,"f":34},{"t":1410532,"n":"s_durableEnlistmentDelegated","d":1541604,"h":17181410788,"f":34},{"t":1476068,"n":"s_durableEnlistmentEnded","d":1541604,"h":21476378084,"f":34},{"t":131073,"n":"s_classSyncObject","d":1541604,"h":25771345380,"f":34}],"c":[{"n":".ctor","o":"$ctor$2","d":1541604,"h":73015985636,"f":4}],"h":1541604}; }
            static get $b() { return $.$stl.System.Transactions.EnlistmentState; }
            static get $fullName() { return `System.Transactions.DurableEnlistmentState`; }
        });
        
        $asm.$cls("$stl.System.Transactions.VolatileEnlistmentState", ($self) => class VolatileEnlistmentState extends $.$stl.System.Transactions.EnlistmentState
        {
            /*VolatileEnlistmentActive?*/ static s_volatileEnlistmentActive = null;
            /*VolatileEnlistmentPreparing?*/ static s_volatileEnlistmentPreparing = null;
            /*VolatileEnlistmentPrepared?*/ static s_volatileEnlistmentPrepared = null;
            /*VolatileEnlistmentSPC?*/ static s_volatileEnlistmentSPC = null;
            /*VolatileEnlistmentPreparingAborting?*/ static s_volatileEnlistmentPreparingAborting = null;
            /*VolatileEnlistmentAborting?*/ static s_volatileEnlistmentAborting = null;
            /*VolatileEnlistmentCommitting?*/ static s_volatileEnlistmentCommitting = null;
            /*VolatileEnlistmentInDoubt?*/ static s_volatileEnlistmentInDoubt = null;
            /*VolatileEnlistmentEnded?*/ static s_volatileEnlistmentEnded = null;
            /*VolatileEnlistmentDone?*/ static s_volatileEnlistmentDone = null;
            /*object?*/ static s_classSyncObject = null;
            static /*VolatileEnlistmentActive */ get VolatileEnlistmentActive()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.VolatileEnlistmentActive, $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentActive, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentActive = $v, $.$stl.System.Transactions.VolatileEnlistmentActive), $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.VolatileEnlistmentActive))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.VolatileEnlistmentActive().$ctor$3();
                }, {"r":8816100,"n":"","d":9471460,"h":0,"f":1048578}));
            }
            static /*VolatileEnlistmentPreparing */ get VolatileEnlistmentPreparing()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.VolatileEnlistmentPreparing, $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentPreparing, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentPreparing = $v, $.$stl.System.Transactions.VolatileEnlistmentPreparing), $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.VolatileEnlistmentPreparing))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.VolatileEnlistmentPreparing().$ctor$3();
                }, {"r":9209316,"n":"","d":9471460,"h":0,"f":1048578}));
            }
            static /*VolatileEnlistmentPrepared */ get VolatileEnlistmentPrepared()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.VolatileEnlistmentPrepared, $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentPrepared, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentPrepared = $v, $.$stl.System.Transactions.VolatileEnlistmentPrepared), $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.VolatileEnlistmentPrepared))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.VolatileEnlistmentPrepared().$ctor$3();
                }, {"r":9143780,"n":"","d":9471460,"h":0,"f":1048578}));
            }
            static /*VolatileEnlistmentSPC */ get VolatileEnlistmentSPC()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.VolatileEnlistmentSPC, $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentSPC, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentSPC = $v, $.$stl.System.Transactions.VolatileEnlistmentSPC), $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.VolatileEnlistmentSPC))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.VolatileEnlistmentSPC().$ctor$3();
                }, {"r":9405924,"n":"","d":9471460,"h":0,"f":1048578}));
            }
            static /*VolatileEnlistmentPreparingAborting */ get VolatileEnlistmentPreparingAborting()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.VolatileEnlistmentPreparingAborting, $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentPreparingAborting, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentPreparingAborting = $v, $.$stl.System.Transactions.VolatileEnlistmentPreparingAborting), $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.VolatileEnlistmentPreparingAborting))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.VolatileEnlistmentPreparingAborting().$ctor$3();
                }, {"r":9274852,"n":"","d":9471460,"h":0,"f":1048578}));
            }
            static /*VolatileEnlistmentAborting */ get VolatileEnlistmentAborting()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.VolatileEnlistmentAborting, $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentAborting, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentAborting = $v, $.$stl.System.Transactions.VolatileEnlistmentAborting), $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.VolatileEnlistmentAborting))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.VolatileEnlistmentAborting().$ctor$3();
                }, {"r":8750564,"n":"","d":9471460,"h":0,"f":1048578}));
            }
            static /*VolatileEnlistmentCommitting */ get VolatileEnlistmentCommitting()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.VolatileEnlistmentCommitting, $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentCommitting, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentCommitting = $v, $.$stl.System.Transactions.VolatileEnlistmentCommitting), $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.VolatileEnlistmentCommitting))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.VolatileEnlistmentCommitting().$ctor$3();
                }, {"r":8881636,"n":"","d":9471460,"h":0,"f":1048578}));
            }
            static /*VolatileEnlistmentInDoubt */ get VolatileEnlistmentInDoubt()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.VolatileEnlistmentInDoubt, $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentInDoubt, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentInDoubt = $v, $.$stl.System.Transactions.VolatileEnlistmentInDoubt), $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.VolatileEnlistmentInDoubt))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.VolatileEnlistmentInDoubt().$ctor$3();
                }, {"r":9078244,"n":"","d":9471460,"h":0,"f":1048578}));
            }
            static /*VolatileEnlistmentEnded */ get VolatileEnlistmentEnded()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.VolatileEnlistmentEnded, $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentEnded, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentEnded = $v, $.$stl.System.Transactions.VolatileEnlistmentEnded), $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.VolatileEnlistmentEnded))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.VolatileEnlistmentEnded().$ctor$3();
                }, {"r":9012708,"n":"","d":9471460,"h":0,"f":1048578}));
            }
            static /*VolatileEnlistmentDone */ get VolatileEnlistmentDone()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.VolatileEnlistmentDone, $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentDone, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_volatileEnlistmentDone = $v, $.$stl.System.Transactions.VolatileEnlistmentDone), $.$ref(() => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject, ($v) => $.$stl.System.Transactions.VolatileEnlistmentState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.VolatileEnlistmentDone))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.VolatileEnlistmentDone().$ctor$4();
                }, {"r":8947172,"n":"","d":9471460,"h":0,"f":1048578}));
            }
            /*byte[] */ RecoveryInformation(/*InternalEnlistment*/ enlistment)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException$1(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.VolEnlistNoRecoveryInfo, null, enlistment === null ? $.$spc.System.Guid.Empty : enlistment.DistributedTxId);
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 9471460;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1934820,"p":[{"p":8816100,"g":{"r":0,"d":0,"h":55844046308,"f":40},"n":"VolatileEnlistmentActive","d":9471460,"h":51549079012,"f":40},{"p":9209316,"g":{"r":0,"d":0,"h":64433980900,"f":36},"n":"VolatileEnlistmentPreparing","d":9471460,"h":60139013604,"f":36},{"p":9143780,"g":{"r":0,"d":0,"h":73023915492,"f":36},"n":"VolatileEnlistmentPrepared","d":9471460,"h":68728948196,"f":36},{"p":9405924,"g":{"r":0,"d":0,"h":81613850084,"f":36},"n":"VolatileEnlistmentSPC","d":9471460,"h":77318882788,"f":36},{"p":9274852,"g":{"r":0,"d":0,"h":90203784676,"f":36},"n":"VolatileEnlistmentPreparingAborting","d":9471460,"h":85908817380,"f":36},{"p":8750564,"g":{"r":0,"d":0,"h":98793719268,"f":36},"n":"VolatileEnlistmentAborting","d":9471460,"h":94498751972,"f":36},{"p":8881636,"g":{"r":0,"d":0,"h":107383653860,"f":36},"n":"VolatileEnlistmentCommitting","d":9471460,"h":103088686564,"f":36},{"p":9078244,"g":{"r":0,"d":0,"h":115973588452,"f":36},"n":"VolatileEnlistmentInDoubt","d":9471460,"h":111678621156,"f":36},{"p":9012708,"g":{"r":0,"d":0,"h":124563523044,"f":36},"n":"VolatileEnlistmentEnded","d":9471460,"h":120268555748,"f":36},{"p":8947172,"g":{"r":0,"d":0,"h":133153457636,"f":36},"n":"VolatileEnlistmentDone","d":9471460,"h":128858490340,"f":36}],"m":[{"r":0,"p":[{"n":"enlistment","p":2721252}],"n":"RecoveryInformation","d":9471460,"h":137448424932,"f":32776}],"l":[{"t":8816100,"n":"s_volatileEnlistmentActive","d":9471460,"h":4304438756,"f":34},{"t":9209316,"n":"s_volatileEnlistmentPreparing","d":9471460,"h":8599406052,"f":34},{"t":9143780,"n":"s_volatileEnlistmentPrepared","d":9471460,"h":12894373348,"f":34},{"t":9405924,"n":"s_volatileEnlistmentSPC","d":9471460,"h":17189340644,"f":34},{"t":9274852,"n":"s_volatileEnlistmentPreparingAborting","d":9471460,"h":21484307940,"f":34},{"t":8750564,"n":"s_volatileEnlistmentAborting","d":9471460,"h":25779275236,"f":34},{"t":8881636,"n":"s_volatileEnlistmentCommitting","d":9471460,"h":30074242532,"f":34},{"t":9078244,"n":"s_volatileEnlistmentInDoubt","d":9471460,"h":34369209828,"f":34},{"t":9012708,"n":"s_volatileEnlistmentEnded","d":9471460,"h":38664177124,"f":34},{"t":8947172,"n":"s_volatileEnlistmentDone","d":9471460,"h":42959144420,"f":34},{"t":131073,"n":"s_classSyncObject","d":9471460,"h":47254111716,"f":34}],"c":[{"n":".ctor","o":"$ctor$2","d":9471460,"h":141743392228,"f":4}],"h":9471460}; }
            static get $b() { return $.$stl.System.Transactions.EnlistmentState; }
            static get $fullName() { return `System.Transactions.VolatileEnlistmentState`; }
        });
        
        $asm.$cls("$stl.System.Transactions.ActiveStates", ($self) => class ActiveStates extends $.$stl.System.Transactions.TransactionState
        {
            /*TransactionStatus */ get_Status(/*InternalTransaction*/ tx)
            {
                return 0/*TransactionStatus.Active*/;
            }
            /*void */ AddOutcomeRegistrant(/*InternalTransaction*/ tx, /*TransactionCompletedEventHandler?*/ transactionCompletedDelegate)
            {
                tx._transactionCompletedDelegate = $.$cast($.$spc.System.Delegate.Combine(tx._transactionCompletedDelegate, transactionCompletedDelegate), $.$stl.System.Transactions.TransactionCompletedEventHandler);
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 230884;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":5735908,"m":[{"r":8422884,"p":[{"n":"tx","p":2786788}],"n":"get_Status","d":230884,"h":4295198180,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"transactionCompletedDelegate","p":4425188}],"n":"AddOutcomeRegistrant","d":230884,"h":8590165476,"f":32776}],"c":[{"n":".ctor","o":"$ctor$2","d":230884,"h":12885132772,"f":4}],"h":230884}; }
            static get $b() { return $.$stl.System.Transactions.TransactionState; }
            static get $fullName() { return `System.Transactions.ActiveStates`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateEnded", ($self) => class TransactionStateEnded extends $.$stl.System.Transactions.TransactionState
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                if (tx._needPulse)
                {
                    $.$spc.System.Threading.Monitor.Pulse(tx);
                }
            }
            /*void */ AddOutcomeRegistrant(/*InternalTransaction*/ tx, /*TransactionCompletedEventHandler?*/ transactionCompletedDelegate)
            {
                if (transactionCompletedDelegate !== null)
                {
                    /*TransactionEventArgs*/ let args = new $.$stl.System.Transactions.TransactionEventArgs().$ctor$2();
                    args._transaction = tx._outcomeSource.InternalClone();
                    transactionCompletedDelegate.Invoke(args._transaction, args);
                }
            }
            /*bool */ IsCompleted(/*InternalTransaction*/ tx)
            {
                return true;
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 6456804;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":5735908,"m":[{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"EnterState","d":6456804,"h":4301424100,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"transactionCompletedDelegate","p":4425188}],"n":"AddOutcomeRegistrant","d":6456804,"h":8596391396,"f":32776},{"r":262145,"p":[{"n":"tx","p":2786788}],"n":"IsCompleted","d":6456804,"h":12891358692,"f":32776}],"c":[{"n":".ctor","o":"$ctor$2","d":6456804,"h":17186325988,"f":4}],"h":6456804}; }
            static get $b() { return $.$stl.System.Transactions.TransactionState; }
            static get $fullName() { return `System.Transactions.TransactionStateEnded`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedBase", ($self) => class TransactionStatePromotedBase extends $.$stl.System.Transactions.TransactionState
        {
            /*TransactionStatus */ get_Status(/*InternalTransaction*/ tx)
            {
                return 0/*TransactionStatus.Active*/;
            }
            /*Enlistment */ EnlistVolatile(/*InternalTransaction*/ tx, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(tx.PromotedTransaction !== null, "Promoted state not valid for transaction.");
                $.$spc.System.Threading.Monitor.Exit(tx);
                try
                {
                    /*Enlistment*/ let en = new $.$stl.System.Transactions.Enlistment().$ctor$5(enlistmentNotification, tx, atomicTransaction);
                    $.$stl.System.Transactions.EnlistmentState.EnlistmentStatePromoted.EnterState(en.InternalEnlistment);
                    en.InternalEnlistment.PromotedEnlistment = tx.PromotedTransaction.EnlistVolatile(en.InternalEnlistment, enlistmentOptions);
                    return en;
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(tx);
                    }
                }
            }
            /*Enlistment */ EnlistVolatile$1(/*InternalTransaction*/ tx, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(tx.PromotedTransaction !== null, "Promoted state not valid for transaction.");
                $.$spc.System.Threading.Monitor.Exit(tx);
                try
                {
                    /*Enlistment*/ let en = new $.$stl.System.Transactions.Enlistment().$ctor$5(enlistmentNotification, tx, atomicTransaction);
                    $.$stl.System.Transactions.EnlistmentState.EnlistmentStatePromoted.EnterState(en.InternalEnlistment);
                    en.InternalEnlistment.PromotedEnlistment = tx.PromotedTransaction.EnlistVolatile(en.InternalEnlistment, enlistmentOptions);
                    return en;
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(tx);
                    }
                }
            }
            /*Enlistment */ EnlistDurable(/*InternalTransaction*/ tx, /*Guid*/ resourceManagerIdentifier, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(tx.PromotedTransaction !== null, "Promoted state not valid for transaction.");
                tx.ThrowIfPromoterTypeIsNotMSDTC();
                $.$spc.System.Threading.Monitor.Exit(tx);
                try
                {
                    /*Enlistment*/ let en = new $.$stl.System.Transactions.Enlistment().$ctor$2(resourceManagerIdentifier, tx, enlistmentNotification, null, atomicTransaction);
                    $.$stl.System.Transactions.EnlistmentState.EnlistmentStatePromoted.EnterState(en.InternalEnlistment);
                    en.InternalEnlistment.PromotedEnlistment = tx.PromotedTransaction.EnlistDurable(resourceManagerIdentifier, $.$cast(en.InternalEnlistment, $.$stl.System.Transactions.DurableInternalEnlistment), false, enlistmentOptions);
                    return en;
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(tx);
                    }
                }
            }
            /*Enlistment */ EnlistDurable$1(/*InternalTransaction*/ tx, /*Guid*/ resourceManagerIdentifier, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(tx.PromotedTransaction !== null, "Promoted state not valid for transaction.");
                tx.ThrowIfPromoterTypeIsNotMSDTC();
                $.$spc.System.Threading.Monitor.Exit(tx);
                try
                {
                    /*Enlistment*/ let en = new $.$stl.System.Transactions.Enlistment().$ctor$2(resourceManagerIdentifier, tx, enlistmentNotification, enlistmentNotification, atomicTransaction);
                    $.$stl.System.Transactions.EnlistmentState.EnlistmentStatePromoted.EnterState(en.InternalEnlistment);
                    en.InternalEnlistment.PromotedEnlistment = tx.PromotedTransaction.EnlistDurable(resourceManagerIdentifier, $.$cast(en.InternalEnlistment, $.$stl.System.Transactions.DurableInternalEnlistment), true, enlistmentOptions);
                    return en;
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(tx);
                    }
                }
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(tx.PromotedTransaction !== null, "Promoted state not valid for transaction.");
                tx._innerException ??= e;
                $.$spc.System.Threading.Monitor.Exit(tx);
                try
                {
                    tx.PromotedTransaction.Rollback();
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(tx);
                    }
                }
            }
            /*Guid */ get_Identifier(/*InternalTransaction?*/ tx)
            {
                if (tx !== null && tx.PromotedTransaction !== null)
                {
                    return tx.PromotedTransaction.Identifier;
                }
                else 
                {
                    return $.$spc.System.Guid.Empty;
                }
            }
            /*void */ AddOutcomeRegistrant(/*InternalTransaction*/ tx, /*TransactionCompletedEventHandler?*/ transactionCompletedDelegate)
            {
                tx._transactionCompletedDelegate = $.$cast($.$spc.System.Delegate.Combine(tx._transactionCompletedDelegate, transactionCompletedDelegate), $.$stl.System.Transactions.TransactionCompletedEventHandler);
            }
            /*void */ BeginCommit(/*InternalTransaction*/ tx, /*bool*/ asyncCommit, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                tx._asyncCommit = asyncCommit;
                tx._asyncCallback = asyncCallback;
                tx._asyncState = asyncState;
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedCommitting.EnterState(tx);
            }
            /*void */ RestartCommitIfNeeded(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedP0Wave.EnterState(tx);
            }
            /*bool */ EnlistPromotableSinglePhase(/*InternalTransaction*/ tx, /*IPromotableSinglePhaseNotification*/ promotableSinglePhaseNotification, /*Transaction*/ atomicTransaction, /*Guid*/ promoterType)
            {
                return false;
            }
            /*void */ CompleteBlockingClone(/*InternalTransaction*/ tx)
            {
                if (tx._phase0Volatiles._dependentClones > 0)
                {
                    tx._phase0Volatiles._dependentClones--;
                    $.$spc.System.Diagnostics.Debug.Assert$1(tx._phase0Volatiles._preparedVolatileEnlistments <= ((tx._phase0Volatiles._volatileEnlistmentCount + tx._phase0Volatiles._dependentClones) | 0), "tx._phase0Volatiles._preparedVolatileEnlistments <=\r\n                    tx._phase0Volatiles._volatileEnlistmentCount + tx._phase0Volatiles._dependentClones");
                    if (tx._phase0Volatiles._preparedVolatileEnlistments === ((tx._phase0VolatileWaveCount + tx._phase0Volatiles._dependentClones) | 0))
                    {
                        tx.State.Phase0VolatilePrepareDone(tx);
                    }
                }
                else 
                {
                    tx._phase0WaveDependentCloneCount--;
                    $.$spc.System.Diagnostics.Debug.Assert$1(tx._phase0WaveDependentCloneCount >= 0, "tx._phase0WaveDependentCloneCount >= 0");
                    if (tx._phase0WaveDependentCloneCount === 0)
                    {
                        /*OletxDependentTransaction*/ let dtx = tx._phase0WaveDependentClone;
                        tx._phase0WaveDependentClone = null;
                        $.$spc.System.Threading.Monitor.Exit(tx);
                        try
                        {
                            try
                            {
                                dtx.Complete();
                            }
                            finally
                            {
                                {
                                    dtx.Dispose();
                                }
                            }
                        }
                        finally
                        {
                            {
                                $.$spc.System.Threading.Monitor.Enter(tx);
                            }
                        }
                    }
                }
            }
            /*void */ CompleteAbortingClone(/*InternalTransaction*/ tx)
            {
                if (null !== tx._phase1Volatiles.VolatileDemux)
                {
                    tx._phase1Volatiles._dependentClones--;
                    $.$spc.System.Diagnostics.Debug.Assert$1(tx._phase1Volatiles._dependentClones >= 0, "tx._phase1Volatiles._dependentClones >= 0");
                }
                else 
                {
                    tx._abortingDependentCloneCount--;
                    $.$spc.System.Diagnostics.Debug.Assert$1(0 <= tx._abortingDependentCloneCount, "0 <= tx._abortingDependentCloneCount");
                    if (0 === tx._abortingDependentCloneCount)
                    {
                        /*OletxDependentTransaction*/ let dtx = tx._abortingDependentClone;
                        tx._abortingDependentClone = null;
                        $.$spc.System.Threading.Monitor.Exit(tx);
                        try
                        {
                            try
                            {
                                dtx.Complete();
                            }
                            finally
                            {
                                {
                                    dtx.Dispose();
                                }
                            }
                        }
                        finally
                        {
                            {
                                $.$spc.System.Threading.Monitor.Enter(tx);
                            }
                        }
                    }
                }
            }
            /*void */ CreateBlockingClone(/*InternalTransaction*/ tx)
            {
                if (tx._phase0WaveDependentClone === null)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(tx.PromotedTransaction !== null, "tx.PromotedTransaction != null");
                    tx._phase0WaveDependentClone = tx.PromotedTransaction.DependentClone(true);
                }
                tx._phase0WaveDependentCloneCount++;
            }
            /*void */ CreateAbortingClone(/*InternalTransaction*/ tx)
            {
                if (null !== tx._phase1Volatiles.VolatileDemux)
                {
                    tx._phase1Volatiles._dependentClones++;
                }
                else 
                {
                    if (null === tx._abortingDependentClone)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(tx.PromotedTransaction !== null, "tx.PromotedTransaction != null");
                        tx._abortingDependentClone = tx.PromotedTransaction.DependentClone(false);
                    }
                    tx._abortingDependentCloneCount++;
                }
            }
            /*bool */ ContinuePhase0Prepares()
            {
                return true;
            }
            /*void */ GetObjectData(/*InternalTransaction*/ tx, /*SerializationInfo*/ serializationInfo, /*StreamingContext*/ context)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(tx.PromotedTransaction !== null, "Promoted state not valid for transaction.");
                tx.ThrowIfPromoterTypeIsNotMSDTC();
                /*OletxTransaction*/ let serializableTx = tx.PromotedTransaction;
                if (serializableTx === null)
                {
                    throw new $.$spc.System.NotSupportedException().$ctor$9();
                }
                serializationInfo.FullTypeName = $.$spc.System.Object.GetType.call(serializableTx).FullName;
                serializableTx.GetObjectData(serializationInfo, context);
            }
            /*void */ ChangeStatePromotedAborted(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedAborted.EnterState(tx);
            }
            /*void */ ChangeStatePromotedCommitted(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedCommitted.EnterState(tx);
            }
            /*void */ InDoubtFromDtc(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedIndoubt.EnterState(tx);
            }
            /*void */ InDoubtFromEnlistment(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedIndoubt.EnterState(tx);
            }
            /*void */ ChangeStateAbortedDuringPromotion(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStateAborted.EnterState(tx);
            }
            /*void */ Timeout(/*InternalTransaction*/ tx)
            {
                try
                {
                    tx._innerException ??= new $.$spc.System.TimeoutException().$ctor$10($.$stl.System.SR.TraceTransactionTimeout);
                    $.$spc.System.Diagnostics.Debug.Assert$1(tx.PromotedTransaction !== null, "tx.PromotedTransaction != null");
                    tx.PromotedTransaction.Rollback();
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.TransactionTimeout(tx.TransactionTraceId);
                    }
                }
                catch(te)
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.ExceptionConsumed$1(te);
                    }
                }
            }
            /*void */ Promote(/*InternalTransaction*/ tx)
            {
            }
            /*byte[] */ PromotedToken(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(tx.promotedToken !== null, "InternalTransaction.promotedToken is null in TransactionStateDelegatedNonMSDTCBase or one of its derived classes.");
                return tx.promotedToken;
            }
            /*void */ Phase0VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ Phase1VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 6915556;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":5735908,"m":[{"r":8422884,"p":[{"n":"tx","p":2786788}],"n":"get_Status","d":6915556,"h":4301882852,"f":32776},{"r":1738212,"p":[{"n":"tx","p":2786788},{"n":"enlistmentNotification","p":2590180},{"n":"enlistmentOptions","p":1869284},{"n":"atomicTransaction","p":4294116}],"n":"EnlistVolatile","d":6915556,"h":8596850148,"f":32776},{"r":1738212,"p":[{"n":"tx","p":2786788},{"n":"enlistmentNotification","p":3048932},{"n":"enlistmentOptions","p":1869284},{"n":"atomicTransaction","p":4294116}],"n":"EnlistVolatile","o":"@$1","d":6915556,"h":12891817444,"f":32776},{"r":1738212,"p":[{"n":"tx","p":2786788},{"n":"resourceManagerIdentifier","p":56229889},{"n":"enlistmentNotification","p":2590180},{"n":"enlistmentOptions","p":1869284},{"n":"atomicTransaction","p":4294116}],"n":"EnlistDurable","d":6915556,"h":17186784740,"f":32776},{"r":1738212,"p":[{"n":"tx","p":2786788},{"n":"resourceManagerIdentifier","p":56229889},{"n":"enlistmentNotification","p":3048932},{"n":"enlistmentOptions","p":1869284},{"n":"atomicTransaction","p":4294116}],"n":"EnlistDurable","o":"@$1","d":6915556,"h":21481752036,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"e","p":47251457}],"n":"Rollback","d":6915556,"h":25776719332,"f":32776},{"r":56229889,"p":[{"n":"tx","p":2786788}],"n":"get_Identifier","d":6915556,"h":30071686628,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"transactionCompletedDelegate","p":4425188}],"n":"AddOutcomeRegistrant","d":6915556,"h":34366653924,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"asyncCommit","p":262145},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":6915556,"h":38661621220,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"RestartCommitIfNeeded","d":6915556,"h":42956588516,"f":32776},{"r":262145,"p":[{"n":"tx","p":2786788},{"n":"promotableSinglePhaseNotification","p":2852324},{"n":"atomicTransaction","p":4294116},{"n":"promoterType","p":56229889}],"n":"EnlistPromotableSinglePhase","d":6915556,"h":47251555812,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"CompleteBlockingClone","d":6915556,"h":51546523108,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"CompleteAbortingClone","d":6915556,"h":55841490404,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"CreateBlockingClone","d":6915556,"h":60136457700,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"CreateAbortingClone","d":6915556,"h":64431424996,"f":32776},{"r":262145,"n":"ContinuePhase0Prepares","d":6915556,"h":68726392292,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"serializationInfo","p":113967105},{"n":"context","p":114098177}],"n":"GetObjectData","d":6915556,"h":73021359588,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"ChangeStatePromotedAborted","d":6915556,"h":77316326884,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"ChangeStatePromotedCommitted","d":6915556,"h":81611294180,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"InDoubtFromDtc","d":6915556,"h":85906261476,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"InDoubtFromEnlistment","d":6915556,"h":90201228772,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"ChangeStateAbortedDuringPromotion","d":6915556,"h":94496196068,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"Timeout","d":6915556,"h":98791163364,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"Promote","d":6915556,"h":103086130660,"f":32776},{"r":0,"p":[{"n":"tx","p":2786788}],"n":"PromotedToken","d":6915556,"h":107381097956,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"Phase0VolatilePrepareDone","d":6915556,"h":111676065252,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"Phase1VolatilePrepareDone","d":6915556,"h":115971032548,"f":32776}],"c":[{"n":".ctor","o":"$ctor$2","d":6915556,"h":120265999844,"f":4}],"h":6915556}; }
            static get $b() { return $.$stl.System.Transactions.TransactionState; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedBase`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedNonMSDTCBase", ($self) => class TransactionStatePromotedNonMSDTCBase extends $.$stl.System.Transactions.TransactionState
        {
            /*TransactionStatus */ get_Status(/*InternalTransaction*/ tx)
            {
                return 0/*TransactionStatus.Active*/;
            }
            /*Enlistment */ EnlistVolatile(/*InternalTransaction*/ tx, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                /*Enlistment*/ let enlistment = new $.$stl.System.Transactions.Enlistment().$ctor$3(tx, enlistmentNotification, null, atomicTransaction, enlistmentOptions);
                if ((enlistmentOptions & 1/*EnlistmentOptions.EnlistDuringPrepareRequired*/) !== 0)
                {
                    $.$stl.System.Transactions.TransactionState.AddVolatileEnlistment($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase0Volatiles, ($v) => tx._phase0Volatiles = $v, null), enlistment);
                }
                else 
                {
                    $.$stl.System.Transactions.TransactionState.AddVolatileEnlistment($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase1Volatiles, ($v) => tx._phase1Volatiles = $v, null), enlistment);
                }
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionstateEnlist(enlistment.InternalEnlistment.EnlistmentTraceId, 0/*EnlistmentType.Volatile*/, enlistmentOptions);
                }
                return enlistment;
            }
            /*Enlistment */ EnlistVolatile$1(/*InternalTransaction*/ tx, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                /*Enlistment*/ let enlistment = new $.$stl.System.Transactions.Enlistment().$ctor$3(tx, enlistmentNotification, enlistmentNotification, atomicTransaction, enlistmentOptions);
                if ((enlistmentOptions & 1/*EnlistmentOptions.EnlistDuringPrepareRequired*/) !== 0)
                {
                    $.$stl.System.Transactions.TransactionState.AddVolatileEnlistment($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase0Volatiles, ($v) => tx._phase0Volatiles = $v, null), enlistment);
                }
                else 
                {
                    $.$stl.System.Transactions.TransactionState.AddVolatileEnlistment($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase1Volatiles, ($v) => tx._phase1Volatiles = $v, null), enlistment);
                }
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionstateEnlist(enlistment.InternalEnlistment.EnlistmentTraceId, 0/*EnlistmentType.Volatile*/, enlistmentOptions);
                }
                return enlistment;
            }
            /*Enlistment */ EnlistDurable(/*InternalTransaction*/ tx, /*Guid*/ resourceManagerIdentifier, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                throw new $.$stl.System.Transactions.TransactionPromotionException().$ctor$15($.$stl.System.SR.Format($.$stl.System.SR.PromoterTypeUnrecognized, $.$spc.System.Guid.ToString.call(tx._promoterType)), tx._innerException);
            }
            /*Enlistment */ EnlistDurable$1(/*InternalTransaction*/ tx, /*Guid*/ resourceManagerIdentifier, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                throw new $.$stl.System.Transactions.TransactionPromotionException().$ctor$15($.$stl.System.SR.Format($.$stl.System.SR.PromoterTypeUnrecognized, $.$spc.System.Guid.ToString.call(tx._promoterType)), tx._innerException);
            }
            /*bool */ EnlistPromotableSinglePhase(/*InternalTransaction*/ tx, /*IPromotableSinglePhaseNotification*/ promotableSinglePhaseNotification, /*Transaction*/ atomicTransaction, /*Guid*/ promoterType)
            {
                return false;
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(tx._durableEnlistment !== null, "PromotedNonMSDTC state is not valid for transaction");
                tx._innerException ??= e;
                $.$stl.System.Transactions.TransactionState.TransactionStateAborted.EnterState(tx);
            }
            /*Guid */ get_Identifier(/*InternalTransaction*/ tx)
            {
                return tx._distributedTransactionIdentifierNonMSDTC;
            }
            /*void */ AddOutcomeRegistrant(/*InternalTransaction*/ tx, /*TransactionCompletedEventHandler?*/ transactionCompletedDelegate)
            {
                tx._transactionCompletedDelegate = $.$cast($.$spc.System.Delegate.Combine(tx._transactionCompletedDelegate, transactionCompletedDelegate), $.$stl.System.Transactions.TransactionCompletedEventHandler);
            }
            /*void */ BeginCommit(/*InternalTransaction*/ tx, /*bool*/ asyncCommit, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                tx._asyncCommit = asyncCommit;
                tx._asyncCallback = asyncCallback;
                tx._asyncState = asyncState;
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedNonMSDTCPhase0.EnterState(tx);
            }
            /*void */ CompleteBlockingClone(/*InternalTransaction*/ tx)
            {
                if (tx._phase0Volatiles._dependentClones > 0)
                {
                    tx._phase0Volatiles._dependentClones--;
                    $.$spc.System.Diagnostics.Debug.Assert$1(tx._phase0Volatiles._preparedVolatileEnlistments <= ((tx._phase0Volatiles._volatileEnlistmentCount + tx._phase0Volatiles._dependentClones) | 0), "tx._phase0Volatiles._preparedVolatileEnlistments <=\r\n                    tx._phase0Volatiles._volatileEnlistmentCount + tx._phase0Volatiles._dependentClones");
                    if (tx._phase0Volatiles._preparedVolatileEnlistments === ((tx._phase0VolatileWaveCount + tx._phase0Volatiles._dependentClones) | 0))
                    {
                        tx.State.Phase0VolatilePrepareDone(tx);
                    }
                }
            }
            /*void */ CompleteAbortingClone(/*InternalTransaction*/ tx)
            {
                tx._phase1Volatiles._dependentClones--;
                $.$spc.System.Diagnostics.Debug.Assert$1(tx._phase1Volatiles._dependentClones >= 0, "tx._phase1Volatiles._dependentClones >= 0");
            }
            /*void */ CreateBlockingClone(/*InternalTransaction*/ tx)
            {
                tx._phase0Volatiles._dependentClones++;
            }
            /*void */ CreateAbortingClone(/*InternalTransaction*/ tx)
            {
                tx._phase1Volatiles._dependentClones++;
            }
            /*bool */ ContinuePhase0Prepares()
            {
                return true;
            }
            /*void */ GetObjectData(/*InternalTransaction*/ tx, /*SerializationInfo*/ serializationInfo, /*StreamingContext*/ context)
            {
                throw new $.$stl.System.Transactions.TransactionPromotionException().$ctor$15($.$stl.System.SR.Format($.$stl.System.SR.PromoterTypeUnrecognized, $.$spc.System.Guid.ToString.call(tx._promoterType)), tx._innerException);
            }
            /*void */ ChangeStateTransactionAborted(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                tx._innerException ??= e;
                $.$stl.System.Transactions.TransactionState.TransactionStateAborted.EnterState(tx);
            }
            /*void */ InDoubtFromEnlistment(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedNonMSDTCIndoubt.EnterState(tx);
            }
            /*void */ ChangeStateAbortedDuringPromotion(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStateAborted.EnterState(tx);
            }
            /*void */ Timeout(/*InternalTransaction*/ tx)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionTimeout(tx.TransactionTraceId);
                }
                /*TimeoutException*/ let e = new $.$spc.System.TimeoutException().$ctor$10($.$stl.System.SR.TraceTransactionTimeout);
                this.Rollback(tx, e);
            }
            /*void */ Promote(/*InternalTransaction*/ tx)
            {
            }
            /*void */ Phase0VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ Phase1VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            /*byte[] */ PromotedToken(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(tx.promotedToken !== null, "InternalTransaction.promotedToken is null in TransactionStateDelegatedNonMSDTCBase or one of its derived classes.");
                return tx.promotedToken;
            }
            /*void */ DisposeRoot(/*InternalTransaction*/ tx)
            {
                tx.State.Rollback(tx, null);
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 7308772;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":5735908,"m":[{"r":8422884,"p":[{"n":"tx","p":2786788}],"n":"get_Status","d":7308772,"h":4302276068,"f":32776},{"r":1738212,"p":[{"n":"tx","p":2786788},{"n":"enlistmentNotification","p":2590180},{"n":"enlistmentOptions","p":1869284},{"n":"atomicTransaction","p":4294116}],"n":"EnlistVolatile","d":7308772,"h":8597243364,"f":32776},{"r":1738212,"p":[{"n":"tx","p":2786788},{"n":"enlistmentNotification","p":3048932},{"n":"enlistmentOptions","p":1869284},{"n":"atomicTransaction","p":4294116}],"n":"EnlistVolatile","o":"@$1","d":7308772,"h":12892210660,"f":32776},{"r":1738212,"p":[{"n":"tx","p":2786788},{"n":"resourceManagerIdentifier","p":56229889},{"n":"enlistmentNotification","p":2590180},{"n":"enlistmentOptions","p":1869284},{"n":"atomicTransaction","p":4294116}],"n":"EnlistDurable","d":7308772,"h":17187177956,"f":32776},{"r":1738212,"p":[{"n":"tx","p":2786788},{"n":"resourceManagerIdentifier","p":56229889},{"n":"enlistmentNotification","p":3048932},{"n":"enlistmentOptions","p":1869284},{"n":"atomicTransaction","p":4294116}],"n":"EnlistDurable","o":"@$1","d":7308772,"h":21482145252,"f":32776},{"r":262145,"p":[{"n":"tx","p":2786788},{"n":"promotableSinglePhaseNotification","p":2852324},{"n":"atomicTransaction","p":4294116},{"n":"promoterType","p":56229889}],"n":"EnlistPromotableSinglePhase","d":7308772,"h":25777112548,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"e","p":47251457}],"n":"Rollback","d":7308772,"h":30072079844,"f":32776},{"r":56229889,"p":[{"n":"tx","p":2786788}],"n":"get_Identifier","d":7308772,"h":34367047140,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"transactionCompletedDelegate","p":4425188}],"n":"AddOutcomeRegistrant","d":7308772,"h":38662014436,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"asyncCommit","p":262145},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":7308772,"h":42956981732,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"CompleteBlockingClone","d":7308772,"h":47251949028,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"CompleteAbortingClone","d":7308772,"h":51546916324,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"CreateBlockingClone","d":7308772,"h":55841883620,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"CreateAbortingClone","d":7308772,"h":60136850916,"f":32776},{"r":262145,"n":"ContinuePhase0Prepares","d":7308772,"h":64431818212,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"serializationInfo","p":113967105},{"n":"context","p":114098177}],"n":"GetObjectData","d":7308772,"h":68726785508,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"e","p":47251457}],"n":"ChangeStateTransactionAborted","d":7308772,"h":73021752804,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"InDoubtFromEnlistment","d":7308772,"h":77316720100,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"ChangeStateAbortedDuringPromotion","d":7308772,"h":81611687396,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"Timeout","d":7308772,"h":85906654692,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"Promote","d":7308772,"h":90201621988,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"Phase0VolatilePrepareDone","d":7308772,"h":94496589284,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"Phase1VolatilePrepareDone","d":7308772,"h":98791556580,"f":32776},{"r":0,"p":[{"n":"tx","p":2786788}],"n":"PromotedToken","d":7308772,"h":103086523876,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"DisposeRoot","d":7308772,"h":107381491172,"f":32776}],"c":[{"n":".ctor","o":"$ctor$2","d":7308772,"h":111676458468,"f":4}],"h":7308772}; }
            static get $b() { return $.$stl.System.Transactions.TransactionState; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedNonMSDTCBase`; }
        });
        
        $asm.$cls("$stl.System.Transactions.EnlistableStates", ($self) => class EnlistableStates extends $.$stl.System.Transactions.ActiveStates
        {
            /*Enlistment */ EnlistDurable(/*InternalTransaction*/ tx, /*Guid*/ resourceManagerIdentifier, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                tx.ThrowIfPromoterTypeIsNotMSDTC();
                tx._promoteState.EnterState(tx);
                return tx.State.EnlistDurable(tx, resourceManagerIdentifier, enlistmentNotification, enlistmentOptions, atomicTransaction);
            }
            /*Enlistment */ EnlistDurable$1(/*InternalTransaction*/ tx, /*Guid*/ resourceManagerIdentifier, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                tx.ThrowIfPromoterTypeIsNotMSDTC();
                if (tx._durableEnlistment !== null || (enlistmentOptions & 1/*EnlistmentOptions.EnlistDuringPrepareRequired*/) !== 0)
                {
                    tx._promoteState.EnterState(tx);
                    return tx.State.EnlistDurable$1(tx, resourceManagerIdentifier, enlistmentNotification, enlistmentOptions, atomicTransaction);
                }
                /*Enlistment*/ let en = new $.$stl.System.Transactions.Enlistment().$ctor$2(resourceManagerIdentifier, tx, enlistmentNotification, enlistmentNotification, atomicTransaction);
                tx._durableEnlistment = en.InternalEnlistment;
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentActive.EnterState(tx._durableEnlistment);
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionstateEnlist(tx._durableEnlistment.EnlistmentTraceId, 1/*EnlistmentType.Durable*/, 0/*EnlistmentOptions.None*/);
                }
                return en;
            }
            /*void */ Timeout(/*InternalTransaction*/ tx)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionTimeout(tx.TransactionTraceId);
                }
                /*TimeoutException*/ let e = new $.$spc.System.TimeoutException().$ctor$10($.$stl.System.SR.TraceTransactionTimeout);
                this.Rollback(tx, e);
            }
            /*void */ GetObjectData(/*InternalTransaction*/ tx, /*SerializationInfo*/ serializationInfo, /*StreamingContext*/ context)
            {
                tx.ThrowIfPromoterTypeIsNotMSDTC();
                tx._promoteState.EnterState(tx);
                tx.State.GetObjectData(tx, serializationInfo, context);
            }
            /*void */ CompleteBlockingClone(/*InternalTransaction*/ tx)
            {
                tx._phase0Volatiles._dependentClones--;
                $.$spc.System.Diagnostics.Debug.Assert$1(tx._phase0Volatiles._dependentClones >= 0, "tx._phase0Volatiles._dependentClones >= 0");
                $.$spc.System.Diagnostics.Debug.Assert$1(tx._phase0Volatiles._preparedVolatileEnlistments <= ((tx._phase0Volatiles._volatileEnlistmentCount + tx._phase0Volatiles._dependentClones) | 0), "tx._phase0Volatiles._preparedVolatileEnlistments <=\r\n                tx._phase0Volatiles._volatileEnlistmentCount + tx._phase0Volatiles._dependentClones");
                if (tx._phase0Volatiles._preparedVolatileEnlistments === ((tx._phase0VolatileWaveCount + tx._phase0Volatiles._dependentClones) | 0))
                {
                    tx.State.Phase0VolatilePrepareDone(tx);
                }
            }
            /*void */ CompleteAbortingClone(/*InternalTransaction*/ tx)
            {
                tx._phase1Volatiles._dependentClones--;
                $.$spc.System.Diagnostics.Debug.Assert$1(tx._phase1Volatiles._dependentClones >= 0, "tx._phase1Volatiles._dependentClones >= 0");
            }
            /*void */ CreateBlockingClone(/*InternalTransaction*/ tx)
            {
                tx._phase0Volatiles._dependentClones++;
            }
            /*void */ CreateAbortingClone(/*InternalTransaction*/ tx)
            {
                tx._phase1Volatiles._dependentClones++;
            }
            /*void */ Promote(/*InternalTransaction*/ tx)
            {
                tx._promoteState.EnterState(tx);
                tx.State.CheckForFinishedTransaction(tx);
            }
            /*byte[] */ PromotedToken(/*InternalTransaction*/ tx)
            {
                if (tx.promotedToken === null)
                {
                    tx._promoteState.EnterState(tx);
                    tx.State.CheckForFinishedTransaction(tx);
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(tx.promotedToken !== null, "tx.promotedToken != null");
                return tx.promotedToken;
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 1672676;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":230884,"m":[{"r":1738212,"p":[{"n":"tx","p":2786788},{"n":"resourceManagerIdentifier","p":56229889},{"n":"enlistmentNotification","p":2590180},{"n":"enlistmentOptions","p":1869284},{"n":"atomicTransaction","p":4294116}],"n":"EnlistDurable","d":1672676,"h":4296639972,"f":32776},{"r":1738212,"p":[{"n":"tx","p":2786788},{"n":"resourceManagerIdentifier","p":56229889},{"n":"enlistmentNotification","p":3048932},{"n":"enlistmentOptions","p":1869284},{"n":"atomicTransaction","p":4294116}],"n":"EnlistDurable","o":"@$1","d":1672676,"h":8591607268,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"Timeout","d":1672676,"h":12886574564,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"serializationInfo","p":113967105},{"n":"context","p":114098177}],"n":"GetObjectData","d":1672676,"h":17181541860,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"CompleteBlockingClone","d":1672676,"h":21476509156,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"CompleteAbortingClone","d":1672676,"h":25771476452,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"CreateBlockingClone","d":1672676,"h":30066443748,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"CreateAbortingClone","d":1672676,"h":34361411044,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"Promote","d":1672676,"h":38656378340,"f":32776},{"r":0,"p":[{"n":"tx","p":2786788}],"n":"PromotedToken","d":1672676,"h":42951345636,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":1672676,"h":47246312932,"f":4}],"h":1672676}; }
            static get $b() { return $.$stl.System.Transactions.ActiveStates; }
            static get $fullName() { return `System.Transactions.EnlistableStates`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedAborting", ($self) => class TransactionStatePromotedAborting extends $.$stl.System.Transactions.TransactionStatePromotedBase
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
            }
            /*TransactionStatus */ get_Status(/*InternalTransaction*/ tx)
            {
                return 2/*TransactionStatus.Aborted*/;
            }
            /*void */ BeginCommit(/*InternalTransaction*/ tx, /*bool*/ asyncCommit, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ CreateBlockingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ CreateAbortingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ ChangeStatePromotedAborted(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedAborted.EnterState(tx);
            }
            /*void */ ChangeStateTransactionAborted(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
            }
            /*void */ RestartCommitIfNeeded(/*InternalTransaction*/ tx)
            {
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 6850020;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6915556,"m":[{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"EnterState","d":6850020,"h":4301817316,"f":32776},{"r":8422884,"p":[{"n":"tx","p":2786788}],"n":"get_Status","d":6850020,"h":8596784612,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"asyncCommit","p":262145},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":6850020,"h":12891751908,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"CreateBlockingClone","d":6850020,"h":17186719204,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"CreateAbortingClone","d":6850020,"h":21481686500,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"ChangeStatePromotedAborted","d":6850020,"h":25776653796,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"e","p":47251457}],"n":"ChangeStateTransactionAborted","d":6850020,"h":30071621092,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"RestartCommitIfNeeded","d":6850020,"h":34366588388,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":6850020,"h":38661555684,"f":4}],"h":6850020}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedBase; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedAborting`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedEnded", ($self) => class TransactionStatePromotedEnded extends $.$stl.System.Transactions.TransactionStateEnded
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                super.EnterState(tx);
                this.CommonEnterState(tx);
                if (!$.$spc.System.Threading.ThreadPool.QueueUserWorkItem$1($.$stl.System.Transactions.TransactionStatePromotedEnded.SignalMethod, tx))
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException$1(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.UnexpectedFailureOfThreadPool, null, tx === null ? $.$spc.System.Guid.Empty : tx.DistributedTxId);
                }
            }
            /*void */ AddOutcomeRegistrant(/*InternalTransaction*/ tx, /*TransactionCompletedEventHandler?*/ transactionCompletedDelegate)
            {
                if (transactionCompletedDelegate !== null)
                {
                    /*TransactionEventArgs*/ let args = new $.$stl.System.Transactions.TransactionEventArgs().$ctor$2();
                    args._transaction = tx._outcomeSource.InternalClone();
                    transactionCompletedDelegate.Invoke(args._transaction, args);
                }
            }
            /*void */ EndCommit(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(tx.PromotedTransaction !== null, "Promoted state not valid for transaction.");
                this.PromotedTransactionOutcome(tx);
            }
            /*void */ CompleteBlockingClone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ CompleteAbortingClone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ CreateBlockingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ CreateAbortingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*Guid */ get_Identifier(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(tx.PromotedTransaction !== null, "tx.PromotedTransaction != null");
                return tx.PromotedTransaction.Identifier;
            }
            /*void */ Promote(/*InternalTransaction*/ tx)
            {
            }
            /*WaitCallback?*/ static s_signalMethod = null;
            static /*WaitCallback */ get SignalMethod()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$spc.System.Threading.WaitCallback, $.$ref(() => $.$stl.System.Transactions.TransactionStatePromotedEnded.s_signalMethod, ($v) => $.$stl.System.Transactions.TransactionStatePromotedEnded.s_signalMethod = $v, $.$spc.System.Threading.WaitCallback), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$spc.System.Threading.WaitCallback))().$ctor(this,  () =>
                {
                    return new $.$spc.System.Threading.WaitCallback().$ctor($.$stl.System.Transactions.TransactionStatePromotedEnded, $.$stl.System.Transactions.TransactionStatePromotedEnded.SignalCallback);
                }, {"r":139067393,"n":"","d":7112164,"h":0,"f":1048578}));
            }
            static /*void */ SignalCallback(/*object*/ state)
            {
                /*InternalTransaction*/ let tx = $.$cast(state, $.$stl.System.Transactions.InternalTransaction);
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(tx)
                    {
                        tx.SignalAsyncCompletion();
                        $.$stl.System.Transactions.TransactionTable.Remove(tx);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(tx)
                }
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 7112164;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6456804,"p":[{"p":139067393,"g":{"r":0,"d":0,"h":55841687012,"f":34},"n":"SignalMethod","d":7112164,"h":51546719716,"f":34}],"m":[{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"EnterState","d":7112164,"h":4302079460,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"transactionCompletedDelegate","p":4425188}],"n":"AddOutcomeRegistrant","d":7112164,"h":8597046756,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"EndCommit","d":7112164,"h":12892014052,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"CompleteBlockingClone","d":7112164,"h":17186981348,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"CompleteAbortingClone","d":7112164,"h":21481948644,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"CreateBlockingClone","d":7112164,"h":25776915940,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"CreateAbortingClone","d":7112164,"h":30071883236,"f":32776},{"r":56229889,"p":[{"n":"tx","p":2786788}],"n":"get_Identifier","d":7112164,"h":34366850532,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"Promote","d":7112164,"h":38661817828,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"PromotedTransactionOutcome","d":7112164,"h":42956785124,"f":260},{"r":65537,"p":[{"n":"state","p":131073}],"n":"SignalCallback","d":7112164,"h":60136654308,"f":34}],"l":[{"t":139067393,"n":"s_signalMethod","d":7112164,"h":47251752420,"f":34}],"c":[{"n":".ctor","o":"$ctor$3","d":7112164,"h":64431621604,"f":4}],"h":7112164}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStateEnded; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedEnded`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedNonMSDTCEnded", ($self) => class TransactionStatePromotedNonMSDTCEnded extends $.$stl.System.Transactions.TransactionStateEnded
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                super.EnterState(tx);
                this.CommonEnterState(tx);
                if (!$.$spc.System.Threading.ThreadPool.QueueUserWorkItem$1($.$stl.System.Transactions.TransactionStatePromotedNonMSDTCEnded.SignalMethod, tx))
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException$1(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.UnexpectedFailureOfThreadPool, null, tx === null ? $.$spc.System.Guid.Empty : tx.DistributedTxId);
                }
            }
            /*void */ AddOutcomeRegistrant(/*InternalTransaction*/ tx, /*TransactionCompletedEventHandler?*/ transactionCompletedDelegate)
            {
                if (transactionCompletedDelegate !== null)
                {
                    /*TransactionEventArgs*/ let args = new $.$stl.System.Transactions.TransactionEventArgs().$ctor$2();
                    args._transaction = tx._outcomeSource.InternalClone();
                    transactionCompletedDelegate.Invoke(args._transaction, args);
                }
            }
            /*void */ EndCommit(/*InternalTransaction*/ tx)
            {
                this.PromotedTransactionOutcome(tx);
            }
            /*void */ CompleteBlockingClone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ CompleteAbortingClone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ CreateBlockingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ CreateAbortingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*Guid */ get_Identifier(/*InternalTransaction*/ tx)
            {
                return tx._distributedTransactionIdentifierNonMSDTC;
            }
            /*void */ Promote(/*InternalTransaction*/ tx)
            {
            }
            /*WaitCallback?*/ static s_signalMethod = null;
            static /*WaitCallback */ get SignalMethod()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$spc.System.Threading.WaitCallback, $.$ref(() => $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCEnded.s_signalMethod, ($v) => $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCEnded.s_signalMethod = $v, $.$spc.System.Threading.WaitCallback), $.$ref(() => $.$stl.System.Transactions.TransactionState.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionState.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$spc.System.Threading.WaitCallback))().$ctor(this,  () =>
                {
                    return new $.$spc.System.Threading.WaitCallback().$ctor($.$stl.System.Transactions.TransactionStatePromotedNonMSDTCEnded, $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCEnded.SignalCallback);
                }, {"r":139067393,"n":"","d":7439844,"h":0,"f":1048578}));
            }
            static /*void */ SignalCallback(/*object*/ state)
            {
                /*InternalTransaction*/ let tx = $.$cast(state, $.$stl.System.Transactions.InternalTransaction);
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(tx)
                    {
                        tx.SignalAsyncCompletion();
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(tx)
                }
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 7439844;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6456804,"p":[{"p":139067393,"g":{"r":0,"d":0,"h":55842014692,"f":34},"n":"SignalMethod","d":7439844,"h":51547047396,"f":34}],"m":[{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"EnterState","d":7439844,"h":4302407140,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"transactionCompletedDelegate","p":4425188}],"n":"AddOutcomeRegistrant","d":7439844,"h":8597374436,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"EndCommit","d":7439844,"h":12892341732,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"CompleteBlockingClone","d":7439844,"h":17187309028,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"CompleteAbortingClone","d":7439844,"h":21482276324,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"CreateBlockingClone","d":7439844,"h":25777243620,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"CreateAbortingClone","d":7439844,"h":30072210916,"f":32776},{"r":56229889,"p":[{"n":"tx","p":2786788}],"n":"get_Identifier","d":7439844,"h":34367178212,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"Promote","d":7439844,"h":38662145508,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"PromotedTransactionOutcome","d":7439844,"h":42957112804,"f":260},{"r":65537,"p":[{"n":"state","p":131073}],"n":"SignalCallback","d":7439844,"h":60136981988,"f":34}],"l":[{"t":139067393,"n":"s_signalMethod","d":7439844,"h":47252080100,"f":34}],"c":[{"n":".ctor","o":"$ctor$3","d":7439844,"h":64431949284,"f":4}],"h":7439844}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStateEnded; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedNonMSDTCEnded`; }
        });
        
        $asm.$cls("$stl.System.Transactions.EnterpriseServices", ($self) => class EnterpriseServices
        {
            static /*bool */ get EnterpriseServicesOk()
            {
                return false;
            }
            static /*void */ VerifyEnterpriseServicesOk()
            {
                if (!$.$stl.System.Transactions.EnterpriseServices.EnterpriseServicesOk)
                {
                    $.$stl.System.Transactions.EnterpriseServices.ThrowNotSupported();
                }
            }
            static /*Transaction? */ GetContextTransaction()
            {
                if ($.$stl.System.Transactions.EnterpriseServices.EnterpriseServicesOk)
                {
                    $.$stl.System.Transactions.EnterpriseServices.ThrowNotSupported();
                }
                return null;
            }
            /*bool*/ static CreatedServiceDomain = false;
            static /*bool */ UseServiceDomainForCurrent()
            {
                return false;
            }
            static /*void */ PushServiceDomain()
            {
                $.$stl.System.Transactions.EnterpriseServices.ThrowNotSupported();
            }
            static /*void */ LeaveServiceDomain()
            {
                $.$stl.System.Transactions.EnterpriseServices.ThrowNotSupported();
            }
            static /*void */ ThrowNotSupported()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$14($.$stl.System.SR.EsNotSupported);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.CreatedServiceDomain = false;
                }
            }
            static $h = 2196964;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":8592131556,"f":40},"n":"EnterpriseServicesOk","d":2196964,"h":4297164260,"f":40},{"p":262145,"g":{"r":0,"d":0,"h":30066968036,"f":40},"s":{"r":0,"d":0,"h":34361935332,"f":40},"n":"CreatedServiceDomain","d":2196964,"h":25772000740,"f":40}],"m":[{"r":65537,"n":"VerifyEnterpriseServicesOk","d":2196964,"h":12887098852,"f":40},{"r":4294116,"n":"GetContextTransaction","d":2196964,"h":17182066148,"f":40},{"r":262145,"n":"UseServiceDomainForCurrent","d":2196964,"h":38656902628,"f":40},{"r":65537,"n":"PushServiceDomain","d":2196964,"h":42951869924,"f":40},{"r":65537,"n":"LeaveServiceDomain","d":2196964,"h":47246837220,"f":40},{"r":65537,"n":"ThrowNotSupported","d":2196964,"h":51541804516,"f":34}],"h":2196964}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Transactions.EnterpriseServices`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionInformation", ($self) => class TransactionInformation extends $.$spc.System.Object
        {
            /*InternalTransaction*/ _internalTransaction = null;
            $ctor$1(/*InternalTransaction*/ internalTransaction)
            {
                super.$ctor();
                {
                    this._internalTransaction = internalTransaction;
                }
                return this;
            }
            /*string */ get LocalIdentifier()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "LocalIdentifier");
                }
                try
                {
                    return this._internalTransaction.TransactionTraceId.TransactionIdentifier;
                }
                finally
                {
                    {
                        if (etwLog.IsEnabled())
                        {
                            etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "LocalIdentifier");
                        }
                    }
                }
            }
            /*Guid */ get DistributedIdentifier()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "DistributedIdentifier");
                }
                try
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                            return this._internalTransaction.State.get_Identifier(this._internalTransaction);
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                    }
                }
                finally
                {
                    {
                        if (etwLog.IsEnabled())
                        {
                            etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "DistributedIdentifier");
                        }
                    }
                }
            }
            /*DateTime */ get CreationTime()
            {
                return new $.$spc.System.DateTime().$ctor$2(this._internalTransaction.CreationTime);
            }
            /*TransactionStatus */ get Status()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "Status");
                }
                try
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                    return this._internalTransaction.State.get_Status(this._internalTransaction);
                }
                finally
                {
                    {
                        if (etwLog.IsEnabled())
                        {
                            etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "Status");
                        }
                    }
                }
            }
            static $h = 4752868;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17184622052,"f":1},"n":"LocalIdentifier","d":4752868,"h":12889654756,"f":1},{"p":56229889,"g":{"r":0,"d":0,"h":25774556644,"f":1},"n":"DistributedIdentifier","d":4752868,"h":21479589348,"f":1},{"p":34209793,"g":{"r":0,"d":0,"h":34364491236,"f":1},"n":"CreationTime","d":4752868,"h":30069523940,"f":1},{"p":8422884,"g":{"r":0,"d":0,"h":42954425828,"f":1},"n":"Status","d":4752868,"h":38659458532,"f":1}],"l":[{"t":2786788,"n":"_internalTransaction","d":4752868,"h":4299720164,"f":2}],"c":[{"p":[{"n":"internalTransaction","p":2786788}],"n":".ctor","o":"$ctor$1","d":4752868,"h":8594687460,"f":8}],"h":4752868}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Transactions.TransactionInformation`; }
        });
        
        $asm.$cls("$stl.System.Transactions.Configuration.AppSettings", ($self) => class AppSettings
        {
            /*bool*/ static s_settingsInitialized = false;
            /*object*/ static s_appSettingsLock = null;
            /*bool*/ static s_includeDistributedTxIdInExceptionMessage = false;
            static /*void */ EnsureSettingsLoaded()
            {
                if (!$.$stl.System.Transactions.Configuration.AppSettings.s_settingsInitialized)
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter($.$stl.System.Transactions.Configuration.AppSettings.s_appSettingsLock)
                        {
                            if (!$.$stl.System.Transactions.Configuration.AppSettings.s_settingsInitialized)
                            {
                                $.$stl.System.Transactions.Configuration.AppSettings.s_includeDistributedTxIdInExceptionMessage = false;
                                $.$stl.System.Transactions.Configuration.AppSettings.s_settingsInitialized = true;
                            }
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit($.$stl.System.Transactions.Configuration.AppSettings.s_appSettingsLock)
                    }
                }
            }
            static /*bool */ get IncludeDistributedTxIdInExceptionMessage()
            {
                $.$stl.System.Transactions.Configuration.AppSettings.EnsureSettingsLoaded();
                return $.$stl.System.Transactions.Configuration.AppSettings.s_includeDistributedTxIdInExceptionMessage;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_appSettingsLock = new $.$spc.System.Object().$ctor();
                }
            }
            static $h = 624100;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":25770427876,"f":40},"n":"IncludeDistributedTxIdInExceptionMessage","d":624100,"h":21475460580,"f":40}],"m":[{"r":65537,"n":"EnsureSettingsLoaded","d":624100,"h":17180493284,"f":34}],"l":[{"t":262145,"n":"s_settingsInitialized","d":624100,"h":4295591396,"f":34},{"t":131073,"n":"s_appSettingsLock","d":624100,"h":8590558692,"f":34},{"t":262145,"n":"s_includeDistributedTxIdInExceptionMessage","d":624100,"h":12885525988,"f":34}],"h":624100}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Transactions.Configuration.AppSettings`; }
        });
        
        $asm.$cls("$stl.System.Transactions.Configuration.ConfigurationStrings", ($self) => class ConfigurationStrings
        {
            /*string*/ static DefaultDistributedTransactionManagerName = null;
            /*string*/ static DefaultMaxTimeout = null;
            /*string*/ static DefaultTimeout = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.DefaultDistributedTransactionManagerName = "";
                }
                {
                    this.DefaultMaxTimeout = "00:10:00";
                }
                {
                    this.DefaultTimeout = "00:01:00";
                }
            }
            static $h = 689636;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"DefaultDistributedTransactionManagerName","d":689636,"h":4295656932,"f":40},{"t":1310721,"n":"DefaultMaxTimeout","d":689636,"h":8590624228,"f":40},{"t":1310721,"n":"DefaultTimeout","d":689636,"h":12885591524,"f":40}],"h":689636}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Transactions.Configuration.ConfigurationStrings`; }
        });
        
        $asm.$cls("$stl.System.Transactions.Configuration.DefaultSettingsSection", ($self) => class DefaultSettingsSection extends $.$spc.System.Object
        {
            /*DefaultSettingsSection*/ static s_section = null;
            /*TimeSpan*/ static s_timeout;
            static /*DefaultSettingsSection */ GetSection()
            {
                return $.$stl.System.Transactions.Configuration.DefaultSettingsSection.s_section;
            }
            /*string*/ static DistributedTransactionManagerName = null;
            static /*TimeSpan */ get Timeout()
            {
                return $.$stl.System.Transactions.Configuration.DefaultSettingsSection.s_timeout;
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_section = new $.$stl.System.Transactions.Configuration.DefaultSettingsSection().$ctor$1();
                }
                {
                    this.s_timeout = $.$spc.System.TimeSpan.Parse("00:01:00"/*ConfigurationStrings.DefaultTimeout*/);
                }
                {
                    this.DistributedTransactionManagerName = "";
                }
            }
            static $h = 755172;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":25770558948,"f":33},"s":{"r":0,"d":0,"h":30065526244,"f":33},"n":"DistributedTransactionManagerName","d":755172,"h":21475591652,"f":33},{"p":140705793,"g":{"r":0,"d":0,"h":38655460836,"f":33},"n":"Timeout","d":755172,"h":34360493540,"f":33}],"m":[{"r":755172,"n":"GetSection","d":755172,"h":12885657060,"f":40}],"l":[{"t":755172,"n":"s_section","d":755172,"h":4295722468,"f":34},{"t":140705793,"n":"s_timeout","d":755172,"h":8590689764,"f":34}],"c":[{"n":".ctor","o":"$ctor$1","d":755172,"h":42950428132,"f":1}],"h":755172}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Transactions.Configuration.DefaultSettingsSection`; }
        });
        
        $asm.$cls("$stl.System.Transactions.Configuration.MachineSettingsSection", ($self) => class MachineSettingsSection extends $.$spc.System.Object
        {
            /*MachineSettingsSection*/ static s_section = null;
            /*TimeSpan*/ static s_maxTimeout;
            static /*MachineSettingsSection */ GetSection()
            {
                return $.$stl.System.Transactions.Configuration.MachineSettingsSection.s_section;
            }
            static /*TimeSpan */ get MaxTimeout()
            {
                return $.$stl.System.Transactions.Configuration.MachineSettingsSection.s_maxTimeout;
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_section = new $.$stl.System.Transactions.Configuration.MachineSettingsSection().$ctor$1();
                }
                {
                    this.s_maxTimeout = $.$spc.System.TimeSpan.Parse("00:10:00"/*ConfigurationStrings.DefaultMaxTimeout*/);
                }
            }
            static $h = 820708;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":140705793,"g":{"r":0,"d":0,"h":21475657188,"f":33},"n":"MaxTimeout","d":820708,"h":17180689892,"f":33}],"m":[{"r":820708,"n":"GetSection","d":820708,"h":12885722596,"f":40}],"l":[{"t":820708,"n":"s_section","d":820708,"h":4295788004,"f":34},{"t":140705793,"n":"s_maxTimeout","d":820708,"h":8590755300,"f":34}],"c":[{"n":".ctor","o":"$ctor$1","d":820708,"h":25770624484,"f":1}],"h":820708}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Transactions.Configuration.MachineSettingsSection`; }
        });
        
        $asm.$cls("$stl.System.SR", ($self) => class SR
        {
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$stl.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$stl.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$stl.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$stl.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$stl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$stl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$stl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$stl.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$stl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$stl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$stl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$stl.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$stl.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("System.Transactions.Local", $.$stl.System.SR.$type.Assembly);
                    $.$stl.System.SR.s_resourceManager = temp;
                }
                return $.$stl.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$stl.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$stl.System.SR.resourceCulture = value;
            }
            static /*string */ get AsyncFlowAndESInteropNotSupported()
            {
                return "TransactionScope with TransactionScopeAsyncFlowOption.Enabled option is not supported when the TransactionScope is used within Enterprise Service context with Automatic or Full EnterpriseServicesInteropOption enabled in parent scope.";
            }
            static /*string */ get BadAsyncResult()
            {
                return "The IAsyncResult parameter must be the same parameter returned by BeginCommit.";
            }
            static /*string */ get BadResourceManagerId()
            {
                return "Resource Manager Identifiers cannot be Guid.Empty.";
            }
            static /*string */ get CannotPromoteSnapshot()
            {
                return "Transactions with IsolationLevel Snapshot cannot be promoted.";
            }
            static /*string */ get CannotSetCurrent()
            {
                return "Current cannot be set directly when Com+ Interop is enabled.";
            }
            static /*string */ get CurrentDelegateSet()
            {
                return "The delegate for an external current can only be set once.";
            }
            static /*string */ get DisposeScope()
            {
                return "The current TransactionScope is already complete. You should dispose the TransactionScope.";
            }
            static /*string */ get EnlistmentStateException()
            {
                return "The operation is not valid for the current state of the enlistment.";
            }
            static /*string */ get EsNotSupported()
            {
                return "Com+ Interop features cannot be supported.";
            }
            static /*string */ get InternalError()
            {
                return "Internal Error";
            }
            static /*string */ get InvalidArgument()
            {
                return "The argument is invalid.";
            }
            static /*string */ get InvalidIPromotableSinglePhaseNotificationSpecified()
            {
                return "The specified IPromotableSinglePhaseNotification is not the same as the one provided to EnlistPromotableSinglePhase.";
            }
            static /*string */ get InvalidRecoveryInformation()
            {
                return "Transaction Manager in the Recovery Information does not match the configured transaction manager.";
            }
            static /*string */ get InvalidScopeThread()
            {
                return "A TransactionScope must be disposed on the same thread that it was created.";
            }
            static /*string */ get PromotionFailed()
            {
                return "There was an error promoting the transaction to a distributed transaction.";
            }
            static /*string */ get PromotedReturnedInvalidValue()
            {
                return "The Promote method returned an invalid value for the distributed transaction.";
            }
            static /*string */ get PromotedTransactionExists()
            {
                return "The transaction returned from Promote already exists as a distributed transaction.";
            }
            static /*string */ get TooLate()
            {
                return "It is too late to add enlistments to this transaction.";
            }
            static /*string */ get TraceTransactionTimeout()
            {
                return "Transaction Timeout";
            }
            static /*string */ get TransactionAborted()
            {
                return "The transaction has aborted.";
            }
            static /*string */ get TransactionAlreadyCompleted()
            {
                return "DependentTransaction.Complete or CommittableTransaction.Commit has already been called for this transaction.";
            }
            static /*string */ get TransactionIndoubt()
            {
                return "The transaction is in doubt.";
            }
            static /*string */ get TransactionManagerCommunicationException()
            {
                return "Communication with the underlying transaction manager has failed.";
            }
            static /*string */ get TransactionScopeComplete()
            {
                return "The current TransactionScope is already complete.";
            }
            static /*string */ get TransactionScopeIncorrectCurrent()
            {
                return "Transaction.Current has changed inside of the TransactionScope.";
            }
            static /*string */ get TransactionScopeInvalidNesting()
            {
                return "TransactionScope nested incorrectly.";
            }
            static /*string */ get TransactionScopeIsolationLevelDifferentFromTransaction()
            {
                return "The transaction specified for TransactionScope has a different IsolationLevel than the value requested for the scope.";
            }
            static /*string */ get TransactionScopeTimerObjectInvalid()
            {
                return "TransactionScope timer object is invalid.";
            }
            static /*string */ get TransactionStateException()
            {
                return "The operation is not valid for the state of the transaction.";
            }
            static /*string */ get UnexpectedFailureOfThreadPool()
            {
                return "There was an unexpected failure of QueueUserWorkItem.";
            }
            static /*string */ get UnexpectedTimerFailure()
            {
                return "There was an unexpected failure of a timer.";
            }
            static /*string */ get UnrecognizedRecoveryInformation()
            {
                return "The RecoveryInformation provided is not recognized by this version of System.Transactions.";
            }
            static /*string */ get VolEnlistNoRecoveryInfo()
            {
                return "Volatile enlistments do not generate recovery information.";
            }
            static /*string */ get DistributedTxIDInTransactionException()
            {
                return "{0} Distributed Transaction ID is {1}";
            }
            static /*string */ FormatDistributedTxIDInTransactionException(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("{0} Distributed Transaction ID is {1}", arg1, arg2);
            }
            static /*string */ get PromoterTypeInvalid()
            {
                return "The specified PromoterType is invalid.";
            }
            static /*string */ get PromoterTypeUnrecognized()
            {
                return "There is a promotable enlistment for the transaction which has a PromoterType value that is not recognized by System.Transactions. {0}";
            }
            static /*string */ FormatPromoterTypeUnrecognized(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("There is a promotable enlistment for the transaction which has a PromoterType value that is not recognized by System.Transactions. {0}", arg1);
            }
            static /*string */ get DistributedNotSupported()
            {
                return "This platform does not support distributed transactions.";
            }
            static /*string */ get TraceSourceOletx()
            {
                return "[Distributed]";
            }
            static /*string */ get TraceConfiguredDefaultTimeoutAdjusted()
            {
                return "Configured DefaultTimeout is greater than configured DefaultMaximumTimeout - adjusting down to DefaultMaximumTimeout";
            }
            static /*string */ get TraceMethodEntered()
            {
                return "Method Entered";
            }
            static /*string */ get TraceMethodExited()
            {
                return "Method Exited";
            }
            static /*string */ get OperationInvalidOnAnEmptyDocument()
            {
                return "The operation is invalid because the document is empty.";
            }
            static /*string */ get CannotAddToClosedDocument()
            {
                return "Cannot add an element to a closed document.";
            }
            static /*string */ get TextNodeAlreadyPopulated()
            {
                return "The text node already has a value.";
            }
            static /*string */ get TraceEnlistment()
            {
                return "Enlistment Created";
            }
            static /*string */ get TraceTransactionPromoted()
            {
                return "Transaction Promoted";
            }
            static /*string */ get TraceEnlistmentNotificationCall()
            {
                return "Enlistment Notification Call";
            }
            static /*string */ get TraceEnlistmentCallbackPositive()
            {
                return "Enlistment Callback Positive";
            }
            static /*string */ get TraceEnlistmentCallbackNegative()
            {
                return "Enlistment Callback Negative";
            }
            static /*string */ get DocumentAlreadyClosed()
            {
                return "Cannot close an element on a closed document.";
            }
            static /*string */ get TraceInternalError()
            {
                return "Internal Error";
            }
            static /*string */ get TraceInvalidOperationException()
            {
                return "InvalidOperationException Thrown";
            }
            static /*string */ get TraceExceptionConsumed()
            {
                return "Exception Consumed";
            }
            static /*string */ get TraceTransactionException()
            {
                return "TransactionException Thrown";
            }
            static /*string */ get TraceTransactionDeserialized()
            {
                return "Transaction Deserialized";
            }
            static /*string */ get TraceTransactionSerialized()
            {
                return "Transaction Serialized";
            }
            static /*string */ get TraceTransactionManagerCreated()
            {
                return "Transaction Manager Instance Created";
            }
            static /*string */ get TraceReenlist()
            {
                return "TransactionManager.Reenlist Called";
            }
            static /*string */ get TraceTransactionCreated()
            {
                return "Transaction Created";
            }
            static /*string */ get TraceTransactionCommitCalled()
            {
                return "CommittableTransaction.Commit Called";
            }
            static /*string */ get TraceTransactionCommitted()
            {
                return "Transaction Committed";
            }
            static /*string */ get TraceTransactionAborted()
            {
                return "Transaction Aborted";
            }
            static /*string */ get TraceTransactionInDoubt()
            {
                return "Transaction InDoubt";
            }
            static /*string */ get TraceTransactionScopeCreated()
            {
                return "TransactionScope Created";
            }
            static /*string */ get TraceTransactionScopeDisposed()
            {
                return "TransactionScope Disposed";
            }
            static /*string */ get ProxyCannotSupportMultipleNodeNames()
            {
                return "MSDTC Proxy cannot support specification of different node names in the same process.";
            }
            static /*string */ get CannotSupportNodeNameSpecification()
            {
                return "Cannot support specification of node name for the distributed transaction manager through System.Transactions due to MSDTC Proxy version.";
            }
            static /*string */ get FailedToCreateTraceSource()
            {
                return "Failed to create trace source.";
            }
            static /*string */ get FailedToInitializeTraceSource()
            {
                return "Failed to initialize trace source.";
            }
            static /*string */ get TraceRecoveryComplete()
            {
                return "TransactionManager.RecoveryComplete Called";
            }
            static /*string */ get TraceCloneCreated()
            {
                return "Clone Created";
            }
            static /*string */ get TraceDependentCloneComplete()
            {
                return "Dependent Clone Completed";
            }
            static /*string */ get TraceDependentCloneCreated()
            {
                return "Dependent Clone Created";
            }
            static /*string */ get TraceTransactionScopeTimeout()
            {
                return "TransactionScope Timeout";
            }
            static /*string */ get TraceTransactionRollbackCalled()
            {
                return "Transaction.Rollback Called";
            }
            static /*string */ get TraceFailure()
            {
                return "Trace Event Type: {0}\\nTrace Code: {1}\\nTrace Description {2}\\nObject: {3}";
            }
            static /*string */ FormatTraceFailure(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3, /*object*/ arg4)
            {
                return $.$spc.System.String.Format$4("Trace Event Type: {0}\\nTrace Code: {1}\\nTrace Description {2}\\nObject: {3}", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ arg1, arg2, arg3, arg4 ]));
            }
            static /*string */ get OletxEnlistmentUnexpectedTransactionStatus()
            {
                return "Internal Error - Unexpected transaction status value in enlistment constructor.";
            }
            static /*string */ get UnableToDeserializeTransaction()
            {
                return "Unable to deserialize the transaction.";
            }
            static /*string */ get UnableToDeserializeTransactionInternalError()
            {
                return "Internal Error - Unable to deserialize the transaction.";
            }
            static /*string */ get TransactionAlreadyOver()
            {
                return "The transaction has already been implicitly or explicitly committed or aborted.";
            }
            static /*string */ get EventLogValue()
            {
                return "Process Name: {0}\\nProcess Id: {1}\\nCode: {2}\\nDescription: {3}";
            }
            static /*string */ FormatEventLogValue(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3, /*object*/ arg4)
            {
                return $.$spc.System.String.Format$4("Process Name: {0}\\nProcess Id: {1}\\nCode: {2}\\nDescription: {3}", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ arg1, arg2, arg3, arg4 ]));
            }
            static /*string */ get EventLogSourceValue()
            {
                return "Source: {0}";
            }
            static /*string */ FormatEventLogSourceValue(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Source: {0}", arg1);
            }
            static /*string */ get EventLogExceptionValue()
            {
                return "Exception: {0}";
            }
            static /*string */ FormatEventLogExceptionValue(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Exception: {0}", arg1);
            }
            static /*string */ get EventLogEventIdValue()
            {
                return "Event ID: {0}";
            }
            static /*string */ FormatEventLogEventIdValue(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Event ID: {0}", arg1);
            }
            static /*string */ get EventLogTraceValue()
            {
                return "Other information : {0}";
            }
            static /*string */ FormatEventLogTraceValue(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Other information : {0}", arg1);
            }
            static /*string */ get TraceTransactionScopeCurrentTransactionChanged()
            {
                return "TransactionScope Current Transaction Changed";
            }
            static /*string */ get TraceTransactionScopeNestedIncorrectly()
            {
                return "TransactionScope Nested Incorrectly";
            }
            static /*string */ get TraceTransactionScopeIncomplete()
            {
                return "TransactionScope Incomplete";
            }
            static /*string */ get UnableToGetNotificationShimFactory()
            {
                return "Distributed transaction manager is unable to create the NotificationShimFactory object.";
            }
            static /*string */ get CannotGetTransactionIdentifier()
            {
                return "Unable to obtain the transaction identifier.";
            }
            static /*string */ get ReenlistAfterRecoveryComplete()
            {
                return "Calling TransactionManager.Reenlist is not allowed after TransactionManager.RecoveryComplete is called for a given resource manager identifier.";
            }
            static /*string */ get DuplicateRecoveryComplete()
            {
                return "RecoveryComplete must not be called twice by the same resource manager identifier instance.";
            }
            static /*string */ get DtcTransactionManagerUnavailable()
            {
                return "MSDTC Transaction Manager is unavailable.";
            }
            static /*string */ get NetworkTransactionsDisabled()
            {
                return "Network access for Distributed Transaction Manager (MSDTC) has been disabled. Please enable DTC for network access in the security configuration for MSDTC using the Component Services Administrative tool.";
            }
            static /*string */ get TraceSourceLtm()
            {
                return "[Lightweight]";
            }
            static /*string */ get TraceCodeAppDomainUnloading()
            {
                return "AppDomain unloading.";
            }
            static /*string */ get UnhandledException()
            {
                return "Unhandled Exception";
            }
            static /*string */ get ResourceManagerIdDoesNotMatchRecoveryInformation()
            {
                return "The resourceManagerIdentifier does not match the contents of the specified recovery information.";
            }
            static /*string */ get OletxTooManyEnlistments()
            {
                return "The distributed transaction manager does not allow any more durable enlistments on the transaction.";
            }
            static /*string */ get FailedToTraceEvent()
            {
                return "Failed to trace event: {0}.";
            }
            static /*string */ FormatFailedToTraceEvent(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Failed to trace event: {0}.", arg1);
            }
            static /*string */ get TraceSourceBase()
            {
                return "[Base]";
            }
            static /*string */ get DistributedNotSupportedOn32Bits()
            {
                return "Distributed transactions are currently unsupported in 32-bit processes.";
            }
            static /*string */ get ImplicitDistributedTransactionsDisabled()
            {
                return "Implicit distributed transactions have not been enabled. If you're intentionally starting a distributed transaction, set TransactionManager.ImplicitDistributedTransactions to true.";
            }
            static /*string */ get ImplicitDistributedTransactionsCannotBeChanged()
            {
                return "TransactionManager.ImplicitDistributedTransaction cannot be changed once set, or once System.Transactions distributed transactions have been initialized. Set this flag once at the start of your program.";
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$stl.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 165348;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":165348}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$stl.System.Transactions.CheapUnfairReaderWriterLock", ($self) => class CheapUnfairReaderWriterLock extends $.$spc.System.Object
        {
            /*object?*/ _writerFinishedEvent = null;
            /*int*/ _readersIn = 0;
            /*int*/ _readersOut = 0;
            /*bool*/ _writerPresent = false;
            /*object?*/ _syncRoot = null;
            /*int*/ static MAX_SPIN_COUNT = 100;
            /*int*/ static SLEEP_TIME = 500;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*object */ get SyncRoot()
            {
                if (this._syncRoot === null)
                {
                    $.$spc.System.Threading.Interlocked.CompareExchange$2($.$ref(() => this._syncRoot, ($v) => this._syncRoot = $v, $.$spc.System.Object), new $.$spc.System.Object().$ctor(), null);
                }
                return this._syncRoot;
            }
            /*bool */ get ReadersPresent()
            {
                return this._readersIn !== this._readersOut;
            }
            /*ManualResetEvent */ get WriterFinishedEvent()
            {
                if (this._writerFinishedEvent === null)
                {
                    $.$spc.System.Threading.Interlocked.CompareExchange$2($.$ref(() => this._writerFinishedEvent, ($v) => this._writerFinishedEvent = $v, $.$spc.System.Object), new $.$spc.System.Threading.ManualResetEvent().$ctor$8(true), null);
                }
                return $.$cast(this._writerFinishedEvent, $.$spc.System.Threading.ManualResetEvent);
            }
            /*int */ EnterReadLock()
            {
                /*int*/ let readerIndex;
                do
                {
                    if (this._writerPresent)
                    {
                        this.WriterFinishedEvent.WaitOne$2();
                    }
                    readerIndex = $.$spc.System.Threading.Interlocked.Increment($.$ref(() => this._readersIn, ($v) => this._readersIn = $v, $.$spc.System.Int32));
                    if (!this._writerPresent)
                    {
                        break;
                    }
                    $.$spc.System.Threading.Interlocked.Decrement($.$ref(() => this._readersIn, ($v) => this._readersIn = $v, $.$spc.System.Int32));
                }
                while(true);
                return readerIndex;
            }
            /*void */ EnterWriteLock()
            {
                $.$spc.System.Threading.Monitor.Enter(this.SyncRoot);
                this._writerPresent = true;
                this.WriterFinishedEvent.Reset();
                do
                {
                    /*int*/ let i = 0;
                    while(this.ReadersPresent && i < 100/*MAX_SPIN_COUNT*/)
                    {
                        $.$spc.System.Threading.Thread.Sleep(0);
                        i++;
                    }
                    if (this.ReadersPresent)
                    {
                        $.$spc.System.Threading.Thread.Sleep(500/*SLEEP_TIME*/);
                    }
                }
                while(this.ReadersPresent);
            }
            /*void */ ExitReadLock()
            {
                $.$spc.System.Threading.Interlocked.Increment($.$ref(() => this._readersOut, ($v) => this._readersOut = $v, $.$spc.System.Int32));
            }
            /*void */ ExitWriteLock()
            {
                try
                {
                    this._writerPresent = false;
                    this.WriterFinishedEvent.Set$1();
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Exit(this.SyncRoot);
                    }
                }
            }
            static $h = 493028;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":131073,"g":{"r":0,"d":0,"h":42950165988,"f":2},"n":"SyncRoot","d":493028,"h":38655198692,"f":2},{"p":262145,"g":{"r":0,"d":0,"h":51540100580,"f":2},"n":"ReadersPresent","d":493028,"h":47245133284,"f":2},{"p":128319489,"g":{"r":0,"d":0,"h":60130035172,"f":2},"n":"WriterFinishedEvent","d":493028,"h":55835067876,"f":2}],"m":[{"r":655361,"n":"EnterReadLock","d":493028,"h":64425002468,"f":1},{"r":65537,"n":"EnterWriteLock","d":493028,"h":68719969764,"f":1},{"r":65537,"n":"ExitReadLock","d":493028,"h":73014937060,"f":1},{"r":65537,"n":"ExitWriteLock","d":493028,"h":77309904356,"f":1}],"l":[{"t":131073,"n":"_writerFinishedEvent","d":493028,"h":4295460324,"f":2},{"t":655361,"n":"_readersIn","d":493028,"h":8590427620,"f":2},{"t":655361,"n":"_readersOut","d":493028,"h":12885394916,"f":2},{"t":262145,"n":"_writerPresent","d":493028,"h":17180362212,"f":2},{"t":131073,"n":"_syncRoot","d":493028,"h":21475329508,"f":2},{"t":655361,"n":"MAX_SPIN_COUNT","d":493028,"h":25770296804,"f":34},{"t":655361,"n":"SLEEP_TIME","d":493028,"h":30065264100,"f":34}],"c":[{"n":".ctor","o":"$ctor$1","d":493028,"h":34360231396,"f":1}],"h":493028}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Transactions.CheapUnfairReaderWriterLock`; }
        });
        
        $asm.$cls("$stl.System.Obsoletions", ($self) => class Obsoletions
        {
            /*string*/ static SharedUrlFormat = null;
            /*string*/ static SystemTextEncodingUTF7Message = null;
            /*string*/ static SystemTextEncodingUTF7DiagId = null;
            /*string*/ static PrincipalPermissionAttributeMessage = null;
            /*string*/ static PrincipalPermissionAttributeDiagId = null;
            /*string*/ static CodeAccessSecurityMessage = null;
            /*string*/ static CodeAccessSecurityDiagId = null;
            /*string*/ static ConstrainedExecutionRegionMessage = null;
            /*string*/ static ConstrainedExecutionRegionDiagId = null;
            /*string*/ static GlobalAssemblyCacheMessage = null;
            /*string*/ static GlobalAssemblyCacheDiagId = null;
            /*string*/ static ThreadAbortMessage = null;
            /*string*/ static ThreadResetAbortMessage = null;
            /*string*/ static ThreadAbortDiagId = null;
            /*string*/ static DefaultCryptoAlgorithmsMessage = null;
            /*string*/ static DefaultCryptoAlgorithmsDiagId = null;
            /*string*/ static CreatePdbGeneratorMessage = null;
            /*string*/ static CreatePdbGeneratorDiagId = null;
            /*string*/ static AuthenticationManagerMessage = null;
            /*string*/ static AuthenticationManagerDiagId = null;
            /*string*/ static RemotingApisMessage = null;
            /*string*/ static RemotingApisDiagId = null;
            /*string*/ static BinaryFormatterMessage = null;
            /*string*/ static BinaryFormatterDiagId = null;
            /*string*/ static CodeBaseMessage = null;
            /*string*/ static CodeBaseDiagId = null;
            /*string*/ static EscapeUriStringMessage = null;
            /*string*/ static EscapeUriStringDiagId = null;
            /*string*/ static WebRequestMessage = null;
            /*string*/ static WebRequestDiagId = null;
            /*string*/ static DisablePrivateReflectionAttributeMessage = null;
            /*string*/ static DisablePrivateReflectionAttributeDiagId = null;
            /*string*/ static GetContextInfoMessage = null;
            /*string*/ static GetContextInfoDiagId = null;
            /*string*/ static StrongNameKeyPairMessage = null;
            /*string*/ static StrongNameKeyPairDiagId = null;
            /*string*/ static ReflectionOnlyLoadingMessage = null;
            /*string*/ static ReflectionOnlyLoadingDiagId = null;
            /*string*/ static RuntimeEnvironmentMessage = null;
            /*string*/ static RuntimeEnvironmentDiagId = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesMessage = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesDiagId = null;
            /*string*/ static DerivedCryptographicTypesMessage = null;
            /*string*/ static DerivedCryptographicTypesDiagId = null;
            /*string*/ static RijndaelMessage = null;
            /*string*/ static RijndaelDiagId = null;
            /*string*/ static RNGCryptoServiceProviderMessage = null;
            /*string*/ static RNGCryptoServiceProviderDiagId = null;
            /*string*/ static AppDomainCreateUnloadMessage = null;
            /*string*/ static AppDomainCreateUnloadDiagId = null;
            /*string*/ static SuppressIldasmAttributeMessage = null;
            /*string*/ static SuppressIldasmAttributeDiagId = null;
            /*string*/ static X509CertificateImmutableMessage = null;
            /*string*/ static X509CertificateImmutableDiagId = null;
            /*string*/ static PublicKeyPropertyMessage = null;
            /*string*/ static PublicKeyPropertyDiagId = null;
            /*string*/ static X509CertificatePrivateKeyMessage = null;
            /*string*/ static X509CertificatePrivateKeyDiagId = null;
            /*string*/ static ProduceLegacyHmacValuesMessage = null;
            /*string*/ static ProduceLegacyHmacValuesDiagId = null;
            /*string*/ static UseManagedSha1Message = null;
            /*string*/ static UseManagedSha1DiagId = null;
            /*string*/ static CryptoConfigEncodeOIDMessage = null;
            /*string*/ static CryptoConfigEncodeOIDDiagId = null;
            /*string*/ static CorruptedStateRecoveryMessage = null;
            /*string*/ static CorruptedStateRecoveryDiagId = null;
            /*string*/ static Rfc2898CryptDeriveKeyMessage = null;
            /*string*/ static Rfc2898CryptDeriveKeyDiagId = null;
            /*string*/ static CmsSignerCspParamsCtorMessage = null;
            /*string*/ static CmsSignerCspParamsCtorDiagId = null;
            /*string*/ static SignerInfoCounterSigMessage = null;
            /*string*/ static SignerInfoCounterSigDiagId = null;
            /*string*/ static RegexCompileToAssemblyMessage = null;
            /*string*/ static RegexCompileToAssemblyDiagId = null;
            /*string*/ static AssemblyNameMembersMessage = null;
            /*string*/ static AssemblyNameMembersDiagId = null;
            /*string*/ static SystemDataSerializationFormatBinaryMessage = null;
            /*string*/ static SystemDataSerializationFormatBinaryDiagId = null;
            /*string*/ static TlsVersion10and11Message = null;
            /*string*/ static TlsVersion10and11DiagId = null;
            /*string*/ static EncryptionPolicyMessage = null;
            /*string*/ static EncryptionPolicyDiagId = null;
            /*string*/ static EccXmlExportImportMessage = null;
            /*string*/ static EccXmlExportImportDiagId = null;
            /*string*/ static EcDhPublicKeyBlobMessage = null;
            /*string*/ static EcDhPublicKeyBlobDiagId = null;
            /*string*/ static AssemblyNameCodeBaseMessage = null;
            /*string*/ static AssemblyNameCodeBaseDiagId = null;
            /*string*/ static CryptoStringFactoryMessage = null;
            /*string*/ static CryptoStringFactoryDiagId = null;
            /*string*/ static ControlledExecutionRunMessage = null;
            /*string*/ static ControlledExecutionRunDiagId = null;
            /*string*/ static XmlSecureResolverMessage = null;
            /*string*/ static XmlSecureResolverDiagId = null;
            /*string*/ static RsaEncryptDecryptValueMessage = null;
            /*string*/ static RsaEncryptDecryptDiagId = null;
            /*string*/ static JsonSerializerOptionsAddContextMessage = null;
            /*string*/ static JsonSerializerOptionsAddContextDiagId = null;
            /*string*/ static LegacyFormatterMessage = null;
            /*string*/ static LegacyFormatterDiagId = null;
            /*string*/ static LegacyFormatterImplMessage = null;
            /*string*/ static LegacyFormatterImplDiagId = null;
            /*string*/ static RegexExtensibilityImplMessage = null;
            /*string*/ static RegexExtensibilityDiagId = null;
            /*string*/ static AesGcmTagConstructorMessage = null;
            /*string*/ static AesGcmTagConstructorDiagId = null;
            /*string*/ static ThreadVolatileReadWriteMessage = null;
            /*string*/ static ThreadVolatileReadWriteDiagId = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationMessage = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationDiagId = null;
            /*string*/ static LoadFromHashAlgorithmMessage = null;
            /*string*/ static LoadFromHashAlgorithmDiagId = null;
            /*string*/ static X509CtorCertDataObsoleteMessage = null;
            /*string*/ static X509CtorCertDataObsoleteDiagId = null;
            /*string*/ static TlsCipherAlgorithmEnumsMessage = null;
            /*string*/ static TlsCipherAlgorithmEnumsDiagId = null;
            /*string*/ static SystemEventsEventsThreadShutdownMessage = null;
            /*string*/ static SystemEventsEventsThreadShutdownDiagId = null;
            /*string*/ static Rfc2898DeriveBytesCtorMessage = null;
            /*string*/ static Rfc2898DeriveBytesCtorDiagId = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteMessage = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteDiagId = null;
            /*string*/ static XsltSettingsEnableScriptMessage = null;
            /*string*/ static XsltSettingsEnableScriptDiagId = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                }
                {
                    this.SystemTextEncodingUTF7Message = "The UTF-7 encoding is insecure and should not be used. Consider using UTF-8 instead.";
                }
                {
                    this.SystemTextEncodingUTF7DiagId = "SYSLIB0001";
                }
                {
                    this.PrincipalPermissionAttributeMessage = "PrincipalPermissionAttribute is not honored by the runtime and must not be used.";
                }
                {
                    this.PrincipalPermissionAttributeDiagId = "SYSLIB0002";
                }
                {
                    this.CodeAccessSecurityMessage = "Code Access Security is not supported or honored by the runtime.";
                }
                {
                    this.CodeAccessSecurityDiagId = "SYSLIB0003";
                }
                {
                    this.ConstrainedExecutionRegionMessage = "The Constrained Execution Region (CER) feature is not supported.";
                }
                {
                    this.ConstrainedExecutionRegionDiagId = "SYSLIB0004";
                }
                {
                    this.GlobalAssemblyCacheMessage = "The Global Assembly Cache is not supported.";
                }
                {
                    this.GlobalAssemblyCacheDiagId = "SYSLIB0005";
                }
                {
                    this.ThreadAbortMessage = "Thread.Abort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadResetAbortMessage = "Thread.ResetAbort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadAbortDiagId = "SYSLIB0006";
                }
                {
                    this.DefaultCryptoAlgorithmsMessage = "The default implementation of this cryptography algorithm is not supported.";
                }
                {
                    this.DefaultCryptoAlgorithmsDiagId = "SYSLIB0007";
                }
                {
                    this.CreatePdbGeneratorMessage = "The CreatePdbGenerator API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.CreatePdbGeneratorDiagId = "SYSLIB0008";
                }
                {
                    this.AuthenticationManagerMessage = "AuthenticationManager is not supported. Methods will no-op or throw PlatformNotSupportedException.";
                }
                {
                    this.AuthenticationManagerDiagId = "SYSLIB0009";
                }
                {
                    this.RemotingApisMessage = "This Remoting API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.RemotingApisDiagId = "SYSLIB0010";
                }
                {
                    this.BinaryFormatterMessage = "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.";
                }
                {
                    this.BinaryFormatterDiagId = "SYSLIB0011";
                }
                {
                    this.CodeBaseMessage = "Assembly.CodeBase and Assembly.EscapedCodeBase are only included for .NET Framework compatibility. Use Assembly.Location instead.";
                }
                {
                    this.CodeBaseDiagId = "SYSLIB0012";
                }
                {
                    this.EscapeUriStringMessage = "Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.";
                }
                {
                    this.EscapeUriStringDiagId = "SYSLIB0013";
                }
                {
                    this.WebRequestMessage = "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.";
                }
                {
                    this.WebRequestDiagId = "SYSLIB0014";
                }
                {
                    this.DisablePrivateReflectionAttributeMessage = "DisablePrivateReflectionAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.DisablePrivateReflectionAttributeDiagId = "SYSLIB0015";
                }
                {
                    this.GetContextInfoMessage = "Use the Graphics.GetContextInfo overloads that accept arguments for better performance and fewer allocations.";
                }
                {
                    this.GetContextInfoDiagId = "SYSLIB0016";
                }
                {
                    this.StrongNameKeyPairMessage = "Strong name signing is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.StrongNameKeyPairDiagId = "SYSLIB0017";
                }
                {
                    this.ReflectionOnlyLoadingMessage = "ReflectionOnly loading is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ReflectionOnlyLoadingDiagId = "SYSLIB0018";
                }
                {
                    this.RuntimeEnvironmentMessage = "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.";
                }
                {
                    this.RuntimeEnvironmentDiagId = "SYSLIB0019";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesMessage = "JsonSerializerOptions.IgnoreNullValues is obsolete. To ignore null values when serializing, set DefaultIgnoreCondition to JsonIgnoreCondition.WhenWritingNull.";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesDiagId = "SYSLIB0020";
                }
                {
                    this.DerivedCryptographicTypesMessage = "Derived cryptographic types are obsolete. Use the Create method on the base type instead.";
                }
                {
                    this.DerivedCryptographicTypesDiagId = "SYSLIB0021";
                }
                {
                    this.RijndaelMessage = "The Rijndael and RijndaelManaged types are obsolete. Use Aes instead.";
                }
                {
                    this.RijndaelDiagId = "SYSLIB0022";
                }
                {
                    this.RNGCryptoServiceProviderMessage = "RNGCryptoServiceProvider is obsolete. To generate a random number, use one of the RandomNumberGenerator static methods instead.";
                }
                {
                    this.RNGCryptoServiceProviderDiagId = "SYSLIB0023";
                }
                {
                    this.AppDomainCreateUnloadMessage = "Creating and unloading AppDomains is not supported and throws an exception.";
                }
                {
                    this.AppDomainCreateUnloadDiagId = "SYSLIB0024";
                }
                {
                    this.SuppressIldasmAttributeMessage = "SuppressIldasmAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.SuppressIldasmAttributeDiagId = "SYSLIB0025";
                }
                {
                    this.X509CertificateImmutableMessage = "X509Certificate and X509Certificate2 are immutable. Use X509CertificateLoader to create a new certificate.";
                }
                {
                    this.X509CertificateImmutableDiagId = "SYSLIB0026";
                }
                {
                    this.PublicKeyPropertyMessage = "PublicKey.Key is obsolete. Use the appropriate method to get the public key, such as GetRSAPublicKey.";
                }
                {
                    this.PublicKeyPropertyDiagId = "SYSLIB0027";
                }
                {
                    this.X509CertificatePrivateKeyMessage = "X509Certificate2.PrivateKey is obsolete. Use the appropriate method to get the private key, such as GetRSAPrivateKey, or use the CopyWithPrivateKey method to create a new instance with a private key.";
                }
                {
                    this.X509CertificatePrivateKeyDiagId = "SYSLIB0028";
                }
                {
                    this.ProduceLegacyHmacValuesMessage = "ProduceLegacyHmacValues is obsolete. Producing legacy HMAC values is not supported.";
                }
                {
                    this.ProduceLegacyHmacValuesDiagId = "SYSLIB0029";
                }
                {
                    this.UseManagedSha1Message = "HMACSHA1 always uses the algorithm implementation provided by the platform. Use a constructor without the useManagedSha1 parameter.";
                }
                {
                    this.UseManagedSha1DiagId = "SYSLIB0030";
                }
                {
                    this.CryptoConfigEncodeOIDMessage = "EncodeOID is obsolete. Use the ASN.1 functionality provided in System.Formats.Asn1.";
                }
                {
                    this.CryptoConfigEncodeOIDDiagId = "SYSLIB0031";
                }
                {
                    this.CorruptedStateRecoveryMessage = "Recovery from corrupted process state exceptions is not supported; HandleProcessCorruptedStateExceptionsAttribute is ignored.";
                }
                {
                    this.CorruptedStateRecoveryDiagId = "SYSLIB0032";
                }
                {
                    this.Rfc2898CryptDeriveKeyMessage = "Rfc2898DeriveBytes.CryptDeriveKey is obsolete and is not supported. Use PasswordDeriveBytes.CryptDeriveKey instead.";
                }
                {
                    this.Rfc2898CryptDeriveKeyDiagId = "SYSLIB0033";
                }
                {
                    this.CmsSignerCspParamsCtorMessage = "CmsSigner(CspParameters) is obsolete and is not supported. Use an alternative constructor instead.";
                }
                {
                    this.CmsSignerCspParamsCtorDiagId = "SYSLIB0034";
                }
                {
                    this.SignerInfoCounterSigMessage = "ComputeCounterSignature without specifying a CmsSigner is obsolete and is not supported. Use the overload that accepts a CmsSigner.";
                }
                {
                    this.SignerInfoCounterSigDiagId = "SYSLIB0035";
                }
                {
                    this.RegexCompileToAssemblyMessage = "Regex.CompileToAssembly is obsolete and not supported. Use the GeneratedRegexAttribute with the regular expression source generator instead.";
                }
                {
                    this.RegexCompileToAssemblyDiagId = "SYSLIB0036";
                }
                {
                    this.AssemblyNameMembersMessage = "AssemblyName members HashAlgorithm, ProcessorArchitecture, and VersionCompatibility are obsolete and not supported.";
                }
                {
                    this.AssemblyNameMembersDiagId = "SYSLIB0037";
                }
                {
                    this.SystemDataSerializationFormatBinaryMessage = "SerializationFormat.Binary is obsolete and should not be used. See https://aka.ms/serializationformat-binary-obsolete for more information.";
                }
                {
                    this.SystemDataSerializationFormatBinaryDiagId = "SYSLIB0038";
                }
                {
                    this.TlsVersion10and11Message = "TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.";
                }
                {
                    this.TlsVersion10and11DiagId = "SYSLIB0039";
                }
                {
                    this.EncryptionPolicyMessage = "EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.";
                }
                {
                    this.EncryptionPolicyDiagId = "SYSLIB0040";
                }
                {
                    this.EccXmlExportImportMessage = "ToXmlString and FromXmlString have no implementation for ECC types, and are obsolete. Use a standard import and export format such as ExportSubjectPublicKeyInfo or ImportSubjectPublicKeyInfo for public keys and ExportPkcs8PrivateKey or ImportPkcs8PrivateKey for private keys.";
                }
                {
                    this.EccXmlExportImportDiagId = "SYSLIB0042";
                }
                {
                    this.EcDhPublicKeyBlobMessage = "ECDiffieHellmanPublicKey.ToByteArray() and the associated constructor do not have a consistent and interoperable implementation on all platforms. Use ECDiffieHellmanPublicKey.ExportSubjectPublicKeyInfo() instead.";
                }
                {
                    this.EcDhPublicKeyBlobDiagId = "SYSLIB0043";
                }
                {
                    this.AssemblyNameCodeBaseMessage = "AssemblyName.CodeBase and AssemblyName.EscapedCodeBase are obsolete. Using them for loading an assembly is not supported.";
                }
                {
                    this.AssemblyNameCodeBaseDiagId = "SYSLIB0044";
                }
                {
                    this.CryptoStringFactoryMessage = "Cryptographic factory methods accepting an algorithm name are obsolete. Use the parameterless Create factory method on the algorithm type instead.";
                }
                {
                    this.CryptoStringFactoryDiagId = "SYSLIB0045";
                }
                {
                    this.ControlledExecutionRunMessage = "ControlledExecution.Run method may corrupt the process and should not be used in production code.";
                }
                {
                    this.ControlledExecutionRunDiagId = "SYSLIB0046";
                }
                {
                    this.XmlSecureResolverMessage = "XmlSecureResolver is obsolete. Use XmlResolver.ThrowingResolver instead when attempting to forbid XML external entity resolution.";
                }
                {
                    this.XmlSecureResolverDiagId = "SYSLIB0047";
                }
                {
                    this.RsaEncryptDecryptValueMessage = "RSA.EncryptValue and DecryptValue are not supported and throw NotSupportedException. Use RSA.Encrypt and RSA.Decrypt instead.";
                }
                {
                    this.RsaEncryptDecryptDiagId = "SYSLIB0048";
                }
                {
                    this.JsonSerializerOptionsAddContextMessage = "JsonSerializerOptions.AddContext is obsolete. To register a JsonSerializerContext, use either the TypeInfoResolver or TypeInfoResolverChain properties.";
                }
                {
                    this.JsonSerializerOptionsAddContextDiagId = "SYSLIB0049";
                }
                {
                    this.LegacyFormatterMessage = "Formatter-based serialization is obsolete and should not be used.";
                }
                {
                    this.LegacyFormatterDiagId = "SYSLIB0050";
                }
                {
                    this.LegacyFormatterImplMessage = "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.";
                }
                {
                    this.LegacyFormatterImplDiagId = "SYSLIB0051";
                }
                {
                    this.RegexExtensibilityImplMessage = "This API supports obsolete mechanisms for Regex extensibility. It is not supported.";
                }
                {
                    this.RegexExtensibilityDiagId = "SYSLIB0052";
                }
                {
                    this.AesGcmTagConstructorMessage = "AesGcm should indicate the required tag size for encryption and decryption. Use a constructor that accepts the tag size.";
                }
                {
                    this.AesGcmTagConstructorDiagId = "SYSLIB0053";
                }
                {
                    this.ThreadVolatileReadWriteMessage = "Thread.VolatileRead and Thread.VolatileWrite are obsolete. Use Volatile.Read or Volatile.Write respectively instead.";
                }
                {
                    this.ThreadVolatileReadWriteDiagId = "SYSLIB0054";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationMessage = "The underlying hardware instruction does not perform a signed saturate narrowing operation, and it always returns an unsigned result. Use the unsigned overload instead.";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationDiagId = "SYSLIB0055";
                }
                {
                    this.LoadFromHashAlgorithmMessage = "LoadFrom with a custom AssemblyHashAlgorithm is obsolete. Use overloads without an AssemblyHashAlgorithm.";
                }
                {
                    this.LoadFromHashAlgorithmDiagId = "SYSLIB0056";
                }
                {
                    this.X509CtorCertDataObsoleteMessage = "Loading certificate data through the constructor or Import is obsolete. Use X509CertificateLoader instead to load certificates.";
                }
                {
                    this.X509CtorCertDataObsoleteDiagId = "SYSLIB0057";
                }
                {
                    this.TlsCipherAlgorithmEnumsMessage = "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.";
                }
                {
                    this.TlsCipherAlgorithmEnumsDiagId = "SYSLIB0058";
                }
                {
                    this.SystemEventsEventsThreadShutdownMessage = "SystemEvents.EventsThreadShutdown callbacks are not run before the process exits. Use AppDomain.ProcessExit instead.";
                }
                {
                    this.SystemEventsEventsThreadShutdownDiagId = "SYSLIB0059";
                }
                {
                    this.Rfc2898DeriveBytesCtorMessage = "The constructors on Rfc2898DeriveBytes are obsolete. Use the static Pbkdf2 method instead.";
                }
                {
                    this.Rfc2898DeriveBytesCtorDiagId = "SYSLIB0060";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteMessage = "The Queryable MinBy and MaxBy taking an IComparer<TSource> are obsolete. Use the new ones that take an IComparer<TKey>.";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteDiagId = "SYSLIB0061";
                }
                {
                    this.XsltSettingsEnableScriptMessage = "XSLT Script blocks are not supported.";
                }
                {
                    this.XsltSettingsEnableScriptDiagId = "SYSLIB0062";
                }
            }
            static $h = 99812;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"SharedUrlFormat","d":99812,"h":4295067108,"f":40},{"t":1310721,"n":"SystemTextEncodingUTF7Message","d":99812,"h":8590034404,"f":40},{"t":1310721,"n":"SystemTextEncodingUTF7DiagId","d":99812,"h":12885001700,"f":40},{"t":1310721,"n":"PrincipalPermissionAttributeMessage","d":99812,"h":17179968996,"f":40},{"t":1310721,"n":"PrincipalPermissionAttributeDiagId","d":99812,"h":21474936292,"f":40},{"t":1310721,"n":"CodeAccessSecurityMessage","d":99812,"h":25769903588,"f":40},{"t":1310721,"n":"CodeAccessSecurityDiagId","d":99812,"h":30064870884,"f":40},{"t":1310721,"n":"ConstrainedExecutionRegionMessage","d":99812,"h":34359838180,"f":40},{"t":1310721,"n":"ConstrainedExecutionRegionDiagId","d":99812,"h":38654805476,"f":40},{"t":1310721,"n":"GlobalAssemblyCacheMessage","d":99812,"h":42949772772,"f":40},{"t":1310721,"n":"GlobalAssemblyCacheDiagId","d":99812,"h":47244740068,"f":40},{"t":1310721,"n":"ThreadAbortMessage","d":99812,"h":51539707364,"f":40},{"t":1310721,"n":"ThreadResetAbortMessage","d":99812,"h":55834674660,"f":40},{"t":1310721,"n":"ThreadAbortDiagId","d":99812,"h":60129641956,"f":40},{"t":1310721,"n":"DefaultCryptoAlgorithmsMessage","d":99812,"h":64424609252,"f":40},{"t":1310721,"n":"DefaultCryptoAlgorithmsDiagId","d":99812,"h":68719576548,"f":40},{"t":1310721,"n":"CreatePdbGeneratorMessage","d":99812,"h":73014543844,"f":40},{"t":1310721,"n":"CreatePdbGeneratorDiagId","d":99812,"h":77309511140,"f":40},{"t":1310721,"n":"AuthenticationManagerMessage","d":99812,"h":81604478436,"f":40},{"t":1310721,"n":"AuthenticationManagerDiagId","d":99812,"h":85899445732,"f":40},{"t":1310721,"n":"RemotingApisMessage","d":99812,"h":90194413028,"f":40},{"t":1310721,"n":"RemotingApisDiagId","d":99812,"h":94489380324,"f":40},{"t":1310721,"n":"BinaryFormatterMessage","d":99812,"h":98784347620,"f":40},{"t":1310721,"n":"BinaryFormatterDiagId","d":99812,"h":103079314916,"f":40},{"t":1310721,"n":"CodeBaseMessage","d":99812,"h":107374282212,"f":40},{"t":1310721,"n":"CodeBaseDiagId","d":99812,"h":111669249508,"f":40},{"t":1310721,"n":"EscapeUriStringMessage","d":99812,"h":115964216804,"f":40},{"t":1310721,"n":"EscapeUriStringDiagId","d":99812,"h":120259184100,"f":40},{"t":1310721,"n":"WebRequestMessage","d":99812,"h":124554151396,"f":40},{"t":1310721,"n":"WebRequestDiagId","d":99812,"h":128849118692,"f":40},{"t":1310721,"n":"DisablePrivateReflectionAttributeMessage","d":99812,"h":133144085988,"f":40},{"t":1310721,"n":"DisablePrivateReflectionAttributeDiagId","d":99812,"h":137439053284,"f":40},{"t":1310721,"n":"GetContextInfoMessage","d":99812,"h":141734020580,"f":40},{"t":1310721,"n":"GetContextInfoDiagId","d":99812,"h":146028987876,"f":40},{"t":1310721,"n":"StrongNameKeyPairMessage","d":99812,"h":150323955172,"f":40},{"t":1310721,"n":"StrongNameKeyPairDiagId","d":99812,"h":154618922468,"f":40},{"t":1310721,"n":"ReflectionOnlyLoadingMessage","d":99812,"h":158913889764,"f":40},{"t":1310721,"n":"ReflectionOnlyLoadingDiagId","d":99812,"h":163208857060,"f":40},{"t":1310721,"n":"RuntimeEnvironmentMessage","d":99812,"h":167503824356,"f":40},{"t":1310721,"n":"RuntimeEnvironmentDiagId","d":99812,"h":171798791652,"f":40},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesMessage","d":99812,"h":176093758948,"f":40},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesDiagId","d":99812,"h":180388726244,"f":40},{"t":1310721,"n":"DerivedCryptographicTypesMessage","d":99812,"h":184683693540,"f":40},{"t":1310721,"n":"DerivedCryptographicTypesDiagId","d":99812,"h":188978660836,"f":40},{"t":1310721,"n":"RijndaelMessage","d":99812,"h":193273628132,"f":40},{"t":1310721,"n":"RijndaelDiagId","d":99812,"h":197568595428,"f":40},{"t":1310721,"n":"RNGCryptoServiceProviderMessage","d":99812,"h":201863562724,"f":40},{"t":1310721,"n":"RNGCryptoServiceProviderDiagId","d":99812,"h":206158530020,"f":40},{"t":1310721,"n":"AppDomainCreateUnloadMessage","d":99812,"h":210453497316,"f":40},{"t":1310721,"n":"AppDomainCreateUnloadDiagId","d":99812,"h":214748464612,"f":40},{"t":1310721,"n":"SuppressIldasmAttributeMessage","d":99812,"h":219043431908,"f":40},{"t":1310721,"n":"SuppressIldasmAttributeDiagId","d":99812,"h":223338399204,"f":40},{"t":1310721,"n":"X509CertificateImmutableMessage","d":99812,"h":227633366500,"f":40},{"t":1310721,"n":"X509CertificateImmutableDiagId","d":99812,"h":231928333796,"f":40},{"t":1310721,"n":"PublicKeyPropertyMessage","d":99812,"h":236223301092,"f":40},{"t":1310721,"n":"PublicKeyPropertyDiagId","d":99812,"h":240518268388,"f":40},{"t":1310721,"n":"X509CertificatePrivateKeyMessage","d":99812,"h":244813235684,"f":40},{"t":1310721,"n":"X509CertificatePrivateKeyDiagId","d":99812,"h":249108202980,"f":40},{"t":1310721,"n":"ProduceLegacyHmacValuesMessage","d":99812,"h":253403170276,"f":40},{"t":1310721,"n":"ProduceLegacyHmacValuesDiagId","d":99812,"h":257698137572,"f":40},{"t":1310721,"n":"UseManagedSha1Message","d":99812,"h":261993104868,"f":40},{"t":1310721,"n":"UseManagedSha1DiagId","d":99812,"h":266288072164,"f":40},{"t":1310721,"n":"CryptoConfigEncodeOIDMessage","d":99812,"h":270583039460,"f":40},{"t":1310721,"n":"CryptoConfigEncodeOIDDiagId","d":99812,"h":274878006756,"f":40},{"t":1310721,"n":"CorruptedStateRecoveryMessage","d":99812,"h":279172974052,"f":40},{"t":1310721,"n":"CorruptedStateRecoveryDiagId","d":99812,"h":283467941348,"f":40},{"t":1310721,"n":"Rfc2898CryptDeriveKeyMessage","d":99812,"h":287762908644,"f":40},{"t":1310721,"n":"Rfc2898CryptDeriveKeyDiagId","d":99812,"h":292057875940,"f":40},{"t":1310721,"n":"CmsSignerCspParamsCtorMessage","d":99812,"h":296352843236,"f":40},{"t":1310721,"n":"CmsSignerCspParamsCtorDiagId","d":99812,"h":300647810532,"f":40},{"t":1310721,"n":"SignerInfoCounterSigMessage","d":99812,"h":304942777828,"f":40},{"t":1310721,"n":"SignerInfoCounterSigDiagId","d":99812,"h":309237745124,"f":40},{"t":1310721,"n":"RegexCompileToAssemblyMessage","d":99812,"h":313532712420,"f":40},{"t":1310721,"n":"RegexCompileToAssemblyDiagId","d":99812,"h":317827679716,"f":40},{"t":1310721,"n":"AssemblyNameMembersMessage","d":99812,"h":322122647012,"f":40},{"t":1310721,"n":"AssemblyNameMembersDiagId","d":99812,"h":326417614308,"f":40},{"t":1310721,"n":"SystemDataSerializationFormatBinaryMessage","d":99812,"h":330712581604,"f":40},{"t":1310721,"n":"SystemDataSerializationFormatBinaryDiagId","d":99812,"h":335007548900,"f":40},{"t":1310721,"n":"TlsVersion10and11Message","d":99812,"h":339302516196,"f":40},{"t":1310721,"n":"TlsVersion10and11DiagId","d":99812,"h":343597483492,"f":40},{"t":1310721,"n":"EncryptionPolicyMessage","d":99812,"h":347892450788,"f":40},{"t":1310721,"n":"EncryptionPolicyDiagId","d":99812,"h":352187418084,"f":40},{"t":1310721,"n":"EccXmlExportImportMessage","d":99812,"h":356482385380,"f":40},{"t":1310721,"n":"EccXmlExportImportDiagId","d":99812,"h":360777352676,"f":40},{"t":1310721,"n":"EcDhPublicKeyBlobMessage","d":99812,"h":365072319972,"f":40},{"t":1310721,"n":"EcDhPublicKeyBlobDiagId","d":99812,"h":369367287268,"f":40},{"t":1310721,"n":"AssemblyNameCodeBaseMessage","d":99812,"h":373662254564,"f":40},{"t":1310721,"n":"AssemblyNameCodeBaseDiagId","d":99812,"h":377957221860,"f":40},{"t":1310721,"n":"CryptoStringFactoryMessage","d":99812,"h":382252189156,"f":40},{"t":1310721,"n":"CryptoStringFactoryDiagId","d":99812,"h":386547156452,"f":40},{"t":1310721,"n":"ControlledExecutionRunMessage","d":99812,"h":390842123748,"f":40},{"t":1310721,"n":"ControlledExecutionRunDiagId","d":99812,"h":395137091044,"f":40},{"t":1310721,"n":"XmlSecureResolverMessage","d":99812,"h":399432058340,"f":40},{"t":1310721,"n":"XmlSecureResolverDiagId","d":99812,"h":403727025636,"f":40},{"t":1310721,"n":"RsaEncryptDecryptValueMessage","d":99812,"h":408021992932,"f":40},{"t":1310721,"n":"RsaEncryptDecryptDiagId","d":99812,"h":412316960228,"f":40},{"t":1310721,"n":"JsonSerializerOptionsAddContextMessage","d":99812,"h":416611927524,"f":40},{"t":1310721,"n":"JsonSerializerOptionsAddContextDiagId","d":99812,"h":420906894820,"f":40},{"t":1310721,"n":"LegacyFormatterMessage","d":99812,"h":425201862116,"f":40},{"t":1310721,"n":"LegacyFormatterDiagId","d":99812,"h":429496829412,"f":40},{"t":1310721,"n":"LegacyFormatterImplMessage","d":99812,"h":433791796708,"f":40},{"t":1310721,"n":"LegacyFormatterImplDiagId","d":99812,"h":438086764004,"f":40},{"t":1310721,"n":"RegexExtensibilityImplMessage","d":99812,"h":442381731300,"f":40},{"t":1310721,"n":"RegexExtensibilityDiagId","d":99812,"h":446676698596,"f":40},{"t":1310721,"n":"AesGcmTagConstructorMessage","d":99812,"h":450971665892,"f":40},{"t":1310721,"n":"AesGcmTagConstructorDiagId","d":99812,"h":455266633188,"f":40},{"t":1310721,"n":"ThreadVolatileReadWriteMessage","d":99812,"h":459561600484,"f":40},{"t":1310721,"n":"ThreadVolatileReadWriteDiagId","d":99812,"h":463856567780,"f":40},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationMessage","d":99812,"h":468151535076,"f":40},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationDiagId","d":99812,"h":472446502372,"f":40},{"t":1310721,"n":"LoadFromHashAlgorithmMessage","d":99812,"h":476741469668,"f":40},{"t":1310721,"n":"LoadFromHashAlgorithmDiagId","d":99812,"h":481036436964,"f":40},{"t":1310721,"n":"X509CtorCertDataObsoleteMessage","d":99812,"h":485331404260,"f":40},{"t":1310721,"n":"X509CtorCertDataObsoleteDiagId","d":99812,"h":489626371556,"f":40},{"t":1310721,"n":"TlsCipherAlgorithmEnumsMessage","d":99812,"h":493921338852,"f":40},{"t":1310721,"n":"TlsCipherAlgorithmEnumsDiagId","d":99812,"h":498216306148,"f":40},{"t":1310721,"n":"SystemEventsEventsThreadShutdownMessage","d":99812,"h":502511273444,"f":40},{"t":1310721,"n":"SystemEventsEventsThreadShutdownDiagId","d":99812,"h":506806240740,"f":40},{"t":1310721,"n":"Rfc2898DeriveBytesCtorMessage","d":99812,"h":511101208036,"f":40},{"t":1310721,"n":"Rfc2898DeriveBytesCtorDiagId","d":99812,"h":515396175332,"f":40},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteMessage","d":99812,"h":519691142628,"f":40},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteDiagId","d":99812,"h":523986109924,"f":40},{"t":1310721,"n":"XsltSettingsEnableScriptMessage","d":99812,"h":528281077220,"f":40},{"t":1310721,"n":"XsltSettingsEnableScriptDiagId","d":99812,"h":532576044516,"f":40}],"h":99812}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Obsoletions`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionInterop", ($self) => class TransactionInterop
        {
            static /*OletxTransaction */ ConvertToOletxTransaction(/*Transaction*/ transaction)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(transaction, "transaction");
                $.$spc.System.ObjectDisposedException.ThrowIf(transaction.Disposed, transaction);
                if (transaction._complete)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateTransactionCompletedException(transaction.DistributedTxId);
                }
                /*OletxTransaction?*/ let distributedTx = transaction.Promote();
                if (distributedTx === null)
                {
                    throw $.$stl.System.Transactions.Oletx.OletxTransaction.NotSupported();
                }
                return distributedTx;
            }
            /*Guid*/ static PromoterTypeDtc;
            static /*byte[] */ GetExportCookie(/*Transaction*/ transaction, /*byte[]*/ whereabouts)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(transaction, "transaction");
                $.$spc.System.ArgumentNullException.ThrowIfNull(whereabouts, "whereabouts");
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetExportCookie");
                }
                /*var*/ let whereaboutsCopy = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [whereabouts.length], null);
                $.$spc.System.Buffer.BlockCopy(whereabouts, 0, whereaboutsCopy, 0, whereabouts.length);
                $.$stl.System.Transactions.TransactionInterop.ConvertToOletxTransaction(transaction);
                /*byte[]*/ let cookie = $.$stl.System.Transactions.Oletx.OletxTransaction.GetExportCookie(whereaboutsCopy);
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetExportCookie");
                }
                return cookie;
            }
            static /*Transaction */ GetTransactionFromExportCookie(/*byte[]*/ cookie)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(cookie, "cookie");
                if (cookie.length < 32)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$stl.System.SR.InvalidArgument, "cookie");
                }
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetTransactionFromExportCookie");
                }
                /*var*/ let cookieCopy = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [cookie.length], null);
                $.$spc.System.Buffer.BlockCopy(cookie, 0, cookieCopy, 0, cookie.length);
                cookie = cookieCopy;
                /*var*/ let txId = new $.$spc.System.Guid().$ctor$3($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.Byte, cookie, 16, 16)));
                /*Transaction?*/ let transaction = $.$stl.System.Transactions.TransactionManager.FindPromotedTransaction(txId);
                if ($.$stl.System.Transactions.Transaction.op_Inequality(transaction, null))
                {
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodExit$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetTransactionFromExportCookie");
                    }
                    return transaction;
                }
                /*OletxTransaction*/ let dTx = $.$stl.System.Transactions.Oletx.OletxTransactionManager.GetTransactionFromExportCookie(cookieCopy, txId);
                transaction = $.$stl.System.Transactions.TransactionManager.FindOrCreatePromotedTransaction(txId, dTx);
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetTransactionFromExportCookie");
                }
                return transaction;
            }
            static /*byte[] */ GetTransmitterPropagationToken(/*Transaction*/ transaction)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(transaction, "transaction");
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetTransmitterPropagationToken");
                }
                $.$stl.System.Transactions.TransactionInterop.ConvertToOletxTransaction(transaction);
                /*byte[]*/ let token = $.$stl.System.Transactions.Oletx.OletxTransaction.GetTransmitterPropagationToken();
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetTransmitterPropagationToken");
                }
                return token;
            }
            static /*Transaction */ GetTransactionFromTransmitterPropagationToken(/*byte[]*/ propagationToken)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(propagationToken, "propagationToken");
                if (propagationToken.length < 24)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$stl.System.SR.InvalidArgument, "propagationToken");
                }
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetTransactionFromTransmitterPropagationToken");
                }
                /*var*/ let txId = new $.$spc.System.Guid().$ctor$3($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.Byte, propagationToken, 8, 16)));
                /*Transaction?*/ let tx = $.$stl.System.Transactions.TransactionManager.FindPromotedTransaction(txId);
                if ($.$stl.System.Transactions.Transaction.op_Inequality(null, tx))
                {
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodExit$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetTransactionFromTransmitterPropagationToken");
                    }
                    return tx;
                }
                /*OletxTransaction*/ let dTx = $.$stl.System.Transactions.TransactionInterop.GetOletxTransactionFromTransmitterPropagationToken(propagationToken);
                /*Transaction*/ let returnValue = $.$stl.System.Transactions.TransactionManager.FindOrCreatePromotedTransaction(txId, dTx);
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetTransactionFromTransmitterPropagationToken");
                }
                return returnValue;
            }
            static /*IDtcTransaction */ GetDtcTransaction(/*Transaction*/ transaction)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(transaction, "transaction");
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetDtcTransaction");
                }
                $.$stl.System.Transactions.TransactionInterop.ConvertToOletxTransaction(transaction);
                /*IDtcTransaction*/ let transactionNative = $.$stl.System.Transactions.Oletx.OletxTransaction.GetDtcTransaction();
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetDtcTransaction");
                }
                return transactionNative;
            }
            static /*Transaction */ GetTransactionFromDtcTransaction(/*IDtcTransaction*/ transactionNative)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(transactionNative, "transactionNative");
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetTransactionFromDtcTransaction");
                }
                /*Transaction*/ let transaction = $.$stl.System.Transactions.Oletx.OletxTransactionManager.GetTransactionFromDtcTransaction(transactionNative);
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetTransactionFromDtcTransaction");
                }
                return transaction;
            }
            static /*byte[] */ GetWhereabouts()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetWhereabouts");
                }
                /*byte[]*/ let returnValue = $.$stl.System.Transactions.Oletx.OletxTransactionManager.GetWhereabouts();
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(2/*TraceSourceType.TraceSourceOleTx*/, "TransactionInterop.GetWhereabouts");
                }
                return returnValue;
            }
            static /*OletxTransaction */ GetOletxTransactionFromTransmitterPropagationToken(/*byte[]*/ propagationToken)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(propagationToken, "propagationToken");
                if (propagationToken.length < 24)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$stl.System.SR.InvalidArgument, "propagationToken");
                }
                /*byte[]*/ let propagationTokenCopy = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [propagationToken.length], null);
                $.$spc.System.Array.Copy(propagationToken, propagationTokenCopy, propagationToken.length);
                return $.$stl.System.Transactions.Oletx.OletxTransactionManager.GetOletxTransactionFromTransmitterPropagationToken(propagationTokenCopy);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.PromoterTypeDtc = new $.$spc.System.Guid().$ctor$8("14229753-FFE1-428D-82B7-DF73045CB8DA");
                }
            }
            static $h = 4818404;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":3507684,"p":[{"n":"transaction","p":4294116}],"n":"ConvertToOletxTransaction","d":4818404,"h":4299785700,"f":40},{"r":0,"p":[{"n":"transaction","p":4294116},{"n":"whereabouts","p":0}],"n":"GetExportCookie","d":4818404,"h":12889720292,"f":33},{"r":4294116,"p":[{"n":"cookie","p":0}],"n":"GetTransactionFromExportCookie","d":4818404,"h":17184687588,"f":33},{"r":0,"p":[{"n":"transaction","p":4294116}],"n":"GetTransmitterPropagationToken","d":4818404,"h":21479654884,"f":33},{"r":4294116,"p":[{"n":"propagationToken","p":0}],"n":"GetTransactionFromTransmitterPropagationToken","d":4818404,"h":25774622180,"f":33},{"r":2524644,"p":[{"n":"transaction","p":4294116}],"n":"GetDtcTransaction","d":4818404,"h":30069589476,"f":33},{"r":4294116,"p":[{"n":"transactionNative","p":2524644}],"n":"GetTransactionFromDtcTransaction","d":4818404,"h":34364556772,"f":33},{"r":0,"n":"GetWhereabouts","d":4818404,"h":38659524068,"f":33},{"r":3507684,"p":[{"n":"propagationToken","p":0}],"n":"GetOletxTransactionFromTransmitterPropagationToken","d":4818404,"h":42954491364,"f":40}],"l":[{"t":56229889,"n":"PromoterTypeDtc","d":4818404,"h":8594752996,"f":33}],"h":4818404}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Transactions.TransactionInterop`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionTable", ($self) => class TransactionTable extends $.$spc.System.Object
        {
            /*Timer*/ _timer = null;
            /*bool*/ _timerEnabled = false;
            /*int*/ static timerInternalExponent = 9;
            /*int*/ _timerInterval = 0;
            /*long*/ _ticks = 0n;
            /*long*/ _lastTimerTime = 0n;
            /*BucketSet*/ _headBucketSet = null;
            /*CheapUnfairReaderWriterLock*/ _rwLock = null;
            $ctor$1()
            {
                super.$ctor();
                {
                    this._timer = new $.$spc.System.Threading.Timer().$ctor$2(new $.$spc.System.Threading.TimerCallback().$ctor(this, this.ThreadTimer), null, -1/*Timeout.Infinite*/, this._timerInterval);
                    this._timerEnabled = false;
                    this._timerInterval = 1 << 9/*TransactionTable.timerInternalExponent*/;
                    this._ticks = 0n;
                    this._headBucketSet = new $.$stl.System.Transactions.BucketSet().$ctor$1(this, 9223372036854775807n);
                    this._rwLock = new $.$stl.System.Transactions.CheapUnfairReaderWriterLock().$ctor$1();
                }
                return this;
            }
            /*long */ TimeoutTicks(/*TimeSpan*/ timeout)
            {
                if ($.$spc.System.TimeSpan.op_Inequality(timeout, $.$spc.System.TimeSpan.Zero))
                {
                    /*long*/ let timeoutTicks = ((timeout.Ticks / 10000n) >> BigInt(9/*TransactionTable.timerInternalExponent*/)) + this._ticks;
                    return timeoutTicks + 2n;
                }
                else 
                {
                    return 9223372036854775807n;
                }
            }
            /*TimeSpan */ RecalcTimeout(/*InternalTransaction*/ tx)
            {
                return $.$spc.System.TimeSpan.FromMilliseconds((tx.AbsoluteTimeout - this._ticks) * BigInt(this._timerInterval));
            }
            /*long */ get CurrentTime()
            {
                if (this._timerEnabled)
                {
                    return this._lastTimerTime;
                }
                else 
                {
                    return $.$spc.System.DateTime.UtcNow.Ticks;
                }
            }
            /*int */ Add(/*InternalTransaction*/ txNew)
            {
                /*int*/ let readerIndex;
                readerIndex = this._rwLock.EnterReadLock();
                try
                {
                    if (txNew.AbsoluteTimeout !== 9223372036854775807n)
                    {
                        if (!this._timerEnabled)
                        {
                            if (!this._timer.Change(this._timerInterval, this._timerInterval))
                            {
                                throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.UnexpectedTimerFailure, null);
                            }
                            this._lastTimerTime = $.$spc.System.DateTime.UtcNow.Ticks;
                            this._timerEnabled = true;
                        }
                    }
                    txNew.CreationTime = this.CurrentTime;
                    this.AddIter(txNew);
                }
                finally
                {
                    {
                        this._rwLock.ExitReadLock();
                    }
                }
                return readerIndex;
            }
            /*void */ AddIter(/*InternalTransaction*/ txNew)
            {
                /*BucketSet*/ let currentBucketSet = this._headBucketSet;
                while(currentBucketSet.AbsoluteTimeout !== txNew.AbsoluteTimeout)
                {
                    /*BucketSet?*/ let lastBucketSet = null;
                    do
                    {
                        /*WeakReference?*/ let nextSetWeak = $.$cast(currentBucketSet.nextSetWeak, $.$spc.System.WeakReference);
                        /*BucketSet?*/ let nextBucketSet = null;
                        if (nextSetWeak !== null)
                        {
                            nextBucketSet = $.$cast(nextSetWeak.Target, $.$stl.System.Transactions.BucketSet);
                        }
                        if (nextBucketSet === null)
                        {
                            /*BucketSet*/ let newBucketSet = new $.$stl.System.Transactions.BucketSet().$ctor$1(this, txNew.AbsoluteTimeout);
                            /*WeakReference*/ let newSetWeak = new $.$spc.System.WeakReference().$ctor$1(newBucketSet);
                            /*WeakReference?*/ let oldNextSetWeak = $.$cast($.$spc.System.Threading.Interlocked.CompareExchange$2($.$ref(() => currentBucketSet.nextSetWeak, ($v) => currentBucketSet.nextSetWeak = $v, $.$spc.System.Object), newSetWeak, nextSetWeak), $.$spc.System.WeakReference);
                            if (oldNextSetWeak === nextSetWeak)
                            {
                                newBucketSet.prevSet = currentBucketSet;
                            }
                        }
                        else 
                        {
                            lastBucketSet = currentBucketSet;
                            currentBucketSet = nextBucketSet;
                        }
                    }
                    while(currentBucketSet.AbsoluteTimeout > txNew.AbsoluteTimeout);
                    if (currentBucketSet.AbsoluteTimeout !== txNew.AbsoluteTimeout)
                    {
                        /*BucketSet*/ let newBucketSet = new $.$stl.System.Transactions.BucketSet().$ctor$1(this, txNew.AbsoluteTimeout);
                        /*WeakReference*/ let newSetWeak = new $.$spc.System.WeakReference().$ctor$1(newBucketSet);
                        $.$spc.System.Diagnostics.Debug.Assert$1(lastBucketSet !== null, "lastBucketSet != null");
                        newBucketSet.nextSetWeak = lastBucketSet.nextSetWeak;
                        /*WeakReference?*/ let oldNextSetWeak = $.$cast($.$spc.System.Threading.Interlocked.CompareExchange$2($.$ref(() => lastBucketSet.nextSetWeak, ($v) => lastBucketSet.nextSetWeak = $v, $.$spc.System.Object), newSetWeak, newBucketSet.nextSetWeak), $.$spc.System.WeakReference);
                        if (oldNextSetWeak === newBucketSet.nextSetWeak)
                        {
                            if (oldNextSetWeak !== null)
                            {
                                /*BucketSet?*/ let oldSet = $.$cast(oldNextSetWeak.Target, $.$stl.System.Transactions.BucketSet);
                                if (oldSet !== null)
                                {
                                    oldSet.prevSet = newBucketSet;
                                }
                            }
                            newBucketSet.prevSet = lastBucketSet;
                        }
                        currentBucketSet = lastBucketSet;
                    }
                }
                currentBucketSet.Add(txNew);
            }
            static /*void */ Remove(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(tx._tableBucket !== null, "tx._tableBucket != null");
                tx._tableBucket.Remove(tx);
                tx._tableBucket = null;
            }
            /*void */ ThreadTimer(/*object?*/ state)
            {
                if (!this._timerEnabled)
                {
                    return;
                }
                this._ticks++;
                this._lastTimerTime = $.$spc.System.DateTime.UtcNow.Ticks;
                /*BucketSet?*/ let lastBucketSet;
                /*BucketSet*/ let currentBucketSet = this._headBucketSet;
                /*WeakReference?*/ let nextWeakSet;
                /*BucketSet?*/ let nextBucketSet = null;
                nextWeakSet = $.$cast(currentBucketSet.nextSetWeak, $.$spc.System.WeakReference);
                if (nextWeakSet !== null)
                {
                    nextBucketSet = $.$cast(nextWeakSet.Target, $.$stl.System.Transactions.BucketSet);
                }
                if (nextBucketSet === null)
                {
                    this._rwLock.EnterWriteLock();
                    try
                    {
                        nextWeakSet = $.$cast(currentBucketSet.nextSetWeak, $.$spc.System.WeakReference);
                        if (nextWeakSet !== null)
                        {
                            nextBucketSet = $.$cast(nextWeakSet.Target, $.$stl.System.Transactions.BucketSet);
                        }
                        if (nextBucketSet === null)
                        {
                            if (!this._timer.Change(-1/*Timeout.Infinite*/, -1/*Timeout.Infinite*/))
                            {
                                throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.UnexpectedTimerFailure, null);
                            }
                            this._timerEnabled = false;
                            return;
                        }
                    }
                    finally
                    {
                        {
                            this._rwLock.ExitWriteLock();
                        }
                    }
                }
                do
                {
                    do
                    {
                        nextWeakSet = $.$cast(currentBucketSet.nextSetWeak, $.$spc.System.WeakReference);
                        if (nextWeakSet === null)
                        {
                            return;
                        }
                        nextBucketSet = $.$cast(nextWeakSet.Target, $.$stl.System.Transactions.BucketSet);
                        if (nextBucketSet === null)
                        {
                            return;
                        }
                        lastBucketSet = currentBucketSet;
                        currentBucketSet = nextBucketSet;
                    }
                    while(currentBucketSet.AbsoluteTimeout > this._ticks);
                    /*WeakReference?*/ let abortingSetsWeak = $.$cast($.$spc.System.Threading.Interlocked.CompareExchange$2($.$ref(() => lastBucketSet.nextSetWeak, ($v) => lastBucketSet.nextSetWeak = $v, $.$spc.System.Object), null, nextWeakSet), $.$spc.System.WeakReference);
                    if (abortingSetsWeak === nextWeakSet)
                    {
                        /*BucketSet?*/ let abortingBucketSets;
                        do
                        {
                            if (abortingSetsWeak !== null)
                            {
                                abortingBucketSets = $.$cast(abortingSetsWeak.Target, $.$stl.System.Transactions.BucketSet);
                            }
                            else 
                            {
                                abortingBucketSets = null;
                            }
                            if (abortingBucketSets !== null)
                            {
                                abortingBucketSets.TimeoutTransactions();
                                abortingSetsWeak = $.$cast(abortingBucketSets.nextSetWeak, $.$spc.System.WeakReference);
                            }
                        }
                        while(abortingBucketSets !== null);
                        break;
                    }
                    currentBucketSet = lastBucketSet;
                }
                while(true);
            }
            static $h = 8488420;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":917505,"g":{"r":0,"d":0,"h":55843063268,"f":2},"n":"CurrentTime","d":8488420,"h":51548095972,"f":2}],"m":[{"r":917505,"p":[{"n":"timeout","p":140705793}],"n":"TimeoutTicks","d":8488420,"h":42958161380,"f":8},{"r":140705793,"p":[{"n":"tx","p":2786788}],"n":"RecalcTimeout","d":8488420,"h":47253128676,"f":8},{"r":655361,"p":[{"n":"txNew","p":2786788}],"n":"Add","d":8488420,"h":60138030564,"f":8},{"r":65537,"p":[{"n":"txNew","p":2786788}],"n":"AddIter","d":8488420,"h":64432997860,"f":2},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"Remove","d":8488420,"h":68727965156,"f":40},{"r":65537,"p":[{"n":"state","p":131073}],"n":"ThreadTimer","d":8488420,"h":73022932452,"f":2}],"l":[{"t":138543105,"n":"_timer","d":8488420,"h":4303455716,"f":2},{"t":262145,"n":"_timerEnabled","d":8488420,"h":8598423012,"f":2},{"t":655361,"n":"timerInternalExponent","d":8488420,"h":12893390308,"f":34},{"t":655361,"n":"_timerInterval","d":8488420,"h":17188357604,"f":2},{"t":917505,"n":"_ticks","d":8488420,"h":21483324900,"f":2},{"t":917505,"n":"_lastTimerTime","d":8488420,"h":25778292196,"f":2},{"t":361956,"n":"_headBucketSet","d":8488420,"h":30073259492,"f":2},{"t":493028,"n":"_rwLock","d":8488420,"h":34368226788,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":8488420,"h":38663194084,"f":8}],"h":8488420}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Transactions.TransactionTable`; }
        });
        
        $asm.$cls("$stl.System.Transactions.Oletx.OletxTransactionManager", ($self) => class OletxTransactionManager extends $.$spc.System.Object
        {
            /*object?*/ NodeName = null;
            $ctor$1(/*string*/ nodeName)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*IPromotedEnlistment */ ReenlistTransaction(/*Guid*/ resourceManagerIdentifier, /*byte[]*/ resourceManagerRecoveryInformation, /*RecoveringInternalEnlistment*/ internalEnlistment)
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransactionManager.NotSupported();
            }
            /*OletxCommittableTransaction */ CreateTransaction(/*TransactionOptions*/ options)
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransactionManager.NotSupported();
            }
            /*void */ ResourceManagerRecoveryComplete(/*Guid*/ resourceManagerIdentifier)
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransactionManager.NotSupported();
            }
            static /*byte[] */ GetWhereabouts()
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransactionManager.NotSupported();
            }
            static /*Transaction */ GetTransactionFromDtcTransaction(/*IDtcTransaction*/ transactionNative)
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransactionManager.NotSupported();
            }
            static /*OletxTransaction */ GetTransactionFromExportCookie(/*byte[]*/ cookie, /*Guid*/ txId)
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransactionManager.NotSupported();
            }
            static /*OletxTransaction */ GetOletxTransactionFromTransmitterPropagationToken(/*byte[]*/ propagationToken)
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransactionManager.NotSupported();
            }
            static /*Exception */ NotSupported()
            {
                return new $.$spc.System.PlatformNotSupportedException().$ctor$14($.$stl.System.SR.DistributedNotSupported);
            }
            static $h = 3638756;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":131073,"g":{"r":0,"d":0,"h":12888540644,"f":8},"s":{"r":0,"d":0,"h":17183507940,"f":8},"n":"NodeName","d":3638756,"h":8593573348,"f":8}],"m":[{"r":2917860,"p":[{"n":"resourceManagerIdentifier","p":56229889},{"n":"resourceManagerRecoveryInformation","p":0},{"n":"internalEnlistment","p":4031972}],"n":"ReenlistTransaction","d":3638756,"h":25773442532,"f":8},{"r":3376612,"p":[{"n":"options","p":5015012}],"n":"CreateTransaction","d":3638756,"h":30068409828,"f":8},{"r":65537,"p":[{"n":"resourceManagerIdentifier","p":56229889}],"n":"ResourceManagerRecoveryComplete","d":3638756,"h":34363377124,"f":8},{"r":0,"n":"GetWhereabouts","d":3638756,"h":38658344420,"f":40},{"r":4294116,"p":[{"n":"transactionNative","p":2524644}],"n":"GetTransactionFromDtcTransaction","d":3638756,"h":42953311716,"f":40},{"r":3507684,"p":[{"n":"cookie","p":0},{"n":"txId","p":56229889}],"n":"GetTransactionFromExportCookie","d":3638756,"h":47248279012,"f":40},{"r":3507684,"p":[{"n":"propagationToken","p":0}],"n":"GetOletxTransactionFromTransmitterPropagationToken","d":3638756,"h":51543246308,"f":40},{"r":47251457,"n":"NotSupported","d":3638756,"h":55838213604,"f":40}],"c":[{"p":[{"n":"nodeName","p":1310721}],"n":".ctor","o":"$ctor$1","d":3638756,"h":21478475236,"f":8}],"h":3638756}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Transactions.Oletx.OletxTransactionManager`; }
        });
        
        $asm.$cls("$stl.System.Transactions.Enlistment", ($self) => class Enlistment extends $.$spc.System.Object
        {
            /*InternalEnlistment*/ _internalEnlistment = null;
            $ctor$1(/*InternalEnlistment*/ internalEnlistment)
            {
                super.$ctor();
                {
                    this._internalEnlistment = internalEnlistment;
                }
                return this;
            }
            $ctor$2(/*Guid*/ resourceManagerIdentifier, /*InternalTransaction*/ transaction, /*IEnlistmentNotification*/ twoPhaseNotifications, /*ISinglePhaseNotification?*/ singlePhaseNotifications, /*Transaction*/ atomicTransaction)
            {
                super.$ctor();
                {
                    this._internalEnlistment = new $.$stl.System.Transactions.DurableInternalEnlistment().$ctor$5(this, resourceManagerIdentifier, transaction, twoPhaseNotifications, singlePhaseNotifications, atomicTransaction);
                }
                return this;
            }
            $ctor$3(/*InternalTransaction*/ transaction, /*IEnlistmentNotification*/ twoPhaseNotifications, /*ISinglePhaseNotification?*/ singlePhaseNotifications, /*Transaction*/ atomicTransaction, /*EnlistmentOptions*/ enlistmentOptions)
            {
                super.$ctor();
                {
                    if ((enlistmentOptions & 1/*EnlistmentOptions.EnlistDuringPrepareRequired*/) !== 0)
                    {
                        this._internalEnlistment = new $.$stl.System.Transactions.InternalEnlistment().$ctor$3(this, transaction, twoPhaseNotifications, singlePhaseNotifications, atomicTransaction);
                    }
                    else 
                    {
                        this._internalEnlistment = new $.$stl.System.Transactions.Phase1VolatileEnlistment().$ctor$5(this, transaction, twoPhaseNotifications, singlePhaseNotifications, atomicTransaction);
                    }
                }
                return this;
            }
            $ctor$4(/*InternalTransaction*/ transaction, /*IPromotableSinglePhaseNotification*/ promotableSinglePhaseNotification, /*Transaction*/ atomicTransaction)
            {
                super.$ctor();
                {
                    this._internalEnlistment = new $.$stl.System.Transactions.PromotableInternalEnlistment().$ctor$5(this, transaction, promotableSinglePhaseNotification, atomicTransaction);
                }
                return this;
            }
            $ctor$5(/*IEnlistmentNotification*/ twoPhaseNotifications, /*InternalTransaction*/ transaction, /*Transaction*/ atomicTransaction)
            {
                super.$ctor();
                {
                    this._internalEnlistment = new $.$stl.System.Transactions.InternalEnlistment().$ctor$4(this, twoPhaseNotifications, transaction, atomicTransaction);
                }
                return this;
            }
            $ctor$6(/*IEnlistmentNotification*/ twoPhaseNotifications, /*object*/ syncRoot)
            {
                super.$ctor();
                {
                    this._internalEnlistment = new $.$stl.System.Transactions.RecoveringInternalEnlistment().$ctor$7(this, twoPhaseNotifications, syncRoot);
                }
                return this;
            }
            /*void */ Done()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "Done");
                    etwLog.EnlistmentDone(this._internalEnlistment);
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalEnlistment.SyncRoot)
                    {
                        this._internalEnlistment.State.EnlistmentDone(this._internalEnlistment);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalEnlistment.SyncRoot)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "Done");
                }
            }
            /*InternalEnlistment */ get InternalEnlistment()
            {
                return this._internalEnlistment;
            }
            static $h = 1738212;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":2721252,"g":{"r":0,"d":0,"h":42951411172,"f":8},"n":"InternalEnlistment","d":1738212,"h":38656443876,"f":8}],"m":[{"r":65537,"n":"Done","d":1738212,"h":34361476580,"f":1}],"l":[{"t":2721252,"n":"_internalEnlistment","d":1738212,"h":4296705508,"f":8}],"c":[{"p":[{"n":"internalEnlistment","p":2721252}],"n":".ctor","o":"$ctor$1","d":1738212,"h":8591672804,"f":8},{"p":[{"n":"resourceManagerIdentifier","p":56229889},{"n":"transaction","p":2786788},{"n":"twoPhaseNotifications","p":2590180},{"n":"singlePhaseNotifications","p":3048932},{"n":"atomicTransaction","p":4294116}],"n":".ctor","o":"$ctor$2","d":1738212,"h":12886640100,"f":8},{"p":[{"n":"transaction","p":2786788},{"n":"twoPhaseNotifications","p":2590180},{"n":"singlePhaseNotifications","p":3048932},{"n":"atomicTransaction","p":4294116},{"n":"enlistmentOptions","p":1869284}],"n":".ctor","o":"$ctor$3","d":1738212,"h":17181607396,"f":8},{"p":[{"n":"transaction","p":2786788},{"n":"promotableSinglePhaseNotification","p":2852324},{"n":"atomicTransaction","p":4294116}],"n":".ctor","o":"$ctor$4","d":1738212,"h":21476574692,"f":8},{"p":[{"n":"twoPhaseNotifications","p":2590180},{"n":"transaction","p":2786788},{"n":"atomicTransaction","p":4294116}],"n":".ctor","o":"$ctor$5","d":1738212,"h":25771541988,"f":8},{"p":[{"n":"twoPhaseNotifications","p":2590180},{"n":"syncRoot","p":131073}],"n":".ctor","o":"$ctor$6","d":1738212,"h":30066509284,"f":8}],"h":1738212}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Transactions.Enlistment`; }
        });
        
        $asm.$cls("$stl.System.Transactions.BucketSet", ($self) => class BucketSet extends $.$spc.System.Object
        {
            /*object?*/ nextSetWeak = null;
            /*BucketSet?*/ prevSet = null;
            /*TransactionTable*/ _table = null;
            /*long*/ _absoluteTimeout = 0n;
            /*Bucket*/ headBucket = null;
            $ctor$1(/*TransactionTable*/ table, /*long*/ absoluteTimeout)
            {
                super.$ctor();
                {
                    this.headBucket = new $.$stl.System.Transactions.Bucket().$ctor$1(this);
                    this._table = table;
                    this._absoluteTimeout = absoluteTimeout;
                }
                return this;
            }
            /*long */ get AbsoluteTimeout()
            {
                return this._absoluteTimeout;
            }
            /*void */ Add(/*InternalTransaction*/ newTx)
            {
                while(!this.headBucket.Add(newTx))
                {
                }
            }
            /*void */ TimeoutTransactions()
            {
                /*Bucket?*/ let currentBucket = this.headBucket;
                do
                {
                    currentBucket.TimeoutTransactions();
                    /*WeakReference?*/ let nextWeakBucket = currentBucket.nextBucketWeak;
                    if (nextWeakBucket !== null)
                    {
                        currentBucket = $.$cast(nextWeakBucket.Target, $.$stl.System.Transactions.Bucket);
                    }
                    else 
                    {
                        currentBucket = null;
                    }
                }
                while(currentBucket !== null);
            }
            static $h = 361956;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":917505,"g":{"r":0,"d":0,"h":34360100324,"f":8},"n":"AbsoluteTimeout","d":361956,"h":30065133028,"f":8}],"m":[{"r":65537,"p":[{"n":"newTx","p":2786788}],"n":"Add","d":361956,"h":38655067620,"f":8},{"r":65537,"n":"TimeoutTransactions","d":361956,"h":42950034916,"f":8}],"l":[{"t":131073,"n":"nextSetWeak","d":361956,"h":4295329252,"f":8},{"t":361956,"n":"prevSet","d":361956,"h":8590296548,"f":8},{"t":8488420,"n":"_table","d":361956,"h":12885263844,"f":2},{"t":917505,"n":"_absoluteTimeout","d":361956,"h":17180231140,"f":2},{"t":296420,"n":"headBucket","d":361956,"h":21475198436,"f":8}],"c":[{"p":[{"n":"table","p":8488420},{"n":"absoluteTimeout","p":917505}],"n":".ctor","o":"$ctor$1","d":361956,"h":25770165732,"f":8}],"h":361956}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Transactions.BucketSet`; }
        });
        
        $asm.$cls("$stl.System.Transactions.Bucket", ($self) => class Bucket extends $.$spc.System.Object
        {
            /*bool*/ _timedOut = false;
            /*int*/ _index = 0;
            /*int*/ _size = 0;
            /*InternalTransaction?[]*/ _transactions = null;
            /*WeakReference?*/ nextBucketWeak = null;
            /*Bucket?*/ _previous = null;
            /*BucketSet*/ _owningSet = null;
            $ctor$1(/*BucketSet*/ owningSet)
            {
                super.$ctor();
                {
                    this._timedOut = false;
                    this._index = -1;
                    this._size = 1024;
                    this._transactions = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$stl.System.Transactions.InternalTransaction), null, [this._size], null);
                    this._owningSet = owningSet;
                }
                return this;
            }
            /*bool */ Add(/*InternalTransaction*/ tx)
            {
                /*int*/ let currentIndex = $.$spc.System.Threading.Interlocked.Increment($.$ref(() => this._index, ($v) => this._index = $v, $.$spc.System.Int32));
                if (currentIndex < this._size)
                {
                    tx._tableBucket = this;
                    tx._bucketIndex = currentIndex;
                    $.$spc.System.Threading.Interlocked.MemoryBarrier();
                    $.$spc.System.Array.$WriteT1.call(this._transactions, tx, currentIndex);
                    if (this._timedOut)
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(tx)
                            {
                                tx.State.Timeout(tx);
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(tx)
                        }
                    }
                }
                else 
                {
                    /*Bucket*/ let newBucket = new $.$stl.System.Transactions.Bucket().$ctor$1(this._owningSet);
                    newBucket.nextBucketWeak = new $.$spc.System.WeakReference().$ctor$1(this);
                    /*Bucket*/ let oldBucket = $.$spc.System.Threading.Interlocked.CompareExchange$14($.$stl.System.Transactions.Bucket, $.$ref(() => this._owningSet.headBucket, ($v) => this._owningSet.headBucket = $v, $.$stl.System.Transactions.Bucket), newBucket, this);
                    if (oldBucket === this)
                    {
                        this._previous = newBucket;
                    }
                    return false;
                }
                return true;
            }
            /*void */ Remove(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Array.$WriteT1.call(this._transactions, null, tx._bucketIndex);
            }
            /*void */ TimeoutTransactions()
            {
                /*int*/ let i;
                /*int*/ let transactionCount = this._index;
                this._timedOut = true;
                $.$spc.System.Threading.Interlocked.MemoryBarrier();
                for(i = 0; i <= transactionCount && i < this._size; i++)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(transactionCount === this._index, "Index changed timing out transactions");
                    /*InternalTransaction?*/ let tx = $.$spc.System.Array.$ReadT1.call(this._transactions, i);
                    if (tx !== null)
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(tx)
                            {
                                tx.State.Timeout(tx);
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(tx)
                        }
                    }
                }
            }
            static $h = 296420;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"tx","p":2786788}],"n":"Add","d":296420,"h":38655002084,"f":8},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"Remove","d":296420,"h":42949969380,"f":8},{"r":65537,"n":"TimeoutTransactions","d":296420,"h":47244936676,"f":8}],"l":[{"t":262145,"n":"_timedOut","d":296420,"h":4295263716,"f":2},{"t":655361,"n":"_index","d":296420,"h":8590231012,"f":2},{"t":655361,"n":"_size","d":296420,"h":12885198308,"f":2},{"t":0,"n":"_transactions","d":296420,"h":17180165604,"f":2},{"t":144769025,"n":"nextBucketWeak","d":296420,"h":21475132900,"f":8},{"t":296420,"n":"_previous","d":296420,"h":25770100196,"f":2},{"t":361956,"n":"_owningSet","d":296420,"h":30065067492,"f":2}],"c":[{"p":[{"n":"owningSet","p":361956}],"n":".ctor","o":"$ctor$1","d":296420,"h":34360034788,"f":8}],"h":296420}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Transactions.Bucket`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionManager", ($self) => class TransactionManager
        {
            /*int*/ static RecoveryInformationVersion1 = 1;
            /*int*/ static CurrentRecoveryVersion = 1;
            /*Hashtable?*/ static s_promotedTransactionTable = null;
            /*TransactionTable?*/ static s_transactionTable = null;
            /*TransactionStartedEventHandler?*/ static s_distributedTransactionStartedDelegate = null;
            /*string*/ static DistributedTransactionTrimmingWarning = null;
            /*TransactionStartedEventHandler?*/static  add_DistributedTransactionStarted(value)
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter($.$stl.System.Transactions.TransactionManager.ClassSyncObject)
                    {
                        $.$stl.System.Transactions.TransactionManager.s_distributedTransactionStartedDelegate = $.$cast($.$spc.System.Delegate.Combine($.$stl.System.Transactions.TransactionManager.s_distributedTransactionStartedDelegate, value), $.$stl.System.Transactions.TransactionStartedEventHandler);
                        if (value !== null)
                        {
                            $.$stl.System.Transactions.TransactionManager.ProcessExistingTransactions(value);
                        }
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit($.$stl.System.Transactions.TransactionManager.ClassSyncObject)
                }
            }
            /*TransactionStartedEventHandler?*/static  remove_DistributedTransactionStarted(value)
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter($.$stl.System.Transactions.TransactionManager.ClassSyncObject)
                    {
                        $.$stl.System.Transactions.TransactionManager.s_distributedTransactionStartedDelegate = $.$cast($.$spc.System.Delegate.Remove($.$stl.System.Transactions.TransactionManager.s_distributedTransactionStartedDelegate, value), $.$stl.System.Transactions.TransactionStartedEventHandler);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit($.$stl.System.Transactions.TransactionManager.ClassSyncObject)
                }
            }
            static /*void */ ProcessExistingTransactions(/*TransactionStartedEventHandler*/ eventHandler)
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter($.$stl.System.Transactions.TransactionManager.PromotedTransactionTable)
                    {
                        /*IDictionaryEnumerator*/ let e = $.$stl.System.Transactions.TransactionManager.PromotedTransactionTable.GetEnumerator();
                        while(e.System$Collections$IEnumerator$MoveNext())
                        {
                            /*WeakReference*/ let weakRef = $.$cast(e.System$Collections$IDictionaryEnumerator$Value, $.$spc.System.WeakReference);
                            let tx;
                            if ($.$is(weakRef.Target, $.$stl.System.Transactions.Transaction, { set $v(v){ tx = v; } }))
                            {
                                /*TransactionEventArgs*/ let args = new $.$stl.System.Transactions.TransactionEventArgs().$ctor$2();
                                args._transaction = tx.InternalClone();
                                eventHandler.Invoke(args._transaction, args);
                            }
                        }
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit($.$stl.System.Transactions.TransactionManager.PromotedTransactionTable)
                }
            }
            static /*void */ FireDistributedTransactionStarted(/*Transaction*/ transaction)
            {
                /*TransactionStartedEventHandler?*/ let localStartedEventHandler = null;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter($.$stl.System.Transactions.TransactionManager.ClassSyncObject)
                    {
                        localStartedEventHandler = $.$stl.System.Transactions.TransactionManager.s_distributedTransactionStartedDelegate;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit($.$stl.System.Transactions.TransactionManager.ClassSyncObject)
                }
                if (null !== localStartedEventHandler)
                {
                    /*TransactionEventArgs*/ let args = new $.$stl.System.Transactions.TransactionEventArgs().$ctor$2();
                    args._transaction = transaction.InternalClone();
                    localStartedEventHandler.Invoke(args._transaction, args);
                }
            }
            /*HostCurrentTransactionCallback?*/ static s_currentDelegate = null;
            /*bool*/ static s_currentDelegateSet = false;
            static /*HostCurrentTransactionCallback? */ get HostCurrentCallback()
            {
                return $.$stl.System.Transactions.TransactionManager.s_currentDelegate;
            }
            static /*HostCurrentTransactionCallback? */ set HostCurrentCallback(value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter($.$stl.System.Transactions.TransactionManager.ClassSyncObject)
                    {
                        if ($.$stl.System.Transactions.TransactionManager.s_currentDelegateSet)
                        {
                            throw new $.$spc.System.InvalidOperationException().$ctor$10($.$stl.System.SR.CurrentDelegateSet);
                        }
                        $.$stl.System.Transactions.TransactionManager.s_currentDelegateSet = true;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit($.$stl.System.Transactions.TransactionManager.ClassSyncObject)
                }
                $.$stl.System.Transactions.TransactionManager.s_currentDelegate = value;
            }
            static /*Enlistment */ Reenlist(/*Guid*/ resourceManagerIdentifier, /*byte[]*/ recoveryInformation, /*IEnlistmentNotification*/ enlistmentNotification)
            {
                if ($.$spc.System.Guid.op_Equality(resourceManagerIdentifier, $.$spc.System.Guid.Empty))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$stl.System.SR.BadResourceManagerId, "resourceManagerIdentifier");
                }
                $.$spc.System.ArgumentNullException.ThrowIfNull(recoveryInformation, "recoveryInformation");
                $.$spc.System.ArgumentNullException.ThrowIfNull(enlistmentNotification, "enlistmentNotification");
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(0/*TraceSourceType.TraceSourceBase*/, "TransactionManager.Reenlist");
                    etwLog.TransactionManagerReenlist(resourceManagerIdentifier);
                }
                /*MemoryStream*/ let stream = new $.$spc.System.IO.MemoryStream().$ctor$5(recoveryInformation);
                /*int*/ let recoveryInformationVersion;
                /*string?*/ let nodeName;
                /*byte[]?*/ let resourceManagerRecoveryInformation = null;
                try
                {
                    /*BinaryReader*/ let reader = new $.$spc.System.IO.BinaryReader().$ctor$1(stream);
                    recoveryInformationVersion = reader.ReadInt32();
                    if (recoveryInformationVersion === 1/*TransactionManager.RecoveryInformationVersion1*/)
                    {
                        nodeName = reader.ReadString();
                        resourceManagerRecoveryInformation = reader.ReadBytes(((recoveryInformation.length - $.$cast(stream.Position, $.$spc.System.Int32)) | 0));
                    }
                    else 
                    {
                        if (etwLog.IsEnabled())
                        {
                            etwLog.TransactionExceptionTrace(0/*TraceSourceType.TraceSourceBase*/, 5/*TransactionExceptionType.UnrecognizedRecoveryInformation*/, "recoveryInformation", $.$spc.System.String.Empty);
                        }
                        throw new $.$spc.System.ArgumentException().$ctor$13($.$stl.System.SR.UnrecognizedRecoveryInformation, "recoveryInformation");
                    }
                }
                catch($e)
                {
                    if ($e instanceof $.$spc.System.IO.EndOfStreamException)
                    {
                        let e = $e;
                        if (etwLog.IsEnabled())
                        {
                            etwLog.TransactionExceptionTrace(0/*TraceSourceType.TraceSourceBase*/, 5/*TransactionExceptionType.UnrecognizedRecoveryInformation*/, "recoveryInformation", $.$spc.System.Exception.ToString.call(e));
                        }
                        throw new $.$spc.System.ArgumentException().$ctor$12($.$stl.System.SR.UnrecognizedRecoveryInformation, "recoveryInformation", e);
                    }
                    else if ($e instanceof $.$spc.System.FormatException)
                    {
                        let e = $e;
                        if (etwLog.IsEnabled())
                        {
                            etwLog.TransactionExceptionTrace(0/*TraceSourceType.TraceSourceBase*/, 5/*TransactionExceptionType.UnrecognizedRecoveryInformation*/, "recoveryInformation", $.$spc.System.Exception.ToString.call(e));
                        }
                        throw new $.$spc.System.ArgumentException().$ctor$12($.$stl.System.SR.UnrecognizedRecoveryInformation, "recoveryInformation", e);
                    }
                    else
                    {
                        throw $e;
                    }
                }
                finally
                {
                    {
                        stream.Dispose();
                    }
                }
                /*object*/ let syncRoot = new $.$spc.System.Object().$ctor();
                /*Enlistment*/ let returnValue = new $.$stl.System.Transactions.Enlistment().$ctor$6(enlistmentNotification, syncRoot);
                $.$stl.System.Transactions.EnlistmentState.EnlistmentStatePromoted.EnterState(returnValue.InternalEnlistment);
                returnValue.InternalEnlistment.PromotedEnlistment = $.$stl.System.Transactions.TransactionManager.DistributedTransactionManager.ReenlistTransaction(resourceManagerIdentifier, resourceManagerRecoveryInformation, $.$cast(returnValue.InternalEnlistment, $.$stl.System.Transactions.RecoveringInternalEnlistment));
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(0/*TraceSourceType.TraceSourceBase*/, "TransactionManager.Reenlist");
                }
                return returnValue;
            }
            static /*OletxTransactionManager */ CheckTransactionManager(/*string?*/ nodeName)
            {
                /*OletxTransactionManager*/ let tm = $.$stl.System.Transactions.TransactionManager.DistributedTransactionManager;
                if (!((tm.NodeName === null && $.$spc.System.String.IsNullOrEmpty(nodeName)) || (tm.NodeName !== null && $.$spc.System.Object.Equals.call(tm.NodeName, nodeName))))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$stl.System.SR.InvalidRecoveryInformation, "recoveryInformation");
                }
                return tm;
            }
            static /*void */ RecoveryComplete(/*Guid*/ resourceManagerIdentifier)
            {
                if ($.$spc.System.Guid.op_Equality(resourceManagerIdentifier, $.$spc.System.Guid.Empty))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$stl.System.SR.BadResourceManagerId, "resourceManagerIdentifier");
                }
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(0/*TraceSourceType.TraceSourceBase*/, "TransactionManager.RecoveryComplete");
                    etwLog.TransactionManagerRecoveryComplete(resourceManagerIdentifier);
                }
                $.$stl.System.Transactions.TransactionManager.DistributedTransactionManager.ResourceManagerRecoveryComplete(resourceManagerIdentifier);
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(0/*TraceSourceType.TraceSourceBase*/, "TransactionManager.RecoveryComplete");
                }
            }
            /*object?*/ static s_classSyncObject = null;
            static /*object */ get ClassSyncObject()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized($.$spc.System.Object, $.$ref(() => $.$stl.System.Transactions.TransactionManager.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionManager.s_classSyncObject = $v, $.$spc.System.Object));
            }
            static /*IsolationLevel */ get DefaultIsolationLevel()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(0/*TraceSourceType.TraceSourceBase*/, "TransactionManager.get_DefaultIsolationLevel");
                    etwLog.MethodExit$1(0/*TraceSourceType.TraceSourceBase*/, "TransactionManager.get_DefaultIsolationLevel");
                }
                return 0/*IsolationLevel.Serializable*/;
            }
            /*DefaultSettingsSection*/ static DefaultSettings$ = null;
            static /*DefaultSettingsSection */ get DefaultSettings()
            {
                return $.$stl.System.Transactions.TransactionManager.DefaultSettings$ ??= $.$stl.System.Transactions.Configuration.DefaultSettingsSection.GetSection();
            }
            /*MachineSettingsSection*/ static MachineSettings$ = null;
            static /*MachineSettingsSection */ get MachineSettings()
            {
                return $.$stl.System.Transactions.TransactionManager.MachineSettings$ ??= $.$stl.System.Transactions.Configuration.MachineSettingsSection.GetSection();
            }
            /*bool*/ static s_defaultTimeoutValidated = false;
            /*long*/ static s_defaultTimeoutTicks = 0n;
            static /*TimeSpan */ get DefaultTimeout()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(0/*TraceSourceType.TraceSourceBase*/, "TransactionManager.get_DefaultTimeout");
                }
                if (!$.$stl.System.Transactions.TransactionManager.s_defaultTimeoutValidated)
                {
                    $.$spc.System.Threading.LazyInitializer.EnsureInitialized$3($.$spc.System.Int64, $.$ref(() => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks, ($v) => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks = $v, $.$spc.System.Int64), $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Boolean, () => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutValidated, ($v) => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutValidated = $v, null), $.$ref(() => $.$stl.System.Transactions.TransactionManager.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionManager.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$spc.System.Int64))().$ctor(this,  () =>
                    {
                        return $.$stl.System.Transactions.TransactionManager.ValidateTimeout($.$stl.System.Transactions.Configuration.DefaultSettingsSection.Timeout).Ticks;
                    }, {"r":917505,"n":"","d":4883940,"h":0,"f":1048578}));
                    if ($.$spc.System.Threading.Interlocked.Read($.$ref(() => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks, ($v) => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks = $v, $.$spc.System.Int64)) !== $.$stl.System.Transactions.Configuration.DefaultSettingsSection.Timeout.Ticks)
                    {
                        if (etwLog.IsEnabled())
                        {
                            etwLog.ConfiguredDefaultTimeoutAdjusted();
                        }
                    }
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(0/*TraceSourceType.TraceSourceBase*/, "TransactionManager.get_DefaultTimeout");
                }
                return new $.$spc.System.TimeSpan().$ctor$2($.$spc.System.Threading.Interlocked.Read($.$ref(() => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks, ($v) => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks = $v, $.$spc.System.Int64)));
            }
            static /*TimeSpan */ set DefaultTimeout(value)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(0/*TraceSourceType.TraceSourceBase*/, "TransactionManager.set_DefaultTimeout");
                }
                $.$spc.System.Threading.Interlocked.Exchange$3($.$ref(() => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks, ($v) => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks = $v, $.$spc.System.Int64), $.$stl.System.Transactions.TransactionManager.ValidateTimeout(value).Ticks);
                if ($.$spc.System.Threading.Interlocked.Read($.$ref(() => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks, ($v) => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks = $v, $.$spc.System.Int64)) !== value.Ticks)
                {
                    if (etwLog.IsEnabled())
                    {
                        etwLog.ConfiguredDefaultTimeoutAdjusted();
                    }
                }
                $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutValidated = true;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(0/*TraceSourceType.TraceSourceBase*/, "TransactionManager.set_DefaultTimeout");
                }
            }
            /*bool*/ static s_cachedMaxTimeout = false;
            /*TimeSpan*/ static s_maximumTimeout;
            static /*TimeSpan */ get MaximumTimeout()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(0/*TraceSourceType.TraceSourceBase*/, "TransactionManager.get_DefaultMaximumTimeout");
                }
                $.$spc.System.Threading.LazyInitializer.EnsureInitialized$3($.$spc.System.TimeSpan, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.TimeSpan, () => $.$stl.System.Transactions.TransactionManager.s_maximumTimeout, ($v) => $.$stl.System.Transactions.TransactionManager.s_maximumTimeout = $v, null), $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Boolean, () => $.$stl.System.Transactions.TransactionManager.s_cachedMaxTimeout, ($v) => $.$stl.System.Transactions.TransactionManager.s_cachedMaxTimeout = $v, null), $.$ref(() => $.$stl.System.Transactions.TransactionManager.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionManager.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$spc.System.TimeSpan))().$ctor(this,  () =>
                {
                    return $.$stl.System.Transactions.Configuration.MachineSettingsSection.MaxTimeout;
                }, {"r":140705793,"n":"","d":4883940,"h":0,"f":1048578}));
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(0/*TraceSourceType.TraceSourceBase*/, "TransactionManager.get_DefaultMaximumTimeout");
                }
                return $.$stl.System.Transactions.TransactionManager.s_maximumTimeout;
            }
            static /*TimeSpan */ set MaximumTimeout(value)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(0/*TraceSourceType.TraceSourceBase*/, "TransactionManager.set_DefaultMaximumTimeout");
                }
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfLessThan($.$spc.System.TimeSpan, value, $.$spc.System.TimeSpan.Zero, "value");
                $.$stl.System.Transactions.TransactionManager.s_cachedMaxTimeout = true;
                $.$stl.System.Transactions.TransactionManager.s_maximumTimeout = value;
                $.$spc.System.Threading.LazyInitializer.EnsureInitialized$3($.$spc.System.Int64, $.$ref(() => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks, ($v) => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks = $v, $.$spc.System.Int64), $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Boolean, () => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutValidated, ($v) => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutValidated = $v, null), $.$ref(() => $.$stl.System.Transactions.TransactionManager.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionManager.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$spc.System.Int64))().$ctor(this,  () =>
                {
                    return $.$stl.System.Transactions.Configuration.DefaultSettingsSection.Timeout.Ticks;
                }, {"r":917505,"n":"","d":4883940,"h":0,"f":1048578}));
                /*long*/ let defaultTimeoutTicks = $.$spc.System.Threading.Interlocked.Read($.$ref(() => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks, ($v) => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks = $v, $.$spc.System.Int64));
                $.$spc.System.Threading.Interlocked.Exchange$3($.$ref(() => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks, ($v) => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks = $v, $.$spc.System.Int64), $.$stl.System.Transactions.TransactionManager.ValidateTimeout(new $.$spc.System.TimeSpan().$ctor$2(defaultTimeoutTicks)).Ticks);
                if ($.$spc.System.Threading.Interlocked.Read($.$ref(() => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks, ($v) => $.$stl.System.Transactions.TransactionManager.s_defaultTimeoutTicks = $v, $.$spc.System.Int64)) !== defaultTimeoutTicks)
                {
                    if (etwLog.IsEnabled())
                    {
                        etwLog.ConfiguredDefaultTimeoutAdjusted();
                    }
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(0/*TraceSourceType.TraceSourceBase*/, "TransactionManager.set_DefaultMaximumTimeout");
                }
            }
            static /*bool */ get ImplicitDistributedTransactions()
            {
                return false;
            }
            static /*bool */ set ImplicitDistributedTransactions(value)
            {
                if (value)
                {
                    throw new $.$spc.System.PlatformNotSupportedException().$ctor$14($.$stl.System.SR.DistributedNotSupported);
                }
            }
            static /*byte[] */ GetRecoveryInformation(/*string?*/ startupInfo, /*byte[]*/ resourceManagerRecoveryInformation)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(2/*TraceSourceType.TraceSourceOleTx*/, `${"TransactionManager"}.${"GetRecoveryInformation"}`);
                }
                /*MemoryStream*/ let stream = new $.$spc.System.IO.MemoryStream().$ctor$3();
                /*byte[]?*/ let returnValue = null;
                try
                {
                    /*BinaryWriter*/ let writer = new $.$spc.System.IO.BinaryWriter().$ctor$2(stream);
                    writer.Write$12(1/*CurrentRecoveryVersion*/);
                    if ($.$spc.System.String.op_Inequality(startupInfo, null))
                    {
                        writer.Write$18(startupInfo);
                    }
                    else 
                    {
                        writer.Write$18("");
                    }
                    writer.Write$3(resourceManagerRecoveryInformation);
                    writer.Flush();
                    returnValue = stream.ToArray();
                }
                finally
                {
                    {
                        stream.Close();
                    }
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(2/*TraceSourceType.TraceSourceOleTx*/, `${"TransactionManager"}.${"GetRecoveryInformation"}`);
                }
                return returnValue;
            }
            static /*void */ ValidateIsolationLevel(/*IsolationLevel*/ transactionIsolationLevel)
            {
                switch(transactionIsolationLevel)
                {
                    case 0/*IsolationLevel.Serializable*/:
                    case 1/*IsolationLevel.RepeatableRead*/:
                    case 2/*IsolationLevel.ReadCommitted*/:
                    case 3/*IsolationLevel.ReadUncommitted*/:
                    case 6/*IsolationLevel.Unspecified*/:
                    case 5/*IsolationLevel.Chaos*/:
                    case 4/*IsolationLevel.Snapshot*/:
                    break;
                    default:
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("transactionIsolationLevel");
                }
            }
            static /*TimeSpan */ ValidateTimeout(/*TimeSpan*/ transactionTimeout)
            {
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfLessThan($.$spc.System.TimeSpan, transactionTimeout, $.$spc.System.TimeSpan.Zero, "transactionTimeout");
                if ($.$spc.System.TimeSpan.op_Inequality($.$stl.System.Transactions.TransactionManager.MaximumTimeout, $.$spc.System.TimeSpan.Zero))
                {
                    if ($.$spc.System.TimeSpan.op_GreaterThan(transactionTimeout, $.$stl.System.Transactions.TransactionManager.MaximumTimeout) || $.$spc.System.TimeSpan.op_Equality(transactionTimeout, $.$spc.System.TimeSpan.Zero))
                    {
                        return $.$stl.System.Transactions.TransactionManager.MaximumTimeout;
                    }
                }
                return transactionTimeout;
            }
            static /*Transaction? */ FindPromotedTransaction(/*Guid*/ transactionIdentifier)
            {
                /*Hashtable*/ let promotedTransactionTable = $.$stl.System.Transactions.TransactionManager.PromotedTransactionTable;
                /*WeakReference?*/ let weakRef = $.$cast(promotedTransactionTable.get_Item(transactionIdentifier), $.$spc.System.WeakReference);
                if (null !== weakRef)
                {
                    let tx;
                    if ($.$is(weakRef.Target, $.$stl.System.Transactions.Transaction, { set $v(v){ tx = v; } }))
                    {
                        return tx.InternalClone();
                    }
                    else 
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(promotedTransactionTable)
                            {
                                promotedTransactionTable.Remove(transactionIdentifier);
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(promotedTransactionTable)
                        }
                    }
                }
                return null;
            }
            static /*Transaction */ FindOrCreatePromotedTransaction(/*Guid*/ transactionIdentifier, /*OletxTransaction*/ dtx)
            {
                /*Transaction?*/ let tx = null;
                /*Hashtable*/ let promotedTransactionTable = $.$stl.System.Transactions.TransactionManager.PromotedTransactionTable;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(promotedTransactionTable)
                    {
                        /*WeakReference?*/ let weakRef = $.$cast(promotedTransactionTable.get_Item(transactionIdentifier), $.$spc.System.WeakReference);
                        if (null !== weakRef)
                        {
                            tx = $.$as(weakRef.Target, $.$stl.System.Transactions.Transaction);
                            if ($.$stl.System.Transactions.Transaction.op_Inequality(null, tx))
                            {
                                return tx.InternalClone();
                            }
                            else 
                            {
                                //lock
                                try
                                {
                                    $.$spc.System.Threading.Monitor.Enter(promotedTransactionTable)
                                    {
                                        promotedTransactionTable.Remove(transactionIdentifier);
                                    }
                                }
                                finally
                                {
                                    $.$spc.System.Threading.Monitor.Exit(promotedTransactionTable)
                                }
                            }
                        }
                        tx = new $.$stl.System.Transactions.Transaction().$ctor$3(dtx);
                        tx._internalTransaction._finalizedObject = new $.$stl.System.Transactions.FinalizedObject().$ctor$1(tx._internalTransaction, dtx.Identifier);
                        weakRef = new $.$spc.System.WeakReference().$ctor$2(tx, false);
                        promotedTransactionTable.set_Item(dtx.Identifier, weakRef);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(promotedTransactionTable)
                }
                dtx.SavedLtmPromotedTransaction = tx;
                $.$stl.System.Transactions.TransactionManager.FireDistributedTransactionStarted(tx);
                return tx;
            }
            static /*Hashtable */ get PromotedTransactionTable()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$spc.System.Collections.Hashtable, $.$ref(() => $.$stl.System.Transactions.TransactionManager.s_promotedTransactionTable, ($v) => $.$stl.System.Transactions.TransactionManager.s_promotedTransactionTable = $v, $.$spc.System.Collections.Hashtable), $.$ref(() => $.$stl.System.Transactions.TransactionManager.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionManager.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$spc.System.Collections.Hashtable))().$ctor(this,  () =>
                {
                    return new $.$spc.System.Collections.Hashtable().$ctor$3(100);
                }, {"r":30998529,"n":"","d":4883940,"h":0,"f":1048578}));
            }
            static /*TransactionTable */ get TransactionTable()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.TransactionTable, $.$ref(() => $.$stl.System.Transactions.TransactionManager.s_transactionTable, ($v) => $.$stl.System.Transactions.TransactionManager.s_transactionTable = $v, $.$stl.System.Transactions.TransactionTable), $.$ref(() => $.$stl.System.Transactions.TransactionManager.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionManager.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.TransactionTable))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.TransactionTable().$ctor$1();
                }, {"r":8488420,"n":"","d":4883940,"h":0,"f":1048578}));
            }
            /*OletxTransactionManager?*/ static distributedTransactionManager = null;
            static /*OletxTransactionManager */ get DistributedTransactionManager()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$stl.System.Transactions.Oletx.OletxTransactionManager, $.$ref(() => $.$stl.System.Transactions.TransactionManager.distributedTransactionManager, ($v) => $.$stl.System.Transactions.TransactionManager.distributedTransactionManager = $v, $.$stl.System.Transactions.Oletx.OletxTransactionManager), $.$ref(() => $.$stl.System.Transactions.TransactionManager.s_classSyncObject, ($v) => $.$stl.System.Transactions.TransactionManager.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$stl.System.Transactions.Oletx.OletxTransactionManager))().$ctor(this,  () =>
                {
                    return new $.$stl.System.Transactions.Oletx.OletxTransactionManager().$ctor$1($.$stl.System.Transactions.Configuration.DefaultSettingsSection.DistributedTransactionManagerName);
                }, {"r":3638756,"n":"","d":4883940,"h":0,"f":1048578}));
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.DistributedTransactionTrimmingWarning = "Distributed transactions support may not be compatible with trimming. If your program creates a distributed transaction via System.Transactions, the correctness of the application cannot be guaranteed after trimming.";
                }
                {
                    this.s_maximumTimeout = $.$default($.$spc.System.TimeSpan);
                }
            }
            static $h = 4883940;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":2459108,"g":{"r":0,"d":0,"h":64429393380,"f":33},"s":{"r":0,"d":0,"h":68724360676,"f":33},"n":"HostCurrentCallback","d":4883940,"h":60134426084,"f":33},{"p":131073,"g":{"r":0,"d":0,"h":94494164452,"f":34},"n":"ClassSyncObject","d":4883940,"h":90199197156,"f":34},{"p":3180004,"g":{"r":0,"d":0,"h":103084099044,"f":40},"n":"DefaultIsolationLevel","d":4883940,"h":98789131748,"f":40},{"p":755172,"g":{"r":0,"d":0,"h":115969000932,"f":34},"n":"DefaultSettings","d":4883940,"h":111674033636,"f":34},{"p":820708,"g":{"r":0,"d":0,"h":128853902820,"f":34},"n":"MachineSettings","d":4883940,"h":124558935524,"f":34},{"p":140705793,"g":{"r":0,"d":0,"h":146033772004,"f":33},"s":{"r":0,"d":0,"h":150328739300,"f":33},"n":"DefaultTimeout","d":4883940,"h":141738804708,"f":33},{"p":140705793,"g":{"r":0,"d":0,"h":167508608484,"f":33},"s":{"r":0,"d":0,"h":171803575780,"f":33},"n":"MaximumTimeout","d":4883940,"h":163213641188,"f":33},{"p":262145,"g":{"r":0,"d":0,"h":180393510372,"f":33},"s":{"r":0,"d":0,"h":184688477668,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},"n":"ImplicitDistributedTransactions","d":4883940,"h":176098543076,"f":33},{"p":30998529,"g":{"r":0,"d":0,"h":214753248740,"f":40},"n":"PromotedTransactionTable","d":4883940,"h":210458281444,"f":40},{"p":8488420,"g":{"r":0,"d":0,"h":223343183332,"f":40},"n":"TransactionTable","d":4883940,"h":219048216036,"f":40},{"p":3638756,"g":{"r":0,"d":0,"h":236228085220,"f":40},"n":"DistributedTransactionManager","d":4883940,"h":231933117924,"f":40}],"m":[{"r":65537,"p":[{"n":"eventHandler","p":5670372}],"n":"ProcessExistingTransactions","d":4883940,"h":42954556900,"f":40},{"r":65537,"p":[{"n":"transaction","p":4294116}],"n":"FireDistributedTransactionStarted","d":4883940,"h":47249524196,"f":40},{"r":1738212,"p":[{"n":"resourceManagerIdentifier","p":56229889},{"n":"recoveryInformation","p":0},{"n":"enlistmentNotification","p":2590180}],"n":"Reenlist","d":4883940,"h":73019327972,"f":33},{"r":3638756,"p":[{"n":"nodeName","p":1310721}],"n":"CheckTransactionManager","d":4883940,"h":77314295268,"f":34},{"r":65537,"p":[{"n":"resourceManagerIdentifier","p":56229889}],"n":"RecoveryComplete","d":4883940,"h":81609262564,"f":33},{"r":0,"p":[{"n":"startupInfo","p":1310721},{"n":"resourceManagerRecoveryInformation","p":0}],"n":"GetRecoveryInformation","d":4883940,"h":188983444964,"f":40},{"r":65537,"p":[{"n":"transactionIsolationLevel","p":3180004}],"n":"ValidateIsolationLevel","d":4883940,"h":193278412260,"f":40},{"r":140705793,"p":[{"n":"transactionTimeout","p":140705793}],"n":"ValidateTimeout","d":4883940,"h":197573379556,"f":40},{"r":4294116,"p":[{"n":"transactionIdentifier","p":56229889}],"n":"FindPromotedTransaction","d":4883940,"h":201868346852,"f":40},{"r":4294116,"p":[{"n":"transactionIdentifier","p":56229889},{"n":"dtx","p":3507684}],"n":"FindOrCreatePromotedTransaction","d":4883940,"h":206163314148,"f":40}],"l":[{"t":655361,"n":"RecoveryInformationVersion1","d":4883940,"h":4299851236,"f":34},{"t":655361,"n":"CurrentRecoveryVersion","d":4883940,"h":8594818532,"f":34},{"t":30998529,"n":"s_promotedTransactionTable","d":4883940,"h":12889785828,"f":34},{"t":8488420,"n":"s_transactionTable","d":4883940,"h":17184753124,"f":34},{"t":5670372,"n":"s_distributedTransactionStartedDelegate","d":4883940,"h":21479720420,"f":34},{"t":1310721,"n":"DistributedTransactionTrimmingWarning","d":4883940,"h":25774687716,"f":40},{"t":2459108,"n":"s_currentDelegate","d":4883940,"h":51544491492,"f":40},{"t":262145,"n":"s_currentDelegateSet","d":4883940,"h":55839458788,"f":40},{"t":131073,"n":"s_classSyncObject","d":4883940,"h":85904229860,"f":34},{"t":262145,"n":"s_defaultTimeoutValidated","d":4883940,"h":133148870116,"f":34},{"t":917505,"n":"s_defaultTimeoutTicks","d":4883940,"h":137443837412,"f":34},{"t":262145,"n":"s_cachedMaxTimeout","d":4883940,"h":154623706596,"f":34},{"t":140705793,"n":"s_maximumTimeout","d":4883940,"h":158918673892,"f":34},{"t":3638756,"n":"distributedTransactionManager","d":4883940,"h":227638150628,"f":40}],"e":[{"e":5670372,"m":{"r":65537,"p":[{"n":"value","p":5670372}],"n":"add_DistributedTransactionStarted","d":4883940,"h":34364622308,"f":33},"r":{"r":65537,"p":[{"n":"value","p":5670372}],"n":"remove_DistributedTransactionStarted","d":4883940,"h":38659589604,"f":33},"n":"DistributedTransactionStarted","d":4883940,"h":30069655012,"f":33}],"h":4883940}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Transactions.TransactionManager`; }
        });
        
        $asm.$cls("$stl.System.Transactions.CallContextCurrentData", ($self) => class CallContextCurrentData
        {
            /*AsyncLocal<ContextKey?>*/ static s_currentTransaction = null;
            /*ConditionalWeakTable<ContextKey, ContextData>*/ static s_contextDataTable = null;
            static /*ContextData */ CreateOrGetCurrentData(/*ContextKey*/ contextKey)
            {
                $.$stl.System.Transactions.CallContextCurrentData.s_currentTransaction.Value = contextKey;
                return $.$stl.System.Transactions.CallContextCurrentData.s_contextDataTable.GetValue(contextKey, new $.$spc.System.Runtime.CompilerServices.ConditionalWeakTable$$$($.$stl.System.Transactions.ContextKey, $.$stl.System.Transactions.ContextData).CreateValueCallback().$ctor(this,  (/*env*/ env) =>
                {
                    return new $.$stl.System.Transactions.ContextData().$ctor$1(true);
                }, {"r":886244,"p":[{"n":"env","p":951780}],"n":"","d":427492,"h":0,"f":1048578}));
            }
            static /*void */ ClearCurrentData(/*ContextKey?*/ contextKey, /*bool*/ removeContextData)
            {
                /*ContextKey?*/ let key = $.$stl.System.Transactions.CallContextCurrentData.s_currentTransaction.Value;
                if (contextKey !== null || key !== null)
                {
                    if (removeContextData)
                    {
                        $.$stl.System.Transactions.CallContextCurrentData.s_contextDataTable.Remove(contextKey ?? key);
                    }
                    if (key !== null)
                    {
                        $.$stl.System.Transactions.CallContextCurrentData.s_currentTransaction.Value = null;
                    }
                }
            }
            static /*bool */ TryGetCurrentData(/*out ContextData?*/ currentData)
            {
                currentData.$v = null;
                /*ContextKey?*/ let contextKey = $.$stl.System.Transactions.CallContextCurrentData.s_currentTransaction.Value;
                if (contextKey === null)
                {
                    return false;
                }
                else 
                {
                    return $.$stl.System.Transactions.CallContextCurrentData.s_contextDataTable.TryGetValue(contextKey, currentData);
                }
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_currentTransaction = new ($.$spc.System.Threading.AsyncLocal$$($.$stl.System.Transactions.ContextKey))().$ctor$1();
                }
                {
                    this.s_contextDataTable = new ($.$spc.System.Runtime.CompilerServices.ConditionalWeakTable$$$($.$stl.System.Transactions.ContextKey, $.$stl.System.Transactions.ContextData))().$ctor$1();
                }
            }
            static $h = 427492;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":886244,"p":[{"n":"contextKey","p":951780}],"n":"CreateOrGetCurrentData","d":427492,"h":12885329380,"f":33},{"r":65537,"p":[{"n":"contextKey","p":951780},{"n":"removeContextData","p":262145}],"n":"ClearCurrentData","d":427492,"h":17180296676,"f":33},{"r":262145,"p":[{"n":"currentData","p":886244,"f":2}],"n":"TryGetCurrentData","d":427492,"h":21475263972,"f":33}],"l":[{"t":$.$spc.System.Threading.AsyncLocal$$($.$stl.System.Transactions.ContextKey).$h,"n":"s_currentTransaction","d":427492,"h":4295394788,"f":34},{"t":$.$spc.System.Runtime.CompilerServices.ConditionalWeakTable$$$($.$stl.System.Transactions.ContextKey, $.$stl.System.Transactions.ContextData).$h,"n":"s_contextDataTable","d":427492,"h":8590362084,"f":34}],"h":427492}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Transactions.CallContextCurrentData`; }
        });
        
        $asm.$cls("$stl.System.Transactions.ContextKey", ($self) => class ContextKey extends $.$spc.System.Object
        {
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 951780;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"c":[{"n":".ctor","o":"$ctor$1","d":951780,"h":4295919076,"f":1}],"h":951780}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Transactions.ContextKey`; }
        });
        
        $asm.$cls("$stl.System.Transactions.ContextData", ($self) => class ContextData extends $.$spc.System.Object
        {
            /*TransactionScope?*/ CurrentScope = null;
            /*Transaction?*/ CurrentTransaction = null;
            /*DefaultComContextState*/ DefaultComContextState = 0;
            /*WeakReference?*/ WeakDefaultComContext = null;
            /*bool*/ _asyncFlow = false;
            /*ContextData?*/ static t_staticData = null;
            $ctor$1(/*bool*/ asyncFlow)
            {
                super.$ctor();
                {
                    this._asyncFlow = asyncFlow;
                }
                return this;
            }
            static /*ContextData */ get TLSCurrentData()
            {
                return $.$stl.System.Transactions.ContextData.t_staticData ??= new $.$stl.System.Transactions.ContextData().$ctor$1(false);
            }
            static /*ContextData */ set TLSCurrentData(value)
            {
                if (value === null && $.$stl.System.Transactions.ContextData.t_staticData !== null)
                {
                    $.$stl.System.Transactions.ContextData.t_staticData.CurrentScope = null;
                    $.$stl.System.Transactions.ContextData.t_staticData.CurrentTransaction = null;
                    $.$stl.System.Transactions.ContextData.t_staticData.DefaultComContextState = 0/*DefaultComContextState.Unknown*/;
                    $.$stl.System.Transactions.ContextData.t_staticData.WeakDefaultComContext = null;
                }
                else 
                {
                    $.$stl.System.Transactions.ContextData.t_staticData = value;
                }
            }
            static /*ContextData */ LookupContextData(/*TxLookup*/ defaultLookup)
            {
                /*ContextData?*/ let currentData;
                if ($.$stl.System.Transactions.CallContextCurrentData.TryGetCurrentData($.$ref(() => currentData, ($v) => currentData = $v, $.$stl.System.Transactions.ContextData)))
                {
                    if (currentData.CurrentScope === null && $.$stl.System.Transactions.Transaction.op_Equality(currentData.CurrentTransaction, null) && defaultLookup !== 1/*TxLookup.DefaultCallContext*/)
                    {
                        $.$stl.System.Transactions.CallContextCurrentData.ClearCurrentData(null, true);
                        return $.$stl.System.Transactions.ContextData.TLSCurrentData;
                    }
                    return currentData;
                }
                else 
                {
                    return $.$stl.System.Transactions.ContextData.TLSCurrentData;
                }
            }
            static $h = 886244;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":886244,"g":{"r":0,"d":0,"h":38655591908,"f":40},"s":{"r":0,"d":0,"h":42950559204,"f":40},"n":"TLSCurrentData","d":886244,"h":34360624612,"f":40}],"m":[{"r":886244,"p":[{"n":"defaultLookup","p":8619492}],"n":"LookupContextData","d":886244,"h":47245526500,"f":40}],"l":[{"t":5146084,"n":"CurrentScope","d":886244,"h":4295853540,"f":8},{"t":4294116,"n":"CurrentTransaction","d":886244,"h":8590820836,"f":8},{"t":1017316,"n":"DefaultComContextState","d":886244,"h":12885788132,"f":8},{"t":144769025,"n":"WeakDefaultComContext","d":886244,"h":17180755428,"f":8},{"t":262145,"n":"_asyncFlow","d":886244,"h":21475722724,"f":8},{"t":886244,"n":"t_staticData","d":886244,"h":25770690020,"f":34,"a":[{"t":140181505,"c":4435148801}]}],"c":[{"p":[{"n":"asyncFlow","p":262145}],"n":".ctor","o":"$ctor$1","d":886244,"h":30065657316,"f":8}],"h":886244}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Transactions.ContextData`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionScope", ($self) => class TransactionScope extends $.$spc.System.Object
        {
            $ctor$1()
            {
                this.$ctor$2(0/*TransactionScopeOption.Required*/);
                {
                }
                return this;
            }
            $ctor$2(/*TransactionScopeOption*/ scopeOption)
            {
                this.$ctor$4(scopeOption, 0/*TransactionScopeAsyncFlowOption.Suppress*/);
                {
                }
                return this;
            }
            $ctor$3(/*TransactionScopeAsyncFlowOption*/ asyncFlowOption)
            {
                this.$ctor$4(0/*TransactionScopeOption.Required*/, asyncFlowOption);
                {
                }
                return this;
            }
            $ctor$4(/*TransactionScopeOption*/ scopeOption, /*TransactionScopeAsyncFlowOption*/ asyncFlowOption)
            {
                super.$ctor();
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodEnter(0/*TraceSourceType.TraceSourceBase*/, this, "TransactionScope");
                    }
                    this.ValidateAndSetAsyncFlowOption(asyncFlowOption);
                    if (this.NeedToCreateTransaction(scopeOption))
                    {
                        this._committableTransaction = new $.$stl.System.Transactions.CommittableTransaction().$ctor$5();
                        this._expectedCurrent = this._committableTransaction.Clone();
                    }
                    if ($.$stl.System.Transactions.Transaction.op_Equality(null, this._expectedCurrent))
                    {
                        if (etwLog.IsEnabled())
                        {
                            etwLog.TransactionScopeCreated($.$stl.System.Transactions.TransactionTraceIdentifier.Empty, 4/*TransactionScopeResult.NoTransaction*/);
                        }
                    }
                    else 
                    {
                        /*TransactionScopeResult*/ let scopeResult;
                        if ($.$stl.System.Transactions.Transaction.op_Equality(null, this._committableTransaction))
                        {
                            scopeResult = 1/*TransactionScopeResult.UsingExistingCurrent*/;
                        }
                        else 
                        {
                            scopeResult = 0/*TransactionScopeResult.CreatedTransaction*/;
                        }
                        if (etwLog.IsEnabled())
                        {
                            etwLog.TransactionScopeCreated(this._expectedCurrent.TransactionTraceId, scopeResult);
                        }
                    }
                    this.PushScope();
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodExit(0/*TraceSourceType.TraceSourceBase*/, this, "TransactionScope");
                    }
                }
                return this;
            }
            $ctor$5(/*TransactionScopeOption*/ scopeOption, /*TimeSpan*/ scopeTimeout)
            {
                this.$ctor$6(scopeOption, scopeTimeout, 0/*TransactionScopeAsyncFlowOption.Suppress*/);
                {
                }
                return this;
            }
            $ctor$6(/*TransactionScopeOption*/ scopeOption, /*TimeSpan*/ scopeTimeout, /*TransactionScopeAsyncFlowOption*/ asyncFlowOption)
            {
                super.$ctor();
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodEnter(0/*TraceSourceType.TraceSourceBase*/, this, "TransactionScope");
                    }
                    $.$stl.System.Transactions.TransactionScope.ValidateScopeTimeout("scopeTimeout", scopeTimeout);
                    /*TimeSpan*/ let txTimeout = $.$stl.System.Transactions.TransactionManager.ValidateTimeout(scopeTimeout);
                    this.ValidateAndSetAsyncFlowOption(asyncFlowOption);
                    if (this.NeedToCreateTransaction(scopeOption))
                    {
                        this._committableTransaction = new $.$stl.System.Transactions.CommittableTransaction().$ctor$6(txTimeout);
                        this._expectedCurrent = this._committableTransaction.Clone();
                    }
                    if (($.$stl.System.Transactions.Transaction.op_Inequality(null, this._expectedCurrent)) && ($.$stl.System.Transactions.Transaction.op_Equality(null, this._committableTransaction)) && ($.$spc.System.TimeSpan.op_Inequality($.$spc.System.TimeSpan.Zero, scopeTimeout)))
                    {
                        this._scopeTimer = new $.$spc.System.Threading.Timer().$ctor$4(new $.$spc.System.Threading.TimerCallback().$ctor($.$stl.System.Transactions.TransactionScope, $.$stl.System.Transactions.TransactionScope.TimerCallback), this, scopeTimeout, $.$spc.System.TimeSpan.Zero);
                    }
                    if ($.$stl.System.Transactions.Transaction.op_Equality(null, this._expectedCurrent))
                    {
                        if (etwLog.IsEnabled())
                        {
                            etwLog.TransactionScopeCreated($.$stl.System.Transactions.TransactionTraceIdentifier.Empty, 4/*TransactionScopeResult.NoTransaction*/);
                        }
                    }
                    else 
                    {
                        /*TransactionScopeResult*/ let scopeResult;
                        if ($.$stl.System.Transactions.Transaction.op_Equality(null, this._committableTransaction))
                        {
                            scopeResult = 1/*TransactionScopeResult.UsingExistingCurrent*/;
                        }
                        else 
                        {
                            scopeResult = 0/*TransactionScopeResult.CreatedTransaction*/;
                        }
                        if (etwLog.IsEnabled())
                        {
                            etwLog.TransactionScopeCreated(this._expectedCurrent.TransactionTraceId, scopeResult);
                        }
                    }
                    this.PushScope();
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodExit(0/*TraceSourceType.TraceSourceBase*/, this, "TransactionScope");
                    }
                }
                return this;
            }
            $ctor$7(/*TransactionScopeOption*/ scopeOption, /*TransactionOptions*/ transactionOptions)
            {
                this.$ctor$8(scopeOption, transactionOptions.Clone(), 0/*TransactionScopeAsyncFlowOption.Suppress*/);
                {
                }
                return this;
            }
            $ctor$8(/*TransactionScopeOption*/ scopeOption, /*TransactionOptions*/ transactionOptions, /*TransactionScopeAsyncFlowOption*/ asyncFlowOption)
            {
                super.$ctor();
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodEnter(0/*TraceSourceType.TraceSourceBase*/, this, "TransactionScope");
                    }
                    $.$stl.System.Transactions.TransactionScope.ValidateScopeTimeout("transactionOptions.Timeout", transactionOptions.Timeout);
                    /*TimeSpan*/ let scopeTimeout = transactionOptions.Timeout;
                    transactionOptions.Timeout = $.$stl.System.Transactions.TransactionManager.ValidateTimeout(transactionOptions.Timeout);
                    $.$stl.System.Transactions.TransactionManager.ValidateIsolationLevel(transactionOptions.IsolationLevel);
                    this.ValidateAndSetAsyncFlowOption(asyncFlowOption);
                    if (this.NeedToCreateTransaction(scopeOption))
                    {
                        this._committableTransaction = new $.$stl.System.Transactions.CommittableTransaction().$ctor$7(transactionOptions.Clone());
                        this._expectedCurrent = this._committableTransaction.Clone();
                    }
                    else 
                    {
                        if ($.$stl.System.Transactions.Transaction.op_Inequality(null, this._expectedCurrent))
                        {
                            if ((6/*IsolationLevel.Unspecified*/ !== transactionOptions.IsolationLevel) && (this._expectedCurrent.IsolationLevel !== transactionOptions.IsolationLevel))
                            {
                                throw new $.$spc.System.ArgumentException().$ctor$13($.$stl.System.SR.TransactionScopeIsolationLevelDifferentFromTransaction, "transactionOptions");
                            }
                        }
                    }
                    if (($.$stl.System.Transactions.Transaction.op_Inequality(null, this._expectedCurrent)) && ($.$stl.System.Transactions.Transaction.op_Equality(null, this._committableTransaction)) && ($.$spc.System.TimeSpan.op_Inequality($.$spc.System.TimeSpan.Zero, scopeTimeout)))
                    {
                        this._scopeTimer = new $.$spc.System.Threading.Timer().$ctor$4(new $.$spc.System.Threading.TimerCallback().$ctor($.$stl.System.Transactions.TransactionScope, $.$stl.System.Transactions.TransactionScope.TimerCallback), this, scopeTimeout, $.$spc.System.TimeSpan.Zero);
                    }
                    if ($.$stl.System.Transactions.Transaction.op_Equality(null, this._expectedCurrent))
                    {
                        if (etwLog.IsEnabled())
                        {
                            etwLog.TransactionScopeCreated($.$stl.System.Transactions.TransactionTraceIdentifier.Empty, 4/*TransactionScopeResult.NoTransaction*/);
                        }
                    }
                    else 
                    {
                        /*TransactionScopeResult*/ let scopeResult;
                        if ($.$stl.System.Transactions.Transaction.op_Equality(null, this._committableTransaction))
                        {
                            scopeResult = 1/*TransactionScopeResult.UsingExistingCurrent*/;
                        }
                        else 
                        {
                            scopeResult = 0/*TransactionScopeResult.CreatedTransaction*/;
                        }
                        if (etwLog.IsEnabled())
                        {
                            etwLog.TransactionScopeCreated(this._expectedCurrent.TransactionTraceId, scopeResult);
                        }
                    }
                    this.PushScope();
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodExit(0/*TraceSourceType.TraceSourceBase*/, this, "TransactionScope");
                    }
                }
                return this;
            }
            $ctor$9(/*TransactionScopeOption*/ scopeOption, /*TransactionOptions*/ transactionOptions, /*EnterpriseServicesInteropOption*/ interopOption)
            {
                super.$ctor();
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodEnter(0/*TraceSourceType.TraceSourceBase*/, this, "TransactionScope");
                    }
                    $.$stl.System.Transactions.TransactionScope.ValidateScopeTimeout("transactionOptions.Timeout", transactionOptions.Timeout);
                    /*TimeSpan*/ let scopeTimeout = transactionOptions.Timeout;
                    transactionOptions.Timeout = $.$stl.System.Transactions.TransactionManager.ValidateTimeout(transactionOptions.Timeout);
                    $.$stl.System.Transactions.TransactionManager.ValidateIsolationLevel(transactionOptions.IsolationLevel);
                    $.$stl.System.Transactions.TransactionScope.ValidateInteropOption(interopOption);
                    this._interopModeSpecified = true;
                    this._interopOption = interopOption;
                    if (this.NeedToCreateTransaction(scopeOption))
                    {
                        this._committableTransaction = new $.$stl.System.Transactions.CommittableTransaction().$ctor$7(transactionOptions.Clone());
                        this._expectedCurrent = this._committableTransaction.Clone();
                    }
                    else 
                    {
                        if ($.$stl.System.Transactions.Transaction.op_Inequality(null, this._expectedCurrent))
                        {
                            if ((6/*IsolationLevel.Unspecified*/ !== transactionOptions.IsolationLevel) && (this._expectedCurrent.IsolationLevel !== transactionOptions.IsolationLevel))
                            {
                                throw new $.$spc.System.ArgumentException().$ctor$13($.$stl.System.SR.TransactionScopeIsolationLevelDifferentFromTransaction, "transactionOptions");
                            }
                        }
                    }
                    if (($.$stl.System.Transactions.Transaction.op_Inequality(null, this._expectedCurrent)) && ($.$stl.System.Transactions.Transaction.op_Equality(null, this._committableTransaction)) && ($.$spc.System.TimeSpan.op_Inequality($.$spc.System.TimeSpan.Zero, scopeTimeout)))
                    {
                        this._scopeTimer = new $.$spc.System.Threading.Timer().$ctor$4(new $.$spc.System.Threading.TimerCallback().$ctor($.$stl.System.Transactions.TransactionScope, $.$stl.System.Transactions.TransactionScope.TimerCallback), this, scopeTimeout, $.$spc.System.TimeSpan.Zero);
                    }
                    if ($.$stl.System.Transactions.Transaction.op_Equality(null, this._expectedCurrent))
                    {
                        if (etwLog.IsEnabled())
                        {
                            etwLog.TransactionScopeCreated($.$stl.System.Transactions.TransactionTraceIdentifier.Empty, 4/*TransactionScopeResult.NoTransaction*/);
                        }
                    }
                    else 
                    {
                        /*TransactionScopeResult*/ let scopeResult;
                        if ($.$stl.System.Transactions.Transaction.op_Equality(null, this._committableTransaction))
                        {
                            scopeResult = 1/*TransactionScopeResult.UsingExistingCurrent*/;
                        }
                        else 
                        {
                            scopeResult = 0/*TransactionScopeResult.CreatedTransaction*/;
                        }
                        if (etwLog.IsEnabled())
                        {
                            etwLog.TransactionScopeCreated(this._expectedCurrent.TransactionTraceId, scopeResult);
                        }
                    }
                    this.PushScope();
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodExit(0/*TraceSourceType.TraceSourceBase*/, this, "TransactionScope");
                    }
                }
                return this;
            }
            $ctor$10(/*Transaction*/ transactionToUse)
            {
                this.$ctor$11(transactionToUse, 0/*TransactionScopeAsyncFlowOption.Suppress*/);
                {
                }
                return this;
            }
            $ctor$11(/*Transaction*/ transactionToUse, /*TransactionScopeAsyncFlowOption*/ asyncFlowOption)
            {
                super.$ctor();
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodEnter(0/*TraceSourceType.TraceSourceBase*/, this, "TransactionScope");
                    }
                    this.ValidateAndSetAsyncFlowOption(asyncFlowOption);
                    this.Initialize(transactionToUse, $.$spc.System.TimeSpan.Zero, false);
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodExit(0/*TraceSourceType.TraceSourceBase*/, this, "TransactionScope");
                    }
                }
                return this;
            }
            $ctor$12(/*Transaction*/ transactionToUse, /*TimeSpan*/ scopeTimeout)
            {
                this.$ctor$13(transactionToUse, scopeTimeout, 0/*TransactionScopeAsyncFlowOption.Suppress*/);
                {
                }
                return this;
            }
            $ctor$13(/*Transaction*/ transactionToUse, /*TimeSpan*/ scopeTimeout, /*TransactionScopeAsyncFlowOption*/ asyncFlowOption)
            {
                super.$ctor();
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodEnter(0/*TraceSourceType.TraceSourceBase*/, this, "TransactionScope");
                    }
                    this.ValidateAndSetAsyncFlowOption(asyncFlowOption);
                    this.Initialize(transactionToUse, scopeTimeout, false);
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodExit(0/*TraceSourceType.TraceSourceBase*/, this, "TransactionScope");
                    }
                }
                return this;
            }
            $ctor$14(/*Transaction*/ transactionToUse, /*TimeSpan*/ scopeTimeout, /*EnterpriseServicesInteropOption*/ interopOption)
            {
                super.$ctor();
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodEnter(0/*TraceSourceType.TraceSourceBase*/, this, "TransactionScope");
                    }
                    $.$stl.System.Transactions.TransactionScope.ValidateInteropOption(interopOption);
                    this._interopOption = interopOption;
                    this.Initialize(transactionToUse, scopeTimeout, true);
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodExit(0/*TraceSourceType.TraceSourceBase*/, this, "TransactionScope");
                    }
                }
                return this;
            }
            /*bool */ NeedToCreateTransaction(/*TransactionScopeOption*/ scopeOption)
            {
                /*bool*/ let retVal = false;
                this.CommonInitialize();
                switch(scopeOption)
                {
                    case 2/*TransactionScopeOption.Suppress*/:
                    this._expectedCurrent = null;
                    retVal = false;
                    break;
                    case 0/*TransactionScopeOption.Required*/:
                    this._expectedCurrent = this._savedCurrent;
                    if ($.$stl.System.Transactions.Transaction.op_Equality(null, this._expectedCurrent))
                    {
                        retVal = true;
                    }
                    break;
                    case 1/*TransactionScopeOption.RequiresNew*/:
                    retVal = true;
                    break;
                    default:
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("scopeOption");
                }
                return retVal;
            }
            /*void */ Initialize(/*Transaction*/ transactionToUse, /*TimeSpan*/ scopeTimeout, /*bool*/ interopModeSpecified)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(transactionToUse, "transactionToUse");
                $.$stl.System.Transactions.TransactionScope.ValidateScopeTimeout("scopeTimeout", scopeTimeout);
                this.CommonInitialize();
                if ($.$spc.System.TimeSpan.op_Inequality($.$spc.System.TimeSpan.Zero, scopeTimeout))
                {
                    this._scopeTimer = new $.$spc.System.Threading.Timer().$ctor$4(new $.$spc.System.Threading.TimerCallback().$ctor($.$stl.System.Transactions.TransactionScope, $.$stl.System.Transactions.TransactionScope.TimerCallback), this, scopeTimeout, $.$spc.System.TimeSpan.Zero);
                }
                this._expectedCurrent = transactionToUse;
                this._interopModeSpecified = interopModeSpecified;
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionScopeCreated(this._expectedCurrent.TransactionTraceId, 2/*TransactionScopeResult.TransactionPassed*/);
                }
                this.PushScope();
            }
            /*void */ Dispose()
            {
                /*bool*/ let successful = false;
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(0/*TraceSourceType.TraceSourceBase*/, this, "Dispose");
                }
                if (this._disposed)
                {
                    if (etwLog.IsEnabled())
                    {
                        etwLog.MethodExit(0/*TraceSourceType.TraceSourceBase*/, this, "Dispose");
                    }
                    return;
                }
                if ((this._scopeThread !== $.$spc.System.Threading.Thread.CurrentThread) && !this.AsyncFlowEnabled)
                {
                    if (etwLog.IsEnabled())
                    {
                        etwLog.InvalidOperation("TransactionScope", "InvalidScopeThread");
                    }
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$stl.System.SR.InvalidScopeThread);
                }
                /*Exception?*/ let exToThrow = null;
                try
                {
                    this._disposed = true;
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._threadContextData !== null, "_threadContextData != null");
                    /*TransactionScope?*/ let actualCurrentScope = this._threadContextData.CurrentScope;
                    /*Transaction?*/ let contextTransaction = null;
                    /*Transaction?*/ let current = $.$stl.System.Transactions.Transaction.FastGetTransaction(actualCurrentScope, this._threadContextData, $.$ref(() => contextTransaction, ($v) => contextTransaction = $v, $.$stl.System.Transactions.Transaction));
                    if (!$.$spc.System.Object.Equals.call(this, actualCurrentScope))
                    {
                        if (actualCurrentScope === null)
                        {
                            /*Transaction?*/ let rollbackTransaction = this._committableTransaction ?? this._dependentTransaction;
                            $.$spc.System.Diagnostics.Debug.Assert$1($.$stl.System.Transactions.Transaction.op_Inequality(rollbackTransaction, null), "rollbackTransaction != null");
                            rollbackTransaction.Rollback();
                            successful = true;
                            throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException$1(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionScopeInvalidNesting, null, rollbackTransaction.DistributedTxId);
                        }
                        else if (0/*EnterpriseServicesInteropOption.None*/ === actualCurrentScope._interopOption)
                        {
                            if ((($.$stl.System.Transactions.Transaction.op_Inequality(null, actualCurrentScope._expectedCurrent)) && (!$.$stl.System.Transactions.Transaction.Equals.call(actualCurrentScope._expectedCurrent, current))) || (($.$stl.System.Transactions.Transaction.op_Inequality(null, current)) && ($.$stl.System.Transactions.Transaction.op_Equality(null, actualCurrentScope._expectedCurrent))))
                            {
                                /*TransactionTraceIdentifier*/ let myId;
                                /*TransactionTraceIdentifier*/ let currentId;
                                if ($.$stl.System.Transactions.Transaction.op_Equality(null, current))
                                {
                                    currentId = $.$stl.System.Transactions.TransactionTraceIdentifier.Empty;
                                }
                                else 
                                {
                                    currentId = current.TransactionTraceId;
                                }
                                if ($.$stl.System.Transactions.Transaction.op_Equality(null, this._expectedCurrent))
                                {
                                    myId = $.$stl.System.Transactions.TransactionTraceIdentifier.Empty;
                                }
                                else 
                                {
                                    myId = this._expectedCurrent.TransactionTraceId;
                                }
                                if (etwLog.IsEnabled())
                                {
                                    etwLog.TransactionScopeCurrentChanged(currentId, myId);
                                }
                                exToThrow = $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException$1(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionScopeIncorrectCurrent, null, $.$stl.System.Transactions.Transaction.op_Equality(current, null) ? $.$spc.System.Guid.Empty : current.DistributedTxId);
                                if ($.$stl.System.Transactions.Transaction.op_Inequality(null, current))
                                {
                                    try
                                    {
                                        current.Rollback();
                                    }
                                    catch($e)
                                    {
                                        if ($e instanceof $.$stl.System.Transactions.TransactionException)
                                        {
                                        }
                                        else if ($e instanceof $.$spc.System.ObjectDisposedException)
                                        {
                                        }
                                        else
                                        {
                                            throw $e;
                                        }
                                    }
                                }
                            }
                        }
                        while(!$.$spc.System.Object.Equals.call(this, actualCurrentScope))
                        {
                            if (null === exToThrow)
                            {
                                exToThrow = $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException$1(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionScopeInvalidNesting, null, $.$stl.System.Transactions.Transaction.op_Equality(current, null) ? $.$spc.System.Guid.Empty : current.DistributedTxId);
                            }
                            if ($.$stl.System.Transactions.Transaction.op_Equality(null, actualCurrentScope._expectedCurrent))
                            {
                                if (etwLog.IsEnabled())
                                {
                                    etwLog.TransactionScopeNestedIncorrectly($.$stl.System.Transactions.TransactionTraceIdentifier.Empty);
                                }
                            }
                            else 
                            {
                                if (etwLog.IsEnabled())
                                {
                                    etwLog.TransactionScopeNestedIncorrectly(actualCurrentScope._expectedCurrent.TransactionTraceId);
                                }
                            }
                            actualCurrentScope._complete = false;
                            try
                            {
                                actualCurrentScope.InternalDispose();
                            }
                            catch($e)
                            {
                            }
                            actualCurrentScope = this._threadContextData.CurrentScope;
                            this._complete = false;
                        }
                    }
                    else 
                    {
                        if (0/*EnterpriseServicesInteropOption.None*/ === this._interopOption)
                        {
                            if ((($.$stl.System.Transactions.Transaction.op_Inequality(null, this._expectedCurrent)) && (!$.$stl.System.Transactions.Transaction.Equals.call(this._expectedCurrent, current))) || (($.$stl.System.Transactions.Transaction.op_Inequality(null, current)) && ($.$stl.System.Transactions.Transaction.op_Equality(null, this._expectedCurrent))))
                            {
                                /*TransactionTraceIdentifier*/ let myId;
                                /*TransactionTraceIdentifier*/ let currentId;
                                if ($.$stl.System.Transactions.Transaction.op_Equality(null, current))
                                {
                                    currentId = $.$stl.System.Transactions.TransactionTraceIdentifier.Empty;
                                }
                                else 
                                {
                                    currentId = current.TransactionTraceId;
                                }
                                if ($.$stl.System.Transactions.Transaction.op_Equality(null, this._expectedCurrent))
                                {
                                    myId = $.$stl.System.Transactions.TransactionTraceIdentifier.Empty;
                                }
                                else 
                                {
                                    myId = this._expectedCurrent.TransactionTraceId;
                                }
                                if (etwLog.IsEnabled())
                                {
                                    etwLog.TransactionScopeCurrentChanged(currentId, myId);
                                }
                                if (null === exToThrow)
                                {
                                    exToThrow = $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException$1(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionScopeIncorrectCurrent, null, $.$stl.System.Transactions.Transaction.op_Equality(current, null) ? $.$spc.System.Guid.Empty : current.DistributedTxId);
                                }
                                if ($.$stl.System.Transactions.Transaction.op_Inequality(null, current))
                                {
                                    try
                                    {
                                        current.Rollback();
                                    }
                                    catch($e)
                                    {
                                        if ($e instanceof $.$stl.System.Transactions.TransactionException)
                                        {
                                        }
                                        else if ($e instanceof $.$spc.System.ObjectDisposedException)
                                        {
                                        }
                                        else
                                        {
                                            throw $e;
                                        }
                                    }
                                }
                                this._complete = false;
                            }
                        }
                    }
                    successful = true;
                }
                finally
                {
                    {
                        if (!successful)
                        {
                            this.PopScope();
                        }
                    }
                }
                this.InternalDispose();
                if (null !== exToThrow)
                {
                    throw exToThrow;
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(0/*TraceSourceType.TraceSourceBase*/, this, "Dispose");
                }
            }
            /*void */ InternalDispose()
            {
                this._disposed = true;
                try
                {
                    this.PopScope();
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if ($.$stl.System.Transactions.Transaction.op_Equality(null, this._expectedCurrent))
                    {
                        if (etwLog.IsEnabled())
                        {
                            etwLog.TransactionScopeDisposed($.$stl.System.Transactions.TransactionTraceIdentifier.Empty);
                        }
                    }
                    else 
                    {
                        if (etwLog.IsEnabled())
                        {
                            etwLog.TransactionScopeDisposed(this._expectedCurrent.TransactionTraceId);
                        }
                    }
                    if ($.$stl.System.Transactions.Transaction.op_Inequality(null, this._expectedCurrent))
                    {
                        if (!this._complete)
                        {
                            if (etwLog.IsEnabled())
                            {
                                etwLog.TransactionScopeIncomplete(this._expectedCurrent.TransactionTraceId);
                            }
                            /*Transaction?*/ let rollbackTransaction = this._committableTransaction ?? this._dependentTransaction;
                            $.$spc.System.Diagnostics.Debug.Assert$1($.$stl.System.Transactions.Transaction.op_Inequality(rollbackTransaction, null), "rollbackTransaction != null");
                            rollbackTransaction.Rollback();
                        }
                        else 
                        {
                            if ($.$stl.System.Transactions.Transaction.op_Inequality(null, this._committableTransaction))
                            {
                                this._committableTransaction.Commit();
                            }
                            else 
                            {
                                $.$spc.System.Diagnostics.Debug.Assert$1($.$stl.System.Transactions.Transaction.op_Inequality(null, this._dependentTransaction), "null != this.dependentTransaction");
                                this._dependentTransaction.Complete();
                            }
                        }
                    }
                }
                finally
                {
                    {
                        this._scopeTimer?.Dispose$1();
                        if ($.$stl.System.Transactions.Transaction.op_Inequality(null, this._committableTransaction))
                        {
                            this._committableTransaction.Dispose();
                            $.$spc.System.Diagnostics.Debug.Assert$1($.$stl.System.Transactions.Transaction.op_Inequality(this._expectedCurrent, null), "_expectedCurrent != null");
                            this._expectedCurrent.Dispose();
                        }
                        this._dependentTransaction?.Dispose();
                    }
                }
            }
            /*void */ Complete()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(0/*TraceSourceType.TraceSourceBase*/, this, "Complete");
                }
                $.$spc.System.ObjectDisposedException.ThrowIf(this._disposed, this);
                if (this._complete)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.DisposeScope, null);
                }
                this._complete = true;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(0/*TraceSourceType.TraceSourceBase*/, this, "Complete");
                }
            }
            static /*void */ TimerCallback(/*object?*/ state)
            {
                /*TransactionScope?*/ let scope = $.$as(state, $.$stl.System.Transactions.TransactionScope);
                if (null === scope)
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.InternalError("TransactionScopeTimerObjectInvalid");
                    }
                    throw $.$stl.System.Transactions.TransactionException.Create($.$stl.System.SR.InternalError + $.$stl.System.SR.TransactionScopeTimerObjectInvalid, null);
                }
                scope.Timeout();
            }
            /*void */ Timeout()
            {
                if ((!this._complete) && ($.$stl.System.Transactions.Transaction.op_Inequality(null, this._expectedCurrent)))
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.TransactionScopeTimeout(this._expectedCurrent.TransactionTraceId);
                    }
                    try
                    {
                        this._expectedCurrent.Rollback();
                    }
                    catch($e)
                    {
                        if ($e instanceof $.$spc.System.ObjectDisposedException)
                        {
                            let ex = $e;
                            if (etwLog.IsEnabled())
                            {
                                etwLog.ExceptionConsumed(0/*TraceSourceType.TraceSourceBase*/, ex);
                            }
                        }
                        else if ($e instanceof $.$stl.System.Transactions.TransactionException)
                        {
                            let txEx = $e;
                            if (etwLog.IsEnabled())
                            {
                                etwLog.ExceptionConsumed(0/*TraceSourceType.TraceSourceBase*/, txEx);
                            }
                        }
                        else
                        {
                            throw $e;
                        }
                    }
                }
            }
            /*void */ CommonInitialize()
            {
                this.ContextKey = new $.$stl.System.Transactions.ContextKey().$ctor$1();
                this._complete = false;
                this._dependentTransaction = null;
                this._disposed = false;
                this._committableTransaction = null;
                this._expectedCurrent = null;
                this._scopeTimer = null;
                this._scopeThread = $.$spc.System.Threading.Thread.CurrentThread;
                $.$stl.System.Transactions.Transaction.GetCurrentTransactionAndScope(this.AsyncFlowEnabled ? 1/*TxLookup.DefaultCallContext*/ : 2/*TxLookup.DefaultTLS*/, $.$ref(() => this._savedCurrent, ($v) => this._savedCurrent = $v, $.$stl.System.Transactions.Transaction), $.$ref(() => this._savedCurrentScope, ($v) => this._savedCurrentScope = $v, $.$stl.System.Transactions.TransactionScope), $.$ref(() => this._contextTransaction, ($v) => this._contextTransaction = $v, $.$stl.System.Transactions.Transaction));
                this.ValidateAsyncFlowOptionAndESInteropOption();
            }
            /*void */ PushScope()
            {
                if (!this._interopModeSpecified)
                {
                    this._interopOption = $.$stl.System.Transactions.Transaction.InteropMode(this._savedCurrentScope);
                }
                this.SaveTLSContextData();
                if (this.AsyncFlowEnabled)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(this.ContextKey !== null, "ContextKey != null");
                    this._threadContextData = $.$stl.System.Transactions.CallContextCurrentData.CreateOrGetCurrentData(this.ContextKey);
                    if (this._savedCurrentScope === null && $.$stl.System.Transactions.Transaction.op_Equality(this._savedCurrent, null))
                    {
                        $.$stl.System.Transactions.ContextData.TLSCurrentData = null;
                    }
                }
                else 
                {
                    this._threadContextData = $.$stl.System.Transactions.ContextData.TLSCurrentData;
                    $.$stl.System.Transactions.CallContextCurrentData.ClearCurrentData(this.ContextKey, false);
                }
                this.SetCurrent(this._expectedCurrent);
                this._threadContextData.CurrentScope = this;
            }
            /*void */ PopScope()
            {
                /*bool*/ let shouldRestoreContextData = true;
                if (this.AsyncFlowEnabled)
                {
                    $.$stl.System.Transactions.CallContextCurrentData.ClearCurrentData(this.ContextKey, true);
                }
                if (this._scopeThread === $.$spc.System.Threading.Thread.CurrentThread)
                {
                    this.RestoreSavedTLSContextData();
                }
                if (this._savedCurrentScope !== null)
                {
                    if (this._savedCurrentScope.AsyncFlowEnabled)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._savedCurrentScope.ContextKey !== null, "_savedCurrentScope.ContextKey != null");
                        this._threadContextData = $.$stl.System.Transactions.CallContextCurrentData.CreateOrGetCurrentData(this._savedCurrentScope.ContextKey);
                    }
                    else 
                    {
                        if (this._savedCurrentScope._scopeThread !== $.$spc.System.Threading.Thread.CurrentThread)
                        {
                            shouldRestoreContextData = false;
                            $.$stl.System.Transactions.ContextData.TLSCurrentData = null;
                        }
                        else 
                        {
                            this._threadContextData = $.$stl.System.Transactions.ContextData.TLSCurrentData;
                        }
                        $.$stl.System.Transactions.CallContextCurrentData.ClearCurrentData(this._savedCurrentScope.ContextKey, false);
                    }
                }
                else 
                {
                    $.$stl.System.Transactions.CallContextCurrentData.ClearCurrentData(null, false);
                    if (this._scopeThread !== $.$spc.System.Threading.Thread.CurrentThread)
                    {
                        shouldRestoreContextData = false;
                        $.$stl.System.Transactions.ContextData.TLSCurrentData = null;
                    }
                    else 
                    {
                        $.$stl.System.Transactions.ContextData.TLSCurrentData = this._threadContextData;
                    }
                }
                if (shouldRestoreContextData)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._threadContextData !== null, "_threadContextData != null");
                    this._threadContextData.CurrentScope = this._savedCurrentScope;
                    this.RestoreCurrent();
                }
            }
            /*void */ SetCurrent(/*Transaction?*/ newCurrent)
            {
                if (this._dependentTransaction === null && this._committableTransaction === null)
                {
                    if ($.$stl.System.Transactions.Transaction.op_Inequality(newCurrent, null))
                    {
                        this._dependentTransaction = newCurrent.DependentClone(1/*DependentCloneOption.RollbackIfNotComplete*/);
                    }
                }
                switch(this._interopOption)
                {
                    case 0/*EnterpriseServicesInteropOption.None*/:
                    this._threadContextData.CurrentTransaction = newCurrent;
                    break;
                    case 1/*EnterpriseServicesInteropOption.Automatic*/:
                    $.$stl.System.Transactions.EnterpriseServices.VerifyEnterpriseServicesOk();
                    if ($.$stl.System.Transactions.EnterpriseServices.UseServiceDomainForCurrent())
                    {
                        $.$stl.System.Transactions.EnterpriseServices.PushServiceDomain();
                    }
                    else 
                    {
                        this._threadContextData.CurrentTransaction = newCurrent;
                    }
                    break;
                    case 2/*EnterpriseServicesInteropOption.Full*/:
                    $.$stl.System.Transactions.EnterpriseServices.VerifyEnterpriseServicesOk();
                    $.$stl.System.Transactions.EnterpriseServices.PushServiceDomain();
                    break;
                }
            }
            /*void */ SaveTLSContextData()
            {
                this._savedTLSContextData ??= new $.$stl.System.Transactions.ContextData().$ctor$1(false);
                this._savedTLSContextData.CurrentScope = $.$stl.System.Transactions.ContextData.TLSCurrentData.CurrentScope;
                this._savedTLSContextData.CurrentTransaction = $.$stl.System.Transactions.ContextData.TLSCurrentData.CurrentTransaction;
                this._savedTLSContextData.DefaultComContextState = $.$stl.System.Transactions.ContextData.TLSCurrentData.DefaultComContextState;
                this._savedTLSContextData.WeakDefaultComContext = $.$stl.System.Transactions.ContextData.TLSCurrentData.WeakDefaultComContext;
            }
            /*void */ RestoreSavedTLSContextData()
            {
                if (this._savedTLSContextData !== null)
                {
                    $.$stl.System.Transactions.ContextData.TLSCurrentData.CurrentScope = this._savedTLSContextData.CurrentScope;
                    $.$stl.System.Transactions.ContextData.TLSCurrentData.CurrentTransaction = this._savedTLSContextData.CurrentTransaction;
                    $.$stl.System.Transactions.ContextData.TLSCurrentData.DefaultComContextState = this._savedTLSContextData.DefaultComContextState;
                    $.$stl.System.Transactions.ContextData.TLSCurrentData.WeakDefaultComContext = this._savedTLSContextData.WeakDefaultComContext;
                }
            }
            /*void */ RestoreCurrent()
            {
                if ($.$stl.System.Transactions.EnterpriseServices.CreatedServiceDomain)
                {
                    $.$stl.System.Transactions.EnterpriseServices.LeaveServiceDomain();
                }
                this._threadContextData.CurrentTransaction = this._contextTransaction;
            }
            static /*void */ ValidateInteropOption(/*EnterpriseServicesInteropOption*/ interopOption)
            {
                if (interopOption < 0/*EnterpriseServicesInteropOption.None*/ || interopOption > 2/*EnterpriseServicesInteropOption.Full*/)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("interopOption");
                }
            }
            static /*void */ ValidateScopeTimeout(/*string?*/ paramName, /*TimeSpan*/ scopeTimeout)
            {
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfLessThan($.$spc.System.TimeSpan, scopeTimeout, $.$spc.System.TimeSpan.Zero, paramName);
            }
            /*void */ ValidateAndSetAsyncFlowOption(/*TransactionScopeAsyncFlowOption*/ asyncFlowOption)
            {
                if (asyncFlowOption < 0/*TransactionScopeAsyncFlowOption.Suppress*/ || asyncFlowOption > 1/*TransactionScopeAsyncFlowOption.Enabled*/)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("asyncFlowOption");
                }
                if (asyncFlowOption === 1/*TransactionScopeAsyncFlowOption.Enabled*/)
                {
                    this.AsyncFlowEnabled = true;
                }
            }
            /*void */ ValidateAsyncFlowOptionAndESInteropOption()
            {
                if (this.AsyncFlowEnabled)
                {
                    /*EnterpriseServicesInteropOption*/ let currentInteropOption = this._interopOption;
                    if (!this._interopModeSpecified)
                    {
                        currentInteropOption = $.$stl.System.Transactions.Transaction.InteropMode(this._savedCurrentScope);
                    }
                    if (currentInteropOption !== 0/*EnterpriseServicesInteropOption.None*/)
                    {
                        throw new $.$spc.System.NotSupportedException().$ctor$10($.$stl.System.SR.AsyncFlowAndESInteropNotSupported);
                    }
                }
            }
            /*bool*/ _complete = false;
            /*bool */ get ScopeComplete()
            {
                return this._complete;
            }
            /*Transaction?*/ _savedCurrent = null;
            /*Transaction?*/ _contextTransaction = null;
            /*TransactionScope?*/ _savedCurrentScope = null;
            /*ContextData?*/ _threadContextData = null;
            /*ContextData?*/ _savedTLSContextData = null;
            /*Transaction?*/ _expectedCurrent = null;
            /*CommittableTransaction?*/ _committableTransaction = null;
            /*DependentTransaction?*/ _dependentTransaction = null;
            /*bool*/ _disposed = false;
            /*Timer?*/ _scopeTimer = null;
            /*Thread?*/ _scopeThread = null;
            /*bool*/ _interopModeSpecified = false;
            /*EnterpriseServicesInteropOption*/ _interopOption = 0;
            /*EnterpriseServicesInteropOption */ get InteropMode()
            {
                return this._interopOption;
            }
            /*ContextKey?*/ ContextKey = null;
            /*bool*/ AsyncFlowEnabled = false;
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this.AsyncFlowEnabled = false;
            }
            static $h = 5146084;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":150329001444,"f":8},"n":"ScopeComplete","d":5146084,"h":146034034148,"f":8},{"p":2262500,"g":{"r":0,"d":0,"h":214753510884,"f":8},"n":"InteropMode","d":5146084,"h":210458543588,"f":8},{"p":951780,"g":{"r":0,"d":0,"h":227638412772,"f":8},"s":{"r":0,"d":0,"h":231933380068,"f":2},"n":"ContextKey","d":5146084,"h":223343445476,"f":8},{"p":262145,"g":{"r":0,"d":0,"h":244818281956,"f":8},"s":{"r":0,"d":0,"h":249113249252,"f":2},"n":"AsyncFlowEnabled","d":5146084,"h":240523314660,"f":8}],"m":[{"r":262145,"p":[{"n":"scopeOption","p":5277156}],"n":"NeedToCreateTransaction","d":5146084,"h":64429655524,"f":2},{"r":65537,"p":[{"n":"transactionToUse","p":4294116},{"n":"scopeTimeout","p":140705793},{"n":"interopModeSpecified","p":262145}],"n":"Initialize","d":5146084,"h":68724622820,"f":2},{"r":65537,"n":"Dispose","d":5146084,"h":73019590116,"f":1},{"r":65537,"n":"InternalDispose","d":5146084,"h":77314557412,"f":2},{"r":65537,"n":"Complete","d":5146084,"h":81609524708,"f":1},{"r":65537,"p":[{"n":"state","p":131073}],"n":"TimerCallback","d":5146084,"h":85904492004,"f":34},{"r":65537,"n":"Timeout","d":5146084,"h":90199459300,"f":2},{"r":65537,"n":"CommonInitialize","d":5146084,"h":94494426596,"f":2},{"r":65537,"n":"PushScope","d":5146084,"h":98789393892,"f":2},{"r":65537,"n":"PopScope","d":5146084,"h":103084361188,"f":2},{"r":65537,"p":[{"n":"newCurrent","p":4294116}],"n":"SetCurrent","d":5146084,"h":107379328484,"f":2},{"r":65537,"n":"SaveTLSContextData","d":5146084,"h":111674295780,"f":2},{"r":65537,"n":"RestoreSavedTLSContextData","d":5146084,"h":115969263076,"f":2},{"r":65537,"n":"RestoreCurrent","d":5146084,"h":120264230372,"f":2},{"r":65537,"p":[{"n":"interopOption","p":2262500}],"n":"ValidateInteropOption","d":5146084,"h":124559197668,"f":34},{"r":65537,"p":[{"n":"paramName","p":1310721},{"n":"scopeTimeout","p":140705793}],"n":"ValidateScopeTimeout","d":5146084,"h":128854164964,"f":34},{"r":65537,"p":[{"n":"asyncFlowOption","p":5211620}],"n":"ValidateAndSetAsyncFlowOption","d":5146084,"h":133149132260,"f":2},{"r":65537,"n":"ValidateAsyncFlowOptionAndESInteropOption","d":5146084,"h":137444099556,"f":2}],"l":[{"t":262145,"n":"_complete","d":5146084,"h":141739066852,"f":2},{"t":4294116,"n":"_savedCurrent","d":5146084,"h":154623968740,"f":2},{"t":4294116,"n":"_contextTransaction","d":5146084,"h":158918936036,"f":2},{"t":5146084,"n":"_savedCurrentScope","d":5146084,"h":163213903332,"f":2},{"t":886244,"n":"_threadContextData","d":5146084,"h":167508870628,"f":2},{"t":886244,"n":"_savedTLSContextData","d":5146084,"h":171803837924,"f":2},{"t":4294116,"n":"_expectedCurrent","d":5146084,"h":176098805220,"f":2},{"t":558564,"n":"_committableTransaction","d":5146084,"h":180393772516,"f":2},{"t":1148388,"n":"_dependentTransaction","d":5146084,"h":184688739812,"f":2},{"t":262145,"n":"_disposed","d":5146084,"h":188983707108,"f":2},{"t":138543105,"n":"_scopeTimer","d":5146084,"h":193278674404,"f":2},{"t":136445953,"n":"_scopeThread","d":5146084,"h":197573641700,"f":2},{"t":262145,"n":"_interopModeSpecified","d":5146084,"h":201868608996,"f":2},{"t":2262500,"n":"_interopOption","d":5146084,"h":206163576292,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":5146084,"h":4300113380,"f":1},{"p":[{"n":"scopeOption","p":5277156}],"n":".ctor","o":"$ctor$2","d":5146084,"h":8595080676,"f":1},{"p":[{"n":"asyncFlowOption","p":5211620}],"n":".ctor","o":"$ctor$3","d":5146084,"h":12890047972,"f":1},{"p":[{"n":"scopeOption","p":5277156},{"n":"asyncFlowOption","p":5211620}],"n":".ctor","o":"$ctor$4","d":5146084,"h":17185015268,"f":1},{"p":[{"n":"scopeOption","p":5277156},{"n":"scopeTimeout","p":140705793}],"n":".ctor","o":"$ctor$5","d":5146084,"h":21479982564,"f":1},{"p":[{"n":"scopeOption","p":5277156},{"n":"scopeTimeout","p":140705793},{"n":"asyncFlowOption","p":5211620}],"n":".ctor","o":"$ctor$6","d":5146084,"h":25774949860,"f":1},{"p":[{"n":"scopeOption","p":5277156},{"n":"transactionOptions","p":5015012}],"n":".ctor","o":"$ctor$7","d":5146084,"h":30069917156,"f":1},{"p":[{"n":"scopeOption","p":5277156},{"n":"transactionOptions","p":5015012},{"n":"asyncFlowOption","p":5211620}],"n":".ctor","o":"$ctor$8","d":5146084,"h":34364884452,"f":1},{"p":[{"n":"scopeOption","p":5277156},{"n":"transactionOptions","p":5015012},{"n":"interopOption","p":2262500}],"n":".ctor","o":"$ctor$9","d":5146084,"h":38659851748,"f":1},{"p":[{"n":"transactionToUse","p":4294116}],"n":".ctor","o":"$ctor$10","d":5146084,"h":42954819044,"f":1},{"p":[{"n":"transactionToUse","p":4294116},{"n":"asyncFlowOption","p":5211620}],"n":".ctor","o":"$ctor$11","d":5146084,"h":47249786340,"f":1},{"p":[{"n":"transactionToUse","p":4294116},{"n":"scopeTimeout","p":140705793}],"n":".ctor","o":"$ctor$12","d":5146084,"h":51544753636,"f":1},{"p":[{"n":"transactionToUse","p":4294116},{"n":"scopeTimeout","p":140705793},{"n":"asyncFlowOption","p":5211620}],"n":".ctor","o":"$ctor$13","d":5146084,"h":55839720932,"f":1},{"p":[{"n":"transactionToUse","p":4294116},{"n":"scopeTimeout","p":140705793},{"n":"interopOption","p":2262500}],"n":".ctor","o":"$ctor$14","d":5146084,"h":60134688228,"f":1}],"i":[57540609],"h":5146084,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Transactions.TransactionScope`; }
        });
        
        $asm.$cls("$stl.System.Transactions.Oletx.OletxTransaction", ($self) => class OletxTransaction extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*SerializationInfo*/ serializationInfo, /*StreamingContext*/ context)
            {
                super.$ctor();
                {
                    throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                }
                return this;
            }
            /*Exception?*/ InnerException = null;
            /*Guid*/ Identifier;
            /*RealOletxTransaction?*/ RealTransaction = null;
            /*TransactionTraceIdentifier*/ TransactionTraceId;
            /*IsolationLevel*/ IsolationLevel = 0;
            /*Transaction?*/ SavedLtmPromotedTransaction = null;
            /*IPromotedEnlistment */ EnlistVolatile(/*InternalEnlistment*/ internalEnlistment, /*EnlistmentOptions*/ enlistmentOptions)
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransaction.NotSupported();
            }
            /*IPromotedEnlistment */ EnlistDurable(/*Guid*/ resourceManagerIdentifier, /*DurableInternalEnlistment*/ internalEnlistment, /*bool*/ v, /*EnlistmentOptions*/ enlistmentOptions)
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransaction.NotSupported();
            }
            /*void */ Rollback()
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransaction.NotSupported();
            }
            /*OletxDependentTransaction */ DependentClone(/*bool*/ delayCommit)
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransaction.NotSupported();
            }
            /*IPromotedEnlistment */ EnlistVolatile$1(/*VolatileDemultiplexer*/ volatileDemux, /*EnlistmentOptions*/ enlistmentOptions)
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransaction.NotSupported();
            }
            static /*byte[] */ GetExportCookie(/*byte[]*/ whereaboutsCopy)
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransaction.NotSupported();
            }
            static /*byte[] */ GetTransmitterPropagationToken()
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransaction.NotSupported();
            }
            static /*IDtcTransaction */ GetDtcTransaction()
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransaction.NotSupported();
            }
            /*void */ GetObjectData(/*SerializationInfo*/ serializationInfo, /*StreamingContext*/ context)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose()
            {
            }
            static /*Exception */ NotSupported()
            {
                return new $.$spc.System.PlatformNotSupportedException().$ctor$14($.$stl.System.SR.DistributedNotSupported);
            }
            static $_RealOletxTransaction;
            static get RealOletxTransaction()
            {
                let $cls = $.$stl.System.Transactions.Oletx.OletxTransaction;
                return $cls.$_RealOletxTransaction ??= $asm.$ncls("$stl.System.Transactions.Oletx.OletxTransaction.RealOletxTransaction", ($self) => class RealOletxTransaction extends $.$spc.System.Object
                {
                    /*InternalTransaction?*/ InternalTransaction = null;
                    //default reference type constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        return this;
                    }
                    static $h = 3573220;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":2786788,"g":{"r":0,"d":0,"h":12888475108,"f":8},"s":{"r":0,"d":0,"h":17183442404,"f":8},"n":"InternalTransaction","d":3573220,"h":8593507812,"f":8}],"c":[{"n":".ctor","o":"$ctor$1","d":3573220,"h":21478409700,"f":1}],"d":3507684,"h":3573220}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Transactions.Oletx.OletxTransaction.RealOletxTransaction`; }
                }, $cls, ($v) => $cls.$_RealOletxTransaction = $v);
            }
            //Generated interface implemetation for System.Runtime.Serialization.ISerializable.GetObjectData(System.Runtime.Serialization.SerializationInfo, System.Runtime.Serialization.StreamingContext)
            System$Runtime$Serialization$ISerializable$GetObjectData()
            {
                return this.GetObjectData(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this.Identifier = $.$default($.$spc.System.Guid);
                this.TransactionTraceId = $.$default($.$stl.System.Transactions.TransactionTraceIdentifier);
                this.IsolationLevel = 0;
            }
            static $h = 3507684;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":56229889,"g":{"r":0,"d":0,"h":38658213348,"f":8},"s":{"r":0,"d":0,"h":42953180644,"f":8},"n":"Identifier","d":3507684,"h":34363246052,"f":8},{"p":3573220,"g":{"r":0,"d":0,"h":55838082532,"f":8},"s":{"r":0,"d":0,"h":60133049828,"f":8},"n":"RealTransaction","d":3507684,"h":51543115236,"f":8},{"p":8553956,"g":{"r":0,"d":0,"h":73017951716,"f":8},"s":{"r":0,"d":0,"h":77312919012,"f":8},"n":"TransactionTraceId","d":3507684,"h":68722984420,"f":8},{"p":3180004,"g":{"r":0,"d":0,"h":90197820900,"f":8},"s":{"r":0,"d":0,"h":94492788196,"f":8},"n":"IsolationLevel","d":3507684,"h":85902853604,"f":8},{"p":4294116,"g":{"r":0,"d":0,"h":107377690084,"f":8},"s":{"r":0,"d":0,"h":111672657380,"f":8},"n":"SavedLtmPromotedTransaction","d":3507684,"h":103082722788,"f":8}],"m":[{"r":2917860,"p":[{"n":"internalEnlistment","p":2721252},{"n":"enlistmentOptions","p":1869284}],"n":"EnlistVolatile","d":3507684,"h":115967624676,"f":8},{"r":2917860,"p":[{"n":"resourceManagerIdentifier","p":56229889},{"n":"internalEnlistment","p":1607140},{"n":"v","p":262145},{"n":"enlistmentOptions","p":1869284}],"n":"EnlistDurable","d":3507684,"h":120262591972,"f":8},{"r":65537,"n":"Rollback","d":3507684,"h":124557559268,"f":8},{"r":3442148,"p":[{"n":"delayCommit","p":262145}],"n":"DependentClone","d":3507684,"h":128852526564,"f":8},{"r":2917860,"p":[{"n":"volatileDemux","p":8685028},{"n":"enlistmentOptions","p":1869284}],"n":"EnlistVolatile","o":"@$1","d":3507684,"h":133147493860,"f":8},{"r":0,"p":[{"n":"whereaboutsCopy","p":0}],"n":"GetExportCookie","d":3507684,"h":137442461156,"f":40},{"r":0,"n":"GetTransmitterPropagationToken","d":3507684,"h":141737428452,"f":40},{"r":2524644,"n":"GetDtcTransaction","d":3507684,"h":146032395748,"f":40},{"r":65537,"p":[{"n":"serializationInfo","p":113967105},{"n":"context","p":114098177}],"n":"GetObjectData","d":3507684,"h":150327363044,"f":1},{"r":65537,"n":"Dispose","d":3507684,"h":154622330340,"f":8},{"r":47251457,"n":"NotSupported","d":3507684,"h":158917297636,"f":40}],"c":[{"n":".ctor","o":"$ctor$1","d":3507684,"h":4298474980,"f":8},{"p":[{"n":"serializationInfo","p":113967105},{"n":"context","p":114098177}],"n":".ctor","o":"$ctor$2","d":3507684,"h":8593442276,"f":4}],"i":[113377281],"j":[3573220],"h":3507684}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Transactions.Oletx.OletxTransaction`; }
        });
        
        $asm.$cls("$stl.System.Transactions.InternalTransaction", ($self) => class InternalTransaction extends $.$spc.System.Object
        {
            /*TransactionState?*/ _transactionState = null;
            /*TransactionState? */ get State()
            {
                return this._transactionState;
            }
            /*TransactionState? */ set State(value)
            {
                this._transactionState = value;
            }
            /*TransactionState*/ _promoteState = null;
            /*Guid*/ _promoterType;
            /*byte[]?*/ promotedToken = null;
            /*Guid*/ _distributedTransactionIdentifierNonMSDTC;
            /*int*/ static MaxStateHist = 20;
            /*TransactionState[]*/ _stateHistory = null;
            /*int*/ _currentStateHist = 0;
            /*FinalizedObject?*/ _finalizedObject = null;
            /*int*/ _transactionHash = 0;
            /*int */ get TransactionHash()
            {
                return this._transactionHash;
            }
            /*int*/ static _nextHash = 0;
            /*long*/ _absoluteTimeout = 0n;
            /*long */ get AbsoluteTimeout()
            {
                return this._absoluteTimeout;
            }
            /*long*/ _creationTime = 0n;
            /*long */ get CreationTime()
            {
                return this._creationTime;
            }
            /*long */ set CreationTime(value)
            {
                this._creationTime = value;
            }
            /*InternalEnlistment?*/ _durableEnlistment = null;
            /*VolatileEnlistmentSet*/ _phase0Volatiles;
            /*VolatileEnlistmentSet*/ _phase1Volatiles;
            /*int*/ _phase0VolatileWaveCount = 0;
            /*OletxDependentTransaction?*/ _phase0WaveDependentClone = null;
            /*int*/ _phase0WaveDependentCloneCount = 0;
            /*OletxDependentTransaction?*/ _abortingDependentClone = null;
            /*int*/ _abortingDependentCloneCount = 0;
            /*int*/ static VolatileArrayIncrement = 8;
            /*Bucket?*/ _tableBucket = null;
            /*int*/ _bucketIndex = 0;
            /*TransactionCompletedEventHandler?*/ _transactionCompletedDelegate = null;
            /*OletxTransaction?*/ _promotedTransaction = null;
            /*OletxTransaction? */ get PromotedTransaction()
            {
                return this._promotedTransaction;
            }
            /*OletxTransaction? */ set PromotedTransaction(value)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._promotedTransaction === null, "A transaction can only be promoted once!");
                this._promotedTransaction = value;
            }
            /*Exception?*/ _innerException = null;
            /*int*/ _cloneCount = 0;
            /*int*/ _enlistmentCount = 0;
            /*ManualResetEvent?*/ _asyncResultEvent = null;
            /*bool*/ _asyncCommit = false;
            /*AsyncCallback?*/ _asyncCallback = null;
            /*object?*/ _asyncState = null;
            /*bool*/ _needPulse = false;
            /*TransactionInformation?*/ _transactionInformation = null;
            /*CommittableTransaction?*/ _committableTransaction = null;
            /*Transaction*/ _outcomeSource = null;
            /*object?*/ static s_classSyncObject = null;
            /*Guid */ get DistributedTxId()
            {
                return this.State.get_Identifier(this);
            }
            /*string?*/ static s_instanceIdentifier = null;
            static /*string */ get InstanceIdentifier()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$4($.$spc.System.String, $.$ref(() => $.$stl.System.Transactions.InternalTransaction.s_instanceIdentifier, ($v) => $.$stl.System.Transactions.InternalTransaction.s_instanceIdentifier = $v, $.$spc.System.String), $.$ref(() => $.$stl.System.Transactions.InternalTransaction.s_classSyncObject, ($v) => $.$stl.System.Transactions.InternalTransaction.s_classSyncObject = $v, $.$spc.System.Object), new ($.$spc.System.Func$$($.$spc.System.String))().$ctor(this,  () =>
                {
                    return `${$.$spc.System.Guid.ToString.call($.$spc.System.Guid.NewGuid())}:`;
                }, {"r":1310721,"n":"","d":2786788,"h":0,"f":1048578}));
            }
            /*bool*/ _traceIdentifierInited = false;
            /*TransactionTraceIdentifier*/ _traceIdentifier;
            /*TransactionTraceIdentifier */ get TransactionTraceId()
            {
                if (!this._traceIdentifierInited)
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter(this)
                        {
                            if (!this._traceIdentifierInited)
                            {
                                /*TransactionTraceIdentifier*/ let temp = new $.$stl.System.Transactions.TransactionTraceIdentifier().$ctor$2($.$spc.System.String.Create$9($.$spc.System.Globalization.CultureInfo.InvariantCulture, `${$.$stl.System.Transactions.InternalTransaction.InstanceIdentifier}${this._transactionHash}`), 0);
                                this._traceIdentifier = temp;
                                this._traceIdentifierInited = true;
                            }
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit(this)
                    }
                }
                return this._traceIdentifier;
            }
            /*ITransactionPromoter?*/ _promoter = null;
            /*bool*/ _attemptingPSPEPromote = false;
            /*void */ SetPromoterTypeToMSDTC()
            {
                if (($.$spc.System.Guid.op_Inequality(this._promoterType, $.$spc.System.Guid.Empty)) && ($.$spc.System.Guid.op_Inequality(this._promoterType, $.$stl.System.Transactions.TransactionInterop.PromoterTypeDtc)))
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$stl.System.SR.PromoterTypeInvalid);
                }
                this._promoterType = $.$stl.System.Transactions.TransactionInterop.PromoterTypeDtc;
            }
            /*void */ ThrowIfPromoterTypeIsNotMSDTC()
            {
                if (($.$spc.System.Guid.op_Inequality(this._promoterType, $.$spc.System.Guid.Empty)) && ($.$spc.System.Guid.op_Inequality(this._promoterType, $.$stl.System.Transactions.TransactionInterop.PromoterTypeDtc)))
                {
                    throw new $.$stl.System.Transactions.TransactionPromotionException().$ctor$15($.$stl.System.SR.Format($.$stl.System.SR.PromoterTypeUnrecognized, $.$spc.System.Guid.ToString.call(this._promoterType)), this._innerException);
                }
            }
            $ctor$1(/*TimeSpan*/ timeout, /*CommittableTransaction*/ committableTransaction)
            {
                super.$ctor();
                {
                    this._absoluteTimeout = $.$stl.System.Transactions.TransactionManager.TransactionTable.TimeoutTicks(timeout);
                    $.$stl.System.Transactions.TransactionState.TransactionStateActive.EnterState(this);
                    this._promoteState = $.$stl.System.Transactions.TransactionState.TransactionStatePromoted;
                    this._committableTransaction = committableTransaction;
                    this._outcomeSource = committableTransaction;
                    this._transactionHash = $.$stl.System.Transactions.TransactionManager.TransactionTable.Add(this);
                }
                return this;
            }
            $ctor$2(/*Transaction*/ outcomeSource, /*OletxTransaction*/ distributedTx)
            {
                super.$ctor();
                {
                    this._promotedTransaction = distributedTx;
                    this._absoluteTimeout = 9223372036854775807n;
                    this._outcomeSource = outcomeSource;
                    this._transactionHash = $.$stl.System.Transactions.TransactionManager.TransactionTable.Add(this);
                    $.$stl.System.Transactions.TransactionState.TransactionStateNonCommittablePromoted.EnterState(this);
                    this._promoteState = $.$stl.System.Transactions.TransactionState.TransactionStateNonCommittablePromoted;
                }
                return this;
            }
            $ctor$3(/*Transaction*/ outcomeSource, /*ITransactionPromoter*/ promoter)
            {
                super.$ctor();
                {
                    this._absoluteTimeout = 9223372036854775807n;
                    this._outcomeSource = outcomeSource;
                    this._transactionHash = $.$stl.System.Transactions.TransactionManager.TransactionTable.Add(this);
                    this._promoter = promoter;
                    $.$stl.System.Transactions.TransactionState.TransactionStateSubordinateActive.EnterState(this);
                    this._promoteState = $.$stl.System.Transactions.TransactionState.TransactionStateDelegatedSubordinate;
                }
                return this;
            }
            static /*void */ DistributedTransactionOutcome(/*InternalTransaction*/ tx, /*TransactionStatus*/ status)
            {
                /*FinalizedObject?*/ let fo = null;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(tx)
                    {
                        if (null === tx._innerException)
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(tx.PromotedTransaction !== null, "tx.PromotedTransaction != null");
                            tx._innerException = tx.PromotedTransaction.InnerException;
                        }
                        $.$spc.System.Diagnostics.Debug.Assert$1(tx.State !== null, "tx.State!= null");
                        switch(status)
                        {
                            case 1/*TransactionStatus.Committed*/:
                            {
                                tx.State.ChangeStatePromotedCommitted(tx);
                                break;
                            }
                            case 2/*TransactionStatus.Aborted*/:
                            {
                                tx.State.ChangeStatePromotedAborted(tx);
                                break;
                            }
                            case 3/*TransactionStatus.InDoubt*/:
                            {
                                tx.State.InDoubtFromDtc(tx);
                                break;
                            }
                            default:
                            {
                                $.$spc.System.Diagnostics.Debug.Fail("InternalTransaction.DistributedTransactionOutcome - Unexpected TransactionStatus");
                                $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException$1(1/*TraceSourceType.TraceSourceLtm*/, "", null, tx.DistributedTxId);
                                break;
                            }
                        }
                        fo = tx._finalizedObject;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(tx)
                }
                fo?.Dispose$1();
            }
            /*void */ SignalAsyncCompletion()
            {
                this._asyncResultEvent?.Set$1();
                if (this._asyncCallback !== null)
                {
                    $.$spc.System.Threading.Monitor.Exit(this);
                    try
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._committableTransaction !== null, "_committableTransaction != null");
                        this._asyncCallback.Invoke(this._committableTransaction);
                    }
                    finally
                    {
                        {
                            $.$spc.System.Threading.Monitor.Enter(this);
                        }
                    }
                }
            }
            /*void */ FireCompletion()
            {
                /*TransactionCompletedEventHandler?*/ let eventHandlers = this._transactionCompletedDelegate;
                if (eventHandlers !== null)
                {
                    /*TransactionEventArgs*/ let args = new $.$stl.System.Transactions.TransactionEventArgs().$ctor$2();
                    args._transaction = this._outcomeSource.InternalClone();
                    eventHandlers.Invoke(args._transaction, args);
                }
            }
            /*void */ Dispose()
            {
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this._promoterType = $.$spc.System.Guid.Empty;
                this._distributedTransactionIdentifierNonMSDTC = $.$spc.System.Guid.Empty;
                this._stateHistory = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$stl.System.Transactions.TransactionState), null, [20/*MaxStateHist*/], null);
                this._phase0Volatiles = $.$default($.$stl.System.Transactions.VolatileEnlistmentSet);
                this._phase1Volatiles = $.$default($.$stl.System.Transactions.VolatileEnlistmentSet);
                this._traceIdentifier = $.$default($.$stl.System.Transactions.TransactionTraceIdentifier);
            }
            static $h = 2786788;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":5735908,"g":{"r":0,"d":0,"h":12887688676,"f":8},"s":{"r":0,"d":0,"h":17182655972,"f":8},"n":"State","d":2786788,"h":8592721380,"f":8},{"p":655361,"g":{"r":0,"d":0,"h":64427296228,"f":8},"n":"TransactionHash","d":2786788,"h":60132328932,"f":8},{"p":917505,"g":{"r":0,"d":0,"h":81607165412,"f":8},"n":"AbsoluteTimeout","d":2786788,"h":77312198116,"f":8},{"p":917505,"g":{"r":0,"d":0,"h":94492067300,"f":8},"s":{"r":0,"d":0,"h":98787034596,"f":8},"n":"CreationTime","d":2786788,"h":90197100004,"f":8},{"p":3507684,"g":{"r":0,"d":0,"h":163211544036,"f":8},"s":{"r":0,"d":0,"h":167506511332,"f":8},"n":"PromotedTransaction","d":2786788,"h":158916576740,"f":8},{"p":56229889,"g":{"r":0,"d":0,"h":227636053476,"f":8},"n":"DistributedTxId","d":2786788,"h":223341086180,"f":8},{"p":1310721,"g":{"r":0,"d":0,"h":240520955364,"f":40},"n":"InstanceIdentifier","d":2786788,"h":236225988068,"f":40},{"p":8553956,"g":{"r":0,"d":0,"h":257700824548,"f":8},"n":"TransactionTraceId","d":2786788,"h":253405857252,"f":8}],"m":[{"r":65537,"n":"SetPromoterTypeToMSDTC","d":2786788,"h":270585726436,"f":8},{"r":65537,"n":"ThrowIfPromoterTypeIsNotMSDTC","d":2786788,"h":274880693732,"f":8},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"status","p":8422884}],"n":"DistributedTransactionOutcome","d":2786788,"h":292060562916,"f":40},{"r":65537,"n":"SignalAsyncCompletion","d":2786788,"h":296355530212,"f":8},{"r":65537,"n":"FireCompletion","d":2786788,"h":300650497508,"f":8},{"r":65537,"n":"Dispose","d":2786788,"h":304945464804,"f":1}],"l":[{"t":5735908,"n":"_transactionState","d":2786788,"h":4297754084,"f":2},{"t":5735908,"n":"_promoteState","d":2786788,"h":21477623268,"f":8},{"t":56229889,"n":"_promoterType","d":2786788,"h":25772590564,"f":8},{"t":0,"n":"promotedToken","d":2786788,"h":30067557860,"f":8},{"t":56229889,"n":"_distributedTransactionIdentifierNonMSDTC","d":2786788,"h":34362525156,"f":8},{"t":655361,"n":"MaxStateHist","d":2786788,"h":38657492452,"f":40},{"t":0,"n":"_stateHistory","d":2786788,"h":42952459748,"f":8},{"t":655361,"n":"_currentStateHist","d":2786788,"h":47247427044,"f":8},{"t":2328036,"n":"_finalizedObject","d":2786788,"h":51542394340,"f":8},{"t":655361,"n":"_transactionHash","d":2786788,"h":55837361636,"f":8},{"t":655361,"n":"_nextHash","d":2786788,"h":68722263524,"f":40},{"t":917505,"n":"_absoluteTimeout","d":2786788,"h":73017230820,"f":2},{"t":917505,"n":"_creationTime","d":2786788,"h":85902132708,"f":2},{"t":2721252,"n":"_durableEnlistment","d":2786788,"h":103082001892,"f":8},{"t":9340388,"n":"_phase0Volatiles","d":2786788,"h":107376969188,"f":8},{"t":9340388,"n":"_phase1Volatiles","d":2786788,"h":111671936484,"f":8},{"t":655361,"n":"_phase0VolatileWaveCount","d":2786788,"h":115966903780,"f":8},{"t":3442148,"n":"_phase0WaveDependentClone","d":2786788,"h":120261871076,"f":8},{"t":655361,"n":"_phase0WaveDependentCloneCount","d":2786788,"h":124556838372,"f":8},{"t":3442148,"n":"_abortingDependentClone","d":2786788,"h":128851805668,"f":8},{"t":655361,"n":"_abortingDependentCloneCount","d":2786788,"h":133146772964,"f":8},{"t":655361,"n":"VolatileArrayIncrement","d":2786788,"h":137441740260,"f":40},{"t":296420,"n":"_tableBucket","d":2786788,"h":141736707556,"f":8},{"t":655361,"n":"_bucketIndex","d":2786788,"h":146031674852,"f":8},{"t":4425188,"n":"_transactionCompletedDelegate","d":2786788,"h":150326642148,"f":8},{"t":3507684,"n":"_promotedTransaction","d":2786788,"h":154621609444,"f":2},{"t":655361,"n":"_cloneCount","d":2786788,"h":176096445924,"f":8},{"t":655361,"n":"_enlistmentCount","d":2786788,"h":180391413220,"f":8},{"t":128319489,"n":"_asyncResultEvent","d":2786788,"h":184686380516,"f":8},{"t":262145,"n":"_asyncCommit","d":2786788,"h":188981347812,"f":8},{"t":14483457,"n":"_asyncCallback","d":2786788,"h":193276315108,"f":8},{"t":131073,"n":"_asyncState","d":2786788,"h":197571282404,"f":8},{"t":262145,"n":"_needPulse","d":2786788,"h":201866249700,"f":8},{"t":4752868,"n":"_transactionInformation","d":2786788,"h":206161216996,"f":8},{"t":558564,"n":"_committableTransaction","d":2786788,"h":210456184292,"f":8},{"t":4294116,"n":"_outcomeSource","d":2786788,"h":214751151588,"f":8},{"t":131073,"n":"s_classSyncObject","d":2786788,"h":219046118884,"f":34},{"t":1310721,"n":"s_instanceIdentifier","d":2786788,"h":231931020772,"f":34},{"t":262145,"n":"_traceIdentifierInited","d":2786788,"h":244815922660,"f":2},{"t":8553956,"n":"_traceIdentifier","d":2786788,"h":249110889956,"f":2},{"t":3245540,"n":"_promoter","d":2786788,"h":261995791844,"f":8},{"t":262145,"n":"_attemptingPSPEPromote","d":2786788,"h":266290759140,"f":8}],"c":[{"p":[{"n":"timeout","p":140705793},{"n":"committableTransaction","p":558564}],"n":".ctor","o":"$ctor$1","d":2786788,"h":279175661028,"f":8},{"p":[{"n":"outcomeSource","p":4294116},{"n":"distributedTx","p":3507684}],"n":".ctor","o":"$ctor$2","d":2786788,"h":283470628324,"f":8},{"p":[{"n":"outcomeSource","p":4294116},{"n":"promoter","p":3245540}],"n":".ctor","o":"$ctor$3","d":2786788,"h":287765595620,"f":8}],"i":[57540609],"h":2786788}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Transactions.InternalTransaction`; }
        });
        
        $asm.$cls("$stl.System.Transactions.FinalizedObject", ($self) => class FinalizedObject extends $.$spc.System.Object
        {
            /*Guid*/ _identifier;
            /*InternalTransaction*/ _internalTransaction = null;
            $ctor$1(/*InternalTransaction*/ internalTransaction, /*Guid*/ identifier)
            {
                super.$ctor();
                {
                    this._internalTransaction = internalTransaction;
                    this._identifier = identifier;
                }
                return this;
            }
            /*void */ Dispose(/*bool*/ disposing)
            {
                if (disposing)
                {
                    $.$spc.System.GC.SuppressFinalize(this);
                }
                /*Hashtable*/ let promotedTransactionTable = $.$stl.System.Transactions.TransactionManager.PromotedTransactionTable;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(promotedTransactionTable)
                    {
                        /*WeakReference?*/ let weakRef = $.$cast(promotedTransactionTable.get_Item(this._identifier), $.$spc.System.WeakReference);
                        if (null !== weakRef)
                        {
                            if (weakRef.Target !== null)
                            {
                                weakRef.Target = null;
                            }
                        }
                        promotedTransactionTable.Remove(this._identifier);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(promotedTransactionTable)
                }
            }
            /*void */ Dispose$1()
            {
                this.Dispose(true);
            }
            $dtor()
            {
                this.Dispose(false);
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose$1(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this._identifier = $.$default($.$spc.System.Guid);
                $.$finalizer(this);
            }
            static $h = 2328036;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","d":2328036,"h":17182197220,"f":2},{"r":65537,"n":"Dispose","o":"@$1","d":2328036,"h":21477164516,"f":1}],"l":[{"t":56229889,"n":"_identifier","d":2328036,"h":4297295332,"f":2},{"t":2786788,"n":"_internalTransaction","d":2328036,"h":8592262628,"f":2}],"c":[{"p":[{"n":"internalTransaction","p":2786788},{"n":"identifier","p":56229889}],"n":".ctor","o":"$ctor$1","d":2328036,"h":12887229924,"f":8}],"i":[57540609],"h":2328036}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Transactions.FinalizedObject`; }
        });
        
        $asm.$cls("$stl.System.Transactions.InternalEnlistment", ($self) => class InternalEnlistment extends $.$spc.System.Object
        {
            /*EnlistmentState?*/ _twoPhaseState = null;
            /*IEnlistmentNotification?*/ _twoPhaseNotifications = null;
            /*ISinglePhaseNotification?*/ _singlePhaseNotifications = null;
            /*InternalTransaction*/ _transaction = null;
            /*Transaction?*/ _atomicTransaction = null;
            /*EnlistmentTraceIdentifier*/ _traceIdentifier;
            /*int*/ _enlistmentId = 0;
            /*Guid */ get DistributedTxId()
            {
                /*Guid*/ let returnValue = $.$spc.System.Guid.Empty;
                if (this.Transaction !== null)
                {
                    returnValue = this.Transaction.DistributedTxId;
                }
                return returnValue;
            }
            /*Enlistment*/ _enlistment = null;
            /*PreparingEnlistment?*/ _preparingEnlistment = null;
            /*SinglePhaseEnlistment?*/ _singlePhaseEnlistment = null;
            /*IPromotedEnlistment?*/ _promotedEnlistment = null;
            $ctor$1(/*Enlistment*/ enlistment, /*IEnlistmentNotification*/ twoPhaseNotifications)
            {
                super.$ctor();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1($.$is(this, $.$stl.System.Transactions.RecoveringInternalEnlistment), "this is RecoveringInternalEnlistment");
                    this._enlistment = enlistment;
                    this._twoPhaseNotifications = twoPhaseNotifications;
                    this._enlistmentId = 1;
                    this._traceIdentifier = $.$stl.System.Transactions.EnlistmentTraceIdentifier.Empty;
                }
                return this;
            }
            $ctor$2(/*Enlistment*/ enlistment, /*InternalTransaction*/ transaction, /*Transaction*/ atomicTransaction)
            {
                super.$ctor();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1($.$is(this, $.$stl.System.Transactions.PromotableInternalEnlistment), "this is PromotableInternalEnlistment");
                    this._enlistment = enlistment;
                    this._transaction = transaction;
                    this._atomicTransaction = atomicTransaction;
                    this._enlistmentId = transaction._enlistmentCount++;
                    this._traceIdentifier = $.$stl.System.Transactions.EnlistmentTraceIdentifier.Empty;
                }
                return this;
            }
            $ctor$3(/*Enlistment*/ enlistment, /*InternalTransaction*/ transaction, /*IEnlistmentNotification*/ twoPhaseNotifications, /*ISinglePhaseNotification?*/ singlePhaseNotifications, /*Transaction*/ atomicTransaction)
            {
                super.$ctor();
                {
                    this._enlistment = enlistment;
                    this._transaction = transaction;
                    this._twoPhaseNotifications = twoPhaseNotifications;
                    this._singlePhaseNotifications = singlePhaseNotifications;
                    this._atomicTransaction = atomicTransaction;
                    this._enlistmentId = transaction._enlistmentCount++;
                    this._traceIdentifier = $.$stl.System.Transactions.EnlistmentTraceIdentifier.Empty;
                }
                return this;
            }
            $ctor$4(/*Enlistment*/ enlistment, /*IEnlistmentNotification*/ twoPhaseNotifications, /*InternalTransaction*/ transaction, /*Transaction*/ atomicTransaction)
            {
                super.$ctor();
                {
                    this._enlistment = enlistment;
                    this._twoPhaseNotifications = twoPhaseNotifications;
                    this._transaction = transaction;
                    this._atomicTransaction = atomicTransaction;
                }
                return this;
            }
            /*EnlistmentState */ get State()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._twoPhaseState !== null, "_twoPhaseState != null");
                return this._twoPhaseState;
            }
            /*EnlistmentState */ set State(value)
            {
                this._twoPhaseState = value;
            }
            /*Enlistment */ get Enlistment()
            {
                return this._enlistment;
            }
            /*PreparingEnlistment */ get PreparingEnlistment()
            {
                return this._preparingEnlistment ??= new $.$stl.System.Transactions.PreparingEnlistment().$ctor$7(this);
            }
            /*SinglePhaseEnlistment */ get SinglePhaseEnlistment()
            {
                return this._singlePhaseEnlistment ??= new $.$stl.System.Transactions.SinglePhaseEnlistment().$ctor$7(this);
            }
            /*InternalTransaction */ get Transaction()
            {
                return this._transaction;
            }
            /*object */ get SyncRoot()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._transaction !== null, "this.transaction != null");
                return this._transaction;
            }
            /*IEnlistmentNotification? */ get EnlistmentNotification()
            {
                return this._twoPhaseNotifications;
            }
            /*ISinglePhaseNotification? */ get SinglePhaseNotification()
            {
                return this._singlePhaseNotifications;
            }
            /*IPromotableSinglePhaseNotification */ get PromotableSinglePhaseNotification()
            {
                $.$spc.System.Diagnostics.Debug.Fail("PromotableSinglePhaseNotification called for a non promotable enlistment.");
                throw new $.$spc.System.NotImplementedException().$ctor$9();
            }
            /*IPromotedEnlistment? */ get PromotedEnlistment()
            {
                return this._promotedEnlistment;
            }
            /*IPromotedEnlistment? */ set PromotedEnlistment(value)
            {
                this._promotedEnlistment = value;
            }
            /*EnlistmentTraceIdentifier */ get EnlistmentTraceId()
            {
                if ($.$stl.System.Transactions.EnlistmentTraceIdentifier.op_Equality(this._traceIdentifier, $.$stl.System.Transactions.EnlistmentTraceIdentifier.Empty))
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter(this.SyncRoot)
                        {
                            if ($.$stl.System.Transactions.EnlistmentTraceIdentifier.op_Equality(this._traceIdentifier, $.$stl.System.Transactions.EnlistmentTraceIdentifier.Empty))
                            {
                                /*EnlistmentTraceIdentifier*/ let temp;
                                if ($.$stl.System.Transactions.Transaction.op_Inequality(null, this._atomicTransaction))
                                {
                                    temp = new $.$stl.System.Transactions.EnlistmentTraceIdentifier().$ctor$2($.$spc.System.Guid.Empty, this._atomicTransaction.TransactionTraceId, this._enlistmentId);
                                }
                                else 
                                {
                                    temp = new $.$stl.System.Transactions.EnlistmentTraceIdentifier().$ctor$2($.$spc.System.Guid.Empty, new $.$stl.System.Transactions.TransactionTraceIdentifier().$ctor$2($.$spc.System.String.Create$9($.$spc.System.Globalization.CultureInfo.InvariantCulture, `${$.$stl.System.Transactions.InternalTransaction.InstanceIdentifier}${$.$spc.System.Threading.Interlocked.Increment($.$ref(() => $.$stl.System.Transactions.InternalTransaction._nextHash, ($v) => $.$stl.System.Transactions.InternalTransaction._nextHash = $v, $.$spc.System.Int32))}`), 0), this._enlistmentId);
                                }
                                $.$spc.System.Threading.Interlocked.MemoryBarrier();
                                this._traceIdentifier = temp;
                            }
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit(this.SyncRoot)
                    }
                }
                return this._traceIdentifier;
            }
            /*void */ FinishEnlistment()
            {
                this.Transaction._phase0Volatiles._preparedVolatileEnlistments++;
                this.CheckComplete();
            }
            /*void */ CheckComplete()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this.Transaction._phase0Volatiles._preparedVolatileEnlistments <= ((this.Transaction._phase0Volatiles._volatileEnlistmentCount + this.Transaction._phase0Volatiles._dependentClones) | 0), "Transaction._phase0Volatiles._preparedVolatileEnlistments <=\r\n                Transaction._phase0Volatiles._volatileEnlistmentCount + Transaction._phase0Volatiles._dependentClones");
                if (this.Transaction._phase0Volatiles._preparedVolatileEnlistments === ((this.Transaction._phase0VolatileWaveCount + this.Transaction._phase0Volatiles._dependentClones) | 0))
                {
                    this.Transaction.State.Phase0VolatilePrepareDone(this.Transaction);
                }
            }
            /*Guid */ get ResourceManagerIdentifier()
            {
                $.$spc.System.Diagnostics.Debug.Fail("ResourceManagerIdentifier called for non durable enlistment");
                throw new $.$spc.System.NotImplementedException().$ctor$9();
            }
            /*void */ System$Transactions$ISinglePhaseNotificationInternal$SinglePhaseCommit(/*IPromotedEnlistment*/ singlePhaseEnlistment)
            {
                /*bool*/ let spcCommitted = false;
                this._promotedEnlistment = singlePhaseEnlistment;
                try
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._singlePhaseNotifications !== null, "_singlePhaseNotifications != null");
                    this._singlePhaseNotifications.System$Transactions$ISinglePhaseNotification$SinglePhaseCommit(this.SinglePhaseEnlistment);
                    spcCommitted = true;
                }
                finally
                {
                    {
                        if (!spcCommitted)
                        {
                            this.SinglePhaseEnlistment.InDoubt();
                        }
                    }
                }
            }
            /*void */ System$Transactions$IEnlistmentNotificationInternal$Prepare(/*IPromotedEnlistment*/ preparingEnlistment)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._twoPhaseNotifications !== null, "_twoPhaseNotifications != null");
                this._promotedEnlistment = preparingEnlistment;
                this._twoPhaseNotifications.System$Transactions$IEnlistmentNotification$Prepare(this.PreparingEnlistment);
            }
            /*void */ System$Transactions$IEnlistmentNotificationInternal$Commit(/*IPromotedEnlistment*/ enlistment)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._twoPhaseNotifications !== null, "_twoPhaseNotifications != null");
                this._promotedEnlistment = enlistment;
                this._twoPhaseNotifications.System$Transactions$IEnlistmentNotification$Commit(this.Enlistment);
            }
            /*void */ System$Transactions$IEnlistmentNotificationInternal$Rollback(/*IPromotedEnlistment*/ enlistment)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._twoPhaseNotifications !== null, "_twoPhaseNotifications != null");
                this._promotedEnlistment = enlistment;
                this._twoPhaseNotifications.System$Transactions$IEnlistmentNotification$Rollback(this.Enlistment);
            }
            /*void */ System$Transactions$IEnlistmentNotificationInternal$InDoubt(/*IPromotedEnlistment*/ enlistment)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._twoPhaseNotifications !== null, "_twoPhaseNotifications != null");
                this._promotedEnlistment = enlistment;
                this._twoPhaseNotifications.System$Transactions$IEnlistmentNotification$InDoubt(this.Enlistment);
            }
            //default member initializer
            constructor()
            {
                super();
                this._transaction = null;
                this._traceIdentifier = $.$default($.$stl.System.Transactions.EnlistmentTraceIdentifier);
            }
            static $h = 2721252;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":56229889,"g":{"r":0,"d":0,"h":38657426916,"f":8},"n":"DistributedTxId","d":2721252,"h":34362459620,"f":8},{"p":1934820,"g":{"r":0,"d":0,"h":81607099876,"f":8},"s":{"r":0,"d":0,"h":85902067172,"f":8},"n":"State","d":2721252,"h":77312132580,"f":8},{"p":1738212,"g":{"r":0,"d":0,"h":94492001764,"f":8},"n":"Enlistment","d":2721252,"h":90197034468,"f":8},{"p":3900900,"g":{"r":0,"d":0,"h":103081936356,"f":8},"n":"PreparingEnlistment","d":2721252,"h":98786969060,"f":8},{"p":4097508,"g":{"r":0,"d":0,"h":111671870948,"f":8},"n":"SinglePhaseEnlistment","d":2721252,"h":107376903652,"f":8},{"p":2786788,"g":{"r":0,"d":0,"h":120261805540,"f":8},"n":"Transaction","d":2721252,"h":115966838244,"f":8},{"p":131073,"g":{"r":0,"d":0,"h":128851740132,"f":136},"n":"SyncRoot","d":2721252,"h":124556772836,"f":136},{"p":2590180,"g":{"r":0,"d":0,"h":137441674724,"f":8},"n":"EnlistmentNotification","d":2721252,"h":133146707428,"f":8},{"p":3048932,"g":{"r":0,"d":0,"h":146031609316,"f":8},"n":"SinglePhaseNotification","d":2721252,"h":141736642020,"f":8},{"p":2852324,"g":{"r":0,"d":0,"h":154621543908,"f":136},"n":"PromotableSinglePhaseNotification","d":2721252,"h":150326576612,"f":136},{"p":2917860,"g":{"r":0,"d":0,"h":163211478500,"f":8},"s":{"r":0,"d":0,"h":167506445796,"f":8},"n":"PromotedEnlistment","d":2721252,"h":158916511204,"f":8},{"p":2065892,"g":{"r":0,"d":0,"h":176096380388,"f":8},"n":"EnlistmentTraceId","d":2721252,"h":171801413092,"f":8},{"p":56229889,"g":{"r":0,"d":0,"h":193276249572,"f":136},"n":"ResourceManagerIdentifier","d":2721252,"h":188981282276,"f":136}],"m":[{"r":65537,"n":"FinishEnlistment","d":2721252,"h":180391347684,"f":136},{"r":65537,"n":"CheckComplete","d":2721252,"h":184686314980,"f":136}],"l":[{"t":1934820,"n":"_twoPhaseState","d":2721252,"h":4297688548,"f":8},{"t":2590180,"n":"_twoPhaseNotifications","d":2721252,"h":8592655844,"f":4},{"t":3048932,"n":"_singlePhaseNotifications","d":2721252,"h":12887623140,"f":4},{"t":2786788,"n":"_transaction","d":2721252,"h":17182590436,"f":4},{"t":4294116,"n":"_atomicTransaction","d":2721252,"h":21477557732,"f":2},{"t":2065892,"n":"_traceIdentifier","d":2721252,"h":25772525028,"f":2},{"t":655361,"n":"_enlistmentId","d":2721252,"h":30067492324,"f":2},{"t":1738212,"n":"_enlistment","d":2721252,"h":42952394212,"f":2},{"t":3900900,"n":"_preparingEnlistment","d":2721252,"h":47247361508,"f":2},{"t":4097508,"n":"_singlePhaseEnlistment","d":2721252,"h":51542328804,"f":2},{"t":2917860,"n":"_promotedEnlistment","d":2721252,"h":55837296100,"f":2}],"c":[{"p":[{"n":"enlistment","p":1738212},{"n":"twoPhaseNotifications","p":2590180}],"n":".ctor","o":"$ctor$1","d":2721252,"h":60132263396,"f":4},{"p":[{"n":"enlistment","p":1738212},{"n":"transaction","p":2786788},{"n":"atomicTransaction","p":4294116}],"n":".ctor","o":"$ctor$2","d":2721252,"h":64427230692,"f":4},{"p":[{"n":"enlistment","p":1738212},{"n":"transaction","p":2786788},{"n":"twoPhaseNotifications","p":2590180},{"n":"singlePhaseNotifications","p":3048932},{"n":"atomicTransaction","p":4294116}],"n":".ctor","o":"$ctor$3","d":2721252,"h":68722197988,"f":8},{"p":[{"n":"enlistment","p":1738212},{"n":"twoPhaseNotifications","p":2590180},{"n":"transaction","p":2786788},{"n":"atomicTransaction","p":4294116}],"n":".ctor","o":"$ctor$4","d":2721252,"h":73017165284,"f":8}],"i":[3114468,2655716],"h":2721252}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stl.System.Transactions.ISinglePhaseNotificationInternal, $.$stl.System.Transactions.IEnlistmentNotificationInternal ]; }
            static get $fullName() { return `System.Transactions.InternalEnlistment`; }
        });
        
        $asm.$cls("$stl.System.Transactions.Transaction", ($self) => class Transaction extends $.$spc.System.Object
        {
            static /*bool */ UseServiceDomainForCurrent()
            {
                return false;
            }
            static /*EnterpriseServicesInteropOption */ InteropMode(/*TransactionScope?*/ currentScope)
            {
                if (currentScope !== null)
                {
                    return currentScope.InteropMode;
                }
                return 0/*EnterpriseServicesInteropOption.None*/;
            }
            static /*Transaction? */ FastGetTransaction(/*TransactionScope?*/ currentScope, /*ContextData*/ contextData, /*out Transaction?*/ contextTransaction)
            {
                /*Transaction?*/ let current = null;
                contextTransaction.$v = contextData.CurrentTransaction;
                let $switch1 = $.$stl.System.Transactions.Transaction.InteropMode(currentScope);
                switch($switch1)
                {
                    case 0/*EnterpriseServicesInteropOption.None*/:
                    current = contextTransaction.$v;
                    if ($.$stl.System.Transactions.Transaction.op_Equality(current, null) && currentScope === null)
                    {
                        if ($.$stl.System.Transactions.TransactionManager.s_currentDelegateSet)
                        {
                            current = $.$stl.System.Transactions.TransactionManager.$.$stl.System.Transactions.TransactionManager.s_currentDelegate.Invoke();
                        }
                        else 
                        {
                            current = $.$stl.System.Transactions.EnterpriseServices.GetContextTransaction();
                        }
                    }
                    break;
                    case 2/*EnterpriseServicesInteropOption.Full*/:
                    current = $.$stl.System.Transactions.EnterpriseServices.GetContextTransaction();
                    break;
                    case 1/*EnterpriseServicesInteropOption.Automatic*/:
                    if ($.$stl.System.Transactions.EnterpriseServices.UseServiceDomainForCurrent())
                    {
                        current = $.$stl.System.Transactions.EnterpriseServices.GetContextTransaction();
                    }
                    else 
                    {
                        current = contextData.CurrentTransaction;
                    }
                    break;
                }
                return current;
            }
            static /*void */ GetCurrentTransactionAndScope(/*TxLookup*/ defaultLookup, /*out Transaction?*/ current, /*out TransactionScope?*/ currentScope, /*out Transaction?*/ contextTransaction)
            {
                current.$v = null;
                currentScope.$v = null;
                contextTransaction.$v = null;
                /*ContextData*/ let contextData = $.$stl.System.Transactions.ContextData.LookupContextData(defaultLookup);
                if (contextData !== null)
                {
                    currentScope.$v = contextData.CurrentScope;
                    current.$v = $.$stl.System.Transactions.Transaction.FastGetTransaction(currentScope.$v, contextData, contextTransaction);
                }
            }
            static /*Transaction? */ get Current()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(0/*TraceSourceType.TraceSourceBase*/, "Transaction.get_Current");
                }
                /*Transaction?*/ let current;
                /*TransactionScope?*/ let currentScope;
                $.$stl.System.Transactions.Transaction.GetCurrentTransactionAndScope(0/*TxLookup.Default*/, $.$ref(() => current, ($v) => current = $v, $.$stl.System.Transactions.Transaction), $.$ref(() => currentScope, ($v) => currentScope = $v, $.$stl.System.Transactions.TransactionScope), $.$discardRef());
                if (currentScope !== null)
                {
                    if (currentScope.ScopeComplete)
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$stl.System.SR.TransactionScopeComplete);
                    }
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(0/*TraceSourceType.TraceSourceBase*/, "Transaction.get_Current");
                }
                return current;
            }
            static /*Transaction? */ set Current(value)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter$1(0/*TraceSourceType.TraceSourceBase*/, "Transaction.set_Current");
                }
                if ($.$stl.System.Transactions.Transaction.InteropMode($.$stl.System.Transactions.ContextData.TLSCurrentData.CurrentScope) !== 0/*EnterpriseServicesInteropOption.None*/)
                {
                    if (etwLog.IsEnabled())
                    {
                        etwLog.InvalidOperation("Transaction", "Transaction.set_Current");
                    }
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$stl.System.SR.CannotSetCurrent);
                }
                $.$stl.System.Transactions.ContextData.TLSCurrentData.CurrentTransaction = value;
                $.$stl.System.Transactions.CallContextCurrentData.ClearCurrentData(null, false);
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit$1(0/*TraceSourceType.TraceSourceBase*/, "Transaction.set_Current");
                }
            }
            /*IsolationLevel*/ _isoLevel = 0;
            /*bool*/ _complete = false;
            /*int*/ _cloneId = 0;
            /*int*/ static _disposedTrueValue = 1;
            /*int*/ _disposed = 0;
            /*bool */ get Disposed()
            {
                return this._disposed === 1/*Transaction._disposedTrueValue*/;
            }
            /*Guid */ get DistributedTxId()
            {
                /*Guid*/ let returnValue = $.$spc.System.Guid.Empty;
                if (this._internalTransaction !== null)
                {
                    returnValue = this._internalTransaction.DistributedTxId;
                }
                return returnValue;
            }
            /*InternalTransaction*/ _internalTransaction = null;
            /*TransactionTraceIdentifier*/ _traceIdentifier;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*IsolationLevel*/ isoLevel, /*InternalTransaction?*/ internalTransaction)
            {
                super.$ctor();
                {
                    $.$stl.System.Transactions.TransactionManager.ValidateIsolationLevel(isoLevel);
                    this._isoLevel = isoLevel;
                    if (6/*IsolationLevel.Unspecified*/ === this._isoLevel)
                    {
                        this._isoLevel = $.$stl.System.Transactions.TransactionManager.DefaultIsolationLevel;
                    }
                    if (internalTransaction !== null)
                    {
                        this._internalTransaction = internalTransaction;
                        this._cloneId = $.$spc.System.Threading.Interlocked.Increment($.$ref(() => this._internalTransaction._cloneCount, ($v) => this._internalTransaction._cloneCount = $v, $.$spc.System.Int32));
                    }
                    else 
                    {
                    }
                }
                return this;
            }
            $ctor$3(/*OletxTransaction*/ distributedTransaction)
            {
                super.$ctor();
                {
                    this._isoLevel = distributedTransaction.IsolationLevel;
                    this._internalTransaction = new $.$stl.System.Transactions.InternalTransaction().$ctor$2(this, distributedTransaction);
                    this._cloneId = $.$spc.System.Threading.Interlocked.Increment($.$ref(() => this._internalTransaction._cloneCount, ($v) => this._internalTransaction._cloneCount = $v, $.$spc.System.Int32));
                }
                return this;
            }
            $ctor$4(/*IsolationLevel*/ isoLevel, /*ISimpleTransactionSuperior*/ superior)
            {
                super.$ctor();
                {
                    $.$stl.System.Transactions.TransactionManager.ValidateIsolationLevel(isoLevel);
                    $.$spc.System.ArgumentNullException.ThrowIfNull(superior, "superior");
                    this._isoLevel = isoLevel;
                    if (6/*IsolationLevel.Unspecified*/ === this._isoLevel)
                    {
                        this._isoLevel = $.$stl.System.Transactions.TransactionManager.DefaultIsolationLevel;
                    }
                    this._internalTransaction = new $.$stl.System.Transactions.InternalTransaction().$ctor$3(this, superior);
                    this._internalTransaction.SetPromoterTypeToMSDTC();
                    this._cloneId = 1;
                }
                return this;
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return this._internalTransaction.TransactionHash;
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$stl.System.Transactions.Transaction.GetHashCode.apply(this, arguments); }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                let transaction;
                return $.$is(obj, $.$stl.System.Transactions.Transaction, { set $v(v){ transaction = v; } }) && this._internalTransaction.TransactionHash === transaction._internalTransaction.TransactionHash;
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$stl.System.Transactions.Transaction.Equals.apply(this, arguments); }
            static /*bool */ op_Equality(/*Transaction?*/ x, /*Transaction?*/ y)
            {
                if ((x) !== null)
                {
                    return $.$stl.System.Transactions.Transaction.Equals.call(x, y);
                }
                return (y) === null;
            }
            static /*bool */ op_Inequality(/*Transaction?*/ x, /*Transaction?*/ y)
            {
                if ((x) !== null)
                {
                    return !$.$stl.System.Transactions.Transaction.Equals.call(x, y);
                }
                return (y) !== null;
            }
            /*TransactionInformation */ get TransactionInformation()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "TransactionInformation");
                }
                $.$spc.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                /*TransactionInformation?*/ let txInfo = this._internalTransaction._transactionInformation;
                if (txInfo === null)
                {
                    txInfo = new $.$stl.System.Transactions.TransactionInformation().$ctor$1(this._internalTransaction);
                    this._internalTransaction._transactionInformation = txInfo;
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "TransactionInformation");
                }
                return txInfo;
            }
            /*IsolationLevel */ get IsolationLevel()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "IsolationLevel");
                }
                $.$spc.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "IsolationLevel");
                }
                return this._isoLevel;
            }
            /*Guid */ get PromoterType()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "PromoterType");
                }
                $.$spc.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                    {
                        return this._internalTransaction._promoterType;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                }
            }
            /*byte[] */ GetPromotedToken()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "GetPromotedToken");
                }
                $.$spc.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                /*byte[]*/ let internalPromotedToken;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        internalPromotedToken = this._internalTransaction.State.PromotedToken(this._internalTransaction);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                }
                /*byte[]*/ let toReturn = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [internalPromotedToken.length], null);
                $.$spc.System.Array.Copy(internalPromotedToken, toReturn, toReturn.length);
                return toReturn;
            }
            /*Enlistment */ EnlistDurable(/*Guid*/ resourceManagerIdentifier, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "EnlistDurable");
                }
                $.$spc.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                if ($.$spc.System.Guid.op_Equality(resourceManagerIdentifier, $.$spc.System.Guid.Empty))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$stl.System.SR.BadResourceManagerId, "resourceManagerIdentifier");
                }
                $.$spc.System.ArgumentNullException.ThrowIfNull(enlistmentNotification, "enlistmentNotification");
                if (enlistmentOptions !== 0/*EnlistmentOptions.None*/ && enlistmentOptions !== 1/*EnlistmentOptions.EnlistDuringPrepareRequired*/)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("enlistmentOptions");
                }
                if (this._complete)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateTransactionCompletedException(this.DistributedTxId);
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        /*Enlistment*/ let enlistment = this._internalTransaction.State.EnlistDurable(this._internalTransaction, resourceManagerIdentifier, enlistmentNotification, enlistmentOptions, this);
                        if (etwLog.IsEnabled())
                        {
                            etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "EnlistDurable");
                        }
                        return enlistment;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                }
            }
            /*Enlistment */ EnlistDurable$1(/*Guid*/ resourceManagerIdentifier, /*ISinglePhaseNotification*/ singlePhaseNotification, /*EnlistmentOptions*/ enlistmentOptions)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "EnlistDurable");
                }
                $.$spc.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                if ($.$spc.System.Guid.op_Equality(resourceManagerIdentifier, $.$spc.System.Guid.Empty))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$stl.System.SR.BadResourceManagerId, "resourceManagerIdentifier");
                }
                $.$spc.System.ArgumentNullException.ThrowIfNull(singlePhaseNotification, "singlePhaseNotification");
                if (enlistmentOptions !== 0/*EnlistmentOptions.None*/ && enlistmentOptions !== 1/*EnlistmentOptions.EnlistDuringPrepareRequired*/)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("enlistmentOptions");
                }
                if (this._complete)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateTransactionCompletedException(this.DistributedTxId);
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        /*Enlistment*/ let enlistment = this._internalTransaction.State.EnlistDurable$1(this._internalTransaction, resourceManagerIdentifier, singlePhaseNotification, enlistmentOptions, this);
                        if (etwLog.IsEnabled())
                        {
                            etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "EnlistDurable");
                        }
                        return enlistment;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                }
            }
            /*void */ Rollback()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "Rollback");
                    etwLog.TransactionRollback(1/*TraceSourceType.TraceSourceLtm*/, this.TransactionTraceId, "Transaction");
                }
                $.$spc.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        this._internalTransaction.State.Rollback(this._internalTransaction, null);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "Rollback");
                }
            }
            /*void */ Rollback$1(/*Exception?*/ e)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "Rollback");
                    etwLog.TransactionRollback(1/*TraceSourceType.TraceSourceLtm*/, this.TransactionTraceId, "Transaction");
                }
                $.$spc.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        this._internalTransaction.State.Rollback(this._internalTransaction, e);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "Rollback");
                }
            }
            /*Enlistment */ EnlistVolatile(/*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "EnlistVolatile");
                }
                $.$spc.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                $.$spc.System.ArgumentNullException.ThrowIfNull(enlistmentNotification, "enlistmentNotification");
                if (enlistmentOptions !== 0/*EnlistmentOptions.None*/ && enlistmentOptions !== 1/*EnlistmentOptions.EnlistDuringPrepareRequired*/)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("enlistmentOptions");
                }
                if (this._complete)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateTransactionCompletedException(this.DistributedTxId);
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        /*Enlistment*/ let enlistment = this._internalTransaction.State.EnlistVolatile(this._internalTransaction, enlistmentNotification, enlistmentOptions, this);
                        if (etwLog.IsEnabled())
                        {
                            etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "EnlistVolatile");
                        }
                        return enlistment;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                }
            }
            /*Enlistment */ EnlistVolatile$1(/*ISinglePhaseNotification*/ singlePhaseNotification, /*EnlistmentOptions*/ enlistmentOptions)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "EnlistVolatile");
                }
                $.$spc.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                $.$spc.System.ArgumentNullException.ThrowIfNull(singlePhaseNotification, "singlePhaseNotification");
                if (enlistmentOptions !== 0/*EnlistmentOptions.None*/ && enlistmentOptions !== 1/*EnlistmentOptions.EnlistDuringPrepareRequired*/)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("enlistmentOptions");
                }
                if (this._complete)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateTransactionCompletedException(this.DistributedTxId);
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        /*Enlistment*/ let enlistment = this._internalTransaction.State.EnlistVolatile$1(this._internalTransaction, singlePhaseNotification, enlistmentOptions, this);
                        if (etwLog.IsEnabled())
                        {
                            etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "EnlistVolatile");
                        }
                        return enlistment;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                }
            }
            /*Transaction */ Clone()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "Clone");
                }
                $.$spc.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                if (this._complete)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateTransactionCompletedException(this.DistributedTxId);
                }
                /*Transaction*/ let clone = this.InternalClone();
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "Clone");
                }
                return clone;
            }
            /*Transaction */ InternalClone()
            {
                /*Transaction*/ let clone = new $.$stl.System.Transactions.Transaction().$ctor$2(this._isoLevel, this._internalTransaction);
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionCloneCreate(clone, "Transaction");
                }
                return clone;
            }
            /*DependentTransaction */ DependentClone(/*DependentCloneOption*/ cloneOption)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "DependentClone");
                }
                if (cloneOption !== 0/*DependentCloneOption.BlockCommitUntilComplete*/ && cloneOption !== 1/*DependentCloneOption.RollbackIfNotComplete*/)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("cloneOption");
                }
                $.$spc.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                if (this._complete)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateTransactionCompletedException(this.DistributedTxId);
                }
                /*DependentTransaction*/ let clone = new $.$stl.System.Transactions.DependentTransaction().$ctor$5(this._isoLevel, this._internalTransaction, cloneOption === 0/*DependentCloneOption.BlockCommitUntilComplete*/);
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionCloneCreate(clone, "DependentTransaction");
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "DependentClone");
                }
                return clone;
            }
            /*TransactionTraceIdentifier */ get TransactionTraceId()
            {
                if ($.$stl.System.Transactions.TransactionTraceIdentifier.op_Equality(this._traceIdentifier, $.$stl.System.Transactions.TransactionTraceIdentifier.Empty))
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                        {
                            if ($.$stl.System.Transactions.TransactionTraceIdentifier.op_Equality(this._traceIdentifier, $.$stl.System.Transactions.TransactionTraceIdentifier.Empty))
                            {
                                /*TransactionTraceIdentifier*/ let temp = new $.$stl.System.Transactions.TransactionTraceIdentifier().$ctor$2(this._internalTransaction.TransactionTraceId.TransactionIdentifier, this._cloneId);
                                $.$spc.System.Threading.Interlocked.MemoryBarrier();
                                this._traceIdentifier = temp;
                            }
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                    }
                }
                return this._traceIdentifier;
            }
            /*TransactionCompletedEventHandler?*/ add_TransactionCompleted(value)
            {
                $.$spc.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        this._internalTransaction.State.AddOutcomeRegistrant(this._internalTransaction, value);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                }
            }
            /*TransactionCompletedEventHandler?*/ remove_TransactionCompleted(value)
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                    {
                        this._internalTransaction._transactionCompletedDelegate = $.$cast($.$spc.System.Delegate.Remove(this._internalTransaction._transactionCompletedDelegate, value), $.$stl.System.Transactions.TransactionCompletedEventHandler);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                }
            }
            /*void */ Dispose()
            {
                this.InternalDispose();
            }
            /*void */ InternalDispose()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "InternalDispose");
                }
                if ($.$spc.System.Threading.Interlocked.Exchange($.$ref(() => this._disposed, ($v) => this._disposed = $v, $.$spc.System.Int32), 1/*Transaction._disposedTrueValue*/) === 1/*Transaction._disposedTrueValue*/)
                {
                    return;
                }
                /*long*/ let remainingITx = BigInt($.$spc.System.Threading.Interlocked.Decrement($.$ref(() => this._internalTransaction._cloneCount, ($v) => this._internalTransaction._cloneCount = $v, $.$spc.System.Int32)));
                if (remainingITx === 0n)
                {
                    this._internalTransaction.Dispose();
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "InternalDispose");
                }
            }
            /*void */ System$Runtime$Serialization$ISerializable$GetObjectData(/*SerializationInfo*/ serializationInfo, /*StreamingContext*/ context)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ EnlistPromotableSinglePhase(/*IPromotableSinglePhaseNotification*/ promotableSinglePhaseNotification)
            {
                return this.EnlistPromotableSinglePhase$1(promotableSinglePhaseNotification, $.$stl.System.Transactions.TransactionInterop.PromoterTypeDtc);
            }
            /*bool */ EnlistPromotableSinglePhase$1(/*IPromotableSinglePhaseNotification*/ promotableSinglePhaseNotification, /*Guid*/ promoterType)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "EnlistPromotableSinglePhase");
                }
                $.$spc.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                $.$spc.System.ArgumentNullException.ThrowIfNull(promotableSinglePhaseNotification, "promotableSinglePhaseNotification");
                if ($.$spc.System.Guid.op_Equality(promoterType, $.$spc.System.Guid.Empty))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$stl.System.SR.PromoterTypeInvalid, "promoterType");
                }
                if (this._complete)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateTransactionCompletedException(this.DistributedTxId);
                }
                /*bool*/ let succeeded = false;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        succeeded = this._internalTransaction.State.EnlistPromotableSinglePhase(this._internalTransaction, promotableSinglePhaseNotification, this, promoterType);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "EnlistPromotableSinglePhase");
                }
                return succeeded;
            }
            /*Enlistment */ PromoteAndEnlistDurable(/*Guid*/ resourceManagerIdentifier, /*IPromotableSinglePhaseNotification*/ promotableNotification, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(2/*TraceSourceType.TraceSourceOleTx*/, this, "PromoteAndEnlistDurable");
                }
                $.$spc.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                if ($.$spc.System.Guid.op_Equality(resourceManagerIdentifier, $.$spc.System.Guid.Empty))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$stl.System.SR.BadResourceManagerId, "resourceManagerIdentifier");
                }
                $.$spc.System.ArgumentNullException.ThrowIfNull(promotableNotification, "promotableNotification");
                $.$spc.System.ArgumentNullException.ThrowIfNull(enlistmentNotification, "enlistmentNotification");
                if (enlistmentOptions !== 0/*EnlistmentOptions.None*/ && enlistmentOptions !== 1/*EnlistmentOptions.EnlistDuringPrepareRequired*/)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("enlistmentOptions");
                }
                if (this._complete)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateTransactionCompletedException(this.DistributedTxId);
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        /*Enlistment*/ let enlistment = this._internalTransaction.State.PromoteAndEnlistDurable(this._internalTransaction, resourceManagerIdentifier, promotableNotification, enlistmentNotification, enlistmentOptions, this);
                        if (etwLog.IsEnabled())
                        {
                            etwLog.MethodExit(2/*TraceSourceType.TraceSourceOleTx*/, this, "PromoteAndEnlistDurable");
                        }
                        return enlistment;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                }
            }
            /*void */ SetDistributedTransactionIdentifier(/*IPromotableSinglePhaseNotification*/ promotableNotification, /*Guid*/ distributedTransactionIdentifier)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "SetDistributedTransactionIdentifier");
                }
                $.$spc.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                $.$spc.System.ArgumentNullException.ThrowIfNull(promotableNotification, "promotableNotification");
                if ($.$spc.System.Guid.op_Equality(distributedTransactionIdentifier, $.$spc.System.Guid.Empty))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13(null, "distributedTransactionIdentifier");
                }
                if (this._complete)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateTransactionCompletedException(this.DistributedTxId);
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        this._internalTransaction.State.SetDistributedTransactionId(this._internalTransaction, promotableNotification, distributedTransactionIdentifier);
                        if (etwLog.IsEnabled())
                        {
                            etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "SetDistributedTransactionIdentifier");
                        }
                        return;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                }
            }
            /*OletxTransaction? */ Promote()
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        this._internalTransaction.ThrowIfPromoterTypeIsNotMSDTC();
                        this._internalTransaction.State.Promote(this._internalTransaction);
                        return this._internalTransaction.PromotedTransaction;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                }
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this._internalTransaction = null;
                this._traceIdentifier = $.$default($.$stl.System.Transactions.TransactionTraceIdentifier);
            }
            static $h = 4294116;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":4294116,"g":{"r":0,"d":0,"h":25774097892,"f":33},"s":{"r":0,"d":0,"h":30069065188,"f":33},"n":"Current","d":4294116,"h":21479130596,"f":33},{"p":262145,"g":{"r":0,"d":0,"h":60133836260,"f":8},"n":"Disposed","d":4294116,"h":55838868964,"f":8},{"p":56229889,"g":{"r":0,"d":0,"h":68723770852,"f":8},"n":"DistributedTxId","d":4294116,"h":64428803556,"f":8},{"p":4752868,"g":{"r":0,"d":0,"h":120263378404,"f":1},"n":"TransactionInformation","d":4294116,"h":115968411108,"f":1},{"p":3180004,"g":{"r":0,"d":0,"h":128853312996,"f":1},"n":"IsolationLevel","d":4294116,"h":124558345700,"f":1},{"p":56229889,"g":{"r":0,"d":0,"h":137443247588,"f":1},"n":"PromoterType","d":4294116,"h":133148280292,"f":1},{"p":8553956,"g":{"r":0,"d":0,"h":188982855140,"f":8},"n":"TransactionTraceId","d":4294116,"h":184687887844,"f":8}],"m":[{"r":262145,"n":"UseServiceDomainForCurrent","d":4294116,"h":4299261412,"f":40},{"r":2262500,"p":[{"n":"currentScope","p":5146084}],"n":"InteropMode","d":4294116,"h":8594228708,"f":40},{"r":4294116,"p":[{"n":"currentScope","p":5146084},{"n":"contextData","p":886244},{"n":"contextTransaction","p":4294116,"f":2}],"n":"FastGetTransaction","d":4294116,"h":12889196004,"f":40},{"r":65537,"p":[{"n":"defaultLookup","p":8619492},{"n":"current","p":4294116,"f":2},{"n":"currentScope","p":5146084,"f":2},{"n":"contextTransaction","p":4294116,"f":2}],"n":"GetCurrentTransactionAndScope","d":4294116,"h":17184163300,"f":40},{"r":655361,"n":"GetHashCode","d":4294116,"h":98788541924,"f":32769},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":4294116,"h":103083509220,"f":32769},{"r":0,"n":"GetPromotedToken","d":4294116,"h":141738214884,"f":1},{"r":1738212,"p":[{"n":"resourceManagerIdentifier","p":56229889},{"n":"enlistmentNotification","p":2590180},{"n":"enlistmentOptions","p":1869284}],"n":"EnlistDurable","d":4294116,"h":146033182180,"f":1},{"r":1738212,"p":[{"n":"resourceManagerIdentifier","p":56229889},{"n":"singlePhaseNotification","p":3048932},{"n":"enlistmentOptions","p":1869284}],"n":"EnlistDurable","o":"@$1","d":4294116,"h":150328149476,"f":1},{"r":65537,"n":"Rollback","d":4294116,"h":154623116772,"f":1},{"r":65537,"p":[{"n":"e","p":47251457}],"n":"Rollback","o":"@$1","d":4294116,"h":158918084068,"f":1},{"r":1738212,"p":[{"n":"enlistmentNotification","p":2590180},{"n":"enlistmentOptions","p":1869284}],"n":"EnlistVolatile","d":4294116,"h":163213051364,"f":1},{"r":1738212,"p":[{"n":"singlePhaseNotification","p":3048932},{"n":"enlistmentOptions","p":1869284}],"n":"EnlistVolatile","o":"@$1","d":4294116,"h":167508018660,"f":1},{"r":4294116,"n":"Clone","d":4294116,"h":171802985956,"f":1},{"r":4294116,"n":"InternalClone","d":4294116,"h":176097953252,"f":8},{"r":1148388,"p":[{"n":"cloneOption","p":1082852}],"n":"DependentClone","d":4294116,"h":180392920548,"f":1},{"r":65537,"n":"Dispose","d":4294116,"h":206162724324,"f":1},{"r":65537,"n":"InternalDispose","d":4294116,"h":210457691620,"f":136},{"r":262145,"p":[{"n":"promotableSinglePhaseNotification","p":2852324}],"n":"EnlistPromotableSinglePhase","d":4294116,"h":219047626212,"f":1},{"r":262145,"p":[{"n":"promotableSinglePhaseNotification","p":2852324},{"n":"promoterType","p":56229889}],"n":"EnlistPromotableSinglePhase","o":"@$1","d":4294116,"h":223342593508,"f":1},{"r":1738212,"p":[{"n":"resourceManagerIdentifier","p":56229889},{"n":"promotableNotification","p":2852324},{"n":"enlistmentNotification","p":3048932},{"n":"enlistmentOptions","p":1869284}],"n":"PromoteAndEnlistDurable","d":4294116,"h":227637560804,"f":1},{"r":65537,"p":[{"n":"promotableNotification","p":2852324},{"n":"distributedTransactionIdentifier","p":56229889}],"n":"SetDistributedTransactionIdentifier","d":4294116,"h":231932528100,"f":1},{"r":3507684,"n":"Promote","d":4294116,"h":236227495396,"f":8}],"l":[{"t":3180004,"n":"_isoLevel","d":4294116,"h":34364032484,"f":8},{"t":262145,"n":"_complete","d":4294116,"h":38658999780,"f":8},{"t":655361,"n":"_cloneId","d":4294116,"h":42953967076,"f":8},{"t":655361,"n":"_disposedTrueValue","d":4294116,"h":47248934372,"f":40},{"t":655361,"n":"_disposed","d":4294116,"h":51543901668,"f":8},{"t":2786788,"n":"_internalTransaction","d":4294116,"h":73018738148,"f":8},{"t":8553956,"n":"_traceIdentifier","d":4294116,"h":77313705444,"f":8}],"c":[{"n":".ctor","o":"$ctor$1","d":4294116,"h":81608672740,"f":2},{"p":[{"n":"isoLevel","p":3180004},{"n":"internalTransaction","p":2786788}],"n":".ctor","o":"$ctor$2","d":4294116,"h":85903640036,"f":8},{"p":[{"n":"distributedTransaction","p":3507684}],"n":".ctor","o":"$ctor$3","d":4294116,"h":90198607332,"f":8},{"p":[{"n":"isoLevel","p":3180004},{"n":"superior","p":2983396}],"n":".ctor","o":"$ctor$4","d":4294116,"h":94493574628,"f":8}],"e":[{"e":4425188,"m":{"r":65537,"p":[{"n":"value","p":4425188}],"n":"add_TransactionCompleted","d":4294116,"h":197572789732,"f":1},"r":{"r":65537,"p":[{"n":"value","p":4425188}],"n":"remove_TransactionCompleted","d":4294116,"h":201867757028,"f":1},"n":"TransactionCompleted","d":4294116,"h":193277822436,"f":1}],"i":[57540609,113377281],"h":4294116}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Transactions.Transaction`; }
        });
        
        $asm.$cls("$stl.System.Transactions.EnlistmentStatePromoted", ($self) => class EnlistmentStatePromoted extends $.$stl.System.Transactions.EnlistmentState
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                enlistment.State = this;
            }
            /*void */ EnlistmentDone(/*InternalEnlistment*/ enlistment)
            {
                $.$spc.System.Threading.Monitor.Exit(enlistment.SyncRoot);
                try
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.PromotedEnlistment !== null, "enlistment.PromotedEnlistment != null");
                    enlistment.PromotedEnlistment.System$Transactions$IPromotedEnlistment$EnlistmentDone();
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(enlistment.SyncRoot);
                    }
                }
            }
            /*void */ Prepared(/*InternalEnlistment*/ enlistment)
            {
                $.$spc.System.Threading.Monitor.Exit(enlistment.SyncRoot);
                try
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.PromotedEnlistment !== null, "enlistment.PromotedEnlistment != null");
                    enlistment.PromotedEnlistment.System$Transactions$IPromotedEnlistment$Prepared();
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(enlistment.SyncRoot);
                    }
                }
            }
            /*void */ ForceRollback(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
                $.$spc.System.Threading.Monitor.Exit(enlistment.SyncRoot);
                try
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.PromotedEnlistment !== null, "enlistment.PromotedEnlistment != null");
                    enlistment.PromotedEnlistment.System$Transactions$IPromotedEnlistment$ForceRollback$1(e);
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(enlistment.SyncRoot);
                    }
                }
            }
            /*void */ Committed(/*InternalEnlistment*/ enlistment)
            {
                $.$spc.System.Threading.Monitor.Exit(enlistment.SyncRoot);
                try
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.PromotedEnlistment !== null, "enlistment.PromotedEnlistment != null");
                    enlistment.PromotedEnlistment.System$Transactions$IPromotedEnlistment$Committed();
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(enlistment.SyncRoot);
                    }
                }
            }
            /*void */ Aborted(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
                $.$spc.System.Threading.Monitor.Exit(enlistment.SyncRoot);
                try
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.PromotedEnlistment !== null, "enlistment.PromotedEnlistment != null");
                    enlistment.PromotedEnlistment.System$Transactions$IPromotedEnlistment$Aborted$1(e);
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(enlistment.SyncRoot);
                    }
                }
            }
            /*void */ InDoubt(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
                $.$spc.System.Threading.Monitor.Exit(enlistment.SyncRoot);
                try
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.PromotedEnlistment !== null, "enlistment.PromotedEnlistment != null");
                    enlistment.PromotedEnlistment.System$Transactions$IPromotedEnlistment$InDoubt$1(e);
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(enlistment.SyncRoot);
                    }
                }
            }
            /*byte[] */ RecoveryInformation(/*InternalEnlistment*/ enlistment)
            {
                $.$spc.System.Threading.Monitor.Exit(enlistment.SyncRoot);
                try
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.PromotedEnlistment !== null, "enlistment.PromotedEnlistment != null");
                    return enlistment.PromotedEnlistment.System$Transactions$IPromotedEnlistment$GetRecoveryInformation();
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(enlistment.SyncRoot);
                    }
                }
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 2000356;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1934820,"m":[{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"EnterState","d":2000356,"h":4296967652,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"EnlistmentDone","d":2000356,"h":8591934948,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"Prepared","d":2000356,"h":12886902244,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2721252},{"n":"e","p":47251457}],"n":"ForceRollback","d":2000356,"h":17181869540,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"Committed","d":2000356,"h":21476836836,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2721252},{"n":"e","p":47251457}],"n":"Aborted","d":2000356,"h":25771804132,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2721252},{"n":"e","p":47251457}],"n":"InDoubt","d":2000356,"h":30066771428,"f":32776},{"r":0,"p":[{"n":"enlistment","p":2721252}],"n":"RecoveryInformation","d":2000356,"h":34361738724,"f":32776}],"c":[{"n":".ctor","o":"$ctor$2","d":2000356,"h":38656706020,"f":1}],"h":2000356}; }
            static get $b() { return $.$stl.System.Transactions.EnlistmentState; }
            static get $fullName() { return `System.Transactions.EnlistmentStatePromoted`; }
        });
        
        $asm.$str("$stl.System.Transactions.VolatileEnlistmentSet", ($self) => class VolatileEnlistmentSet extends $.$spc.System.ValueType
        {
            /*InternalEnlistment[]*/  get _volatileEnlistments() { return this.$getField(0, 4); }
            /*InternalEnlistment[]*/  set _volatileEnlistments(value) { this.$setField(0, 4, value); }
            /*int*/  get _volatileEnlistmentCount() { return this.$getField(4, 4); }
            /*int*/  set _volatileEnlistmentCount(value) { this.$setField(4, 4, value); }
            /*int*/  get _volatileEnlistmentSize() { return this.$getField(8, 4); }
            /*int*/  set _volatileEnlistmentSize(value) { this.$setField(8, 4, value); }
            /*int*/  get _dependentClones() { return this.$getField(12, 4); }
            /*int*/  set _dependentClones(value) { this.$setField(12, 4, value); }
            /*int*/  get _preparedVolatileEnlistments() { return this.$getField(16, 4); }
            /*int*/  set _preparedVolatileEnlistments(value) { this.$setField(16, 4, value); }
            /*VolatileDemultiplexer*/  get _volatileDemux() { return this.$getField(20, 4); }
            /*VolatileDemultiplexer*/  set _volatileDemux(value) { this.$setField(20, 4, value); }
            /*VolatileDemultiplexer */ get VolatileDemux()
            {
                return this._volatileDemux;
            }
            /*VolatileDemultiplexer */ set VolatileDemux(value)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._volatileDemux === null, "volatileDemux can only be set once.");
                this._volatileDemux = value;
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._volatileEnlistments = this._volatileEnlistments;
                copy._volatileEnlistmentCount = this._volatileEnlistmentCount;
                copy._volatileEnlistmentSize = this._volatileEnlistmentSize;
                copy._dependentClones = this._dependentClones;
                copy._preparedVolatileEnlistments = this._preparedVolatileEnlistments;
                copy._volatileDemux = this._volatileDemux;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._volatileEnlistments = null;
                this._volatileEnlistmentCount = 0;
                this._volatileEnlistmentSize = 0;
                this._dependentClones = 0;
                this._preparedVolatileEnlistments = 0;
                this._volatileDemux = null;
            }
            static $h = 9340388;
            static $z = 24;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":8685028,"g":{"r":0,"d":0,"h":34369078756,"f":8},"s":{"r":0,"d":0,"h":38664046052,"f":8},"n":"VolatileDemux","d":9340388,"h":30074111460,"f":8}],"l":[{"t":0,"n":"_volatileEnlistments","d":9340388,"h":4304307684,"f":8},{"t":655361,"n":"_volatileEnlistmentCount","d":9340388,"h":8599274980,"f":8},{"t":655361,"n":"_volatileEnlistmentSize","d":9340388,"h":12894242276,"f":8},{"t":655361,"n":"_dependentClones","d":9340388,"h":17189209572,"f":8},{"t":655361,"n":"_preparedVolatileEnlistments","d":9340388,"h":21484176868,"f":8},{"t":8685028,"n":"_volatileDemux","d":9340388,"h":25779144164,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":9340388,"h":42959013348,"f":1}],"h":9340388}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Transactions.VolatileEnlistmentSet`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePSPEOperation", ($self) => class TransactionStatePSPEOperation extends $.$stl.System.Transactions.TransactionState
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                throw new $.$spc.System.InvalidOperationException().$ctor$9();
            }
            /*TransactionStatus */ get_Status(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ PSPEInitialize(/*InternalTransaction*/ tx, /*IPromotableSinglePhaseNotification*/ promotableSinglePhaseNotification, /*Guid*/ promoterType)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(tx.State === $.$stl.System.Transactions.TransactionState.TransactionStateActive, "PSPEPromote called from state other than TransactionStateActive");
                this.CommonEnterState(tx);
                try
                {
                    promotableSinglePhaseNotification.System$Transactions$IPromotableSinglePhaseNotification$Initialize();
                    tx._promoterType = promoterType;
                }
                finally
                {
                    {
                        $.$stl.System.Transactions.TransactionState.TransactionStateActive.CommonEnterState(tx);
                    }
                }
            }
            /*void */ Phase0PSPEInitialize(/*InternalTransaction*/ tx, /*IPromotableSinglePhaseNotification*/ promotableSinglePhaseNotification, /*Guid*/ promoterType)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(tx.State === $.$stl.System.Transactions.TransactionState.TransactionStatePhase0, "Phase0PSPEInitialize called from state other than TransactionStatePhase0");
                this.CommonEnterState(tx);
                try
                {
                    promotableSinglePhaseNotification.System$Transactions$IPromotableSinglePhaseNotification$Initialize();
                    tx._promoterType = promoterType;
                }
                finally
                {
                    {
                        $.$stl.System.Transactions.TransactionState.TransactionStatePhase0.CommonEnterState(tx);
                    }
                }
            }
            /*Oletx.OletxTransaction? */ PSPEPromote(/*InternalTransaction*/ tx)
            {
                /*bool*/ let changeToReturnState = true;
                /*TransactionState?*/ let returnState = tx.State;
                $.$spc.System.Diagnostics.Debug.Assert$1(returnState === $.$stl.System.Transactions.TransactionState.TransactionStateDelegated || returnState === $.$stl.System.Transactions.TransactionState.TransactionStateDelegatedSubordinate || returnState === $.$stl.System.Transactions.TransactionState.TransactionStateDelegatedNonMSDTC, "PSPEPromote called from state other than TransactionStateDelegated[NonMSDTC]");
                this.CommonEnterState(tx);
                /*Oletx.OletxTransaction?*/ let distributedTx = null;
                try
                {
                    if (tx._attemptingPSPEPromote)
                    {
                        throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException$1(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.PromotedReturnedInvalidValue, null, tx.DistributedTxId);
                    }
                    tx._attemptingPSPEPromote = true;
                    $.$spc.System.Diagnostics.Debug.Assert$1(tx._promoter !== null, "tx._promoter != null");
                    /*byte[]?*/ let propagationToken = tx._promoter.System$Transactions$ITransactionPromoter$Promote();
                    if ($.$spc.System.Guid.op_Inequality(tx._promoterType, $.$stl.System.Transactions.TransactionInterop.PromoterTypeDtc))
                    {
                        if (propagationToken === null)
                        {
                            throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException$1(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.PromotedReturnedInvalidValue, null, tx.DistributedTxId);
                        }
                        tx.promotedToken = propagationToken;
                        return null;
                    }
                    if (propagationToken === null)
                    {
                        if (tx.PromotedTransaction === null)
                        {
                            throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException$1(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.PromotedReturnedInvalidValue, null, tx.DistributedTxId);
                        }
                        changeToReturnState = false;
                        distributedTx = tx.PromotedTransaction;
                    }
                    if (distributedTx === null)
                    {
                        try
                        {
                            distributedTx = $.$stl.System.Transactions.TransactionInterop.GetOletxTransactionFromTransmitterPropagationToken(propagationToken);
                        }
                        catch(e)
                        {
                            throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException$1(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.PromotedReturnedInvalidValue, e, tx.DistributedTxId);
                        }
                        if ($.$stl.System.Transactions.Transaction.op_Inequality($.$stl.System.Transactions.TransactionManager.FindPromotedTransaction(distributedTx.Identifier), null))
                        {
                            throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException$1(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.PromotedTransactionExists, null, tx.DistributedTxId);
                        }
                    }
                }
                finally
                {
                    {
                        tx._attemptingPSPEPromote = false;
                        if (changeToReturnState)
                        {
                            returnState.CommonEnterState(tx);
                        }
                    }
                }
                return distributedTx;
            }
            /*Enlistment */ PromoteAndEnlistDurable(/*InternalTransaction*/ tx, /*Guid*/ resourceManagerIdentifier, /*IPromotableSinglePhaseNotification*/ promotableNotification, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                if (!tx._attemptingPSPEPromote)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
                }
                if (promotableNotification !== tx._promoter)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException$1(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.InvalidIPromotableSinglePhaseNotificationSpecified, null, tx.DistributedTxId);
                }
                /*Enlistment*/ let enlistment;
                tx._durableEnlistment = null;
                tx._promoteState = $.$stl.System.Transactions.TransactionState.TransactionStatePromoted;
                tx._promoteState.EnterState(tx);
                enlistment = tx.State.EnlistDurable$1(tx, resourceManagerIdentifier, enlistmentNotification, enlistmentOptions, atomicTransaction);
                tx._durableEnlistment = enlistment.InternalEnlistment;
                return enlistment;
            }
            /*void */ SetDistributedTransactionId(/*InternalTransaction*/ tx, /*IPromotableSinglePhaseNotification*/ promotableNotification, /*Guid*/ distributedTransactionIdentifier)
            {
                if (!tx._attemptingPSPEPromote)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
                }
                if (promotableNotification !== tx._promoter)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException$1(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.InvalidIPromotableSinglePhaseNotificationSpecified, null, tx.DistributedTxId);
                }
                tx._distributedTransactionIdentifierNonMSDTC = distributedTransactionIdentifier;
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 8095204;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":5735908,"m":[{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"EnterState","d":8095204,"h":4303062500,"f":32776},{"r":8422884,"p":[{"n":"tx","p":2786788}],"n":"get_Status","d":8095204,"h":8598029796,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"promotableSinglePhaseNotification","p":2852324},{"n":"promoterType","p":56229889}],"n":"PSPEInitialize","d":8095204,"h":12892997092,"f":8},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"promotableSinglePhaseNotification","p":2852324},{"n":"promoterType","p":56229889}],"n":"Phase0PSPEInitialize","d":8095204,"h":17187964388,"f":8},{"r":3507684,"p":[{"n":"tx","p":2786788}],"n":"PSPEPromote","d":8095204,"h":21482931684,"f":8},{"r":1738212,"p":[{"n":"tx","p":2786788},{"n":"resourceManagerIdentifier","p":56229889},{"n":"promotableNotification","p":2852324},{"n":"enlistmentNotification","p":3048932},{"n":"enlistmentOptions","p":1869284},{"n":"atomicTransaction","p":4294116}],"n":"PromoteAndEnlistDurable","d":8095204,"h":25777898980,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"promotableNotification","p":2852324},{"n":"distributedTransactionIdentifier","p":56229889}],"n":"SetDistributedTransactionId","d":8095204,"h":30072866276,"f":32776}],"c":[{"n":".ctor","o":"$ctor$2","d":8095204,"h":34367833572,"f":1}],"h":8095204}; }
            static get $b() { return $.$stl.System.Transactions.TransactionState; }
            static get $fullName() { return `System.Transactions.TransactionStatePSPEOperation`; }
        });
        
        $asm.$str("$stl.System.Transactions.EnlistmentTraceIdentifier", ($self) => class EnlistmentTraceIdentifier extends $.$spc.System.ValueType
        {
            static /*EnlistmentTraceIdentifier */ get Empty()
            {
                return new $.$stl.System.Transactions.EnlistmentTraceIdentifier();
            }
            $ctor$2(/*Guid*/ resourceManagerIdentifier, /*TransactionTraceIdentifier*/ transactionTraceId, /*int*/ enlistmentIdentifier)
            {
                super.$ctor$1();
                {
                    this._resourceManagerIdentifier = resourceManagerIdentifier;
                    this._transactionTraceIdentifier = transactionTraceId;
                    this._enlistmentIdentifier = enlistmentIdentifier;
                }
                return this;
            }
            /*Guid*/  get _resourceManagerIdentifier() { return this.$getField(0, 16); }
            /*Guid*/  set _resourceManagerIdentifier(value) { this.$setField(0, 16, value); }
            /*Guid */ get ResourceManagerIdentifier()
            {
                return this._resourceManagerIdentifier;
            }
            /*TransactionTraceIdentifier*/  get _transactionTraceIdentifier() { return this.$getField(16, 8); }
            /*TransactionTraceIdentifier*/  set _transactionTraceIdentifier(value) { this.$setField(16, 8, value); }
            /*TransactionTraceIdentifier */ get TransactionTraceId()
            {
                return this._transactionTraceIdentifier;
            }
            /*int*/  get _enlistmentIdentifier() { return this.$getField(24, 4); }
            /*int*/  set _enlistmentIdentifier(value) { this.$setField(24, 4, value); }
            /*int */ get EnlistmentIdentifier()
            {
                return this._enlistmentIdentifier;
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$spc.System.ValueType.GetHashCode.call(this);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$stl.System.Transactions.EnlistmentTraceIdentifier.GetHashCode.apply(this, arguments); }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                let enlistmentTraceId;
                return $.$is(obj, $.$stl.System.Transactions.EnlistmentTraceIdentifier, { set $v(v){ enlistmentTraceId = v; } }) && this.Equals$2(enlistmentTraceId);
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$stl.System.Transactions.EnlistmentTraceIdentifier.Equals.apply(this, arguments); }
            /*bool */ Equals$2(/*EnlistmentTraceIdentifier*/ other)
            {
                return this._enlistmentIdentifier === other._enlistmentIdentifier && $.$spc.System.Guid.op_Equality(this._resourceManagerIdentifier, other._resourceManagerIdentifier) && $.$stl.System.Transactions.TransactionTraceIdentifier.op_Equality(this._transactionTraceIdentifier, other._transactionTraceIdentifier);
            }
            static /*bool */ op_Equality(/*EnlistmentTraceIdentifier*/ left, /*EnlistmentTraceIdentifier*/ right)
            {
                return left.Equals$2(right);
            }
            static /*bool */ op_Inequality(/*EnlistmentTraceIdentifier*/ left, /*EnlistmentTraceIdentifier*/ right)
            {
                return !left.Equals$2(right);
            }
            //Generated interface implemetation for System.IEquatable<System.Transactions.EnlistmentTraceIdentifier>.Equals(System.Transactions.EnlistmentTraceIdentifier)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._resourceManagerIdentifier = this._resourceManagerIdentifier.Clone();
                copy._transactionTraceIdentifier = this._transactionTraceIdentifier.Clone();
                copy._enlistmentIdentifier = this._enlistmentIdentifier;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._resourceManagerIdentifier = $.$default($.$spc.System.Guid);
                this._transactionTraceIdentifier = $.$default($.$stl.System.Transactions.TransactionTraceIdentifier);
                this._enlistmentIdentifier = 0;
            }
            static $h = 2065892;
            static $z = 28;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":2065892,"g":{"r":0,"d":0,"h":8592000484,"f":33},"n":"Empty","d":2065892,"h":4297033188,"f":33},{"p":56229889,"g":{"r":0,"d":0,"h":25771869668,"f":1},"n":"ResourceManagerIdentifier","d":2065892,"h":21476902372,"f":1},{"p":8553956,"g":{"r":0,"d":0,"h":38656771556,"f":1},"n":"TransactionTraceId","d":2065892,"h":34361804260,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":51541673444,"f":1},"n":"EnlistmentIdentifier","d":2065892,"h":47246706148,"f":1}],"m":[{"r":655361,"n":"GetHashCode","d":2065892,"h":55836640740,"f":32769},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":2065892,"h":60131608036,"f":32769},{"r":262145,"p":[{"n":"other","p":2065892}],"n":"Equals","o":"@$2","d":2065892,"h":64426575332,"f":1}],"l":[{"t":56229889,"n":"_resourceManagerIdentifier","d":2065892,"h":17181935076,"f":2},{"t":8553956,"n":"_transactionTraceIdentifier","d":2065892,"h":30066836964,"f":2},{"t":655361,"n":"_enlistmentIdentifier","d":2065892,"h":42951738852,"f":2}],"c":[{"p":[{"n":"resourceManagerIdentifier","p":56229889},{"n":"transactionTraceId","p":8553956},{"n":"enlistmentIdentifier","p":655361}],"n":".ctor","o":"$ctor$2","d":2065892,"h":12886967780,"f":1},{"n":".ctor","o":"$ctor$3","d":2065892,"h":77311477220,"f":1}],"i":[$.$spc.System.IEquatable$$($.$stl.System.Transactions.EnlistmentTraceIdentifier).$h],"h":2065892}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$stl.System.Transactions.EnlistmentTraceIdentifier) ]; }
            static get $fullName() { return `System.Transactions.EnlistmentTraceIdentifier`; }
        });
        
        $asm.$str("$stl.System.Transactions.TransactionOptions", ($self) => class TransactionOptions extends $.$spc.System.ValueType
        {
            /*TimeSpan*/  get _timeout() { return this.$getField(0, $.$spc.System.TimeSpan); }
            /*TimeSpan*/  set _timeout(value) { this.$setField(0, $.$spc.System.TimeSpan, value); }
            /*IsolationLevel*/  get _isolationLevel() { return this.$getField(8, $.$stl.System.Transactions.IsolationLevel); }
            /*IsolationLevel*/  set _isolationLevel(value) { this.$setField(8, $.$stl.System.Transactions.IsolationLevel, value); }
            /*TimeSpan */ get Timeout()
            {
                return this._timeout;
            }
            /*TimeSpan */ set Timeout(value)
            {
                this._timeout = value;
            }
            /*IsolationLevel */ get IsolationLevel()
            {
                return this._isolationLevel;
            }
            /*IsolationLevel */ set IsolationLevel(value)
            {
                this._isolationLevel = value;
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$spc.System.ValueType.GetHashCode.call(this);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$stl.System.Transactions.TransactionOptions.GetHashCode.apply(this, arguments); }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                let transactionOptions;
                return $.$is(obj, $.$stl.System.Transactions.TransactionOptions, { set $v(v){ transactionOptions = v; } }) && this.Equals$2(transactionOptions.Clone());
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$stl.System.Transactions.TransactionOptions.Equals.apply(this, arguments); }
            /*bool */ Equals$2(/*TransactionOptions*/ other)
            {
                return $.$spc.System.TimeSpan.op_Equality(this._timeout, other._timeout) && this._isolationLevel === other._isolationLevel;
            }
            static /*bool */ op_Equality(/*TransactionOptions*/ x, /*TransactionOptions*/ y)
            {
                return x.Equals$2(y.Clone());
            }
            static /*bool */ op_Inequality(/*TransactionOptions*/ x, /*TransactionOptions*/ y)
            {
                return !x.Equals$2(y.Clone());
            }
            //Generated interface implemetation for System.IEquatable<System.Transactions.TransactionOptions>.Equals(System.Transactions.TransactionOptions)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._timeout = this._timeout.Clone();
                copy._isolationLevel = this._isolationLevel;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._timeout = $.$default($.$spc.System.TimeSpan);
                this._isolationLevel = 0;
            }
            static $h = 5015012;
            static $z = 12;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":140705793,"g":{"r":0,"d":0,"h":17184884196,"f":1},"s":{"r":0,"d":0,"h":21479851492,"f":1},"n":"Timeout","d":5015012,"h":12889916900,"f":1},{"p":3180004,"g":{"r":0,"d":0,"h":30069786084,"f":1},"s":{"r":0,"d":0,"h":34364753380,"f":1},"n":"IsolationLevel","d":5015012,"h":25774818788,"f":1}],"m":[{"r":655361,"n":"GetHashCode","d":5015012,"h":38659720676,"f":32769},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":5015012,"h":42954687972,"f":32769},{"r":262145,"p":[{"n":"other","p":5015012}],"n":"Equals","o":"@$2","d":5015012,"h":47249655268,"f":1}],"l":[{"t":140705793,"n":"_timeout","d":5015012,"h":4299982308,"f":2},{"t":3180004,"n":"_isolationLevel","d":5015012,"h":8594949604,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":5015012,"h":60134557156,"f":1}],"i":[$.$spc.System.IEquatable$$($.$stl.System.Transactions.TransactionOptions).$h],"h":5015012}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$stl.System.Transactions.TransactionOptions) ]; }
            static get $fullName() { return `System.Transactions.TransactionOptions`; }
        });
        
        $asm.$str("$stl.System.Transactions.TransactionTraceIdentifier", ($self) => class TransactionTraceIdentifier extends $.$spc.System.ValueType
        {
            static /*TransactionTraceIdentifier */ get Empty()
            {
                return new $.$stl.System.Transactions.TransactionTraceIdentifier();
            }
            $ctor$2(/*string*/ transactionIdentifier, /*int*/ cloneIdentifier)
            {
                super.$ctor$1();
                {
                    this._transactionIdentifier = transactionIdentifier;
                    this._cloneIdentifier = cloneIdentifier;
                }
                return this;
            }
            /*string*/  get _transactionIdentifier() { return this.$getField(0, 4); }
            /*string*/  set _transactionIdentifier(value) { this.$setField(0, 4, value); }
            /*string */ get TransactionIdentifier()
            {
                return this._transactionIdentifier;
            }
            /*int*/  get _cloneIdentifier() { return this.$getField(4, 4); }
            /*int*/  set _cloneIdentifier(value) { this.$setField(4, 4, value); }
            /*int */ get CloneIdentifier()
            {
                return this._cloneIdentifier;
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$spc.System.ValueType.GetHashCode.call(this);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$stl.System.Transactions.TransactionTraceIdentifier.GetHashCode.apply(this, arguments); }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                let transactionTraceId;
                return $.$is(obj, $.$stl.System.Transactions.TransactionTraceIdentifier, { set $v(v){ transactionTraceId = v; } }) && this.Equals$2(transactionTraceId);
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$stl.System.Transactions.TransactionTraceIdentifier.Equals.apply(this, arguments); }
            /*bool */ Equals$2(/*TransactionTraceIdentifier*/ other)
            {
                return this._cloneIdentifier === other._cloneIdentifier && $.$spc.System.String.op_Equality(this._transactionIdentifier, other._transactionIdentifier);
            }
            static /*bool */ op_Equality(/*TransactionTraceIdentifier*/ left, /*TransactionTraceIdentifier*/ right)
            {
                return left.Equals$2(right);
            }
            static /*bool */ op_Inequality(/*TransactionTraceIdentifier*/ left, /*TransactionTraceIdentifier*/ right)
            {
                return !left.Equals$2(right);
            }
            //Generated interface implemetation for System.IEquatable<System.Transactions.TransactionTraceIdentifier>.Equals(System.Transactions.TransactionTraceIdentifier)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._transactionIdentifier = this._transactionIdentifier;
                copy._cloneIdentifier = this._cloneIdentifier;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._transactionIdentifier = null;
                this._cloneIdentifier = 0;
            }
            static $h = 8553956;
            static $z = 8;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":8553956,"g":{"r":0,"d":0,"h":8598488548,"f":33},"n":"Empty","d":8553956,"h":4303521252,"f":33},{"p":1310721,"g":{"r":0,"d":0,"h":25778357732,"f":1},"n":"TransactionIdentifier","d":8553956,"h":21483390436,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":38663259620,"f":1},"n":"CloneIdentifier","d":8553956,"h":34368292324,"f":1}],"m":[{"r":655361,"n":"GetHashCode","d":8553956,"h":42958226916,"f":32769},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":8553956,"h":47253194212,"f":32769},{"r":262145,"p":[{"n":"other","p":8553956}],"n":"Equals","o":"@$2","d":8553956,"h":51548161508,"f":1}],"l":[{"t":1310721,"n":"_transactionIdentifier","d":8553956,"h":17188423140,"f":2},{"t":655361,"n":"_cloneIdentifier","d":8553956,"h":30073325028,"f":2}],"c":[{"p":[{"n":"transactionIdentifier","p":1310721},{"n":"cloneIdentifier","p":655361}],"n":".ctor","o":"$ctor$2","d":8553956,"h":12893455844,"f":1},{"n":".ctor","o":"$ctor$3","d":8553956,"h":64433063396,"f":1}],"i":[$.$spc.System.IEquatable$$($.$stl.System.Transactions.TransactionTraceIdentifier).$h],"h":8553956}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$stl.System.Transactions.TransactionTraceIdentifier) ]; }
            static get $fullName() { return `System.Transactions.TransactionTraceIdentifier`; }
        });
        
        $asm.$cls("$stl.System.Transactions.Phase0VolatileDemultiplexer", ($self) => class Phase0VolatileDemultiplexer extends $.$stl.System.Transactions.VolatileDemultiplexer
        {
            $ctor$2(/*InternalTransaction*/ transaction)
            {
                super.$ctor$1(transaction);
                {
                }
                return this;
            }
            /*void */ InternalPrepare()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._promotedEnlistment !== null && this._transaction.State !== null, "_promotedEnlistment != null && _transaction.State != null");
                try
                {
                    this._transaction.State.ChangeStatePromotedPhase0(this._transaction);
                }
                catch($e)
                {
                    if ($e instanceof $.$stl.System.Transactions.TransactionAbortedException)
                    {
                        let e = $e;
                        this._promotedEnlistment.System$Transactions$IPromotedEnlistment$ForceRollback$1(e);
                        /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                        if (etwLog.IsEnabled())
                        {
                            etwLog.ExceptionConsumed$1(e);
                        }
                    }
                    else if ($e instanceof $.$stl.System.Transactions.TransactionInDoubtException)
                    {
                        let e = $e;
                        this._promotedEnlistment.System$Transactions$IPromotedEnlistment$EnlistmentDone();
                        /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                        if (etwLog.IsEnabled())
                        {
                            etwLog.ExceptionConsumed$1(e);
                        }
                    }
                    else
                    {
                        throw $e;
                    }
                }
            }
            /*void */ InternalCommit()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._promotedEnlistment !== null && this._transaction.State !== null, "_promotedEnlistment != null && _transaction.State != null");
                this._promotedEnlistment.System$Transactions$IPromotedEnlistment$EnlistmentDone();
                this._transaction.State.ChangeStatePromotedCommitted(this._transaction);
            }
            /*void */ InternalRollback()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._promotedEnlistment !== null && this._transaction.State !== null, "_promotedEnlistment != null && _transaction.State != null");
                this._promotedEnlistment.System$Transactions$IPromotedEnlistment$EnlistmentDone();
                this._transaction.State.ChangeStatePromotedAborted(this._transaction);
            }
            /*void */ InternalInDoubt()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._transaction.State !== null, "_transaction.State != null");
                this._transaction.State.InDoubtFromDtc(this._transaction);
            }
            /*void */ Prepare(/*IPromotedEnlistment*/ en)
            {
                this._preparingEnlistment = en;
                $.$stl.System.Transactions.VolatileDemultiplexer.PoolablePrepare(this);
            }
            /*void */ Commit(/*IPromotedEnlistment*/ en)
            {
                this._promotedEnlistment = en;
                $.$stl.System.Transactions.VolatileDemultiplexer.PoolableCommit(this);
            }
            /*void */ Rollback(/*IPromotedEnlistment*/ en)
            {
                this._promotedEnlistment = en;
                $.$stl.System.Transactions.VolatileDemultiplexer.PoolableRollback(this);
            }
            /*void */ InDoubt(/*IPromotedEnlistment*/ en)
            {
                this._promotedEnlistment = en;
                $.$stl.System.Transactions.VolatileDemultiplexer.PoolableInDoubt(this);
            }
            static $h = 3704292;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":8685028,"m":[{"r":65537,"n":"InternalPrepare","d":3704292,"h":8593638884,"f":32772},{"r":65537,"n":"InternalCommit","d":3704292,"h":12888606180,"f":32772},{"r":65537,"n":"InternalRollback","d":3704292,"h":17183573476,"f":32772},{"r":65537,"n":"InternalInDoubt","d":3704292,"h":21478540772,"f":32772},{"r":65537,"p":[{"n":"en","p":2917860}],"n":"Prepare","d":3704292,"h":25773508068,"f":32769},{"r":65537,"p":[{"n":"en","p":2917860}],"n":"Commit","d":3704292,"h":30068475364,"f":32769},{"r":65537,"p":[{"n":"en","p":2917860}],"n":"Rollback","d":3704292,"h":34363442660,"f":32769},{"r":65537,"p":[{"n":"en","p":2917860}],"n":"InDoubt","d":3704292,"h":38658409956,"f":32769}],"c":[{"p":[{"n":"transaction","p":2786788}],"n":".ctor","o":"$ctor$2","d":3704292,"h":4298671588,"f":1}],"i":[2655716],"h":3704292}; }
            static get $b() { return $.$stl.System.Transactions.VolatileDemultiplexer; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stl.System.Transactions.IEnlistmentNotificationInternal ]; }
            static get $fullName() { return `System.Transactions.Phase0VolatileDemultiplexer`; }
        });
        
        $asm.$cls("$stl.System.Transactions.Phase1VolatileDemultiplexer", ($self) => class Phase1VolatileDemultiplexer extends $.$stl.System.Transactions.VolatileDemultiplexer
        {
            $ctor$2(/*InternalTransaction*/ transaction)
            {
                super.$ctor$1(transaction);
                {
                }
                return this;
            }
            /*void */ InternalPrepare()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._promotedEnlistment !== null && this._transaction.State !== null, "_promotedEnlistment != null && _transaction.State != null");
                try
                {
                    this._transaction.State.ChangeStatePromotedPhase1(this._transaction);
                }
                catch($e)
                {
                    if ($e instanceof $.$stl.System.Transactions.TransactionAbortedException)
                    {
                        let e = $e;
                        this._promotedEnlistment.System$Transactions$IPromotedEnlistment$ForceRollback$1(e);
                        /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                        if (etwLog.IsEnabled())
                        {
                            etwLog.ExceptionConsumed$1(e);
                        }
                    }
                    else if ($e instanceof $.$stl.System.Transactions.TransactionInDoubtException)
                    {
                        let e = $e;
                        this._promotedEnlistment.System$Transactions$IPromotedEnlistment$EnlistmentDone();
                        /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                        if (etwLog.IsEnabled())
                        {
                            etwLog.ExceptionConsumed$1(e);
                        }
                    }
                    else
                    {
                        throw $e;
                    }
                }
            }
            /*void */ InternalCommit()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._promotedEnlistment !== null && this._transaction.State !== null, "_promotedEnlistment != null && _transaction.State != null");
                this._promotedEnlistment.System$Transactions$IPromotedEnlistment$EnlistmentDone();
                this._transaction.State.ChangeStatePromotedCommitted(this._transaction);
            }
            /*void */ InternalRollback()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._promotedEnlistment !== null && this._transaction.State !== null, "_promotedEnlistment != null && _transaction.State != null");
                this._promotedEnlistment.System$Transactions$IPromotedEnlistment$EnlistmentDone();
                this._transaction.State.ChangeStatePromotedAborted(this._transaction);
            }
            /*void */ InternalInDoubt()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._transaction.State !== null, "_transaction.State != null");
                this._transaction.State.InDoubtFromDtc(this._transaction);
            }
            /*void */ Prepare(/*IPromotedEnlistment*/ en)
            {
                this._preparingEnlistment = en;
                $.$stl.System.Transactions.VolatileDemultiplexer.PoolablePrepare(this);
            }
            /*void */ Commit(/*IPromotedEnlistment*/ en)
            {
                this._promotedEnlistment = en;
                $.$stl.System.Transactions.VolatileDemultiplexer.PoolableCommit(this);
            }
            /*void */ Rollback(/*IPromotedEnlistment*/ en)
            {
                this._promotedEnlistment = en;
                $.$stl.System.Transactions.VolatileDemultiplexer.PoolableRollback(this);
            }
            /*void */ InDoubt(/*IPromotedEnlistment*/ en)
            {
                this._promotedEnlistment = en;
                $.$stl.System.Transactions.VolatileDemultiplexer.PoolableInDoubt(this);
            }
            static $h = 3769828;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":8685028,"m":[{"r":65537,"n":"InternalPrepare","d":3769828,"h":8593704420,"f":32772},{"r":65537,"n":"InternalCommit","d":3769828,"h":12888671716,"f":32772},{"r":65537,"n":"InternalRollback","d":3769828,"h":17183639012,"f":32772},{"r":65537,"n":"InternalInDoubt","d":3769828,"h":21478606308,"f":32772},{"r":65537,"p":[{"n":"en","p":2917860}],"n":"Prepare","d":3769828,"h":25773573604,"f":32769},{"r":65537,"p":[{"n":"en","p":2917860}],"n":"Commit","d":3769828,"h":30068540900,"f":32769},{"r":65537,"p":[{"n":"en","p":2917860}],"n":"Rollback","d":3769828,"h":34363508196,"f":32769},{"r":65537,"p":[{"n":"en","p":2917860}],"n":"InDoubt","d":3769828,"h":38658475492,"f":32769}],"c":[{"p":[{"n":"transaction","p":2786788}],"n":".ctor","o":"$ctor$2","d":3769828,"h":4298737124,"f":1}],"i":[2655716],"h":3769828}; }
            static get $b() { return $.$stl.System.Transactions.VolatileDemultiplexer; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stl.System.Transactions.IEnlistmentNotificationInternal ]; }
            static get $fullName() { return `System.Transactions.Phase1VolatileDemultiplexer`; }
        });
        
        $asm.$cls("$stl.System.Transactions.DurableEnlistmentActive", ($self) => class DurableEnlistmentActive extends $.$stl.System.Transactions.DurableEnlistmentState
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                enlistment.State = this;
            }
            /*void */ EnlistmentDone(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentEnded.EnterState(enlistment);
            }
            /*void */ InternalAborted(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentAborting.EnterState(enlistment);
            }
            /*void */ ChangeStateCommitting(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentCommitting.EnterState(enlistment);
            }
            /*void */ ChangeStatePromoted(/*InternalEnlistment*/ enlistment, /*IPromotedEnlistment*/ promotedEnlistment)
            {
                enlistment.PromotedEnlistment = promotedEnlistment;
                $.$stl.System.Transactions.EnlistmentState.EnlistmentStatePromoted.EnterState(enlistment);
            }
            /*void */ ChangeStateDelegated(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentDelegated.EnterState(enlistment);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 1279460;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1541604,"m":[{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"EnterState","d":1279460,"h":4296246756,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"EnlistmentDone","d":1279460,"h":8591214052,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"InternalAborted","d":1279460,"h":12886181348,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"ChangeStateCommitting","d":1279460,"h":17181148644,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2721252},{"n":"promotedEnlistment","p":2917860}],"n":"ChangeStatePromoted","d":1279460,"h":21476115940,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"ChangeStateDelegated","d":1279460,"h":25771083236,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":1279460,"h":30066050532,"f":1}],"h":1279460}; }
            static get $b() { return $.$stl.System.Transactions.DurableEnlistmentState; }
            static get $fullName() { return `System.Transactions.DurableEnlistmentActive`; }
        });
        
        $asm.$cls("$stl.System.Transactions.DurableEnlistmentAborting", ($self) => class DurableEnlistmentAborting extends $.$stl.System.Transactions.DurableEnlistmentState
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                enlistment.State = this;
                $.$spc.System.Threading.Monitor.Exit(enlistment.Transaction);
                try
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.EnlistmentStatus(1/*TraceSourceType.TraceSourceLtm*/, enlistment.EnlistmentTraceId, 2/*NotificationCall.Rollback*/);
                    }
                    if (enlistment.SinglePhaseNotification !== null)
                    {
                        enlistment.SinglePhaseNotification.System$Transactions$IEnlistmentNotification$Rollback(enlistment.SinglePhaseEnlistment);
                    }
                    else 
                    {
                        enlistment.PromotableSinglePhaseNotification.System$Transactions$IPromotableSinglePhaseNotification$Rollback(enlistment.SinglePhaseEnlistment);
                    }
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(enlistment.Transaction);
                    }
                }
            }
            /*void */ Aborted(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
                enlistment.Transaction._innerException ??= e;
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentEnded.EnterState(enlistment);
            }
            /*void */ EnlistmentDone(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentEnded.EnterState(enlistment);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 1213924;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1541604,"m":[{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"EnterState","d":1213924,"h":4296181220,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2721252},{"n":"e","p":47251457}],"n":"Aborted","d":1213924,"h":8591148516,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"EnlistmentDone","d":1213924,"h":12886115812,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":1213924,"h":17181083108,"f":1}],"h":1213924}; }
            static get $b() { return $.$stl.System.Transactions.DurableEnlistmentState; }
            static get $fullName() { return `System.Transactions.DurableEnlistmentAborting`; }
        });
        
        $asm.$cls("$stl.System.Transactions.DurableEnlistmentCommitting", ($self) => class DurableEnlistmentCommitting extends $.$stl.System.Transactions.DurableEnlistmentState
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                /*bool*/ let spcCommitted = false;
                enlistment.State = this;
                $.$spc.System.Threading.Monitor.Exit(enlistment.Transaction);
                try
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.EnlistmentStatus(1/*TraceSourceType.TraceSourceLtm*/, enlistment.EnlistmentTraceId, 4/*NotificationCall.SinglePhaseCommit*/);
                    }
                    if (enlistment.SinglePhaseNotification !== null)
                    {
                        enlistment.SinglePhaseNotification.System$Transactions$ISinglePhaseNotification$SinglePhaseCommit(enlistment.SinglePhaseEnlistment);
                    }
                    else 
                    {
                        enlistment.PromotableSinglePhaseNotification.System$Transactions$IPromotableSinglePhaseNotification$SinglePhaseCommit(enlistment.SinglePhaseEnlistment);
                    }
                    spcCommitted = true;
                }
                finally
                {
                    {
                        if (!spcCommitted)
                        {
                            enlistment.SinglePhaseEnlistment.InDoubt();
                        }
                        $.$spc.System.Threading.Monitor.Enter(enlistment.Transaction);
                    }
                }
            }
            /*void */ EnlistmentDone(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentEnded.EnterState(enlistment);
                $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.Transaction.State !== null, "enlistment.Transaction.State != null");
                enlistment.Transaction.State.ChangeStateTransactionCommitted(enlistment.Transaction);
            }
            /*void */ Committed(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentEnded.EnterState(enlistment);
                $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.Transaction.State !== null, "enlistment.Transaction.State != null");
                enlistment.Transaction.State.ChangeStateTransactionCommitted(enlistment.Transaction);
            }
            /*void */ Aborted(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentEnded.EnterState(enlistment);
                $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.Transaction.State !== null, "enlistment.Transaction.State != null");
                enlistment.Transaction.State.ChangeStateTransactionAborted(enlistment.Transaction, e);
            }
            /*void */ InDoubt(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentEnded.EnterState(enlistment);
                enlistment.Transaction._innerException ??= e;
                $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.Transaction.State !== null, "enlistment.Transaction.State != null");
                enlistment.Transaction.State.InDoubtFromEnlistment(enlistment.Transaction);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 1344996;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1541604,"m":[{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"EnterState","d":1344996,"h":4296312292,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"EnlistmentDone","d":1344996,"h":8591279588,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"Committed","d":1344996,"h":12886246884,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2721252},{"n":"e","p":47251457}],"n":"Aborted","d":1344996,"h":17181214180,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2721252},{"n":"e","p":47251457}],"n":"InDoubt","d":1344996,"h":21476181476,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":1344996,"h":25771148772,"f":1}],"h":1344996}; }
            static get $b() { return $.$stl.System.Transactions.DurableEnlistmentState; }
            static get $fullName() { return `System.Transactions.DurableEnlistmentCommitting`; }
        });
        
        $asm.$cls("$stl.System.Transactions.DurableEnlistmentDelegated", ($self) => class DurableEnlistmentDelegated extends $.$stl.System.Transactions.DurableEnlistmentState
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                enlistment.State = this;
                $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.PromotableSinglePhaseNotification !== null, "enlistment.PromotableSinglePhaseNotification != null");
            }
            /*void */ Committed(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentEnded.EnterState(enlistment);
                $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.Transaction.State !== null, "enlistment.Transaction.State != null");
                enlistment.Transaction.State.ChangeStatePromotedCommitted(enlistment.Transaction);
            }
            /*void */ Aborted(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentEnded.EnterState(enlistment);
                enlistment.Transaction._innerException ??= e;
                $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.Transaction.State !== null, "enlistment.Transaction.State != null");
                enlistment.Transaction.State.ChangeStatePromotedAborted(enlistment.Transaction);
            }
            /*void */ InDoubt(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentEnded.EnterState(enlistment);
                enlistment.Transaction._innerException ??= e;
                $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.Transaction.State !== null, "enlistment.Transaction.State != null");
                enlistment.Transaction.State.InDoubtFromEnlistment(enlistment.Transaction);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 1410532;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1541604,"m":[{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"EnterState","d":1410532,"h":4296377828,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"Committed","d":1410532,"h":8591345124,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2721252},{"n":"e","p":47251457}],"n":"Aborted","d":1410532,"h":12886312420,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2721252},{"n":"e","p":47251457}],"n":"InDoubt","d":1410532,"h":17181279716,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":1410532,"h":21476247012,"f":1}],"h":1410532}; }
            static get $b() { return $.$stl.System.Transactions.DurableEnlistmentState; }
            static get $fullName() { return `System.Transactions.DurableEnlistmentDelegated`; }
        });
        
        $asm.$cls("$stl.System.Transactions.VolatileEnlistmentActive", ($self) => class VolatileEnlistmentActive extends $.$stl.System.Transactions.VolatileEnlistmentState
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                enlistment.State = this;
            }
            /*void */ EnlistmentDone(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentDone.EnterState(enlistment);
                enlistment.FinishEnlistment();
            }
            /*void */ ChangeStatePreparing(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentPreparing.EnterState(enlistment);
            }
            /*void */ ChangeStateSinglePhaseCommit(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentSPC.EnterState(enlistment);
            }
            /*void */ InternalAborted(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentAborting.EnterState(enlistment);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 8816100;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":9471460,"m":[{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"EnterState","d":8816100,"h":4303783396,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"EnlistmentDone","d":8816100,"h":8598750692,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"ChangeStatePreparing","d":8816100,"h":12893717988,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"ChangeStateSinglePhaseCommit","d":8816100,"h":17188685284,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"InternalAborted","d":8816100,"h":21483652580,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":8816100,"h":25778619876,"f":1}],"h":8816100}; }
            static get $b() { return $.$stl.System.Transactions.VolatileEnlistmentState; }
            static get $fullName() { return `System.Transactions.VolatileEnlistmentActive`; }
        });
        
        $asm.$cls("$stl.System.Transactions.DurableEnlistmentEnded", ($self) => class DurableEnlistmentEnded extends $.$stl.System.Transactions.DurableEnlistmentState
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                enlistment.State = this;
            }
            /*void */ InternalAborted(/*InternalEnlistment*/ enlistment)
            {
            }
            /*void */ InDoubt(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 1476068;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1541604,"m":[{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"EnterState","d":1476068,"h":4296443364,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"InternalAborted","d":1476068,"h":8591410660,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2721252},{"n":"e","p":47251457}],"n":"InDoubt","d":1476068,"h":12886377956,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":1476068,"h":17181345252,"f":1}],"h":1476068}; }
            static get $b() { return $.$stl.System.Transactions.DurableEnlistmentState; }
            static get $fullName() { return `System.Transactions.DurableEnlistmentEnded`; }
        });
        
        $asm.$cls("$stl.System.Transactions.VolatileEnlistmentPreparing", ($self) => class VolatileEnlistmentPreparing extends $.$stl.System.Transactions.VolatileEnlistmentState
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                enlistment.State = this;
                $.$spc.System.Threading.Monitor.Exit(enlistment.Transaction);
                try
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.EnlistmentStatus(1/*TraceSourceType.TraceSourceLtm*/, enlistment.EnlistmentTraceId, 0/*NotificationCall.Prepare*/);
                    }
                    $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.EnlistmentNotification !== null, "enlistment.EnlistmentNotification != null");
                    enlistment.EnlistmentNotification.System$Transactions$IEnlistmentNotification$Prepare(enlistment.PreparingEnlistment);
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(enlistment.Transaction);
                    }
                }
            }
            /*void */ EnlistmentDone(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentDone.EnterState(enlistment);
                enlistment.FinishEnlistment();
            }
            /*void */ Prepared(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentPrepared.EnterState(enlistment);
                enlistment.FinishEnlistment();
            }
            /*void */ ForceRollback(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentEnded.EnterState(enlistment);
                $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.Transaction.State !== null, "enlistment.Transaction.State != null");
                enlistment.Transaction.State.ChangeStateTransactionAborted(enlistment.Transaction, e);
                enlistment.FinishEnlistment();
            }
            /*void */ ChangeStatePreparing(/*InternalEnlistment*/ enlistment)
            {
            }
            /*void */ InternalAborted(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentPreparingAborting.EnterState(enlistment);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 9209316;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":9471460,"m":[{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"EnterState","d":9209316,"h":4304176612,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"EnlistmentDone","d":9209316,"h":8599143908,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"Prepared","d":9209316,"h":12894111204,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2721252},{"n":"e","p":47251457}],"n":"ForceRollback","d":9209316,"h":17189078500,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"ChangeStatePreparing","d":9209316,"h":21484045796,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"InternalAborted","d":9209316,"h":25779013092,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":9209316,"h":30073980388,"f":1}],"h":9209316}; }
            static get $b() { return $.$stl.System.Transactions.VolatileEnlistmentState; }
            static get $fullName() { return `System.Transactions.VolatileEnlistmentPreparing`; }
        });
        
        $asm.$cls("$stl.System.Transactions.VolatileEnlistmentSPC", ($self) => class VolatileEnlistmentSPC extends $.$stl.System.Transactions.VolatileEnlistmentState
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                /*bool*/ let spcCommitted = false;
                enlistment.State = this;
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.EnlistmentStatus(1/*TraceSourceType.TraceSourceLtm*/, enlistment.EnlistmentTraceId, 4/*NotificationCall.SinglePhaseCommit*/);
                }
                $.$spc.System.Threading.Monitor.Exit(enlistment.Transaction);
                try
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.SinglePhaseNotification !== null, "enlistment.SinglePhaseNotification != null");
                    enlistment.SinglePhaseNotification.System$Transactions$ISinglePhaseNotification$SinglePhaseCommit(enlistment.SinglePhaseEnlistment);
                    spcCommitted = true;
                }
                finally
                {
                    {
                        if (!spcCommitted)
                        {
                            enlistment.SinglePhaseEnlistment.InDoubt();
                        }
                        $.$spc.System.Threading.Monitor.Enter(enlistment.Transaction);
                    }
                }
            }
            /*void */ EnlistmentDone(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentEnded.EnterState(enlistment);
                $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.Transaction.State !== null, "enlistment.Transaction.State != null");
                enlistment.Transaction.State.ChangeStateTransactionCommitted(enlistment.Transaction);
            }
            /*void */ Committed(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentEnded.EnterState(enlistment);
                $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.Transaction.State !== null, "enlistment.Transaction.State != null");
                enlistment.Transaction.State.ChangeStateTransactionCommitted(enlistment.Transaction);
            }
            /*void */ Aborted(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentEnded.EnterState(enlistment);
                $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.Transaction.State !== null, "enlistment.Transaction.State != null");
                enlistment.Transaction.State.ChangeStateTransactionAborted(enlistment.Transaction, e);
            }
            /*void */ InDoubt(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentEnded.EnterState(enlistment);
                enlistment.Transaction._innerException ??= e;
                $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.Transaction.State !== null, "enlistment.Transaction.State != null");
                enlistment.Transaction.State.InDoubtFromEnlistment(enlistment.Transaction);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 9405924;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":9471460,"m":[{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"EnterState","d":9405924,"h":4304373220,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"EnlistmentDone","d":9405924,"h":8599340516,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"Committed","d":9405924,"h":12894307812,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2721252},{"n":"e","p":47251457}],"n":"Aborted","d":9405924,"h":17189275108,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2721252},{"n":"e","p":47251457}],"n":"InDoubt","d":9405924,"h":21484242404,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":9405924,"h":25779209700,"f":1}],"h":9405924}; }
            static get $b() { return $.$stl.System.Transactions.VolatileEnlistmentState; }
            static get $fullName() { return `System.Transactions.VolatileEnlistmentSPC`; }
        });
        
        $asm.$cls("$stl.System.Transactions.VolatileEnlistmentPrepared", ($self) => class VolatileEnlistmentPrepared extends $.$stl.System.Transactions.VolatileEnlistmentState
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                enlistment.State = this;
            }
            /*void */ InternalAborted(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentAborting.EnterState(enlistment);
            }
            /*void */ InternalCommitted(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentCommitting.EnterState(enlistment);
            }
            /*void */ InternalIndoubt(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentInDoubt.EnterState(enlistment);
            }
            /*void */ ChangeStatePreparing(/*InternalEnlistment*/ enlistment)
            {
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 9143780;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":9471460,"m":[{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"EnterState","d":9143780,"h":4304111076,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"InternalAborted","d":9143780,"h":8599078372,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"InternalCommitted","d":9143780,"h":12894045668,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"InternalIndoubt","d":9143780,"h":17189012964,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"ChangeStatePreparing","d":9143780,"h":21483980260,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":9143780,"h":25778947556,"f":1}],"h":9143780}; }
            static get $b() { return $.$stl.System.Transactions.VolatileEnlistmentState; }
            static get $fullName() { return `System.Transactions.VolatileEnlistmentPrepared`; }
        });
        
        $asm.$cls("$stl.System.Transactions.VolatileEnlistmentPreparingAborting", ($self) => class VolatileEnlistmentPreparingAborting extends $.$stl.System.Transactions.VolatileEnlistmentState
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                enlistment.State = this;
            }
            /*void */ EnlistmentDone(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentEnded.EnterState(enlistment);
            }
            /*void */ Prepared(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentAborting.EnterState(enlistment);
                enlistment.FinishEnlistment();
            }
            /*void */ ForceRollback(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentEnded.EnterState(enlistment);
                if (enlistment.Transaction._innerException === null)
                {
                    enlistment.Transaction._innerException = e;
                }
                enlistment.FinishEnlistment();
            }
            /*void */ InternalAborted(/*InternalEnlistment*/ enlistment)
            {
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 9274852;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":9471460,"m":[{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"EnterState","d":9274852,"h":4304242148,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"EnlistmentDone","d":9274852,"h":8599209444,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"Prepared","d":9274852,"h":12894176740,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2721252},{"n":"e","p":47251457}],"n":"ForceRollback","d":9274852,"h":17189144036,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"InternalAborted","d":9274852,"h":21484111332,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":9274852,"h":25779078628,"f":1}],"h":9274852}; }
            static get $b() { return $.$stl.System.Transactions.VolatileEnlistmentState; }
            static get $fullName() { return `System.Transactions.VolatileEnlistmentPreparingAborting`; }
        });
        
        $asm.$cls("$stl.System.Transactions.VolatileEnlistmentAborting", ($self) => class VolatileEnlistmentAborting extends $.$stl.System.Transactions.VolatileEnlistmentState
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                enlistment.State = this;
                $.$spc.System.Threading.Monitor.Exit(enlistment.Transaction);
                try
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.EnlistmentStatus(1/*TraceSourceType.TraceSourceLtm*/, enlistment.EnlistmentTraceId, 2/*NotificationCall.Rollback*/);
                    }
                    $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.EnlistmentNotification !== null, "enlistment.EnlistmentNotification != null");
                    enlistment.EnlistmentNotification.System$Transactions$IEnlistmentNotification$Rollback(enlistment.SinglePhaseEnlistment);
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(enlistment.Transaction);
                    }
                }
            }
            /*void */ ChangeStatePreparing(/*InternalEnlistment*/ enlistment)
            {
            }
            /*void */ EnlistmentDone(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentEnded.EnterState(enlistment);
            }
            /*void */ InternalAborted(/*InternalEnlistment*/ enlistment)
            {
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 8750564;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":9471460,"m":[{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"EnterState","d":8750564,"h":4303717860,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"ChangeStatePreparing","d":8750564,"h":8598685156,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"EnlistmentDone","d":8750564,"h":12893652452,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"InternalAborted","d":8750564,"h":17188619748,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":8750564,"h":21483587044,"f":1}],"h":8750564}; }
            static get $b() { return $.$stl.System.Transactions.VolatileEnlistmentState; }
            static get $fullName() { return `System.Transactions.VolatileEnlistmentAborting`; }
        });
        
        $asm.$cls("$stl.System.Transactions.VolatileEnlistmentCommitting", ($self) => class VolatileEnlistmentCommitting extends $.$stl.System.Transactions.VolatileEnlistmentState
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                enlistment.State = this;
                $.$spc.System.Threading.Monitor.Exit(enlistment.Transaction);
                try
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.EnlistmentStatus(1/*TraceSourceType.TraceSourceLtm*/, enlistment.EnlistmentTraceId, 1/*NotificationCall.Commit*/);
                    }
                    $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.EnlistmentNotification !== null, "enlistment.EnlistmentNotification != null");
                    enlistment.EnlistmentNotification.System$Transactions$IEnlistmentNotification$Commit(enlistment.Enlistment);
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(enlistment.Transaction);
                    }
                }
            }
            /*void */ EnlistmentDone(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentEnded.EnterState(enlistment);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 8881636;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":9471460,"m":[{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"EnterState","d":8881636,"h":4303848932,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"EnlistmentDone","d":8881636,"h":8598816228,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":8881636,"h":12893783524,"f":1}],"h":8881636}; }
            static get $b() { return $.$stl.System.Transactions.VolatileEnlistmentState; }
            static get $fullName() { return `System.Transactions.VolatileEnlistmentCommitting`; }
        });
        
        $asm.$cls("$stl.System.Transactions.VolatileEnlistmentInDoubt", ($self) => class VolatileEnlistmentInDoubt extends $.$stl.System.Transactions.VolatileEnlistmentState
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                enlistment.State = this;
                $.$spc.System.Threading.Monitor.Exit(enlistment.Transaction);
                try
                {
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.EnlistmentStatus(1/*TraceSourceType.TraceSourceLtm*/, enlistment.EnlistmentTraceId, 3/*NotificationCall.InDoubt*/);
                    }
                    $.$spc.System.Diagnostics.Debug.Assert$1(enlistment.EnlistmentNotification !== null, "enlistment.EnlistmentNotification != null");
                    enlistment.EnlistmentNotification.System$Transactions$IEnlistmentNotification$InDoubt(enlistment.PreparingEnlistment);
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(enlistment.Transaction);
                    }
                }
            }
            /*void */ EnlistmentDone(/*InternalEnlistment*/ enlistment)
            {
                $.$stl.System.Transactions.VolatileEnlistmentState.VolatileEnlistmentEnded.EnterState(enlistment);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 9078244;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":9471460,"m":[{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"EnterState","d":9078244,"h":4304045540,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"EnlistmentDone","d":9078244,"h":8599012836,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":9078244,"h":12893980132,"f":1}],"h":9078244}; }
            static get $b() { return $.$stl.System.Transactions.VolatileEnlistmentState; }
            static get $fullName() { return `System.Transactions.VolatileEnlistmentInDoubt`; }
        });
        
        $asm.$cls("$stl.System.Transactions.VolatileEnlistmentEnded", ($self) => class VolatileEnlistmentEnded extends $.$stl.System.Transactions.VolatileEnlistmentState
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                enlistment.State = this;
            }
            /*void */ ChangeStatePreparing(/*InternalEnlistment*/ enlistment)
            {
            }
            /*void */ InternalAborted(/*InternalEnlistment*/ enlistment)
            {
            }
            /*void */ InternalCommitted(/*InternalEnlistment*/ enlistment)
            {
            }
            /*void */ InternalIndoubt(/*InternalEnlistment*/ enlistment)
            {
            }
            /*void */ InDoubt(/*InternalEnlistment*/ enlistment, /*Exception?*/ e)
            {
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 9012708;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":9471460,"m":[{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"EnterState","d":9012708,"h":4303980004,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"ChangeStatePreparing","d":9012708,"h":8598947300,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"InternalAborted","d":9012708,"h":12893914596,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"InternalCommitted","d":9012708,"h":17188881892,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"InternalIndoubt","d":9012708,"h":21483849188,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2721252},{"n":"e","p":47251457}],"n":"InDoubt","d":9012708,"h":25778816484,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":9012708,"h":30073783780,"f":1}],"h":9012708}; }
            static get $b() { return $.$stl.System.Transactions.VolatileEnlistmentState; }
            static get $fullName() { return `System.Transactions.VolatileEnlistmentEnded`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateVolatilePhase1", ($self) => class TransactionStateVolatilePhase1 extends $.$stl.System.Transactions.ActiveStates
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                $.$spc.System.Diagnostics.Debug.Assert$1(tx._committableTransaction !== null, "tx._committableTransaction != null");
                tx._committableTransaction._complete = true;
                if (tx._phase1Volatiles._dependentClones !== 0)
                {
                    $.$stl.System.Transactions.TransactionState.TransactionStateAborted.EnterState(tx);
                    return;
                }
                if (tx._phase1Volatiles._volatileEnlistmentCount === 1 && tx._durableEnlistment === null && $.$spc.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, 0).SinglePhaseNotification !== null)
                {
                    $.$stl.System.Transactions.TransactionState.TransactionStateVolatileSPC.EnterState(tx);
                }
                else if (tx._phase1Volatiles._volatileEnlistmentCount > 0)
                {
                    for(/*int*/ let i = 0; i < tx._phase1Volatiles._volatileEnlistmentCount; i++)
                    {
                        $.$spc.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i)._twoPhaseState.ChangeStatePreparing($.$spc.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i));
                        if (!tx.State.ContinuePhase1Prepares())
                        {
                            break;
                        }
                    }
                }
                else 
                {
                    $.$stl.System.Transactions.TransactionState.TransactionStateSPC.EnterState(tx);
                }
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                this.ChangeStateTransactionAborted(tx, e);
            }
            /*void */ ChangeStateTransactionAborted(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                tx._innerException ??= e;
                $.$stl.System.Transactions.TransactionState.TransactionStateAborted.EnterState(tx);
            }
            /*void */ Phase1VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStateSPC.EnterState(tx);
            }
            /*bool */ ContinuePhase1Prepares()
            {
                return true;
            }
            /*void */ Timeout(/*InternalTransaction*/ tx)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionTimeout(tx.TransactionTraceId);
                }
                /*TimeoutException*/ let e = new $.$spc.System.TimeoutException().$ctor$10($.$stl.System.SR.TraceTransactionTimeout);
                this.Rollback(tx, e);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 8291812;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":230884,"m":[{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"EnterState","d":8291812,"h":4303259108,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"e","p":47251457}],"n":"Rollback","d":8291812,"h":8598226404,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"e","p":47251457}],"n":"ChangeStateTransactionAborted","d":8291812,"h":12893193700,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"Phase1VolatilePrepareDone","d":8291812,"h":17188160996,"f":32776},{"r":262145,"n":"ContinuePhase1Prepares","d":8291812,"h":21483128292,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"Timeout","d":8291812,"h":25778095588,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":8291812,"h":30073062884,"f":1}],"h":8291812}; }
            static get $b() { return $.$stl.System.Transactions.ActiveStates; }
            static get $fullName() { return `System.Transactions.TransactionStateVolatilePhase1`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateVolatileSPC", ($self) => class TransactionStateVolatileSPC extends $.$stl.System.Transactions.ActiveStates
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                $.$spc.System.Diagnostics.Debug.Assert$1(tx._phase1Volatiles._volatileEnlistmentCount === 1, "There must be exactly 1 phase 1 volatile enlistment for TransactionStateVolatileSPC");
                $.$spc.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, 0)._twoPhaseState.ChangeStateSinglePhaseCommit($.$spc.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, 0));
            }
            /*void */ ChangeStateTransactionCommitted(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStateCommitted.EnterState(tx);
            }
            /*void */ InDoubtFromEnlistment(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStateInDoubt.EnterState(tx);
            }
            /*void */ ChangeStateTransactionAborted(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                tx._innerException ??= e;
                $.$stl.System.Transactions.TransactionState.TransactionStateAborted.EnterState(tx);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 8357348;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":230884,"m":[{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"EnterState","d":8357348,"h":4303324644,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"ChangeStateTransactionCommitted","d":8357348,"h":8598291940,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"InDoubtFromEnlistment","d":8357348,"h":12893259236,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"e","p":47251457}],"n":"ChangeStateTransactionAborted","d":8357348,"h":17188226532,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":8357348,"h":21483193828,"f":1}],"h":8357348}; }
            static get $b() { return $.$stl.System.Transactions.ActiveStates; }
            static get $fullName() { return `System.Transactions.TransactionStateVolatileSPC`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateSPC", ($self) => class TransactionStateSPC extends $.$stl.System.Transactions.ActiveStates
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                if (tx._durableEnlistment !== null)
                {
                    tx._durableEnlistment.State.ChangeStateCommitting(tx._durableEnlistment);
                }
                else 
                {
                    $.$stl.System.Transactions.TransactionState.TransactionStateCommitted.EnterState(tx);
                }
            }
            /*void */ ChangeStateTransactionCommitted(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStateCommitted.EnterState(tx);
            }
            /*void */ InDoubtFromEnlistment(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStateInDoubt.EnterState(tx);
            }
            /*void */ ChangeStateTransactionAborted(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                tx._innerException ??= e;
                $.$stl.System.Transactions.TransactionState.TransactionStateAborted.EnterState(tx);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 8160740;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":230884,"m":[{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"EnterState","d":8160740,"h":4303128036,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"ChangeStateTransactionCommitted","d":8160740,"h":8598095332,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"InDoubtFromEnlistment","d":8160740,"h":12893062628,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"e","p":47251457}],"n":"ChangeStateTransactionAborted","d":8160740,"h":17188029924,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":8160740,"h":21482997220,"f":1}],"h":8160740}; }
            static get $b() { return $.$stl.System.Transactions.ActiveStates; }
            static get $fullName() { return `System.Transactions.TransactionStateSPC`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateAborted", ($self) => class TransactionStateAborted extends $.$stl.System.Transactions.TransactionStateEnded
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                super.EnterState(tx);
                this.CommonEnterState(tx);
                for(/*int*/ let i = 0; i < tx._phase0Volatiles._volatileEnlistmentCount; i++)
                {
                    $.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i)._twoPhaseState.InternalAborted($.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i));
                }
                for(/*int*/ let i = 0; i < tx._phase1Volatiles._volatileEnlistmentCount; i++)
                {
                    $.$spc.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i)._twoPhaseState.InternalAborted($.$spc.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i));
                }
                tx._durableEnlistment?.State.InternalAborted(tx._durableEnlistment);
                $.$stl.System.Transactions.TransactionTable.Remove(tx);
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionTimeout(tx.TransactionTraceId);
                }
                tx.FireCompletion();
                if (tx._asyncCommit)
                {
                    tx.SignalAsyncCompletion();
                }
            }
            /*TransactionStatus */ get_Status(/*InternalTransaction*/ tx)
            {
                return 2/*TransactionStatus.Aborted*/;
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
            }
            /*void */ BeginCommit(/*InternalTransaction*/ tx, /*bool*/ asyncCommit, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw $.$stl.System.Transactions.TransactionStateAborted.CreateTransactionAbortedException(tx);
            }
            /*void */ EndCommit(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionStateAborted.CreateTransactionAbortedException(tx);
            }
            /*void */ RestartCommitIfNeeded(/*InternalTransaction*/ tx)
            {
            }
            /*void */ Timeout(/*InternalTransaction*/ tx)
            {
            }
            /*void */ Phase0VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ Phase1VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ ChangeStateTransactionAborted(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
            }
            /*void */ ChangeStatePromotedAborted(/*InternalTransaction*/ tx)
            {
            }
            /*void */ ChangeStateAbortedDuringPromotion(/*InternalTransaction*/ tx)
            {
            }
            /*void */ CreateBlockingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionStateAborted.CreateTransactionAbortedException(tx);
            }
            /*void */ CreateAbortingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionStateAborted.CreateTransactionAbortedException(tx);
            }
            /*void */ GetObjectData(/*InternalTransaction*/ tx, /*SerializationInfo*/ serializationInfo, /*StreamingContext*/ context)
            {
                throw $.$stl.System.Transactions.TransactionStateAborted.CreateTransactionAbortedException(tx);
            }
            /*void */ CheckForFinishedTransaction(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionStateAborted.CreateTransactionAbortedException(tx);
            }
            static /*TransactionAbortedException */ CreateTransactionAbortedException(/*InternalTransaction*/ tx)
            {
                return $.$stl.System.Transactions.TransactionAbortedException.Create$3($.$stl.System.SR.TransactionAborted, tx._innerException, tx.DistributedTxId);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 5801444;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6456804,"m":[{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"EnterState","d":5801444,"h":4300768740,"f":32776},{"r":8422884,"p":[{"n":"tx","p":2786788}],"n":"get_Status","d":5801444,"h":8595736036,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"e","p":47251457}],"n":"Rollback","d":5801444,"h":12890703332,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"asyncCommit","p":262145},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":5801444,"h":17185670628,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"EndCommit","d":5801444,"h":21480637924,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"RestartCommitIfNeeded","d":5801444,"h":25775605220,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"Timeout","d":5801444,"h":30070572516,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"Phase0VolatilePrepareDone","d":5801444,"h":34365539812,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"Phase1VolatilePrepareDone","d":5801444,"h":38660507108,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"e","p":47251457}],"n":"ChangeStateTransactionAborted","d":5801444,"h":42955474404,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"ChangeStatePromotedAborted","d":5801444,"h":47250441700,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"ChangeStateAbortedDuringPromotion","d":5801444,"h":51545408996,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"CreateBlockingClone","d":5801444,"h":55840376292,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"CreateAbortingClone","d":5801444,"h":60135343588,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"serializationInfo","p":113967105},{"n":"context","p":114098177}],"n":"GetObjectData","d":5801444,"h":64430310884,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"CheckForFinishedTransaction","d":5801444,"h":68725278180,"f":32776},{"r":4359652,"p":[{"n":"tx","p":2786788}],"n":"CreateTransactionAbortedException","d":5801444,"h":73020245476,"f":34}],"c":[{"n":".ctor","o":"$ctor$3","d":5801444,"h":77315212772,"f":1}],"h":5801444}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStateEnded; }
            static get $fullName() { return `System.Transactions.TransactionStateAborted`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateCommitted", ($self) => class TransactionStateCommitted extends $.$stl.System.Transactions.TransactionStateEnded
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                super.EnterState(tx);
                this.CommonEnterState(tx);
                for(/*int*/ let i = 0; i < tx._phase0Volatiles._volatileEnlistmentCount; i++)
                {
                    $.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i)._twoPhaseState.InternalCommitted($.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i));
                }
                for(/*int*/ let i = 0; i < tx._phase1Volatiles._volatileEnlistmentCount; i++)
                {
                    $.$spc.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i)._twoPhaseState.InternalCommitted($.$spc.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i));
                }
                $.$stl.System.Transactions.TransactionTable.Remove(tx);
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionCommitted(1/*TraceSourceType.TraceSourceLtm*/, tx.TransactionTraceId);
                }
                tx.FireCompletion();
                if (tx._asyncCommit)
                {
                    tx.SignalAsyncCompletion();
                }
            }
            /*TransactionStatus */ get_Status(/*InternalTransaction*/ tx)
            {
                return 1/*TransactionStatus.Committed*/;
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ EndCommit(/*InternalTransaction*/ tx)
            {
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 5932516;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6456804,"m":[{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"EnterState","d":5932516,"h":4300899812,"f":32776},{"r":8422884,"p":[{"n":"tx","p":2786788}],"n":"get_Status","d":5932516,"h":8595867108,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"e","p":47251457}],"n":"Rollback","d":5932516,"h":12890834404,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"EndCommit","d":5932516,"h":17185801700,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":5932516,"h":21480768996,"f":1}],"h":5932516}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStateEnded; }
            static get $fullName() { return `System.Transactions.TransactionStateCommitted`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateInDoubt", ($self) => class TransactionStateInDoubt extends $.$stl.System.Transactions.TransactionStateEnded
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                super.EnterState(tx);
                this.CommonEnterState(tx);
                for(/*int*/ let i = 0; i < tx._phase0Volatiles._volatileEnlistmentCount; i++)
                {
                    $.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i)._twoPhaseState.InternalIndoubt($.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i));
                }
                for(/*int*/ let i = 0; i < tx._phase1Volatiles._volatileEnlistmentCount; i++)
                {
                    $.$spc.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i)._twoPhaseState.InternalIndoubt($.$spc.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i));
                }
                $.$stl.System.Transactions.TransactionTable.Remove(tx);
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionInDoubt(1/*TraceSourceType.TraceSourceLtm*/, tx.TransactionTraceId);
                }
                tx.FireCompletion();
                if (tx._asyncCommit)
                {
                    tx.SignalAsyncCompletion();
                }
            }
            /*TransactionStatus */ get_Status(/*InternalTransaction*/ tx)
            {
                return 3/*TransactionStatus.InDoubt*/;
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ EndCommit(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionInDoubtException.Create$3(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionIndoubt, tx._innerException, tx.DistributedTxId);
            }
            /*void */ CheckForFinishedTransaction(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionInDoubtException.Create$3(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionIndoubt, tx._innerException, tx.DistributedTxId);
            }
            /*void */ GetObjectData(/*InternalTransaction*/ tx, /*SerializationInfo*/ serializationInfo, /*StreamingContext*/ context)
            {
                throw $.$stl.System.Transactions.TransactionInDoubtException.Create$3(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionIndoubt, tx._innerException, tx.DistributedTxId);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 6522340;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6456804,"m":[{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"EnterState","d":6522340,"h":4301489636,"f":32776},{"r":8422884,"p":[{"n":"tx","p":2786788}],"n":"get_Status","d":6522340,"h":8596456932,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"e","p":47251457}],"n":"Rollback","d":6522340,"h":12891424228,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"EndCommit","d":6522340,"h":17186391524,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"CheckForFinishedTransaction","d":6522340,"h":21481358820,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"serializationInfo","p":113967105},{"n":"context","p":114098177}],"n":"GetObjectData","d":6522340,"h":25776326116,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":6522340,"h":30071293412,"f":1}],"h":6522340}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStateEnded; }
            static get $fullName() { return `System.Transactions.TransactionStateInDoubt`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateNonCommittablePromoted", ($self) => class TransactionStateNonCommittablePromoted extends $.$stl.System.Transactions.TransactionStatePromotedBase
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                $.$spc.System.Diagnostics.Debug.Assert$1(tx.PromotedTransaction !== null && tx.PromotedTransaction.RealTransaction !== null, "tx.PromotedTransaction != null && tx.PromotedTransaction.RealTransaction != null");
                tx.PromotedTransaction.RealTransaction.InternalTransaction = tx;
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 6587876;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6915556,"m":[{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"EnterState","d":6587876,"h":4301555172,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":6587876,"h":8596522468,"f":1}],"h":6587876}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedBase; }
            static get $fullName() { return `System.Transactions.TransactionStateNonCommittablePromoted`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromoted", ($self) => class TransactionStatePromoted extends $.$stl.System.Transactions.TransactionStatePromotedBase
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(($.$spc.System.Guid.op_Equality(tx._promoterType, $.$spc.System.Guid.Empty)) || ($.$spc.System.Guid.op_Equality(tx._promoterType, $.$stl.System.Transactions.TransactionInterop.PromoterTypeDtc)), "Promoted to MSTC but PromoterType is not TransactionInterop.PromoterTypeDtc");
                tx.SetPromoterTypeToMSDTC();
                if (tx._outcomeSource._isoLevel === 4/*IsolationLevel.Snapshot*/)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.CannotPromoteSnapshot, null);
                }
                this.CommonEnterState(tx);
                /*OletxCommittableTransaction?*/ let distributedTx = null;
                try
                {
                    /*TimeSpan*/ let newTimeout;
                    if (tx.AbsoluteTimeout === 9223372036854775807n)
                    {
                        newTimeout = $.$spc.System.TimeSpan.Zero;
                    }
                    else 
                    {
                        newTimeout = $.$stl.System.Transactions.TransactionManager.TransactionTable.RecalcTimeout(tx);
                        if ($.$spc.System.TimeSpan.op_LessThanOrEqual(newTimeout, $.$spc.System.TimeSpan.Zero))
                        {
                            return;
                        }
                    }
                    /*TransactionOptions*/ let options = new $.$stl.System.Transactions.TransactionOptions();
                    options.IsolationLevel = tx._outcomeSource._isoLevel;
                    options.Timeout = newTimeout;
                    distributedTx = $.$stl.System.Transactions.TransactionManager.DistributedTransactionManager.CreateTransaction(options.Clone());
                    distributedTx.SavedLtmPromotedTransaction = tx._outcomeSource;
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.TransactionPromoted(tx.TransactionTraceId, distributedTx.TransactionTraceId);
                    }
                }
                catch(te)
                {
                    tx._innerException = te;
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.ExceptionConsumed$1(te);
                    }
                    return;
                }
                finally
                {
                    {
                        if (distributedTx === null)
                        {
                            tx.State.ChangeStateAbortedDuringPromotion(tx);
                        }
                    }
                }
                tx.PromotedTransaction = distributedTx;
                /*Hashtable*/ let promotedTransactionTable = $.$stl.System.Transactions.TransactionManager.PromotedTransactionTable;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(promotedTransactionTable)
                    {
                        tx._finalizedObject = new $.$stl.System.Transactions.FinalizedObject().$ctor$1(tx, distributedTx.Identifier);
                        /*WeakReference*/ let weakRef = new $.$spc.System.WeakReference().$ctor$2(tx._outcomeSource, false);
                        promotedTransactionTable.set_Item(distributedTx.Identifier, weakRef);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(promotedTransactionTable)
                }
                $.$stl.System.Transactions.TransactionManager.FireDistributedTransactionStarted(tx._outcomeSource);
                this.PromoteEnlistmentsAndOutcome(tx);
            }
            static /*bool */ PromotePhaseVolatiles(/*InternalTransaction*/ tx, /*ref VolatileEnlistmentSet*/ volatiles, /*bool*/ phase0)
            {
                if (((volatiles.$v._volatileEnlistmentCount + volatiles.$v._dependentClones) | 0) > 0)
                {
                    if (phase0)
                    {
                        volatiles.$v.VolatileDemux = new $.$stl.System.Transactions.Phase0VolatileDemultiplexer().$ctor$2(tx);
                    }
                    else 
                    {
                        volatiles.$v.VolatileDemux = new $.$stl.System.Transactions.Phase1VolatileDemultiplexer().$ctor$2(tx);
                    }
                    $.$spc.System.Diagnostics.Debug.Assert$1(tx.PromotedTransaction !== null, "tx.PromotedTransaction != null");
                    volatiles.$v.VolatileDemux._promotedEnlistment = tx.PromotedTransaction.EnlistVolatile$1(volatiles.$v.VolatileDemux, phase0 ? 1/*EnlistmentOptions.EnlistDuringPrepareRequired*/ : 0/*EnlistmentOptions.None*/);
                }
                return true;
            }
            /*bool */ PromoteDurable(/*InternalTransaction*/ tx)
            {
                if (tx._durableEnlistment !== null)
                {
                    /*InternalEnlistment*/ let enlistment = tx._durableEnlistment;
                    $.$spc.System.Diagnostics.Debug.Assert$1(tx.PromotedTransaction !== null, "tx.PromotedTransaction != null");
                    /*IPromotedEnlistment*/ let promotedEnlistment = tx.PromotedTransaction.EnlistDurable(enlistment.ResourceManagerIdentifier, $.$cast(enlistment, $.$stl.System.Transactions.DurableInternalEnlistment), enlistment.SinglePhaseNotification !== null, 0/*EnlistmentOptions.None*/);
                    tx._durableEnlistment.State.ChangeStatePromoted(tx._durableEnlistment, promotedEnlistment);
                }
                return true;
            }
            /*void */ PromoteEnlistmentsAndOutcome(/*InternalTransaction*/ tx)
            {
                /*bool*/ let enlistmentsPromoted = false;
                $.$spc.System.Diagnostics.Debug.Assert$1(tx.PromotedTransaction !== null && tx.PromotedTransaction.RealTransaction !== null, "tx.PromotedTransaction != null && tx.PromotedTransaction.RealTransaction != null");
                tx.PromotedTransaction.RealTransaction.InternalTransaction = tx;
                $.$spc.System.Diagnostics.Debug.Assert$1(tx.State !== null, "tx.State != null");
                try
                {
                    enlistmentsPromoted = $.$stl.System.Transactions.TransactionStatePromoted.PromotePhaseVolatiles(tx, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase0Volatiles, ($v) => tx._phase0Volatiles = $v, null), true);
                }
                catch(te)
                {
                    tx._innerException = te;
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.ExceptionConsumed$1(te);
                    }
                    return;
                }
                finally
                {
                    {
                        if (!enlistmentsPromoted)
                        {
                            tx.PromotedTransaction.Rollback();
                            tx.State.ChangeStateAbortedDuringPromotion(tx);
                        }
                    }
                }
                enlistmentsPromoted = false;
                try
                {
                    enlistmentsPromoted = $.$stl.System.Transactions.TransactionStatePromoted.PromotePhaseVolatiles(tx, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase1Volatiles, ($v) => tx._phase1Volatiles = $v, null), false);
                }
                catch(te)
                {
                    tx._innerException = te;
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.ExceptionConsumed$1(te);
                    }
                    return;
                }
                finally
                {
                    {
                        if (!enlistmentsPromoted)
                        {
                            tx.PromotedTransaction.Rollback();
                            tx.State.ChangeStateAbortedDuringPromotion(tx);
                        }
                    }
                }
                enlistmentsPromoted = false;
                try
                {
                    enlistmentsPromoted = this.PromoteDurable(tx);
                }
                catch(te)
                {
                    tx._innerException = te;
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.ExceptionConsumed$1(te);
                    }
                    return;
                }
                finally
                {
                    {
                        if (!enlistmentsPromoted)
                        {
                            tx.PromotedTransaction.Rollback();
                            tx.State.ChangeStateAbortedDuringPromotion(tx);
                        }
                    }
                }
            }
            /*void */ DisposeRoot(/*InternalTransaction*/ tx)
            {
                tx.State.Rollback(tx, null);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 6718948;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6915556,"m":[{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"EnterState","d":6718948,"h":4301686244,"f":32776},{"r":262145,"p":[{"n":"tx","p":2786788},{"n":"volatiles","p":9340388,"f":4},{"n":"phase0","p":262145}],"n":"PromotePhaseVolatiles","d":6718948,"h":8596653540,"f":36},{"r":262145,"p":[{"n":"tx","p":2786788}],"n":"PromoteDurable","d":6718948,"h":12891620836,"f":136},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"PromoteEnlistmentsAndOutcome","d":6718948,"h":17186588132,"f":136},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"DisposeRoot","d":6718948,"h":21481555428,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":6718948,"h":25776522724,"f":1}],"h":6718948}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedBase; }
            static get $fullName() { return `System.Transactions.TransactionStatePromoted`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedP0Wave", ($self) => class TransactionStatePromotedP0Wave extends $.$stl.System.Transactions.TransactionStatePromotedBase
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
            }
            /*void */ BeginCommit(/*InternalTransaction*/ tx, /*bool*/ asyncCommit, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ Phase0VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
                try
                {
                    $.$stl.System.Transactions.TransactionState.TransactionStatePromotedCommitting.EnterState(tx);
                }
                catch(e)
                {
                    tx._innerException ??= e;
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.ExceptionConsumed$1(e);
                    }
                }
            }
            /*bool */ ContinuePhase0Prepares()
            {
                return true;
            }
            /*void */ ChangeStateTransactionAborted(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                tx._innerException ??= e;
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedP0Aborting.EnterState(tx);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 7833060;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6915556,"m":[{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"EnterState","d":7833060,"h":4302800356,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"asyncCommit","p":262145},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":7833060,"h":8597767652,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"Phase0VolatilePrepareDone","d":7833060,"h":12892734948,"f":32776},{"r":262145,"n":"ContinuePhase0Prepares","d":7833060,"h":17187702244,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"e","p":47251457}],"n":"ChangeStateTransactionAborted","d":7833060,"h":21482669540,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":7833060,"h":25777636836,"f":1}],"h":7833060}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedBase; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedP0Wave`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedCommitting", ($self) => class TransactionStatePromotedCommitting extends $.$stl.System.Transactions.TransactionStatePromotedBase
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                /*OletxCommittableTransaction*/ let ctx = $.$cast(tx.PromotedTransaction, $.$stl.System.Transactions.Oletx.OletxCommittableTransaction);
                ctx.BeginCommit(tx);
            }
            /*void */ BeginCommit(/*InternalTransaction*/ tx, /*bool*/ asyncCommit, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ ChangeStatePromotedPhase0(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedPhase0.EnterState(tx);
            }
            /*void */ ChangeStatePromotedPhase1(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedPhase1.EnterState(tx);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 7046628;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6915556,"m":[{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"EnterState","d":7046628,"h":4302013924,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"asyncCommit","p":262145},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":7046628,"h":8596981220,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"ChangeStatePromotedPhase0","d":7046628,"h":12891948516,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"ChangeStatePromotedPhase1","d":7046628,"h":17186915812,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":7046628,"h":21481883108,"f":1}],"h":7046628}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedBase; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedCommitting`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedNonMSDTCPhase0", ($self) => class TransactionStatePromotedNonMSDTCPhase0 extends $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCBase
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                /*int*/ let volatileCount = tx._phase0Volatiles._volatileEnlistmentCount;
                /*int*/ let dependentCount = tx._phase0Volatiles._dependentClones;
                tx._phase0VolatileWaveCount = volatileCount;
                if (tx._phase0Volatiles._preparedVolatileEnlistments < ((volatileCount + dependentCount) | 0))
                {
                    for(/*int*/ let i = 0; i < volatileCount; i++)
                    {
                        $.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i)._twoPhaseState.ChangeStatePreparing($.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i));
                        if (!tx.State.ContinuePhase0Prepares())
                        {
                            break;
                        }
                    }
                }
                else 
                {
                    $.$stl.System.Transactions.TransactionState.TransactionStatePromotedNonMSDTCVolatilePhase1.EnterState(tx);
                }
            }
            /*void */ BeginCommit(/*InternalTransaction*/ tx, /*bool*/ asyncCommit, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                this.ChangeStateTransactionAborted(tx, e);
            }
            /*void */ Phase0VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
                /*int*/ let volatileCount = tx._phase0Volatiles._volatileEnlistmentCount;
                /*int*/ let dependentCount = tx._phase0Volatiles._dependentClones;
                tx._phase0VolatileWaveCount = volatileCount;
                if (tx._phase0Volatiles._preparedVolatileEnlistments < ((volatileCount + dependentCount) | 0))
                {
                    for(/*int*/ let i = 0; i < volatileCount; i++)
                    {
                        $.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i)._twoPhaseState.ChangeStatePreparing($.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i));
                        if (!tx.State.ContinuePhase0Prepares())
                        {
                            break;
                        }
                    }
                }
                else 
                {
                    $.$stl.System.Transactions.TransactionState.TransactionStatePromotedNonMSDTCVolatilePhase1.EnterState(tx);
                }
            }
            /*void */ Phase1VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            /*bool */ ContinuePhase0Prepares()
            {
                return true;
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 7570916;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7308772,"m":[{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"EnterState","d":7570916,"h":4302538212,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"asyncCommit","p":262145},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":7570916,"h":8597505508,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"e","p":47251457}],"n":"Rollback","d":7570916,"h":12892472804,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"Phase0VolatilePrepareDone","d":7570916,"h":17187440100,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"Phase1VolatilePrepareDone","d":7570916,"h":21482407396,"f":32776},{"r":262145,"n":"ContinuePhase0Prepares","d":7570916,"h":25777374692,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":7570916,"h":30072341988,"f":1}],"h":7570916}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCBase; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedNonMSDTCPhase0`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedNonMSDTCVolatilePhase1", ($self) => class TransactionStatePromotedNonMSDTCVolatilePhase1 extends $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCBase
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                $.$spc.System.Diagnostics.Debug.Assert$1(tx._committableTransaction !== null, "tx._committableTransaction != null");
                tx._committableTransaction._complete = true;
                if (tx._phase1Volatiles._dependentClones !== 0)
                {
                    this.ChangeStateTransactionAborted(tx, null);
                    return;
                }
                if (tx._phase1Volatiles._volatileEnlistmentCount > 0)
                {
                    for(/*int*/ let i = 0; i < tx._phase1Volatiles._volatileEnlistmentCount; i++)
                    {
                        $.$spc.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i)._twoPhaseState.ChangeStatePreparing($.$spc.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i));
                        if (!tx.State.ContinuePhase1Prepares())
                        {
                            break;
                        }
                    }
                }
                else 
                {
                    $.$stl.System.Transactions.TransactionState.TransactionStatePromotedNonMSDTCSinglePhaseCommit.EnterState(tx);
                }
            }
            /*void */ BeginCommit(/*InternalTransaction*/ tx, /*bool*/ asyncCommit, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                this.ChangeStateTransactionAborted(tx, e);
            }
            /*void */ Phase1VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedNonMSDTCSinglePhaseCommit.EnterState(tx);
            }
            /*bool */ ContinuePhase1Prepares()
            {
                return true;
            }
            /*Enlistment */ EnlistVolatile(/*InternalTransaction*/ tx, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                throw $.$stl.System.Transactions.TransactionException.Create$1($.$stl.System.SR.TooLate, tx === null ? $.$spc.System.Guid.Empty : tx.DistributedTxId);
            }
            /*Enlistment */ EnlistVolatile$1(/*InternalTransaction*/ tx, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                throw $.$stl.System.Transactions.TransactionException.Create$1($.$stl.System.SR.TooLate, tx === null ? $.$spc.System.Guid.Empty : tx.DistributedTxId);
            }
            /*bool */ EnlistPromotableSinglePhase(/*InternalTransaction*/ tx, /*IPromotableSinglePhaseNotification*/ promotableSinglePhaseNotification, /*Transaction*/ atomicTransaction, /*Guid*/ promoterType)
            {
                throw $.$stl.System.Transactions.TransactionException.Create$1($.$stl.System.SR.TooLate, tx === null ? $.$spc.System.Guid.Empty : tx.DistributedTxId);
            }
            /*void */ CreateBlockingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.Create$1($.$stl.System.SR.TooLate, tx === null ? $.$spc.System.Guid.Empty : tx.DistributedTxId);
            }
            /*void */ CreateAbortingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.Create$1($.$stl.System.SR.TooLate, tx === null ? $.$spc.System.Guid.Empty : tx.DistributedTxId);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 7701988;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7308772,"m":[{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"EnterState","d":7701988,"h":4302669284,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"asyncCommit","p":262145},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":7701988,"h":8597636580,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"e","p":47251457}],"n":"Rollback","d":7701988,"h":12892603876,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"Phase1VolatilePrepareDone","d":7701988,"h":17187571172,"f":32776},{"r":262145,"n":"ContinuePhase1Prepares","d":7701988,"h":21482538468,"f":32776},{"r":1738212,"p":[{"n":"tx","p":2786788},{"n":"enlistmentNotification","p":2590180},{"n":"enlistmentOptions","p":1869284},{"n":"atomicTransaction","p":4294116}],"n":"EnlistVolatile","d":7701988,"h":25777505764,"f":32776},{"r":1738212,"p":[{"n":"tx","p":2786788},{"n":"enlistmentNotification","p":3048932},{"n":"enlistmentOptions","p":1869284},{"n":"atomicTransaction","p":4294116}],"n":"EnlistVolatile","o":"@$1","d":7701988,"h":30072473060,"f":32776},{"r":262145,"p":[{"n":"tx","p":2786788},{"n":"promotableSinglePhaseNotification","p":2852324},{"n":"atomicTransaction","p":4294116},{"n":"promoterType","p":56229889}],"n":"EnlistPromotableSinglePhase","d":7701988,"h":34367440356,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"CreateBlockingClone","d":7701988,"h":38662407652,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"CreateAbortingClone","d":7701988,"h":42957374948,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":7701988,"h":47252342244,"f":1}],"h":7701988}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCBase; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedNonMSDTCVolatilePhase1`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedNonMSDTCSinglePhaseCommit", ($self) => class TransactionStatePromotedNonMSDTCSinglePhaseCommit extends $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCBase
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                $.$spc.System.Diagnostics.Debug.Assert$1(tx._durableEnlistment !== null, "tx._durableEnlistment != null");
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.EnlistmentStatus(1/*TraceSourceType.TraceSourceLtm*/, tx._durableEnlistment.EnlistmentTraceId, 4/*NotificationCall.SinglePhaseCommit*/);
                }
                $.$stl.System.Transactions.TransactionTable.Remove(tx);
                tx._durableEnlistment.State.ChangeStateCommitting(tx._durableEnlistment);
            }
            /*void */ BeginCommit(/*InternalTransaction*/ tx, /*bool*/ asyncCommit, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ ChangeStateTransactionCommitted(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedNonMSDTCCommitted.EnterState(tx);
            }
            /*void */ InDoubtFromEnlistment(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedNonMSDTCIndoubt.EnterState(tx);
            }
            /*void */ ChangeStateTransactionAborted(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                tx._innerException ??= e;
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedNonMSDTCAborted.EnterState(tx);
            }
            /*void */ ChangeStateAbortedDuringPromotion(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStateAborted.EnterState(tx);
            }
            /*Enlistment */ EnlistVolatile(/*InternalTransaction*/ tx, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                throw $.$stl.System.Transactions.TransactionException.Create$1($.$stl.System.SR.TooLate, tx === null ? $.$spc.System.Guid.Empty : tx.DistributedTxId);
            }
            /*Enlistment */ EnlistVolatile$1(/*InternalTransaction*/ tx, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                throw $.$stl.System.Transactions.TransactionException.Create$1($.$stl.System.SR.TooLate, tx === null ? $.$spc.System.Guid.Empty : tx.DistributedTxId);
            }
            /*bool */ EnlistPromotableSinglePhase(/*InternalTransaction*/ tx, /*IPromotableSinglePhaseNotification*/ promotableSinglePhaseNotification, /*Transaction*/ atomicTransaction, /*Guid*/ promoterType)
            {
                throw $.$stl.System.Transactions.TransactionException.Create$1($.$stl.System.SR.TooLate, tx === null ? $.$spc.System.Guid.Empty : tx.DistributedTxId);
            }
            /*void */ CreateBlockingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.Create$1($.$stl.System.SR.TooLate, tx === null ? $.$spc.System.Guid.Empty : tx.DistributedTxId);
            }
            /*void */ CreateAbortingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.Create$1($.$stl.System.SR.TooLate, tx === null ? $.$spc.System.Guid.Empty : tx.DistributedTxId);
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 7636452;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7308772,"m":[{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"EnterState","d":7636452,"h":4302603748,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"asyncCommit","p":262145},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":7636452,"h":8597571044,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"e","p":47251457}],"n":"Rollback","d":7636452,"h":12892538340,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"ChangeStateTransactionCommitted","d":7636452,"h":17187505636,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"InDoubtFromEnlistment","d":7636452,"h":21482472932,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"e","p":47251457}],"n":"ChangeStateTransactionAborted","d":7636452,"h":25777440228,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"ChangeStateAbortedDuringPromotion","d":7636452,"h":30072407524,"f":32776},{"r":1738212,"p":[{"n":"tx","p":2786788},{"n":"enlistmentNotification","p":2590180},{"n":"enlistmentOptions","p":1869284},{"n":"atomicTransaction","p":4294116}],"n":"EnlistVolatile","d":7636452,"h":34367374820,"f":32776},{"r":1738212,"p":[{"n":"tx","p":2786788},{"n":"enlistmentNotification","p":3048932},{"n":"enlistmentOptions","p":1869284},{"n":"atomicTransaction","p":4294116}],"n":"EnlistVolatile","o":"@$1","d":7636452,"h":38662342116,"f":32776},{"r":262145,"p":[{"n":"tx","p":2786788},{"n":"promotableSinglePhaseNotification","p":2852324},{"n":"atomicTransaction","p":4294116},{"n":"promoterType","p":56229889}],"n":"EnlistPromotableSinglePhase","d":7636452,"h":42957309412,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"CreateBlockingClone","d":7636452,"h":47252276708,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"CreateAbortingClone","d":7636452,"h":51547244004,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":7636452,"h":55842211300,"f":1}],"h":7636452}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCBase; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedNonMSDTCSinglePhaseCommit`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateDelegatedNonMSDTC", ($self) => class TransactionStateDelegatedNonMSDTC extends $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCBase
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                /*OletxTransaction?*/ let distributedTx;
                try
                {
                    if (tx._durableEnlistment !== null)
                    {
                        /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                        if (etwLog.IsEnabled())
                        {
                            etwLog.EnlistmentStatus(1/*TraceSourceType.TraceSourceLtm*/, tx._durableEnlistment.EnlistmentTraceId, 5/*NotificationCall.Promote*/);
                        }
                    }
                    distributedTx = $.$stl.System.Transactions.TransactionState.TransactionStatePSPEOperation.PSPEPromote(tx);
                    $.$spc.System.Diagnostics.Debug.Assert$1((distributedTx === null), "PSPEPromote for non-MSDTC promotion returned a distributed transaction.");
                    $.$spc.System.Diagnostics.Debug.Assert$1((tx.promotedToken !== null), "PSPEPromote for non-MSDTC promotion did not set InternalTransaction.PromotedToken.");
                }
                catch(e)
                {
                    tx._innerException = e;
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.ExceptionConsumed$1(e);
                    }
                }
                finally
                {
                    {
                        if (tx.promotedToken === null)
                        {
                            tx.State.ChangeStateAbortedDuringPromotion(tx);
                        }
                    }
                }
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 6260196;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7308772,"m":[{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"EnterState","d":6260196,"h":4301227492,"f":32776}],"c":[{"n":".ctor","o":"$ctor$3","d":6260196,"h":8596194788,"f":1}],"h":6260196}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCBase; }
            static get $fullName() { return `System.Transactions.TransactionStateDelegatedNonMSDTC`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionCompletedEventHandler", ($self) => class TransactionCompletedEventHandler extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*void*/ Invoke(/*$.$spc.System.Nullable$$*/ sender, /**/ e)
            {
                return this.$nativeFunction.call(this.$target, sender, e);
            }
            static $h = 4425188;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":4490724}],"n":"Invoke","d":4425188,"h":8594359780,"f":129},{"r":57016321,"p":[{"n":"sender","p":131073},{"n":"e","p":4490724},{"n":"callback","p":14483457},{"n":"object","p":131073}],"n":"BeginInvoke","d":4425188,"h":12889327076,"f":129},{"r":65537,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":4425188,"h":17184294372,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":4425188,"h":4299392484,"f":1}],"i":[57212929,113377281],"h":4425188}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Transactions.TransactionCompletedEventHandler`; }
        });
        
        $asm.$cls("$stl.System.Transactions.FinishVolatileDelegate", ($self) => class FinishVolatileDelegate extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*void*/ Invoke(/**/ enlistment)
            {
                return this.$nativeFunction.call(this.$target, enlistment);
            }
            static $h = 2393572;
            static $f = 0b10000000;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"Invoke","d":2393572,"h":8592328164,"f":129},{"r":57016321,"p":[{"n":"enlistment","p":2721252},{"n":"callback","p":14483457},{"n":"object","p":131073}],"n":"BeginInvoke","d":2393572,"h":12887295460,"f":129},{"r":65537,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":2393572,"h":17182262756,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":2393572,"h":4297360868,"f":1}],"i":[57212929,113377281],"h":2393572}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Transactions.FinishVolatileDelegate`; }
        });
        
        $asm.$cls("$stl.System.Transactions.HostCurrentTransactionCallback", ($self) => class HostCurrentTransactionCallback extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*Transaction?*/ Invoke()
            {
                return this.$nativeFunction.call(this.$target, );
            }
            static $h = 2459108;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":4294116,"n":"Invoke","d":2459108,"h":8592393700,"f":129},{"r":57016321,"p":[{"n":"callback","p":14483457},{"n":"object","p":131073}],"n":"BeginInvoke","d":2459108,"h":12887360996,"f":129},{"r":4294116,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":2459108,"h":17182328292,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":2459108,"h":4297426404,"f":1}],"i":[57212929,113377281],"h":2459108}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Transactions.HostCurrentTransactionCallback`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStartedEventHandler", ($self) => class TransactionStartedEventHandler extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*void*/ Invoke(/*$.$spc.System.Nullable$$*/ sender, /**/ e)
            {
                return this.$nativeFunction.call(this.$target, sender, e);
            }
            static $h = 5670372;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":4490724}],"n":"Invoke","d":5670372,"h":8595604964,"f":129},{"r":57016321,"p":[{"n":"sender","p":131073},{"n":"e","p":4490724},{"n":"callback","p":14483457},{"n":"object","p":131073}],"n":"BeginInvoke","d":5670372,"h":12890572260,"f":129},{"r":65537,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":5670372,"h":17185539556,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":5670372,"h":4300637668,"f":1}],"i":[57212929,113377281],"h":5670372}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Transactions.TransactionStartedEventHandler`; }
        });
        
        $asm.$str("$stl.System.Transactions.IsolationLevel", ($self) => class IsolationLevel extends $.$spc.System.Enum
        {
            static Serializable = 0;
            static RepeatableRead = 1;
            static ReadCommitted = 2;
            static ReadUncommitted = 3;
            static Snapshot = 4;
            static Chaos = 5;
            static Unspecified = 6;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Serializable": 0n,
                    "RepeatableRead": 1n,
                    "ReadCommitted": 2n,
                    "ReadUncommitted": 3n,
                    "Snapshot": 4n,
                    "Chaos": 5n,
                    "Unspecified": 6n
                };
            }
            static $h = 3180004;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":3180004,"n":"Serializable","d":3180004,"h":4298147300,"f":33},{"t":3180004,"n":"RepeatableRead","d":3180004,"h":8593114596,"f":33},{"t":3180004,"n":"ReadCommitted","d":3180004,"h":12888081892,"f":33},{"t":3180004,"n":"ReadUncommitted","d":3180004,"h":17183049188,"f":33},{"t":3180004,"n":"Snapshot","d":3180004,"h":21478016484,"f":33},{"t":3180004,"n":"Chaos","d":3180004,"h":25772983780,"f":33},{"t":3180004,"n":"Unspecified","d":3180004,"h":30067951076,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":3180004,"h":34362918372,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":3180004}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Transactions.IsolationLevel`; }
        });
        
        $asm.$str("$stl.System.Transactions.TransactionStatus", ($self) => class TransactionStatus extends $.$spc.System.Enum
        {
            static Active = 0;
            static Committed = 1;
            static Aborted = 2;
            static InDoubt = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Active": 0n,
                    "Committed": 1n,
                    "Aborted": 2n,
                    "InDoubt": 3n
                };
            }
            static $h = 8422884;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":8422884,"n":"Active","d":8422884,"h":4303390180,"f":33},{"t":8422884,"n":"Committed","d":8422884,"h":8598357476,"f":33},{"t":8422884,"n":"Aborted","d":8422884,"h":12893324772,"f":33},{"t":8422884,"n":"InDoubt","d":8422884,"h":17188292068,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":8422884,"h":21483259364,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":8422884}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Transactions.TransactionStatus`; }
        });
        
        $asm.$str("$stl.System.Transactions.DependentCloneOption", ($self) => class DependentCloneOption extends $.$spc.System.Enum
        {
            static BlockCommitUntilComplete = 0;
            static RollbackIfNotComplete = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "BlockCommitUntilComplete": 0n,
                    "RollbackIfNotComplete": 1n
                };
            }
            static $h = 1082852;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1082852,"n":"BlockCommitUntilComplete","d":1082852,"h":4296050148,"f":33},{"t":1082852,"n":"RollbackIfNotComplete","d":1082852,"h":8591017444,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1082852,"h":12885984740,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1082852}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Transactions.DependentCloneOption`; }
        });
        
        $asm.$str("$stl.System.Transactions.EnlistmentOptions", ($self) => class EnlistmentOptions extends $.$spc.System.Enum
        {
            static None = 0;
            static EnlistDuringPrepareRequired = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "EnlistDuringPrepareRequired": 1n
                };
            }
            static $h = 1869284;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1869284,"n":"None","d":1869284,"h":4296836580,"f":33},{"t":1869284,"n":"EnlistDuringPrepareRequired","d":1869284,"h":8591803876,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1869284,"h":12886771172,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1869284,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Transactions.EnlistmentOptions`; }
        });
        
        $asm.$str("$stl.System.Transactions.TransactionScopeOption", ($self) => class TransactionScopeOption extends $.$spc.System.Enum
        {
            static Required = 0;
            static RequiresNew = 1;
            static Suppress = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Required": 0n,
                    "RequiresNew": 1n,
                    "Suppress": 2n
                };
            }
            static $h = 5277156;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":5277156,"n":"Required","d":5277156,"h":4300244452,"f":33},{"t":5277156,"n":"RequiresNew","d":5277156,"h":8595211748,"f":33},{"t":5277156,"n":"Suppress","d":5277156,"h":12890179044,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":5277156,"h":17185146340,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":5277156}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Transactions.TransactionScopeOption`; }
        });
        
        $asm.$str("$stl.System.Transactions.TransactionScopeAsyncFlowOption", ($self) => class TransactionScopeAsyncFlowOption extends $.$spc.System.Enum
        {
            static Suppress = 0;
            static Enabled = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Suppress": 0n,
                    "Enabled": 1n
                };
            }
            static $h = 5211620;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":5211620,"n":"Suppress","d":5211620,"h":4300178916,"f":33},{"t":5211620,"n":"Enabled","d":5211620,"h":8595146212,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":5211620,"h":12890113508,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":5211620}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Transactions.TransactionScopeAsyncFlowOption`; }
        });
        
        $asm.$str("$stl.System.Transactions.EnterpriseServicesInteropOption", ($self) => class EnterpriseServicesInteropOption extends $.$spc.System.Enum
        {
            static None = 0;
            static Automatic = 1;
            static Full = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "Automatic": 1n,
                    "Full": 2n
                };
            }
            static $h = 2262500;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2262500,"n":"None","d":2262500,"h":4297229796,"f":33},{"t":2262500,"n":"Automatic","d":2262500,"h":8592197092,"f":33},{"t":2262500,"n":"Full","d":2262500,"h":12887164388,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2262500,"h":17182131684,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":2262500}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Transactions.EnterpriseServicesInteropOption`; }
        });
        
        $asm.$str("$stl.System.Transactions.EnlistmentType", ($self) => class EnlistmentType extends $.$spc.System.Enum
        {
            static Volatile = 0;
            static Durable = 1;
            static PromotableSinglePhase = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Volatile": 0n,
                    "Durable": 1n,
                    "PromotableSinglePhase": 2n
                };
            }
            static $h = 2131428;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2131428,"n":"Volatile","d":2131428,"h":4297098724,"f":33},{"t":2131428,"n":"Durable","d":2131428,"h":8592066020,"f":33},{"t":2131428,"n":"PromotableSinglePhase","d":2131428,"h":12887033316,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2131428,"h":17182000612,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":2131428}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Transactions.EnlistmentType`; }
        });
        
        $asm.$str("$stl.System.Transactions.NotificationCall", ($self) => class NotificationCall extends $.$spc.System.Enum
        {
            static Prepare = 0;
            static Commit = 1;
            static Rollback = 2;
            static InDoubt = 3;
            static SinglePhaseCommit = 4;
            static Promote = 5;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Prepare": 0n,
                    "Commit": 1n,
                    "Rollback": 2n,
                    "InDoubt": 3n,
                    "SinglePhaseCommit": 4n,
                    "Promote": 5n
                };
            }
            static $h = 3311076;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":3311076,"n":"Prepare","d":3311076,"h":4298278372,"f":33},{"t":3311076,"n":"Commit","d":3311076,"h":8593245668,"f":33},{"t":3311076,"n":"Rollback","d":3311076,"h":12888212964,"f":33},{"t":3311076,"n":"InDoubt","d":3311076,"h":17183180260,"f":33},{"t":3311076,"n":"SinglePhaseCommit","d":3311076,"h":21478147556,"f":33},{"t":3311076,"n":"Promote","d":3311076,"h":25773114852,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":3311076,"h":30068082148,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":3311076}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Transactions.NotificationCall`; }
        });
        
        $asm.$str("$stl.System.Transactions.EnlistmentCallback", ($self) => class EnlistmentCallback extends $.$spc.System.Enum
        {
            static Done = 0;
            static Prepared = 1;
            static ForceRollback = 2;
            static Committed = 3;
            static Aborted = 4;
            static InDoubt = 5;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Done": 0n,
                    "Prepared": 1n,
                    "ForceRollback": 2n,
                    "Committed": 3n,
                    "Aborted": 4n,
                    "InDoubt": 5n
                };
            }
            static $h = 1803748;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1803748,"n":"Done","d":1803748,"h":4296771044,"f":33},{"t":1803748,"n":"Prepared","d":1803748,"h":8591738340,"f":33},{"t":1803748,"n":"ForceRollback","d":1803748,"h":12886705636,"f":33},{"t":1803748,"n":"Committed","d":1803748,"h":17181672932,"f":33},{"t":1803748,"n":"Aborted","d":1803748,"h":21476640228,"f":33},{"t":1803748,"n":"InDoubt","d":1803748,"h":25771607524,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1803748,"h":30066574820,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1803748}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Transactions.EnlistmentCallback`; }
        });
        
        $asm.$str("$stl.System.Transactions.TransactionScopeResult", ($self) => class TransactionScopeResult extends $.$spc.System.Enum
        {
            static CreatedTransaction = 0;
            static UsingExistingCurrent = 1;
            static TransactionPassed = 2;
            static DependentTransactionPassed = 3;
            static NoTransaction = 4;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "CreatedTransaction": 0n,
                    "UsingExistingCurrent": 1n,
                    "TransactionPassed": 2n,
                    "DependentTransactionPassed": 3n,
                    "NoTransaction": 4n
                };
            }
            static $h = 5342692;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":5342692,"n":"CreatedTransaction","d":5342692,"h":4300309988,"f":33},{"t":5342692,"n":"UsingExistingCurrent","d":5342692,"h":8595277284,"f":33},{"t":5342692,"n":"TransactionPassed","d":5342692,"h":12890244580,"f":33},{"t":5342692,"n":"DependentTransactionPassed","d":5342692,"h":17185211876,"f":33},{"t":5342692,"n":"NoTransaction","d":5342692,"h":21480179172,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":5342692,"h":25775146468,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":5342692}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Transactions.TransactionScopeResult`; }
        });
        
        $asm.$str("$stl.System.Transactions.TransactionExceptionType", ($self) => class TransactionExceptionType extends $.$spc.System.Enum
        {
            static InvalidOperationException = 0;
            static TransactionAbortedException = 1;
            static TransactionException = 2;
            static TransactionInDoubtException = 3;
            static TransactionManagerCommunicationException = 4;
            static UnrecognizedRecoveryInformation = 5;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "InvalidOperationException": 0n,
                    "TransactionAbortedException": 1n,
                    "TransactionException": 2n,
                    "TransactionInDoubtException": 3n,
                    "TransactionManagerCommunicationException": 4n,
                    "UnrecognizedRecoveryInformation": 5n
                };
            }
            static $h = 4621796;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":4621796,"n":"UnrecognizedRecoveryInformation","d":4621796,"h":25774425572,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":4621796,"h":30069392868,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":4621796}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Transactions.TransactionExceptionType`; }
        });
        
        $asm.$str("$stl.System.Transactions.TraceSourceType", ($self) => class TraceSourceType extends $.$spc.System.Enum
        {
            static TraceSourceBase = 0;
            static TraceSourceLtm = 1;
            static TraceSourceOleTx = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "TraceSourceBase": 0n,
                    "TraceSourceLtm": 1n,
                    "TraceSourceOleTx": 2n
                };
            }
            static $h = 4228580;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":4228580,"n":"TraceSourceBase","d":4228580,"h":4299195876,"f":33},{"t":4228580,"n":"TraceSourceLtm","d":4228580,"h":8594163172,"f":33},{"t":4228580,"n":"TraceSourceOleTx","d":4228580,"h":12889130468,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":4228580,"h":17184097764,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":4228580}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Transactions.TraceSourceType`; }
        });
        
        $asm.$str("$stl.System.Transactions.DefaultComContextState", ($self) => class DefaultComContextState extends $.$spc.System.Enum
        {
            static Unknown = 0;
            static Unavailable = -1;
            static Available = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unknown": 0n,
                    "Unavailable": -1n,
                    "Available": 1n
                };
            }
            static $h = 1017316;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1017316,"n":"Unknown","d":1017316,"h":4295984612,"f":33},{"t":1017316,"n":"Unavailable","d":1017316,"h":8590951908,"f":33},{"t":1017316,"n":"Available","d":1017316,"h":12885919204,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1017316,"h":17180886500,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1017316}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Transactions.DefaultComContextState`; }
        });
        
        $asm.$str("$stl.System.Transactions.TxLookup", ($self) => class TxLookup extends $.$spc.System.Enum
        {
            static Default = 0;
            static DefaultCallContext = 1;
            static DefaultTLS = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Default": 0n,
                    "DefaultCallContext": 1n,
                    "DefaultTLS": 2n
                };
            }
            static $h = 8619492;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":8619492,"n":"Default","d":8619492,"h":4303586788,"f":33},{"t":8619492,"n":"DefaultCallContext","d":8619492,"h":8598554084,"f":33},{"t":8619492,"n":"DefaultTLS","d":8619492,"h":12893521380,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":8619492,"h":17188488676,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":8619492}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Transactions.TxLookup`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateActive", ($self) => class TransactionStateActive extends $.$stl.System.Transactions.EnlistableStates
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
            }
            /*void */ BeginCommit(/*InternalTransaction*/ tx, /*bool*/ asyncCommit, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                tx._asyncCommit = asyncCommit;
                tx._asyncCallback = asyncCallback;
                tx._asyncState = asyncState;
                $.$stl.System.Transactions.TransactionState.TransactionStatePhase0.EnterState(tx);
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                tx._innerException ??= e;
                $.$stl.System.Transactions.TransactionState.TransactionStateAborted.EnterState(tx);
            }
            /*Enlistment */ EnlistVolatile(/*InternalTransaction*/ tx, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                /*Enlistment*/ let enlistment = new $.$stl.System.Transactions.Enlistment().$ctor$3(tx, enlistmentNotification, null, atomicTransaction, enlistmentOptions);
                if ((enlistmentOptions & 1/*EnlistmentOptions.EnlistDuringPrepareRequired*/) !== 0)
                {
                    $.$stl.System.Transactions.TransactionState.AddVolatileEnlistment($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase0Volatiles, ($v) => tx._phase0Volatiles = $v, null), enlistment);
                }
                else 
                {
                    $.$stl.System.Transactions.TransactionState.AddVolatileEnlistment($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase1Volatiles, ($v) => tx._phase1Volatiles = $v, null), enlistment);
                }
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionstateEnlist(enlistment.InternalEnlistment.EnlistmentTraceId, 0/*EnlistmentType.Volatile*/, enlistmentOptions);
                }
                return enlistment;
            }
            /*Enlistment */ EnlistVolatile$1(/*InternalTransaction*/ tx, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                /*Enlistment*/ let enlistment = new $.$stl.System.Transactions.Enlistment().$ctor$3(tx, enlistmentNotification, enlistmentNotification, atomicTransaction, enlistmentOptions);
                if ((enlistmentOptions & 1/*EnlistmentOptions.EnlistDuringPrepareRequired*/) !== 0)
                {
                    $.$stl.System.Transactions.TransactionState.AddVolatileEnlistment($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase0Volatiles, ($v) => tx._phase0Volatiles = $v, null), enlistment);
                }
                else 
                {
                    $.$stl.System.Transactions.TransactionState.AddVolatileEnlistment($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase1Volatiles, ($v) => tx._phase1Volatiles = $v, null), enlistment);
                }
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionstateEnlist(enlistment.InternalEnlistment.EnlistmentTraceId, 0/*EnlistmentType.Volatile*/, enlistmentOptions);
                }
                return enlistment;
            }
            /*bool */ EnlistPromotableSinglePhase(/*InternalTransaction*/ tx, /*IPromotableSinglePhaseNotification*/ promotableSinglePhaseNotification, /*Transaction*/ atomicTransaction, /*Guid*/ promoterType)
            {
                if (tx._durableEnlistment !== null)
                {
                    return false;
                }
                $.$stl.System.Transactions.TransactionState.TransactionStatePSPEOperation.PSPEInitialize(tx, promotableSinglePhaseNotification, promoterType);
                /*Enlistment*/ let en = new $.$stl.System.Transactions.Enlistment().$ctor$4(tx, promotableSinglePhaseNotification, atomicTransaction);
                tx._durableEnlistment = en.InternalEnlistment;
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionstateEnlist(tx._durableEnlistment.EnlistmentTraceId, 2/*EnlistmentType.PromotableSinglePhase*/, 0/*EnlistmentOptions.None*/);
                }
                tx._promoter = promotableSinglePhaseNotification;
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Guid.op_Inequality(tx._promoterType, $.$spc.System.Guid.Empty), "InternalTransaction.PromoterType was not set in PSPEInitialize");
                if ($.$spc.System.Guid.op_Equality(tx._promoterType, $.$stl.System.Transactions.TransactionInterop.PromoterTypeDtc))
                {
                    tx._promoteState = $.$stl.System.Transactions.TransactionState.TransactionStateDelegated;
                }
                else 
                {
                    tx._promoteState = $.$stl.System.Transactions.TransactionState.TransactionStateDelegatedNonMSDTC;
                }
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentActive.EnterState(tx._durableEnlistment);
                return true;
            }
            /*void */ Phase0VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ Phase1VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ DisposeRoot(/*InternalTransaction*/ tx)
            {
                tx.State.Rollback(tx, null);
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 5866980;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1672676,"m":[{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"EnterState","d":5866980,"h":4300834276,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"asyncCommit","p":262145},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":5866980,"h":8595801572,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"e","p":47251457}],"n":"Rollback","d":5866980,"h":12890768868,"f":32776},{"r":1738212,"p":[{"n":"tx","p":2786788},{"n":"enlistmentNotification","p":2590180},{"n":"enlistmentOptions","p":1869284},{"n":"atomicTransaction","p":4294116}],"n":"EnlistVolatile","d":5866980,"h":17185736164,"f":32776},{"r":1738212,"p":[{"n":"tx","p":2786788},{"n":"enlistmentNotification","p":3048932},{"n":"enlistmentOptions","p":1869284},{"n":"atomicTransaction","p":4294116}],"n":"EnlistVolatile","o":"@$1","d":5866980,"h":21480703460,"f":32776},{"r":262145,"p":[{"n":"tx","p":2786788},{"n":"promotableSinglePhaseNotification","p":2852324},{"n":"atomicTransaction","p":4294116},{"n":"promoterType","p":56229889}],"n":"EnlistPromotableSinglePhase","d":5866980,"h":25775670756,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"Phase0VolatilePrepareDone","d":5866980,"h":30070638052,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"Phase1VolatilePrepareDone","d":5866980,"h":34365605348,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"DisposeRoot","d":5866980,"h":38660572644,"f":32776}],"c":[{"n":".ctor","o":"$ctor$4","d":5866980,"h":42955539940,"f":1}],"h":5866980}; }
            static get $b() { return $.$stl.System.Transactions.EnlistableStates; }
            static get $fullName() { return `System.Transactions.TransactionStateActive`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePhase0", ($self) => class TransactionStatePhase0 extends $.$stl.System.Transactions.EnlistableStates
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                /*int*/ let volatileCount = tx._phase0Volatiles._volatileEnlistmentCount;
                /*int*/ let dependentCount = tx._phase0Volatiles._dependentClones;
                tx._phase0VolatileWaveCount = volatileCount;
                if (tx._phase0Volatiles._preparedVolatileEnlistments < ((volatileCount + dependentCount) | 0))
                {
                    for(/*int*/ let i = 0; i < volatileCount; i++)
                    {
                        $.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i)._twoPhaseState.ChangeStatePreparing($.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i));
                        if (!tx.State.ContinuePhase0Prepares())
                        {
                            break;
                        }
                    }
                }
                else 
                {
                    $.$stl.System.Transactions.TransactionState.TransactionStateVolatilePhase1.EnterState(tx);
                }
            }
            /*Enlistment */ EnlistDurable(/*InternalTransaction*/ tx, /*Guid*/ resourceManagerIdentifier, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                tx.ThrowIfPromoterTypeIsNotMSDTC();
                /*Enlistment*/ let en = super.EnlistDurable(tx, resourceManagerIdentifier, enlistmentNotification, enlistmentOptions, atomicTransaction);
                tx.State.RestartCommitIfNeeded(tx);
                return en;
            }
            /*Enlistment */ EnlistDurable$1(/*InternalTransaction*/ tx, /*Guid*/ resourceManagerIdentifier, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                tx.ThrowIfPromoterTypeIsNotMSDTC();
                /*Enlistment*/ let en = super.EnlistDurable$1(tx, resourceManagerIdentifier, enlistmentNotification, enlistmentOptions, atomicTransaction);
                tx.State.RestartCommitIfNeeded(tx);
                return en;
            }
            /*Enlistment */ EnlistVolatile(/*InternalTransaction*/ tx, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                /*Enlistment*/ let enlistment = new $.$stl.System.Transactions.Enlistment().$ctor$3(tx, enlistmentNotification, null, atomicTransaction, enlistmentOptions);
                if ((enlistmentOptions & 1/*EnlistmentOptions.EnlistDuringPrepareRequired*/) !== 0)
                {
                    $.$stl.System.Transactions.TransactionState.AddVolatileEnlistment($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase0Volatiles, ($v) => tx._phase0Volatiles = $v, null), enlistment);
                }
                else 
                {
                    $.$stl.System.Transactions.TransactionState.AddVolatileEnlistment($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase1Volatiles, ($v) => tx._phase1Volatiles = $v, null), enlistment);
                }
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionstateEnlist(enlistment.InternalEnlistment.EnlistmentTraceId, 0/*EnlistmentType.Volatile*/, enlistmentOptions);
                }
                return enlistment;
            }
            /*Enlistment */ EnlistVolatile$1(/*InternalTransaction*/ tx, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                /*Enlistment*/ let enlistment = new $.$stl.System.Transactions.Enlistment().$ctor$3(tx, enlistmentNotification, enlistmentNotification, atomicTransaction, enlistmentOptions);
                if ((enlistmentOptions & 1/*EnlistmentOptions.EnlistDuringPrepareRequired*/) !== 0)
                {
                    $.$stl.System.Transactions.TransactionState.AddVolatileEnlistment($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase0Volatiles, ($v) => tx._phase0Volatiles = $v, null), enlistment);
                }
                else 
                {
                    $.$stl.System.Transactions.TransactionState.AddVolatileEnlistment($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase1Volatiles, ($v) => tx._phase1Volatiles = $v, null), enlistment);
                }
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionstateEnlist(enlistment.InternalEnlistment.EnlistmentTraceId, 0/*EnlistmentType.Volatile*/, enlistmentOptions);
                }
                return enlistment;
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                this.ChangeStateTransactionAborted(tx, e);
            }
            /*bool */ EnlistPromotableSinglePhase(/*InternalTransaction*/ tx, /*IPromotableSinglePhaseNotification*/ promotableSinglePhaseNotification, /*Transaction*/ atomicTransaction, /*Guid*/ promoterType)
            {
                if (tx._durableEnlistment !== null)
                {
                    return false;
                }
                $.$stl.System.Transactions.TransactionState.TransactionStatePSPEOperation.Phase0PSPEInitialize(tx, promotableSinglePhaseNotification, promoterType);
                /*Enlistment*/ let en = new $.$stl.System.Transactions.Enlistment().$ctor$4(tx, promotableSinglePhaseNotification, atomicTransaction);
                tx._durableEnlistment = en.InternalEnlistment;
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionstateEnlist(tx._durableEnlistment.EnlistmentTraceId, 2/*EnlistmentType.PromotableSinglePhase*/, 0/*EnlistmentOptions.None*/);
                }
                tx._promoter = promotableSinglePhaseNotification;
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Guid.op_Inequality(tx._promoterType, $.$spc.System.Guid.Empty), "InternalTransaction.PromoterType was not set in Phase0PSPEInitialize");
                if ($.$spc.System.Guid.op_Equality(tx._promoterType, $.$stl.System.Transactions.TransactionInterop.PromoterTypeDtc))
                {
                    tx._promoteState = $.$stl.System.Transactions.TransactionState.TransactionStateDelegated;
                }
                else 
                {
                    tx._promoteState = $.$stl.System.Transactions.TransactionState.TransactionStateDelegatedNonMSDTC;
                }
                $.$stl.System.Transactions.DurableEnlistmentState.DurableEnlistmentActive.EnterState(tx._durableEnlistment);
                return true;
            }
            /*void */ Phase0VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
                /*int*/ let volatileCount = tx._phase0Volatiles._volatileEnlistmentCount;
                /*int*/ let dependentCount = tx._phase0Volatiles._dependentClones;
                tx._phase0VolatileWaveCount = volatileCount;
                if (tx._phase0Volatiles._preparedVolatileEnlistments < ((volatileCount + dependentCount) | 0))
                {
                    for(/*int*/ let i = 0; i < volatileCount; i++)
                    {
                        $.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i)._twoPhaseState.ChangeStatePreparing($.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i));
                        if (!tx.State.ContinuePhase0Prepares())
                        {
                            break;
                        }
                    }
                }
                else 
                {
                    $.$stl.System.Transactions.TransactionState.TransactionStateVolatilePhase1.EnterState(tx);
                }
            }
            /*void */ Phase1VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ RestartCommitIfNeeded(/*InternalTransaction*/ tx)
            {
            }
            /*bool */ ContinuePhase0Prepares()
            {
                return true;
            }
            /*void */ Promote(/*InternalTransaction*/ tx)
            {
                tx._promoteState.EnterState(tx);
                tx.State.CheckForFinishedTransaction(tx);
                tx.State.RestartCommitIfNeeded(tx);
            }
            /*void */ ChangeStateTransactionAborted(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                tx._innerException ??= e;
                $.$stl.System.Transactions.TransactionState.TransactionStateAborted.EnterState(tx);
            }
            /*void */ GetObjectData(/*InternalTransaction*/ tx, /*SerializationInfo*/ serializationInfo, /*StreamingContext*/ context)
            {
                tx.ThrowIfPromoterTypeIsNotMSDTC();
                tx._promoteState.EnterState(tx);
                tx.State.GetObjectData(tx, serializationInfo, context);
                tx.State.RestartCommitIfNeeded(tx);
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 6653412;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1672676,"m":[{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"EnterState","d":6653412,"h":4301620708,"f":32776},{"r":1738212,"p":[{"n":"tx","p":2786788},{"n":"resourceManagerIdentifier","p":56229889},{"n":"enlistmentNotification","p":2590180},{"n":"enlistmentOptions","p":1869284},{"n":"atomicTransaction","p":4294116}],"n":"EnlistDurable","d":6653412,"h":8596588004,"f":32776},{"r":1738212,"p":[{"n":"tx","p":2786788},{"n":"resourceManagerIdentifier","p":56229889},{"n":"enlistmentNotification","p":3048932},{"n":"enlistmentOptions","p":1869284},{"n":"atomicTransaction","p":4294116}],"n":"EnlistDurable","o":"@$1","d":6653412,"h":12891555300,"f":32776},{"r":1738212,"p":[{"n":"tx","p":2786788},{"n":"enlistmentNotification","p":2590180},{"n":"enlistmentOptions","p":1869284},{"n":"atomicTransaction","p":4294116}],"n":"EnlistVolatile","d":6653412,"h":17186522596,"f":32776},{"r":1738212,"p":[{"n":"tx","p":2786788},{"n":"enlistmentNotification","p":3048932},{"n":"enlistmentOptions","p":1869284},{"n":"atomicTransaction","p":4294116}],"n":"EnlistVolatile","o":"@$1","d":6653412,"h":21481489892,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"e","p":47251457}],"n":"Rollback","d":6653412,"h":25776457188,"f":32776},{"r":262145,"p":[{"n":"tx","p":2786788},{"n":"promotableSinglePhaseNotification","p":2852324},{"n":"atomicTransaction","p":4294116},{"n":"promoterType","p":56229889}],"n":"EnlistPromotableSinglePhase","d":6653412,"h":30071424484,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"Phase0VolatilePrepareDone","d":6653412,"h":34366391780,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"Phase1VolatilePrepareDone","d":6653412,"h":38661359076,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"RestartCommitIfNeeded","d":6653412,"h":42956326372,"f":32776},{"r":262145,"n":"ContinuePhase0Prepares","d":6653412,"h":47251293668,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"Promote","d":6653412,"h":51546260964,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"e","p":47251457}],"n":"ChangeStateTransactionAborted","d":6653412,"h":55841228260,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"serializationInfo","p":113967105},{"n":"context","p":114098177}],"n":"GetObjectData","d":6653412,"h":60136195556,"f":32776}],"c":[{"n":".ctor","o":"$ctor$4","d":6653412,"h":64431162852,"f":1}],"h":6653412}; }
            static get $b() { return $.$stl.System.Transactions.EnlistableStates; }
            static get $fullName() { return `System.Transactions.TransactionStatePhase0`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedP0Aborting", ($self) => class TransactionStatePromotedP0Aborting extends $.$stl.System.Transactions.TransactionStatePromotedAborting
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                this.ChangeStatePromotedAborted(tx);
                if (tx._phase0Volatiles.VolatileDemux._preparingEnlistment !== null)
                {
                    $.$spc.System.Threading.Monitor.Exit(tx);
                    try
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(tx._phase0Volatiles.VolatileDemux._promotedEnlistment !== null, "tx._phase0Volatiles.VolatileDemux._promotedEnlistment != null");
                        tx._phase0Volatiles.VolatileDemux._promotedEnlistment.System$Transactions$IPromotedEnlistment$ForceRollback();
                    }
                    finally
                    {
                        {
                            $.$spc.System.Threading.Monitor.Enter(tx);
                        }
                    }
                }
                else 
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(tx.PromotedTransaction !== null, "tx.PromotedTransaction != null");
                    tx.PromotedTransaction.Rollback();
                }
            }
            /*void */ Phase0VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 7767524;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6850020,"m":[{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"EnterState","d":7767524,"h":4302734820,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"Phase0VolatilePrepareDone","d":7767524,"h":8597702116,"f":32776}],"c":[{"n":".ctor","o":"$ctor$4","d":7767524,"h":12892669412,"f":1}],"h":7767524}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedAborting; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedP0Aborting`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedP1Aborting", ($self) => class TransactionStatePromotedP1Aborting extends $.$stl.System.Transactions.TransactionStatePromotedAborting
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                $.$spc.System.Diagnostics.Debug.Assert$1(tx._phase1Volatiles.VolatileDemux !== null, "Volatile Demux must exist.");
                this.ChangeStatePromotedAborted(tx);
                $.$spc.System.Threading.Monitor.Exit(tx);
                try
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(tx._phase1Volatiles.VolatileDemux._promotedEnlistment !== null, "tx._phase1Volatiles.VolatileDemux._promotedEnlistment != null");
                    tx._phase1Volatiles.VolatileDemux._promotedEnlistment.System$Transactions$IPromotedEnlistment$ForceRollback();
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(tx);
                    }
                }
            }
            /*void */ Phase1VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 7898596;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6850020,"m":[{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"EnterState","d":7898596,"h":4302865892,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"Phase1VolatilePrepareDone","d":7898596,"h":8597833188,"f":32776}],"c":[{"n":".ctor","o":"$ctor$4","d":7898596,"h":12892800484,"f":1}],"h":7898596}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedAborting; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedP1Aborting`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedAborted", ($self) => class TransactionStatePromotedAborted extends $.$stl.System.Transactions.TransactionStatePromotedEnded
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                super.EnterState(tx);
                if (tx._phase1Volatiles.VolatileDemux !== null)
                {
                    $.$stl.System.Transactions.VolatileDemultiplexer.BroadcastRollback($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase1Volatiles, ($v) => tx._phase1Volatiles = $v, null));
                }
                if (tx._phase0Volatiles.VolatileDemux !== null)
                {
                    $.$stl.System.Transactions.VolatileDemultiplexer.BroadcastRollback($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase0Volatiles, ($v) => tx._phase0Volatiles = $v, null));
                }
                tx.FireCompletion();
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionAborted(1/*TraceSourceType.TraceSourceLtm*/, tx.TransactionTraceId);
                }
            }
            /*TransactionStatus */ get_Status(/*InternalTransaction*/ tx)
            {
                return 2/*TransactionStatus.Aborted*/;
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
            }
            /*void */ BeginCommit(/*InternalTransaction*/ tx, /*bool*/ asyncCommit, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw $.$stl.System.Transactions.TransactionAbortedException.Create$3($.$stl.System.SR.TransactionAborted, tx._innerException, tx.DistributedTxId);
            }
            /*void */ CreateBlockingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionAbortedException.Create$3($.$stl.System.SR.TransactionAborted, tx._innerException, tx.DistributedTxId);
            }
            /*void */ CreateAbortingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionAbortedException.Create$3($.$stl.System.SR.TransactionAborted, tx._innerException, tx.DistributedTxId);
            }
            /*void */ RestartCommitIfNeeded(/*InternalTransaction*/ tx)
            {
            }
            /*void */ Phase0VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ Phase1VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ ChangeStatePromotedPhase0(/*InternalTransaction*/ tx)
            {
                throw new $.$stl.System.Transactions.TransactionAbortedException().$ctor$17(tx._innerException, tx.DistributedTxId);
            }
            /*void */ ChangeStatePromotedPhase1(/*InternalTransaction*/ tx)
            {
                throw new $.$stl.System.Transactions.TransactionAbortedException().$ctor$17(tx._innerException, tx.DistributedTxId);
            }
            /*void */ ChangeStatePromotedAborted(/*InternalTransaction*/ tx)
            {
            }
            /*void */ ChangeStateTransactionAborted(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
            }
            /*void */ PromotedTransactionOutcome(/*InternalTransaction*/ tx)
            {
                if ((null === tx._innerException) && (null !== tx.PromotedTransaction))
                {
                    tx._innerException = tx.PromotedTransaction.InnerException;
                }
                throw $.$stl.System.Transactions.TransactionAbortedException.Create$3($.$stl.System.SR.TransactionAborted, tx._innerException, tx.DistributedTxId);
            }
            /*void */ CheckForFinishedTransaction(/*InternalTransaction*/ tx)
            {
                throw new $.$stl.System.Transactions.TransactionAbortedException().$ctor$17(tx._innerException, tx.DistributedTxId);
            }
            /*void */ GetObjectData(/*InternalTransaction*/ tx, /*SerializationInfo*/ serializationInfo, /*StreamingContext*/ context)
            {
                throw $.$stl.System.Transactions.TransactionAbortedException.Create$3($.$stl.System.SR.TransactionAborted, tx._innerException, tx.DistributedTxId);
            }
            /*void */ InDoubtFromDtc(/*InternalTransaction*/ tx)
            {
            }
            /*void */ InDoubtFromEnlistment(/*InternalTransaction*/ tx)
            {
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 6784484;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7112164,"m":[{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"EnterState","d":6784484,"h":4301751780,"f":32776},{"r":8422884,"p":[{"n":"tx","p":2786788}],"n":"get_Status","d":6784484,"h":8596719076,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"e","p":47251457}],"n":"Rollback","d":6784484,"h":12891686372,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"asyncCommit","p":262145},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":6784484,"h":17186653668,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"CreateBlockingClone","d":6784484,"h":21481620964,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"CreateAbortingClone","d":6784484,"h":25776588260,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"RestartCommitIfNeeded","d":6784484,"h":30071555556,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"Phase0VolatilePrepareDone","d":6784484,"h":34366522852,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"Phase1VolatilePrepareDone","d":6784484,"h":38661490148,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"ChangeStatePromotedPhase0","d":6784484,"h":42956457444,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"ChangeStatePromotedPhase1","d":6784484,"h":47251424740,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"ChangeStatePromotedAborted","d":6784484,"h":51546392036,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"e","p":47251457}],"n":"ChangeStateTransactionAborted","d":6784484,"h":55841359332,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"PromotedTransactionOutcome","d":6784484,"h":60136326628,"f":32772},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"CheckForFinishedTransaction","d":6784484,"h":64431293924,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"serializationInfo","p":113967105},{"n":"context","p":114098177}],"n":"GetObjectData","d":6784484,"h":68726261220,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"InDoubtFromDtc","d":6784484,"h":73021228516,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"InDoubtFromEnlistment","d":6784484,"h":77316195812,"f":32776}],"c":[{"n":".ctor","o":"$ctor$4","d":6784484,"h":81611163108,"f":1}],"h":6784484}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedEnded; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedAborted`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedCommitted", ($self) => class TransactionStatePromotedCommitted extends $.$stl.System.Transactions.TransactionStatePromotedEnded
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                super.EnterState(tx);
                if (tx._phase1Volatiles.VolatileDemux !== null)
                {
                    $.$stl.System.Transactions.VolatileDemultiplexer.BroadcastCommitted($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase1Volatiles, ($v) => tx._phase1Volatiles = $v, null));
                }
                if (tx._phase0Volatiles.VolatileDemux !== null)
                {
                    $.$stl.System.Transactions.VolatileDemultiplexer.BroadcastCommitted($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase0Volatiles, ($v) => tx._phase0Volatiles = $v, null));
                }
                tx.FireCompletion();
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionCommitted(1/*TraceSourceType.TraceSourceLtm*/, tx.TransactionTraceId);
                }
            }
            /*TransactionStatus */ get_Status(/*InternalTransaction*/ tx)
            {
                return 1/*TransactionStatus.Committed*/;
            }
            /*void */ ChangeStatePromotedCommitted(/*InternalTransaction*/ tx)
            {
            }
            /*void */ PromotedTransactionOutcome(/*InternalTransaction*/ tx)
            {
            }
            /*void */ InDoubtFromDtc(/*InternalTransaction*/ tx)
            {
            }
            /*void */ InDoubtFromEnlistment(/*InternalTransaction*/ tx)
            {
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 6981092;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7112164,"m":[{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"EnterState","d":6981092,"h":4301948388,"f":32776},{"r":8422884,"p":[{"n":"tx","p":2786788}],"n":"get_Status","d":6981092,"h":8596915684,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"ChangeStatePromotedCommitted","d":6981092,"h":12891882980,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"PromotedTransactionOutcome","d":6981092,"h":17186850276,"f":32772},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"InDoubtFromDtc","d":6981092,"h":21481817572,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"InDoubtFromEnlistment","d":6981092,"h":25776784868,"f":32776}],"c":[{"n":".ctor","o":"$ctor$4","d":6981092,"h":30071752164,"f":1}],"h":6981092}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedEnded; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedCommitted`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedIndoubt", ($self) => class TransactionStatePromotedIndoubt extends $.$stl.System.Transactions.TransactionStatePromotedEnded
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                super.EnterState(tx);
                if (tx._phase1Volatiles.VolatileDemux !== null)
                {
                    $.$stl.System.Transactions.VolatileDemultiplexer.BroadcastInDoubt($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase1Volatiles, ($v) => tx._phase1Volatiles = $v, null));
                }
                if (tx._phase0Volatiles.VolatileDemux !== null)
                {
                    $.$stl.System.Transactions.VolatileDemultiplexer.BroadcastInDoubt($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stl.System.Transactions.VolatileEnlistmentSet, () => tx._phase0Volatiles, ($v) => tx._phase0Volatiles = $v, null));
                }
                tx.FireCompletion();
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionInDoubt(1/*TraceSourceType.TraceSourceLtm*/, tx.TransactionTraceId);
                }
            }
            /*TransactionStatus */ get_Status(/*InternalTransaction*/ tx)
            {
                return 3/*TransactionStatus.InDoubt*/;
            }
            /*void */ RestartCommitIfNeeded(/*InternalTransaction*/ tx)
            {
            }
            /*void */ ChangeStatePromotedPhase0(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionInDoubtException.Create$3(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionIndoubt, tx._innerException, tx.DistributedTxId);
            }
            /*void */ ChangeStatePromotedPhase1(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionInDoubtException.Create$3(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionIndoubt, tx._innerException, tx.DistributedTxId);
            }
            /*void */ InDoubtFromDtc(/*InternalTransaction*/ tx)
            {
            }
            /*void */ InDoubtFromEnlistment(/*InternalTransaction*/ tx)
            {
            }
            /*void */ PromotedTransactionOutcome(/*InternalTransaction*/ tx)
            {
                if ((null === tx._innerException) && (null !== tx.PromotedTransaction))
                {
                    tx._innerException = tx.PromotedTransaction.InnerException;
                }
                throw $.$stl.System.Transactions.TransactionInDoubtException.Create$3(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionIndoubt, tx._innerException, tx.DistributedTxId);
            }
            /*void */ CheckForFinishedTransaction(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionInDoubtException.Create$3(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionIndoubt, tx._innerException, tx.DistributedTxId);
            }
            /*void */ GetObjectData(/*InternalTransaction*/ tx, /*SerializationInfo*/ serializationInfo, /*StreamingContext*/ context)
            {
                throw $.$stl.System.Transactions.TransactionInDoubtException.Create$3(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionIndoubt, tx._innerException, tx.DistributedTxId);
            }
            /*void */ ChangeStatePromotedAborted(/*InternalTransaction*/ tx)
            {
            }
            /*void */ ChangeStatePromotedCommitted(/*InternalTransaction*/ tx)
            {
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 7177700;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7112164,"m":[{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"EnterState","d":7177700,"h":4302144996,"f":32776},{"r":8422884,"p":[{"n":"tx","p":2786788}],"n":"get_Status","d":7177700,"h":8597112292,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"RestartCommitIfNeeded","d":7177700,"h":12892079588,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"ChangeStatePromotedPhase0","d":7177700,"h":17187046884,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"ChangeStatePromotedPhase1","d":7177700,"h":21482014180,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"InDoubtFromDtc","d":7177700,"h":25776981476,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"InDoubtFromEnlistment","d":7177700,"h":30071948772,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"PromotedTransactionOutcome","d":7177700,"h":34366916068,"f":32772},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"CheckForFinishedTransaction","d":7177700,"h":38661883364,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"serializationInfo","p":113967105},{"n":"context","p":114098177}],"n":"GetObjectData","d":7177700,"h":42956850660,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"ChangeStatePromotedAborted","d":7177700,"h":47251817956,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"ChangeStatePromotedCommitted","d":7177700,"h":51546785252,"f":32776}],"c":[{"n":".ctor","o":"$ctor$4","d":7177700,"h":55841752548,"f":1}],"h":7177700}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedEnded; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedIndoubt`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateDelegatedBase", ($self) => class TransactionStateDelegatedBase extends $.$stl.System.Transactions.TransactionStatePromoted
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                if (tx._outcomeSource._isoLevel === 4/*IsolationLevel.Snapshot*/)
                {
                    throw $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException$1(1/*TraceSourceType.TraceSourceLtm*/, $.$stl.System.SR.CannotPromoteSnapshot, null, tx.DistributedTxId);
                }
                this.CommonEnterState(tx);
                /*Oletx.OletxTransaction?*/ let distributedTx = null;
                try
                {
                    if (tx._durableEnlistment !== null)
                    {
                        /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                        if (etwLog.IsEnabled())
                        {
                            etwLog.EnlistmentStatus(1/*TraceSourceType.TraceSourceLtm*/, tx._durableEnlistment.EnlistmentTraceId, 5/*NotificationCall.Promote*/);
                        }
                    }
                    distributedTx = $.$stl.System.Transactions.TransactionState.TransactionStatePSPEOperation.PSPEPromote(tx);
                }
                catch(e)
                {
                    tx._innerException = e;
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.ExceptionConsumed$1(e);
                    }
                }
                finally
                {
                    {
                        if ((distributedTx) === null)
                        {
                            tx.State.ChangeStateAbortedDuringPromotion(tx);
                        }
                    }
                }
                if ((distributedTx) === null)
                {
                    return;
                }
                if (tx.PromotedTransaction !== distributedTx)
                {
                    tx.PromotedTransaction = distributedTx;
                    /*Hashtable*/ let promotedTransactionTable = $.$stl.System.Transactions.TransactionManager.PromotedTransactionTable;
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter(promotedTransactionTable)
                        {
                            tx._finalizedObject = new $.$stl.System.Transactions.FinalizedObject().$ctor$1(tx, tx.PromotedTransaction.Identifier);
                            /*WeakReference*/ let weakRef = new $.$spc.System.WeakReference().$ctor$2(tx._outcomeSource, false);
                            promotedTransactionTable.set_Item(tx.PromotedTransaction.Identifier, weakRef);
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit(promotedTransactionTable)
                    }
                    $.$stl.System.Transactions.TransactionManager.FireDistributedTransactionStarted(tx._outcomeSource);
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.TransactionPromoted(tx.TransactionTraceId, distributedTx.TransactionTraceId);
                    }
                    this.PromoteEnlistmentsAndOutcome(tx);
                }
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 6129124;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6718948,"m":[{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"EnterState","d":6129124,"h":4301096420,"f":32776}],"c":[{"n":".ctor","o":"$ctor$4","d":6129124,"h":8596063716,"f":4}],"h":6129124}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromoted; }
            static get $fullName() { return `System.Transactions.TransactionStateDelegatedBase`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedNonMSDTCAborted", ($self) => class TransactionStatePromotedNonMSDTCAborted extends $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCEnded
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                super.EnterState(tx);
                for(/*int*/ let i = 0; i < tx._phase0Volatiles._volatileEnlistmentCount; i++)
                {
                    $.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i)._twoPhaseState.InternalAborted($.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i));
                }
                for(/*int*/ let i = 0; i < tx._phase1Volatiles._volatileEnlistmentCount; i++)
                {
                    $.$spc.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i)._twoPhaseState.InternalAborted($.$spc.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i));
                }
                tx._durableEnlistment?.State.InternalAborted(tx._durableEnlistment);
                tx.FireCompletion();
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionAborted(1/*TraceSourceType.TraceSourceLtm*/, tx.TransactionTraceId);
                }
            }
            /*TransactionStatus */ get_Status(/*InternalTransaction*/ tx)
            {
                return 2/*TransactionStatus.Aborted*/;
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
            }
            /*void */ BeginCommit(/*InternalTransaction*/ tx, /*bool*/ asyncCommit, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw $.$stl.System.Transactions.TransactionAbortedException.Create$3($.$stl.System.SR.TransactionAborted, tx._innerException, tx.DistributedTxId);
            }
            /*void */ CreateBlockingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionAbortedException.Create$3($.$stl.System.SR.TransactionAborted, tx._innerException, tx.DistributedTxId);
            }
            /*void */ CreateAbortingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionAbortedException.Create$3($.$stl.System.SR.TransactionAborted, tx._innerException, tx.DistributedTxId);
            }
            /*void */ Phase0VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ Phase1VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
            }
            /*void */ ChangeStateTransactionAborted(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
            }
            /*void */ PromotedTransactionOutcome(/*InternalTransaction*/ tx)
            {
                if ((null === tx._innerException) && (null !== tx.PromotedTransaction))
                {
                    tx._innerException = tx.PromotedTransaction.InnerException;
                }
                throw $.$stl.System.Transactions.TransactionAbortedException.Create$3($.$stl.System.SR.TransactionAborted, tx._innerException, tx.DistributedTxId);
            }
            /*void */ CheckForFinishedTransaction(/*InternalTransaction*/ tx)
            {
                throw new $.$stl.System.Transactions.TransactionAbortedException().$ctor$17(tx._innerException, tx.DistributedTxId);
            }
            /*void */ GetObjectData(/*InternalTransaction*/ tx, /*SerializationInfo*/ serializationInfo, /*StreamingContext*/ context)
            {
                throw $.$stl.System.Transactions.TransactionAbortedException.Create$3($.$stl.System.SR.TransactionAborted, tx._innerException, tx.DistributedTxId);
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 7243236;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7439844,"m":[{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"EnterState","d":7243236,"h":4302210532,"f":32776},{"r":8422884,"p":[{"n":"tx","p":2786788}],"n":"get_Status","d":7243236,"h":8597177828,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"e","p":47251457}],"n":"Rollback","d":7243236,"h":12892145124,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"asyncCommit","p":262145},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":7243236,"h":17187112420,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"CreateBlockingClone","d":7243236,"h":21482079716,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"CreateAbortingClone","d":7243236,"h":25777047012,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"Phase0VolatilePrepareDone","d":7243236,"h":30072014308,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"Phase1VolatilePrepareDone","d":7243236,"h":34366981604,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"e","p":47251457}],"n":"ChangeStateTransactionAborted","d":7243236,"h":38661948900,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"PromotedTransactionOutcome","d":7243236,"h":42956916196,"f":32772},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"CheckForFinishedTransaction","d":7243236,"h":47251883492,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"serializationInfo","p":113967105},{"n":"context","p":114098177}],"n":"GetObjectData","d":7243236,"h":51546850788,"f":32776}],"c":[{"n":".ctor","o":"$ctor$4","d":7243236,"h":55841818084,"f":1}],"h":7243236}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCEnded; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedNonMSDTCAborted`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedNonMSDTCCommitted", ($self) => class TransactionStatePromotedNonMSDTCCommitted extends $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCEnded
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                super.EnterState(tx);
                for(/*int*/ let i = 0; i < tx._phase0Volatiles._volatileEnlistmentCount; i++)
                {
                    $.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i)._twoPhaseState.InternalCommitted($.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i));
                }
                for(/*int*/ let i = 0; i < tx._phase1Volatiles._volatileEnlistmentCount; i++)
                {
                    $.$spc.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i)._twoPhaseState.InternalCommitted($.$spc.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i));
                }
                tx.FireCompletion();
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionCommitted(1/*TraceSourceType.TraceSourceLtm*/, tx.TransactionTraceId);
                }
            }
            /*TransactionStatus */ get_Status(/*InternalTransaction*/ tx)
            {
                return 1/*TransactionStatus.Committed*/;
            }
            /*void */ PromotedTransactionOutcome(/*InternalTransaction*/ tx)
            {
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 7374308;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7439844,"m":[{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"EnterState","d":7374308,"h":4302341604,"f":32776},{"r":8422884,"p":[{"n":"tx","p":2786788}],"n":"get_Status","d":7374308,"h":8597308900,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"PromotedTransactionOutcome","d":7374308,"h":12892276196,"f":32772}],"c":[{"n":".ctor","o":"$ctor$4","d":7374308,"h":17187243492,"f":1}],"h":7374308}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCEnded; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedNonMSDTCCommitted`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedNonMSDTCIndoubt", ($self) => class TransactionStatePromotedNonMSDTCIndoubt extends $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCEnded
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                super.EnterState(tx);
                for(/*int*/ let i = 0; i < tx._phase0Volatiles._volatileEnlistmentCount; i++)
                {
                    $.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i)._twoPhaseState.InternalIndoubt($.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i));
                }
                for(/*int*/ let i = 0; i < tx._phase1Volatiles._volatileEnlistmentCount; i++)
                {
                    $.$spc.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i)._twoPhaseState.InternalIndoubt($.$spc.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i));
                }
                tx.FireCompletion();
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionInDoubt(1/*TraceSourceType.TraceSourceLtm*/, tx.TransactionTraceId);
                }
            }
            /*TransactionStatus */ get_Status(/*InternalTransaction*/ tx)
            {
                return 3/*TransactionStatus.InDoubt*/;
            }
            /*void */ ChangeStatePromotedPhase0(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionInDoubtException.Create$3(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionIndoubt, tx._innerException, tx.DistributedTxId);
            }
            /*void */ ChangeStatePromotedPhase1(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionInDoubtException.Create$3(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionIndoubt, tx._innerException, tx.DistributedTxId);
            }
            /*void */ PromotedTransactionOutcome(/*InternalTransaction*/ tx)
            {
                if ((null === tx._innerException) && (null !== tx.PromotedTransaction))
                {
                    tx._innerException = tx.PromotedTransaction.InnerException;
                }
                throw $.$stl.System.Transactions.TransactionInDoubtException.Create$3(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionIndoubt, tx._innerException, tx.DistributedTxId);
            }
            /*void */ CheckForFinishedTransaction(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionInDoubtException.Create$3(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionIndoubt, tx._innerException, tx.DistributedTxId);
            }
            /*void */ GetObjectData(/*InternalTransaction*/ tx, /*SerializationInfo*/ serializationInfo, /*StreamingContext*/ context)
            {
                throw $.$stl.System.Transactions.TransactionInDoubtException.Create$3(0/*TraceSourceType.TraceSourceBase*/, $.$stl.System.SR.TransactionIndoubt, tx._innerException, tx.DistributedTxId);
            }
            /*void */ CreateBlockingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.Create$2($.$stl.System.SR.TransactionAborted, tx._innerException, tx.DistributedTxId);
            }
            /*void */ CreateAbortingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.Create$2($.$stl.System.SR.TransactionAborted, tx._innerException, tx.DistributedTxId);
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 7505380;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7439844,"m":[{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"EnterState","d":7505380,"h":4302472676,"f":32776},{"r":8422884,"p":[{"n":"tx","p":2786788}],"n":"get_Status","d":7505380,"h":8597439972,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"ChangeStatePromotedPhase0","d":7505380,"h":12892407268,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"ChangeStatePromotedPhase1","d":7505380,"h":17187374564,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"PromotedTransactionOutcome","d":7505380,"h":21482341860,"f":32772},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"CheckForFinishedTransaction","d":7505380,"h":25777309156,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"serializationInfo","p":113967105},{"n":"context","p":114098177}],"n":"GetObjectData","d":7505380,"h":30072276452,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"CreateBlockingClone","d":7505380,"h":34367243748,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"CreateAbortingClone","d":7505380,"h":38662211044,"f":32776}],"c":[{"n":".ctor","o":"$ctor$4","d":7505380,"h":42957178340,"f":1}],"h":7505380}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedNonMSDTCEnded; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedNonMSDTCIndoubt`; }
        });
        
        $asm.$cls("$stl.System.Transactions.PreparingEnlistment", ($self) => class PreparingEnlistment extends $.$stl.System.Transactions.Enlistment
        {
            $ctor$7(/*InternalEnlistment*/ enlistment)
            {
                super.$ctor$1(enlistment);
                {
                }
                return this;
            }
            /*void */ Prepared()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "Prepared");
                    etwLog.EnlistmentPrepared(this._internalEnlistment);
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalEnlistment.SyncRoot)
                    {
                        this._internalEnlistment.State.Prepared(this._internalEnlistment);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalEnlistment.SyncRoot)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "Prepared");
                }
            }
            /*void */ ForceRollback()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "ForceRollback");
                    etwLog.EnlistmentForceRollback(this._internalEnlistment);
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalEnlistment.SyncRoot)
                    {
                        this._internalEnlistment.State.ForceRollback(this._internalEnlistment, null);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalEnlistment.SyncRoot)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "ForceRollback");
                }
            }
            /*void */ ForceRollback$1(/*Exception?*/ e)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "ForceRollback");
                    etwLog.EnlistmentForceRollback(this._internalEnlistment);
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalEnlistment.SyncRoot)
                    {
                        this._internalEnlistment.State.ForceRollback(this._internalEnlistment, e);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalEnlistment.SyncRoot)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "ForceRollback");
                }
            }
            /*byte[] */ RecoveryInformation()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "RecoveryInformation");
                }
                try
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter(this._internalEnlistment.SyncRoot)
                        {
                            return this._internalEnlistment.State.RecoveryInformation(this._internalEnlistment);
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit(this._internalEnlistment.SyncRoot)
                    }
                }
                finally
                {
                    {
                        if (etwLog.IsEnabled())
                        {
                            etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "RecoveryInformation");
                        }
                    }
                }
            }
            static $h = 3900900;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1738212,"m":[{"r":65537,"n":"Prepared","d":3900900,"h":8593835492,"f":1},{"r":65537,"n":"ForceRollback","d":3900900,"h":12888802788,"f":1},{"r":65537,"p":[{"n":"e","p":47251457}],"n":"ForceRollback","o":"@$1","d":3900900,"h":17183770084,"f":1},{"r":0,"n":"RecoveryInformation","d":3900900,"h":21478737380,"f":1}],"c":[{"p":[{"n":"enlistment","p":2721252}],"n":".ctor","o":"$ctor$7","d":3900900,"h":4298868196,"f":8}],"h":3900900}; }
            static get $b() { return $.$stl.System.Transactions.Enlistment; }
            static get $fullName() { return `System.Transactions.PreparingEnlistment`; }
        });
        
        $asm.$cls("$stl.System.Transactions.SinglePhaseEnlistment", ($self) => class SinglePhaseEnlistment extends $.$stl.System.Transactions.Enlistment
        {
            $ctor$7(/*InternalEnlistment*/ enlistment)
            {
                super.$ctor$1(enlistment);
                {
                }
                return this;
            }
            /*void */ Aborted()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "Aborted");
                    etwLog.EnlistmentAborted(this._internalEnlistment);
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalEnlistment.SyncRoot)
                    {
                        this._internalEnlistment.State.Aborted(this._internalEnlistment, null);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalEnlistment.SyncRoot)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "Aborted");
                }
            }
            /*void */ Aborted$1(/*Exception?*/ e)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "Aborted");
                    etwLog.EnlistmentAborted(this._internalEnlistment);
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalEnlistment.SyncRoot)
                    {
                        this._internalEnlistment.State.Aborted(this._internalEnlistment, e);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalEnlistment.SyncRoot)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "Aborted");
                }
            }
            /*void */ Committed()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "Committed");
                    etwLog.EnlistmentCommitted(this._internalEnlistment);
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalEnlistment.SyncRoot)
                    {
                        this._internalEnlistment.State.Committed(this._internalEnlistment);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalEnlistment.SyncRoot)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "Committed");
                }
            }
            /*void */ InDoubt()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "InDoubt");
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalEnlistment.SyncRoot)
                    {
                        if (etwLog.IsEnabled())
                        {
                            etwLog.EnlistmentInDoubt(this._internalEnlistment);
                        }
                        this._internalEnlistment.State.InDoubt(this._internalEnlistment, null);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalEnlistment.SyncRoot)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "InDoubt");
                }
            }
            /*void */ InDoubt$1(/*Exception?*/ e)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "InDoubt");
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalEnlistment.SyncRoot)
                    {
                        if (etwLog.IsEnabled())
                        {
                            etwLog.EnlistmentInDoubt(this._internalEnlistment);
                        }
                        this._internalEnlistment.State.InDoubt(this._internalEnlistment, e);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalEnlistment.SyncRoot)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "InDoubt");
                }
            }
            static $h = 4097508;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1738212,"m":[{"r":65537,"n":"Aborted","d":4097508,"h":8594032100,"f":1},{"r":65537,"p":[{"n":"e","p":47251457}],"n":"Aborted","o":"@$1","d":4097508,"h":12888999396,"f":1},{"r":65537,"n":"Committed","d":4097508,"h":17183966692,"f":1},{"r":65537,"n":"InDoubt","d":4097508,"h":21478933988,"f":1},{"r":65537,"p":[{"n":"e","p":47251457}],"n":"InDoubt","o":"@$1","d":4097508,"h":25773901284,"f":1}],"c":[{"p":[{"n":"enlistment","p":2721252}],"n":".ctor","o":"$ctor$7","d":4097508,"h":4299064804,"f":8}],"h":4097508}; }
            static get $b() { return $.$stl.System.Transactions.Enlistment; }
            static get $fullName() { return `System.Transactions.SinglePhaseEnlistment`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionEventArgs", ($self) => class TransactionEventArgs extends $.$spc.System.EventArgs
        {
            /*Transaction?*/ _transaction = null;
            /*Transaction? */ get Transaction()
            {
                return this._transaction;
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 4490724;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46989313,"p":[{"p":4294116,"g":{"r":0,"d":0,"h":12889392612,"f":1},"n":"Transaction","d":4490724,"h":8594425316,"f":1}],"l":[{"t":4294116,"n":"_transaction","d":4490724,"h":4299458020,"f":8}],"c":[{"n":".ctor","o":"$ctor$2","d":4490724,"h":17184359908,"f":1}],"h":4490724}; }
            static get $b() { return $.$spc.System.EventArgs; }
            static get $fullName() { return `System.Transactions.TransactionEventArgs`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionsEtwProvider", ($self) => class TransactionsEtwProvider extends $.$spc.System.Diagnostics.Tracing.EventSource
        {
            /*TransactionsEtwProvider*/ static Log = null;
            $ctor$8()
            {
                super.$ctor$4();
                {
                }
                return this;
            }
            /*EventKeywords*/ static ALL_KEYWORDS = -1n;
            /*int*/ static CONFIGURED_DEFAULT_TIMEOUT_ADJUSTED_EVENTID = 1;
            /*int*/ static ENLISTMENT_ABORTED_EVENTID = 2;
            /*int*/ static ENLISTMENT_COMMITTED_EVENTID = 3;
            /*int*/ static ENLISTMENT_DONE_EVENTID = 4;
            /*int*/ static ENLISTMENT_LTM_EVENTID = 5;
            /*int*/ static ENLISTMENT_FORCEROLLBACK_EVENTID = 6;
            /*int*/ static ENLISTMENT_INDOUBT_EVENTID = 7;
            /*int*/ static ENLISTMENT_PREPARED_EVENTID = 8;
            /*int*/ static EXCEPTION_CONSUMED_BASE_EVENTID = 9;
            /*int*/ static EXCEPTION_CONSUMED_LTM_EVENTID = 10;
            /*int*/ static METHOD_ENTER_LTM_EVENTID = 11;
            /*int*/ static METHOD_EXIT_LTM_EVENTID = 12;
            /*int*/ static METHOD_ENTER_BASE_EVENTID = 13;
            /*int*/ static METHOD_EXIT_BASE_EVENTID = 14;
            /*int*/ static METHOD_ENTER_OLETX_EVENTID = 15;
            /*int*/ static METHOD_EXIT_OLETX_EVENTID = 16;
            /*int*/ static TRANSACTION_ABORTED_LTM_EVENTID = 17;
            /*int*/ static TRANSACTION_CLONECREATE_EVENTID = 18;
            /*int*/ static TRANSACTION_COMMIT_LTM_EVENTID = 19;
            /*int*/ static TRANSACTION_COMMITTED_LTM_EVENTID = 20;
            /*int*/ static TRANSACTION_CREATED_LTM_EVENTID = 21;
            /*int*/ static TRANSACTION_DEPENDENT_CLONE_COMPLETE_LTM_EVENTID = 22;
            /*int*/ static TRANSACTION_EXCEPTION_LTM_EVENTID = 23;
            /*int*/ static TRANSACTION_EXCEPTION_BASE_EVENTID = 24;
            /*int*/ static TRANSACTION_INDOUBT_LTM_EVENTID = 25;
            /*int*/ static TRANSACTION_INVALID_OPERATION_EVENTID = 26;
            /*int*/ static TRANSACTION_PROMOTED_EVENTID = 27;
            /*int*/ static TRANSACTION_ROLLBACK_LTM_EVENTID = 28;
            /*int*/ static TRANSACTION_SERIALIZED_EVENTID = 29;
            /*int*/ static TRANSACTION_TIMEOUT_EVENTID = 30;
            /*int*/ static TRANSACTIONMANAGER_RECOVERY_COMPLETE_EVENTID = 31;
            /*int*/ static TRANSACTIONMANAGER_REENLIST_EVENTID = 32;
            /*int*/ static TRANSACTIONSCOPE_CREATED_EVENTID = 33;
            /*int*/ static TRANSACTIONSCOPE_CURRENT_CHANGED_EVENTID = 34;
            /*int*/ static TRANSACTIONSCOPE_DISPOSED_EVENTID = 35;
            /*int*/ static TRANSACTIONSCOPE_INCOMPLETE_EVENTID = 36;
            /*int*/ static INTERNAL_ERROR_EVENTID = 37;
            /*int*/ static TRANSACTIONSCOPE_NESTED_INCORRECTLY_EVENTID = 38;
            /*int*/ static TRANSACTIONSCOPE_TIMEOUT_EVENTID = 39;
            /*int*/ static TRANSACTIONSTATE_ENLIST_EVENTID = 40;
            /*int*/ static TRANSACTION_COMMIT_OLETX_EVENTID = 41;
            /*int*/ static TRANSACTION_ROLLBACK_OLETX_EVENTID = 42;
            /*int*/ static EXCEPTION_CONSUMED_OLETX_EVENTID = 43;
            /*int*/ static TRANSACTION_COMMITTED_OLETX_EVENTID = 44;
            /*int*/ static TRANSACTION_ABORTED_OLETX_EVENTID = 45;
            /*int*/ static TRANSACTION_INDOUBT_OLETX_EVENTID = 46;
            /*int*/ static TRANSACTION_DEPENDENT_CLONE_COMPLETE_OLETX_EVENTID = 47;
            /*int*/ static TRANSACTION_DEPENDENT_CLONE_CREATE_LTM_EVENTID = 48;
            /*int*/ static TRANSACTION_DEPENDENT_CLONE_CREATE_OLETX_EVENTID = 49;
            /*int*/ static TRANSACTION_DESERIALIZED_EVENTID = 50;
            /*int*/ static TRANSACTION_CREATED_OLETX_EVENTID = 51;
            /*int*/ static ENLISTMENT_OLETX_EVENTID = 52;
            /*int*/ static ENLISTMENT_CALLBACK_POSITIVE_EVENTID = 53;
            /*int*/ static ENLISTMENT_CALLBACK_NEGATIVE_EVENTID = 54;
            /*int*/ static ENLISTMENT_CREATED_LTM_EVENTID = 55;
            /*int*/ static ENLISTMENT_CREATED_OLETX_EVENTID = 56;
            /*int*/ static TRANSACTIONMANAGER_CREATE_OLETX_EVENTID = 57;
            /*string*/ static NullInstance = null;
            static /*string */ IdOf(/*object?*/ value)
            {
                return value !== null ? $.$spc.System.Object.GetType.call(value).Name + "#" + $.$stl.System.Transactions.TransactionsEtwProvider.GetHashCode$1(value) : "(null)"/*NullInstance*/;
            }
            static /*int */ GetHashCode$1(/*object?*/ value)
            {
                const $t1 = value;
                return $.$ifnn($t1, ($t) => $.$spc.System.Object.GetHashCode.call($t)) ?? 0;
            }
            /*void */ TransactionCreated(/*TraceSourceType*/ traceSource, /*TransactionTraceIdentifier*/ txTraceId, /*string?*/ type)
            {
                if (this.IsEnabled$1(4/*EventLevel.Informational*/, -1n))
                {
                    if (traceSource === 1/*TraceSourceType.TraceSourceLtm*/)
                    {
                        this.TransactionCreatedLtm(txTraceId.TransactionIdentifier, type);
                    }
                    else if (traceSource === 2/*TraceSourceType.TraceSourceOleTx*/)
                    {
                        this.TransactionCreatedOleTx(txTraceId.TransactionIdentifier, type);
                    }
                }
            }
            /*void */ TransactionCreatedLtm(/*string*/ transactionIdentifier, /*string?*/ type)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionIdentifier);
                this.WriteEvent$8(21/*TRANSACTION_CREATED_LTM_EVENTID*/, transactionIdentifier, type);
            }
            /*void */ TransactionCreatedOleTx(/*string*/ transactionIdentifier, /*string?*/ type)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionIdentifier);
                this.WriteEvent$8(51/*TRANSACTION_CREATED_OLETX_EVENTID*/, transactionIdentifier, type);
            }
            /*void */ TransactionCloneCreate(/*Transaction*/ transaction, /*string*/ type)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$stl.System.Transactions.Transaction.op_Inequality(transaction, null), "Transaction needed for the ETW event.");
                if (this.IsEnabled$1(4/*EventLevel.Informational*/, -1n))
                {
                    if ($.$stl.System.Transactions.Transaction.op_Inequality(transaction, null) && $.$spc.System.String.op_Inequality(transaction.TransactionTraceId.TransactionIdentifier, null))
                    {
                        this.TransactionCloneCreate$1(transaction.TransactionTraceId.TransactionIdentifier, type);
                    }
                    else 
                    {
                        this.TransactionCloneCreate$1($.$spc.System.String.Empty, type);
                    }
                }
            }
            /*void */ TransactionCloneCreate$1(/*string*/ transactionIdentifier, /*string*/ type)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionIdentifier);
                this.WriteEvent$8(18/*TRANSACTION_CLONECREATE_EVENTID*/, transactionIdentifier, type);
            }
            /*void */ TransactionSerialized(/*TransactionTraceIdentifier*/ transactionTraceId)
            {
                if (this.IsEnabled$1(4/*EventLevel.Informational*/, -1n))
                {
                    this.TransactionSerialized$1(transactionTraceId.TransactionIdentifier);
                }
            }
            /*void */ TransactionSerialized$1(/*string*/ transactionIdentifier)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionIdentifier);
                this.WriteEvent$7(29/*TRANSACTION_SERIALIZED_EVENTID*/, transactionIdentifier);
            }
            /*void */ TransactionDeserialized(/*TransactionTraceIdentifier*/ transactionTraceId)
            {
                if (this.IsEnabled$1(5/*EventLevel.Verbose*/, -1n))
                {
                    this.TransactionDeserialized$1(transactionTraceId.TransactionIdentifier);
                }
            }
            /*void */ TransactionDeserialized$1(/*string*/ transactionIdentifier)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionIdentifier);
                this.WriteEvent$7(50/*TRANSACTION_DESERIALIZED_EVENTID*/, transactionIdentifier);
            }
            /*void */ TransactionExceptionTrace(/*TraceSourceType*/ traceSource, /*TransactionExceptionType*/ type, /*string?*/ message, /*string?*/ innerExceptionStr)
            {
                if (this.IsEnabled$1(2/*EventLevel.Error*/, -1n))
                {
                    if (traceSource === 0/*TraceSourceType.TraceSourceBase*/)
                    {
                        this.TransactionExceptionBase($.$spc.System.Enum.ToStringT($.$stl.System.Transactions.TransactionExceptionType, $.$spc.System.UInt32, type), message, innerExceptionStr);
                    }
                    else 
                    {
                        this.TransactionExceptionLtm($.$spc.System.Enum.ToStringT($.$stl.System.Transactions.TransactionExceptionType, $.$spc.System.UInt32, type), message, innerExceptionStr);
                    }
                }
            }
            /*void */ TransactionExceptionTrace$1(/*TransactionExceptionType*/ type, /*string?*/ message, /*string?*/ innerExceptionStr)
            {
                if (this.IsEnabled$1(2/*EventLevel.Error*/, -1n))
                {
                    this.TransactionExceptionLtm($.$spc.System.Enum.ToStringT($.$stl.System.Transactions.TransactionExceptionType, $.$spc.System.UInt32, type), message, innerExceptionStr);
                }
            }
            /*void */ TransactionExceptionBase(/*string?*/ type, /*string?*/ message, /*string?*/ innerExceptionStr)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$9(24/*TRANSACTION_EXCEPTION_BASE_EVENTID*/, type, message, innerExceptionStr);
            }
            /*void */ TransactionExceptionLtm(/*string?*/ type, /*string?*/ message, /*string?*/ innerExceptionStr)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$9(23/*TRANSACTION_EXCEPTION_LTM_EVENTID*/, type, message, innerExceptionStr);
            }
            /*void */ InvalidOperation(/*string?*/ type, /*string?*/ operation)
            {
                if (this.IsEnabled$1(2/*EventLevel.Error*/, -1n))
                {
                    this.TransactionInvalidOperation($.$spc.System.String.Empty, type, operation);
                }
            }
            /*void */ TransactionInvalidOperation(/*string?*/ transactionIdentifier, /*string?*/ type, /*string?*/ operation)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$9(26/*TRANSACTION_INVALID_OPERATION_EVENTID*/, transactionIdentifier, type, operation);
            }
            /*void */ TransactionRollback(/*TraceSourceType*/ traceSource, /*TransactionTraceIdentifier*/ txTraceId, /*string?*/ type)
            {
                if (this.IsEnabled$1(3/*EventLevel.Warning*/, -1n))
                {
                    if (traceSource === 1/*TraceSourceType.TraceSourceLtm*/)
                    {
                        this.TransactionRollbackLtm(txTraceId.TransactionIdentifier, type);
                    }
                    else if (traceSource === 2/*TraceSourceType.TraceSourceOleTx*/)
                    {
                        this.TransactionRollbackOleTx(txTraceId.TransactionIdentifier, type);
                    }
                }
            }
            /*void */ TransactionRollbackLtm(/*string*/ transactionIdentifier, /*string?*/ type)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionIdentifier);
                this.WriteEvent$8(28/*TRANSACTION_ROLLBACK_LTM_EVENTID*/, transactionIdentifier, type);
            }
            /*void */ TransactionRollbackOleTx(/*string*/ transactionIdentifier, /*string?*/ type)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionIdentifier);
                this.WriteEvent$8(42/*TRANSACTION_ROLLBACK_OLETX_EVENTID*/, transactionIdentifier, type);
            }
            /*void */ TransactionDependentCloneCreate(/*TraceSourceType*/ traceSource, /*TransactionTraceIdentifier*/ txTraceId, /*DependentCloneOption*/ option)
            {
                if (this.IsEnabled$1(4/*EventLevel.Informational*/, -1n))
                {
                    if (traceSource === 1/*TraceSourceType.TraceSourceLtm*/)
                    {
                        this.TransactionDependentCloneCreateLtm(txTraceId.TransactionIdentifier, $.$spc.System.Enum.ToStringT($.$stl.System.Transactions.DependentCloneOption, $.$spc.System.UInt32, option));
                    }
                    else if (traceSource === 2/*TraceSourceType.TraceSourceOleTx*/)
                    {
                        this.TransactionDependentCloneCreateOleTx(txTraceId.TransactionIdentifier, $.$spc.System.Enum.ToStringT($.$stl.System.Transactions.DependentCloneOption, $.$spc.System.UInt32, option));
                    }
                }
            }
            /*void */ TransactionDependentCloneCreateLtm(/*string*/ transactionIdentifier, /*string?*/ option)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionIdentifier);
                this.WriteEvent$8(48/*TRANSACTION_DEPENDENT_CLONE_CREATE_LTM_EVENTID*/, transactionIdentifier, option);
            }
            /*void */ TransactionDependentCloneCreateOleTx(/*string*/ transactionIdentifier, /*string?*/ option)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionIdentifier);
                this.WriteEvent$8(49/*TRANSACTION_DEPENDENT_CLONE_CREATE_OLETX_EVENTID*/, transactionIdentifier, option);
            }
            /*void */ TransactionDependentCloneComplete(/*TraceSourceType*/ traceSource, /*TransactionTraceIdentifier*/ txTraceId, /*string?*/ type)
            {
                if (this.IsEnabled$1(4/*EventLevel.Informational*/, -1n))
                {
                    if (traceSource === 1/*TraceSourceType.TraceSourceLtm*/)
                    {
                        this.TransactionDependentCloneCompleteLtm(txTraceId.TransactionIdentifier, type);
                    }
                    else if (traceSource === 2/*TraceSourceType.TraceSourceOleTx*/)
                    {
                        this.TransactionDependentCloneCompleteOleTx(txTraceId.TransactionIdentifier, type);
                    }
                }
            }
            /*void */ TransactionDependentCloneCompleteLtm(/*string*/ transactionIdentifier, /*string?*/ type)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionIdentifier);
                this.WriteEvent$8(22/*TRANSACTION_DEPENDENT_CLONE_COMPLETE_LTM_EVENTID*/, transactionIdentifier, type);
            }
            /*void */ TransactionDependentCloneCompleteOleTx(/*string*/ transactionIdentifier, /*string?*/ type)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionIdentifier);
                this.WriteEvent$8(47/*TRANSACTION_DEPENDENT_CLONE_COMPLETE_OLETX_EVENTID*/, transactionIdentifier, type);
            }
            /*void */ TransactionCommit(/*TraceSourceType*/ traceSource, /*TransactionTraceIdentifier*/ txTraceId, /*string?*/ type)
            {
                if (this.IsEnabled$1(5/*EventLevel.Verbose*/, -1n))
                {
                    if (traceSource === 1/*TraceSourceType.TraceSourceLtm*/)
                    {
                        this.TransactionCommitLtm(txTraceId.TransactionIdentifier, type);
                    }
                    else if (traceSource === 2/*TraceSourceType.TraceSourceOleTx*/)
                    {
                        this.TransactionCommitOleTx(txTraceId.TransactionIdentifier, type);
                    }
                }
            }
            /*void */ TransactionCommitLtm(/*string*/ transactionIdentifier, /*string?*/ type)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionIdentifier);
                this.WriteEvent$8(19/*TRANSACTION_COMMIT_LTM_EVENTID*/, transactionIdentifier, type);
            }
            /*void */ TransactionCommitOleTx(/*string*/ transactionIdentifier, /*string?*/ type)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionIdentifier);
                this.WriteEvent$8(41/*TRANSACTION_COMMIT_OLETX_EVENTID*/, transactionIdentifier, type);
            }
            /*void */ EnlistmentStatus(/*TraceSourceType*/ traceSource, /*EnlistmentTraceIdentifier*/ enlistmentTraceId, /*NotificationCall*/ notificationCall)
            {
                if (this.IsEnabled$1(5/*EventLevel.Verbose*/, -1n))
                {
                    if (traceSource === 1/*TraceSourceType.TraceSourceLtm*/)
                    {
                        this.EnlistmentStatusLtm(enlistmentTraceId.EnlistmentIdentifier, $.$spc.System.Enum.ToStringT($.$stl.System.Transactions.NotificationCall, $.$spc.System.UInt32, notificationCall));
                    }
                    else if (traceSource === 2/*TraceSourceType.TraceSourceOleTx*/)
                    {
                        this.EnlistmentStatusOleTx(enlistmentTraceId.EnlistmentIdentifier, $.$spc.System.Enum.ToStringT($.$stl.System.Transactions.NotificationCall, $.$spc.System.UInt32, notificationCall));
                    }
                }
            }
            /*void */ EnlistmentStatusLtm(/*int*/ enlistmentIdentifier, /*string*/ notificationCall)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$14(5/*ENLISTMENT_LTM_EVENTID*/, enlistmentIdentifier, notificationCall);
            }
            /*void */ EnlistmentStatusOleTx(/*int*/ enlistmentIdentifier, /*string*/ notificationCall)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$14(52/*ENLISTMENT_OLETX_EVENTID*/, enlistmentIdentifier, notificationCall);
            }
            /*void */ EnlistmentCreated(/*TraceSourceType*/ traceSource, /*EnlistmentTraceIdentifier*/ enlistmentTraceId, /*EnlistmentType*/ enlistmentType, /*EnlistmentOptions*/ enlistmentOptions)
            {
                if (this.IsEnabled$1(4/*EventLevel.Informational*/, -1n))
                {
                    if (traceSource === 1/*TraceSourceType.TraceSourceLtm*/)
                    {
                        this.EnlistmentCreatedLtm(enlistmentTraceId.EnlistmentIdentifier, $.$spc.System.Enum.ToStringT($.$stl.System.Transactions.EnlistmentType, $.$spc.System.UInt32, enlistmentType), $.$spc.System.Enum.ToStringT($.$stl.System.Transactions.EnlistmentOptions, $.$spc.System.UInt32, enlistmentOptions));
                    }
                    else if (traceSource === 2/*TraceSourceType.TraceSourceOleTx*/)
                    {
                        this.EnlistmentCreatedOleTx(enlistmentTraceId.EnlistmentIdentifier, $.$spc.System.Enum.ToStringT($.$stl.System.Transactions.EnlistmentType, $.$spc.System.UInt32, enlistmentType), $.$spc.System.Enum.ToStringT($.$stl.System.Transactions.EnlistmentOptions, $.$spc.System.UInt32, enlistmentOptions));
                    }
                }
            }
            /*void */ EnlistmentCreatedLtm(/*int*/ enlistmentIdentifier, /*string*/ enlistmentType, /*string*/ enlistmentOptions)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$17(55/*ENLISTMENT_CREATED_LTM_EVENTID*/, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive), [ $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$3(enlistmentIdentifier), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(enlistmentType), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(enlistmentOptions) ], null, null));
            }
            /*void */ EnlistmentCreatedOleTx(/*int*/ enlistmentIdentifier, /*string*/ enlistmentType, /*string*/ enlistmentOptions)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$17(56/*ENLISTMENT_CREATED_OLETX_EVENTID*/, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive), [ $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$3(enlistmentIdentifier), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(enlistmentType), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(enlistmentOptions) ], null, null));
            }
            /*void */ EnlistmentDone(/*InternalEnlistment*/ enlistment)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(enlistment !== null, "Enlistment needed for the ETW event.");
                if (this.IsEnabled$1(5/*EventLevel.Verbose*/, -1n))
                {
                    if (enlistment !== null && enlistment.EnlistmentTraceId.EnlistmentIdentifier !== 0)
                    {
                        this.EnlistmentDone$1(enlistment.EnlistmentTraceId.EnlistmentIdentifier);
                    }
                    else 
                    {
                        this.EnlistmentDone$1(0);
                    }
                }
            }
            /*void */ EnlistmentDone$1(/*int*/ enlistmentIdentifier)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$1(4/*ENLISTMENT_DONE_EVENTID*/, enlistmentIdentifier);
            }
            /*void */ EnlistmentPrepared(/*InternalEnlistment*/ enlistment)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(enlistment !== null, "Enlistment needed for the ETW event.");
                if (this.IsEnabled$1(5/*EventLevel.Verbose*/, -1n))
                {
                    if (enlistment !== null && enlistment.EnlistmentTraceId.EnlistmentIdentifier !== 0)
                    {
                        this.EnlistmentPrepared$1(enlistment.EnlistmentTraceId.EnlistmentIdentifier);
                    }
                    else 
                    {
                        this.EnlistmentPrepared$1(0);
                    }
                }
            }
            /*void */ EnlistmentPrepared$1(/*int*/ enlistmentIdentifier)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$1(8/*ENLISTMENT_PREPARED_EVENTID*/, enlistmentIdentifier);
            }
            /*void */ EnlistmentForceRollback(/*InternalEnlistment*/ enlistment)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(enlistment !== null, "Enlistment needed for the ETW event.");
                if (this.IsEnabled$1(3/*EventLevel.Warning*/, -1n))
                {
                    if (enlistment !== null && enlistment.EnlistmentTraceId.EnlistmentIdentifier !== 0)
                    {
                        this.EnlistmentForceRollback$1(enlistment.EnlistmentTraceId.EnlistmentIdentifier);
                    }
                    else 
                    {
                        this.EnlistmentForceRollback$1(0);
                    }
                }
            }
            /*void */ EnlistmentForceRollback$1(/*int*/ enlistmentIdentifier)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$1(6/*ENLISTMENT_FORCEROLLBACK_EVENTID*/, enlistmentIdentifier);
            }
            /*void */ EnlistmentAborted(/*InternalEnlistment*/ enlistment)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(enlistment !== null, "Enlistment needed for the ETW event.");
                if (this.IsEnabled$1(3/*EventLevel.Warning*/, -1n))
                {
                    if (enlistment !== null && enlistment.EnlistmentTraceId.EnlistmentIdentifier !== 0)
                    {
                        this.EnlistmentAborted$1(enlistment.EnlistmentTraceId.EnlistmentIdentifier);
                    }
                    else 
                    {
                        this.EnlistmentAborted$1(0);
                    }
                }
            }
            /*void */ EnlistmentAborted$1(/*int*/ enlistmentIdentifier)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$1(2/*ENLISTMENT_ABORTED_EVENTID*/, enlistmentIdentifier);
            }
            /*void */ EnlistmentCommitted(/*InternalEnlistment*/ enlistment)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(enlistment !== null, "Enlistment needed for the ETW event.");
                if (this.IsEnabled$1(5/*EventLevel.Verbose*/, -1n))
                {
                    if (enlistment !== null && enlistment.EnlistmentTraceId.EnlistmentIdentifier !== 0)
                    {
                        this.EnlistmentCommitted$1(enlistment.EnlistmentTraceId.EnlistmentIdentifier);
                    }
                    else 
                    {
                        this.EnlistmentCommitted$1(0);
                    }
                }
            }
            /*void */ EnlistmentCommitted$1(/*int*/ enlistmentIdentifier)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$1(3/*ENLISTMENT_COMMITTED_EVENTID*/, enlistmentIdentifier);
            }
            /*void */ EnlistmentInDoubt(/*InternalEnlistment*/ enlistment)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(enlistment !== null, "Enlistment needed for the ETW event.");
                if (this.IsEnabled$1(3/*EventLevel.Warning*/, -1n))
                {
                    if (enlistment !== null && enlistment.EnlistmentTraceId.EnlistmentIdentifier !== 0)
                    {
                        this.EnlistmentInDoubt$1(enlistment.EnlistmentTraceId.EnlistmentIdentifier);
                    }
                    else 
                    {
                        this.EnlistmentInDoubt$1(0);
                    }
                }
            }
            /*void */ EnlistmentInDoubt$1(/*int*/ enlistmentIdentifier)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$1(7/*ENLISTMENT_INDOUBT_EVENTID*/, enlistmentIdentifier);
            }
            /*void */ EnlistmentCallbackPositive(/*EnlistmentTraceIdentifier*/ enlistmentTraceIdentifier, /*EnlistmentCallback*/ callback)
            {
                if (this.IsEnabled$1(5/*EventLevel.Verbose*/, -1n))
                {
                    this.EnlistmentCallbackPositive$1(enlistmentTraceIdentifier.EnlistmentIdentifier, $.$spc.System.Enum.ToStringT($.$stl.System.Transactions.EnlistmentCallback, $.$spc.System.UInt32, callback));
                }
            }
            /*void */ EnlistmentCallbackPositive$1(/*int*/ enlistmentIdentifier, /*string?*/ callback)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$14(53/*ENLISTMENT_CALLBACK_POSITIVE_EVENTID*/, enlistmentIdentifier, callback);
            }
            /*void */ EnlistmentCallbackNegative(/*EnlistmentTraceIdentifier*/ enlistmentTraceIdentifier, /*EnlistmentCallback*/ callback)
            {
                if (this.IsEnabled$1(3/*EventLevel.Warning*/, -1n))
                {
                    this.EnlistmentCallbackNegative$1(enlistmentTraceIdentifier.EnlistmentIdentifier, $.$spc.System.Enum.ToStringT($.$stl.System.Transactions.EnlistmentCallback, $.$spc.System.UInt32, callback));
                }
            }
            /*void */ EnlistmentCallbackNegative$1(/*int*/ enlistmentIdentifier, /*string?*/ callback)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$14(54/*ENLISTMENT_CALLBACK_NEGATIVE_EVENTID*/, enlistmentIdentifier, callback);
            }
            /*void */ MethodEnter(/*TraceSourceType*/ traceSource, /*object?*/ thisOrContextObject, /*string?*/ methodname)
            {
                if (this.IsEnabled$1(5/*EventLevel.Verbose*/, -1n))
                {
                    if (traceSource === 1/*TraceSourceType.TraceSourceLtm*/)
                    {
                        this.MethodEnterTraceLtm($.$stl.System.Transactions.TransactionsEtwProvider.IdOf(thisOrContextObject), methodname);
                    }
                    else if (traceSource === 0/*TraceSourceType.TraceSourceBase*/)
                    {
                        this.MethodEnterTraceBase($.$stl.System.Transactions.TransactionsEtwProvider.IdOf(thisOrContextObject), methodname);
                    }
                    else if (traceSource === 2/*TraceSourceType.TraceSourceOleTx*/)
                    {
                        this.MethodEnterTraceDistributed($.$stl.System.Transactions.TransactionsEtwProvider.IdOf(thisOrContextObject), methodname);
                    }
                }
            }
            /*void */ MethodEnter$1(/*TraceSourceType*/ traceSource, /*string?*/ methodname)
            {
                if (this.IsEnabled$1(5/*EventLevel.Verbose*/, -1n))
                {
                    if (traceSource === 1/*TraceSourceType.TraceSourceLtm*/)
                    {
                        this.MethodEnterTraceLtm($.$spc.System.String.Empty, methodname);
                    }
                    else if (traceSource === 0/*TraceSourceType.TraceSourceBase*/)
                    {
                        this.MethodEnterTraceBase($.$spc.System.String.Empty, methodname);
                    }
                    else if (traceSource === 2/*TraceSourceType.TraceSourceOleTx*/)
                    {
                        this.MethodEnterTraceDistributed($.$spc.System.String.Empty, methodname);
                    }
                }
            }
            /*void */ MethodEnterTraceLtm(/*string*/ thisOrContextObject, /*string?*/ methodname)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$8(11/*METHOD_ENTER_LTM_EVENTID*/, thisOrContextObject, methodname);
            }
            /*void */ MethodEnterTraceBase(/*string*/ thisOrContextObject, /*string?*/ methodname)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$8(13/*METHOD_ENTER_BASE_EVENTID*/, thisOrContextObject, methodname);
            }
            /*void */ MethodEnterTraceDistributed(/*string*/ thisOrContextObject, /*string?*/ methodname)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$8(15/*METHOD_ENTER_OLETX_EVENTID*/, thisOrContextObject, methodname);
            }
            /*void */ MethodExit(/*TraceSourceType*/ traceSource, /*object?*/ thisOrContextObject, /*string?*/ methodname)
            {
                if (this.IsEnabled$1(5/*EventLevel.Verbose*/, -1n))
                {
                    if (traceSource === 1/*TraceSourceType.TraceSourceLtm*/)
                    {
                        this.MethodExitTraceLtm($.$stl.System.Transactions.TransactionsEtwProvider.IdOf(thisOrContextObject), methodname);
                    }
                    else if (traceSource === 0/*TraceSourceType.TraceSourceBase*/)
                    {
                        this.MethodExitTraceBase($.$stl.System.Transactions.TransactionsEtwProvider.IdOf(thisOrContextObject), methodname);
                    }
                    else if (traceSource === 2/*TraceSourceType.TraceSourceOleTx*/)
                    {
                        this.MethodExitTraceDistributed($.$stl.System.Transactions.TransactionsEtwProvider.IdOf(thisOrContextObject), methodname);
                    }
                }
            }
            /*void */ MethodExit$1(/*TraceSourceType*/ traceSource, /*string?*/ methodname)
            {
                if (this.IsEnabled$1(5/*EventLevel.Verbose*/, -1n))
                {
                    if (traceSource === 1/*TraceSourceType.TraceSourceLtm*/)
                    {
                        this.MethodExitTraceLtm($.$spc.System.String.Empty, methodname);
                    }
                    else if (traceSource === 0/*TraceSourceType.TraceSourceBase*/)
                    {
                        this.MethodExitTraceBase($.$spc.System.String.Empty, methodname);
                    }
                    else if (traceSource === 2/*TraceSourceType.TraceSourceOleTx*/)
                    {
                        this.MethodExitTraceDistributed($.$spc.System.String.Empty, methodname);
                    }
                }
            }
            /*void */ MethodExitTraceLtm(/*string*/ thisOrContextObject, /*string?*/ methodname)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$8(12/*METHOD_EXIT_LTM_EVENTID*/, thisOrContextObject, methodname);
            }
            /*void */ MethodExitTraceBase(/*string*/ thisOrContextObject, /*string?*/ methodname)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$8(14/*METHOD_EXIT_BASE_EVENTID*/, thisOrContextObject, methodname);
            }
            /*void */ MethodExitTraceDistributed(/*string*/ thisOrContextObject, /*string?*/ methodname)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$8(16/*METHOD_EXIT_OLETX_EVENTID*/, thisOrContextObject, methodname);
            }
            /*void */ ExceptionConsumed(/*TraceSourceType*/ traceSource, /*Exception*/ exception)
            {
                if (this.IsEnabled$1(5/*EventLevel.Verbose*/, -1n))
                {
                    switch(traceSource)
                    {
                        case 0/*TraceSourceType.TraceSourceBase*/:
                        this.ExceptionConsumedBase($.$spc.System.Exception.ToString.call(exception));
                        return;
                        case 1/*TraceSourceType.TraceSourceLtm*/:
                        this.ExceptionConsumedLtm($.$spc.System.Exception.ToString.call(exception));
                        return;
                        case 2/*TraceSourceType.TraceSourceOleTx*/:
                        this.ExceptionConsumedOleTx($.$spc.System.Exception.ToString.call(exception));
                        return;
                    }
                }
            }
            /*void */ ExceptionConsumed$1(/*Exception*/ exception)
            {
                if (this.IsEnabled$1(5/*EventLevel.Verbose*/, -1n))
                {
                    this.ExceptionConsumedLtm($.$spc.System.Exception.ToString.call(exception));
                }
            }
            /*void */ ExceptionConsumedBase(/*string*/ exceptionStr)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$7(9/*EXCEPTION_CONSUMED_BASE_EVENTID*/, exceptionStr);
            }
            /*void */ ExceptionConsumedLtm(/*string*/ exceptionStr)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$7(10/*EXCEPTION_CONSUMED_LTM_EVENTID*/, exceptionStr);
            }
            /*void */ ExceptionConsumedOleTx(/*string*/ exceptionStr)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$7(43/*EXCEPTION_CONSUMED_OLETX_EVENTID*/, exceptionStr);
            }
            /*void */ OleTxTransactionManagerCreate(/*Type*/ tmType, /*string?*/ nodeName)
            {
                if (this.IsEnabled$1(5/*EventLevel.Verbose*/, -1n))
                {
                    this.OleTxTransactionManagerCreate$1($.$spc.System.Type.ToString.call(tmType), nodeName);
                }
            }
            /*void */ OleTxTransactionManagerCreate$1(/*string*/ tmType, /*string?*/ nodeName)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$8(57/*TRANSACTIONMANAGER_CREATE_OLETX_EVENTID*/, tmType, nodeName);
            }
            /*void */ TransactionManagerReenlist(/*Guid*/ resourceManagerID)
            {
                if (this.IsEnabled$1(4/*EventLevel.Informational*/, -1n))
                {
                    this.TransactionManagerReenlistTrace($.$spc.System.Guid.ToString.call(resourceManagerID));
                }
            }
            /*void */ TransactionManagerReenlistTrace(/*string*/ rmID)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$7(32/*TRANSACTIONMANAGER_REENLIST_EVENTID*/, rmID);
            }
            /*void */ TransactionManagerRecoveryComplete(/*Guid*/ resourceManagerID)
            {
                if (this.IsEnabled$1(4/*EventLevel.Informational*/, -1n))
                {
                    this.TransactionManagerRecoveryComplete$1($.$spc.System.Guid.ToString.call(resourceManagerID));
                }
            }
            /*void */ TransactionManagerRecoveryComplete$1(/*string*/ rmID)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$7(31/*TRANSACTIONMANAGER_RECOVERY_COMPLETE_EVENTID*/, rmID);
            }
            /*void */ ConfiguredDefaultTimeoutAdjusted()
            {
                if (this.IsEnabled$1(3/*EventLevel.Warning*/, -1n))
                {
                    this.ConfiguredDefaultTimeoutAdjustedTrace();
                }
            }
            /*void */ ConfiguredDefaultTimeoutAdjustedTrace()
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent(1/*CONFIGURED_DEFAULT_TIMEOUT_ADJUSTED_EVENTID*/);
            }
            /*void */ TransactionScopeCreated(/*TransactionTraceIdentifier*/ transactionID, /*TransactionScopeResult*/ transactionScopeResult)
            {
                if (this.IsEnabled$1(4/*EventLevel.Informational*/, -1n))
                {
                    this.TransactionScopeCreated$1(transactionID.TransactionIdentifier ?? $.$spc.System.String.Empty, transactionScopeResult);
                }
            }
            /*void */ TransactionScopeCreated$1(/*string*/ transactionID, /*TransactionScopeResult*/ transactionScopeResult)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionID);
                this.WriteEvent$17(33/*TRANSACTIONSCOPE_CREATED_EVENTID*/, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive), [ $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(transactionID), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$19($.$box(transactionScopeResult, $.$stl.System.Transactions.TransactionScopeResult)) ], null, null));
            }
            /*void */ TransactionScopeCurrentChanged(/*TransactionTraceIdentifier*/ currenttransactionID, /*TransactionTraceIdentifier*/ newtransactionID)
            {
                if (this.IsEnabled$1(3/*EventLevel.Warning*/, -1n))
                {
                    /*string*/ let currentId = $.$spc.System.String.Empty;
                    /*string*/ let newId = $.$spc.System.String.Empty;
                    if ($.$spc.System.String.op_Inequality(currenttransactionID.TransactionIdentifier, null))
                    {
                        currentId = $.$spc.System.String.ToString.call(currenttransactionID.TransactionIdentifier);
                    }
                    if ($.$spc.System.String.op_Inequality(newtransactionID.TransactionIdentifier, null))
                    {
                        newId = $.$spc.System.String.ToString.call(newtransactionID.TransactionIdentifier);
                    }
                    this.TransactionScopeCurrentChanged$1(currentId, newId);
                }
            }
            /*void */ TransactionScopeCurrentChanged$1(/*string*/ currenttransactionID, /*string*/ newtransactionID)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(newtransactionID);
                this.WriteEvent$8(34/*TRANSACTIONSCOPE_CURRENT_CHANGED_EVENTID*/, currenttransactionID, newtransactionID);
            }
            /*void */ TransactionScopeNestedIncorrectly(/*TransactionTraceIdentifier*/ transactionID)
            {
                if (this.IsEnabled$1(3/*EventLevel.Warning*/, -1n))
                {
                    this.TransactionScopeNestedIncorrectly$1(transactionID.TransactionIdentifier ?? $.$spc.System.String.Empty);
                }
            }
            /*void */ TransactionScopeNestedIncorrectly$1(/*string*/ transactionID)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionID);
                this.WriteEvent$7(38/*TRANSACTIONSCOPE_NESTED_INCORRECTLY_EVENTID*/, transactionID);
            }
            /*void */ TransactionScopeDisposed(/*TransactionTraceIdentifier*/ transactionID)
            {
                if (this.IsEnabled$1(4/*EventLevel.Informational*/, -1n))
                {
                    this.TransactionScopeDisposed$1(transactionID.TransactionIdentifier ?? $.$spc.System.String.Empty);
                }
            }
            /*void */ TransactionScopeDisposed$1(/*string*/ transactionID)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionID);
                this.WriteEvent$7(35/*TRANSACTIONSCOPE_DISPOSED_EVENTID*/, transactionID);
            }
            /*void */ TransactionScopeIncomplete(/*TransactionTraceIdentifier*/ transactionID)
            {
                if (this.IsEnabled$1(3/*EventLevel.Warning*/, -1n))
                {
                    this.TransactionScopeIncomplete$1(transactionID.TransactionIdentifier ?? $.$spc.System.String.Empty);
                }
            }
            /*void */ TransactionScopeIncomplete$1(/*string*/ transactionID)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionID);
                this.WriteEvent$7(36/*TRANSACTIONSCOPE_INCOMPLETE_EVENTID*/, transactionID);
            }
            /*void */ TransactionScopeTimeout(/*TransactionTraceIdentifier*/ transactionID)
            {
                if (this.IsEnabled$1(3/*EventLevel.Warning*/, -1n))
                {
                    this.TransactionScopeTimeout$1(transactionID.TransactionIdentifier ?? $.$spc.System.String.Empty);
                }
            }
            /*void */ TransactionScopeTimeout$1(/*string*/ transactionID)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionID);
                this.WriteEvent$7(39/*TRANSACTIONSCOPE_TIMEOUT_EVENTID*/, transactionID);
            }
            /*void */ TransactionTimeout(/*TransactionTraceIdentifier*/ transactionID)
            {
                if (this.IsEnabled$1(3/*EventLevel.Warning*/, -1n))
                {
                    this.TransactionTimeout$1(transactionID.TransactionIdentifier ?? $.$spc.System.String.Empty);
                }
            }
            /*void */ TransactionTimeout$1(/*string*/ transactionID)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionID);
                this.WriteEvent$7(30/*TRANSACTION_TIMEOUT_EVENTID*/, transactionID);
            }
            /*void */ TransactionstateEnlist(/*EnlistmentTraceIdentifier*/ enlistmentID, /*EnlistmentType*/ enlistmentType, /*EnlistmentOptions*/ enlistmentOption)
            {
                if (this.IsEnabled$1(4/*EventLevel.Informational*/, -1n))
                {
                    if (enlistmentID.EnlistmentIdentifier !== 0)
                    {
                        this.TransactionstateEnlist$1($.$spc.System.Int32.ToString.call(enlistmentID.EnlistmentIdentifier), $.$spc.System.Enum.ToStringT($.$stl.System.Transactions.EnlistmentType, $.$spc.System.UInt32, enlistmentType), $.$spc.System.Enum.ToStringT($.$stl.System.Transactions.EnlistmentOptions, $.$spc.System.UInt32, enlistmentOption));
                    }
                    else 
                    {
                        this.TransactionstateEnlist$1($.$spc.System.String.Empty, $.$spc.System.Enum.ToStringT($.$stl.System.Transactions.EnlistmentType, $.$spc.System.UInt32, enlistmentType), $.$spc.System.Enum.ToStringT($.$stl.System.Transactions.EnlistmentOptions, $.$spc.System.UInt32, enlistmentOption));
                    }
                }
            }
            /*void */ TransactionstateEnlist$1(/*string*/ enlistmentID, /*string*/ type, /*string*/ option)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$9(40/*TRANSACTIONSTATE_ENLIST_EVENTID*/, enlistmentID, type, option);
            }
            /*void */ TransactionCommitted(/*TraceSourceType*/ traceSource, /*TransactionTraceIdentifier*/ transactionID)
            {
                if (this.IsEnabled$1(5/*EventLevel.Verbose*/, -1n))
                {
                    if (traceSource === 1/*TraceSourceType.TraceSourceLtm*/)
                    {
                        this.TransactionCommittedLtm(transactionID.TransactionIdentifier ?? $.$spc.System.String.Empty);
                    }
                    else if (traceSource === 2/*TraceSourceType.TraceSourceOleTx*/)
                    {
                        this.TransactionCommittedOleTx(transactionID.TransactionIdentifier ?? $.$spc.System.String.Empty);
                    }
                }
            }
            /*void */ TransactionCommittedLtm(/*string*/ transactionID)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionID);
                this.WriteEvent$7(20/*TRANSACTION_COMMITTED_LTM_EVENTID*/, transactionID);
            }
            /*void */ TransactionCommittedOleTx(/*string*/ transactionID)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionID);
                this.WriteEvent$7(44/*TRANSACTION_COMMITTED_OLETX_EVENTID*/, transactionID);
            }
            /*void */ TransactionInDoubt(/*TraceSourceType*/ traceSource, /*TransactionTraceIdentifier*/ transactionID)
            {
                if (this.IsEnabled$1(3/*EventLevel.Warning*/, -1n))
                {
                    if (traceSource === 1/*TraceSourceType.TraceSourceLtm*/)
                    {
                        this.TransactionInDoubtLtm(transactionID.TransactionIdentifier ?? $.$spc.System.String.Empty);
                    }
                    else if (traceSource === 2/*TraceSourceType.TraceSourceOleTx*/)
                    {
                        this.TransactionInDoubtOleTx(transactionID.TransactionIdentifier ?? $.$spc.System.String.Empty);
                    }
                }
            }
            /*void */ TransactionInDoubtLtm(/*string*/ transactionID)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionID);
                this.WriteEvent$7(25/*TRANSACTION_INDOUBT_LTM_EVENTID*/, transactionID);
            }
            /*void */ TransactionInDoubtOleTx(/*string*/ transactionID)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionID);
                this.WriteEvent$7(46/*TRANSACTION_INDOUBT_OLETX_EVENTID*/, transactionID);
            }
            /*void */ TransactionPromoted(/*TransactionTraceIdentifier*/ transactionID, /*TransactionTraceIdentifier*/ distributedTxID)
            {
                if (this.IsEnabled$1(4/*EventLevel.Informational*/, -1n))
                {
                    this.TransactionPromoted$1(transactionID.TransactionIdentifier ?? $.$spc.System.String.Empty, distributedTxID.TransactionIdentifier ?? $.$spc.System.String.Empty);
                }
            }
            /*void */ TransactionPromoted$1(/*string*/ transactionID, /*string*/ distributedTxID)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionID);
                this.WriteEvent$8(27/*TRANSACTION_PROMOTED_EVENTID*/, transactionID, distributedTxID);
            }
            /*void */ TransactionAborted(/*TraceSourceType*/ traceSource, /*TransactionTraceIdentifier*/ transactionID)
            {
                if (this.IsEnabled$1(3/*EventLevel.Warning*/, -1n))
                {
                    if (traceSource === 1/*TraceSourceType.TraceSourceLtm*/)
                    {
                        this.TransactionAbortedLtm(transactionID.TransactionIdentifier ?? $.$spc.System.String.Empty);
                    }
                    else if (traceSource === 2/*TraceSourceType.TraceSourceOleTx*/)
                    {
                        this.TransactionAbortedOleTx(transactionID.TransactionIdentifier ?? $.$spc.System.String.Empty);
                    }
                }
            }
            /*void */ TransactionAbortedLtm(/*string*/ transactionID)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionID);
                this.WriteEvent$7(17/*TRANSACTION_ABORTED_LTM_EVENTID*/, transactionID);
            }
            /*void */ TransactionAbortedOleTx(/*string*/ transactionID)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId(transactionID);
                this.WriteEvent$7(45/*TRANSACTION_ABORTED_OLETX_EVENTID*/, transactionID);
            }
            /*void */ InternalError(/*string?*/ error)
            {
                if (this.IsEnabled$1(1/*EventLevel.Critical*/, -1n))
                {
                    this.InternalErrorTrace(error);
                }
            }
            /*void */ InternalErrorTrace(/*string?*/ error)
            {
                $.$stl.System.Transactions.TransactionsEtwProvider.SetActivityId($.$spc.System.String.Empty);
                this.WriteEvent$7(37/*INTERNAL_ERROR_EVENTID*/, error);
            }
            static $_Opcodes;
            static get Opcodes()
            {
                let $cls = $.$stl.System.Transactions.TransactionsEtwProvider;
                return $cls.$_Opcodes ??= $asm.$ncls("$stl.System.Transactions.TransactionsEtwProvider.Opcodes", ($self) => class Opcodes
                {
                    /*EventOpcode*/ static Aborted = 100;
                    /*EventOpcode*/ static Activity = 101;
                    /*EventOpcode*/ static Adjusted = 102;
                    /*EventOpcode*/ static CloneCreate = 103;
                    /*EventOpcode*/ static Commit = 104;
                    /*EventOpcode*/ static Committed = 105;
                    /*EventOpcode*/ static Create = 106;
                    /*EventOpcode*/ static Created = 107;
                    /*EventOpcode*/ static CurrentChanged = 108;
                    /*EventOpcode*/ static DependentCloneComplete = 109;
                    /*EventOpcode*/ static Disposed = 110;
                    /*EventOpcode*/ static Done = 111;
                    /*EventOpcode*/ static Enlist = 112;
                    /*EventOpcode*/ static Enter = 113;
                    /*EventOpcode*/ static ExceptionConsumed = 114;
                    /*EventOpcode*/ static Exit = 115;
                    /*EventOpcode*/ static ForceRollback = 116;
                    /*EventOpcode*/ static Incomplete = 117;
                    /*EventOpcode*/ static InDoubt = 118;
                    /*EventOpcode*/ static InternalError = 119;
                    /*EventOpcode*/ static InvalidOperation = 120;
                    /*EventOpcode*/ static NestedIncorrectly = 121;
                    /*EventOpcode*/ static Prepared = 122;
                    /*EventOpcode*/ static Promoted = 123;
                    /*EventOpcode*/ static RecoveryComplete = 124;
                    /*EventOpcode*/ static Reenlist = 125;
                    /*EventOpcode*/ static Rollback = 126;
                    /*EventOpcode*/ static Serialized = 127;
                    /*EventOpcode*/ static Timeout = 128;
                    /*EventOpcode*/ static CallbackPositive = 129;
                    /*EventOpcode*/ static CallbackNegative = 130;
                    static $h = 5539300;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":41156609,"n":"Aborted","d":5539300,"h":4300506596,"f":33},{"t":41156609,"n":"Activity","d":5539300,"h":8595473892,"f":33},{"t":41156609,"n":"Adjusted","d":5539300,"h":12890441188,"f":33},{"t":41156609,"n":"CloneCreate","d":5539300,"h":17185408484,"f":33},{"t":41156609,"n":"Commit","d":5539300,"h":21480375780,"f":33},{"t":41156609,"n":"Committed","d":5539300,"h":25775343076,"f":33},{"t":41156609,"n":"Create","d":5539300,"h":30070310372,"f":33},{"t":41156609,"n":"Created","d":5539300,"h":34365277668,"f":33},{"t":41156609,"n":"CurrentChanged","d":5539300,"h":38660244964,"f":33},{"t":41156609,"n":"DependentCloneComplete","d":5539300,"h":42955212260,"f":33},{"t":41156609,"n":"Disposed","d":5539300,"h":47250179556,"f":33},{"t":41156609,"n":"Done","d":5539300,"h":51545146852,"f":33},{"t":41156609,"n":"Enlist","d":5539300,"h":55840114148,"f":33},{"t":41156609,"n":"Enter","d":5539300,"h":60135081444,"f":33},{"t":41156609,"n":"ExceptionConsumed","d":5539300,"h":64430048740,"f":33},{"t":41156609,"n":"Exit","d":5539300,"h":68725016036,"f":33},{"t":41156609,"n":"ForceRollback","d":5539300,"h":73019983332,"f":33},{"t":41156609,"n":"Incomplete","d":5539300,"h":77314950628,"f":33},{"t":41156609,"n":"InDoubt","d":5539300,"h":81609917924,"f":33},{"t":41156609,"n":"InternalError","d":5539300,"h":85904885220,"f":33},{"t":41156609,"n":"InvalidOperation","d":5539300,"h":90199852516,"f":33},{"t":41156609,"n":"NestedIncorrectly","d":5539300,"h":94494819812,"f":33},{"t":41156609,"n":"Prepared","d":5539300,"h":98789787108,"f":33},{"t":41156609,"n":"Promoted","d":5539300,"h":103084754404,"f":33},{"t":41156609,"n":"RecoveryComplete","d":5539300,"h":107379721700,"f":33},{"t":41156609,"n":"Reenlist","d":5539300,"h":111674688996,"f":33},{"t":41156609,"n":"Rollback","d":5539300,"h":115969656292,"f":33},{"t":41156609,"n":"Serialized","d":5539300,"h":120264623588,"f":33},{"t":41156609,"n":"Timeout","d":5539300,"h":124559590884,"f":33},{"t":41156609,"n":"CallbackPositive","d":5539300,"h":128854558180,"f":33},{"t":41156609,"n":"CallbackNegative","d":5539300,"h":133149525476,"f":33}],"d":5408228,"h":5539300}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Transactions.TransactionsEtwProvider.Opcodes`; }
                }, $cls, ($v) => $cls.$_Opcodes = $v);
            }
            static $_Tasks;
            static get Tasks()
            {
                let $cls = $.$stl.System.Transactions.TransactionsEtwProvider;
                return $cls.$_Tasks ??= $asm.$ncls("$stl.System.Transactions.TransactionsEtwProvider.Tasks", ($self) => class Tasks
                {
                    /*EventTask*/ static ConfiguredDefaultTimeout = 1;
                    /*EventTask*/ static Enlistment = 2;
                    /*EventTask*/ static ResourceManager = 3;
                    /*EventTask*/ static Method = 4;
                    /*EventTask*/ static Transaction = 5;
                    /*EventTask*/ static TransactionException = 6;
                    /*EventTask*/ static TransactionManager = 7;
                    /*EventTask*/ static TransactionScope = 8;
                    /*EventTask*/ static TransactionState = 9;
                    static $h = 5604836;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":42598401,"n":"ConfiguredDefaultTimeout","d":5604836,"h":4300572132,"f":33},{"t":42598401,"n":"Enlistment","d":5604836,"h":8595539428,"f":33},{"t":42598401,"n":"ResourceManager","d":5604836,"h":12890506724,"f":33},{"t":42598401,"n":"Method","d":5604836,"h":17185474020,"f":33},{"t":42598401,"n":"Transaction","d":5604836,"h":21480441316,"f":33},{"t":42598401,"n":"TransactionManager","d":5604836,"h":30070375908,"f":33},{"t":42598401,"n":"TransactionScope","d":5604836,"h":34365343204,"f":33},{"t":42598401,"n":"TransactionState","d":5604836,"h":38660310500,"f":33}],"d":5408228,"h":5604836}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Transactions.TransactionsEtwProvider.Tasks`; }
                }, $cls, ($v) => $cls.$_Tasks = $v);
            }
            static $_Keywords;
            static get Keywords()
            {
                let $cls = $.$stl.System.Transactions.TransactionsEtwProvider;
                return $cls.$_Keywords ??= $asm.$ncls("$stl.System.Transactions.TransactionsEtwProvider.Keywords", ($self) => class Keywords
                {
                    /*EventKeywords*/ static TraceBase = 1n;
                    /*EventKeywords*/ static TraceLtm = 2n;
                    /*EventKeywords*/ static TraceOleTx = 4n;
                    static $h = 5473764;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":40894465,"n":"TraceBase","d":5473764,"h":4300441060,"f":33},{"t":40894465,"n":"TraceLtm","d":5473764,"h":8595408356,"f":33},{"t":40894465,"n":"TraceOleTx","d":5473764,"h":12890375652,"f":33}],"d":5408228,"h":5473764}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Transactions.TransactionsEtwProvider.Keywords`; }
                }, $cls, ($v) => $cls.$_Keywords = $v);
            }
            static /*void */ SetActivityId(/*string*/ str)
            {
                /*Guid*/ let guid = $.$spc.System.Guid.Empty;
                if ($.$spc.System.String.Contains$2.call(str, /*-*/ 45))
                {
                    if (str.length >= 36)
                    {
                        $.$spc.System.Guid.TryParse$1($.$spc.System.MemoryExtensions.AsSpan$7(str, 0, 36), $.$ref(() => guid, ($v) => guid = $v, $.$spc.System.Guid));
                    }
                }
                else 
                {
                    if (str.length >= 32)
                    {
                        $.$spc.System.Guid.TryParse$1($.$spc.System.MemoryExtensions.AsSpan$7(str, 0, 32), $.$ref(() => guid, ($v) => guid = $v, $.$spc.System.Guid));
                    }
                }
                $.$spc.System.Diagnostics.Tracing.EventSource.SetCurrentThreadActivityId(guid);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Log = new $.$stl.System.Transactions.TransactionsEtwProvider().$ctor$8();
                }
                {
                    this.NullInstance = "(null)";
                }
            }
            static $h = 5408228;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":41746433,"m":[{"r":1310721,"p":[{"n":"value","p":131073}],"n":"IdOf","d":5408228,"h":266293380580,"f":33,"a":[{"t":44302337,"c":4339269633}]},{"r":655361,"p":[{"n":"value","p":131073}],"n":"GetHashCode","o":"@$1","d":5408228,"h":270588347876,"f":33,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"traceSource","p":4228580},{"n":"txTraceId","p":8553956},{"n":"type","p":1310721}],"n":"TransactionCreated","d":5408228,"h":274883315172,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"transactionIdentifier","p":1310721},{"n":"type","p":1310721}],"n":"TransactionCreatedLtm","d":5408228,"h":279178282468,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":21,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":4,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":106,"t":41156609},{"n":"Message","v":"Transaction Created (LTM). ID is {0}, type is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionIdentifier","p":1310721},{"n":"type","p":1310721}],"n":"TransactionCreatedOleTx","d":5408228,"h":283473249764,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":51,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40894465},{"n":"Level","v":4,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":106,"t":41156609},{"n":"Message","v":"Transaction Created (OLETX). ID is {0}, type is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"transaction","p":4294116},{"n":"type","p":1310721}],"n":"TransactionCloneCreate","d":5408228,"h":287768217060,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"transactionIdentifier","p":1310721},{"n":"type","p":1310721}],"n":"TransactionCloneCreate","o":"@$1","d":5408228,"h":292063184356,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":18,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":4,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":103,"t":41156609},{"n":"Message","v":"Transaction Clone Created. ID is {0}, type is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionTraceId","p":8553956}],"n":"TransactionSerialized","d":5408228,"h":296358151652,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"transactionIdentifier","p":1310721}],"n":"TransactionSerialized","o":"@$1","d":5408228,"h":300653118948,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":29,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40894465},{"n":"Level","v":4,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":127,"t":41156609},{"n":"Message","v":"Transaction Serialized. ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionTraceId","p":8553956}],"n":"TransactionDeserialized","d":5408228,"h":304948086244,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"transactionIdentifier","p":1310721}],"n":"TransactionDeserialized","o":"@$1","d":5408228,"h":309243053540,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":50,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40894465},{"n":"Level","v":5,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":127,"t":41156609},{"n":"Message","v":"Transaction Deserialized. ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"traceSource","p":4228580},{"n":"type","p":4621796},{"n":"message","p":1310721},{"n":"innerExceptionStr","p":1310721}],"n":"TransactionExceptionTrace","d":5408228,"h":313538020836,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"type","p":4621796},{"n":"message","p":1310721},{"n":"innerExceptionStr","p":1310721}],"n":"TransactionExceptionTrace","o":"@$1","d":5408228,"h":317832988132,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"type","p":1310721},{"n":"message","p":1310721},{"n":"innerExceptionStr","p":1310721}],"n":"TransactionExceptionBase","d":5408228,"h":322127955428,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":24,"t":655361}],"n":[{"n":"Keywords","v":1,"t":40894465},{"n":"Level","v":2,"t":40960001},{"n":"Task","v":6,"t":42598401},{"n":"Message","v":"Transaction Exception. Type is {0}, message is {1}, InnerException is {2}","t":1310721}]}]},{"r":65537,"p":[{"n":"type","p":1310721},{"n":"message","p":1310721},{"n":"innerExceptionStr","p":1310721}],"n":"TransactionExceptionLtm","d":5408228,"h":326422922724,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":23,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":2,"t":40960001},{"n":"Task","v":6,"t":42598401},{"n":"Message","v":"Transaction Exception. Type is {0}, message is {1}, InnerException is {2}","t":1310721}]}]},{"r":65537,"p":[{"n":"type","p":1310721},{"n":"operation","p":1310721}],"n":"InvalidOperation","d":5408228,"h":330717890020,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"transactionIdentifier","p":1310721},{"n":"type","p":1310721},{"n":"operation","p":1310721}],"n":"TransactionInvalidOperation","d":5408228,"h":335012857316,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":26,"t":655361}],"n":[{"n":"Keywords","v":1,"t":40894465},{"n":"Level","v":2,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":120,"t":41156609},{"n":"Message","v":"Transaction Invalid Operation. ID is {0}, type is {1} and operation is {2}","t":1310721}]}]},{"r":65537,"p":[{"n":"traceSource","p":4228580},{"n":"txTraceId","p":8553956},{"n":"type","p":1310721}],"n":"TransactionRollback","d":5408228,"h":339307824612,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"transactionIdentifier","p":1310721},{"n":"type","p":1310721}],"n":"TransactionRollbackLtm","d":5408228,"h":343602791908,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":28,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":3,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":126,"t":41156609},{"n":"Message","v":"Transaction LTM Rollback. ID is {0}, type is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionIdentifier","p":1310721},{"n":"type","p":1310721}],"n":"TransactionRollbackOleTx","d":5408228,"h":347897759204,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":42,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40894465},{"n":"Level","v":3,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":126,"t":41156609},{"n":"Message","v":"Transaction OleTx Rollback. ID is {0}, type is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"traceSource","p":4228580},{"n":"txTraceId","p":8553956},{"n":"option","p":1082852}],"n":"TransactionDependentCloneCreate","d":5408228,"h":352192726500,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"transactionIdentifier","p":1310721},{"n":"option","p":1310721}],"n":"TransactionDependentCloneCreateLtm","d":5408228,"h":356487693796,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":48,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":4,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":109,"t":41156609},{"n":"Message","v":"Transaction Dependent Clone Created (LTM). ID is {0}, option is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionIdentifier","p":1310721},{"n":"option","p":1310721}],"n":"TransactionDependentCloneCreateOleTx","d":5408228,"h":360782661092,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":49,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40894465},{"n":"Level","v":4,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":109,"t":41156609},{"n":"Message","v":"Transaction Dependent Clone Created (OLETX). ID is {0}, option is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"traceSource","p":4228580},{"n":"txTraceId","p":8553956},{"n":"type","p":1310721}],"n":"TransactionDependentCloneComplete","d":5408228,"h":365077628388,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"transactionIdentifier","p":1310721},{"n":"type","p":1310721}],"n":"TransactionDependentCloneCompleteLtm","d":5408228,"h":369372595684,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":22,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":4,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":109,"t":41156609},{"n":"Message","v":"Transaction Dependent Clone Completed (LTM). ID is {0}, type is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionIdentifier","p":1310721},{"n":"type","p":1310721}],"n":"TransactionDependentCloneCompleteOleTx","d":5408228,"h":373667562980,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":47,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40894465},{"n":"Level","v":4,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":109,"t":41156609},{"n":"Message","v":"Transaction Dependent Clone Completed (OLETX). ID is {0}, type is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"traceSource","p":4228580},{"n":"txTraceId","p":8553956},{"n":"type","p":1310721}],"n":"TransactionCommit","d":5408228,"h":377962530276,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"transactionIdentifier","p":1310721},{"n":"type","p":1310721}],"n":"TransactionCommitLtm","d":5408228,"h":382257497572,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":19,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":5,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":104,"t":41156609},{"n":"Message","v":"Transaction LTM Commit: ID is {0}, type is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionIdentifier","p":1310721},{"n":"type","p":1310721}],"n":"TransactionCommitOleTx","d":5408228,"h":386552464868,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":41,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40894465},{"n":"Level","v":5,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":104,"t":41156609},{"n":"Message","v":"Transaction OleTx Commit: ID is {0}, type is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"traceSource","p":4228580},{"n":"enlistmentTraceId","p":2065892},{"n":"notificationCall","p":3311076}],"n":"EnlistmentStatus","d":5408228,"h":390847432164,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"enlistmentIdentifier","p":655361},{"n":"notificationCall","p":1310721}],"n":"EnlistmentStatusLtm","d":5408228,"h":395142399460,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":5,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":5,"t":40960001},{"n":"Task","v":2,"t":42598401},{"n":"Message","v":"Enlistment status (LTM): ID is {0}, notificationcall is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"enlistmentIdentifier","p":655361},{"n":"notificationCall","p":1310721}],"n":"EnlistmentStatusOleTx","d":5408228,"h":399437366756,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":52,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40894465},{"n":"Level","v":5,"t":40960001},{"n":"Task","v":2,"t":42598401},{"n":"Message","v":"Enlistment status (OLETX): ID is {0}, notificationcall is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"traceSource","p":4228580},{"n":"enlistmentTraceId","p":2065892},{"n":"enlistmentType","p":2131428},{"n":"enlistmentOptions","p":1869284}],"n":"EnlistmentCreated","d":5408228,"h":403732334052,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"enlistmentIdentifier","p":655361},{"n":"enlistmentType","p":1310721},{"n":"enlistmentOptions","p":1310721}],"n":"EnlistmentCreatedLtm","d":5408228,"h":408027301348,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":55,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":4,"t":40960001},{"n":"Task","v":2,"t":42598401},{"n":"Opcode","v":106,"t":41156609},{"n":"Message","v":"Enlistment Created (LTM). ID is {0}, type is {1}, options is {2}","t":1310721}]}]},{"r":65537,"p":[{"n":"enlistmentIdentifier","p":655361},{"n":"enlistmentType","p":1310721},{"n":"enlistmentOptions","p":1310721}],"n":"EnlistmentCreatedOleTx","d":5408228,"h":412322268644,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":56,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40894465},{"n":"Level","v":4,"t":40960001},{"n":"Task","v":2,"t":42598401},{"n":"Opcode","v":106,"t":41156609},{"n":"Message","v":"Enlistment Created (OLETX). ID is {0}, type is {1}, options is {2}","t":1310721}]}]},{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"EnlistmentDone","d":5408228,"h":416617235940,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"enlistmentIdentifier","p":655361}],"n":"EnlistmentDone","o":"@$1","d":5408228,"h":420912203236,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":4,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":5,"t":40960001},{"n":"Task","v":2,"t":42598401},{"n":"Opcode","v":111,"t":41156609},{"n":"Message","v":"Enlistment.Done: ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"EnlistmentPrepared","d":5408228,"h":425207170532,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"enlistmentIdentifier","p":655361}],"n":"EnlistmentPrepared","o":"@$1","d":5408228,"h":429502137828,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":8,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":5,"t":40960001},{"n":"Task","v":2,"t":42598401},{"n":"Opcode","v":122,"t":41156609},{"n":"Message","v":"PreparingEnlistment.Prepared: ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"EnlistmentForceRollback","d":5408228,"h":433797105124,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"enlistmentIdentifier","p":655361}],"n":"EnlistmentForceRollback","o":"@$1","d":5408228,"h":438092072420,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":6,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":3,"t":40960001},{"n":"Task","v":2,"t":42598401},{"n":"Opcode","v":116,"t":41156609},{"n":"Message","v":"Enlistment forceRollback: ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"EnlistmentAborted","d":5408228,"h":442387039716,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"enlistmentIdentifier","p":655361}],"n":"EnlistmentAborted","o":"@$1","d":5408228,"h":446682007012,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":2,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":3,"t":40960001},{"n":"Task","v":2,"t":42598401},{"n":"Opcode","v":100,"t":41156609},{"n":"Message","v":"Enlistment SinglePhase Aborted: ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"EnlistmentCommitted","d":5408228,"h":450976974308,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"enlistmentIdentifier","p":655361}],"n":"EnlistmentCommitted","o":"@$1","d":5408228,"h":455271941604,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":3,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":5,"t":40960001},{"n":"Task","v":2,"t":42598401},{"n":"Opcode","v":105,"t":41156609},{"n":"Message","v":"Enlistment Committed: ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"EnlistmentInDoubt","d":5408228,"h":459566908900,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"enlistmentIdentifier","p":655361}],"n":"EnlistmentInDoubt","o":"@$1","d":5408228,"h":463861876196,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":7,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":3,"t":40960001},{"n":"Task","v":2,"t":42598401},{"n":"Opcode","v":118,"t":41156609},{"n":"Message","v":"Enlistment SinglePhase InDoubt: ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"enlistmentTraceIdentifier","p":2065892},{"n":"callback","p":1803748}],"n":"EnlistmentCallbackPositive","d":5408228,"h":468156843492,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"enlistmentIdentifier","p":655361},{"n":"callback","p":1310721}],"n":"EnlistmentCallbackPositive","o":"@$1","d":5408228,"h":472451810788,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":53,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40894465},{"n":"Level","v":5,"t":40960001},{"n":"Task","v":2,"t":42598401},{"n":"Opcode","v":129,"t":41156609},{"n":"Message","v":"Enlistment callback positive: ID is {0}, callback is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"enlistmentTraceIdentifier","p":2065892},{"n":"callback","p":1803748}],"n":"EnlistmentCallbackNegative","d":5408228,"h":476746778084,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"enlistmentIdentifier","p":655361},{"n":"callback","p":1310721}],"n":"EnlistmentCallbackNegative","o":"@$1","d":5408228,"h":481041745380,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":54,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40894465},{"n":"Level","v":3,"t":40960001},{"n":"Task","v":2,"t":42598401},{"n":"Opcode","v":130,"t":41156609},{"n":"Message","v":"Enlistment callback negative: ID is {0}, callback is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"traceSource","p":4228580},{"n":"thisOrContextObject","p":131073},{"n":"methodname","p":1310721,"f":65,"a":[{"t":88145921,"c":4383113217}]}],"n":"MethodEnter","d":5408228,"h":485336712676,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"traceSource","p":4228580},{"n":"methodname","p":1310721,"f":65,"a":[{"t":88145921,"c":4383113217}]}],"n":"MethodEnter","o":"@$1","d":5408228,"h":489631679972,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"thisOrContextObject","p":1310721},{"n":"methodname","p":1310721}],"n":"MethodEnterTraceLtm","d":5408228,"h":493926647268,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":11,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":5,"t":40960001},{"n":"Task","v":4,"t":42598401},{"n":"Opcode","v":113,"t":41156609},{"n":"Message","v":"Enter method : {0}.{1}","t":1310721}]}]},{"r":65537,"p":[{"n":"thisOrContextObject","p":1310721},{"n":"methodname","p":1310721}],"n":"MethodEnterTraceBase","d":5408228,"h":498221614564,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":13,"t":655361}],"n":[{"n":"Keywords","v":1,"t":40894465},{"n":"Level","v":5,"t":40960001},{"n":"Task","v":4,"t":42598401},{"n":"Opcode","v":113,"t":41156609},{"n":"Message","v":"Enter method : {0}.{1}","t":1310721}]}]},{"r":65537,"p":[{"n":"thisOrContextObject","p":1310721},{"n":"methodname","p":1310721}],"n":"MethodEnterTraceDistributed","d":5408228,"h":502516581860,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":15,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40894465},{"n":"Level","v":5,"t":40960001},{"n":"Task","v":4,"t":42598401},{"n":"Opcode","v":113,"t":41156609},{"n":"Message","v":"Enter method : {0}.{1}","t":1310721}]}]},{"r":65537,"p":[{"n":"traceSource","p":4228580},{"n":"thisOrContextObject","p":131073},{"n":"methodname","p":1310721,"f":65,"a":[{"t":88145921,"c":4383113217}]}],"n":"MethodExit","d":5408228,"h":506811549156,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"traceSource","p":4228580},{"n":"methodname","p":1310721,"f":65,"a":[{"t":88145921,"c":4383113217}]}],"n":"MethodExit","o":"@$1","d":5408228,"h":511106516452,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"thisOrContextObject","p":1310721},{"n":"methodname","p":1310721}],"n":"MethodExitTraceLtm","d":5408228,"h":515401483748,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":12,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":5,"t":40960001},{"n":"Task","v":4,"t":42598401},{"n":"Opcode","v":115,"t":41156609},{"n":"Message","v":"Exit method: {0}.{1}","t":1310721}]}]},{"r":65537,"p":[{"n":"thisOrContextObject","p":1310721},{"n":"methodname","p":1310721}],"n":"MethodExitTraceBase","d":5408228,"h":519696451044,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":14,"t":655361}],"n":[{"n":"Keywords","v":1,"t":40894465},{"n":"Level","v":5,"t":40960001},{"n":"Task","v":4,"t":42598401},{"n":"Opcode","v":115,"t":41156609},{"n":"Message","v":"Exit method: {0}.{1}","t":1310721}]}]},{"r":65537,"p":[{"n":"thisOrContextObject","p":1310721},{"n":"methodname","p":1310721}],"n":"MethodExitTraceDistributed","d":5408228,"h":523991418340,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":16,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40894465},{"n":"Level","v":5,"t":40960001},{"n":"Task","v":4,"t":42598401},{"n":"Opcode","v":115,"t":41156609},{"n":"Message","v":"Exit method: {0}.{1}","t":1310721}]}]},{"r":65537,"p":[{"n":"traceSource","p":4228580},{"n":"exception","p":47251457}],"n":"ExceptionConsumed","d":5408228,"h":528286385636,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"exception","p":47251457}],"n":"ExceptionConsumed","o":"@$1","d":5408228,"h":532581352932,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"exceptionStr","p":1310721}],"n":"ExceptionConsumedBase","d":5408228,"h":536876320228,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":9,"t":655361}],"n":[{"n":"Keywords","v":1,"t":40894465},{"n":"Level","v":5,"t":40960001},{"n":"Opcode","v":114,"t":41156609},{"n":"Message","v":"Exception consumed: {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"exceptionStr","p":1310721}],"n":"ExceptionConsumedLtm","d":5408228,"h":541171287524,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":10,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":5,"t":40960001},{"n":"Opcode","v":114,"t":41156609},{"n":"Message","v":"Exception consumed: {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"exceptionStr","p":1310721}],"n":"ExceptionConsumedOleTx","d":5408228,"h":545466254820,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":43,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40894465},{"n":"Level","v":5,"t":40960001},{"n":"Opcode","v":114,"t":41156609},{"n":"Message","v":"Exception consumed: {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"tmType","p":142606337},{"n":"nodeName","p":1310721}],"n":"OleTxTransactionManagerCreate","d":5408228,"h":549761222116,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"tmType","p":1310721},{"n":"nodeName","p":1310721}],"n":"OleTxTransactionManagerCreate","o":"@$1","d":5408228,"h":554056189412,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":57,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40894465},{"n":"Level","v":5,"t":40960001},{"n":"Task","v":7,"t":42598401},{"n":"Opcode","v":107,"t":41156609},{"n":"Message","v":"Created OleTx transaction manager, type is {0}, node name is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"resourceManagerID","p":56229889}],"n":"TransactionManagerReenlist","d":5408228,"h":558351156708,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"rmID","p":1310721}],"n":"TransactionManagerReenlistTrace","d":5408228,"h":562646124004,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":32,"t":655361}],"n":[{"n":"Keywords","v":1,"t":40894465},{"n":"Level","v":4,"t":40960001},{"n":"Task","v":7,"t":42598401},{"n":"Opcode","v":125,"t":41156609},{"n":"Message","v":"Reenlist in: {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"resourceManagerID","p":56229889}],"n":"TransactionManagerRecoveryComplete","d":5408228,"h":566941091300,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"rmID","p":1310721}],"n":"TransactionManagerRecoveryComplete","o":"@$1","d":5408228,"h":571236058596,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":31,"t":655361}],"n":[{"n":"Keywords","v":1,"t":40894465},{"n":"Level","v":4,"t":40960001},{"n":"Task","v":7,"t":42598401},{"n":"Opcode","v":124,"t":41156609},{"n":"Message","v":"Recovery complete: {0}","t":1310721}]}]},{"r":65537,"n":"ConfiguredDefaultTimeoutAdjusted","d":5408228,"h":575531025892,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"n":"ConfiguredDefaultTimeoutAdjustedTrace","d":5408228,"h":579825993188,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":1,"t":655361}],"n":[{"n":"Keywords","v":1,"t":40894465},{"n":"Level","v":3,"t":40960001},{"n":"Task","v":1,"t":42598401},{"n":"Opcode","v":102,"t":41156609},{"n":"Message","v":"Configured Default Timeout Adjusted","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionID","p":8553956},{"n":"transactionScopeResult","p":5342692}],"n":"TransactionScopeCreated","d":5408228,"h":584120960484,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"transactionID","p":1310721},{"n":"transactionScopeResult","p":5342692}],"n":"TransactionScopeCreated","o":"@$1","d":5408228,"h":588415927780,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":33,"t":655361}],"n":[{"n":"Keywords","v":1,"t":40894465},{"n":"Level","v":4,"t":40960001},{"n":"Task","v":8,"t":42598401},{"n":"Opcode","v":107,"t":41156609},{"n":"Message","v":"Transactionscope was created: Transaction ID is {0}, TransactionScope Result is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"currenttransactionID","p":8553956},{"n":"newtransactionID","p":8553956}],"n":"TransactionScopeCurrentChanged","d":5408228,"h":592710895076,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"currenttransactionID","p":1310721},{"n":"newtransactionID","p":1310721}],"n":"TransactionScopeCurrentChanged","o":"@$1","d":5408228,"h":597005862372,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":34,"t":655361}],"n":[{"n":"Keywords","v":1,"t":40894465},{"n":"Level","v":3,"t":40960001},{"n":"Task","v":8,"t":42598401},{"n":"Opcode","v":108,"t":41156609},{"n":"Message","v":"Transactionscope current transaction ID changed from {0} to {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionID","p":8553956}],"n":"TransactionScopeNestedIncorrectly","d":5408228,"h":601300829668,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"transactionID","p":1310721}],"n":"TransactionScopeNestedIncorrectly","o":"@$1","d":5408228,"h":605595796964,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":38,"t":655361}],"n":[{"n":"Keywords","v":1,"t":40894465},{"n":"Level","v":3,"t":40960001},{"n":"Task","v":8,"t":42598401},{"n":"Opcode","v":121,"t":41156609},{"n":"Message","v":"Transactionscope nested incorrectly: transaction ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionID","p":8553956}],"n":"TransactionScopeDisposed","d":5408228,"h":609890764260,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"transactionID","p":1310721}],"n":"TransactionScopeDisposed","o":"@$1","d":5408228,"h":614185731556,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":35,"t":655361}],"n":[{"n":"Keywords","v":1,"t":40894465},{"n":"Level","v":4,"t":40960001},{"n":"Task","v":8,"t":42598401},{"n":"Opcode","v":110,"t":41156609},{"n":"Message","v":"Transactionscope disposed: transaction ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionID","p":8553956}],"n":"TransactionScopeIncomplete","d":5408228,"h":618480698852,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"transactionID","p":1310721}],"n":"TransactionScopeIncomplete","o":"@$1","d":5408228,"h":622775666148,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":36,"t":655361}],"n":[{"n":"Keywords","v":1,"t":40894465},{"n":"Level","v":3,"t":40960001},{"n":"Task","v":8,"t":42598401},{"n":"Opcode","v":117,"t":41156609},{"n":"Message","v":"Transactionscope incomplete: transaction ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionID","p":8553956}],"n":"TransactionScopeTimeout","d":5408228,"h":627070633444,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"transactionID","p":1310721}],"n":"TransactionScopeTimeout","o":"@$1","d":5408228,"h":631365600740,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":39,"t":655361}],"n":[{"n":"Keywords","v":1,"t":40894465},{"n":"Level","v":3,"t":40960001},{"n":"Task","v":8,"t":42598401},{"n":"Opcode","v":128,"t":41156609},{"n":"Message","v":"Transactionscope timeout: transaction ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionID","p":8553956}],"n":"TransactionTimeout","d":5408228,"h":635660568036,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"transactionID","p":1310721}],"n":"TransactionTimeout","o":"@$1","d":5408228,"h":639955535332,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":30,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":3,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":128,"t":41156609},{"n":"Message","v":"Transaction timeout: transaction ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"enlistmentID","p":2065892},{"n":"enlistmentType","p":2131428},{"n":"enlistmentOption","p":1869284}],"n":"TransactionstateEnlist","d":5408228,"h":644250502628,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"enlistmentID","p":1310721},{"n":"type","p":1310721},{"n":"option","p":1310721}],"n":"TransactionstateEnlist","o":"@$1","d":5408228,"h":648545469924,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":40,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":4,"t":40960001},{"n":"Task","v":9,"t":42598401},{"n":"Opcode","v":112,"t":41156609},{"n":"Message","v":"Transactionstate enlist: Enlistment ID is {0}, type is {1} and options is {2}","t":1310721}]}]},{"r":65537,"p":[{"n":"traceSource","p":4228580},{"n":"transactionID","p":8553956}],"n":"TransactionCommitted","d":5408228,"h":652840437220,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"transactionID","p":1310721}],"n":"TransactionCommittedLtm","d":5408228,"h":657135404516,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":20,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":5,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":105,"t":41156609},{"n":"Message","v":"Transaction committed LTM: transaction ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionID","p":1310721}],"n":"TransactionCommittedOleTx","d":5408228,"h":661430371812,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":44,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40894465},{"n":"Level","v":5,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":105,"t":41156609},{"n":"Message","v":"Transaction committed OleTx: transaction ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"traceSource","p":4228580},{"n":"transactionID","p":8553956}],"n":"TransactionInDoubt","d":5408228,"h":665725339108,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"transactionID","p":1310721}],"n":"TransactionInDoubtLtm","d":5408228,"h":670020306404,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":25,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":3,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":118,"t":41156609},{"n":"Message","v":"Transaction indoubt LTM: transaction ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionID","p":1310721}],"n":"TransactionInDoubtOleTx","d":5408228,"h":674315273700,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":46,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40894465},{"n":"Level","v":3,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":118,"t":41156609},{"n":"Message","v":"Transaction indoubt OleTx: transaction ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionID","p":8553956},{"n":"distributedTxID","p":8553956}],"n":"TransactionPromoted","d":5408228,"h":678610240996,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"transactionID","p":1310721},{"n":"distributedTxID","p":1310721}],"n":"TransactionPromoted","o":"@$1","d":5408228,"h":682905208292,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":27,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":4,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":123,"t":41156609},{"n":"Message","v":"Transaction promoted: transaction ID is {0} and distributed transaction ID is {1}","t":1310721}]}]},{"r":65537,"p":[{"n":"traceSource","p":4228580},{"n":"transactionID","p":8553956}],"n":"TransactionAborted","d":5408228,"h":687200175588,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"transactionID","p":1310721}],"n":"TransactionAbortedLtm","d":5408228,"h":691495142884,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":17,"t":655361}],"n":[{"n":"Keywords","v":2,"t":40894465},{"n":"Level","v":3,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":100,"t":41156609},{"n":"Message","v":"Transaction aborted LTM: transaction ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"transactionID","p":1310721}],"n":"TransactionAbortedOleTx","d":5408228,"h":695790110180,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":45,"t":655361}],"n":[{"n":"Keywords","v":4,"t":40894465},{"n":"Level","v":3,"t":40960001},{"n":"Task","v":5,"t":42598401},{"n":"Opcode","v":100,"t":41156609},{"n":"Message","v":"Transaction aborted OleTx: transaction ID is {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"error","p":1310721,"f":65}],"n":"InternalError","d":5408228,"h":700085077476,"f":8,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"error","p":1310721}],"n":"InternalErrorTrace","d":5408228,"h":704380044772,"f":2,"a":[{"t":39976961,"c":4334944257,"a":[{"v":37,"t":655361}],"n":[{"n":"Keywords","v":1,"t":40894465},{"n":"Level","v":1,"t":40960001},{"n":"Task","v":8,"t":42598401},{"n":"Opcode","v":119,"t":41156609},{"n":"Message","v":"Transactionscope internal error: {0}","t":1310721}]}]},{"r":65537,"p":[{"n":"str","p":1310721}],"n":"SetActivityId","d":5408228,"h":721559913956,"f":34}],"l":[{"t":5408228,"n":"Log","d":5408228,"h":4300375524,"f":40},{"t":40894465,"n":"ALL_KEYWORDS","d":5408228,"h":12890310116,"f":34},{"t":655361,"n":"CONFIGURED_DEFAULT_TIMEOUT_ADJUSTED_EVENTID","d":5408228,"h":17185277412,"f":34},{"t":655361,"n":"ENLISTMENT_ABORTED_EVENTID","d":5408228,"h":21480244708,"f":34},{"t":655361,"n":"ENLISTMENT_COMMITTED_EVENTID","d":5408228,"h":25775212004,"f":34},{"t":655361,"n":"ENLISTMENT_DONE_EVENTID","d":5408228,"h":30070179300,"f":34},{"t":655361,"n":"ENLISTMENT_LTM_EVENTID","d":5408228,"h":34365146596,"f":34},{"t":655361,"n":"ENLISTMENT_FORCEROLLBACK_EVENTID","d":5408228,"h":38660113892,"f":34},{"t":655361,"n":"ENLISTMENT_INDOUBT_EVENTID","d":5408228,"h":42955081188,"f":34},{"t":655361,"n":"ENLISTMENT_PREPARED_EVENTID","d":5408228,"h":47250048484,"f":34},{"t":655361,"n":"EXCEPTION_CONSUMED_BASE_EVENTID","d":5408228,"h":51545015780,"f":34},{"t":655361,"n":"EXCEPTION_CONSUMED_LTM_EVENTID","d":5408228,"h":55839983076,"f":34},{"t":655361,"n":"METHOD_ENTER_LTM_EVENTID","d":5408228,"h":60134950372,"f":34},{"t":655361,"n":"METHOD_EXIT_LTM_EVENTID","d":5408228,"h":64429917668,"f":34},{"t":655361,"n":"METHOD_ENTER_BASE_EVENTID","d":5408228,"h":68724884964,"f":34},{"t":655361,"n":"METHOD_EXIT_BASE_EVENTID","d":5408228,"h":73019852260,"f":34},{"t":655361,"n":"METHOD_ENTER_OLETX_EVENTID","d":5408228,"h":77314819556,"f":34},{"t":655361,"n":"METHOD_EXIT_OLETX_EVENTID","d":5408228,"h":81609786852,"f":34},{"t":655361,"n":"TRANSACTION_ABORTED_LTM_EVENTID","d":5408228,"h":85904754148,"f":34},{"t":655361,"n":"TRANSACTION_CLONECREATE_EVENTID","d":5408228,"h":90199721444,"f":34},{"t":655361,"n":"TRANSACTION_COMMIT_LTM_EVENTID","d":5408228,"h":94494688740,"f":34},{"t":655361,"n":"TRANSACTION_COMMITTED_LTM_EVENTID","d":5408228,"h":98789656036,"f":34},{"t":655361,"n":"TRANSACTION_CREATED_LTM_EVENTID","d":5408228,"h":103084623332,"f":34},{"t":655361,"n":"TRANSACTION_DEPENDENT_CLONE_COMPLETE_LTM_EVENTID","d":5408228,"h":107379590628,"f":34},{"t":655361,"n":"TRANSACTION_EXCEPTION_LTM_EVENTID","d":5408228,"h":111674557924,"f":34},{"t":655361,"n":"TRANSACTION_EXCEPTION_BASE_EVENTID","d":5408228,"h":115969525220,"f":34},{"t":655361,"n":"TRANSACTION_INDOUBT_LTM_EVENTID","d":5408228,"h":120264492516,"f":34},{"t":655361,"n":"TRANSACTION_INVALID_OPERATION_EVENTID","d":5408228,"h":124559459812,"f":34},{"t":655361,"n":"TRANSACTION_PROMOTED_EVENTID","d":5408228,"h":128854427108,"f":34},{"t":655361,"n":"TRANSACTION_ROLLBACK_LTM_EVENTID","d":5408228,"h":133149394404,"f":34},{"t":655361,"n":"TRANSACTION_SERIALIZED_EVENTID","d":5408228,"h":137444361700,"f":34},{"t":655361,"n":"TRANSACTION_TIMEOUT_EVENTID","d":5408228,"h":141739328996,"f":34},{"t":655361,"n":"TRANSACTIONMANAGER_RECOVERY_COMPLETE_EVENTID","d":5408228,"h":146034296292,"f":34},{"t":655361,"n":"TRANSACTIONMANAGER_REENLIST_EVENTID","d":5408228,"h":150329263588,"f":34},{"t":655361,"n":"TRANSACTIONSCOPE_CREATED_EVENTID","d":5408228,"h":154624230884,"f":34},{"t":655361,"n":"TRANSACTIONSCOPE_CURRENT_CHANGED_EVENTID","d":5408228,"h":158919198180,"f":34},{"t":655361,"n":"TRANSACTIONSCOPE_DISPOSED_EVENTID","d":5408228,"h":163214165476,"f":34},{"t":655361,"n":"TRANSACTIONSCOPE_INCOMPLETE_EVENTID","d":5408228,"h":167509132772,"f":34},{"t":655361,"n":"INTERNAL_ERROR_EVENTID","d":5408228,"h":171804100068,"f":34},{"t":655361,"n":"TRANSACTIONSCOPE_NESTED_INCORRECTLY_EVENTID","d":5408228,"h":176099067364,"f":34},{"t":655361,"n":"TRANSACTIONSCOPE_TIMEOUT_EVENTID","d":5408228,"h":180394034660,"f":34},{"t":655361,"n":"TRANSACTIONSTATE_ENLIST_EVENTID","d":5408228,"h":184689001956,"f":34},{"t":655361,"n":"TRANSACTION_COMMIT_OLETX_EVENTID","d":5408228,"h":188983969252,"f":34},{"t":655361,"n":"TRANSACTION_ROLLBACK_OLETX_EVENTID","d":5408228,"h":193278936548,"f":34},{"t":655361,"n":"EXCEPTION_CONSUMED_OLETX_EVENTID","d":5408228,"h":197573903844,"f":34},{"t":655361,"n":"TRANSACTION_COMMITTED_OLETX_EVENTID","d":5408228,"h":201868871140,"f":34},{"t":655361,"n":"TRANSACTION_ABORTED_OLETX_EVENTID","d":5408228,"h":206163838436,"f":34},{"t":655361,"n":"TRANSACTION_INDOUBT_OLETX_EVENTID","d":5408228,"h":210458805732,"f":34},{"t":655361,"n":"TRANSACTION_DEPENDENT_CLONE_COMPLETE_OLETX_EVENTID","d":5408228,"h":214753773028,"f":34},{"t":655361,"n":"TRANSACTION_DEPENDENT_CLONE_CREATE_LTM_EVENTID","d":5408228,"h":219048740324,"f":34},{"t":655361,"n":"TRANSACTION_DEPENDENT_CLONE_CREATE_OLETX_EVENTID","d":5408228,"h":223343707620,"f":34},{"t":655361,"n":"TRANSACTION_DESERIALIZED_EVENTID","d":5408228,"h":227638674916,"f":34},{"t":655361,"n":"TRANSACTION_CREATED_OLETX_EVENTID","d":5408228,"h":231933642212,"f":34},{"t":655361,"n":"ENLISTMENT_OLETX_EVENTID","d":5408228,"h":236228609508,"f":34},{"t":655361,"n":"ENLISTMENT_CALLBACK_POSITIVE_EVENTID","d":5408228,"h":240523576804,"f":34},{"t":655361,"n":"ENLISTMENT_CALLBACK_NEGATIVE_EVENTID","d":5408228,"h":244818544100,"f":34},{"t":655361,"n":"ENLISTMENT_CREATED_LTM_EVENTID","d":5408228,"h":249113511396,"f":34},{"t":655361,"n":"ENLISTMENT_CREATED_OLETX_EVENTID","d":5408228,"h":253408478692,"f":34},{"t":655361,"n":"TRANSACTIONMANAGER_CREATE_OLETX_EVENTID","d":5408228,"h":257703445988,"f":34},{"t":1310721,"n":"NullInstance","d":5408228,"h":261998413284,"f":34}],"c":[{"n":".ctor","o":"$ctor$8","d":5408228,"h":8595342820,"f":2}],"i":[57540609],"j":[5539300,5604836,5473764],"h":5408228,"a":[{"t":42074113,"c":55876648961,"n":[{"n":"Name","v":"System.Transactions.TransactionsEventSource","t":1310721},{"n":"Guid","v":"8ac2d80a-1f1a-431b-ace4-bff8824aef0b","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Diagnostics.Tracing.EventSource; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Transactions.TransactionsEtwProvider`; }
        });
        
        $asm.$cls("$stl.System.Transactions.Oletx.OletxDependentTransaction", ($self) => class OletxDependentTransaction extends $.$stl.System.Transactions.Oletx.OletxTransaction
        {
            /*void */ Complete()
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransaction.NotSupported();
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 3442148;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":3507684,"m":[{"r":65537,"n":"Complete","d":3442148,"h":4298409444,"f":8}],"c":[{"n":".ctor","o":"$ctor$3","d":3442148,"h":8593376740,"f":1}],"i":[113377281],"h":3442148}; }
            static get $b() { return $.$stl.System.Transactions.Oletx.OletxTransaction; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Transactions.Oletx.OletxDependentTransaction`; }
        });
        
        $asm.$cls("$stl.System.Transactions.Oletx.OletxCommittableTransaction", ($self) => class OletxCommittableTransaction extends $.$stl.System.Transactions.Oletx.OletxTransaction
        {
            /*void */ BeginCommit(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.Oletx.OletxTransaction.NotSupported();
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 3376612;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":3507684,"m":[{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"BeginCommit","d":3376612,"h":4298343908,"f":8}],"c":[{"n":".ctor","o":"$ctor$3","d":3376612,"h":8593311204,"f":1}],"i":[113377281],"h":3376612}; }
            static get $b() { return $.$stl.System.Transactions.Oletx.OletxTransaction; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Transactions.Oletx.OletxCommittableTransaction`; }
        });
        
        $asm.$cls("$stl.System.Transactions.SubordinateTransaction", ($self) => class SubordinateTransaction extends $.$stl.System.Transactions.Transaction
        {
            $ctor$5(/*IsolationLevel*/ isoLevel, /*ISimpleTransactionSuperior*/ superior)
            {
                super.$ctor$4(isoLevel, superior);
                {
                }
                return this;
            }
            static $h = 4163044;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":4294116,"c":[{"p":[{"n":"isoLevel","p":3180004},{"n":"superior","p":2983396}],"n":".ctor","o":"$ctor$5","d":4163044,"h":4299130340,"f":1}],"i":[57540609,113377281],"h":4163044}; }
            static get $b() { return $.$stl.System.Transactions.Transaction; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Transactions.SubordinateTransaction`; }
        });
        
        $asm.$cls("$stl.System.Transactions.DependentTransaction", ($self) => class DependentTransaction extends $.$stl.System.Transactions.Transaction
        {
            /*bool*/ _blocking = false;
            $ctor$5(/*IsolationLevel*/ isoLevel, /*InternalTransaction*/ internalTransaction, /*bool*/ blocking)
            {
                super.$ctor$2(isoLevel, internalTransaction);
                {
                    this._blocking = blocking;
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                            if (blocking)
                            {
                                this._internalTransaction.State.CreateBlockingClone(this._internalTransaction);
                            }
                            else 
                            {
                                this._internalTransaction.State.CreateAbortingClone(this._internalTransaction);
                            }
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                    }
                }
                return this;
            }
            /*void */ Complete()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "Complete");
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                    {
                        $.$spc.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                        if (this._complete)
                        {
                            throw $.$stl.System.Transactions.TransactionException.CreateTransactionCompletedException(this.DistributedTxId);
                        }
                        this._complete = true;
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        if (this._blocking)
                        {
                            this._internalTransaction.State.CompleteBlockingClone(this._internalTransaction);
                        }
                        else 
                        {
                            this._internalTransaction.State.CompleteAbortingClone(this._internalTransaction);
                        }
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionDependentCloneComplete(1/*TraceSourceType.TraceSourceLtm*/, this.TransactionTraceId, "DependentTransaction");
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "Complete");
                }
            }
            static $h = 1148388;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":4294116,"m":[{"r":65537,"n":"Complete","d":1148388,"h":12886050276,"f":1}],"l":[{"t":262145,"n":"_blocking","d":1148388,"h":4296115684,"f":2}],"c":[{"p":[{"n":"isoLevel","p":3180004},{"n":"internalTransaction","p":2786788},{"n":"blocking","p":262145}],"n":".ctor","o":"$ctor$5","d":1148388,"h":8591082980,"f":8}],"i":[57540609,113377281],"h":1148388}; }
            static get $b() { return $.$stl.System.Transactions.Transaction; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Transactions.DependentTransaction`; }
        });
        
        $asm.$cls("$stl.System.Transactions.DurableInternalEnlistment", ($self) => class DurableInternalEnlistment extends $.$stl.System.Transactions.InternalEnlistment
        {
            /*Guid*/ _resourceManagerIdentifier;
            $ctor$5(/*Enlistment*/ enlistment, /*Guid*/ resourceManagerIdentifier, /*InternalTransaction*/ transaction, /*IEnlistmentNotification*/ twoPhaseNotifications, /*ISinglePhaseNotification?*/ singlePhaseNotifications, /*Transaction*/ atomicTransaction)
            {
                super.$ctor$3(enlistment, transaction, twoPhaseNotifications, singlePhaseNotifications, atomicTransaction);
                {
                    this._resourceManagerIdentifier = resourceManagerIdentifier;
                }
                return this;
            }
            $ctor$6(/*Enlistment*/ enlistment, /*IEnlistmentNotification*/ twoPhaseNotifications)
            {
                super.$ctor$1(enlistment, twoPhaseNotifications);
                {
                }
                return this;
            }
            /*Guid */ get ResourceManagerIdentifier()
            {
                return this._resourceManagerIdentifier;
            }
            //default member initializer
            constructor()
            {
                super();
                this._resourceManagerIdentifier = $.$default($.$spc.System.Guid);
            }
            static $h = 1607140;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2721252,"p":[{"p":56229889,"g":{"r":0,"d":0,"h":21476443620,"f":32776},"n":"ResourceManagerIdentifier","d":1607140,"h":17181476324,"f":32776}],"l":[{"t":56229889,"n":"_resourceManagerIdentifier","d":1607140,"h":4296574436,"f":8}],"c":[{"p":[{"n":"enlistment","p":1738212},{"n":"resourceManagerIdentifier","p":56229889},{"n":"transaction","p":2786788},{"n":"twoPhaseNotifications","p":2590180},{"n":"singlePhaseNotifications","p":3048932},{"n":"atomicTransaction","p":4294116}],"n":".ctor","o":"$ctor$5","d":1607140,"h":8591541732,"f":8},{"p":[{"n":"enlistment","p":1738212},{"n":"twoPhaseNotifications","p":2590180}],"n":".ctor","o":"$ctor$6","d":1607140,"h":12886509028,"f":4}],"i":[3114468,2655716],"h":1607140}; }
            static get $b() { return $.$stl.System.Transactions.InternalEnlistment; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stl.System.Transactions.ISinglePhaseNotificationInternal, $.$stl.System.Transactions.IEnlistmentNotificationInternal ]; }
            static get $fullName() { return `System.Transactions.DurableInternalEnlistment`; }
        });
        
        $asm.$cls("$stl.System.Transactions.PromotableInternalEnlistment", ($self) => class PromotableInternalEnlistment extends $.$stl.System.Transactions.InternalEnlistment
        {
            /*IPromotableSinglePhaseNotification*/ _promotableNotificationInterface = null;
            $ctor$5(/*Enlistment*/ enlistment, /*InternalTransaction*/ transaction, /*IPromotableSinglePhaseNotification*/ promotableSinglePhaseNotification, /*Transaction*/ atomicTransaction)
            {
                super.$ctor$2(enlistment, transaction, atomicTransaction);
                {
                    this._promotableNotificationInterface = promotableSinglePhaseNotification;
                }
                return this;
            }
            /*IPromotableSinglePhaseNotification */ get PromotableSinglePhaseNotification()
            {
                return this._promotableNotificationInterface;
            }
            static $h = 3966436;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2721252,"p":[{"p":2852324,"g":{"r":0,"d":0,"h":17183835620,"f":32776},"n":"PromotableSinglePhaseNotification","d":3966436,"h":12888868324,"f":32776}],"l":[{"t":2852324,"n":"_promotableNotificationInterface","d":3966436,"h":4298933732,"f":2}],"c":[{"p":[{"n":"enlistment","p":1738212},{"n":"transaction","p":2786788},{"n":"promotableSinglePhaseNotification","p":2852324},{"n":"atomicTransaction","p":4294116}],"n":".ctor","o":"$ctor$5","d":3966436,"h":8593901028,"f":8}],"i":[3114468,2655716],"h":3966436}; }
            static get $b() { return $.$stl.System.Transactions.InternalEnlistment; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stl.System.Transactions.ISinglePhaseNotificationInternal, $.$stl.System.Transactions.IEnlistmentNotificationInternal ]; }
            static get $fullName() { return `System.Transactions.PromotableInternalEnlistment`; }
        });
        
        $asm.$cls("$stl.System.Transactions.Phase1VolatileEnlistment", ($self) => class Phase1VolatileEnlistment extends $.$stl.System.Transactions.InternalEnlistment
        {
            $ctor$5(/*Enlistment*/ enlistment, /*InternalTransaction*/ transaction, /*IEnlistmentNotification*/ twoPhaseNotifications, /*ISinglePhaseNotification?*/ singlePhaseNotifications, /*Transaction*/ atomicTransaction)
            {
                super.$ctor$3(enlistment, transaction, twoPhaseNotifications, singlePhaseNotifications, atomicTransaction);
                {
                }
                return this;
            }
            /*void */ FinishEnlistment()
            {
                this._transaction._phase1Volatiles._preparedVolatileEnlistments++;
                this.CheckComplete();
            }
            /*void */ CheckComplete()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._transaction._phase1Volatiles._preparedVolatileEnlistments <= ((this._transaction._phase1Volatiles._volatileEnlistmentCount + this._transaction._phase1Volatiles._dependentClones) | 0), "_transaction._phase1Volatiles._preparedVolatileEnlistments <=\r\n                _transaction._phase1Volatiles._volatileEnlistmentCount +\r\n                _transaction._phase1Volatiles._dependentClones");
                if (this._transaction._phase1Volatiles._preparedVolatileEnlistments === ((this._transaction._phase1Volatiles._volatileEnlistmentCount + this._transaction._phase1Volatiles._dependentClones) | 0))
                {
                    this._transaction.State.Phase1VolatilePrepareDone(this._transaction);
                }
            }
            static $h = 3835364;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2721252,"m":[{"r":65537,"n":"FinishEnlistment","d":3835364,"h":8593769956,"f":32776},{"r":65537,"n":"CheckComplete","d":3835364,"h":12888737252,"f":32776}],"c":[{"p":[{"n":"enlistment","p":1738212},{"n":"transaction","p":2786788},{"n":"twoPhaseNotifications","p":2590180},{"n":"singlePhaseNotifications","p":3048932},{"n":"atomicTransaction","p":4294116}],"n":".ctor","o":"$ctor$5","d":3835364,"h":4298802660,"f":1}],"i":[3114468,2655716],"h":3835364}; }
            static get $b() { return $.$stl.System.Transactions.InternalEnlistment; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stl.System.Transactions.ISinglePhaseNotificationInternal, $.$stl.System.Transactions.IEnlistmentNotificationInternal ]; }
            static get $fullName() { return `System.Transactions.Phase1VolatileEnlistment`; }
        });
        
        $asm.$cls("$stl.System.Transactions.CommittableTransaction", ($self) => class CommittableTransaction extends $.$stl.System.Transactions.Transaction
        {
            $ctor$5()
            {
                this.$ctor$8($.$stl.System.Transactions.TransactionManager.DefaultIsolationLevel, $.$stl.System.Transactions.TransactionManager.DefaultTimeout);
                {
                }
                return this;
            }
            $ctor$6(/*TimeSpan*/ timeout)
            {
                this.$ctor$8($.$stl.System.Transactions.TransactionManager.DefaultIsolationLevel, timeout);
                {
                }
                return this;
            }
            $ctor$7(/*TransactionOptions*/ options)
            {
                this.$ctor$8(options.IsolationLevel, options.Timeout);
                {
                }
                return this;
            }
            $ctor$8(/*IsolationLevel*/ isoLevel, /*TimeSpan*/ timeout)
            {
                super.$ctor$2(isoLevel, null);
                {
                    this._internalTransaction = new $.$stl.System.Transactions.InternalTransaction().$ctor$1(timeout, this);
                    this._internalTransaction._cloneCount = 1;
                    this._cloneId = 1;
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.TransactionCreated(1/*TraceSourceType.TraceSourceLtm*/, this.TransactionTraceId, "CommittableTransaction");
                    }
                }
                return this;
            }
            /*IAsyncResult */ BeginCommit(/*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "BeginCommit");
                    etwLog.TransactionCommit(1/*TraceSourceType.TraceSourceLtm*/, this.TransactionTraceId, "CommittableTransaction");
                }
                $.$spc.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                    {
                        if (this._complete)
                        {
                            throw $.$stl.System.Transactions.TransactionException.CreateTransactionCompletedException(this.DistributedTxId);
                        }
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        this._internalTransaction.State.BeginCommit(this._internalTransaction, true, asyncCallback, asyncState);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "BeginCommit");
                }
                return this;
            }
            /*void */ Commit()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "Commit");
                    etwLog.TransactionCommit(1/*TraceSourceType.TraceSourceLtm*/, this.TransactionTraceId, "CommittableTransaction");
                }
                $.$spc.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                    {
                        if (this._complete)
                        {
                            throw $.$stl.System.Transactions.TransactionException.CreateTransactionCompletedException(this.DistributedTxId);
                        }
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        this._internalTransaction.State.BeginCommit(this._internalTransaction, false, null, null);
                        do
                        {
                            if (this._internalTransaction.State.IsCompleted(this._internalTransaction))
                            {
                                break;
                            }
                        }
                        while($.$spc.System.Threading.Monitor.Wait$2(this._internalTransaction));
                        this._internalTransaction.State.EndCommit(this._internalTransaction);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "Commit");
                }
            }
            /*void */ InternalDispose()
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "InternalDispose");
                }
                if ($.$spc.System.Threading.Interlocked.Exchange($.$ref(() => this._disposed, ($v) => this._disposed = $v, $.$spc.System.Int32), 1/*Transaction._disposedTrueValue*/) === 1/*Transaction._disposedTrueValue*/)
                {
                    return;
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                if (this._internalTransaction.State.get_Status(this._internalTransaction) === 0/*TransactionStatus.Active*/)
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                        {
                            this._internalTransaction.State.DisposeRoot(this._internalTransaction);
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                    }
                }
                /*long*/ let remainingITx = BigInt($.$spc.System.Threading.Interlocked.Decrement($.$ref(() => this._internalTransaction._cloneCount, ($v) => this._internalTransaction._cloneCount = $v, $.$spc.System.Int32)));
                if (remainingITx === 0n)
                {
                    this._internalTransaction.Dispose();
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "InternalDispose");
                }
            }
            /*void */ EndCommit(/*IAsyncResult*/ asyncResult)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodEnter(1/*TraceSourceType.TraceSourceLtm*/, this, "EndCommit");
                }
                if (asyncResult !== ($.$cast(this, $.$spc.System.Object)))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$stl.System.SR.BadAsyncResult, "asyncResult");
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                    {
                        do
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                            if (this._internalTransaction.State.IsCompleted(this._internalTransaction))
                            {
                                break;
                            }
                        }
                        while($.$spc.System.Threading.Monitor.Wait$2(this._internalTransaction));
                        this._internalTransaction.State.EndCommit(this._internalTransaction);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                }
                if (etwLog.IsEnabled())
                {
                    etwLog.MethodExit(1/*TraceSourceType.TraceSourceLtm*/, this, "EndCommit");
                }
            }
            /*object? */ get System$IAsyncResult$AsyncState()
            {
                return this._internalTransaction._asyncState;
            }
            /*bool */ get System$IAsyncResult$CompletedSynchronously()
            {
                return false;
            }
            /*WaitHandle */ get System$IAsyncResult$AsyncWaitHandle()
            {
                if (this._internalTransaction._asyncResultEvent === null)
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                        {
                            if (this._internalTransaction._asyncResultEvent === null)
                            {
                                $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                                /*ManualResetEvent*/ let temp = new $.$spc.System.Threading.ManualResetEvent().$ctor$8(this._internalTransaction.State.get_Status(this._internalTransaction) !== 0/*TransactionStatus.Active*/);
                                this._internalTransaction._asyncResultEvent = temp;
                            }
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                    }
                }
                return this._internalTransaction._asyncResultEvent;
            }
            /*bool */ get System$IAsyncResult$IsCompleted()
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._internalTransaction)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._internalTransaction.State !== null, "_internalTransaction.State != null");
                        return this._internalTransaction.State.get_Status(this._internalTransaction) !== 0/*TransactionStatus.Active*/;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._internalTransaction)
                }
            }
            static $h = 558564;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":4294116,"p":[{"p":131073,"g":{"r":0,"d":0,"h":42950231524,"f":2},"n":"{57016321}.AsyncState","o":"System$IAsyncResult$AsyncState","d":558564,"h":38655264228,"f":2},{"p":262145,"g":{"r":0,"d":0,"h":51540166116,"f":2},"n":"{57016321}.CompletedSynchronously","o":"System$IAsyncResult$CompletedSynchronously","d":558564,"h":47245198820,"f":2},{"p":139132929,"g":{"r":0,"d":0,"h":60130100708,"f":2},"n":"{57016321}.AsyncWaitHandle","o":"System$IAsyncResult$AsyncWaitHandle","d":558564,"h":55835133412,"f":2},{"p":262145,"g":{"r":0,"d":0,"h":68720035300,"f":2},"n":"{57016321}.IsCompleted","o":"System$IAsyncResult$IsCompleted","d":558564,"h":64425068004,"f":2}],"m":[{"r":57016321,"p":[{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":558564,"h":21475395044,"f":1},{"r":65537,"n":"Commit","d":558564,"h":25770362340,"f":1},{"r":65537,"n":"InternalDispose","d":558564,"h":30065329636,"f":32776},{"r":65537,"p":[{"n":"asyncResult","p":57016321}],"n":"EndCommit","d":558564,"h":34360296932,"f":1}],"c":[{"n":".ctor","o":"$ctor$5","d":558564,"h":4295525860,"f":1},{"p":[{"n":"timeout","p":140705793}],"n":".ctor","o":"$ctor$6","d":558564,"h":8590493156,"f":1},{"p":[{"n":"options","p":5015012}],"n":".ctor","o":"$ctor$7","d":558564,"h":12885460452,"f":1},{"p":[{"n":"isoLevel","p":3180004},{"n":"timeout","p":140705793}],"n":".ctor","o":"$ctor$8","d":558564,"h":17180427748,"f":8}],"i":[57540609,113377281,57016321],"h":558564,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]}]}; }
            static get $b() { return $.$stl.System.Transactions.Transaction; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.Runtime.Serialization.ISerializable, $.$spc.System.IAsyncResult ]; }
            static get $fullName() { return `System.Transactions.CommittableTransaction`; }
        });
        
        $asm.$cls("$stl.System.Transactions.VolatileEnlistmentDone", ($self) => class VolatileEnlistmentDone extends $.$stl.System.Transactions.VolatileEnlistmentEnded
        {
            /*void */ EnterState(/*InternalEnlistment*/ enlistment)
            {
                enlistment.State = this;
            }
            /*void */ ChangeStatePreparing(/*InternalEnlistment*/ enlistment)
            {
                enlistment.CheckComplete();
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 8947172;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":9012708,"m":[{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"EnterState","d":8947172,"h":4303914468,"f":32776},{"r":65537,"p":[{"n":"enlistment","p":2721252}],"n":"ChangeStatePreparing","d":8947172,"h":8598881764,"f":32776}],"c":[{"n":".ctor","o":"$ctor$4","d":8947172,"h":12893849060,"f":1}],"h":8947172}; }
            static get $b() { return $.$stl.System.Transactions.VolatileEnlistmentEnded; }
            static get $fullName() { return `System.Transactions.VolatileEnlistmentDone`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedPhase0", ($self) => class TransactionStatePromotedPhase0 extends $.$stl.System.Transactions.TransactionStatePromotedCommitting
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                /*int*/ let volatileCount = tx._phase0Volatiles._volatileEnlistmentCount;
                /*int*/ let dependentCount = tx._phase0Volatiles._dependentClones;
                tx._phase0VolatileWaveCount = volatileCount;
                if (tx._phase0Volatiles._preparedVolatileEnlistments < ((volatileCount + dependentCount) | 0))
                {
                    for(/*int*/ let i = 0; i < volatileCount; i++)
                    {
                        $.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i)._twoPhaseState.ChangeStatePreparing($.$spc.System.Array.$ReadT1.call(tx._phase0Volatiles._volatileEnlistments, i));
                        if (!tx.State.ContinuePhase0Prepares())
                        {
                            break;
                        }
                    }
                }
                else 
                {
                    this.Phase0VolatilePrepareDone(tx);
                }
            }
            /*void */ Phase0VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(tx._phase0Volatiles.VolatileDemux !== null, "Volatile Demux must exist for VolatilePrepareDone when promoted.");
                $.$spc.System.Threading.Monitor.Exit(tx);
                try
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(tx._phase0Volatiles.VolatileDemux._promotedEnlistment !== null, "tx._phase0Volatiles.VolatileDemux._promotedEnlistment != null");
                    tx._phase0Volatiles.VolatileDemux._promotedEnlistment.System$Transactions$IPromotedEnlistment$Prepared();
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(tx);
                    }
                }
            }
            /*bool */ ContinuePhase0Prepares()
            {
                return true;
            }
            /*void */ ChangeStateTransactionAborted(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                tx._innerException ??= e;
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedP0Aborting.EnterState(tx);
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 7964132;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7046628,"m":[{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"EnterState","d":7964132,"h":4302931428,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"Phase0VolatilePrepareDone","d":7964132,"h":8597898724,"f":32776},{"r":262145,"n":"ContinuePhase0Prepares","d":7964132,"h":12892866020,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"e","p":47251457}],"n":"ChangeStateTransactionAborted","d":7964132,"h":17187833316,"f":32776}],"c":[{"n":".ctor","o":"$ctor$4","d":7964132,"h":21482800612,"f":1}],"h":7964132}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedCommitting; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedPhase0`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStatePromotedPhase1", ($self) => class TransactionStatePromotedPhase1 extends $.$stl.System.Transactions.TransactionStatePromotedCommitting
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                if (tx._committableTransaction !== null)
                {
                    tx._committableTransaction._complete = true;
                }
                if (tx._phase1Volatiles._dependentClones !== 0)
                {
                    tx.State.ChangeStateTransactionAborted(tx, null);
                    return;
                }
                /*int*/ let volatileCount = tx._phase1Volatiles._volatileEnlistmentCount;
                if (tx._phase1Volatiles._preparedVolatileEnlistments < volatileCount)
                {
                    for(/*int*/ let i = 0; i < volatileCount; i++)
                    {
                        $.$spc.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i)._twoPhaseState.ChangeStatePreparing($.$spc.System.Array.$ReadT1.call(tx._phase1Volatiles._volatileEnlistments, i));
                        if (!tx.State.ContinuePhase1Prepares())
                        {
                            break;
                        }
                    }
                }
                else 
                {
                    this.Phase1VolatilePrepareDone(tx);
                }
            }
            /*void */ CreateBlockingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ CreateAbortingClone(/*InternalTransaction*/ tx)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ ChangeStateTransactionAborted(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                tx._innerException ??= e;
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedP1Aborting.EnterState(tx);
            }
            /*void */ Phase1VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(tx._phase1Volatiles.VolatileDemux !== null, "Volatile Demux must exist for VolatilePrepareDone when promoted.");
                $.$spc.System.Threading.Monitor.Exit(tx);
                try
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(tx._phase1Volatiles.VolatileDemux._promotedEnlistment !== null, "tx._phase1Volatiles.VolatileDemux._promotedEnlistment != null");
                    tx._phase1Volatiles.VolatileDemux._promotedEnlistment.System$Transactions$IPromotedEnlistment$Prepared();
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(tx);
                    }
                }
            }
            /*bool */ ContinuePhase1Prepares()
            {
                return true;
            }
            /*Enlistment */ EnlistVolatile(/*InternalTransaction*/ tx, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                throw $.$stl.System.Transactions.TransactionException.Create$1($.$stl.System.SR.TooLate, tx === null ? $.$spc.System.Guid.Empty : tx.DistributedTxId);
            }
            /*Enlistment */ EnlistVolatile$1(/*InternalTransaction*/ tx, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                throw $.$stl.System.Transactions.TransactionException.Create$1($.$stl.System.SR.TooLate, tx === null ? $.$spc.System.Guid.Empty : tx.DistributedTxId);
            }
            /*Enlistment */ EnlistDurable(/*InternalTransaction*/ tx, /*Guid*/ resourceManagerIdentifier, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                throw $.$stl.System.Transactions.TransactionException.Create$1($.$stl.System.SR.TooLate, tx === null ? $.$spc.System.Guid.Empty : tx.DistributedTxId);
            }
            /*Enlistment */ EnlistDurable$1(/*InternalTransaction*/ tx, /*Guid*/ resourceManagerIdentifier, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                throw $.$stl.System.Transactions.TransactionException.Create$1($.$stl.System.SR.TooLate, tx === null ? $.$spc.System.Guid.Empty : tx.DistributedTxId);
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 8029668;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7046628,"m":[{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"EnterState","d":8029668,"h":4302996964,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"CreateBlockingClone","d":8029668,"h":8597964260,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"CreateAbortingClone","d":8029668,"h":12892931556,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"e","p":47251457}],"n":"ChangeStateTransactionAborted","d":8029668,"h":17187898852,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"Phase1VolatilePrepareDone","d":8029668,"h":21482866148,"f":32776},{"r":262145,"n":"ContinuePhase1Prepares","d":8029668,"h":25777833444,"f":32776},{"r":1738212,"p":[{"n":"tx","p":2786788},{"n":"enlistmentNotification","p":2590180},{"n":"enlistmentOptions","p":1869284},{"n":"atomicTransaction","p":4294116}],"n":"EnlistVolatile","d":8029668,"h":30072800740,"f":32776},{"r":1738212,"p":[{"n":"tx","p":2786788},{"n":"enlistmentNotification","p":3048932},{"n":"enlistmentOptions","p":1869284},{"n":"atomicTransaction","p":4294116}],"n":"EnlistVolatile","o":"@$1","d":8029668,"h":34367768036,"f":32776},{"r":1738212,"p":[{"n":"tx","p":2786788},{"n":"resourceManagerIdentifier","p":56229889},{"n":"enlistmentNotification","p":2590180},{"n":"enlistmentOptions","p":1869284},{"n":"atomicTransaction","p":4294116}],"n":"EnlistDurable","d":8029668,"h":38662735332,"f":32776},{"r":1738212,"p":[{"n":"tx","p":2786788},{"n":"resourceManagerIdentifier","p":56229889},{"n":"enlistmentNotification","p":3048932},{"n":"enlistmentOptions","p":1869284},{"n":"atomicTransaction","p":4294116}],"n":"EnlistDurable","o":"@$1","d":8029668,"h":42957702628,"f":32776}],"c":[{"n":".ctor","o":"$ctor$4","d":8029668,"h":47252669924,"f":1}],"h":8029668}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedCommitting; }
            static get $fullName() { return `System.Transactions.TransactionStatePromotedPhase1`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateDelegatedP0Wave", ($self) => class TransactionStateDelegatedP0Wave extends $.$stl.System.Transactions.TransactionStatePromotedP0Wave
        {
            /*void */ Phase0VolatilePrepareDone(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStateDelegatedCommitting.EnterState(tx);
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 6325732;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7833060,"m":[{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"Phase0VolatilePrepareDone","d":6325732,"h":4301293028,"f":32776}],"c":[{"n":".ctor","o":"$ctor$4","d":6325732,"h":8596260324,"f":1}],"h":6325732}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedP0Wave; }
            static get $fullName() { return `System.Transactions.TransactionStateDelegatedP0Wave`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateDelegatedCommitting", ($self) => class TransactionStateDelegatedCommitting extends $.$stl.System.Transactions.TransactionStatePromotedCommitting
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                $.$spc.System.Threading.Monitor.Exit(tx);
                $.$spc.System.Diagnostics.Debug.Assert$1(tx._durableEnlistment !== null, "tx._durableEnlistment != null");
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.EnlistmentStatus(1/*TraceSourceType.TraceSourceLtm*/, tx._durableEnlistment.EnlistmentTraceId, 4/*NotificationCall.SinglePhaseCommit*/);
                }
                try
                {
                    tx._durableEnlistment.PromotableSinglePhaseNotification.System$Transactions$IPromotableSinglePhaseNotification$SinglePhaseCommit(tx._durableEnlistment.SinglePhaseEnlistment);
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(tx);
                    }
                }
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                return this;
            }
            static $h = 6194660;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7046628,"m":[{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"EnterState","d":6194660,"h":4301161956,"f":32776}],"c":[{"n":".ctor","o":"$ctor$4","d":6194660,"h":8596129252,"f":1}],"h":6194660}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedCommitting; }
            static get $fullName() { return `System.Transactions.TransactionStateDelegatedCommitting`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateSubordinateActive", ($self) => class TransactionStateSubordinateActive extends $.$stl.System.Transactions.TransactionStateActive
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                $.$spc.System.Diagnostics.Debug.Assert$1(tx._promoter !== null, "Transaction Promoter is Null entering SubordinateActive");
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                tx._innerException ??= e;
                $.$spc.System.Diagnostics.Debug.Assert$1(tx._promoter !== null, "tx._promoter != null");
                ($.$cast(tx._promoter, $.$stl.System.Transactions.ISimpleTransactionSuperior)).System$Transactions$ISimpleTransactionSuperior$Rollback();
                $.$stl.System.Transactions.TransactionState.TransactionStateAborted.EnterState(tx);
            }
            /*Enlistment */ EnlistVolatile(/*InternalTransaction*/ tx, /*IEnlistmentNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                tx._promoteState.EnterState(tx);
                return tx.State.EnlistVolatile(tx, enlistmentNotification, enlistmentOptions, atomicTransaction);
            }
            /*Enlistment */ EnlistVolatile$1(/*InternalTransaction*/ tx, /*ISinglePhaseNotification*/ enlistmentNotification, /*EnlistmentOptions*/ enlistmentOptions, /*Transaction*/ atomicTransaction)
            {
                tx._promoteState.EnterState(tx);
                return tx.State.EnlistVolatile$1(tx, enlistmentNotification, enlistmentOptions, atomicTransaction);
            }
            /*TransactionStatus */ get_Status(/*InternalTransaction*/ tx)
            {
                tx._promoteState.EnterState(tx);
                return tx.State.get_Status(tx);
            }
            /*void */ AddOutcomeRegistrant(/*InternalTransaction*/ tx, /*TransactionCompletedEventHandler?*/ transactionCompletedDelegate)
            {
                tx._promoteState.EnterState(tx);
                tx.State.AddOutcomeRegistrant(tx, transactionCompletedDelegate);
            }
            /*bool */ EnlistPromotableSinglePhase(/*InternalTransaction*/ tx, /*IPromotableSinglePhaseNotification*/ promotableSinglePhaseNotification, /*Transaction*/ atomicTransaction, /*Guid*/ promoterType)
            {
                return false;
            }
            /*void */ CreateBlockingClone(/*InternalTransaction*/ tx)
            {
                tx._promoteState.EnterState(tx);
                tx.State.CreateBlockingClone(tx);
            }
            /*void */ CreateAbortingClone(/*InternalTransaction*/ tx)
            {
                tx._promoteState.EnterState(tx);
                tx.State.CreateAbortingClone(tx);
            }
            //default reference type constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                return this;
            }
            static $h = 8226276;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":5866980,"m":[{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"EnterState","d":8226276,"h":4303193572,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"e","p":47251457}],"n":"Rollback","d":8226276,"h":8598160868,"f":32776},{"r":1738212,"p":[{"n":"tx","p":2786788},{"n":"enlistmentNotification","p":2590180},{"n":"enlistmentOptions","p":1869284},{"n":"atomicTransaction","p":4294116}],"n":"EnlistVolatile","d":8226276,"h":12893128164,"f":32776},{"r":1738212,"p":[{"n":"tx","p":2786788},{"n":"enlistmentNotification","p":3048932},{"n":"enlistmentOptions","p":1869284},{"n":"atomicTransaction","p":4294116}],"n":"EnlistVolatile","o":"@$1","d":8226276,"h":17188095460,"f":32776},{"r":8422884,"p":[{"n":"tx","p":2786788}],"n":"get_Status","d":8226276,"h":21483062756,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"transactionCompletedDelegate","p":4425188}],"n":"AddOutcomeRegistrant","d":8226276,"h":25778030052,"f":32776},{"r":262145,"p":[{"n":"tx","p":2786788},{"n":"promotableSinglePhaseNotification","p":2852324},{"n":"atomicTransaction","p":4294116},{"n":"promoterType","p":56229889}],"n":"EnlistPromotableSinglePhase","d":8226276,"h":30072997348,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"CreateBlockingClone","d":8226276,"h":34367964644,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"CreateAbortingClone","d":8226276,"h":38662931940,"f":32776}],"c":[{"n":".ctor","o":"$ctor$5","d":8226276,"h":42957899236,"f":1}],"h":8226276}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStateActive; }
            static get $fullName() { return `System.Transactions.TransactionStateSubordinateActive`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateDelegated", ($self) => class TransactionStateDelegated extends $.$stl.System.Transactions.TransactionStateDelegatedBase
        {
            /*void */ BeginCommit(/*InternalTransaction*/ tx, /*bool*/ asyncCommit, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                tx._asyncCommit = asyncCommit;
                tx._asyncCallback = asyncCallback;
                tx._asyncState = asyncState;
                $.$stl.System.Transactions.TransactionState.TransactionStateDelegatedCommitting.EnterState(tx);
            }
            /*bool */ PromoteDurable(/*InternalTransaction*/ tx)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(tx._durableEnlistment !== null, "tx._durableEnlistment != null");
                tx._durableEnlistment.State.ChangeStateDelegated(tx._durableEnlistment);
                return true;
            }
            /*void */ RestartCommitIfNeeded(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStateDelegatedP0Wave.EnterState(tx);
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                tx._innerException ??= e;
                $.$stl.System.Transactions.TransactionState.TransactionStateDelegatedAborting.EnterState(tx);
            }
            //default reference type constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                return this;
            }
            static $h = 5998052;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6129124,"m":[{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"asyncCommit","p":262145},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":5998052,"h":4300965348,"f":32776},{"r":262145,"p":[{"n":"tx","p":2786788}],"n":"PromoteDurable","d":5998052,"h":8595932644,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"RestartCommitIfNeeded","d":5998052,"h":12890899940,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"e","p":47251457}],"n":"Rollback","d":5998052,"h":17185867236,"f":32776}],"c":[{"n":".ctor","o":"$ctor$5","d":5998052,"h":21480834532,"f":1}],"h":5998052}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStateDelegatedBase; }
            static get $fullName() { return `System.Transactions.TransactionStateDelegated`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateDelegatedSubordinate", ($self) => class TransactionStateDelegatedSubordinate extends $.$stl.System.Transactions.TransactionStateDelegatedBase
        {
            /*bool */ PromoteDurable(/*InternalTransaction*/ tx)
            {
                return true;
            }
            /*void */ Rollback(/*InternalTransaction*/ tx, /*Exception?*/ e)
            {
                tx._innerException ??= e;
                $.$spc.System.Diagnostics.Debug.Assert$1(tx.PromotedTransaction !== null, "tx.PromotedTransaction != null");
                tx.PromotedTransaction.Rollback();
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedAborted.EnterState(tx);
            }
            /*void */ ChangeStatePromotedPhase0(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedPhase0.EnterState(tx);
            }
            /*void */ ChangeStatePromotedPhase1(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedPhase1.EnterState(tx);
            }
            //default reference type constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                return this;
            }
            static $h = 6391268;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6129124,"m":[{"r":262145,"p":[{"n":"tx","p":2786788}],"n":"PromoteDurable","d":6391268,"h":4301358564,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"e","p":47251457}],"n":"Rollback","d":6391268,"h":8596325860,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"ChangeStatePromotedPhase0","d":6391268,"h":12891293156,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"ChangeStatePromotedPhase1","d":6391268,"h":17186260452,"f":32776}],"c":[{"n":".ctor","o":"$ctor$5","d":6391268,"h":21481227748,"f":1}],"h":6391268}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStateDelegatedBase; }
            static get $fullName() { return `System.Transactions.TransactionStateDelegatedSubordinate`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionStateDelegatedAborting", ($self) => class TransactionStateDelegatedAborting extends $.$stl.System.Transactions.TransactionStatePromotedAborted
        {
            /*void */ EnterState(/*InternalTransaction*/ tx)
            {
                this.CommonEnterState(tx);
                $.$spc.System.Threading.Monitor.Exit(tx);
                try
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(tx._durableEnlistment !== null, "tx._durableEnlistment != null");
                    /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                    if (etwLog.IsEnabled())
                    {
                        etwLog.EnlistmentStatus(1/*TraceSourceType.TraceSourceLtm*/, tx._durableEnlistment.EnlistmentTraceId, 2/*NotificationCall.Rollback*/);
                    }
                    tx._durableEnlistment.PromotableSinglePhaseNotification.System$Transactions$IPromotableSinglePhaseNotification$Rollback(tx._durableEnlistment.SinglePhaseEnlistment);
                }
                finally
                {
                    {
                        $.$spc.System.Threading.Monitor.Enter(tx);
                    }
                }
            }
            /*void */ BeginCommit(/*InternalTransaction*/ tx, /*bool*/ asyncCommit, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw $.$stl.System.Transactions.TransactionException.CreateTransactionStateException$1(tx._innerException, tx.DistributedTxId);
            }
            /*void */ ChangeStatePromotedAborted(/*InternalTransaction*/ tx)
            {
                $.$stl.System.Transactions.TransactionState.TransactionStatePromotedAborted.EnterState(tx);
            }
            //default reference type constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                return this;
            }
            static $h = 6063588;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6784484,"m":[{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"EnterState","d":6063588,"h":4301030884,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788},{"n":"asyncCommit","p":262145},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginCommit","d":6063588,"h":8595998180,"f":32776},{"r":65537,"p":[{"n":"tx","p":2786788}],"n":"ChangeStatePromotedAborted","d":6063588,"h":12890965476,"f":32776}],"c":[{"n":".ctor","o":"$ctor$5","d":6063588,"h":17185932772,"f":1}],"h":6063588}; }
            static get $b() { return $.$stl.System.Transactions.TransactionStatePromotedAborted; }
            static get $fullName() { return `System.Transactions.TransactionStateDelegatedAborting`; }
        });
        
        $asm.$cls("$stl.System.Transactions.RecoveringInternalEnlistment", ($self) => class RecoveringInternalEnlistment extends $.$stl.System.Transactions.DurableInternalEnlistment
        {
            /*object*/ _syncRoot = null;
            $ctor$7(/*Enlistment*/ enlistment, /*IEnlistmentNotification*/ twoPhaseNotifications, /*object*/ syncRoot)
            {
                super.$ctor$6(enlistment, twoPhaseNotifications);
                {
                    this._syncRoot = syncRoot;
                }
                return this;
            }
            /*object */ get SyncRoot()
            {
                return this._syncRoot;
            }
            static $h = 4031972;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1607140,"p":[{"p":131073,"g":{"r":0,"d":0,"h":17183901156,"f":32776},"n":"SyncRoot","d":4031972,"h":12888933860,"f":32776}],"l":[{"t":131073,"n":"_syncRoot","d":4031972,"h":4298999268,"f":2}],"c":[{"p":[{"n":"enlistment","p":1738212},{"n":"twoPhaseNotifications","p":2590180},{"n":"syncRoot","p":131073}],"n":".ctor","o":"$ctor$7","d":4031972,"h":8593966564,"f":8}],"i":[3114468,2655716],"h":4031972}; }
            static get $b() { return $.$stl.System.Transactions.DurableInternalEnlistment; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stl.System.Transactions.ISinglePhaseNotificationInternal, $.$stl.System.Transactions.IEnlistmentNotificationInternal ]; }
            static get $fullName() { return `System.Transactions.RecoveringInternalEnlistment`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionException", ($self) => class TransactionException extends $.$spc.System.SystemException
        {
            static /*bool */ IncludeDistributedTxId(/*Guid*/ distributedTxId)
            {
                return ($.$spc.System.Guid.op_Inequality(distributedTxId, $.$spc.System.Guid.Empty) && $.$stl.System.Transactions.Configuration.AppSettings.IncludeDistributedTxIdInExceptionMessage);
            }
            static /*TransactionException */ Create(/*string?*/ message, /*Exception?*/ innerException)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace$1(2/*TransactionExceptionType.TransactionException*/, message, innerException === null ? $.$spc.System.String.Empty : $.$spc.System.Exception.ToString.call(innerException));
                }
                return new $.$stl.System.Transactions.TransactionException().$ctor$11(message, innerException);
            }
            static /*TransactionException */ CreateTransactionStateException(/*Exception?*/ innerException)
            {
                return $.$stl.System.Transactions.TransactionException.Create($.$stl.System.SR.TransactionStateException, innerException);
            }
            static /*Exception */ CreateEnlistmentStateException(/*Exception?*/ innerException, /*Guid*/ distributedTxId)
            {
                /*string*/ let messagewithTxId = $.$stl.System.SR.EnlistmentStateException;
                if ($.$stl.System.Transactions.TransactionException.IncludeDistributedTxId(distributedTxId))
                {
                    messagewithTxId = $.$stl.System.SR.Format$1($.$stl.System.SR.DistributedTxIDInTransactionException, messagewithTxId, distributedTxId);
                }
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace$1(0/*TransactionExceptionType.InvalidOperationException*/, messagewithTxId, innerException === null ? $.$spc.System.String.Empty : $.$spc.System.Exception.ToString.call(innerException));
                }
                return new $.$spc.System.InvalidOperationException().$ctor$11(messagewithTxId, innerException);
            }
            static /*Exception */ CreateInvalidOperationException(/*TraceSourceType*/ traceSource, /*string?*/ message, /*Exception?*/ innerException)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace(traceSource, 0/*TransactionExceptionType.InvalidOperationException*/, message, innerException === null ? $.$spc.System.String.Empty : $.$spc.System.Exception.ToString.call(innerException));
                }
                return new $.$spc.System.InvalidOperationException().$ctor$11(message, innerException);
            }
            $ctor$9()
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            $ctor$10(/*string?*/ message)
            {
                super.$ctor$6(message);
                {
                }
                return this;
            }
            $ctor$11(/*string?*/ message, /*Exception?*/ innerException)
            {
                super.$ctor$7(message, innerException);
                {
                }
                return this;
            }
            $ctor$12(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor$8(info, context);
                {
                }
                return this;
            }
            static /*TransactionException */ Create$1(/*string?*/ message, /*Guid*/ distributedTxId)
            {
                if ($.$stl.System.Transactions.TransactionException.IncludeDistributedTxId(distributedTxId))
                {
                    return new $.$stl.System.Transactions.TransactionException().$ctor$10($.$stl.System.SR.Format$1($.$stl.System.SR.DistributedTxIDInTransactionException, message, distributedTxId));
                }
                return new $.$stl.System.Transactions.TransactionException().$ctor$10(message);
            }
            static /*TransactionException */ Create$2(/*string?*/ message, /*Exception?*/ innerException, /*Guid*/ distributedTxId)
            {
                /*string?*/ let messagewithTxId = message;
                if ($.$stl.System.Transactions.TransactionException.IncludeDistributedTxId(distributedTxId))
                {
                    messagewithTxId = $.$stl.System.SR.Format$1($.$stl.System.SR.DistributedTxIDInTransactionException, messagewithTxId, distributedTxId);
                }
                return $.$stl.System.Transactions.TransactionException.Create(messagewithTxId, innerException);
            }
            static /*TransactionException */ CreateTransactionStateException$1(/*Exception?*/ innerException, /*Guid*/ distributedTxId)
            {
                return $.$stl.System.Transactions.TransactionException.Create$2($.$stl.System.SR.TransactionStateException, innerException, distributedTxId);
            }
            static /*Exception */ CreateTransactionCompletedException(/*Guid*/ distributedTxId)
            {
                /*string*/ let messagewithTxId = $.$stl.System.SR.TransactionAlreadyCompleted;
                if ($.$stl.System.Transactions.TransactionException.IncludeDistributedTxId(distributedTxId))
                {
                    messagewithTxId = $.$stl.System.SR.Format$1($.$stl.System.SR.DistributedTxIDInTransactionException, messagewithTxId, distributedTxId);
                }
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace$1(0/*TransactionExceptionType.InvalidOperationException*/, messagewithTxId, $.$spc.System.String.Empty);
                }
                return new $.$spc.System.InvalidOperationException().$ctor$10(messagewithTxId);
            }
            static /*Exception */ CreateInvalidOperationException$1(/*TraceSourceType*/ traceSource, /*string?*/ message, /*Exception?*/ innerException, /*Guid*/ distributedTxId)
            {
                /*string?*/ let messagewithTxId = message;
                if ($.$stl.System.Transactions.TransactionException.IncludeDistributedTxId(distributedTxId))
                {
                    messagewithTxId = $.$stl.System.SR.Format$1($.$stl.System.SR.DistributedTxIDInTransactionException, messagewithTxId, distributedTxId);
                }
                return $.$stl.System.Transactions.TransactionException.CreateInvalidOperationException(traceSource, messagewithTxId, innerException);
            }
            static $h = 4556260;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":119668737,"h":4556260}; }
            static get $b() { return $.$spc.System.SystemException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Transactions.TransactionException`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionAbortedException", ($self) => class TransactionAbortedException extends $.$stl.System.Transactions.TransactionException
        {
            static /*TransactionAbortedException */ Create$3(/*string?*/ message, /*Exception?*/ innerException, /*Guid*/ distributedTxId)
            {
                /*string?*/ let messagewithTxId = message;
                if ($.$stl.System.Transactions.TransactionException.IncludeDistributedTxId(distributedTxId))
                {
                    messagewithTxId = $.$stl.System.SR.Format$1($.$stl.System.SR.DistributedTxIDInTransactionException, messagewithTxId, distributedTxId);
                }
                return $.$stl.System.Transactions.TransactionAbortedException.Create$4(messagewithTxId, innerException);
            }
            static /*TransactionAbortedException */ Create$4(/*string?*/ message, /*Exception?*/ innerException)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace$1(1/*TransactionExceptionType.TransactionAbortedException*/, message, innerException === null ? $.$spc.System.String.Empty : $.$spc.System.Exception.ToString.call(innerException));
                }
                return new $.$stl.System.Transactions.TransactionAbortedException().$ctor$15(message, innerException);
            }
            $ctor$13()
            {
                super.$ctor$10($.$stl.System.SR.TransactionAborted);
                {
                }
                return this;
            }
            $ctor$14(/*string?*/ message)
            {
                super.$ctor$10(message ?? $.$stl.System.SR.TransactionAborted);
                {
                }
                return this;
            }
            $ctor$15(/*string?*/ message, /*Exception?*/ innerException)
            {
                super.$ctor$11(message ?? $.$stl.System.SR.TransactionAborted, innerException);
                {
                }
                return this;
            }
            $ctor$16(/*Exception?*/ innerException)
            {
                super.$ctor$11($.$stl.System.SR.TransactionAborted, innerException);
                {
                }
                return this;
            }
            $ctor$17(/*Exception?*/ innerException, /*Guid*/ distributedTxId)
            {
                super.$ctor$11($.$stl.System.Transactions.TransactionException.IncludeDistributedTxId(distributedTxId) ? $.$stl.System.SR.Format$1($.$stl.System.SR.DistributedTxIDInTransactionException, $.$stl.System.SR.TransactionAborted, distributedTxId) : $.$stl.System.SR.TransactionAborted, innerException);
                {
                }
                return this;
            }
            $ctor$18(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor$12(info, context);
                {
                }
                return this;
            }
            static $h = 4359652;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":4556260,"h":4359652}; }
            static get $b() { return $.$stl.System.Transactions.TransactionException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Transactions.TransactionAbortedException`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionInDoubtException", ($self) => class TransactionInDoubtException extends $.$stl.System.Transactions.TransactionException
        {
            static /*TransactionInDoubtException */ Create$3(/*TraceSourceType*/ traceSource, /*string?*/ message, /*Exception?*/ innerException, /*Guid*/ distributedTxId)
            {
                /*string?*/ let messagewithTxId = message;
                if ($.$stl.System.Transactions.TransactionException.IncludeDistributedTxId(distributedTxId))
                {
                    messagewithTxId = $.$stl.System.SR.Format$1($.$stl.System.SR.DistributedTxIDInTransactionException, messagewithTxId, distributedTxId);
                }
                return $.$stl.System.Transactions.TransactionInDoubtException.Create$4(traceSource, messagewithTxId, innerException);
            }
            static /*TransactionInDoubtException */ Create$4(/*TraceSourceType*/ traceSource, /*string?*/ message, /*Exception?*/ innerException)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace(traceSource, 3/*TransactionExceptionType.TransactionInDoubtException*/, message, innerException === null ? $.$spc.System.String.Empty : $.$spc.System.Exception.ToString.call(innerException));
                }
                return new $.$stl.System.Transactions.TransactionInDoubtException().$ctor$15(message, innerException);
            }
            $ctor$13()
            {
                super.$ctor$10($.$stl.System.SR.TransactionIndoubt);
                {
                }
                return this;
            }
            $ctor$14(/*string?*/ message)
            {
                super.$ctor$10(message ?? $.$stl.System.SR.TransactionIndoubt);
                {
                }
                return this;
            }
            $ctor$15(/*string?*/ message, /*Exception?*/ innerException)
            {
                super.$ctor$11(message ?? $.$stl.System.SR.TransactionIndoubt, innerException);
                {
                }
                return this;
            }
            $ctor$16(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor$12(info, context);
                {
                }
                return this;
            }
            static $h = 4687332;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":4556260,"h":4687332}; }
            static get $b() { return $.$stl.System.Transactions.TransactionException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Transactions.TransactionInDoubtException`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionManagerCommunicationException", ($self) => class TransactionManagerCommunicationException extends $.$stl.System.Transactions.TransactionException
        {
            static /*TransactionManagerCommunicationException */ Create$3(/*string?*/ message, /*Exception?*/ innerException)
            {
                /*TransactionsEtwProvider*/ let etwLog = $.$stl.System.Transactions.TransactionsEtwProvider.Log;
                if (etwLog.IsEnabled())
                {
                    etwLog.TransactionExceptionTrace$1(4/*TransactionExceptionType.TransactionManagerCommunicationException*/, message, innerException === null ? $.$spc.System.String.Empty : $.$spc.System.Exception.ToString.call(innerException));
                }
                return new $.$stl.System.Transactions.TransactionManagerCommunicationException().$ctor$15(message, innerException);
            }
            static /*TransactionManagerCommunicationException */ Create$4(/*Exception?*/ innerException)
            {
                return $.$stl.System.Transactions.TransactionManagerCommunicationException.Create$3($.$stl.System.SR.TransactionManagerCommunicationException, innerException);
            }
            $ctor$13()
            {
                super.$ctor$10($.$stl.System.SR.TransactionManagerCommunicationException);
                {
                }
                return this;
            }
            $ctor$14(/*string?*/ message)
            {
                super.$ctor$10(message ?? $.$stl.System.SR.TransactionManagerCommunicationException);
                {
                }
                return this;
            }
            $ctor$15(/*string?*/ message, /*Exception?*/ innerException)
            {
                super.$ctor$11(message ?? $.$stl.System.SR.TransactionManagerCommunicationException, innerException);
                {
                }
                return this;
            }
            $ctor$16(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor$12(info, context);
                {
                }
                return this;
            }
            static $h = 4949476;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":4556260,"h":4949476}; }
            static get $b() { return $.$stl.System.Transactions.TransactionException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Transactions.TransactionManagerCommunicationException`; }
        });
        
        $asm.$cls("$stl.System.Transactions.TransactionPromotionException", ($self) => class TransactionPromotionException extends $.$stl.System.Transactions.TransactionException
        {
            $ctor$13()
            {
                this.$ctor$14($.$stl.System.SR.PromotionFailed);
                {
                }
                return this;
            }
            $ctor$14(/*string?*/ message)
            {
                super.$ctor$10(message ?? $.$stl.System.SR.PromotionFailed);
                {
                }
                return this;
            }
            $ctor$15(/*string?*/ message, /*Exception?*/ innerException)
            {
                super.$ctor$11(message ?? $.$stl.System.SR.PromotionFailed, innerException);
                {
                }
                return this;
            }
            $ctor$16(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor$12(info, context);
                {
                }
                return this;
            }
            static $h = 5080548;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":4556260,"h":5080548}; }
            static get $b() { return $.$stl.System.Transactions.TransactionException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Transactions.TransactionPromotionException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Collections.NonGeneric", "NetJs.System.Threading.Thread", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.Threading.Overlapped", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Xml.ReaderWriter"))