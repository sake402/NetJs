
(function ($global, $, $$, $sc, $sm, $spu, $sr, $st, $scn, $scm, $so, $scp, $scs) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Web.HttpUtility", 
    {"h":48516,"f":"System.Web.HttpUtility","v":"1.0.35.0","a":[{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Beff628fa5ab8bd29ec37e9c13a50148694bea088","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Web.HttpUtility","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Web.HttpUtility","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115081217,"c":4410048513,"a":[{"v":"browser1.0","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser1.0","t":1310721}]},{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$swh.System.Web.IHtmlString", ($self) => class IHtmlString
        {
            static $h = 507268;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":1310721,"n":"ToHtmlString","o":"System$Web$IHtmlString$ToHtmlString","d":507268,"h":4295474564,"f":16777473}],"h":507268}; }
            static get $fullName() { return `System.Web.IHtmlString`; }
        });
        
        $asm.$cls("$swh.System.Web.Util.UriUtil", ($self) => class UriUtil
        {
            static /*bool */ TrySplitUriForPathEncode(/*string*/ input, /*out ReadOnlySpan<char>*/ schemeAndAuthority, /*out string?*/ path, /*out ReadOnlySpan<char>*/ queryAndFragment)
            {
                /*int*/ let queryFragmentSeparatorPos = $.$$.System.MemoryExtensions.IndexOfAny$8($.$$.System.Char, $.$$.System.MemoryExtensions.AsSpan$4(input), /*?*/ 63, /*#*/ 35);
                /*string*/ let inputWithoutQueryFragment;
                if (queryFragmentSeparatorPos >= 0)
                {
                    inputWithoutQueryFragment = $.$$.System.String.Substring.call(input, 0, queryFragmentSeparatorPos);
                    queryAndFragment.$v = $.$$.System.MemoryExtensions.AsSpan$2(input, queryFragmentSeparatorPos);
                }
                else 
                {
                    inputWithoutQueryFragment = input;
                    queryAndFragment.$v = $.$$.System.ReadOnlySpan$$($.$$.System.Char).Empty;
                }
                /*Uri?*/ let uri;
                if ($.$spu.System.Uri.TryCreate(inputWithoutQueryFragment, 1/*UriKind.Absolute*/, $.$ref(() => uri, ($v) => uri = $v, $.$spu.System.Uri)))
                {
                    /*string*/ let authority = uri.Authority;
                    if (!$.$$.System.String.IsNullOrEmpty(authority))
                    {
                        /*int*/ let authorityIndex = $.$$.System.String.IndexOf$8.call(inputWithoutQueryFragment, authority, 5/*StringComparison.OrdinalIgnoreCase*/);
                        if (authorityIndex >= 0)
                        {
                            /*int*/ let schemeAndAuthorityLength = ((authorityIndex + authority.length) | 0);
                            schemeAndAuthority.$v = $.$$.System.MemoryExtensions.AsSpan$1(input, 0, schemeAndAuthorityLength);
                            path.$v = $.$$.System.String.Substring$1.call(inputWithoutQueryFragment, schemeAndAuthorityLength);
                            return true;
                        }
                    }
                }
                schemeAndAuthority.$v = $.$$.System.ReadOnlySpan$$($.$$.System.Char).Empty;
                path.$v = null;
                queryAndFragment.$v = $.$$.System.ReadOnlySpan$$($.$$.System.Char).Empty;
                return false;
            }
            static $h = 703876;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"input","p":1310721},{"n":"schemeAndAuthority","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h,"f":2},{"n":"path","p":1310721,"f":2},{"n":"queryAndFragment","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h,"f":2}],"n":"TrySplitUriForPathEncode","d":703876,"h":4295671172,"f":16777256}],"h":703876}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Web.Util.UriUtil`; }
        });
        
        $asm.$cls("$swh.System.Web.Util.HttpEncoder", ($self) => class HttpEncoder
        {
            /*int*/ static MaxStackAllocUrlLength = 256;
            /*int*/ static StackallocThreshold = 512;
            /*SearchValues<byte>*/ static s_urlSafeBytes = null;
            /*SearchValues<char>*/ static s_invalidJavaScriptChars = null;
            static /*string? */ HtmlAttributeEncode$1(/*string?*/ value)
            {
                if ($.$$.System.String.IsNullOrEmpty(value))
                {
                    return value;
                }
                /*int*/ let pos = $.$swh.System.Web.Util.HttpEncoder.IndexOfHtmlAttributeEncodingChars(value);
                if (pos < 0)
                {
                    return value;
                }
                /*StringWriter*/ let writer = new $.$$.System.IO.StringWriter().$ctor$5($.$$.System.Globalization.CultureInfo.InvariantCulture);
                $.$swh.System.Web.Util.HttpEncoder.HtmlAttributeEncodeInternal(value, pos, writer);
                return $.$$.System.IO.StringWriter.ToString.call(writer);
            }
            static /*void */ HtmlAttributeEncode(/*string?*/ value, /*TextWriter*/ output)
            {
                if ($.$$.System.String.op_Equality(value, null))
                {
                    return;
                }
                $.$$.System.ArgumentNullException.ThrowIfNull$2(output, "output");
                /*int*/ let pos = $.$swh.System.Web.Util.HttpEncoder.IndexOfHtmlAttributeEncodingChars(value);
                if (pos < 0)
                {
                    output.Write$16(value);
                    return;
                }
                $.$swh.System.Web.Util.HttpEncoder.HtmlAttributeEncodeInternal(value, pos, output);
            }
            static /*void */ HtmlAttributeEncodeInternal(/*string*/ s, /*int*/ index, /*TextWriter*/ output)
            {
                output.Write$9($.$$.System.MemoryExtensions.AsSpan$1(s, 0, index));
                /*ReadOnlySpan<char>*/ let remaining = $.$$.System.MemoryExtensions.AsSpan$2(s, index);
                for(/*int*/ let i = 0; i < remaining.Length; i++)
                {
                    /*char*/ let ch = remaining.get_Item(i).$v;
                    if (ch <= /*<*/ 60)
                    {
                        switch(ch)
                        {
                            case /*<*/ 60:
                            output.Write$16("&lt;");
                            break;
                            case /*\"*/ 34:
                            output.Write$16("&quot;");
                            break;
                            case /*'*/ 39:
                            output.Write$16("&#39;");
                            break;
                            case /*&*/ 38:
                            output.Write$16("&amp;");
                            break;
                            default:
                            output.Write$1(ch);
                            break;
                        }
                    }
                    else 
                    {
                        output.Write$1(ch);
                    }
                }
            }
            static /*string? */ HtmlDecode$1(/*string?*/ value)
            {
                return $.$$.System.String.IsNullOrEmpty(value) ? value : $.$$.System.Net.WebUtility.HtmlDecode$2(value);
            }
            static /*void */ HtmlDecode(/*string?*/ value, /*TextWriter*/ output)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(output, "output");
                output.Write$16($.$$.System.Net.WebUtility.HtmlDecode$2(value));
            }
            static /*string? */ HtmlEncode$1(/*string?*/ value)
            {
                return $.$$.System.String.IsNullOrEmpty(value) ? value : $.$$.System.Net.WebUtility.HtmlEncode$2(value);
            }
            static /*void */ HtmlEncode(/*string?*/ value, /*TextWriter*/ output)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(output, "output");
                output.Write$16($.$$.System.Net.WebUtility.HtmlEncode$2(value));
            }
            static /*int */ IndexOfHtmlAttributeEncodingChars(/*string*/ s)
            {
                return $.$$.System.MemoryExtensions.IndexOfAny$4($.$$.System.Char, $.$$.System.MemoryExtensions.AsSpan$4(s), $.$$.System.String.op_Implicit("<\"'&"));
            }
            static /*string */ JavaScriptStringEncode(/*string?*/ value, /*bool*/ addDoubleQuotes)
            {
                /*int*/ let i = $.$$.System.MemoryExtensions.IndexOfAny$2($.$$.System.Char, $.$$.System.MemoryExtensions.AsSpan$4(value), $.$swh.System.Web.Util.HttpEncoder.s_invalidJavaScriptChars);
                if (i < 0)
                {
                    return addDoubleQuotes ? `\"${value}\"` : value ?? $.$$.System.String.Empty;
                }
                return EncodeCore($.$$.System.String.op_Implicit(value), i, addDoubleQuotes);
                /*static string*/  function EncodeCore(/*ReadOnlySpan<char>*/ value, /*int*/ i, /*bool*/ addDoubleQuotes)
                {
                    /*var*/ let vsb = new $.$swh.System.Text.ValueStringBuilder().$ctor$4($.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Char, 512/*StackallocThreshold*/, null));
                    if (addDoubleQuotes)
                    {
                        vsb.Append$1(/*\"*/ 34);
                    }
                    /*ReadOnlySpan<char>*/ let chars = value;
                    do
                    {
                        vsb.Append$2(chars.Slice(0, i));
                        /*char*/ let c = chars.get_Item(i).$v;
                        chars = chars.Slice$1(((i + 1) | 0));
                        switch(c)
                        {
                            case /*\r*/ 13:
                            vsb.Append$3("\\r");
                            break;
                            case /*\t*/ 9:
                            vsb.Append$3("\\t");
                            break;
                            case /*\"*/ 34:
                            vsb.Append$3("\\\"");
                            break;
                            case /*\\*/ 92:
                            vsb.Append$3("\\\\");
                            break;
                            case /*\n*/ 10:
                            vsb.Append$3("\\n");
                            break;
                            case /*\u0008*/ 8:
                            vsb.Append$3("\\b");
                            break;
                            case /*\u000C*/ 12:
                            vsb.Append$3("\\f");
                            break;
                            default:
                            vsb.Append$3("\\u");
                            vsb.AppendSpanFormattable($.$$.System.Int32, $.$cast(c, $.$$.System.Int32), "x4", null);
                            break;
                        }
                        i = $.$$.System.MemoryExtensions.IndexOfAny$2($.$$.System.Char, chars, $.$swh.System.Web.Util.HttpEncoder.s_invalidJavaScriptChars);
                    }
                    while(i >= 0);
                    vsb.Append$2(chars);
                    if (addDoubleQuotes)
                    {
                        vsb.Append$1(/*\"*/ 34);
                    }
                    return $.$swh.System.Text.ValueStringBuilder.ToString.call(vsb);
                }
            }
            static /*byte[]? */ UrlDecode$1(/*byte[]?*/ bytes, /*int*/ offset, /*int*/ count)
            {
                if (!$.$swh.System.Web.Util.HttpEncoder.ValidateUrlEncodingParameters(bytes, offset, count))
                {
                    return null;
                }
                return $.$swh.System.Web.Util.HttpEncoder.UrlDecode$2($.$$.System.Span$$($.$$.System.Byte).op_Implicit($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, bytes, offset, count)));
            }
            static /*byte[] */ UrlDecode$2(/*ReadOnlySpan<byte>*/ bytes)
            {
                /*int*/ let decodedBytesCount = 0;
                /*int*/ let count = bytes.Length;
                /*Span<byte>*/ let decodedBytes = count <= 512/*StackallocThreshold*/ ? $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Byte, 512/*StackallocThreshold*/, null) : $.$$.System.Span$$($.$$.System.Byte).op_Implicit$2($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Byte), null, [count], null));
                for(/*int*/ let i = 0; i < count; i++)
                {
                    /*byte*/ let b = bytes.get_Item(i).$v;
                    if (b === /*+*/ 43)
                    {
                        b = /* */ 32;
                    }
                    else if (b === /*%*/ 37 && i < ((count - 2) | 0))
                    {
                        /*int*/ let h1 = $.$swh.System.HexConverter.FromChar(bytes.get_Item(((i + 1) | 0)).$v);
                        /*int*/ let h2 = $.$swh.System.HexConverter.FromChar(bytes.get_Item(((i + 2) | 0)).$v);
                        if ((h1 | h2) !== 255)
                        {
                            b = $.$cast(((h1 << 4) | h2), $.$$.System.Byte);
                            i += 2;
                        }
                    }
                    decodedBytes.get_Item(decodedBytesCount++).$v = b;
                }
                return decodedBytes.Slice(0, decodedBytesCount).ToArray();
            }
            static /*string? */ UrlDecode(/*byte[]?*/ bytes, /*int*/ offset, /*int*/ count, /*Encoding*/ encoding)
            {
                if (!$.$swh.System.Web.Util.HttpEncoder.ValidateUrlEncodingParameters(bytes, offset, count))
                {
                    return null;
                }
                /*UrlDecoder*/ let helper = count <= 256/*MaxStackAllocUrlLength*/ ? new $.$swh.System.Web.Util.HttpEncoder.UrlDecoder().$ctor$3($.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Char, 256/*MaxStackAllocUrlLength*/, null), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Byte, 256/*MaxStackAllocUrlLength*/, null), encoding) : new $.$swh.System.Web.Util.HttpEncoder.UrlDecoder().$ctor$3($.$$.System.Span$$($.$$.System.Char).op_Implicit$2($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Char), null, [count], null)), $.$$.System.Span$$($.$$.System.Byte).op_Implicit$2($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Byte), null, [count], null)), encoding);
                for(/*int*/ let i = 0; i < count; i++)
                {
                    /*int*/ let pos = ((offset + i) | 0);
                    /*byte*/ let b = $.$$.System.Array.$ReadT1.call(bytes, pos);
                    if (b === /*+*/ 43)
                    {
                        b = /* */ 32;
                    }
                    else if (b === /*%*/ 37 && i < ((count - 2) | 0))
                    {
                        if ($.$$.System.Array.$ReadT1.call(bytes, ((pos + 1) | 0)) === /*u*/ 117 && i < ((count - 5) | 0))
                        {
                            /*int*/ let h1 = $.$swh.System.HexConverter.FromChar($.$$.System.Array.$ReadT1.call(bytes, ((pos + 2) | 0)));
                            /*int*/ let h2 = $.$swh.System.HexConverter.FromChar($.$$.System.Array.$ReadT1.call(bytes, ((pos + 3) | 0)));
                            /*int*/ let h3 = $.$swh.System.HexConverter.FromChar($.$$.System.Array.$ReadT1.call(bytes, ((pos + 4) | 0)));
                            /*int*/ let h4 = $.$swh.System.HexConverter.FromChar($.$$.System.Array.$ReadT1.call(bytes, ((pos + 5) | 0)));
                            if ((h1 | h2 | h3 | h4) !== 255)
                            {
                                /*char*/ let ch = $.$cast(((h1 << 12) | (h2 << 8) | (h3 << 4) | h4), $.$$.System.Char);
                                i += 5;
                                helper.AddChar(ch);
                                continue;
                            }
                        }
                        else 
                        {
                            /*int*/ let h1 = $.$swh.System.HexConverter.FromChar($.$$.System.Array.$ReadT1.call(bytes, ((pos + 1) | 0)));
                            /*int*/ let h2 = $.$swh.System.HexConverter.FromChar($.$$.System.Array.$ReadT1.call(bytes, ((pos + 2) | 0)));
                            if ((h1 | h2) !== 255)
                            {
                                b = $.$cast(((h1 << 4) | h2), $.$$.System.Byte);
                                i += 2;
                            }
                        }
                    }
                    helper.AddByte(b);
                }
                return helper.GetString();
            }
            static /*string? */ UrlDecode$4(/*string?*/ value, /*Encoding*/ encoding)
            {
                if ($.$$.System.String.op_Equality(value, null))
                {
                    return null;
                }
                return $.$swh.System.Web.Util.HttpEncoder.UrlDecode$3($.$$.System.MemoryExtensions.AsSpan$4(value), encoding);
            }
            static /*string */ UrlDecode$3(/*ReadOnlySpan<char>*/ value, /*Encoding*/ encoding)
            {
                if (value.IsEmpty)
                {
                    return $.$$.System.String.Empty;
                }
                /*int*/ let count = value.Length;
                /*UrlDecoder*/ let helper = count <= 256/*MaxStackAllocUrlLength*/ ? new $.$swh.System.Web.Util.HttpEncoder.UrlDecoder().$ctor$3($.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Char, 256/*MaxStackAllocUrlLength*/, null), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Byte, 256/*MaxStackAllocUrlLength*/, null), encoding) : new $.$swh.System.Web.Util.HttpEncoder.UrlDecoder().$ctor$3($.$$.System.Span$$($.$$.System.Char).op_Implicit$2($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Char), null, [count], null)), $.$$.System.Span$$($.$$.System.Byte).op_Implicit$2($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Byte), null, [count], null)), encoding);
                for(/*int*/ let pos = 0; pos < count; pos++)
                {
                    /*char*/ let ch = value.get_Item(pos).$v;
                    if (ch === /*+*/ 43)
                    {
                        ch = /* */ 32;
                    }
                    else if (ch === /*%*/ 37 && pos < ((count - 2) | 0))
                    {
                        if (value.get_Item(((pos + 1) | 0)).$v === /*u*/ 117 && pos < ((count - 5) | 0))
                        {
                            /*int*/ let h1 = $.$swh.System.HexConverter.FromChar(value.get_Item(((pos + 2) | 0)).$v);
                            /*int*/ let h2 = $.$swh.System.HexConverter.FromChar(value.get_Item(((pos + 3) | 0)).$v);
                            /*int*/ let h3 = $.$swh.System.HexConverter.FromChar(value.get_Item(((pos + 4) | 0)).$v);
                            /*int*/ let h4 = $.$swh.System.HexConverter.FromChar(value.get_Item(((pos + 5) | 0)).$v);
                            if ((h1 | h2 | h3 | h4) !== 255)
                            {
                                ch = $.$cast(((h1 << 12) | (h2 << 8) | (h3 << 4) | h4), $.$$.System.Char);
                                pos += 5;
                                helper.AddChar(ch);
                                continue;
                            }
                        }
                        else 
                        {
                            /*int*/ let h1 = $.$swh.System.HexConverter.FromChar(value.get_Item(((pos + 1) | 0)).$v);
                            /*int*/ let h2 = $.$swh.System.HexConverter.FromChar(value.get_Item(((pos + 2) | 0)).$v);
                            if ((h1 | h2) !== 255)
                            {
                                /*byte*/ let b = $.$cast(((h1 << 4) | h2), $.$$.System.Byte);
                                pos += 2;
                                helper.AddByte(b);
                                continue;
                            }
                        }
                    }
                    if ((ch & 65408) === 0)
                    {
                        helper.AddByte($.$cast(ch, $.$$.System.Byte));
                    }
                    else 
                    {
                        helper.AddChar(ch);
                    }
                }
                return helper.GetString();
            }
            static /*byte[]? */ UrlEncode(/*byte[]?*/ bytes, /*int*/ offset, /*int*/ count)
            {
                if (!$.$swh.System.Web.Util.HttpEncoder.ValidateUrlEncodingParameters(bytes, offset, count))
                {
                    return null;
                }
                return $.$swh.System.Web.Util.HttpEncoder.UrlEncode$2($.$$.System.Span$$($.$$.System.Byte).op_Implicit($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, bytes, offset, count)));
            }
            static /*byte[] */ UrlEncode$2(/*ReadOnlySpan<byte>*/ bytes)
            {
                /*int*/ let cUnsafe;
                if (!$.$swh.System.Web.Util.HttpEncoder.NeedsEncoding(bytes, $.$ref(() => cUnsafe, ($v) => cUnsafe = $v, $.$$.System.Int32)))
                {
                    return bytes.ToArray();
                }
                return $.$swh.System.Web.Util.HttpEncoder.UrlEncode$1(bytes, cUnsafe);
            }
            static /*byte[] */ UrlEncode$1(/*ReadOnlySpan<byte>*/ bytes, /*int*/ cUnsafe)
            {
                /*byte[]*/ let expandedBytes = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Byte), null, [((bytes.Length + ((cUnsafe * 2) | 0)) | 0)], null);
                /*int*/ let pos = 0;
                var $en2 = bytes.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var b = $en2.Current.$v;
                    {
                        if ($.$swh.System.Web.Util.HttpEncoder.s_urlSafeBytes.Contains(b))
                        {
                            $.$$.System.Array.$WriteT1.call(expandedBytes, b, pos++);
                        }
                        else if (b === /* */ 32)
                        {
                            $.$$.System.Array.$WriteT1.call(expandedBytes, /*+*/ 43, pos++);
                        }
                        else 
                        {
                            $.$$.System.Array.$WriteT1.call(expandedBytes, /*%*/ 37, pos++);
                            $.$$.System.Array.$WriteT1.call(expandedBytes, $.$cast($.$swh.System.HexConverter.ToCharLower(b >>> 4), $.$$.System.Byte), pos++);
                            $.$$.System.Array.$WriteT1.call(expandedBytes, $.$cast($.$swh.System.HexConverter.ToCharLower(b), $.$$.System.Byte), pos++);
                        }
                    }
                }
                return expandedBytes;
            }
            static /*bool */ NeedsEncoding(/*ReadOnlySpan<byte>*/ bytes, /*out int*/ cUnsafe)
            {
                cUnsafe.$v = 0;
                /*int*/ let i = $.$$.System.MemoryExtensions.IndexOfAnyExcept($.$$.System.Byte, bytes, $.$swh.System.Web.Util.HttpEncoder.s_urlSafeBytes);
                if (i < 0)
                {
                    return false;
                }
                var $en2 = bytes.Slice$1(i).GetEnumerator();
                while ($en2.MoveNext())
                {
                    var b = $en2.Current.$v;
                    {
                        if (!$.$swh.System.Web.Util.HttpEncoder.s_urlSafeBytes.Contains(b) && b !== /* */ 32)
                        {
                            cUnsafe.$v++;
                        }
                    }
                }
                return true;
            }
            static /*byte[] */ UrlEncode$3(/*string*/ str, /*Encoding*/ e)
            {
                if (e.GetMaxByteCount(str.length) <= 512/*StackallocThreshold*/)
                {
                    /*Span<byte>*/ let byteSpan = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Byte, 512/*StackallocThreshold*/, null);
                    /*int*/ let encodedBytes = e.GetBytes$5($.$$.System.String.op_Implicit(str), byteSpan);
                    return $.$swh.System.Web.Util.HttpEncoder.UrlEncode$2($.$$.System.Span$$($.$$.System.Byte).op_Implicit(byteSpan.Slice(0, encodedBytes)));
                }
                /*byte[]*/ let bytes = e.GetBytes$8(str);
                /*int*/ let cUnsafe;
                return $.$swh.System.Web.Util.HttpEncoder.NeedsEncoding($.$$.System.ReadOnlySpan$$($.$$.System.Byte).op_Implicit$1(bytes), $.$ref(() => cUnsafe, ($v) => cUnsafe = $v, $.$$.System.Int32)) ? $.$swh.System.Web.Util.HttpEncoder.UrlEncode$1($.$$.System.ReadOnlySpan$$($.$$.System.Byte).op_Implicit$1(bytes), cUnsafe) : bytes;
            }
            static /*string? */ UrlEncodeUnicode(/*string?*/ value)
            {
                if ($.$$.System.String.op_Equality(value, null))
                {
                    return null;
                }
                /*int*/ let l = value.length;
                /*StringBuilder*/ let sb = new $.$$.System.Text.StringBuilder().$ctor$4(l);
                for(/*int*/ let i = 0; i < l; i++)
                {
                    /*char*/ let ch = $.$$.System.String.get_Chars.call(value, i);
                    if ((ch & 65408) === 0)
                    {
                        if ($.$swh.System.Web.Util.HttpEncoder.s_urlSafeBytes.Contains($.$cast(ch, $.$$.System.Byte)))
                        {
                            sb.Append$3(ch);
                        }
                        else if (ch === /* */ 32)
                        {
                            sb.Append$3(/*+*/ 43);
                        }
                        else 
                        {
                            sb.Append$3(/*%*/ 37);
                            sb.Append$3($.$swh.System.HexConverter.ToCharLower(ch >>> 4));
                            sb.Append$3($.$swh.System.HexConverter.ToCharLower(ch));
                        }
                    }
                    else 
                    {
                        sb.Append$19("%u");
                        sb.Append$3($.$swh.System.HexConverter.ToCharLower(ch >>> 12));
                        sb.Append$3($.$swh.System.HexConverter.ToCharLower(ch >>> 8));
                        sb.Append$3($.$swh.System.HexConverter.ToCharLower(ch >>> 4));
                        sb.Append$3($.$swh.System.HexConverter.ToCharLower(ch));
                    }
                }
                return $.$$.System.Text.StringBuilder.ToString.call(sb);
            }
            static /*string? */ UrlPathEncode(/*string?*/ value)
            {
                if ($.$$.System.String.IsNullOrEmpty(value))
                {
                    return value;
                }
                /*ReadOnlySpan<char>*/ let schemeAndAuthority;
                /*string?*/ let path;
                /*ReadOnlySpan<char>*/ let queryAndFragment;
                if (!$.$swh.System.Web.Util.UriUtil.TrySplitUriForPathEncode(value, $.$ref(() => schemeAndAuthority, ($v) => schemeAndAuthority = $v, $.$$.System.ReadOnlySpan$$($.$$.System.Char)), $.$ref(() => path, ($v) => path = $v, $.$$.System.String), $.$ref(() => queryAndFragment, ($v) => queryAndFragment = $v, $.$$.System.ReadOnlySpan$$($.$$.System.Char))))
                {
                    return $.$swh.System.Web.Util.HttpEncoder.UrlPathEncodeImpl(value);
                }
                return $.$$.System.String.Concat$7(schemeAndAuthority, $.$$.System.String.op_Implicit($.$swh.System.Web.Util.HttpEncoder.UrlPathEncodeImpl(path)), queryAndFragment);
            }
            static /*string */ UrlPathEncodeImpl(/*string*/ value)
            {
                if ($.$$.System.String.IsNullOrEmpty(value))
                {
                    return value;
                }
                /*int*/ let i = $.$$.System.MemoryExtensions.IndexOfAnyExceptInRange($.$$.System.Char, $.$$.System.MemoryExtensions.AsSpan$4(value), 33, 127);
                if (i < 0)
                {
                    return value;
                }
                /*int*/ let indexOfQuery = $.$$.System.String.IndexOf$3.call(value, /*?*/ 63);
                if ((indexOfQuery >>> 0) < (i >>> 0))
                {
                    return value;
                }
                /*ReadOnlySpan<char>*/ let toEncode = indexOfQuery >= 0 ? $.$$.System.MemoryExtensions.AsSpan$1(value, i, ((indexOfQuery - i) | 0)) : $.$$.System.MemoryExtensions.AsSpan$2(value, i);
                /*byte[]*/ let bytes = $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared.Rent($.$$.System.Text.Encoding.UTF8.GetMaxByteCount(toEncode.Length));
                /*int*/ let utf8Length = $.$$.System.Text.Encoding.UTF8.GetBytes$5(toEncode, $.$$.System.Span$$($.$$.System.Byte).op_Implicit$2(bytes));
                /*char[]*/ let chars = $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared.Rent(((utf8Length * 3) | 0));
                /*int*/ let charCount = 0;
                var $en2 = $.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, bytes, 0, utf8Length).GetEnumerator();
                while ($en2.MoveNext())
                {
                    var b = $en2.Current.$v;
                    {
                        if (!$.$$.System.Char.IsBetween(b, 33, 127))
                        {
                            $.$$.System.Array.$WriteT1.call(chars, /*%*/ 37, charCount++);
                            $.$$.System.Array.$WriteT1.call(chars, $.$swh.System.HexConverter.ToCharLower(b >>> 4), charCount++);
                            $.$$.System.Array.$WriteT1.call(chars, $.$swh.System.HexConverter.ToCharLower(b), charCount++);
                        }
                        else 
                        {
                            $.$$.System.Array.$WriteT1.call(chars, b, charCount++);
                        }
                    }
                }
                $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared.Return(bytes, false);
                /*string*/ let result = $.$$.System.String.Concat$7($.$$.System.MemoryExtensions.AsSpan$1(value, 0, i), $.$$.System.Span$$($.$$.System.Char).op_Implicit($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Char, chars, 0, charCount)), indexOfQuery >= 0 ? $.$$.System.MemoryExtensions.AsSpan$2(value, indexOfQuery) : $.$$.System.ReadOnlySpan$$($.$$.System.Char).Empty);
                $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared.Return(chars, false);
                return result;
            }
            static /*bool */ ValidateUrlEncodingParameters(/*byte[]?*/ bytes, /*int*/ offset, /*int*/ count)
            {
                if (bytes === null && count === 0)
                {
                    return false;
                }
                $.$$.System.ArgumentNullException.ThrowIfNull$2(bytes, "bytes");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, offset, "offset");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$$.System.Int32, offset, bytes.length, "offset");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, count, "count");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$$.System.Int32, count, ((bytes.length - offset) | 0), "count");
                return true;
            }
            static $_UrlDecoder;
            static get UrlDecoder()
            {
                let $cls = $.$swh.System.Web.Util.HttpEncoder;
                return $cls.$_UrlDecoder ??= $asm.$nstr("$swh.System.Web.Util.HttpEncoder.UrlDecoder", ($self) => class UrlDecoder extends $.$$.System.ValueType
                {
                    /*int*/  get _numChars() { return this.$getField(0, 4); }
                    /*int*/  set _numChars(value) { this.$setField(0, 4, value); }
                    /*Span<char>*/  get _charBuffer() { return this.$getField(4, 6); }
                    /*Span<char>*/  set _charBuffer(value) { this.$setField(4, 6, value); }
                    /*int*/  get _numBytes() { return this.$getField(10, 4); }
                    /*int*/  set _numBytes(value) { this.$setField(10, 4, value); }
                    /*Span<byte>*/  get _byteBuffer() { return this.$getField(14, 5); }
                    /*Span<byte>*/  set _byteBuffer(value) { this.$setField(14, 5, value); }
                    /*Encoding*/  get _encoding() { return this.$getField(19, 4); }
                    /*Encoding*/  set _encoding(value) { this.$setField(19, 4, value); }
                    /*void */ FlushBytes()
                    {
                        if (this._numBytes > 0)
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(!this._byteBuffer.IsEmpty, "!_byteBuffer.IsEmpty");
                            this._numChars += this._encoding.GetChars$5($.$$.System.Span$$($.$$.System.Byte).op_Implicit(this._byteBuffer.Slice(0, this._numBytes)), this._charBuffer.Slice$1(this._numChars));
                            this._numBytes = 0;
                        }
                    }
                    $ctor$3(/*Span<char>*/ charBuffer, /*Span<byte>*/ byteBuffer, /*Encoding*/ encoding)
                    {
                        super.$ctor$1();
                        {
                            this._charBuffer = charBuffer;
                            this._byteBuffer = byteBuffer;
                            this._encoding = encoding;
                        }
                        return this;
                    }
                    /*void */ AddChar(/*char*/ ch)
                    {
                        if (this._numBytes > 0)
                        {
                            this.FlushBytes();
                        }
                        this._charBuffer.get_Item(this._numChars++).$v = ch;
                    }
                    /*void */ AddByte(/*byte*/ b)
                    {
                        {
                            this._byteBuffer.get_Item(this._numBytes++).$v = b;
                        }
                    }
                    /*string */ GetString()
                    {
                        if (this._numBytes > 0)
                        {
                            this.FlushBytes();
                        }
                        /*Span<char>*/ let chars = this._charBuffer.Slice(0, this._numChars);
                        /*char*/ let HIGH_SURROGATE_START = /*\uD800*/ 55296;
                        /*char*/ let LOW_SURROGATE_END = /*\uDFFF*/ 57343;
                        /*int*/ let idxOfFirstSurrogate = $.$$.System.MemoryExtensions.IndexOfAnyInRange($.$$.System.Char, $.$$.System.Span$$($.$$.System.Char).op_Implicit(chars), HIGH_SURROGATE_START, LOW_SURROGATE_END);
                        for(/*int*/ let i = idxOfFirstSurrogate; (i >>> 0) < (chars.Length >>> 0); i++)
                        {
                            if ($.$$.System.Char.IsHighSurrogate(chars.get_Item(i).$v))
                            {
                                if (((((i + 1) | 0)) >>> 0) >= (chars.Length >>> 0) || !$.$$.System.Char.IsLowSurrogate(chars.get_Item(((i + 1) | 0)).$v))
                                {
                                    chars.get_Item(i).$v = $.$cast($.$$.System.Text.Rune.ReplacementChar.Value, $.$$.System.Char);
                                }
                                else 
                                {
                                    i++;
                                }
                            }
                            else if ($.$$.System.Char.IsLowSurrogate(chars.get_Item(i).$v))
                            {
                                chars.get_Item(i).$v = $.$cast($.$$.System.Text.Rune.ReplacementChar.Value, $.$$.System.Char);
                            }
                        }
                        return $.$$.System.Span$$($.$$.System.Char).ToString.call(chars);
                    }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._numChars = this._numChars;
                        copy._charBuffer = this._charBuffer.Clone();
                        copy._numBytes = this._numBytes;
                        copy._byteBuffer = this._byteBuffer.Clone();
                        copy._encoding = this._encoding;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._numChars = 0;
                        this._charBuffer = $.$default($.$$.System.Span$$($.$$.System.Char));
                        this._numBytes = 0;
                        this._byteBuffer = $.$default($.$$.System.Span$$($.$$.System.Byte));
                        this._encoding = null;
                    }
                    static $h = 638340;
                    static $z = 23;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"m":[{"r":65537,"n":"FlushBytes","d":638340,"h":25770442116,"f":16777218},{"r":65537,"p":[{"n":"ch","p":458753}],"n":"AddChar","d":638340,"h":34360376708,"f":16777224},{"r":65537,"p":[{"n":"b","p":393217}],"n":"AddByte","d":638340,"h":38655344004,"f":16777224},{"r":1310721,"n":"GetString","d":638340,"h":42950311300,"f":16777224}],"l":[{"t":655361,"n":"_numChars","d":638340,"h":4295605636,"f":4194306},{"t":$.$$.System.Span$$($.$$.System.Char).$h,"n":"_charBuffer","d":638340,"h":8590572932,"f":4194306},{"t":655361,"n":"_numBytes","d":638340,"h":12885540228,"f":4194306},{"t":$.$$.System.Span$$($.$$.System.Byte).$h,"n":"_byteBuffer","d":638340,"h":17180507524,"f":4194306},{"t":121700353,"n":"_encoding","d":638340,"h":21475474820,"f":4194306}],"c":[{"p":[{"n":"charBuffer","p":$.$$.System.Span$$($.$$.System.Char).$h},{"n":"byteBuffer","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"encoding","p":121700353}],"n":".ctor","o":"$ctor$3","d":638340,"h":30065409412,"f":16777224},{"n":".ctor","o":"$ctor$2","d":638340,"h":47245278596,"f":16777217}],"d":572804,"h":638340}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `System.Web.Util.HttpEncoder.UrlDecoder`; }
                }, $cls, ($v) => $cls.$_UrlDecoder = $v);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_urlSafeBytes = $.$$.System.Buffers.SearchValues.Create(new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([33, 40, 41, 42, 45, 46, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 95, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122]));
                }
                {
                    this.s_invalidJavaScriptChars = $.$$.System.Buffers.SearchValues.Create$1($.$$.System.String.op_Implicit("\u0000\u0001\u0002\u0003\u0004\u0005\u0006\u0007\u0008\t\n\u000B\u000C\r\u000E\u000F\u0010\u0011\u0012\u0013\u0014\u0015\u0016\u0017\u0018\u0019\u001A\u001B\u001C\u001D\u001E\u001F" + "\"&'<>\\" + "\u0085\u2028\u2029"));
                }
            }
            static $h = 572804;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1310721,"p":[{"n":"value","p":1310721}],"n":"HtmlAttributeEncode","o":"@$1","d":572804,"h":21475409284,"f":16777256},{"r":65537,"p":[{"n":"value","p":1310721},{"n":"output","p":63045633}],"n":"HtmlAttributeEncode","d":572804,"h":25770376580,"f":16777256},{"r":65537,"p":[{"n":"s","p":1310721},{"n":"index","p":655361},{"n":"output","p":63045633}],"n":"HtmlAttributeEncodeInternal","d":572804,"h":30065343876,"f":16777250},{"r":1310721,"p":[{"n":"value","p":1310721}],"n":"HtmlDecode","o":"@$1","d":572804,"h":34360311172,"f":16777256},{"r":65537,"p":[{"n":"value","p":1310721},{"n":"output","p":63045633}],"n":"HtmlDecode","d":572804,"h":38655278468,"f":16777256},{"r":1310721,"p":[{"n":"value","p":1310721}],"n":"HtmlEncode","o":"@$1","d":572804,"h":42950245764,"f":16777256},{"r":65537,"p":[{"n":"value","p":1310721},{"n":"output","p":63045633}],"n":"HtmlEncode","d":572804,"h":47245213060,"f":16777256},{"r":655361,"p":[{"n":"s","p":1310721}],"n":"IndexOfHtmlAttributeEncodingChars","d":572804,"h":51540180356,"f":16777250},{"r":1310721,"p":[{"n":"value","p":1310721},{"n":"addDoubleQuotes","p":262145}],"n":"JavaScriptStringEncode","d":572804,"h":55835147652,"f":16777256},{"r":$.$typeArray($.$$.System.Byte).$h,"p":[{"n":"bytes","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"UrlDecode","o":"@$1","d":572804,"h":60130114948,"f":16777256},{"r":$.$typeArray($.$$.System.Byte).$h,"p":[{"n":"bytes","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h}],"n":"UrlDecode","o":"@$2","d":572804,"h":64425082244,"f":16777256},{"r":1310721,"p":[{"n":"bytes","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"encoding","p":121700353}],"n":"UrlDecode","d":572804,"h":68720049540,"f":16777256},{"r":1310721,"p":[{"n":"value","p":1310721},{"n":"encoding","p":121700353}],"n":"UrlDecode","o":"@$4","d":572804,"h":73015016836,"f":16777256},{"r":1310721,"p":[{"n":"value","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h},{"n":"encoding","p":121700353}],"n":"UrlDecode","o":"@$3","d":572804,"h":77309984132,"f":16777256},{"r":$.$typeArray($.$$.System.Byte).$h,"p":[{"n":"bytes","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"UrlEncode","d":572804,"h":81604951428,"f":16777256},{"r":$.$typeArray($.$$.System.Byte).$h,"p":[{"n":"bytes","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h}],"n":"UrlEncode","o":"@$2","d":572804,"h":85899918724,"f":16777250},{"r":$.$typeArray($.$$.System.Byte).$h,"p":[{"n":"bytes","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"cUnsafe","p":655361}],"n":"UrlEncode","o":"@$1","d":572804,"h":90194886020,"f":16777250},{"r":262145,"p":[{"n":"bytes","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"cUnsafe","p":655361,"f":2}],"n":"NeedsEncoding","d":572804,"h":94489853316,"f":16777250},{"r":$.$typeArray($.$$.System.Byte).$h,"p":[{"n":"str","p":1310721},{"n":"e","p":121700353}],"n":"UrlEncode","o":"@$3","d":572804,"h":98784820612,"f":16777256},{"r":1310721,"p":[{"n":"value","p":1310721}],"n":"UrlEncodeUnicode","d":572804,"h":103079787908,"f":16777256,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This method produces non-standards-compliant output and has interoperability issues. The preferred alternative is UrlEncode(*).","t":1310721}]}]},{"r":1310721,"p":[{"n":"value","p":1310721}],"n":"UrlPathEncode","d":572804,"h":107374755204,"f":16777256},{"r":1310721,"p":[{"n":"value","p":1310721}],"n":"UrlPathEncodeImpl","d":572804,"h":111669722500,"f":16777250},{"r":262145,"p":[{"n":"bytes","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"ValidateUrlEncodingParameters","d":572804,"h":115964689796,"f":16777250}],"l":[{"t":655361,"n":"MaxStackAllocUrlLength","d":572804,"h":4295540100,"f":4194338},{"t":655361,"n":"StackallocThreshold","d":572804,"h":8590507396,"f":4194338},{"t":$.$$.System.Buffers.SearchValues$$($.$$.System.Byte).$h,"n":"s_urlSafeBytes","d":572804,"h":12885474692,"f":4194338},{"t":$.$$.System.Buffers.SearchValues$$($.$$.System.Char).$h,"n":"s_invalidJavaScriptChars","d":572804,"h":17180441988,"f":4194338}],"j":[638340],"h":572804}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Web.Util.HttpEncoder`; }
        });
        
        $asm.$cls("$swh.System.Web.HttpUtility", ($self) => class HttpUtility extends $.$$.System.Object
        {
            static $_HttpQSCollection;
            static get HttpQSCollection()
            {
                let $cls = $.$swh.System.Web.HttpUtility;
                return $cls.$_HttpQSCollection ??= $asm.$ncls("$swh.System.Web.HttpUtility.HttpQSCollection", ($self) => class HttpQSCollection extends $.$scs.System.Collections.Specialized.NameValueCollection
                {
                    $ctor$17()
                    {
                        super.$ctor$9($.$$.System.StringComparer.OrdinalIgnoreCase);
                        {
                        }
                        return this;
                    }
                    static/*conventional*/ /*string */ ToString()
                    {
                        /*int*/ let count = this.Count;
                        if (count === 0)
                        {
                            return "";
                        }
                        /*StringBuilder*/ let sb = new $.$$.System.Text.StringBuilder().$ctor$1();
                        /*string?[]*/ let keys = this.AllKeys;
                        for(/*int*/ let i = 0; i < count; i++)
                        {
                            /*string?*/ let key = $.$$.System.Array.$ReadT1.call(keys, i);
                            /*string[]?*/ let values = this.GetValues$1(key);
                            if (values !== null)
                            {
                                let $i1 = 0;
                                let $arr1 = values;
                                while ($i1 < $arr1.length)
                                {
                                    let value = $arr1[$i1++];
                                    if (!$.$$.System.String.IsNullOrEmpty(key))
                                    {
                                        sb.Append$19($.$swh.System.Web.HttpUtility.UrlEncode$3(key)).Append$3(/*=*/ 61);
                                    }
                                    sb.Append$19($.$swh.System.Web.HttpUtility.UrlEncode$3(value)).Append$3(/*&*/ 38);
                                }
                            }
                        }
                        return sb.Length > 0 ? sb.ToString$1(0, ((sb.Length - 1) | 0)) : "";
                    }
                    //Static convention instance redirect
                    /*string */ ToString() { return $.$swh.System.Web.HttpUtility.HttpQSCollection.ToString.apply(this, arguments); }
                    static $h = 441732;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":983076,"m":[{"r":1310721,"n":"ToString","d":441732,"h":8590376324,"f":16809985}],"c":[{"n":".ctor","o":"$ctor$17","d":441732,"h":4295409028,"f":16777224}],"i":[31457281,31719425,113246209,112984065],"d":376196,"h":441732}; }
                    static get $b() { return $.$scs.System.Collections.Specialized.NameValueCollection; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable, $.$$.System.Runtime.Serialization.ISerializable, $.$$.System.Runtime.Serialization.IDeserializationCallback ]; }
                    static get $fullName() { return `System.Web.HttpUtility.HttpQSCollection`; }
                }, $cls, ($v) => $cls.$_HttpQSCollection = $v);
            }
            static /*NameValueCollection */ ParseQueryString$1(/*string*/ query)
            {
                return $.$swh.System.Web.HttpUtility.ParseQueryString(query, $.$$.System.Text.Encoding.UTF8);
            }
            static /*NameValueCollection */ ParseQueryString(/*string*/ query, /*Encoding*/ encoding)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(query, "query");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(encoding, "encoding");
                /*HttpQSCollection*/ let result = new $.$swh.System.Web.HttpUtility.HttpQSCollection().$ctor$17();
                /*int*/ let queryLength = query.length;
                /*int*/ let namePos = $.$$.System.String.StartsWith.call(query, /*?*/ 63) ? 1 : 0;
                if (queryLength === namePos)
                {
                    return result;
                }
                while(namePos <= queryLength)
                {
                    /*int*/ let valuePos = -1, valueEnd = -1;
                    for(/*int*/ let q = namePos; q < queryLength; q++)
                    {
                        if (valuePos === -1 && $.$$.System.String.get_Chars.call(query, q) === /*=*/ 61)
                        {
                            valuePos = ((q + 1) | 0);
                        }
                        else if ($.$$.System.String.get_Chars.call(query, q) === /*&*/ 38)
                        {
                            valueEnd = q;
                            break;
                        }
                    }
                    /*string?*/ let name;
                    if (valuePos === -1)
                    {
                        name = null;
                        valuePos = namePos;
                    }
                    else 
                    {
                        name = $.$swh.System.Web.HttpUtility.UrlDecode$2($.$$.System.MemoryExtensions.AsSpan$1(query, namePos, ((((valuePos - namePos) | 0) - 1) | 0)), encoding);
                    }
                    if (valueEnd < 0)
                    {
                        valueEnd = query.length;
                    }
                    namePos = ((valueEnd + 1) | 0);
                    /*string*/ let value = $.$swh.System.Web.HttpUtility.UrlDecode$2($.$$.System.MemoryExtensions.AsSpan$1(query, valuePos, ((valueEnd - valuePos) | 0)), encoding);
                    result.Add(name, value);
                }
                return result;
            }
            static /*string? */ HtmlDecode$1(/*string?*/ s)
            {
                return $.$swh.System.Web.Util.HttpEncoder.HtmlDecode$1(s);
            }
            static /*void */ HtmlDecode(/*string?*/ s, /*TextWriter*/ output)
            {
                return $.$swh.System.Web.Util.HttpEncoder.HtmlDecode(s, output);
            }
            static /*string? */ HtmlEncode$2(/*string?*/ s)
            {
                return $.$swh.System.Web.Util.HttpEncoder.HtmlEncode$1(s);
            }
            static /*string? */ HtmlEncode(/*object?*/ value)
            {
                return (() =>
                {
                    if (value === null)
                    {
                        return null;
                    }
                    {
                        let ihs;
                        if ((ihs = value, $.$is(ihs, $.$swh.System.Web.IHtmlString)))
                        {
                            return ihs.System$Web$IHtmlString$ToHtmlString() ?? $.$$.System.String.Empty;
                        }
                    }
                    return $.$swh.System.Web.HttpUtility.HtmlEncode$2($.$$.System.Convert.ToString$23(value, $.$$.System.Globalization.CultureInfo.CurrentCulture) ?? $.$$.System.String.Empty);
                })();
            }
            static /*void */ HtmlEncode$1(/*string?*/ s, /*TextWriter*/ output)
            {
                return $.$swh.System.Web.Util.HttpEncoder.HtmlEncode(s, output);
            }
            static /*string? */ HtmlAttributeEncode$1(/*string?*/ s)
            {
                return $.$swh.System.Web.Util.HttpEncoder.HtmlAttributeEncode$1(s);
            }
            static /*void */ HtmlAttributeEncode(/*string?*/ s, /*TextWriter*/ output)
            {
                return $.$swh.System.Web.Util.HttpEncoder.HtmlAttributeEncode(s, output);
            }
            static /*string? */ UrlEncode$3(/*string?*/ str)
            {
                return $.$swh.System.Web.HttpUtility.UrlEncode$2(str, $.$$.System.Text.Encoding.UTF8);
            }
            static /*string? */ UrlPathEncode(/*string?*/ str)
            {
                return $.$swh.System.Web.Util.HttpEncoder.UrlPathEncode(str);
            }
            static /*string? */ UrlEncode$2(/*string?*/ str, /*Encoding*/ e)
            {
                return $.$$.System.String.op_Equality(str, null) ? null : $.$$.System.Text.Encoding.ASCII.GetString$1($.$swh.System.Web.HttpUtility.UrlEncodeToBytes$2(str, e));
            }
            static /*string? */ UrlEncode$1(/*byte[]?*/ bytes)
            {
                return bytes === null ? null : $.$$.System.Text.Encoding.ASCII.GetString$1($.$swh.System.Web.HttpUtility.UrlEncodeToBytes$1(bytes));
            }
            static /*string? */ UrlEncode(/*byte[]?*/ bytes, /*int*/ offset, /*int*/ count)
            {
                return bytes === null ? null : $.$$.System.Text.Encoding.ASCII.GetString$1($.$swh.System.Web.HttpUtility.UrlEncodeToBytes(bytes, offset, count));
            }
            static /*byte[]? */ UrlEncodeToBytes$3(/*string?*/ str)
            {
                return $.$swh.System.Web.HttpUtility.UrlEncodeToBytes$2(str, $.$$.System.Text.Encoding.UTF8);
            }
            static /*byte[]? */ UrlEncodeToBytes$1(/*byte[]?*/ bytes)
            {
                return bytes === null ? null : $.$swh.System.Web.HttpUtility.UrlEncodeToBytes(bytes, 0, bytes.length);
            }
            static /*byte[]? */ UrlEncodeUnicodeToBytes(/*string?*/ str)
            {
                return $.$$.System.String.op_Equality(str, null) ? null : $.$$.System.Text.Encoding.ASCII.GetBytes$8($.$swh.System.Web.HttpUtility.UrlEncodeUnicode(str));
            }
            static /*string? */ UrlDecode$4(/*string?*/ str)
            {
                return $.$swh.System.Web.HttpUtility.UrlDecode$3(str, $.$$.System.Text.Encoding.UTF8);
            }
            static /*string? */ UrlDecode$1(/*byte[]?*/ bytes, /*Encoding*/ e)
            {
                return bytes === null ? null : $.$swh.System.Web.HttpUtility.UrlDecode(bytes, 0, bytes.length, e);
            }
            static /*byte[]? */ UrlDecodeToBytes$3(/*string?*/ str)
            {
                return $.$swh.System.Web.HttpUtility.UrlDecodeToBytes$2(str, $.$$.System.Text.Encoding.UTF8);
            }
            static /*byte[]? */ UrlDecodeToBytes$2(/*string?*/ str, /*Encoding*/ e)
            {
                /*int*/ let StackallocThreshold = 512;
                if ($.$$.System.String.op_Equality(str, null))
                {
                    return null;
                }
                if (e.GetMaxByteCount(str.length) <= StackallocThreshold)
                {
                    /*Span<byte>*/ let bytes = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Byte, StackallocThreshold, null);
                    /*int*/ let encodedBytes = e.GetBytes$5($.$$.System.String.op_Implicit(str), bytes);
                    return $.$swh.System.Web.Util.HttpEncoder.UrlDecode$2($.$$.System.Span$$($.$$.System.Byte).op_Implicit(bytes.Slice(0, encodedBytes)));
                }
                return $.$swh.System.Web.HttpUtility.UrlDecodeToBytes$1(e.GetBytes$8(str));
            }
            static /*byte[]? */ UrlDecodeToBytes$1(/*byte[]?*/ bytes)
            {
                return bytes === null ? null : $.$swh.System.Web.Util.HttpEncoder.UrlDecode$2($.$$.System.ReadOnlySpan$$($.$$.System.Byte).op_Implicit$1(bytes));
            }
            static /*byte[]? */ UrlEncodeToBytes$2(/*string?*/ str, /*Encoding*/ e)
            {
                return $.$$.System.String.op_Equality(str, null) ? null : $.$swh.System.Web.Util.HttpEncoder.UrlEncode$3(str, e);
            }
            static /*byte[]? */ UrlEncodeToBytes(/*byte[]?*/ bytes, /*int*/ offset, /*int*/ count)
            {
                return $.$swh.System.Web.Util.HttpEncoder.UrlEncode(bytes, offset, count);
            }
            static /*string? */ UrlEncodeUnicode(/*string?*/ str)
            {
                return $.$swh.System.Web.Util.HttpEncoder.UrlEncodeUnicode(str);
            }
            static /*string? */ UrlDecode$3(/*string?*/ str, /*Encoding*/ e)
            {
                return $.$swh.System.Web.Util.HttpEncoder.UrlDecode$4(str, e);
            }
            static /*string */ UrlDecode$2(/*ReadOnlySpan<char>*/ str, /*Encoding*/ e)
            {
                return $.$swh.System.Web.Util.HttpEncoder.UrlDecode$3(str, e);
            }
            static /*string? */ UrlDecode(/*byte[]?*/ bytes, /*int*/ offset, /*int*/ count, /*Encoding*/ e)
            {
                return $.$swh.System.Web.Util.HttpEncoder.UrlDecode(bytes, offset, count, e);
            }
            static /*byte[]? */ UrlDecodeToBytes(/*byte[]?*/ bytes, /*int*/ offset, /*int*/ count)
            {
                return $.$swh.System.Web.Util.HttpEncoder.UrlDecode$1(bytes, offset, count);
            }
            static /*string */ JavaScriptStringEncode$1(/*string?*/ value)
            {
                return $.$swh.System.Web.Util.HttpEncoder.JavaScriptStringEncode(value, false);
            }
            static /*string */ JavaScriptStringEncode(/*string?*/ value, /*bool*/ addDoubleQuotes)
            {
                return $.$swh.System.Web.Util.HttpEncoder.JavaScriptStringEncode(value, addDoubleQuotes);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 376196;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":983076,"p":[{"n":"query","p":1310721}],"n":"ParseQueryString","o":"@$1","d":376196,"h":8590310788,"f":16777249},{"r":983076,"p":[{"n":"query","p":1310721},{"n":"encoding","p":121700353}],"n":"ParseQueryString","d":376196,"h":12885278084,"f":16777249},{"r":1310721,"p":[{"n":"s","p":1310721}],"n":"HtmlDecode","o":"@$1","d":376196,"h":17180245380,"f":16777249},{"r":65537,"p":[{"n":"s","p":1310721},{"n":"output","p":63045633}],"n":"HtmlDecode","d":376196,"h":21475212676,"f":16777249},{"r":1310721,"p":[{"n":"s","p":1310721}],"n":"HtmlEncode","o":"@$2","d":376196,"h":25770179972,"f":16777249},{"r":1310721,"p":[{"n":"value","p":131073}],"n":"HtmlEncode","d":376196,"h":30065147268,"f":16777249},{"r":65537,"p":[{"n":"s","p":1310721},{"n":"output","p":63045633}],"n":"HtmlEncode","o":"@$1","d":376196,"h":34360114564,"f":16777249},{"r":1310721,"p":[{"n":"s","p":1310721}],"n":"HtmlAttributeEncode","o":"@$1","d":376196,"h":38655081860,"f":16777249},{"r":65537,"p":[{"n":"s","p":1310721},{"n":"output","p":63045633}],"n":"HtmlAttributeEncode","d":376196,"h":42950049156,"f":16777249},{"r":1310721,"p":[{"n":"str","p":1310721}],"n":"UrlEncode","o":"@$3","d":376196,"h":47245016452,"f":16777249},{"r":1310721,"p":[{"n":"str","p":1310721}],"n":"UrlPathEncode","d":376196,"h":51539983748,"f":16777249},{"r":1310721,"p":[{"n":"str","p":1310721},{"n":"e","p":121700353}],"n":"UrlEncode","o":"@$2","d":376196,"h":55834951044,"f":16777249},{"r":1310721,"p":[{"n":"bytes","p":$.$typeArray($.$$.System.Byte).$h}],"n":"UrlEncode","o":"@$1","d":376196,"h":60129918340,"f":16777249},{"r":1310721,"p":[{"n":"bytes","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"UrlEncode","d":376196,"h":64424885636,"f":16777249},{"r":$.$typeArray($.$$.System.Byte).$h,"p":[{"n":"str","p":1310721}],"n":"UrlEncodeToBytes","o":"@$3","d":376196,"h":68719852932,"f":16777249},{"r":$.$typeArray($.$$.System.Byte).$h,"p":[{"n":"bytes","p":$.$typeArray($.$$.System.Byte).$h}],"n":"UrlEncodeToBytes","o":"@$1","d":376196,"h":73014820228,"f":16777249},{"r":$.$typeArray($.$$.System.Byte).$h,"p":[{"n":"str","p":1310721}],"n":"UrlEncodeUnicodeToBytes","d":376196,"h":77309787524,"f":16777249,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This method produces non-standards-compliant output and has interoperability issues. The preferred alternative is UrlEncodeToBytes(String).","t":1310721}]}]},{"r":1310721,"p":[{"n":"str","p":1310721}],"n":"UrlDecode","o":"@$4","d":376196,"h":81604754820,"f":16777249},{"r":1310721,"p":[{"n":"bytes","p":$.$typeArray($.$$.System.Byte).$h},{"n":"e","p":121700353}],"n":"UrlDecode","o":"@$1","d":376196,"h":85899722116,"f":16777249},{"r":$.$typeArray($.$$.System.Byte).$h,"p":[{"n":"str","p":1310721}],"n":"UrlDecodeToBytes","o":"@$3","d":376196,"h":90194689412,"f":16777249},{"r":$.$typeArray($.$$.System.Byte).$h,"p":[{"n":"str","p":1310721},{"n":"e","p":121700353}],"n":"UrlDecodeToBytes","o":"@$2","d":376196,"h":94489656708,"f":16777249},{"r":$.$typeArray($.$$.System.Byte).$h,"p":[{"n":"bytes","p":$.$typeArray($.$$.System.Byte).$h}],"n":"UrlDecodeToBytes","o":"@$1","d":376196,"h":98784624004,"f":16777249},{"r":$.$typeArray($.$$.System.Byte).$h,"p":[{"n":"str","p":1310721},{"n":"e","p":121700353}],"n":"UrlEncodeToBytes","o":"@$2","d":376196,"h":103079591300,"f":16777249},{"r":$.$typeArray($.$$.System.Byte).$h,"p":[{"n":"bytes","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"UrlEncodeToBytes","d":376196,"h":107374558596,"f":16777249},{"r":1310721,"p":[{"n":"str","p":1310721}],"n":"UrlEncodeUnicode","d":376196,"h":111669525892,"f":16777249,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This method produces non-standards-compliant output and has interoperability issues. The preferred alternative is UrlEncode(String).","t":1310721}]}]},{"r":1310721,"p":[{"n":"str","p":1310721},{"n":"e","p":121700353}],"n":"UrlDecode","o":"@$3","d":376196,"h":115964493188,"f":16777249},{"r":1310721,"p":[{"n":"str","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h},{"n":"e","p":121700353}],"n":"UrlDecode","o":"@$2","d":376196,"h":120259460484,"f":16777250},{"r":1310721,"p":[{"n":"bytes","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"e","p":121700353}],"n":"UrlDecode","d":376196,"h":124554427780,"f":16777249},{"r":$.$typeArray($.$$.System.Byte).$h,"p":[{"n":"bytes","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"UrlDecodeToBytes","d":376196,"h":128849395076,"f":16777249},{"r":1310721,"p":[{"n":"value","p":1310721}],"n":"JavaScriptStringEncode","o":"@$1","d":376196,"h":133144362372,"f":16777249},{"r":1310721,"p":[{"n":"value","p":1310721},{"n":"addDoubleQuotes","p":262145}],"n":"JavaScriptStringEncode","d":376196,"h":137439329668,"f":16777249}],"c":[{"n":".ctor","o":"$ctor$1","d":376196,"h":141734296964,"f":16777217}],"j":[441732],"h":376196}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Web.HttpUtility`; }
        });
        
        $asm.$cls("$swh.System.HexConverter", ($self) => class HexConverter
        {
            static $_Casing;
            static get Casing()
            {
                let $cls = $.$swh.System.HexConverter;
                return $cls.$_Casing ??= $asm.$nstr("$swh.System.HexConverter.Casing", ($self) => class Casing extends $.$$.System.Enum
                {
                    static Upper = 0;
                    static Lower = 8224;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "Upper": 0n,
                            "Lower": 8224n
                        };
                    }
                    static $h = 179588;
                    static $z = 4;
                    static $f = 0b110000011010001001;
                    static $k = 4;
                    static get $eut() { return $.$$.System.UInt32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":720897,"l":[{"t":179588,"n":"Upper","d":179588,"h":4295146884,"f":4194337},{"t":179588,"n":"Lower","d":179588,"h":8590114180,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":179588,"h":12885081476,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"d":114052,"h":179588}; }
                    static get $b() { return $.$$.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
                    static get $fullName() { return `System.HexConverter.Casing`; }
                }, $cls, ($v) => $cls.$_Casing = $v);
            }
            static /*void */ ToBytesBuffer(/*byte*/ value, /*Span<byte>*/ buffer, /*int*/ startingIndex, /*Casing*/ casing)
            {
                /*uint*/ let difference = (((((((value & 240) << 4) >>> 0) + (value & 15)) >>> 0) - 35209) >>> 0);
                /*uint*/ let packedResult = (((((((((-(difference | 0)) >>> 0) & 28784) >>> 4) + difference) >>> 0) + 47545) >>> 0)) | casing;
                buffer.get_Item(((startingIndex + 1) | 0)).$v = $.$cast(packedResult, $.$$.System.Byte);
                buffer.get_Item(startingIndex).$v = $.$cast((packedResult >>> 8), $.$$.System.Byte);
            }
            static /*void */ ToCharsBuffer(/*byte*/ value, /*Span<char>*/ buffer, /*int*/ startingIndex, /*Casing*/ casing)
            {
                /*uint*/ let difference = (((((((value & 240) << 4) >>> 0) + (value & 15)) >>> 0) - 35209) >>> 0);
                /*uint*/ let packedResult = (((((((((-(difference | 0)) >>> 0) & 28784) >>> 4) + difference) >>> 0) + 47545) >>> 0)) | casing;
                buffer.get_Item(((startingIndex + 1) | 0)).$v = $.$cast((packedResult & 255), $.$$.System.Char);
                buffer.get_Item(startingIndex).$v = $.$cast((packedResult >>> 8), $.$$.System.Char);
            }
            static /*void */ EncodeToUtf8(/*ReadOnlySpan<byte>*/ source, /*Span<byte>*/ utf8Destination, /*Casing*/ casing)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(utf8Destination.Length >= (((source.Length * 2) | 0)), "utf8Destination.Length >= (source.Length * 2)");
                for(/*int*/ let pos = 0; pos < source.Length; pos++)
                {
                    $.$swh.System.HexConverter.ToBytesBuffer(source.get_Item(pos).$v, utf8Destination, ((pos * 2) | 0), casing);
                }
            }
            static /*void */ EncodeToUtf16(/*ReadOnlySpan<byte>*/ source, /*Span<char>*/ destination, /*Casing*/ casing)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(destination.Length >= (((source.Length * 2) | 0)), "destination.Length >= (source.Length * 2)");
                for(/*int*/ let pos = 0; pos < source.Length; pos++)
                {
                    $.$swh.System.HexConverter.ToCharsBuffer(source.get_Item(pos).$v, destination, ((pos * 2) | 0), casing);
                }
            }
            static /*string */ ToString$1(/*ReadOnlySpan<byte>*/ bytes, /*Casing*/ casing)
            {
                /*SpanCasingPair*/ let args = (() =>
                {
                    //new $.$swh.System.HexConverter.SpanCasingPair()
                    const $t1 = $.$swh.System.HexConverter.SpanCasingPair;
                    const $i1 = new $t1();
                    $i1.Bytes = bytes;
                    $i1.Casing = casing;
                    return $i1;
                })();
                return $.$$.System.String.Create$10($.$swh.System.HexConverter.SpanCasingPair, ((bytes.Length * 2) | 0), args.Clone(), new ($.$$.System.Buffers.SpanAction$$$($.$$.System.Char, $.$swh.System.HexConverter.SpanCasingPair))().$ctor($.$swh.System.HexConverter, /*static*/ (/*chars*/ chars, /*args*/ args) =>
                {
                    return $.$swh.System.HexConverter.EncodeToUtf16(args.Bytes, chars, args.Casing);
                }, {"r":65537,"p":[{"n":"chars","p":$.$$.System.Span$$($.$$.System.Char).$h},{"n":"args","p":245124}],"n":"","d":114052,"h":0,"f":17825826}));
            }
            static $_SpanCasingPair;
            static get SpanCasingPair()
            {
                let $cls = $.$swh.System.HexConverter;
                return $cls.$_SpanCasingPair ??= $asm.$nstr("$swh.System.HexConverter.SpanCasingPair", ($self) => class SpanCasingPair extends $.$$.System.ValueType
                {
                    /*ReadOnlySpan<byte>*/ Bytes;
                    /*Casing*/ Casing = 0;
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Bytes = this.Bytes.Clone();
                        copy.Casing = this.Casing;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.Bytes = $.$default($.$$.System.ReadOnlySpan$$($.$$.System.Byte));
                        this.Casing = 0;
                    }
                    static $h = 245124;
                    static $z = 9;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":12885147012,"f":50331649},"s":{"r":0,"d":0,"h":17180114308,"f":83886081},"n":"Bytes","d":245124,"h":8590179716,"f":2097153},{"p":179588,"g":{"r":0,"d":0,"h":30065016196,"f":50331649},"s":{"r":0,"d":0,"h":34359983492,"f":83886081},"n":"Casing","d":245124,"h":25770048900,"f":2097153}],"c":[{"n":".ctor","o":"$ctor$2","d":245124,"h":38654950788,"f":16777217}],"d":114052,"h":245124}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `System.HexConverter.SpanCasingPair`; }
                }, $cls, ($v) => $cls.$_SpanCasingPair = $v);
            }
            static /*char */ ToCharUpper(/*int*/ value)
            {
                value &= 15;
                value += /*0*/ 48;
                if (value > /*9*/ 57)
                {
                    value += (((/*A*/ 65 - (((/*9*/ 57 + 1) | 0))) | 0));
                }
                return $.$cast(value, $.$$.System.Char);
            }
            static /*char */ ToCharLower(/*int*/ value)
            {
                value &= 15;
                value += /*0*/ 48;
                if (value > /*9*/ 57)
                {
                    value += (((/*a*/ 97 - (((/*9*/ 57 + 1) | 0))) | 0));
                }
                return $.$cast(value, $.$$.System.Char);
            }
            static /*bool */ TryDecodeFromUtf8(/*ReadOnlySpan<byte>*/ utf8Source, /*Span<byte>*/ destination, /*out int*/ bytesProcessed)
            {
                return $.$swh.System.HexConverter.TryDecodeFromUtf8_Scalar(utf8Source, destination, bytesProcessed);
            }
            static /*bool */ TryDecodeFromUtf16(/*ReadOnlySpan<char>*/ source, /*Span<byte>*/ destination, /*out int*/ charsProcessed)
            {
                return $.$swh.System.HexConverter.TryDecodeFromUtf16_Scalar(source, destination, charsProcessed);
            }
            static /*bool */ TryDecodeFromUtf8_Scalar(/*ReadOnlySpan<byte>*/ utf8Source, /*Span<byte>*/ destination, /*out int*/ bytesProcessed)
            {
                $.$$.System.Diagnostics.Debug.Assert$2((utf8Source.Length % 2) === 0, "Un-even number of characters provided");
                $.$$.System.Diagnostics.Debug.Assert$2(($.trunc(utf8Source.Length / 2)) === destination.Length, "Target buffer not right-sized for provided characters");
                /*int*/ let i = 0;
                /*int*/ let j = 0;
                /*int*/ let byteLo = 0;
                /*int*/ let byteHi = 0;
                while(j < destination.Length)
                {
                    byteLo = $.$swh.System.HexConverter.FromChar(utf8Source.get_Item(((i + 1) | 0)).$v);
                    byteHi = $.$swh.System.HexConverter.FromChar(utf8Source.get_Item(i).$v);
                    if ((byteLo | byteHi) === 255)
                    {
                        break;
                    }
                    destination.get_Item(j++).$v = $.$cast(((byteHi << 4) | byteLo), $.$$.System.Byte);
                    i += 2;
                }
                if (byteLo === 255)
                {
                    i++;
                }
                bytesProcessed.$v = i;
                return (byteLo | byteHi) !== 255;
            }
            static /*bool */ TryDecodeFromUtf16_Scalar(/*ReadOnlySpan<char>*/ source, /*Span<byte>*/ destination, /*out int*/ charsProcessed)
            {
                $.$$.System.Diagnostics.Debug.Assert$2((source.Length % 2) === 0, "Un-even number of characters provided");
                $.$$.System.Diagnostics.Debug.Assert$2(($.trunc(source.Length / 2)) === destination.Length, "Target buffer not right-sized for provided characters");
                /*int*/ let i = 0;
                /*int*/ let j = 0;
                /*int*/ let byteLo = 0;
                /*int*/ let byteHi = 0;
                while(j < destination.Length)
                {
                    byteLo = $.$swh.System.HexConverter.FromChar(source.get_Item(((i + 1) | 0)).$v);
                    byteHi = $.$swh.System.HexConverter.FromChar(source.get_Item(i).$v);
                    if ((byteLo | byteHi) === 255)
                    {
                        break;
                    }
                    destination.get_Item(j++).$v = $.$cast(((byteHi << 4) | byteLo), $.$$.System.Byte);
                    i += 2;
                }
                if (byteLo === 255)
                {
                    i++;
                }
                charsProcessed.$v = i;
                return (byteLo | byteHi) !== 255;
            }
            static /*int */ FromChar(/*int*/ c)
            {
                return (c >= $.$swh.System.HexConverter.CharToHexLookup.Length) ? 255 : $.$swh.System.HexConverter.CharToHexLookup.get_Item(c).$v;
            }
            static /*int */ FromUpperChar(/*int*/ c)
            {
                return (c > 71) ? 255 : $.$swh.System.HexConverter.CharToHexLookup.get_Item(c).$v;
            }
            static /*int */ FromLowerChar(/*int*/ c)
            {
                if (((((c - /*0*/ 48) | 0)) >>> 0) <= (/*9*/ 57 - /*0*/ 48))
                {
                    return ((c - /*0*/ 48) | 0);
                }
                if (((((c - /*a*/ 97) | 0)) >>> 0) <= (/*f*/ 102 - /*a*/ 97))
                {
                    return ((((c - /*a*/ 97) | 0) + 10) | 0);
                }
                return 255;
            }
            static /*bool */ IsHexChar(/*int*/ c)
            {
                //if (IntPtr.Size == 8) { ... }
                return $.$swh.System.HexConverter.FromChar(c) !== 255;
            }
            static /*bool */ IsHexUpperChar(/*int*/ c)
            {
                return (((((c - /*0*/ 48) | 0)) >>> 0) <= 9) || (((((c - /*A*/ 65) | 0)) >>> 0) <= (/*F*/ 70 - /*A*/ 65));
            }
            static /*bool */ IsHexLowerChar(/*int*/ c)
            {
                return (((((c - /*0*/ 48) | 0)) >>> 0) <= 9) || (((((c - /*a*/ 97) | 0)) >>> 0) <= (/*f*/ 102 - /*a*/ 97));
            }
            static /*ReadOnlySpan<byte> */ get CharToHexLookup()
            {
                return this.$cacheCharToHexLookup ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([ 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 255, 255, 255, 255, 255, 255, 255, 10, 11, 12, 13, 14, 15, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 10, 11, 12, 13, 14, 15, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255 ]);
            }
            static $h = 114052;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":90194427268,"f":50331681},"n":"CharToHexLookup","d":114052,"h":85899459972,"f":2097185}],"m":[{"r":65537,"p":[{"n":"value","p":393217},{"n":"buffer","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"startingIndex","p":655361,"f":65,"v":0},{"n":"casing","p":179588,"f":65,"v":0}],"n":"ToBytesBuffer","d":114052,"h":8590048644,"f":16777249},{"r":65537,"p":[{"n":"value","p":393217},{"n":"buffer","p":$.$$.System.Span$$($.$$.System.Char).$h},{"n":"startingIndex","p":655361,"f":65,"v":0},{"n":"casing","p":179588,"f":65,"v":0}],"n":"ToCharsBuffer","d":114052,"h":12885015940,"f":16777249},{"r":65537,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"utf8Destination","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"casing","p":179588,"f":65,"v":0}],"n":"EncodeToUtf8","d":114052,"h":17179983236,"f":16777249},{"r":65537,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"destination","p":$.$$.System.Span$$($.$$.System.Char).$h},{"n":"casing","p":179588,"f":65,"v":0}],"n":"EncodeToUtf16","d":114052,"h":21474950532,"f":16777249},{"r":1310721,"p":[{"n":"bytes","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"casing","p":179588,"f":65,"v":0}],"n":"ToString","o":"@$1","d":114052,"h":25769917828,"f":16777249},{"r":458753,"p":[{"n":"value","p":655361}],"n":"ToCharUpper","d":114052,"h":34359852420,"f":16777249},{"r":458753,"p":[{"n":"value","p":655361}],"n":"ToCharLower","d":114052,"h":38654819716,"f":16777249},{"r":262145,"p":[{"n":"utf8Source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"destination","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"bytesProcessed","p":655361,"f":2}],"n":"TryDecodeFromUtf8","d":114052,"h":42949787012,"f":16777249},{"r":262145,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h},{"n":"destination","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"charsProcessed","p":655361,"f":2}],"n":"TryDecodeFromUtf16","d":114052,"h":47244754308,"f":16777249},{"r":262145,"p":[{"n":"utf8Source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"destination","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"bytesProcessed","p":655361,"f":2}],"n":"TryDecodeFromUtf8_Scalar","d":114052,"h":51539721604,"f":16777250},{"r":262145,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h},{"n":"destination","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"charsProcessed","p":655361,"f":2}],"n":"TryDecodeFromUtf16_Scalar","d":114052,"h":55834688900,"f":16777250},{"r":655361,"p":[{"n":"c","p":655361}],"n":"FromChar","d":114052,"h":60129656196,"f":16777249},{"r":655361,"p":[{"n":"c","p":655361}],"n":"FromUpperChar","d":114052,"h":64424623492,"f":16777249},{"r":655361,"p":[{"n":"c","p":655361}],"n":"FromLowerChar","d":114052,"h":68719590788,"f":16777249},{"r":262145,"p":[{"n":"c","p":655361}],"n":"IsHexChar","d":114052,"h":73014558084,"f":16777249},{"r":262145,"p":[{"n":"c","p":655361}],"n":"IsHexUpperChar","d":114052,"h":77309525380,"f":16777249},{"r":262145,"p":[{"n":"c","p":655361}],"n":"IsHexLowerChar","d":114052,"h":81604492676,"f":16777249}],"j":[179588,245124],"h":114052}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.HexConverter`; }
        });
        
        $asm.$str("$swh.System.Text.ValueStringBuilder", ($self) => class ValueStringBuilder extends $.$$.System.ValueType
        {
            /*void */ AppendSpanFormattable(T, /*T*/ value, /*string?*/ format, /*IFormatProvider?*/ provider)
            {
                /*int*/ let charsWritten;
                if ($.$dsp(value, T, ($t) => $t.System$ISpanFormattable$TryFormat, this._chars.Slice$1(this._pos), $.$ref(() => charsWritten, ($v) => charsWritten = $v, $.$$.System.Int32), $.$$.System.String.op_Implicit(format), provider))
                {
                    this._pos += charsWritten;
                }
                else 
                {
                    this.Append$3($.$dsp(value, T, ($t) => $t.System$IFormattable$ToString, format, provider));
                }
            }
            /*char[]?*/  get _arrayToReturnToPool() { return this.$getField(0, 4); }
            /*char[]?*/  set _arrayToReturnToPool(value) { this.$setField(0, 4, value); }
            /*Span<char>*/  get _chars() { return this.$getField(4, 6); }
            /*Span<char>*/  set _chars(value) { this.$setField(4, 6, value); }
            /*int*/  get _pos() { return this.$getField(10, 4); }
            /*int*/  set _pos(value) { this.$setField(10, 4, value); }
            $ctor$4(/*Span<char>*/ initialBuffer)
            {
                super.$ctor$1();
                {
                    this._arrayToReturnToPool = null;
                    this._chars = initialBuffer;
                    this._pos = 0;
                }
                return this;
            }
            $ctor$3(/*int*/ initialCapacity)
            {
                super.$ctor$1();
                {
                    this._arrayToReturnToPool = $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared.Rent(initialCapacity);
                    this._chars = $.$$.System.Span$$($.$$.System.Char).op_Implicit$2(this._arrayToReturnToPool);
                    this._pos = 0;
                }
                return this;
            }
            /*int */ get Length()
            {
                return this._pos;
            }
            /*int */ set Length(value)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(value >= 0, "value >= 0");
                $.$$.System.Diagnostics.Debug.Assert$2(value <= this._chars.Length, "value <= _chars.Length");
                this._pos = value;
            }
            /*int */ get Capacity()
            {
                return this._chars.Length;
            }
            /*void */ EnsureCapacity(/*int*/ capacity)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(capacity >= 0, "capacity >= 0");
                if ((capacity >>> 0) > (this._chars.Length >>> 0))
                {
                    this.Grow(((capacity - this._pos) | 0));
                }
            }
            /*ref char */ GetPinnableReference()
            {
                return $.$$.System.Runtime.InteropServices.MemoryMarshal.GetReference$1($.$$.System.Char, this._chars);
            }
            /*ref char */ GetPinnableReference$1(/*bool*/ terminate)
            {
                if (terminate)
                {
                    this.EnsureCapacity(((this.Length + 1) | 0));
                    this._chars.get_Item(this.Length).$v = /*\u0000*/ 0;
                }
                return $.$$.System.Runtime.InteropServices.MemoryMarshal.GetReference$1($.$$.System.Char, this._chars);
            }
            /*ref char*/ get_Item(/*int*/ index)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(index < this._pos, "index < _pos");
                return this._chars.get_Item(index);
            }
            static/*conventional*/ /*string */ ToString()
            {
                /*string*/ let s = $.$$.System.Span$$($.$$.System.Char).ToString.call(this._chars.Slice(0, this._pos));
                this.Dispose();
                return s;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$swh.System.Text.ValueStringBuilder.ToString.apply(this, arguments); }
            /*Span<char> */ get RawChars()
            {
                return this._chars;
            }
            /*ReadOnlySpan<char> */ AsSpan$1(/*bool*/ terminate)
            {
                if (terminate)
                {
                    this.EnsureCapacity(((this.Length + 1) | 0));
                    this._chars.get_Item(this.Length).$v = /*\u0000*/ 0;
                }
                return $.$$.System.Span$$($.$$.System.Char).op_Implicit(this._chars.Slice(0, this._pos));
            }
            /*ReadOnlySpan<char> */ AsSpan()
            {
                return $.$$.System.Span$$($.$$.System.Char).op_Implicit(this._chars.Slice(0, this._pos));
            }
            /*ReadOnlySpan<char> */ AsSpan$3(/*int*/ start)
            {
                return $.$$.System.Span$$($.$$.System.Char).op_Implicit(this._chars.Slice(start, ((this._pos - start) | 0)));
            }
            /*ReadOnlySpan<char> */ AsSpan$2(/*int*/ start, /*int*/ length)
            {
                return $.$$.System.Span$$($.$$.System.Char).op_Implicit(this._chars.Slice(start, length));
            }
            /*bool */ TryCopyTo(/*Span<char>*/ destination, /*out int*/ charsWritten)
            {
                if (this._chars.Slice(0, this._pos).TryCopyTo(destination))
                {
                    charsWritten.$v = this._pos;
                    this.Dispose();
                    return true;
                }
                else 
                {
                    charsWritten.$v = 0;
                    this.Dispose();
                    return false;
                }
            }
            /*void */ Insert(/*int*/ index, /*char*/ value, /*int*/ count)
            {
                if (this._pos > ((this._chars.Length - count) | 0))
                {
                    this.Grow(count);
                }
                /*int*/ let remaining = ((this._pos - index) | 0);
                this._chars.Slice(index, remaining).CopyTo(this._chars.Slice$1(((index + count) | 0)));
                this._chars.Slice(index, count).Fill(value);
                this._pos += count;
            }
            /*void */ Insert$1(/*int*/ index, /*string?*/ s)
            {
                if ($.$$.System.String.op_Equality(s, null))
                {
                    return;
                }
                /*int*/ let count = s.length;
                if (this._pos > (((this._chars.Length - count) | 0)))
                {
                    this.Grow(count);
                }
                /*int*/ let remaining = ((this._pos - index) | 0);
                this._chars.Slice(index, remaining).CopyTo(this._chars.Slice$1(((index + count) | 0)));
                $.$$.System.String.CopyTo$1.call(s, this._chars.Slice$1(index));
                this._pos += count;
            }
            /*void */ Append$1(/*char*/ c)
            {
                /*int*/ let pos = this._pos;
                /*Span<char>*/ let chars = this._chars;
                if ((pos >>> 0) < (chars.Length >>> 0))
                {
                    chars.get_Item(pos).$v = c;
                    this._pos = ((pos + 1) | 0);
                }
                else 
                {
                    this.GrowAndAppend(c);
                }
            }
            /*void */ Append$3(/*string?*/ s)
            {
                if ($.$$.System.String.op_Equality(s, null))
                {
                    return;
                }
                /*int*/ let pos = this._pos;
                if (s.length === 1 && (pos >>> 0) < (this._chars.Length >>> 0))
                {
                    this._chars.get_Item(pos).$v = $.$$.System.String.get_Chars.call(s, 0);
                    this._pos = ((pos + 1) | 0);
                }
                else 
                {
                    this.AppendSlow(s);
                }
            }
            /*void */ AppendSlow(/*string*/ s)
            {
                /*int*/ let pos = this._pos;
                if (pos > ((this._chars.Length - s.length) | 0))
                {
                    this.Grow(s.length);
                }
                $.$$.System.String.CopyTo$1.call(s, this._chars.Slice$1(pos));
                this._pos += s.length;
            }
            /*void */ Append(/*char*/ c, /*int*/ count)
            {
                if (this._pos > ((this._chars.Length - count) | 0))
                {
                    this.Grow(count);
                }
                /*Span<char>*/ let dst = this._chars.Slice(this._pos, count);
                for(/*int*/ let i = 0; i < dst.Length; i++)
                {
                    dst.get_Item(i).$v = c;
                }
                this._pos += count;
            }
            /*void */ Append$2(/*scoped ReadOnlySpan<char>*/ value)
            {
                /*int*/ let pos = this._pos;
                if (pos > ((this._chars.Length - value.Length) | 0))
                {
                    this.Grow(value.Length);
                }
                value.CopyTo(this._chars.Slice$1(this._pos));
                this._pos += value.Length;
            }
            /*Span<char> */ AppendSpan(/*int*/ length)
            {
                /*int*/ let origPos = this._pos;
                if (origPos > ((this._chars.Length - length) | 0))
                {
                    this.Grow(length);
                }
                this._pos = ((origPos + length) | 0);
                return this._chars.Slice(origPos, length);
            }
            /*void */ GrowAndAppend(/*char*/ c)
            {
                this.Grow(1);
                this.Append$1(c);
            }
            /*void */ Grow(/*int*/ additionalCapacityBeyondPos)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(additionalCapacityBeyondPos > 0, "additionalCapacityBeyondPos > 0");
                $.$$.System.Diagnostics.Debug.Assert$2(this._pos > ((this._chars.Length - additionalCapacityBeyondPos) | 0), "Grow called incorrectly, no resize is needed.");
                /*uint*/ let ArrayMaxLength = 2147483591;
                /*int*/ let newCapacity = ($.$$.System.Math.Max$10(((((this._pos + additionalCapacityBeyondPos) | 0)) >>> 0), $.$$.System.Math.Min$10((((this._chars.Length >>> 0) * 2) >>> 0), ArrayMaxLength)) | 0);
                /*char[]*/ let poolArray = $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared.Rent(newCapacity);
                this._chars.Slice(0, this._pos).CopyTo($.$$.System.Span$$($.$$.System.Char).op_Implicit$2(poolArray));
                /*char[]?*/ let toReturn = this._arrayToReturnToPool;
                this._chars = $.$$.System.Span$$($.$$.System.Char).op_Implicit$2(this._arrayToReturnToPool = poolArray);
                if (toReturn !== null)
                {
                    $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared.Return(toReturn, false);
                }
            }
            /*void */ Dispose()
            {
                /*char[]?*/ let toReturn = this._arrayToReturnToPool;
                new $.$swh.System.Text.ValueStringBuilder().Clone(this);
                if (toReturn !== null)
                {
                    $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared.Return(toReturn, false);
                }
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._arrayToReturnToPool = this._arrayToReturnToPool;
                copy._chars = this._chars.Clone();
                copy._pos = this._pos;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._arrayToReturnToPool = null;
                this._chars = $.$default($.$$.System.Span$$($.$$.System.Char));
                this._pos = 0;
            }
            static $h = 310660;
            static $z = 14;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":655361,"g":{"r":0,"d":0,"h":34360049028,"f":50331649},"s":{"r":0,"d":0,"h":38655016324,"f":83886081},"n":"Length","d":310660,"h":30065081732,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":47244950916,"f":50331649},"n":"Capacity","d":310660,"h":42949983620,"f":2097153},{"p":458753,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":68719787396,"f":50331649},"n":"Item","o":"@$2","d":310660,"h":64424820100,"f":2097153},{"p":$.$$.System.Span$$($.$$.System.Char).$h,"g":{"r":0,"d":0,"h":81604689284,"f":50331649},"n":"RawChars","d":310660,"h":77309721988,"f":2097153}],"m":[{"r":65537,"p":[{"n":"value","p":(T) => T.$h},{"n":"format","p":1310721,"f":65},{"n":"provider","p":57671681,"f":65}],"g":["T"],"n":"AppendSpanFormattable","d":310660,"h":4295277956,"f":16908296},{"r":65537,"p":[{"n":"capacity","p":655361}],"n":"EnsureCapacity","d":310660,"h":51539918212,"f":16777217},{"r":458753,"n":"GetPinnableReference","d":310660,"h":55834885508,"f":16777217},{"r":458753,"p":[{"n":"terminate","p":262145}],"n":"GetPinnableReference","o":"@$1","d":310660,"h":60129852804,"f":16777217},{"r":1310721,"n":"ToString","d":310660,"h":73014754692,"f":16809985},{"r":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h,"p":[{"n":"terminate","p":262145}],"n":"AsSpan","o":"@$1","d":310660,"h":85899656580,"f":16777217},{"r":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h,"n":"AsSpan","d":310660,"h":90194623876,"f":16777217},{"r":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h,"p":[{"n":"start","p":655361}],"n":"AsSpan","o":"@$3","d":310660,"h":94489591172,"f":16777217},{"r":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h,"p":[{"n":"start","p":655361},{"n":"length","p":655361}],"n":"AsSpan","o":"@$2","d":310660,"h":98784558468,"f":16777217},{"r":262145,"p":[{"n":"destination","p":$.$$.System.Span$$($.$$.System.Char).$h},{"n":"charsWritten","p":655361,"f":2}],"n":"TryCopyTo","d":310660,"h":103079525764,"f":16777217},{"r":65537,"p":[{"n":"index","p":655361},{"n":"value","p":458753},{"n":"count","p":655361}],"n":"Insert","d":310660,"h":107374493060,"f":16777217},{"r":65537,"p":[{"n":"index","p":655361},{"n":"s","p":1310721}],"n":"Insert","o":"@$1","d":310660,"h":111669460356,"f":16777217},{"r":65537,"p":[{"n":"c","p":458753}],"n":"Append","o":"@$1","d":310660,"h":115964427652,"f":16777217},{"r":65537,"p":[{"n":"s","p":1310721}],"n":"Append","o":"@$3","d":310660,"h":120259394948,"f":16777217},{"r":65537,"p":[{"n":"s","p":1310721}],"n":"AppendSlow","d":310660,"h":124554362244,"f":16777218},{"r":65537,"p":[{"n":"c","p":458753},{"n":"count","p":655361}],"n":"Append","d":310660,"h":128849329540,"f":16777217},{"r":65537,"p":[{"n":"value","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h}],"n":"Append","o":"@$2","d":310660,"h":133144296836,"f":16777217},{"r":$.$$.System.Span$$($.$$.System.Char).$h,"p":[{"n":"length","p":655361}],"n":"AppendSpan","d":310660,"h":137439264132,"f":16777217},{"r":65537,"p":[{"n":"c","p":458753}],"n":"GrowAndAppend","d":310660,"h":141734231428,"f":16777218},{"r":65537,"p":[{"n":"additionalCapacityBeyondPos","p":655361}],"n":"Grow","d":310660,"h":146029198724,"f":16777218},{"r":65537,"n":"Dispose","d":310660,"h":150324166020,"f":16777217}],"l":[{"t":$.$typeArray($.$$.System.Char).$h,"n":"_arrayToReturnToPool","d":310660,"h":8590245252,"f":4194306},{"t":$.$$.System.Span$$($.$$.System.Char).$h,"n":"_chars","d":310660,"h":12885212548,"f":4194306},{"t":655361,"n":"_pos","d":310660,"h":17180179844,"f":4194306}],"c":[{"p":[{"n":"initialBuffer","p":$.$$.System.Span$$($.$$.System.Char).$h}],"n":".ctor","o":"$ctor$4","d":310660,"h":21475147140,"f":16777217},{"p":[{"n":"initialCapacity","p":655361}],"n":".ctor","o":"$ctor$3","d":310660,"h":25770114436,"f":16777217},{"n":".ctor","o":"$ctor$2","d":310660,"h":154619133316,"f":16777217}],"h":310660}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.Text.ValueStringBuilder`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Threading", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized"))