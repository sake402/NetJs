
//--TRIMMABLE-BOUNDARY-START(71)
(function ($global, $, $$, $sc, $sm, $spu, $sr, $st, $scn, $scm, $so, $scp, $scs) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Web.HttpUtility", 
    {
  "h": 71,
  "f": "System.Web.HttpUtility",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 159121409,
      "c": 13044023297,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106299393,
      "c": 4401266689,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106364929,
      "c": 4401332225,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106823681,
      "c": 4401790977,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 4401922049,
      "a": [
        {
          "v": "1.0.35\u002B39e7ca3e4bf1d7d75afdb3a3db320b6c1a1b2fcf",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 4402774017,
      "a": [
        {
          "v": "NetJs.System.Web.HttpUtility",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 4402905089,
      "a": [
        {
          "v": "NetJs.System.Web.HttpUtility",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 4403036161,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159186945,
      "c": 4454154241,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 158924801,
      "c": 4453892097,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(458823)
        $asm.$cls("$swh.System.Web.IHtmlString", ($self) => class IHtmlString
        {
            static $h = 458823;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295426119),
    {
      "r": 1310721,
      "n": "ToHtmlString",
      "o": "System$Web$IHtmlString$ToHtmlString",
      "d": 458823,
      "h": 4295426119,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295426119)
  ],
  "h": 458823
}; }
            static get $fullName() { return `System.Web.IHtmlString`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458823)
        
        
        //--TRIMMABLE-BOUNDARY-START(327751)
        $asm.$cls("$swh.System.Web.HttpUtility", ($self) => class HttpUtility extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(393287)
            static $_HttpQSCollection;
            static get HttpQSCollection()
            {
                let $cls = $.$swh.System.Web.HttpUtility;
                return $cls.$_HttpQSCollection ??= $asm.$ncls("$swh.System.Web.HttpUtility.HttpQSCollection", ($self) => class HttpQSCollection extends $.$scs.System.Collections.Specialized.NameValueCollection
                {
                    //--TRIMMABLE-BOUNDARY-START(4295360583)
                    $ctor$17()
                    {
                        super.$ctor$9($.$$.System.StringComparer.OrdinalIgnoreCase);
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4295360583);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295360583)
                    
                    //--TRIMMABLE-BOUNDARY-START(ALL, 8590327879, 330712612865)
                    static/*conventional*/ /*string */ ToString()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8590327879);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*int*/ let count = this.Count;
                        if (count === 0)
                        {
                            return "";
                        }
                        /*StringBuilder*/ let sb = new $.$$.System.Text.StringBuilder().$ctor$1();
                        /*string?[]*/ let keys = this.AllKeys;
                        for(/*int*/ let i = 0; i < count; i++)
                        {
                            /*string?*/ let key = $.$$.System.Array.$ReadT1.call(keys, i);
                            /*string[]?*/ let values = this.GetValues$1(key);
                            if (values !== null)
                            {
                                let $i1 = 0;
                                let $arr1 = values;
                                while ($i1 < $arr1.length)
                                {
                                    let value = $arr1[$i1++];
                                    if (!$.$$.System.String.IsNullOrEmpty(key))
                                    {
                                        sb.Append$19($.$swh.System.Web.HttpUtility.UrlEncode$3(key)).Append$3(/*=*/ 61);
                                    }
                                    sb.Append$19($.$swh.System.Web.HttpUtility.UrlEncode$3(value)).Append$3(/*&*/ 38);
                                }
                            }
                        }
                        return sb.Length > 0 ? sb.ToString$1(0, ((sb.Length - 1) | 0)) : "";
                    }
                    //Static convention instance redirect
                    /*string */ ToString() { return $.$swh.System.Web.HttpUtility.HttpQSCollection.ToString.apply(this, arguments); }
                    //--TRIMMABLE-BOUNDARY-END(ALL, 8590327879, 330712612865)
                    
                    static $h = 393287;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 983057,
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 8590327879, 330712612865),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 393287,
      "h": 8590327879,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 8590327879, 330712612865)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295360583),
    {
      "n": ".ctor",
      "o": "$ctor$17",
      "d": 393287,
      "h": 4295360583,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4295360583)
  ],
  "i": [62259201,62521345,157351937,157089793
  ],
  "d": 327751,
  "h": 393287
}; }
                    static get $b() { return $.$scs.System.Collections.Specialized.NameValueCollection; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable, $.$$.System.Runtime.Serialization.ISerializable, $.$$.System.Runtime.Serialization.IDeserializationCallback ]; }
                    static get $fullName() { return `System.Web.HttpUtility.HttpQSCollection`; }
                }, $cls, ($v) => $cls.$_HttpQSCollection = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(393287)
            
            //--TRIMMABLE-BOUNDARY-START(51539935303)
            static /*NameValueCollection */ ParseQueryString$1(/*string*/ query)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51539935303);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$swh.System.Web.HttpUtility.ParseQueryString(query, $.$$.System.Text.Encoding.UTF8);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51539935303)
            
            //--TRIMMABLE-BOUNDARY-START(55834902599)
            static /*NameValueCollection */ ParseQueryString(/*string*/ query, /*Encoding*/ encoding)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834902599);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(query, "query");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(encoding, "encoding");
                /*HttpQSCollection*/ let result = new $.$swh.System.Web.HttpUtility.HttpQSCollection().$ctor$17();
                /*int*/ let queryLength = query.length;
                /*int*/ let namePos = $.$$.System.String.StartsWith.call(query, /*?*/ 63) ? 1 : 0;
                if (queryLength === namePos)
                {
                    return result;
                }
                while(namePos <= queryLength)
                {
                    /*int*/ let valuePos = -1, valueEnd = -1;
                    for(/*int*/ let q = namePos; q < queryLength; q++)
                    {
                        if (valuePos === -1 && $.$$.System.String.get_Chars.call(query, q) === /*=*/ 61)
                        {
                            valuePos = ((q + 1) | 0);
                        }
                        else if ($.$$.System.String.get_Chars.call(query, q) === /*&*/ 38)
                        {
                            valueEnd = q;
                            break;
                        }
                    }
                    /*string?*/ let name;
                    if (valuePos === -1)
                    {
                        name = null;
                        valuePos = namePos;
                    }
                    else 
                    {
                        name = $.$swh.System.Web.HttpUtility.UrlDecode$2($.$$.System.MemoryExtensions.AsSpan$1(query, namePos, ((((valuePos - namePos) | 0) - 1) | 0)), encoding);
                    }
                    if (valueEnd < 0)
                    {
                        valueEnd = query.length;
                    }
                    namePos = ((valueEnd + 1) | 0);
                    /*string*/ let value = $.$swh.System.Web.HttpUtility.UrlDecode$2($.$$.System.MemoryExtensions.AsSpan$1(query, valuePos, ((valueEnd - valuePos) | 0)), encoding);
                    result.Add(name, value);
                }
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(55834902599)
            
            //--TRIMMABLE-BOUNDARY-START(17180196935)
            static /*string? */ HtmlDecode$1(/*string?*/ s)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180196935);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$swh.System.Web.Util.HttpEncoder.HtmlDecode$1(s);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180196935)
            
            //--TRIMMABLE-BOUNDARY-START(21475164231)
            static /*void */ HtmlDecode(/*string?*/ s, /*TextWriter*/ output)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475164231);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$swh.System.Web.Util.HttpEncoder.HtmlDecode(s, output);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475164231)
            
            //--TRIMMABLE-BOUNDARY-START(25770131527)
            static /*string? */ HtmlEncode$2(/*string?*/ s)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770131527);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$swh.System.Web.Util.HttpEncoder.HtmlEncode$1(s);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770131527)
            
            //--TRIMMABLE-BOUNDARY-START(30065098823)
            static /*string? */ HtmlEncode(/*object?*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065098823);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (() =>
                    {
                        if (value === null)
                        {
                            return null;
                        }
                        {
                            let ihs;
                            if ((ihs = value, $.$is(ihs, $.$swh.System.Web.IHtmlString)))
                            {
                                return ihs.System$Web$IHtmlString$ToHtmlString() ?? $.$$.System.String.Empty;
                            }
                        }
                        return $.$swh.System.Web.HttpUtility.HtmlEncode$2($.$$.System.Convert.ToString$23(value, $.$$.System.Globalization.CultureInfo.CurrentCulture) ?? $.$$.System.String.Empty);
                    })();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065098823)
            
            //--TRIMMABLE-BOUNDARY-START(34360066119)
            static /*void */ HtmlEncode$1(/*string?*/ s, /*TextWriter*/ output)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360066119);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$swh.System.Web.Util.HttpEncoder.HtmlEncode(s, output);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360066119)
            
            //--TRIMMABLE-BOUNDARY-START(8590262343)
            static /*string? */ HtmlAttributeEncode$1(/*string?*/ s)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590262343);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$swh.System.Web.Util.HttpEncoder.HtmlAttributeEncode$1(s);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590262343)
            
            //--TRIMMABLE-BOUNDARY-START(12885229639)
            static /*void */ HtmlAttributeEncode(/*string?*/ s, /*TextWriter*/ output)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885229639);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$swh.System.Web.Util.HttpEncoder.HtmlAttributeEncode(s, output);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885229639)
            
            //--TRIMMABLE-BOUNDARY-START(98784575559)
            static /*string? */ UrlEncode$3(/*string?*/ str)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(98784575559);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$swh.System.Web.HttpUtility.UrlEncode$2(str, $.$$.System.Text.Encoding.UTF8);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(98784575559)
            
            //--TRIMMABLE-BOUNDARY-START(141734248519)
            static /*string? */ UrlPathEncode(/*string?*/ str)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(141734248519);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$swh.System.Web.Util.HttpEncoder.UrlPathEncode(str);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(141734248519)
            
            //--TRIMMABLE-BOUNDARY-START(103079542855)
            static /*string? */ UrlEncode$2(/*string?*/ str, /*Encoding*/ e)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(103079542855);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.String.op_Equality(str, null) ? null : $.$$.System.Text.Encoding.ASCII.GetString$1($.$swh.System.Web.HttpUtility.UrlEncodeToBytes$2(str, e));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103079542855)
            
            //--TRIMMABLE-BOUNDARY-START(107374510151)
            static /*string? */ UrlEncode$1(/*byte[]?*/ bytes)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(107374510151);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return bytes === null ? null : $.$$.System.Text.Encoding.ASCII.GetString$1($.$swh.System.Web.HttpUtility.UrlEncodeToBytes$1(bytes));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(107374510151)
            
            //--TRIMMABLE-BOUNDARY-START(111669477447)
            static /*string? */ UrlEncode(/*byte[]?*/ bytes, /*int*/ offset, /*int*/ count)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(111669477447);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return bytes === null ? null : $.$$.System.Text.Encoding.ASCII.GetString$1($.$swh.System.Web.HttpUtility.UrlEncodeToBytes(bytes, offset, count));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(111669477447)
            
            //--TRIMMABLE-BOUNDARY-START(115964444743)
            static /*byte[]? */ UrlEncodeToBytes$3(/*string?*/ str)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(115964444743);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$swh.System.Web.HttpUtility.UrlEncodeToBytes$2(str, $.$$.System.Text.Encoding.UTF8);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(115964444743)
            
            //--TRIMMABLE-BOUNDARY-START(120259412039)
            static /*byte[]? */ UrlEncodeToBytes$1(/*byte[]?*/ bytes)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(120259412039);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return bytes === null ? null : $.$swh.System.Web.HttpUtility.UrlEncodeToBytes(bytes, 0, bytes.length);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(120259412039)
            
            //--TRIMMABLE-BOUNDARY-START(137439281223)
            static /*byte[]? */ UrlEncodeUnicodeToBytes(/*string?*/ str)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(137439281223);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.String.op_Equality(str, null) ? null : $.$$.System.Text.Encoding.ASCII.GetBytes$8($.$swh.System.Web.HttpUtility.UrlEncodeUnicode(str));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(137439281223)
            
            //--TRIMMABLE-BOUNDARY-START(60129869895)
            static /*string? */ UrlDecode$4(/*string?*/ str)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60129869895);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$swh.System.Web.HttpUtility.UrlDecode$3(str, $.$$.System.Text.Encoding.UTF8);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60129869895)
            
            //--TRIMMABLE-BOUNDARY-START(64424837191)
            static /*string? */ UrlDecode$1(/*byte[]?*/ bytes, /*Encoding*/ e)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64424837191);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return bytes === null ? null : $.$swh.System.Web.HttpUtility.UrlDecode(bytes, 0, bytes.length, e);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64424837191)
            
            //--TRIMMABLE-BOUNDARY-START(81604706375)
            static /*byte[]? */ UrlDecodeToBytes$3(/*string?*/ str)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(81604706375);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$swh.System.Web.HttpUtility.UrlDecodeToBytes$2(str, $.$$.System.Text.Encoding.UTF8);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(81604706375)
            
            //--TRIMMABLE-BOUNDARY-START(85899673671)
            static /*byte[]? */ UrlDecodeToBytes$2(/*string?*/ str, /*Encoding*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899673671);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let StackallocThreshold = 512;
                if ($.$$.System.String.op_Equality(str, null))
                {
                    return null;
                }
                if (e.GetMaxByteCount(str.length) <= StackallocThreshold)
                {
                    /*Span<byte>*/ let bytes = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Byte, StackallocThreshold, null);
                    /*int*/ let encodedBytes = e.GetBytes$5($.$$.System.String.op_Implicit(str), bytes);
                    return $.$swh.System.Web.Util.HttpEncoder.UrlDecode$2($.$$.System.Span$$($.$$.System.Byte).op_Implicit(bytes.Slice(0, encodedBytes)));
                }
                return $.$swh.System.Web.HttpUtility.UrlDecodeToBytes$1(e.GetBytes$8(str));
            }
            //--TRIMMABLE-BOUNDARY-END(85899673671)
            
            //--TRIMMABLE-BOUNDARY-START(90194640967)
            static /*byte[]? */ UrlDecodeToBytes$1(/*byte[]?*/ bytes)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(90194640967);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return bytes === null ? null : $.$swh.System.Web.Util.HttpEncoder.UrlDecode$2($.$$.System.ReadOnlySpan$$($.$$.System.Byte).op_Implicit$1(bytes));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(90194640967)
            
            //--TRIMMABLE-BOUNDARY-START(124554379335)
            static /*byte[]? */ UrlEncodeToBytes$2(/*string?*/ str, /*Encoding*/ e)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(124554379335);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.String.op_Equality(str, null) ? null : $.$swh.System.Web.Util.HttpEncoder.UrlEncode$3(str, e);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(124554379335)
            
            //--TRIMMABLE-BOUNDARY-START(128849346631)
            static /*byte[]? */ UrlEncodeToBytes(/*byte[]?*/ bytes, /*int*/ offset, /*int*/ count)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(128849346631);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$swh.System.Web.Util.HttpEncoder.UrlEncode(bytes, offset, count);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(128849346631)
            
            //--TRIMMABLE-BOUNDARY-START(133144313927)
            static /*string? */ UrlEncodeUnicode(/*string?*/ str)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(133144313927);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$swh.System.Web.Util.HttpEncoder.UrlEncodeUnicode(str);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(133144313927)
            
            //--TRIMMABLE-BOUNDARY-START(68719804487)
            static /*string? */ UrlDecode$3(/*string?*/ str, /*Encoding*/ e)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68719804487);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$swh.System.Web.Util.HttpEncoder.UrlDecode$4(str, e);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68719804487)
            
            //--TRIMMABLE-BOUNDARY-START(73014771783)
            static /*string */ UrlDecode$2(/*ReadOnlySpan<char>*/ str, /*Encoding*/ e)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73014771783);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$swh.System.Web.Util.HttpEncoder.UrlDecode$3(str, e);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(73014771783)
            
            //--TRIMMABLE-BOUNDARY-START(77309739079)
            static /*string? */ UrlDecode(/*byte[]?*/ bytes, /*int*/ offset, /*int*/ count, /*Encoding*/ e)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77309739079);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$swh.System.Web.Util.HttpEncoder.UrlDecode(bytes, offset, count, e);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77309739079)
            
            //--TRIMMABLE-BOUNDARY-START(94489608263)
            static /*byte[]? */ UrlDecodeToBytes(/*byte[]?*/ bytes, /*int*/ offset, /*int*/ count)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(94489608263);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$swh.System.Web.Util.HttpEncoder.UrlDecode$1(bytes, offset, count);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(94489608263)
            
            //--TRIMMABLE-BOUNDARY-START(42950000711)
            static /*string */ JavaScriptStringEncode$1(/*string?*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950000711);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$swh.System.Web.Util.HttpEncoder.JavaScriptStringEncode(value, false);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950000711)
            
            //--TRIMMABLE-BOUNDARY-START(47244968007)
            static /*string */ JavaScriptStringEncode(/*string?*/ value, /*bool*/ addDoubleQuotes)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47244968007);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$swh.System.Web.Util.HttpEncoder.JavaScriptStringEncode(value, addDoubleQuotes);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47244968007)
            
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 327751;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(51539935303),
    {
      "r": 983057,
      "p": [
        {
          "n": "query",
          "p": 1310721
        }
      ],
      "n": "ParseQueryString",
      "o": "@$1",
      "d": 327751,
      "h": 51539935303,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(51539935303),
//--TRIMMABLE-BOUNDARY-START(55834902599),
    {
      "r": 983057,
      "p": [
        {
          "n": "query",
          "p": 1310721
        },
        {
          "n": "encoding",
          "p": 165806081
        }
      ],
      "n": "ParseQueryString",
      "d": 327751,
      "h": 55834902599,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(55834902599),
//--TRIMMABLE-BOUNDARY-START(17180196935),
    {
      "r": 1310721,
      "p": [
        {
          "n": "s",
          "p": 1310721
        }
      ],
      "n": "HtmlDecode",
      "o": "@$1",
      "d": 327751,
      "h": 17180196935,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17180196935),
//--TRIMMABLE-BOUNDARY-START(21475164231),
    {
      "r": 65537,
      "p": [
        {
          "n": "s",
          "p": 1310721
        },
        {
          "n": "output",
          "p": 95682561
        }
      ],
      "n": "HtmlDecode",
      "d": 327751,
      "h": 21475164231,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21475164231),
//--TRIMMABLE-BOUNDARY-START(25770131527),
    {
      "r": 1310721,
      "p": [
        {
          "n": "s",
          "p": 1310721
        }
      ],
      "n": "HtmlEncode",
      "o": "@$2",
      "d": 327751,
      "h": 25770131527,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25770131527),
//--TRIMMABLE-BOUNDARY-START(30065098823),
    {
      "r": 1310721,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "HtmlEncode",
      "d": 327751,
      "h": 30065098823,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30065098823),
//--TRIMMABLE-BOUNDARY-START(34360066119),
    {
      "r": 65537,
      "p": [
        {
          "n": "s",
          "p": 1310721
        },
        {
          "n": "output",
          "p": 95682561
        }
      ],
      "n": "HtmlEncode",
      "o": "@$1",
      "d": 327751,
      "h": 34360066119,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34360066119),
//--TRIMMABLE-BOUNDARY-START(8590262343),
    {
      "r": 1310721,
      "p": [
        {
          "n": "s",
          "p": 1310721
        }
      ],
      "n": "HtmlAttributeEncode",
      "o": "@$1",
      "d": 327751,
      "h": 8590262343,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590262343),
//--TRIMMABLE-BOUNDARY-START(12885229639),
    {
      "r": 65537,
      "p": [
        {
          "n": "s",
          "p": 1310721
        },
        {
          "n": "output",
          "p": 95682561
        }
      ],
      "n": "HtmlAttributeEncode",
      "d": 327751,
      "h": 12885229639,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12885229639),
//--TRIMMABLE-BOUNDARY-START(98784575559),
    {
      "r": 1310721,
      "p": [
        {
          "n": "str",
          "p": 1310721
        }
      ],
      "n": "UrlEncode",
      "o": "@$3",
      "d": 327751,
      "h": 98784575559,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(98784575559),
//--TRIMMABLE-BOUNDARY-START(141734248519),
    {
      "r": 1310721,
      "p": [
        {
          "n": "str",
          "p": 1310721
        }
      ],
      "n": "UrlPathEncode",
      "d": 327751,
      "h": 141734248519,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(141734248519),
//--TRIMMABLE-BOUNDARY-START(103079542855),
    {
      "r": 1310721,
      "p": [
        {
          "n": "str",
          "p": 1310721
        },
        {
          "n": "e",
          "p": 165806081
        }
      ],
      "n": "UrlEncode",
      "o": "@$2",
      "d": 327751,
      "h": 103079542855,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(103079542855),
//--TRIMMABLE-BOUNDARY-START(107374510151),
    {
      "r": 1310721,
      "p": [
        {
          "n": "bytes",
          "p": $.$typeArray($.$$.System.Byte).$h
        }
      ],
      "n": "UrlEncode",
      "o": "@$1",
      "d": 327751,
      "h": 107374510151,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(107374510151),
//--TRIMMABLE-BOUNDARY-START(111669477447),
    {
      "r": 1310721,
      "p": [
        {
          "n": "bytes",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "UrlEncode",
      "d": 327751,
      "h": 111669477447,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(111669477447),
//--TRIMMABLE-BOUNDARY-START(115964444743),
    {
      "r": $.$typeArray($.$$.System.Byte).$h,
      "p": [
        {
          "n": "str",
          "p": 1310721
        }
      ],
      "n": "UrlEncodeToBytes",
      "o": "@$3",
      "d": 327751,
      "h": 115964444743,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(115964444743),
//--TRIMMABLE-BOUNDARY-START(120259412039),
    {
      "r": $.$typeArray($.$$.System.Byte).$h,
      "p": [
        {
          "n": "bytes",
          "p": $.$typeArray($.$$.System.Byte).$h
        }
      ],
      "n": "UrlEncodeToBytes",
      "o": "@$1",
      "d": 327751,
      "h": 120259412039,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(120259412039),
//--TRIMMABLE-BOUNDARY-START(137439281223),
    {
      "r": $.$typeArray($.$$.System.Byte).$h,
      "p": [
        {
          "n": "str",
          "p": 1310721
        }
      ],
      "n": "UrlEncodeUnicodeToBytes",
      "d": 327751,
      "h": 137439281223,
      "f": 16777249,
      "a": [
        {
          "t": 103612417,
          "c": 8693547009,
          "a": [
            {
              "v": "This method produces non-standards-compliant output and has interoperability issues. The preferred alternative is UrlEncodeToBytes(String).",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(137439281223),
//--TRIMMABLE-BOUNDARY-START(60129869895),
    {
      "r": 1310721,
      "p": [
        {
          "n": "str",
          "p": 1310721
        }
      ],
      "n": "UrlDecode",
      "o": "@$4",
      "d": 327751,
      "h": 60129869895,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(60129869895),
//--TRIMMABLE-BOUNDARY-START(64424837191),
    {
      "r": 1310721,
      "p": [
        {
          "n": "bytes",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "e",
          "p": 165806081
        }
      ],
      "n": "UrlDecode",
      "o": "@$1",
      "d": 327751,
      "h": 64424837191,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(64424837191),
//--TRIMMABLE-BOUNDARY-START(81604706375),
    {
      "r": $.$typeArray($.$$.System.Byte).$h,
      "p": [
        {
          "n": "str",
          "p": 1310721
        }
      ],
      "n": "UrlDecodeToBytes",
      "o": "@$3",
      "d": 327751,
      "h": 81604706375,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(81604706375),
//--TRIMMABLE-BOUNDARY-START(85899673671),
    {
      "r": $.$typeArray($.$$.System.Byte).$h,
      "p": [
        {
          "n": "str",
          "p": 1310721
        },
        {
          "n": "e",
          "p": 165806081
        }
      ],
      "n": "UrlDecodeToBytes",
      "o": "@$2",
      "d": 327751,
      "h": 85899673671,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(85899673671),
//--TRIMMABLE-BOUNDARY-START(90194640967),
    {
      "r": $.$typeArray($.$$.System.Byte).$h,
      "p": [
        {
          "n": "bytes",
          "p": $.$typeArray($.$$.System.Byte).$h
        }
      ],
      "n": "UrlDecodeToBytes",
      "o": "@$1",
      "d": 327751,
      "h": 90194640967,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(90194640967),
//--TRIMMABLE-BOUNDARY-START(124554379335),
    {
      "r": $.$typeArray($.$$.System.Byte).$h,
      "p": [
        {
          "n": "str",
          "p": 1310721
        },
        {
          "n": "e",
          "p": 165806081
        }
      ],
      "n": "UrlEncodeToBytes",
      "o": "@$2",
      "d": 327751,
      "h": 124554379335,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(124554379335),
//--TRIMMABLE-BOUNDARY-START(128849346631),
    {
      "r": $.$typeArray($.$$.System.Byte).$h,
      "p": [
        {
          "n": "bytes",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "UrlEncodeToBytes",
      "d": 327751,
      "h": 128849346631,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(128849346631),
//--TRIMMABLE-BOUNDARY-START(133144313927),
    {
      "r": 1310721,
      "p": [
        {
          "n": "str",
          "p": 1310721
        }
      ],
      "n": "UrlEncodeUnicode",
      "d": 327751,
      "h": 133144313927,
      "f": 16777249,
      "a": [
        {
          "t": 103612417,
          "c": 8693547009,
          "a": [
            {
              "v": "This method produces non-standards-compliant output and has interoperability issues. The preferred alternative is UrlEncode(String).",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(133144313927),
//--TRIMMABLE-BOUNDARY-START(68719804487),
    {
      "r": 1310721,
      "p": [
        {
          "n": "str",
          "p": 1310721
        },
        {
          "n": "e",
          "p": 165806081
        }
      ],
      "n": "UrlDecode",
      "o": "@$3",
      "d": 327751,
      "h": 68719804487,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(68719804487),
//--TRIMMABLE-BOUNDARY-START(73014771783),
    {
      "r": 1310721,
      "p": [
        {
          "n": "str",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        },
        {
          "n": "e",
          "p": 165806081
        }
      ],
      "n": "UrlDecode",
      "o": "@$2",
      "d": 327751,
      "h": 73014771783,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(73014771783),
//--TRIMMABLE-BOUNDARY-START(77309739079),
    {
      "r": 1310721,
      "p": [
        {
          "n": "bytes",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "e",
          "p": 165806081
        }
      ],
      "n": "UrlDecode",
      "d": 327751,
      "h": 77309739079,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(77309739079),
//--TRIMMABLE-BOUNDARY-START(94489608263),
    {
      "r": $.$typeArray($.$$.System.Byte).$h,
      "p": [
        {
          "n": "bytes",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "UrlDecodeToBytes",
      "d": 327751,
      "h": 94489608263,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(94489608263),
//--TRIMMABLE-BOUNDARY-START(42950000711),
    {
      "r": 1310721,
      "p": [
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "JavaScriptStringEncode",
      "o": "@$1",
      "d": 327751,
      "h": 42950000711,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(42950000711),
//--TRIMMABLE-BOUNDARY-START(47244968007),
    {
      "r": 1310721,
      "p": [
        {
          "n": "value",
          "p": 1310721
        },
        {
          "n": "addDoubleQuotes",
          "p": 262145
        }
      ],
      "n": "JavaScriptStringEncode",
      "d": 327751,
      "h": 47244968007,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(47244968007)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295295047),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 327751,
      "h": 4295295047,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295295047)
  ],
  "j": [393287
  ],
  "h": 327751
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Web.HttpUtility`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327751)
        
        
        //--TRIMMABLE-BOUNDARY-START(524359)
        $asm.$cls("$swh.System.Web.Util.HttpEncoder", ($self) => class HttpEncoder
        {
            //--TRIMMABLE-BOUNDARY-START(47245164615)
            /*int*/ static MaxStackAllocUrlLength = 256;
            //--TRIMMABLE-BOUNDARY-END(47245164615)
            
            //--TRIMMABLE-BOUNDARY-START(64425033799)
            /*int*/ static StackallocThreshold = 512;
            //--TRIMMABLE-BOUNDARY-END(64425033799)
            
            //--TRIMMABLE-BOUNDARY-START(60130066503)
            /*SearchValues<byte>*/ static s_urlSafeBytes = null;
            //--TRIMMABLE-BOUNDARY-END(60130066503)
            
            //--TRIMMABLE-BOUNDARY-START(55835099207)
            /*SearchValues<char>*/ static s_invalidJavaScriptChars = null;
            //--TRIMMABLE-BOUNDARY-END(55835099207)
            
            //--TRIMMABLE-BOUNDARY-START(8590458951)
            static /*string? */ HtmlAttributeEncode$1(/*string?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590458951);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.IsNullOrEmpty(value))
                {
                    return value;
                }
                /*int*/ let pos = $.$swh.System.Web.Util.HttpEncoder.IndexOfHtmlAttributeEncodingChars(value);
                if (pos < 0)
                {
                    return value;
                }
                /*StringWriter*/ let writer = new $.$$.System.IO.StringWriter().$ctor$5($.$$.System.Globalization.CultureInfo.InvariantCulture);
                $.$swh.System.Web.Util.HttpEncoder.HtmlAttributeEncodeInternal(value, pos, writer);
                return $.$$.System.IO.StringWriter.ToString.call(writer);
            }
            //--TRIMMABLE-BOUNDARY-END(8590458951)
            
            //--TRIMMABLE-BOUNDARY-START(12885426247)
            static /*void */ HtmlAttributeEncode(/*string?*/ value, /*TextWriter*/ output)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885426247);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.op_Equality(value, null))
                {
                    return;
                }
                $.$$.System.ArgumentNullException.ThrowIfNull$2(output, "output");
                /*int*/ let pos = $.$swh.System.Web.Util.HttpEncoder.IndexOfHtmlAttributeEncodingChars(value);
                if (pos < 0)
                {
                    output.Write$16(value);
                    return;
                }
                $.$swh.System.Web.Util.HttpEncoder.HtmlAttributeEncodeInternal(value, pos, output);
            }
            //--TRIMMABLE-BOUNDARY-END(12885426247)
            
            //--TRIMMABLE-BOUNDARY-START(17180393543)
            static /*void */ HtmlAttributeEncodeInternal(/*string*/ s, /*int*/ index, /*TextWriter*/ output)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180393543);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                output.Write$9($.$$.System.MemoryExtensions.AsSpan$1(s, 0, index));
                /*ReadOnlySpan<char>*/ let remaining = $.$$.System.MemoryExtensions.AsSpan$2(s, index);
                for(/*int*/ let i = 0; i < remaining.Length; i++)
                {
                    /*char*/ let ch = remaining.get_Item(i).$v;
                    if (ch <= /*<*/ 60)
                    {
                        switch(ch)
                        {
                            case /*<*/ 60:
                            output.Write$16("&lt;");
                            break;
                            case /*\"*/ 34:
                            output.Write$16("&quot;");
                            break;
                            case /*'*/ 39:
                            output.Write$16("&#39;");
                            break;
                            case /*&*/ 38:
                            output.Write$16("&amp;");
                            break;
                            default:
                            output.Write$1(ch);
                            break;
                        }
                    }
                    else 
                    {
                        output.Write$1(ch);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180393543)
            
            //--TRIMMABLE-BOUNDARY-START(21475360839)
            static /*string? */ HtmlDecode$1(/*string?*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475360839);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.String.IsNullOrEmpty(value) ? value : $.$$.System.Net.WebUtility.HtmlDecode$2(value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475360839)
            
            //--TRIMMABLE-BOUNDARY-START(25770328135)
            static /*void */ HtmlDecode(/*string?*/ value, /*TextWriter*/ output)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770328135);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(output, "output");
                output.Write$16($.$$.System.Net.WebUtility.HtmlDecode$2(value));
            }
            //--TRIMMABLE-BOUNDARY-END(25770328135)
            
            //--TRIMMABLE-BOUNDARY-START(30065295431)
            static /*string? */ HtmlEncode$1(/*string?*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065295431);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.String.IsNullOrEmpty(value) ? value : $.$$.System.Net.WebUtility.HtmlEncode$2(value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065295431)
            
            //--TRIMMABLE-BOUNDARY-START(34360262727)
            static /*void */ HtmlEncode(/*string?*/ value, /*TextWriter*/ output)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360262727);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(output, "output");
                output.Write$16($.$$.System.Net.WebUtility.HtmlEncode$2(value));
            }
            //--TRIMMABLE-BOUNDARY-END(34360262727)
            
            //--TRIMMABLE-BOUNDARY-START(38655230023)
            static /*int */ IndexOfHtmlAttributeEncodingChars(/*string*/ s)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655230023);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.MemoryExtensions.IndexOfAny$4($.$$.System.Char, $.$$.System.MemoryExtensions.AsSpan$4(s), $.$$.System.String.op_Implicit("<\"'&"));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38655230023)
            
            //--TRIMMABLE-BOUNDARY-START(42950197319)
            static /*string */ JavaScriptStringEncode(/*string?*/ value, /*bool*/ addDoubleQuotes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950197319);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let i = $.$$.System.MemoryExtensions.IndexOfAny$2($.$$.System.Char, $.$$.System.MemoryExtensions.AsSpan$4(value), $.$swh.System.Web.Util.HttpEncoder.s_invalidJavaScriptChars);
                if (i < 0)
                {
                    return addDoubleQuotes ? `\"${value}\"` : value ?? $.$$.System.String.Empty;
                }
                return EncodeCore($.$$.System.String.op_Implicit(value), i, addDoubleQuotes);
                /*static string*/  function EncodeCore(/*ReadOnlySpan<char>*/ value, /*int*/ i, /*bool*/ addDoubleQuotes)
                {
                    /*var*/ let vsb = new $.$swh.System.Text.ValueStringBuilder().$ctor$4($.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Char, 512/*StackallocThreshold*/, null));
                    if (addDoubleQuotes)
                    {
                        vsb.Append$1(/*\"*/ 34);
                    }
                    /*ReadOnlySpan<char>*/ let chars = value;
                    do
                    {
                        vsb.Append$2(chars.Slice(0, i));
                        /*char*/ let c = chars.get_Item(i).$v;
                        chars = chars.Slice$1(((i + 1) | 0));
                        switch(c)
                        {
                            case /*\r*/ 13:
                            vsb.Append$3("\\r");
                            break;
                            case /*\t*/ 9:
                            vsb.Append$3("\\t");
                            break;
                            case /*\"*/ 34:
                            vsb.Append$3("\\\"");
                            break;
                            case /*\\*/ 92:
                            vsb.Append$3("\\\\");
                            break;
                            case /*\n*/ 10:
                            vsb.Append$3("\\n");
                            break;
                            case /*\u0008*/ 8:
                            vsb.Append$3("\\b");
                            break;
                            case /*\u000C*/ 12:
                            vsb.Append$3("\\f");
                            break;
                            default:
                            vsb.Append$3("\\u");
                            vsb.AppendSpanFormattable($.$$.System.Int32, $.$cast(c, $.$$.System.Int32), "x4", null);
                            break;
                        }
                        i = $.$$.System.MemoryExtensions.IndexOfAny$2($.$$.System.Char, chars, $.$swh.System.Web.Util.HttpEncoder.s_invalidJavaScriptChars);
                    }
                    while(i >= 0);
                    vsb.Append$2(chars);
                    if (addDoubleQuotes)
                    {
                        vsb.Append$1(/*\"*/ 34);
                    }
                    return $.$swh.System.Text.ValueStringBuilder.ToString.call(vsb);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950197319)
            
            //--TRIMMABLE-BOUNDARY-START(68720001095)
            static /*byte[]? */ UrlDecode$1(/*byte[]?*/ bytes, /*int*/ offset, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720001095);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$swh.System.Web.Util.HttpEncoder.ValidateUrlEncodingParameters(bytes, offset, count))
                {
                    return null;
                }
                return $.$swh.System.Web.Util.HttpEncoder.UrlDecode$2($.$$.System.Span$$($.$$.System.Byte).op_Implicit($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, bytes, offset, count)));
            }
            //--TRIMMABLE-BOUNDARY-END(68720001095)
            
            //--TRIMMABLE-BOUNDARY-START(73014968391)
            static /*byte[] */ UrlDecode$2(/*ReadOnlySpan<byte>*/ bytes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014968391);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let decodedBytesCount = 0;
                /*int*/ let count = bytes.Length;
                /*Span<byte>*/ let decodedBytes = count <= 512/*StackallocThreshold*/ ? $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Byte, 512/*StackallocThreshold*/, null) : $.$$.System.Span$$($.$$.System.Byte).op_Implicit$2($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Byte), null, [count], null));
                for(/*int*/ let i = 0; i < count; i++)
                {
                    /*byte*/ let b = bytes.get_Item(i).$v;
                    if (b === /*+*/ 43)
                    {
                        b = /* */ 32;
                    }
                    else if (b === /*%*/ 37 && i < ((count - 2) | 0))
                    {
                        /*int*/ let h1 = $.$swh.System.HexConverter.FromChar(bytes.get_Item(((i + 1) | 0)).$v);
                        /*int*/ let h2 = $.$swh.System.HexConverter.FromChar(bytes.get_Item(((i + 2) | 0)).$v);
                        if ((h1 | h2) !== 255)
                        {
                            b = $.$cast(((h1 << 4) | h2), $.$$.System.Byte);
                            i += 2;
                        }
                    }
                    decodedBytes.get_Item(decodedBytesCount++).$v = b;
                }
                return decodedBytes.Slice(0, decodedBytesCount).ToArray();
            }
            //--TRIMMABLE-BOUNDARY-END(73014968391)
            
            //--TRIMMABLE-BOUNDARY-START(77309935687)
            static /*string? */ UrlDecode(/*byte[]?*/ bytes, /*int*/ offset, /*int*/ count, /*Encoding*/ encoding)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309935687);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$swh.System.Web.Util.HttpEncoder.ValidateUrlEncodingParameters(bytes, offset, count))
                {
                    return null;
                }
                /*UrlDecoder*/ let helper = count <= 256/*MaxStackAllocUrlLength*/ ? new $.$swh.System.Web.Util.HttpEncoder.UrlDecoder().$ctor$3($.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Char, 256/*MaxStackAllocUrlLength*/, null), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Byte, 256/*MaxStackAllocUrlLength*/, null), encoding) : new $.$swh.System.Web.Util.HttpEncoder.UrlDecoder().$ctor$3($.$$.System.Span$$($.$$.System.Char).op_Implicit$2($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Char), null, [count], null)), $.$$.System.Span$$($.$$.System.Byte).op_Implicit$2($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Byte), null, [count], null)), encoding);
                for(/*int*/ let i = 0; i < count; i++)
                {
                    /*int*/ let pos = ((offset + i) | 0);
                    /*byte*/ let b = $.$$.System.Array.$ReadT1.call(bytes, pos);
                    if (b === /*+*/ 43)
                    {
                        b = /* */ 32;
                    }
                    else if (b === /*%*/ 37 && i < ((count - 2) | 0))
                    {
                        if ($.$$.System.Array.$ReadT1.call(bytes, ((pos + 1) | 0)) === /*u*/ 117 && i < ((count - 5) | 0))
                        {
                            /*int*/ let h1 = $.$swh.System.HexConverter.FromChar($.$$.System.Array.$ReadT1.call(bytes, ((pos + 2) | 0)));
                            /*int*/ let h2 = $.$swh.System.HexConverter.FromChar($.$$.System.Array.$ReadT1.call(bytes, ((pos + 3) | 0)));
                            /*int*/ let h3 = $.$swh.System.HexConverter.FromChar($.$$.System.Array.$ReadT1.call(bytes, ((pos + 4) | 0)));
                            /*int*/ let h4 = $.$swh.System.HexConverter.FromChar($.$$.System.Array.$ReadT1.call(bytes, ((pos + 5) | 0)));
                            if ((h1 | h2 | h3 | h4) !== 255)
                            {
                                /*char*/ let ch = $.$cast(((h1 << 12) | (h2 << 8) | (h3 << 4) | h4), $.$$.System.Char);
                                i += 5;
                                helper.AddChar(ch);
                                continue;
                            }
                        }
                        else 
                        {
                            /*int*/ let h1 = $.$swh.System.HexConverter.FromChar($.$$.System.Array.$ReadT1.call(bytes, ((pos + 1) | 0)));
                            /*int*/ let h2 = $.$swh.System.HexConverter.FromChar($.$$.System.Array.$ReadT1.call(bytes, ((pos + 2) | 0)));
                            if ((h1 | h2) !== 255)
                            {
                                b = $.$cast(((h1 << 4) | h2), $.$$.System.Byte);
                                i += 2;
                            }
                        }
                    }
                    helper.AddByte(b);
                }
                return helper.GetString();
            }
            //--TRIMMABLE-BOUNDARY-END(77309935687)
            
            //--TRIMMABLE-BOUNDARY-START(81604902983)
            static /*string? */ UrlDecode$4(/*string?*/ value, /*Encoding*/ encoding)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604902983);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.op_Equality(value, null))
                {
                    return null;
                }
                return $.$swh.System.Web.Util.HttpEncoder.UrlDecode$3($.$$.System.MemoryExtensions.AsSpan$4(value), encoding);
            }
            //--TRIMMABLE-BOUNDARY-END(81604902983)
            
            //--TRIMMABLE-BOUNDARY-START(85899870279)
            static /*string */ UrlDecode$3(/*ReadOnlySpan<char>*/ value, /*Encoding*/ encoding)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899870279);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value.IsEmpty)
                {
                    return $.$$.System.String.Empty;
                }
                /*int*/ let count = value.Length;
                /*UrlDecoder*/ let helper = count <= 256/*MaxStackAllocUrlLength*/ ? new $.$swh.System.Web.Util.HttpEncoder.UrlDecoder().$ctor$3($.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Char, 256/*MaxStackAllocUrlLength*/, null), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Byte, 256/*MaxStackAllocUrlLength*/, null), encoding) : new $.$swh.System.Web.Util.HttpEncoder.UrlDecoder().$ctor$3($.$$.System.Span$$($.$$.System.Char).op_Implicit$2($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Char), null, [count], null)), $.$$.System.Span$$($.$$.System.Byte).op_Implicit$2($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Byte), null, [count], null)), encoding);
                for(/*int*/ let pos = 0; pos < count; pos++)
                {
                    /*char*/ let ch = value.get_Item(pos).$v;
                    if (ch === /*+*/ 43)
                    {
                        ch = /* */ 32;
                    }
                    else if (ch === /*%*/ 37 && pos < ((count - 2) | 0))
                    {
                        if (value.get_Item(((pos + 1) | 0)).$v === /*u*/ 117 && pos < ((count - 5) | 0))
                        {
                            /*int*/ let h1 = $.$swh.System.HexConverter.FromChar(value.get_Item(((pos + 2) | 0)).$v);
                            /*int*/ let h2 = $.$swh.System.HexConverter.FromChar(value.get_Item(((pos + 3) | 0)).$v);
                            /*int*/ let h3 = $.$swh.System.HexConverter.FromChar(value.get_Item(((pos + 4) | 0)).$v);
                            /*int*/ let h4 = $.$swh.System.HexConverter.FromChar(value.get_Item(((pos + 5) | 0)).$v);
                            if ((h1 | h2 | h3 | h4) !== 255)
                            {
                                ch = $.$cast(((h1 << 12) | (h2 << 8) | (h3 << 4) | h4), $.$$.System.Char);
                                pos += 5;
                                helper.AddChar(ch);
                                continue;
                            }
                        }
                        else 
                        {
                            /*int*/ let h1 = $.$swh.System.HexConverter.FromChar(value.get_Item(((pos + 1) | 0)).$v);
                            /*int*/ let h2 = $.$swh.System.HexConverter.FromChar(value.get_Item(((pos + 2) | 0)).$v);
                            if ((h1 | h2) !== 255)
                            {
                                /*byte*/ let b = $.$cast(((h1 << 4) | h2), $.$$.System.Byte);
                                pos += 2;
                                helper.AddByte(b);
                                continue;
                            }
                        }
                    }
                    if ((ch & 65408) === 0)
                    {
                        helper.AddByte($.$cast(ch, $.$$.System.Byte));
                    }
                    else 
                    {
                        helper.AddChar(ch);
                    }
                }
                return helper.GetString();
            }
            //--TRIMMABLE-BOUNDARY-END(85899870279)
            
            //--TRIMMABLE-BOUNDARY-START(94489804871)
            static /*byte[]? */ UrlEncode(/*byte[]?*/ bytes, /*int*/ offset, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489804871);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$swh.System.Web.Util.HttpEncoder.ValidateUrlEncodingParameters(bytes, offset, count))
                {
                    return null;
                }
                return $.$swh.System.Web.Util.HttpEncoder.UrlEncode$2($.$$.System.Span$$($.$$.System.Byte).op_Implicit($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, bytes, offset, count)));
            }
            //--TRIMMABLE-BOUNDARY-END(94489804871)
            
            //--TRIMMABLE-BOUNDARY-START(98784772167)
            static /*byte[] */ UrlEncode$2(/*ReadOnlySpan<byte>*/ bytes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784772167);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let cUnsafe;
                if (!$.$swh.System.Web.Util.HttpEncoder.NeedsEncoding(bytes, $.$ref(() => cUnsafe, ($v) => cUnsafe = $v, $.$$.System.Int32)))
                {
                    return bytes.ToArray();
                }
                return $.$swh.System.Web.Util.HttpEncoder.UrlEncode$1(bytes, cUnsafe);
            }
            //--TRIMMABLE-BOUNDARY-END(98784772167)
            
            //--TRIMMABLE-BOUNDARY-START(103079739463)
            static /*byte[] */ UrlEncode$1(/*ReadOnlySpan<byte>*/ bytes, /*int*/ cUnsafe)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079739463);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*byte[]*/ let expandedBytes = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Byte), null, [((bytes.Length + ((cUnsafe * 2) | 0)) | 0)], null);
                /*int*/ let pos = 0;
                var $en2 = bytes.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var b = $en2.Current.$v;
                    {
                        if ($.$swh.System.Web.Util.HttpEncoder.s_urlSafeBytes.Contains(b))
                        {
                            $.$$.System.Array.$WriteT1.call(expandedBytes, b, pos++);
                        }
                        else if (b === /* */ 32)
                        {
                            $.$$.System.Array.$WriteT1.call(expandedBytes, /*+*/ 43, pos++);
                        }
                        else 
                        {
                            $.$$.System.Array.$WriteT1.call(expandedBytes, /*%*/ 37, pos++);
                            $.$$.System.Array.$WriteT1.call(expandedBytes, $.$cast($.$swh.System.HexConverter.ToCharLower(b >>> 4), $.$$.System.Byte), pos++);
                            $.$$.System.Array.$WriteT1.call(expandedBytes, $.$cast($.$swh.System.HexConverter.ToCharLower(b), $.$$.System.Byte), pos++);
                        }
                    }
                }
                return expandedBytes;
            }
            //--TRIMMABLE-BOUNDARY-END(103079739463)
            
            //--TRIMMABLE-BOUNDARY-START(51540131911)
            static /*bool */ NeedsEncoding(/*ReadOnlySpan<byte>*/ bytes, /*out int*/ cUnsafe)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540131911);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                cUnsafe.$v = 0;
                /*int*/ let i = $.$$.System.MemoryExtensions.IndexOfAnyExcept($.$$.System.Byte, bytes, $.$swh.System.Web.Util.HttpEncoder.s_urlSafeBytes);
                if (i < 0)
                {
                    return false;
                }
                var $en2 = bytes.Slice$1(i).GetEnumerator();
                while ($en2.MoveNext())
                {
                    var b = $en2.Current.$v;
                    {
                        if (!$.$swh.System.Web.Util.HttpEncoder.s_urlSafeBytes.Contains(b) && b !== /* */ 32)
                        {
                            cUnsafe.$v++;
                        }
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(51540131911)
            
            //--TRIMMABLE-BOUNDARY-START(107374706759)
            static /*byte[] */ UrlEncode$3(/*string*/ str, /*Encoding*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374706759);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (e.GetMaxByteCount(str.length) <= 512/*StackallocThreshold*/)
                {
                    /*Span<byte>*/ let byteSpan = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Byte, 512/*StackallocThreshold*/, null);
                    /*int*/ let encodedBytes = e.GetBytes$5($.$$.System.String.op_Implicit(str), byteSpan);
                    return $.$swh.System.Web.Util.HttpEncoder.UrlEncode$2($.$$.System.Span$$($.$$.System.Byte).op_Implicit(byteSpan.Slice(0, encodedBytes)));
                }
                /*byte[]*/ let bytes = e.GetBytes$8(str);
                /*int*/ let cUnsafe;
                return $.$swh.System.Web.Util.HttpEncoder.NeedsEncoding($.$$.System.ReadOnlySpan$$($.$$.System.Byte).op_Implicit$1(bytes), $.$ref(() => cUnsafe, ($v) => cUnsafe = $v, $.$$.System.Int32)) ? $.$swh.System.Web.Util.HttpEncoder.UrlEncode$1($.$$.System.ReadOnlySpan$$($.$$.System.Byte).op_Implicit$1(bytes), cUnsafe) : bytes;
            }
            //--TRIMMABLE-BOUNDARY-END(107374706759)
            
            //--TRIMMABLE-BOUNDARY-START(111669674055)
            static /*string? */ UrlEncodeUnicode(/*string?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669674055);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.op_Equality(value, null))
                {
                    return null;
                }
                /*int*/ let l = value.length;
                /*StringBuilder*/ let sb = new $.$$.System.Text.StringBuilder().$ctor$4(l);
                for(/*int*/ let i = 0; i < l; i++)
                {
                    /*char*/ let ch = $.$$.System.String.get_Chars.call(value, i);
                    if ((ch & 65408) === 0)
                    {
                        if ($.$swh.System.Web.Util.HttpEncoder.s_urlSafeBytes.Contains($.$cast(ch, $.$$.System.Byte)))
                        {
                            sb.Append$3(ch);
                        }
                        else if (ch === /* */ 32)
                        {
                            sb.Append$3(/*+*/ 43);
                        }
                        else 
                        {
                            sb.Append$3(/*%*/ 37);
                            sb.Append$3($.$swh.System.HexConverter.ToCharLower(ch >>> 4));
                            sb.Append$3($.$swh.System.HexConverter.ToCharLower(ch));
                        }
                    }
                    else 
                    {
                        sb.Append$19("%u");
                        sb.Append$3($.$swh.System.HexConverter.ToCharLower(ch >>> 12));
                        sb.Append$3($.$swh.System.HexConverter.ToCharLower(ch >>> 8));
                        sb.Append$3($.$swh.System.HexConverter.ToCharLower(ch >>> 4));
                        sb.Append$3($.$swh.System.HexConverter.ToCharLower(ch));
                    }
                }
                return $.$$.System.Text.StringBuilder.ToString.call(sb);
            }
            //--TRIMMABLE-BOUNDARY-END(111669674055)
            
            //--TRIMMABLE-BOUNDARY-START(115964641351)
            static /*string? */ UrlPathEncode(/*string?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964641351);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.IsNullOrEmpty(value))
                {
                    return value;
                }
                /*ReadOnlySpan<char>*/ let schemeAndAuthority;
                /*string?*/ let path;
                /*ReadOnlySpan<char>*/ let queryAndFragment;
                if (!$.$swh.System.Web.Util.UriUtil.TrySplitUriForPathEncode(value, $.$ref(() => schemeAndAuthority, ($v) => schemeAndAuthority = $v, $.$$.System.ReadOnlySpan$$($.$$.System.Char)), $.$ref(() => path, ($v) => path = $v, $.$$.System.String), $.$ref(() => queryAndFragment, ($v) => queryAndFragment = $v, $.$$.System.ReadOnlySpan$$($.$$.System.Char))))
                {
                    return $.$swh.System.Web.Util.HttpEncoder.UrlPathEncodeImpl(value);
                }
                return $.$$.System.String.Concat$7(schemeAndAuthority, $.$$.System.String.op_Implicit($.$swh.System.Web.Util.HttpEncoder.UrlPathEncodeImpl(path)), queryAndFragment);
            }
            //--TRIMMABLE-BOUNDARY-END(115964641351)
            
            //--TRIMMABLE-BOUNDARY-START(120259608647)
            static /*string */ UrlPathEncodeImpl(/*string*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259608647);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.IsNullOrEmpty(value))
                {
                    return value;
                }
                /*int*/ let i = $.$$.System.MemoryExtensions.IndexOfAnyExceptInRange($.$$.System.Char, $.$$.System.MemoryExtensions.AsSpan$4(value), 33, 127);
                if (i < 0)
                {
                    return value;
                }
                /*int*/ let indexOfQuery = $.$$.System.String.IndexOf$3.call(value, /*?*/ 63);
                if ((indexOfQuery >>> 0) < (i >>> 0))
                {
                    return value;
                }
                /*ReadOnlySpan<char>*/ let toEncode = indexOfQuery >= 0 ? $.$$.System.MemoryExtensions.AsSpan$1(value, i, ((indexOfQuery - i) | 0)) : $.$$.System.MemoryExtensions.AsSpan$2(value, i);
                /*byte[]*/ let bytes = $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared.Rent($.$$.System.Text.Encoding.UTF8.GetMaxByteCount(toEncode.Length));
                /*int*/ let utf8Length = $.$$.System.Text.Encoding.UTF8.GetBytes$5(toEncode, $.$$.System.Span$$($.$$.System.Byte).op_Implicit$2(bytes));
                /*char[]*/ let chars = $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared.Rent(((utf8Length * 3) | 0));
                /*int*/ let charCount = 0;
                var $en2 = $.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, bytes, 0, utf8Length).GetEnumerator();
                while ($en2.MoveNext())
                {
                    var b = $en2.Current.$v;
                    {
                        if (!$.$$.System.Char.IsBetween(b, 33, 127))
                        {
                            $.$$.System.Array.$WriteT1.call(chars, /*%*/ 37, charCount++);
                            $.$$.System.Array.$WriteT1.call(chars, $.$swh.System.HexConverter.ToCharLower(b >>> 4), charCount++);
                            $.$$.System.Array.$WriteT1.call(chars, $.$swh.System.HexConverter.ToCharLower(b), charCount++);
                        }
                        else 
                        {
                            $.$$.System.Array.$WriteT1.call(chars, b, charCount++);
                        }
                    }
                }
                $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared.Return(bytes, false);
                /*string*/ let result = $.$$.System.String.Concat$7($.$$.System.MemoryExtensions.AsSpan$1(value, 0, i), $.$$.System.Span$$($.$$.System.Char).op_Implicit($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Char, chars, 0, charCount)), indexOfQuery >= 0 ? $.$$.System.MemoryExtensions.AsSpan$2(value, indexOfQuery) : $.$$.System.ReadOnlySpan$$($.$$.System.Char).Empty);
                $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared.Return(chars, false);
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(120259608647)
            
            //--TRIMMABLE-BOUNDARY-START(124554575943)
            static /*bool */ ValidateUrlEncodingParameters(/*byte[]?*/ bytes, /*int*/ offset, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554575943);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (bytes === null && count === 0)
                {
                    return false;
                }
                $.$$.System.ArgumentNullException.ThrowIfNull$2(bytes, "bytes");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, offset, "offset");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$$.System.Int32, offset, bytes.length, "offset");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, count, "count");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$$.System.Int32, count, ((bytes.length - offset) | 0), "count");
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(124554575943)
            
            //--TRIMMABLE-BOUNDARY-START(589895)
            static $_UrlDecoder;
            static get UrlDecoder()
            {
                let $cls = $.$swh.System.Web.Util.HttpEncoder;
                return $cls.$_UrlDecoder ??= $asm.$nstr("$swh.System.Web.Util.HttpEncoder.UrlDecoder", ($self) => class UrlDecoder extends $.$$.System.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(21475426375)
                    /*int*/  get _numChars() { return this.$getField(0, 4); }
                    /*int*/  set _numChars(value) { this.$setField(0, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(21475426375)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590524487)
                    /*Span<char>*/  get _charBuffer() { return this.$getField(4, 6); }
                    /*Span<char>*/  set _charBuffer(value) { this.$setField(4, 6, value); }
                    //--TRIMMABLE-BOUNDARY-END(8590524487)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180459079)
                    /*int*/  get _numBytes() { return this.$getField(10, 4); }
                    /*int*/  set _numBytes(value) { this.$setField(10, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(17180459079)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295557191)
                    /*Span<byte>*/  get _byteBuffer() { return this.$getField(14, 5); }
                    /*Span<byte>*/  set _byteBuffer(value) { this.$setField(14, 5, value); }
                    //--TRIMMABLE-BOUNDARY-END(4295557191)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885491783)
                    /*Encoding*/  get _encoding() { return this.$getField(19, 4); }
                    /*Encoding*/  set _encoding(value) { this.$setField(19, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(12885491783)
                    
                    //--TRIMMABLE-BOUNDARY-START(42950262855)
                    /*void */ FlushBytes()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(42950262855);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._numBytes > 0)
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(!this._byteBuffer.IsEmpty, "!_byteBuffer.IsEmpty");
                            this._numChars += this._encoding.GetChars$5($.$$.System.Span$$($.$$.System.Byte).op_Implicit(this._byteBuffer.Slice(0, this._numBytes)), this._charBuffer.Slice$1(this._numChars));
                            this._numBytes = 0;
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(42950262855)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770393671)
                    $ctor$3(/*Span<char>*/ charBuffer, /*Span<byte>*/ byteBuffer, /*Encoding*/ encoding)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(25770393671);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._charBuffer = charBuffer;
                            this._byteBuffer = byteBuffer;
                            this._encoding = encoding;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770393671)
                    
                    //--TRIMMABLE-BOUNDARY-START(38655295559)
                    /*void */ AddChar(/*char*/ ch)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(38655295559);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._numBytes > 0)
                        {
                            this.FlushBytes();
                        }
                        this._charBuffer.get_Item(this._numChars++).$v = ch;
                    }
                    //--TRIMMABLE-BOUNDARY-END(38655295559)
                    
                    //--TRIMMABLE-BOUNDARY-START(34360328263)
                    /*void */ AddByte(/*byte*/ b)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34360328263);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        {
                            this._byteBuffer.get_Item(this._numBytes++).$v = b;
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(34360328263)
                    
                    //--TRIMMABLE-BOUNDARY-START(47245230151)
                    /*string */ GetString()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(47245230151);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._numBytes > 0)
                        {
                            this.FlushBytes();
                        }
                        /*Span<char>*/ let chars = this._charBuffer.Slice(0, this._numChars);
                        /*char*/ let HIGH_SURROGATE_START = /*\uD800*/ 55296;
                        /*char*/ let LOW_SURROGATE_END = /*\uDFFF*/ 57343;
                        /*int*/ let idxOfFirstSurrogate = $.$$.System.MemoryExtensions.IndexOfAnyInRange($.$$.System.Char, $.$$.System.Span$$($.$$.System.Char).op_Implicit(chars), HIGH_SURROGATE_START, LOW_SURROGATE_END);
                        for(/*int*/ let i = idxOfFirstSurrogate; (i >>> 0) < (chars.Length >>> 0); i++)
                        {
                            if ($.$$.System.Char.IsHighSurrogate(chars.get_Item(i).$v))
                            {
                                if (((((i + 1) | 0)) >>> 0) >= (chars.Length >>> 0) || !$.$$.System.Char.IsLowSurrogate(chars.get_Item(((i + 1) | 0)).$v))
                                {
                                    chars.get_Item(i).$v = $.$cast($.$$.System.Text.Rune.ReplacementChar.Value, $.$$.System.Char);
                                }
                                else 
                                {
                                    i++;
                                }
                            }
                            else if ($.$$.System.Char.IsLowSurrogate(chars.get_Item(i).$v))
                            {
                                chars.get_Item(i).$v = $.$cast($.$$.System.Text.Rune.ReplacementChar.Value, $.$$.System.Char);
                            }
                        }
                        return $.$$.System.Span$$($.$$.System.Char).ToString.call(chars);
                    }
                    //--TRIMMABLE-BOUNDARY-END(47245230151)
                    
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._numChars = this._numChars;
                        copy._charBuffer = this._charBuffer.Clone();
                        copy._numBytes = this._numBytes;
                        copy._byteBuffer = this._byteBuffer.Clone();
                        copy._encoding = this._encoding;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(21475426375)
                        this._numChars = 0;
                        //--TRIMMABLE-BOUNDARY-END(21475426375)
                        
                        //--TRIMMABLE-BOUNDARY-START(8590524487)
                        this._charBuffer = $.$default($.$$.System.Span$$($.$$.System.Char));
                        //--TRIMMABLE-BOUNDARY-END(8590524487)
                        
                        //--TRIMMABLE-BOUNDARY-START(17180459079)
                        this._numBytes = 0;
                        //--TRIMMABLE-BOUNDARY-END(17180459079)
                        
                        //--TRIMMABLE-BOUNDARY-START(4295557191)
                        this._byteBuffer = $.$default($.$$.System.Span$$($.$$.System.Byte));
                        //--TRIMMABLE-BOUNDARY-END(4295557191)
                        
                        //--TRIMMABLE-BOUNDARY-START(12885491783)
                        this._encoding = null;
                        //--TRIMMABLE-BOUNDARY-END(12885491783)
                        
                    }
                    static $h = 589895;
                    static $z = 23;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 196609,
  "m": [
//--TRIMMABLE-BOUNDARY-START(42950262855),
    {
      "r": 65537,
      "n": "FlushBytes",
      "d": 589895,
      "h": 42950262855,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(42950262855),
//--TRIMMABLE-BOUNDARY-START(38655295559),
    {
      "r": 65537,
      "p": [
        {
          "n": "ch",
          "p": 458753
        }
      ],
      "n": "AddChar",
      "d": 589895,
      "h": 38655295559,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(38655295559),
//--TRIMMABLE-BOUNDARY-START(34360328263),
    {
      "r": 65537,
      "p": [
        {
          "n": "b",
          "p": 393217
        }
      ],
      "n": "AddByte",
      "d": 589895,
      "h": 34360328263,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(34360328263),
//--TRIMMABLE-BOUNDARY-START(47245230151),
    {
      "r": 1310721,
      "n": "GetString",
      "d": 589895,
      "h": 47245230151,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(47245230151)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(21475426375),
    {
      "t": 655361,
      "n": "_numChars",
      "d": 589895,
      "h": 21475426375,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475426375),
//--TRIMMABLE-BOUNDARY-START(8590524487),
    {
      "t": $.$$.System.Span$$($.$$.System.Char).$h,
      "n": "_charBuffer",
      "d": 589895,
      "h": 8590524487,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590524487),
//--TRIMMABLE-BOUNDARY-START(17180459079),
    {
      "t": 655361,
      "n": "_numBytes",
      "d": 589895,
      "h": 17180459079,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180459079),
//--TRIMMABLE-BOUNDARY-START(4295557191),
    {
      "t": $.$$.System.Span$$($.$$.System.Byte).$h,
      "n": "_byteBuffer",
      "d": 589895,
      "h": 4295557191,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295557191),
//--TRIMMABLE-BOUNDARY-START(12885491783),
    {
      "t": 165806081,
      "n": "_encoding",
      "d": 589895,
      "h": 12885491783,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885491783)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770393671),
    {
      "p": [
        {
          "n": "charBuffer",
          "p": $.$$.System.Span$$($.$$.System.Char).$h
        },
        {
          "n": "byteBuffer",
          "p": $.$$.System.Span$$($.$$.System.Byte).$h
        },
        {
          "n": "encoding",
          "p": 165806081
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 589895,
      "h": 25770393671,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(25770393671),
//--TRIMMABLE-BOUNDARY-START(30065360967),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 589895,
      "h": 30065360967,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065360967)
  ],
  "d": 524359,
  "h": 589895
}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `System.Web.Util.HttpEncoder.UrlDecoder`; }
                }, $cls, ($v) => $cls.$_UrlDecoder = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(589895)
            
            //--TRIMMABLE-BOUNDARY-START(4295491655)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(60130066503)
                    this.s_urlSafeBytes = $.$$.System.Buffers.SearchValues.Create(new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([33, 40, 41, 42, 45, 46, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 95, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122]));
                    //--TRIMMABLE-BOUNDARY-END(60130066503)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(55835099207)
                    this.s_invalidJavaScriptChars = $.$$.System.Buffers.SearchValues.Create$1($.$$.System.String.op_Implicit("\u0000\u0001\u0002\u0003\u0004\u0005\u0006\u0007\u0008\t\n\u000B\u000C\r\u000E\u000F\u0010\u0011\u0012\u0013\u0014\u0015\u0016\u0017\u0018\u0019\u001A\u001B\u001C\u001D\u001E\u001F" + "\"&'<>\\" + "\u0085\u2028\u2029"));
                    //--TRIMMABLE-BOUNDARY-END(55835099207)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295491655)
            
            static $h = 524359;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590458951),
    {
      "r": 1310721,
      "p": [
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "HtmlAttributeEncode",
      "o": "@$1",
      "d": 524359,
      "h": 8590458951,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8590458951),
//--TRIMMABLE-BOUNDARY-START(12885426247),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 1310721
        },
        {
          "n": "output",
          "p": 95682561
        }
      ],
      "n": "HtmlAttributeEncode",
      "d": 524359,
      "h": 12885426247,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12885426247),
//--TRIMMABLE-BOUNDARY-START(17180393543),
    {
      "r": 65537,
      "p": [
        {
          "n": "s",
          "p": 1310721
        },
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "output",
          "p": 95682561
        }
      ],
      "n": "HtmlAttributeEncodeInternal",
      "d": 524359,
      "h": 17180393543,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(17180393543),
//--TRIMMABLE-BOUNDARY-START(21475360839),
    {
      "r": 1310721,
      "p": [
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "HtmlDecode",
      "o": "@$1",
      "d": 524359,
      "h": 21475360839,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(21475360839),
//--TRIMMABLE-BOUNDARY-START(25770328135),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 1310721
        },
        {
          "n": "output",
          "p": 95682561
        }
      ],
      "n": "HtmlDecode",
      "d": 524359,
      "h": 25770328135,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(25770328135),
//--TRIMMABLE-BOUNDARY-START(30065295431),
    {
      "r": 1310721,
      "p": [
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "HtmlEncode",
      "o": "@$1",
      "d": 524359,
      "h": 30065295431,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(30065295431),
//--TRIMMABLE-BOUNDARY-START(34360262727),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 1310721
        },
        {
          "n": "output",
          "p": 95682561
        }
      ],
      "n": "HtmlEncode",
      "d": 524359,
      "h": 34360262727,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(34360262727),
//--TRIMMABLE-BOUNDARY-START(38655230023),
    {
      "r": 655361,
      "p": [
        {
          "n": "s",
          "p": 1310721
        }
      ],
      "n": "IndexOfHtmlAttributeEncodingChars",
      "d": 524359,
      "h": 38655230023,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(38655230023),
//--TRIMMABLE-BOUNDARY-START(42950197319),
    {
      "r": 1310721,
      "p": [
        {
          "n": "value",
          "p": 1310721
        },
        {
          "n": "addDoubleQuotes",
          "p": 262145
        }
      ],
      "n": "JavaScriptStringEncode",
      "d": 524359,
      "h": 42950197319,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(42950197319),
//--TRIMMABLE-BOUNDARY-START(68720001095),
    {
      "r": $.$typeArray($.$$.System.Byte).$h,
      "p": [
        {
          "n": "bytes",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "UrlDecode",
      "o": "@$1",
      "d": 524359,
      "h": 68720001095,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(68720001095),
//--TRIMMABLE-BOUNDARY-START(73014968391),
    {
      "r": $.$typeArray($.$$.System.Byte).$h,
      "p": [
        {
          "n": "bytes",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        }
      ],
      "n": "UrlDecode",
      "o": "@$2",
      "d": 524359,
      "h": 73014968391,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(73014968391),
//--TRIMMABLE-BOUNDARY-START(77309935687),
    {
      "r": 1310721,
      "p": [
        {
          "n": "bytes",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "encoding",
          "p": 165806081
        }
      ],
      "n": "UrlDecode",
      "d": 524359,
      "h": 77309935687,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(77309935687),
//--TRIMMABLE-BOUNDARY-START(81604902983),
    {
      "r": 1310721,
      "p": [
        {
          "n": "value",
          "p": 1310721
        },
        {
          "n": "encoding",
          "p": 165806081
        }
      ],
      "n": "UrlDecode",
      "o": "@$4",
      "d": 524359,
      "h": 81604902983,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(81604902983),
//--TRIMMABLE-BOUNDARY-START(85899870279),
    {
      "r": 1310721,
      "p": [
        {
          "n": "value",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        },
        {
          "n": "encoding",
          "p": 165806081
        }
      ],
      "n": "UrlDecode",
      "o": "@$3",
      "d": 524359,
      "h": 85899870279,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(85899870279),
//--TRIMMABLE-BOUNDARY-START(94489804871),
    {
      "r": $.$typeArray($.$$.System.Byte).$h,
      "p": [
        {
          "n": "bytes",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "UrlEncode",
      "d": 524359,
      "h": 94489804871,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(94489804871),
//--TRIMMABLE-BOUNDARY-START(98784772167),
    {
      "r": $.$typeArray($.$$.System.Byte).$h,
      "p": [
        {
          "n": "bytes",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        }
      ],
      "n": "UrlEncode",
      "o": "@$2",
      "d": 524359,
      "h": 98784772167,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(98784772167),
//--TRIMMABLE-BOUNDARY-START(103079739463),
    {
      "r": $.$typeArray($.$$.System.Byte).$h,
      "p": [
        {
          "n": "bytes",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "cUnsafe",
          "p": 655361
        }
      ],
      "n": "UrlEncode",
      "o": "@$1",
      "d": 524359,
      "h": 103079739463,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(103079739463),
//--TRIMMABLE-BOUNDARY-START(51540131911),
    {
      "r": 262145,
      "p": [
        {
          "n": "bytes",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "cUnsafe",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "NeedsEncoding",
      "d": 524359,
      "h": 51540131911,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(51540131911),
//--TRIMMABLE-BOUNDARY-START(107374706759),
    {
      "r": $.$typeArray($.$$.System.Byte).$h,
      "p": [
        {
          "n": "str",
          "p": 1310721
        },
        {
          "n": "e",
          "p": 165806081
        }
      ],
      "n": "UrlEncode",
      "o": "@$3",
      "d": 524359,
      "h": 107374706759,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(107374706759),
//--TRIMMABLE-BOUNDARY-START(111669674055),
    {
      "r": 1310721,
      "p": [
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "UrlEncodeUnicode",
      "d": 524359,
      "h": 111669674055,
      "f": 16777256,
      "a": [
        {
          "t": 103612417,
          "c": 8693547009,
          "a": [
            {
              "v": "This method produces non-standards-compliant output and has interoperability issues. The preferred alternative is UrlEncode(*).",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(111669674055),
//--TRIMMABLE-BOUNDARY-START(115964641351),
    {
      "r": 1310721,
      "p": [
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "UrlPathEncode",
      "d": 524359,
      "h": 115964641351,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(115964641351),
//--TRIMMABLE-BOUNDARY-START(120259608647),
    {
      "r": 1310721,
      "p": [
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "UrlPathEncodeImpl",
      "d": 524359,
      "h": 120259608647,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(120259608647),
//--TRIMMABLE-BOUNDARY-START(124554575943),
    {
      "r": 262145,
      "p": [
        {
          "n": "bytes",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "ValidateUrlEncodingParameters",
      "d": 524359,
      "h": 124554575943,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(124554575943)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(47245164615),
    {
      "t": 655361,
      "n": "MaxStackAllocUrlLength",
      "d": 524359,
      "h": 47245164615,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(47245164615),
//--TRIMMABLE-BOUNDARY-START(64425033799),
    {
      "t": 655361,
      "n": "StackallocThreshold",
      "d": 524359,
      "h": 64425033799,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(64425033799),
//--TRIMMABLE-BOUNDARY-START(60130066503),
    {
      "t": $.$$.System.Buffers.SearchValues$$($.$$.System.Byte).$h,
      "n": "s_urlSafeBytes",
      "d": 524359,
      "h": 60130066503,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(60130066503),
//--TRIMMABLE-BOUNDARY-START(55835099207),
    {
      "t": $.$$.System.Buffers.SearchValues$$($.$$.System.Char).$h,
      "n": "s_invalidJavaScriptChars",
      "d": 524359,
      "h": 55835099207,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(55835099207)
  ],
  "j": [589895
  ],
  "h": 524359
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Web.Util.HttpEncoder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524359)
        
        
        //--TRIMMABLE-BOUNDARY-START(65607)
        $asm.$cls("$swh.System.HexConverter", ($self) => class HexConverter
        {
            //--TRIMMABLE-BOUNDARY-START(131143)
            static $_Casing;
            static get Casing()
            {
                let $cls = $.$swh.System.HexConverter;
                return $cls.$_Casing ??= $asm.$nstr("$swh.System.HexConverter.Casing", ($self) => class Casing extends $.$$.System.Enum
                {
                    static Upper = 0;
                    static Lower = 8224;
                    static $map;
                    static get Map()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(131143);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.$map ??= 
                        {
                            "Upper": 0n,
                            "Lower": 8224n
                        };
                    }
                    static $h = 131143;
                    static $z = 4;
                    static $f = 0b110000011010001001;
                    static $k = 4;
                    static get $eut() { return $.$$.System.UInt32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 720897,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885033031),
    {
      "t": 131143,
      "n": "Upper",
      "d": 131143,
      "h": 12885033031,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885033031),
//--TRIMMABLE-BOUNDARY-START(8590065735),
    {
      "t": 131143,
      "n": "Lower",
      "d": 131143,
      "h": 8590065735,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590065735)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295098439),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 131143,
      "h": 4295098439,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295098439)
  ],
  "i": [89915393,96468993,90374145,90046465
  ],
  "d": 65607,
  "h": 131143
}; }
                    static get $b() { return $.$$.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
                    static get $fullName() { return `System.HexConverter.Casing`; }
                }, $cls, ($v) => $cls.$_Casing = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(131143)
            
            //--TRIMMABLE-BOUNDARY-START(60129607751)
            static /*void */ ToBytesBuffer(/*byte*/ value, /*Span<byte>*/ buffer, /*int*/ startingIndex, /*Casing*/ casing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129607751);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*uint*/ let difference = (((((((value & 240) << 4) >>> 0) + (value & 15)) >>> 0) - 35209) >>> 0);
                /*uint*/ let packedResult = (((((((((-(difference | 0)) >>> 0) & 28784) >>> 4) + difference) >>> 0) + 47545) >>> 0)) | casing;
                buffer.get_Item(((startingIndex + 1) | 0)).$v = $.$cast(packedResult, $.$$.System.Byte);
                buffer.get_Item(startingIndex).$v = $.$cast((packedResult >>> 8), $.$$.System.Byte);
            }
            //--TRIMMABLE-BOUNDARY-END(60129607751)
            
            //--TRIMMABLE-BOUNDARY-START(68719542343)
            static /*void */ ToCharsBuffer(/*byte*/ value, /*Span<char>*/ buffer, /*int*/ startingIndex, /*Casing*/ casing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719542343);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*uint*/ let difference = (((((((value & 240) << 4) >>> 0) + (value & 15)) >>> 0) - 35209) >>> 0);
                /*uint*/ let packedResult = (((((((((-(difference | 0)) >>> 0) & 28784) >>> 4) + difference) >>> 0) + 47545) >>> 0)) | casing;
                buffer.get_Item(((startingIndex + 1) | 0)).$v = $.$cast((packedResult & 255), $.$$.System.Char);
                buffer.get_Item(startingIndex).$v = $.$cast((packedResult >>> 8), $.$$.System.Char);
            }
            //--TRIMMABLE-BOUNDARY-END(68719542343)
            
            //--TRIMMABLE-BOUNDARY-START(17179934791)
            static /*void */ EncodeToUtf8(/*ReadOnlySpan<byte>*/ source, /*Span<byte>*/ utf8Destination, /*Casing*/ casing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17179934791);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(utf8Destination.Length >= (((source.Length * 2) | 0)), "utf8Destination.Length >= (source.Length * 2)");
                for(/*int*/ let pos = 0; pos < source.Length; pos++)
                {
                    $.$swh.System.HexConverter.ToBytesBuffer(source.get_Item(pos).$v, utf8Destination, ((pos * 2) | 0), casing);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17179934791)
            
            //--TRIMMABLE-BOUNDARY-START(12884967495)
            static /*void */ EncodeToUtf16(/*ReadOnlySpan<byte>*/ source, /*Span<char>*/ destination, /*Casing*/ casing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12884967495);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(destination.Length >= (((source.Length * 2) | 0)), "destination.Length >= (source.Length * 2)");
                for(/*int*/ let pos = 0; pos < source.Length; pos++)
                {
                    $.$swh.System.HexConverter.ToCharsBuffer(source.get_Item(pos).$v, destination, ((pos * 2) | 0), casing);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12884967495)
            
            //--TRIMMABLE-BOUNDARY-START(77309476935)
            static /*string */ ToString$1(/*ReadOnlySpan<byte>*/ bytes, /*Casing*/ casing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309476935);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*SpanCasingPair*/ let args = (() =>
                {
                    //new $.$swh.System.HexConverter.SpanCasingPair()
                    const $t1 = $.$swh.System.HexConverter.SpanCasingPair;
                    const $i1 = new $t1();
                    $i1.Bytes = bytes;
                    $i1.Casing = casing;
                    return $i1;
                })();
                return $.$$.System.String.Create$10($.$swh.System.HexConverter.SpanCasingPair, ((bytes.Length * 2) | 0), args.Clone(), new ($.$$.System.Buffers.SpanAction$$$($.$$.System.Char, $.$swh.System.HexConverter.SpanCasingPair))().$ctor($.$swh.System.HexConverter, /*static*/ (/*chars*/ chars, /**/ args) =>
                {
                    return $.$swh.System.HexConverter.EncodeToUtf16(args.Bytes, chars, args.Casing);
                }, {
  "r": 65537,
  "p": [
    {
      "n": "chars",
      "p": $.$$.System.Span$$($.$$.System.Char).$h
    },
    {
      "n": "args",
      "p": 196679
    }
  ],
  "n": "",
  "d": 65607,
  "h": 0,
  "f": 17825826
}));
            }
            //--TRIMMABLE-BOUNDARY-END(77309476935)
            
            //--TRIMMABLE-BOUNDARY-START(196679)
            static $_SpanCasingPair;
            static get SpanCasingPair()
            {
                let $cls = $.$swh.System.HexConverter;
                return $cls.$_SpanCasingPair ??= $asm.$nstr("$swh.System.HexConverter.SpanCasingPair", ($self) => class SpanCasingPair extends $.$$.System.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(17180065863)
                    /*ReadOnlySpan<byte>*/ Bytes;
                    //--TRIMMABLE-BOUNDARY-END(17180065863)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475033159)
                    /*Casing*/ Casing = 0;
                    //--TRIMMABLE-BOUNDARY-END(21475033159)
                    
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Bytes = this.Bytes.Clone();
                        copy.Casing = this.Casing;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.Bytes = $.$default($.$$.System.ReadOnlySpan$$($.$$.System.Byte));
                    }
                    static $h = 196679;
                    static $z = 9;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180065863),
    {
      "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30064967751,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47244836935,
        "f": 83886081
      },
      "n": "Bytes",
      "d": 196679,
      "h": 17180065863,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180065863),
//--TRIMMABLE-BOUNDARY-START(21475033159),
    {
      "p": 131143,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38654902343,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55834771527,
        "f": 83886081
      },
      "n": "Casing",
      "d": 196679,
      "h": 21475033159,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475033159)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295163975),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 196679,
      "h": 4295163975,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295163975)
  ],
  "d": 65607,
  "h": 196679
}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `System.HexConverter.SpanCasingPair`; }
                }, $cls, ($v) => $cls.$_SpanCasingPair = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(196679)
            
            //--TRIMMABLE-BOUNDARY-START(73014509639)
            static /*char */ ToCharUpper(/*int*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014509639);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                value &= 15;
                value += /*0*/ 48;
                if (value > /*9*/ 57)
                {
                    value += (((/*A*/ 65 - (((/*9*/ 57 + 1) | 0))) | 0));
                }
                return $.$cast(value, $.$$.System.Char);
            }
            //--TRIMMABLE-BOUNDARY-END(73014509639)
            
            //--TRIMMABLE-BOUNDARY-START(64424575047)
            static /*char */ ToCharLower(/*int*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424575047);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                value &= 15;
                value += /*0*/ 48;
                if (value > /*9*/ 57)
                {
                    value += (((/*a*/ 97 - (((/*9*/ 57 + 1) | 0))) | 0));
                }
                return $.$cast(value, $.$$.System.Char);
            }
            //--TRIMMABLE-BOUNDARY-END(64424575047)
            
            //--TRIMMABLE-BOUNDARY-START(90194378823)
            static /*bool */ TryDecodeFromUtf8(/*ReadOnlySpan<byte>*/ utf8Source, /*Span<byte>*/ destination, /*out int*/ bytesProcessed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194378823);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$swh.System.HexConverter.TryDecodeFromUtf8_Scalar(utf8Source, destination, bytesProcessed);
            }
            //--TRIMMABLE-BOUNDARY-END(90194378823)
            
            //--TRIMMABLE-BOUNDARY-START(81604444231)
            static /*bool */ TryDecodeFromUtf16(/*ReadOnlySpan<char>*/ source, /*Span<byte>*/ destination, /*out int*/ charsProcessed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604444231);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$swh.System.HexConverter.TryDecodeFromUtf16_Scalar(source, destination, charsProcessed);
            }
            //--TRIMMABLE-BOUNDARY-END(81604444231)
            
            //--TRIMMABLE-BOUNDARY-START(94489346119)
            static /*bool */ TryDecodeFromUtf8_Scalar(/*ReadOnlySpan<byte>*/ utf8Source, /*Span<byte>*/ destination, /*out int*/ bytesProcessed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489346119);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2((utf8Source.Length % 2) === 0, "Un-even number of characters provided");
                $.$$.System.Diagnostics.Debug.Assert$2(($.trunc(utf8Source.Length / 2)) === destination.Length, "Target buffer not right-sized for provided characters");
                /*int*/ let i = 0;
                /*int*/ let j = 0;
                /*int*/ let byteLo = 0;
                /*int*/ let byteHi = 0;
                while(j < destination.Length)
                {
                    byteLo = $.$swh.System.HexConverter.FromChar(utf8Source.get_Item(((i + 1) | 0)).$v);
                    byteHi = $.$swh.System.HexConverter.FromChar(utf8Source.get_Item(i).$v);
                    if ((byteLo | byteHi) === 255)
                    {
                        break;
                    }
                    destination.get_Item(j++).$v = $.$cast(((byteHi << 4) | byteLo), $.$$.System.Byte);
                    i += 2;
                }
                if (byteLo === 255)
                {
                    i++;
                }
                bytesProcessed.$v = i;
                return (byteLo | byteHi) !== 255;
            }
            //--TRIMMABLE-BOUNDARY-END(94489346119)
            
            //--TRIMMABLE-BOUNDARY-START(85899411527)
            static /*bool */ TryDecodeFromUtf16_Scalar(/*ReadOnlySpan<char>*/ source, /*Span<byte>*/ destination, /*out int*/ charsProcessed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899411527);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2((source.Length % 2) === 0, "Un-even number of characters provided");
                $.$$.System.Diagnostics.Debug.Assert$2(($.trunc(source.Length / 2)) === destination.Length, "Target buffer not right-sized for provided characters");
                /*int*/ let i = 0;
                /*int*/ let j = 0;
                /*int*/ let byteLo = 0;
                /*int*/ let byteHi = 0;
                while(j < destination.Length)
                {
                    byteLo = $.$swh.System.HexConverter.FromChar(source.get_Item(((i + 1) | 0)).$v);
                    byteHi = $.$swh.System.HexConverter.FromChar(source.get_Item(i).$v);
                    if ((byteLo | byteHi) === 255)
                    {
                        break;
                    }
                    destination.get_Item(j++).$v = $.$cast(((byteHi << 4) | byteLo), $.$$.System.Byte);
                    i += 2;
                }
                if (byteLo === 255)
                {
                    i++;
                }
                charsProcessed.$v = i;
                return (byteLo | byteHi) !== 255;
            }
            //--TRIMMABLE-BOUNDARY-END(85899411527)
            
            //--TRIMMABLE-BOUNDARY-START(21474902087)
            static /*int */ FromChar(/*int*/ c)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21474902087);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (c >= $.$swh.System.HexConverter.CharToHexLookup.Length) ? 255 : $.$swh.System.HexConverter.CharToHexLookup.get_Item(c).$v;
            }
            //--TRIMMABLE-BOUNDARY-END(21474902087)
            
            //--TRIMMABLE-BOUNDARY-START(30064836679)
            static /*int */ FromUpperChar(/*int*/ c)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064836679);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (c > 71) ? 255 : $.$swh.System.HexConverter.CharToHexLookup.get_Item(c).$v;
            }
            //--TRIMMABLE-BOUNDARY-END(30064836679)
            
            //--TRIMMABLE-BOUNDARY-START(25769869383)
            static /*int */ FromLowerChar(/*int*/ c)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25769869383);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (((((c - /*0*/ 48) | 0)) >>> 0) <= (/*9*/ 57 - /*0*/ 48))
                {
                    return ((c - /*0*/ 48) | 0);
                }
                if (((((c - /*a*/ 97) | 0)) >>> 0) <= (/*f*/ 102 - /*a*/ 97))
                {
                    return ((((c - /*a*/ 97) | 0) + 10) | 0);
                }
                return 255;
            }
            //--TRIMMABLE-BOUNDARY-END(25769869383)
            
            //--TRIMMABLE-BOUNDARY-START(42949738567)
            static /*bool */ IsHexChar(/*int*/ c)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949738567);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //if (IntPtr.Size == 8) { ... }
                return $.$swh.System.HexConverter.FromChar(c) !== 255;
            }
            //--TRIMMABLE-BOUNDARY-END(42949738567)
            
            //--TRIMMABLE-BOUNDARY-START(51539673159)
            static /*bool */ IsHexUpperChar(/*int*/ c)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539673159);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (((((c - /*0*/ 48) | 0)) >>> 0) <= 9) || (((((c - /*A*/ 65) | 0)) >>> 0) <= (/*F*/ 70 - /*A*/ 65));
            }
            //--TRIMMABLE-BOUNDARY-END(51539673159)
            
            //--TRIMMABLE-BOUNDARY-START(47244705863)
            static /*bool */ IsHexLowerChar(/*int*/ c)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244705863);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (((((c - /*0*/ 48) | 0)) >>> 0) <= 9) || (((((c - /*a*/ 97) | 0)) >>> 0) <= (/*f*/ 102 - /*a*/ 97));
            }
            //--TRIMMABLE-BOUNDARY-END(47244705863)
            
            //--TRIMMABLE-BOUNDARY-START(8590000199)
            static /*ReadOnlySpan<byte> */ get CharToHexLookup()
            {
                return this.$cacheCharToHexLookup ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([ 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 255, 255, 255, 255, 255, 255, 255, 10, 11, 12, 13, 14, 15, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 10, 11, 12, 13, 14, 15, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255 ]);
            }
            //--TRIMMABLE-BOUNDARY-END(8590000199)
            
            static $h = 65607;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(8590000199),
    {
      "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38654771271,
        "f": 50331681
      },
      "n": "CharToHexLookup",
      "d": 65607,
      "h": 8590000199,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(8590000199)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(60129607751),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 393217
        },
        {
          "n": "buffer",
          "p": $.$$.System.Span$$($.$$.System.Byte).$h
        },
        {
          "n": "startingIndex",
          "p": 655361,
          "f": 65,
          "v": 0
        },
        {
          "n": "casing",
          "p": 131143,
          "f": 65,
          "v": 0
        }
      ],
      "n": "ToBytesBuffer",
      "d": 65607,
      "h": 60129607751,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(60129607751),
//--TRIMMABLE-BOUNDARY-START(68719542343),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 393217
        },
        {
          "n": "buffer",
          "p": $.$$.System.Span$$($.$$.System.Char).$h
        },
        {
          "n": "startingIndex",
          "p": 655361,
          "f": 65,
          "v": 0
        },
        {
          "n": "casing",
          "p": 131143,
          "f": 65,
          "v": 0
        }
      ],
      "n": "ToCharsBuffer",
      "d": 65607,
      "h": 68719542343,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(68719542343),
//--TRIMMABLE-BOUNDARY-START(17179934791),
    {
      "r": 65537,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "utf8Destination",
          "p": $.$$.System.Span$$($.$$.System.Byte).$h
        },
        {
          "n": "casing",
          "p": 131143,
          "f": 65,
          "v": 0
        }
      ],
      "n": "EncodeToUtf8",
      "d": 65607,
      "h": 17179934791,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17179934791),
//--TRIMMABLE-BOUNDARY-START(12884967495),
    {
      "r": 65537,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "destination",
          "p": $.$$.System.Span$$($.$$.System.Char).$h
        },
        {
          "n": "casing",
          "p": 131143,
          "f": 65,
          "v": 0
        }
      ],
      "n": "EncodeToUtf16",
      "d": 65607,
      "h": 12884967495,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12884967495),
//--TRIMMABLE-BOUNDARY-START(77309476935),
    {
      "r": 1310721,
      "p": [
        {
          "n": "bytes",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "casing",
          "p": 131143,
          "f": 65,
          "v": 0
        }
      ],
      "n": "ToString",
      "o": "@$1",
      "d": 65607,
      "h": 77309476935,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(77309476935),
//--TRIMMABLE-BOUNDARY-START(73014509639),
    {
      "r": 458753,
      "p": [
        {
          "n": "value",
          "p": 655361
        }
      ],
      "n": "ToCharUpper",
      "d": 65607,
      "h": 73014509639,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(73014509639),
//--TRIMMABLE-BOUNDARY-START(64424575047),
    {
      "r": 458753,
      "p": [
        {
          "n": "value",
          "p": 655361
        }
      ],
      "n": "ToCharLower",
      "d": 65607,
      "h": 64424575047,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(64424575047),
//--TRIMMABLE-BOUNDARY-START(90194378823),
    {
      "r": 262145,
      "p": [
        {
          "n": "utf8Source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "destination",
          "p": $.$$.System.Span$$($.$$.System.Byte).$h
        },
        {
          "n": "bytesProcessed",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryDecodeFromUtf8",
      "d": 65607,
      "h": 90194378823,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(90194378823),
//--TRIMMABLE-BOUNDARY-START(81604444231),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        },
        {
          "n": "destination",
          "p": $.$$.System.Span$$($.$$.System.Byte).$h
        },
        {
          "n": "charsProcessed",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryDecodeFromUtf16",
      "d": 65607,
      "h": 81604444231,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(81604444231),
//--TRIMMABLE-BOUNDARY-START(94489346119),
    {
      "r": 262145,
      "p": [
        {
          "n": "utf8Source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "destination",
          "p": $.$$.System.Span$$($.$$.System.Byte).$h
        },
        {
          "n": "bytesProcessed",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryDecodeFromUtf8_Scalar",
      "d": 65607,
      "h": 94489346119,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(94489346119),
//--TRIMMABLE-BOUNDARY-START(85899411527),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        },
        {
          "n": "destination",
          "p": $.$$.System.Span$$($.$$.System.Byte).$h
        },
        {
          "n": "charsProcessed",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryDecodeFromUtf16_Scalar",
      "d": 65607,
      "h": 85899411527,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(85899411527),
//--TRIMMABLE-BOUNDARY-START(21474902087),
    {
      "r": 655361,
      "p": [
        {
          "n": "c",
          "p": 655361
        }
      ],
      "n": "FromChar",
      "d": 65607,
      "h": 21474902087,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21474902087),
//--TRIMMABLE-BOUNDARY-START(30064836679),
    {
      "r": 655361,
      "p": [
        {
          "n": "c",
          "p": 655361
        }
      ],
      "n": "FromUpperChar",
      "d": 65607,
      "h": 30064836679,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30064836679),
//--TRIMMABLE-BOUNDARY-START(25769869383),
    {
      "r": 655361,
      "p": [
        {
          "n": "c",
          "p": 655361
        }
      ],
      "n": "FromLowerChar",
      "d": 65607,
      "h": 25769869383,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25769869383),
//--TRIMMABLE-BOUNDARY-START(42949738567),
    {
      "r": 262145,
      "p": [
        {
          "n": "c",
          "p": 655361
        }
      ],
      "n": "IsHexChar",
      "d": 65607,
      "h": 42949738567,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(42949738567),
//--TRIMMABLE-BOUNDARY-START(51539673159),
    {
      "r": 262145,
      "p": [
        {
          "n": "c",
          "p": 655361
        }
      ],
      "n": "IsHexUpperChar",
      "d": 65607,
      "h": 51539673159,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(51539673159),
//--TRIMMABLE-BOUNDARY-START(47244705863),
    {
      "r": 262145,
      "p": [
        {
          "n": "c",
          "p": 655361
        }
      ],
      "n": "IsHexLowerChar",
      "d": 65607,
      "h": 47244705863,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(47244705863)
  ],
  "j": [131143,196679
  ],
  "h": 65607
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.HexConverter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65607)
        
        
        //--TRIMMABLE-BOUNDARY-START(655431)
        $asm.$cls("$swh.System.Web.Util.UriUtil", ($self) => class UriUtil
        {
            //--TRIMMABLE-BOUNDARY-START(4295622727)
            static /*bool */ TrySplitUriForPathEncode(/*string*/ input, /*out ReadOnlySpan<char>*/ schemeAndAuthority, /*out string?*/ path, /*out ReadOnlySpan<char>*/ queryAndFragment)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295622727);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let queryFragmentSeparatorPos = $.$$.System.MemoryExtensions.IndexOfAny$8($.$$.System.Char, $.$$.System.MemoryExtensions.AsSpan$4(input), /*?*/ 63, /*#*/ 35);
                /*string*/ let inputWithoutQueryFragment;
                if (queryFragmentSeparatorPos >= 0)
                {
                    inputWithoutQueryFragment = $.$$.System.String.Substring.call(input, 0, queryFragmentSeparatorPos);
                    queryAndFragment.$v = $.$$.System.MemoryExtensions.AsSpan$2(input, queryFragmentSeparatorPos);
                }
                else 
                {
                    inputWithoutQueryFragment = input;
                    queryAndFragment.$v = $.$$.System.ReadOnlySpan$$($.$$.System.Char).Empty;
                }
                /*Uri?*/ let uri;
                if ($.$spu.System.Uri.TryCreate(inputWithoutQueryFragment, 1/*UriKind.Absolute*/, $.$ref(() => uri, ($v) => uri = $v, $.$spu.System.Uri)))
                {
                    /*string*/ let authority = uri.Authority;
                    if (!$.$$.System.String.IsNullOrEmpty(authority))
                    {
                        /*int*/ let authorityIndex = $.$$.System.String.IndexOf$8.call(inputWithoutQueryFragment, authority, 5/*StringComparison.OrdinalIgnoreCase*/);
                        if (authorityIndex >= 0)
                        {
                            /*int*/ let schemeAndAuthorityLength = ((authorityIndex + authority.length) | 0);
                            schemeAndAuthority.$v = $.$$.System.MemoryExtensions.AsSpan$1(input, 0, schemeAndAuthorityLength);
                            path.$v = $.$$.System.String.Substring$1.call(inputWithoutQueryFragment, schemeAndAuthorityLength);
                            return true;
                        }
                    }
                }
                schemeAndAuthority.$v = $.$$.System.ReadOnlySpan$$($.$$.System.Char).Empty;
                path.$v = null;
                queryAndFragment.$v = $.$$.System.ReadOnlySpan$$($.$$.System.Char).Empty;
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(4295622727)
            
            static $h = 655431;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295622727),
    {
      "r": 262145,
      "p": [
        {
          "n": "input",
          "p": 1310721
        },
        {
          "n": "schemeAndAuthority",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h,
          "f": 2
        },
        {
          "n": "path",
          "p": 1310721,
          "f": 2
        },
        {
          "n": "queryAndFragment",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h,
          "f": 2
        }
      ],
      "n": "TrySplitUriForPathEncode",
      "d": 655431,
      "h": 4295622727,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295622727)
  ],
  "h": 655431
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Web.Util.UriUtil`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655431)
        
        
        //--TRIMMABLE-BOUNDARY-START(262215)
        $asm.$str("$swh.System.Text.ValueStringBuilder", ($self) => class ValueStringBuilder extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(55834837063)
            /*void */ AppendSpanFormattable(T, /*T*/ value, /*string?*/ format, /*IFormatProvider?*/ provider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834837063);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let charsWritten;
                if ($.$dsp(value, T, ($t) => $t.System$ISpanFormattable$TryFormat, this._chars.Slice$1(this._pos), $.$ref(() => charsWritten, ($v) => charsWritten = $v, $.$$.System.Int32), $.$$.System.String.op_Implicit(format), provider))
                {
                    this._pos += charsWritten;
                }
                else 
                {
                    this.Append$3($.$dsp(value, T, ($t) => $t.System$IFormattable$ToString, format, provider));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55834837063)
            
            //--TRIMMABLE-BOUNDARY-START(4295229511)
            /*char[]?*/  get _arrayToReturnToPool() { return this.$getField(0, 4); }
            /*char[]?*/  set _arrayToReturnToPool(value) { this.$setField(0, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(4295229511)
            
            //--TRIMMABLE-BOUNDARY-START(8590196807)
            /*Span<char>*/  get _chars() { return this.$getField(4, 6); }
            /*Span<char>*/  set _chars(value) { this.$setField(4, 6, value); }
            //--TRIMMABLE-BOUNDARY-END(8590196807)
            
            //--TRIMMABLE-BOUNDARY-START(12885164103)
            /*int*/  get _pos() { return this.$getField(10, 4); }
            /*int*/  set _pos(value) { this.$setField(10, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(12885164103)
            
            //--TRIMMABLE-BOUNDARY-START(17180131399)
            $ctor$4(/*Span<char>*/ initialBuffer)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180131399);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._arrayToReturnToPool = null;
                    this._chars = initialBuffer;
                    this._pos = 0;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180131399)
            
            //--TRIMMABLE-BOUNDARY-START(21475098695)
            $ctor$3(/*int*/ initialCapacity)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475098695);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._arrayToReturnToPool = $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared.Rent(initialCapacity);
                    this._chars = $.$$.System.Span$$($.$$.System.Char).op_Implicit$2(this._arrayToReturnToPool);
                    this._pos = 0;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475098695)
            
            //--TRIMMABLE-BOUNDARY-START(150324117575)
            /*int */ get Length()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669411911);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._pos;
            }
            /*int */ set Length(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209019463);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(value >= 0, "value >= 0");
                $.$$.System.Diagnostics.Debug.Assert$2(value <= this._chars.Length, "value <= _chars.Length");
                this._pos = value;
            }
            //--TRIMMABLE-BOUNDARY-END(150324117575)
            
            //--TRIMMABLE-BOUNDARY-START(77309673543)
            /*int */ get Capacity()
            {
                return this._chars.Length;
            }
            //--TRIMMABLE-BOUNDARY-END(77309673543)
            
            //--TRIMMABLE-BOUNDARY-START(85899608135)
            /*void */ EnsureCapacity(/*int*/ capacity)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899608135);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(capacity >= 0, "capacity >= 0");
                if ((capacity >>> 0) > (this._chars.Length >>> 0))
                {
                    this.Grow(((capacity - this._pos) | 0));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(85899608135)
            
            //--TRIMMABLE-BOUNDARY-START(124554313799)
            /*ref char */ GetPinnableReference()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554313799);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.Runtime.InteropServices.MemoryMarshal.GetReference$1($.$$.System.Char, this._chars);
            }
            //--TRIMMABLE-BOUNDARY-END(124554313799)
            
            //--TRIMMABLE-BOUNDARY-START(128849281095)
            /*ref char */ GetPinnableReference$1(/*bool*/ terminate)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849281095);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (terminate)
                {
                    this.EnsureCapacity(((this.Length + 1) | 0));
                    this._chars.get_Item(this.Length).$v = /*\u0000*/ 0;
                }
                return $.$$.System.Runtime.InteropServices.MemoryMarshal.GetReference$1($.$$.System.Char, this._chars);
            }
            //--TRIMMABLE-BOUNDARY-END(128849281095)
            
            //--TRIMMABLE-BOUNDARY-START(167503986759)
            /*ref char*/ get_Item(/*int*/ index)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(index < this._pos, "index < _pos");
                return this._chars.get_Item(index);
            }
            //--TRIMMABLE-BOUNDARY-END(167503986759)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 171798954055, 330712612865)
            static/*conventional*/ /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171798954055);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let s = $.$$.System.Span$$($.$$.System.Char).ToString.call(this._chars.Slice(0, this._pos));
                this.Dispose();
                return s;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$swh.System.Text.ValueStringBuilder.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(ALL, 171798954055, 330712612865)
            
            //--TRIMMABLE-BOUNDARY-START(154619084871)
            /*Span<char> */ get RawChars()
            {
                return this._chars;
            }
            //--TRIMMABLE-BOUNDARY-END(154619084871)
            
            //--TRIMMABLE-BOUNDARY-START(60129804359)
            /*ReadOnlySpan<char> */ AsSpan$1(/*bool*/ terminate)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129804359);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (terminate)
                {
                    this.EnsureCapacity(((this.Length + 1) | 0));
                    this._chars.get_Item(this.Length).$v = /*\u0000*/ 0;
                }
                return $.$$.System.Span$$($.$$.System.Char).op_Implicit(this._chars.Slice(0, this._pos));
            }
            //--TRIMMABLE-BOUNDARY-END(60129804359)
            
            //--TRIMMABLE-BOUNDARY-START(64424771655)
            /*ReadOnlySpan<char> */ AsSpan()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64424771655);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.Span$$($.$$.System.Char).op_Implicit(this._chars.Slice(0, this._pos));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64424771655)
            
            //--TRIMMABLE-BOUNDARY-START(68719738951)
            /*ReadOnlySpan<char> */ AsSpan$3(/*int*/ start)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68719738951);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.Span$$($.$$.System.Char).op_Implicit(this._chars.Slice(start, ((this._pos - start) | 0)));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68719738951)
            
            //--TRIMMABLE-BOUNDARY-START(73014706247)
            /*ReadOnlySpan<char> */ AsSpan$2(/*int*/ start, /*int*/ length)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73014706247);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.Span$$($.$$.System.Char).op_Implicit(this._chars.Slice(start, length));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(73014706247)
            
            //--TRIMMABLE-BOUNDARY-START(176093921351)
            /*bool */ TryCopyTo(/*Span<char>*/ destination, /*out int*/ charsWritten)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176093921351);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._chars.Slice(0, this._pos).TryCopyTo(destination))
                {
                    charsWritten.$v = this._pos;
                    this.Dispose();
                    return true;
                }
                else 
                {
                    charsWritten.$v = 0;
                    this.Dispose();
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(176093921351)
            
            //--TRIMMABLE-BOUNDARY-START(141734182983)
            /*void */ Insert(/*int*/ index, /*char*/ value, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734182983);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._pos > ((this._chars.Length - count) | 0))
                {
                    this.Grow(count);
                }
                /*int*/ let remaining = ((this._pos - index) | 0);
                this._chars.Slice(index, remaining).CopyTo(this._chars.Slice$1(((index + count) | 0)));
                this._chars.Slice(index, count).Fill(value);
                this._pos += count;
            }
            //--TRIMMABLE-BOUNDARY-END(141734182983)
            
            //--TRIMMABLE-BOUNDARY-START(146029150279)
            /*void */ Insert$1(/*int*/ index, /*string?*/ s)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029150279);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.op_Equality(s, null))
                {
                    return;
                }
                /*int*/ let count = s.length;
                if (this._pos > (((this._chars.Length - count) | 0)))
                {
                    this.Grow(count);
                }
                /*int*/ let remaining = ((this._pos - index) | 0);
                this._chars.Slice(index, remaining).CopyTo(this._chars.Slice$1(((index + count) | 0)));
                $.$$.System.String.CopyTo$1.call(s, this._chars.Slice$1(index));
                this._pos += count;
            }
            //--TRIMMABLE-BOUNDARY-END(146029150279)
            
            //--TRIMMABLE-BOUNDARY-START(30065033287)
            /*void */ Append$1(/*char*/ c)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065033287);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let pos = this._pos;
                /*Span<char>*/ let chars = this._chars;
                if ((pos >>> 0) < (chars.Length >>> 0))
                {
                    chars.get_Item(pos).$v = c;
                    this._pos = ((pos + 1) | 0);
                }
                else 
                {
                    this.GrowAndAppend(c);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065033287)
            
            //--TRIMMABLE-BOUNDARY-START(34360000583)
            /*void */ Append$3(/*string?*/ s)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360000583);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.op_Equality(s, null))
                {
                    return;
                }
                /*int*/ let pos = this._pos;
                if (s.length === 1 && (pos >>> 0) < (this._chars.Length >>> 0))
                {
                    this._chars.get_Item(pos).$v = $.$$.System.String.get_Chars.call(s, 0);
                    this._pos = ((pos + 1) | 0);
                }
                else 
                {
                    this.AppendSlow(s);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360000583)
            
            //--TRIMMABLE-BOUNDARY-START(47244902471)
            /*void */ AppendSlow(/*string*/ s)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244902471);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let pos = this._pos;
                if (pos > ((this._chars.Length - s.length) | 0))
                {
                    this.Grow(s.length);
                }
                $.$$.System.String.CopyTo$1.call(s, this._chars.Slice$1(pos));
                this._pos += s.length;
            }
            //--TRIMMABLE-BOUNDARY-END(47244902471)
            
            //--TRIMMABLE-BOUNDARY-START(38654967879)
            /*void */ Append(/*char*/ c, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654967879);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._pos > ((this._chars.Length - count) | 0))
                {
                    this.Grow(count);
                }
                /*Span<char>*/ let dst = this._chars.Slice(this._pos, count);
                for(/*int*/ let i = 0; i < dst.Length; i++)
                {
                    dst.get_Item(i).$v = c;
                }
                this._pos += count;
            }
            //--TRIMMABLE-BOUNDARY-END(38654967879)
            
            //--TRIMMABLE-BOUNDARY-START(42949935175)
            /*void */ Append$2(/*scoped ReadOnlySpan<char>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949935175);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let pos = this._pos;
                if (pos > ((this._chars.Length - value.Length) | 0))
                {
                    this.Grow(value.Length);
                }
                value.CopyTo(this._chars.Slice$1(this._pos));
                this._pos += value.Length;
            }
            //--TRIMMABLE-BOUNDARY-END(42949935175)
            
            //--TRIMMABLE-BOUNDARY-START(51539869767)
            /*Span<char> */ AppendSpan(/*int*/ length)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539869767);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let origPos = this._pos;
                if (origPos > ((this._chars.Length - length) | 0))
                {
                    this.Grow(length);
                }
                this._pos = ((origPos + length) | 0);
                return this._chars.Slice(origPos, length);
            }
            //--TRIMMABLE-BOUNDARY-END(51539869767)
            
            //--TRIMMABLE-BOUNDARY-START(137439215687)
            /*void */ GrowAndAppend(/*char*/ c)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439215687);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Grow(1);
                this.Append$1(c);
            }
            //--TRIMMABLE-BOUNDARY-END(137439215687)
            
            //--TRIMMABLE-BOUNDARY-START(133144248391)
            /*void */ Grow(/*int*/ additionalCapacityBeyondPos)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144248391);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(additionalCapacityBeyondPos > 0, "additionalCapacityBeyondPos > 0");
                $.$$.System.Diagnostics.Debug.Assert$2(this._pos > ((this._chars.Length - additionalCapacityBeyondPos) | 0), "Grow called incorrectly, no resize is needed.");
                /*uint*/ let ArrayMaxLength = 2147483591;
                /*int*/ let newCapacity = ($.$$.System.Math.Max$10(((((this._pos + additionalCapacityBeyondPos) | 0)) >>> 0), $.$$.System.Math.Min$10((((this._chars.Length >>> 0) * 2) >>> 0), ArrayMaxLength)) | 0);
                /*char[]*/ let poolArray = $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared.Rent(newCapacity);
                this._chars.Slice(0, this._pos).CopyTo($.$$.System.Span$$($.$$.System.Char).op_Implicit$2(poolArray));
                /*char[]?*/ let toReturn = this._arrayToReturnToPool;
                this._chars = $.$$.System.Span$$($.$$.System.Char).op_Implicit$2(this._arrayToReturnToPool = poolArray);
                if (toReturn !== null)
                {
                    $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared.Return(toReturn, false);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(133144248391)
            
            //--TRIMMABLE-BOUNDARY-START(81604640839)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604640839);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*char[]?*/ let toReturn = this._arrayToReturnToPool;
                new $.$swh.System.Text.ValueStringBuilder().Clone(this);
                if (toReturn !== null)
                {
                    $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared.Return(toReturn, false);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(81604640839)
            
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._arrayToReturnToPool = this._arrayToReturnToPool;
                copy._chars = this._chars.Clone();
                copy._pos = this._pos;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4295229511)
                this._arrayToReturnToPool = null;
                //--TRIMMABLE-BOUNDARY-END(4295229511)
                
                //--TRIMMABLE-BOUNDARY-START(8590196807)
                this._chars = $.$default($.$$.System.Span$$($.$$.System.Char));
                //--TRIMMABLE-BOUNDARY-END(8590196807)
                
                //--TRIMMABLE-BOUNDARY-START(12885164103)
                this._pos = 0;
                //--TRIMMABLE-BOUNDARY-END(12885164103)
                
            }
            static $h = 262215;
            static $z = 14;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(150324117575),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111669411911,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 163209019463,
        "f": 83886081
      },
      "n": "Length",
      "d": 262215,
      "h": 150324117575,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(150324117575),
//--TRIMMABLE-BOUNDARY-START(77309673543),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94489542727,
        "f": 50331649
      },
      "n": "Capacity",
      "d": 262215,
      "h": 77309673543,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77309673543),
//--TRIMMABLE-BOUNDARY-START(167503986759),
    {
      "p": 458753,
      "i": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 103079477319,
        "f": 50331649
      },
      "n": "Item",
      "o": "@$2",
      "d": 262215,
      "h": 167503986759,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(167503986759),
//--TRIMMABLE-BOUNDARY-START(154619084871),
    {
      "p": $.$$.System.Span$$($.$$.System.Char).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120259346503,
        "f": 50331649
      },
      "n": "RawChars",
      "d": 262215,
      "h": 154619084871,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(154619084871)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(55834837063),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": (T) => T.$h
        },
        {
          "n": "format",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "provider",
          "p": 90308609,
          "f": 65
        }
      ],
      "g": [
        "T"
      ],
      "n": "AppendSpanFormattable",
      "d": 262215,
      "h": 55834837063,
      "f": 16908296
    },
//--TRIMMABLE-BOUNDARY-END(55834837063),
//--TRIMMABLE-BOUNDARY-START(85899608135),
    {
      "r": 65537,
      "p": [
        {
          "n": "capacity",
          "p": 655361
        }
      ],
      "n": "EnsureCapacity",
      "d": 262215,
      "h": 85899608135,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85899608135),
//--TRIMMABLE-BOUNDARY-START(124554313799),
    {
      "r": 458753,
      "n": "GetPinnableReference",
      "d": 262215,
      "h": 124554313799,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(124554313799),
//--TRIMMABLE-BOUNDARY-START(128849281095),
    {
      "r": 458753,
      "p": [
        {
          "n": "terminate",
          "p": 262145
        }
      ],
      "n": "GetPinnableReference",
      "o": "@$1",
      "d": 262215,
      "h": 128849281095,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(128849281095),
//--TRIMMABLE-BOUNDARY-START(ALL, 171798954055, 330712612865),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 262215,
      "h": 171798954055,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 171798954055, 330712612865),
//--TRIMMABLE-BOUNDARY-START(60129804359),
    {
      "r": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h,
      "p": [
        {
          "n": "terminate",
          "p": 262145
        }
      ],
      "n": "AsSpan",
      "o": "@$1",
      "d": 262215,
      "h": 60129804359,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60129804359),
//--TRIMMABLE-BOUNDARY-START(64424771655),
    {
      "r": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h,
      "n": "AsSpan",
      "d": 262215,
      "h": 64424771655,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64424771655),
//--TRIMMABLE-BOUNDARY-START(68719738951),
    {
      "r": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h,
      "p": [
        {
          "n": "start",
          "p": 655361
        }
      ],
      "n": "AsSpan",
      "o": "@$3",
      "d": 262215,
      "h": 68719738951,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68719738951),
//--TRIMMABLE-BOUNDARY-START(73014706247),
    {
      "r": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h,
      "p": [
        {
          "n": "start",
          "p": 655361
        },
        {
          "n": "length",
          "p": 655361
        }
      ],
      "n": "AsSpan",
      "o": "@$2",
      "d": 262215,
      "h": 73014706247,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73014706247),
//--TRIMMABLE-BOUNDARY-START(176093921351),
    {
      "r": 262145,
      "p": [
        {
          "n": "destination",
          "p": $.$$.System.Span$$($.$$.System.Char).$h
        },
        {
          "n": "charsWritten",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryCopyTo",
      "d": 262215,
      "h": 176093921351,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(176093921351),
//--TRIMMABLE-BOUNDARY-START(141734182983),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "value",
          "p": 458753
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Insert",
      "d": 262215,
      "h": 141734182983,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(141734182983),
//--TRIMMABLE-BOUNDARY-START(146029150279),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "s",
          "p": 1310721
        }
      ],
      "n": "Insert",
      "o": "@$1",
      "d": 262215,
      "h": 146029150279,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(146029150279),
//--TRIMMABLE-BOUNDARY-START(30065033287),
    {
      "r": 65537,
      "p": [
        {
          "n": "c",
          "p": 458753
        }
      ],
      "n": "Append",
      "o": "@$1",
      "d": 262215,
      "h": 30065033287,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065033287),
//--TRIMMABLE-BOUNDARY-START(34360000583),
    {
      "r": 65537,
      "p": [
        {
          "n": "s",
          "p": 1310721
        }
      ],
      "n": "Append",
      "o": "@$3",
      "d": 262215,
      "h": 34360000583,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360000583),
//--TRIMMABLE-BOUNDARY-START(47244902471),
    {
      "r": 65537,
      "p": [
        {
          "n": "s",
          "p": 1310721
        }
      ],
      "n": "AppendSlow",
      "d": 262215,
      "h": 47244902471,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(47244902471),
//--TRIMMABLE-BOUNDARY-START(38654967879),
    {
      "r": 65537,
      "p": [
        {
          "n": "c",
          "p": 458753
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Append",
      "d": 262215,
      "h": 38654967879,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38654967879),
//--TRIMMABLE-BOUNDARY-START(42949935175),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        }
      ],
      "n": "Append",
      "o": "@$2",
      "d": 262215,
      "h": 42949935175,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42949935175),
//--TRIMMABLE-BOUNDARY-START(51539869767),
    {
      "r": $.$$.System.Span$$($.$$.System.Char).$h,
      "p": [
        {
          "n": "length",
          "p": 655361
        }
      ],
      "n": "AppendSpan",
      "d": 262215,
      "h": 51539869767,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51539869767),
//--TRIMMABLE-BOUNDARY-START(137439215687),
    {
      "r": 65537,
      "p": [
        {
          "n": "c",
          "p": 458753
        }
      ],
      "n": "GrowAndAppend",
      "d": 262215,
      "h": 137439215687,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(137439215687),
//--TRIMMABLE-BOUNDARY-START(133144248391),
    {
      "r": 65537,
      "p": [
        {
          "n": "additionalCapacityBeyondPos",
          "p": 655361
        }
      ],
      "n": "Grow",
      "d": 262215,
      "h": 133144248391,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(133144248391),
//--TRIMMABLE-BOUNDARY-START(81604640839),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 262215,
      "h": 81604640839,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(81604640839)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295229511),
    {
      "t": $.$typeArray($.$$.System.Char).$h,
      "n": "_arrayToReturnToPool",
      "d": 262215,
      "h": 4295229511,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295229511),
//--TRIMMABLE-BOUNDARY-START(8590196807),
    {
      "t": $.$$.System.Span$$($.$$.System.Char).$h,
      "n": "_chars",
      "d": 262215,
      "h": 8590196807,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590196807),
//--TRIMMABLE-BOUNDARY-START(12885164103),
    {
      "t": 655361,
      "n": "_pos",
      "d": 262215,
      "h": 12885164103,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885164103)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180131399),
    {
      "p": [
        {
          "n": "initialBuffer",
          "p": $.$$.System.Span$$($.$$.System.Char).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 262215,
      "h": 17180131399,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180131399),
//--TRIMMABLE-BOUNDARY-START(21475098695),
    {
      "p": [
        {
          "n": "initialCapacity",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 262215,
      "h": 21475098695,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475098695),
//--TRIMMABLE-BOUNDARY-START(25770065991),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 262215,
      "h": 25770065991,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770065991)
  ],
  "h": 262215
}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.Text.ValueStringBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262215)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Threading", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized"))
//--TRIMMABLE-BOUNDARY-END(71)
