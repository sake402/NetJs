
(function ($global, $, $spc, $sc, $sm, $spu, $sr, $st, $scn, $scm, $so, $scp, $scs) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Web.HttpUtility", 
    {"h":58008,"f":"System.Web.HttpUtility","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bf7a34a6f78fee11131301a9f55ca16a968616013","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Web.HttpUtility","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Web.HttpUtility","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$swh.System.Web.IHtmlString", ($self) => class IHtmlString
        {
            static $h = 516760;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":1310721,"n":"ToHtmlString","o":"System$Web$IHtmlString$ToHtmlString","d":516760,"h":4295484056,"f":257}],"h":516760}; }
            static get $fullName() { return `System.Web.IHtmlString`; }
        });
        
        $asm.$cls("$swh.System.Web.Util.UriUtil", ($self) => class UriUtil
        {
            static /*bool */ TrySplitUriForPathEncode(/*string*/ input, /*out ReadOnlySpan<char>*/ schemeAndAuthority, /*out string?*/ path, /*out ReadOnlySpan<char>*/ queryAndFragment)
            {
                /*int*/ let queryFragmentSeparatorPos = $.$spc.System.MemoryExtensions.IndexOfAny$5($.$spc.System.Char, $.$spc.System.MemoryExtensions.AsSpan$3(input), /*?*/ 63, /*#*/ 35);
                /*string*/ let inputWithoutQueryFragment;
                if (queryFragmentSeparatorPos >= 0)
                {
                    inputWithoutQueryFragment = $.$spc.System.String.Substring$1.call(input, 0, queryFragmentSeparatorPos);
                    queryAndFragment.$v = $.$spc.System.MemoryExtensions.AsSpan$4(input, queryFragmentSeparatorPos);
                }
                else 
                {
                    inputWithoutQueryFragment = input;
                    queryAndFragment.$v = $.$spc.System.ReadOnlySpan$$($.$spc.System.Char).Empty;
                }
                /*Uri?*/ let uri;
                if ($.$spu.System.Uri.TryCreate(inputWithoutQueryFragment, 1/*UriKind.Absolute*/, $.$ref(() => uri, ($v) => uri = $v, $.$spu.System.Uri)))
                {
                    /*string*/ let authority = uri.Authority;
                    if (!$.$spc.System.String.IsNullOrEmpty(authority))
                    {
                        /*int*/ let authorityIndex = $.$spc.System.String.IndexOf$7.call(inputWithoutQueryFragment, authority, 5/*StringComparison.OrdinalIgnoreCase*/);
                        if (authorityIndex >= 0)
                        {
                            /*int*/ let schemeAndAuthorityLength = ((authorityIndex + authority.length) | 0);
                            schemeAndAuthority.$v = $.$spc.System.MemoryExtensions.AsSpan$7(input, 0, schemeAndAuthorityLength);
                            path.$v = $.$spc.System.String.Substring.call(inputWithoutQueryFragment, schemeAndAuthorityLength);
                            return true;
                        }
                    }
                }
                schemeAndAuthority.$v = $.$spc.System.ReadOnlySpan$$($.$spc.System.Char).Empty;
                path.$v = null;
                queryAndFragment.$v = $.$spc.System.ReadOnlySpan$$($.$spc.System.Char).Empty;
                return false;
            }
            static $h = 713368;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"input","p":1310721},{"n":"schemeAndAuthority","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h,"f":2},{"n":"path","p":1310721,"f":2},{"n":"queryAndFragment","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h,"f":2}],"n":"TrySplitUriForPathEncode","d":713368,"h":4295680664,"f":40}],"h":713368}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Web.Util.UriUtil`; }
        });
        
        $asm.$cls("$swh.System.HexConverter", ($self) => class HexConverter
        {
            static $_Casing;
            static get Casing()
            {
                let $cls = $.$swh.System.HexConverter;
                return $cls.$_Casing ??= $asm.$nstr("$swh.System.HexConverter.Casing", ($self) => class Casing extends $.$spc.System.Enum
                {
                    static Upper = 0;
                    static Lower = 8224;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "Upper": 0n,
                            "Lower": 8224n
                        };
                    }
                    static $h = 189080;
                    static $z = 4;
                    static $f = 0b110000011010001001;
                    static $k = 4;
                    static get $eut() { return $.$spc.System.UInt32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":720897,"l":[{"t":189080,"n":"Upper","d":189080,"h":4295156376,"f":33},{"t":189080,"n":"Lower","d":189080,"h":8590123672,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":189080,"h":12885090968,"f":1}],"i":[57278465,63832065,57737217,57409537],"d":123544,"h":189080}; }
                    static get $b() { return $.$spc.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                    static get $fullName() { return `System.HexConverter.Casing`; }
                }, $cls, ($v) => $cls.$_Casing = $v);
            }
            static /*void */ ToBytesBuffer(/*byte*/ value, /*Span<byte>*/ buffer, /*int*/ startingIndex, /*Casing*/ casing)
            {
                /*uint*/ let difference = (((((((value & 240) << 4) >>> 0) + (value & 15)) >>> 0) - 35209) >>> 0);
                /*uint*/ let packedResult = (((((((((-(difference | 0)) >>> 0) & 28784) >>> 4) + difference) >>> 0) + 47545) >>> 0)) | casing;
                buffer.get_Item(((startingIndex + 1) | 0)).$v = $.$cast(packedResult, $.$spc.System.Byte);
                buffer.get_Item(startingIndex).$v = $.$cast((packedResult >>> 8), $.$spc.System.Byte);
            }
            static /*void */ ToCharsBuffer(/*byte*/ value, /*Span<char>*/ buffer, /*int*/ startingIndex, /*Casing*/ casing)
            {
                /*uint*/ let difference = (((((((value & 240) << 4) >>> 0) + (value & 15)) >>> 0) - 35209) >>> 0);
                /*uint*/ let packedResult = (((((((((-(difference | 0)) >>> 0) & 28784) >>> 4) + difference) >>> 0) + 47545) >>> 0)) | casing;
                buffer.get_Item(((startingIndex + 1) | 0)).$v = $.$cast((packedResult & 255), $.$spc.System.Char);
                buffer.get_Item(startingIndex).$v = $.$cast((packedResult >>> 8), $.$spc.System.Char);
            }
            static /*void */ EncodeToUtf8(/*ReadOnlySpan<byte>*/ source, /*Span<byte>*/ utf8Destination, /*Casing*/ casing)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(utf8Destination.Length >= (((source.Length * 2) | 0)), "utf8Destination.Length >= (source.Length * 2)");
                for(/*int*/ let pos = 0; pos < source.Length; pos++)
                {
                    $.$swh.System.HexConverter.ToBytesBuffer(source.get_Item(pos).$v, utf8Destination, ((pos * 2) | 0), casing);
                }
            }
            static /*void */ EncodeToUtf16(/*ReadOnlySpan<byte>*/ source, /*Span<char>*/ destination, /*Casing*/ casing)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(destination.Length >= (((source.Length * 2) | 0)), "destination.Length >= (source.Length * 2)");
                for(/*int*/ let pos = 0; pos < source.Length; pos++)
                {
                    $.$swh.System.HexConverter.ToCharsBuffer(source.get_Item(pos).$v, destination, ((pos * 2) | 0), casing);
                }
            }
            static /*string */ ToString$1(/*ReadOnlySpan<byte>*/ bytes, /*Casing*/ casing)
            {
                /*SpanCasingPair*/ let args = (() =>
                {
                    //new $.$swh.System.HexConverter.SpanCasingPair()
                    const $t1 = $.$swh.System.HexConverter.SpanCasingPair;
                    const $i1 = new $t1();
                    $i1.Bytes = bytes;
                    $i1.Casing = casing;
                    return $i1;
                })();
                return $.$spc.System.String.Create$8($.$swh.System.HexConverter.SpanCasingPair, ((bytes.Length * 2) | 0), args.Clone(), new ($.$spc.System.Buffers.SpanAction$$$($.$spc.System.Char, $.$swh.System.HexConverter.SpanCasingPair))().$ctor($.$swh.System.HexConverter, /*static*/ (/*chars*/ chars, /*args*/ args) =>
                {
                    return $.$swh.System.HexConverter.EncodeToUtf16(args.Bytes, chars, args.Casing);
                }, {"r":65537,"p":[{"n":"chars","p":$.$spc.System.Span$$($.$spc.System.Char).$h},{"n":"args","p":254616}],"n":"","d":123544,"h":0,"f":1048610}));
            }
            static $_SpanCasingPair;
            static get SpanCasingPair()
            {
                let $cls = $.$swh.System.HexConverter;
                return $cls.$_SpanCasingPair ??= $asm.$nstr("$swh.System.HexConverter.SpanCasingPair", ($self) => class SpanCasingPair extends $.$spc.System.ValueType
                {
                    /*ReadOnlySpan<byte>*/ Bytes;
                    /*Casing*/ Casing = 0;
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Bytes = this.Bytes.Clone();
                        copy.Casing = this.Casing;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.Bytes = $.$default($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte));
                        this.Casing = 0;
                    }
                    static $h = 254616;
                    static $z = 9;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":12885156504,"f":1},"s":{"r":0,"d":0,"h":17180123800,"f":1},"n":"Bytes","d":254616,"h":8590189208,"f":1},{"p":189080,"g":{"r":0,"d":0,"h":30065025688,"f":1},"s":{"r":0,"d":0,"h":34359992984,"f":1},"n":"Casing","d":254616,"h":25770058392,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":254616,"h":38654960280,"f":1}],"d":123544,"h":254616}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `System.HexConverter.SpanCasingPair`; }
                }, $cls, ($v) => $cls.$_SpanCasingPair = $v);
            }
            static /*char */ ToCharUpper(/*int*/ value)
            {
                value &= 15;
                value += /*0*/ 48;
                if (value > /*9*/ 57)
                {
                    value += (((/*A*/ 65 - (((/*9*/ 57 + 1) | 0))) | 0));
                }
                return $.$cast(value, $.$spc.System.Char);
            }
            static /*char */ ToCharLower(/*int*/ value)
            {
                value &= 15;
                value += /*0*/ 48;
                if (value > /*9*/ 57)
                {
                    value += (((/*a*/ 97 - (((/*9*/ 57 + 1) | 0))) | 0));
                }
                return $.$cast(value, $.$spc.System.Char);
            }
            static /*bool */ TryDecodeFromUtf8(/*ReadOnlySpan<byte>*/ utf8Source, /*Span<byte>*/ destination, /*out int*/ bytesProcessed)
            {
                return $.$swh.System.HexConverter.TryDecodeFromUtf8_Scalar(utf8Source, destination, bytesProcessed);
            }
            static /*bool */ TryDecodeFromUtf16(/*ReadOnlySpan<char>*/ source, /*Span<byte>*/ destination, /*out int*/ charsProcessed)
            {
                return $.$swh.System.HexConverter.TryDecodeFromUtf16_Scalar(source, destination, charsProcessed);
            }
            static /*bool */ TryDecodeFromUtf8_Scalar(/*ReadOnlySpan<byte>*/ utf8Source, /*Span<byte>*/ destination, /*out int*/ bytesProcessed)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1((utf8Source.Length % 2) === 0, "Un-even number of characters provided");
                $.$spc.System.Diagnostics.Debug.Assert$1(($.trunc(utf8Source.Length / 2)) === destination.Length, "Target buffer not right-sized for provided characters");
                /*int*/ let i = 0;
                /*int*/ let j = 0;
                /*int*/ let byteLo = 0;
                /*int*/ let byteHi = 0;
                while(j < destination.Length)
                {
                    byteLo = $.$swh.System.HexConverter.FromChar(utf8Source.get_Item(((i + 1) | 0)).$v);
                    byteHi = $.$swh.System.HexConverter.FromChar(utf8Source.get_Item(i).$v);
                    if ((byteLo | byteHi) === 255)
                    {
                        break;
                    }
                    destination.get_Item(j++).$v = $.$cast(((byteHi << 4) | byteLo), $.$spc.System.Byte);
                    i += 2;
                }
                if (byteLo === 255)
                {
                    i++;
                }
                bytesProcessed.$v = i;
                return (byteLo | byteHi) !== 255;
            }
            static /*bool */ TryDecodeFromUtf16_Scalar(/*ReadOnlySpan<char>*/ source, /*Span<byte>*/ destination, /*out int*/ charsProcessed)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1((source.Length % 2) === 0, "Un-even number of characters provided");
                $.$spc.System.Diagnostics.Debug.Assert$1(($.trunc(source.Length / 2)) === destination.Length, "Target buffer not right-sized for provided characters");
                /*int*/ let i = 0;
                /*int*/ let j = 0;
                /*int*/ let byteLo = 0;
                /*int*/ let byteHi = 0;
                while(j < destination.Length)
                {
                    byteLo = $.$swh.System.HexConverter.FromChar(source.get_Item(((i + 1) | 0)).$v);
                    byteHi = $.$swh.System.HexConverter.FromChar(source.get_Item(i).$v);
                    if ((byteLo | byteHi) === 255)
                    {
                        break;
                    }
                    destination.get_Item(j++).$v = $.$cast(((byteHi << 4) | byteLo), $.$spc.System.Byte);
                    i += 2;
                }
                if (byteLo === 255)
                {
                    i++;
                }
                charsProcessed.$v = i;
                return (byteLo | byteHi) !== 255;
            }
            static /*int */ FromChar(/*int*/ c)
            {
                return (c >= $.$swh.System.HexConverter.CharToHexLookup.Length) ? 255 : $.$swh.System.HexConverter.CharToHexLookup.get_Item(c).$v;
            }
            static /*int */ FromUpperChar(/*int*/ c)
            {
                return (c > 71) ? 255 : $.$swh.System.HexConverter.CharToHexLookup.get_Item(c).$v;
            }
            static /*int */ FromLowerChar(/*int*/ c)
            {
                if (((((c - /*0*/ 48) | 0)) >>> 0) <= (/*9*/ 57 - /*0*/ 48))
                {
                    return ((c - /*0*/ 48) | 0);
                }
                if (((((c - /*a*/ 97) | 0)) >>> 0) <= (/*f*/ 102 - /*a*/ 97))
                {
                    return ((((c - /*a*/ 97) | 0) + 10) | 0);
                }
                return 255;
            }
            static /*bool */ IsHexChar(/*int*/ c)
            {
                //if (IntPtr.Size == 8) { ... }
                return $.$swh.System.HexConverter.FromChar(c) !== 255;
            }
            static /*bool */ IsHexUpperChar(/*int*/ c)
            {
                return (((((c - /*0*/ 48) | 0)) >>> 0) <= 9) || (((((c - /*A*/ 65) | 0)) >>> 0) <= (/*F*/ 70 - /*A*/ 65));
            }
            static /*bool */ IsHexLowerChar(/*int*/ c)
            {
                return (((((c - /*0*/ 48) | 0)) >>> 0) <= 9) || (((((c - /*a*/ 97) | 0)) >>> 0) <= (/*f*/ 102 - /*a*/ 97));
            }
            static /*ReadOnlySpan<byte> */ get CharToHexLookup()
            {
                return this.$cacheCharToHexLookup ??= new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$2([ 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 255, 255, 255, 255, 255, 255, 255, 10, 11, 12, 13, 14, 15, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 10, 11, 12, 13, 14, 15, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255 ]);
            }
            static $h = 123544;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":90194436760,"f":33},"n":"CharToHexLookup","d":123544,"h":85899469464,"f":33}],"m":[{"r":65537,"p":[{"n":"value","p":393217},{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"startingIndex","p":655361,"f":65,"v":0},{"n":"casing","p":189080,"f":65,"v":0}],"n":"ToBytesBuffer","d":123544,"h":8590058136,"f":33},{"r":65537,"p":[{"n":"value","p":393217},{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Char).$h},{"n":"startingIndex","p":655361,"f":65,"v":0},{"n":"casing","p":189080,"f":65,"v":0}],"n":"ToCharsBuffer","d":123544,"h":12885025432,"f":33},{"r":65537,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"utf8Destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"casing","p":189080,"f":65,"v":0}],"n":"EncodeToUtf8","d":123544,"h":17179992728,"f":33},{"r":65537,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Char).$h},{"n":"casing","p":189080,"f":65,"v":0}],"n":"EncodeToUtf16","d":123544,"h":21474960024,"f":33},{"r":1310721,"p":[{"n":"bytes","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"casing","p":189080,"f":65,"v":0}],"n":"ToString","o":"@$1","d":123544,"h":25769927320,"f":33},{"r":458753,"p":[{"n":"value","p":655361}],"n":"ToCharUpper","d":123544,"h":34359861912,"f":33},{"r":458753,"p":[{"n":"value","p":655361}],"n":"ToCharLower","d":123544,"h":38654829208,"f":33},{"r":262145,"p":[{"n":"utf8Source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"bytesProcessed","p":655361,"f":2}],"n":"TryDecodeFromUtf8","d":123544,"h":42949796504,"f":33},{"r":262145,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"charsProcessed","p":655361,"f":2}],"n":"TryDecodeFromUtf16","d":123544,"h":47244763800,"f":33},{"r":262145,"p":[{"n":"utf8Source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"bytesProcessed","p":655361,"f":2}],"n":"TryDecodeFromUtf8_Scalar","d":123544,"h":51539731096,"f":34},{"r":262145,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"charsProcessed","p":655361,"f":2}],"n":"TryDecodeFromUtf16_Scalar","d":123544,"h":55834698392,"f":34},{"r":655361,"p":[{"n":"c","p":655361}],"n":"FromChar","d":123544,"h":60129665688,"f":33},{"r":655361,"p":[{"n":"c","p":655361}],"n":"FromUpperChar","d":123544,"h":64424632984,"f":33},{"r":655361,"p":[{"n":"c","p":655361}],"n":"FromLowerChar","d":123544,"h":68719600280,"f":33},{"r":262145,"p":[{"n":"c","p":655361}],"n":"IsHexChar","d":123544,"h":73014567576,"f":33},{"r":262145,"p":[{"n":"c","p":655361}],"n":"IsHexUpperChar","d":123544,"h":77309534872,"f":33},{"r":262145,"p":[{"n":"c","p":655361}],"n":"IsHexLowerChar","d":123544,"h":81604502168,"f":33}],"j":[189080,254616],"h":123544}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.HexConverter`; }
        });
        
        $asm.$cls("$swh.System.Web.HttpUtility", ($self) => class HttpUtility extends $.$spc.System.Object
        {
            static $_HttpQSCollection;
            static get HttpQSCollection()
            {
                let $cls = $.$swh.System.Web.HttpUtility;
                return $cls.$_HttpQSCollection ??= $asm.$ncls("$swh.System.Web.HttpUtility.HttpQSCollection", ($self) => class HttpQSCollection extends $.$scs.System.Collections.Specialized.NameValueCollection
                {
                    $ctor$17()
                    {
                        super.$ctor$12($.$spc.System.StringComparer.OrdinalIgnoreCase);
                        {
                        }
                        return this;
                    }
                    static/*conventional*/ /*string */ ToString()
                    {
                        /*int*/ let count = this.Count;
                        if (count === 0)
                        {
                            return "";
                        }
                        /*StringBuilder*/ let sb = new $.$spc.System.Text.StringBuilder().$ctor$1();
                        /*string?[]*/ let keys = this.AllKeys;
                        for(/*int*/ let i = 0; i < count; i++)
                        {
                            /*string?*/ let key = $.$spc.System.Array.$ReadT1.call(keys, i);
                            /*string[]?*/ let values = this.GetValues(key);
                            if (values !== null)
                            {
                                let $i1 = 0;
                                let $arr1 = values;
                                while ($i1 < $arr1.length)
                                {
                                    let value = $arr1[$i1++];
                                    if (!$.$spc.System.String.IsNullOrEmpty(key))
                                    {
                                        sb.Append$2($.$swh.System.Web.HttpUtility.UrlEncode(key)).Append$7(/*=*/ 61);
                                    }
                                    sb.Append$2($.$swh.System.Web.HttpUtility.UrlEncode(value)).Append$7(/*&*/ 38);
                                }
                            }
                        }
                        return sb.Length > 0 ? sb.ToString$1(0, ((sb.Length - 1) | 0)) : "";
                    }
                    //Static convention instance redirect
                    /*string */ ToString() { return $.$swh.System.Web.HttpUtility.HttpQSCollection.ToString.apply(this, arguments); }
                    static $h = 451224;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":983076,"m":[{"r":1310721,"n":"ToString","d":451224,"h":8590385816,"f":32769}],"c":[{"n":".ctor","o":"$ctor$17","d":451224,"h":4295418520,"f":8}],"i":[31391745,31653889,113377281,113115137],"d":385688,"h":451224}; }
                    static get $b() { return $.$scs.System.Collections.Specialized.NameValueCollection; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable, $.$spc.System.Runtime.Serialization.ISerializable, $.$spc.System.Runtime.Serialization.IDeserializationCallback ]; }
                    static get $fullName() { return `System.Web.HttpUtility.HttpQSCollection`; }
                }, $cls, ($v) => $cls.$_HttpQSCollection = $v);
            }
            static /*NameValueCollection */ ParseQueryString(/*string*/ query)
            {
                return $.$swh.System.Web.HttpUtility.ParseQueryString$1(query, $.$spc.System.Text.Encoding.UTF8);
            }
            static /*NameValueCollection */ ParseQueryString$1(/*string*/ query, /*Encoding*/ encoding)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(query, "query");
                $.$spc.System.ArgumentNullException.ThrowIfNull(encoding, "encoding");
                /*HttpQSCollection*/ let result = new $.$swh.System.Web.HttpUtility.HttpQSCollection().$ctor$17();
                /*int*/ let queryLength = query.length;
                /*int*/ let namePos = $.$spc.System.String.StartsWith$3.call(query, /*?*/ 63) ? 1 : 0;
                if (queryLength === namePos)
                {
                    return result;
                }
                while(namePos <= queryLength)
                {
                    /*int*/ let valuePos = -1, valueEnd = -1;
                    for(/*int*/ let q = namePos; q < queryLength; q++)
                    {
                        if (valuePos === -1 && $.$spc.System.String.get_Chars.call(query, q) === /*=*/ 61)
                        {
                            valuePos = ((q + 1) | 0);
                        }
                        else if ($.$spc.System.String.get_Chars.call(query, q) === /*&*/ 38)
                        {
                            valueEnd = q;
                            break;
                        }
                    }
                    /*string?*/ let name;
                    if (valuePos === -1)
                    {
                        name = null;
                        valuePos = namePos;
                    }
                    else 
                    {
                        name = $.$swh.System.Web.HttpUtility.UrlDecode$3($.$spc.System.MemoryExtensions.AsSpan$7(query, namePos, ((((valuePos - namePos) | 0) - 1) | 0)), encoding);
                    }
                    if (valueEnd < 0)
                    {
                        valueEnd = query.length;
                    }
                    namePos = ((valueEnd + 1) | 0);
                    /*string*/ let value = $.$swh.System.Web.HttpUtility.UrlDecode$3($.$spc.System.MemoryExtensions.AsSpan$7(query, valuePos, ((valueEnd - valuePos) | 0)), encoding);
                    result.Add$1(name, value);
                }
                return result;
            }
            static /*string? */ HtmlDecode(/*string?*/ s)
            {
                return $.$swh.System.Web.Util.HttpEncoder.HtmlDecode(s);
            }
            static /*void */ HtmlDecode$1(/*string?*/ s, /*TextWriter*/ output)
            {
                return $.$swh.System.Web.Util.HttpEncoder.HtmlDecode$1(s, output);
            }
            static /*string? */ HtmlEncode(/*string?*/ s)
            {
                return $.$swh.System.Web.Util.HttpEncoder.HtmlEncode(s);
            }
            static /*string? */ HtmlEncode$1(/*object?*/ value)
            {
                return (() =>
                {
                    if (value === null)
                    {
                        return null;
                    }
                    {
                        let ihs;
                        if ((ihs = value, $.$is(ihs, $.$swh.System.Web.IHtmlString)))
                        {
                            return ihs.System$Web$IHtmlString$ToHtmlString() ?? $.$spc.System.String.Empty;
                        }
                    }
                    return $.$swh.System.Web.HttpUtility.HtmlEncode($.$spc.System.Convert.ToString$2(value, $.$spc.System.Globalization.CultureInfo.CurrentCulture) ?? $.$spc.System.String.Empty);
                })();
            }
            static /*void */ HtmlEncode$2(/*string?*/ s, /*TextWriter*/ output)
            {
                return $.$swh.System.Web.Util.HttpEncoder.HtmlEncode$1(s, output);
            }
            static /*string? */ HtmlAttributeEncode(/*string?*/ s)
            {
                return $.$swh.System.Web.Util.HttpEncoder.HtmlAttributeEncode(s);
            }
            static /*void */ HtmlAttributeEncode$1(/*string?*/ s, /*TextWriter*/ output)
            {
                return $.$swh.System.Web.Util.HttpEncoder.HtmlAttributeEncode$1(s, output);
            }
            static /*string? */ UrlEncode(/*string?*/ str)
            {
                return $.$swh.System.Web.HttpUtility.UrlEncode$1(str, $.$spc.System.Text.Encoding.UTF8);
            }
            static /*string? */ UrlPathEncode(/*string?*/ str)
            {
                return $.$swh.System.Web.Util.HttpEncoder.UrlPathEncode(str);
            }
            static /*string? */ UrlEncode$1(/*string?*/ str, /*Encoding*/ e)
            {
                return $.$spc.System.String.op_Equality(str, null) ? null : $.$spc.System.Text.Encoding.ASCII.GetString$2($.$swh.System.Web.HttpUtility.UrlEncodeToBytes$2(str, e));
            }
            static /*string? */ UrlEncode$2(/*byte[]?*/ bytes)
            {
                return bytes === null ? null : $.$spc.System.Text.Encoding.ASCII.GetString$2($.$swh.System.Web.HttpUtility.UrlEncodeToBytes$1(bytes));
            }
            static /*string? */ UrlEncode$3(/*byte[]?*/ bytes, /*int*/ offset, /*int*/ count)
            {
                return bytes === null ? null : $.$spc.System.Text.Encoding.ASCII.GetString$2($.$swh.System.Web.HttpUtility.UrlEncodeToBytes$3(bytes, offset, count));
            }
            static /*byte[]? */ UrlEncodeToBytes(/*string?*/ str)
            {
                return $.$swh.System.Web.HttpUtility.UrlEncodeToBytes$2(str, $.$spc.System.Text.Encoding.UTF8);
            }
            static /*byte[]? */ UrlEncodeToBytes$1(/*byte[]?*/ bytes)
            {
                return bytes === null ? null : $.$swh.System.Web.HttpUtility.UrlEncodeToBytes$3(bytes, 0, bytes.length);
            }
            static /*byte[]? */ UrlEncodeUnicodeToBytes(/*string?*/ str)
            {
                return $.$spc.System.String.op_Equality(str, null) ? null : $.$spc.System.Text.Encoding.ASCII.GetBytes$3($.$swh.System.Web.HttpUtility.UrlEncodeUnicode(str));
            }
            static /*string? */ UrlDecode(/*string?*/ str)
            {
                return $.$swh.System.Web.HttpUtility.UrlDecode$2(str, $.$spc.System.Text.Encoding.UTF8);
            }
            static /*string? */ UrlDecode$1(/*byte[]?*/ bytes, /*Encoding*/ e)
            {
                return bytes === null ? null : $.$swh.System.Web.HttpUtility.UrlDecode$4(bytes, 0, bytes.length, e);
            }
            static /*byte[]? */ UrlDecodeToBytes(/*string?*/ str)
            {
                return $.$swh.System.Web.HttpUtility.UrlDecodeToBytes$1(str, $.$spc.System.Text.Encoding.UTF8);
            }
            static /*byte[]? */ UrlDecodeToBytes$1(/*string?*/ str, /*Encoding*/ e)
            {
                /*int*/ let StackallocThreshold = 512;
                if ($.$spc.System.String.op_Equality(str, null))
                {
                    return null;
                }
                if (e.GetMaxByteCount(str.length) <= StackallocThreshold)
                {
                    /*Span<byte>*/ let bytes = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, StackallocThreshold, null);
                    /*int*/ let encodedBytes = e.GetBytes$7($.$spc.System.String.op_Implicit(str), bytes);
                    return $.$swh.System.Web.Util.HttpEncoder.UrlDecode$1($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2(bytes.Slice$1(0, encodedBytes)));
                }
                return $.$swh.System.Web.HttpUtility.UrlDecodeToBytes$2(e.GetBytes$3(str));
            }
            static /*byte[]? */ UrlDecodeToBytes$2(/*byte[]?*/ bytes)
            {
                return bytes === null ? null : $.$swh.System.Web.Util.HttpEncoder.UrlDecode$1($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).op_Implicit(bytes));
            }
            static /*byte[]? */ UrlEncodeToBytes$2(/*string?*/ str, /*Encoding*/ e)
            {
                return $.$spc.System.String.op_Equality(str, null) ? null : $.$swh.System.Web.Util.HttpEncoder.UrlEncode$3(str, e);
            }
            static /*byte[]? */ UrlEncodeToBytes$3(/*byte[]?*/ bytes, /*int*/ offset, /*int*/ count)
            {
                return $.$swh.System.Web.Util.HttpEncoder.UrlEncode(bytes, offset, count);
            }
            static /*string? */ UrlEncodeUnicode(/*string?*/ str)
            {
                return $.$swh.System.Web.Util.HttpEncoder.UrlEncodeUnicode(str);
            }
            static /*string? */ UrlDecode$2(/*string?*/ str, /*Encoding*/ e)
            {
                return $.$swh.System.Web.Util.HttpEncoder.UrlDecode$3(str, e);
            }
            static /*string */ UrlDecode$3(/*ReadOnlySpan<char>*/ str, /*Encoding*/ e)
            {
                return $.$swh.System.Web.Util.HttpEncoder.UrlDecode$4(str, e);
            }
            static /*string? */ UrlDecode$4(/*byte[]?*/ bytes, /*int*/ offset, /*int*/ count, /*Encoding*/ e)
            {
                return $.$swh.System.Web.Util.HttpEncoder.UrlDecode$2(bytes, offset, count, e);
            }
            static /*byte[]? */ UrlDecodeToBytes$3(/*byte[]?*/ bytes, /*int*/ offset, /*int*/ count)
            {
                return $.$swh.System.Web.Util.HttpEncoder.UrlDecode(bytes, offset, count);
            }
            static /*string */ JavaScriptStringEncode(/*string?*/ value)
            {
                return $.$swh.System.Web.Util.HttpEncoder.JavaScriptStringEncode(value, false);
            }
            static /*string */ JavaScriptStringEncode$1(/*string?*/ value, /*bool*/ addDoubleQuotes)
            {
                return $.$swh.System.Web.Util.HttpEncoder.JavaScriptStringEncode(value, addDoubleQuotes);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 385688;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":983076,"p":[{"n":"query","p":1310721}],"n":"ParseQueryString","d":385688,"h":8590320280,"f":33},{"r":983076,"p":[{"n":"query","p":1310721},{"n":"encoding","p":121831425}],"n":"ParseQueryString","o":"@$1","d":385688,"h":12885287576,"f":33},{"r":1310721,"p":[{"n":"s","p":1310721}],"n":"HtmlDecode","d":385688,"h":17180254872,"f":33},{"r":65537,"p":[{"n":"s","p":1310721},{"n":"output","p":63045633}],"n":"HtmlDecode","o":"@$1","d":385688,"h":21475222168,"f":33},{"r":1310721,"p":[{"n":"s","p":1310721}],"n":"HtmlEncode","d":385688,"h":25770189464,"f":33},{"r":1310721,"p":[{"n":"value","p":131073}],"n":"HtmlEncode","o":"@$1","d":385688,"h":30065156760,"f":33},{"r":65537,"p":[{"n":"s","p":1310721},{"n":"output","p":63045633}],"n":"HtmlEncode","o":"@$2","d":385688,"h":34360124056,"f":33},{"r":1310721,"p":[{"n":"s","p":1310721}],"n":"HtmlAttributeEncode","d":385688,"h":38655091352,"f":33},{"r":65537,"p":[{"n":"s","p":1310721},{"n":"output","p":63045633}],"n":"HtmlAttributeEncode","o":"@$1","d":385688,"h":42950058648,"f":33},{"r":1310721,"p":[{"n":"str","p":1310721}],"n":"UrlEncode","d":385688,"h":47245025944,"f":33},{"r":1310721,"p":[{"n":"str","p":1310721}],"n":"UrlPathEncode","d":385688,"h":51539993240,"f":33},{"r":1310721,"p":[{"n":"str","p":1310721},{"n":"e","p":121831425}],"n":"UrlEncode","o":"@$1","d":385688,"h":55834960536,"f":33},{"r":1310721,"p":[{"n":"bytes","p":0}],"n":"UrlEncode","o":"@$2","d":385688,"h":60129927832,"f":33},{"r":1310721,"p":[{"n":"bytes","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"UrlEncode","o":"@$3","d":385688,"h":64424895128,"f":33},{"r":0,"p":[{"n":"str","p":1310721}],"n":"UrlEncodeToBytes","d":385688,"h":68719862424,"f":33},{"r":0,"p":[{"n":"bytes","p":0}],"n":"UrlEncodeToBytes","o":"@$1","d":385688,"h":73014829720,"f":33},{"r":0,"p":[{"n":"str","p":1310721}],"n":"UrlEncodeUnicodeToBytes","d":385688,"h":77309797016,"f":33,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This method produces non-standards-compliant output and has interoperability issues. The preferred alternative is UrlEncodeToBytes(String).","t":1310721}]}]},{"r":1310721,"p":[{"n":"str","p":1310721}],"n":"UrlDecode","d":385688,"h":81604764312,"f":33},{"r":1310721,"p":[{"n":"bytes","p":0},{"n":"e","p":121831425}],"n":"UrlDecode","o":"@$1","d":385688,"h":85899731608,"f":33},{"r":0,"p":[{"n":"str","p":1310721}],"n":"UrlDecodeToBytes","d":385688,"h":90194698904,"f":33},{"r":0,"p":[{"n":"str","p":1310721},{"n":"e","p":121831425}],"n":"UrlDecodeToBytes","o":"@$1","d":385688,"h":94489666200,"f":33},{"r":0,"p":[{"n":"bytes","p":0}],"n":"UrlDecodeToBytes","o":"@$2","d":385688,"h":98784633496,"f":33},{"r":0,"p":[{"n":"str","p":1310721},{"n":"e","p":121831425}],"n":"UrlEncodeToBytes","o":"@$2","d":385688,"h":103079600792,"f":33},{"r":0,"p":[{"n":"bytes","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"UrlEncodeToBytes","o":"@$3","d":385688,"h":107374568088,"f":33},{"r":1310721,"p":[{"n":"str","p":1310721}],"n":"UrlEncodeUnicode","d":385688,"h":111669535384,"f":33,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This method produces non-standards-compliant output and has interoperability issues. The preferred alternative is UrlEncode(String).","t":1310721}]}]},{"r":1310721,"p":[{"n":"str","p":1310721},{"n":"e","p":121831425}],"n":"UrlDecode","o":"@$2","d":385688,"h":115964502680,"f":33},{"r":1310721,"p":[{"n":"str","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"e","p":121831425}],"n":"UrlDecode","o":"@$3","d":385688,"h":120259469976,"f":34},{"r":1310721,"p":[{"n":"bytes","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"e","p":121831425}],"n":"UrlDecode","o":"@$4","d":385688,"h":124554437272,"f":33},{"r":0,"p":[{"n":"bytes","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"UrlDecodeToBytes","o":"@$3","d":385688,"h":128849404568,"f":33},{"r":1310721,"p":[{"n":"value","p":1310721}],"n":"JavaScriptStringEncode","d":385688,"h":133144371864,"f":33},{"r":1310721,"p":[{"n":"value","p":1310721},{"n":"addDoubleQuotes","p":262145}],"n":"JavaScriptStringEncode","o":"@$1","d":385688,"h":137439339160,"f":33}],"c":[{"n":".ctor","o":"$ctor$1","d":385688,"h":141734306456,"f":1}],"j":[451224],"h":385688}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Web.HttpUtility`; }
        });
        
        $asm.$cls("$swh.System.Web.Util.HttpEncoder", ($self) => class HttpEncoder
        {
            /*int*/ static MaxStackAllocUrlLength = 256;
            /*int*/ static StackallocThreshold = 512;
            /*SearchValues<byte>*/ static s_urlSafeBytes = null;
            /*SearchValues<char>*/ static s_invalidJavaScriptChars = null;
            static /*string? */ HtmlAttributeEncode(/*string?*/ value)
            {
                if ($.$spc.System.String.IsNullOrEmpty(value))
                {
                    return value;
                }
                /*int*/ let pos = $.$swh.System.Web.Util.HttpEncoder.IndexOfHtmlAttributeEncodingChars(value);
                if (pos < 0)
                {
                    return value;
                }
                /*StringWriter*/ let writer = new $.$spc.System.IO.StringWriter().$ctor$5($.$spc.System.Globalization.CultureInfo.InvariantCulture);
                $.$swh.System.Web.Util.HttpEncoder.HtmlAttributeEncodeInternal(value, pos, writer);
                return $.$spc.System.IO.StringWriter.ToString.call(writer);
            }
            static /*void */ HtmlAttributeEncode$1(/*string?*/ value, /*TextWriter*/ output)
            {
                if ($.$spc.System.String.op_Equality(value, null))
                {
                    return;
                }
                $.$spc.System.ArgumentNullException.ThrowIfNull(output, "output");
                /*int*/ let pos = $.$swh.System.Web.Util.HttpEncoder.IndexOfHtmlAttributeEncodingChars(value);
                if (pos < 0)
                {
                    output.Write$12(value);
                    return;
                }
                $.$swh.System.Web.Util.HttpEncoder.HtmlAttributeEncodeInternal(value, pos, output);
            }
            static /*void */ HtmlAttributeEncodeInternal(/*string*/ s, /*int*/ index, /*TextWriter*/ output)
            {
                output.Write$3($.$spc.System.MemoryExtensions.AsSpan$7(s, 0, index));
                /*ReadOnlySpan<char>*/ let remaining = $.$spc.System.MemoryExtensions.AsSpan$4(s, index);
                for(/*int*/ let i = 0; i < remaining.Length; i++)
                {
                    /*char*/ let ch = remaining.get_Item(i).$v;
                    if (ch <= /*<*/ 60)
                    {
                        switch(ch)
                        {
                            case /*<*/ 60:
                            output.Write$12("&lt;");
                            break;
                            case /*\"*/ 34:
                            output.Write$12("&quot;");
                            break;
                            case /*'*/ 39:
                            output.Write$12("&#39;");
                            break;
                            case /*&*/ 38:
                            output.Write$12("&amp;");
                            break;
                            default:
                            output.Write(ch);
                            break;
                        }
                    }
                    else 
                    {
                        output.Write(ch);
                    }
                }
            }
            static /*string? */ HtmlDecode(/*string?*/ value)
            {
                return $.$spc.System.String.IsNullOrEmpty(value) ? value : $.$spc.System.Net.WebUtility.HtmlDecode(value);
            }
            static /*void */ HtmlDecode$1(/*string?*/ value, /*TextWriter*/ output)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(output, "output");
                output.Write$12($.$spc.System.Net.WebUtility.HtmlDecode(value));
            }
            static /*string? */ HtmlEncode(/*string?*/ value)
            {
                return $.$spc.System.String.IsNullOrEmpty(value) ? value : $.$spc.System.Net.WebUtility.HtmlEncode(value);
            }
            static /*void */ HtmlEncode$1(/*string?*/ value, /*TextWriter*/ output)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(output, "output");
                output.Write$12($.$spc.System.Net.WebUtility.HtmlEncode(value));
            }
            static /*int */ IndexOfHtmlAttributeEncodingChars(/*string*/ s)
            {
                return $.$spc.System.MemoryExtensions.IndexOfAny$9($.$spc.System.Char, $.$spc.System.MemoryExtensions.AsSpan$3(s), $.$spc.System.String.op_Implicit("<\"'&"));
            }
            static /*string */ JavaScriptStringEncode(/*string?*/ value, /*bool*/ addDoubleQuotes)
            {
                /*int*/ let i = $.$spc.System.MemoryExtensions.IndexOfAny$11($.$spc.System.Char, $.$spc.System.MemoryExtensions.AsSpan$3(value), $.$swh.System.Web.Util.HttpEncoder.s_invalidJavaScriptChars);
                if (i < 0)
                {
                    return addDoubleQuotes ? `\"${value}\"` : value ?? $.$spc.System.String.Empty;
                }
                return EncodeCore($.$spc.System.String.op_Implicit(value), i, addDoubleQuotes);
                /*static string*/  function EncodeCore(/*ReadOnlySpan<char>*/ value, /*int*/ i, /*bool*/ addDoubleQuotes)
                {
                    /*var*/ let vsb = new $.$swh.System.Text.ValueStringBuilder().$ctor$2($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Char, 512/*StackallocThreshold*/, null));
                    if (addDoubleQuotes)
                    {
                        vsb.Append(/*\"*/ 34);
                    }
                    /*ReadOnlySpan<char>*/ let chars = value;
                    do
                    {
                        vsb.Append$3(chars.Slice$1(0, i));
                        /*char*/ let c = chars.get_Item(i).$v;
                        chars = chars.Slice(((i + 1) | 0));
                        switch(c)
                        {
                            case /*\r*/ 13:
                            vsb.Append$1("\\r");
                            break;
                            case /*\t*/ 9:
                            vsb.Append$1("\\t");
                            break;
                            case /*\"*/ 34:
                            vsb.Append$1("\\\"");
                            break;
                            case /*\\*/ 92:
                            vsb.Append$1("\\\\");
                            break;
                            case /*\n*/ 10:
                            vsb.Append$1("\\n");
                            break;
                            case /*\u0008*/ 8:
                            vsb.Append$1("\\b");
                            break;
                            case /*\u000C*/ 12:
                            vsb.Append$1("\\f");
                            break;
                            default:
                            vsb.Append$1("\\u");
                            vsb.AppendSpanFormattable($.$spc.System.Int32, $.$cast(c, $.$spc.System.Int32), "x4", null);
                            break;
                        }
                        i = $.$spc.System.MemoryExtensions.IndexOfAny$11($.$spc.System.Char, chars, $.$swh.System.Web.Util.HttpEncoder.s_invalidJavaScriptChars);
                    }
                    while(i >= 0);
                    vsb.Append$3(chars);
                    if (addDoubleQuotes)
                    {
                        vsb.Append(/*\"*/ 34);
                    }
                    return $.$swh.System.Text.ValueStringBuilder.ToString.call(vsb);
                }
            }
            static /*byte[]? */ UrlDecode(/*byte[]?*/ bytes, /*int*/ offset, /*int*/ count)
            {
                if (!$.$swh.System.Web.Util.HttpEncoder.ValidateUrlEncodingParameters(bytes, offset, count))
                {
                    return null;
                }
                return $.$swh.System.Web.Util.HttpEncoder.UrlDecode$1($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.Byte, bytes, offset, count)));
            }
            static /*byte[] */ UrlDecode$1(/*ReadOnlySpan<byte>*/ bytes)
            {
                /*int*/ let decodedBytesCount = 0;
                /*int*/ let count = bytes.Length;
                /*Span<byte>*/ let decodedBytes = count <= 512/*StackallocThreshold*/ ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, 512/*StackallocThreshold*/, null) : $.$spc.System.Span$$($.$spc.System.Byte).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [count], null));
                for(/*int*/ let i = 0; i < count; i++)
                {
                    /*byte*/ let b = bytes.get_Item(i).$v;
                    if (b === /*+*/ 43)
                    {
                        b = /* */ 32;
                    }
                    else if (b === /*%*/ 37 && i < ((count - 2) | 0))
                    {
                        /*int*/ let h1 = $.$swh.System.HexConverter.FromChar(bytes.get_Item(((i + 1) | 0)).$v);
                        /*int*/ let h2 = $.$swh.System.HexConverter.FromChar(bytes.get_Item(((i + 2) | 0)).$v);
                        if ((h1 | h2) !== 255)
                        {
                            b = $.$cast(((h1 << 4) | h2), $.$spc.System.Byte);
                            i += 2;
                        }
                    }
                    decodedBytes.get_Item(decodedBytesCount++).$v = b;
                }
                return decodedBytes.Slice$1(0, decodedBytesCount).ToArray();
            }
            static /*string? */ UrlDecode$2(/*byte[]?*/ bytes, /*int*/ offset, /*int*/ count, /*Encoding*/ encoding)
            {
                if (!$.$swh.System.Web.Util.HttpEncoder.ValidateUrlEncodingParameters(bytes, offset, count))
                {
                    return null;
                }
                /*UrlDecoder*/ let helper = count <= 256/*MaxStackAllocUrlLength*/ ? new $.$swh.System.Web.Util.HttpEncoder.UrlDecoder().$ctor$2($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Char, 256/*MaxStackAllocUrlLength*/, null), $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, 256/*MaxStackAllocUrlLength*/, null), encoding) : new $.$swh.System.Web.Util.HttpEncoder.UrlDecoder().$ctor$2($.$spc.System.Span$$($.$spc.System.Char).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Char), null, [count], null)), $.$spc.System.Span$$($.$spc.System.Byte).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [count], null)), encoding);
                for(/*int*/ let i = 0; i < count; i++)
                {
                    /*int*/ let pos = ((offset + i) | 0);
                    /*byte*/ let b = $.$spc.System.Array.$ReadT1.call(bytes, pos);
                    if (b === /*+*/ 43)
                    {
                        b = /* */ 32;
                    }
                    else if (b === /*%*/ 37 && i < ((count - 2) | 0))
                    {
                        if ($.$spc.System.Array.$ReadT1.call(bytes, ((pos + 1) | 0)) === /*u*/ 117 && i < ((count - 5) | 0))
                        {
                            /*int*/ let h1 = $.$swh.System.HexConverter.FromChar($.$spc.System.Array.$ReadT1.call(bytes, ((pos + 2) | 0)));
                            /*int*/ let h2 = $.$swh.System.HexConverter.FromChar($.$spc.System.Array.$ReadT1.call(bytes, ((pos + 3) | 0)));
                            /*int*/ let h3 = $.$swh.System.HexConverter.FromChar($.$spc.System.Array.$ReadT1.call(bytes, ((pos + 4) | 0)));
                            /*int*/ let h4 = $.$swh.System.HexConverter.FromChar($.$spc.System.Array.$ReadT1.call(bytes, ((pos + 5) | 0)));
                            if ((h1 | h2 | h3 | h4) !== 255)
                            {
                                /*char*/ let ch = $.$cast(((h1 << 12) | (h2 << 8) | (h3 << 4) | h4), $.$spc.System.Char);
                                i += 5;
                                helper.AddChar(ch);
                                continue;
                            }
                        }
                        else 
                        {
                            /*int*/ let h1 = $.$swh.System.HexConverter.FromChar($.$spc.System.Array.$ReadT1.call(bytes, ((pos + 1) | 0)));
                            /*int*/ let h2 = $.$swh.System.HexConverter.FromChar($.$spc.System.Array.$ReadT1.call(bytes, ((pos + 2) | 0)));
                            if ((h1 | h2) !== 255)
                            {
                                b = $.$cast(((h1 << 4) | h2), $.$spc.System.Byte);
                                i += 2;
                            }
                        }
                    }
                    helper.AddByte(b);
                }
                return helper.GetString();
            }
            static /*string? */ UrlDecode$3(/*string?*/ value, /*Encoding*/ encoding)
            {
                if ($.$spc.System.String.op_Equality(value, null))
                {
                    return null;
                }
                return $.$swh.System.Web.Util.HttpEncoder.UrlDecode$4($.$spc.System.MemoryExtensions.AsSpan$3(value), encoding);
            }
            static /*string */ UrlDecode$4(/*ReadOnlySpan<char>*/ value, /*Encoding*/ encoding)
            {
                if (value.IsEmpty)
                {
                    return $.$spc.System.String.Empty;
                }
                /*int*/ let count = value.Length;
                /*UrlDecoder*/ let helper = count <= 256/*MaxStackAllocUrlLength*/ ? new $.$swh.System.Web.Util.HttpEncoder.UrlDecoder().$ctor$2($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Char, 256/*MaxStackAllocUrlLength*/, null), $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, 256/*MaxStackAllocUrlLength*/, null), encoding) : new $.$swh.System.Web.Util.HttpEncoder.UrlDecoder().$ctor$2($.$spc.System.Span$$($.$spc.System.Char).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Char), null, [count], null)), $.$spc.System.Span$$($.$spc.System.Byte).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [count], null)), encoding);
                for(/*int*/ let pos = 0; pos < count; pos++)
                {
                    /*char*/ let ch = value.get_Item(pos).$v;
                    if (ch === /*+*/ 43)
                    {
                        ch = /* */ 32;
                    }
                    else if (ch === /*%*/ 37 && pos < ((count - 2) | 0))
                    {
                        if (value.get_Item(((pos + 1) | 0)).$v === /*u*/ 117 && pos < ((count - 5) | 0))
                        {
                            /*int*/ let h1 = $.$swh.System.HexConverter.FromChar(value.get_Item(((pos + 2) | 0)).$v);
                            /*int*/ let h2 = $.$swh.System.HexConverter.FromChar(value.get_Item(((pos + 3) | 0)).$v);
                            /*int*/ let h3 = $.$swh.System.HexConverter.FromChar(value.get_Item(((pos + 4) | 0)).$v);
                            /*int*/ let h4 = $.$swh.System.HexConverter.FromChar(value.get_Item(((pos + 5) | 0)).$v);
                            if ((h1 | h2 | h3 | h4) !== 255)
                            {
                                ch = $.$cast(((h1 << 12) | (h2 << 8) | (h3 << 4) | h4), $.$spc.System.Char);
                                pos += 5;
                                helper.AddChar(ch);
                                continue;
                            }
                        }
                        else 
                        {
                            /*int*/ let h1 = $.$swh.System.HexConverter.FromChar(value.get_Item(((pos + 1) | 0)).$v);
                            /*int*/ let h2 = $.$swh.System.HexConverter.FromChar(value.get_Item(((pos + 2) | 0)).$v);
                            if ((h1 | h2) !== 255)
                            {
                                /*byte*/ let b = $.$cast(((h1 << 4) | h2), $.$spc.System.Byte);
                                pos += 2;
                                helper.AddByte(b);
                                continue;
                            }
                        }
                    }
                    if ((ch & 65408) === 0)
                    {
                        helper.AddByte($.$cast(ch, $.$spc.System.Byte));
                    }
                    else 
                    {
                        helper.AddChar(ch);
                    }
                }
                return helper.GetString();
            }
            static /*byte[]? */ UrlEncode(/*byte[]?*/ bytes, /*int*/ offset, /*int*/ count)
            {
                if (!$.$swh.System.Web.Util.HttpEncoder.ValidateUrlEncodingParameters(bytes, offset, count))
                {
                    return null;
                }
                return $.$swh.System.Web.Util.HttpEncoder.UrlEncode$1($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.Byte, bytes, offset, count)));
            }
            static /*byte[] */ UrlEncode$1(/*ReadOnlySpan<byte>*/ bytes)
            {
                /*int*/ let cUnsafe;
                if (!$.$swh.System.Web.Util.HttpEncoder.NeedsEncoding(bytes, $.$ref(() => cUnsafe, ($v) => cUnsafe = $v, $.$spc.System.Int32)))
                {
                    return bytes.ToArray();
                }
                return $.$swh.System.Web.Util.HttpEncoder.UrlEncode$2(bytes, cUnsafe);
            }
            static /*byte[] */ UrlEncode$2(/*ReadOnlySpan<byte>*/ bytes, /*int*/ cUnsafe)
            {
                /*byte[]*/ let expandedBytes = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [((bytes.Length + ((cUnsafe * 2) | 0)) | 0)], null);
                /*int*/ let pos = 0;
                var $en2 = bytes.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var b = $en2.Current.$v;
                    {
                        if ($.$swh.System.Web.Util.HttpEncoder.s_urlSafeBytes.Contains(b))
                        {
                            $.$spc.System.Array.$WriteT1.call(expandedBytes, b, pos++);
                        }
                        else if (b === /* */ 32)
                        {
                            $.$spc.System.Array.$WriteT1.call(expandedBytes, /*+*/ 43, pos++);
                        }
                        else 
                        {
                            $.$spc.System.Array.$WriteT1.call(expandedBytes, /*%*/ 37, pos++);
                            $.$spc.System.Array.$WriteT1.call(expandedBytes, $.$cast($.$swh.System.HexConverter.ToCharLower(b >>> 4), $.$spc.System.Byte), pos++);
                            $.$spc.System.Array.$WriteT1.call(expandedBytes, $.$cast($.$swh.System.HexConverter.ToCharLower(b), $.$spc.System.Byte), pos++);
                        }
                    }
                }
                return expandedBytes;
            }
            static /*bool */ NeedsEncoding(/*ReadOnlySpan<byte>*/ bytes, /*out int*/ cUnsafe)
            {
                cUnsafe.$v = 0;
                /*int*/ let i = $.$spc.System.MemoryExtensions.IndexOfAnyExcept$14($.$spc.System.Byte, bytes, $.$swh.System.Web.Util.HttpEncoder.s_urlSafeBytes);
                if (i < 0)
                {
                    return false;
                }
                var $en2 = bytes.Slice(i).GetEnumerator();
                while ($en2.MoveNext())
                {
                    var b = $en2.Current.$v;
                    {
                        if (!$.$swh.System.Web.Util.HttpEncoder.s_urlSafeBytes.Contains(b) && b !== /* */ 32)
                        {
                            cUnsafe.$v++;
                        }
                    }
                }
                return true;
            }
            static /*byte[] */ UrlEncode$3(/*string*/ str, /*Encoding*/ e)
            {
                if (e.GetMaxByteCount(str.length) <= 512/*StackallocThreshold*/)
                {
                    /*Span<byte>*/ let byteSpan = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, 512/*StackallocThreshold*/, null);
                    /*int*/ let encodedBytes = e.GetBytes$7($.$spc.System.String.op_Implicit(str), byteSpan);
                    return $.$swh.System.Web.Util.HttpEncoder.UrlEncode$1($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2(byteSpan.Slice$1(0, encodedBytes)));
                }
                /*byte[]*/ let bytes = e.GetBytes$3(str);
                /*int*/ let cUnsafe;
                return $.$swh.System.Web.Util.HttpEncoder.NeedsEncoding($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).op_Implicit(bytes), $.$ref(() => cUnsafe, ($v) => cUnsafe = $v, $.$spc.System.Int32)) ? $.$swh.System.Web.Util.HttpEncoder.UrlEncode$2($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).op_Implicit(bytes), cUnsafe) : bytes;
            }
            static /*string? */ UrlEncodeUnicode(/*string?*/ value)
            {
                if ($.$spc.System.String.op_Equality(value, null))
                {
                    return null;
                }
                /*int*/ let l = value.length;
                /*StringBuilder*/ let sb = new $.$spc.System.Text.StringBuilder().$ctor$2(l);
                for(/*int*/ let i = 0; i < l; i++)
                {
                    /*char*/ let ch = $.$spc.System.String.get_Chars.call(value, i);
                    if ((ch & 65408) === 0)
                    {
                        if ($.$swh.System.Web.Util.HttpEncoder.s_urlSafeBytes.Contains($.$cast(ch, $.$spc.System.Byte)))
                        {
                            sb.Append$7(ch);
                        }
                        else if (ch === /* */ 32)
                        {
                            sb.Append$7(/*+*/ 43);
                        }
                        else 
                        {
                            sb.Append$7(/*%*/ 37);
                            sb.Append$7($.$swh.System.HexConverter.ToCharLower(ch >>> 4));
                            sb.Append$7($.$swh.System.HexConverter.ToCharLower(ch));
                        }
                    }
                    else 
                    {
                        sb.Append$2("%u");
                        sb.Append$7($.$swh.System.HexConverter.ToCharLower(ch >>> 12));
                        sb.Append$7($.$swh.System.HexConverter.ToCharLower(ch >>> 8));
                        sb.Append$7($.$swh.System.HexConverter.ToCharLower(ch >>> 4));
                        sb.Append$7($.$swh.System.HexConverter.ToCharLower(ch));
                    }
                }
                return $.$spc.System.Text.StringBuilder.ToString.call(sb);
            }
            static /*string? */ UrlPathEncode(/*string?*/ value)
            {
                if ($.$spc.System.String.IsNullOrEmpty(value))
                {
                    return value;
                }
                /*ReadOnlySpan<char>*/ let schemeAndAuthority;
                /*string?*/ let path;
                /*ReadOnlySpan<char>*/ let queryAndFragment;
                if (!$.$swh.System.Web.Util.UriUtil.TrySplitUriForPathEncode(value, $.$ref(() => schemeAndAuthority, ($v) => schemeAndAuthority = $v, $.$spc.System.ReadOnlySpan$$($.$spc.System.Char)), $.$ref(() => path, ($v) => path = $v, $.$spc.System.String), $.$ref(() => queryAndFragment, ($v) => queryAndFragment = $v, $.$spc.System.ReadOnlySpan$$($.$spc.System.Char))))
                {
                    return $.$swh.System.Web.Util.HttpEncoder.UrlPathEncodeImpl(value);
                }
                return $.$spc.System.String.Concat$11(schemeAndAuthority, $.$spc.System.String.op_Implicit($.$swh.System.Web.Util.HttpEncoder.UrlPathEncodeImpl(path)), queryAndFragment);
            }
            static /*string */ UrlPathEncodeImpl(/*string*/ value)
            {
                if ($.$spc.System.String.IsNullOrEmpty(value))
                {
                    return value;
                }
                /*int*/ let i = $.$spc.System.MemoryExtensions.IndexOfAnyExceptInRange$1($.$spc.System.Char, $.$spc.System.MemoryExtensions.AsSpan$3(value), 33, 127);
                if (i < 0)
                {
                    return value;
                }
                /*int*/ let indexOfQuery = $.$spc.System.String.IndexOf.call(value, /*?*/ 63);
                if ((indexOfQuery >>> 0) < (i >>> 0))
                {
                    return value;
                }
                /*ReadOnlySpan<char>*/ let toEncode = indexOfQuery >= 0 ? $.$spc.System.MemoryExtensions.AsSpan$7(value, i, ((indexOfQuery - i) | 0)) : $.$spc.System.MemoryExtensions.AsSpan$4(value, i);
                /*byte[]*/ let bytes = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Rent($.$spc.System.Text.Encoding.UTF8.GetMaxByteCount(toEncode.Length));
                /*int*/ let utf8Length = $.$spc.System.Text.Encoding.UTF8.GetBytes$7(toEncode, $.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(bytes));
                /*char[]*/ let chars = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Char).Shared.Rent(((utf8Length * 3) | 0));
                /*int*/ let charCount = 0;
                var $en2 = $.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.Byte, bytes, 0, utf8Length).GetEnumerator();
                while ($en2.MoveNext())
                {
                    var b = $en2.Current.$v;
                    {
                        if (!$.$spc.System.Char.IsBetween(b, 33, 127))
                        {
                            $.$spc.System.Array.$WriteT1.call(chars, /*%*/ 37, charCount++);
                            $.$spc.System.Array.$WriteT1.call(chars, $.$swh.System.HexConverter.ToCharLower(b >>> 4), charCount++);
                            $.$spc.System.Array.$WriteT1.call(chars, $.$swh.System.HexConverter.ToCharLower(b), charCount++);
                        }
                        else 
                        {
                            $.$spc.System.Array.$WriteT1.call(chars, b, charCount++);
                        }
                    }
                }
                $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Return(bytes, false);
                /*string*/ let result = $.$spc.System.String.Concat$11($.$spc.System.MemoryExtensions.AsSpan$7(value, 0, i), $.$spc.System.Span$$($.$spc.System.Char).op_Implicit$2($.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.Char, chars, 0, charCount)), indexOfQuery >= 0 ? $.$spc.System.MemoryExtensions.AsSpan$4(value, indexOfQuery) : $.$spc.System.ReadOnlySpan$$($.$spc.System.Char).Empty);
                $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Char).Shared.Return(chars, false);
                return result;
            }
            static /*bool */ ValidateUrlEncodingParameters(/*byte[]?*/ bytes, /*int*/ offset, /*int*/ count)
            {
                if (bytes === null && count === 0)
                {
                    return false;
                }
                $.$spc.System.ArgumentNullException.ThrowIfNull(bytes, "bytes");
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegative($.$spc.System.Int32, offset, "offset");
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$spc.System.Int32, offset, bytes.length, "offset");
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegative($.$spc.System.Int32, count, "count");
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$spc.System.Int32, count, ((bytes.length - offset) | 0), "count");
                return true;
            }
            static $_UrlDecoder;
            static get UrlDecoder()
            {
                let $cls = $.$swh.System.Web.Util.HttpEncoder;
                return $cls.$_UrlDecoder ??= $asm.$nstr("$swh.System.Web.Util.HttpEncoder.UrlDecoder", ($self) => class UrlDecoder extends $.$spc.System.ValueType
                {
                    /*int*/  get _numChars() { return this.$getField(0, 4); }
                    /*int*/  set _numChars(value) { this.$setField(0, 4, value); }
                    /*Span<char>*/  get _charBuffer() { return this.$getField(4, 6); }
                    /*Span<char>*/  set _charBuffer(value) { this.$setField(4, 6, value); }
                    /*int*/  get _numBytes() { return this.$getField(10, 4); }
                    /*int*/  set _numBytes(value) { this.$setField(10, 4, value); }
                    /*Span<byte>*/  get _byteBuffer() { return this.$getField(14, 5); }
                    /*Span<byte>*/  set _byteBuffer(value) { this.$setField(14, 5, value); }
                    /*Encoding*/  get _encoding() { return this.$getField(19, 4); }
                    /*Encoding*/  set _encoding(value) { this.$setField(19, 4, value); }
                    /*void */ FlushBytes()
                    {
                        if (this._numBytes > 0)
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(!this._byteBuffer.IsEmpty, "!_byteBuffer.IsEmpty");
                            this._numChars += this._encoding.GetChars$4($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2(this._byteBuffer.Slice$1(0, this._numBytes)), this._charBuffer.Slice(this._numChars));
                            this._numBytes = 0;
                        }
                    }
                    $ctor$2(/*Span<char>*/ charBuffer, /*Span<byte>*/ byteBuffer, /*Encoding*/ encoding)
                    {
                        super.$ctor$1();
                        {
                            this._charBuffer = charBuffer;
                            this._byteBuffer = byteBuffer;
                            this._encoding = encoding;
                        }
                        return this;
                    }
                    /*void */ AddChar(/*char*/ ch)
                    {
                        if (this._numBytes > 0)
                        {
                            this.FlushBytes();
                        }
                        this._charBuffer.get_Item(this._numChars++).$v = ch;
                    }
                    /*void */ AddByte(/*byte*/ b)
                    {
                        {
                            this._byteBuffer.get_Item(this._numBytes++).$v = b;
                        }
                    }
                    /*string */ GetString()
                    {
                        if (this._numBytes > 0)
                        {
                            this.FlushBytes();
                        }
                        /*Span<char>*/ let chars = this._charBuffer.Slice$1(0, this._numChars);
                        /*char*/ let HIGH_SURROGATE_START = /*\uD800*/ 55296;
                        /*char*/ let LOW_SURROGATE_END = /*\uDFFF*/ 57343;
                        /*int*/ let idxOfFirstSurrogate = $.$spc.System.MemoryExtensions.IndexOfAnyInRange$1($.$spc.System.Char, $.$spc.System.Span$$($.$spc.System.Char).op_Implicit$2(chars), HIGH_SURROGATE_START, LOW_SURROGATE_END);
                        for(/*int*/ let i = idxOfFirstSurrogate; (i >>> 0) < (chars.Length >>> 0); i++)
                        {
                            if ($.$spc.System.Char.IsHighSurrogate(chars.get_Item(i).$v))
                            {
                                if (((((i + 1) | 0)) >>> 0) >= (chars.Length >>> 0) || !$.$spc.System.Char.IsLowSurrogate(chars.get_Item(((i + 1) | 0)).$v))
                                {
                                    chars.get_Item(i).$v = $.$cast($.$spc.System.Text.Rune.ReplacementChar.Value, $.$spc.System.Char);
                                }
                                else 
                                {
                                    i++;
                                }
                            }
                            else if ($.$spc.System.Char.IsLowSurrogate(chars.get_Item(i).$v))
                            {
                                chars.get_Item(i).$v = $.$cast($.$spc.System.Text.Rune.ReplacementChar.Value, $.$spc.System.Char);
                            }
                        }
                        return $.$spc.System.Span$$($.$spc.System.Char).ToString.call(chars);
                    }
                    //default value type constructor
                    $ctor$3()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._numChars = this._numChars;
                        copy._charBuffer = this._charBuffer.Clone();
                        copy._numBytes = this._numBytes;
                        copy._byteBuffer = this._byteBuffer.Clone();
                        copy._encoding = this._encoding;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._numChars = 0;
                        this._charBuffer = $.$default($.$spc.System.Span$$($.$spc.System.Char));
                        this._numBytes = 0;
                        this._byteBuffer = $.$default($.$spc.System.Span$$($.$spc.System.Byte));
                        this._encoding = null;
                    }
                    static $h = 647832;
                    static $z = 23;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"m":[{"r":65537,"n":"FlushBytes","d":647832,"h":25770451608,"f":2},{"r":65537,"p":[{"n":"ch","p":458753}],"n":"AddChar","d":647832,"h":34360386200,"f":8},{"r":65537,"p":[{"n":"b","p":393217}],"n":"AddByte","d":647832,"h":38655353496,"f":8},{"r":1310721,"n":"GetString","d":647832,"h":42950320792,"f":8}],"l":[{"t":655361,"n":"_numChars","d":647832,"h":4295615128,"f":2},{"t":$.$spc.System.Span$$($.$spc.System.Char).$h,"n":"_charBuffer","d":647832,"h":8590582424,"f":2},{"t":655361,"n":"_numBytes","d":647832,"h":12885549720,"f":2},{"t":$.$spc.System.Span$$($.$spc.System.Byte).$h,"n":"_byteBuffer","d":647832,"h":17180517016,"f":2},{"t":121831425,"n":"_encoding","d":647832,"h":21475484312,"f":2}],"c":[{"p":[{"n":"charBuffer","p":$.$spc.System.Span$$($.$spc.System.Char).$h},{"n":"byteBuffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"encoding","p":121831425}],"n":".ctor","o":"$ctor$2","d":647832,"h":30065418904,"f":8},{"n":".ctor","o":"$ctor$3","d":647832,"h":47245288088,"f":1}],"d":582296,"h":647832}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `System.Web.Util.HttpEncoder.UrlDecoder`; }
                }, $cls, ($v) => $cls.$_UrlDecoder = $v);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_urlSafeBytes = $.$spc.System.Buffers.SearchValues.Create(new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$2([33, 40, 41, 42, 45, 46, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 95, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122]));
                }
                {
                    this.s_invalidJavaScriptChars = $.$spc.System.Buffers.SearchValues.Create$1($.$spc.System.String.op_Implicit("\u0000\u0001\u0002\u0003\u0004\u0005\u0006\u0007\u0008\t\n\u000B\u000C\r\u000E\u000F\u0010\u0011\u0012\u0013\u0014\u0015\u0016\u0017\u0018\u0019\u001A\u001B\u001C\u001D\u001E\u001F" + "\"&'<>\\" + "\u0085\u2028\u2029"));
                }
            }
            static $h = 582296;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1310721,"p":[{"n":"value","p":1310721}],"n":"HtmlAttributeEncode","d":582296,"h":21475418776,"f":40},{"r":65537,"p":[{"n":"value","p":1310721},{"n":"output","p":63045633}],"n":"HtmlAttributeEncode","o":"@$1","d":582296,"h":25770386072,"f":40},{"r":65537,"p":[{"n":"s","p":1310721},{"n":"index","p":655361},{"n":"output","p":63045633}],"n":"HtmlAttributeEncodeInternal","d":582296,"h":30065353368,"f":34},{"r":1310721,"p":[{"n":"value","p":1310721}],"n":"HtmlDecode","d":582296,"h":34360320664,"f":40},{"r":65537,"p":[{"n":"value","p":1310721},{"n":"output","p":63045633}],"n":"HtmlDecode","o":"@$1","d":582296,"h":38655287960,"f":40},{"r":1310721,"p":[{"n":"value","p":1310721}],"n":"HtmlEncode","d":582296,"h":42950255256,"f":40},{"r":65537,"p":[{"n":"value","p":1310721},{"n":"output","p":63045633}],"n":"HtmlEncode","o":"@$1","d":582296,"h":47245222552,"f":40},{"r":655361,"p":[{"n":"s","p":1310721}],"n":"IndexOfHtmlAttributeEncodingChars","d":582296,"h":51540189848,"f":34},{"r":1310721,"p":[{"n":"value","p":1310721},{"n":"addDoubleQuotes","p":262145}],"n":"JavaScriptStringEncode","d":582296,"h":55835157144,"f":40},{"r":0,"p":[{"n":"bytes","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"UrlDecode","d":582296,"h":60130124440,"f":40},{"r":0,"p":[{"n":"bytes","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"UrlDecode","o":"@$1","d":582296,"h":64425091736,"f":40},{"r":1310721,"p":[{"n":"bytes","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"encoding","p":121831425}],"n":"UrlDecode","o":"@$2","d":582296,"h":68720059032,"f":40},{"r":1310721,"p":[{"n":"value","p":1310721},{"n":"encoding","p":121831425}],"n":"UrlDecode","o":"@$3","d":582296,"h":73015026328,"f":40},{"r":1310721,"p":[{"n":"value","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"encoding","p":121831425}],"n":"UrlDecode","o":"@$4","d":582296,"h":77309993624,"f":40},{"r":0,"p":[{"n":"bytes","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"UrlEncode","d":582296,"h":81604960920,"f":40},{"r":0,"p":[{"n":"bytes","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"UrlEncode","o":"@$1","d":582296,"h":85899928216,"f":34},{"r":0,"p":[{"n":"bytes","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"cUnsafe","p":655361}],"n":"UrlEncode","o":"@$2","d":582296,"h":90194895512,"f":34},{"r":262145,"p":[{"n":"bytes","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"cUnsafe","p":655361,"f":2}],"n":"NeedsEncoding","d":582296,"h":94489862808,"f":34},{"r":0,"p":[{"n":"str","p":1310721},{"n":"e","p":121831425}],"n":"UrlEncode","o":"@$3","d":582296,"h":98784830104,"f":40},{"r":1310721,"p":[{"n":"value","p":1310721}],"n":"UrlEncodeUnicode","d":582296,"h":103079797400,"f":40,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This method produces non-standards-compliant output and has interoperability issues. The preferred alternative is UrlEncode(*).","t":1310721}]}]},{"r":1310721,"p":[{"n":"value","p":1310721}],"n":"UrlPathEncode","d":582296,"h":107374764696,"f":40},{"r":1310721,"p":[{"n":"value","p":1310721}],"n":"UrlPathEncodeImpl","d":582296,"h":111669731992,"f":34},{"r":262145,"p":[{"n":"bytes","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"ValidateUrlEncodingParameters","d":582296,"h":115964699288,"f":34}],"l":[{"t":655361,"n":"MaxStackAllocUrlLength","d":582296,"h":4295549592,"f":34},{"t":655361,"n":"StackallocThreshold","d":582296,"h":8590516888,"f":34},{"t":$.$spc.System.Buffers.SearchValues$$($.$spc.System.Byte).$h,"n":"s_urlSafeBytes","d":582296,"h":12885484184,"f":34},{"t":$.$spc.System.Buffers.SearchValues$$($.$spc.System.Char).$h,"n":"s_invalidJavaScriptChars","d":582296,"h":17180451480,"f":34}],"j":[647832],"h":582296}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Web.Util.HttpEncoder`; }
        });
        
        $asm.$str("$swh.System.Text.ValueStringBuilder", ($self) => class ValueStringBuilder extends $.$spc.System.ValueType
        {
            /*void */ AppendSpanFormattable(T, /*T*/ value, /*string?*/ format, /*IFormatProvider?*/ provider)
            {
                /*int*/ let charsWritten;
                if ($.$dsp(value, T, ($t) => $t.System$ISpanFormattable$TryFormat, this._chars.Slice(this._pos), $.$ref(() => charsWritten, ($v) => charsWritten = $v, $.$spc.System.Int32), $.$spc.System.String.op_Implicit(format), provider))
                {
                    this._pos += charsWritten;
                }
                else 
                {
                    this.Append$1($.$dsp(value, T, ($t) => $t.System$IFormattable$ToString, format, provider));
                }
            }
            /*char[]?*/  get _arrayToReturnToPool() { return this.$getField(0, 4); }
            /*char[]?*/  set _arrayToReturnToPool(value) { this.$setField(0, 4, value); }
            /*Span<char>*/  get _chars() { return this.$getField(4, 6); }
            /*Span<char>*/  set _chars(value) { this.$setField(4, 6, value); }
            /*int*/  get _pos() { return this.$getField(10, 4); }
            /*int*/  set _pos(value) { this.$setField(10, 4, value); }
            $ctor$2(/*Span<char>*/ initialBuffer)
            {
                super.$ctor$1();
                {
                    this._arrayToReturnToPool = null;
                    this._chars = initialBuffer;
                    this._pos = 0;
                }
                return this;
            }
            $ctor$3(/*int*/ initialCapacity)
            {
                super.$ctor$1();
                {
                    this._arrayToReturnToPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Char).Shared.Rent(initialCapacity);
                    this._chars = $.$spc.System.Span$$($.$spc.System.Char).op_Implicit(this._arrayToReturnToPool);
                    this._pos = 0;
                }
                return this;
            }
            /*int */ get Length()
            {
                return this._pos;
            }
            /*int */ set Length(value)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(value >= 0, "value >= 0");
                $.$spc.System.Diagnostics.Debug.Assert$1(value <= this._chars.Length, "value <= _chars.Length");
                this._pos = value;
            }
            /*int */ get Capacity()
            {
                return this._chars.Length;
            }
            /*void */ EnsureCapacity(/*int*/ capacity)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(capacity >= 0, "capacity >= 0");
                if ((capacity >>> 0) > (this._chars.Length >>> 0))
                {
                    this.Grow(((capacity - this._pos) | 0));
                }
            }
            /*ref char */ GetPinnableReference()
            {
                return $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference($.$spc.System.Char, this._chars);
            }
            /*ref char */ GetPinnableReference$1(/*bool*/ terminate)
            {
                if (terminate)
                {
                    this.EnsureCapacity(((this.Length + 1) | 0));
                    this._chars.get_Item(this.Length).$v = /*\u0000*/ 0;
                }
                return $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference($.$spc.System.Char, this._chars);
            }
            /*ref char*/ get_Item(/*int*/ index)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(index < this._pos, "index < _pos");
                return this._chars.get_Item(index);
            }
            static/*conventional*/ /*string */ ToString()
            {
                /*string*/ let s = $.$spc.System.Span$$($.$spc.System.Char).ToString.call(this._chars.Slice$1(0, this._pos));
                this.Dispose();
                return s;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$swh.System.Text.ValueStringBuilder.ToString.apply(this, arguments); }
            /*Span<char> */ get RawChars()
            {
                return this._chars;
            }
            /*ReadOnlySpan<char> */ AsSpan(/*bool*/ terminate)
            {
                if (terminate)
                {
                    this.EnsureCapacity(((this.Length + 1) | 0));
                    this._chars.get_Item(this.Length).$v = /*\u0000*/ 0;
                }
                return $.$spc.System.Span$$($.$spc.System.Char).op_Implicit$2(this._chars.Slice$1(0, this._pos));
            }
            /*ReadOnlySpan<char> */ AsSpan$1()
            {
                return $.$spc.System.Span$$($.$spc.System.Char).op_Implicit$2(this._chars.Slice$1(0, this._pos));
            }
            /*ReadOnlySpan<char> */ AsSpan$2(/*int*/ start)
            {
                return $.$spc.System.Span$$($.$spc.System.Char).op_Implicit$2(this._chars.Slice$1(start, ((this._pos - start) | 0)));
            }
            /*ReadOnlySpan<char> */ AsSpan$3(/*int*/ start, /*int*/ length)
            {
                return $.$spc.System.Span$$($.$spc.System.Char).op_Implicit$2(this._chars.Slice$1(start, length));
            }
            /*bool */ TryCopyTo(/*Span<char>*/ destination, /*out int*/ charsWritten)
            {
                if (this._chars.Slice$1(0, this._pos).TryCopyTo(destination))
                {
                    charsWritten.$v = this._pos;
                    this.Dispose();
                    return true;
                }
                else 
                {
                    charsWritten.$v = 0;
                    this.Dispose();
                    return false;
                }
            }
            /*void */ Insert(/*int*/ index, /*char*/ value, /*int*/ count)
            {
                if (this._pos > ((this._chars.Length - count) | 0))
                {
                    this.Grow(count);
                }
                /*int*/ let remaining = ((this._pos - index) | 0);
                this._chars.Slice$1(index, remaining).CopyTo(this._chars.Slice(((index + count) | 0)));
                this._chars.Slice$1(index, count).Fill(value);
                this._pos += count;
            }
            /*void */ Insert$1(/*int*/ index, /*string?*/ s)
            {
                if ($.$spc.System.String.op_Equality(s, null))
                {
                    return;
                }
                /*int*/ let count = s.length;
                if (this._pos > (((this._chars.Length - count) | 0)))
                {
                    this.Grow(count);
                }
                /*int*/ let remaining = ((this._pos - index) | 0);
                this._chars.Slice$1(index, remaining).CopyTo(this._chars.Slice(((index + count) | 0)));
                $.$spc.System.String.CopyTo$1.call(s, this._chars.Slice(index));
                this._pos += count;
            }
            /*void */ Append(/*char*/ c)
            {
                /*int*/ let pos = this._pos;
                /*Span<char>*/ let chars = this._chars;
                if ((pos >>> 0) < (chars.Length >>> 0))
                {
                    chars.get_Item(pos).$v = c;
                    this._pos = ((pos + 1) | 0);
                }
                else 
                {
                    this.GrowAndAppend(c);
                }
            }
            /*void */ Append$1(/*string?*/ s)
            {
                if ($.$spc.System.String.op_Equality(s, null))
                {
                    return;
                }
                /*int*/ let pos = this._pos;
                if (s.length === 1 && (pos >>> 0) < (this._chars.Length >>> 0))
                {
                    this._chars.get_Item(pos).$v = $.$spc.System.String.get_Chars.call(s, 0);
                    this._pos = ((pos + 1) | 0);
                }
                else 
                {
                    this.AppendSlow(s);
                }
            }
            /*void */ AppendSlow(/*string*/ s)
            {
                /*int*/ let pos = this._pos;
                if (pos > ((this._chars.Length - s.length) | 0))
                {
                    this.Grow(s.length);
                }
                $.$spc.System.String.CopyTo$1.call(s, this._chars.Slice(pos));
                this._pos += s.length;
            }
            /*void */ Append$2(/*char*/ c, /*int*/ count)
            {
                if (this._pos > ((this._chars.Length - count) | 0))
                {
                    this.Grow(count);
                }
                /*Span<char>*/ let dst = this._chars.Slice$1(this._pos, count);
                for(/*int*/ let i = 0; i < dst.Length; i++)
                {
                    dst.get_Item(i).$v = c;
                }
                this._pos += count;
            }
            /*void */ Append$3(/*scoped ReadOnlySpan<char>*/ value)
            {
                /*int*/ let pos = this._pos;
                if (pos > ((this._chars.Length - value.Length) | 0))
                {
                    this.Grow(value.Length);
                }
                value.CopyTo(this._chars.Slice(this._pos));
                this._pos += value.Length;
            }
            /*Span<char> */ AppendSpan(/*int*/ length)
            {
                /*int*/ let origPos = this._pos;
                if (origPos > ((this._chars.Length - length) | 0))
                {
                    this.Grow(length);
                }
                this._pos = ((origPos + length) | 0);
                return this._chars.Slice$1(origPos, length);
            }
            /*void */ GrowAndAppend(/*char*/ c)
            {
                this.Grow(1);
                this.Append(c);
            }
            /*void */ Grow(/*int*/ additionalCapacityBeyondPos)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(additionalCapacityBeyondPos > 0, "additionalCapacityBeyondPos > 0");
                $.$spc.System.Diagnostics.Debug.Assert$1(this._pos > ((this._chars.Length - additionalCapacityBeyondPos) | 0), "Grow called incorrectly, no resize is needed.");
                /*uint*/ let ArrayMaxLength = 2147483591;
                /*int*/ let newCapacity = ($.$spc.System.Math.Max$10(((((this._pos + additionalCapacityBeyondPos) | 0)) >>> 0), $.$spc.System.Math.Min$10((((this._chars.Length >>> 0) * 2) >>> 0), ArrayMaxLength)) | 0);
                /*char[]*/ let poolArray = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Char).Shared.Rent(newCapacity);
                this._chars.Slice$1(0, this._pos).CopyTo($.$spc.System.Span$$($.$spc.System.Char).op_Implicit(poolArray));
                /*char[]?*/ let toReturn = this._arrayToReturnToPool;
                this._chars = $.$spc.System.Span$$($.$spc.System.Char).op_Implicit(this._arrayToReturnToPool = poolArray);
                if (toReturn !== null)
                {
                    $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Char).Shared.Return(toReturn, false);
                }
            }
            /*void */ Dispose()
            {
                /*char[]?*/ let toReturn = this._arrayToReturnToPool;
                new $.$swh.System.Text.ValueStringBuilder().Clone(this);
                if (toReturn !== null)
                {
                    $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Char).Shared.Return(toReturn, false);
                }
            }
            //default value type constructor
            $ctor$4()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._arrayToReturnToPool = this._arrayToReturnToPool;
                copy._chars = this._chars.Clone();
                copy._pos = this._pos;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._arrayToReturnToPool = null;
                this._chars = $.$default($.$spc.System.Span$$($.$spc.System.Char));
                this._pos = 0;
            }
            static $h = 320152;
            static $z = 14;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":655361,"g":{"r":0,"d":0,"h":34360058520,"f":1},"s":{"r":0,"d":0,"h":38655025816,"f":1},"n":"Length","d":320152,"h":30065091224,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":47244960408,"f":1},"n":"Capacity","d":320152,"h":42949993112,"f":1},{"p":458753,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":68719796888,"f":1},"n":"Item","o":"@$2","d":320152,"h":64424829592,"f":1},{"p":$.$spc.System.Span$$($.$spc.System.Char).$h,"g":{"r":0,"d":0,"h":81604698776,"f":1},"n":"RawChars","d":320152,"h":77309731480,"f":1}],"m":[{"r":65537,"p":[{"n":"value","p":(T) => T.$h},{"n":"format","p":1310721,"f":65},{"n":"provider","p":57671681,"f":65}],"g":["T"],"n":"AppendSpanFormattable","d":320152,"h":4295287448,"f":131080},{"r":65537,"p":[{"n":"capacity","p":655361}],"n":"EnsureCapacity","d":320152,"h":51539927704,"f":1},{"r":458753,"n":"GetPinnableReference","d":320152,"h":55834895000,"f":1},{"r":458753,"p":[{"n":"terminate","p":262145}],"n":"GetPinnableReference","o":"@$1","d":320152,"h":60129862296,"f":1},{"r":1310721,"n":"ToString","d":320152,"h":73014764184,"f":32769},{"r":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h,"p":[{"n":"terminate","p":262145}],"n":"AsSpan","d":320152,"h":85899666072,"f":1},{"r":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h,"n":"AsSpan","o":"@$1","d":320152,"h":90194633368,"f":1},{"r":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h,"p":[{"n":"start","p":655361}],"n":"AsSpan","o":"@$2","d":320152,"h":94489600664,"f":1},{"r":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h,"p":[{"n":"start","p":655361},{"n":"length","p":655361}],"n":"AsSpan","o":"@$3","d":320152,"h":98784567960,"f":1},{"r":262145,"p":[{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Char).$h},{"n":"charsWritten","p":655361,"f":2}],"n":"TryCopyTo","d":320152,"h":103079535256,"f":1},{"r":65537,"p":[{"n":"index","p":655361},{"n":"value","p":458753},{"n":"count","p":655361}],"n":"Insert","d":320152,"h":107374502552,"f":1},{"r":65537,"p":[{"n":"index","p":655361},{"n":"s","p":1310721}],"n":"Insert","o":"@$1","d":320152,"h":111669469848,"f":1},{"r":65537,"p":[{"n":"c","p":458753}],"n":"Append","d":320152,"h":115964437144,"f":1},{"r":65537,"p":[{"n":"s","p":1310721}],"n":"Append","o":"@$1","d":320152,"h":120259404440,"f":1},{"r":65537,"p":[{"n":"s","p":1310721}],"n":"AppendSlow","d":320152,"h":124554371736,"f":2},{"r":65537,"p":[{"n":"c","p":458753},{"n":"count","p":655361}],"n":"Append","o":"@$2","d":320152,"h":128849339032,"f":1},{"r":65537,"p":[{"n":"value","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h}],"n":"Append","o":"@$3","d":320152,"h":133144306328,"f":1},{"r":$.$spc.System.Span$$($.$spc.System.Char).$h,"p":[{"n":"length","p":655361}],"n":"AppendSpan","d":320152,"h":137439273624,"f":1},{"r":65537,"p":[{"n":"c","p":458753}],"n":"GrowAndAppend","d":320152,"h":141734240920,"f":2},{"r":65537,"p":[{"n":"additionalCapacityBeyondPos","p":655361}],"n":"Grow","d":320152,"h":146029208216,"f":2},{"r":65537,"n":"Dispose","d":320152,"h":150324175512,"f":1}],"l":[{"t":0,"n":"_arrayToReturnToPool","d":320152,"h":8590254744,"f":2},{"t":$.$spc.System.Span$$($.$spc.System.Char).$h,"n":"_chars","d":320152,"h":12885222040,"f":2},{"t":655361,"n":"_pos","d":320152,"h":17180189336,"f":2}],"c":[{"p":[{"n":"initialBuffer","p":$.$spc.System.Span$$($.$spc.System.Char).$h}],"n":".ctor","o":"$ctor$2","d":320152,"h":21475156632,"f":1},{"p":[{"n":"initialCapacity","p":655361}],"n":".ctor","o":"$ctor$3","d":320152,"h":25770123928,"f":1},{"n":".ctor","o":"$ctor$4","d":320152,"h":154619142808,"f":1}],"h":320152}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Text.ValueStringBuilder`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Threading", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized"))