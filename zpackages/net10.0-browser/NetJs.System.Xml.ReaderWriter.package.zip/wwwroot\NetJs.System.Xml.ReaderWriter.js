
(function ($global, $, $spc, $mwp, $sc, $sdt, $sm, $snv, $spu, $srei, $srel, $srp, $sri, $srl, $stee, $st, $sto, $stt, $sttp, $sr, $scc, $scn, $scm, $so, $srn, $ssc, $sris, $stc, $scp, $scsl, $sfa, $sic, $sim, $sl, $snp, $sspw, $srij, $scs, $sicb, $sci, $sdd, $sdts, $srm, $snnr, $sds, $sre, $sns, $sscr, $sle, $str, $snn, $snsc, $snq, $snh, $spx) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Xml.ReaderWriter", 
    {"h":43347,"f":"System.Xml.ReaderWriter","v":"1.0.35.0","a":[{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B760b8187d87d291733fdcda9f4d484d24d61a938","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Xml.ReaderWriter","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Xml.ReaderWriter","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Runtime.Loader", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Threading", "NetJs.System.Threading.Overlapped", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.Runtime.Numerics", "NetJs.System.Security.Claims", "NetJs.System.Runtime.InteropServices", "NetJs.System.Threading.Channels", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Console", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Linq", "NetJs.System.Net.Primitives", "NetJs.System.Security.Principal.Windows", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Collections.Specialized", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Collections.Immutable", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Reflection.Metadata", "NetJs.System.Net.NameResolution", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Reflection.Emit", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography", "NetJs.System.Linq.Expressions", "NetJs.System.Text.RegularExpressions", "NetJs.System.Net.NetworkInformation", "NetJs.System.Net.Security", "NetJs.System.Net.Quic", "NetJs.System.Net.Http", "NetJs.System.Private.Xml"))