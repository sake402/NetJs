
//--TRIMMABLE-BOUNDARY-START(61)
(async function () {
(function ($global, $, $$, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $spu, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl) {
    "use strict";
    let _;

    
    
    
	$.$asm(
    "NetJs.System.Xml.XPath.XDocument", 
    {
  "h": 61,
  "f": "System.Xml.XPath.XDocument",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B96771abe2820045936210554b19d0578b9bc2b1c",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "NetJs.System.Xml.XPath.XDocument",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "NetJs.System.Xml.XPath.XDocument",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160104449,
      "c": 4455071745,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(65597)
        $asm.$cls(`$sxxx.SXX.XDocumentExtensions`, ($self) => class XDocumentExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(131133)
            static $_XDocumentNavigable;
            static get XDocumentNavigable()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(131133);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$sxxx.SXX.XDocumentExtensions;
                return $cls.$_XDocumentNavigable ??= $asm.$ncls(`$sxxx.SXX.XDocumentExtensions.XDocumentNavigable`, ($self) => class XDocumentNavigable extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(4295098429)
                    /*XNode*/ _node = null;
                    //--TRIMMABLE-BOUNDARY-END(4295098429)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590065725)
                    $ctor$1(/*XNode*/ n)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8590065725);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._node = n;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590065725)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885033021)
                    /*XPathNavigator */ CreateNavigator()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12885033021);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return $.$spxl.SXX.Extensions.CreateNavigator$1(this._node);
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885033021)
                    
                    //--TRIMMABLE-BOUNDARY-START(4353556483)
                    //Generated interface implemetation for System.Xml.XPath.IXPathNavigable.CreateNavigator()
                    SXX$IXPathNavigable$CreateNavigator()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4353556483);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.CreateNavigator(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4353556483)
                    
                    static $h = 131133;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885033021),
    {
      "r": 59310083,
      "n": "CreateNavigator",
      "d": 131133,
      "h": 12885033021,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885033021)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295098429),
    {
      "t": 2228228,
      "n": "_node",
      "d": 131133,
      "h": 4295098429,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295098429)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590065725),
    {
      "p": [
        {
          "n": "n",
          "p": 2228228
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 131133,
      "h": 8590065725,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590065725)
  ],
  "d": 65597,
  "h": 131133
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spx.SXX.IXPathNavigable ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Xml.XPath.XDocumentExtensions+XDocumentNavigable`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Xml${separator}XPath${separator}XDocumentExtensions${separator}XDocumentNavigable`; }
                }, $cls, ($v) => $cls.$_XDocumentNavigable = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(131133)
            
            //--TRIMMABLE-BOUNDARY-START(4295032893)
            static /*IXPathNavigable */ ToXPathNavigable(/*this XNode*/ node)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295032893);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$sxxx.SXX.XDocumentExtensions.XDocumentNavigable().$ctor$1(node);
            }
            //--TRIMMABLE-BOUNDARY-END(4295032893)
            
            static $h = 65597;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295032893),
    {
      "r": 58589187,
      "p": [
        {
          "n": "node",
          "p": 2228228
        }
      ],
      "n": "ToXPathNavigable",
      "d": 65597,
      "h": 4295032893,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295032893)
  ],
  "h": 65597
}; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$sxxx.SXX.XDocumentExtensions.XDocumentNavigable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Xml.XPath.XDocumentExtensions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Xml${separator}XPath${separator}XDocumentExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65597)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq"));
})();
//--TRIMMABLE-BOUNDARY-END(61)
