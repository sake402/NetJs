
//--TRIMMABLE-BOUNDARY-START(61)
(function ($global, $, $$, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $spu, $sr, $sris, $sri, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Xml.XPath.XDocument", 
    {
  "h": 61,
  "f": "System.Xml.XPath.XDocument",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 159252481,
      "c": 13044154369,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106430465,
      "c": 8696365057,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106496001,
      "c": 8696430593,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 8696889345,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107085825,
      "c": 8697020417,
      "a": [
        {
          "v": "1.0.35\u002Bdf6f45b09d58f65c84d384efc8772929a0c6464b",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 8697872385,
      "a": [
        {
          "v": "NetJs.System.Xml.XPath.XDocument",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 8698003457,
      "a": [
        {
          "v": "NetJs.System.Xml.XPath.XDocument",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108199937,
      "c": 8698134529,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159318017,
      "c": 4454285313,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159055873,
      "c": 4454023169,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(65597)
        $asm.$cls("$sxxx.System.Xml.XPath.XDocumentExtensions", ($self) => class XDocumentExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(131133)
            static $_XDocumentNavigable;
            static get XDocumentNavigable()
            {
                let $cls = $.$sxxx.System.Xml.XPath.XDocumentExtensions;
                return $cls.$_XDocumentNavigable ??= $asm.$ncls("$sxxx.System.Xml.XPath.XDocumentExtensions.XDocumentNavigable", ($self) => class XDocumentNavigable extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(4295098429)
                    /*XNode*/ _node = null;
                    //--TRIMMABLE-BOUNDARY-END(4295098429)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590065725)
                    $ctor$1(/*XNode*/ n)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8590065725);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._node = n;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590065725)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885033021)
                    /*XPathNavigator */ CreateNavigator()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12885033021);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return $.$spxl.System.Xml.XPath.Extensions.CreateNavigator$1(this._node);
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885033021)
                    
                    //--TRIMMABLE-BOUNDARY-START(4353490947)
                    //Generated interface implemetation for System.Xml.XPath.IXPathNavigable.CreateNavigator()
                    System$Xml$XPath$IXPathNavigable$CreateNavigator()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4353490947);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.CreateNavigator(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4353490947)
                    
                    static $h = 131133;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885033021),
    {
      "r": 59244547,
      "n": "CreateNavigator",
      "d": 131133,
      "h": 12885033021,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885033021)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295098429),
    {
      "t": 2228228,
      "n": "_node",
      "d": 131133,
      "h": 4295098429,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295098429)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590065725),
    {
      "p": [
        {
          "n": "n",
          "p": 2228228
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 131133,
      "h": 8590065725,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590065725)
  ],
  "i": [58523651
  ],
  "d": 65597,
  "h": 131133
}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spx.System.Xml.XPath.IXPathNavigable ]; }
                    static get $fullName() { return `System.Xml.XPath.XDocumentExtensions.XDocumentNavigable`; }
                }, $cls, ($v) => $cls.$_XDocumentNavigable = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(131133)
            
            //--TRIMMABLE-BOUNDARY-START(8590000189)
            static /*IXPathNavigable */ ToXPathNavigable(/*this XNode*/ node)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590000189);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$sxxx.System.Xml.XPath.XDocumentExtensions.XDocumentNavigable().$ctor$1(node);
            }
            //--TRIMMABLE-BOUNDARY-END(8590000189)
            
            static $h = 65597;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590000189),
    {
      "r": 58523651,
      "p": [
        {
          "n": "node",
          "p": 2228228
        }
      ],
      "n": "ToXPathNavigable",
      "d": 65597,
      "h": 8590000189,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590000189)
  ],
  "j": [131133
  ],
  "h": 65597
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Xml.XPath.XDocumentExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65597)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq"))
//--TRIMMABLE-BOUNDARY-END(61)
