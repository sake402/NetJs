
(function ($global, $, $spc, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $spu, $sr, $sris, $sri, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Xml.XPath.XDocument", 
    {"h":65318,"f":"System.Xml.XPath.XDocument","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bf7a34a6f78fee11131301a9f55ca16a968616013","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Xml.XPath.XDocument","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Xml.XPath.XDocument","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sxxx.System.Xml.XPath.XDocumentExtensions", ($self) => class XDocumentExtensions
        {
            static $_XDocumentNavigable;
            static get XDocumentNavigable()
            {
                let $cls = $.$sxxx.System.Xml.XPath.XDocumentExtensions;
                return $cls.$_XDocumentNavigable ??= $asm.$ncls("$sxxx.System.Xml.XPath.XDocumentExtensions.XDocumentNavigable", ($self) => class XDocumentNavigable extends $.$spc.System.Object
                {
                    /*XNode*/ _node = null;
                    $ctor$1(/*XNode*/ n)
                    {
                        super.$ctor();
                        {
                            this._node = n;
                        }
                        return this;
                    }
                    /*XPathNavigator */ CreateNavigator()
                    {
                        return $.$spxl.System.Xml.XPath.Extensions.CreateNavigator(this._node);
                    }
                    //Generated interface implemetation for System.Xml.XPath.IXPathNavigable.CreateNavigator()
                    System$Xml$XPath$IXPathNavigable$CreateNavigator()
                    {
                        return this.CreateNavigator(...arguments);
                    }
                    static $h = 196390;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":59287709,"n":"CreateNavigator","d":196390,"h":12885098278,"f":1}],"l":[{"t":2279852,"n":"_node","d":196390,"h":4295163686,"f":2}],"c":[{"p":[{"n":"n","p":2279852}],"n":".ctor","o":"$ctor$1","d":196390,"h":8590130982,"f":1}],"i":[58566813],"d":130854,"h":196390}; }
                    static get $b() { return $.$spc.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spx.System.Xml.XPath.IXPathNavigable ]; }
                    static get $fullName() { return `System.Xml.XPath.XDocumentExtensions.XDocumentNavigable`; }
                }, $cls, ($v) => $cls.$_XDocumentNavigable = $v);
            }
            static /*IXPathNavigable */ ToXPathNavigable(/*this XNode*/ node)
            {
                return new $.$sxxx.System.Xml.XPath.XDocumentExtensions.XDocumentNavigable().$ctor$1(node);
            }
            static $h = 130854;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":58566813,"p":[{"n":"node","p":2279852}],"n":"ToXPathNavigable","d":130854,"h":8590065446,"f":33}],"j":[196390],"h":130854}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Xml.XPath.XDocumentExtensions`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq"))