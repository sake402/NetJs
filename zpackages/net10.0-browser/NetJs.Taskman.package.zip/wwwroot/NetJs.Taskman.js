
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sri, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mam, $mep, $meca, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mxdi, $sca, $meo, $meda, $meoc, $mxdg, $mela, $maa, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sipl, $stew, $stj, $mac, $mev, $srsp, $macf, $med, $mj, $macw, $mefa, $mef, $sifw, $mefp, $mecf, $mecj, $mel, $mjw, $macwa, $mc, $slq, $snhj, $stec, $swh, $sxx, $sxxx) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Taskman", 
    {"g":1,"h":38417,"f":"Taskman","v":"1.0.0.0","a":[{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"Taskman","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.0.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.0\u002B6779361f5261a44420e4641fa63588bbe7bcfaa8","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"Taskman","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"Taskman","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.0.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$t.I", ($self) => class ITaskService
        {
            static $h = 169489;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":133169153,"n":"SaveTask","o":"I$S","d":169489,"h":17180038673,"f":257},{"r":133169153,"n":"LoadTasks","o":"I$L","d":169489,"h":21475005969,"f":257},{"r":$.$$.SCG.L$$($.$t.A).$h,"n":"GetAll","o":"I$G","d":169489,"h":25769973265,"f":257},{"r":65537,"p":[{"n":"title","p":1310721},{"n":"priority","p":366097}],"n":"Add","o":"I$A","d":169489,"h":30064940561,"f":257},{"r":65537,"p":[{"n":"id","p":655361},{"n":"title","p":1310721},{"n":"priority","p":366097}],"n":"Edit","o":"I$E","d":169489,"h":34359907857,"f":257},{"r":65537,"p":[{"n":"title","p":1310721},{"n":"priority","p":366097}],"n":"MoveTask","o":"I$M","d":169489,"h":38654875153,"f":257},{"r":65537,"p":[{"n":"id","p":655361}],"n":"Delete","o":"I$D","d":169489,"h":42949842449,"f":257},{"r":65537,"n":"ClearAllTask","o":"I$C","d":169489,"h":47244809745,"f":257},{"r":133169153,"p":[{"n":"id","p":655361}],"n":"ToggleCompleted","o":"I$T","d":169489,"h":51539777041,"f":257},{"r":655361,"n":"GetCompletedCount","o":"I$GC","d":169489,"h":55834744337,"f":257},{"r":655361,"n":"GetPendingCount","o":"I$GP","d":169489,"h":60129711633,"f":257}],"e":[{"e":11730945,"m":{"r":65537,"p":[{"n":"value","p":11730945}],"n":"add_OnChange","o":"I$a","d":169489,"h":4295136785,"f":257},"r":{"r":65537,"p":[{"n":"value","p":11730945}],"n":"remove_OnChange","o":"I$r","d":169489,"h":8590104081,"f":257},"n":"OnChange","o":"ITaskService$O","d":169489,"h":12885071377,"f":257}],"h":169489}; }
            static get $fullName() { return `ITaskService`; }
        });
        
        $asm.$cls("$t.U", ($self) => class UserModel extends $.$$.S.O
        {
            /*string*/ FN = null;
            /*string*/ L = null;
            /*string*/ E$2 = null;
            /*DateTime?*/ D = null;
            /*string*/ U = null;
            /*string*/ P$1 = null;
            /*string*/ C = null;
            /*string*/ R$1 = null;
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.FN = "";
                this.L = "";
                this.E$2 = "";
                this.D = null;
                this.U = "";
                this.P$1 = "";
                this.C = "";
                this.R$1 = "";
            }
            static $h = 2201105;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12887102993,"f":1},"s":{"r":0,"d":0,"h":17182070289,"f":1},"n":"FirstName","o":"FN","d":2201105,"h":8592135697,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":30066972177,"f":1},"s":{"r":0,"d":0,"h":34361939473,"f":1},"n":"LastName","o":"L","d":2201105,"h":25772004881,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":47246841361,"f":1},"s":{"r":0,"d":0,"h":51541808657,"f":1},"n":"Email","o":"E$2","d":2201105,"h":42951874065,"f":1},{"p":$.$typeNullable($.$$.S.DT$1).$h,"g":{"r":0,"d":0,"h":64426710545,"f":1},"s":{"r":0,"d":0,"h":68721677841,"f":1},"n":"DateOfBirth","o":"D","d":2201105,"h":60131743249,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":81606579729,"f":1},"s":{"r":0,"d":0,"h":85901547025,"f":1},"n":"Username","o":"U","d":2201105,"h":77311612433,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":98786448913,"f":1},"s":{"r":0,"d":0,"h":103081416209,"f":1},"n":"Password","o":"P$1","d":2201105,"h":94491481617,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":115966318097,"f":1},"s":{"r":0,"d":0,"h":120261285393,"f":1},"n":"ConfirmPassword","o":"C","d":2201105,"h":111671350801,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":133146187281,"f":1},"s":{"r":0,"d":0,"h":137441154577,"f":1},"n":"Role","o":"R$1","d":2201105,"h":128851219985,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":2201105,"h":141736121873,"f":1}],"h":2201105}; }
            static get $b() { return $.$$.S.O; }
            static get $fullName() { return `UserModel`; }
        });
        
        $asm.$cls("$t.A", ($self) => class AppTask extends $.$$.S.O
        {
            /*int*/ Id = 0;
            /*string*/ T$1 = null;
            /*Priority*/ P$1 = 0;
            /*bool*/ IC = false;
            /*string*/ D = null;
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.T$1 = "";
                this.P$1 = 2;
                this.IC = false;
                this.D = "";
            }
            static $h = 103953;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885005841,"f":1},"s":{"r":0,"d":0,"h":17179973137,"f":1},"n":"Id","d":103953,"h":8590038545,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":30064875025,"f":1},"s":{"r":0,"d":0,"h":34359842321,"f":1},"n":"Title","o":"T$1","d":103953,"h":25769907729,"f":1},{"p":366097,"g":{"r":0,"d":0,"h":47244744209,"f":1},"s":{"r":0,"d":0,"h":51539711505,"f":1},"n":"Priority","o":"P$1","d":103953,"h":42949776913,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":64424613393,"f":1},"s":{"r":0,"d":0,"h":68719580689,"f":1},"n":"IsComplete","o":"IC","d":103953,"h":60129646097,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":81604482577,"f":1},"s":{"r":0,"d":0,"h":85899449873,"f":1},"n":"Date","o":"D","d":103953,"h":77309515281,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":103953,"h":90194417169,"f":1}],"h":103953}; }
            static get $b() { return $.$$.S.O; }
            static get $fullName() { return `AppTask`; }
        });
        
        $asm.$cls("$t.T._", ($self) => class _Imports extends $.$$.S.O
        {
            /*void */ E$2()
            {
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 497169;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"n":"Execute","o":"E$2","d":497169,"h":4295464465,"f":4}],"c":[{"n":".ctor","o":"$ctor$1","d":497169,"h":8590431761,"f":1}],"h":497169}; }
            static get $b() { return $.$$.S.O; }
            static get $fullName() { return `Taskman._Imports`; }
        });
        
        $asm.$cls("$t.TC._", ($self) => class _Imports extends $.$$.S.O
        {
            /*void */ E$2()
            {
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 628241;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"n":"Execute","o":"E$2","d":628241,"h":4295595537,"f":4}],"c":[{"n":".ctor","o":"$ctor$1","d":628241,"h":8590562833,"f":1}],"h":628241}; }
            static get $b() { return $.$$.S.O; }
            static get $fullName() { return `Taskman.Components._Imports`; }
        });
        
        $asm.$cls("$t.P", ($self) => class Program
        {
            static async $$$(args)
            {
                /*var*/ let builder = $.$macwa.MACWH.WAHB.CD(args);
                builder.RC.A$3($.$t.T.A, "#app");
                builder.RC.A$3($.$macw.MACW.HO, "head::after");
                $.$mxdi.MED.SC.AS$6($.$t.TS.A, builder.S$1);
                $.$mxdi.MED.SC.AS$4($.$t.I, $.$t.TS$1, builder.S$1);
                $.$mxdi.MED.SC.AS$5($.$snh.SNH.HC, builder.S$1, new ($.$$.S.F$$$($.$scm.S.I, $.$snh.SNH.HC))().$ctor(this,  (/*sp*/ sp) =>
                {
                    return (() =>
                    {
                        //new $.$snh.SNH.HC()
                        const $t1 = $.$snh.SNH.HC;
                        const $i1 = new $t1();
                        $i1.$ctor$3();
                        $i1.B = new $.$spu.S.U$1().$ctor$5(builder.H.MACWH$I$B);
                        return $i1;
                    })();
                }, {"r":6422573,"p":[{"n":"sp","p":327717}],"n":"","d":431633,"h":0,"f":1048578}));
                await builder.B().RA();
            }
            static $h = 431633;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":133169153,"p":[{"n":"args","p":0}],"n":"\u003CMain\u003E$","o":"$$$","d":431633,"h":4295398929,"f":4130}],"c":[{"n":".ctor","o":"$ctor$1","d":431633,"h":8590366225,"f":1}],"h":431633}; }
            static get $b() { return $.$$.S.O; }
            static get $fullName() { return `Program`; }
        });
        
        $asm.$cls("$t.TS.A", ($self) => class AuthService extends $.$$.S.O
        {
            /*IJSRuntime*/ JS = null;
            $ctor$1(/*IJSRuntime*/ jS)
            {
                super.$ctor();
                {
                    this.JS = jS;
                }
                return this;
            }
            /*bool*/ IL = false;
            /*string*/ U = null;
            /*string*/ R$1 = null;
            /*string*/ F$1 = null;
            /*string*/ L = null;
            /*string*/ E$2 = null;
            /*string*/ D = null;
            /*string*/ P$1 = null;
            /*string*/ C = null;
            /*bool*/ u = false;
            /*UserModel*/ n = null;
            /*List<UserModel>*/ _ = null;
            /*Action?*/ O = null;
            a(/*Action?*/ value)
            {
                this.O = $.$$.S.D$1.C$1(this.O, value);
            }
            r(/*Action?*/ value)
            {
                this.O = $.$$.S.D$1.R$1(this.O, value);
            }
            /*void */ N()
            {
                return (this.O?.I$1() ?? null);
            }
            /*List<UserModel>*/ u$1 = null;
            /*Task<string> *//*async*/  SU$1(/*string*/ firstname, /*string*/ lastname, /*string*/ email, /*string*/ role, /*DateTime?*/ dateOfBirth, /*string*/ username, /*string*/ password, /*string*/ confirmPassword)
            {
                return $.$$.N.AR.A($.$$.STT.T$1$$($.$$.S.S$1), $.$$.S.S$1, async () => 
                {
                    this.F$1 = firstname;
                    this.L = lastname;
                    this.E$2 = email;
                    this.D = (dateOfBirth?.TS$3("yyyy-MM-dd") ?? null) ?? "";
                    this.U = username;
                    this.P$1 = password;
                    this.C = confirmPassword;
                    this.R$1 = role;
                    if ($.$$.S.S$1.o_E(firstname, "") || $.$$.S.S$1.o_E(lastname, "") || $.$$.S.S$1.o_E(email, "") || $.$$.S.S$1.o_E(role, "") || dateOfBirth === null || $.$$.S.S$1.o_E(username, "") || $.$$.S.S$1.o_E(password, "") || $.$$.S.S$1.o_E(confirmPassword, ""))
                    {
                        if ($.$$.S.S$1.o_I(password, confirmPassword))
                        {
                            return "Passwords do not match.";
                        }
                        else 
                        {
                            return "Please fill all required entries.";
                        }
                    }
                    this.u = $.$sl.SL.E.A$4($.$t.U, this.u$1, new ($.$$.S.F$$$($.$t.U, $.$$.S.B$2))().$ctor(this,  (/*u*/ u) =>
                    {
                        return $.$$.S.S$1.E$5.call(u.U, username, 5/*StringComparison.OrdinalIgnoreCase*/);
                    }, {"r":262145,"p":[{"n":"u","p":2201105}],"n":"","d":2070033,"h":0,"f":1048578}));
                    if (this.u)
                    {
                        return "Username is already taken.";
                    }
                    this.n = (() =>
                    {
                        //new $.$t.U()
                        const $t1 = $.$t.U;
                        const $i1 = new $t1();
                        $i1.FN = firstname;
                        $i1.L = lastname;
                        $i1.E$2 = email;
                        $i1.D = dateOfBirth?.Clone() ?? null;
                        $i1.U = username;
                        $i1.P$1 = password;
                        $i1.R$1 = role;
                        return $i1;
                    })();
                    this.u$1.A(this.n);
                    await this.SU();
                    await this.LU();
                    this.N();
                    return "Success";
                });
            }
            /*bool */ L$1(/*string*/ username, /*string*/ password)
            {
                if ($.$$.S.S$1.INOW(username) || $.$$.S.S$1.INOW(password))
                {
                    this.IL = false;
                    return false;
                }
                /*var*/ let user = $.$sl.SL.E.FOD($.$t.U, this.u$1, new ($.$$.S.F$$$($.$t.U, $.$$.S.B$2))().$ctor(this,  (/*u*/ u) =>
                {
                    return $.$$.S.S$1.E$5.call(u.U, username, 5/*StringComparison.OrdinalIgnoreCase*/) && $.$$.S.S$1.o_E(u.P$1, password);
                }, {"r":262145,"p":[{"n":"u","p":2201105}],"n":"","d":2070033,"h":0,"f":1048578}));
                if (user === null)
                {
                    this.IL = false;
                    return false;
                }
                this.IL = true;
                this.U = user.U ?? "";
                this.R$1 = user.R$1 ?? "";
                this.F$1 = user.FN ?? "";
                this.L = user.L ?? "";
                this.E$2 = user.E$2 ?? "";
                this.D = (user.D?.TS$3("yyyy-MM-dd") ?? null) ?? "";
                this.N();
                return true;
            }
            /*void */ L$2()
            {
                this.IL = false;
                this.U = "";
                this.R$1 = "";
                this.F$1 = "";
                this.L = "";
                this.E$2 = "";
                this.D = "";
                this.N();
            }
            /*Task *//*async*/  SU()
            {
                return $.$$.N.AR.A($.$$.STT.T, $.$$.S.V$2, async () => 
                {
                    /*var*/ let jsonString = $.$stj.STJ.JS.S$14($.$$.SCG.L$$($.$t.U), this.u$1, null);
                    await $.$mj.MJ.JSE.IV(this.JS, "localStorage.setItem", $.$$.SRC.RH.CA($.$typeOf($.$$.S.O), [ "All_Users", jsonString ], null, null));
                });
            }
            /*bool*/ l = false;
            /*Task *//*async*/  LU()
            {
                return $.$$.N.AR.A($.$$.STT.T, $.$$.S.V$2, async () => 
                {
                    if (this.l)
                    {
                        return;
                    }
                    /*var*/ let jsonString = await $.$mj.MJ.JSE.IA($.$$.S.S$1, this.JS, "localStorage.getItem", $.$$.SRC.RH.CA($.$typeOf($.$$.S.O), [ "All_Users" ], null, null));
                    if (!$.$$.S.S$1.INO(jsonString))
                    {
                        /*var*/ let savedUsers = $.$stj.STJ.JS.D$30($.$$.SCG.L$$($.$t.U), jsonString, null);
                        if (savedUsers !== null)
                        {
                            this.u$1 = savedUsers;
                        }
                    }
                    this.l = true;
                });
            }
            /*Task *//*async*/  DA()
            {
                return $.$$.N.AR.A($.$$.STT.T, $.$$.S.V$2, async () => 
                {
                    if (!this.IL)
                    {
                        return;
                    }
                    /*var*/ let userToRemove = $.$sl.SL.E.FOD($.$t.U, this.u$1, new ($.$$.S.F$$$($.$t.U, $.$$.S.B$2))().$ctor(this,  (/*u*/ u) =>
                    {
                        return $.$$.S.S$1.E$5.call(u.U, this.U, 5/*StringComparison.OrdinalIgnoreCase*/);
                    }, {"r":262145,"p":[{"n":"u","p":2201105}],"n":"","d":2070033,"h":0,"f":1048578}));
                    if (userToRemove !== null)
                    {
                        this.u$1.R$1(userToRemove);
                    }
                    /*var*/ let jsonString = $.$stj.STJ.JS.S$14($.$$.SCG.L$$($.$t.U), this.u$1, null);
                    await $.$mj.MJ.JSE.IV(this.JS, "localStorage.setItem", $.$$.SRC.RH.CA($.$typeOf($.$$.S.O), [ "All_Users", jsonString ], null, null));
                    this.L$2();
                });
            }
            //default member initializer
            constructor()
            {
                super();
                this.IL = false;
                this.U = "";
                this.R$1 = "";
                this.F$1 = "";
                this.L = "";
                this.E$2 = "";
                this.D = "";
                this.P$1 = "";
                this.C = "";
                this.u = true;
                this._ = new ($.$$.SCG.L$$($.$t.U))().$ctor$1();
                this.u$1 = (() =>
                {
                    //new $.$$.SCG.L$$($.$t.U)()
                    const $t1 = $.$$.SCG.L$$($.$t.U);
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.A((() =>
                    {
                        //new $.$t.U()
                        const $t2 = $.$t.U;
                        const $i2 = new $t2();
                        $i2.U = "Olabode";
                        $i2.P$1 = "1234";
                        $i2.R$1 = "Admin";
                        $i2.E$2 = "benny@mail.com";
                        return $i2;
                    })());
                    $i1.A((() =>
                    {
                        //new $.$t.U()
                        const $t3 = $.$t.U;
                        const $i3 = new $t3();
                        $i3.U = "Benedicta";
                        $i3.P$1 = "2345";
                        $i3.R$1 = "Admin";
                        return $i3;
                    })());
                    $i1.A((() =>
                    {
                        //new $.$t.U()
                        const $t4 = $.$t.U;
                        const $i4 = new $t4();
                        $i4.U = "Blessing";
                        $i4.P$1 = "3456";
                        $i4.R$1 = "User";
                        return $i4;
                    })());
                    return $i1;
                })();
            }
            static $h = 2070033;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":21476906513,"f":1},"s":{"r":0,"d":0,"h":25771873809,"f":2},"n":"IsLoggedIn","o":"IL","d":2070033,"h":17181939217,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":38656775697,"f":1},"s":{"r":0,"d":0,"h":42951742993,"f":2},"n":"Username","o":"U","d":2070033,"h":34361808401,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":55836644881,"f":1},"s":{"r":0,"d":0,"h":60131612177,"f":2},"n":"Role","o":"R$1","d":2070033,"h":51541677585,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":73016514065,"f":1},"s":{"r":0,"d":0,"h":77311481361,"f":2},"n":"Firstname","o":"F$1","d":2070033,"h":68721546769,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":90196383249,"f":1},"s":{"r":0,"d":0,"h":94491350545,"f":2},"n":"Lastname","o":"L","d":2070033,"h":85901415953,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":107376252433,"f":1},"s":{"r":0,"d":0,"h":111671219729,"f":2},"n":"Email","o":"E$2","d":2070033,"h":103081285137,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":124556121617,"f":1},"s":{"r":0,"d":0,"h":128851088913,"f":2},"n":"DateOfBirth","o":"D","d":2070033,"h":120261154321,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":141735990801,"f":1},"s":{"r":0,"d":0,"h":146030958097,"f":2},"n":"Password1","o":"P$1","d":2070033,"h":137441023505,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":158915859985,"f":1},"s":{"r":0,"d":0,"h":163210827281,"f":2},"n":"ConfirmPassword","o":"C","d":2070033,"h":154620892689,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":176095729169,"f":1},"s":{"r":0,"d":0,"h":180390696465,"f":2},"n":"userExists","o":"u","d":2070033,"h":171800761873,"f":1},{"p":2201105,"g":{"r":0,"d":0,"h":193275598353,"f":1},"s":{"r":0,"d":0,"h":197570565649,"f":2},"n":"newUser","o":"n","d":2070033,"h":188980631057,"f":1}],"m":[{"r":65537,"n":"Notify","o":"N","d":2070033,"h":219045402129,"f":1},{"r":$.$$.STT.T$1$$($.$$.S.S$1).$h,"p":[{"n":"firstname","p":1310721},{"n":"lastname","p":1310721},{"n":"email","p":1310721},{"n":"role","p":1310721},{"n":"dateOfBirth","p":$.$typeNullable($.$$.S.DT$1).$h},{"n":"username","p":1310721},{"n":"password","p":1310721},{"n":"confirmPassword","p":1310721}],"n":"SignUp","o":"SU$1","d":2070033,"h":227635336721,"f":4097},{"r":262145,"p":[{"n":"username","p":1310721},{"n":"password","p":1310721}],"n":"Login","o":"L$1","d":2070033,"h":231930304017,"f":1},{"r":65537,"n":"Logout","o":"L$2","d":2070033,"h":236225271313,"f":1},{"r":133169153,"n":"SaveUser","o":"SU","d":2070033,"h":240520238609,"f":4097},{"r":133169153,"n":"LoadUsers","o":"LU","d":2070033,"h":249110173201,"f":4097},{"r":133169153,"n":"DeleteAccount","o":"DA","d":2070033,"h":253405140497,"f":4097}],"l":[{"t":524318,"n":"JS","d":2070033,"h":4297037329,"f":2},{"t":$.$$.SCG.L$$($.$t.U).$h,"n":"_user","o":"_","d":2070033,"h":201865532945,"f":1},{"t":$.$$.SCG.L$$($.$t.U).$h,"n":"users","o":"u$1","d":2070033,"h":223340369425,"f":2},{"t":262145,"n":"loaded","o":"l","d":2070033,"h":244815205905,"f":2}],"c":[{"p":[{"n":"jS","p":524318}],"n":".ctor","o":"$ctor$1","d":2070033,"h":8592004625,"f":1}],"e":[{"e":11730945,"m":{"r":65537,"p":[{"n":"value","p":11730945}],"n":"add_OnChange","o":"a","d":2070033,"h":206160500241,"f":1},"r":{"r":65537,"p":[{"n":"value","p":11730945}],"n":"remove_OnChange","o":"r","d":2070033,"h":210455467537,"f":1},"n":"OnChange","o":"O","d":2070033,"h":214750434833,"f":1}],"h":2070033}; }
            static get $b() { return $.$$.S.O; }
            static get $fullName() { return `Taskman.Services.AuthService`; }
        });
        
        $asm.$cls("$t.TS$1", ($self) => class TaskService extends $.$$.S.O
        {
            /*IJSRuntime*/ JS = null;
            $ctor$1(/*IJSRuntime*/ jS)
            {
                super.$ctor();
                {
                    this.JS = jS;
                }
                return this;
            }
            /*object*/ _ = null;
            /*AppTask*/ n = null;
            /*List<AppTask>*/ t$1 = null;
            /*Action?*/ O = null;
            a(/*Action?*/ value)
            {
                this.O = $.$$.S.D$1.C$1(this.O, value);
            }
            r(/*Action?*/ value)
            {
                this.O = $.$$.S.D$1.R$1(this.O, value);
            }
            /*void */ N()
            {
                return (this.O?.I$1() ?? null);
            }
            /*List<AppTask> */ GA()
            {
                //lock
                try
                {
                    $.$$.ST$1.M$1.E$3(this._)
                    {
                        return $.$sl.SL.E.TL$1($.$t.A, this.t$1);
                    }
                }
                finally
                {
                    $.$$.ST$1.M$1.E$4(this._)
                }
            }
            /*void */ A(/*string*/ title, /*Priority*/ priority)
            {
                //lock
                try
                {
                    $.$$.ST$1.M$1.E$3(this._)
                    {
                        this.n = (() =>
                        {
                            //new $.$t.A()
                            const $t1 = $.$t.A;
                            const $i1 = new $t1();
                            $i1.Id = $.$sl.SL.E.A$5($.$t.A, this.t$1) ? (($.$sl.SL.E.M$15($.$t.A, this.t$1, new ($.$$.S.F$$$($.$t.A, $.$$.S.I$4))().$ctor(this,  (/*t*/ t) =>
                            {
                                return t.Id;
                            }, {"r":655361,"p":[{"n":"t","p":103953}],"n":"","d":2135569,"h":0,"f":1048578})) + 1) | 0) : 1;
                            $i1.T$1 = title;
                            $i1.P$1 = priority;
                            $i1.D = $.$$.S.DT$1.N$1.TS$3("dd MMM yyyy");
                            $i1.IC = false;
                            return $i1;
                        })();
                        this.t$1.A(this.n);
                    }
                }
                finally
                {
                    $.$$.ST$1.M$1.E$4(this._)
                }
                this.N();
            }
            /*void */ E$2(/*int*/ id, /*string*/ title, /*Priority*/ priority)
            {
                //lock
                try
                {
                    $.$$.ST$1.M$1.E$3(this._)
                    {
                        /*var*/ let existingTask = $.$sl.SL.E.FOD($.$t.A, this.t$1, new ($.$$.S.F$$$($.$t.A, $.$$.S.B$2))().$ctor(this,  (/**/ t) =>
                        {
                            return t.Id === id;
                        }, {"r":262145,"p":[{"n":"t","p":103953}],"n":"","d":2135569,"h":0,"f":1048578}));
                        if (existingTask !== null)
                        {
                            existingTask.T$1 = title;
                            existingTask.P$1 = priority;
                        }
                    }
                }
                finally
                {
                    $.$$.ST$1.M$1.E$4(this._)
                }
                this.N();
            }
            /*void */ MT(/*string*/ title, /*Priority*/ priority)
            {
                //lock
                try
                {
                    $.$$.ST$1.M$1.E$3(this._)
                    {
                        this.n = (() =>
                        {
                            //new $.$t.A()
                            const $t1 = $.$t.A;
                            const $i1 = new $t1();
                            $i1.Id = $.$sl.SL.E.A$5($.$t.A, this.t$1) ? (($.$sl.SL.E.M$15($.$t.A, this.t$1, new ($.$$.S.F$$$($.$t.A, $.$$.S.I$4))().$ctor(this,  (/*t*/ t) =>
                            {
                                return t.Id;
                            }, {"r":655361,"p":[{"n":"t","p":103953}],"n":"","d":2135569,"h":0,"f":1048578})) + 1) | 0) : 1;
                            $i1.T$1 = title;
                            $i1.P$1 = priority;
                            $i1.D = $.$$.S.DT$1.N$1.TS$3("dd MMM yyyy");
                            $i1.IC = true;
                            return $i1;
                        })();
                        this.t$1.A(this.n);
                    }
                }
                finally
                {
                    $.$$.ST$1.M$1.E$4(this._)
                }
                this.N();
            }
            /*void */ D(/*int*/ id)
            {
                //lock
                try
                {
                    $.$$.ST$1.M$1.E$3(this._)
                    {
                        this.t$1.RA(new ($.$$.S.P$1$$($.$t.A))().$ctor(this,  (/*t*/ t) =>
                        {
                            return t.Id === id;
                        }, {"r":262145,"p":[{"n":"t","p":103953}],"n":"","d":2135569,"h":0,"f":1048578}));
                    }
                }
                finally
                {
                    $.$$.ST$1.M$1.E$4(this._)
                }
                this.N();
            }
            /*void */ C()
            {
                //lock
                try
                {
                    $.$$.ST$1.M$1.E$3(this._)
                    {
                        this.t$1.C$1();
                    }
                }
                finally
                {
                    $.$$.ST$1.M$1.E$4(this._)
                }
                this.N();
            }
            /*Task *//*async*/  ST()
            {
                return $.$$.N.AR.A($.$$.STT.T, $.$$.S.V$2, async () => 
                {
                    /*var*/ let jsonString = $.$stj.STJ.JS.S$14($.$$.SCG.L$$($.$t.A), this.t$1, null);
                    await $.$mj.MJ.JSE.IV(this.JS, "localStorage.setItem", $.$$.SRC.RH.CA($.$typeOf($.$$.S.O), [ "All_Tasks", jsonString ], null, null));
                });
            }
            /*Task *//*async*/  L()
            {
                return $.$$.N.AR.A($.$$.STT.T, $.$$.S.V$2, async () => 
                {
                    /*var*/ let jsonString = await $.$mj.MJ.JSE.IA($.$$.S.S$1, this.JS, "localStorage.getItem", $.$$.SRC.RH.CA($.$typeOf($.$$.S.O), [ "All_Tasks" ], null, null));
                    if (!$.$$.S.S$1.INOW(jsonString))
                    {
                        this.t$1 = $.$stj.STJ.JS.D$30($.$$.SCG.L$$($.$t.A), jsonString, null) ?? new ($.$$.SCG.L$$($.$t.A))().$ctor$1();
                    }
                    this.N();
                });
            }
            /*Task *//*async*/  TC(/*int*/ id)
            {
                return $.$$.N.AR.A($.$$.STT.T, $.$$.S.V$2, async () => 
                {
                    //lock
                    try
                    {
                        $.$$.ST$1.M$1.E$3(this._)
                        {
                            /*var*/ let task = $.$sl.SL.E.FOD($.$t.A, this.t$1, new ($.$$.S.F$$$($.$t.A, $.$$.S.B$2))().$ctor(this,  (/**/ t) =>
                            {
                                return t.Id === id;
                            }, {"r":262145,"p":[{"n":"t","p":103953}],"n":"","d":2135569,"h":0,"f":1048578}));
                            if (task !== null)
                            {
                                task.IC = !task.IC;
                            }
                        }
                    }
                    finally
                    {
                        $.$$.ST$1.M$1.E$4(this._)
                    }
                    await this.ST();
                    this.N();
                });
            }
            /*int */ GCC()
            {
                return $.$sl.SL.E.C$6($.$t.A, this.t$1, new ($.$$.S.F$$$($.$t.A, $.$$.S.B$2))().$ctor(this,  (/*t*/ t) =>
                {
                    return t.IC;
                }, {"r":262145,"p":[{"n":"t","p":103953}],"n":"","d":2135569,"h":0,"f":1048578}));
            }
            /*int */ GPC()
            {
                return $.$sl.SL.E.C$6($.$t.A, this.t$1, new ($.$$.S.F$$$($.$t.A, $.$$.S.B$2))().$ctor(this,  (/*t*/ t) =>
                {
                    return !t.IC;
                }, {"r":262145,"p":[{"n":"t","p":103953}],"n":"","d":2135569,"h":0,"f":1048578}));
            }
            //Generated interface implemetation for ITaskService.OnChange.add
            I$a()
            {
                return this.a(...arguments);
            }
            //Generated interface implemetation for ITaskService.OnChange.remove
            I$r()
            {
                return this.r(...arguments);
            }
            //Generated interface implemetation for ITaskService.OnChange
            ITaskService$O()
            {
                this.O;
            }
            //Generated interface implemetation for ITaskService.SaveTask()
            I$S()
            {
                return this.ST(...arguments);
            }
            //Generated interface implemetation for ITaskService.LoadTasks()
            I$L()
            {
                return this.L(...arguments);
            }
            //Generated interface implemetation for ITaskService.GetAll()
            I$G()
            {
                return this.GA(...arguments);
            }
            //Generated interface implemetation for ITaskService.Add(string, Priority)
            I$A()
            {
                return this.A(...arguments);
            }
            //Generated interface implemetation for ITaskService.Edit(int, string, Priority)
            I$E()
            {
                return this.E$2(...arguments);
            }
            //Generated interface implemetation for ITaskService.MoveTask(string, Priority)
            I$M()
            {
                return this.MT(...arguments);
            }
            //Generated interface implemetation for ITaskService.Delete(int)
            I$D()
            {
                return this.D(...arguments);
            }
            //Generated interface implemetation for ITaskService.ClearAllTask()
            I$C()
            {
                return this.C(...arguments);
            }
            //Generated interface implemetation for ITaskService.ToggleCompleted(int)
            I$T()
            {
                return this.TC(...arguments);
            }
            //Generated interface implemetation for ITaskService.GetCompletedCount()
            I$GC()
            {
                return this.GCC(...arguments);
            }
            //Generated interface implemetation for ITaskService.GetPendingCount()
            I$GP()
            {
                return this.GPC(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this._ = new $.$$.S.O().$ctor();
                this.n = new $.$t.A().$ctor$1();
                this.t$1 = new ($.$$.SCG.L$$($.$t.A))().$ctor$1();
            }
            static $h = 2135569;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"n":"Notify","o":"N","d":2135569,"h":38656841233,"f":1},{"r":$.$$.SCG.L$$($.$t.A).$h,"n":"GetAll","o":"GA","d":2135569,"h":42951808529,"f":1},{"r":65537,"p":[{"n":"title","p":1310721},{"n":"priority","p":366097}],"n":"Add","o":"A","d":2135569,"h":47246775825,"f":1},{"r":65537,"p":[{"n":"id","p":655361},{"n":"title","p":1310721},{"n":"priority","p":366097}],"n":"Edit","o":"E$2","d":2135569,"h":51541743121,"f":1},{"r":65537,"p":[{"n":"title","p":1310721},{"n":"priority","p":366097}],"n":"MoveTask","o":"MT","d":2135569,"h":55836710417,"f":1},{"r":65537,"p":[{"n":"id","p":655361}],"n":"Delete","o":"D","d":2135569,"h":60131677713,"f":1},{"r":65537,"n":"ClearAllTask","o":"C","d":2135569,"h":64426645009,"f":1},{"r":133169153,"n":"SaveTask","o":"ST","d":2135569,"h":68721612305,"f":4097},{"r":133169153,"n":"LoadTasks","o":"L","d":2135569,"h":73016579601,"f":4097},{"r":133169153,"p":[{"n":"id","p":655361}],"n":"ToggleCompleted","o":"TC","d":2135569,"h":77311546897,"f":4097},{"r":655361,"n":"GetCompletedCount","o":"GCC","d":2135569,"h":81606514193,"f":1},{"r":655361,"n":"GetPendingCount","o":"GPC","d":2135569,"h":85901481489,"f":1}],"l":[{"t":524318,"n":"JS","d":2135569,"h":4297102865,"f":2},{"t":131073,"n":"_lock","o":"_","d":2135569,"h":12887037457,"f":2},{"t":103953,"n":"newTask","o":"n","d":2135569,"h":17182004753,"f":1},{"t":$.$$.SCG.L$$($.$t.A).$h,"n":"tasks","o":"t$1","d":2135569,"h":21476972049,"f":1}],"c":[{"p":[{"n":"jS","p":524318}],"n":".ctor","o":"$ctor$1","d":2135569,"h":8592070161,"f":1}],"e":[{"e":11730945,"m":{"r":65537,"p":[{"n":"value","p":11730945}],"n":"add_OnChange","o":"a","d":2135569,"h":25771939345,"f":1},"r":{"r":65537,"p":[{"n":"value","p":11730945}],"n":"remove_OnChange","o":"r","d":2135569,"h":30066906641,"f":1},"n":"OnChange","o":"O","d":2135569,"h":34361873937,"f":1}],"i":[169489],"h":2135569}; }
            static get $b() { return $.$$.S.O; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$t.I ]; }
            static get $fullName() { return `TaskService`; }
        });
        
        $asm.$cls("$t.MC.E", ($self) => class EmbeddedAttribute extends $.$$.S.A$1
        {
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 235025;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"c":[{"n":".ctor","o":"$ctor$2","d":235025,"h":4295202321,"f":1}],"h":235025}; }
            static get $b() { return $.$$.S.A$1; }
            static get $fullName() { return `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
        });
        
        $asm.$cls("$t.MEVE.V", ($self) => class ValidatableTypeAttribute extends $.$$.S.A$1
        {
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 300561;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"c":[{"n":".ctor","o":"$ctor$2","d":300561,"h":4295267857,"f":1}],"h":300561,"a":[{"t":235025,"c":4295202321},{"t":14745601,"c":21489582081,"a":[{"v":4,"t":14680065}]}]}; }
            static get $b() { return $.$$.S.A$1; }
            static get $fullName() { return `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
        });
        
        $asm.$cls("$t.TC.NF", ($self) => class NotFound extends $.$mac.MAC.CB
        {
            /*void */ B(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.AM(0, "<h3>Not Found</h3>\n");
                __builder.AM(1, "<p>Sorry, the content you are looking for does not exist.</p>");
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 1086993;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","o":"B","d":1086993,"h":4296054289,"f":32772}],"c":[{"n":".ctor","o":"$ctor$2","d":1086993,"h":8591021585,"f":1}],"i":[2752520,3145736,3080200],"h":1086993,"a":[{"t":4587528,"c":4299554824,"a":[{"v":1873425,"t":142475265}]},{"t":9895944,"c":4304863240,"a":[{"v":"/not-found","t":1310721}]}]}; }
            static get $b() { return $.$mac.MAC.CB; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IC, $.$mac.MAC.IHE, $.$mac.MAC.IH ]; }
            static get $fullName() { return `Taskman.Components.NotFound`; }
        });
        
        $asm.$cls("$t.TC.L", ($self) => class LoadingCardMajor extends $.$mac.MAC.CB
        {
            /*void */ B(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.AM(0, "<div style=\"margin-bottom: 20px;\"><div style=\"width: 100%; height: 30px; border-radius: 20px; background: rgb(127, 127, 127, 0.2); margin-bottom: 5px;\"></div>\n    <div style=\"width: 100%; height: 30px; border-radius: 20px; background: rgb(127, 127, 127, 0.2); margin-bottom: 5px;\"></div>\n    <div style=\"width: 100%; height: 30px; border-radius: 20px; background: rgb(127, 127, 127, 0.2); margin-bottom: 5px;\"></div>\n    <div style=\"width: 100%; height: 30px; border-radius: 20px; background: rgb(127, 127, 127, 0.2); margin-bottom: 5px;\"></div>\n    <div style=\"width: 100%; height: 30px; border-radius: 20px; background: rgb(127, 127, 127, 0.2); margin-bottom: 5px;\"></div>\n    <div style=\"width: 100%; height: 30px; border-radius: 20px; background: rgb(127, 127, 127, 0.2); margin-bottom: 5px;\"></div>\n    <div style=\"width: 100%; height: 30px; border-radius: 20px; background: rgb(127, 127, 127, 0.2);\"></div></div>\n");
                __builder.OE(1, "p");
                __builder.AC$3(2, this.L);
                __builder.CE();
            }
            /*string*/ L = null;
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.L = "";
            }
            static $h = 890385;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17180759569,"f":1},"s":{"r":0,"d":0,"h":21475726865,"f":1},"n":"LoadingState","o":"L","d":890385,"h":12885792273,"f":1,"a":[{"t":5636104,"c":21480472584}]}],"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","o":"B","d":890385,"h":4295857681,"f":32772}],"c":[{"n":".ctor","o":"$ctor$2","d":890385,"h":25770694161,"f":1}],"i":[2752520,3145736,3080200],"h":890385}; }
            static get $b() { return $.$mac.MAC.CB; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IC, $.$mac.MAC.IHE, $.$mac.MAC.IH ]; }
            static get $fullName() { return `Taskman.Components.LoadingCardMajor`; }
        });
        
        $asm.$cls("$t.TC.LC", ($self) => class LoadingCardMinor extends $.$mac.MAC.CB
        {
            /*void */ B(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OE(0, "div");
                __builder.AA$2(1, "style", "margin-bottom: 20px;");
                __builder.AM(2, "<div style=\"width: 100%; margin: 20px 0 0; align-items: center; justify-content: center; margin-bottom: 50px;\"><div style=\"margin-bottom: 0;\"><div style=\"width: 100%; height: 30px; border-radius: 20px; background: rgb(127, 127, 127, 0.2); margin-bottom: 5px;\"></div>\n            <div style=\"width: 100%; height: 30px; border-radius: 20px; background: rgb(127, 127, 127, 0.2); margin-bottom: 5px;\"></div>\n            <div style=\"width: 100%; height: 30px; border-radius: 20px; background: rgb(127, 127, 127, 0.2);\"></div></div></div>\n    ");
                __builder.OE(3, "p");
                __builder.AC$3(4, this.L);
                __builder.CE();
                __builder.CE();
            }
            /*string*/ L = null;
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.L = "";
            }
            static $h = 955921;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17180825105,"f":1},"s":{"r":0,"d":0,"h":21475792401,"f":1},"n":"LoadingState","o":"L","d":955921,"h":12885857809,"f":1,"a":[{"t":5636104,"c":21480472584}]}],"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","o":"B","d":955921,"h":4295923217,"f":32772}],"c":[{"n":".ctor","o":"$ctor$2","d":955921,"h":25770759697,"f":1}],"i":[2752520,3145736,3080200],"h":955921}; }
            static get $b() { return $.$mac.MAC.CB; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IC, $.$mac.MAC.IHE, $.$mac.MAC.IH ]; }
            static get $fullName() { return `Taskman.Components.LoadingCardMinor`; }
        });
        
        $asm.$cls("$t.TC.B", ($self) => class ButtonCard extends $.$mac.MAC.CB
        {
            /*void */ B(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OE(0, "button");
                __builder.AA$6($.$macw.MACW.ME, 1, "onclick", $.$mac.MAC.EC$1.F$1.C$7($.$macw.MACW.ME, this, new ($.$$.S.F$$($.$$.STT.T))().$ctor(this, this.H)));
                __builder.AA$2(2, "style", "background:" + " " + (this.BC) + ";" + " padding:" + " 10px" + " 20px;" + " border:" + " none;" + " border-radius:" + " 10px;");
                __builder.AC$3(3, this.BT);
                __builder.CE();
            }
            /*bool*/ CC = false;
            /*string*/ BC = null;
            /*string*/ BT = null;
            /*EventCallback*/ OC;
            /*Task *//*async*/  H()
            {
                return $.$$.N.AR.A($.$$.STT.T, $.$$.S.V$2, async () => 
                {
                    await this.OC.IA();
                });
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.CC = false;
                this.BC = "";
                this.BT = "";
                this.OC = $.$default($.$mac.MAC.EC$1);
            }
            static $h = 693777;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17180562961,"f":1},"s":{"r":0,"d":0,"h":21475530257,"f":1},"n":"ConfirmClear","o":"CC","d":693777,"h":12885595665,"f":1,"a":[{"t":5636104,"c":21480472584}]},{"p":1310721,"g":{"r":0,"d":0,"h":34360432145,"f":1},"s":{"r":0,"d":0,"h":38655399441,"f":1},"n":"BgColor","o":"BC","d":693777,"h":30065464849,"f":1,"a":[{"t":5636104,"c":21480472584}]},{"p":1310721,"g":{"r":0,"d":0,"h":51540301329,"f":1},"s":{"r":0,"d":0,"h":55835268625,"f":1},"n":"BtnText","o":"BT","d":693777,"h":47245334033,"f":1,"a":[{"t":5636104,"c":21480472584}]},{"p":2097160,"g":{"r":0,"d":0,"h":68720170513,"f":1},"s":{"r":0,"d":0,"h":73015137809,"f":1},"n":"OnClick","o":"OC","d":693777,"h":64425203217,"f":1,"a":[{"t":5636104,"c":21480472584}]}],"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","o":"B","d":693777,"h":4295661073,"f":32772},{"r":133169153,"n":"HandleClick","o":"H","d":693777,"h":77310105105,"f":4098}],"c":[{"n":".ctor","o":"$ctor$2","d":693777,"h":81605072401,"f":1}],"i":[2752520,3145736,3080200],"h":693777}; }
            static get $b() { return $.$mac.MAC.CB; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IC, $.$mac.MAC.IHE, $.$mac.MAC.IH ]; }
            static get $fullName() { return `Taskman.Components.ButtonCard`; }
        });
        
        $asm.$cls("$t.TL.R", ($self) => class ReconnectModal extends $.$mac.MAC.CB
        {
            /*void */ B(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OE(0, "script");
                __builder.AA$2(1, "type", "module");
                __builder.AA$2(2, "src", this.A.g_I$1("Components/Layout/ReconnectModal.razor.js"));
                __builder.AA$4(3, "b-0qeclx541a");
                __builder.CE();
                __builder.AM(4, "\n\n");
                __builder.AM(5, "<dialog id=\"components-reconnect-modal\" data-nosnippet b-0qeclx541a><div class=\"components-reconnect-container\" b-0qeclx541a><div class=\"components-rejoining-animation\" aria-hidden=\"true\" b-0qeclx541a><div b-0qeclx541a></div>\n            <div b-0qeclx541a></div></div>\n        <p class=\"components-reconnect-first-attempt-visible\" b-0qeclx541a>\n            Rejoining the server...\n        </p>\n        <p class=\"components-reconnect-repeated-attempt-visible\" b-0qeclx541a>\n            Rejoin failed... trying again in <span id=\"components-seconds-to-next-attempt\" b-0qeclx541a></span> seconds.\n        </p>\n        <p class=\"components-reconnect-failed-visible\" b-0qeclx541a>\n            Failed to rejoin.<br b-0qeclx541a>Please retry or reload the page.\n        </p>\n        <button id=\"components-reconnect-button\" class=\"components-reconnect-failed-visible\" b-0qeclx541a>\n            Retry\n        </button>\n        <p class=\"components-pause-visible\" b-0qeclx541a>\n            The session has been paused by the server.\n        </p>\n        <button id=\"components-resume-button\" class=\"components-pause-visible\" b-0qeclx541a>\n            Resume\n        </button>\n        <p class=\"components-resume-failed-visible\" b-0qeclx541a>\n            Failed to resume the session.<br b-0qeclx541a>Please reload the page.\n        </p></div></dialog>");
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 2004497;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","o":"B","d":2004497,"h":4296971793,"f":32772}],"c":[{"n":".ctor","o":"$ctor$2","d":2004497,"h":8591939089,"f":1}],"i":[2752520,3145736,3080200],"h":2004497}; }
            static get $b() { return $.$mac.MAC.CB; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IC, $.$mac.MAC.IHE, $.$mac.MAC.IH ]; }
            static get $fullName() { return `Taskman.Layout.ReconnectModal`; }
        });
        
        $asm.$cls("$t.TC.S", ($self) => class SignUpSuccess extends $.$mac.MAC.CB
        {
            /*void */ B(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                if (this.iL)
                {
                    __builder.OE(0, "div");
                    __builder.AA$2(1, "style", "display: flex;; width: 100%; height: 100vh; align-items: center; justify-content: center; font-size: 30px;");
                    __builder.OC($.$t.TC.L, 2);
                    __builder.AC(3, "LoadingState", "\u23F3 creating user account...");
                    __builder.CC();
                    __builder.CE();
                }
                else 
                {
                    __builder.OE(4, "div");
                    __builder.AA$2(5, "style", "display: flex;; width: 100%; height: 100vh; align-items: center; justify-content: center;");
                    __builder.OC($.$t.TC.NL, 6);
                    __builder.AC(7, "Title", "Account created successful...");
                    __builder.AC(8, "SubTitle", "Continue to login...");
                    __builder.CC();
                    __builder.CE();
                }
            }
            /*bool*/ iL = true;
            /*Task *//*async*/  OIA()
            {
                return $.$$.N.AR.A($.$$.STT.T, $.$$.S.V$2, async () => 
                {
                    this.iL = true;
                    await $.$$.STT.T.D$2(4000);
                    this.iL = false;
                });
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 1676817;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","o":"B","d":1676817,"h":4296644113,"f":32772},{"r":133169153,"n":"OnInitializedAsync","o":"OIA","d":1676817,"h":12886578705,"f":36868}],"l":[{"t":262145,"n":"isLoading","o":"iL","d":1676817,"h":8591611409,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":1676817,"h":17181546001,"f":1}],"i":[2752520,3145736,3080200],"h":1676817,"a":[{"t":9895944,"c":4304863240,"a":[{"v":"/signupsuccess","t":1310721}]}]}; }
            static get $b() { return $.$mac.MAC.CB; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IC, $.$mac.MAC.IHE, $.$mac.MAC.IH ]; }
            static get $fullName() { return `Taskman.Components.SignUpSuccess`; }
        });
        
        $asm.$cls("$t.TC.C", ($self) => class Confirm extends $.$mac.MAC.CB
        {
            /*void */ B(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OE(0, "div");
                __builder.AA$2(1, "class", "notify");
                __builder.AA$4(2, "b-nc8ags17cu");
                __builder.OE(3, "div");
                __builder.AA$2(4, "class", "notify-in slide-in-left");
                __builder.AA$4(5, "b-nc8ags17cu");
                __builder.OE(6, "div");
                __builder.AA$2(7, "class", "notify-inner");
                __builder.AA$4(8, "b-nc8ags17cu");
                __builder.OE(9, "p");
                __builder.AA$2(10, "style", "padding: 20px;");
                __builder.AA$4(11, "b-nc8ags17cu");
                __builder.AC$3(12, this.T$3);
                __builder.CE();
                __builder.AM(13, "\n            ");
                __builder.OE(14, "div");
                __builder.AA$2(15, "style", "display: flex; justify-content: space-around; padding: 20px;");
                __builder.AA$4(16, "b-nc8ags17cu");
                __builder.OE(17, "button");
                __builder.AA$2(18, "style", "background: rgb(135, 0, 135, 0.3); padding: 10px 20px; border: none; border-radius: 10px; margin-right:20px");
                __builder.AA$6($.$macw.MACW.ME, 19, "onclick", $.$mac.MAC.EC$1.F$1.C$7($.$macw.MACW.ME, this, new ($.$$.S.F$$($.$$.STT.T))().$ctor(this, this.HC)));
                __builder.AA$4(20, "b-nc8ags17cu");
                __builder.AC$3(21, this.T$1);
                __builder.CE();
                __builder.AM(22, "\n                ");
                __builder.OE(23, "button");
                __builder.AA$2(24, "style", "background: rgb(131, 131, 131, 0.3); padding: 10px 20px; border: none; border-radius: 10px;");
                __builder.AA$6($.$macw.MACW.ME, 25, "onclick", $.$mac.MAC.EC$1.F$1.C$7($.$macw.MACW.ME, this, new ($.$$.S.F$$($.$$.STT.T))().$ctor(this, this.H)));
                __builder.AA$4(26, "b-nc8ags17cu");
                __builder.AC$3(27, this.T$2);
                __builder.CE();
                __builder.CE();
                __builder.CE();
                __builder.CE();
                __builder.CE();
            }
            /*string*/ T$3 = null;
            /*string*/ T$1 = null;
            /*string*/ T$2 = null;
            /*EventCallback*/ CB$1;
            /*EventCallback*/ CB;
            /*Task *//*async*/  HC()
            {
                return $.$$.N.AR.A($.$$.STT.T, $.$$.S.V$2, async () => 
                {
                    await this.CB$1.IA();
                });
            }
            /*Task *//*async*/  H()
            {
                return $.$$.N.AR.A($.$$.STT.T, $.$$.S.V$2, async () => 
                {
                    await this.CB.IA();
                });
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.T$3 = "";
                this.T$1 = "";
                this.T$2 = "";
                this.CB$1 = $.$default($.$mac.MAC.EC$1);
                this.CB = $.$default($.$mac.MAC.EC$1);
            }
            static $h = 759313;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17180628497,"f":1},"s":{"r":0,"d":0,"h":21475595793,"f":1},"n":"Title","o":"T$3","d":759313,"h":12885661201,"f":1,"a":[{"t":5636104,"c":21480472584}]},{"p":1310721,"g":{"r":0,"d":0,"h":34360497681,"f":1},"s":{"r":0,"d":0,"h":38655464977,"f":1},"n":"Text1","o":"T$1","d":759313,"h":30065530385,"f":1,"a":[{"t":5636104,"c":21480472584}]},{"p":1310721,"g":{"r":0,"d":0,"h":51540366865,"f":1},"s":{"r":0,"d":0,"h":55835334161,"f":1},"n":"Text2","o":"T$2","d":759313,"h":47245399569,"f":1,"a":[{"t":5636104,"c":21480472584}]},{"p":2097160,"g":{"r":0,"d":0,"h":68720236049,"f":1},"s":{"r":0,"d":0,"h":73015203345,"f":1},"n":"ConfirmBtn","o":"CB$1","d":759313,"h":64425268753,"f":1,"a":[{"t":5636104,"c":21480472584}]},{"p":2097160,"g":{"r":0,"d":0,"h":85900105233,"f":1},"s":{"r":0,"d":0,"h":90195072529,"f":1},"n":"CancelBtn","o":"CB","d":759313,"h":81605137937,"f":1,"a":[{"t":5636104,"c":21480472584}]}],"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","o":"B","d":759313,"h":4295726609,"f":32772},{"r":133169153,"n":"HandleConfirm","o":"HC","d":759313,"h":94490039825,"f":4098},{"r":133169153,"n":"HandleCancel","o":"H","d":759313,"h":98785007121,"f":4098}],"c":[{"n":".ctor","o":"$ctor$2","d":759313,"h":103079974417,"f":1}],"i":[2752520,3145736,3080200],"h":759313}; }
            static get $b() { return $.$mac.MAC.CB; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IC, $.$mac.MAC.IHE, $.$mac.MAC.IH ]; }
            static get $fullName() { return `Taskman.Components.Confirm`; }
        });
        
        $asm.$cls("$t.TC.NL", ($self) => class NotLoginCard extends $.$mac.MAC.CB
        {
            /*void */ B(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OE(0, "div");
                __builder.AA$2(1, "style", "width: 100%; height: 30vh; font-size: 20px; display: flex; align-items: center; justify-content: center; text-align: center;");
                __builder.OE(2, "div");
                __builder.OE(3, "p");
                __builder.AC$3(4, this.T$1);
                __builder.CE();
                __builder.AM(5, "\n        ");
                __builder.OE(6, "p");
                __builder.OC($.$macw.MACR$2.NL$1, 7);
                __builder.AC(8, "style", "text-decoration: none; color: white; background: rgb(133, 0, 133, 0.3); padding: 10px 20px; border-radius: 10px; font-weight: bold; font-size: 15px;");
                __builder.AC(9, "href", "");
                __builder.AC(10, "Match", $.$box($.$mac.MACC.R.TC($.$macw.MACR$2.NLM, 1/*NavLinkMatch.All*/), $.$macw.MACR$2.NLM));
                __builder.AA(11, "ChildContent", new $.$mac.MAC.RF().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.AM(12, "\uD83D\uDEAA Login");
                })));
                __builder.CC();
                __builder.AM(13, "\n            ");
                __builder.AC$3(14, this.ST);
                __builder.CE();
                __builder.CE();
                __builder.CE();
            }
            /*string*/ T$1 = null;
            /*string*/ ST = null;
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.T$1 = "";
                this.ST = "";
            }
            static $h = 1152529;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17181021713,"f":1},"s":{"r":0,"d":0,"h":21475989009,"f":1},"n":"Title","o":"T$1","d":1152529,"h":12886054417,"f":1,"a":[{"t":5636104,"c":21480472584}]},{"p":1310721,"g":{"r":0,"d":0,"h":34360890897,"f":1},"s":{"r":0,"d":0,"h":38655858193,"f":1},"n":"SubTitle","o":"ST","d":1152529,"h":30065923601,"f":1,"a":[{"t":5636104,"c":21480472584}]}],"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","o":"B","d":1152529,"h":4296119825,"f":32772}],"c":[{"n":".ctor","o":"$ctor$2","d":1152529,"h":42950825489,"f":1}],"i":[2752520,3145736,3080200],"h":1152529}; }
            static get $b() { return $.$mac.MAC.CB; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IC, $.$mac.MAC.IHE, $.$mac.MAC.IH ]; }
            static get $fullName() { return `Taskman.Components.NotLoginCard`; }
        });
        
        $asm.$cls("$t.T.A", ($self) => class App extends $.$mac.MAC.CB
        {
            /*void */ B(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OC($.$mac.MACR$3.R$1, 0);
                __builder.AC(1, "AppAssembly", $.$mac.MACC.R.TC($.$$.SR.A, $.$t.T.A.$type.A));
                __builder.AC(2, "PreferExactMatches", $.$box(true, $.$$.S.B$2));
                __builder.AC(3, "NotFoundPage", $.$mac.MACC.R.TC($.$$.S.T$2, $.$t.TC.NF.$type));
                __builder.AA(4, "Found", new ($.$mac.MAC.R$$($.$mac.MAC.RD))().$ctor(this, ( (/*routeData*/ routeData) =>
                {
                    return new $.$mac.MAC.RF().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OC($.$mac.MAC.RV, 5);
                        __builder2.AC(6, "RouteData", $.$mac.MACC.R.TC($.$mac.MAC.RD, routeData));
                        __builder2.AC(7, "DefaultLayout", $.$mac.MACC.R.TC($.$$.S.T$2, $.$t.TL.M.$type));
                        __builder2.CC();
                        __builder2.AM(8, "\n        ");
                        __builder2.OC($.$macw.MACR$2.F, 9);
                        __builder2.AC(10, "RouteData", $.$mac.MACC.R.TC($.$mac.MAC.RD, routeData));
                        __builder2.AC(11, "Selector", "h1");
                        __builder2.CC();
                    }, {"r":65537,"p":[{"n":"__builder2","p":7536648}],"n":"","d":562705,"h":0,"f":1048578});
                })));
                __builder.CC();
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 562705;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","o":"B","d":562705,"h":4295530001,"f":32772}],"c":[{"n":".ctor","o":"$ctor$2","d":562705,"h":8590497297,"f":1}],"i":[2752520,3145736,3080200],"h":562705}; }
            static get $b() { return $.$mac.MAC.CB; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IC, $.$mac.MAC.IHE, $.$mac.MAC.IH ]; }
            static get $fullName() { return `Taskman.App`; }
        });
        
        $asm.$cls("$t.TC.D", ($self) => class DeleteAccountPage extends $.$mac.MAC.CB
        {
            /*void */ B(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                if (this.iL)
                {
                    __builder.OE(0, "div");
                    __builder.AA$2(1, "style", "display: flex;; width: 100%; height: 100vh; align-items: center; justify-content: center; font-size: 30px;");
                    __builder.OC($.$t.TC.L, 2);
                    __builder.AC(3, "LoadingState", "\u23F3 deleting user account...");
                    __builder.CC();
                    __builder.CE();
                }
                else 
                {
                    __builder.OE(4, "div");
                    __builder.AA$2(5, "style", "display: flex;; width: 100%; height: 100vh; align-items: center; justify-content: center;");
                    __builder.OC($.$t.TC.NL, 6);
                    __builder.AC(7, "Title", "Account deleted successful...");
                    __builder.AC(8, "SubTitle", "Click to login...");
                    __builder.CC();
                    __builder.CE();
                }
            }
            /*bool*/ iL = true;
            /*Task *//*async*/  OIA()
            {
                return $.$$.N.AR.A($.$$.STT.T, $.$$.S.V$2, async () => 
                {
                    this.iL = true;
                    await $.$$.STT.T.D$2(4000);
                    this.iL = false;
                });
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 824849;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","o":"B","d":824849,"h":4295792145,"f":32772},{"r":133169153,"n":"OnInitializedAsync","o":"OIA","d":824849,"h":12885726737,"f":36868}],"l":[{"t":262145,"n":"isLoading","o":"iL","d":824849,"h":8590759441,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":824849,"h":17180694033,"f":1}],"i":[2752520,3145736,3080200],"h":824849,"a":[{"t":9895944,"c":4304863240,"a":[{"v":"/deleteacc","t":1310721}]}]}; }
            static get $b() { return $.$mac.MAC.CB; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IC, $.$mac.MAC.IHE, $.$mac.MAC.IH ]; }
            static get $fullName() { return `Taskman.Components.DeleteAccountPage`; }
        });
        
        $asm.$cls("$t.TC.R", ($self) => class Routes extends $.$mac.MAC.CB
        {
            /*void */ B(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OC($.$mac.MACR$3.R$1, 0);
                __builder.AC(1, "AppAssembly", $.$mac.MACC.R.TC($.$$.SR.A, $.$t.P.$type.A));
                __builder.AC(2, "NotFoundPage", $.$mac.MACC.R.TC($.$$.S.T$2, $.$t.TC.NF.$type));
                __builder.AA(3, "Found", new ($.$mac.MAC.R$$($.$mac.MAC.RD))().$ctor(this, ( (/*routeData*/ routeData) =>
                {
                    return new $.$mac.MAC.RF().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OC($.$mac.MAC.RV, 4);
                        __builder2.AC(5, "RouteData", $.$mac.MACC.R.TC($.$mac.MAC.RD, routeData));
                        __builder2.AC(6, "DefaultLayout", $.$mac.MACC.R.TC($.$$.S.T$2, $.$t.TL.M.$type));
                        __builder2.CC();
                        __builder2.AM(7, "\n        ");
                        __builder2.OC($.$macw.MACR$2.F, 8);
                        __builder2.AC(9, "RouteData", $.$mac.MACC.R.TC($.$mac.MAC.RD, routeData));
                        __builder2.AC(10, "Selector", "h1");
                        __builder2.CC();
                    }, {"r":65537,"p":[{"n":"__builder2","p":7536648}],"n":"","d":1545745,"h":0,"f":1048578});
                })));
                __builder.CC();
            }
            static $___;
            static get __()
            {
                let $cls = $.$t.TC.R;
                return $cls.$___ ??= $asm.$ncls("$t.TC.R.__", ($self) => class __PrivateComponentRenderModeAttribute extends $.$mac.MAC.RM
                {
                    static /*global::Microsoft.AspNetCore.Components.IComponentRenderMode */ get MI()
                    {
                        return $.$macw.MACW.R.IS;
                    }
                    /*global::Microsoft.AspNetCore.Components.IComponentRenderMode */ get M$1()
                    {
                        return $.$t.TC.R.__.MI;
                    }
                    //default reference type constructor overload
                    $ctor$3()
                    {
                        super.$ctor$2();
                        return this;
                    }
                    static $h = 1611281;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":7733256,"p":[{"p":2883592,"g":{"r":0,"d":0,"h":8591545873,"f":34},"n":"ModeImpl","o":"MI","d":1611281,"h":4296578577,"f":34},{"p":2883592,"g":{"r":0,"d":0,"h":17181480465,"f":32769},"n":"Mode","o":"M$1","d":1611281,"h":12886513169,"f":32769}],"c":[{"n":".ctor","o":"$ctor$3","d":1611281,"h":21476447761,"f":1}],"d":1545745,"h":1611281}; }
                    static get $b() { return $.$mac.MAC.RM; }
                    static get $fullName() { return `Taskman.Components.Routes.__PrivateComponentRenderModeAttribute`; }
                }, $cls, ($v) => $cls.$___ = $v);
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 1545745;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","o":"B","d":1545745,"h":4296513041,"f":32772}],"c":[{"n":".ctor","o":"$ctor$2","d":1545745,"h":12886447633,"f":1}],"i":[2752520,3145736,3080200],"j":[1611281],"h":1545745,"a":[{"t":1611281,"c":21476447761}]}; }
            static get $b() { return $.$mac.MAC.CB; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IC, $.$mac.MAC.IHE, $.$mac.MAC.IH ]; }
            static get $fullName() { return `Taskman.Components.Routes`; }
        });
        
        $asm.$cls("$t.TL.N", ($self) => class NavMenu extends $.$mac.MAC.CB
        {
            /*void */ B(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OE(0, "div");
                __builder.AA$2(1, "class", "top-row ps-3 navbar navbar-dark");
                __builder.AA$4(2, "b-l8at8xwutv");
                __builder.OE(3, "div");
                __builder.AA$2(4, "class", "container-fluid");
                __builder.AA$4(5, "b-l8at8xwutv");
                __builder.AM(6, "<a class=\"navbar-brand\" href b-l8at8xwutv>Taskman</a>\n        ");
                __builder.OE(7, "button");
                __builder.AA$2(8, "title", "Navigation menu");
                __builder.AA$2(9, "class", "navbar-toggler");
                __builder.AA$6($.$macw.MACW.ME, 10, "onclick", $.$mac.MAC.EC$1.F$1.C$5($.$macw.MACW.ME, this, new $.$$.S.A$2().$ctor(this, this.TN)));
                __builder.AA$4(11, "b-l8at8xwutv");
                __builder.AM(12, "<span class=\"navbar-toggler-icon\" b-l8at8xwutv></span>");
                __builder.CE();
                __builder.CE();
                __builder.CE();
                __builder.AM(13, "\n\n");
                __builder.OE(14, "div");
                __builder.AA$2(15, "class", (this.N) + " nav-scrollable");
                __builder.AA$6($.$macw.MACW.ME, 16, "onclick", $.$mac.MAC.EC$1.F$1.C$5($.$macw.MACW.ME, this, new $.$$.S.A$2().$ctor(this, this.TN)));
                __builder.AA$4(17, "b-l8at8xwutv");
                __builder.OE(18, "nav");
                __builder.AA$2(19, "class", "nav flex-column");
                __builder.AA$4(20, "b-l8at8xwutv");
                __builder.OE(21, "div");
                __builder.AA$2(22, "class", "nav-item px-3");
                __builder.AA$4(23, "b-l8at8xwutv");
                __builder.OC($.$macw.MACR$2.NL$1, 24);
                __builder.AC(25, "class", "nav-link");
                __builder.AC(26, "href", "");
                __builder.AC(27, "Match", $.$box($.$mac.MACC.R.TC($.$macw.MACR$2.NLM, 1/*NavLinkMatch.All*/), $.$macw.MACR$2.NLM));
                __builder.AA(28, "ChildContent", new $.$mac.MAC.RF().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.AM(29, "<span class=\"bi bi-house-door-fill-nav-menu\" aria-hidden=\"true\" b-l8at8xwutv></span> Home\n            ");
                })));
                __builder.CC();
                __builder.CE();
                __builder.AM(30, "\n        ");
                __builder.OE(31, "div");
                __builder.AA$2(32, "class", "nav-item px-3");
                __builder.AA$4(33, "b-l8at8xwutv");
                __builder.OC($.$macw.MACR$2.NL$1, 34);
                __builder.AC(35, "class", "nav-link");
                __builder.AC(36, "href", "counter");
                __builder.AA(37, "ChildContent", new $.$mac.MAC.RF().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.AM(38, "<span class=\"bi bi-plus-square-fill-nav-menu\" aria-hidden=\"true\" b-l8at8xwutv></span> Counter\n            ");
                })));
                __builder.CC();
                __builder.CE();
                __builder.AM(39, "\n        ");
                __builder.OE(40, "div");
                __builder.AA$2(41, "class", "nav-item px-3");
                __builder.AA$4(42, "b-l8at8xwutv");
                __builder.OC($.$macw.MACR$2.NL$1, 43);
                __builder.AC(44, "class", "nav-link");
                __builder.AC(45, "href", "weather");
                __builder.AA(46, "ChildContent", new $.$mac.MAC.RF().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.AM(47, "<span class=\"bi bi-list-nested-nav-menu\" aria-hidden=\"true\" b-l8at8xwutv></span> Weather\n            ");
                })));
                __builder.CC();
                __builder.CE();
                __builder.AM(48, "\n\n        ");
                __builder.OE(49, "div");
                __builder.AA$2(50, "class", "nav-item px-3");
                __builder.AA$4(51, "b-l8at8xwutv");
                __builder.OC($.$macw.MACR$2.NL$1, 52);
                __builder.AC(53, "class", "nav-link");
                __builder.AC(54, "href", "login");
                __builder.AA(55, "ChildContent", new $.$mac.MAC.RF().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.AM(56, "<span class=\"bi bi-list-nested-nav-menu\" aria-hidden=\"true\" b-l8at8xwutv></span> Login\n            ");
                })));
                __builder.CC();
                __builder.CE();
                __builder.CE();
                __builder.CE();
            }
            /*bool*/ cN = true;
            /*string? */ get N()
            {
                return this.cN ? "collapse" : null;
            }
            /*void */ TN()
            {
                this.cN = !this.cN;
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 1938961;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17181808145,"f":2},"n":"NavMenuCssClass","o":"N","d":1938961,"h":12886840849,"f":2}],"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","o":"B","d":1938961,"h":4296906257,"f":32772},{"r":65537,"n":"ToggleNavMenu","o":"TN","d":1938961,"h":21476775441,"f":2}],"l":[{"t":262145,"n":"collapseNavMenu","o":"cN","d":1938961,"h":8591873553,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":1938961,"h":25771742737,"f":1}],"i":[2752520,3145736,3080200],"h":1938961}; }
            static get $b() { return $.$mac.MAC.CB; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IC, $.$mac.MAC.IHE, $.$mac.MAC.IH ]; }
            static get $fullName() { return `Taskman.Layout.NavMenu`; }
        });
        
        $asm.$cls("$t.TC.SC", ($self) => class StatCard extends $.$mac.MAC.CB
        {
            /*void */ B(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OE(0, "div");
                __builder.AA$2(1, "class", "stat-container");
                __builder.AA$4(2, "b-35l3j00qne");
                __builder.OE(3, "div");
                __builder.AA$2(4, "class", "label");
                __builder.AA$4(5, "b-35l3j00qne");
                __builder.OE(6, "p");
                __builder.AA$4(7, "b-35l3j00qne");
                __builder.AC$3(8, this.I$2);
                __builder.CE();
                __builder.AM(9, "\n        ");
                __builder.OE(10, "p");
                __builder.AA$4(11, "b-35l3j00qne");
                __builder.AC$3(12, this.L);
                __builder.CE();
                __builder.CE();
                __builder.AM(13, "\n    ");
                __builder.OE(14, "p");
                __builder.AA$2(15, "class", "value");
                __builder.AA$4(16, "b-35l3j00qne");
                __builder.AC$3(17, this.V);
                __builder.CE();
                __builder.CE();
            }
            /*string*/ I$2 = null;
            /*string*/ L = null;
            /*string*/ V = null;
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.I$2 = "";
                this.L = "";
                this.V = "";
            }
            static $h = 1742353;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17181611537,"f":1},"s":{"r":0,"d":0,"h":21476578833,"f":1},"n":"Icon","o":"I$2","d":1742353,"h":12886644241,"f":1,"a":[{"t":5636104,"c":21480472584}]},{"p":1310721,"g":{"r":0,"d":0,"h":34361480721,"f":1},"s":{"r":0,"d":0,"h":38656448017,"f":1},"n":"Label","o":"L","d":1742353,"h":30066513425,"f":1,"a":[{"t":5636104,"c":21480472584}]},{"p":1310721,"g":{"r":0,"d":0,"h":51541349905,"f":1},"s":{"r":0,"d":0,"h":55836317201,"f":1},"n":"Value","o":"V","d":1742353,"h":47246382609,"f":1,"a":[{"t":5636104,"c":21480472584}]}],"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","o":"B","d":1742353,"h":4296709649,"f":32772}],"c":[{"n":".ctor","o":"$ctor$2","d":1742353,"h":60131284497,"f":1}],"i":[2752520,3145736,3080200],"h":1742353}; }
            static get $b() { return $.$mac.MAC.CB; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IC, $.$mac.MAC.IHE, $.$mac.MAC.IH ]; }
            static get $fullName() { return `Taskman.Components.StatCard`; }
        });
        
        $asm.$cls("$t.TCP.P", ($self) => class Profile extends $.$mac.MAC.CB
        {
            /*void */ B(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OC($.$t.TC.N, 0);
                __builder.CC();
                if (this.iL)
                {
                    if ($.$$.S.S$1.o_E(this.A$1.R$1, "Admin"))
                    {
                        __builder.OC($.$t.TC.L, 1);
                        __builder.AC(2, "LoadingState", "\u23F3 Loading Admin profile...");
                        __builder.CC();
                    }
                    else if ($.$$.S.S$1.o_E(this.A$1.R$1, "User"))
                    {
                        __builder.OC($.$t.TC.L, 3);
                        __builder.AC(4, "LoadingState", "\u23F3 Loading User profile...");
                        __builder.CC();
                    }
                    else 
                    {
                        __builder.OC($.$t.TC.L, 5);
                        __builder.AC(6, "LoadingState", "\u23F3 Loading profile...");
                        __builder.CC();
                    }
                }
                else 
                {
                    __builder.AM(7, "<h3 style=\"margin-top: 20px;\">\uD83D\uDC64 My Profile</h3>");
                    __builder.OE(8, "div");
                    __builder.AA$2(9, "style", "background: rgb(255, 166, 0, 0.2); padding: 20px 40px; font-size: 20px; margin-top: 30px; flex-wrap: wrap;");
                    __builder.OE(10, "div");
                    __builder.AA$2(11, "style", "background: rgb(255, 166, 0, 0.2); padding: 20px 40px; font-size: 20px; display: flex; justify-content: space-between; margin-top: 30px; flex-wrap: wrap;");
                    __builder.OE(12, "p");
                    __builder.AM(13, "<b style=\"color: purple;\">\uD83D\uDE4E\u200D\u2642\uFE0F Fullname:</b>\n                ");
                    __builder.AC$3(14, this.fN);
                    __builder.CE();
                    __builder.AM(15, "\n            ");
                    __builder.OE(16, "p");
                    __builder.AM(17, "<b style=\"color: purple;\">\uD83D\uDC66 Username:</b>\n                ");
                    __builder.AC$3(18, this.A$1.U);
                    __builder.CE();
                    __builder.AM(19, "\n            ");
                    __builder.OE(20, "p");
                    __builder.AM(21, "<b style=\"color: purple; margin-right: 4px;\">\uD83D\uDCC5 Member since:</b>");
                    if (this.A$1.IL)
                    {
                        __builder.AC$3(22, $.$$.S.DT$1.N$1.TS$3("MMM yyyy"));
                    }
                    __builder.CE();
                    __builder.CE();
                    __builder.AM(23, "\n        ");
                    __builder.OE(24, "div");
                    __builder.AA$2(25, "style", "background: rgb(255, 166, 0, 0.2); padding: 20px 40px; font-size: 20px; display: flex; justify-content: space-between; margin-top: 30px; flex-wrap: wrap;");
                    __builder.OE(26, "p");
                    __builder.AM(27, "<b style=\"color: purple;\">\uD83C\uDFF7\uFE0F Role:</b>\n                ");
                    __builder.AC$3(28, this.A$1.R$1);
                    __builder.CE();
                    __builder.AM(29, "\n            ");
                    __builder.OE(30, "p");
                    __builder.AM(31, "<b style=\"color: purple;\">\uD83D\uDCC5 Date of Birth:</b>\n                ");
                    __builder.AC$3(32, this.A$1.D);
                    __builder.CE();
                    __builder.AM(33, "\n            ");
                    __builder.OE(34, "p");
                    __builder.AM(35, "<b style=\"color: purple; margin-right: 4px;\">\uD83D\uDCE7 Email:</b>\n                ");
                    __builder.AC$3(36, this.A$1.E$2);
                    __builder.CE();
                    __builder.CE();
                    __builder.CE();
                    if (!this.A$1.IL)
                    {
                        __builder.OC($.$t.TC.NL, 37);
                        __builder.AC(38, "Title", "User not logged in...");
                        __builder.AC(39, "SubTitle", "Click to log in...");
                        __builder.CC();
                    }
                    else 
                    {
                        __builder.OE(40, "div");
                        __builder.AA$2(41, "style", "background: rgb(133, 133, 133, 0.2); padding: 20px 40px; font-size: 20px; margin: 30px 0;");
                        __builder.AM(42, "<h5>\uD83D\uDCCA My Stats</h5>\n            ");
                        __builder.OE(43, "div");
                        __builder.AA$2(44, "style", "background: rgb(133, 133, 133, 0.2); padding: 20px 40px; font-size: 20px; display: flex; justify-content: space-between; flex-wrap: wrap; margin-top: 30px;");
                        __builder.OE(45, "p");
                        __builder.AM(46, "<b style=\"margin-right: 20px\">\u2705 Completed: </b>\n                    ");
                        __builder.OE(47, "i");
                        __builder.AA$2(48, "style", "font-size: 30px; color: purple; font-weight: bold;");
                        __builder.AC$3(49, this.cC);
                        __builder.CE();
                        __builder.CE();
                        __builder.AM(50, "\n                ");
                        __builder.OE(51, "p");
                        __builder.AM(52, "<b style=\"margin-right: 20px\">\u23F3 Pending: </b>\n                    ");
                        __builder.OE(53, "i");
                        __builder.AA$2(54, "style", "font-size: 30px; color: purple; font-weight: bold;");
                        __builder.AC$3(55, this.pC);
                        __builder.CE();
                        __builder.CE();
                        __builder.AM(56, "\n                ");
                        __builder.OE(57, "p");
                        __builder.AM(58, "<b style=\"margin-right: 20px\">\uD83D\uDCDD Total: </b>\n                    ");
                        __builder.OE(59, "i");
                        __builder.AA$2(60, "style", "font-size: 30px; color: purple; font-weight: bold;");
                        __builder.AC$3(61, this.tC);
                        __builder.CE();
                        __builder.CE();
                        __builder.CE();
                        __builder.CE();
                        __builder.OE(62, "div");
                        __builder.AA$2(63, "style", "display: flex; justify-content: space-between; flex-wrap: wrap;");
                        __builder.OE(64, "div");
                        __builder.AA$2(65, "style", "margin-bottom: 10px;");
                        __builder.OE(66, "div");
                        __builder.AA$2(67, "style", "margin-bottom: 10px;");
                        __builder.OC($.$t.TC.B, 68);
                        __builder.AC(69, "BgColor", "rgb(140, 0, 140, 0.3)");
                        __builder.AC(70, "BtnText", "\u2B05 Back To DashBoard");
                        __builder.AC(71, "OnClick", $.$mac.MACC.R.TC($.$mac.MAC.EC$1, $.$mac.MAC.EC$1.F$1.C(this, new $.$$.S.A$2().$ctor(this, this.BT))));
                        __builder.CC();
                        __builder.CE();
                        __builder.AM(72, "\n                ");
                        __builder.OE(73, "div");
                        __builder.AA$2(74, "style", "margin-bottom: 10px;");
                        __builder.OC($.$t.TC.B, 75);
                        __builder.AC(76, "BgColor", "rgb(135, 135, 135, 0.3)");
                        __builder.AC(77, "BtnText", "\uD83D\uDEAA Logout");
                        __builder.AC(78, "OnClick", $.$mac.MACC.R.TC($.$mac.MAC.EC$1, $.$mac.MAC.EC$1.F$1.C(this, new $.$$.S.A$2().$ctor(this, this.L))));
                        __builder.CC();
                        __builder.CE();
                        __builder.CE();
                        if (this.cA === false)
                        {
                            __builder.OE(79, "div");
                            __builder.OC($.$t.TC.C, 80);
                            __builder.AC(81, "Title", "Sure to delete this account?");
                            __builder.AC(82, "Text1", "\u2705 Confirm");
                            __builder.AC(83, "Text2", "\u274C Cancel");
                            __builder.AC(84, "ConfirmBtn", $.$mac.MACC.R.TC($.$mac.MAC.EC$1, $.$mac.MAC.EC$1.F$1.C$3(this, new ($.$$.S.F$$($.$$.STT.T))().$ctor(this, this.DU))));
                            __builder.AC(85, "CancelBtn", $.$mac.MACC.R.TC($.$mac.MAC.EC$1, $.$mac.MAC.EC$1.F$1.C(this, new $.$$.S.A$2().$ctor(this,  () =>
                            {
                                return this.cA = true;
                            }, {"r":65537,"n":"","d":1349137,"h":0,"f":1048578}))));
                            __builder.CC();
                            __builder.CE();
                        }
                        else 
                        {
                            __builder.OE(86, "div");
                            __builder.AA$2(87, "style", "margin-bottom: 10px;");
                            __builder.OC($.$t.TC.B, 88);
                            __builder.AC(89, "BgColor", "rgba(255, 0, 0, 0.3)");
                            __builder.AC(90, "BtnText", "\uD83D\uDDD1\uFE0F Delete Account");
                            __builder.AC(91, "OnClick", $.$mac.MACC.R.TC($.$mac.MAC.EC$1, $.$mac.MAC.EC$1.F$1.C(this, new $.$$.S.A$2().$ctor(this,  () =>
                            {
                                return this.cA = false;
                            }, {"r":65537,"n":"","d":1349137,"h":0,"f":1048578}))));
                            __builder.CC();
                            __builder.CE();
                        }
                        __builder.CE();
                    }
                }
            }
            /*bool*/ iL = false;
            /*List<AppTask> */ get t$1()
            {
                return this.TS.I$G() ?? new ($.$$.SCG.L$$($.$t.A))().$ctor$1();
            }
            /*string */ get tC()
            {
                return $.$$.S.I$4.T.call(this.t$1.C$3);
            }
            /*string */ get cC()
            {
                return $.$$.S.I$4.T.call($.$sl.SL.E.C$6($.$t.A, this.t$1, new ($.$$.S.F$$$($.$t.A, $.$$.S.B$2))().$ctor(this,  (/*t*/ t) =>
                {
                    return t.IC;
                }, {"r":262145,"p":[{"n":"t","p":103953}],"n":"","d":1349137,"h":0,"f":1048578})));
            }
            /*string */ get pC()
            {
                return $.$$.S.I$4.T.call($.$sl.SL.E.C$6($.$t.A, this.t$1, new ($.$$.S.F$$$($.$t.A, $.$$.S.B$2))().$ctor(this,  (/*t*/ t) =>
                {
                    return !t.IC;
                }, {"r":262145,"p":[{"n":"t","p":103953}],"n":"","d":1349137,"h":0,"f":1048578})));
            }
            /*string */ get fN()
            {
                return `${this.A$1.L} ${this.A$1.F$1}`;
            }
            /*bool*/ cA = true;
            /*Task *//*async*/  OIA()
            {
                return $.$$.N.AR.A($.$$.STT.T, $.$$.S.V$2, async () => 
                {
                    this.iL = true;
                    await $.$$.STT.T.D$2(500);
                    this.iL = false;
                    this.SH();
                });
            }
            /*void */ BT()
            {
                this.N.N("dashboard", false, false);
                this.SH();
            }
            /*Task *//*async*/  DU()
            {
                return $.$$.N.AR.A($.$$.STT.T, $.$$.S.V$2, async () => 
                {
                    await this.A$1.DA();
                    this.SH();
                });
            }
            /*void */ L()
            {
                this.N.N("", false, false);
                this.A$1.L$2();
            }
            /*Task *//*async*/  OA(/*bool*/ firstRender)
            {
                return $.$$.N.AR.A($.$$.STT.T, $.$$.S.V$2, async () => 
                {
                    if (firstRender)
                    {
                        await this.A$1.LU();
                        await this.TS.I$L();
                        this.SH();
                    }
                });
            }
            /*NavigationManager*/ N = null;
            /*ITaskService*/ TS = null;
            /*Taskman.Services.AuthService*/ A$1 = null;
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.iL = false;
                this.N = null;
                this.TS = null;
                this.A$1 = null;
            }
            static $h = 1349137;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17181218321,"f":2},"s":{"r":0,"d":0,"h":21476185617,"f":2},"n":"isLoading","o":"iL","d":1349137,"h":12886251025,"f":2},{"p":$.$$.SCG.L$$($.$t.A).$h,"g":{"r":0,"d":0,"h":30066120209,"f":2},"n":"tasks","o":"t$1","d":1349137,"h":25771152913,"f":2},{"p":1310721,"g":{"r":0,"d":0,"h":38656054801,"f":2},"n":"tasksCount","o":"tC","d":1349137,"h":34361087505,"f":2},{"p":1310721,"g":{"r":0,"d":0,"h":47245989393,"f":2},"n":"completedCount","o":"cC","d":1349137,"h":42951022097,"f":2},{"p":1310721,"g":{"r":0,"d":0,"h":55835923985,"f":2},"n":"pendingCount","o":"pC","d":1349137,"h":51540956689,"f":2},{"p":1310721,"g":{"r":0,"d":0,"h":64425858577,"f":2},"n":"fullName","o":"fN","d":1349137,"h":60130891281,"f":2},{"p":4980744,"g":{"r":0,"d":0,"h":103080564241,"f":2},"s":{"r":0,"d":0,"h":107375531537,"f":2},"n":"Nav","o":"N","d":1349137,"h":98785596945,"f":2,"a":[{"t":4259848,"c":21479096328}]},{"p":169489,"g":{"r":0,"d":0,"h":120260433425,"f":2},"s":{"r":0,"d":0,"h":124555400721,"f":2},"n":"TaskService","o":"TS","d":1349137,"h":115965466129,"f":2,"a":[{"t":4259848,"c":21479096328}]},{"p":2070033,"g":{"r":0,"d":0,"h":137440302609,"f":2},"s":{"r":0,"d":0,"h":141735269905,"f":2},"n":"Auth","o":"A$1","d":1349137,"h":133145335313,"f":2,"a":[{"t":4259848,"c":21479096328}]}],"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","o":"B","d":1349137,"h":4296316433,"f":32772},{"r":133169153,"n":"OnInitializedAsync","o":"OIA","d":1349137,"h":73015793169,"f":36868},{"r":65537,"n":"BackToDashboard","o":"BT","d":1349137,"h":77310760465,"f":2},{"r":133169153,"n":"DeleteUserAccount","o":"DU","d":1349137,"h":81605727761,"f":4098},{"r":65537,"n":"Logout","o":"L","d":1349137,"h":85900695057,"f":2},{"r":133169153,"p":[{"n":"firstRender","p":262145}],"n":"OnAfterRenderAsync","o":"OA","d":1349137,"h":90195662353,"f":36868}],"l":[{"t":262145,"n":"confirmAccountDelete","o":"cA","d":1349137,"h":68720825873,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":1349137,"h":146030237201,"f":1}],"i":[2752520,3145736,3080200],"h":1349137,"a":[{"t":9895944,"c":4304863240,"a":[{"v":"/profile","t":1310721}]}]}; }
            static get $b() { return $.$mac.MAC.CB; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IC, $.$mac.MAC.IHE, $.$mac.MAC.IH ]; }
            static get $fullName() { return `Taskman.Components.Pages.Profile`; }
        });
        
        $asm.$cls("$t.TC.T", ($self) => class TaskCard extends $.$mac.MAC.CB
        {
            /*void */ B(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OE(0, "table");
                __builder.AA$2(1, "class", "task-container mobile");
                __builder.AA$4(2, "b-whjw6qbj78");
                __builder.OE(3, "tr");
                __builder.AA$2(4, "class", "tr");
                __builder.AA$4(5, "b-whjw6qbj78");
                __builder.OE(6, "td");
                __builder.AA$2(7, "class", "td1");
                __builder.AA$4(8, "b-whjw6qbj78");
                __builder.OE(9, "div");
                __builder.AA$6($.$macw.MACW.ME, 10, "onclick", $.$mac.MAC.EC$1.F$1.C$7($.$macw.MACW.ME, this, new ($.$$.S.F$$($.$$.STT.T))().$ctor(this,  () =>
                {
                    return this.OT.IA$1(this.T$1.Id);
                }, {"r":133169153,"n":"","d":1807889,"h":0,"f":1048578})));
                __builder.AA$2(11, "class", "container-title");
                __builder.AA$4(12, "b-whjw6qbj78");
                __builder.OE(13, "p");
                __builder.AA$4(14, "b-whjw6qbj78");
                __builder.OE(15, "input");
                __builder.AA$2(16, "style", "user-select: none; pointer-events: none;");
                __builder.AA$2(17, "type", "checkbox");
                __builder.A(18, "checked", this.T$1.IC);
                $.$macw.MACW.WR.AE(__builder, 19, "onclick", true);
                __builder.AA$4(20, "b-whjw6qbj78");
                __builder.CE();
                __builder.CE();
                __builder.AM(21, "\n\n                ");
                __builder.OE(22, "p");
                __builder.AA$2(23, "style", "font-weight: bold");
                __builder.AA$4(24, "b-whjw6qbj78");
                __builder.AC$3(25, this.T$1.T$1);
                __builder.CE();
                __builder.CE();
                __builder.CE();
                __builder.AM(26, "\n        ");
                __builder.OE(27, "td");
                __builder.AA$2(28, "class", "td2");
                __builder.AA$4(29, "b-whjw6qbj78");
                __builder.OE(30, "button");
                __builder.AA$4(31, "b-whjw6qbj78");
                if (this.T$1.P$1 === 1/*Priority.Low*/)
                {
                    __builder.AM(32, "<span b-whjw6qbj78><text b-whjw6qbj78>\uD83D\uDD34</text></span>");
                }
                else if (this.T$1.P$1 === 2/*Priority.Medium*/)
                {
                    __builder.AM(33, "<span b-whjw6qbj78><text b-whjw6qbj78>\uD83D\uDFE1</text></span>");
                }
                else if (this.T$1.P$1 === 3/*Priority.High*/)
                {
                    __builder.AM(34, "<span b-whjw6qbj78><text b-whjw6qbj78>\uD83D\uDFE2</text></span>");
                }
                __builder.AC$2(35, $.$box(this.T$1.P$1, $.$t.P$1));
                __builder.CE();
                __builder.AM(36, "\n            ");
                __builder.OE(37, "button");
                __builder.AA$6($.$macw.MACW.ME, 38, "onclick", $.$mac.MAC.EC$1.F$1.C$7($.$macw.MACW.ME, this, new ($.$$.S.F$$($.$$.STT.T))().$ctor(this,  () =>
                {
                    return this.OR.IA$1(this.T$1.Id);
                }, {"r":133169153,"n":"","d":1807889,"h":0,"f":1048578})));
                __builder.AA$4(39, "b-whjw6qbj78");
                __builder.AM(40, "\uD83D\uDDD1\uFE0F");
                __builder.CE();
                __builder.CE();
                __builder.CE();
                __builder.CE();
            }
            /*int?*/ TI = null;
            /*EventCallback<int>*/ OR;
            /*AppTask*/ T$1 = null;
            /*EventCallback<int>*/ OD;
            /*EventCallback<int>*/ OT;
            /*EventCallback<int>*/ OE;
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.TI = null;
                this.OR = $.$default($.$mac.MAC.E$$($.$$.S.I$4));
                this.T$1 = new $.$t.A().$ctor$1();
                this.OD = $.$default($.$mac.MAC.E$$($.$$.S.I$4));
                this.OT = $.$default($.$mac.MAC.E$$($.$$.S.I$4));
                this.OE = $.$default($.$mac.MAC.E$$($.$$.S.I$4));
            }
            static $h = 1807889;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":$.$typeNullable($.$$.S.I$4).$h,"g":{"r":0,"d":0,"h":17181677073,"f":1},"s":{"r":0,"d":0,"h":21476644369,"f":1},"n":"TaskIdToDelete","o":"TI","d":1807889,"h":12886709777,"f":1,"a":[{"t":5636104,"c":21480472584}]},{"p":$.$mac.MAC.E$$($.$$.S.I$4).$h,"g":{"r":0,"d":0,"h":34361546257,"f":1},"s":{"r":0,"d":0,"h":38656513553,"f":1},"n":"OnRequestDelete","o":"OR","d":1807889,"h":30066578961,"f":1,"a":[{"t":5636104,"c":21480472584}]},{"p":103953,"g":{"r":0,"d":0,"h":51541415441,"f":1},"s":{"r":0,"d":0,"h":55836382737,"f":1},"n":"Task","o":"T$1","d":1807889,"h":47246448145,"f":1,"a":[{"t":5636104,"c":21480472584}]},{"p":$.$mac.MAC.E$$($.$$.S.I$4).$h,"g":{"r":0,"d":0,"h":68721284625,"f":1},"s":{"r":0,"d":0,"h":73016251921,"f":1},"n":"OnDelete","o":"OD","d":1807889,"h":64426317329,"f":1,"a":[{"t":5636104,"c":21480472584}]},{"p":$.$mac.MAC.E$$($.$$.S.I$4).$h,"g":{"r":0,"d":0,"h":85901153809,"f":1},"s":{"r":0,"d":0,"h":90196121105,"f":1},"n":"OnToggle","o":"OT","d":1807889,"h":81606186513,"f":1,"a":[{"t":5636104,"c":21480472584}]},{"p":$.$mac.MAC.E$$($.$$.S.I$4).$h,"g":{"r":0,"d":0,"h":103081022993,"f":1},"s":{"r":0,"d":0,"h":107375990289,"f":1},"n":"OnEdit","o":"OE","d":1807889,"h":98786055697,"f":1,"a":[{"t":5636104,"c":21480472584}]}],"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","o":"B","d":1807889,"h":4296775185,"f":32772}],"c":[{"n":".ctor","o":"$ctor$2","d":1807889,"h":111670957585,"f":1}],"i":[2752520,3145736,3080200],"h":1807889}; }
            static get $b() { return $.$mac.MAC.CB; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IC, $.$mac.MAC.IHE, $.$mac.MAC.IH ]; }
            static get $fullName() { return `Taskman.Components.TaskCard`; }
        });
        
        $asm.$cls("$t.TCP.L", ($self) => class Login extends $.$mac.MAC.CB
        {
            /*void */ B(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                if (this.iL)
                {
                    __builder.AM(0, "<div style=\"position: fixed; top: 0px; bottom: 0px; left: 0px; right: 0px; background: purple;\" b-5mkzhhjfiq><div class=\"loading-progress\" style=\"display: flex; align-items: center; justify-content: center; width: 100%; height: 100vh;\" b-5mkzhhjfiq><img src=\"favicon.png\" alt=\"Taskman Logo\" width=\"120\" b-5mkzhhjfiq></div></div>");
                }
                else 
                {
                    __builder.OE(1, "div");
                    __builder.AA$2(2, "class", "login-container");
                    __builder.AA$4(3, "b-5mkzhhjfiq");
                    __builder.AM(4, "<h3 b-5mkzhhjfiq>Login</h3>\n        ");
                    __builder.OE(5, "div");
                    __builder.AA$2(6, "class", "sub-container");
                    __builder.AA$4(7, "b-5mkzhhjfiq");
                    __builder.OE(8, "div");
                    __builder.AA$2(9, "class", "input-container");
                    __builder.AA$4(10, "b-5mkzhhjfiq");
                    __builder.AM(11, "<label for=\"username\" b-5mkzhhjfiq>Username</label>\n                ");
                    __builder.OE(12, "input");
                    __builder.AA$2(13, "type", "text");
                    __builder.AA$2(14, "placeholder", "enter username...");
                    __builder.AA$2(15, "value", $.$mac.MAC.B.FV$28(this.u, null));
                    __builder.AA$6($.$mac.MAC.CE, 16, "onchange", $.$mac.MAC.ECF.CB$27($.$mac.MAC.EC$1.F$1, this, new ($.$$.S.A$1$$($.$$.S.S$1))().$ctor(this,  (/*__value*/ __value) =>
                    {
                        return this.u = __value;
                    }, {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1283601,"h":0,"f":1048578}), this.u, null));
                    __builder.SU("value");
                    __builder.AA$4(17, "b-5mkzhhjfiq");
                    __builder.CE();
                    __builder.CE();
                    __builder.AM(18, "\n\n            ");
                    __builder.OE(19, "div");
                    __builder.AA$2(20, "class", "input-container");
                    __builder.AA$4(21, "b-5mkzhhjfiq");
                    __builder.AM(22, "<label for=\"username\" b-5mkzhhjfiq>Password</label>\n                ");
                    __builder.OE(23, "input");
                    __builder.AA$2(24, "type", "password");
                    __builder.AA$2(25, "placeholder", "enter password...");
                    __builder.AA$2(26, "value", $.$mac.MAC.B.FV$28(this.p$1, null));
                    __builder.AA$6($.$mac.MAC.CE, 27, "onchange", $.$mac.MAC.ECF.CB$27($.$mac.MAC.EC$1.F$1, this, new ($.$$.S.A$1$$($.$$.S.S$1))().$ctor(this,  (/*__value*/ __value) =>
                    {
                        return this.p$1 = __value;
                    }, {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1283601,"h":0,"f":1048578}), this.p$1, null));
                    __builder.SU("value");
                    __builder.AA$4(28, "b-5mkzhhjfiq");
                    __builder.CE();
                    __builder.CE();
                    __builder.AM(29, "\n\n            ");
                    __builder.OE(30, "div");
                    __builder.AA$2(31, "class", "input-container");
                    __builder.AA$4(32, "b-5mkzhhjfiq");
                    __builder.OE(33, "button");
                    __builder.AA$6($.$macw.MACW.ME, 34, "onclick", $.$mac.MAC.EC$1.F$1.C$5($.$macw.MACW.ME, this, new $.$$.S.A$2().$ctor(this, this.L)));
                    __builder.AA$4(35, "b-5mkzhhjfiq");
                    __builder.AC$3(36, "Login");
                    __builder.CE();
                    __builder.CE();
                    if (!this.A$1.IL)
                    {
                        __builder.OE(37, "p");
                        __builder.AA$4(38, "b-5mkzhhjfiq");
                        __builder.AC$3(39, this.e);
                        __builder.CE();
                    }
                    __builder.OE(40, "div");
                    __builder.AA$2(41, "class", "signup");
                    __builder.AA$4(42, "b-5mkzhhjfiq");
                    __builder.AM(43, "<p b-5mkzhhjfiq>Don't have an account?</p>\n                ");
                    __builder.OC($.$t.TC.B, 44);
                    __builder.AC(45, "BgColor", "rgb(127, 0, 127, 0.3)");
                    __builder.AC(46, "BtnText", "Sign Up");
                    __builder.AC(47, "OnClick", $.$mac.MACC.R.TC($.$mac.MAC.EC$1, $.$mac.MAC.EC$1.F$1.C(this, new $.$$.S.A$2().$ctor(this, this.SU))));
                    __builder.CC();
                    __builder.CE();
                    __builder.CE();
                    __builder.CE();
                }
            }
            /*string*/ u = null;
            /*string*/ p$1 = null;
            /*string*/ e = null;
            /*bool*/ iL = false;
            /*Task *//*async*/  OIA()
            {
                return $.$$.N.AR.A($.$$.STT.T, $.$$.S.V$2, async () => 
                {
                    this.iL = true;
                    await $.$$.STT.T.D$2(2000);
                    this.iL = false;
                });
            }
            /*Task *//*async*/  OA(/*bool*/ firstRender)
            {
                return $.$$.N.AR.A($.$$.STT.T, $.$$.S.V$2, async () => 
                {
                    if (firstRender)
                    {
                        await this.A$1.LU();
                    }
                });
            }
            /*void */ OI()
            {
                if (this.A$1.IL)
                {
                    this.N.N("dashboard", false, false);
                }
            }
            /*void */ L()
            {
                /*bool*/ let success = this.A$1.L$1(this.u, this.p$1);
                if (success)
                {
                    this.N.N("dashboard", false, false);
                }
                else 
                {
                    this.e = "\u26A0\uFE0F Username or Password is not correct";
                }
            }
            /*void */ SU()
            {
                this.N.N("signup", false, false);
            }
            /*NavigationManager*/ N = null;
            /*Taskman.Services.AuthService*/ A$1 = null;
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.u = "";
                this.p$1 = "";
                this.e = "";
                this.N = null;
                this.A$1 = null;
            }
            static $h = 1283601;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":4980744,"g":{"r":0,"d":0,"h":55835858449,"f":2},"s":{"r":0,"d":0,"h":60130825745,"f":2},"n":"Nav","o":"N","d":1283601,"h":51540891153,"f":2,"a":[{"t":4259848,"c":21479096328}]},{"p":2070033,"g":{"r":0,"d":0,"h":73015727633,"f":2},"s":{"r":0,"d":0,"h":77310694929,"f":2},"n":"Auth","o":"A$1","d":1283601,"h":68720760337,"f":2,"a":[{"t":4259848,"c":21479096328}]}],"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","o":"B","d":1283601,"h":4296250897,"f":32772},{"r":133169153,"n":"OnInitializedAsync","o":"OIA","d":1283601,"h":25771087377,"f":36868},{"r":133169153,"p":[{"n":"firstRender","p":262145}],"n":"OnAfterRenderAsync","o":"OA","d":1283601,"h":30066054673,"f":36868},{"r":65537,"n":"OnInitialized","o":"OI","d":1283601,"h":34361021969,"f":32772},{"r":65537,"n":"LoginUser","o":"L","d":1283601,"h":38655989265,"f":2},{"r":65537,"n":"SignUp","o":"SU","d":1283601,"h":42950956561,"f":2}],"l":[{"t":1310721,"n":"username","o":"u","d":1283601,"h":8591218193,"f":2},{"t":1310721,"n":"password","o":"p$1","d":1283601,"h":12886185489,"f":2},{"t":1310721,"n":"errorMessage","o":"e","d":1283601,"h":17181152785,"f":2},{"t":262145,"n":"isLoading","o":"iL","d":1283601,"h":21476120081,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":1283601,"h":81605662225,"f":1}],"i":[2752520,3145736,3080200],"h":1283601,"a":[{"t":9895944,"c":4304863240,"a":[{"v":"/","t":1310721}]}]}; }
            static get $b() { return $.$mac.MAC.CB; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IC, $.$mac.MAC.IHE, $.$mac.MAC.IH ]; }
            static get $fullName() { return `Taskman.Components.Pages.Login`; }
        });
        
        $asm.$cls("$t.TCP.S", ($self) => class SignUp extends $.$mac.MAC.CB
        {
            /*void */ B(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                if (this.iL)
                {
                    __builder.AM(0, "<p b-m9x6l6rp3k>\u23F3 Loading...</p>");
                }
                else 
                {
                    __builder.OE(1, "div");
                    __builder.AA$2(2, "class", "login-container");
                    __builder.AA$4(3, "b-m9x6l6rp3k");
                    __builder.AM(4, "<h3 b-m9x6l6rp3k>Sign Up</h3>\n        ");
                    __builder.OE(5, "div");
                    __builder.AA$2(6, "class", "sub-container");
                    __builder.AA$4(7, "b-m9x6l6rp3k");
                    __builder.OE(8, "div");
                    __builder.AA$2(9, "class", "input-container");
                    __builder.AA$4(10, "b-m9x6l6rp3k");
                    __builder.AM(11, "<label for=\"username\" b-m9x6l6rp3k>Firstname</label>\n                ");
                    __builder.OE(12, "input");
                    __builder.AA$2(13, "type", "text");
                    __builder.AA$2(14, "placeholder", "enter firstname...");
                    __builder.AA$2(15, "value", $.$mac.MAC.B.FV$28(this.f$1, null));
                    __builder.AA$6($.$mac.MAC.CE, 16, "onchange", $.$mac.MAC.ECF.CB$27($.$mac.MAC.EC$1.F$1, this, new ($.$$.S.A$1$$($.$$.S.S$1))().$ctor(this,  (/*__value*/ __value) =>
                    {
                        return this.f$1 = __value;
                    }, {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1414673,"h":0,"f":1048578}), this.f$1, null));
                    __builder.SU("value");
                    __builder.AA$4(17, "b-m9x6l6rp3k");
                    __builder.CE();
                    __builder.CE();
                    __builder.AM(18, "\n\n            ");
                    __builder.OE(19, "div");
                    __builder.AA$2(20, "class", "input-container");
                    __builder.AA$4(21, "b-m9x6l6rp3k");
                    __builder.AM(22, "<label for=\"username\" b-m9x6l6rp3k>Lastname</label>\n                ");
                    __builder.OE(23, "input");
                    __builder.AA$2(24, "type", "text");
                    __builder.AA$2(25, "placeholder", "enter lastname...");
                    __builder.AA$2(26, "value", $.$mac.MAC.B.FV$28(this.l, null));
                    __builder.AA$6($.$mac.MAC.CE, 27, "onchange", $.$mac.MAC.ECF.CB$27($.$mac.MAC.EC$1.F$1, this, new ($.$$.S.A$1$$($.$$.S.S$1))().$ctor(this,  (/*__value*/ __value) =>
                    {
                        return this.l = __value;
                    }, {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1414673,"h":0,"f":1048578}), this.l, null));
                    __builder.SU("value");
                    __builder.AA$4(28, "b-m9x6l6rp3k");
                    __builder.CE();
                    __builder.CE();
                    __builder.AM(29, "\n\n            ");
                    __builder.OE(30, "div");
                    __builder.AA$2(31, "class", "input-container");
                    __builder.AA$4(32, "b-m9x6l6rp3k");
                    __builder.AM(33, "<label for=\"username\" b-m9x6l6rp3k>Email</label>\n                ");
                    __builder.OE(34, "input");
                    __builder.AA$2(35, "type", "email");
                    __builder.AA$2(36, "placeholder", "enter email...");
                    __builder.AA$2(37, "value", $.$mac.MAC.B.FV$28(this.e, null));
                    __builder.AA$6($.$mac.MAC.CE, 38, "onchange", $.$mac.MAC.ECF.CB$27($.$mac.MAC.EC$1.F$1, this, new ($.$$.S.A$1$$($.$$.S.S$1))().$ctor(this,  (/**/ __value) =>
                    {
                        return this.e = __value;
                    }, {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1414673,"h":0,"f":1048578}), this.e, null));
                    __builder.SU("value");
                    __builder.AA$4(39, "b-m9x6l6rp3k");
                    __builder.CE();
                    __builder.CE();
                    __builder.AM(40, "\n\n            ");
                    __builder.OE(41, "div");
                    __builder.AA$2(42, "class", "input-container");
                    __builder.AA$4(43, "b-m9x6l6rp3k");
                    __builder.AM(44, "<label for=\"username\" b-m9x6l6rp3k>Username</label>\n                ");
                    __builder.OE(45, "input");
                    __builder.AA$2(46, "type", "text");
                    __builder.AA$2(47, "placeholder", "enter username...");
                    __builder.AA$2(48, "value", $.$mac.MAC.B.FV$28(this.u, null));
                    __builder.AA$6($.$mac.MAC.CE, 49, "onchange", $.$mac.MAC.ECF.CB$27($.$mac.MAC.EC$1.F$1, this, new ($.$$.S.A$1$$($.$$.S.S$1))().$ctor(this,  (/*__value*/ __value) =>
                    {
                        return this.u = __value;
                    }, {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1414673,"h":0,"f":1048578}), this.u, null));
                    __builder.SU("value");
                    __builder.AA$4(50, "b-m9x6l6rp3k");
                    __builder.CE();
                    __builder.CE();
                    __builder.AM(51, "\n\n            ");
                    __builder.OE(52, "div");
                    __builder.AA$2(53, "class", "input-container");
                    __builder.AA$4(54, "b-m9x6l6rp3k");
                    __builder.AM(55, "<label for=\"username\" b-m9x6l6rp3k>Date of Birth</label>\n                ");
                    __builder.OE(56, "input");
                    __builder.AA$2(57, "type", "date");
                    __builder.AA$2(58, "placeholder", "enter password...");
                    __builder.AA$2(59, "value", $.$mac.MAC.B.FV$16(this.dO?.Clone() ?? null, "yyyy-MM-dd", $.$$.SG.CI$1.IC));
                    __builder.AA$6($.$mac.MAC.CE, 60, "onchange", $.$mac.MAC.ECF.CB$15($.$mac.MAC.EC$1.F$1, this, new ($.$$.S.A$1$$($.$$.S.N$$($.$$.S.DT$1)))().$ctor(this,  (/**/ __value) =>
                    {
                        return this.dO = __value?.Clone() ?? null;
                    }, {"r":65537,"p":[{"n":"__value","p":$.$typeNullable($.$$.S.DT$1).$h}],"n":"","d":1414673,"h":0,"f":1048578}), this.dO?.Clone() ?? null, "yyyy-MM-dd", $.$$.SG.CI$1.IC));
                    __builder.SU("value");
                    __builder.AA$4(61, "b-m9x6l6rp3k");
                    __builder.CE();
                    __builder.CE();
                    __builder.AM(62, "\n\n            ");
                    __builder.OE(63, "div");
                    __builder.AA$2(64, "class", "input-container");
                    __builder.AA$4(65, "b-m9x6l6rp3k");
                    __builder.AM(66, "<label for=\"username\" b-m9x6l6rp3k>Role</label>\n                ");
                    __builder.OE(67, "select");
                    __builder.AA$2(68, "name", "");
                    __builder.AA$2(69, "id", "");
                    __builder.AA$2(70, "value", $.$mac.MAC.B.FV$28(this.r, null));
                    __builder.AA$6($.$mac.MAC.CE, 71, "onchange", $.$mac.MAC.ECF.CB$27($.$mac.MAC.EC$1.F$1, this, new ($.$$.S.A$1$$($.$$.S.S$1))().$ctor(this,  (/**/ __value) =>
                    {
                        return this.r = __value;
                    }, {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1414673,"h":0,"f":1048578}), this.r, null));
                    __builder.SU("value");
                    __builder.AA$4(72, "b-m9x6l6rp3k");
                    __builder.OE(73, "option");
                    __builder.AA$2(74, "value", "Admin");
                    __builder.AA$4(75, "b-m9x6l6rp3k");
                    __builder.AC$3(76, "Admin");
                    __builder.CE();
                    __builder.AM(77, "\n                    ");
                    __builder.OE(78, "option");
                    __builder.AA$2(79, "value", "User");
                    __builder.AA$4(80, "b-m9x6l6rp3k");
                    __builder.AC$3(81, "User");
                    __builder.CE();
                    __builder.CE();
                    __builder.CE();
                    __builder.AM(82, "\n\n            ");
                    __builder.OE(83, "div");
                    __builder.AA$2(84, "class", "input-container");
                    __builder.AA$4(85, "b-m9x6l6rp3k");
                    __builder.AM(86, "<label for=\"username\" b-m9x6l6rp3k>Password</label>\n                ");
                    __builder.OE(87, "input");
                    __builder.AA$2(88, "type", "password");
                    __builder.AA$2(89, "placeholder", "enter password...");
                    __builder.AA$2(90, "value", $.$mac.MAC.B.FV$28(this.p$1, null));
                    __builder.AA$6($.$mac.MAC.CE, 91, "onchange", $.$mac.MAC.ECF.CB$27($.$mac.MAC.EC$1.F$1, this, new ($.$$.S.A$1$$($.$$.S.S$1))().$ctor(this,  (/*__value*/ __value) =>
                    {
                        return this.p$1 = __value;
                    }, {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1414673,"h":0,"f":1048578}), this.p$1, null));
                    __builder.SU("value");
                    __builder.AA$4(92, "b-m9x6l6rp3k");
                    __builder.CE();
                    __builder.CE();
                    __builder.AM(93, "\n\n            ");
                    __builder.OE(94, "div");
                    __builder.AA$2(95, "class", "input-container");
                    __builder.AA$4(96, "b-m9x6l6rp3k");
                    __builder.AM(97, "<label for=\"username\" b-m9x6l6rp3k>Confirm password</label>\n                ");
                    __builder.OE(98, "input");
                    __builder.AA$2(99, "type", "password");
                    __builder.AA$2(100, "placeholder", "enter password...");
                    __builder.AA$2(101, "value", $.$mac.MAC.B.FV$28(this.cP, null));
                    __builder.AA$6($.$mac.MAC.CE, 102, "onchange", $.$mac.MAC.ECF.CB$27($.$mac.MAC.EC$1.F$1, this, new ($.$$.S.A$1$$($.$$.S.S$1))().$ctor(this,  (/*__value*/ __value) =>
                    {
                        return this.cP = __value;
                    }, {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1414673,"h":0,"f":1048578}), this.cP, null));
                    __builder.SU("value");
                    __builder.AA$4(103, "b-m9x6l6rp3k");
                    __builder.CE();
                    __builder.CE();
                    __builder.AM(104, "\n\n            ");
                    __builder.OE(105, "div");
                    __builder.AA$2(106, "class", "input-container");
                    __builder.AA$4(107, "b-m9x6l6rp3k");
                    __builder.OE(108, "button");
                    __builder.AA$6($.$macw.MACW.ME, 109, "onclick", $.$mac.MAC.EC$1.F$1.C$7($.$macw.MACW.ME, this, new ($.$$.S.F$$($.$$.STT.T))().$ctor(this, this.SU$1)));
                    __builder.AA$4(110, "b-m9x6l6rp3k");
                    __builder.AC$3(111, "Sign Up");
                    __builder.CE();
                    __builder.CE();
                    if (!this.A$1.IL)
                    {
                        __builder.OE(112, "p");
                        __builder.AA$4(113, "b-m9x6l6rp3k");
                        __builder.AC$3(114, this.eM);
                        __builder.CE();
                    }
                    __builder.OE(115, "div");
                    __builder.AA$2(116, "class", "signup");
                    __builder.AA$4(117, "b-m9x6l6rp3k");
                    __builder.AM(118, "<p b-m9x6l6rp3k>Already have an account?</p>\n                ");
                    __builder.OC($.$t.TC.B, 119);
                    __builder.AC(120, "BgColor", "rgb(127, 0, 127, 0.3)");
                    __builder.AC(121, "BtnText", "Login");
                    __builder.AC(122, "OnClick", $.$mac.MACC.R.TC($.$mac.MAC.EC$1, $.$mac.MAC.EC$1.F$1.C(this, new $.$$.S.A$2().$ctor(this,  () =>
                    {
                        return this.N.N("", false, false);
                    }, {"r":65537,"n":"","d":1414673,"h":0,"f":1048578}))));
                    __builder.CC();
                    __builder.CE();
                    __builder.CE();
                    __builder.CE();
                }
            }
            /*string*/ f$1 = null;
            /*string*/ l = null;
            /*string*/ e = null;
            /*string*/ r = null;
            /*DateTime?*/ dO = null;
            /*string*/ u = null;
            /*string*/ p$1 = null;
            /*string*/ cP = null;
            /*string*/ eM = null;
            /*bool*/ iL = true;
            /*List<UserModel>*/ u$1 = null;
            /*Task *//*async*/  OIA()
            {
                return $.$$.N.AR.A($.$$.STT.T, $.$$.S.V$2, async () => 
                {
                    this.iL = true;
                    await $.$$.STT.T.D$2(1000);
                    this.iL = false;
                });
            }
            /*void */ OI()
            {
                if (this.A$1.IL)
                {
                    this.N.N("dashboard", false, false);
                }
            }
            /*Task *//*async*/  OA(/*bool*/ firstRender)
            {
                return $.$$.N.AR.A($.$$.STT.T, $.$$.S.V$2, async () => 
                {
                    if (firstRender)
                    {
                        await this.L();
                        this.iL = false;
                        this.SH();
                    }
                });
            }
            /*Task *//*async*/  L()
            {
                return $.$$.N.AR.A($.$$.STT.T, $.$$.S.V$2, async () => 
                {
                    await this.A$1.LU();
                });
            }
            /*Task *//*async*/  SU$1()
            {
                return $.$$.N.AR.A($.$$.STT.T, $.$$.S.V$2, async () => 
                {
                    if ($.$$.S.S$1.o_I(this.p$1, this.cP))
                    {
                        this.eM = "\u26A0\uFE0F Passwords do not match.";
                        return;
                    }
                    /*var*/ let result = await this.A$1.SU$1(this.f$1, this.l, this.e, this.r, this.dO?.Clone() ?? null, this.u, this.p$1, this.cP);
                    if ($.$$.S.S$1.o_E(result, "Success"))
                    {
                        this.N.N("signupsuccess", false, false);
                    }
                    else 
                    {
                        this.eM = `\u26A0\uFE0F ${result}`;
                    }
                });
            }
            /*Task *//*async*/  SU()
            {
                return $.$$.N.AR.A($.$$.STT.T, $.$$.S.V$2, async () => 
                {
                    await this.A$1.SU();
                });
            }
            /*IJSRuntime*/ JS = null;
            /*NavigationManager*/ N = null;
            /*Taskman.Services.AuthService*/ A$1 = null;
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.f$1 = "";
                this.l = "";
                this.e = "";
                this.r = "";
                this.dO = null;
                this.u = "";
                this.p$1 = "";
                this.cP = "";
                this.eM = "";
                this.u$1 = new ($.$$.SCG.L$$($.$t.U))().$ctor$1();
                this.JS = null;
                this.N = null;
                this.A$1 = null;
            }
            static $h = 1414673;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":524318,"g":{"r":0,"d":0,"h":90195727889,"f":2},"s":{"r":0,"d":0,"h":94490695185,"f":2},"n":"JS","d":1414673,"h":85900760593,"f":2,"a":[{"t":4259848,"c":21479096328}]},{"p":4980744,"g":{"r":0,"d":0,"h":107375597073,"f":2},"s":{"r":0,"d":0,"h":111670564369,"f":2},"n":"Nav","o":"N","d":1414673,"h":103080629777,"f":2,"a":[{"t":4259848,"c":21479096328}]},{"p":2070033,"g":{"r":0,"d":0,"h":124555466257,"f":2},"s":{"r":0,"d":0,"h":128850433553,"f":2},"n":"Auth","o":"A$1","d":1414673,"h":120260498961,"f":2,"a":[{"t":4259848,"c":21479096328}]}],"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","o":"B","d":1414673,"h":4296381969,"f":32772},{"r":133169153,"n":"OnInitializedAsync","o":"OIA","d":1414673,"h":55835989521,"f":36868},{"r":65537,"n":"OnInitialized","o":"OI","d":1414673,"h":60130956817,"f":32772},{"r":133169153,"p":[{"n":"firstRender","p":262145}],"n":"OnAfterRenderAsync","o":"OA","d":1414673,"h":64425924113,"f":36868},{"r":133169153,"n":"LoadUsers","o":"L","d":1414673,"h":68720891409,"f":4098},{"r":133169153,"n":"SignupUser","o":"SU$1","d":1414673,"h":73015858705,"f":4098},{"r":133169153,"n":"SaveUser","o":"SU","d":1414673,"h":77310826001,"f":4098}],"l":[{"t":1310721,"n":"firstname","o":"f$1","d":1414673,"h":8591349265,"f":2},{"t":1310721,"n":"lastname","o":"l","d":1414673,"h":12886316561,"f":2},{"t":1310721,"n":"email","o":"e","d":1414673,"h":17181283857,"f":2},{"t":1310721,"n":"role","o":"r","d":1414673,"h":21476251153,"f":2},{"t":$.$typeNullable($.$$.S.DT$1).$h,"n":"dateOfBirth","o":"dO","d":1414673,"h":25771218449,"f":2},{"t":1310721,"n":"username","o":"u","d":1414673,"h":30066185745,"f":2},{"t":1310721,"n":"password","o":"p$1","d":1414673,"h":34361153041,"f":2},{"t":1310721,"n":"confirmPassword","o":"cP","d":1414673,"h":38656120337,"f":2},{"t":1310721,"n":"errorMessage","o":"eM","d":1414673,"h":42951087633,"f":2},{"t":262145,"n":"isLoading","o":"iL","d":1414673,"h":47246054929,"f":2},{"t":$.$$.SCG.L$$($.$t.U).$h,"n":"users","o":"u$1","d":1414673,"h":51541022225,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":1414673,"h":133145400849,"f":1}],"i":[2752520,3145736,3080200],"h":1414673,"a":[{"t":9895944,"c":4304863240,"a":[{"v":"/signup","t":1310721}]}]}; }
            static get $b() { return $.$mac.MAC.CB; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IC, $.$mac.MAC.IHE, $.$mac.MAC.IH ]; }
            static get $fullName() { return `Taskman.Components.Pages.SignUp`; }
        });
        
        $asm.$cls("$t.TC.N", ($self) => class NavBar extends $.$mac.MAC.CB
        {
            /*void */ B(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OE(0, "div");
                __builder.AA$2(1, "class", "mobile-menu");
                __builder.AA$4(2, "b-jig343vp1k");
                __builder.OE(3, "div");
                __builder.AA$2(4, "style", "background: purple; padding: 5px 10px;");
                __builder.AA$4(5, "b-jig343vp1k");
                __builder.OE(6, "div");
                __builder.AA$2(7, "style", "display: flex; justify-content: space-between; align-items: center;");
                __builder.AA$4(8, "b-jig343vp1k");
                __builder.OE(9, "div");
                __builder.AA$2(10, "style", "display: flex; align-items: center;");
                __builder.AA$6($.$macw.MACW.ME, 11, "onclick", $.$mac.MAC.EC$1.F$1.C$5($.$macw.MACW.ME, this, new $.$$.S.A$2().$ctor(this,  () =>
                {
                    return this.N.N("", false, false);
                }, {"r":65537,"n":"","d":1021457,"h":0,"f":1048578})));
                __builder.AA$4(12, "b-jig343vp1k");
                __builder.AM(13, "<img src=\"favicon.png\" alt style=\"width: 30px; height: 30px; margin-right: 5px; border-radius: 5px;\" b-jig343vp1k>\n                ");
                __builder.AM(14, "<div style=\"display: flex; margin-top: 10px;\" b-jig343vp1k><h3 style=\"color: white;\" b-jig343vp1k>Tasks</h3>\n                    <h3 style=\"color: orange;\" b-jig343vp1k>Man</h3></div>");
                __builder.CE();
                __builder.AM(15, "\n            ");
                __builder.OE(16, "button");
                __builder.AA$2(17, "style", "background: none; border: none;");
                __builder.AA$6($.$macw.MACW.ME, 18, "onclick", $.$mac.MAC.EC$1.F$1.C$5($.$macw.MACW.ME, this, new $.$$.S.A$2().$ctor(this, this.SM)));
                __builder.AA$4(19, "b-jig343vp1k");
                __builder.AM(20, "<img src=\"menu.png\" alt style=\"width: 30px; height: 30px; border: 2px solid white; border-radius: 50%; color: color: white;\" b-jig343vp1k>");
                __builder.CE();
                __builder.CE();
                __builder.CE();
                __builder.CE();
                __builder.AM(21, "\n\n");
                __builder.OE(22, "div");
                __builder.AA$2(23, "class", "mobile-nav");
                __builder.AA$4(24, "b-jig343vp1k");
                __builder.OE(25, "nav");
                __builder.AA$2(26, "style", "display: flex; justify-content: space-around; margin-bottom: 20px;");
                __builder.AA$4(27, "b-jig343vp1k");
                __builder.OE(28, "div");
                __builder.AA$2(29, "class", "mobile");
                __builder.AA$4(30, "b-jig343vp1k");
                __builder.OC($.$macw.MACR$2.NL$1, 31);
                __builder.AC(32, "style", "text-decoration: none; color: white; font-weight: bold; font-size: 15px;");
                __builder.AC(33, "href", "dashboard");
                __builder.AC(34, "Match", $.$box($.$mac.MACC.R.TC($.$macw.MACR$2.NLM, 1/*NavLinkMatch.All*/), $.$macw.MACR$2.NLM));
                __builder.AA(35, "ChildContent", new $.$mac.MAC.RF().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.AM(36, "\uD83C\uDFE0 Home");
                })));
                __builder.CC();
                __builder.CE();
                if ($.$$.S.S$1.o_E(this.A$1.R$1, "Admin"))
                {
                    __builder.OE(37, "div");
                    __builder.AA$2(38, "class", "mobile");
                    __builder.AA$4(39, "b-jig343vp1k");
                    __builder.OC($.$macw.MACR$2.NL$1, 40);
                    __builder.AC(41, "style", "text-decoration: none; color: white; font-weight: bold; font-size: 15px;");
                    __builder.AC(42, "href", "tasks");
                    __builder.AC(43, "Match", $.$box($.$mac.MACC.R.TC($.$macw.MACR$2.NLM, 1/*NavLinkMatch.All*/), $.$macw.MACR$2.NLM));
                    __builder.AA(44, "ChildContent", new $.$mac.MAC.RF().$ctor(this, ( (/*__builder2*/ __builder2) =>
                    {
                        __builder2.AM(45, "\uD83D\uDCDD Tasks");
                    })));
                    __builder.CC();
                    __builder.CE();
                    __builder.AM(46, "\n            ");
                    __builder.OE(47, "div");
                    __builder.AA$2(48, "class", "mobile");
                    __builder.AA$4(49, "b-jig343vp1k");
                    __builder.OC($.$macw.MACR$2.NL$1, 50);
                    __builder.AC(51, "style", "text-decoration: none; color: white; font-weight: bold; font-size: 15px;");
                    __builder.AC(52, "href", "profile");
                    __builder.AC(53, "Match", $.$box($.$mac.MACC.R.TC($.$macw.MACR$2.NLM, 1/*NavLinkMatch.All*/), $.$macw.MACR$2.NLM));
                    __builder.AA(54, "ChildContent", new $.$mac.MAC.RF().$ctor(this, ( (/*__builder2*/ __builder2) =>
                    {
                        __builder2.AM(55, "\uD83D\uDC64 Profile");
                    })));
                    __builder.CC();
                    __builder.CE();
                }
                __builder.OE(56, "div");
                __builder.AA$2(57, "class", "mobile");
                __builder.AA$4(58, "b-jig343vp1k");
                __builder.OE(59, "p");
                __builder.AA$2(60, "style", "text-decoration: none; color: white; font-weight: bold; font-size: 15px;");
                __builder.AA$2(61, "Match", "NavLinkMatch.All");
                __builder.AA$4(62, "b-jig343vp1k");
                __builder.AM(63, "\uD83D\uDC64\n                ");
                __builder.AC$3(64, this.A$1.U);
                __builder.AM(65, " \uD83C\uDFF7\uFE0F ");
                __builder.AC$3(66, this.A$1.R$1);
                __builder.CE();
                __builder.CE();
                if (this.A$1.IL)
                {
                    __builder.OE(67, "div");
                    __builder.AA$2(68, "class", "mobile");
                    __builder.AA$4(69, "b-jig343vp1k");
                    __builder.OC($.$macw.MACR$2.NL$1, 70);
                    __builder.AC(71, "style", "text-decoration: none; color: white; font-weight: bold; font-size: 15px;");
                    __builder.AC(72, "href", "");
                    __builder.AC(73, "onclick", $.$mac.MAC.EC$1.F$1.C$5($.$macw.MACW.ME, this, new $.$$.S.A$2().$ctor(this, this.LU)));
                    __builder.AC(74, "Match", $.$box($.$mac.MACC.R.TC($.$macw.MACR$2.NLM, 1/*NavLinkMatch.All*/), $.$macw.MACR$2.NLM));
                    __builder.AA(75, "ChildContent", new $.$mac.MAC.RF().$ctor(this, ( (/**/ __builder2) =>
                    {
                        __builder2.OC($.$t.TC.B, 76);
                        __builder2.AC(77, "BgColor", "white");
                        __builder2.AC(78, "BtnText", "\u232B Logout");
                        __builder2.AC(79, "OnClick", $.$mac.MACC.R.TC($.$mac.MAC.EC$1, $.$mac.MAC.EC$1.F$1.C(this, new $.$$.S.A$2().$ctor(this, this.LU))));
                        __builder2.CC();
                    })));
                    __builder.CC();
                    __builder.CE();
                }
                else 
                {
                    __builder.OE(80, "div");
                    __builder.AA$2(81, "class", "mobile");
                    __builder.AA$4(82, "b-jig343vp1k");
                    __builder.OC($.$macw.MACR$2.NL$1, 83);
                    __builder.AC(84, "style", "text-decoration: none; color: white; font-weight: bold; font-size: 15px;");
                    __builder.AC(85, "href", "");
                    __builder.AC(86, "onclick", $.$mac.MAC.EC$1.F$1.C$5($.$macw.MACW.ME, this, new $.$$.S.A$2().$ctor(this, this.LU)));
                    __builder.AC(87, "Match", $.$box($.$mac.MACC.R.TC($.$macw.MACR$2.NLM, 1/*NavLinkMatch.All*/), $.$macw.MACR$2.NLM));
                    __builder.AA(88, "ChildContent", new $.$mac.MAC.RF().$ctor(this, ( (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OC($.$t.TC.B, 89);
                        __builder2.AC(90, "BgColor", "white");
                        __builder2.AC(91, "BtnText", "\uD83D\uDEAA Login");
                        __builder2.AC(92, "OnClick", $.$mac.MACC.R.TC($.$mac.MAC.EC$1, $.$mac.MAC.EC$1.F$1.C(this, new $.$$.S.A$2().$ctor(this, this.L))));
                        __builder2.CC();
                    })));
                    __builder.CC();
                    __builder.CE();
                }
                __builder.CE();
                __builder.CE();
                __builder.AM(93, "\n\n");
                __builder.OE(94, "div");
                __builder.AA$2(95, "class", "mobile-nav slide-from-top");
                __builder.AA$2(96, "style", "display:" + " " + (this.sM ? "block" : "none") + ";");
                __builder.AA$4(97, "b-jig343vp1k");
                __builder.OE(98, "nav");
                __builder.AA$2(99, "style", "display: flex; justify-content: space-around;");
                __builder.AA$4(100, "b-jig343vp1k");
                __builder.OE(101, "div");
                __builder.AA$2(102, "class", "mobile");
                __builder.AA$4(103, "b-jig343vp1k");
                __builder.OC($.$macw.MACR$2.NL$1, 104);
                __builder.AC(105, "style", "text-decoration: none; color: white; font-weight: bold; font-size: 15px;");
                __builder.AC(106, "href", "dashboard");
                __builder.AC(107, "Match", $.$box($.$mac.MACC.R.TC($.$macw.MACR$2.NLM, 1/*NavLinkMatch.All*/), $.$macw.MACR$2.NLM));
                __builder.AA(108, "ChildContent", new $.$mac.MAC.RF().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.AM(109, "\uD83C\uDFE0 Home");
                })));
                __builder.CC();
                __builder.CE();
                if ($.$$.S.S$1.o_E(this.A$1.R$1, "Admin"))
                {
                    __builder.OE(110, "div");
                    __builder.AA$2(111, "class", "mobile");
                    __builder.AA$4(112, "b-jig343vp1k");
                    __builder.OC($.$macw.MACR$2.NL$1, 113);
                    __builder.AC(114, "style", "text-decoration: none; color: white; font-weight: bold; font-size: 15px;");
                    __builder.AC(115, "href", "tasks");
                    __builder.AC(116, "Match", $.$box($.$mac.MACC.R.TC($.$macw.MACR$2.NLM, 1/*NavLinkMatch.All*/), $.$macw.MACR$2.NLM));
                    __builder.AA(117, "ChildContent", new $.$mac.MAC.RF().$ctor(this, ( (/*__builder2*/ __builder2) =>
                    {
                        __builder2.AM(118, "\uD83D\uDCDD Tasks");
                    })));
                    __builder.CC();
                    __builder.CE();
                    __builder.AM(119, "\n            ");
                    __builder.OE(120, "div");
                    __builder.AA$2(121, "class", "mobile");
                    __builder.AA$4(122, "b-jig343vp1k");
                    __builder.OC($.$macw.MACR$2.NL$1, 123);
                    __builder.AC(124, "style", "text-decoration: none; color: white; font-weight: bold; font-size: 15px;");
                    __builder.AC(125, "href", "profile");
                    __builder.AC(126, "Match", $.$box($.$mac.MACC.R.TC($.$macw.MACR$2.NLM, 1/*NavLinkMatch.All*/), $.$macw.MACR$2.NLM));
                    __builder.AA(127, "ChildContent", new $.$mac.MAC.RF().$ctor(this, ( (/*__builder2*/ __builder2) =>
                    {
                        __builder2.AM(128, "\uD83D\uDC64 Profile");
                    })));
                    __builder.CC();
                    __builder.CE();
                }
                __builder.OE(129, "div");
                __builder.AA$2(130, "class", "mobile");
                __builder.AA$4(131, "b-jig343vp1k");
                __builder.OE(132, "p");
                __builder.AA$2(133, "style", "text-decoration: none; color: white; font-weight: bold; font-size: 15px;");
                __builder.AA$2(134, "Match", "NavLinkMatch.All");
                __builder.AA$4(135, "b-jig343vp1k");
                __builder.AM(136, "\uD83D\uDC64\n                ");
                __builder.AC$3(137, this.A$1.U);
                __builder.AM(138, " \uD83C\uDFF7\uFE0F ");
                __builder.AC$3(139, this.A$1.R$1);
                __builder.CE();
                __builder.CE();
                if (this.A$1.IL)
                {
                    __builder.OE(140, "div");
                    __builder.AA$2(141, "class", "mobile");
                    __builder.AA$4(142, "b-jig343vp1k");
                    __builder.OC($.$macw.MACR$2.NL$1, 143);
                    __builder.AC(144, "style", "text-decoration: none; color: white; font-weight: bold; font-size: 15px;");
                    __builder.AC(145, "href", "");
                    __builder.AC(146, "onclick", $.$mac.MAC.EC$1.F$1.C$5($.$macw.MACW.ME, this, new $.$$.S.A$2().$ctor(this, this.LU)));
                    __builder.AC(147, "Match", $.$box($.$mac.MACC.R.TC($.$macw.MACR$2.NLM, 1/*NavLinkMatch.All*/), $.$macw.MACR$2.NLM));
                    __builder.AA(148, "ChildContent", new $.$mac.MAC.RF().$ctor(this, ( (/**/ __builder2) =>
                    {
                        __builder2.OC($.$t.TC.B, 149);
                        __builder2.AC(150, "BgColor", "white");
                        __builder2.AC(151, "BtnText", "\u232B Logout");
                        __builder2.AC(152, "OnClick", $.$mac.MACC.R.TC($.$mac.MAC.EC$1, $.$mac.MAC.EC$1.F$1.C(this, new $.$$.S.A$2().$ctor(this, this.LU))));
                        __builder2.CC();
                    })));
                    __builder.CC();
                    __builder.CE();
                }
                else 
                {
                    __builder.OE(153, "div");
                    __builder.AA$2(154, "class", "mobile");
                    __builder.AA$4(155, "b-jig343vp1k");
                    __builder.OC($.$macw.MACR$2.NL$1, 156);
                    __builder.AC(157, "style", "text-decoration: none; color: white; font-weight: bold; font-size: 15px;");
                    __builder.AC(158, "href", "");
                    __builder.AC(159, "onclick", $.$mac.MAC.EC$1.F$1.C$5($.$macw.MACW.ME, this, new $.$$.S.A$2().$ctor(this, this.LU)));
                    __builder.AC(160, "Match", $.$box($.$mac.MACC.R.TC($.$macw.MACR$2.NLM, 1/*NavLinkMatch.All*/), $.$macw.MACR$2.NLM));
                    __builder.AA(161, "ChildContent", new $.$mac.MAC.RF().$ctor(this, ( (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OC($.$t.TC.B, 162);
                        __builder2.AC(163, "BgColor", "white");
                        __builder2.AC(164, "BtnText", "\uD83D\uDEAA Login");
                        __builder2.AC(165, "OnClick", $.$mac.MACC.R.TC($.$mac.MAC.EC$1, $.$mac.MAC.EC$1.F$1.C(this, new $.$$.S.A$2().$ctor(this, this.L))));
                        __builder2.CC();
                    })));
                    __builder.CC();
                    __builder.CE();
                }
                __builder.CE();
                __builder.CE();
            }
            /*bool*/ sM = false;
            /*void */ SM()
            {
                this.sM = !this.sM;
            }
            /*void */ L()
            {
                this.N.N("", false, false);
            }
            /*void */ LU()
            {
                this.A$1.L$2();
                this.N.N("", false, false);
            }
            /*NavigationManager*/ N = null;
            /*Taskman.Services.AuthService*/ A$1 = null;
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.N = null;
                this.A$1 = null;
            }
            static $h = 1021457;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":4980744,"g":{"r":0,"d":0,"h":34360759825,"f":2},"s":{"r":0,"d":0,"h":38655727121,"f":2},"n":"Nav","o":"N","d":1021457,"h":30065792529,"f":2,"a":[{"t":4259848,"c":21479096328}]},{"p":2070033,"g":{"r":0,"d":0,"h":51540629009,"f":2},"s":{"r":0,"d":0,"h":55835596305,"f":2},"n":"Auth","o":"A$1","d":1021457,"h":47245661713,"f":2,"a":[{"t":4259848,"c":21479096328}]}],"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","o":"B","d":1021457,"h":4295988753,"f":32772},{"r":65537,"n":"ShowMenu","o":"SM","d":1021457,"h":12885923345,"f":2},{"r":65537,"n":"LoginUser","o":"L","d":1021457,"h":17180890641,"f":2},{"r":65537,"n":"LogoutUser","o":"LU","d":1021457,"h":21475857937,"f":2}],"l":[{"t":262145,"n":"showMenu","o":"sM","d":1021457,"h":8590956049,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":1021457,"h":60130563601,"f":1}],"i":[2752520,3145736,3080200],"h":1021457}; }
            static get $b() { return $.$mac.MAC.CB; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IC, $.$mac.MAC.IHE, $.$mac.MAC.IH ]; }
            static get $fullName() { return `Taskman.Components.NavBar`; }
        });
        
        $asm.$cls("$t.TCP.D", ($self) => class Dashboard extends $.$mac.MAC.CB
        {
            /*void */ B(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OC($.$t.TC.N, 0);
                __builder.CC();
                if (this.iL)
                {
                    __builder.OC($.$t.TC.L, 1);
                    __builder.AC(2, "LoadingState", "\u23F3 Loading Dashboard...");
                    __builder.CC();
                }
                else 
                {
                    __builder.OE(3, "div");
                    __builder.AA$2(4, "style", "margin-top: 20px;");
                    __builder.AM(5, "<h3>\uD83D\uDCCA Dashboard</h3>\n        ");
                    __builder.OE(6, "p");
                    __builder.AC$3(7, "Welcome back, ");
                    __builder.AC$3(8, this.A$1.U);
                    __builder.AM(9, " \uD83D\uDD90\uFE0F");
                    __builder.CE();
                    if (this.A$1.IL)
                    {
                        __builder.OE(10, "div");
                        __builder.AA$2(11, "style", "display: flex; gap: 10px; padding: 10px 0 30px;");
                        __builder.OC($.$t.TC.SC, 12);
                        __builder.AC(13, "Icon", "\uD83D\uDCDD");
                        __builder.AC(14, "Label", "Total");
                        __builder.AC(15, "Value", $.$mac.MACC.R.TC($.$$.S.S$1, this.tC));
                        __builder.CC();
                        __builder.AM(16, "\n                ");
                        __builder.OC($.$t.TC.SC, 17);
                        __builder.AC(18, "Icon", "\u2705");
                        __builder.AC(19, "Label", "Done");
                        __builder.AC(20, "Value", $.$mac.MACC.R.TC($.$$.S.S$1, this.cC));
                        __builder.CC();
                        __builder.AM(21, "\n                ");
                        __builder.OC($.$t.TC.SC, 22);
                        __builder.AC(23, "Icon", "\u23F3");
                        __builder.AC(24, "Label", "Left");
                        __builder.AC(25, "Value", $.$mac.MACC.R.TC($.$$.S.S$1, this.pC));
                        __builder.CC();
                        __builder.CE();
                    }
                    else 
                    {
                        __builder.OE(26, "div");
                        __builder.AA$2(27, "style", "display: flex; gap: 10px; padding: 10px 0 30px;");
                        __builder.OC($.$t.TC.SC, 28);
                        __builder.AC(29, "Icon", "\uD83D\uDCDD");
                        __builder.AC(30, "Label", "Total");
                        __builder.AC(31, "Value", "0");
                        __builder.CC();
                        __builder.AM(32, "\n                ");
                        __builder.OC($.$t.TC.SC, 33);
                        __builder.AC(34, "Icon", "\u2705");
                        __builder.AC(35, "Label", "Done");
                        __builder.AC(36, "Value", "0");
                        __builder.CC();
                        __builder.AM(37, "\n                ");
                        __builder.OC($.$t.TC.SC, 38);
                        __builder.AC(39, "Icon", "\u23F3");
                        __builder.AC(40, "Label", "Left");
                        __builder.AC(41, "Value", "0");
                        __builder.CC();
                        __builder.CE();
                    }
                    if ($.$$.S.S$1.o_E(this.A$1.R$1, "Admin"))
                    {
                        __builder.OE(42, "div");
                        __builder.AM(43, "<h5>\u2699\uFE0F Admin Panel</h5>\n                ");
                        __builder.OE(44, "div");
                        __builder.OC($.$t.TC.B, 45);
                        __builder.AC(46, "BgColor", "rgb(140, 0, 140, 0.3)");
                        __builder.AC(47, "BtnText", "\uD83D\uDCC1 Go to Tasks");
                        __builder.AC(48, "OnClick", $.$mac.MACC.R.TC($.$mac.MAC.EC$1, $.$mac.MAC.EC$1.F$1.C(this, new $.$$.S.A$2().$ctor(this, this.GTT))));
                        __builder.CC();
                        __builder.AM(49, "\n                    ");
                        __builder.OC($.$t.TC.B, 50);
                        __builder.AC(51, "BgColor", "rgb(135, 135, 135, 0.3)");
                        __builder.AC(52, "BtnText", "\uD83D\uDE4E\u200D\u2642\uFE0F View Profile");
                        __builder.AC(53, "OnClick", $.$mac.MACC.R.TC($.$mac.MAC.EC$1, $.$mac.MAC.EC$1.F$1.C(this, new $.$$.S.A$2().$ctor(this, this.V))));
                        __builder.CC();
                        __builder.CE();
                        __builder.CE();
                    }
                    __builder.CE();
                    if (!this.A$1.IL)
                    {
                        __builder.OC($.$t.TC.NL, 54);
                        __builder.AC(55, "Title", "User not logged in....");
                        __builder.AC(56, "SubTitle", "Click to login...");
                        __builder.CC();
                    }
                }
            }
            /*bool*/ iL = true;
            /*List<AppTask> */ get t$1()
            {
                return this.TS.I$G() ?? new ($.$$.SCG.L$$($.$t.A))().$ctor$1();
            }
            /*string */ get tC()
            {
                return $.$$.S.I$4.T.call(this.t$1.C$3);
            }
            /*string */ get cC()
            {
                return $.$$.S.I$4.T.call($.$sl.SL.E.C$6($.$t.A, this.t$1, new ($.$$.S.F$$$($.$t.A, $.$$.S.B$2))().$ctor(this,  (/*t*/ t) =>
                {
                    return t.IC;
                }, {"r":262145,"p":[{"n":"t","p":103953}],"n":"","d":1218065,"h":0,"f":1048578})));
            }
            /*string */ get pC()
            {
                return $.$$.S.I$4.T.call($.$sl.SL.E.C$6($.$t.A, this.t$1, new ($.$$.S.F$$$($.$t.A, $.$$.S.B$2))().$ctor(this,  (/*t*/ t) =>
                {
                    return !t.IC;
                }, {"r":262145,"p":[{"n":"t","p":103953}],"n":"","d":1218065,"h":0,"f":1048578})));
            }
            /*void */ GTT()
            {
                return this.N.N("tasks", false, false);
            }
            /*void */ V()
            {
                return this.N.N("profile", false, false);
            }
            /*Task *//*async*/  OIA()
            {
                return $.$$.N.AR.A($.$$.STT.T, $.$$.S.V$2, async () => 
                {
                    if (this.iL)
                    {
                        this.iL = true;
                        await $.$$.STT.T.D$2(500);
                        this.iL = false;
                    }
                });
            }
            /*Task *//*async*/  OA(/*bool*/ firstRender)
            {
                return $.$$.N.AR.A($.$$.STT.T, $.$$.S.V$2, async () => 
                {
                    if (firstRender)
                    {
                        await this.TS.I$L();
                        this.SH();
                    }
                });
            }
            /*NavigationManager*/ N = null;
            /*ITaskService*/ TS = null;
            /*Taskman.Services.AuthService*/ A$1 = null;
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.N = null;
                this.TS = null;
                this.A$1 = null;
            }
            static $h = 1218065;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":$.$$.SCG.L$$($.$t.A).$h,"g":{"r":0,"d":0,"h":17181087249,"f":2},"n":"tasks","o":"t$1","d":1218065,"h":12886119953,"f":2},{"p":1310721,"g":{"r":0,"d":0,"h":25771021841,"f":2},"n":"tasksCount","o":"tC","d":1218065,"h":21476054545,"f":2},{"p":1310721,"g":{"r":0,"d":0,"h":34360956433,"f":2},"n":"completedCount","o":"cC","d":1218065,"h":30065989137,"f":2},{"p":1310721,"g":{"r":0,"d":0,"h":42950891025,"f":2},"n":"pendingCount","o":"pC","d":1218065,"h":38655923729,"f":2},{"p":4980744,"g":{"r":0,"d":0,"h":73015662097,"f":2},"s":{"r":0,"d":0,"h":77310629393,"f":2},"n":"Nav","o":"N","d":1218065,"h":68720694801,"f":2,"a":[{"t":4259848,"c":21479096328}]},{"p":169489,"g":{"r":0,"d":0,"h":90195531281,"f":2},"s":{"r":0,"d":0,"h":94490498577,"f":2},"n":"TaskService","o":"TS","d":1218065,"h":85900563985,"f":2,"a":[{"t":4259848,"c":21479096328}]},{"p":2070033,"g":{"r":0,"d":0,"h":107375400465,"f":2},"s":{"r":0,"d":0,"h":111670367761,"f":2},"n":"Auth","o":"A$1","d":1218065,"h":103080433169,"f":2,"a":[{"t":4259848,"c":21479096328}]}],"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","o":"B","d":1218065,"h":4296185361,"f":32772},{"r":65537,"n":"GoToTask","o":"GTT","d":1218065,"h":47245858321,"f":2},{"r":65537,"n":"ViewProfile","o":"V","d":1218065,"h":51540825617,"f":2},{"r":133169153,"n":"OnInitializedAsync","o":"OIA","d":1218065,"h":55835792913,"f":36868},{"r":133169153,"p":[{"n":"firstRender","p":262145}],"n":"OnAfterRenderAsync","o":"OA","d":1218065,"h":60130760209,"f":36868}],"l":[{"t":262145,"n":"isLoading","o":"iL","d":1218065,"h":8591152657,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":1218065,"h":115965335057,"f":1}],"i":[2752520,3145736,3080200],"h":1218065,"a":[{"t":9895944,"c":4304863240,"a":[{"v":"/dashboard","t":1310721}]}]}; }
            static get $b() { return $.$mac.MAC.CB; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IC, $.$mac.MAC.IHE, $.$mac.MAC.IH ]; }
            static get $fullName() { return `Taskman.Components.Pages.Dashboard`; }
        });
        
        $asm.$cls("$t.TCP.T", ($self) => class Tasks extends $.$mac.MAC.CB
        {
            /*void */ B(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OC($.$t.TC.N, 0);
                __builder.CC();
                __builder.AM(1, "\n\n");
                __builder.OE(2, "div");
                __builder.AA$2(3, "class", "mobile");
                __builder.AA$2(4, "style", "display: flex; flex-wrap: wrap; margin-bottom: 20px; gap: 5px; justify-content: space-between;");
                __builder.AA$4(5, "b-aeb0nnurq8");
                __builder.AM(6, "<h3 style=\"margin-bottom: 30px; margin-top: 20px;\" b-aeb0nnurq8>\uD83D\uDCDD Task Manager </h3>");
                if (this.A$1.IL)
                {
                    if ($.$sl.SL.E.A$5($.$t.A, this.t$1))
                    {
                        __builder.OE(7, "div");
                        __builder.AA$2(8, "class", "i");
                        __builder.AA$2(9, "style", "margin-top: 20px;");
                        __builder.AA$4(10, "b-aeb0nnurq8");
                        __builder.OE(11, "i");
                        __builder.AA$2(12, "style", "font-size: 15px; color: white; margin-top: 5px; background: rgb(0, 107, 0, 0.7); padding: 0 30px; margin: 0; border-bottom-right-radius: 20px; border-top-right-radius: 20px; display: flex; align-items: center;");
                        __builder.AA$4(13, "b-aeb0nnurq8");
                        __builder.AC$2(14, $.$box(this.t$1.C$3, $.$$.S.I$4));
                        __builder.AC$3(15, " task(s) added");
                        __builder.CE();
                        __builder.CE();
                    }
                }
                __builder.CE();
                __builder.AM(16, "\n\n    ");
                __builder.AM(17, "<h5 b-aeb0nnurq8>Priority</h5>\n\n    ");
                __builder.OE(18, "div");
                __builder.AA$2(19, "style", "display: flex; flex-wrap: wrap; gap: 10px;");
                __builder.AA$4(20, "b-aeb0nnurq8");
                __builder.OE(21, "select");
                __builder.AA$4(22, "name");
                __builder.AA$4(23, "id");
                __builder.AA$2(24, "class", "opt-btn");
                __builder.AA$2(25, "style", "padding: 10px; border: none; background: rgb(255, 166, 0, 0.2); width: 50%; border-radius: 10px;");
                __builder.AA$4(26, "b-aeb0nnurq8");
                __builder.OE(27, "option");
                __builder.AA$2(28, "value", "All");
                __builder.AA$4(29, "b-aeb0nnurq8");
                __builder.AC$3(30, "All");
                __builder.CE();
                __builder.AM(31, "\n            ");
                __builder.OE(32, "option");
                __builder.AA$2(33, "value", "Pending");
                __builder.AA$4(34, "b-aeb0nnurq8");
                __builder.AC$3(35, "Pending");
                __builder.CE();
                __builder.AM(36, "\n            ");
                __builder.OE(37, "option");
                __builder.AA$2(38, "value", "Done");
                __builder.AA$4(39, "b-aeb0nnurq8");
                __builder.AC$3(40, "Done");
                __builder.CE();
                __builder.CE();
                __builder.AM(41, "\n        ");
                __builder.OE(42, "div");
                __builder.AA$2(43, "class", "opt-btn");
                __builder.AA$4(44, "b-aeb0nnurq8");
                __builder.OE(45, "button");
                __builder.AA$2(46, "class", "btn-hov");
                __builder.AA$2(47, "style", "padding: 10px; border: none; background: rgb(255, 166, 0, 0.2); border-radius: 10px;");
                __builder.AA$6($.$macw.MACW.ME, 48, "onclick", $.$mac.MAC.EC$1.F$1.C$5($.$macw.MACW.ME, this, new $.$$.S.A$2().$ctor(this, this.AT$1)));
                __builder.AA$4(49, "b-aeb0nnurq8");
                __builder.AC$3(50, "All");
                __builder.CE();
                __builder.AM(51, "\n            ");
                __builder.OE(52, "button");
                __builder.AA$2(53, "class", "btn-hov");
                __builder.AA$2(54, "style", "padding: 10px; border: none; background: rgb(255, 166, 0, 0.2); border-radius: 10px;");
                __builder.AA$6($.$macw.MACW.ME, 55, "onclick", $.$mac.MAC.EC$1.F$1.C$5($.$macw.MACW.ME, this, new $.$$.S.A$2().$ctor(this, this.P$1)));
                __builder.AA$4(56, "b-aeb0nnurq8");
                __builder.AM(57, "\u23F3\n                Pending");
                __builder.CE();
                __builder.AM(58, "\n                ");
                __builder.OE(59, "button");
                __builder.AA$2(60, "class", "btn-hov");
                __builder.AA$2(61, "style", "padding: 10px; border: none; background: rgb(255, 166, 0, 0.2); border-radius: 10px;");
                __builder.AA$6($.$macw.MACW.ME, 62, "onclick", $.$mac.MAC.EC$1.F$1.C$5($.$macw.MACW.ME, this, new $.$$.S.A$2().$ctor(this, this.C$1)));
                __builder.AA$4(63, "b-aeb0nnurq8");
                __builder.AM(64, "\u2705\n                    Done");
                __builder.CE();
                __builder.CE();
                __builder.CE();
                __builder.AM(65, "\n\n            ");
                __builder.OE(66, "div");
                __builder.AA$2(67, "style", "display: flex; flex-wrap: wrap; gap: 10px; padding: 30px 0; width: 100%");
                __builder.AA$4(68, "b-aeb0nnurq8");
                __builder.OE(69, "div");
                __builder.AA$4(70, "style");
                __builder.AA$4(71, "b-aeb0nnurq8");
                __builder.AM(72, "<label for=\"title\" b-aeb0nnurq8>Title:</label>\n                    ");
                __builder.OE(73, "input");
                __builder.AA$2(74, "type", "text");
                __builder.AA$2(75, "placeholder", "enter task title...");
                __builder.AA$2(76, "style", "padding: 10px; border: none; background: rgb(255, 166, 0, 0.2); width: 100%; border-radius: 10px;");
                __builder.AA$2(77, "value", $.$mac.MAC.B.FV$28(this.tT, null));
                __builder.AA$6($.$mac.MAC.CE, 78, "onchange", $.$mac.MAC.ECF.CB$27($.$mac.MAC.EC$1.F$1, this, new ($.$$.S.A$1$$($.$$.S.S$1))().$ctor(this,  (/*__value*/ __value) =>
                {
                    return this.tT = __value;
                }, {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1480209,"h":0,"f":1048578}), this.tT, null));
                __builder.SU("value");
                __builder.AA$4(79, "b-aeb0nnurq8");
                __builder.CE();
                __builder.CE();
                __builder.AM(80, "\n\n                ");
                __builder.OE(81, "div");
                __builder.AA$2(82, "class", "input-container");
                __builder.AA$4(83, "b-aeb0nnurq8");
                __builder.AM(84, "<label for=\"title\" b-aeb0nnurq8>Priority:</label>\n                    ");
                __builder.OE(85, "select");
                __builder.AA$2(86, "name", "Priority");
                __builder.AA$2(87, "id", "");
                __builder.AA$2(88, "style", "padding: 13px; border: none; background: rgb(255, 166, 0, 0.2); width: 100%; border-radius: 10px;");
                __builder.AA$1(89, "value", $.$mac.MAC.B.FV$31($.$t.P$1, this.tP, null));
                __builder.AA$6($.$mac.MAC.CE, 90, "onchange", $.$mac.MAC.ECF.CB$61($.$t.P$1, $.$mac.MAC.EC$1.F$1, this, new ($.$$.S.A$1$$($.$t.P$1))().$ctor(this,  (/*__value*/ __value) =>
                {
                    return this.tP = __value;
                }, {"r":65537,"p":[{"n":"__value","p":366097}],"n":"","d":1480209,"h":0,"f":1048578}), this.tP, null));
                __builder.SU("value");
                __builder.AA$4(91, "b-aeb0nnurq8");
                /*var*/ let values = $.$$.S.E$3.GV$2($.$t.P$1);
                let $i1 = 0;
                let $arr1 = values;
                while ($i1 < $arr1.length)
                {
                    let value = $arr1[$i1++];
                    __builder.OE(92, "option");
                    __builder.AA$1(93, "value", $.$box(value, $.$t.P$1));
                    __builder.AA$4(94, "b-aeb0nnurq8");
                    if (value === 1/*Priority.Low*/)
                    {
                        __builder.AM(95, "\uD83D\uDD34");
                    }
                    else if (value === 2/*Priority.Medium*/)
                    {
                        __builder.AM(96, "\uD83D\uDFE1");
                    }
                    else if (value === 3/*Priority.High*/)
                    {
                        __builder.AM(97, "\uD83D\uDFE2");
                    }
                    __builder.AC$3(98, $.$$.S.E$3.TST($.$t.P$1, $.$$.S.UI$2, value));
                    __builder.CE();
                }
                __builder.CE();
                __builder.CE();
                __builder.CE();
                __builder.AM(99, "\n\n            ");
                __builder.OE(100, "div");
                __builder.AA$2(101, "style", "display: flex; flex-wrap: wrap; gap: 10px; margin-bottom: 50px;");
                __builder.AA$4(102, "b-aeb0nnurq8");
                __builder.OC($.$t.TC.B, 103);
                __builder.AC(104, "BgColor", "rgb(140, 0, 140, 0.3)");
                __builder.AC(105, "BtnText", "\u2795 AddTask");
                __builder.AC(106, "OnClick", $.$mac.MACC.R.TC($.$mac.MAC.EC$1, $.$mac.MAC.EC$1.F$1.C$3(this, new ($.$$.S.F$$($.$$.STT.T))().$ctor(this, this.AT))));
                __builder.CC();
                __builder.CE();
                __builder.AM(107, "\n\n            <hr b-aeb0nnurq8>");
                if (!this.A$1.IL)
                {
                    __builder.OC($.$t.TC.NL, 108);
                    __builder.AC(109, "Title", "User not logged in...");
                    __builder.AC(110, "SubTitle", "Click to log in...");
                    __builder.CC();
                }
                else 
                {
                    __builder.OE(111, "div");
                    __builder.AA$2(112, "style", "display: flex; justify-content: space-between; margin-bottom: 10px;");
                    __builder.AA$4(113, "b-aeb0nnurq8");
                    __builder.OE(114, "input");
                    __builder.AA$2(115, "type", "text");
                    __builder.AA$2(116, "placeholder", "search task");
                    __builder.AA$2(117, "value", $.$mac.MAC.B.FV$28(this.s, null));
                    __builder.AA$6($.$mac.MAC.CE, 118, "oninput", $.$mac.MAC.ECF.CB$27($.$mac.MAC.EC$1.F$1, this, new ($.$$.S.A$1$$($.$$.S.S$1))().$ctor(this,  (/**/ __value) =>
                    {
                        return this.s = __value;
                    }, {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1480209,"h":0,"f":1048578}), this.s, null));
                    __builder.SU("value");
                    __builder.AA$4(119, "b-aeb0nnurq8");
                    __builder.CE();
                    __builder.CE();
                    if (!$.$$.S.S$1.INOW(this.s) && !$.$sl.SL.E.A$5($.$t.A, this.FI))
                    {
                        __builder.AM(120, "<p style=\"margin:10px 0; color: red;\" b-aeb0nnurq8>\uD83D\uDD0D No task(s) found.</p>");
                    }
                    __builder.OE(121, "div");
                    __builder.AA$2(122, "style", "display: flex; flex-wrap: wrap; justify-content: space-between; padding-top: 10px; margin-top: 40px;");
                    __builder.AA$4(123, "b-aeb0nnurq8");
                    __builder.AM(124, "<h4 b-aeb0nnurq8>\uD83D\uDCC1 Available Task</h4>");
                    if (this.cC)
                    {
                        __builder.OE(125, "div");
                        __builder.AA$4(126, "b-aeb0nnurq8");
                        __builder.OC($.$t.TC.C, 127);
                        __builder.AC(128, "Title", "Sure to clear all tasks?");
                        __builder.AC(129, "Text1", "\u2705 Clear");
                        __builder.AC(130, "Text2", "\u274C Cancel");
                        __builder.AC(131, "ConfirmBtn", $.$mac.MACC.R.TC($.$mac.MAC.EC$1, $.$mac.MAC.EC$1.F$1.C$3(this, new ($.$$.S.F$$($.$$.STT.T))().$ctor(this, this.CT))));
                        __builder.AC(132, "CancelBtn", $.$mac.MACC.R.TC($.$mac.MAC.EC$1, $.$mac.MAC.EC$1.F$1.C(this, new $.$$.S.A$2().$ctor(this,  () =>
                        {
                            return this.cC = false;
                        }, {"r":65537,"n":"","d":1480209,"h":0,"f":1048578}))));
                        __builder.CC();
                        __builder.CE();
                    }
                    else 
                    {
                        __builder.OC($.$t.TC.B, 133);
                        __builder.AC(134, "BgColor", "rgb(140, 0, 140, 0.3)");
                        __builder.AC(135, "BtnText", "\uD83E\uDDF9 Clear All Tasks");
                        __builder.AC(136, "OnClick", $.$mac.MACC.R.TC($.$mac.MAC.EC$1, $.$mac.MAC.EC$1.F$1.C(this, new $.$$.S.A$2().$ctor(this,  () =>
                        {
                            return this.cC = true;
                        }, {"r":65537,"n":"","d":1480209,"h":0,"f":1048578}))));
                        __builder.CC();
                    }
                    __builder.CE();
                    if ($.$sl.SL.E.A$5($.$t.A, this.t$1))
                    {
                        if (this.iL)
                        {
                            __builder.OC($.$t.TC.LC, 137);
                            __builder.AC(138, "LoadingState", "\u23F3 Loading Available Tasks...");
                            __builder.CC();
                        }
                        else 
                        {
                            __builder.OE(139, "div");
                            __builder.AA$2(140, "style", "background: rgba(228, 228, 228, 0.1); max-height: 700px; overflow: scroll;");
                            __builder.AA$4(141, "b-aeb0nnurq8");
                            __builder.OE(142, "ul");
                            __builder.AA$2(143, "style", "margin: 20px 0px 40px;");
                            __builder.AA$4(144, "b-aeb0nnurq8");
                            var $en5 = this.FI.SCG$IE$$$G();
                            while ($en5.SC$1$IE$1$M())
                            {
                                var task = $en5.SCG$IE$1$$$C;
                                {
                                    if (this.a === task.Id)
                                    {
                                        __builder.OC($.$t.TC.C, 145);
                                        __builder.AC(146, "Title", "Confirm to complete this task.");
                                        __builder.AC(147, "Text1", "\u2705 Confirm");
                                        __builder.AC(148, "Text2", "\u274C Cancel");
                                        __builder.AC(149, "ConfirmBtn", $.$mac.MACC.R.TC($.$mac.MAC.EC$1, $.$mac.MAC.EC$1.F$1.C$3(this, new ($.$$.S.F$$($.$$.STT.T))().$ctor(this,  () =>
                                        {
                                            return this.CT$1(task.Id);
                                        }, {"r":133169153,"n":"","d":1480209,"h":0,"f":1048578}))));
                                        __builder.AC(150, "CancelBtn", $.$mac.MACC.R.TC($.$mac.MAC.EC$1, $.$mac.MAC.EC$1.F$1.C(this, new $.$$.S.A$2().$ctor(this,  () =>
                                        {
                                            return this.a = null;
                                        }, {"r":65537,"n":"","d":1480209,"h":0,"f":1048578}))));
                                        __builder.CC();
                                    }
                                    else if (task.IC)
                                    {
                                        __builder.OE(151, "li");
                                        __builder.AA$2(152, "class", task.IC ? "disabled-container" : "");
                                        __builder.AA$2(153, "style", "margin: 10px 0; padding: 7px; list-style: none; border-left: 3px solid purple; text-decoration: line-through; background: rgb(129, 129, 129, 0.1);");
                                        __builder.AA$4(154, "b-aeb0nnurq8");
                                        __builder.OC($.$t.TC.T, 155);
                                        __builder.AC(156, "Task", $.$mac.MACC.R.TC($.$t.A, task));
                                        __builder.AC(157, "TaskIdToDelete", $.$box($.$mac.MACC.R.TC($.$typeNullable($.$$.S.I$4), this.tI), $.$$.S.N$$($.$$.S.I$4)));
                                        __builder.AC(158, "OnRequestDelete", $.$mac.MACC.R.TC($.$mac.MAC.E$$($.$$.S.I$4), $.$mac.MAC.EC$1.F$1.C$6($.$$.S.I$4, this, new ($.$$.S.A$1$$($.$$.S.I$4))().$ctor(this, this.SD))));
                                        __builder.AC(159, "OnDelete", $.$mac.MACC.R.TC($.$mac.MAC.E$$($.$$.S.I$4), $.$mac.MAC.EC$1.F$1.C$8($.$$.S.I$4, this, new ($.$$.S.F$$$($.$$.S.I$4, $.$$.STT.T))().$ctor(this, this.DT))));
                                        __builder.AC(160, "OnToggle", $.$mac.MACC.R.TC($.$mac.MAC.E$$($.$$.S.I$4), $.$mac.MAC.EC$1.F$1.C$8($.$$.S.I$4, this, new ($.$$.S.F$$$($.$$.S.I$4, $.$$.STT.T))().$ctor(this, this.TT))));
                                        __builder.CC();
                                        __builder.CE();
                                    }
                                    else 
                                    {
                                        __builder.OE(161, "li");
                                        __builder.AA$2(162, "class", "slide-from-top");
                                        __builder.AA$2(163, "style", "margin: 10px 0; padding: 7px; list-style: none; border-left: 3px solid purple; background: rgb(129, 129, 129, 0.1);");
                                        __builder.AA$4(164, "b-aeb0nnurq8");
                                        __builder.OC($.$t.TC.T, 165);
                                        __builder.AC(166, "Task", $.$mac.MACC.R.TC($.$t.A, task));
                                        __builder.AC(167, "TaskIdToDelete", $.$box($.$mac.MACC.R.TC($.$typeNullable($.$$.S.I$4), this.tI), $.$$.S.N$$($.$$.S.I$4)));
                                        __builder.AC(168, "OnRequestDelete", $.$mac.MACC.R.TC($.$mac.MAC.E$$($.$$.S.I$4), $.$mac.MAC.EC$1.F$1.C$6($.$$.S.I$4, this, new ($.$$.S.A$1$$($.$$.S.I$4))().$ctor(this, this.SD))));
                                        __builder.AC(169, "OnDelete", $.$mac.MACC.R.TC($.$mac.MAC.E$$($.$$.S.I$4), $.$mac.MAC.EC$1.F$1.C$8($.$$.S.I$4, this, new ($.$$.S.F$$$($.$$.S.I$4, $.$$.STT.T))().$ctor(this, this.DT))));
                                        __builder.AC(170, "OnToggle", $.$mac.MACC.R.TC($.$mac.MAC.E$$($.$$.S.I$4), $.$mac.MAC.EC$1.F$1.C$8($.$$.S.I$4, this, new ($.$$.S.F$$$($.$$.S.I$4, $.$$.STT.T))().$ctor(this, this.TT))));
                                        __builder.CC();
                                        __builder.CE();
                                    }
                                }
                            }
                            __builder.CE();
                            __builder.CE();
                        }
                    }
                    else 
                    {
                        if (!this.iL)
                        {
                            __builder.AM(171, "<div style=\"display: flex; width: 100%; height: 100%; background: rgb(137, 137, 137, 0.1); margin: 20px 0 30px; height: 50vh; align-items: center; justify-content: center;\" b-aeb0nnurq8><b b-aeb0nnurq8>\uD83D\uDCC1 No tasks added.</b></div>");
                        }
                        else 
                        {
                            __builder.OE(172, "div");
                            __builder.AA$2(173, "style", "margin-bottom: 60px;");
                            __builder.AA$4(174, "b-aeb0nnurq8");
                            __builder.OC($.$t.TC.LC, 175);
                            __builder.AC(176, "LoadingState", "\u23F3 Loading Available Tasks...");
                            __builder.CC();
                            __builder.CE();
                        }
                    }
                }
                if (this.tI !== null)
                {
                    __builder.OC($.$t.TC.C, 177);
                    __builder.AC(178, "Title", "Sure to delete this task?");
                    __builder.AC(179, "Text1", "\u2705 Delete");
                    __builder.AC(180, "Text2", "\u274C Cancel");
                    __builder.AC(181, "ConfirmBtn", $.$mac.MACC.R.TC($.$mac.MAC.EC$1, $.$mac.MAC.EC$1.F$1.C$3(this, new ($.$$.S.F$$($.$$.STT.T))().$ctor(this,  () =>
                    {
                        return this.DT($.$$.S.N$$($.$$.S.I$4).V$get.call(this.tI));
                    }, {"r":133169153,"n":"","d":1480209,"h":0,"f":1048578}))));
                    __builder.AC(182, "CancelBtn", $.$mac.MACC.R.TC($.$mac.MAC.EC$1, $.$mac.MAC.EC$1.F$1.C(this, new $.$$.S.A$2().$ctor(this,  () =>
                    {
                        return this.tI = null;
                    }, {"r":65537,"n":"","d":1480209,"h":0,"f":1048578}))));
                    __builder.CC();
                }
            }
            /*string*/ tT = null;
            /*string*/ s = null;
            /*bool*/ iL = false;
            /*int?*/ tI = null;
            /*Priority*/ tP = 0;
            /*string */ get tTT()
            {
                return $.$$.S.S$1.TU.call($.$$.S.S$1.T$1.call(this.tT));
            }
            /*List<AppTask>*/ t$1 = null;
            /*List<AppTask>*/ cT = null;
            /*bool*/ cC = false;
            /*AppTask*/ T$1 = null;
            /*string*/ cF = null;
            /*bool*/ ID = false;
            /*int?*/ a = null;
            /*void */ SDD(/*int*/ id)
            {
                this.tI = id;
            }
            /*void */ HD()
            {
                this.tI = -1;
            }
            /*Task *//*async*/  DS()
            {
                return $.$$.N.AR.A($.$$.STT.T, $.$$.S.V$2, async () => 
                {
                    if ($.$$.S.N$$($.$$.S.I$4).H$get.call(this.tI))
                    {
                        await this.DT($.$$.S.N$$($.$$.S.I$4).V$get.call(this.tI));
                        this.tI = null;
                    }
                });
            }
            /*Task *//*async*/  CT$1(/*int*/ id)
            {
                return $.$$.N.AR.A($.$$.STT.T, $.$$.S.V$2, async () => 
                {
                    await this.TS.I$T(id);
                    this.RT();
                    this.a = null;
                });
            }
            /*void */ SD(/*int*/ id)
            {
                this.tI = id;
            }
            /*IEnumerable<AppTask> */ get FI()
            {
                /*var*/ let allTasks = this.t$1;
                /*var*/ let statusFiltered = (() =>
                {
                    if (this.cF === "Pending")
                    {
                        return $.$sl.SL.E.W($.$t.A, allTasks, new ($.$$.S.F$$$($.$t.A, $.$$.S.B$2))().$ctor(this,  (/*t*/ t) =>
                        {
                            return !t.IC;
                        }, {"r":262145,"p":[{"n":"t","p":103953}],"n":"","d":1480209,"h":0,"f":1048578}));
                    }
                    if (this.cF === "Done")
                    {
                        return $.$sl.SL.E.W($.$t.A, allTasks, new ($.$$.S.F$$$($.$t.A, $.$$.S.B$2))().$ctor(this,  (/**/ t) =>
                        {
                            return t.IC;
                        }, {"r":262145,"p":[{"n":"t","p":103953}],"n":"","d":1480209,"h":0,"f":1048578}));
                    }
                    return allTasks;
                })();
                if (!$.$$.S.S$1.INOW(this.s))
                {
                    statusFiltered = $.$sl.SL.E.W($.$t.A, statusFiltered, new ($.$$.S.F$$$($.$t.A, $.$$.S.B$2))().$ctor(this,  (/*t*/ t) =>
                    {
                        return $.$$.S.S$1.o_I(t.T$1, null) && $.$$.S.S$1.C$30.call(t.T$1, this.s, 5/*StringComparison.OrdinalIgnoreCase*/);
                    }, {"r":262145,"p":[{"n":"t","p":103953}],"n":"","d":1480209,"h":0,"f":1048578}));
                }
                return statusFiltered;
            }
            /*Task */ OIA()
            {
                this.iL = true;
                return $.$$.STT.T.CT$1;
            }
            /*bool*/ _l = false;
            /*Task *//*async*/  OA(/*bool*/ firstRender)
            {
                return $.$$.N.AR.A($.$$.STT.T, $.$$.S.V$2, async () => 
                {
                    if (firstRender && !this._l)
                    {
                        this._l = true;
                        await this.TS.I$L();
                        this.RT();
                        this.iL = false;
                        this.SH();
                    }
                });
            }
            /*void */ OI()
            {
                this.TS.I$a(new $.$$.S.A$2().$ctor(this, this.H));
            }
            /*Task *//*async*/  AT()
            {
                return $.$$.N.AR.A($.$$.STT.T, $.$$.S.V$2, async () => 
                {
                    if ($.$$.S.S$1.INO(this.tT) || this.tP === 0/*Priority.Select_Priority*/)
                    {
                        return;
                    }
                    this.TS.I$A(this.tTT, this.tP);
                    this.tI = null;
                    this.tT = "";
                    this.tP = 0/*Priority.Select_Priority*/;
                    this.RT();
                    if (this.A$1.IL)
                    {
                        await this.ST();
                    }
                });
            }
            /*Task *//*async*/  ET(/*int*/ id)
            {
                return $.$$.N.AR.A($.$$.STT.T, $.$$.S.V$2, async () => 
                {
                    if ($.$$.S.S$1.INO(this.tT) || this.tP === 0/*Priority.Select_Priority*/)
                    {
                        return;
                    }
                    this.TS.I$E(id, this.tTT, this.tP);
                    this.tT = "";
                    this.tP = 0/*Priority.Select_Priority*/;
                    this.RT();
                    if (this.A$1.IL)
                    {
                        await this.ST();
                    }
                });
            }
            /*Task *//*async*/  MC()
            {
                return $.$$.N.AR.A($.$$.STT.T, $.$$.S.V$2, async () => 
                {
                    this.TS.I$M(this.tTT, this.tP);
                    this.RT();
                    if (this.A$1.IL)
                    {
                        await this.ST();
                    }
                });
            }
            /*void */ AT$1()
            {
                this.cF = "All";
            }
            /*void */ P$1()
            {
                this.cF = "Pending";
            }
            /*void */ C$1()
            {
                this.cF = "Done";
            }
            /*Task */ TT(/*int*/ id)
            {
                $.$scsl.S.C.WL$18(`Clicked Task: ${id}`);
                this.a = id;
                this.ID = true;
                this.SH();
                return $.$$.STT.T.CT$1;
            }
            /*Task *//*async*/  DT(/*int*/ id)
            {
                return $.$$.N.AR.A($.$$.STT.T, $.$$.S.V$2, async () => 
                {
                    this.TS.I$D(id);
                    this.tI = null;
                    this.tI = null;
                    this.RT();
                    if (this.A$1.IL)
                    {
                        await this.ST();
                    }
                });
            }
            /*Task *//*async*/  CT()
            {
                return $.$$.N.AR.A($.$$.STT.T, $.$$.S.V$2, async () => 
                {
                    this.TS.I$C();
                    this.cC = false;
                    if (this.A$1.IL)
                    {
                        await this.ST();
                        await this.TS.I$L();
                    }
                });
            }
            /*Task *//*async*/  ST()
            {
                return $.$$.N.AR.A($.$$.STT.T, $.$$.S.V$2, async () => 
                {
                    await this.TS.I$S();
                });
            }
            /*void */ RT()
            {
                this.t$1 = this.TS.I$G();
                this.SH();
            }
            /*void */ H()
            {
                this.RT();
                this.IA(new $.$$.S.A$2().$ctor(this, this.SH));
            }
            /*void */ D$1()
            {
                this.TS.I$r(new $.$$.S.A$2().$ctor(this, this.H));
            }
            /*IJSRuntime*/ JS = null;
            /*NavigationManager*/ N = null;
            /*ITaskService*/ TS = null;
            /*Taskman.Services.AuthService*/ A$1 = null;
            //Generated interface implemetation for System.IDisposable.Dispose()
            S$ID$D()
            {
                return this.D$1(...arguments);
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.tT = "";
                this.s = "";
                this.iL = false;
                this.t$1 = new ($.$$.SCG.L$$($.$t.A))().$ctor$1();
                this.cT = new ($.$$.SCG.L$$($.$t.A))().$ctor$1();
                this.T$1 = new $.$t.A().$ctor$1();
                this.cF = "All";
                this.JS = null;
                this.N = null;
                this.TS = null;
                this.A$1 = null;
            }
            static $h = 1480209;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":262145,"g":{"r":0,"d":0,"h":25771283985,"f":2},"s":{"r":0,"d":0,"h":30066251281,"f":2},"n":"isLoading","o":"iL","d":1480209,"h":21476316689,"f":2},{"p":1310721,"g":{"r":0,"d":0,"h":47246120465,"f":2},"n":"trimmedTaskTitle","o":"tTT","d":1480209,"h":42951153169,"f":2},{"p":$.$$.SCG.IE$$($.$t.A).$h,"g":{"r":0,"d":0,"h":107375662609,"f":2},"n":"FilteredItems","o":"FI","d":1480209,"h":103080695313,"f":2},{"p":524318,"g":{"r":0,"d":0,"h":193275008529,"f":2},"s":{"r":0,"d":0,"h":197569975825,"f":2},"n":"JS","d":1480209,"h":188980041233,"f":2,"a":[{"t":4259848,"c":21479096328}]},{"p":4980744,"g":{"r":0,"d":0,"h":210454877713,"f":2},"s":{"r":0,"d":0,"h":214749845009,"f":2},"n":"Nav","o":"N","d":1480209,"h":206159910417,"f":2,"a":[{"t":4259848,"c":21479096328}]},{"p":169489,"g":{"r":0,"d":0,"h":227634746897,"f":2},"s":{"r":0,"d":0,"h":231929714193,"f":2},"n":"TaskService","o":"TS","d":1480209,"h":223339779601,"f":2,"a":[{"t":4259848,"c":21479096328}]},{"p":2070033,"g":{"r":0,"d":0,"h":244814616081,"f":2},"s":{"r":0,"d":0,"h":249109583377,"f":2},"n":"Auth","o":"A$1","d":1480209,"h":240519648785,"f":2,"a":[{"t":4259848,"c":21479096328}]}],"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","o":"B","d":1480209,"h":4296447505,"f":32772},{"r":65537,"p":[{"n":"id","p":655361}],"n":"ShowDeleteDialog","o":"SDD","d":1480209,"h":81605858833,"f":2},{"r":65537,"n":"HideDeleteDialog","o":"HD","d":1480209,"h":85900826129,"f":2},{"r":133169153,"n":"DeleteSelectedTask","o":"DS","d":1480209,"h":90195793425,"f":4098},{"r":133169153,"p":[{"n":"id","p":655361}],"n":"CompleteTask","o":"CT$1","d":1480209,"h":94490760721,"f":4098},{"r":65537,"p":[{"n":"id","p":655361}],"n":"ShowDeleteConfirmation","o":"SD","d":1480209,"h":98785728017,"f":2},{"r":133169153,"n":"OnInitializedAsync","o":"OIA","d":1480209,"h":111670629905,"f":32772},{"r":133169153,"p":[{"n":"firstRender","p":262145}],"n":"OnAfterRenderAsync","o":"OA","d":1480209,"h":120260564497,"f":36868},{"r":65537,"n":"OnInitialized","o":"OI","d":1480209,"h":124555531793,"f":32772},{"r":133169153,"n":"AddTask","o":"AT","d":1480209,"h":128850499089,"f":4098},{"r":133169153,"p":[{"n":"id","p":655361}],"n":"EditTask","o":"ET","d":1480209,"h":133145466385,"f":4098},{"r":133169153,"n":"MoveCompletedTask","o":"MC","d":1480209,"h":137440433681,"f":4098},{"r":65537,"n":"AllTasks","o":"AT$1","d":1480209,"h":141735400977,"f":2},{"r":65537,"n":"Pending","o":"P$1","d":1480209,"h":146030368273,"f":2},{"r":65537,"n":"Completed","o":"C$1","d":1480209,"h":150325335569,"f":2},{"r":133169153,"p":[{"n":"id","p":655361}],"n":"ToggleTask","o":"TT","d":1480209,"h":154620302865,"f":2},{"r":133169153,"p":[{"n":"id","p":655361}],"n":"DeleteTask","o":"DT","d":1480209,"h":158915270161,"f":4098},{"r":133169153,"n":"ClearTask","o":"CT","d":1480209,"h":163210237457,"f":4098},{"r":133169153,"n":"SaveTask","o":"ST","d":1480209,"h":167505204753,"f":4098},{"r":65537,"n":"RefreshTasks","o":"RT","d":1480209,"h":171800172049,"f":2},{"r":65537,"n":"HandleStateChanged","o":"H","d":1480209,"h":176095139345,"f":2},{"r":65537,"n":"Dispose","o":"D$1","d":1480209,"h":180390106641,"f":1}],"l":[{"t":1310721,"n":"taskTitle","o":"tT","d":1480209,"h":8591414801,"f":2},{"t":1310721,"n":"searchTask","o":"s","d":1480209,"h":12886382097,"f":2},{"t":$.$typeNullable($.$$.S.I$4).$h,"n":"taskIdToDelete","o":"tI","d":1480209,"h":34361218577,"f":2},{"t":366097,"n":"taskPriority","o":"tP","d":1480209,"h":38656185873,"f":2},{"t":$.$$.SCG.L$$($.$t.A).$h,"n":"tasks","o":"t$1","d":1480209,"h":51541087761,"f":1},{"t":$.$$.SCG.L$$($.$t.A).$h,"n":"completedTasks","o":"cT","d":1480209,"h":55836055057,"f":1},{"t":262145,"n":"confirmClear","o":"cC","d":1480209,"h":60131022353,"f":1},{"t":103953,"n":"Taskss","o":"T$1","d":1480209,"h":64425989649,"f":2},{"t":1310721,"n":"currentFilter","o":"cF","d":1480209,"h":68720956945,"f":2},{"t":262145,"n":"IsDisabled","o":"ID","d":1480209,"h":73015924241,"f":2},{"t":$.$typeNullable($.$$.S.I$4).$h,"n":"activeNotifyTaskId","o":"a","d":1480209,"h":77310891537,"f":2},{"t":262145,"n":"_loaded","o":"_l","d":1480209,"h":115965597201,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":1480209,"h":253404550673,"f":1}],"i":[2752520,3145736,3080200,57540609],"h":1480209,"a":[{"t":9895944,"c":4304863240,"a":[{"v":"/tasks","t":1310721}]}]}; }
            static get $b() { return $.$mac.MAC.CB; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IC, $.$mac.MAC.IHE, $.$mac.MAC.IH, $.$$.S.ID ]; }
            static get $fullName() { return `Taskman.Components.Pages.Tasks`; }
        });
        
        $asm.$cls("$t.TL.M", ($self) => class MainLayout extends $.$mac.MAC.LC
        {
            /*void */ B(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OE(0, "div");
                __builder.AA$2(1, "class", "page");
                __builder.AA$4(2, "b-9e607fbywf");
                __builder.OE(3, "main");
                __builder.AA$4(4, "b-9e607fbywf");
                __builder.OE(5, "article");
                __builder.AA$2(6, "class", "content");
                __builder.AA$2(7, "style", "padding: 10px;");
                __builder.AA$4(8, "b-9e607fbywf");
                __builder.AC$5(9, this.B$1);
                __builder.CE();
                __builder.CE();
                __builder.CE();
                __builder.AM(10, "\n\n");
                __builder.AM(11, "<div id=\"blazor-error-ui\" data-nosnippet b-9e607fbywf>\n    An unhandled error has occurred.\n    <a href=\".\" class=\"reload\" b-9e607fbywf>Reload</a>\n    <span class=\"dismiss\" b-9e607fbywf>\uD83D\uDDD9</span></div>");
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 1873425;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":4653064,"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","o":"B","d":1873425,"h":4296840721,"f":32772}],"c":[{"n":".ctor","o":"$ctor$3","d":1873425,"h":8591808017,"f":1}],"i":[2752520,3145736,3080200],"h":1873425}; }
            static get $b() { return $.$mac.MAC.LC; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IC, $.$mac.MAC.IHE, $.$mac.MAC.IH ]; }
            static get $fullName() { return `Taskman.Layout.MainLayout`; }
        });
        
        $asm.$str("$t.P$1", ($self) => class Priority extends $.$$.S.E$3
        {
            static Select_Priority = 0;
            static Low = 1;
            static Medium = 2;
            static High = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Select_Priority": 0n,
                    "Low": 1n,
                    "Medium": 2n,
                    "High": 3n
                };
            }
            static $h = 366097;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.S.I$4; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":366097,"n":"Select_Priority","o":"S_","d":366097,"h":4295333393,"f":33},{"t":366097,"n":"Low","o":"L","d":366097,"h":8590300689,"f":33},{"t":366097,"n":"Medium","o":"M$1","d":366097,"h":12885267985,"f":33},{"t":366097,"n":"High","o":"H$1","d":366097,"h":17180235281,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":366097,"h":21475202577,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":366097}; }
            static get $b() { return $.$$.S.E$3; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IC$1, $.$$.S.IS, $.$$.S.IF$1, $.$$.S.IC$2 ]; }
            static get $fullName() { return `Priority`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.Extensions.Validation", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.Logging", "NetJs.Microsoft.JSInterop.WebAssembly", "NetJs.Microsoft.AspNetCore.Components.WebAssembly", "NetJs.Microsoft.CSharp", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument"))