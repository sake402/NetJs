
(function ($global, $, $spc, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sri, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mam, $mep, $meca, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mxdi, $sca, $meo, $meda, $meoc, $mxdg, $mela, $maa, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sipl, $stew, $stj, $mac, $mev, $srsp, $macf, $med, $mj, $macw, $mefa, $mef, $sifw, $mefp, $mecf, $mecj, $mel, $mjw, $macwa, $mc, $slq, $snhj, $stec, $swh, $sxx, $sxxx) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Taskman", 
    {"g":1,"h":50336,"f":"Taskman","v":"1.0.0.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"Taskman","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.0.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.0\u002B6779361f5261a44420e4641fa63588bbe7bcfaa8","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"Taskman","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"Taskman","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.0.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$t.ITaskService", ($self) => class ITaskService
        {
            static $h = 181408;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":133300225,"n":"SaveTask","o":"ITaskService$SaveTask","d":181408,"h":17180050592,"f":257},{"r":133300225,"n":"LoadTasks","o":"ITaskService$LoadTasks","d":181408,"h":21475017888,"f":257},{"r":$.$spc.System.Collections.Generic.List$$($.$t.AppTask).$h,"n":"GetAll","o":"ITaskService$GetAll","d":181408,"h":25769985184,"f":257},{"r":65537,"p":[{"n":"title","p":1310721},{"n":"priority","p":378016}],"n":"Add","o":"ITaskService$Add","d":181408,"h":30064952480,"f":257},{"r":65537,"p":[{"n":"id","p":655361},{"n":"title","p":1310721},{"n":"priority","p":378016}],"n":"Edit","o":"ITaskService$Edit","d":181408,"h":34359919776,"f":257},{"r":65537,"p":[{"n":"title","p":1310721},{"n":"priority","p":378016}],"n":"MoveTask","o":"ITaskService$MoveTask","d":181408,"h":38654887072,"f":257},{"r":65537,"p":[{"n":"id","p":655361}],"n":"Delete","o":"ITaskService$Delete","d":181408,"h":42949854368,"f":257},{"r":65537,"n":"ClearAllTask","o":"ITaskService$ClearAllTask","d":181408,"h":47244821664,"f":257},{"r":133300225,"p":[{"n":"id","p":655361}],"n":"ToggleCompleted","o":"ITaskService$ToggleCompleted","d":181408,"h":51539788960,"f":257},{"r":655361,"n":"GetCompletedCount","o":"ITaskService$GetCompletedCount","d":181408,"h":55834756256,"f":257},{"r":655361,"n":"GetPendingCount","o":"ITaskService$GetPendingCount","d":181408,"h":60129723552,"f":257}],"e":[{"e":11665409,"m":{"r":65537,"p":[{"n":"value","p":11665409}],"n":"add_OnChange","o":"ITaskService$add_OnChange","d":181408,"h":4295148704,"f":257},"r":{"r":65537,"p":[{"n":"value","p":11665409}],"n":"remove_OnChange","o":"ITaskService$remove_OnChange","d":181408,"h":8590116000,"f":257},"n":"OnChange","o":"ITaskService$OnChange","d":181408,"h":12885083296,"f":257}],"h":181408}; }
            static get $fullName() { return `ITaskService`; }
        });
        
        $asm.$cls("$t.UserModel", ($self) => class UserModel extends $.$spc.System.Object
        {
            /*string*/ FirstName = null;
            /*string*/ LastName = null;
            /*string*/ Email = null;
            /*DateTime?*/ DateOfBirth = null;
            /*string*/ Username = null;
            /*string*/ Password = null;
            /*string*/ ConfirmPassword = null;
            /*string*/ Role = null;
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.FirstName = "";
                this.LastName = "";
                this.Email = "";
                this.DateOfBirth = null;
                this.Username = "";
                this.Password = "";
                this.ConfirmPassword = "";
                this.Role = "";
            }
            static $h = 2213024;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12887114912,"f":1},"s":{"r":0,"d":0,"h":17182082208,"f":1},"n":"FirstName","d":2213024,"h":8592147616,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":30066984096,"f":1},"s":{"r":0,"d":0,"h":34361951392,"f":1},"n":"LastName","d":2213024,"h":25772016800,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":47246853280,"f":1},"s":{"r":0,"d":0,"h":51541820576,"f":1},"n":"Email","d":2213024,"h":42951885984,"f":1},{"p":$.$typeNullable($.$spc.System.DateTime).$h,"g":{"r":0,"d":0,"h":64426722464,"f":1},"s":{"r":0,"d":0,"h":68721689760,"f":1},"n":"DateOfBirth","d":2213024,"h":60131755168,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":81606591648,"f":1},"s":{"r":0,"d":0,"h":85901558944,"f":1},"n":"Username","d":2213024,"h":77311624352,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":98786460832,"f":1},"s":{"r":0,"d":0,"h":103081428128,"f":1},"n":"Password","d":2213024,"h":94491493536,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":115966330016,"f":1},"s":{"r":0,"d":0,"h":120261297312,"f":1},"n":"ConfirmPassword","d":2213024,"h":111671362720,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":133146199200,"f":1},"s":{"r":0,"d":0,"h":137441166496,"f":1},"n":"Role","d":2213024,"h":128851231904,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":2213024,"h":141736133792,"f":1}],"h":2213024}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `UserModel`; }
        });
        
        $asm.$cls("$t.AppTask", ($self) => class AppTask extends $.$spc.System.Object
        {
            /*int*/ Id = 0;
            /*string*/ Title = null;
            /*Priority*/ Priority = 0;
            /*bool*/ IsComplete = false;
            /*string*/ Date = null;
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Title = "";
                this.Priority = 2;
                this.IsComplete = false;
                this.Date = "";
            }
            static $h = 115872;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885017760,"f":1},"s":{"r":0,"d":0,"h":17179985056,"f":1},"n":"Id","d":115872,"h":8590050464,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":30064886944,"f":1},"s":{"r":0,"d":0,"h":34359854240,"f":1},"n":"Title","d":115872,"h":25769919648,"f":1},{"p":378016,"g":{"r":0,"d":0,"h":47244756128,"f":1},"s":{"r":0,"d":0,"h":51539723424,"f":1},"n":"Priority","d":115872,"h":42949788832,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":64424625312,"f":1},"s":{"r":0,"d":0,"h":68719592608,"f":1},"n":"IsComplete","d":115872,"h":60129658016,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":81604494496,"f":1},"s":{"r":0,"d":0,"h":85899461792,"f":1},"n":"Date","d":115872,"h":77309527200,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":115872,"h":90194429088,"f":1}],"h":115872}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `AppTask`; }
        });
        
        $asm.$cls("$t.Taskman._Imports", ($self) => class _Imports extends $.$spc.System.Object
        {
            /*void */ Execute()
            {
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 509088;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"n":"Execute","d":509088,"h":4295476384,"f":4}],"c":[{"n":".ctor","o":"$ctor$1","d":509088,"h":8590443680,"f":1}],"h":509088}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Taskman._Imports`; }
        });
        
        $asm.$cls("$t.Program", ($self) => class Program
        {
            static async $$$(args)
            {
                /*var*/ let builder = $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyHostBuilder.CreateDefault(args);
                builder.RootComponents.Add$1($.$t.Taskman.App, "#app");
                builder.RootComponents.Add$1($.$macw.Microsoft.AspNetCore.Components.Web.HeadOutlet, "head::after");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddScoped$4($.$t.Taskman.Services.AuthService, builder.Services);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddScoped$2($.$t.ITaskService, $.$t.TaskService, builder.Services);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddScoped$5($.$snh.System.Net.Http.HttpClient, builder.Services, new ($.$spc.System.Func$$$($.$scm.System.IServiceProvider, $.$snh.System.Net.Http.HttpClient))().$ctor(this,  (/**/ sp) =>
                {
                    return (() =>
                    {
                        //new $.$snh.System.Net.Http.HttpClient()
                        const $t1 = $.$snh.System.Net.Http.HttpClient;
                        const $i1 = new $t1();
                        $i1.$ctor$3();
                        $i1.BaseAddress = new $.$spu.System.Uri().$ctor$2(builder.HostEnvironment.Microsoft$AspNetCore$Components$WebAssembly$Hosting$IWebAssemblyHostEnvironment$BaseAddress);
                        return $i1;
                    })();
                }, {"r":6422573,"p":[{"n":"sp","p":327717}],"n":"","d":443552,"h":0,"f":1048578}));
                await builder.Build().RunAsync();
            }
            static $h = 443552;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":133300225,"p":[{"n":"args","p":0}],"n":"\u003CMain\u003E$","o":"$$$","d":443552,"h":4295410848,"f":4130}],"c":[{"n":".ctor","o":"$ctor$1","d":443552,"h":8590378144,"f":1}],"h":443552}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Program`; }
        });
        
        $asm.$cls("$t.Taskman.Components._Imports", ($self) => class _Imports extends $.$spc.System.Object
        {
            /*void */ Execute()
            {
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 640160;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"n":"Execute","d":640160,"h":4295607456,"f":4}],"c":[{"n":".ctor","o":"$ctor$1","d":640160,"h":8590574752,"f":1}],"h":640160}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Taskman.Components._Imports`; }
        });
        
        $asm.$cls("$t.Taskman.Services.AuthService", ($self) => class AuthService extends $.$spc.System.Object
        {
            /*IJSRuntime*/ JS = null;
            $ctor$1(/*IJSRuntime*/ jS)
            {
                super.$ctor();
                {
                    this.JS = jS;
                }
                return this;
            }
            /*bool*/ IsLoggedIn = false;
            /*string*/ Username = null;
            /*string*/ Role = null;
            /*string*/ Firstname = null;
            /*string*/ Lastname = null;
            /*string*/ Email = null;
            /*string*/ DateOfBirth = null;
            /*string*/ Password1 = null;
            /*string*/ ConfirmPassword = null;
            /*bool*/ userExists = false;
            /*UserModel*/ newUser = null;
            /*List<UserModel>*/ _user = null;
            /*Action?*/ OnChange = null;
            add_OnChange(/*Action?*/ value)
            {
                this.OnChange = $.$spc.System.Delegate.Combine(this.OnChange, value);
            }
            remove_OnChange(/*Action?*/ value)
            {
                this.OnChange = $.$spc.System.Delegate.Remove(this.OnChange, value);
            }
            /*void */ Notify()
            {
                return (this.OnChange?.Invoke() ?? null);
            }
            /*List<UserModel>*/ users = null;
            /*Task<string> *//*async*/  SignUp(/*string*/ firstname, /*string*/ lastname, /*string*/ email, /*string*/ role, /*DateTime?*/ dateOfBirth, /*string*/ username, /*string*/ password, /*string*/ confirmPassword)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$spc.System.String), $.$spc.System.String, async () => 
                {
                    this.Firstname = firstname;
                    this.Lastname = lastname;
                    this.Email = email;
                    this.DateOfBirth = (dateOfBirth?.ToString$1("yyyy-MM-dd") ?? null) ?? "";
                    this.Username = username;
                    this.Password1 = password;
                    this.ConfirmPassword = confirmPassword;
                    this.Role = role;
                    if ($.$spc.System.String.op_Equality(firstname, "") || $.$spc.System.String.op_Equality(lastname, "") || $.$spc.System.String.op_Equality(email, "") || $.$spc.System.String.op_Equality(role, "") || dateOfBirth === null || $.$spc.System.String.op_Equality(username, "") || $.$spc.System.String.op_Equality(password, "") || $.$spc.System.String.op_Equality(confirmPassword, ""))
                    {
                        if ($.$spc.System.String.op_Inequality(password, confirmPassword))
                        {
                            return "Passwords do not match.";
                        }
                        else 
                        {
                            return "Please fill all required entries.";
                        }
                    }
                    this.userExists = $.$sl.System.Linq.Enumerable.Any$1($.$t.UserModel, this.users, new ($.$spc.System.Func$$$($.$t.UserModel, $.$spc.System.Boolean))().$ctor(this,  (/*u*/ u) =>
                    {
                        return $.$spc.System.String.Equals$3.call(u.Username, username, 5/*StringComparison.OrdinalIgnoreCase*/);
                    }, {"r":262145,"p":[{"n":"u","p":2213024}],"n":"","d":2081952,"h":0,"f":1048578}));
                    if (this.userExists)
                    {
                        return "Username is already taken.";
                    }
                    this.newUser = (() =>
                    {
                        //new $.$t.UserModel()
                        const $t1 = $.$t.UserModel;
                        const $i1 = new $t1();
                        $i1.FirstName = firstname;
                        $i1.LastName = lastname;
                        $i1.Email = email;
                        $i1.DateOfBirth = dateOfBirth?.Clone() ?? null;
                        $i1.Username = username;
                        $i1.Password = password;
                        $i1.Role = role;
                        return $i1;
                    })();
                    this.users.Add(this.newUser);
                    await this.SaveUser();
                    await this.LoadUsers();
                    this.Notify();
                    return "Success";
                });
            }
            /*bool */ Login(/*string*/ username, /*string*/ password)
            {
                if ($.$spc.System.String.IsNullOrWhiteSpace(username) || $.$spc.System.String.IsNullOrWhiteSpace(password))
                {
                    this.IsLoggedIn = false;
                    return false;
                }
                /*var*/ let user = $.$sl.System.Linq.Enumerable.FirstOrDefault$2($.$t.UserModel, this.users, new ($.$spc.System.Func$$$($.$t.UserModel, $.$spc.System.Boolean))().$ctor(this,  (/*u*/ u) =>
                {
                    return $.$spc.System.String.Equals$3.call(u.Username, username, 5/*StringComparison.OrdinalIgnoreCase*/) && $.$spc.System.String.op_Equality(u.Password, password);
                }, {"r":262145,"p":[{"n":"u","p":2213024}],"n":"","d":2081952,"h":0,"f":1048578}));
                if (user === null)
                {
                    this.IsLoggedIn = false;
                    return false;
                }
                this.IsLoggedIn = true;
                this.Username = user.Username ?? "";
                this.Role = user.Role ?? "";
                this.Firstname = user.FirstName ?? "";
                this.Lastname = user.LastName ?? "";
                this.Email = user.Email ?? "";
                this.DateOfBirth = (user.DateOfBirth?.ToString$1("yyyy-MM-dd") ?? null) ?? "";
                this.Notify();
                return true;
            }
            /*void */ Logout()
            {
                this.IsLoggedIn = false;
                this.Username = "";
                this.Role = "";
                this.Firstname = "";
                this.Lastname = "";
                this.Email = "";
                this.DateOfBirth = "";
                this.Notify();
            }
            /*Task *//*async*/  SaveUser()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    /*var*/ let jsonString = $.$stj.System.Text.Json.JsonSerializer.Serialize$5($.$spc.System.Collections.Generic.List$$($.$t.UserModel), this.users, null);
                    await $.$mj.Microsoft.JSInterop.JSRuntimeExtensions.InvokeVoidAsync(this.JS, "localStorage.setItem", $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [ "All_Users", jsonString ], null, null));
                });
            }
            /*bool*/ loaded = false;
            /*Task *//*async*/  LoadUsers()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    if (this.loaded)
                    {
                        return;
                    }
                    /*var*/ let jsonString = await $.$mj.Microsoft.JSInterop.JSRuntimeExtensions.InvokeAsync($.$spc.System.String, this.JS, "localStorage.getItem", $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [ "All_Users" ], null, null));
                    if (!$.$spc.System.String.IsNullOrEmpty(jsonString))
                    {
                        /*var*/ let savedUsers = $.$stj.System.Text.Json.JsonSerializer.Deserialize$30($.$spc.System.Collections.Generic.List$$($.$t.UserModel), jsonString, null);
                        if (savedUsers !== null)
                        {
                            this.users = savedUsers;
                        }
                    }
                    this.loaded = true;
                });
            }
            /*Task *//*async*/  DeleteAccount()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    if (!this.IsLoggedIn)
                    {
                        return;
                    }
                    /*var*/ let userToRemove = $.$sl.System.Linq.Enumerable.FirstOrDefault$2($.$t.UserModel, this.users, new ($.$spc.System.Func$$$($.$t.UserModel, $.$spc.System.Boolean))().$ctor(this,  (/*u*/ u) =>
                    {
                        return $.$spc.System.String.Equals$3.call(u.Username, this.Username, 5/*StringComparison.OrdinalIgnoreCase*/);
                    }, {"r":262145,"p":[{"n":"u","p":2213024}],"n":"","d":2081952,"h":0,"f":1048578}));
                    if (userToRemove !== null)
                    {
                        this.users.Remove(userToRemove);
                    }
                    /*var*/ let jsonString = $.$stj.System.Text.Json.JsonSerializer.Serialize$5($.$spc.System.Collections.Generic.List$$($.$t.UserModel), this.users, null);
                    await $.$mj.Microsoft.JSInterop.JSRuntimeExtensions.InvokeVoidAsync(this.JS, "localStorage.setItem", $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [ "All_Users", jsonString ], null, null));
                    this.Logout();
                });
            }
            //default member initializer
            constructor()
            {
                super();
                this.IsLoggedIn = false;
                this.Username = "";
                this.Role = "";
                this.Firstname = "";
                this.Lastname = "";
                this.Email = "";
                this.DateOfBirth = "";
                this.Password1 = "";
                this.ConfirmPassword = "";
                this.userExists = true;
                this._user = new ($.$spc.System.Collections.Generic.List$$($.$t.UserModel))().$ctor$1();
                this.users = (() =>
                {
                    //new $.$spc.System.Collections.Generic.List$$($.$t.UserModel)()
                    const $t1 = $.$spc.System.Collections.Generic.List$$($.$t.UserModel);
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.Add((() =>
                    {
                        //new $.$t.UserModel()
                        const $t2 = $.$t.UserModel;
                        const $i2 = new $t2();
                        $i2.Username = "Olabode";
                        $i2.Password = "1234";
                        $i2.Role = "Admin";
                        $i2.Email = "benny@mail.com";
                        return $i2;
                    })());
                    $i1.Add((() =>
                    {
                        //new $.$t.UserModel()
                        const $t3 = $.$t.UserModel;
                        const $i3 = new $t3();
                        $i3.Username = "Benedicta";
                        $i3.Password = "2345";
                        $i3.Role = "Admin";
                        return $i3;
                    })());
                    $i1.Add((() =>
                    {
                        //new $.$t.UserModel()
                        const $t4 = $.$t.UserModel;
                        const $i4 = new $t4();
                        $i4.Username = "Blessing";
                        $i4.Password = "3456";
                        $i4.Role = "User";
                        return $i4;
                    })());
                    return $i1;
                })();
            }
            static $h = 2081952;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":21476918432,"f":1},"s":{"r":0,"d":0,"h":25771885728,"f":2},"n":"IsLoggedIn","d":2081952,"h":17181951136,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":38656787616,"f":1},"s":{"r":0,"d":0,"h":42951754912,"f":2},"n":"Username","d":2081952,"h":34361820320,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":55836656800,"f":1},"s":{"r":0,"d":0,"h":60131624096,"f":2},"n":"Role","d":2081952,"h":51541689504,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":73016525984,"f":1},"s":{"r":0,"d":0,"h":77311493280,"f":2},"n":"Firstname","d":2081952,"h":68721558688,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":90196395168,"f":1},"s":{"r":0,"d":0,"h":94491362464,"f":2},"n":"Lastname","d":2081952,"h":85901427872,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":107376264352,"f":1},"s":{"r":0,"d":0,"h":111671231648,"f":2},"n":"Email","d":2081952,"h":103081297056,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":124556133536,"f":1},"s":{"r":0,"d":0,"h":128851100832,"f":2},"n":"DateOfBirth","d":2081952,"h":120261166240,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":141736002720,"f":1},"s":{"r":0,"d":0,"h":146030970016,"f":2},"n":"Password1","d":2081952,"h":137441035424,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":158915871904,"f":1},"s":{"r":0,"d":0,"h":163210839200,"f":2},"n":"ConfirmPassword","d":2081952,"h":154620904608,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":176095741088,"f":1},"s":{"r":0,"d":0,"h":180390708384,"f":2},"n":"userExists","d":2081952,"h":171800773792,"f":1},{"p":2213024,"g":{"r":0,"d":0,"h":193275610272,"f":1},"s":{"r":0,"d":0,"h":197570577568,"f":2},"n":"newUser","d":2081952,"h":188980642976,"f":1}],"m":[{"r":65537,"n":"Notify","d":2081952,"h":219045414048,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.String).$h,"p":[{"n":"firstname","p":1310721},{"n":"lastname","p":1310721},{"n":"email","p":1310721},{"n":"role","p":1310721},{"n":"dateOfBirth","p":$.$typeNullable($.$spc.System.DateTime).$h},{"n":"username","p":1310721},{"n":"password","p":1310721},{"n":"confirmPassword","p":1310721}],"n":"SignUp","d":2081952,"h":227635348640,"f":4097},{"r":262145,"p":[{"n":"username","p":1310721},{"n":"password","p":1310721}],"n":"Login","d":2081952,"h":231930315936,"f":1},{"r":65537,"n":"Logout","d":2081952,"h":236225283232,"f":1},{"r":133300225,"n":"SaveUser","d":2081952,"h":240520250528,"f":4097},{"r":133300225,"n":"LoadUsers","d":2081952,"h":249110185120,"f":4097},{"r":133300225,"n":"DeleteAccount","d":2081952,"h":253405152416,"f":4097}],"l":[{"t":524318,"n":"JS","d":2081952,"h":4297049248,"f":2},{"t":$.$spc.System.Collections.Generic.List$$($.$t.UserModel).$h,"n":"_user","d":2081952,"h":201865544864,"f":1},{"t":$.$spc.System.Collections.Generic.List$$($.$t.UserModel).$h,"n":"users","d":2081952,"h":223340381344,"f":2},{"t":262145,"n":"loaded","d":2081952,"h":244815217824,"f":2}],"c":[{"p":[{"n":"jS","p":524318}],"n":".ctor","o":"$ctor$1","d":2081952,"h":8592016544,"f":1}],"e":[{"e":11665409,"m":{"r":65537,"p":[{"n":"value","p":11665409}],"n":"add_OnChange","d":2081952,"h":206160512160,"f":1},"r":{"r":65537,"p":[{"n":"value","p":11665409}],"n":"remove_OnChange","d":2081952,"h":210455479456,"f":1},"n":"OnChange","d":2081952,"h":214750446752,"f":1}],"h":2081952}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Taskman.Services.AuthService`; }
        });
        
        $asm.$cls("$t.TaskService", ($self) => class TaskService extends $.$spc.System.Object
        {
            /*IJSRuntime*/ JS = null;
            $ctor$1(/*IJSRuntime*/ jS)
            {
                super.$ctor();
                {
                    this.JS = jS;
                }
                return this;
            }
            /*object*/ _lock = null;
            /*AppTask*/ newTask = null;
            /*List<AppTask>*/ tasks = null;
            /*Action?*/ OnChange = null;
            add_OnChange(/*Action?*/ value)
            {
                this.OnChange = $.$spc.System.Delegate.Combine(this.OnChange, value);
            }
            remove_OnChange(/*Action?*/ value)
            {
                this.OnChange = $.$spc.System.Delegate.Remove(this.OnChange, value);
            }
            /*void */ Notify()
            {
                return (this.OnChange?.Invoke() ?? null);
            }
            /*List<AppTask> */ GetAll()
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._lock)
                    {
                        return $.$sl.System.Linq.Enumerable.ToList($.$t.AppTask, this.tasks);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._lock)
                }
            }
            /*void */ Add(/*string*/ title, /*Priority*/ priority)
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._lock)
                    {
                        this.newTask = (() =>
                        {
                            //new $.$t.AppTask()
                            const $t1 = $.$t.AppTask;
                            const $i1 = new $t1();
                            $i1.Id = $.$sl.System.Linq.Enumerable.Any($.$t.AppTask, this.tasks) ? (($.$sl.System.Linq.Enumerable.Max$12($.$t.AppTask, this.tasks, new ($.$spc.System.Func$$$($.$t.AppTask, $.$spc.System.Int32))().$ctor(this,  (/*t*/ t) =>
                            {
                                return t.Id;
                            }, {"r":655361,"p":[{"n":"t","p":115872}],"n":"","d":2147488,"h":0,"f":1048578})) + 1) | 0) : 1;
                            $i1.Title = title;
                            $i1.Priority = priority;
                            $i1.Date = $.$spc.System.DateTime.Now.ToString$1("dd MMM yyyy");
                            $i1.IsComplete = false;
                            return $i1;
                        })();
                        this.tasks.Add(this.newTask);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._lock)
                }
                this.Notify();
            }
            /*void */ Edit(/*int*/ id, /*string*/ title, /*Priority*/ priority)
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._lock)
                    {
                        /*var*/ let existingTask = $.$sl.System.Linq.Enumerable.FirstOrDefault$2($.$t.AppTask, this.tasks, new ($.$spc.System.Func$$$($.$t.AppTask, $.$spc.System.Boolean))().$ctor(this,  (/*t*/ t) =>
                        {
                            return t.Id === id;
                        }, {"r":262145,"p":[{"n":"t","p":115872}],"n":"","d":2147488,"h":0,"f":1048578}));
                        if (existingTask !== null)
                        {
                            existingTask.Title = title;
                            existingTask.Priority = priority;
                        }
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._lock)
                }
                this.Notify();
            }
            /*void */ MoveTask(/*string*/ title, /*Priority*/ priority)
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._lock)
                    {
                        this.newTask = (() =>
                        {
                            //new $.$t.AppTask()
                            const $t1 = $.$t.AppTask;
                            const $i1 = new $t1();
                            $i1.Id = $.$sl.System.Linq.Enumerable.Any($.$t.AppTask, this.tasks) ? (($.$sl.System.Linq.Enumerable.Max$12($.$t.AppTask, this.tasks, new ($.$spc.System.Func$$$($.$t.AppTask, $.$spc.System.Int32))().$ctor(this,  (/*t*/ t) =>
                            {
                                return t.Id;
                            }, {"r":655361,"p":[{"n":"t","p":115872}],"n":"","d":2147488,"h":0,"f":1048578})) + 1) | 0) : 1;
                            $i1.Title = title;
                            $i1.Priority = priority;
                            $i1.Date = $.$spc.System.DateTime.Now.ToString$1("dd MMM yyyy");
                            $i1.IsComplete = true;
                            return $i1;
                        })();
                        this.tasks.Add(this.newTask);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._lock)
                }
                this.Notify();
            }
            /*void */ Delete(/*int*/ id)
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._lock)
                    {
                        this.tasks.RemoveAll(new ($.$spc.System.Predicate$$($.$t.AppTask))().$ctor(this,  (/*t*/ t) =>
                        {
                            return t.Id === id;
                        }, {"r":262145,"p":[{"n":"t","p":115872}],"n":"","d":2147488,"h":0,"f":1048578}));
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._lock)
                }
                this.Notify();
            }
            /*void */ ClearAllTask()
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._lock)
                    {
                        this.tasks.Clear();
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._lock)
                }
                this.Notify();
            }
            /*Task *//*async*/  SaveTask()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    /*var*/ let jsonString = $.$stj.System.Text.Json.JsonSerializer.Serialize$5($.$spc.System.Collections.Generic.List$$($.$t.AppTask), this.tasks, null);
                    await $.$mj.Microsoft.JSInterop.JSRuntimeExtensions.InvokeVoidAsync(this.JS, "localStorage.setItem", $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [ "All_Tasks", jsonString ], null, null));
                });
            }
            /*Task *//*async*/  LoadTasks()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    /*var*/ let jsonString = await $.$mj.Microsoft.JSInterop.JSRuntimeExtensions.InvokeAsync($.$spc.System.String, this.JS, "localStorage.getItem", $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [ "All_Tasks" ], null, null));
                    if (!$.$spc.System.String.IsNullOrWhiteSpace(jsonString))
                    {
                        this.tasks = $.$stj.System.Text.Json.JsonSerializer.Deserialize$30($.$spc.System.Collections.Generic.List$$($.$t.AppTask), jsonString, null) ?? new ($.$spc.System.Collections.Generic.List$$($.$t.AppTask))().$ctor$1();
                    }
                    this.Notify();
                });
            }
            /*Task *//*async*/  ToggleCompleted(/*int*/ id)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter(this._lock)
                        {
                            /*var*/ let task = $.$sl.System.Linq.Enumerable.FirstOrDefault$2($.$t.AppTask, this.tasks, new ($.$spc.System.Func$$$($.$t.AppTask, $.$spc.System.Boolean))().$ctor(this,  (/**/ t) =>
                            {
                                return t.Id === id;
                            }, {"r":262145,"p":[{"n":"t","p":115872}],"n":"","d":2147488,"h":0,"f":1048578}));
                            if (task !== null)
                            {
                                task.IsComplete = !task.IsComplete;
                            }
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit(this._lock)
                    }
                    await this.SaveTask();
                    this.Notify();
                });
            }
            /*int */ GetCompletedCount()
            {
                return $.$sl.System.Linq.Enumerable.Count$1($.$t.AppTask, this.tasks, new ($.$spc.System.Func$$$($.$t.AppTask, $.$spc.System.Boolean))().$ctor(this,  (/*t*/ t) =>
                {
                    return t.IsComplete;
                }, {"r":262145,"p":[{"n":"t","p":115872}],"n":"","d":2147488,"h":0,"f":1048578}));
            }
            /*int */ GetPendingCount()
            {
                return $.$sl.System.Linq.Enumerable.Count$1($.$t.AppTask, this.tasks, new ($.$spc.System.Func$$$($.$t.AppTask, $.$spc.System.Boolean))().$ctor(this,  (/*t*/ t) =>
                {
                    return !t.IsComplete;
                }, {"r":262145,"p":[{"n":"t","p":115872}],"n":"","d":2147488,"h":0,"f":1048578}));
            }
            //Generated interface implemetation for ITaskService.OnChange.add
            ITaskService$add_OnChange()
            {
                return this.add_OnChange(...arguments);
            }
            //Generated interface implemetation for ITaskService.OnChange.remove
            ITaskService$remove_OnChange()
            {
                return this.remove_OnChange(...arguments);
            }
            //Generated interface implemetation for ITaskService.OnChange
            ITaskService$OnChange()
            {
                this.OnChange;
            }
            //Generated interface implemetation for ITaskService.SaveTask()
            ITaskService$SaveTask()
            {
                return this.SaveTask(...arguments);
            }
            //Generated interface implemetation for ITaskService.LoadTasks()
            ITaskService$LoadTasks()
            {
                return this.LoadTasks(...arguments);
            }
            //Generated interface implemetation for ITaskService.GetAll()
            ITaskService$GetAll()
            {
                return this.GetAll(...arguments);
            }
            //Generated interface implemetation for ITaskService.Add(string, Priority)
            ITaskService$Add()
            {
                return this.Add(...arguments);
            }
            //Generated interface implemetation for ITaskService.Edit(int, string, Priority)
            ITaskService$Edit()
            {
                return this.Edit(...arguments);
            }
            //Generated interface implemetation for ITaskService.MoveTask(string, Priority)
            ITaskService$MoveTask()
            {
                return this.MoveTask(...arguments);
            }
            //Generated interface implemetation for ITaskService.Delete(int)
            ITaskService$Delete()
            {
                return this.Delete(...arguments);
            }
            //Generated interface implemetation for ITaskService.ClearAllTask()
            ITaskService$ClearAllTask()
            {
                return this.ClearAllTask(...arguments);
            }
            //Generated interface implemetation for ITaskService.ToggleCompleted(int)
            ITaskService$ToggleCompleted()
            {
                return this.ToggleCompleted(...arguments);
            }
            //Generated interface implemetation for ITaskService.GetCompletedCount()
            ITaskService$GetCompletedCount()
            {
                return this.GetCompletedCount(...arguments);
            }
            //Generated interface implemetation for ITaskService.GetPendingCount()
            ITaskService$GetPendingCount()
            {
                return this.GetPendingCount(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this._lock = new $.$spc.System.Object().$ctor();
                this.newTask = new $.$t.AppTask().$ctor$1();
                this.tasks = new ($.$spc.System.Collections.Generic.List$$($.$t.AppTask))().$ctor$1();
            }
            static $h = 2147488;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"n":"Notify","d":2147488,"h":38656853152,"f":1},{"r":$.$spc.System.Collections.Generic.List$$($.$t.AppTask).$h,"n":"GetAll","d":2147488,"h":42951820448,"f":1},{"r":65537,"p":[{"n":"title","p":1310721},{"n":"priority","p":378016}],"n":"Add","d":2147488,"h":47246787744,"f":1},{"r":65537,"p":[{"n":"id","p":655361},{"n":"title","p":1310721},{"n":"priority","p":378016}],"n":"Edit","d":2147488,"h":51541755040,"f":1},{"r":65537,"p":[{"n":"title","p":1310721},{"n":"priority","p":378016}],"n":"MoveTask","d":2147488,"h":55836722336,"f":1},{"r":65537,"p":[{"n":"id","p":655361}],"n":"Delete","d":2147488,"h":60131689632,"f":1},{"r":65537,"n":"ClearAllTask","d":2147488,"h":64426656928,"f":1},{"r":133300225,"n":"SaveTask","d":2147488,"h":68721624224,"f":4097},{"r":133300225,"n":"LoadTasks","d":2147488,"h":73016591520,"f":4097},{"r":133300225,"p":[{"n":"id","p":655361}],"n":"ToggleCompleted","d":2147488,"h":77311558816,"f":4097},{"r":655361,"n":"GetCompletedCount","d":2147488,"h":81606526112,"f":1},{"r":655361,"n":"GetPendingCount","d":2147488,"h":85901493408,"f":1}],"l":[{"t":524318,"n":"JS","d":2147488,"h":4297114784,"f":2},{"t":131073,"n":"_lock","d":2147488,"h":12887049376,"f":2},{"t":115872,"n":"newTask","d":2147488,"h":17182016672,"f":1},{"t":$.$spc.System.Collections.Generic.List$$($.$t.AppTask).$h,"n":"tasks","d":2147488,"h":21476983968,"f":1}],"c":[{"p":[{"n":"jS","p":524318}],"n":".ctor","o":"$ctor$1","d":2147488,"h":8592082080,"f":1}],"e":[{"e":11665409,"m":{"r":65537,"p":[{"n":"value","p":11665409}],"n":"add_OnChange","d":2147488,"h":25771951264,"f":1},"r":{"r":65537,"p":[{"n":"value","p":11665409}],"n":"remove_OnChange","d":2147488,"h":30066918560,"f":1},"n":"OnChange","d":2147488,"h":34361885856,"f":1}],"i":[181408],"h":2147488}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$t.ITaskService ]; }
            static get $fullName() { return `TaskService`; }
        });
        
        $asm.$cls("$t.Microsoft.CodeAnalysis.EmbeddedAttribute", ($self) => class EmbeddedAttribute extends $.$spc.System.Attribute
        {
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 246944;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14548993,"c":[{"n":".ctor","o":"$ctor$2","d":246944,"h":4295214240,"f":1}],"h":246944}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
        });
        
        $asm.$cls("$t.Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute", ($self) => class ValidatableTypeAttribute extends $.$spc.System.Attribute
        {
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 312480;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14548993,"c":[{"n":".ctor","o":"$ctor$2","d":312480,"h":4295279776,"f":1}],"h":312480,"a":[{"t":246944,"c":4295214240},{"t":14680065,"c":21489516545,"a":[{"v":4,"t":14614529}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
        });
        
        $asm.$cls("$t.Taskman.Components.LoadingCardMajor", ($self) => class LoadingCardMajor extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.AddMarkupContent(0, "<div style=\"margin-bottom: 20px;\"><div style=\"width: 100%; height: 30px; border-radius: 20px; background: rgb(127, 127, 127, 0.2); margin-bottom: 5px;\"></div>\n    <div style=\"width: 100%; height: 30px; border-radius: 20px; background: rgb(127, 127, 127, 0.2); margin-bottom: 5px;\"></div>\n    <div style=\"width: 100%; height: 30px; border-radius: 20px; background: rgb(127, 127, 127, 0.2); margin-bottom: 5px;\"></div>\n    <div style=\"width: 100%; height: 30px; border-radius: 20px; background: rgb(127, 127, 127, 0.2); margin-bottom: 5px;\"></div>\n    <div style=\"width: 100%; height: 30px; border-radius: 20px; background: rgb(127, 127, 127, 0.2); margin-bottom: 5px;\"></div>\n    <div style=\"width: 100%; height: 30px; border-radius: 20px; background: rgb(127, 127, 127, 0.2); margin-bottom: 5px;\"></div>\n    <div style=\"width: 100%; height: 30px; border-radius: 20px; background: rgb(127, 127, 127, 0.2);\"></div></div>\n");
                __builder.OpenElement(1, "p");
                __builder.AddContent(2, this.LoadingState);
                __builder.CloseElement();
            }
            /*string*/ LoadingState = null;
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.LoadingState = "";
            }
            static $h = 902304;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17180771488,"f":1},"s":{"r":0,"d":0,"h":21475738784,"f":1},"n":"LoadingState","d":902304,"h":12885804192,"f":1,"a":[{"t":5636104,"c":21480472584}]}],"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","d":902304,"h":4295869600,"f":32772}],"c":[{"n":".ctor","o":"$ctor$2","d":902304,"h":25770706080,"f":1}],"i":[2752520,3145736,3080200],"h":902304}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `Taskman.Components.LoadingCardMajor`; }
        });
        
        $asm.$cls("$t.Taskman.Components.LoadingCardMinor", ($self) => class LoadingCardMinor extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$2(1, "style", "margin-bottom: 20px;");
                __builder.AddMarkupContent(2, "<div style=\"width: 100%; margin: 20px 0 0; align-items: center; justify-content: center; margin-bottom: 50px;\"><div style=\"margin-bottom: 0;\"><div style=\"width: 100%; height: 30px; border-radius: 20px; background: rgb(127, 127, 127, 0.2); margin-bottom: 5px;\"></div>\n            <div style=\"width: 100%; height: 30px; border-radius: 20px; background: rgb(127, 127, 127, 0.2); margin-bottom: 5px;\"></div>\n            <div style=\"width: 100%; height: 30px; border-radius: 20px; background: rgb(127, 127, 127, 0.2);\"></div></div></div>\n    ");
                __builder.OpenElement(3, "p");
                __builder.AddContent(4, this.LoadingState);
                __builder.CloseElement();
                __builder.CloseElement();
            }
            /*string*/ LoadingState = null;
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.LoadingState = "";
            }
            static $h = 967840;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17180837024,"f":1},"s":{"r":0,"d":0,"h":21475804320,"f":1},"n":"LoadingState","d":967840,"h":12885869728,"f":1,"a":[{"t":5636104,"c":21480472584}]}],"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","d":967840,"h":4295935136,"f":32772}],"c":[{"n":".ctor","o":"$ctor$2","d":967840,"h":25770771616,"f":1}],"i":[2752520,3145736,3080200],"h":967840}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `Taskman.Components.LoadingCardMinor`; }
        });
        
        $asm.$cls("$t.Taskman.Components.ButtonCard", ($self) => class ButtonCard extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OpenElement(0, "button");
                __builder.AddAttribute$5($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, 1, "onclick", $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$9($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, this, new ($.$spc.System.Func$$($.$spc.System.Threading.Tasks.Task))().$ctor(this, this.HandleClick)));
                __builder.AddAttribute$2(2, "style", "background:" + " " + (this.BgColor) + ";" + " padding:" + " 10px" + " 20px;" + " border:" + " none;" + " border-radius:" + " 10px;");
                __builder.AddContent(3, this.BtnText);
                __builder.CloseElement();
            }
            /*bool*/ ConfirmClear = false;
            /*string*/ BgColor = null;
            /*string*/ BtnText = null;
            /*EventCallback*/ OnClick;
            /*Task *//*async*/  HandleClick()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    await this.OnClick.InvokeAsync$1();
                });
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.ConfirmClear = false;
                this.BgColor = "";
                this.BtnText = "";
                this.OnClick = $.$default($.$mac.Microsoft.AspNetCore.Components.EventCallback);
            }
            static $h = 705696;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17180574880,"f":1},"s":{"r":0,"d":0,"h":21475542176,"f":1},"n":"ConfirmClear","d":705696,"h":12885607584,"f":1,"a":[{"t":5636104,"c":21480472584}]},{"p":1310721,"g":{"r":0,"d":0,"h":34360444064,"f":1},"s":{"r":0,"d":0,"h":38655411360,"f":1},"n":"BgColor","d":705696,"h":30065476768,"f":1,"a":[{"t":5636104,"c":21480472584}]},{"p":1310721,"g":{"r":0,"d":0,"h":51540313248,"f":1},"s":{"r":0,"d":0,"h":55835280544,"f":1},"n":"BtnText","d":705696,"h":47245345952,"f":1,"a":[{"t":5636104,"c":21480472584}]},{"p":2097160,"g":{"r":0,"d":0,"h":68720182432,"f":1},"s":{"r":0,"d":0,"h":73015149728,"f":1},"n":"OnClick","d":705696,"h":64425215136,"f":1,"a":[{"t":5636104,"c":21480472584}]}],"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","d":705696,"h":4295672992,"f":32772},{"r":133300225,"n":"HandleClick","d":705696,"h":77310117024,"f":4098}],"c":[{"n":".ctor","o":"$ctor$2","d":705696,"h":81605084320,"f":1}],"i":[2752520,3145736,3080200],"h":705696}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `Taskman.Components.ButtonCard`; }
        });
        
        $asm.$cls("$t.Taskman.Components.DeleteAccountPage", ($self) => class DeleteAccountPage extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                if (this.isLoading)
                {
                    __builder.OpenElement(0, "div");
                    __builder.AddAttribute$2(1, "style", "display: flex;; width: 100%; height: 100vh; align-items: center; justify-content: center; font-size: 30px;");
                    __builder.OpenComponent($.$t.Taskman.Components.LoadingCardMajor, 2);
                    __builder.AddComponentParameter(3, "LoadingState", "\u23F3 deleting user account...");
                    __builder.CloseComponent();
                    __builder.CloseElement();
                }
                else 
                {
                    __builder.OpenElement(4, "div");
                    __builder.AddAttribute$2(5, "style", "display: flex;; width: 100%; height: 100vh; align-items: center; justify-content: center;");
                    __builder.OpenComponent($.$t.Taskman.Components.NotLoginCard, 6);
                    __builder.AddComponentParameter(7, "Title", "Account deleted successful...");
                    __builder.AddComponentParameter(8, "SubTitle", "Click to login...");
                    __builder.CloseComponent();
                    __builder.CloseElement();
                }
            }
            /*bool*/ isLoading = true;
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    this.isLoading = true;
                    await $.$spc.System.Threading.Tasks.Task.Delay$4(4000);
                    this.isLoading = false;
                });
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 836768;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","d":836768,"h":4295804064,"f":32772},{"r":133300225,"n":"OnInitializedAsync","d":836768,"h":12885738656,"f":36868}],"l":[{"t":262145,"n":"isLoading","d":836768,"h":8590771360,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":836768,"h":17180705952,"f":1}],"i":[2752520,3145736,3080200],"h":836768,"a":[{"t":9895944,"c":4304863240,"a":[{"v":"/deleteacc","t":1310721}]}]}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `Taskman.Components.DeleteAccountPage`; }
        });
        
        $asm.$cls("$t.Taskman.Components.NotFound", ($self) => class NotFound extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.AddMarkupContent(0, "<h3>Not Found</h3>\n");
                __builder.AddMarkupContent(1, "<p>Sorry, the content you are looking for does not exist.</p>");
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 1098912;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","d":1098912,"h":4296066208,"f":32772}],"c":[{"n":".ctor","o":"$ctor$2","d":1098912,"h":8591033504,"f":1}],"i":[2752520,3145736,3080200],"h":1098912,"a":[{"t":4587528,"c":4299554824,"a":[{"v":1885344,"t":142606337}]},{"t":9895944,"c":4304863240,"a":[{"v":"/not-found","t":1310721}]}]}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `Taskman.Components.NotFound`; }
        });
        
        $asm.$cls("$t.Taskman.Components.NotLoginCard", ($self) => class NotLoginCard extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$2(1, "style", "width: 100%; height: 30vh; font-size: 20px; display: flex; align-items: center; justify-content: center; text-align: center;");
                __builder.OpenElement(2, "div");
                __builder.OpenElement(3, "p");
                __builder.AddContent(4, this.Title);
                __builder.CloseElement();
                __builder.AddMarkupContent(5, "\n        ");
                __builder.OpenElement(6, "p");
                __builder.OpenComponent($.$macw.Microsoft.AspNetCore.Components.Routing.NavLink, 7);
                __builder.AddComponentParameter(8, "style", "text-decoration: none; color: white; background: rgb(133, 0, 133, 0.3); padding: 10px 20px; border-radius: 10px; font-weight: bold; font-size: 15px;");
                __builder.AddComponentParameter(9, "href", "");
                __builder.AddComponentParameter(10, "Match", $.$box($.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$macw.Microsoft.AspNetCore.Components.Routing.NavLinkMatch, 1/*NavLinkMatch.All*/), $.$macw.Microsoft.AspNetCore.Components.Routing.NavLinkMatch));
                __builder.AddAttribute$3(11, "ChildContent", new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddMarkupContent(12, "\uD83D\uDEAA Login");
                })));
                __builder.CloseComponent();
                __builder.AddMarkupContent(13, "\n            ");
                __builder.AddContent(14, this.SubTitle);
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
            }
            /*string*/ Title = null;
            /*string*/ SubTitle = null;
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Title = "";
                this.SubTitle = "";
            }
            static $h = 1164448;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17181033632,"f":1},"s":{"r":0,"d":0,"h":21476000928,"f":1},"n":"Title","d":1164448,"h":12886066336,"f":1,"a":[{"t":5636104,"c":21480472584}]},{"p":1310721,"g":{"r":0,"d":0,"h":34360902816,"f":1},"s":{"r":0,"d":0,"h":38655870112,"f":1},"n":"SubTitle","d":1164448,"h":30065935520,"f":1,"a":[{"t":5636104,"c":21480472584}]}],"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","d":1164448,"h":4296131744,"f":32772}],"c":[{"n":".ctor","o":"$ctor$2","d":1164448,"h":42950837408,"f":1}],"i":[2752520,3145736,3080200],"h":1164448}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `Taskman.Components.NotLoginCard`; }
        });
        
        $asm.$cls("$t.Taskman.Components.StatCard", ($self) => class StatCard extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$2(1, "class", "stat-container");
                __builder.AddAttribute(2, "b-35l3j00qne");
                __builder.OpenElement(3, "div");
                __builder.AddAttribute$2(4, "class", "label");
                __builder.AddAttribute(5, "b-35l3j00qne");
                __builder.OpenElement(6, "p");
                __builder.AddAttribute(7, "b-35l3j00qne");
                __builder.AddContent(8, this.Icon);
                __builder.CloseElement();
                __builder.AddMarkupContent(9, "\n        ");
                __builder.OpenElement(10, "p");
                __builder.AddAttribute(11, "b-35l3j00qne");
                __builder.AddContent(12, this.Label);
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(13, "\n    ");
                __builder.OpenElement(14, "p");
                __builder.AddAttribute$2(15, "class", "value");
                __builder.AddAttribute(16, "b-35l3j00qne");
                __builder.AddContent(17, this.Value);
                __builder.CloseElement();
                __builder.CloseElement();
            }
            /*string*/ Icon = null;
            /*string*/ Label = null;
            /*string*/ Value = null;
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Icon = "";
                this.Label = "";
                this.Value = "";
            }
            static $h = 1754272;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17181623456,"f":1},"s":{"r":0,"d":0,"h":21476590752,"f":1},"n":"Icon","d":1754272,"h":12886656160,"f":1,"a":[{"t":5636104,"c":21480472584}]},{"p":1310721,"g":{"r":0,"d":0,"h":34361492640,"f":1},"s":{"r":0,"d":0,"h":38656459936,"f":1},"n":"Label","d":1754272,"h":30066525344,"f":1,"a":[{"t":5636104,"c":21480472584}]},{"p":1310721,"g":{"r":0,"d":0,"h":51541361824,"f":1},"s":{"r":0,"d":0,"h":55836329120,"f":1},"n":"Value","d":1754272,"h":47246394528,"f":1,"a":[{"t":5636104,"c":21480472584}]}],"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","d":1754272,"h":4296721568,"f":32772}],"c":[{"n":".ctor","o":"$ctor$2","d":1754272,"h":60131296416,"f":1}],"i":[2752520,3145736,3080200],"h":1754272}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `Taskman.Components.StatCard`; }
        });
        
        $asm.$cls("$t.Taskman.Components.SignUpSuccess", ($self) => class SignUpSuccess extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                if (this.isLoading)
                {
                    __builder.OpenElement(0, "div");
                    __builder.AddAttribute$2(1, "style", "display: flex;; width: 100%; height: 100vh; align-items: center; justify-content: center; font-size: 30px;");
                    __builder.OpenComponent($.$t.Taskman.Components.LoadingCardMajor, 2);
                    __builder.AddComponentParameter(3, "LoadingState", "\u23F3 creating user account...");
                    __builder.CloseComponent();
                    __builder.CloseElement();
                }
                else 
                {
                    __builder.OpenElement(4, "div");
                    __builder.AddAttribute$2(5, "style", "display: flex;; width: 100%; height: 100vh; align-items: center; justify-content: center;");
                    __builder.OpenComponent($.$t.Taskman.Components.NotLoginCard, 6);
                    __builder.AddComponentParameter(7, "Title", "Account created successful...");
                    __builder.AddComponentParameter(8, "SubTitle", "Continue to login...");
                    __builder.CloseComponent();
                    __builder.CloseElement();
                }
            }
            /*bool*/ isLoading = true;
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    this.isLoading = true;
                    await $.$spc.System.Threading.Tasks.Task.Delay$4(4000);
                    this.isLoading = false;
                });
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 1688736;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","d":1688736,"h":4296656032,"f":32772},{"r":133300225,"n":"OnInitializedAsync","d":1688736,"h":12886590624,"f":36868}],"l":[{"t":262145,"n":"isLoading","d":1688736,"h":8591623328,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":1688736,"h":17181557920,"f":1}],"i":[2752520,3145736,3080200],"h":1688736,"a":[{"t":9895944,"c":4304863240,"a":[{"v":"/signupsuccess","t":1310721}]}]}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `Taskman.Components.SignUpSuccess`; }
        });
        
        $asm.$cls("$t.Taskman.Components.Confirm", ($self) => class Confirm extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$2(1, "class", "notify");
                __builder.AddAttribute(2, "b-nc8ags17cu");
                __builder.OpenElement(3, "div");
                __builder.AddAttribute$2(4, "class", "notify-in slide-in-left");
                __builder.AddAttribute(5, "b-nc8ags17cu");
                __builder.OpenElement(6, "div");
                __builder.AddAttribute$2(7, "class", "notify-inner");
                __builder.AddAttribute(8, "b-nc8ags17cu");
                __builder.OpenElement(9, "p");
                __builder.AddAttribute$2(10, "style", "padding: 20px;");
                __builder.AddAttribute(11, "b-nc8ags17cu");
                __builder.AddContent(12, this.Title);
                __builder.CloseElement();
                __builder.AddMarkupContent(13, "\n            ");
                __builder.OpenElement(14, "div");
                __builder.AddAttribute$2(15, "style", "display: flex; justify-content: space-around; padding: 20px;");
                __builder.AddAttribute(16, "b-nc8ags17cu");
                __builder.OpenElement(17, "button");
                __builder.AddAttribute$2(18, "style", "background: rgb(135, 0, 135, 0.3); padding: 10px 20px; border: none; border-radius: 10px; margin-right:20px");
                __builder.AddAttribute$5($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, 19, "onclick", $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$9($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, this, new ($.$spc.System.Func$$($.$spc.System.Threading.Tasks.Task))().$ctor(this, this.HandleConfirm)));
                __builder.AddAttribute(20, "b-nc8ags17cu");
                __builder.AddContent(21, this.Text1);
                __builder.CloseElement();
                __builder.AddMarkupContent(22, "\n                ");
                __builder.OpenElement(23, "button");
                __builder.AddAttribute$2(24, "style", "background: rgb(131, 131, 131, 0.3); padding: 10px 20px; border: none; border-radius: 10px;");
                __builder.AddAttribute$5($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, 25, "onclick", $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$9($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, this, new ($.$spc.System.Func$$($.$spc.System.Threading.Tasks.Task))().$ctor(this, this.HandleCancel)));
                __builder.AddAttribute(26, "b-nc8ags17cu");
                __builder.AddContent(27, this.Text2);
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
            }
            /*string*/ Title = null;
            /*string*/ Text1 = null;
            /*string*/ Text2 = null;
            /*EventCallback*/ ConfirmBtn;
            /*EventCallback*/ CancelBtn;
            /*Task *//*async*/  HandleConfirm()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    await this.ConfirmBtn.InvokeAsync$1();
                });
            }
            /*Task *//*async*/  HandleCancel()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    await this.CancelBtn.InvokeAsync$1();
                });
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Title = "";
                this.Text1 = "";
                this.Text2 = "";
                this.ConfirmBtn = $.$default($.$mac.Microsoft.AspNetCore.Components.EventCallback);
                this.CancelBtn = $.$default($.$mac.Microsoft.AspNetCore.Components.EventCallback);
            }
            static $h = 771232;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17180640416,"f":1},"s":{"r":0,"d":0,"h":21475607712,"f":1},"n":"Title","d":771232,"h":12885673120,"f":1,"a":[{"t":5636104,"c":21480472584}]},{"p":1310721,"g":{"r":0,"d":0,"h":34360509600,"f":1},"s":{"r":0,"d":0,"h":38655476896,"f":1},"n":"Text1","d":771232,"h":30065542304,"f":1,"a":[{"t":5636104,"c":21480472584}]},{"p":1310721,"g":{"r":0,"d":0,"h":51540378784,"f":1},"s":{"r":0,"d":0,"h":55835346080,"f":1},"n":"Text2","d":771232,"h":47245411488,"f":1,"a":[{"t":5636104,"c":21480472584}]},{"p":2097160,"g":{"r":0,"d":0,"h":68720247968,"f":1},"s":{"r":0,"d":0,"h":73015215264,"f":1},"n":"ConfirmBtn","d":771232,"h":64425280672,"f":1,"a":[{"t":5636104,"c":21480472584}]},{"p":2097160,"g":{"r":0,"d":0,"h":85900117152,"f":1},"s":{"r":0,"d":0,"h":90195084448,"f":1},"n":"CancelBtn","d":771232,"h":81605149856,"f":1,"a":[{"t":5636104,"c":21480472584}]}],"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","d":771232,"h":4295738528,"f":32772},{"r":133300225,"n":"HandleConfirm","d":771232,"h":94490051744,"f":4098},{"r":133300225,"n":"HandleCancel","d":771232,"h":98785019040,"f":4098}],"c":[{"n":".ctor","o":"$ctor$2","d":771232,"h":103079986336,"f":1}],"i":[2752520,3145736,3080200],"h":771232}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `Taskman.Components.Confirm`; }
        });
        
        $asm.$cls("$t.Taskman.Components.Routes", ($self) => class Routes extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OpenComponent($.$mac.Microsoft.AspNetCore.Components.Routing.Router, 0);
                __builder.AddComponentParameter(1, "AppAssembly", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$spc.System.Reflection.Assembly, $.$t.Program.$type.Assembly));
                __builder.AddComponentParameter(2, "NotFoundPage", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$spc.System.Type, $.$t.Taskman.Components.NotFound.$type));
                __builder.AddAttribute$3(3, "Found", new ($.$mac.Microsoft.AspNetCore.Components.RenderFragment$$($.$mac.Microsoft.AspNetCore.Components.RouteData))().$ctor(this, ( (/*routeData*/ routeData) =>
                {
                    return new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this,  (/**/ __builder2) =>
                    {
                        __builder2.OpenComponent($.$mac.Microsoft.AspNetCore.Components.RouteView, 4);
                        __builder2.AddComponentParameter(5, "RouteData", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$mac.Microsoft.AspNetCore.Components.RouteData, routeData));
                        __builder2.AddComponentParameter(6, "DefaultLayout", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$spc.System.Type, $.$t.Taskman.Layout.MainLayout.$type));
                        __builder2.CloseComponent();
                        __builder2.AddMarkupContent(7, "\n        ");
                        __builder2.OpenComponent($.$macw.Microsoft.AspNetCore.Components.Routing.FocusOnNavigate, 8);
                        __builder2.AddComponentParameter(9, "RouteData", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$mac.Microsoft.AspNetCore.Components.RouteData, routeData));
                        __builder2.AddComponentParameter(10, "Selector", "h1");
                        __builder2.CloseComponent();
                    }, {"r":65537,"p":[{"n":"__builder2","p":7536648}],"n":"","d":1557664,"h":0,"f":1048578});
                })));
                __builder.CloseComponent();
            }
            static $___PrivateComponentRenderModeAttribute;
            static get __PrivateComponentRenderModeAttribute()
            {
                let $cls = $.$t.Taskman.Components.Routes;
                return $cls.$___PrivateComponentRenderModeAttribute ??= $asm.$ncls("$t.Taskman.Components.Routes.__PrivateComponentRenderModeAttribute", ($self) => class __PrivateComponentRenderModeAttribute extends $.$mac.Microsoft.AspNetCore.Components.RenderModeAttribute
                {
                    static /*global::Microsoft.AspNetCore.Components.IComponentRenderMode */ get ModeImpl()
                    {
                        return $.$macw.Microsoft.AspNetCore.Components.Web.RenderMode.InteractiveServer;
                    }
                    /*global::Microsoft.AspNetCore.Components.IComponentRenderMode */ get Mode()
                    {
                        return $.$t.Taskman.Components.Routes.__PrivateComponentRenderModeAttribute.ModeImpl;
                    }
                    //default reference type constructor overload
                    $ctor$3()
                    {
                        super.$ctor$2();
                        return this;
                    }
                    static $h = 1623200;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":7733256,"p":[{"p":2883592,"g":{"r":0,"d":0,"h":8591557792,"f":34},"n":"ModeImpl","d":1623200,"h":4296590496,"f":34},{"p":2883592,"g":{"r":0,"d":0,"h":17181492384,"f":32769},"n":"Mode","d":1623200,"h":12886525088,"f":32769}],"c":[{"n":".ctor","o":"$ctor$3","d":1623200,"h":21476459680,"f":1}],"d":1557664,"h":1623200}; }
                    static get $b() { return $.$mac.Microsoft.AspNetCore.Components.RenderModeAttribute; }
                    static get $fullName() { return `Taskman.Components.Routes.__PrivateComponentRenderModeAttribute`; }
                }, $cls, ($v) => $cls.$___PrivateComponentRenderModeAttribute = $v);
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 1557664;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","d":1557664,"h":4296524960,"f":32772}],"c":[{"n":".ctor","o":"$ctor$2","d":1557664,"h":12886459552,"f":1}],"i":[2752520,3145736,3080200],"j":[1623200],"h":1557664,"a":[{"t":1623200,"c":21476459680}]}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `Taskman.Components.Routes`; }
        });
        
        $asm.$cls("$t.Taskman.Layout.NavMenu", ($self) => class NavMenu extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$2(1, "class", "top-row ps-3 navbar navbar-dark");
                __builder.AddAttribute(2, "b-l8at8xwutv");
                __builder.OpenElement(3, "div");
                __builder.AddAttribute$2(4, "class", "container-fluid");
                __builder.AddAttribute(5, "b-l8at8xwutv");
                __builder.AddMarkupContent(6, "<a class=\"navbar-brand\" href b-l8at8xwutv>Taskman</a>\n        ");
                __builder.OpenElement(7, "button");
                __builder.AddAttribute$2(8, "title", "Navigation menu");
                __builder.AddAttribute$2(9, "class", "navbar-toggler");
                __builder.AddAttribute$5($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, 10, "onclick", $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$7($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, this, new $.$spc.System.Action().$ctor(this, this.ToggleNavMenu)));
                __builder.AddAttribute(11, "b-l8at8xwutv");
                __builder.AddMarkupContent(12, "<span class=\"navbar-toggler-icon\" b-l8at8xwutv></span>");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(13, "\n\n");
                __builder.OpenElement(14, "div");
                __builder.AddAttribute$2(15, "class", (this.NavMenuCssClass) + " nav-scrollable");
                __builder.AddAttribute$5($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, 16, "onclick", $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$7($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, this, new $.$spc.System.Action().$ctor(this, this.ToggleNavMenu)));
                __builder.AddAttribute(17, "b-l8at8xwutv");
                __builder.OpenElement(18, "nav");
                __builder.AddAttribute$2(19, "class", "nav flex-column");
                __builder.AddAttribute(20, "b-l8at8xwutv");
                __builder.OpenElement(21, "div");
                __builder.AddAttribute$2(22, "class", "nav-item px-3");
                __builder.AddAttribute(23, "b-l8at8xwutv");
                __builder.OpenComponent($.$macw.Microsoft.AspNetCore.Components.Routing.NavLink, 24);
                __builder.AddComponentParameter(25, "class", "nav-link");
                __builder.AddComponentParameter(26, "href", "");
                __builder.AddComponentParameter(27, "Match", $.$box($.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$macw.Microsoft.AspNetCore.Components.Routing.NavLinkMatch, 1/*NavLinkMatch.All*/), $.$macw.Microsoft.AspNetCore.Components.Routing.NavLinkMatch));
                __builder.AddAttribute$3(28, "ChildContent", new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddMarkupContent(29, "<span class=\"bi bi-house-door-fill-nav-menu\" aria-hidden=\"true\" b-l8at8xwutv></span> Home\n            ");
                })));
                __builder.CloseComponent();
                __builder.CloseElement();
                __builder.AddMarkupContent(30, "\n        ");
                __builder.OpenElement(31, "div");
                __builder.AddAttribute$2(32, "class", "nav-item px-3");
                __builder.AddAttribute(33, "b-l8at8xwutv");
                __builder.OpenComponent($.$macw.Microsoft.AspNetCore.Components.Routing.NavLink, 34);
                __builder.AddComponentParameter(35, "class", "nav-link");
                __builder.AddComponentParameter(36, "href", "counter");
                __builder.AddAttribute$3(37, "ChildContent", new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddMarkupContent(38, "<span class=\"bi bi-plus-square-fill-nav-menu\" aria-hidden=\"true\" b-l8at8xwutv></span> Counter\n            ");
                })));
                __builder.CloseComponent();
                __builder.CloseElement();
                __builder.AddMarkupContent(39, "\n        ");
                __builder.OpenElement(40, "div");
                __builder.AddAttribute$2(41, "class", "nav-item px-3");
                __builder.AddAttribute(42, "b-l8at8xwutv");
                __builder.OpenComponent($.$macw.Microsoft.AspNetCore.Components.Routing.NavLink, 43);
                __builder.AddComponentParameter(44, "class", "nav-link");
                __builder.AddComponentParameter(45, "href", "weather");
                __builder.AddAttribute$3(46, "ChildContent", new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this, ( (/**/ __builder2) =>
                {
                    __builder2.AddMarkupContent(47, "<span class=\"bi bi-list-nested-nav-menu\" aria-hidden=\"true\" b-l8at8xwutv></span> Weather\n            ");
                })));
                __builder.CloseComponent();
                __builder.CloseElement();
                __builder.AddMarkupContent(48, "\n\n        ");
                __builder.OpenElement(49, "div");
                __builder.AddAttribute$2(50, "class", "nav-item px-3");
                __builder.AddAttribute(51, "b-l8at8xwutv");
                __builder.OpenComponent($.$macw.Microsoft.AspNetCore.Components.Routing.NavLink, 52);
                __builder.AddComponentParameter(53, "class", "nav-link");
                __builder.AddComponentParameter(54, "href", "login");
                __builder.AddAttribute$3(55, "ChildContent", new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddMarkupContent(56, "<span class=\"bi bi-list-nested-nav-menu\" aria-hidden=\"true\" b-l8at8xwutv></span> Login\n            ");
                })));
                __builder.CloseComponent();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
            }
            /*bool*/ collapseNavMenu = true;
            /*string? */ get NavMenuCssClass()
            {
                return this.collapseNavMenu ? "collapse" : null;
            }
            /*void */ ToggleNavMenu()
            {
                this.collapseNavMenu = !this.collapseNavMenu;
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 1950880;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17181820064,"f":2},"n":"NavMenuCssClass","d":1950880,"h":12886852768,"f":2}],"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","d":1950880,"h":4296918176,"f":32772},{"r":65537,"n":"ToggleNavMenu","d":1950880,"h":21476787360,"f":2}],"l":[{"t":262145,"n":"collapseNavMenu","d":1950880,"h":8591885472,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":1950880,"h":25771754656,"f":1}],"i":[2752520,3145736,3080200],"h":1950880}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `Taskman.Layout.NavMenu`; }
        });
        
        $asm.$cls("$t.Taskman.App", ($self) => class App extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OpenComponent($.$mac.Microsoft.AspNetCore.Components.Routing.Router, 0);
                __builder.AddComponentParameter(1, "AppAssembly", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$spc.System.Reflection.Assembly, $.$t.Taskman.App.$type.Assembly));
                __builder.AddComponentParameter(2, "PreferExactMatches", $.$box(true, $.$spc.System.Boolean));
                __builder.AddComponentParameter(3, "NotFoundPage", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$spc.System.Type, $.$t.Taskman.Components.NotFound.$type));
                __builder.AddAttribute$3(4, "Found", new ($.$mac.Microsoft.AspNetCore.Components.RenderFragment$$($.$mac.Microsoft.AspNetCore.Components.RouteData))().$ctor(this, ( (/*routeData*/ routeData) =>
                {
                    return new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this,  (/**/ __builder2) =>
                    {
                        __builder2.OpenComponent($.$mac.Microsoft.AspNetCore.Components.RouteView, 5);
                        __builder2.AddComponentParameter(6, "RouteData", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$mac.Microsoft.AspNetCore.Components.RouteData, routeData));
                        __builder2.AddComponentParameter(7, "DefaultLayout", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$spc.System.Type, $.$t.Taskman.Layout.MainLayout.$type));
                        __builder2.CloseComponent();
                        __builder2.AddMarkupContent(8, "\n        ");
                        __builder2.OpenComponent($.$macw.Microsoft.AspNetCore.Components.Routing.FocusOnNavigate, 9);
                        __builder2.AddComponentParameter(10, "RouteData", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$mac.Microsoft.AspNetCore.Components.RouteData, routeData));
                        __builder2.AddComponentParameter(11, "Selector", "h1");
                        __builder2.CloseComponent();
                    }, {"r":65537,"p":[{"n":"__builder2","p":7536648}],"n":"","d":574624,"h":0,"f":1048578});
                })));
                __builder.CloseComponent();
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 574624;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","d":574624,"h":4295541920,"f":32772}],"c":[{"n":".ctor","o":"$ctor$2","d":574624,"h":8590509216,"f":1}],"i":[2752520,3145736,3080200],"h":574624}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `Taskman.App`; }
        });
        
        $asm.$cls("$t.Taskman.Components.Pages.Dashboard", ($self) => class Dashboard extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OpenComponent($.$t.Taskman.Components.NavBar, 0);
                __builder.CloseComponent();
                if (this.isLoading)
                {
                    __builder.OpenComponent($.$t.Taskman.Components.LoadingCardMajor, 1);
                    __builder.AddComponentParameter(2, "LoadingState", "\u23F3 Loading Dashboard...");
                    __builder.CloseComponent();
                }
                else 
                {
                    __builder.OpenElement(3, "div");
                    __builder.AddAttribute$2(4, "style", "margin-top: 20px;");
                    __builder.AddMarkupContent(5, "<h3>\uD83D\uDCCA Dashboard</h3>\n        ");
                    __builder.OpenElement(6, "p");
                    __builder.AddContent(7, "Welcome back, ");
                    __builder.AddContent(8, this.Auth.Username);
                    __builder.AddMarkupContent(9, " \uD83D\uDD90\uFE0F");
                    __builder.CloseElement();
                    if (this.Auth.IsLoggedIn)
                    {
                        __builder.OpenElement(10, "div");
                        __builder.AddAttribute$2(11, "style", "display: flex; gap: 10px; padding: 10px 0 30px;");
                        __builder.OpenComponent($.$t.Taskman.Components.StatCard, 12);
                        __builder.AddComponentParameter(13, "Icon", "\uD83D\uDCDD");
                        __builder.AddComponentParameter(14, "Label", "Total");
                        __builder.AddComponentParameter(15, "Value", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$spc.System.String, this.tasksCount));
                        __builder.CloseComponent();
                        __builder.AddMarkupContent(16, "\n                ");
                        __builder.OpenComponent($.$t.Taskman.Components.StatCard, 17);
                        __builder.AddComponentParameter(18, "Icon", "\u2705");
                        __builder.AddComponentParameter(19, "Label", "Done");
                        __builder.AddComponentParameter(20, "Value", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$spc.System.String, this.completedCount));
                        __builder.CloseComponent();
                        __builder.AddMarkupContent(21, "\n                ");
                        __builder.OpenComponent($.$t.Taskman.Components.StatCard, 22);
                        __builder.AddComponentParameter(23, "Icon", "\u23F3");
                        __builder.AddComponentParameter(24, "Label", "Left");
                        __builder.AddComponentParameter(25, "Value", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$spc.System.String, this.pendingCount));
                        __builder.CloseComponent();
                        __builder.CloseElement();
                    }
                    else 
                    {
                        __builder.OpenElement(26, "div");
                        __builder.AddAttribute$2(27, "style", "display: flex; gap: 10px; padding: 10px 0 30px;");
                        __builder.OpenComponent($.$t.Taskman.Components.StatCard, 28);
                        __builder.AddComponentParameter(29, "Icon", "\uD83D\uDCDD");
                        __builder.AddComponentParameter(30, "Label", "Total");
                        __builder.AddComponentParameter(31, "Value", "0");
                        __builder.CloseComponent();
                        __builder.AddMarkupContent(32, "\n                ");
                        __builder.OpenComponent($.$t.Taskman.Components.StatCard, 33);
                        __builder.AddComponentParameter(34, "Icon", "\u2705");
                        __builder.AddComponentParameter(35, "Label", "Done");
                        __builder.AddComponentParameter(36, "Value", "0");
                        __builder.CloseComponent();
                        __builder.AddMarkupContent(37, "\n                ");
                        __builder.OpenComponent($.$t.Taskman.Components.StatCard, 38);
                        __builder.AddComponentParameter(39, "Icon", "\u23F3");
                        __builder.AddComponentParameter(40, "Label", "Left");
                        __builder.AddComponentParameter(41, "Value", "0");
                        __builder.CloseComponent();
                        __builder.CloseElement();
                    }
                    if ($.$spc.System.String.op_Equality(this.Auth.Role, "Admin"))
                    {
                        __builder.OpenElement(42, "div");
                        __builder.AddMarkupContent(43, "<h5>\u2699\uFE0F Admin Panel</h5>\n                ");
                        __builder.OpenElement(44, "div");
                        __builder.OpenComponent($.$t.Taskman.Components.ButtonCard, 45);
                        __builder.AddComponentParameter(46, "BgColor", "rgb(140, 0, 140, 0.3)");
                        __builder.AddComponentParameter(47, "BtnText", "\uD83D\uDCC1 Go to Tasks");
                        __builder.AddComponentParameter(48, "OnClick", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$mac.Microsoft.AspNetCore.Components.EventCallback, $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$1(this, new $.$spc.System.Action().$ctor(this, this.GoToTask))));
                        __builder.CloseComponent();
                        __builder.AddMarkupContent(49, "\n                    ");
                        __builder.OpenComponent($.$t.Taskman.Components.ButtonCard, 50);
                        __builder.AddComponentParameter(51, "BgColor", "rgb(135, 135, 135, 0.3)");
                        __builder.AddComponentParameter(52, "BtnText", "\uD83D\uDE4E\u200D\u2642\uFE0F View Profile");
                        __builder.AddComponentParameter(53, "OnClick", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$mac.Microsoft.AspNetCore.Components.EventCallback, $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$1(this, new $.$spc.System.Action().$ctor(this, this.ViewProfile))));
                        __builder.CloseComponent();
                        __builder.CloseElement();
                        __builder.CloseElement();
                    }
                    __builder.CloseElement();
                    if (!this.Auth.IsLoggedIn)
                    {
                        __builder.OpenComponent($.$t.Taskman.Components.NotLoginCard, 54);
                        __builder.AddComponentParameter(55, "Title", "User not logged in....");
                        __builder.AddComponentParameter(56, "SubTitle", "Click to login...");
                        __builder.CloseComponent();
                    }
                }
            }
            /*bool*/ isLoading = true;
            /*List<AppTask> */ get tasks()
            {
                return this.TaskService.ITaskService$GetAll() ?? new ($.$spc.System.Collections.Generic.List$$($.$t.AppTask))().$ctor$1();
            }
            /*string */ get tasksCount()
            {
                return $.$spc.System.Int32.ToString.call(this.tasks.Count);
            }
            /*string */ get completedCount()
            {
                return $.$spc.System.Int32.ToString.call($.$sl.System.Linq.Enumerable.Count$1($.$t.AppTask, this.tasks, new ($.$spc.System.Func$$$($.$t.AppTask, $.$spc.System.Boolean))().$ctor(this,  (/*t*/ t) =>
                {
                    return t.IsComplete;
                }, {"r":262145,"p":[{"n":"t","p":115872}],"n":"","d":1229984,"h":0,"f":1048578})));
            }
            /*string */ get pendingCount()
            {
                return $.$spc.System.Int32.ToString.call($.$sl.System.Linq.Enumerable.Count$1($.$t.AppTask, this.tasks, new ($.$spc.System.Func$$$($.$t.AppTask, $.$spc.System.Boolean))().$ctor(this,  (/*t*/ t) =>
                {
                    return !t.IsComplete;
                }, {"r":262145,"p":[{"n":"t","p":115872}],"n":"","d":1229984,"h":0,"f":1048578})));
            }
            /*void */ GoToTask()
            {
                return this.Nav.NavigateTo$1("tasks", false, false);
            }
            /*void */ ViewProfile()
            {
                return this.Nav.NavigateTo$1("profile", false, false);
            }
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    if (this.isLoading)
                    {
                        this.isLoading = true;
                        await $.$spc.System.Threading.Tasks.Task.Delay$4(500);
                        this.isLoading = false;
                    }
                });
            }
            /*Task *//*async*/  OnAfterRenderAsync(/*bool*/ firstRender)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    if (firstRender)
                    {
                        await this.TaskService.ITaskService$LoadTasks();
                        this.StateHasChanged();
                    }
                });
            }
            /*NavigationManager*/ Nav = null;
            /*ITaskService*/ TaskService = null;
            /*Taskman.Services.AuthService*/ Auth = null;
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Nav = null;
                this.TaskService = null;
                this.Auth = null;
            }
            static $h = 1229984;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":$.$spc.System.Collections.Generic.List$$($.$t.AppTask).$h,"g":{"r":0,"d":0,"h":17181099168,"f":2},"n":"tasks","d":1229984,"h":12886131872,"f":2},{"p":1310721,"g":{"r":0,"d":0,"h":25771033760,"f":2},"n":"tasksCount","d":1229984,"h":21476066464,"f":2},{"p":1310721,"g":{"r":0,"d":0,"h":34360968352,"f":2},"n":"completedCount","d":1229984,"h":30066001056,"f":2},{"p":1310721,"g":{"r":0,"d":0,"h":42950902944,"f":2},"n":"pendingCount","d":1229984,"h":38655935648,"f":2},{"p":4980744,"g":{"r":0,"d":0,"h":73015674016,"f":2},"s":{"r":0,"d":0,"h":77310641312,"f":2},"n":"Nav","d":1229984,"h":68720706720,"f":2,"a":[{"t":4259848,"c":21479096328}]},{"p":181408,"g":{"r":0,"d":0,"h":90195543200,"f":2},"s":{"r":0,"d":0,"h":94490510496,"f":2},"n":"TaskService","d":1229984,"h":85900575904,"f":2,"a":[{"t":4259848,"c":21479096328}]},{"p":2081952,"g":{"r":0,"d":0,"h":107375412384,"f":2},"s":{"r":0,"d":0,"h":111670379680,"f":2},"n":"Auth","d":1229984,"h":103080445088,"f":2,"a":[{"t":4259848,"c":21479096328}]}],"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","d":1229984,"h":4296197280,"f":32772},{"r":65537,"n":"GoToTask","d":1229984,"h":47245870240,"f":2},{"r":65537,"n":"ViewProfile","d":1229984,"h":51540837536,"f":2},{"r":133300225,"n":"OnInitializedAsync","d":1229984,"h":55835804832,"f":36868},{"r":133300225,"p":[{"n":"firstRender","p":262145}],"n":"OnAfterRenderAsync","d":1229984,"h":60130772128,"f":36868}],"l":[{"t":262145,"n":"isLoading","d":1229984,"h":8591164576,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":1229984,"h":115965346976,"f":1}],"i":[2752520,3145736,3080200],"h":1229984,"a":[{"t":9895944,"c":4304863240,"a":[{"v":"/dashboard","t":1310721}]}]}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `Taskman.Components.Pages.Dashboard`; }
        });
        
        $asm.$cls("$t.Taskman.Components.Pages.Profile", ($self) => class Profile extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OpenComponent($.$t.Taskman.Components.NavBar, 0);
                __builder.CloseComponent();
                if (this.isLoading)
                {
                    if ($.$spc.System.String.op_Equality(this.Auth.Role, "Admin"))
                    {
                        __builder.OpenComponent($.$t.Taskman.Components.LoadingCardMajor, 1);
                        __builder.AddComponentParameter(2, "LoadingState", "\u23F3 Loading Admin profile...");
                        __builder.CloseComponent();
                    }
                    else if ($.$spc.System.String.op_Equality(this.Auth.Role, "User"))
                    {
                        __builder.OpenComponent($.$t.Taskman.Components.LoadingCardMajor, 3);
                        __builder.AddComponentParameter(4, "LoadingState", "\u23F3 Loading User profile...");
                        __builder.CloseComponent();
                    }
                    else 
                    {
                        __builder.OpenComponent($.$t.Taskman.Components.LoadingCardMajor, 5);
                        __builder.AddComponentParameter(6, "LoadingState", "\u23F3 Loading profile...");
                        __builder.CloseComponent();
                    }
                }
                else 
                {
                    __builder.AddMarkupContent(7, "<h3 style=\"margin-top: 20px;\">\uD83D\uDC64 My Profile</h3>");
                    __builder.OpenElement(8, "div");
                    __builder.AddAttribute$2(9, "style", "background: rgb(255, 166, 0, 0.2); padding: 20px 40px; font-size: 20px; margin-top: 30px; flex-wrap: wrap;");
                    __builder.OpenElement(10, "div");
                    __builder.AddAttribute$2(11, "style", "background: rgb(255, 166, 0, 0.2); padding: 20px 40px; font-size: 20px; display: flex; justify-content: space-between; margin-top: 30px; flex-wrap: wrap;");
                    __builder.OpenElement(12, "p");
                    __builder.AddMarkupContent(13, "<b style=\"color: purple;\">\uD83D\uDE4E\u200D\u2642\uFE0F Fullname:</b>\n                ");
                    __builder.AddContent(14, this.fullName);
                    __builder.CloseElement();
                    __builder.AddMarkupContent(15, "\n            ");
                    __builder.OpenElement(16, "p");
                    __builder.AddMarkupContent(17, "<b style=\"color: purple;\">\uD83D\uDC66 Username:</b>\n                ");
                    __builder.AddContent(18, this.Auth.Username);
                    __builder.CloseElement();
                    __builder.AddMarkupContent(19, "\n            ");
                    __builder.OpenElement(20, "p");
                    __builder.AddMarkupContent(21, "<b style=\"color: purple; margin-right: 4px;\">\uD83D\uDCC5 Member since:</b>");
                    if (this.Auth.IsLoggedIn)
                    {
                        __builder.AddContent(22, $.$spc.System.DateTime.Now.ToString$1("MMM yyyy"));
                    }
                    __builder.CloseElement();
                    __builder.CloseElement();
                    __builder.AddMarkupContent(23, "\n        ");
                    __builder.OpenElement(24, "div");
                    __builder.AddAttribute$2(25, "style", "background: rgb(255, 166, 0, 0.2); padding: 20px 40px; font-size: 20px; display: flex; justify-content: space-between; margin-top: 30px; flex-wrap: wrap;");
                    __builder.OpenElement(26, "p");
                    __builder.AddMarkupContent(27, "<b style=\"color: purple;\">\uD83C\uDFF7\uFE0F Role:</b>\n                ");
                    __builder.AddContent(28, this.Auth.Role);
                    __builder.CloseElement();
                    __builder.AddMarkupContent(29, "\n            ");
                    __builder.OpenElement(30, "p");
                    __builder.AddMarkupContent(31, "<b style=\"color: purple;\">\uD83D\uDCC5 Date of Birth:</b>\n                ");
                    __builder.AddContent(32, this.Auth.DateOfBirth);
                    __builder.CloseElement();
                    __builder.AddMarkupContent(33, "\n            ");
                    __builder.OpenElement(34, "p");
                    __builder.AddMarkupContent(35, "<b style=\"color: purple; margin-right: 4px;\">\uD83D\uDCE7 Email:</b>\n                ");
                    __builder.AddContent(36, this.Auth.Email);
                    __builder.CloseElement();
                    __builder.CloseElement();
                    __builder.CloseElement();
                    if (!this.Auth.IsLoggedIn)
                    {
                        __builder.OpenComponent($.$t.Taskman.Components.NotLoginCard, 37);
                        __builder.AddComponentParameter(38, "Title", "User not logged in...");
                        __builder.AddComponentParameter(39, "SubTitle", "Click to log in...");
                        __builder.CloseComponent();
                    }
                    else 
                    {
                        __builder.OpenElement(40, "div");
                        __builder.AddAttribute$2(41, "style", "background: rgb(133, 133, 133, 0.2); padding: 20px 40px; font-size: 20px; margin: 30px 0;");
                        __builder.AddMarkupContent(42, "<h5>\uD83D\uDCCA My Stats</h5>\n            ");
                        __builder.OpenElement(43, "div");
                        __builder.AddAttribute$2(44, "style", "background: rgb(133, 133, 133, 0.2); padding: 20px 40px; font-size: 20px; display: flex; justify-content: space-between; flex-wrap: wrap; margin-top: 30px;");
                        __builder.OpenElement(45, "p");
                        __builder.AddMarkupContent(46, "<b style=\"margin-right: 20px\">\u2705 Completed: </b>\n                    ");
                        __builder.OpenElement(47, "i");
                        __builder.AddAttribute$2(48, "style", "font-size: 30px; color: purple; font-weight: bold;");
                        __builder.AddContent(49, this.completedCount);
                        __builder.CloseElement();
                        __builder.CloseElement();
                        __builder.AddMarkupContent(50, "\n                ");
                        __builder.OpenElement(51, "p");
                        __builder.AddMarkupContent(52, "<b style=\"margin-right: 20px\">\u23F3 Pending: </b>\n                    ");
                        __builder.OpenElement(53, "i");
                        __builder.AddAttribute$2(54, "style", "font-size: 30px; color: purple; font-weight: bold;");
                        __builder.AddContent(55, this.pendingCount);
                        __builder.CloseElement();
                        __builder.CloseElement();
                        __builder.AddMarkupContent(56, "\n                ");
                        __builder.OpenElement(57, "p");
                        __builder.AddMarkupContent(58, "<b style=\"margin-right: 20px\">\uD83D\uDCDD Total: </b>\n                    ");
                        __builder.OpenElement(59, "i");
                        __builder.AddAttribute$2(60, "style", "font-size: 30px; color: purple; font-weight: bold;");
                        __builder.AddContent(61, this.tasksCount);
                        __builder.CloseElement();
                        __builder.CloseElement();
                        __builder.CloseElement();
                        __builder.CloseElement();
                        __builder.OpenElement(62, "div");
                        __builder.AddAttribute$2(63, "style", "display: flex; justify-content: space-between; flex-wrap: wrap;");
                        __builder.OpenElement(64, "div");
                        __builder.AddAttribute$2(65, "style", "margin-bottom: 10px;");
                        __builder.OpenElement(66, "div");
                        __builder.AddAttribute$2(67, "style", "margin-bottom: 10px;");
                        __builder.OpenComponent($.$t.Taskman.Components.ButtonCard, 68);
                        __builder.AddComponentParameter(69, "BgColor", "rgb(140, 0, 140, 0.3)");
                        __builder.AddComponentParameter(70, "BtnText", "\u2B05 Back To DashBoard");
                        __builder.AddComponentParameter(71, "OnClick", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$mac.Microsoft.AspNetCore.Components.EventCallback, $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$1(this, new $.$spc.System.Action().$ctor(this, this.BackToDashboard))));
                        __builder.CloseComponent();
                        __builder.CloseElement();
                        __builder.AddMarkupContent(72, "\n                ");
                        __builder.OpenElement(73, "div");
                        __builder.AddAttribute$2(74, "style", "margin-bottom: 10px;");
                        __builder.OpenComponent($.$t.Taskman.Components.ButtonCard, 75);
                        __builder.AddComponentParameter(76, "BgColor", "rgb(135, 135, 135, 0.3)");
                        __builder.AddComponentParameter(77, "BtnText", "\uD83D\uDEAA Logout");
                        __builder.AddComponentParameter(78, "OnClick", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$mac.Microsoft.AspNetCore.Components.EventCallback, $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$1(this, new $.$spc.System.Action().$ctor(this, this.Logout))));
                        __builder.CloseComponent();
                        __builder.CloseElement();
                        __builder.CloseElement();
                        if (this.confirmAccountDelete === false)
                        {
                            __builder.OpenElement(79, "div");
                            __builder.OpenComponent($.$t.Taskman.Components.Confirm, 80);
                            __builder.AddComponentParameter(81, "Title", "Sure to delete this account?");
                            __builder.AddComponentParameter(82, "Text1", "\u2705 Confirm");
                            __builder.AddComponentParameter(83, "Text2", "\u274C Cancel");
                            __builder.AddComponentParameter(84, "ConfirmBtn", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$mac.Microsoft.AspNetCore.Components.EventCallback, $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$3(this, new ($.$spc.System.Func$$($.$spc.System.Threading.Tasks.Task))().$ctor(this, this.DeleteUserAccount))));
                            __builder.AddComponentParameter(85, "CancelBtn", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$mac.Microsoft.AspNetCore.Components.EventCallback, $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$1(this, new $.$spc.System.Action().$ctor(this,  () =>
                            {
                                return this.confirmAccountDelete = true;
                            }, {"r":65537,"n":"","d":1361056,"h":0,"f":1048578}))));
                            __builder.CloseComponent();
                            __builder.CloseElement();
                        }
                        else 
                        {
                            __builder.OpenElement(86, "div");
                            __builder.AddAttribute$2(87, "style", "margin-bottom: 10px;");
                            __builder.OpenComponent($.$t.Taskman.Components.ButtonCard, 88);
                            __builder.AddComponentParameter(89, "BgColor", "rgba(255, 0, 0, 0.3)");
                            __builder.AddComponentParameter(90, "BtnText", "\uD83D\uDDD1\uFE0F Delete Account");
                            __builder.AddComponentParameter(91, "OnClick", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$mac.Microsoft.AspNetCore.Components.EventCallback, $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$1(this, new $.$spc.System.Action().$ctor(this,  () =>
                            {
                                return this.confirmAccountDelete = false;
                            }, {"r":65537,"n":"","d":1361056,"h":0,"f":1048578}))));
                            __builder.CloseComponent();
                            __builder.CloseElement();
                        }
                        __builder.CloseElement();
                    }
                }
            }
            /*bool*/ isLoading = false;
            /*List<AppTask> */ get tasks()
            {
                return this.TaskService.ITaskService$GetAll() ?? new ($.$spc.System.Collections.Generic.List$$($.$t.AppTask))().$ctor$1();
            }
            /*string */ get tasksCount()
            {
                return $.$spc.System.Int32.ToString.call(this.tasks.Count);
            }
            /*string */ get completedCount()
            {
                return $.$spc.System.Int32.ToString.call($.$sl.System.Linq.Enumerable.Count$1($.$t.AppTask, this.tasks, new ($.$spc.System.Func$$$($.$t.AppTask, $.$spc.System.Boolean))().$ctor(this,  (/*t*/ t) =>
                {
                    return t.IsComplete;
                }, {"r":262145,"p":[{"n":"t","p":115872}],"n":"","d":1361056,"h":0,"f":1048578})));
            }
            /*string */ get pendingCount()
            {
                return $.$spc.System.Int32.ToString.call($.$sl.System.Linq.Enumerable.Count$1($.$t.AppTask, this.tasks, new ($.$spc.System.Func$$$($.$t.AppTask, $.$spc.System.Boolean))().$ctor(this,  (/*t*/ t) =>
                {
                    return !t.IsComplete;
                }, {"r":262145,"p":[{"n":"t","p":115872}],"n":"","d":1361056,"h":0,"f":1048578})));
            }
            /*string */ get fullName()
            {
                return `${this.Auth.Lastname} ${this.Auth.Firstname}`;
            }
            /*bool*/ confirmAccountDelete = true;
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    this.isLoading = true;
                    await $.$spc.System.Threading.Tasks.Task.Delay$4(500);
                    this.isLoading = false;
                    this.StateHasChanged();
                });
            }
            /*void */ BackToDashboard()
            {
                this.Nav.NavigateTo$1("dashboard", false, false);
                this.StateHasChanged();
            }
            /*Task *//*async*/  DeleteUserAccount()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    await this.Auth.DeleteAccount();
                    this.StateHasChanged();
                });
            }
            /*void */ Logout()
            {
                this.Nav.NavigateTo$1("", false, false);
                this.Auth.Logout();
            }
            /*Task *//*async*/  OnAfterRenderAsync(/*bool*/ firstRender)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    if (firstRender)
                    {
                        await this.Auth.LoadUsers();
                        await this.TaskService.ITaskService$LoadTasks();
                        this.StateHasChanged();
                    }
                });
            }
            /*NavigationManager*/ Nav = null;
            /*ITaskService*/ TaskService = null;
            /*Taskman.Services.AuthService*/ Auth = null;
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.isLoading = false;
                this.Nav = null;
                this.TaskService = null;
                this.Auth = null;
            }
            static $h = 1361056;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17181230240,"f":2},"s":{"r":0,"d":0,"h":21476197536,"f":2},"n":"isLoading","d":1361056,"h":12886262944,"f":2},{"p":$.$spc.System.Collections.Generic.List$$($.$t.AppTask).$h,"g":{"r":0,"d":0,"h":30066132128,"f":2},"n":"tasks","d":1361056,"h":25771164832,"f":2},{"p":1310721,"g":{"r":0,"d":0,"h":38656066720,"f":2},"n":"tasksCount","d":1361056,"h":34361099424,"f":2},{"p":1310721,"g":{"r":0,"d":0,"h":47246001312,"f":2},"n":"completedCount","d":1361056,"h":42951034016,"f":2},{"p":1310721,"g":{"r":0,"d":0,"h":55835935904,"f":2},"n":"pendingCount","d":1361056,"h":51540968608,"f":2},{"p":1310721,"g":{"r":0,"d":0,"h":64425870496,"f":2},"n":"fullName","d":1361056,"h":60130903200,"f":2},{"p":4980744,"g":{"r":0,"d":0,"h":103080576160,"f":2},"s":{"r":0,"d":0,"h":107375543456,"f":2},"n":"Nav","d":1361056,"h":98785608864,"f":2,"a":[{"t":4259848,"c":21479096328}]},{"p":181408,"g":{"r":0,"d":0,"h":120260445344,"f":2},"s":{"r":0,"d":0,"h":124555412640,"f":2},"n":"TaskService","d":1361056,"h":115965478048,"f":2,"a":[{"t":4259848,"c":21479096328}]},{"p":2081952,"g":{"r":0,"d":0,"h":137440314528,"f":2},"s":{"r":0,"d":0,"h":141735281824,"f":2},"n":"Auth","d":1361056,"h":133145347232,"f":2,"a":[{"t":4259848,"c":21479096328}]}],"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","d":1361056,"h":4296328352,"f":32772},{"r":133300225,"n":"OnInitializedAsync","d":1361056,"h":73015805088,"f":36868},{"r":65537,"n":"BackToDashboard","d":1361056,"h":77310772384,"f":2},{"r":133300225,"n":"DeleteUserAccount","d":1361056,"h":81605739680,"f":4098},{"r":65537,"n":"Logout","d":1361056,"h":85900706976,"f":2},{"r":133300225,"p":[{"n":"firstRender","p":262145}],"n":"OnAfterRenderAsync","d":1361056,"h":90195674272,"f":36868}],"l":[{"t":262145,"n":"confirmAccountDelete","d":1361056,"h":68720837792,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":1361056,"h":146030249120,"f":1}],"i":[2752520,3145736,3080200],"h":1361056,"a":[{"t":9895944,"c":4304863240,"a":[{"v":"/profile","t":1310721}]}]}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `Taskman.Components.Pages.Profile`; }
        });
        
        $asm.$cls("$t.Taskman.Layout.ReconnectModal", ($self) => class ReconnectModal extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OpenElement(0, "script");
                __builder.AddAttribute$2(1, "type", "module");
                __builder.AddAttribute$2(2, "src", this.Assets.get_Item("Components/Layout/ReconnectModal.razor.js"));
                __builder.AddAttribute(3, "b-0qeclx541a");
                __builder.CloseElement();
                __builder.AddMarkupContent(4, "\n\n");
                __builder.AddMarkupContent(5, "<dialog id=\"components-reconnect-modal\" data-nosnippet b-0qeclx541a><div class=\"components-reconnect-container\" b-0qeclx541a><div class=\"components-rejoining-animation\" aria-hidden=\"true\" b-0qeclx541a><div b-0qeclx541a></div>\n            <div b-0qeclx541a></div></div>\n        <p class=\"components-reconnect-first-attempt-visible\" b-0qeclx541a>\n            Rejoining the server...\n        </p>\n        <p class=\"components-reconnect-repeated-attempt-visible\" b-0qeclx541a>\n            Rejoin failed... trying again in <span id=\"components-seconds-to-next-attempt\" b-0qeclx541a></span> seconds.\n        </p>\n        <p class=\"components-reconnect-failed-visible\" b-0qeclx541a>\n            Failed to rejoin.<br b-0qeclx541a>Please retry or reload the page.\n        </p>\n        <button id=\"components-reconnect-button\" class=\"components-reconnect-failed-visible\" b-0qeclx541a>\n            Retry\n        </button>\n        <p class=\"components-pause-visible\" b-0qeclx541a>\n            The session has been paused by the server.\n        </p>\n        <button id=\"components-resume-button\" class=\"components-pause-visible\" b-0qeclx541a>\n            Resume\n        </button>\n        <p class=\"components-resume-failed-visible\" b-0qeclx541a>\n            Failed to resume the session.<br b-0qeclx541a>Please reload the page.\n        </p></div></dialog>");
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 2016416;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","d":2016416,"h":4296983712,"f":32772}],"c":[{"n":".ctor","o":"$ctor$2","d":2016416,"h":8591951008,"f":1}],"i":[2752520,3145736,3080200],"h":2016416}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `Taskman.Layout.ReconnectModal`; }
        });
        
        $asm.$cls("$t.Taskman.Components.TaskCard", ($self) => class TaskCard extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OpenElement(0, "table");
                __builder.AddAttribute$2(1, "class", "task-container mobile");
                __builder.AddAttribute(2, "b-whjw6qbj78");
                __builder.OpenElement(3, "tr");
                __builder.AddAttribute$2(4, "class", "tr");
                __builder.AddAttribute(5, "b-whjw6qbj78");
                __builder.OpenElement(6, "td");
                __builder.AddAttribute$2(7, "class", "td1");
                __builder.AddAttribute(8, "b-whjw6qbj78");
                __builder.OpenElement(9, "div");
                __builder.AddAttribute$5($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, 10, "onclick", $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$9($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, this, new ($.$spc.System.Func$$($.$spc.System.Threading.Tasks.Task))().$ctor(this,  () =>
                {
                    return this.OnToggle.InvokeAsync(this.Task.Id);
                }, {"r":133300225,"n":"","d":1819808,"h":0,"f":1048578})));
                __builder.AddAttribute$2(11, "class", "container-title");
                __builder.AddAttribute(12, "b-whjw6qbj78");
                __builder.OpenElement(13, "p");
                __builder.AddAttribute(14, "b-whjw6qbj78");
                __builder.OpenElement(15, "input");
                __builder.AddAttribute$2(16, "style", "user-select: none; pointer-events: none;");
                __builder.AddAttribute$2(17, "type", "checkbox");
                __builder.AddAttribute$1(18, "checked", this.Task.IsComplete);
                $.$macw.Microsoft.AspNetCore.Components.Web.WebRenderTreeBuilderExtensions.AddEventStopPropagationAttribute(__builder, 19, "onclick", true);
                __builder.AddAttribute(20, "b-whjw6qbj78");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(21, "\n\n                ");
                __builder.OpenElement(22, "p");
                __builder.AddAttribute$2(23, "style", "font-weight: bold");
                __builder.AddAttribute(24, "b-whjw6qbj78");
                __builder.AddContent(25, this.Task.Title);
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(26, "\n        ");
                __builder.OpenElement(27, "td");
                __builder.AddAttribute$2(28, "class", "td2");
                __builder.AddAttribute(29, "b-whjw6qbj78");
                __builder.OpenElement(30, "button");
                __builder.AddAttribute(31, "b-whjw6qbj78");
                if (this.Task.Priority === 1/*Priority.Low*/)
                {
                    __builder.AddMarkupContent(32, "<span b-whjw6qbj78><text b-whjw6qbj78>\uD83D\uDD34</text></span>");
                }
                else if (this.Task.Priority === 2/*Priority.Medium*/)
                {
                    __builder.AddMarkupContent(33, "<span b-whjw6qbj78><text b-whjw6qbj78>\uD83D\uDFE1</text></span>");
                }
                else if (this.Task.Priority === 3/*Priority.High*/)
                {
                    __builder.AddMarkupContent(34, "<span b-whjw6qbj78><text b-whjw6qbj78>\uD83D\uDFE2</text></span>");
                }
                __builder.AddContent$5(35, $.$box(this.Task.Priority, $.$t.Priority));
                __builder.CloseElement();
                __builder.AddMarkupContent(36, "\n            ");
                __builder.OpenElement(37, "button");
                __builder.AddAttribute$5($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, 38, "onclick", $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$9($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, this, new ($.$spc.System.Func$$($.$spc.System.Threading.Tasks.Task))().$ctor(this,  () =>
                {
                    return this.OnRequestDelete.InvokeAsync(this.Task.Id);
                }, {"r":133300225,"n":"","d":1819808,"h":0,"f":1048578})));
                __builder.AddAttribute(39, "b-whjw6qbj78");
                __builder.AddMarkupContent(40, "\uD83D\uDDD1\uFE0F");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
            }
            /*int?*/ TaskIdToDelete = null;
            /*EventCallback<int>*/ OnRequestDelete;
            /*AppTask*/ Task = null;
            /*EventCallback<int>*/ OnDelete;
            /*EventCallback<int>*/ OnToggle;
            /*EventCallback<int>*/ OnEdit;
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.TaskIdToDelete = null;
                this.OnRequestDelete = $.$default($.$mac.Microsoft.AspNetCore.Components.EventCallback$$($.$spc.System.Int32));
                this.Task = new $.$t.AppTask().$ctor$1();
                this.OnDelete = $.$default($.$mac.Microsoft.AspNetCore.Components.EventCallback$$($.$spc.System.Int32));
                this.OnToggle = $.$default($.$mac.Microsoft.AspNetCore.Components.EventCallback$$($.$spc.System.Int32));
                this.OnEdit = $.$default($.$mac.Microsoft.AspNetCore.Components.EventCallback$$($.$spc.System.Int32));
            }
            static $h = 1819808;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":$.$typeNullable($.$spc.System.Int32).$h,"g":{"r":0,"d":0,"h":17181688992,"f":1},"s":{"r":0,"d":0,"h":21476656288,"f":1},"n":"TaskIdToDelete","d":1819808,"h":12886721696,"f":1,"a":[{"t":5636104,"c":21480472584}]},{"p":$.$mac.Microsoft.AspNetCore.Components.EventCallback$$($.$spc.System.Int32).$h,"g":{"r":0,"d":0,"h":34361558176,"f":1},"s":{"r":0,"d":0,"h":38656525472,"f":1},"n":"OnRequestDelete","d":1819808,"h":30066590880,"f":1,"a":[{"t":5636104,"c":21480472584}]},{"p":115872,"g":{"r":0,"d":0,"h":51541427360,"f":1},"s":{"r":0,"d":0,"h":55836394656,"f":1},"n":"Task","d":1819808,"h":47246460064,"f":1,"a":[{"t":5636104,"c":21480472584}]},{"p":$.$mac.Microsoft.AspNetCore.Components.EventCallback$$($.$spc.System.Int32).$h,"g":{"r":0,"d":0,"h":68721296544,"f":1},"s":{"r":0,"d":0,"h":73016263840,"f":1},"n":"OnDelete","d":1819808,"h":64426329248,"f":1,"a":[{"t":5636104,"c":21480472584}]},{"p":$.$mac.Microsoft.AspNetCore.Components.EventCallback$$($.$spc.System.Int32).$h,"g":{"r":0,"d":0,"h":85901165728,"f":1},"s":{"r":0,"d":0,"h":90196133024,"f":1},"n":"OnToggle","d":1819808,"h":81606198432,"f":1,"a":[{"t":5636104,"c":21480472584}]},{"p":$.$mac.Microsoft.AspNetCore.Components.EventCallback$$($.$spc.System.Int32).$h,"g":{"r":0,"d":0,"h":103081034912,"f":1},"s":{"r":0,"d":0,"h":107376002208,"f":1},"n":"OnEdit","d":1819808,"h":98786067616,"f":1,"a":[{"t":5636104,"c":21480472584}]}],"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","d":1819808,"h":4296787104,"f":32772}],"c":[{"n":".ctor","o":"$ctor$2","d":1819808,"h":111670969504,"f":1}],"i":[2752520,3145736,3080200],"h":1819808}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `Taskman.Components.TaskCard`; }
        });
        
        $asm.$cls("$t.Taskman.Components.Pages.Login", ($self) => class Login extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                if (this.isLoading)
                {
                    __builder.AddMarkupContent(0, "<div style=\"position: fixed; top: 0px; bottom: 0px; left: 0px; right: 0px; background: purple;\" b-5mkzhhjfiq><div class=\"loading-progress\" style=\"display: flex; align-items: center; justify-content: center; width: 100%; height: 100vh;\" b-5mkzhhjfiq><img src=\"favicon.png\" alt=\"Taskman Logo\" width=\"120\" b-5mkzhhjfiq></div></div>");
                }
                else 
                {
                    __builder.OpenElement(1, "div");
                    __builder.AddAttribute$2(2, "class", "login-container");
                    __builder.AddAttribute(3, "b-5mkzhhjfiq");
                    __builder.AddMarkupContent(4, "<h3 b-5mkzhhjfiq>Login</h3>\n        ");
                    __builder.OpenElement(5, "div");
                    __builder.AddAttribute$2(6, "class", "sub-container");
                    __builder.AddAttribute(7, "b-5mkzhhjfiq");
                    __builder.OpenElement(8, "div");
                    __builder.AddAttribute$2(9, "class", "input-container");
                    __builder.AddAttribute(10, "b-5mkzhhjfiq");
                    __builder.AddMarkupContent(11, "<label for=\"username\" b-5mkzhhjfiq>Username</label>\n                ");
                    __builder.OpenElement(12, "input");
                    __builder.AddAttribute$2(13, "type", "text");
                    __builder.AddAttribute$2(14, "placeholder", "enter username...");
                    __builder.AddAttribute$2(15, "value", $.$mac.Microsoft.AspNetCore.Components.BindConverter.FormatValue(this.username, null));
                    __builder.AddAttribute$5($.$mac.Microsoft.AspNetCore.Components.ChangeEventArgs, 16, "onchange", $.$mac.Microsoft.AspNetCore.Components.EventCallbackFactoryBinderExtensions.CreateBinder($.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory, this, new ($.$spc.System.Action$$($.$spc.System.String))().$ctor(this,  (/*__value*/ __value) =>
                    {
                        return this.username = __value;
                    }, {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1295520,"h":0,"f":1048578}), this.username, null));
                    __builder.SetUpdatesAttributeName("value");
                    __builder.AddAttribute(17, "b-5mkzhhjfiq");
                    __builder.CloseElement();
                    __builder.CloseElement();
                    __builder.AddMarkupContent(18, "\n\n            ");
                    __builder.OpenElement(19, "div");
                    __builder.AddAttribute$2(20, "class", "input-container");
                    __builder.AddAttribute(21, "b-5mkzhhjfiq");
                    __builder.AddMarkupContent(22, "<label for=\"username\" b-5mkzhhjfiq>Password</label>\n                ");
                    __builder.OpenElement(23, "input");
                    __builder.AddAttribute$2(24, "type", "password");
                    __builder.AddAttribute$2(25, "placeholder", "enter password...");
                    __builder.AddAttribute$2(26, "value", $.$mac.Microsoft.AspNetCore.Components.BindConverter.FormatValue(this.password, null));
                    __builder.AddAttribute$5($.$mac.Microsoft.AspNetCore.Components.ChangeEventArgs, 27, "onchange", $.$mac.Microsoft.AspNetCore.Components.EventCallbackFactoryBinderExtensions.CreateBinder($.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory, this, new ($.$spc.System.Action$$($.$spc.System.String))().$ctor(this,  (/*__value*/ __value) =>
                    {
                        return this.password = __value;
                    }, {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1295520,"h":0,"f":1048578}), this.password, null));
                    __builder.SetUpdatesAttributeName("value");
                    __builder.AddAttribute(28, "b-5mkzhhjfiq");
                    __builder.CloseElement();
                    __builder.CloseElement();
                    __builder.AddMarkupContent(29, "\n\n            ");
                    __builder.OpenElement(30, "div");
                    __builder.AddAttribute$2(31, "class", "input-container");
                    __builder.AddAttribute(32, "b-5mkzhhjfiq");
                    __builder.OpenElement(33, "button");
                    __builder.AddAttribute$5($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, 34, "onclick", $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$7($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, this, new $.$spc.System.Action().$ctor(this, this.LoginUser)));
                    __builder.AddAttribute(35, "b-5mkzhhjfiq");
                    __builder.AddContent(36, "Login");
                    __builder.CloseElement();
                    __builder.CloseElement();
                    if (!this.Auth.IsLoggedIn)
                    {
                        __builder.OpenElement(37, "p");
                        __builder.AddAttribute(38, "b-5mkzhhjfiq");
                        __builder.AddContent(39, this.errorMessage);
                        __builder.CloseElement();
                    }
                    __builder.OpenElement(40, "div");
                    __builder.AddAttribute$2(41, "class", "signup");
                    __builder.AddAttribute(42, "b-5mkzhhjfiq");
                    __builder.AddMarkupContent(43, "<p b-5mkzhhjfiq>Don't have an account?</p>\n                ");
                    __builder.OpenComponent($.$t.Taskman.Components.ButtonCard, 44);
                    __builder.AddComponentParameter(45, "BgColor", "rgb(127, 0, 127, 0.3)");
                    __builder.AddComponentParameter(46, "BtnText", "Sign Up");
                    __builder.AddComponentParameter(47, "OnClick", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$mac.Microsoft.AspNetCore.Components.EventCallback, $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$1(this, new $.$spc.System.Action().$ctor(this, this.SignUp))));
                    __builder.CloseComponent();
                    __builder.CloseElement();
                    __builder.CloseElement();
                    __builder.CloseElement();
                }
            }
            /*string*/ username = null;
            /*string*/ password = null;
            /*string*/ errorMessage = null;
            /*bool*/ isLoading = false;
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    this.isLoading = true;
                    await $.$spc.System.Threading.Tasks.Task.Delay$4(2000);
                    this.isLoading = false;
                });
            }
            /*Task *//*async*/  OnAfterRenderAsync(/*bool*/ firstRender)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    if (firstRender)
                    {
                        await this.Auth.LoadUsers();
                    }
                });
            }
            /*void */ OnInitialized()
            {
                if (this.Auth.IsLoggedIn)
                {
                    this.Nav.NavigateTo$1("dashboard", false, false);
                }
            }
            /*void */ LoginUser()
            {
                /*bool*/ let success = this.Auth.Login(this.username, this.password);
                if (success)
                {
                    this.Nav.NavigateTo$1("dashboard", false, false);
                }
                else 
                {
                    this.errorMessage = "\u26A0\uFE0F Username or Password is not correct";
                }
            }
            /*void */ SignUp()
            {
                this.Nav.NavigateTo$1("signup", false, false);
            }
            /*NavigationManager*/ Nav = null;
            /*Taskman.Services.AuthService*/ Auth = null;
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.username = "";
                this.password = "";
                this.errorMessage = "";
                this.Nav = null;
                this.Auth = null;
            }
            static $h = 1295520;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":4980744,"g":{"r":0,"d":0,"h":55835870368,"f":2},"s":{"r":0,"d":0,"h":60130837664,"f":2},"n":"Nav","d":1295520,"h":51540903072,"f":2,"a":[{"t":4259848,"c":21479096328}]},{"p":2081952,"g":{"r":0,"d":0,"h":73015739552,"f":2},"s":{"r":0,"d":0,"h":77310706848,"f":2},"n":"Auth","d":1295520,"h":68720772256,"f":2,"a":[{"t":4259848,"c":21479096328}]}],"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","d":1295520,"h":4296262816,"f":32772},{"r":133300225,"n":"OnInitializedAsync","d":1295520,"h":25771099296,"f":36868},{"r":133300225,"p":[{"n":"firstRender","p":262145}],"n":"OnAfterRenderAsync","d":1295520,"h":30066066592,"f":36868},{"r":65537,"n":"OnInitialized","d":1295520,"h":34361033888,"f":32772},{"r":65537,"n":"LoginUser","d":1295520,"h":38656001184,"f":2},{"r":65537,"n":"SignUp","d":1295520,"h":42950968480,"f":2}],"l":[{"t":1310721,"n":"username","d":1295520,"h":8591230112,"f":2},{"t":1310721,"n":"password","d":1295520,"h":12886197408,"f":2},{"t":1310721,"n":"errorMessage","d":1295520,"h":17181164704,"f":2},{"t":262145,"n":"isLoading","d":1295520,"h":21476132000,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":1295520,"h":81605674144,"f":1}],"i":[2752520,3145736,3080200],"h":1295520,"a":[{"t":9895944,"c":4304863240,"a":[{"v":"/","t":1310721}]}]}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `Taskman.Components.Pages.Login`; }
        });
        
        $asm.$cls("$t.Taskman.Components.NavBar", ($self) => class NavBar extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$2(1, "class", "mobile-menu");
                __builder.AddAttribute(2, "b-jig343vp1k");
                __builder.OpenElement(3, "div");
                __builder.AddAttribute$2(4, "style", "background: purple; padding: 5px 10px;");
                __builder.AddAttribute(5, "b-jig343vp1k");
                __builder.OpenElement(6, "div");
                __builder.AddAttribute$2(7, "style", "display: flex; justify-content: space-between; align-items: center;");
                __builder.AddAttribute(8, "b-jig343vp1k");
                __builder.OpenElement(9, "div");
                __builder.AddAttribute$2(10, "style", "display: flex; align-items: center;");
                __builder.AddAttribute$5($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, 11, "onclick", $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$7($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, this, new $.$spc.System.Action().$ctor(this,  () =>
                {
                    return this.Nav.NavigateTo$1("", false, false);
                }, {"r":65537,"n":"","d":1033376,"h":0,"f":1048578})));
                __builder.AddAttribute(12, "b-jig343vp1k");
                __builder.AddMarkupContent(13, "<img src=\"favicon.png\" alt style=\"width: 30px; height: 30px; margin-right: 5px; border-radius: 5px;\" b-jig343vp1k>\n                ");
                __builder.AddMarkupContent(14, "<div style=\"display: flex; margin-top: 10px;\" b-jig343vp1k><h3 style=\"color: white;\" b-jig343vp1k>Tasks</h3>\n                    <h3 style=\"color: orange;\" b-jig343vp1k>Man</h3></div>");
                __builder.CloseElement();
                __builder.AddMarkupContent(15, "\n            ");
                __builder.OpenElement(16, "button");
                __builder.AddAttribute$2(17, "style", "background: none; border: none;");
                __builder.AddAttribute$5($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, 18, "onclick", $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$7($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, this, new $.$spc.System.Action().$ctor(this, this.ShowMenu)));
                __builder.AddAttribute(19, "b-jig343vp1k");
                __builder.AddMarkupContent(20, "<img src=\"menu.png\" alt style=\"width: 30px; height: 30px; border: 2px solid white; border-radius: 50%; color: color: white;\" b-jig343vp1k>");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(21, "\n\n");
                __builder.OpenElement(22, "div");
                __builder.AddAttribute$2(23, "class", "mobile-nav");
                __builder.AddAttribute(24, "b-jig343vp1k");
                __builder.OpenElement(25, "nav");
                __builder.AddAttribute$2(26, "style", "display: flex; justify-content: space-around; margin-bottom: 20px;");
                __builder.AddAttribute(27, "b-jig343vp1k");
                __builder.OpenElement(28, "div");
                __builder.AddAttribute$2(29, "class", "mobile");
                __builder.AddAttribute(30, "b-jig343vp1k");
                __builder.OpenComponent($.$macw.Microsoft.AspNetCore.Components.Routing.NavLink, 31);
                __builder.AddComponentParameter(32, "style", "text-decoration: none; color: white; font-weight: bold; font-size: 15px;");
                __builder.AddComponentParameter(33, "href", "dashboard");
                __builder.AddComponentParameter(34, "Match", $.$box($.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$macw.Microsoft.AspNetCore.Components.Routing.NavLinkMatch, 1/*NavLinkMatch.All*/), $.$macw.Microsoft.AspNetCore.Components.Routing.NavLinkMatch));
                __builder.AddAttribute$3(35, "ChildContent", new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddMarkupContent(36, "\uD83C\uDFE0 Home");
                })));
                __builder.CloseComponent();
                __builder.CloseElement();
                if ($.$spc.System.String.op_Equality(this.Auth.Role, "Admin"))
                {
                    __builder.OpenElement(37, "div");
                    __builder.AddAttribute$2(38, "class", "mobile");
                    __builder.AddAttribute(39, "b-jig343vp1k");
                    __builder.OpenComponent($.$macw.Microsoft.AspNetCore.Components.Routing.NavLink, 40);
                    __builder.AddComponentParameter(41, "style", "text-decoration: none; color: white; font-weight: bold; font-size: 15px;");
                    __builder.AddComponentParameter(42, "href", "tasks");
                    __builder.AddComponentParameter(43, "Match", $.$box($.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$macw.Microsoft.AspNetCore.Components.Routing.NavLinkMatch, 1/*NavLinkMatch.All*/), $.$macw.Microsoft.AspNetCore.Components.Routing.NavLinkMatch));
                    __builder.AddAttribute$3(44, "ChildContent", new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                    {
                        __builder2.AddMarkupContent(45, "\uD83D\uDCDD Tasks");
                    })));
                    __builder.CloseComponent();
                    __builder.CloseElement();
                    __builder.AddMarkupContent(46, "\n            ");
                    __builder.OpenElement(47, "div");
                    __builder.AddAttribute$2(48, "class", "mobile");
                    __builder.AddAttribute(49, "b-jig343vp1k");
                    __builder.OpenComponent($.$macw.Microsoft.AspNetCore.Components.Routing.NavLink, 50);
                    __builder.AddComponentParameter(51, "style", "text-decoration: none; color: white; font-weight: bold; font-size: 15px;");
                    __builder.AddComponentParameter(52, "href", "profile");
                    __builder.AddComponentParameter(53, "Match", $.$box($.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$macw.Microsoft.AspNetCore.Components.Routing.NavLinkMatch, 1/*NavLinkMatch.All*/), $.$macw.Microsoft.AspNetCore.Components.Routing.NavLinkMatch));
                    __builder.AddAttribute$3(54, "ChildContent", new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                    {
                        __builder2.AddMarkupContent(55, "\uD83D\uDC64 Profile");
                    })));
                    __builder.CloseComponent();
                    __builder.CloseElement();
                }
                __builder.OpenElement(56, "div");
                __builder.AddAttribute$2(57, "class", "mobile");
                __builder.AddAttribute(58, "b-jig343vp1k");
                __builder.OpenElement(59, "p");
                __builder.AddAttribute$2(60, "style", "text-decoration: none; color: white; font-weight: bold; font-size: 15px;");
                __builder.AddAttribute$2(61, "Match", "NavLinkMatch.All");
                __builder.AddAttribute(62, "b-jig343vp1k");
                __builder.AddMarkupContent(63, "\uD83D\uDC64\n                ");
                __builder.AddContent(64, this.Auth.Username);
                __builder.AddMarkupContent(65, " \uD83C\uDFF7\uFE0F ");
                __builder.AddContent(66, this.Auth.Role);
                __builder.CloseElement();
                __builder.CloseElement();
                if (this.Auth.IsLoggedIn)
                {
                    __builder.OpenElement(67, "div");
                    __builder.AddAttribute$2(68, "class", "mobile");
                    __builder.AddAttribute(69, "b-jig343vp1k");
                    __builder.OpenComponent($.$macw.Microsoft.AspNetCore.Components.Routing.NavLink, 70);
                    __builder.AddComponentParameter(71, "style", "text-decoration: none; color: white; font-weight: bold; font-size: 15px;");
                    __builder.AddComponentParameter(72, "href", "");
                    __builder.AddComponentParameter(73, "onclick", $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$7($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, this, new $.$spc.System.Action().$ctor(this, this.LogoutUser)));
                    __builder.AddComponentParameter(74, "Match", $.$box($.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$macw.Microsoft.AspNetCore.Components.Routing.NavLinkMatch, 1/*NavLinkMatch.All*/), $.$macw.Microsoft.AspNetCore.Components.Routing.NavLinkMatch));
                    __builder.AddAttribute$3(75, "ChildContent", new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent($.$t.Taskman.Components.ButtonCard, 76);
                        __builder2.AddComponentParameter(77, "BgColor", "white");
                        __builder2.AddComponentParameter(78, "BtnText", "\u232B Logout");
                        __builder2.AddComponentParameter(79, "OnClick", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$mac.Microsoft.AspNetCore.Components.EventCallback, $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$1(this, new $.$spc.System.Action().$ctor(this, this.LogoutUser))));
                        __builder2.CloseComponent();
                    })));
                    __builder.CloseComponent();
                    __builder.CloseElement();
                }
                else 
                {
                    __builder.OpenElement(80, "div");
                    __builder.AddAttribute$2(81, "class", "mobile");
                    __builder.AddAttribute(82, "b-jig343vp1k");
                    __builder.OpenComponent($.$macw.Microsoft.AspNetCore.Components.Routing.NavLink, 83);
                    __builder.AddComponentParameter(84, "style", "text-decoration: none; color: white; font-weight: bold; font-size: 15px;");
                    __builder.AddComponentParameter(85, "href", "");
                    __builder.AddComponentParameter(86, "onclick", $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$7($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, this, new $.$spc.System.Action().$ctor(this, this.LogoutUser)));
                    __builder.AddComponentParameter(87, "Match", $.$box($.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$macw.Microsoft.AspNetCore.Components.Routing.NavLinkMatch, 1/*NavLinkMatch.All*/), $.$macw.Microsoft.AspNetCore.Components.Routing.NavLinkMatch));
                    __builder.AddAttribute$3(88, "ChildContent", new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this, ( (/**/ __builder2) =>
                    {
                        __builder2.OpenComponent($.$t.Taskman.Components.ButtonCard, 89);
                        __builder2.AddComponentParameter(90, "BgColor", "white");
                        __builder2.AddComponentParameter(91, "BtnText", "\uD83D\uDEAA Login");
                        __builder2.AddComponentParameter(92, "OnClick", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$mac.Microsoft.AspNetCore.Components.EventCallback, $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$1(this, new $.$spc.System.Action().$ctor(this, this.LoginUser))));
                        __builder2.CloseComponent();
                    })));
                    __builder.CloseComponent();
                    __builder.CloseElement();
                }
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(93, "\n\n");
                __builder.OpenElement(94, "div");
                __builder.AddAttribute$2(95, "class", "mobile-nav slide-from-top");
                __builder.AddAttribute$2(96, "style", "display:" + " " + (this.showMenu ? "block" : "none") + ";");
                __builder.AddAttribute(97, "b-jig343vp1k");
                __builder.OpenElement(98, "nav");
                __builder.AddAttribute$2(99, "style", "display: flex; justify-content: space-around;");
                __builder.AddAttribute(100, "b-jig343vp1k");
                __builder.OpenElement(101, "div");
                __builder.AddAttribute$2(102, "class", "mobile");
                __builder.AddAttribute(103, "b-jig343vp1k");
                __builder.OpenComponent($.$macw.Microsoft.AspNetCore.Components.Routing.NavLink, 104);
                __builder.AddComponentParameter(105, "style", "text-decoration: none; color: white; font-weight: bold; font-size: 15px;");
                __builder.AddComponentParameter(106, "href", "dashboard");
                __builder.AddComponentParameter(107, "Match", $.$box($.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$macw.Microsoft.AspNetCore.Components.Routing.NavLinkMatch, 1/*NavLinkMatch.All*/), $.$macw.Microsoft.AspNetCore.Components.Routing.NavLinkMatch));
                __builder.AddAttribute$3(108, "ChildContent", new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this, ( (/**/ __builder2) =>
                {
                    __builder2.AddMarkupContent(109, "\uD83C\uDFE0 Home");
                })));
                __builder.CloseComponent();
                __builder.CloseElement();
                if ($.$spc.System.String.op_Equality(this.Auth.Role, "Admin"))
                {
                    __builder.OpenElement(110, "div");
                    __builder.AddAttribute$2(111, "class", "mobile");
                    __builder.AddAttribute(112, "b-jig343vp1k");
                    __builder.OpenComponent($.$macw.Microsoft.AspNetCore.Components.Routing.NavLink, 113);
                    __builder.AddComponentParameter(114, "style", "text-decoration: none; color: white; font-weight: bold; font-size: 15px;");
                    __builder.AddComponentParameter(115, "href", "tasks");
                    __builder.AddComponentParameter(116, "Match", $.$box($.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$macw.Microsoft.AspNetCore.Components.Routing.NavLinkMatch, 1/*NavLinkMatch.All*/), $.$macw.Microsoft.AspNetCore.Components.Routing.NavLinkMatch));
                    __builder.AddAttribute$3(117, "ChildContent", new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                    {
                        __builder2.AddMarkupContent(118, "\uD83D\uDCDD Tasks");
                    })));
                    __builder.CloseComponent();
                    __builder.CloseElement();
                    __builder.AddMarkupContent(119, "\n            ");
                    __builder.OpenElement(120, "div");
                    __builder.AddAttribute$2(121, "class", "mobile");
                    __builder.AddAttribute(122, "b-jig343vp1k");
                    __builder.OpenComponent($.$macw.Microsoft.AspNetCore.Components.Routing.NavLink, 123);
                    __builder.AddComponentParameter(124, "style", "text-decoration: none; color: white; font-weight: bold; font-size: 15px;");
                    __builder.AddComponentParameter(125, "href", "profile");
                    __builder.AddComponentParameter(126, "Match", $.$box($.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$macw.Microsoft.AspNetCore.Components.Routing.NavLinkMatch, 1/*NavLinkMatch.All*/), $.$macw.Microsoft.AspNetCore.Components.Routing.NavLinkMatch));
                    __builder.AddAttribute$3(127, "ChildContent", new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                    {
                        __builder2.AddMarkupContent(128, "\uD83D\uDC64 Profile");
                    })));
                    __builder.CloseComponent();
                    __builder.CloseElement();
                }
                __builder.OpenElement(129, "div");
                __builder.AddAttribute$2(130, "class", "mobile");
                __builder.AddAttribute(131, "b-jig343vp1k");
                __builder.OpenElement(132, "p");
                __builder.AddAttribute$2(133, "style", "text-decoration: none; color: white; font-weight: bold; font-size: 15px;");
                __builder.AddAttribute$2(134, "Match", "NavLinkMatch.All");
                __builder.AddAttribute(135, "b-jig343vp1k");
                __builder.AddMarkupContent(136, "\uD83D\uDC64\n                ");
                __builder.AddContent(137, this.Auth.Username);
                __builder.AddMarkupContent(138, " \uD83C\uDFF7\uFE0F ");
                __builder.AddContent(139, this.Auth.Role);
                __builder.CloseElement();
                __builder.CloseElement();
                if (this.Auth.IsLoggedIn)
                {
                    __builder.OpenElement(140, "div");
                    __builder.AddAttribute$2(141, "class", "mobile");
                    __builder.AddAttribute(142, "b-jig343vp1k");
                    __builder.OpenComponent($.$macw.Microsoft.AspNetCore.Components.Routing.NavLink, 143);
                    __builder.AddComponentParameter(144, "style", "text-decoration: none; color: white; font-weight: bold; font-size: 15px;");
                    __builder.AddComponentParameter(145, "href", "");
                    __builder.AddComponentParameter(146, "onclick", $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$7($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, this, new $.$spc.System.Action().$ctor(this, this.LogoutUser)));
                    __builder.AddComponentParameter(147, "Match", $.$box($.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$macw.Microsoft.AspNetCore.Components.Routing.NavLinkMatch, 1/*NavLinkMatch.All*/), $.$macw.Microsoft.AspNetCore.Components.Routing.NavLinkMatch));
                    __builder.AddAttribute$3(148, "ChildContent", new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent($.$t.Taskman.Components.ButtonCard, 149);
                        __builder2.AddComponentParameter(150, "BgColor", "white");
                        __builder2.AddComponentParameter(151, "BtnText", "\u232B Logout");
                        __builder2.AddComponentParameter(152, "OnClick", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$mac.Microsoft.AspNetCore.Components.EventCallback, $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$1(this, new $.$spc.System.Action().$ctor(this, this.LogoutUser))));
                        __builder2.CloseComponent();
                    })));
                    __builder.CloseComponent();
                    __builder.CloseElement();
                }
                else 
                {
                    __builder.OpenElement(153, "div");
                    __builder.AddAttribute$2(154, "class", "mobile");
                    __builder.AddAttribute(155, "b-jig343vp1k");
                    __builder.OpenComponent($.$macw.Microsoft.AspNetCore.Components.Routing.NavLink, 156);
                    __builder.AddComponentParameter(157, "style", "text-decoration: none; color: white; font-weight: bold; font-size: 15px;");
                    __builder.AddComponentParameter(158, "href", "");
                    __builder.AddComponentParameter(159, "onclick", $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$7($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, this, new $.$spc.System.Action().$ctor(this, this.LogoutUser)));
                    __builder.AddComponentParameter(160, "Match", $.$box($.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$macw.Microsoft.AspNetCore.Components.Routing.NavLinkMatch, 1/*NavLinkMatch.All*/), $.$macw.Microsoft.AspNetCore.Components.Routing.NavLinkMatch));
                    __builder.AddAttribute$3(161, "ChildContent", new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this, ( (/**/ __builder2) =>
                    {
                        __builder2.OpenComponent($.$t.Taskman.Components.ButtonCard, 162);
                        __builder2.AddComponentParameter(163, "BgColor", "white");
                        __builder2.AddComponentParameter(164, "BtnText", "\uD83D\uDEAA Login");
                        __builder2.AddComponentParameter(165, "OnClick", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$mac.Microsoft.AspNetCore.Components.EventCallback, $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$1(this, new $.$spc.System.Action().$ctor(this, this.LoginUser))));
                        __builder2.CloseComponent();
                    })));
                    __builder.CloseComponent();
                    __builder.CloseElement();
                }
                __builder.CloseElement();
                __builder.CloseElement();
            }
            /*bool*/ showMenu = false;
            /*void */ ShowMenu()
            {
                this.showMenu = !this.showMenu;
            }
            /*void */ LoginUser()
            {
                this.Nav.NavigateTo$1("", false, false);
            }
            /*void */ LogoutUser()
            {
                this.Auth.Logout();
                this.Nav.NavigateTo$1("", false, false);
            }
            /*NavigationManager*/ Nav = null;
            /*Taskman.Services.AuthService*/ Auth = null;
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Nav = null;
                this.Auth = null;
            }
            static $h = 1033376;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":4980744,"g":{"r":0,"d":0,"h":34360771744,"f":2},"s":{"r":0,"d":0,"h":38655739040,"f":2},"n":"Nav","d":1033376,"h":30065804448,"f":2,"a":[{"t":4259848,"c":21479096328}]},{"p":2081952,"g":{"r":0,"d":0,"h":51540640928,"f":2},"s":{"r":0,"d":0,"h":55835608224,"f":2},"n":"Auth","d":1033376,"h":47245673632,"f":2,"a":[{"t":4259848,"c":21479096328}]}],"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","d":1033376,"h":4296000672,"f":32772},{"r":65537,"n":"ShowMenu","d":1033376,"h":12885935264,"f":2},{"r":65537,"n":"LoginUser","d":1033376,"h":17180902560,"f":2},{"r":65537,"n":"LogoutUser","d":1033376,"h":21475869856,"f":2}],"l":[{"t":262145,"n":"showMenu","d":1033376,"h":8590967968,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":1033376,"h":60130575520,"f":1}],"i":[2752520,3145736,3080200],"h":1033376}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `Taskman.Components.NavBar`; }
        });
        
        $asm.$cls("$t.Taskman.Components.Pages.SignUp", ($self) => class SignUp extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                if (this.isLoading)
                {
                    __builder.AddMarkupContent(0, "<p b-m9x6l6rp3k>\u23F3 Loading...</p>");
                }
                else 
                {
                    __builder.OpenElement(1, "div");
                    __builder.AddAttribute$2(2, "class", "login-container");
                    __builder.AddAttribute(3, "b-m9x6l6rp3k");
                    __builder.AddMarkupContent(4, "<h3 b-m9x6l6rp3k>Sign Up</h3>\n        ");
                    __builder.OpenElement(5, "div");
                    __builder.AddAttribute$2(6, "class", "sub-container");
                    __builder.AddAttribute(7, "b-m9x6l6rp3k");
                    __builder.OpenElement(8, "div");
                    __builder.AddAttribute$2(9, "class", "input-container");
                    __builder.AddAttribute(10, "b-m9x6l6rp3k");
                    __builder.AddMarkupContent(11, "<label for=\"username\" b-m9x6l6rp3k>Firstname</label>\n                ");
                    __builder.OpenElement(12, "input");
                    __builder.AddAttribute$2(13, "type", "text");
                    __builder.AddAttribute$2(14, "placeholder", "enter firstname...");
                    __builder.AddAttribute$2(15, "value", $.$mac.Microsoft.AspNetCore.Components.BindConverter.FormatValue(this.firstname, null));
                    __builder.AddAttribute$5($.$mac.Microsoft.AspNetCore.Components.ChangeEventArgs, 16, "onchange", $.$mac.Microsoft.AspNetCore.Components.EventCallbackFactoryBinderExtensions.CreateBinder($.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory, this, new ($.$spc.System.Action$$($.$spc.System.String))().$ctor(this,  (/*__value*/ __value) =>
                    {
                        return this.firstname = __value;
                    }, {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1426592,"h":0,"f":1048578}), this.firstname, null));
                    __builder.SetUpdatesAttributeName("value");
                    __builder.AddAttribute(17, "b-m9x6l6rp3k");
                    __builder.CloseElement();
                    __builder.CloseElement();
                    __builder.AddMarkupContent(18, "\n\n            ");
                    __builder.OpenElement(19, "div");
                    __builder.AddAttribute$2(20, "class", "input-container");
                    __builder.AddAttribute(21, "b-m9x6l6rp3k");
                    __builder.AddMarkupContent(22, "<label for=\"username\" b-m9x6l6rp3k>Lastname</label>\n                ");
                    __builder.OpenElement(23, "input");
                    __builder.AddAttribute$2(24, "type", "text");
                    __builder.AddAttribute$2(25, "placeholder", "enter lastname...");
                    __builder.AddAttribute$2(26, "value", $.$mac.Microsoft.AspNetCore.Components.BindConverter.FormatValue(this.lastname, null));
                    __builder.AddAttribute$5($.$mac.Microsoft.AspNetCore.Components.ChangeEventArgs, 27, "onchange", $.$mac.Microsoft.AspNetCore.Components.EventCallbackFactoryBinderExtensions.CreateBinder($.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory, this, new ($.$spc.System.Action$$($.$spc.System.String))().$ctor(this,  (/*__value*/ __value) =>
                    {
                        return this.lastname = __value;
                    }, {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1426592,"h":0,"f":1048578}), this.lastname, null));
                    __builder.SetUpdatesAttributeName("value");
                    __builder.AddAttribute(28, "b-m9x6l6rp3k");
                    __builder.CloseElement();
                    __builder.CloseElement();
                    __builder.AddMarkupContent(29, "\n\n            ");
                    __builder.OpenElement(30, "div");
                    __builder.AddAttribute$2(31, "class", "input-container");
                    __builder.AddAttribute(32, "b-m9x6l6rp3k");
                    __builder.AddMarkupContent(33, "<label for=\"username\" b-m9x6l6rp3k>Email</label>\n                ");
                    __builder.OpenElement(34, "input");
                    __builder.AddAttribute$2(35, "type", "email");
                    __builder.AddAttribute$2(36, "placeholder", "enter email...");
                    __builder.AddAttribute$2(37, "value", $.$mac.Microsoft.AspNetCore.Components.BindConverter.FormatValue(this.email, null));
                    __builder.AddAttribute$5($.$mac.Microsoft.AspNetCore.Components.ChangeEventArgs, 38, "onchange", $.$mac.Microsoft.AspNetCore.Components.EventCallbackFactoryBinderExtensions.CreateBinder($.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory, this, new ($.$spc.System.Action$$($.$spc.System.String))().$ctor(this,  (/*__value*/ __value) =>
                    {
                        return this.email = __value;
                    }, {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1426592,"h":0,"f":1048578}), this.email, null));
                    __builder.SetUpdatesAttributeName("value");
                    __builder.AddAttribute(39, "b-m9x6l6rp3k");
                    __builder.CloseElement();
                    __builder.CloseElement();
                    __builder.AddMarkupContent(40, "\n\n            ");
                    __builder.OpenElement(41, "div");
                    __builder.AddAttribute$2(42, "class", "input-container");
                    __builder.AddAttribute(43, "b-m9x6l6rp3k");
                    __builder.AddMarkupContent(44, "<label for=\"username\" b-m9x6l6rp3k>Username</label>\n                ");
                    __builder.OpenElement(45, "input");
                    __builder.AddAttribute$2(46, "type", "text");
                    __builder.AddAttribute$2(47, "placeholder", "enter username...");
                    __builder.AddAttribute$2(48, "value", $.$mac.Microsoft.AspNetCore.Components.BindConverter.FormatValue(this.username, null));
                    __builder.AddAttribute$5($.$mac.Microsoft.AspNetCore.Components.ChangeEventArgs, 49, "onchange", $.$mac.Microsoft.AspNetCore.Components.EventCallbackFactoryBinderExtensions.CreateBinder($.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory, this, new ($.$spc.System.Action$$($.$spc.System.String))().$ctor(this,  (/*__value*/ __value) =>
                    {
                        return this.username = __value;
                    }, {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1426592,"h":0,"f":1048578}), this.username, null));
                    __builder.SetUpdatesAttributeName("value");
                    __builder.AddAttribute(50, "b-m9x6l6rp3k");
                    __builder.CloseElement();
                    __builder.CloseElement();
                    __builder.AddMarkupContent(51, "\n\n            ");
                    __builder.OpenElement(52, "div");
                    __builder.AddAttribute$2(53, "class", "input-container");
                    __builder.AddAttribute(54, "b-m9x6l6rp3k");
                    __builder.AddMarkupContent(55, "<label for=\"username\" b-m9x6l6rp3k>Date of Birth</label>\n                ");
                    __builder.OpenElement(56, "input");
                    __builder.AddAttribute$2(57, "type", "date");
                    __builder.AddAttribute$2(58, "placeholder", "enter password...");
                    __builder.AddAttribute$2(59, "value", $.$mac.Microsoft.AspNetCore.Components.BindConverter.FormatValue$18(this.dateOfBirth?.Clone() ?? null, "yyyy-MM-dd", $.$spc.System.Globalization.CultureInfo.InvariantCulture));
                    __builder.AddAttribute$5($.$mac.Microsoft.AspNetCore.Components.ChangeEventArgs, 60, "onchange", $.$mac.Microsoft.AspNetCore.Components.EventCallbackFactoryBinderExtensions.CreateBinder$36($.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory, this, new ($.$spc.System.Action$$($.$spc.System.Nullable$$($.$spc.System.DateTime)))().$ctor(this,  (/*__value*/ __value) =>
                    {
                        return this.dateOfBirth = __value?.Clone() ?? null;
                    }, {"r":65537,"p":[{"n":"__value","p":$.$typeNullable($.$spc.System.DateTime).$h}],"n":"","d":1426592,"h":0,"f":1048578}), this.dateOfBirth?.Clone() ?? null, "yyyy-MM-dd", $.$spc.System.Globalization.CultureInfo.InvariantCulture));
                    __builder.SetUpdatesAttributeName("value");
                    __builder.AddAttribute(61, "b-m9x6l6rp3k");
                    __builder.CloseElement();
                    __builder.CloseElement();
                    __builder.AddMarkupContent(62, "\n\n            ");
                    __builder.OpenElement(63, "div");
                    __builder.AddAttribute$2(64, "class", "input-container");
                    __builder.AddAttribute(65, "b-m9x6l6rp3k");
                    __builder.AddMarkupContent(66, "<label for=\"username\" b-m9x6l6rp3k>Role</label>\n                ");
                    __builder.OpenElement(67, "select");
                    __builder.AddAttribute$2(68, "name", "");
                    __builder.AddAttribute$2(69, "id", "");
                    __builder.AddAttribute$2(70, "value", $.$mac.Microsoft.AspNetCore.Components.BindConverter.FormatValue(this.role, null));
                    __builder.AddAttribute$5($.$mac.Microsoft.AspNetCore.Components.ChangeEventArgs, 71, "onchange", $.$mac.Microsoft.AspNetCore.Components.EventCallbackFactoryBinderExtensions.CreateBinder($.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory, this, new ($.$spc.System.Action$$($.$spc.System.String))().$ctor(this,  (/*__value*/ __value) =>
                    {
                        return this.role = __value;
                    }, {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1426592,"h":0,"f":1048578}), this.role, null));
                    __builder.SetUpdatesAttributeName("value");
                    __builder.AddAttribute(72, "b-m9x6l6rp3k");
                    __builder.OpenElement(73, "option");
                    __builder.AddAttribute$2(74, "value", "Admin");
                    __builder.AddAttribute(75, "b-m9x6l6rp3k");
                    __builder.AddContent(76, "Admin");
                    __builder.CloseElement();
                    __builder.AddMarkupContent(77, "\n                    ");
                    __builder.OpenElement(78, "option");
                    __builder.AddAttribute$2(79, "value", "User");
                    __builder.AddAttribute(80, "b-m9x6l6rp3k");
                    __builder.AddContent(81, "User");
                    __builder.CloseElement();
                    __builder.CloseElement();
                    __builder.CloseElement();
                    __builder.AddMarkupContent(82, "\n\n            ");
                    __builder.OpenElement(83, "div");
                    __builder.AddAttribute$2(84, "class", "input-container");
                    __builder.AddAttribute(85, "b-m9x6l6rp3k");
                    __builder.AddMarkupContent(86, "<label for=\"username\" b-m9x6l6rp3k>Password</label>\n                ");
                    __builder.OpenElement(87, "input");
                    __builder.AddAttribute$2(88, "type", "password");
                    __builder.AddAttribute$2(89, "placeholder", "enter password...");
                    __builder.AddAttribute$2(90, "value", $.$mac.Microsoft.AspNetCore.Components.BindConverter.FormatValue(this.password, null));
                    __builder.AddAttribute$5($.$mac.Microsoft.AspNetCore.Components.ChangeEventArgs, 91, "onchange", $.$mac.Microsoft.AspNetCore.Components.EventCallbackFactoryBinderExtensions.CreateBinder($.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory, this, new ($.$spc.System.Action$$($.$spc.System.String))().$ctor(this,  (/*__value*/ __value) =>
                    {
                        return this.password = __value;
                    }, {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1426592,"h":0,"f":1048578}), this.password, null));
                    __builder.SetUpdatesAttributeName("value");
                    __builder.AddAttribute(92, "b-m9x6l6rp3k");
                    __builder.CloseElement();
                    __builder.CloseElement();
                    __builder.AddMarkupContent(93, "\n\n            ");
                    __builder.OpenElement(94, "div");
                    __builder.AddAttribute$2(95, "class", "input-container");
                    __builder.AddAttribute(96, "b-m9x6l6rp3k");
                    __builder.AddMarkupContent(97, "<label for=\"username\" b-m9x6l6rp3k>Confirm password</label>\n                ");
                    __builder.OpenElement(98, "input");
                    __builder.AddAttribute$2(99, "type", "password");
                    __builder.AddAttribute$2(100, "placeholder", "enter password...");
                    __builder.AddAttribute$2(101, "value", $.$mac.Microsoft.AspNetCore.Components.BindConverter.FormatValue(this.confirmPassword, null));
                    __builder.AddAttribute$5($.$mac.Microsoft.AspNetCore.Components.ChangeEventArgs, 102, "onchange", $.$mac.Microsoft.AspNetCore.Components.EventCallbackFactoryBinderExtensions.CreateBinder($.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory, this, new ($.$spc.System.Action$$($.$spc.System.String))().$ctor(this,  (/*__value*/ __value) =>
                    {
                        return this.confirmPassword = __value;
                    }, {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1426592,"h":0,"f":1048578}), this.confirmPassword, null));
                    __builder.SetUpdatesAttributeName("value");
                    __builder.AddAttribute(103, "b-m9x6l6rp3k");
                    __builder.CloseElement();
                    __builder.CloseElement();
                    __builder.AddMarkupContent(104, "\n\n            ");
                    __builder.OpenElement(105, "div");
                    __builder.AddAttribute$2(106, "class", "input-container");
                    __builder.AddAttribute(107, "b-m9x6l6rp3k");
                    __builder.OpenElement(108, "button");
                    __builder.AddAttribute$5($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, 109, "onclick", $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$9($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, this, new ($.$spc.System.Func$$($.$spc.System.Threading.Tasks.Task))().$ctor(this, this.SignupUser)));
                    __builder.AddAttribute(110, "b-m9x6l6rp3k");
                    __builder.AddContent(111, "Sign Up");
                    __builder.CloseElement();
                    __builder.CloseElement();
                    if (!this.Auth.IsLoggedIn)
                    {
                        __builder.OpenElement(112, "p");
                        __builder.AddAttribute(113, "b-m9x6l6rp3k");
                        __builder.AddContent(114, this.errorMessage);
                        __builder.CloseElement();
                    }
                    __builder.OpenElement(115, "div");
                    __builder.AddAttribute$2(116, "class", "signup");
                    __builder.AddAttribute(117, "b-m9x6l6rp3k");
                    __builder.AddMarkupContent(118, "<p b-m9x6l6rp3k>Already have an account?</p>\n                ");
                    __builder.OpenComponent($.$t.Taskman.Components.ButtonCard, 119);
                    __builder.AddComponentParameter(120, "BgColor", "rgb(127, 0, 127, 0.3)");
                    __builder.AddComponentParameter(121, "BtnText", "Login");
                    __builder.AddComponentParameter(122, "OnClick", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$mac.Microsoft.AspNetCore.Components.EventCallback, $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$1(this, new $.$spc.System.Action().$ctor(this,  () =>
                    {
                        return this.Nav.NavigateTo$1("", false, false);
                    }, {"r":65537,"n":"","d":1426592,"h":0,"f":1048578}))));
                    __builder.CloseComponent();
                    __builder.CloseElement();
                    __builder.CloseElement();
                    __builder.CloseElement();
                }
            }
            /*string*/ firstname = null;
            /*string*/ lastname = null;
            /*string*/ email = null;
            /*string*/ role = null;
            /*DateTime?*/ dateOfBirth = null;
            /*string*/ username = null;
            /*string*/ password = null;
            /*string*/ confirmPassword = null;
            /*string*/ errorMessage = null;
            /*bool*/ isLoading = true;
            /*List<UserModel>*/ users = null;
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    this.isLoading = true;
                    await $.$spc.System.Threading.Tasks.Task.Delay$4(1000);
                    this.isLoading = false;
                });
            }
            /*void */ OnInitialized()
            {
                if (this.Auth.IsLoggedIn)
                {
                    this.Nav.NavigateTo$1("dashboard", false, false);
                }
            }
            /*Task *//*async*/  OnAfterRenderAsync(/*bool*/ firstRender)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    if (firstRender)
                    {
                        await this.LoadUsers();
                        this.isLoading = false;
                        this.StateHasChanged();
                    }
                });
            }
            /*Task *//*async*/  LoadUsers()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    await this.Auth.LoadUsers();
                });
            }
            /*Task *//*async*/  SignupUser()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    if ($.$spc.System.String.op_Inequality(this.password, this.confirmPassword))
                    {
                        this.errorMessage = "\u26A0\uFE0F Passwords do not match.";
                        return;
                    }
                    /*var*/ let result = await this.Auth.SignUp(this.firstname, this.lastname, this.email, this.role, this.dateOfBirth?.Clone() ?? null, this.username, this.password, this.confirmPassword);
                    if ($.$spc.System.String.op_Equality(result, "Success"))
                    {
                        this.Nav.NavigateTo$1("signupsuccess", false, false);
                    }
                    else 
                    {
                        this.errorMessage = `\u26A0\uFE0F ${result}`;
                    }
                });
            }
            /*Task *//*async*/  SaveUser()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    await this.Auth.SaveUser();
                });
            }
            /*IJSRuntime*/ JS = null;
            /*NavigationManager*/ Nav = null;
            /*Taskman.Services.AuthService*/ Auth = null;
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.firstname = "";
                this.lastname = "";
                this.email = "";
                this.role = "";
                this.dateOfBirth = null;
                this.username = "";
                this.password = "";
                this.confirmPassword = "";
                this.errorMessage = "";
                this.users = new ($.$spc.System.Collections.Generic.List$$($.$t.UserModel))().$ctor$1();
                this.JS = null;
                this.Nav = null;
                this.Auth = null;
            }
            static $h = 1426592;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":524318,"g":{"r":0,"d":0,"h":90195739808,"f":2},"s":{"r":0,"d":0,"h":94490707104,"f":2},"n":"JS","d":1426592,"h":85900772512,"f":2,"a":[{"t":4259848,"c":21479096328}]},{"p":4980744,"g":{"r":0,"d":0,"h":107375608992,"f":2},"s":{"r":0,"d":0,"h":111670576288,"f":2},"n":"Nav","d":1426592,"h":103080641696,"f":2,"a":[{"t":4259848,"c":21479096328}]},{"p":2081952,"g":{"r":0,"d":0,"h":124555478176,"f":2},"s":{"r":0,"d":0,"h":128850445472,"f":2},"n":"Auth","d":1426592,"h":120260510880,"f":2,"a":[{"t":4259848,"c":21479096328}]}],"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","d":1426592,"h":4296393888,"f":32772},{"r":133300225,"n":"OnInitializedAsync","d":1426592,"h":55836001440,"f":36868},{"r":65537,"n":"OnInitialized","d":1426592,"h":60130968736,"f":32772},{"r":133300225,"p":[{"n":"firstRender","p":262145}],"n":"OnAfterRenderAsync","d":1426592,"h":64425936032,"f":36868},{"r":133300225,"n":"LoadUsers","d":1426592,"h":68720903328,"f":4098},{"r":133300225,"n":"SignupUser","d":1426592,"h":73015870624,"f":4098},{"r":133300225,"n":"SaveUser","d":1426592,"h":77310837920,"f":4098}],"l":[{"t":1310721,"n":"firstname","d":1426592,"h":8591361184,"f":2},{"t":1310721,"n":"lastname","d":1426592,"h":12886328480,"f":2},{"t":1310721,"n":"email","d":1426592,"h":17181295776,"f":2},{"t":1310721,"n":"role","d":1426592,"h":21476263072,"f":2},{"t":$.$typeNullable($.$spc.System.DateTime).$h,"n":"dateOfBirth","d":1426592,"h":25771230368,"f":2},{"t":1310721,"n":"username","d":1426592,"h":30066197664,"f":2},{"t":1310721,"n":"password","d":1426592,"h":34361164960,"f":2},{"t":1310721,"n":"confirmPassword","d":1426592,"h":38656132256,"f":2},{"t":1310721,"n":"errorMessage","d":1426592,"h":42951099552,"f":2},{"t":262145,"n":"isLoading","d":1426592,"h":47246066848,"f":2},{"t":$.$spc.System.Collections.Generic.List$$($.$t.UserModel).$h,"n":"users","d":1426592,"h":51541034144,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":1426592,"h":133145412768,"f":1}],"i":[2752520,3145736,3080200],"h":1426592,"a":[{"t":9895944,"c":4304863240,"a":[{"v":"/signup","t":1310721}]}]}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `Taskman.Components.Pages.SignUp`; }
        });
        
        $asm.$cls("$t.Taskman.Components.Pages.Tasks", ($self) => class Tasks extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OpenComponent($.$t.Taskman.Components.NavBar, 0);
                __builder.CloseComponent();
                __builder.AddMarkupContent(1, "\n\n");
                __builder.OpenElement(2, "div");
                __builder.AddAttribute$2(3, "class", "mobile");
                __builder.AddAttribute$2(4, "style", "display: flex; flex-wrap: wrap; margin-bottom: 20px; gap: 5px; justify-content: space-between;");
                __builder.AddAttribute(5, "b-aeb0nnurq8");
                __builder.AddMarkupContent(6, "<h3 style=\"margin-bottom: 30px; margin-top: 20px;\" b-aeb0nnurq8>\uD83D\uDCDD Task Manager </h3>");
                if (this.Auth.IsLoggedIn)
                {
                    if ($.$sl.System.Linq.Enumerable.Any($.$t.AppTask, this.tasks))
                    {
                        __builder.OpenElement(7, "div");
                        __builder.AddAttribute$2(8, "class", "i");
                        __builder.AddAttribute$2(9, "style", "margin-top: 20px;");
                        __builder.AddAttribute(10, "b-aeb0nnurq8");
                        __builder.OpenElement(11, "i");
                        __builder.AddAttribute$2(12, "style", "font-size: 15px; color: white; margin-top: 5px; background: rgb(0, 107, 0, 0.7); padding: 0 30px; margin: 0; border-bottom-right-radius: 20px; border-top-right-radius: 20px; display: flex; align-items: center;");
                        __builder.AddAttribute(13, "b-aeb0nnurq8");
                        __builder.AddContent$5(14, $.$box(this.tasks.Count, $.$spc.System.Int32));
                        __builder.AddContent(15, " task(s) added");
                        __builder.CloseElement();
                        __builder.CloseElement();
                    }
                }
                __builder.CloseElement();
                __builder.AddMarkupContent(16, "\n\n    ");
                __builder.AddMarkupContent(17, "<h5 b-aeb0nnurq8>Priority</h5>\n\n    ");
                __builder.OpenElement(18, "div");
                __builder.AddAttribute$2(19, "style", "display: flex; flex-wrap: wrap; gap: 10px;");
                __builder.AddAttribute(20, "b-aeb0nnurq8");
                __builder.OpenElement(21, "select");
                __builder.AddAttribute(22, "name");
                __builder.AddAttribute(23, "id");
                __builder.AddAttribute$2(24, "class", "opt-btn");
                __builder.AddAttribute$2(25, "style", "padding: 10px; border: none; background: rgb(255, 166, 0, 0.2); width: 50%; border-radius: 10px;");
                __builder.AddAttribute(26, "b-aeb0nnurq8");
                __builder.OpenElement(27, "option");
                __builder.AddAttribute$2(28, "value", "All");
                __builder.AddAttribute(29, "b-aeb0nnurq8");
                __builder.AddContent(30, "All");
                __builder.CloseElement();
                __builder.AddMarkupContent(31, "\n            ");
                __builder.OpenElement(32, "option");
                __builder.AddAttribute$2(33, "value", "Pending");
                __builder.AddAttribute(34, "b-aeb0nnurq8");
                __builder.AddContent(35, "Pending");
                __builder.CloseElement();
                __builder.AddMarkupContent(36, "\n            ");
                __builder.OpenElement(37, "option");
                __builder.AddAttribute$2(38, "value", "Done");
                __builder.AddAttribute(39, "b-aeb0nnurq8");
                __builder.AddContent(40, "Done");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(41, "\n        ");
                __builder.OpenElement(42, "div");
                __builder.AddAttribute$2(43, "class", "opt-btn");
                __builder.AddAttribute(44, "b-aeb0nnurq8");
                __builder.OpenElement(45, "button");
                __builder.AddAttribute$2(46, "class", "btn-hov");
                __builder.AddAttribute$2(47, "style", "padding: 10px; border: none; background: rgb(255, 166, 0, 0.2); border-radius: 10px;");
                __builder.AddAttribute$5($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, 48, "onclick", $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$7($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, this, new $.$spc.System.Action().$ctor(this, this.AllTasks)));
                __builder.AddAttribute(49, "b-aeb0nnurq8");
                __builder.AddContent(50, "All");
                __builder.CloseElement();
                __builder.AddMarkupContent(51, "\n            ");
                __builder.OpenElement(52, "button");
                __builder.AddAttribute$2(53, "class", "btn-hov");
                __builder.AddAttribute$2(54, "style", "padding: 10px; border: none; background: rgb(255, 166, 0, 0.2); border-radius: 10px;");
                __builder.AddAttribute$5($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, 55, "onclick", $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$7($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, this, new $.$spc.System.Action().$ctor(this, this.Pending)));
                __builder.AddAttribute(56, "b-aeb0nnurq8");
                __builder.AddMarkupContent(57, "\u23F3\n                Pending");
                __builder.CloseElement();
                __builder.AddMarkupContent(58, "\n                ");
                __builder.OpenElement(59, "button");
                __builder.AddAttribute$2(60, "class", "btn-hov");
                __builder.AddAttribute$2(61, "style", "padding: 10px; border: none; background: rgb(255, 166, 0, 0.2); border-radius: 10px;");
                __builder.AddAttribute$5($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, 62, "onclick", $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$7($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, this, new $.$spc.System.Action().$ctor(this, this.Completed)));
                __builder.AddAttribute(63, "b-aeb0nnurq8");
                __builder.AddMarkupContent(64, "\u2705\n                    Done");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(65, "\n\n            ");
                __builder.OpenElement(66, "div");
                __builder.AddAttribute$2(67, "style", "display: flex; flex-wrap: wrap; gap: 10px; padding: 30px 0; width: 100%");
                __builder.AddAttribute(68, "b-aeb0nnurq8");
                __builder.OpenElement(69, "div");
                __builder.AddAttribute(70, "style");
                __builder.AddAttribute(71, "b-aeb0nnurq8");
                __builder.AddMarkupContent(72, "<label for=\"title\" b-aeb0nnurq8>Title:</label>\n                    ");
                __builder.OpenElement(73, "input");
                __builder.AddAttribute$2(74, "type", "text");
                __builder.AddAttribute$2(75, "placeholder", "enter task title...");
                __builder.AddAttribute$2(76, "style", "padding: 10px; border: none; background: rgb(255, 166, 0, 0.2); width: 100%; border-radius: 10px;");
                __builder.AddAttribute$2(77, "value", $.$mac.Microsoft.AspNetCore.Components.BindConverter.FormatValue(this.taskTitle, null));
                __builder.AddAttribute$5($.$mac.Microsoft.AspNetCore.Components.ChangeEventArgs, 78, "onchange", $.$mac.Microsoft.AspNetCore.Components.EventCallbackFactoryBinderExtensions.CreateBinder($.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory, this, new ($.$spc.System.Action$$($.$spc.System.String))().$ctor(this,  (/*__value*/ __value) =>
                {
                    return this.taskTitle = __value;
                }, {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1492128,"h":0,"f":1048578}), this.taskTitle, null));
                __builder.SetUpdatesAttributeName("value");
                __builder.AddAttribute(79, "b-aeb0nnurq8");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(80, "\n\n                ");
                __builder.OpenElement(81, "div");
                __builder.AddAttribute$2(82, "class", "input-container");
                __builder.AddAttribute(83, "b-aeb0nnurq8");
                __builder.AddMarkupContent(84, "<label for=\"title\" b-aeb0nnurq8>Priority:</label>\n                    ");
                __builder.OpenElement(85, "select");
                __builder.AddAttribute$2(86, "name", "Priority");
                __builder.AddAttribute$2(87, "id", "");
                __builder.AddAttribute$2(88, "style", "padding: 13px; border: none; background: rgb(255, 166, 0, 0.2); width: 100%; border-radius: 10px;");
                __builder.AddAttribute$6(89, "value", $.$mac.Microsoft.AspNetCore.Components.BindConverter.FormatValue$31($.$t.Priority, this.taskPriority, null));
                __builder.AddAttribute$5($.$mac.Microsoft.AspNetCore.Components.ChangeEventArgs, 90, "onchange", $.$mac.Microsoft.AspNetCore.Components.EventCallbackFactoryBinderExtensions.CreateBinder$62($.$t.Priority, $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory, this, new ($.$spc.System.Action$$($.$t.Priority))().$ctor(this,  (/*__value*/ __value) =>
                {
                    return this.taskPriority = __value;
                }, {"r":65537,"p":[{"n":"__value","p":378016}],"n":"","d":1492128,"h":0,"f":1048578}), this.taskPriority, null));
                __builder.SetUpdatesAttributeName("value");
                __builder.AddAttribute(91, "b-aeb0nnurq8");
                /*var*/ let values = $.$spc.System.Enum.GetValues($.$t.Priority);
                let $i1 = 0;
                let $arr1 = values;
                while ($i1 < $arr1.length)
                {
                    let value = $arr1[$i1++];
                    __builder.OpenElement(92, "option");
                    __builder.AddAttribute$6(93, "value", $.$box(value, $.$t.Priority));
                    __builder.AddAttribute(94, "b-aeb0nnurq8");
                    if (value === 1/*Priority.Low*/)
                    {
                        __builder.AddMarkupContent(95, "\uD83D\uDD34");
                    }
                    else if (value === 2/*Priority.Medium*/)
                    {
                        __builder.AddMarkupContent(96, "\uD83D\uDFE1");
                    }
                    else if (value === 3/*Priority.High*/)
                    {
                        __builder.AddMarkupContent(97, "\uD83D\uDFE2");
                    }
                    __builder.AddContent(98, $.$spc.System.Enum.ToStringT($.$t.Priority, $.$spc.System.UInt32, value));
                    __builder.CloseElement();
                }
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(99, "\n\n            ");
                __builder.OpenElement(100, "div");
                __builder.AddAttribute$2(101, "style", "display: flex; flex-wrap: wrap; gap: 10px; margin-bottom: 50px;");
                __builder.AddAttribute(102, "b-aeb0nnurq8");
                __builder.OpenComponent($.$t.Taskman.Components.ButtonCard, 103);
                __builder.AddComponentParameter(104, "BgColor", "rgb(140, 0, 140, 0.3)");
                __builder.AddComponentParameter(105, "BtnText", "\u2795 AddTask");
                __builder.AddComponentParameter(106, "OnClick", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$mac.Microsoft.AspNetCore.Components.EventCallback, $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$3(this, new ($.$spc.System.Func$$($.$spc.System.Threading.Tasks.Task))().$ctor(this, this.AddTask))));
                __builder.CloseComponent();
                __builder.CloseElement();
                __builder.AddMarkupContent(107, "\n\n            <hr b-aeb0nnurq8>");
                if (!this.Auth.IsLoggedIn)
                {
                    __builder.OpenComponent($.$t.Taskman.Components.NotLoginCard, 108);
                    __builder.AddComponentParameter(109, "Title", "User not logged in...");
                    __builder.AddComponentParameter(110, "SubTitle", "Click to log in...");
                    __builder.CloseComponent();
                }
                else 
                {
                    __builder.OpenElement(111, "div");
                    __builder.AddAttribute$2(112, "style", "display: flex; justify-content: space-between; margin-bottom: 10px;");
                    __builder.AddAttribute(113, "b-aeb0nnurq8");
                    __builder.OpenElement(114, "input");
                    __builder.AddAttribute$2(115, "type", "text");
                    __builder.AddAttribute$2(116, "placeholder", "search task");
                    __builder.AddAttribute$2(117, "value", $.$mac.Microsoft.AspNetCore.Components.BindConverter.FormatValue(this.searchTask, null));
                    __builder.AddAttribute$5($.$mac.Microsoft.AspNetCore.Components.ChangeEventArgs, 118, "oninput", $.$mac.Microsoft.AspNetCore.Components.EventCallbackFactoryBinderExtensions.CreateBinder($.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory, this, new ($.$spc.System.Action$$($.$spc.System.String))().$ctor(this,  (/*__value*/ __value) =>
                    {
                        return this.searchTask = __value;
                    }, {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1492128,"h":0,"f":1048578}), this.searchTask, null));
                    __builder.SetUpdatesAttributeName("value");
                    __builder.AddAttribute(119, "b-aeb0nnurq8");
                    __builder.CloseElement();
                    __builder.CloseElement();
                    if (!$.$spc.System.String.IsNullOrWhiteSpace(this.searchTask) && !$.$sl.System.Linq.Enumerable.Any($.$t.AppTask, this.FilteredItems))
                    {
                        __builder.AddMarkupContent(120, "<p style=\"margin:10px 0; color: red;\" b-aeb0nnurq8>\uD83D\uDD0D No task(s) found.</p>");
                    }
                    __builder.OpenElement(121, "div");
                    __builder.AddAttribute$2(122, "style", "display: flex; flex-wrap: wrap; justify-content: space-between; padding-top: 10px; margin-top: 40px;");
                    __builder.AddAttribute(123, "b-aeb0nnurq8");
                    __builder.AddMarkupContent(124, "<h4 b-aeb0nnurq8>\uD83D\uDCC1 Available Task</h4>");
                    if (this.confirmClear)
                    {
                        __builder.OpenElement(125, "div");
                        __builder.AddAttribute(126, "b-aeb0nnurq8");
                        __builder.OpenComponent($.$t.Taskman.Components.Confirm, 127);
                        __builder.AddComponentParameter(128, "Title", "Sure to clear all tasks?");
                        __builder.AddComponentParameter(129, "Text1", "\u2705 Clear");
                        __builder.AddComponentParameter(130, "Text2", "\u274C Cancel");
                        __builder.AddComponentParameter(131, "ConfirmBtn", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$mac.Microsoft.AspNetCore.Components.EventCallback, $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$3(this, new ($.$spc.System.Func$$($.$spc.System.Threading.Tasks.Task))().$ctor(this, this.ClearTask))));
                        __builder.AddComponentParameter(132, "CancelBtn", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$mac.Microsoft.AspNetCore.Components.EventCallback, $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$1(this, new $.$spc.System.Action().$ctor(this,  () =>
                        {
                            return this.confirmClear = false;
                        }, {"r":65537,"n":"","d":1492128,"h":0,"f":1048578}))));
                        __builder.CloseComponent();
                        __builder.CloseElement();
                    }
                    else 
                    {
                        __builder.OpenComponent($.$t.Taskman.Components.ButtonCard, 133);
                        __builder.AddComponentParameter(134, "BgColor", "rgb(140, 0, 140, 0.3)");
                        __builder.AddComponentParameter(135, "BtnText", "\uD83E\uDDF9 Clear All Tasks");
                        __builder.AddComponentParameter(136, "OnClick", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$mac.Microsoft.AspNetCore.Components.EventCallback, $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$1(this, new $.$spc.System.Action().$ctor(this,  () =>
                        {
                            return this.confirmClear = true;
                        }, {"r":65537,"n":"","d":1492128,"h":0,"f":1048578}))));
                        __builder.CloseComponent();
                    }
                    __builder.CloseElement();
                    if ($.$sl.System.Linq.Enumerable.Any($.$t.AppTask, this.tasks))
                    {
                        if (this.isLoading)
                        {
                            __builder.OpenComponent($.$t.Taskman.Components.LoadingCardMinor, 137);
                            __builder.AddComponentParameter(138, "LoadingState", "\u23F3 Loading Available Tasks...");
                            __builder.CloseComponent();
                        }
                        else 
                        {
                            __builder.OpenElement(139, "div");
                            __builder.AddAttribute$2(140, "style", "background: rgba(228, 228, 228, 0.1); max-height: 700px; overflow: scroll;");
                            __builder.AddAttribute(141, "b-aeb0nnurq8");
                            __builder.OpenElement(142, "ul");
                            __builder.AddAttribute$2(143, "style", "margin: 20px 0px 40px;");
                            __builder.AddAttribute(144, "b-aeb0nnurq8");
                            var $en5 = this.FilteredItems.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                            while ($en5.System$Collections$IEnumerator$MoveNext())
                            {
                                var task = $en5.System$Collections$Generic$IEnumerator$$$Current;
                                {
                                    if (this.activeNotifyTaskId === task.Id)
                                    {
                                        __builder.OpenComponent($.$t.Taskman.Components.Confirm, 145);
                                        __builder.AddComponentParameter(146, "Title", "Confirm to complete this task.");
                                        __builder.AddComponentParameter(147, "Text1", "\u2705 Confirm");
                                        __builder.AddComponentParameter(148, "Text2", "\u274C Cancel");
                                        __builder.AddComponentParameter(149, "ConfirmBtn", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$mac.Microsoft.AspNetCore.Components.EventCallback, $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$3(this, new ($.$spc.System.Func$$($.$spc.System.Threading.Tasks.Task))().$ctor(this,  () =>
                                        {
                                            return this.CompleteTask(task.Id);
                                        }, {"r":133300225,"n":"","d":1492128,"h":0,"f":1048578}))));
                                        __builder.AddComponentParameter(150, "CancelBtn", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$mac.Microsoft.AspNetCore.Components.EventCallback, $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$1(this, new $.$spc.System.Action().$ctor(this,  () =>
                                        {
                                            return this.activeNotifyTaskId = null;
                                        }, {"r":65537,"n":"","d":1492128,"h":0,"f":1048578}))));
                                        __builder.CloseComponent();
                                    }
                                    else if (task.IsComplete)
                                    {
                                        __builder.OpenElement(151, "li");
                                        __builder.AddAttribute$2(152, "class", task.IsComplete ? "disabled-container" : "");
                                        __builder.AddAttribute$2(153, "style", "margin: 10px 0; padding: 7px; list-style: none; border-left: 3px solid purple; text-decoration: line-through; background: rgb(129, 129, 129, 0.1);");
                                        __builder.AddAttribute(154, "b-aeb0nnurq8");
                                        __builder.OpenComponent($.$t.Taskman.Components.TaskCard, 155);
                                        __builder.AddComponentParameter(156, "Task", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$t.AppTask, task));
                                        __builder.AddComponentParameter(157, "TaskIdToDelete", $.$box($.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$typeNullable($.$spc.System.Int32), this.taskIdToDelete), $.$spc.System.Nullable$$($.$spc.System.Int32)));
                                        __builder.AddComponentParameter(158, "OnRequestDelete", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$mac.Microsoft.AspNetCore.Components.EventCallback$$($.$spc.System.Int32), $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$8($.$spc.System.Int32, this, new ($.$spc.System.Action$$($.$spc.System.Int32))().$ctor(this, this.ShowDeleteConfirmation))));
                                        __builder.AddComponentParameter(159, "OnDelete", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$mac.Microsoft.AspNetCore.Components.EventCallback$$($.$spc.System.Int32), $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$10($.$spc.System.Int32, this, new ($.$spc.System.Func$$$($.$spc.System.Int32, $.$spc.System.Threading.Tasks.Task))().$ctor(this, this.DeleteTask))));
                                        __builder.AddComponentParameter(160, "OnToggle", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$mac.Microsoft.AspNetCore.Components.EventCallback$$($.$spc.System.Int32), $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$10($.$spc.System.Int32, this, new ($.$spc.System.Func$$$($.$spc.System.Int32, $.$spc.System.Threading.Tasks.Task))().$ctor(this, this.ToggleTask))));
                                        __builder.CloseComponent();
                                        __builder.CloseElement();
                                    }
                                    else 
                                    {
                                        __builder.OpenElement(161, "li");
                                        __builder.AddAttribute$2(162, "class", "slide-from-top");
                                        __builder.AddAttribute$2(163, "style", "margin: 10px 0; padding: 7px; list-style: none; border-left: 3px solid purple; background: rgb(129, 129, 129, 0.1);");
                                        __builder.AddAttribute(164, "b-aeb0nnurq8");
                                        __builder.OpenComponent($.$t.Taskman.Components.TaskCard, 165);
                                        __builder.AddComponentParameter(166, "Task", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$t.AppTask, task));
                                        __builder.AddComponentParameter(167, "TaskIdToDelete", $.$box($.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$typeNullable($.$spc.System.Int32), this.taskIdToDelete), $.$spc.System.Nullable$$($.$spc.System.Int32)));
                                        __builder.AddComponentParameter(168, "OnRequestDelete", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$mac.Microsoft.AspNetCore.Components.EventCallback$$($.$spc.System.Int32), $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$8($.$spc.System.Int32, this, new ($.$spc.System.Action$$($.$spc.System.Int32))().$ctor(this, this.ShowDeleteConfirmation))));
                                        __builder.AddComponentParameter(169, "OnDelete", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$mac.Microsoft.AspNetCore.Components.EventCallback$$($.$spc.System.Int32), $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$10($.$spc.System.Int32, this, new ($.$spc.System.Func$$$($.$spc.System.Int32, $.$spc.System.Threading.Tasks.Task))().$ctor(this, this.DeleteTask))));
                                        __builder.AddComponentParameter(170, "OnToggle", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$mac.Microsoft.AspNetCore.Components.EventCallback$$($.$spc.System.Int32), $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$10($.$spc.System.Int32, this, new ($.$spc.System.Func$$$($.$spc.System.Int32, $.$spc.System.Threading.Tasks.Task))().$ctor(this, this.ToggleTask))));
                                        __builder.CloseComponent();
                                        __builder.CloseElement();
                                    }
                                }
                            }
                            __builder.CloseElement();
                            __builder.CloseElement();
                        }
                    }
                    else 
                    {
                        if (!this.isLoading)
                        {
                            __builder.AddMarkupContent(171, "<div style=\"display: flex; width: 100%; height: 100%; background: rgb(137, 137, 137, 0.1); margin: 20px 0 30px; height: 50vh; align-items: center; justify-content: center;\" b-aeb0nnurq8><b b-aeb0nnurq8>\uD83D\uDCC1 No tasks added.</b></div>");
                        }
                        else 
                        {
                            __builder.OpenElement(172, "div");
                            __builder.AddAttribute$2(173, "style", "margin-bottom: 60px;");
                            __builder.AddAttribute(174, "b-aeb0nnurq8");
                            __builder.OpenComponent($.$t.Taskman.Components.LoadingCardMinor, 175);
                            __builder.AddComponentParameter(176, "LoadingState", "\u23F3 Loading Available Tasks...");
                            __builder.CloseComponent();
                            __builder.CloseElement();
                        }
                    }
                }
                if (this.taskIdToDelete !== null)
                {
                    __builder.OpenComponent($.$t.Taskman.Components.Confirm, 177);
                    __builder.AddComponentParameter(178, "Title", "Sure to delete this task?");
                    __builder.AddComponentParameter(179, "Text1", "\u2705 Delete");
                    __builder.AddComponentParameter(180, "Text2", "\u274C Cancel");
                    __builder.AddComponentParameter(181, "ConfirmBtn", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$mac.Microsoft.AspNetCore.Components.EventCallback, $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$3(this, new ($.$spc.System.Func$$($.$spc.System.Threading.Tasks.Task))().$ctor(this,  () =>
                    {
                        return this.DeleteTask($.$spc.System.Nullable$$($.$spc.System.Int32).Value$get.call(this.taskIdToDelete));
                    }, {"r":133300225,"n":"","d":1492128,"h":0,"f":1048578}))));
                    __builder.AddComponentParameter(182, "CancelBtn", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$mac.Microsoft.AspNetCore.Components.EventCallback, $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$1(this, new $.$spc.System.Action().$ctor(this,  () =>
                    {
                        return this.taskIdToDelete = null;
                    }, {"r":65537,"n":"","d":1492128,"h":0,"f":1048578}))));
                    __builder.CloseComponent();
                }
            }
            /*string*/ taskTitle = null;
            /*string*/ searchTask = null;
            /*bool*/ isLoading = false;
            /*int?*/ taskIdToDelete = null;
            /*Priority*/ taskPriority = 0;
            /*string */ get trimmedTaskTitle()
            {
                return $.$spc.System.String.ToUpper.call($.$spc.System.String.Trim.call(this.taskTitle));
            }
            /*List<AppTask>*/ tasks = null;
            /*List<AppTask>*/ completedTasks = null;
            /*bool*/ confirmClear = false;
            /*AppTask*/ Taskss = null;
            /*string*/ currentFilter = null;
            /*bool*/ IsDisabled = false;
            /*int?*/ activeNotifyTaskId = null;
            /*void */ ShowDeleteDialog(/*int*/ id)
            {
                this.taskIdToDelete = id;
            }
            /*void */ HideDeleteDialog()
            {
                this.taskIdToDelete = -1;
            }
            /*Task *//*async*/  DeleteSelectedTask()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    if ($.$spc.System.Nullable$$($.$spc.System.Int32).HasValue$get.call(this.taskIdToDelete))
                    {
                        await this.DeleteTask($.$spc.System.Nullable$$($.$spc.System.Int32).Value$get.call(this.taskIdToDelete));
                        this.taskIdToDelete = null;
                    }
                });
            }
            /*Task *//*async*/  CompleteTask(/*int*/ id)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    await this.TaskService.ITaskService$ToggleCompleted(id);
                    this.RefreshTasks();
                    this.activeNotifyTaskId = null;
                });
            }
            /*void */ ShowDeleteConfirmation(/*int*/ id)
            {
                this.taskIdToDelete = id;
            }
            /*IEnumerable<AppTask> */ get FilteredItems()
            {
                /*var*/ let allTasks = this.tasks;
                /*var*/ let statusFiltered = (() =>
                {
                    if (this.currentFilter === "Pending")
                    {
                        return $.$sl.System.Linq.Enumerable.Where($.$t.AppTask, allTasks, new ($.$spc.System.Func$$$($.$t.AppTask, $.$spc.System.Boolean))().$ctor(this,  (/*t*/ t) =>
                        {
                            return !t.IsComplete;
                        }, {"r":262145,"p":[{"n":"t","p":115872}],"n":"","d":1492128,"h":0,"f":1048578}));
                    }
                    if (this.currentFilter === "Done")
                    {
                        return $.$sl.System.Linq.Enumerable.Where($.$t.AppTask, allTasks, new ($.$spc.System.Func$$$($.$t.AppTask, $.$spc.System.Boolean))().$ctor(this,  (/*t*/ t) =>
                        {
                            return t.IsComplete;
                        }, {"r":262145,"p":[{"n":"t","p":115872}],"n":"","d":1492128,"h":0,"f":1048578}));
                    }
                    return allTasks;
                })();
                if (!$.$spc.System.String.IsNullOrWhiteSpace(this.searchTask))
                {
                    statusFiltered = $.$sl.System.Linq.Enumerable.Where($.$t.AppTask, statusFiltered, new ($.$spc.System.Func$$$($.$t.AppTask, $.$spc.System.Boolean))().$ctor(this,  (/*t*/ t) =>
                    {
                        return $.$spc.System.String.op_Inequality(t.Title, null) && $.$spc.System.String.Contains$1.call(t.Title, this.searchTask, 5/*StringComparison.OrdinalIgnoreCase*/);
                    }, {"r":262145,"p":[{"n":"t","p":115872}],"n":"","d":1492128,"h":0,"f":1048578}));
                }
                return statusFiltered;
            }
            /*Task */ OnInitializedAsync()
            {
                this.isLoading = true;
                return $.$spc.System.Threading.Tasks.Task.CompletedTask;
            }
            /*bool*/ _loaded = false;
            /*Task *//*async*/  OnAfterRenderAsync(/*bool*/ firstRender)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    if (firstRender && !this._loaded)
                    {
                        this._loaded = true;
                        await this.TaskService.ITaskService$LoadTasks();
                        this.RefreshTasks();
                        this.isLoading = false;
                        this.StateHasChanged();
                    }
                });
            }
            /*void */ OnInitialized()
            {
                this.TaskService.ITaskService$add_OnChange(new $.$spc.System.Action().$ctor(this, this.HandleStateChanged));
            }
            /*Task *//*async*/  AddTask()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    if ($.$spc.System.String.IsNullOrEmpty(this.taskTitle) || this.taskPriority === 0/*Priority.Select_Priority*/)
                    {
                        return;
                    }
                    this.TaskService.ITaskService$Add(this.trimmedTaskTitle, this.taskPriority);
                    this.taskIdToDelete = null;
                    this.taskTitle = "";
                    this.taskPriority = 0/*Priority.Select_Priority*/;
                    this.RefreshTasks();
                    if (this.Auth.IsLoggedIn)
                    {
                        await this.SaveTask();
                    }
                });
            }
            /*Task *//*async*/  EditTask(/*int*/ id)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    if ($.$spc.System.String.IsNullOrEmpty(this.taskTitle) || this.taskPriority === 0/*Priority.Select_Priority*/)
                    {
                        return;
                    }
                    this.TaskService.ITaskService$Edit(id, this.trimmedTaskTitle, this.taskPriority);
                    this.taskTitle = "";
                    this.taskPriority = 0/*Priority.Select_Priority*/;
                    this.RefreshTasks();
                    if (this.Auth.IsLoggedIn)
                    {
                        await this.SaveTask();
                    }
                });
            }
            /*Task *//*async*/  MoveCompletedTask()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    this.TaskService.ITaskService$MoveTask(this.trimmedTaskTitle, this.taskPriority);
                    this.RefreshTasks();
                    if (this.Auth.IsLoggedIn)
                    {
                        await this.SaveTask();
                    }
                });
            }
            /*void */ AllTasks()
            {
                this.currentFilter = "All";
            }
            /*void */ Pending()
            {
                this.currentFilter = "Pending";
            }
            /*void */ Completed()
            {
                this.currentFilter = "Done";
            }
            /*Task */ ToggleTask(/*int*/ id)
            {
                $.$scsl.System.Console.WriteLine$13(`Clicked Task: ${id}`);
                this.activeNotifyTaskId = id;
                this.IsDisabled = true;
                this.StateHasChanged();
                return $.$spc.System.Threading.Tasks.Task.CompletedTask;
            }
            /*Task *//*async*/  DeleteTask(/*int*/ id)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    this.TaskService.ITaskService$Delete(id);
                    this.taskIdToDelete = null;
                    this.taskIdToDelete = null;
                    this.RefreshTasks();
                    if (this.Auth.IsLoggedIn)
                    {
                        await this.SaveTask();
                    }
                });
            }
            /*Task *//*async*/  ClearTask()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    this.TaskService.ITaskService$ClearAllTask();
                    this.confirmClear = false;
                    if (this.Auth.IsLoggedIn)
                    {
                        await this.SaveTask();
                        await this.TaskService.ITaskService$LoadTasks();
                    }
                });
            }
            /*Task *//*async*/  SaveTask()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    await this.TaskService.ITaskService$SaveTask();
                });
            }
            /*void */ RefreshTasks()
            {
                this.tasks = this.TaskService.ITaskService$GetAll();
                this.StateHasChanged();
            }
            /*void */ HandleStateChanged()
            {
                this.RefreshTasks();
                this.InvokeAsync(new $.$spc.System.Action().$ctor(this, this.StateHasChanged));
            }
            /*void */ Dispose()
            {
                this.TaskService.ITaskService$remove_OnChange(new $.$spc.System.Action().$ctor(this, this.HandleStateChanged));
            }
            /*IJSRuntime*/ JS = null;
            /*NavigationManager*/ Nav = null;
            /*ITaskService*/ TaskService = null;
            /*Taskman.Services.AuthService*/ Auth = null;
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.taskTitle = "";
                this.searchTask = "";
                this.isLoading = false;
                this.tasks = new ($.$spc.System.Collections.Generic.List$$($.$t.AppTask))().$ctor$1();
                this.completedTasks = new ($.$spc.System.Collections.Generic.List$$($.$t.AppTask))().$ctor$1();
                this.Taskss = new $.$t.AppTask().$ctor$1();
                this.currentFilter = "All";
                this.JS = null;
                this.Nav = null;
                this.TaskService = null;
                this.Auth = null;
            }
            static $h = 1492128;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":262145,"g":{"r":0,"d":0,"h":25771295904,"f":2},"s":{"r":0,"d":0,"h":30066263200,"f":2},"n":"isLoading","d":1492128,"h":21476328608,"f":2},{"p":1310721,"g":{"r":0,"d":0,"h":47246132384,"f":2},"n":"trimmedTaskTitle","d":1492128,"h":42951165088,"f":2},{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$t.AppTask).$h,"g":{"r":0,"d":0,"h":107375674528,"f":2},"n":"FilteredItems","d":1492128,"h":103080707232,"f":2},{"p":524318,"g":{"r":0,"d":0,"h":193275020448,"f":2},"s":{"r":0,"d":0,"h":197569987744,"f":2},"n":"JS","d":1492128,"h":188980053152,"f":2,"a":[{"t":4259848,"c":21479096328}]},{"p":4980744,"g":{"r":0,"d":0,"h":210454889632,"f":2},"s":{"r":0,"d":0,"h":214749856928,"f":2},"n":"Nav","d":1492128,"h":206159922336,"f":2,"a":[{"t":4259848,"c":21479096328}]},{"p":181408,"g":{"r":0,"d":0,"h":227634758816,"f":2},"s":{"r":0,"d":0,"h":231929726112,"f":2},"n":"TaskService","d":1492128,"h":223339791520,"f":2,"a":[{"t":4259848,"c":21479096328}]},{"p":2081952,"g":{"r":0,"d":0,"h":244814628000,"f":2},"s":{"r":0,"d":0,"h":249109595296,"f":2},"n":"Auth","d":1492128,"h":240519660704,"f":2,"a":[{"t":4259848,"c":21479096328}]}],"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","d":1492128,"h":4296459424,"f":32772},{"r":65537,"p":[{"n":"id","p":655361}],"n":"ShowDeleteDialog","d":1492128,"h":81605870752,"f":2},{"r":65537,"n":"HideDeleteDialog","d":1492128,"h":85900838048,"f":2},{"r":133300225,"n":"DeleteSelectedTask","d":1492128,"h":90195805344,"f":4098},{"r":133300225,"p":[{"n":"id","p":655361}],"n":"CompleteTask","d":1492128,"h":94490772640,"f":4098},{"r":65537,"p":[{"n":"id","p":655361}],"n":"ShowDeleteConfirmation","d":1492128,"h":98785739936,"f":2},{"r":133300225,"n":"OnInitializedAsync","d":1492128,"h":111670641824,"f":32772},{"r":133300225,"p":[{"n":"firstRender","p":262145}],"n":"OnAfterRenderAsync","d":1492128,"h":120260576416,"f":36868},{"r":65537,"n":"OnInitialized","d":1492128,"h":124555543712,"f":32772},{"r":133300225,"n":"AddTask","d":1492128,"h":128850511008,"f":4098},{"r":133300225,"p":[{"n":"id","p":655361}],"n":"EditTask","d":1492128,"h":133145478304,"f":4098},{"r":133300225,"n":"MoveCompletedTask","d":1492128,"h":137440445600,"f":4098},{"r":65537,"n":"AllTasks","d":1492128,"h":141735412896,"f":2},{"r":65537,"n":"Pending","d":1492128,"h":146030380192,"f":2},{"r":65537,"n":"Completed","d":1492128,"h":150325347488,"f":2},{"r":133300225,"p":[{"n":"id","p":655361}],"n":"ToggleTask","d":1492128,"h":154620314784,"f":2},{"r":133300225,"p":[{"n":"id","p":655361}],"n":"DeleteTask","d":1492128,"h":158915282080,"f":4098},{"r":133300225,"n":"ClearTask","d":1492128,"h":163210249376,"f":4098},{"r":133300225,"n":"SaveTask","d":1492128,"h":167505216672,"f":4098},{"r":65537,"n":"RefreshTasks","d":1492128,"h":171800183968,"f":2},{"r":65537,"n":"HandleStateChanged","d":1492128,"h":176095151264,"f":2},{"r":65537,"n":"Dispose","d":1492128,"h":180390118560,"f":1}],"l":[{"t":1310721,"n":"taskTitle","d":1492128,"h":8591426720,"f":2},{"t":1310721,"n":"searchTask","d":1492128,"h":12886394016,"f":2},{"t":$.$typeNullable($.$spc.System.Int32).$h,"n":"taskIdToDelete","d":1492128,"h":34361230496,"f":2},{"t":378016,"n":"taskPriority","d":1492128,"h":38656197792,"f":2},{"t":$.$spc.System.Collections.Generic.List$$($.$t.AppTask).$h,"n":"tasks","d":1492128,"h":51541099680,"f":1},{"t":$.$spc.System.Collections.Generic.List$$($.$t.AppTask).$h,"n":"completedTasks","d":1492128,"h":55836066976,"f":1},{"t":262145,"n":"confirmClear","d":1492128,"h":60131034272,"f":1},{"t":115872,"n":"Taskss","d":1492128,"h":64426001568,"f":2},{"t":1310721,"n":"currentFilter","d":1492128,"h":68720968864,"f":2},{"t":262145,"n":"IsDisabled","d":1492128,"h":73015936160,"f":2},{"t":$.$typeNullable($.$spc.System.Int32).$h,"n":"activeNotifyTaskId","d":1492128,"h":77310903456,"f":2},{"t":262145,"n":"_loaded","d":1492128,"h":115965609120,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":1492128,"h":253404562592,"f":1}],"i":[2752520,3145736,3080200,57540609],"h":1492128,"a":[{"t":9895944,"c":4304863240,"a":[{"v":"/tasks","t":1310721}]}]}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender, $.$spc.System.IDisposable ]; }
            static get $fullName() { return `Taskman.Components.Pages.Tasks`; }
        });
        
        $asm.$cls("$t.Taskman.Layout.MainLayout", ($self) => class MainLayout extends $.$mac.Microsoft.AspNetCore.Components.LayoutComponentBase
        {
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$2(1, "class", "page");
                __builder.AddAttribute(2, "b-9e607fbywf");
                __builder.OpenElement(3, "main");
                __builder.AddAttribute(4, "b-9e607fbywf");
                __builder.OpenElement(5, "article");
                __builder.AddAttribute$2(6, "class", "content");
                __builder.AddAttribute$2(7, "style", "padding: 10px;");
                __builder.AddAttribute(8, "b-9e607fbywf");
                __builder.AddContent$1(9, this.Body);
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(10, "\n\n");
                __builder.AddMarkupContent(11, "<div id=\"blazor-error-ui\" data-nosnippet b-9e607fbywf>\n    An unhandled error has occurred.\n    <a href=\".\" class=\"reload\" b-9e607fbywf>Reload</a>\n    <span class=\"dismiss\" b-9e607fbywf>\uD83D\uDDD9</span></div>");
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 1885344;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":4653064,"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","d":1885344,"h":4296852640,"f":32772}],"c":[{"n":".ctor","o":"$ctor$3","d":1885344,"h":8591819936,"f":1}],"i":[2752520,3145736,3080200],"h":1885344}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.LayoutComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `Taskman.Layout.MainLayout`; }
        });
        
        $asm.$str("$t.Priority", ($self) => class Priority extends $.$spc.System.Enum
        {
            static Select_Priority = 0;
            static Low = 1;
            static Medium = 2;
            static High = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Select_Priority": 0n,
                    "Low": 1n,
                    "Medium": 2n,
                    "High": 3n
                };
            }
            static $h = 378016;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":378016,"n":"Select_Priority","d":378016,"h":4295345312,"f":33},{"t":378016,"n":"Low","d":378016,"h":8590312608,"f":33},{"t":378016,"n":"Medium","d":378016,"h":12885279904,"f":33},{"t":378016,"n":"High","d":378016,"h":17180247200,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":378016,"h":21475214496,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":378016}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `Priority`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.Extensions.Validation", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.Logging", "NetJs.Microsoft.JSInterop.WebAssembly", "NetJs.Microsoft.AspNetCore.Components.WebAssembly", "NetJs.Microsoft.CSharp", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument"))