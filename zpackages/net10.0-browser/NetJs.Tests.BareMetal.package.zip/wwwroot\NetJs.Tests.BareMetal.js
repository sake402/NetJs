
(function ($global, $, $spc, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sri, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mam, $mep, $meca, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mxdi, $sca, $meo, $meda, $meoc, $mxdg, $mela, $maa, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sipl, $stew, $stj, $mac, $mev, $srsp, $macf, $med, $mj, $macw, $mc, $sifw, $slq, $snhj, $stec, $swh, $sxx, $sxxx) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Tests.BareMetal", 
    {"g":1,"h":36679,"f":"Tests.BareMetal","v":"1.0.0.0","a":[{"t":73596929,"c":4368564225,"a":[{"v":"NetJs.Tests.BareMetal","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.0.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.0\u002Bf7a34a6f78fee11131301a9f55ca16a968616013","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.Tests.BareMetal","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.Tests.BareMetal","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.0.0","t":1310721}]},{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$tb.NetJs.Tests.Baremetal.Program", ($self) => class Program
        {
            static /*string */ A(/*this string*/ a)
            {
                return a;
            }
            static /*string */ B(/*this string*/ b)
            {
                return b;
            }
            static /*string */ C(/*this string*/ b)
            {
                return b;
            }
            static /*string */ D(/*this string*/ b)
            {
                return b;
            }
            static /*string */ E(/*this string*/ b)
            {
                return b;
            }
            static /*Task *//*async*/  Main()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    /*string*/ let __ca1__;
                    /*string*/ let __ca2__;
                    /*string*/ let __ca3__;
                    /*string*/ let __ca4__;
                    /*string*/ let __ca5__;
                    /*string*/ let __ca6__;
                    /*string*/ let __ca7__;
                    /*var*/ let len = ($.$spc.System.String.op_Inequality((__ca1__ = $.$tb.NetJs.Tests.Baremetal.Program.A("")), null) ? ($.$spc.System.String.op_Inequality((__ca2__ = $.$tb.NetJs.Tests.Baremetal.Program.B(__ca1__)), null) ? ($.$spc.System.String.op_Inequality((__ca3__ = $.$tb.NetJs.Tests.Baremetal.Program.D($.$spc.System.String.Trim.call($.$tb.NetJs.Tests.Baremetal.Program.C(__ca2__)))), null) ? ($.$spc.System.String.op_Inequality((__ca4__ = $.$tb.NetJs.Tests.Baremetal.Program.A($.$spc.System.Int32.ToString.call($.$tb.NetJs.Tests.Baremetal.Program.E(__ca3__).length))), null) ? ($.$spc.System.String.op_Inequality((__ca5__ = $.$tb.NetJs.Tests.Baremetal.Program.B(__ca4__)), null) ? ($.$spc.System.String.op_Inequality((__ca6__ = $.$tb.NetJs.Tests.Baremetal.Program.C(__ca5__)), null) ? ($.$spc.System.String.op_Inequality((__ca7__ = $.$tb.NetJs.Tests.Baremetal.Program.D(__ca6__)), null) ? $.$tb.NetJs.Tests.Baremetal.Program.E(__ca7__) : null) : null) : null) : null) : null) : null) : null);
                    /*int*/ let i = 0;
                    while(true)
                    {
                        await $.$spc.System.Threading.Tasks.Task.Delay$4(1000);
                        $.$scsl.System.Console.WriteLine$13(`${$.$spc.System.DateTime.ToString.call($.$spc.System.DateTime.Now)}: Hello World ${i++} again, ${$.$spc.System.Random.Shared.Next()}, ${$.$spc.System.Guid.ToString.call($.$spc.System.Guid.NewGuid())}`);
                    }
                });
            }
            static $h = 233287;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1310721,"p":[{"n":"a","p":1310721}],"n":"A","d":233287,"h":4295200583,"f":33},{"r":1310721,"p":[{"n":"b","p":1310721}],"n":"B","d":233287,"h":8590167879,"f":33},{"r":1310721,"p":[{"n":"b","p":1310721}],"n":"C","d":233287,"h":12885135175,"f":33},{"r":1310721,"p":[{"n":"b","p":1310721}],"n":"D","d":233287,"h":17180102471,"f":33},{"r":1310721,"p":[{"n":"b","p":1310721}],"n":"E","d":233287,"h":21475069767,"f":33},{"r":133300225,"n":"Main","d":233287,"h":25770037063,"f":4129}],"h":233287}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `NetJs.Tests.Baremetal.Program`; }
        });
        
        $asm.$cls("$tb.Microsoft.CodeAnalysis.EmbeddedAttribute", ($self) => class EmbeddedAttribute extends $.$spc.System.Attribute
        {
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 102215;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14548993,"c":[{"n":".ctor","o":"$ctor$2","d":102215,"h":4295069511,"f":1}],"h":102215}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
        });
        
        $asm.$cls("$tb.Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute", ($self) => class ValidatableTypeAttribute extends $.$spc.System.Attribute
        {
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 167751;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14548993,"c":[{"n":".ctor","o":"$ctor$2","d":167751,"h":4295135047,"f":1}],"h":167751,"a":[{"t":102215,"c":4295069511},{"t":14680065,"c":21489516545,"a":[{"v":4,"t":14614529}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.Extensions.Validation", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.CSharp", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument"))