
//--TRIMMABLE-BOUNDARY-START(56403)
(function ($global, $, $$, $spu, $sr, $scm, $sc, $sm, $snv, $sdt, $st, $scc, $sris, $sri, $sl, $so, $sci, $sic, $stt, $sim, $stee, $srm, $sre, $srei, $srel, $srp, $sle, $mxdi, $mep, $meca, $mec, $scn, $scp, $scs, $sdp, $mwp, $scsl, $sttp, $sdd, $sds, $srn, $sfa, $snp, $ssc, $sspw, $sto, $snnr, $sns, $sscr, $snsc, $srw, $srl, $srsf, $str, $sdts, $sicb, $snn, $stc, $snq, $srij, $snh, $spx, $spxl, $sxxd, $sct, $sca, $meo, $meda, $mecb, $meoc, $mxdg, $mexla, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $stew, $sipl, $stj, $mac, $mev, $srsp, $macf, $med, $mj, $macw, $mefa, $mef, $sifw, $mefp, $mecf, $mecj, $mexl, $mjw, $macwa, $mc, $slq, $snhj) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Tests.RCL", 
    {
  "h": 56403,
  "f": "Tests.RCL",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 159186945,
      "c": 13044088833,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106364929,
      "c": 4401332225,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106430465,
      "c": 4401397761,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106889217,
      "c": 4401856513,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107020289,
      "c": 4401987585,
      "a": [
        {
          "v": "1.0.35\u002Bdf6f45b09d58f65c84d384efc8772929a0c6464b",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107872257,
      "c": 4402839553,
      "a": [
        {
          "v": "NetJs.Tests.RCL",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108003329,
      "c": 4402970625,
      "a": [
        {
          "v": "NetJs.Tests.RCL",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108134401,
      "c": 4403101697,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159252481,
      "c": 4454219777,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 158990337,
      "c": 4453957633,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(253011)
        $asm.$cls("$tr.NetJs.Tests.RCL._Imports", ($self) => class _Imports extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590187603)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590187603);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590187603)
            
            //--TRIMMABLE-BOUNDARY-START(4295220307)
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295220307)
            
            static $h = 253011;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590187603),
    {
      "r": 65537,
      "n": "Execute",
      "d": 253011,
      "h": 8590187603,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590187603)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295220307),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 253011,
      "h": 4295220307,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295220307)
  ],
  "h": 253011
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `NetJs.Tests.RCL._Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(253011)
        
        
        //--TRIMMABLE-BOUNDARY-START(187475)
        $asm.$cls("$tr.Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute", ($self) => class ValidatableTypeAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295154771)
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295154771)
            
            static $h = 187475;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45285377,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295154771),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 187475,
      "h": 4295154771,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295154771)
  ],
  "h": 187475,
  "a": [
    {
      "t": 121939,
      "c": 4295089235
    },
    {
      "t": 45416449,
      "c": 21520252929,
      "a": [
        {
          "v": 4,
          "t": 45350913
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(187475)
        
        
        //--TRIMMABLE-BOUNDARY-START(121939)
        $asm.$cls("$tr.Microsoft.CodeAnalysis.EmbeddedAttribute", ($self) => class EmbeddedAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295089235)
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295089235)
            
            static $h = 121939;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45285377,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295089235),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 121939,
      "h": 4295089235,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295089235)
  ],
  "h": 121939
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(121939)
        
        
        //--TRIMMABLE-BOUNDARY-START(318547)
        $asm.$cls("$tr.NetJs.Tests.RCL.Shared.SharedComponent", ($self) => class SharedComponent extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            //--TRIMMABLE-BOUNDARY-START(8590253139)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590253139);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590253139)
            
            //--TRIMMABLE-BOUNDARY-START(4295285843)
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295285843)
            
            static $h = 318547;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1245292,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590253139),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536748
        }
      ],
      "n": "BuildRenderTree",
      "d": 318547,
      "h": 8590253139,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8590253139)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295285843),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 318547,
      "h": 4295285843,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295285843)
  ],
  "i": [2752620,3145836,3080300
  ],
  "h": 318547
}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `NetJs.Tests.RCL.Shared.SharedComponent`; }
        });
        //--TRIMMABLE-BOUNDARY-END(318547)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.ComponentModel", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.ObjectModel", "NetJs.System.Collections.Immutable", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Drawing.Primitives", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Console", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Loader", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Text.RegularExpressions", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Net.NetworkInformation", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Text.Encodings.Web", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Json", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.Extensions.Validation", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.Logging", "NetJs.Microsoft.JSInterop.WebAssembly", "NetJs.Microsoft.AspNetCore.Components.WebAssembly", "NetJs.Microsoft.CSharp", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json"))
//--TRIMMABLE-BOUNDARY-END(56403)
