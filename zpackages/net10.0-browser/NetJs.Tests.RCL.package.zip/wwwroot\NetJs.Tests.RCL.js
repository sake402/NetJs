
(function ($global, $, $spc, $spu, $sr, $scm, $sc, $sm, $snv, $sdt, $st, $scc, $sris, $sri, $sl, $so, $sci, $sic, $stt, $sim, $stee, $srm, $sre, $srei, $srel, $srp, $sle, $mxdi, $mep, $meca, $mec, $scn, $scp, $scs, $sdp, $mwp, $scsl, $sttp, $sdd, $sds, $srn, $sfa, $snp, $ssc, $sspw, $sto, $snnr, $sns, $sscr, $snsc, $srw, $srl, $srsf, $str, $sdts, $sicb, $snn, $stc, $snq, $srij, $snh, $spx, $spxl, $sxxd, $sct, $sca, $meo, $meda, $mecb, $meoc, $mxdg, $mela, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $stew, $sipl, $stj, $mac, $mev, $srsp, $macf, $med, $mj, $macw, $mefa, $mef, $sifw, $mefp, $mecf, $mecj, $mel, $mjw, $macwa, $mc, $slq, $snhj) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Tests.RCL", 
    {"h":50029,"f":"Tests.RCL","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bf7a34a6f78fee11131301a9f55ca16a968616013","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.Tests.RCL","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.Tests.RCL","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$tr.NetJs.Tests.RCL._Imports", ($self) => class _Imports extends $.$spc.System.Object
        {
            /*void */ Execute()
            {
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 246637;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"n":"Execute","d":246637,"h":4295213933,"f":4}],"c":[{"n":".ctor","o":"$ctor$1","d":246637,"h":8590181229,"f":1}],"h":246637}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `NetJs.Tests.RCL._Imports`; }
        });
        
        $asm.$cls("$tr.Microsoft.CodeAnalysis.EmbeddedAttribute", ($self) => class EmbeddedAttribute extends $.$spc.System.Attribute
        {
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 115565;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14548993,"c":[{"n":".ctor","o":"$ctor$2","d":115565,"h":4295082861,"f":1}],"h":115565}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
        });
        
        $asm.$cls("$tr.Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute", ($self) => class ValidatableTypeAttribute extends $.$spc.System.Attribute
        {
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 181101;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14548993,"c":[{"n":".ctor","o":"$ctor$2","d":181101,"h":4295148397,"f":1}],"h":181101,"a":[{"t":115565,"c":4295082861},{"t":14680065,"c":21489516545,"a":[{"v":4,"t":14614529}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
        });
        
        $asm.$cls("$tr.NetJs.Tests.RCL.Shared.SharedComponent", ($self) => class SharedComponent extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 312173;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","d":312173,"h":4295279469,"f":32772}],"c":[{"n":".ctor","o":"$ctor$2","d":312173,"h":8590246765,"f":1}],"i":[2752520,3145736,3080200],"h":312173}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `NetJs.Tests.RCL.Shared.SharedComponent`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.ComponentModel", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.ObjectModel", "NetJs.System.Collections.Immutable", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Drawing.Primitives", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Console", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Loader", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Text.RegularExpressions", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Net.NetworkInformation", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Text.Encodings.Web", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Json", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.Extensions.Validation", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.Logging", "NetJs.Microsoft.JSInterop.WebAssembly", "NetJs.Microsoft.AspNetCore.Components.WebAssembly", "NetJs.Microsoft.CSharp", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json"))