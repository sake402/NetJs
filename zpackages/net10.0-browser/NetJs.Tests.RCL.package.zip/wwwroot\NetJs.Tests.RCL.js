
(function ($global, $, $spc, $mwp, $sc, $sdt, $sm, $snv, $spu, $srei, $srel, $srp, $sri, $srl, $stee, $st, $sto, $stt, $sttp, $mep, $sr, $scc, $scn, $scm, $sipl, $so, $srw, $srn, $srsp, $ssc, $stew, $sris, $stc, $srsf, $scp, $scsl, $sdf, $sfa, $sic, $sifd, $sim, $sl, $snp, $sspw, $srij, $scs, $sdp, $sifw, $sicb, $mefa, $mef, $sci, $sdd, $ssa, $sdts, $srm, $snnr, $mwr, $sip, $sds, $sre, $sns, $sdpc, $sscr, $sle, $str, $snn, $mefp, $snsc, $mc, $meca, $mxdi, $slq, $stj, $snq, $mec, $med, $mela, $snh, $mecf, $mj, $snhj, $spx, $mecj, $mjw, $spxl, $sxr, $sxxs, $sxxd, $stl, $sct, $mecb, $sca, $sdc, $meo, $meda, $mel, $meoc, $mev, $mxdg, $mac, $macf, $macw, $macwa) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Tests.RCL", 
    {"h":50443,"f":"Tests.RCL","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B760b8187d87d291733fdcda9f4d484d24d61a938","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.Tests.RCL","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.Tests.RCL","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$tr.NetJs.Tests.RCL._Imports", ($self) => class _Imports extends $.$spc.System.Object
        {
            /*void */ Execute()
            {
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 247051;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"n":"Execute","d":247051,"h":4295214347,"f":4}],"c":[{"n":".ctor","o":"$ctor$1","d":247051,"h":8590181643,"f":1}],"h":247051}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `NetJs.Tests.RCL._Imports`; }
        });
        
        $asm.$cls("$tr.Microsoft.CodeAnalysis.EmbeddedAttribute", ($self) => class EmbeddedAttribute extends $.$spc.System.Attribute
        {
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 115979;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"c":[{"n":".ctor","o":"$ctor$2","d":115979,"h":4295083275,"f":1}],"h":115979}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
        });
        
        $asm.$cls("$tr.Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute", ($self) => class ValidatableTypeAttribute extends $.$spc.System.Attribute
        {
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 181515;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"c":[{"n":".ctor","o":"$ctor$2","d":181515,"h":4295148811,"f":1}],"h":181515,"a":[{"t":115979,"c":4295083275},{"t":14614529,"c":21489451009,"a":[{"v":4,"t":14548993}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
        });
        
        $asm.$cls("$tr.NetJs.Tests.RCL.Shared.SharedComponent", ($self) => class SharedComponent extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 312587;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","d":312587,"h":4295279883,"f":32772}],"c":[{"n":".ctor","o":"$ctor$2","d":312587,"h":8590247179,"f":1}],"i":[2752520,3145736,3080200],"h":312587}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `NetJs.Tests.RCL.Shared.SharedComponent`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Runtime.Loader", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Threading", "NetJs.System.Threading.Overlapped", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.Microsoft.Extensions.Primitives", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.IO.Pipelines", "NetJs.System.ObjectModel", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Numerics", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Text.Encodings.Web", "NetJs.System.Runtime.InteropServices", "NetJs.System.Threading.Channels", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Console", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Linq", "NetJs.System.Net.Primitives", "NetJs.System.Security.Principal.Windows", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Collections.Specialized", "NetJs.System.Drawing.Primitives", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Compression.Brotli", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.Collections.Immutable", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Security.AccessControl", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Reflection.Metadata", "NetJs.System.Net.NameResolution", "NetJs.Microsoft.Win32.Registry", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Reflection.Emit", "NetJs.System.Net.Sockets", "NetJs.System.Diagnostics.Process", "NetJs.System.Security.Cryptography", "NetJs.System.Linq.Expressions", "NetJs.System.Text.RegularExpressions", "NetJs.System.Net.NetworkInformation", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.System.Net.Security", "NetJs.Microsoft.CSharp", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Json", "NetJs.System.Net.Quic", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.System.Net.Http", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.JSInterop", "NetJs.System.Net.Http.Json", "NetJs.System.Private.Xml", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.JSInterop.WebAssembly", "NetJs.System.Private.Xml.Linq", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Xml.XDocument", "NetJs.System.Transactions.Local", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Data.Common", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Logging", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.AspNetCore.Components.WebAssembly"))