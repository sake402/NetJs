
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sri, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mam, $mep, $meca, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mxdi, $sca, $meo, $meda, $meoc, $mxdg, $mela, $maa, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sipl, $stew, $stj, $mac, $mev, $srsp, $macf, $med, $mj, $macw, $mefa, $mef, $sifw, $mefp, $mecf, $mecj, $mel, $mjw, $macwa, $mc, $slq, $snhj, $stec, $swh, $sxx, $sxxx) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.blzw", 
    {"g":1,"h":49726,"f":"blzw","v":"1.0.0.0","a":[{"t":73596929,"c":4368564225,"a":[{"v":"blzw","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.0.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.0","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"blzw","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"blzw","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.0.0","t":1310721}]},{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$b.Program", ($self) => class Program
        {
            static async $$$(args)
            {
                /*var*/ let builder = $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyHostBuilder.CreateDefault(args);
                builder.RootComponents.Add$3($.$b.blzw.App, "#app");
                builder.RootComponents.Add$3($.$macw.Microsoft.AspNetCore.Components.Web.HeadOutlet, "head::after");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddScoped$5($.$snh.System.Net.Http.HttpClient, builder.Services, new ($.$$.System.Func$$$($.$scm.System.IServiceProvider, $.$snh.System.Net.Http.HttpClient))().$ctor(this,  (/*sp*/ sp) =>
                {
                    return (() =>
                    {
                        //new $.$snh.System.Net.Http.HttpClient()
                        const $t1 = $.$snh.System.Net.Http.HttpClient;
                        const $i1 = new $t1();
                        $i1.$ctor$3();
                        $i1.BaseAddress = new $.$spu.System.Uri().$ctor$5(builder.HostEnvironment.Microsoft$AspNetCore$Components$WebAssembly$Hosting$IWebAssemblyHostEnvironment$BaseAddress);
                        return $i1;
                    })();
                }, {"r":6422573,"p":[{"n":"sp","p":327717}],"n":"","d":836158,"h":0,"f":17825794}));
                await builder.Build().RunAsync();
            }
            static $h = 836158;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":133169153,"p":[{"n":"args","p":$.$typeArray($.$$.System.String).$h}],"n":"\u003CMain\u003E$","o":"$$$","d":836158,"h":4295803454,"f":16781346}],"c":[{"n":".ctor","o":"$ctor$1","d":836158,"h":8590770750,"f":16777217}],"h":836158}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Program`; }
        });
        
        $asm.$cls("$b.blzw._Imports", ($self) => class _Imports extends $.$$.System.Object
        {
            /*void */ Execute()
            {
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 115262;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"n":"Execute","d":115262,"h":4295082558,"f":16777220}],"c":[{"n":".ctor","o":"$ctor$1","d":115262,"h":8590049854,"f":16777217}],"h":115262}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `blzw._Imports`; }
        });
        
        $asm.$cls("$b.Microsoft.CodeAnalysis.EmbeddedAttribute", ($self) => class EmbeddedAttribute extends $.$$.System.Attribute
        {
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 705086;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"c":[{"n":".ctor","o":"$ctor$2","d":705086,"h":4295672382,"f":16777217}],"h":705086}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
        });
        
        $asm.$cls("$b.Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute", ($self) => class ValidatableTypeAttribute extends $.$$.System.Attribute
        {
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 770622;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"c":[{"n":".ctor","o":"$ctor$2","d":770622,"h":4295737918,"f":16777217}],"h":770622,"a":[{"t":705086,"c":4295672382},{"t":14745601,"c":21489582081,"a":[{"v":4,"t":14680065}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
        });
        
        $asm.$cls("$b.blzw.Layout.NavMenu", ($self) => class NavMenu extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$3(1, "class", "top-row ps-3 navbar navbar-dark");
                __builder.AddAttribute$5(2, "b-zaptew5brj");
                __builder.OpenElement(3, "div");
                __builder.AddAttribute$3(4, "class", "container-fluid");
                __builder.AddAttribute$5(5, "b-zaptew5brj");
                __builder.AddMarkupContent(6, "<a class=\"navbar-brand\" href b-zaptew5brj>blzw</a>\r\n        ");
                __builder.OpenElement(7, "button");
                __builder.AddAttribute$3(8, "title", "Navigation menu");
                __builder.AddAttribute$3(9, "class", "navbar-toggler");
                __builder.AddAttribute$7($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, 10, "onclick", $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$5($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, this, new $.$$.System.Action().$ctor(this, this.ToggleNavMenu)));
                __builder.AddAttribute$5(11, "b-zaptew5brj");
                __builder.AddMarkupContent(12, "<span class=\"navbar-toggler-icon\" b-zaptew5brj></span>");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(13, "\r\n\r\n");
                __builder.OpenElement(14, "div");
                __builder.AddAttribute$3(15, "class", (this.NavMenuCssClass) + " nav-scrollable");
                __builder.AddAttribute$7($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, 16, "onclick", $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$5($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, this, new $.$$.System.Action().$ctor(this, this.ToggleNavMenu)));
                __builder.AddAttribute$5(17, "b-zaptew5brj");
                __builder.OpenElement(18, "nav");
                __builder.AddAttribute$3(19, "class", "nav flex-column");
                __builder.AddAttribute$5(20, "b-zaptew5brj");
                __builder.OpenElement(21, "div");
                __builder.AddAttribute$3(22, "class", "nav-item px-3");
                __builder.AddAttribute$5(23, "b-zaptew5brj");
                __builder.OpenComponent$1($.$macw.Microsoft.AspNetCore.Components.Routing.NavLink, 24);
                __builder.AddComponentParameter(25, "class", "nav-link");
                __builder.AddComponentParameter(26, "href", "");
                __builder.AddComponentParameter(27, "Match", $.$box($.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$macw.Microsoft.AspNetCore.Components.Routing.NavLinkMatch, 1/*NavLinkMatch.All*/), $.$macw.Microsoft.AspNetCore.Components.Routing.NavLinkMatch));
                __builder.AddAttribute$1(28, "ChildContent", new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddMarkupContent(29, "<span class=\"bi bi-house-door-fill-nav-menu\" aria-hidden=\"true\" b-zaptew5brj></span> Home\r\n            ");
                })));
                __builder.CloseComponent();
                __builder.CloseElement();
                __builder.AddMarkupContent(30, "\r\n        ");
                __builder.OpenElement(31, "div");
                __builder.AddAttribute$3(32, "class", "nav-item px-3");
                __builder.AddAttribute$5(33, "b-zaptew5brj");
                __builder.OpenComponent$1($.$macw.Microsoft.AspNetCore.Components.Routing.NavLink, 34);
                __builder.AddComponentParameter(35, "class", "nav-link");
                __builder.AddComponentParameter(36, "href", "counter");
                __builder.AddAttribute$1(37, "ChildContent", new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddMarkupContent(38, "<span class=\"bi bi-plus-square-fill-nav-menu\" aria-hidden=\"true\" b-zaptew5brj></span> Counter\r\n            ");
                })));
                __builder.CloseComponent();
                __builder.CloseElement();
                __builder.AddMarkupContent(39, "\r\n        ");
                __builder.OpenElement(40, "div");
                __builder.AddAttribute$3(41, "class", "nav-item px-3");
                __builder.AddAttribute$5(42, "b-zaptew5brj");
                __builder.OpenComponent$1($.$macw.Microsoft.AspNetCore.Components.Routing.NavLink, 43);
                __builder.AddComponentParameter(44, "class", "nav-link");
                __builder.AddComponentParameter(45, "href", "weather");
                __builder.AddAttribute$1(46, "ChildContent", new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddMarkupContent(47, "<span class=\"bi bi-list-nested-nav-menu\" aria-hidden=\"true\" b-zaptew5brj></span> Weather\r\n            ");
                })));
                __builder.CloseComponent();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
            }
            /*bool*/ collapseNavMenu = true;
            /*string? */ get NavMenuCssClass()
            {
                return this.collapseNavMenu ? "collapse" : null;
            }
            /*void */ ToggleNavMenu()
            {
                this.collapseNavMenu = !this.collapseNavMenu;
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 311870;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17180181054,"f":50331650},"n":"NavMenuCssClass","d":311870,"h":12885213758,"f":2097154}],"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","d":311870,"h":4295279166,"f":16809988},{"r":65537,"n":"ToggleNavMenu","d":311870,"h":21475148350,"f":16777218}],"l":[{"t":262145,"n":"collapseNavMenu","d":311870,"h":8590246462,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$2","d":311870,"h":25770115646,"f":16777217}],"i":[2752520,3145736,3080200],"h":311870}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `blzw.Layout.NavMenu`; }
        });
        
        $asm.$cls("$b.blzw.Pages.Counter", ($self) => class Counter extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OpenComponent$1($.$macw.Microsoft.AspNetCore.Components.Web.PageTitle, 0);
                __builder.AddAttribute$1(1, "ChildContent", new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddContent$2(2, "Counter");
                })));
                __builder.CloseComponent();
                __builder.AddMarkupContent(3, "\r\n\r\n");
                __builder.AddMarkupContent(4, "<h1>Counter</h1>\r\n\r\n");
                __builder.OpenElement(5, "p");
                __builder.AddAttribute$3(6, "role", "status");
                __builder.AddContent$2(7, "Current count: ");
                __builder.AddContent$1(8, $.$box(this.currentCount, $.$$.System.Int32));
                __builder.CloseElement();
                __builder.AddMarkupContent(9, "\r\n\r\n");
                __builder.OpenElement(10, "button");
                __builder.AddAttribute$3(11, "class", "btn btn-primary");
                __builder.AddAttribute$7($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, 12, "onclick", $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$5($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, this, new $.$$.System.Action().$ctor(this, this.IncrementCount)));
                __builder.AddContent$2(13, "Click me");
                __builder.CloseElement();
            }
            /*int*/ currentCount = 0;
            /*void */ IncrementCount()
            {
                this.currentCount++;
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 377406;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","d":377406,"h":4295344702,"f":16809988},{"r":65537,"n":"IncrementCount","d":377406,"h":12885279294,"f":16777218}],"l":[{"t":655361,"n":"currentCount","d":377406,"h":8590311998,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$2","d":377406,"h":17180246590,"f":16777217}],"i":[2752520,3145736,3080200],"h":377406,"a":[{"t":9895944,"c":4304863240,"a":[{"v":"/counter","t":1310721}]}]}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `blzw.Pages.Counter`; }
        });
        
        $asm.$cls("$b.blzw.Pages.NotFound", ($self) => class NotFound extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.AddMarkupContent(0, "<h3>Not Found</h3>\r\n");
                __builder.AddMarkupContent(1, "<p>Sorry, the content you are looking for does not exist.</p>");
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 508478;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","d":508478,"h":4295475774,"f":16809988}],"c":[{"n":".ctor","o":"$ctor$2","d":508478,"h":8590443070,"f":16777217}],"i":[2752520,3145736,3080200],"h":508478,"a":[{"t":4587528,"c":4299554824,"a":[{"v":246334,"t":142475265}]},{"t":9895944,"c":4304863240,"a":[{"v":"/not-found","t":1310721}]}]}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `blzw.Pages.NotFound`; }
        });
        
        $asm.$cls("$b.blzw.Pages.Home", ($self) => class Home extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OpenComponent$1($.$macw.Microsoft.AspNetCore.Components.Web.PageTitle, 0);
                __builder.AddAttribute$1(1, "ChildContent", new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this, ( (/**/ __builder2) =>
                {
                    __builder2.AddContent$2(2, "Home");
                })));
                __builder.CloseComponent();
                __builder.AddMarkupContent(3, "\r\n\r\n");
                __builder.AddMarkupContent(4, "<h1>Hello, world!</h1>\r\n\r\nWelcome to your new app.\r\n");
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 442942;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","d":442942,"h":4295410238,"f":16809988}],"c":[{"n":".ctor","o":"$ctor$2","d":442942,"h":8590377534,"f":16777217}],"i":[2752520,3145736,3080200],"h":442942,"a":[{"t":9895944,"c":4304863240,"a":[{"v":"/","t":1310721}]}]}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `blzw.Pages.Home`; }
        });
        
        $asm.$cls("$b.blzw.App", ($self) => class App extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OpenComponent$1($.$mac.Microsoft.AspNetCore.Components.Routing.Router, 0);
                __builder.AddComponentParameter(1, "AppAssembly", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$$.System.Reflection.Assembly, $.$b.blzw.App.$type.Assembly));
                __builder.AddComponentParameter(2, "NotFoundPage", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$$.System.Type, $.$b.blzw.Pages.NotFound.$type));
                __builder.AddAttribute$1(3, "Found", new ($.$mac.Microsoft.AspNetCore.Components.RenderFragment$$($.$mac.Microsoft.AspNetCore.Components.RouteData))().$ctor(this, ( (/*routeData*/ routeData) =>
                {
                    return new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$mac.Microsoft.AspNetCore.Components.RouteView, 4);
                        __builder2.AddComponentParameter(5, "RouteData", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$mac.Microsoft.AspNetCore.Components.RouteData, routeData));
                        __builder2.AddComponentParameter(6, "DefaultLayout", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$$.System.Type, $.$b.blzw.Layout.MainLayout.$type));
                        __builder2.CloseComponent();
                        __builder2.AddMarkupContent(7, "\r\n        ");
                        __builder2.OpenComponent$1($.$macw.Microsoft.AspNetCore.Components.Routing.FocusOnNavigate, 8);
                        __builder2.AddComponentParameter(9, "RouteData", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$mac.Microsoft.AspNetCore.Components.RouteData, routeData));
                        __builder2.AddComponentParameter(10, "Selector", "h1");
                        __builder2.CloseComponent();
                    }, {"r":65537,"p":[{"n":"__builder2","p":7536648}],"n":"","d":180798,"h":0,"f":17825794});
                })));
                __builder.CloseComponent();
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 180798;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","d":180798,"h":4295148094,"f":16809988}],"c":[{"n":".ctor","o":"$ctor$2","d":180798,"h":8590115390,"f":16777217}],"i":[2752520,3145736,3080200],"h":180798}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `blzw.App`; }
        });
        
        $asm.$cls("$b.blzw.Pages.Weather", ($self) => class Weather extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OpenComponent$1($.$macw.Microsoft.AspNetCore.Components.Web.PageTitle, 0);
                __builder.AddAttribute$1(1, "ChildContent", new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddContent$2(2, "Weather");
                })));
                __builder.CloseComponent();
                __builder.AddMarkupContent(3, "\r\n\r\n");
                __builder.AddMarkupContent(4, "<h1>Weather</h1>\r\n\r\n");
                __builder.AddMarkupContent(5, "<p>This component demonstrates fetching data from the server.</p>");
                if (this.forecasts === null)
                {
                    __builder.AddMarkupContent(6, "<p><em>Loading...</em></p>");
                }
                else 
                {
                    __builder.OpenElement(7, "table");
                    __builder.AddAttribute$3(8, "class", "table");
                    __builder.AddMarkupContent(9, "<thead><tr><th>Date</th>\r\n                <th aria-label=\"Temperature in Celsius\">Temp. (C)</th>\r\n                <th aria-label=\"Temperature in Fahrenheit\">Temp. (F)</th>\r\n                <th>Summary</th></tr></thead>\r\n        ");
                    __builder.OpenElement(10, "tbody");
                    let $i1 = 0;
                    let $arr1 = this.forecasts;
                    while ($i1 < $arr1.length)
                    {
                        let forecast = $arr1[$i1++];
                        __builder.OpenElement(11, "tr");
                        __builder.OpenElement(12, "td");
                        __builder.AddContent$2(13, forecast.Date.ToShortDateString());
                        __builder.CloseElement();
                        __builder.AddMarkupContent(14, "\r\n                    ");
                        __builder.OpenElement(15, "td");
                        __builder.AddContent$1(16, $.$box(forecast.TemperatureC, $.$$.System.Int32));
                        __builder.CloseElement();
                        __builder.AddMarkupContent(17, "\r\n                    ");
                        __builder.OpenElement(18, "td");
                        __builder.AddContent$1(19, $.$box(forecast.TemperatureF, $.$$.System.Int32));
                        __builder.CloseElement();
                        __builder.AddMarkupContent(20, "\r\n                    ");
                        __builder.OpenElement(21, "td");
                        __builder.AddContent$2(22, forecast.Summary);
                        __builder.CloseElement();
                        __builder.CloseElement();
                    }
                    __builder.CloseElement();
                    __builder.CloseElement();
                }
            }
            /*WeatherForecast[]?*/ forecasts = null;
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    this.forecasts = await $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.GetFromJsonAsync$6($.$typeArray($.$b.blzw.Pages.Weather.WeatherForecast), this.Http, "sample-data/weather.json", new $.$$.System.Threading.CancellationToken());
                });
            }
            static $_WeatherForecast;
            static get WeatherForecast()
            {
                let $cls = $.$b.blzw.Pages.Weather;
                return $cls.$_WeatherForecast ??= $asm.$ncls("$b.blzw.Pages.Weather.WeatherForecast", ($self) => class WeatherForecast extends $.$$.System.Object
                {
                    /*DateOnly*/ Date;
                    /*int*/ TemperatureC = 0;
                    /*string?*/ Summary = null;
                    /*int */ get TemperatureF()
                    {
                        return ((32 + $.$cast((this.TemperatureC / 0.5556), $.$$.System.Int32)) | 0);
                    }
                    //default reference type constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        return this;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.Date = $.$default($.$$.System.DateOnly);
                    }
                    static $h = 639550;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":34209793,"g":{"r":0,"d":0,"h":12885541438,"f":50331649},"s":{"r":0,"d":0,"h":17180508734,"f":83886081},"n":"Date","d":639550,"h":8590574142,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":30065410622,"f":50331649},"s":{"r":0,"d":0,"h":34360377918,"f":83886081},"n":"TemperatureC","d":639550,"h":25770443326,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":47245279806,"f":50331649},"s":{"r":0,"d":0,"h":51540247102,"f":83886081},"n":"Summary","d":639550,"h":42950312510,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":60130181694,"f":50331649},"n":"TemperatureF","d":639550,"h":55835214398,"f":2097153}],"c":[{"n":".ctor","o":"$ctor$1","d":639550,"h":64425148990,"f":16777217}],"d":574014,"h":639550}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `blzw.Pages.Weather.WeatherForecast`; }
                }, $cls, ($v) => $cls.$_WeatherForecast = $v);
            }
            /*HttpClient*/ Http = null;
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Http = null;
            }
            static $h = 574014;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":6422573,"g":{"r":0,"d":0,"h":30065345086,"f":50331650},"s":{"r":0,"d":0,"h":34360312382,"f":83886082},"n":"Http","d":574014,"h":25770377790,"f":2097154,"a":[{"t":4259848,"c":21479096328}]}],"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","d":574014,"h":4295541310,"f":16809988},{"r":133169153,"n":"OnInitializedAsync","d":574014,"h":12885475902,"f":16814084}],"l":[{"t":$.$typeArray($.$b.blzw.Pages.Weather.WeatherForecast).$h,"n":"forecasts","d":574014,"h":8590508606,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$2","d":574014,"h":38655279678,"f":16777217}],"i":[2752520,3145736,3080200],"j":[639550],"h":574014,"a":[{"t":9895944,"c":4304863240,"a":[{"v":"/weather","t":1310721}]}]}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `blzw.Pages.Weather`; }
        });
        
        $asm.$cls("$b.blzw.Layout.MainLayout", ($self) => class MainLayout extends $.$mac.Microsoft.AspNetCore.Components.LayoutComponentBase
        {
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$3(1, "class", "page");
                __builder.AddAttribute$5(2, "b-zpth50vodu");
                __builder.OpenElement(3, "div");
                __builder.AddAttribute$3(4, "class", "sidebar");
                __builder.AddAttribute$5(5, "b-zpth50vodu");
                __builder.OpenComponent$1($.$b.blzw.Layout.NavMenu, 6);
                __builder.CloseComponent();
                __builder.CloseElement();
                __builder.AddMarkupContent(7, "\r\n\r\n    ");
                __builder.OpenElement(8, "main");
                __builder.AddAttribute$5(9, "b-zpth50vodu");
                __builder.AddMarkupContent(10, "<div class=\"top-row px-4\" b-zpth50vodu><a href=\"https://learn.microsoft.com/aspnet/core/\" target=\"_blank\" b-zpth50vodu>About</a></div>\r\n\r\n        ");
                __builder.OpenElement(11, "article");
                __builder.AddAttribute$3(12, "class", "content px-4");
                __builder.AddAttribute$5(13, "b-zpth50vodu");
                __builder.AddContent$4(14, this.Body);
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 246334;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":4653064,"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","d":246334,"h":4295213630,"f":16809988}],"c":[{"n":".ctor","o":"$ctor$3","d":246334,"h":8590180926,"f":16777217}],"i":[2752520,3145736,3080200],"h":246334}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.LayoutComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `blzw.Layout.MainLayout`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.Extensions.Validation", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.Logging", "NetJs.Microsoft.JSInterop.WebAssembly", "NetJs.Microsoft.AspNetCore.Components.WebAssembly", "NetJs.Microsoft.CSharp", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument"))