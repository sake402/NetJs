
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sri, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mam, $mep, $meca, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mxdi, $sca, $meo, $meda, $meoc, $mxdg, $mela, $maa, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sipl, $stew, $stj, $mac, $mev, $srsp, $macf, $med, $mj, $macw, $mefa, $mef, $sifw, $mefp, $mecf, $mecj, $mel, $mjw, $macwa, $mc, $slq, $snhj, $stec, $swh, $sxx, $sxxx) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.miniapp", 
    {"g":1,"h":49188,"f":"miniapp","v":"1.0.0.0","a":[{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"miniapp","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.0.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.0","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"miniapp","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"miniapp","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.0.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$m.I", ($self) => class ITaskService
        {
            static $h = 180260;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":133169153,"n":"SaveTask","o":"I$S","d":180260,"h":17180049444,"f":257},{"r":133169153,"n":"LoadTasks","o":"I$L","d":180260,"h":21475016740,"f":257},{"r":$.$$.SCG.L$$($.$m.A).$h,"n":"GetAll","o":"I$G","d":180260,"h":25769984036,"f":257},{"r":65537,"p":[{"n":"title","p":1310721},{"n":"priority","p":1949732}],"n":"Add","o":"I$A","d":180260,"h":30064951332,"f":257},{"r":65537,"p":[{"n":"title","p":1310721},{"n":"priority","p":1949732}],"n":"MoveTask","o":"I$M","d":180260,"h":34359918628,"f":257},{"r":65537,"p":[{"n":"id","p":655361}],"n":"Delete","o":"I$D","d":180260,"h":38654885924,"f":257},{"r":65537,"n":"ClearAllTask","o":"I$C","d":180260,"h":42949853220,"f":257},{"r":65537,"p":[{"n":"id","p":655361}],"n":"ToggleCompleted","o":"I$T","d":180260,"h":47244820516,"f":257},{"r":655361,"n":"GetCompletedCount","o":"I$GC","d":180260,"h":51539787812,"f":257},{"r":655361,"n":"GetPendingCount","o":"I$GP","d":180260,"h":55834755108,"f":257}],"e":[{"e":11730945,"m":{"r":65537,"p":[{"n":"value","p":11730945}],"n":"add_OnChange","o":"I$a","d":180260,"h":4295147556,"f":257},"r":{"r":65537,"p":[{"n":"value","p":11730945}],"n":"remove_OnChange","o":"I$r","d":180260,"h":8590114852,"f":257},"n":"OnChange","o":"ITaskService$O","d":180260,"h":12885082148,"f":257}],"h":180260}; }
            static get $fullName() { return `ITaskService`; }
        });
        
        $asm.$cls("$m.m._", ($self) => class _Imports extends $.$$.S.O
        {
            /*void */ E$2()
            {
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 376868;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"n":"Execute","o":"E$2","d":376868,"h":4295344164,"f":4}],"c":[{"n":".ctor","o":"$ctor$1","d":376868,"h":8590311460,"f":1}],"h":376868}; }
            static get $b() { return $.$$.S.O; }
            static get $fullName() { return `miniapp._Imports`; }
        });
        
        $asm.$cls("$m.U", ($self) => class UserModel extends $.$$.S.O
        {
            /*string*/ FN = null;
            /*string*/ L = null;
            /*string*/ E$2 = null;
            /*DateTime?*/ D = null;
            /*string*/ U = null;
            /*string*/ P$1 = null;
            /*string*/ C = null;
            /*string*/ R$1 = null;
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.FN = "";
                this.L = "";
                this.E$2 = "";
                this.D = null;
                this.U = "";
                this.P$1 = "";
                this.C = "";
                this.R$1 = "";
            }
            static $h = 2146340;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12887048228,"f":1},"s":{"r":0,"d":0,"h":17182015524,"f":1},"n":"FirstName","o":"FN","d":2146340,"h":8592080932,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":30066917412,"f":1},"s":{"r":0,"d":0,"h":34361884708,"f":1},"n":"LastName","o":"L","d":2146340,"h":25771950116,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":47246786596,"f":1},"s":{"r":0,"d":0,"h":51541753892,"f":1},"n":"Email","o":"E$2","d":2146340,"h":42951819300,"f":1},{"p":$.$typeNullable($.$$.S.DT$1).$h,"g":{"r":0,"d":0,"h":64426655780,"f":1},"s":{"r":0,"d":0,"h":68721623076,"f":1},"n":"DateOfBirth","o":"D","d":2146340,"h":60131688484,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":81606524964,"f":1},"s":{"r":0,"d":0,"h":85901492260,"f":1},"n":"Username","o":"U","d":2146340,"h":77311557668,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":98786394148,"f":1},"s":{"r":0,"d":0,"h":103081361444,"f":1},"n":"Password","o":"P$1","d":2146340,"h":94491426852,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":115966263332,"f":1},"s":{"r":0,"d":0,"h":120261230628,"f":1},"n":"ConfirmPassword","o":"C","d":2146340,"h":111671296036,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":133146132516,"f":1},"s":{"r":0,"d":0,"h":137441099812,"f":1},"n":"Role","o":"R$1","d":2146340,"h":128851165220,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":2146340,"h":141736067108,"f":1}],"h":2146340}; }
            static get $b() { return $.$$.S.O; }
            static get $fullName() { return `UserModel`; }
        });
        
        $asm.$cls("$m.A", ($self) => class AppTask extends $.$$.S.O
        {
            /*int*/ Id = 0;
            /*string*/ T$1 = null;
            /*Priority*/ P$1 = 0;
            /*bool*/ IC = false;
            /*string*/ D = null;
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.T$1 = "";
                this.P$1 = 2;
                this.IC = false;
                this.D = "";
            }
            static $h = 114724;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885016612,"f":1},"s":{"r":0,"d":0,"h":17179983908,"f":1},"n":"Id","d":114724,"h":8590049316,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":30064885796,"f":1},"s":{"r":0,"d":0,"h":34359853092,"f":1},"n":"Title","o":"T$1","d":114724,"h":25769918500,"f":1},{"p":1949732,"g":{"r":0,"d":0,"h":47244754980,"f":1},"s":{"r":0,"d":0,"h":51539722276,"f":1},"n":"Priority","o":"P$1","d":114724,"h":42949787684,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":64424624164,"f":1},"s":{"r":0,"d":0,"h":68719591460,"f":1},"n":"IsComplete","o":"IC","d":114724,"h":60129656868,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":81604493348,"f":1},"s":{"r":0,"d":0,"h":85899460644,"f":1},"n":"Date","o":"D","d":114724,"h":77309526052,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":114724,"h":90194427940,"f":1}],"h":114724}; }
            static get $b() { return $.$$.S.O; }
            static get $fullName() { return `AppTask`; }
        });
        
        $asm.$cls("$m.mC._", ($self) => class _Imports extends $.$$.S.O
        {
            /*void */ E$2()
            {
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 507940;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"n":"Execute","o":"E$2","d":507940,"h":4295475236,"f":4}],"c":[{"n":".ctor","o":"$ctor$1","d":507940,"h":8590442532,"f":1}],"h":507940}; }
            static get $b() { return $.$$.S.O; }
            static get $fullName() { return `miniapp.Components._Imports`; }
        });
        
        $asm.$cls("$m.P", ($self) => class Program
        {
            static async $$$(args)
            {
                /*var*/ let builder = $.$macwa.MACWH.WAHB.CD(args);
                builder.RC.A$3($.$m.m.A, "#app");
                builder.RC.A$3($.$macw.MACW.HO, "head::after");
                $.$mxdi.MED.SC.AS$6($.$m.mS.A, builder.S$1);
                $.$mxdi.MED.SC.AS$4($.$m.I, $.$m.T, builder.S$1);
                $.$mxdi.MED.SC.AS$5($.$snh.SNH.HC, builder.S$1, new ($.$$.S.F$$$($.$scm.S.I, $.$snh.SNH.HC))().$ctor(this,  (/*sp*/ sp) =>
                {
                    return (() =>
                    {
                        //new $.$snh.SNH.HC()
                        const $t1 = $.$snh.SNH.HC;
                        const $i1 = new $t1();
                        $i1.$ctor$3();
                        $i1.B = new $.$spu.S.U$1().$ctor$5(builder.H.MACWH$I$B);
                        return $i1;
                    })();
                }, {"r":6422573,"p":[{"n":"sp","p":327717}],"n":"","d":2015268,"h":0,"f":1048578}));
                await builder.B().RA();
            }
            static $h = 2015268;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":133169153,"p":[{"n":"args","p":0}],"n":"\u003CMain\u003E$","o":"$$$","d":2015268,"h":4296982564,"f":4130}],"c":[{"n":".ctor","o":"$ctor$1","d":2015268,"h":8591949860,"f":1}],"h":2015268}; }
            static get $b() { return $.$$.S.O; }
            static get $fullName() { return `Program`; }
        });
        
        $asm.$cls("$m.mS.A", ($self) => class AuthService extends $.$$.S.O
        {
            /*IJSRuntime*/ JS = null;
            $ctor$1(/*IJSRuntime*/ jS)
            {
                super.$ctor();
                {
                    this.JS = jS;
                }
                return this;
            }
            /*bool*/ IL = false;
            /*string*/ U = null;
            /*string*/ R$1 = null;
            /*string*/ F$1 = null;
            /*string*/ L = null;
            /*string*/ E$2 = null;
            /*string*/ D = null;
            /*string*/ P$1 = null;
            /*string*/ C = null;
            /*bool*/ u = false;
            /*UserModel*/ n = null;
            /*List<UserModel>*/ _ = null;
            /*Action?*/ O = null;
            a(/*Action?*/ value)
            {
                this.O = $.$$.S.D$1.C$1(this.O, value);
            }
            r(/*Action?*/ value)
            {
                this.O = $.$$.S.D$1.R$1(this.O, value);
            }
            /*void */ N()
            {
                return (this.O?.I$1() ?? null);
            }
            /*List<UserModel>*/ u$1 = null;
            /*Task<string> *//*async*/  SU$1(/*string*/ firstname, /*string*/ lastname, /*string*/ email, /*string*/ role, /*DateTime?*/ dateOfBirth, /*string*/ username, /*string*/ password, /*string*/ confirmPassword)
            {
                return $.$$.N.AR.A($.$$.STT.T$1$$($.$$.S.S$1), $.$$.S.S$1, async () => 
                {
                    this.F$1 = firstname;
                    this.L = lastname;
                    this.E$2 = email;
                    this.D = (dateOfBirth?.TS$3("yyyy-MM-dd") ?? null) ?? "";
                    this.U = username;
                    this.P$1 = password;
                    this.C = confirmPassword;
                    this.R$1 = role;
                    if ($.$$.S.S$1.o_I(password, confirmPassword))
                    {
                        return "Passwords do not match.";
                    }
                    this.u = $.$sl.SL.E.A$4($.$m.U, this.u$1, new ($.$$.S.F$$$($.$m.U, $.$$.S.B$2))().$ctor(this,  (/*u*/ u) =>
                    {
                        return $.$$.S.S$1.E$5.call(u.U, username, 5/*StringComparison.OrdinalIgnoreCase*/);
                    }, {"r":262145,"p":[{"n":"u","p":2146340}],"n":"","d":1884196,"h":0,"f":1048578}));
                    if (this.u)
                    {
                        return "Username is already taken.";
                    }
                    this.n = (() =>
                    {
                        //new $.$m.U()
                        const $t1 = $.$m.U;
                        const $i1 = new $t1();
                        $i1.FN = firstname;
                        $i1.L = lastname;
                        $i1.E$2 = email;
                        $i1.D = dateOfBirth?.Clone() ?? null;
                        $i1.U = username;
                        $i1.P$1 = password;
                        $i1.R$1 = role;
                        return $i1;
                    })();
                    this.u$1.A(this.n);
                    await this.SU();
                    await this.LU();
                    this.N();
                    return "Success";
                });
            }
            /*bool */ L$1(/*string*/ username, /*string*/ password)
            {
                /*var*/ let user = $.$sl.SL.E.FOD($.$m.U, this.u$1, new ($.$$.S.F$$$($.$m.U, $.$$.S.B$2))().$ctor(this,  (/**/ u) =>
                {
                    return $.$$.S.S$1.o_E(u.U, username) && $.$$.S.S$1.o_E(u.P$1, password);
                }, {"r":262145,"p":[{"n":"u","p":2146340}],"n":"","d":1884196,"h":0,"f":1048578}));
                if (user === null)
                {
                    this.IL = false;
                    return false;
                }
                this.IL = true;
                this.U = user.U ?? "";
                this.R$1 = user.R$1 ?? "";
                this.F$1 = user.FN ?? "";
                this.L = user.L ?? "";
                this.E$2 = user.E$2 ?? "";
                this.D = (user.D?.TS$3("yyyy-MM-dd") ?? null) ?? "";
                this.N();
                return true;
            }
            /*void */ L$2()
            {
                this.IL = false;
                this.U = "";
                this.R$1 = "";
                this.F$1 = "";
                this.L = "";
                this.E$2 = "";
                this.D = "";
                this.N();
            }
            /*Task *//*async*/  SU()
            {
                return $.$$.N.AR.A($.$$.STT.T, $.$$.S.V$2, async () => 
                {
                    /*var*/ let jsonString = $.$stj.STJ.JS.S$14($.$$.SCG.L$$($.$m.U), this.u$1, null);
                    await $.$mj.MJ.JSE.IV(this.JS, "localStorage.setItem", $.$$.SRC.RH.CA($.$typeOf($.$$.S.O), [ "All_Users", jsonString ], null, null));
                });
            }
            /*bool*/ l = false;
            /*Task *//*async*/  LU()
            {
                return $.$$.N.AR.A($.$$.STT.T, $.$$.S.V$2, async () => 
                {
                    if (this.l)
                    {
                        return;
                    }
                    /*var*/ let jsonString = await $.$mj.MJ.JSE.IA($.$$.S.S$1, this.JS, "localStorage.getItem", $.$$.SRC.RH.CA($.$typeOf($.$$.S.O), [ "All_Users" ], null, null));
                    if (!$.$$.S.S$1.INO(jsonString))
                    {
                        /*var*/ let savedUsers = $.$stj.STJ.JS.D$30($.$$.SCG.L$$($.$m.U), jsonString, null);
                        if (savedUsers !== null)
                        {
                            this.u$1 = savedUsers;
                        }
                    }
                    this.l = true;
                });
            }
            /*Task *//*async*/  DA()
            {
                return $.$$.N.AR.A($.$$.STT.T, $.$$.S.V$2, async () => 
                {
                    if (!this.IL)
                    {
                        return;
                    }
                    /*var*/ let userToRemove = $.$sl.SL.E.FOD($.$m.U, this.u$1, new ($.$$.S.F$$$($.$m.U, $.$$.S.B$2))().$ctor(this,  (/**/ u) =>
                    {
                        return $.$$.S.S$1.E$5.call(u.U, this.U, 5/*StringComparison.OrdinalIgnoreCase*/);
                    }, {"r":262145,"p":[{"n":"u","p":2146340}],"n":"","d":1884196,"h":0,"f":1048578}));
                    if (userToRemove !== null)
                    {
                        this.u$1.R$1(userToRemove);
                    }
                    /*var*/ let jsonString = $.$stj.STJ.JS.S$14($.$$.SCG.L$$($.$m.U), this.u$1, null);
                    await $.$mj.MJ.JSE.IV(this.JS, "localStorage.setItem", $.$$.SRC.RH.CA($.$typeOf($.$$.S.O), [ "All_Users", jsonString ], null, null));
                    this.L$2();
                });
            }
            //default member initializer
            constructor()
            {
                super();
                this.IL = false;
                this.U = "";
                this.R$1 = "";
                this.F$1 = "";
                this.L = "";
                this.E$2 = "";
                this.D = "";
                this.P$1 = "";
                this.C = "";
                this.u = true;
                this._ = new ($.$$.SCG.L$$($.$m.U))().$ctor$1();
                this.u$1 = (() =>
                {
                    //new $.$$.SCG.L$$($.$m.U)()
                    const $t1 = $.$$.SCG.L$$($.$m.U);
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.A((() =>
                    {
                        //new $.$m.U()
                        const $t2 = $.$m.U;
                        const $i2 = new $t2();
                        $i2.U = "Olabode";
                        $i2.P$1 = "1234";
                        $i2.R$1 = "Admin";
                        $i2.E$2 = "benny@mail.com";
                        return $i2;
                    })());
                    $i1.A((() =>
                    {
                        //new $.$m.U()
                        const $t3 = $.$m.U;
                        const $i3 = new $t3();
                        $i3.U = "Benedicta";
                        $i3.P$1 = "2345";
                        $i3.R$1 = "Admin";
                        return $i3;
                    })());
                    $i1.A((() =>
                    {
                        //new $.$m.U()
                        const $t4 = $.$m.U;
                        const $i4 = new $t4();
                        $i4.U = "Blessing";
                        $i4.P$1 = "3456";
                        $i4.R$1 = "User";
                        return $i4;
                    })());
                    return $i1;
                })();
            }
            static $h = 1884196;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":21476720676,"f":1},"s":{"r":0,"d":0,"h":25771687972,"f":2},"n":"IsLoggedIn","o":"IL","d":1884196,"h":17181753380,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":38656589860,"f":1},"s":{"r":0,"d":0,"h":42951557156,"f":2},"n":"Username","o":"U","d":1884196,"h":34361622564,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":55836459044,"f":1},"s":{"r":0,"d":0,"h":60131426340,"f":2},"n":"Role","o":"R$1","d":1884196,"h":51541491748,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":73016328228,"f":1},"s":{"r":0,"d":0,"h":77311295524,"f":2},"n":"Firstname","o":"F$1","d":1884196,"h":68721360932,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":90196197412,"f":1},"s":{"r":0,"d":0,"h":94491164708,"f":2},"n":"Lastname","o":"L","d":1884196,"h":85901230116,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":107376066596,"f":1},"s":{"r":0,"d":0,"h":111671033892,"f":2},"n":"Email","o":"E$2","d":1884196,"h":103081099300,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":124555935780,"f":1},"s":{"r":0,"d":0,"h":128850903076,"f":2},"n":"DateOfBirth","o":"D","d":1884196,"h":120260968484,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":141735804964,"f":1},"s":{"r":0,"d":0,"h":146030772260,"f":2},"n":"Password1","o":"P$1","d":1884196,"h":137440837668,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":158915674148,"f":1},"s":{"r":0,"d":0,"h":163210641444,"f":2},"n":"ConfirmPassword","o":"C","d":1884196,"h":154620706852,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":176095543332,"f":1},"s":{"r":0,"d":0,"h":180390510628,"f":2},"n":"userExists","o":"u","d":1884196,"h":171800576036,"f":1},{"p":2146340,"g":{"r":0,"d":0,"h":193275412516,"f":1},"s":{"r":0,"d":0,"h":197570379812,"f":2},"n":"newUser","o":"n","d":1884196,"h":188980445220,"f":1}],"m":[{"r":65537,"n":"Notify","o":"N","d":1884196,"h":219045216292,"f":1},{"r":$.$$.STT.T$1$$($.$$.S.S$1).$h,"p":[{"n":"firstname","p":1310721},{"n":"lastname","p":1310721},{"n":"email","p":1310721},{"n":"role","p":1310721},{"n":"dateOfBirth","p":$.$typeNullable($.$$.S.DT$1).$h},{"n":"username","p":1310721},{"n":"password","p":1310721},{"n":"confirmPassword","p":1310721}],"n":"SignUp","o":"SU$1","d":1884196,"h":227635150884,"f":4097},{"r":262145,"p":[{"n":"username","p":1310721},{"n":"password","p":1310721}],"n":"Login","o":"L$1","d":1884196,"h":231930118180,"f":1},{"r":65537,"n":"Logout","o":"L$2","d":1884196,"h":236225085476,"f":1},{"r":133169153,"n":"SaveUser","o":"SU","d":1884196,"h":240520052772,"f":4097},{"r":133169153,"n":"LoadUsers","o":"LU","d":1884196,"h":249109987364,"f":4097},{"r":133169153,"n":"DeleteAccount","o":"DA","d":1884196,"h":253404954660,"f":4097}],"l":[{"t":524318,"n":"JS","d":1884196,"h":4296851492,"f":2},{"t":$.$$.SCG.L$$($.$m.U).$h,"n":"_user","o":"_","d":1884196,"h":201865347108,"f":1},{"t":$.$$.SCG.L$$($.$m.U).$h,"n":"users","o":"u$1","d":1884196,"h":223340183588,"f":2},{"t":262145,"n":"loaded","o":"l","d":1884196,"h":244815020068,"f":2}],"c":[{"p":[{"n":"jS","p":524318}],"n":".ctor","o":"$ctor$1","d":1884196,"h":8591818788,"f":1}],"e":[{"e":11730945,"m":{"r":65537,"p":[{"n":"value","p":11730945}],"n":"add_OnChange","o":"a","d":1884196,"h":206160314404,"f":1},"r":{"r":65537,"p":[{"n":"value","p":11730945}],"n":"remove_OnChange","o":"r","d":1884196,"h":210455281700,"f":1},"n":"OnChange","o":"O","d":1884196,"h":214750248996,"f":1}],"h":1884196}; }
            static get $b() { return $.$$.S.O; }
            static get $fullName() { return `miniapp.Services.AuthService`; }
        });
        
        $asm.$cls("$m.T", ($self) => class TaskService extends $.$$.S.O
        {
            /*IJSRuntime*/ JS = null;
            $ctor$1(/*IJSRuntime*/ jS)
            {
                super.$ctor();
                {
                    this.JS = jS;
                }
                return this;
            }
            /*object*/ _ = null;
            /*AppTask*/ n = null;
            /*List<AppTask>*/ t$1 = null;
            /*Action?*/ O = null;
            a(/*Action?*/ value)
            {
                this.O = $.$$.S.D$1.C$1(this.O, value);
            }
            r(/*Action?*/ value)
            {
                this.O = $.$$.S.D$1.R$1(this.O, value);
            }
            /*void */ N()
            {
                return (this.O?.I$1() ?? null);
            }
            /*List<AppTask> */ GA()
            {
                //lock
                try
                {
                    $.$$.ST$1.M$1.E$3(this._)
                    {
                        return $.$sl.SL.E.TL$1($.$m.A, this.t$1);
                    }
                }
                finally
                {
                    $.$$.ST$1.M$1.E$4(this._)
                }
            }
            /*void */ A(/*string*/ title, /*Priority*/ priority)
            {
                //lock
                try
                {
                    $.$$.ST$1.M$1.E$3(this._)
                    {
                        this.n = (() =>
                        {
                            //new $.$m.A()
                            const $t1 = $.$m.A;
                            const $i1 = new $t1();
                            $i1.Id = $.$sl.SL.E.A$5($.$m.A, this.t$1) ? (($.$sl.SL.E.M$15($.$m.A, this.t$1, new ($.$$.S.F$$$($.$m.A, $.$$.S.I$4))().$ctor(this,  (/*t*/ t) =>
                            {
                                return t.Id;
                            }, {"r":655361,"p":[{"n":"t","p":114724}],"n":"","d":2080804,"h":0,"f":1048578})) + 1) | 0) : 1;
                            $i1.T$1 = title;
                            $i1.P$1 = priority;
                            $i1.D = $.$$.S.DT$1.N$1.TS$3("dd MMM yyyy");
                            $i1.IC = false;
                            return $i1;
                        })();
                        this.t$1.A(this.n);
                    }
                }
                finally
                {
                    $.$$.ST$1.M$1.E$4(this._)
                }
                this.N();
            }
            /*void */ MT(/*string*/ title, /*Priority*/ priority)
            {
                //lock
                try
                {
                    $.$$.ST$1.M$1.E$3(this._)
                    {
                        this.n = (() =>
                        {
                            //new $.$m.A()
                            const $t1 = $.$m.A;
                            const $i1 = new $t1();
                            $i1.Id = $.$sl.SL.E.A$5($.$m.A, this.t$1) ? (($.$sl.SL.E.M$15($.$m.A, this.t$1, new ($.$$.S.F$$$($.$m.A, $.$$.S.I$4))().$ctor(this,  (/*t*/ t) =>
                            {
                                return t.Id;
                            }, {"r":655361,"p":[{"n":"t","p":114724}],"n":"","d":2080804,"h":0,"f":1048578})) + 1) | 0) : 1;
                            $i1.T$1 = title;
                            $i1.P$1 = priority;
                            $i1.D = $.$$.S.DT$1.N$1.TS$3("dd MMM yyyy");
                            $i1.IC = true;
                            return $i1;
                        })();
                        this.t$1.A(this.n);
                    }
                }
                finally
                {
                    $.$$.ST$1.M$1.E$4(this._)
                }
                this.N();
            }
            /*void */ D(/*int*/ id)
            {
                //lock
                try
                {
                    $.$$.ST$1.M$1.E$3(this._)
                    {
                        this.t$1.RA(new ($.$$.S.P$1$$($.$m.A))().$ctor(this,  (/*t*/ t) =>
                        {
                            return t.Id === id;
                        }, {"r":262145,"p":[{"n":"t","p":114724}],"n":"","d":2080804,"h":0,"f":1048578}));
                    }
                }
                finally
                {
                    $.$$.ST$1.M$1.E$4(this._)
                }
                this.N();
            }
            /*void */ C()
            {
                //lock
                try
                {
                    $.$$.ST$1.M$1.E$3(this._)
                    {
                        this.t$1.C$1();
                    }
                }
                finally
                {
                    $.$$.ST$1.M$1.E$4(this._)
                }
                this.N();
            }
            /*Task *//*async*/  ST()
            {
                return $.$$.N.AR.A($.$$.STT.T, $.$$.S.V$2, async () => 
                {
                    /*var*/ let jsonString = $.$stj.STJ.JS.S$14($.$$.SCG.L$$($.$m.A), this.t$1, null);
                    await $.$mj.MJ.JSE.IV(this.JS, "localStorage.setItem", $.$$.SRC.RH.CA($.$typeOf($.$$.S.O), [ "All_Tasks", jsonString ], null, null));
                });
            }
            /*bool*/ l = false;
            /*Task *//*async*/  L()
            {
                return $.$$.N.AR.A($.$$.STT.T, $.$$.S.V$2, async () => 
                {
                    if (this.l)
                    {
                        return;
                    }
                    /*var*/ let jsonString = await $.$mj.MJ.JSE.IA($.$$.S.S$1, this.JS, "localStorage.getItem", $.$$.SRC.RH.CA($.$typeOf($.$$.S.O), [ "All_Tasks" ], null, null));
                    if (!$.$$.S.S$1.INO(jsonString))
                    {
                        /*var*/ let savedTasks = $.$stj.STJ.JS.D$30($.$$.SCG.L$$($.$m.A), jsonString, null);
                        if (savedTasks !== null)
                        {
                            this.t$1 = savedTasks;
                        }
                    }
                    this.l = true;
                });
            }
            /*void */ TC(/*int*/ id)
            {
                //lock
                try
                {
                    $.$$.ST$1.M$1.E$3(this._)
                    {
                        /*var*/ let task = $.$sl.SL.E.FOD($.$m.A, this.t$1, new ($.$$.S.F$$$($.$m.A, $.$$.S.B$2))().$ctor(this,  (/*t*/ t) =>
                        {
                            return t.Id === id;
                        }, {"r":262145,"p":[{"n":"t","p":114724}],"n":"","d":2080804,"h":0,"f":1048578}));
                        const $t1 = task;
                        $.$ifnn($t1, ($t) => $t.IC = !task.IC);
                        this.ST();
                        this.L();
                        this.N();
                    }
                }
                finally
                {
                    $.$$.ST$1.M$1.E$4(this._)
                }
            }
            /*int */ GCC()
            {
                return $.$sl.SL.E.C$6($.$m.A, this.t$1, new ($.$$.S.F$$$($.$m.A, $.$$.S.B$2))().$ctor(this,  (/**/ t) =>
                {
                    return t.IC;
                }, {"r":262145,"p":[{"n":"t","p":114724}],"n":"","d":2080804,"h":0,"f":1048578}));
            }
            /*int */ GPC()
            {
                return $.$sl.SL.E.C$6($.$m.A, this.t$1, new ($.$$.S.F$$$($.$m.A, $.$$.S.B$2))().$ctor(this,  (/*t*/ t) =>
                {
                    return !t.IC;
                }, {"r":262145,"p":[{"n":"t","p":114724}],"n":"","d":2080804,"h":0,"f":1048578}));
            }
            //Generated interface implemetation for ITaskService.OnChange.add
            I$a()
            {
                return this.a(...arguments);
            }
            //Generated interface implemetation for ITaskService.OnChange.remove
            I$r()
            {
                return this.r(...arguments);
            }
            //Generated interface implemetation for ITaskService.OnChange
            ITaskService$O()
            {
                this.O;
            }
            //Generated interface implemetation for ITaskService.SaveTask()
            I$S()
            {
                return this.ST(...arguments);
            }
            //Generated interface implemetation for ITaskService.LoadTasks()
            I$L()
            {
                return this.L(...arguments);
            }
            //Generated interface implemetation for ITaskService.GetAll()
            I$G()
            {
                return this.GA(...arguments);
            }
            //Generated interface implemetation for ITaskService.Add(string, Priority)
            I$A()
            {
                return this.A(...arguments);
            }
            //Generated interface implemetation for ITaskService.MoveTask(string, Priority)
            I$M()
            {
                return this.MT(...arguments);
            }
            //Generated interface implemetation for ITaskService.Delete(int)
            I$D()
            {
                return this.D(...arguments);
            }
            //Generated interface implemetation for ITaskService.ClearAllTask()
            I$C()
            {
                return this.C(...arguments);
            }
            //Generated interface implemetation for ITaskService.ToggleCompleted(int)
            I$T()
            {
                return this.TC(...arguments);
            }
            //Generated interface implemetation for ITaskService.GetCompletedCount()
            I$GC()
            {
                return this.GCC(...arguments);
            }
            //Generated interface implemetation for ITaskService.GetPendingCount()
            I$GP()
            {
                return this.GPC(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this._ = new $.$$.S.O().$ctor();
                this.n = new $.$m.A().$ctor$1();
                this.t$1 = new ($.$$.SCG.L$$($.$m.A))().$ctor$1();
            }
            static $h = 2080804;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"n":"Notify","o":"N","d":2080804,"h":38656786468,"f":1},{"r":$.$$.SCG.L$$($.$m.A).$h,"n":"GetAll","o":"GA","d":2080804,"h":42951753764,"f":1},{"r":65537,"p":[{"n":"title","p":1310721},{"n":"priority","p":1949732}],"n":"Add","o":"A","d":2080804,"h":47246721060,"f":1},{"r":65537,"p":[{"n":"title","p":1310721},{"n":"priority","p":1949732}],"n":"MoveTask","o":"MT","d":2080804,"h":51541688356,"f":1},{"r":65537,"p":[{"n":"id","p":655361}],"n":"Delete","o":"D","d":2080804,"h":55836655652,"f":1},{"r":65537,"n":"ClearAllTask","o":"C","d":2080804,"h":60131622948,"f":1},{"r":133169153,"n":"SaveTask","o":"ST","d":2080804,"h":64426590244,"f":4097},{"r":133169153,"n":"LoadTasks","o":"L","d":2080804,"h":73016524836,"f":4097},{"r":65537,"p":[{"n":"id","p":655361}],"n":"ToggleCompleted","o":"TC","d":2080804,"h":77311492132,"f":1},{"r":655361,"n":"GetCompletedCount","o":"GCC","d":2080804,"h":81606459428,"f":1},{"r":655361,"n":"GetPendingCount","o":"GPC","d":2080804,"h":85901426724,"f":1}],"l":[{"t":524318,"n":"JS","d":2080804,"h":4297048100,"f":2},{"t":131073,"n":"_lock","o":"_","d":2080804,"h":12886982692,"f":2},{"t":114724,"n":"newTask","o":"n","d":2080804,"h":17181949988,"f":1},{"t":$.$$.SCG.L$$($.$m.A).$h,"n":"tasks","o":"t$1","d":2080804,"h":21476917284,"f":1},{"t":262145,"n":"loaded","o":"l","d":2080804,"h":68721557540,"f":2}],"c":[{"p":[{"n":"jS","p":524318}],"n":".ctor","o":"$ctor$1","d":2080804,"h":8592015396,"f":1}],"e":[{"e":11730945,"m":{"r":65537,"p":[{"n":"value","p":11730945}],"n":"add_OnChange","o":"a","d":2080804,"h":25771884580,"f":1},"r":{"r":65537,"p":[{"n":"value","p":11730945}],"n":"remove_OnChange","o":"r","d":2080804,"h":30066851876,"f":1},"n":"OnChange","o":"O","d":2080804,"h":34361819172,"f":1}],"i":[180260],"h":2080804}; }
            static get $b() { return $.$$.S.O; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$m.I ]; }
            static get $fullName() { return `TaskService`; }
        });
        
        $asm.$cls("$m.MC.E", ($self) => class EmbeddedAttribute extends $.$$.S.A$1
        {
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 245796;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"c":[{"n":".ctor","o":"$ctor$2","d":245796,"h":4295213092,"f":1}],"h":245796}; }
            static get $b() { return $.$$.S.A$1; }
            static get $fullName() { return `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
        });
        
        $asm.$cls("$m.MEVE.V", ($self) => class ValidatableTypeAttribute extends $.$$.S.A$1
        {
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 311332;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"c":[{"n":".ctor","o":"$ctor$2","d":311332,"h":4295278628,"f":1}],"h":311332,"a":[{"t":245796,"c":4295213092},{"t":14745601,"c":21489582081,"a":[{"v":4,"t":14680065}]}]}; }
            static get $b() { return $.$$.S.A$1; }
            static get $fullName() { return `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
        });
        
        $asm.$cls("$m.mC.NF", ($self) => class NotFound extends $.$mac.MAC.CB
        {
            /*void */ B(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.AM(0, "<h3>Not Found</h3>\n");
                __builder.AM(1, "<p>Sorry, the content you are looking for does not exist.</p>");
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 901156;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","o":"B","d":901156,"h":4295868452,"f":32772}],"c":[{"n":".ctor","o":"$ctor$2","d":901156,"h":8590835748,"f":1}],"i":[2752520,3145736,3080200],"h":901156,"a":[{"t":4587528,"c":4299554824,"a":[{"v":1687588,"t":142475265}]},{"t":9895944,"c":4304863240,"a":[{"v":"/not-found","t":1310721}]}]}; }
            static get $b() { return $.$mac.MAC.CB; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IC, $.$mac.MAC.IHE, $.$mac.MAC.IH ]; }
            static get $fullName() { return `miniapp.Components.NotFound`; }
        });
        
        $asm.$cls("$m.mC.L", ($self) => class LoadingCardMajor extends $.$mac.MAC.CB
        {
            /*void */ B(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.AM(0, "<div style=\"margin-bottom: 20px;\"><div style=\"width: 100%; height: 30px; border-radius: 20px; background: rgb(127, 127, 127, 0.2); margin-bottom: 5px;\"></div>\n    <div style=\"width: 100%; height: 30px; border-radius: 20px; background: rgb(127, 127, 127, 0.2); margin-bottom: 5px;\"></div>\n    <div style=\"width: 100%; height: 30px; border-radius: 20px; background: rgb(127, 127, 127, 0.2); margin-bottom: 5px;\"></div>\n    <div style=\"width: 100%; height: 30px; border-radius: 20px; background: rgb(127, 127, 127, 0.2); margin-bottom: 5px;\"></div>\n    <div style=\"width: 100%; height: 30px; border-radius: 20px; background: rgb(127, 127, 127, 0.2); margin-bottom: 5px;\"></div>\n    <div style=\"width: 100%; height: 30px; border-radius: 20px; background: rgb(127, 127, 127, 0.2); margin-bottom: 5px;\"></div>\n    <div style=\"width: 100%; height: 30px; border-radius: 20px; background: rgb(127, 127, 127, 0.2);\"></div></div>\n");
                __builder.OE(1, "p");
                __builder.AC$3(2, this.L);
                __builder.CE();
            }
            /*string*/ L = null;
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.L = "";
            }
            static $h = 704548;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17180573732,"f":1},"s":{"r":0,"d":0,"h":21475541028,"f":1},"n":"LoadingState","o":"L","d":704548,"h":12885606436,"f":1,"a":[{"t":5636104,"c":21480472584}]}],"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","o":"B","d":704548,"h":4295671844,"f":32772}],"c":[{"n":".ctor","o":"$ctor$2","d":704548,"h":25770508324,"f":1}],"i":[2752520,3145736,3080200],"h":704548}; }
            static get $b() { return $.$mac.MAC.CB; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IC, $.$mac.MAC.IHE, $.$mac.MAC.IH ]; }
            static get $fullName() { return `miniapp.Components.LoadingCardMajor`; }
        });
        
        $asm.$cls("$m.mC.B", ($self) => class ButtonCard extends $.$mac.MAC.CB
        {
            /*void */ B(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OE(0, "button");
                __builder.AA$6($.$macw.MACW.ME, 1, "onclick", $.$mac.MAC.EC$1.F$1.C$7($.$macw.MACW.ME, this, new ($.$$.S.F$$($.$$.STT.T))().$ctor(this, this.H)));
                __builder.AA$2(2, "style", "background:" + " " + (this.BC) + ";" + " padding:" + " 10px" + " 20px;" + " border:" + " none;" + " border-radius:" + " 10px;");
                __builder.AC$3(3, this.BT);
                __builder.CE();
            }
            /*bool*/ CC = false;
            /*string*/ BC = null;
            /*string*/ BT = null;
            /*EventCallback*/ OC;
            /*Task *//*async*/  H()
            {
                return $.$$.N.AR.A($.$$.STT.T, $.$$.S.V$2, async () => 
                {
                    await this.OC.IA();
                });
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.CC = false;
                this.BC = "";
                this.BT = "";
                this.OC = $.$default($.$mac.MAC.EC$1);
            }
            static $h = 573476;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17180442660,"f":1},"s":{"r":0,"d":0,"h":21475409956,"f":1},"n":"ConfirmClear","o":"CC","d":573476,"h":12885475364,"f":1,"a":[{"t":5636104,"c":21480472584}]},{"p":1310721,"g":{"r":0,"d":0,"h":34360311844,"f":1},"s":{"r":0,"d":0,"h":38655279140,"f":1},"n":"BgColor","o":"BC","d":573476,"h":30065344548,"f":1,"a":[{"t":5636104,"c":21480472584}]},{"p":1310721,"g":{"r":0,"d":0,"h":51540181028,"f":1},"s":{"r":0,"d":0,"h":55835148324,"f":1},"n":"BtnText","o":"BT","d":573476,"h":47245213732,"f":1,"a":[{"t":5636104,"c":21480472584}]},{"p":2097160,"g":{"r":0,"d":0,"h":68720050212,"f":1},"s":{"r":0,"d":0,"h":73015017508,"f":1},"n":"OnClick","o":"OC","d":573476,"h":64425082916,"f":1,"a":[{"t":5636104,"c":21480472584}]}],"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","o":"B","d":573476,"h":4295540772,"f":32772},{"r":133169153,"n":"HandleClick","o":"H","d":573476,"h":77309984804,"f":4098}],"c":[{"n":".ctor","o":"$ctor$2","d":573476,"h":81604952100,"f":1}],"i":[2752520,3145736,3080200],"h":573476}; }
            static get $b() { return $.$mac.MAC.CB; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IC, $.$mac.MAC.IHE, $.$mac.MAC.IH ]; }
            static get $fullName() { return `miniapp.Components.ButtonCard`; }
        });
        
        $asm.$cls("$m.mC.LC", ($self) => class LoadingCardMinor extends $.$mac.MAC.CB
        {
            /*void */ B(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OE(0, "div");
                __builder.AA$2(1, "style", "margin-bottom: 20px;");
                __builder.AM(2, "<div style=\"width: 100%; margin: 20px 0 0; align-items: center; justify-content: center; margin-bottom: 50px;\"><div style=\"margin-bottom: 0;\"><div style=\"width: 100%; height: 30px; border-radius: 20px; background: rgb(127, 127, 127, 0.2); margin-bottom: 5px;\"></div>\n            <div style=\"width: 100%; height: 30px; border-radius: 20px; background: rgb(127, 127, 127, 0.2); margin-bottom: 5px;\"></div>\n            <div style=\"width: 100%; height: 30px; border-radius: 20px; background: rgb(127, 127, 127, 0.2);\"></div></div></div>\n    ");
                __builder.OE(3, "p");
                __builder.AC$3(4, this.L);
                __builder.CE();
                __builder.CE();
            }
            /*string*/ L = null;
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.L = "";
            }
            static $h = 770084;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17180639268,"f":1},"s":{"r":0,"d":0,"h":21475606564,"f":1},"n":"LoadingState","o":"L","d":770084,"h":12885671972,"f":1,"a":[{"t":5636104,"c":21480472584}]}],"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","o":"B","d":770084,"h":4295737380,"f":32772}],"c":[{"n":".ctor","o":"$ctor$2","d":770084,"h":25770573860,"f":1}],"i":[2752520,3145736,3080200],"h":770084}; }
            static get $b() { return $.$mac.MAC.CB; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IC, $.$mac.MAC.IHE, $.$mac.MAC.IH ]; }
            static get $fullName() { return `miniapp.Components.LoadingCardMinor`; }
        });
        
        $asm.$cls("$m.mL.R", ($self) => class ReconnectModal extends $.$mac.MAC.CB
        {
            /*void */ B(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OE(0, "script");
                __builder.AA$2(1, "type", "module");
                __builder.AA$2(2, "src", this.A.g_I$1("Components/Layout/ReconnectModal.razor.js"));
                __builder.AA$4(3, "b-uxhtpx25is");
                __builder.CE();
                __builder.AM(4, "\n\n");
                __builder.AM(5, "<dialog id=\"components-reconnect-modal\" data-nosnippet b-uxhtpx25is><div class=\"components-reconnect-container\" b-uxhtpx25is><div class=\"components-rejoining-animation\" aria-hidden=\"true\" b-uxhtpx25is><div b-uxhtpx25is></div>\n            <div b-uxhtpx25is></div></div>\n        <p class=\"components-reconnect-first-attempt-visible\" b-uxhtpx25is>\n            Rejoining the server...\n        </p>\n        <p class=\"components-reconnect-repeated-attempt-visible\" b-uxhtpx25is>\n            Rejoin failed... trying again in <span id=\"components-seconds-to-next-attempt\" b-uxhtpx25is></span> seconds.\n        </p>\n        <p class=\"components-reconnect-failed-visible\" b-uxhtpx25is>\n            Failed to rejoin.<br b-uxhtpx25is>Please retry or reload the page.\n        </p>\n        <button id=\"components-reconnect-button\" class=\"components-reconnect-failed-visible\" b-uxhtpx25is>\n            Retry\n        </button>\n        <p class=\"components-pause-visible\" b-uxhtpx25is>\n            The session has been paused by the server.\n        </p>\n        <button id=\"components-resume-button\" class=\"components-pause-visible\" b-uxhtpx25is>\n            Resume\n        </button>\n        <p class=\"components-resume-failed-visible\" b-uxhtpx25is>\n            Failed to resume the session.<br b-uxhtpx25is>Please reload the page.\n        </p></div></dialog>");
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 1818660;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","o":"B","d":1818660,"h":4296785956,"f":32772}],"c":[{"n":".ctor","o":"$ctor$2","d":1818660,"h":8591753252,"f":1}],"i":[2752520,3145736,3080200],"h":1818660}; }
            static get $b() { return $.$mac.MAC.CB; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IC, $.$mac.MAC.IHE, $.$mac.MAC.IH ]; }
            static get $fullName() { return `miniapp.Layout.ReconnectModal`; }
        });
        
        $asm.$cls("$m.mC.S", ($self) => class SignUpSuccess extends $.$mac.MAC.CB
        {
            /*void */ B(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                if (this.iL)
                {
                    __builder.OE(0, "div");
                    __builder.AA$2(1, "style", "display: flex;; width: 100%; height: 100vh; align-items: center; justify-content: center; font-size: 30px;");
                    __builder.OC($.$m.mC.L, 2);
                    __builder.AC(3, "LoadingState", "\u23F3 creating user account...");
                    __builder.CC();
                    __builder.CE();
                }
                else 
                {
                    __builder.OE(4, "div");
                    __builder.AA$2(5, "style", "display: flex;; width: 100%; height: 100vh; align-items: center; justify-content: center;");
                    __builder.OC($.$m.mC.NL, 6);
                    __builder.AC(7, "Title", "Account created successful...");
                    __builder.AC(8, "SubTitle", "Continue to login...");
                    __builder.CC();
                    __builder.CE();
                }
            }
            /*bool*/ iL = true;
            /*Task *//*async*/  OIA()
            {
                return $.$$.N.AR.A($.$$.STT.T, $.$$.S.V$2, async () => 
                {
                    this.iL = true;
                    await $.$$.STT.T.D$2(4000);
                    this.iL = false;
                });
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 1490980;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","o":"B","d":1490980,"h":4296458276,"f":32772},{"r":133169153,"n":"OnInitializedAsync","o":"OIA","d":1490980,"h":12886392868,"f":36868}],"l":[{"t":262145,"n":"isLoading","o":"iL","d":1490980,"h":8591425572,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":1490980,"h":17181360164,"f":1}],"i":[2752520,3145736,3080200],"h":1490980,"a":[{"t":9895944,"c":4304863240,"a":[{"v":"/signupsuccess","t":1310721}]}]}; }
            static get $b() { return $.$mac.MAC.CB; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IC, $.$mac.MAC.IHE, $.$mac.MAC.IH ]; }
            static get $fullName() { return `miniapp.Components.SignUpSuccess`; }
        });
        
        $asm.$cls("$m.mC.NL", ($self) => class NotLoginCard extends $.$mac.MAC.CB
        {
            /*void */ B(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OE(0, "div");
                __builder.AA$2(1, "style", "width: 100%; height: 30vh; font-size: 20px; display: flex; align-items: center; justify-content: center; text-align: center;");
                __builder.OE(2, "div");
                __builder.OE(3, "p");
                __builder.AC$3(4, this.T$1);
                __builder.CE();
                __builder.AM(5, "\n        ");
                __builder.OE(6, "p");
                __builder.OC($.$macw.MACR$2.NL$1, 7);
                __builder.AC(8, "style", "text-decoration: none; color: white; background: rgb(133, 0, 133, 0.3); padding: 10px 20px; border-radius: 10px; font-weight: bold; font-size: 15px;");
                __builder.AC(9, "href", "/");
                __builder.AC(10, "Match", $.$box($.$mac.MACC.R.TC($.$macw.MACR$2.NLM, 1/*NavLinkMatch.All*/), $.$macw.MACR$2.NLM));
                __builder.AA(11, "ChildContent", new $.$mac.MAC.RF().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.AM(12, "\uD83D\uDEAA Login");
                })));
                __builder.CC();
                __builder.AM(13, "\n            ");
                __builder.AC$3(14, this.ST);
                __builder.CE();
                __builder.CE();
                __builder.CE();
            }
            /*string*/ T$1 = null;
            /*string*/ ST = null;
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.T$1 = "";
                this.ST = "";
            }
            static $h = 966692;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17180835876,"f":1},"s":{"r":0,"d":0,"h":21475803172,"f":1},"n":"Title","o":"T$1","d":966692,"h":12885868580,"f":1,"a":[{"t":5636104,"c":21480472584}]},{"p":1310721,"g":{"r":0,"d":0,"h":34360705060,"f":1},"s":{"r":0,"d":0,"h":38655672356,"f":1},"n":"SubTitle","o":"ST","d":966692,"h":30065737764,"f":1,"a":[{"t":5636104,"c":21480472584}]}],"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","o":"B","d":966692,"h":4295933988,"f":32772}],"c":[{"n":".ctor","o":"$ctor$2","d":966692,"h":42950639652,"f":1}],"i":[2752520,3145736,3080200],"h":966692}; }
            static get $b() { return $.$mac.MAC.CB; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IC, $.$mac.MAC.IHE, $.$mac.MAC.IH ]; }
            static get $fullName() { return `miniapp.Components.NotLoginCard`; }
        });
        
        $asm.$cls("$m.mC.D", ($self) => class DeleteAccountPage extends $.$mac.MAC.CB
        {
            /*void */ B(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                if (this.iL)
                {
                    __builder.OE(0, "div");
                    __builder.AA$2(1, "style", "display: flex;; width: 100%; height: 100vh; align-items: center; justify-content: center; font-size: 30px;");
                    __builder.OC($.$m.mC.L, 2);
                    __builder.AC(3, "LoadingState", "\u23F3 deleting user account...");
                    __builder.CC();
                    __builder.CE();
                }
                else 
                {
                    __builder.OE(4, "div");
                    __builder.AA$2(5, "style", "display: flex;; width: 100%; height: 100vh; align-items: center; justify-content: center;");
                    __builder.OC($.$m.mC.NL, 6);
                    __builder.AC(7, "Title", "Account deleted successful...");
                    __builder.AC(8, "SubTitle", "Click to login...");
                    __builder.CC();
                    __builder.CE();
                }
            }
            /*bool*/ iL = true;
            /*Task *//*async*/  OIA()
            {
                return $.$$.N.AR.A($.$$.STT.T, $.$$.S.V$2, async () => 
                {
                    this.iL = true;
                    await $.$$.STT.T.D$2(4000);
                    this.iL = false;
                });
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 639012;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","o":"B","d":639012,"h":4295606308,"f":32772},{"r":133169153,"n":"OnInitializedAsync","o":"OIA","d":639012,"h":12885540900,"f":36868}],"l":[{"t":262145,"n":"isLoading","o":"iL","d":639012,"h":8590573604,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":639012,"h":17180508196,"f":1}],"i":[2752520,3145736,3080200],"h":639012,"a":[{"t":9895944,"c":4304863240,"a":[{"v":"/deleteacc","t":1310721}]}]}; }
            static get $b() { return $.$mac.MAC.CB; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IC, $.$mac.MAC.IHE, $.$mac.MAC.IH ]; }
            static get $fullName() { return `miniapp.Components.DeleteAccountPage`; }
        });
        
        $asm.$cls("$m.mC.SC", ($self) => class StatCard extends $.$mac.MAC.CB
        {
            /*void */ B(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OE(0, "div");
                __builder.AA$2(1, "class", "stat-container");
                __builder.AA$4(2, "b-85yfc36wqj");
                __builder.OE(3, "div");
                __builder.AA$2(4, "class", "label");
                __builder.AA$4(5, "b-85yfc36wqj");
                __builder.OE(6, "p");
                __builder.AA$4(7, "b-85yfc36wqj");
                __builder.AC$3(8, this.I$2);
                __builder.CE();
                __builder.AM(9, "\n        ");
                __builder.OE(10, "p");
                __builder.AA$4(11, "b-85yfc36wqj");
                __builder.AC$3(12, this.L);
                __builder.CE();
                __builder.CE();
                __builder.AM(13, "\n    ");
                __builder.OE(14, "p");
                __builder.AA$2(15, "class", "value");
                __builder.AA$4(16, "b-85yfc36wqj");
                __builder.AC$3(17, this.V);
                __builder.CE();
                __builder.CE();
            }
            /*string*/ I$2 = null;
            /*string*/ L = null;
            /*string*/ V = null;
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.I$2 = "";
                this.L = "";
                this.V = "";
            }
            static $h = 1556516;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17181425700,"f":1},"s":{"r":0,"d":0,"h":21476392996,"f":1},"n":"Icon","o":"I$2","d":1556516,"h":12886458404,"f":1,"a":[{"t":5636104,"c":21480472584}]},{"p":1310721,"g":{"r":0,"d":0,"h":34361294884,"f":1},"s":{"r":0,"d":0,"h":38656262180,"f":1},"n":"Label","o":"L","d":1556516,"h":30066327588,"f":1,"a":[{"t":5636104,"c":21480472584}]},{"p":1310721,"g":{"r":0,"d":0,"h":51541164068,"f":1},"s":{"r":0,"d":0,"h":55836131364,"f":1},"n":"Value","o":"V","d":1556516,"h":47246196772,"f":1,"a":[{"t":5636104,"c":21480472584}]}],"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","o":"B","d":1556516,"h":4296523812,"f":32772}],"c":[{"n":".ctor","o":"$ctor$2","d":1556516,"h":60131098660,"f":1}],"i":[2752520,3145736,3080200],"h":1556516}; }
            static get $b() { return $.$mac.MAC.CB; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IC, $.$mac.MAC.IHE, $.$mac.MAC.IH ]; }
            static get $fullName() { return `miniapp.Components.StatCard`; }
        });
        
        $asm.$cls("$m.m.A", ($self) => class App extends $.$mac.MAC.CB
        {
            /*void */ B(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OC($.$mac.MACR$3.R$1, 0);
                __builder.AC(1, "AppAssembly", $.$mac.MACC.R.TC($.$$.SR.A, $.$m.m.A.$type.A));
                __builder.AC(2, "PreferExactMatches", $.$box(true, $.$$.S.B$2));
                __builder.AC(3, "NotFoundPage", $.$mac.MACC.R.TC($.$$.S.T$2, $.$m.mC.NF.$type));
                __builder.AA(4, "Found", new ($.$mac.MAC.R$$($.$mac.MAC.RD))().$ctor(this, ( (/**/ routeData) =>
                {
                    return new $.$mac.MAC.RF().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OC($.$mac.MAC.RV, 5);
                        __builder2.AC(6, "RouteData", $.$mac.MACC.R.TC($.$mac.MAC.RD, routeData));
                        __builder2.AC(7, "DefaultLayout", $.$mac.MACC.R.TC($.$$.S.T$2, $.$m.mL.M.$type));
                        __builder2.CC();
                        __builder2.AM(8, "\n        ");
                        __builder2.OC($.$macw.MACR$2.F, 9);
                        __builder2.AC(10, "RouteData", $.$mac.MACC.R.TC($.$mac.MAC.RD, routeData));
                        __builder2.AC(11, "Selector", "h1");
                        __builder2.CC();
                    }, {"r":65537,"p":[{"n":"__builder2","p":7536648}],"n":"","d":442404,"h":0,"f":1048578});
                })));
                __builder.CC();
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 442404;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","o":"B","d":442404,"h":4295409700,"f":32772}],"c":[{"n":".ctor","o":"$ctor$2","d":442404,"h":8590376996,"f":1}],"i":[2752520,3145736,3080200],"h":442404}; }
            static get $b() { return $.$mac.MAC.CB; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IC, $.$mac.MAC.IHE, $.$mac.MAC.IH ]; }
            static get $fullName() { return `miniapp.App`; }
        });
        
        $asm.$cls("$m.mL.N", ($self) => class NavMenu extends $.$mac.MAC.CB
        {
            /*void */ B(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OE(0, "div");
                __builder.AA$2(1, "class", "top-row ps-3 navbar navbar-dark");
                __builder.AA$4(2, "b-2ys3sctjtr");
                __builder.OE(3, "div");
                __builder.AA$2(4, "class", "container-fluid");
                __builder.AA$4(5, "b-2ys3sctjtr");
                __builder.AM(6, "<a class=\"navbar-brand\" href b-2ys3sctjtr>miniapp</a>\n        ");
                __builder.OE(7, "button");
                __builder.AA$2(8, "title", "Navigation menu");
                __builder.AA$2(9, "class", "navbar-toggler");
                __builder.AA$6($.$macw.MACW.ME, 10, "onclick", $.$mac.MAC.EC$1.F$1.C$5($.$macw.MACW.ME, this, new $.$$.S.A$2().$ctor(this, this.TN)));
                __builder.AA$4(11, "b-2ys3sctjtr");
                __builder.AM(12, "<span class=\"navbar-toggler-icon\" b-2ys3sctjtr></span>");
                __builder.CE();
                __builder.CE();
                __builder.CE();
                __builder.AM(13, "\n\n");
                __builder.OE(14, "div");
                __builder.AA$2(15, "class", (this.N) + " nav-scrollable");
                __builder.AA$6($.$macw.MACW.ME, 16, "onclick", $.$mac.MAC.EC$1.F$1.C$5($.$macw.MACW.ME, this, new $.$$.S.A$2().$ctor(this, this.TN)));
                __builder.AA$4(17, "b-2ys3sctjtr");
                __builder.OE(18, "nav");
                __builder.AA$2(19, "class", "nav flex-column");
                __builder.AA$4(20, "b-2ys3sctjtr");
                __builder.OE(21, "div");
                __builder.AA$2(22, "class", "nav-item px-3");
                __builder.AA$4(23, "b-2ys3sctjtr");
                __builder.OC($.$macw.MACR$2.NL$1, 24);
                __builder.AC(25, "class", "nav-link");
                __builder.AC(26, "href", "");
                __builder.AC(27, "Match", $.$box($.$mac.MACC.R.TC($.$macw.MACR$2.NLM, 1/*NavLinkMatch.All*/), $.$macw.MACR$2.NLM));
                __builder.AA(28, "ChildContent", new $.$mac.MAC.RF().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.AM(29, "<span class=\"bi bi-house-door-fill-nav-menu\" aria-hidden=\"true\" b-2ys3sctjtr></span> Home\n            ");
                })));
                __builder.CC();
                __builder.CE();
                __builder.AM(30, "\n        ");
                __builder.OE(31, "div");
                __builder.AA$2(32, "class", "nav-item px-3");
                __builder.AA$4(33, "b-2ys3sctjtr");
                __builder.OC($.$macw.MACR$2.NL$1, 34);
                __builder.AC(35, "class", "nav-link");
                __builder.AC(36, "href", "counter");
                __builder.AA(37, "ChildContent", new $.$mac.MAC.RF().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.AM(38, "<span class=\"bi bi-plus-square-fill-nav-menu\" aria-hidden=\"true\" b-2ys3sctjtr></span> Counter\n            ");
                })));
                __builder.CC();
                __builder.CE();
                __builder.AM(39, "\n        ");
                __builder.OE(40, "div");
                __builder.AA$2(41, "class", "nav-item px-3");
                __builder.AA$4(42, "b-2ys3sctjtr");
                __builder.OC($.$macw.MACR$2.NL$1, 43);
                __builder.AC(44, "class", "nav-link");
                __builder.AC(45, "href", "weather");
                __builder.AA(46, "ChildContent", new $.$mac.MAC.RF().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.AM(47, "<span class=\"bi bi-list-nested-nav-menu\" aria-hidden=\"true\" b-2ys3sctjtr></span> Weather\n            ");
                })));
                __builder.CC();
                __builder.CE();
                __builder.AM(48, "\n\n        ");
                __builder.OE(49, "div");
                __builder.AA$2(50, "class", "nav-item px-3");
                __builder.AA$4(51, "b-2ys3sctjtr");
                __builder.OC($.$macw.MACR$2.NL$1, 52);
                __builder.AC(53, "class", "nav-link");
                __builder.AC(54, "href", "login");
                __builder.AA(55, "ChildContent", new $.$mac.MAC.RF().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.AM(56, "<span class=\"bi bi-list-nested-nav-menu\" aria-hidden=\"true\" b-2ys3sctjtr></span> Login\n            ");
                })));
                __builder.CC();
                __builder.CE();
                __builder.CE();
                __builder.CE();
            }
            /*bool*/ cN = true;
            /*string? */ get N()
            {
                return this.cN ? "collapse" : null;
            }
            /*void */ TN()
            {
                this.cN = !this.cN;
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 1753124;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17181622308,"f":2},"n":"NavMenuCssClass","o":"N","d":1753124,"h":12886655012,"f":2}],"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","o":"B","d":1753124,"h":4296720420,"f":32772},{"r":65537,"n":"ToggleNavMenu","o":"TN","d":1753124,"h":21476589604,"f":2}],"l":[{"t":262145,"n":"collapseNavMenu","o":"cN","d":1753124,"h":8591687716,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":1753124,"h":25771556900,"f":1}],"i":[2752520,3145736,3080200],"h":1753124}; }
            static get $b() { return $.$mac.MAC.CB; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IC, $.$mac.MAC.IHE, $.$mac.MAC.IH ]; }
            static get $fullName() { return `miniapp.Layout.NavMenu`; }
        });
        
        $asm.$cls("$m.mC.R", ($self) => class Routes extends $.$mac.MAC.CB
        {
            /*void */ B(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OC($.$mac.MACR$3.R$1, 0);
                __builder.AC(1, "AppAssembly", $.$mac.MACC.R.TC($.$$.SR.A, $.$m.P.$type.A));
                __builder.AC(2, "NotFoundPage", $.$mac.MACC.R.TC($.$$.S.T$2, $.$m.mC.NF.$type));
                __builder.AA(3, "Found", new ($.$mac.MAC.R$$($.$mac.MAC.RD))().$ctor(this, ( (/**/ routeData) =>
                {
                    return new $.$mac.MAC.RF().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OC($.$mac.MAC.RV, 4);
                        __builder2.AC(5, "RouteData", $.$mac.MACC.R.TC($.$mac.MAC.RD, routeData));
                        __builder2.AC(6, "DefaultLayout", $.$mac.MACC.R.TC($.$$.S.T$2, $.$m.mL.M.$type));
                        __builder2.CC();
                        __builder2.AM(7, "\n        ");
                        __builder2.OC($.$macw.MACR$2.F, 8);
                        __builder2.AC(9, "RouteData", $.$mac.MACC.R.TC($.$mac.MAC.RD, routeData));
                        __builder2.AC(10, "Selector", "h1");
                        __builder2.CC();
                    }, {"r":65537,"p":[{"n":"__builder2","p":7536648}],"n":"","d":1359908,"h":0,"f":1048578});
                })));
                __builder.CC();
            }
            static $___;
            static get __()
            {
                let $cls = $.$m.mC.R;
                return $cls.$___ ??= $asm.$ncls("$m.mC.R.__", ($self) => class __PrivateComponentRenderModeAttribute extends $.$mac.MAC.RM
                {
                    static /*global::Microsoft.AspNetCore.Components.IComponentRenderMode */ get MI()
                    {
                        return $.$macw.MACW.R.IS;
                    }
                    /*global::Microsoft.AspNetCore.Components.IComponentRenderMode */ get M$1()
                    {
                        return $.$m.mC.R.__.MI;
                    }
                    //default reference type constructor overload
                    $ctor$3()
                    {
                        super.$ctor$2();
                        return this;
                    }
                    static $h = 1425444;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":7733256,"p":[{"p":2883592,"g":{"r":0,"d":0,"h":8591360036,"f":34},"n":"ModeImpl","o":"MI","d":1425444,"h":4296392740,"f":34},{"p":2883592,"g":{"r":0,"d":0,"h":17181294628,"f":32769},"n":"Mode","o":"M$1","d":1425444,"h":12886327332,"f":32769}],"c":[{"n":".ctor","o":"$ctor$3","d":1425444,"h":21476261924,"f":1}],"d":1359908,"h":1425444}; }
                    static get $b() { return $.$mac.MAC.RM; }
                    static get $fullName() { return `miniapp.Components.Routes.__PrivateComponentRenderModeAttribute`; }
                }, $cls, ($v) => $cls.$___ = $v);
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 1359908;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","o":"B","d":1359908,"h":4296327204,"f":32772}],"c":[{"n":".ctor","o":"$ctor$2","d":1359908,"h":12886261796,"f":1}],"i":[2752520,3145736,3080200],"j":[1425444],"h":1359908,"a":[{"t":1425444,"c":21476261924}]}; }
            static get $b() { return $.$mac.MAC.CB; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IC, $.$mac.MAC.IHE, $.$mac.MAC.IH ]; }
            static get $fullName() { return `miniapp.Components.Routes`; }
        });
        
        $asm.$cls("$m.mC.N", ($self) => class NavBar extends $.$mac.MAC.CB
        {
            /*void */ B(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OE(0, "nav");
                __builder.AA$2(1, "style", "display: flex; justify-content: space-around; margin-bottom: 20px;");
                __builder.AA$4(2, "b-ztl0h4or35");
                __builder.OE(3, "div");
                __builder.AA$2(4, "class", "mobile");
                __builder.AA$4(5, "b-ztl0h4or35");
                __builder.OC($.$macw.MACR$2.NL$1, 6);
                __builder.AC(7, "style", "text-decoration: none; color: white; font-weight: bold; font-size: 15px;");
                __builder.AC(8, "href", "/dashboard");
                __builder.AC(9, "Match", $.$box($.$mac.MACC.R.TC($.$macw.MACR$2.NLM, 1/*NavLinkMatch.All*/), $.$macw.MACR$2.NLM));
                __builder.AA(10, "ChildContent", new $.$mac.MAC.RF().$ctor(this, ( (/**/ __builder2) =>
                {
                    __builder2.AM(11, "\uD83C\uDFE0 Home");
                })));
                __builder.CC();
                __builder.CE();
                if ($.$$.S.S$1.o_E(this.A$1.R$1, "Admin"))
                {
                    __builder.OE(12, "div");
                    __builder.AA$2(13, "class", "mobile");
                    __builder.AA$4(14, "b-ztl0h4or35");
                    __builder.OC($.$macw.MACR$2.NL$1, 15);
                    __builder.AC(16, "style", "text-decoration: none; color: white; font-weight: bold; font-size: 15px;");
                    __builder.AC(17, "href", "/tasks");
                    __builder.AC(18, "Match", $.$box($.$mac.MACC.R.TC($.$macw.MACR$2.NLM, 1/*NavLinkMatch.All*/), $.$macw.MACR$2.NLM));
                    __builder.AA(19, "ChildContent", new $.$mac.MAC.RF().$ctor(this, ( (/**/ __builder2) =>
                    {
                        __builder2.AM(20, "\uD83D\uDCDD Tasks");
                    })));
                    __builder.CC();
                    __builder.CE();
                    __builder.AM(21, "\n        ");
                    __builder.OE(22, "div");
                    __builder.AA$2(23, "class", "mobile");
                    __builder.AA$4(24, "b-ztl0h4or35");
                    __builder.OC($.$macw.MACR$2.NL$1, 25);
                    __builder.AC(26, "style", "text-decoration: none; color: white; font-weight: bold; font-size: 15px;");
                    __builder.AC(27, "href", "/profile");
                    __builder.AC(28, "Match", $.$box($.$mac.MACC.R.TC($.$macw.MACR$2.NLM, 1/*NavLinkMatch.All*/), $.$macw.MACR$2.NLM));
                    __builder.AA(29, "ChildContent", new $.$mac.MAC.RF().$ctor(this, ( (/*__builder2*/ __builder2) =>
                    {
                        __builder2.AM(30, "\uD83D\uDC64 Profile");
                    })));
                    __builder.CC();
                    __builder.CE();
                }
                __builder.OE(31, "p");
                __builder.AA$2(32, "style", "text-decoration: none; color: white; font-weight: bold; font-size: 15px;");
                __builder.AA$4(33, "href");
                __builder.AA$2(34, "Match", "NavLinkMatch.All");
                __builder.AA$4(35, "b-ztl0h4or35");
                __builder.AM(36, "\uD83D\uDC64 ");
                __builder.AC$3(37, this.A$1.U);
                __builder.AM(38, " \uD83C\uDFF7\uFE0F ");
                __builder.AC$3(39, this.A$1.R$1);
                __builder.CE();
                if (this.A$1.IL)
                {
                    __builder.OE(40, "div");
                    __builder.AA$2(41, "class", "mobile");
                    __builder.AA$4(42, "b-ztl0h4or35");
                    __builder.OC($.$macw.MACR$2.NL$1, 43);
                    __builder.AC(44, "style", "text-decoration: none; color: white; font-weight: bold; font-size: 15px;");
                    __builder.AC(45, "href", "/");
                    __builder.AC(46, "onclick", $.$mac.MAC.EC$1.F$1.C$5($.$macw.MACW.ME, this, new $.$$.S.A$2().$ctor(this, this.LU)));
                    __builder.AC(47, "Match", $.$box($.$mac.MACC.R.TC($.$macw.MACR$2.NLM, 1/*NavLinkMatch.All*/), $.$macw.MACR$2.NLM));
                    __builder.AA(48, "ChildContent", new $.$mac.MAC.RF().$ctor(this, ( (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OC($.$m.mC.B, 49);
                        __builder2.AC(50, "BgColor", "white");
                        __builder2.AC(51, "BtnText", "\u232B Logout");
                        __builder2.AC(52, "OnClick", $.$mac.MACC.R.TC($.$mac.MAC.EC$1, $.$mac.MAC.EC$1.F$1.C(this, new $.$$.S.A$2().$ctor(this, this.LU))));
                        __builder2.CC();
                    })));
                    __builder.CC();
                    __builder.CE();
                }
                else 
                {
                    __builder.OE(53, "div");
                    __builder.AA$2(54, "class", "mobile");
                    __builder.AA$4(55, "b-ztl0h4or35");
                    __builder.OC($.$macw.MACR$2.NL$1, 56);
                    __builder.AC(57, "style", "text-decoration: none; color: white; font-weight: bold; font-size: 15px;");
                    __builder.AC(58, "href", "/");
                    __builder.AC(59, "onclick", $.$mac.MAC.EC$1.F$1.C$5($.$macw.MACW.ME, this, new $.$$.S.A$2().$ctor(this, this.LU)));
                    __builder.AC(60, "Match", $.$box($.$mac.MACC.R.TC($.$macw.MACR$2.NLM, 1/*NavLinkMatch.All*/), $.$macw.MACR$2.NLM));
                    __builder.AA(61, "ChildContent", new $.$mac.MAC.RF().$ctor(this, ( (/**/ __builder2) =>
                    {
                        __builder2.OC($.$m.mC.B, 62);
                        __builder2.AC(63, "BgColor", "white");
                        __builder2.AC(64, "BtnText", "\uD83D\uDEAA Login");
                        __builder2.AC(65, "OnClick", $.$mac.MACC.R.TC($.$mac.MAC.EC$1, $.$mac.MAC.EC$1.F$1.C(this, new $.$$.S.A$2().$ctor(this, this.L))));
                        __builder2.CC();
                    })));
                    __builder.CC();
                    __builder.CE();
                }
                __builder.CE();
            }
            /*void */ L()
            {
                this.N.N("/", false, false);
            }
            /*void */ LU()
            {
                this.A$1.L$2();
                this.N.N("/", false, false);
            }
            /*NavigationManager*/ N = null;
            /*miniapp.Services.AuthService*/ A$1 = null;
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.N = null;
                this.A$1 = null;
            }
            static $h = 835620;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":4980744,"g":{"r":0,"d":0,"h":25770639396,"f":2},"s":{"r":0,"d":0,"h":30065606692,"f":2},"n":"Nav","o":"N","d":835620,"h":21475672100,"f":2,"a":[{"t":4259848,"c":21479096328}]},{"p":1884196,"g":{"r":0,"d":0,"h":42950508580,"f":2},"s":{"r":0,"d":0,"h":47245475876,"f":2},"n":"Auth","o":"A$1","d":835620,"h":38655541284,"f":2,"a":[{"t":4259848,"c":21479096328}]}],"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","o":"B","d":835620,"h":4295802916,"f":32772},{"r":65537,"n":"LoginUser","o":"L","d":835620,"h":8590770212,"f":2},{"r":65537,"n":"LogoutUser","o":"LU","d":835620,"h":12885737508,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":835620,"h":51540443172,"f":1}],"i":[2752520,3145736,3080200],"h":835620}; }
            static get $b() { return $.$mac.MAC.CB; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IC, $.$mac.MAC.IHE, $.$mac.MAC.IH ]; }
            static get $fullName() { return `miniapp.Components.NavBar`; }
        });
        
        $asm.$cls("$m.mCP.L", ($self) => class Login extends $.$mac.MAC.CB
        {
            /*void */ B(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                if (this.iL)
                {
                    __builder.AM(0, "<p b-pkulom7sod>\u23F3 Loading...</p>");
                }
                else 
                {
                    __builder.OE(1, "div");
                    __builder.AA$2(2, "class", "login-container");
                    __builder.AA$4(3, "b-pkulom7sod");
                    __builder.AM(4, "<h3 b-pkulom7sod>Login</h3>\n        ");
                    __builder.OE(5, "div");
                    __builder.AA$2(6, "class", "sub-container");
                    __builder.AA$4(7, "b-pkulom7sod");
                    __builder.OE(8, "div");
                    __builder.AA$2(9, "class", "input-container");
                    __builder.AA$4(10, "b-pkulom7sod");
                    __builder.AM(11, "<label for=\"username\" b-pkulom7sod>Username</label>\n                ");
                    __builder.OE(12, "input");
                    __builder.AA$2(13, "type", "text");
                    __builder.AA$2(14, "placeholder", "enter username...");
                    __builder.AA$2(15, "value", $.$mac.MAC.B.FV$28(this.u, null));
                    __builder.AA$6($.$mac.MAC.CE, 16, "onchange", $.$mac.MAC.ECF.CB$27($.$mac.MAC.EC$1.F$1, this, new ($.$$.S.A$1$$($.$$.S.S$1))().$ctor(this,  (/**/ __value) =>
                    {
                        return this.u = __value;
                    }, {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1097764,"h":0,"f":1048578}), this.u, null));
                    __builder.SU("value");
                    __builder.AA$4(17, "b-pkulom7sod");
                    __builder.CE();
                    __builder.CE();
                    __builder.AM(18, "\n\n            ");
                    __builder.OE(19, "div");
                    __builder.AA$2(20, "class", "input-container");
                    __builder.AA$4(21, "b-pkulom7sod");
                    __builder.AM(22, "<label for=\"username\" b-pkulom7sod>Password</label>\n                ");
                    __builder.OE(23, "input");
                    __builder.AA$2(24, "type", "password");
                    __builder.AA$2(25, "placeholder", "enter password...");
                    __builder.AA$2(26, "value", $.$mac.MAC.B.FV$28(this.p$1, null));
                    __builder.AA$6($.$mac.MAC.CE, 27, "onchange", $.$mac.MAC.ECF.CB$27($.$mac.MAC.EC$1.F$1, this, new ($.$$.S.A$1$$($.$$.S.S$1))().$ctor(this,  (/*__value*/ __value) =>
                    {
                        return this.p$1 = __value;
                    }, {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1097764,"h":0,"f":1048578}), this.p$1, null));
                    __builder.SU("value");
                    __builder.AA$4(28, "b-pkulom7sod");
                    __builder.CE();
                    __builder.CE();
                    __builder.AM(29, "\n\n            ");
                    __builder.OE(30, "div");
                    __builder.AA$2(31, "class", "input-container");
                    __builder.AA$4(32, "b-pkulom7sod");
                    __builder.OE(33, "button");
                    __builder.AA$6($.$macw.MACW.ME, 34, "onclick", $.$mac.MAC.EC$1.F$1.C$5($.$macw.MACW.ME, this, new $.$$.S.A$2().$ctor(this, this.L)));
                    __builder.AA$4(35, "b-pkulom7sod");
                    __builder.AC$3(36, "Login");
                    __builder.CE();
                    __builder.CE();
                    if (!this.A$1.IL)
                    {
                        __builder.OE(37, "p");
                        __builder.AA$4(38, "b-pkulom7sod");
                        __builder.AC$3(39, this.e);
                        __builder.CE();
                    }
                    __builder.OE(40, "div");
                    __builder.AA$2(41, "class", "signup");
                    __builder.AA$4(42, "b-pkulom7sod");
                    __builder.AM(43, "<p b-pkulom7sod>Don't have an account?</p>\n                ");
                    __builder.OC($.$m.mC.B, 44);
                    __builder.AC(45, "BgColor", "rgb(127, 0, 127, 0.3)");
                    __builder.AC(46, "BtnText", "Sign Up");
                    __builder.AC(47, "OnClick", $.$mac.MACC.R.TC($.$mac.MAC.EC$1, $.$mac.MAC.EC$1.F$1.C(this, new $.$$.S.A$2().$ctor(this, this.SU))));
                    __builder.CC();
                    __builder.CE();
                    __builder.CE();
                    __builder.CE();
                }
            }
            /*string*/ u = null;
            /*string*/ p$1 = null;
            /*string*/ e = null;
            /*bool*/ iL = false;
            /*Task *//*async*/  OIA()
            {
                return $.$$.N.AR.A($.$$.STT.T, $.$$.S.V$2, async () => 
                {
                    this.iL = true;
                    await $.$$.STT.T.D$2(1000);
                    this.iL = false;
                });
            }
            /*Task *//*async*/  OA(/*bool*/ firstRender)
            {
                return $.$$.N.AR.A($.$$.STT.T, $.$$.S.V$2, async () => 
                {
                    if (firstRender)
                    {
                        await this.A$1.LU();
                    }
                });
            }
            /*void */ OI()
            {
                if (this.A$1.IL)
                {
                    this.N.N("/dashboard", false, false);
                }
            }
            /*void */ L()
            {
                /*bool*/ let success = this.A$1.L$1(this.u, this.p$1);
                if (success)
                {
                    this.N.N("/dashboard", false, false);
                }
                else 
                {
                    this.e = "\u26A0\uFE0F Username of Password is not correct";
                }
            }
            /*void */ SU()
            {
                this.N.N("/signup", false, false);
            }
            /*NavigationManager*/ N = null;
            /*miniapp.Services.AuthService*/ A$1 = null;
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.u = "";
                this.p$1 = "";
                this.e = "";
                this.N = null;
                this.A$1 = null;
            }
            static $h = 1097764;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":4980744,"g":{"r":0,"d":0,"h":55835672612,"f":2},"s":{"r":0,"d":0,"h":60130639908,"f":2},"n":"Nav","o":"N","d":1097764,"h":51540705316,"f":2,"a":[{"t":4259848,"c":21479096328}]},{"p":1884196,"g":{"r":0,"d":0,"h":73015541796,"f":2},"s":{"r":0,"d":0,"h":77310509092,"f":2},"n":"Auth","o":"A$1","d":1097764,"h":68720574500,"f":2,"a":[{"t":4259848,"c":21479096328}]}],"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","o":"B","d":1097764,"h":4296065060,"f":32772},{"r":133169153,"n":"OnInitializedAsync","o":"OIA","d":1097764,"h":25770901540,"f":36868},{"r":133169153,"p":[{"n":"firstRender","p":262145}],"n":"OnAfterRenderAsync","o":"OA","d":1097764,"h":30065868836,"f":36868},{"r":65537,"n":"OnInitialized","o":"OI","d":1097764,"h":34360836132,"f":32772},{"r":65537,"n":"LoginUser","o":"L","d":1097764,"h":38655803428,"f":2},{"r":65537,"n":"SignUp","o":"SU","d":1097764,"h":42950770724,"f":2}],"l":[{"t":1310721,"n":"username","o":"u","d":1097764,"h":8591032356,"f":2},{"t":1310721,"n":"password","o":"p$1","d":1097764,"h":12885999652,"f":2},{"t":1310721,"n":"errorMessage","o":"e","d":1097764,"h":17180966948,"f":2},{"t":262145,"n":"isLoading","o":"iL","d":1097764,"h":21475934244,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":1097764,"h":81605476388,"f":1}],"i":[2752520,3145736,3080200],"h":1097764,"a":[{"t":9895944,"c":4304863240,"a":[{"v":"/","t":1310721}]}]}; }
            static get $b() { return $.$mac.MAC.CB; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IC, $.$mac.MAC.IHE, $.$mac.MAC.IH ]; }
            static get $fullName() { return `miniapp.Components.Pages.Login`; }
        });
        
        $asm.$cls("$m.mCP.D", ($self) => class Dashboard extends $.$mac.MAC.CB
        {
            /*void */ B(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OC($.$m.mC.N, 0);
                __builder.CC();
                if (this.iL)
                {
                    __builder.OC($.$m.mC.L, 1);
                    __builder.AC(2, "LoadingState", "\u23F3 Loading Dashboard...");
                    __builder.CC();
                }
                else 
                {
                    __builder.OE(3, "div");
                    __builder.AM(4, "<h3>\uD83D\uDCCA Dashboard</h3>\n        ");
                    __builder.OE(5, "p");
                    __builder.AC$3(6, "Welcome back, ");
                    __builder.AC$3(7, this.A$1.U);
                    __builder.AM(8, " \uD83D\uDD90\uFE0F");
                    __builder.CE();
                    if (this.A$1.IL)
                    {
                        __builder.OE(9, "div");
                        __builder.AA$2(10, "style", "display: flex; gap: 10px; padding: 10px 0 30px;");
                        __builder.OC($.$m.mC.SC, 11);
                        __builder.AC(12, "Icon", "\uD83D\uDCDD");
                        __builder.AC(13, "Label", "Total");
                        __builder.AC(14, "Value", $.$mac.MACC.R.TC($.$$.S.S$1, this.tC));
                        __builder.CC();
                        __builder.AM(15, "\n                ");
                        __builder.OC($.$m.mC.SC, 16);
                        __builder.AC(17, "Icon", "\u2705");
                        __builder.AC(18, "Label", "Done");
                        __builder.AC(19, "Value", $.$mac.MACC.R.TC($.$$.S.S$1, this.cC));
                        __builder.CC();
                        __builder.AM(20, "\n                ");
                        __builder.OC($.$m.mC.SC, 21);
                        __builder.AC(22, "Icon", "\u23F3");
                        __builder.AC(23, "Label", "Left");
                        __builder.AC(24, "Value", $.$mac.MACC.R.TC($.$$.S.S$1, this.pC));
                        __builder.CC();
                        __builder.CE();
                    }
                    else 
                    {
                        __builder.OE(25, "div");
                        __builder.AA$2(26, "style", "display: flex; gap: 10px; padding: 10px 0 30px;");
                        __builder.OC($.$m.mC.SC, 27);
                        __builder.AC(28, "Icon", "\uD83D\uDCDD");
                        __builder.AC(29, "Label", "Total");
                        __builder.AC(30, "Value", "0");
                        __builder.CC();
                        __builder.AM(31, "\n                ");
                        __builder.OC($.$m.mC.SC, 32);
                        __builder.AC(33, "Icon", "\u2705");
                        __builder.AC(34, "Label", "Done");
                        __builder.AC(35, "Value", "0");
                        __builder.CC();
                        __builder.AM(36, "\n                ");
                        __builder.OC($.$m.mC.SC, 37);
                        __builder.AC(38, "Icon", "\u23F3");
                        __builder.AC(39, "Label", "Left");
                        __builder.AC(40, "Value", "0");
                        __builder.CC();
                        __builder.CE();
                    }
                    if ($.$$.S.S$1.o_E(this.A$1.R$1, "Admin"))
                    {
                        __builder.OE(41, "div");
                        __builder.AM(42, "<h5>\u2699\uFE0F Admin Panel</h5>\n                ");
                        __builder.OE(43, "div");
                        __builder.OC($.$m.mC.B, 44);
                        __builder.AC(45, "BgColor", "rgb(140, 0, 140, 0.3)");
                        __builder.AC(46, "BtnText", "\uD83D\uDCC1 Go to Tasks");
                        __builder.AC(47, "OnClick", $.$mac.MACC.R.TC($.$mac.MAC.EC$1, $.$mac.MAC.EC$1.F$1.C(this, new $.$$.S.A$2().$ctor(this, this.GTT))));
                        __builder.CC();
                        __builder.AM(48, "\n                    ");
                        __builder.OC($.$m.mC.B, 49);
                        __builder.AC(50, "BgColor", "rgb(135, 135, 135, 0.3)");
                        __builder.AC(51, "BtnText", "\uD83D\uDE4E\u200D\u2642\uFE0F View Profile");
                        __builder.AC(52, "OnClick", $.$mac.MACC.R.TC($.$mac.MAC.EC$1, $.$mac.MAC.EC$1.F$1.C(this, new $.$$.S.A$2().$ctor(this, this.V))));
                        __builder.CC();
                        __builder.CE();
                        __builder.CE();
                    }
                    __builder.CE();
                    if (!this.A$1.IL)
                    {
                        __builder.OC($.$m.mC.NL, 53);
                        __builder.AC(54, "Title", "User not logged in....");
                        __builder.AC(55, "SubTitle", "Click to login...");
                        __builder.CC();
                    }
                }
            }
            /*bool*/ iL = true;
            /*List<AppTask> */ get t$1()
            {
                return this.TS.I$G() ?? new ($.$$.SCG.L$$($.$m.A))().$ctor$1();
            }
            /*string */ get tC()
            {
                return $.$$.S.I$4.T.call(this.t$1.C$3);
            }
            /*string */ get cC()
            {
                return $.$$.S.I$4.T.call($.$sl.SL.E.C$6($.$m.A, this.t$1, new ($.$$.S.F$$$($.$m.A, $.$$.S.B$2))().$ctor(this,  (/*t*/ t) =>
                {
                    return t.IC;
                }, {"r":262145,"p":[{"n":"t","p":114724}],"n":"","d":1032228,"h":0,"f":1048578})));
            }
            /*string */ get pC()
            {
                return $.$$.S.I$4.T.call($.$sl.SL.E.C$6($.$m.A, this.t$1, new ($.$$.S.F$$$($.$m.A, $.$$.S.B$2))().$ctor(this,  (/*t*/ t) =>
                {
                    return !t.IC;
                }, {"r":262145,"p":[{"n":"t","p":114724}],"n":"","d":1032228,"h":0,"f":1048578})));
            }
            /*void */ GTT()
            {
                return this.N.N("/tasks", false, false);
            }
            /*void */ V()
            {
                return this.N.N("/profile", false, false);
            }
            /*Task *//*async*/  OIA()
            {
                return $.$$.N.AR.A($.$$.STT.T, $.$$.S.V$2, async () => 
                {
                    if (this.iL)
                    {
                        this.iL = true;
                        await $.$$.STT.T.D$2(1500);
                        this.iL = false;
                    }
                });
            }
            /*Task *//*async*/  OA(/*bool*/ firstRender)
            {
                return $.$$.N.AR.A($.$$.STT.T, $.$$.S.V$2, async () => 
                {
                    if (firstRender)
                    {
                        await this.TS.I$L();
                        this.SH();
                    }
                });
            }
            /*NavigationManager*/ N = null;
            /*ITaskService*/ TS = null;
            /*miniapp.Services.AuthService*/ A$1 = null;
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.N = null;
                this.TS = null;
                this.A$1 = null;
            }
            static $h = 1032228;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":$.$$.SCG.L$$($.$m.A).$h,"g":{"r":0,"d":0,"h":17180901412,"f":2},"n":"tasks","o":"t$1","d":1032228,"h":12885934116,"f":2},{"p":1310721,"g":{"r":0,"d":0,"h":25770836004,"f":2},"n":"tasksCount","o":"tC","d":1032228,"h":21475868708,"f":2},{"p":1310721,"g":{"r":0,"d":0,"h":34360770596,"f":2},"n":"completedCount","o":"cC","d":1032228,"h":30065803300,"f":2},{"p":1310721,"g":{"r":0,"d":0,"h":42950705188,"f":2},"n":"pendingCount","o":"pC","d":1032228,"h":38655737892,"f":2},{"p":4980744,"g":{"r":0,"d":0,"h":73015476260,"f":2},"s":{"r":0,"d":0,"h":77310443556,"f":2},"n":"Nav","o":"N","d":1032228,"h":68720508964,"f":2,"a":[{"t":4259848,"c":21479096328}]},{"p":180260,"g":{"r":0,"d":0,"h":90195345444,"f":2},"s":{"r":0,"d":0,"h":94490312740,"f":2},"n":"TaskService","o":"TS","d":1032228,"h":85900378148,"f":2,"a":[{"t":4259848,"c":21479096328}]},{"p":1884196,"g":{"r":0,"d":0,"h":107375214628,"f":2},"s":{"r":0,"d":0,"h":111670181924,"f":2},"n":"Auth","o":"A$1","d":1032228,"h":103080247332,"f":2,"a":[{"t":4259848,"c":21479096328}]}],"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","o":"B","d":1032228,"h":4295999524,"f":32772},{"r":65537,"n":"GoToTask","o":"GTT","d":1032228,"h":47245672484,"f":2},{"r":65537,"n":"ViewProfile","o":"V","d":1032228,"h":51540639780,"f":2},{"r":133169153,"n":"OnInitializedAsync","o":"OIA","d":1032228,"h":55835607076,"f":36868},{"r":133169153,"p":[{"n":"firstRender","p":262145}],"n":"OnAfterRenderAsync","o":"OA","d":1032228,"h":60130574372,"f":36868}],"l":[{"t":262145,"n":"isLoading","o":"iL","d":1032228,"h":8590966820,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":1032228,"h":115965149220,"f":1}],"i":[2752520,3145736,3080200],"h":1032228,"a":[{"t":9895944,"c":4304863240,"a":[{"v":"/dashboard","t":1310721}]}]}; }
            static get $b() { return $.$mac.MAC.CB; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IC, $.$mac.MAC.IHE, $.$mac.MAC.IH ]; }
            static get $fullName() { return `miniapp.Components.Pages.Dashboard`; }
        });
        
        $asm.$cls("$m.mC.T", ($self) => class TaskCard extends $.$mac.MAC.CB
        {
            /*void */ B(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OE(0, "table");
                __builder.AA$2(1, "class", "task-container mobile");
                __builder.AA$4(2, "b-vrvjdqy2df");
                __builder.OE(3, "tr");
                __builder.AA$2(4, "class", "tr");
                __builder.AA$4(5, "b-vrvjdqy2df");
                __builder.OE(6, "td");
                __builder.AA$2(7, "class", "td1");
                __builder.AA$4(8, "b-vrvjdqy2df");
                __builder.OE(9, "div");
                __builder.AA$6($.$macw.MACW.ME, 10, "onclick", $.$mac.MAC.EC$1.F$1.C$7($.$macw.MACW.ME, this, new ($.$$.S.F$$($.$$.STT.T))().$ctor(this,  () =>
                {
                    return this.OT.IA$1(this.T$1.Id);
                }, {"r":133169153,"n":"","d":1622052,"h":0,"f":1048578})));
                __builder.AA$2(11, "class", "container-title");
                __builder.AA$4(12, "b-vrvjdqy2df");
                __builder.OE(13, "p");
                __builder.AA$4(14, "b-vrvjdqy2df");
                __builder.OE(15, "input");
                __builder.AA$2(16, "type", "checkbox");
                __builder.A(17, "checked", $.$mac.MAC.B.FV(this.T$1.IC, null));
                __builder.AA$6($.$mac.MAC.CE, 18, "onchange", $.$mac.MAC.ECF.C($.$mac.MAC.EC$1.F$1, this, new ($.$$.S.A$1$$($.$$.S.B$2))().$ctor(this,  (/*__value*/ __value) =>
                {
                    return this.T$1.IC = __value;
                }, {"r":65537,"p":[{"n":"__value","p":262145}],"n":"","d":1622052,"h":0,"f":1048578}), this.T$1.IC, null));
                __builder.SU("checked");
                __builder.AA$4(19, "b-vrvjdqy2df");
                __builder.CE();
                __builder.CE();
                __builder.AM(20, "\n\n                ");
                __builder.OE(21, "p");
                __builder.AA$4(22, "b-vrvjdqy2df");
                __builder.AC$3(23, this.T$1.T$1);
                __builder.CE();
                __builder.CE();
                __builder.CE();
                __builder.AM(24, "\n        ");
                __builder.OE(25, "td");
                __builder.AA$2(26, "class", "td2");
                __builder.AA$4(27, "b-vrvjdqy2df");
                __builder.OE(28, "button");
                __builder.AA$4(29, "b-vrvjdqy2df");
                if (this.T$1.P$1 === 1/*Priority.Low*/)
                {
                    __builder.AM(30, "<span b-vrvjdqy2df><text b-vrvjdqy2df>\uD83D\uDD34</text></span>");
                }
                else if (this.T$1.P$1 === 2/*Priority.Medium*/)
                {
                    __builder.AM(31, "<span b-vrvjdqy2df><text b-vrvjdqy2df>\uD83D\uDFE1</text></span>");
                }
                else if (this.T$1.P$1 === 3/*Priority.High*/)
                {
                    __builder.AM(32, "<span b-vrvjdqy2df><text b-vrvjdqy2df>\uD83D\uDFE2</text></span>");
                }
                __builder.AC$2(33, $.$box(this.T$1.P$1, $.$m.P$1));
                __builder.CE();
                if (this.TI === this.T$1.Id)
                {
                    __builder.OE(34, "button");
                    __builder.AA$2(35, "style", "width: 200px; margin-left: 5px; transition: 0.3s ease-in");
                    __builder.AA$4(36, "b-vrvjdqy2df");
                    __builder.OE(37, "button");
                    __builder.AA$2(38, "style", "font-size: 12px; margin-right: 10px;");
                    __builder.AA$6($.$macw.MACW.ME, 39, "onclick", $.$mac.MAC.EC$1.F$1.C$7($.$macw.MACW.ME, this, new ($.$$.S.F$$($.$$.STT.T))().$ctor(this,  () =>
                    {
                        return this.OD.IA$1(this.T$1.Id);
                    }, {"r":133169153,"n":"","d":1622052,"h":0,"f":1048578})));
                    __builder.AA$4(40, "b-vrvjdqy2df");
                    __builder.AM(41, "\u2705 Confirm");
                    __builder.CE();
                    __builder.AM(42, "\n                    ");
                    __builder.OE(43, "button");
                    __builder.AA$2(44, "style", "font-size: 12px;");
                    __builder.AA$6($.$macw.MACW.ME, 45, "onclick", $.$mac.MAC.EC$1.F$1.C$5($.$macw.MACW.ME, this, new $.$$.S.A$2().$ctor(this,  () =>
                    {
                        return this.TI = null;
                    }, {"r":65537,"n":"","d":1622052,"h":0,"f":1048578})));
                    __builder.AA$4(46, "b-vrvjdqy2df");
                    __builder.AM(47, "\u274C Cancel");
                    __builder.CE();
                    __builder.CE();
                }
                else 
                {
                    __builder.OE(48, "button");
                    __builder.AA$6($.$macw.MACW.ME, 49, "onclick", $.$mac.MAC.EC$1.F$1.C$5($.$macw.MACW.ME, this, new $.$$.S.A$2().$ctor(this,  () =>
                    {
                        return this.TI = this.T$1.Id;
                    }, {"r":65537,"n":"","d":1622052,"h":0,"f":1048578})));
                    __builder.AA$4(50, "b-vrvjdqy2df");
                    __builder.AM(51, "\uD83D\uDDD1\uFE0F");
                    __builder.CE();
                }
                __builder.CE();
                __builder.CE();
                __builder.CE();
            }
            /*int?*/ TI = null;
            /*AppTask*/ T$1 = null;
            /*EventCallback<int>*/ OD;
            /*EventCallback<int>*/ OT;
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.TI = null;
                this.T$1 = new $.$m.A().$ctor$1();
                this.OD = $.$default($.$mac.MAC.E$$($.$$.S.I$4));
                this.OT = $.$default($.$mac.MAC.E$$($.$$.S.I$4));
            }
            static $h = 1622052;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":$.$typeNullable($.$$.S.I$4).$h,"g":{"r":0,"d":0,"h":17181491236,"f":1},"s":{"r":0,"d":0,"h":21476458532,"f":1},"n":"TaskIdToDelete","o":"TI","d":1622052,"h":12886523940,"f":1,"a":[{"t":5636104,"c":21480472584}]},{"p":114724,"g":{"r":0,"d":0,"h":34361360420,"f":1},"s":{"r":0,"d":0,"h":38656327716,"f":1},"n":"Task","o":"T$1","d":1622052,"h":30066393124,"f":1,"a":[{"t":5636104,"c":21480472584}]},{"p":$.$mac.MAC.E$$($.$$.S.I$4).$h,"g":{"r":0,"d":0,"h":51541229604,"f":1},"s":{"r":0,"d":0,"h":55836196900,"f":1},"n":"OnDelete","o":"OD","d":1622052,"h":47246262308,"f":1,"a":[{"t":5636104,"c":21480472584}]},{"p":$.$mac.MAC.E$$($.$$.S.I$4).$h,"g":{"r":0,"d":0,"h":68721098788,"f":1},"s":{"r":0,"d":0,"h":73016066084,"f":1},"n":"OnToggle","o":"OT","d":1622052,"h":64426131492,"f":1,"a":[{"t":5636104,"c":21480472584}]}],"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","o":"B","d":1622052,"h":4296589348,"f":32772}],"c":[{"n":".ctor","o":"$ctor$2","d":1622052,"h":77311033380,"f":1}],"i":[2752520,3145736,3080200],"h":1622052}; }
            static get $b() { return $.$mac.MAC.CB; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IC, $.$mac.MAC.IHE, $.$mac.MAC.IH ]; }
            static get $fullName() { return `miniapp.Components.TaskCard`; }
        });
        
        $asm.$cls("$m.mCP.S", ($self) => class SignUp extends $.$mac.MAC.CB
        {
            /*void */ B(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                if (this.iL)
                {
                    __builder.AM(0, "<p b-4y7dh9dpok>\u23F3 Loading...</p>");
                }
                else 
                {
                    __builder.OE(1, "div");
                    __builder.AA$2(2, "class", "login-container");
                    __builder.AA$4(3, "b-4y7dh9dpok");
                    __builder.AM(4, "<h3 b-4y7dh9dpok>Sign Up</h3>\n        ");
                    __builder.OE(5, "div");
                    __builder.AA$2(6, "class", "sub-container");
                    __builder.AA$4(7, "b-4y7dh9dpok");
                    __builder.OE(8, "div");
                    __builder.AA$2(9, "class", "input-container");
                    __builder.AA$4(10, "b-4y7dh9dpok");
                    __builder.AM(11, "<label for=\"username\" b-4y7dh9dpok>Firstname</label>\n                ");
                    __builder.OE(12, "input");
                    __builder.AA$2(13, "type", "text");
                    __builder.AA$2(14, "placeholder", "enter firstname...");
                    __builder.AA$2(15, "value", $.$mac.MAC.B.FV$28(this.f$1, null));
                    __builder.AA$6($.$mac.MAC.CE, 16, "onchange", $.$mac.MAC.ECF.CB$27($.$mac.MAC.EC$1.F$1, this, new ($.$$.S.A$1$$($.$$.S.S$1))().$ctor(this,  (/**/ __value) =>
                    {
                        return this.f$1 = __value;
                    }, {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1228836,"h":0,"f":1048578}), this.f$1, null));
                    __builder.SU("value");
                    __builder.AA$4(17, "b-4y7dh9dpok");
                    __builder.CE();
                    __builder.CE();
                    __builder.AM(18, "\n\n            ");
                    __builder.OE(19, "div");
                    __builder.AA$2(20, "class", "input-container");
                    __builder.AA$4(21, "b-4y7dh9dpok");
                    __builder.AM(22, "<label for=\"username\" b-4y7dh9dpok>Lastname</label>\n                ");
                    __builder.OE(23, "input");
                    __builder.AA$2(24, "type", "text");
                    __builder.AA$2(25, "placeholder", "enter lastname...");
                    __builder.AA$2(26, "value", $.$mac.MAC.B.FV$28(this.l, null));
                    __builder.AA$6($.$mac.MAC.CE, 27, "onchange", $.$mac.MAC.ECF.CB$27($.$mac.MAC.EC$1.F$1, this, new ($.$$.S.A$1$$($.$$.S.S$1))().$ctor(this,  (/*__value*/ __value) =>
                    {
                        return this.l = __value;
                    }, {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1228836,"h":0,"f":1048578}), this.l, null));
                    __builder.SU("value");
                    __builder.AA$4(28, "b-4y7dh9dpok");
                    __builder.CE();
                    __builder.CE();
                    __builder.AM(29, "\n\n            ");
                    __builder.OE(30, "div");
                    __builder.AA$2(31, "class", "input-container");
                    __builder.AA$4(32, "b-4y7dh9dpok");
                    __builder.AM(33, "<label for=\"username\" b-4y7dh9dpok>Email</label>\n                ");
                    __builder.OE(34, "input");
                    __builder.AA$2(35, "type", "email");
                    __builder.AA$2(36, "placeholder", "enter email...");
                    __builder.AA$2(37, "value", $.$mac.MAC.B.FV$28(this.e, null));
                    __builder.AA$6($.$mac.MAC.CE, 38, "onchange", $.$mac.MAC.ECF.CB$27($.$mac.MAC.EC$1.F$1, this, new ($.$$.S.A$1$$($.$$.S.S$1))().$ctor(this,  (/*__value*/ __value) =>
                    {
                        return this.e = __value;
                    }, {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1228836,"h":0,"f":1048578}), this.e, null));
                    __builder.SU("value");
                    __builder.AA$4(39, "b-4y7dh9dpok");
                    __builder.CE();
                    __builder.CE();
                    __builder.AM(40, "\n\n            ");
                    __builder.OE(41, "div");
                    __builder.AA$2(42, "class", "input-container");
                    __builder.AA$4(43, "b-4y7dh9dpok");
                    __builder.AM(44, "<label for=\"username\" b-4y7dh9dpok>Username</label>\n                ");
                    __builder.OE(45, "input");
                    __builder.AA$2(46, "type", "text");
                    __builder.AA$2(47, "placeholder", "enter username...");
                    __builder.AA$2(48, "value", $.$mac.MAC.B.FV$28(this.u, null));
                    __builder.AA$6($.$mac.MAC.CE, 49, "onchange", $.$mac.MAC.ECF.CB$27($.$mac.MAC.EC$1.F$1, this, new ($.$$.S.A$1$$($.$$.S.S$1))().$ctor(this,  (/*__value*/ __value) =>
                    {
                        return this.u = __value;
                    }, {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1228836,"h":0,"f":1048578}), this.u, null));
                    __builder.SU("value");
                    __builder.AA$4(50, "b-4y7dh9dpok");
                    __builder.CE();
                    __builder.CE();
                    __builder.AM(51, "\n\n            ");
                    __builder.OE(52, "div");
                    __builder.AA$2(53, "class", "input-container");
                    __builder.AA$4(54, "b-4y7dh9dpok");
                    __builder.AM(55, "<label for=\"username\" b-4y7dh9dpok>Date of Birth</label>\n                ");
                    __builder.OE(56, "input");
                    __builder.AA$2(57, "type", "date");
                    __builder.AA$2(58, "placeholder", "enter password...");
                    __builder.AA$2(59, "value", $.$mac.MAC.B.FV$16(this.dO?.Clone() ?? null, "yyyy-MM-dd", $.$$.SG.CI$1.IC));
                    __builder.AA$6($.$mac.MAC.CE, 60, "onchange", $.$mac.MAC.ECF.CB$15($.$mac.MAC.EC$1.F$1, this, new ($.$$.S.A$1$$($.$$.S.N$$($.$$.S.DT$1)))().$ctor(this,  (/*__value*/ __value) =>
                    {
                        return this.dO = __value?.Clone() ?? null;
                    }, {"r":65537,"p":[{"n":"__value","p":$.$typeNullable($.$$.S.DT$1).$h}],"n":"","d":1228836,"h":0,"f":1048578}), this.dO?.Clone() ?? null, "yyyy-MM-dd", $.$$.SG.CI$1.IC));
                    __builder.SU("value");
                    __builder.AA$4(61, "b-4y7dh9dpok");
                    __builder.CE();
                    __builder.CE();
                    __builder.AM(62, "\n\n            ");
                    __builder.OE(63, "div");
                    __builder.AA$2(64, "class", "input-container");
                    __builder.AA$4(65, "b-4y7dh9dpok");
                    __builder.AM(66, "<label for=\"username\" b-4y7dh9dpok>Role</label>\n                ");
                    __builder.OE(67, "select");
                    __builder.AA$2(68, "name", "");
                    __builder.AA$2(69, "id", "");
                    __builder.AA$2(70, "value", $.$mac.MAC.B.FV$28(this.r, null));
                    __builder.AA$6($.$mac.MAC.CE, 71, "onchange", $.$mac.MAC.ECF.CB$27($.$mac.MAC.EC$1.F$1, this, new ($.$$.S.A$1$$($.$$.S.S$1))().$ctor(this,  (/**/ __value) =>
                    {
                        return this.r = __value;
                    }, {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1228836,"h":0,"f":1048578}), this.r, null));
                    __builder.SU("value");
                    __builder.AA$4(72, "b-4y7dh9dpok");
                    __builder.OE(73, "option");
                    __builder.AA$2(74, "value", "Admin");
                    __builder.AA$4(75, "b-4y7dh9dpok");
                    __builder.AC$3(76, "Admin");
                    __builder.CE();
                    __builder.AM(77, "\n                    ");
                    __builder.OE(78, "option");
                    __builder.AA$2(79, "value", "User");
                    __builder.AA$4(80, "b-4y7dh9dpok");
                    __builder.AC$3(81, "User");
                    __builder.CE();
                    __builder.CE();
                    __builder.CE();
                    __builder.AM(82, "\n\n            ");
                    __builder.OE(83, "div");
                    __builder.AA$2(84, "class", "input-container");
                    __builder.AA$4(85, "b-4y7dh9dpok");
                    __builder.AM(86, "<label for=\"username\" b-4y7dh9dpok>Password</label>\n                ");
                    __builder.OE(87, "input");
                    __builder.AA$2(88, "type", "password");
                    __builder.AA$2(89, "placeholder", "enter password...");
                    __builder.AA$2(90, "value", $.$mac.MAC.B.FV$28(this.p$1, null));
                    __builder.AA$6($.$mac.MAC.CE, 91, "onchange", $.$mac.MAC.ECF.CB$27($.$mac.MAC.EC$1.F$1, this, new ($.$$.S.A$1$$($.$$.S.S$1))().$ctor(this,  (/*__value*/ __value) =>
                    {
                        return this.p$1 = __value;
                    }, {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1228836,"h":0,"f":1048578}), this.p$1, null));
                    __builder.SU("value");
                    __builder.AA$4(92, "b-4y7dh9dpok");
                    __builder.CE();
                    __builder.CE();
                    __builder.AM(93, "\n\n            ");
                    __builder.OE(94, "div");
                    __builder.AA$2(95, "class", "input-container");
                    __builder.AA$4(96, "b-4y7dh9dpok");
                    __builder.AM(97, "<label for=\"username\" b-4y7dh9dpok>Confirm password</label>\n                ");
                    __builder.OE(98, "input");
                    __builder.AA$2(99, "type", "password");
                    __builder.AA$2(100, "placeholder", "enter password...");
                    __builder.AA$2(101, "value", $.$mac.MAC.B.FV$28(this.cP, null));
                    __builder.AA$6($.$mac.MAC.CE, 102, "onchange", $.$mac.MAC.ECF.CB$27($.$mac.MAC.EC$1.F$1, this, new ($.$$.S.A$1$$($.$$.S.S$1))().$ctor(this,  (/**/ __value) =>
                    {
                        return this.cP = __value;
                    }, {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1228836,"h":0,"f":1048578}), this.cP, null));
                    __builder.SU("value");
                    __builder.AA$4(103, "b-4y7dh9dpok");
                    __builder.CE();
                    __builder.CE();
                    __builder.AM(104, "\n\n            ");
                    __builder.OE(105, "div");
                    __builder.AA$2(106, "class", "input-container");
                    __builder.AA$4(107, "b-4y7dh9dpok");
                    __builder.OE(108, "button");
                    __builder.AA$6($.$macw.MACW.ME, 109, "onclick", $.$mac.MAC.EC$1.F$1.C$7($.$macw.MACW.ME, this, new ($.$$.S.F$$($.$$.STT.T))().$ctor(this, this.SU$1)));
                    __builder.AA$4(110, "b-4y7dh9dpok");
                    __builder.AC$3(111, "Sign Up");
                    __builder.CE();
                    __builder.CE();
                    if (!this.A$1.IL)
                    {
                        __builder.OE(112, "p");
                        __builder.AA$4(113, "b-4y7dh9dpok");
                        __builder.AC$3(114, this.eM);
                        __builder.CE();
                    }
                    __builder.CE();
                    __builder.CE();
                }
            }
            /*string*/ f$1 = null;
            /*string*/ l = null;
            /*string*/ e = null;
            /*string*/ r = null;
            /*DateTime?*/ dO = null;
            /*string*/ u = null;
            /*string*/ p$1 = null;
            /*string*/ cP = null;
            /*string*/ eM = null;
            /*bool*/ iL = true;
            /*List<UserModel>*/ u$1 = null;
            /*Task *//*async*/  OIA()
            {
                return $.$$.N.AR.A($.$$.STT.T, $.$$.S.V$2, async () => 
                {
                    this.iL = true;
                    await $.$$.STT.T.D$2(1000);
                    this.iL = false;
                });
            }
            /*void */ OI()
            {
                if (this.A$1.IL)
                {
                    this.N.N("/dashboard", false, false);
                }
            }
            /*Task *//*async*/  OA(/*bool*/ firstRender)
            {
                return $.$$.N.AR.A($.$$.STT.T, $.$$.S.V$2, async () => 
                {
                    if (firstRender)
                    {
                        await this.L();
                        this.iL = false;
                        this.SH();
                    }
                });
            }
            /*Task *//*async*/  L()
            {
                return $.$$.N.AR.A($.$$.STT.T, $.$$.S.V$2, async () => 
                {
                    await this.A$1.LU();
                });
            }
            /*Task *//*async*/  SU$1()
            {
                return $.$$.N.AR.A($.$$.STT.T, $.$$.S.V$2, async () => 
                {
                    /*var*/ let user = this.A$1.SU$1(this.f$1, this.l, this.e, this.r, this.dO?.Clone() ?? null, this.u, this.p$1, this.cP);
                    /*bool*/ let success = true;
                    /*var*/ let newUser = (() =>
                    {
                        //new $.$m.U()
                        const $t1 = $.$m.U;
                        const $i1 = new $t1();
                        $i1.FN = this.f$1;
                        $i1.L = this.l;
                        $i1.E$2 = this.e;
                        $i1.D = this.dO?.Clone() ?? null;
                        $i1.U = this.u;
                        $i1.P$1 = this.p$1;
                        $i1.R$1 = this.r;
                        return $i1;
                    })();
                    this.u$1.A(newUser);
                    await this.SU();
                    await this.L();
                    if (success)
                    {
                        this.N.N("/signupsuccess", false, false);
                    }
                    else 
                    {
                        this.eM = "\u26A0\uFE0F User already exist.";
                    }
                });
            }
            /*Task *//*async*/  SU()
            {
                return $.$$.N.AR.A($.$$.STT.T, $.$$.S.V$2, async () => 
                {
                    await this.A$1.SU();
                });
            }
            /*IJSRuntime*/ JS = null;
            /*NavigationManager*/ N = null;
            /*miniapp.Services.AuthService*/ A$1 = null;
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.f$1 = "";
                this.l = "";
                this.e = "";
                this.r = "";
                this.dO = null;
                this.u = "";
                this.p$1 = "";
                this.cP = "";
                this.eM = "";
                this.u$1 = new ($.$$.SCG.L$$($.$m.U))().$ctor$1();
                this.JS = null;
                this.N = null;
                this.A$1 = null;
            }
            static $h = 1228836;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":524318,"g":{"r":0,"d":0,"h":90195542052,"f":2},"s":{"r":0,"d":0,"h":94490509348,"f":2},"n":"JS","d":1228836,"h":85900574756,"f":2,"a":[{"t":4259848,"c":21479096328}]},{"p":4980744,"g":{"r":0,"d":0,"h":107375411236,"f":2},"s":{"r":0,"d":0,"h":111670378532,"f":2},"n":"Nav","o":"N","d":1228836,"h":103080443940,"f":2,"a":[{"t":4259848,"c":21479096328}]},{"p":1884196,"g":{"r":0,"d":0,"h":124555280420,"f":2},"s":{"r":0,"d":0,"h":128850247716,"f":2},"n":"Auth","o":"A$1","d":1228836,"h":120260313124,"f":2,"a":[{"t":4259848,"c":21479096328}]}],"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","o":"B","d":1228836,"h":4296196132,"f":32772},{"r":133169153,"n":"OnInitializedAsync","o":"OIA","d":1228836,"h":55835803684,"f":36868},{"r":65537,"n":"OnInitialized","o":"OI","d":1228836,"h":60130770980,"f":32772},{"r":133169153,"p":[{"n":"firstRender","p":262145}],"n":"OnAfterRenderAsync","o":"OA","d":1228836,"h":64425738276,"f":36868},{"r":133169153,"n":"LoadUsers","o":"L","d":1228836,"h":68720705572,"f":4098},{"r":133169153,"n":"SignupUser","o":"SU$1","d":1228836,"h":73015672868,"f":4098},{"r":133169153,"n":"SaveUser","o":"SU","d":1228836,"h":77310640164,"f":4098}],"l":[{"t":1310721,"n":"firstname","o":"f$1","d":1228836,"h":8591163428,"f":2},{"t":1310721,"n":"lastname","o":"l","d":1228836,"h":12886130724,"f":2},{"t":1310721,"n":"email","o":"e","d":1228836,"h":17181098020,"f":2},{"t":1310721,"n":"role","o":"r","d":1228836,"h":21476065316,"f":2},{"t":$.$typeNullable($.$$.S.DT$1).$h,"n":"dateOfBirth","o":"dO","d":1228836,"h":25771032612,"f":2},{"t":1310721,"n":"username","o":"u","d":1228836,"h":30065999908,"f":2},{"t":1310721,"n":"password","o":"p$1","d":1228836,"h":34360967204,"f":2},{"t":1310721,"n":"confirmPassword","o":"cP","d":1228836,"h":38655934500,"f":2},{"t":1310721,"n":"errorMessage","o":"eM","d":1228836,"h":42950901796,"f":2},{"t":262145,"n":"isLoading","o":"iL","d":1228836,"h":47245869092,"f":2},{"t":$.$$.SCG.L$$($.$m.U).$h,"n":"users","o":"u$1","d":1228836,"h":51540836388,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":1228836,"h":133145215012,"f":1}],"i":[2752520,3145736,3080200],"h":1228836,"a":[{"t":9895944,"c":4304863240,"a":[{"v":"/signup","t":1310721}]}]}; }
            static get $b() { return $.$mac.MAC.CB; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IC, $.$mac.MAC.IHE, $.$mac.MAC.IH ]; }
            static get $fullName() { return `miniapp.Components.Pages.SignUp`; }
        });
        
        $asm.$cls("$m.mCP.P", ($self) => class Profile extends $.$mac.MAC.CB
        {
            /*void */ B(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OC($.$m.mC.N, 0);
                __builder.CC();
                if (this.iL)
                {
                    if ($.$$.S.S$1.o_E(this.A$1.R$1, "Admin"))
                    {
                        __builder.OC($.$m.mC.L, 1);
                        __builder.AC(2, "LoadingState", "\u23F3 Loading Admin profile...");
                        __builder.CC();
                    }
                    else if ($.$$.S.S$1.o_E(this.A$1.R$1, "User"))
                    {
                        __builder.OC($.$m.mC.L, 3);
                        __builder.AC(4, "LoadingState", "\u23F3 Loading User profile...");
                        __builder.CC();
                    }
                    else 
                    {
                        __builder.OC($.$m.mC.L, 5);
                        __builder.AC(6, "LoadingState", "\u23F3 Loading profile...");
                        __builder.CC();
                    }
                }
                else 
                {
                    __builder.AM(7, "<h3>\uD83D\uDC64 My Profile</h3>");
                    __builder.OE(8, "div");
                    __builder.AA$2(9, "style", "background: rgb(255, 166, 0, 0.2); padding: 20px 40px; font-size: 20px; margin-top: 30px; flex-wrap: wrap;");
                    __builder.OE(10, "div");
                    __builder.AA$2(11, "style", "background: rgb(255, 166, 0, 0.2); padding: 20px 40px; font-size: 20px; display: flex; justify-content: space-between; margin-top: 30px; flex-wrap: wrap;");
                    __builder.OE(12, "p");
                    __builder.AM(13, "<b style=\"color: purple;\">\uD83D\uDE4E\u200D\u2642\uFE0F Fullname:</b>\n                ");
                    __builder.AC$3(14, this.fN);
                    __builder.CE();
                    __builder.AM(15, "\n            ");
                    __builder.OE(16, "p");
                    __builder.AM(17, "<b style=\"color: purple;\">\uD83D\uDC66 Username:</b>\n                ");
                    __builder.AC$3(18, this.A$1.U);
                    __builder.CE();
                    __builder.AM(19, "\n            ");
                    __builder.OE(20, "p");
                    __builder.AM(21, "<b style=\"color: purple; margin-right: 4px;\">\uD83D\uDCC5 Member since:</b>");
                    if (this.A$1.IL)
                    {
                        __builder.AC$3(22, $.$$.S.DT$1.N$1.TS$3("MMM yyyy"));
                    }
                    __builder.CE();
                    __builder.CE();
                    __builder.AM(23, "\n        ");
                    __builder.OE(24, "div");
                    __builder.AA$2(25, "style", "background: rgb(255, 166, 0, 0.2); padding: 20px 40px; font-size: 20px; display: flex; justify-content: space-between; margin-top: 30px; flex-wrap: wrap;");
                    __builder.OE(26, "p");
                    __builder.AM(27, "<b style=\"color: purple;\">\uD83C\uDFF7\uFE0F Role:</b>\n                ");
                    __builder.AC$3(28, this.A$1.R$1);
                    __builder.CE();
                    __builder.AM(29, "\n            ");
                    __builder.OE(30, "p");
                    __builder.AM(31, "<b style=\"color: purple;\">\uD83D\uDCC5 Date of Birth:</b>\n                ");
                    __builder.AC$3(32, this.A$1.D);
                    __builder.CE();
                    __builder.AM(33, "\n            ");
                    __builder.OE(34, "p");
                    __builder.AM(35, "<b style=\"color: purple; margin-right: 4px;\">\uD83D\uDCE7 Email:</b>\n                ");
                    __builder.AC$3(36, this.A$1.E$2);
                    __builder.CE();
                    __builder.CE();
                    __builder.CE();
                    if (!this.A$1.IL)
                    {
                        __builder.OC($.$m.mC.NL, 37);
                        __builder.AC(38, "Title", "User not logged in...");
                        __builder.AC(39, "SubTitle", "Click to log in...");
                        __builder.CC();
                    }
                    else 
                    {
                        __builder.OE(40, "div");
                        __builder.AA$2(41, "style", "background: rgb(133, 133, 133, 0.2); padding: 20px 40px; font-size: 20px; margin: 30px 0;");
                        __builder.AM(42, "<h5>\uD83D\uDCCA My Stats</h5>\n            ");
                        __builder.OE(43, "div");
                        __builder.AA$2(44, "style", "background: rgb(133, 133, 133, 0.2); padding: 20px 40px; font-size: 20px; display: flex; justify-content: space-between; flex-wrap: wrap; margin-top: 30px;");
                        __builder.OE(45, "p");
                        __builder.AM(46, "<b style=\"margin-right: 20px\">\u2705 Completed: </b>\n                    ");
                        __builder.OE(47, "i");
                        __builder.AA$2(48, "style", "font-size: 30px; color: purple; font-weight: bold;");
                        __builder.AC$3(49, this.cC);
                        __builder.CE();
                        __builder.CE();
                        __builder.AM(50, "\n                ");
                        __builder.OE(51, "p");
                        __builder.AM(52, "<b style=\"margin-right: 20px\">\u23F3 Pending: </b>\n                    ");
                        __builder.OE(53, "i");
                        __builder.AA$2(54, "style", "font-size: 30px; color: purple; font-weight: bold;");
                        __builder.AC$3(55, this.pC);
                        __builder.CE();
                        __builder.CE();
                        __builder.AM(56, "\n                ");
                        __builder.OE(57, "p");
                        __builder.AM(58, "<b style=\"margin-right: 20px\">\uD83D\uDCDD Total: </b>\n                    ");
                        __builder.OE(59, "i");
                        __builder.AA$2(60, "style", "font-size: 30px; color: purple; font-weight: bold;");
                        __builder.AC$3(61, this.tC);
                        __builder.CE();
                        __builder.CE();
                        __builder.CE();
                        __builder.CE();
                        __builder.OE(62, "div");
                        __builder.AA$2(63, "style", "display: flex; justify-content: space-between; flex-wrap: wrap;");
                        __builder.OE(64, "div");
                        __builder.AA$2(65, "style", "margin-bottom: 10px;");
                        __builder.OE(66, "div");
                        __builder.AA$2(67, "style", "margin-bottom: 10px;");
                        __builder.OC($.$m.mC.B, 68);
                        __builder.AC(69, "BgColor", "rgb(140, 0, 140, 0.3)");
                        __builder.AC(70, "BtnText", "\u2B05 Back To DashBoard");
                        __builder.AC(71, "OnClick", $.$mac.MACC.R.TC($.$mac.MAC.EC$1, $.$mac.MAC.EC$1.F$1.C(this, new $.$$.S.A$2().$ctor(this, this.BT))));
                        __builder.CC();
                        __builder.CE();
                        __builder.AM(72, "\n                ");
                        __builder.OE(73, "div");
                        __builder.AA$2(74, "style", "margin-bottom: 10px;");
                        __builder.OC($.$m.mC.B, 75);
                        __builder.AC(76, "BgColor", "rgb(135, 135, 135, 0.3)");
                        __builder.AC(77, "BtnText", "\uD83D\uDEAA Logout");
                        __builder.AC(78, "OnClick", $.$mac.MACC.R.TC($.$mac.MAC.EC$1, $.$mac.MAC.EC$1.F$1.C(this, new $.$$.S.A$2().$ctor(this, this.L))));
                        __builder.CC();
                        __builder.CE();
                        __builder.CE();
                        if (this.cA === false)
                        {
                            __builder.OE(79, "div");
                            __builder.AA$2(80, "style", "display: flex; gap:10px;");
                            __builder.OE(81, "div");
                            __builder.AA$2(82, "style", "margin-bottom: 10px;");
                            __builder.OC($.$m.mC.B, 83);
                            __builder.AC(84, "BgColor", "rgba(255, 0, 0, 0.3)");
                            __builder.AC(85, "BtnText", "\u2705 Confirm");
                            __builder.AC(86, "OnClick", $.$mac.MACC.R.TC($.$mac.MAC.EC$1, $.$mac.MAC.EC$1.F$1.C$3(this, new ($.$$.S.F$$($.$$.STT.T))().$ctor(this, this.DU))));
                            __builder.CC();
                            __builder.CE();
                            __builder.AM(87, "\n                    ");
                            __builder.OE(88, "div");
                            __builder.AA$2(89, "style", "margin-bottom: 10px;");
                            __builder.OC($.$m.mC.B, 90);
                            __builder.AC(91, "BgColor", "rgb(126, 126, 126, 0.3)");
                            __builder.AC(92, "BtnText", "\u274C Cancel");
                            __builder.AC(93, "OnClick", $.$mac.MACC.R.TC($.$mac.MAC.EC$1, $.$mac.MAC.EC$1.F$1.C(this, new $.$$.S.A$2().$ctor(this,  () =>
                            {
                                return this.cA = true;
                            }, {"r":65537,"n":"","d":1163300,"h":0,"f":1048578}))));
                            __builder.CC();
                            __builder.CE();
                            __builder.CE();
                        }
                        else 
                        {
                            __builder.OE(94, "div");
                            __builder.AA$2(95, "style", "margin-bottom: 10px;");
                            __builder.OC($.$m.mC.B, 96);
                            __builder.AC(97, "BgColor", "rgba(255, 0, 0, 0.3)");
                            __builder.AC(98, "BtnText", "\uD83D\uDDD1\uFE0F Delete Account");
                            __builder.AC(99, "OnClick", $.$mac.MACC.R.TC($.$mac.MAC.EC$1, $.$mac.MAC.EC$1.F$1.C(this, new $.$$.S.A$2().$ctor(this,  () =>
                            {
                                return this.cA = false;
                            }, {"r":65537,"n":"","d":1163300,"h":0,"f":1048578}))));
                            __builder.CC();
                            __builder.CE();
                        }
                        __builder.CE();
                    }
                }
            }
            /*bool*/ iL = false;
            /*List<AppTask> */ get t$1()
            {
                return this.TS.I$G() ?? new ($.$$.SCG.L$$($.$m.A))().$ctor$1();
            }
            /*string */ get tC()
            {
                return $.$$.S.I$4.T.call(this.t$1.C$3);
            }
            /*string */ get cC()
            {
                return $.$$.S.I$4.T.call($.$sl.SL.E.C$6($.$m.A, this.t$1, new ($.$$.S.F$$$($.$m.A, $.$$.S.B$2))().$ctor(this,  (/*t*/ t) =>
                {
                    return t.IC;
                }, {"r":262145,"p":[{"n":"t","p":114724}],"n":"","d":1163300,"h":0,"f":1048578})));
            }
            /*string */ get pC()
            {
                return $.$$.S.I$4.T.call($.$sl.SL.E.C$6($.$m.A, this.t$1, new ($.$$.S.F$$$($.$m.A, $.$$.S.B$2))().$ctor(this,  (/*t*/ t) =>
                {
                    return !t.IC;
                }, {"r":262145,"p":[{"n":"t","p":114724}],"n":"","d":1163300,"h":0,"f":1048578})));
            }
            /*string */ get fN()
            {
                return `${this.A$1.L} ${this.A$1.F$1}`;
            }
            /*bool*/ cA = true;
            /*Task *//*async*/  OIA()
            {
                return $.$$.N.AR.A($.$$.STT.T, $.$$.S.V$2, async () => 
                {
                    this.iL = true;
                    await $.$$.STT.T.D$2(2000);
                    this.iL = false;
                    this.SH();
                });
            }
            /*void */ BT()
            {
                this.N.N("/dashboard", false, false);
                this.SH();
            }
            /*Task *//*async*/  DU()
            {
                return $.$$.N.AR.A($.$$.STT.T, $.$$.S.V$2, async () => 
                {
                    await this.A$1.DA();
                    this.SH();
                });
            }
            /*void */ L()
            {
                this.N.N("/", false, false);
                this.A$1.L$2();
            }
            /*Task *//*async*/  OA(/*bool*/ firstRender)
            {
                return $.$$.N.AR.A($.$$.STT.T, $.$$.S.V$2, async () => 
                {
                    if (firstRender)
                    {
                        await this.A$1.LU();
                        await this.TS.I$L();
                        this.SH();
                    }
                });
            }
            /*NavigationManager*/ N = null;
            /*ITaskService*/ TS = null;
            /*miniapp.Services.AuthService*/ A$1 = null;
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.iL = false;
                this.N = null;
                this.TS = null;
                this.A$1 = null;
            }
            static $h = 1163300;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17181032484,"f":2},"s":{"r":0,"d":0,"h":21475999780,"f":2},"n":"isLoading","o":"iL","d":1163300,"h":12886065188,"f":2},{"p":$.$$.SCG.L$$($.$m.A).$h,"g":{"r":0,"d":0,"h":30065934372,"f":2},"n":"tasks","o":"t$1","d":1163300,"h":25770967076,"f":2},{"p":1310721,"g":{"r":0,"d":0,"h":38655868964,"f":2},"n":"tasksCount","o":"tC","d":1163300,"h":34360901668,"f":2},{"p":1310721,"g":{"r":0,"d":0,"h":47245803556,"f":2},"n":"completedCount","o":"cC","d":1163300,"h":42950836260,"f":2},{"p":1310721,"g":{"r":0,"d":0,"h":55835738148,"f":2},"n":"pendingCount","o":"pC","d":1163300,"h":51540770852,"f":2},{"p":1310721,"g":{"r":0,"d":0,"h":64425672740,"f":2},"n":"fullName","o":"fN","d":1163300,"h":60130705444,"f":2},{"p":4980744,"g":{"r":0,"d":0,"h":103080378404,"f":2},"s":{"r":0,"d":0,"h":107375345700,"f":2},"n":"Nav","o":"N","d":1163300,"h":98785411108,"f":2,"a":[{"t":4259848,"c":21479096328}]},{"p":180260,"g":{"r":0,"d":0,"h":120260247588,"f":2},"s":{"r":0,"d":0,"h":124555214884,"f":2},"n":"TaskService","o":"TS","d":1163300,"h":115965280292,"f":2,"a":[{"t":4259848,"c":21479096328}]},{"p":1884196,"g":{"r":0,"d":0,"h":137440116772,"f":2},"s":{"r":0,"d":0,"h":141735084068,"f":2},"n":"Auth","o":"A$1","d":1163300,"h":133145149476,"f":2,"a":[{"t":4259848,"c":21479096328}]}],"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","o":"B","d":1163300,"h":4296130596,"f":32772},{"r":133169153,"n":"OnInitializedAsync","o":"OIA","d":1163300,"h":73015607332,"f":36868},{"r":65537,"n":"BackToDashboard","o":"BT","d":1163300,"h":77310574628,"f":2},{"r":133169153,"n":"DeleteUserAccount","o":"DU","d":1163300,"h":81605541924,"f":4098},{"r":65537,"n":"Logout","o":"L","d":1163300,"h":85900509220,"f":2},{"r":133169153,"p":[{"n":"firstRender","p":262145}],"n":"OnAfterRenderAsync","o":"OA","d":1163300,"h":90195476516,"f":36868}],"l":[{"t":262145,"n":"confirmAccountDelete","o":"cA","d":1163300,"h":68720640036,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":1163300,"h":146030051364,"f":1}],"i":[2752520,3145736,3080200],"h":1163300,"a":[{"t":9895944,"c":4304863240,"a":[{"v":"/profile","t":1310721}]}]}; }
            static get $b() { return $.$mac.MAC.CB; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IC, $.$mac.MAC.IHE, $.$mac.MAC.IH ]; }
            static get $fullName() { return `miniapp.Components.Pages.Profile`; }
        });
        
        $asm.$cls("$m.mCP.T", ($self) => class Tasks extends $.$mac.MAC.CB
        {
            /*void */ B(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OC($.$m.mC.N, 0);
                __builder.CC();
                __builder.AM(1, "\n\n");
                __builder.OE(2, "div");
                __builder.AA$2(3, "class", "mobile");
                __builder.AA$2(4, "style", "display: flex; flex-wrap: wrap; margin-bottom: 20px; gap: 5px; justify-content: space-between;");
                __builder.AA$4(5, "b-eh7nwjtt9e");
                __builder.AM(6, "<h3 style=\"margin-bottom: 30px;\" b-eh7nwjtt9e>\uD83D\uDCDD Task Manager </h3>");
                if (this.A$1.IL)
                {
                    if ($.$sl.SL.E.A$5($.$m.A, this.t$1))
                    {
                        __builder.OE(7, "div");
                        __builder.AA$2(8, "class", "i");
                        __builder.AA$4(9, "b-eh7nwjtt9e");
                        __builder.OE(10, "i");
                        __builder.AA$2(11, "style", "font-size: 15px; color: white; margin-top: 5px; background: rgb(0, 107, 0, 0.7); padding: 0 30px; margin: 0; border-bottom-right-radius: 20px; border-top-right-radius: 20px; display: flex; align-items: center;");
                        __builder.AA$4(12, "b-eh7nwjtt9e");
                        __builder.AC$2(13, $.$box(this.t$1.C$3, $.$$.S.I$4));
                        __builder.AC$3(14, " task(s) added");
                        __builder.CE();
                        __builder.CE();
                    }
                }
                __builder.CE();
                __builder.AM(15, "\n\n    ");
                __builder.AM(16, "<h5 b-eh7nwjtt9e>Priority</h5>\n\n    ");
                __builder.OE(17, "div");
                __builder.AA$2(18, "style", "display: flex; flex-wrap: wrap; gap: 10px;");
                __builder.AA$4(19, "b-eh7nwjtt9e");
                __builder.OE(20, "select");
                __builder.AA$4(21, "name");
                __builder.AA$4(22, "id");
                __builder.AA$2(23, "class", "opt-btn");
                __builder.AA$2(24, "style", "padding: 10px; border: none; background: rgb(255, 166, 0, 0.2); width: 50%; border-radius: 10px;");
                __builder.AA$4(25, "b-eh7nwjtt9e");
                __builder.OE(26, "option");
                __builder.AA$2(27, "value", "All");
                __builder.AA$4(28, "b-eh7nwjtt9e");
                __builder.AC$3(29, "All");
                __builder.CE();
                __builder.AM(30, "\n            ");
                __builder.OE(31, "option");
                __builder.AA$2(32, "value", "Pending");
                __builder.AA$4(33, "b-eh7nwjtt9e");
                __builder.AC$3(34, "Pending");
                __builder.CE();
                __builder.AM(35, "\n            ");
                __builder.OE(36, "option");
                __builder.AA$2(37, "value", "Done");
                __builder.AA$4(38, "b-eh7nwjtt9e");
                __builder.AC$3(39, "Done");
                __builder.CE();
                __builder.CE();
                __builder.AM(40, "\n        ");
                __builder.OE(41, "div");
                __builder.AA$2(42, "class", "opt-btn");
                __builder.AA$4(43, "b-eh7nwjtt9e");
                __builder.OE(44, "button");
                __builder.AA$2(45, "class", "btn-hov");
                __builder.AA$2(46, "style", "padding: 10px; border: none; background: rgb(255, 166, 0, 0.2); border-radius: 10px;");
                __builder.AA$6($.$macw.MACW.ME, 47, "onclick", $.$mac.MAC.EC$1.F$1.C$5($.$macw.MACW.ME, this, new $.$$.S.A$2().$ctor(this, this.AT$1)));
                __builder.AA$4(48, "b-eh7nwjtt9e");
                __builder.AC$3(49, "All");
                __builder.CE();
                __builder.AM(50, "\n            ");
                __builder.OE(51, "button");
                __builder.AA$2(52, "class", "btn-hov");
                __builder.AA$2(53, "style", "padding: 10px; border: none; background: rgb(255, 166, 0, 0.2); border-radius: 10px;");
                __builder.AA$6($.$macw.MACW.ME, 54, "onclick", $.$mac.MAC.EC$1.F$1.C$5($.$macw.MACW.ME, this, new $.$$.S.A$2().$ctor(this, this.P$1)));
                __builder.AA$4(55, "b-eh7nwjtt9e");
                __builder.AM(56, "\u23F3\n                Pending");
                __builder.CE();
                __builder.AM(57, "\n                ");
                __builder.OE(58, "button");
                __builder.AA$2(59, "class", "btn-hov");
                __builder.AA$2(60, "style", "padding: 10px; border: none; background: rgb(255, 166, 0, 0.2); border-radius: 10px;");
                __builder.AA$6($.$macw.MACW.ME, 61, "onclick", $.$mac.MAC.EC$1.F$1.C$5($.$macw.MACW.ME, this, new $.$$.S.A$2().$ctor(this, this.C$1)));
                __builder.AA$4(62, "b-eh7nwjtt9e");
                __builder.AM(63, "\u2705\n                    Done");
                __builder.CE();
                __builder.CE();
                __builder.CE();
                __builder.AM(64, "\n\n            ");
                __builder.OE(65, "div");
                __builder.AA$2(66, "style", "display: flex; flex-wrap: wrap; gap: 10px; padding: 30px 0; width: 100%");
                __builder.AA$4(67, "b-eh7nwjtt9e");
                __builder.OE(68, "div");
                __builder.AA$4(69, "style");
                __builder.AA$4(70, "b-eh7nwjtt9e");
                __builder.AM(71, "<label for=\"title\" b-eh7nwjtt9e>Title:</label>\n                    ");
                __builder.OE(72, "input");
                __builder.AA$2(73, "type", "text");
                __builder.AA$2(74, "placeholder", "enter task title...");
                __builder.AA$2(75, "style", "padding: 10px; border: none; background: rgb(255, 166, 0, 0.2); width: 100%; border-radius: 10px;");
                __builder.AA$2(76, "value", $.$mac.MAC.B.FV$28(this.tT, null));
                __builder.AA$6($.$mac.MAC.CE, 77, "onchange", $.$mac.MAC.ECF.CB$27($.$mac.MAC.EC$1.F$1, this, new ($.$$.S.A$1$$($.$$.S.S$1))().$ctor(this,  (/**/ __value) =>
                {
                    return this.tT = __value;
                }, {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1294372,"h":0,"f":1048578}), this.tT, null));
                __builder.SU("value");
                __builder.AA$4(78, "b-eh7nwjtt9e");
                __builder.CE();
                __builder.CE();
                __builder.AM(79, "\n\n                ");
                __builder.OE(80, "div");
                __builder.AA$2(81, "class", "input-container");
                __builder.AA$4(82, "b-eh7nwjtt9e");
                __builder.AM(83, "<label for=\"title\" b-eh7nwjtt9e>Priority:</label>\n                    ");
                __builder.OE(84, "select");
                __builder.AA$2(85, "name", "Priority");
                __builder.AA$2(86, "id", "");
                __builder.AA$2(87, "style", "padding: 13px; border: none; background: rgb(255, 166, 0, 0.2); width: 100%; border-radius: 10px;");
                __builder.AA$1(88, "value", $.$mac.MAC.B.FV$31($.$m.P$1, this.tP, null));
                __builder.AA$6($.$mac.MAC.CE, 89, "onchange", $.$mac.MAC.ECF.CB$61($.$m.P$1, $.$mac.MAC.EC$1.F$1, this, new ($.$$.S.A$1$$($.$m.P$1))().$ctor(this,  (/*__value*/ __value) =>
                {
                    return this.tP = __value;
                }, {"r":65537,"p":[{"n":"__value","p":1949732}],"n":"","d":1294372,"h":0,"f":1048578}), this.tP, null));
                __builder.SU("value");
                __builder.AA$4(90, "b-eh7nwjtt9e");
                /*var*/ let values = $.$$.S.E$3.GV$2($.$m.P$1);
                let $i1 = 0;
                let $arr1 = values;
                while ($i1 < $arr1.length)
                {
                    let value = $arr1[$i1++];
                    __builder.OE(91, "option");
                    __builder.AA$1(92, "value", $.$box(value, $.$m.P$1));
                    __builder.AA$4(93, "b-eh7nwjtt9e");
                    if (value === 1/*Priority.Low*/)
                    {
                        __builder.AM(94, "\uD83D\uDD34");
                    }
                    else if (value === 2/*Priority.Medium*/)
                    {
                        __builder.AM(95, "\uD83D\uDFE1");
                    }
                    else if (value === 3/*Priority.High*/)
                    {
                        __builder.AM(96, "\uD83D\uDFE2");
                    }
                    __builder.AC$3(97, $.$$.S.E$3.TST($.$m.P$1, $.$$.S.UI$2, value));
                    __builder.CE();
                }
                __builder.CE();
                __builder.CE();
                __builder.CE();
                __builder.AM(98, "\n\n            ");
                __builder.OE(99, "div");
                __builder.AA$2(100, "style", "display: flex; flex-wrap: wrap; gap: 10px; margin-bottom: 50px;");
                __builder.AA$4(101, "b-eh7nwjtt9e");
                __builder.OC($.$m.mC.B, 102);
                __builder.AC(103, "BgColor", "rgb(140, 0, 140, 0.3)");
                __builder.AC(104, "BtnText", "\u2795 AddTask");
                __builder.AC(105, "OnClick", $.$mac.MACC.R.TC($.$mac.MAC.EC$1, $.$mac.MAC.EC$1.F$1.C$3(this, new ($.$$.S.F$$($.$$.STT.T))().$ctor(this, this.AT))));
                __builder.CC();
                __builder.AM(106, "\n                ");
                __builder.OC($.$m.mC.B, 107);
                __builder.AC(108, "BgColor", "rgb(126, 126, 126, 0.3)");
                __builder.AC(109, "BtnText", "Move Completed Task \u27A1");
                __builder.AC(110, "OnClick", $.$mac.MACC.R.TC($.$mac.MAC.EC$1, $.$mac.MAC.EC$1.F$1.C$3(this, new ($.$$.S.F$$($.$$.STT.T))().$ctor(this, this.MC))));
                __builder.CC();
                __builder.CE();
                __builder.AM(111, "\n\n            <hr b-eh7nwjtt9e>");
                if (!this.A$1.IL)
                {
                    __builder.OC($.$m.mC.NL, 112);
                    __builder.AC(113, "Title", "User not logged in...");
                    __builder.AC(114, "SubTitle", "Click to log in...");
                    __builder.CC();
                }
                else 
                {
                    __builder.OE(115, "div");
                    __builder.AA$2(116, "style", "display: flex; flex-wrap: wrap; justify-content: space-between; padding-top: 10px;");
                    __builder.AA$4(117, "b-eh7nwjtt9e");
                    __builder.AM(118, "<h4 b-eh7nwjtt9e>\uD83D\uDCC1 Available Task</h4>");
                    if (this.cC)
                    {
                        __builder.OE(119, "div");
                        __builder.AA$2(120, "style", "display: flex; gap:10px;");
                        __builder.AA$4(121, "b-eh7nwjtt9e");
                        __builder.OC($.$m.mC.B, 122);
                        __builder.AC(123, "BgColor", "rgb(140, 0, 140, 0.3)");
                        __builder.AC(124, "BtnText", "\u2705 Clear");
                        __builder.AC(125, "OnClick", $.$mac.MACC.R.TC($.$mac.MAC.EC$1, $.$mac.MAC.EC$1.F$1.C$3(this, new ($.$$.S.F$$($.$$.STT.T))().$ctor(this, this.CT))));
                        __builder.CC();
                        __builder.AM(126, "\n                            ");
                        __builder.OC($.$m.mC.B, 127);
                        __builder.AC(128, "BgColor", "rgb(126, 126, 126, 0.3)");
                        __builder.AC(129, "BtnText", "\u274C Cancel");
                        __builder.AC(130, "OnClick", $.$mac.MACC.R.TC($.$mac.MAC.EC$1, $.$mac.MAC.EC$1.F$1.C(this, new $.$$.S.A$2().$ctor(this,  () =>
                        {
                            return this.cC = false;
                        }, {"r":65537,"n":"","d":1294372,"h":0,"f":1048578}))));
                        __builder.CC();
                        __builder.CE();
                    }
                    else 
                    {
                        __builder.OC($.$m.mC.B, 131);
                        __builder.AC(132, "BgColor", "rgb(140, 0, 140, 0.3)");
                        __builder.AC(133, "BtnText", "\uD83E\uDDF9 Clear All Tasks");
                        __builder.AC(134, "OnClick", $.$mac.MACC.R.TC($.$mac.MAC.EC$1, $.$mac.MAC.EC$1.F$1.C(this, new $.$$.S.A$2().$ctor(this,  () =>
                        {
                            return this.cC = true;
                        }, {"r":65537,"n":"","d":1294372,"h":0,"f":1048578}))));
                        __builder.CC();
                    }
                    __builder.CE();
                    if ($.$sl.SL.E.A$5($.$m.A, this.t$1))
                    {
                        if (this.iL)
                        {
                            __builder.OC($.$m.mC.LC, 135);
                            __builder.AC(136, "LoadingState", "\u23F3 Loading Available Tasks...");
                            __builder.CC();
                        }
                        else 
                        {
                            __builder.OE(137, "div");
                            __builder.AA$2(138, "style", "background: rgba(228, 228, 228, 0.1);");
                            __builder.AA$4(139, "b-eh7nwjtt9e");
                            __builder.OE(140, "ul");
                            __builder.AA$2(141, "style", "margin: 20px 0px 40px;");
                            __builder.AA$4(142, "b-eh7nwjtt9e");
                            var $en5 = this.f$1.GE();
                            while ($en5.M())
                            {
                                var task = $en5.C;
                                {
                                    if (task.IC)
                                    {
                                        __builder.OE(143, "li");
                                        __builder.AA$2(144, "style", "margin: 10px 0; padding: 7px; list-style: none; border-left: 3px solid purple; text-decoration: line-through; background: rgb(129, 129, 129, 0.1);");
                                        __builder.AA$4(145, "b-eh7nwjtt9e");
                                        __builder.OC($.$m.mC.T, 146);
                                        __builder.AC(147, "Task", $.$mac.MACC.R.TC($.$m.A, task));
                                        __builder.AC(148, "OnToggle", $.$mac.MACC.R.TC($.$mac.MAC.E$$($.$$.S.I$4), $.$mac.MAC.EC$1.F$1.C$6($.$$.S.I$4, this, new ($.$$.S.A$1$$($.$$.S.I$4))().$ctor(this, this.TT))));
                                        __builder.AC(149, "OnDelete", $.$mac.MACC.R.TC($.$mac.MAC.E$$($.$$.S.I$4), $.$mac.MAC.EC$1.F$1.C$8($.$$.S.I$4, this, new ($.$$.S.F$$$($.$$.S.I$4, $.$$.STT.T))().$ctor(this, this.DT))));
                                        __builder.AC(150, "TaskIdToDelete", $.$box($.$mac.MACC.R.TC($.$typeNullable($.$$.S.I$4), this.T$1.Id), $.$$.S.N$$($.$$.S.I$4)));
                                        __builder.CC();
                                        __builder.CE();
                                    }
                                    else 
                                    {
                                        __builder.OE(151, "li");
                                        __builder.AA$2(152, "style", "margin: 10px 0; padding: 7px; list-style: none; border-left: 3px solid purple; background: rgb(129, 129, 129, 0.1);");
                                        __builder.AA$4(153, "b-eh7nwjtt9e");
                                        __builder.OC($.$m.mC.T, 154);
                                        __builder.AC(155, "Task", $.$mac.MACC.R.TC($.$m.A, task));
                                        __builder.AC(156, "OnToggle", $.$mac.MACC.R.TC($.$mac.MAC.E$$($.$$.S.I$4), $.$mac.MAC.EC$1.F$1.C$6($.$$.S.I$4, this, new ($.$$.S.A$1$$($.$$.S.I$4))().$ctor(this, this.TT))));
                                        __builder.AC(157, "OnDelete", $.$mac.MACC.R.TC($.$mac.MAC.E$$($.$$.S.I$4), $.$mac.MAC.EC$1.F$1.C$8($.$$.S.I$4, this, new ($.$$.S.F$$$($.$$.S.I$4, $.$$.STT.T))().$ctor(this, this.DT))));
                                        __builder.AC(158, "TaskIdToDelete", $.$box($.$mac.MACC.R.TC($.$typeNullable($.$$.S.I$4), this.T$1.Id), $.$$.S.N$$($.$$.S.I$4)));
                                        __builder.CC();
                                        __builder.CE();
                                    }
                                }
                            }
                            __builder.CE();
                            __builder.CE();
                        }
                    }
                    else 
                    {
                        if (!this.iL)
                        {
                            __builder.AM(159, "<div style=\"display: flex; width: 100%; height: 100%; background: rgb(137, 137, 137, 0.1); margin: 20px 0 30px; height: 50vh; align-items: center; justify-content: center;\" b-eh7nwjtt9e><b b-eh7nwjtt9e>\uD83D\uDCC1 No tasks added.</b></div>");
                        }
                        else 
                        {
                            __builder.OE(160, "div");
                            __builder.AA$2(161, "style", "margin-bottom: 60px;");
                            __builder.AA$4(162, "b-eh7nwjtt9e");
                            __builder.OC($.$m.mC.LC, 163);
                            __builder.AC(164, "LoadingState", "\u23F3 Loading Available Tasks...");
                            __builder.CC();
                            __builder.CE();
                        }
                    }
                    __builder.AM(165, "<hr b-eh7nwjtt9e>");
                }
            }
            /*string*/ tT = null;
            /*bool*/ iL = false;
            /*Priority*/ tP = 0;
            /*string */ get tTT()
            {
                return $.$$.S.S$1.TU.call($.$$.S.S$1.T$1.call(this.tT));
            }
            /*List<AppTask>*/ t$1 = null;
            /*List<AppTask>*/ cT = null;
            /*bool*/ cC = false;
            /*AppTask*/ T$1 = null;
            /*string*/ cF = null;
            /*List<AppTask> */ get f$1()
            {
                return this.GF();
            }
            /*List<AppTask> */ GF()
            {
                /*var*/ let allTasks = this.TS.I$G() ?? new ($.$$.SCG.L$$($.$m.A))().$ctor$1();
                return (() =>
                {
                    if (this.cF === "Pending")
                    {
                        return $.$sl.SL.E.TL$1($.$m.A, $.$sl.SL.E.W($.$m.A, allTasks, new ($.$$.S.F$$$($.$m.A, $.$$.S.B$2))().$ctor(this,  (/*t*/ t) =>
                        {
                            return !t.IC;
                        }, {"r":262145,"p":[{"n":"t","p":114724}],"n":"","d":1294372,"h":0,"f":1048578})));
                    }
                    if (this.cF === "Done")
                    {
                        return $.$sl.SL.E.TL$1($.$m.A, $.$sl.SL.E.W($.$m.A, allTasks, new ($.$$.S.F$$$($.$m.A, $.$$.S.B$2))().$ctor(this,  (/*t*/ t) =>
                        {
                            return t.IC;
                        }, {"r":262145,"p":[{"n":"t","p":114724}],"n":"","d":1294372,"h":0,"f":1048578})));
                    }
                    return allTasks;
                })();
            }
            /*Task *//*async*/  OIA()
            {
                return $.$$.N.AR.A($.$$.STT.T, $.$$.S.V$2, async () => 
                {
                    this.iL = true;
                    await $.$$.STT.T.D$2(3000);
                    this.TS.I$a(new $.$$.S.A$2().$ctor(this, this.H));
                    this.iL = false;
                });
            }
            /*Task *//*async*/  OA(/*bool*/ firstRender)
            {
                return $.$$.N.AR.A($.$$.STT.T, $.$$.S.V$2, async () => 
                {
                    if (firstRender)
                    {
                        await this.TS.I$L();
                    }
                });
            }
            /*void */ OI()
            {
                this.TS.I$a(new $.$$.S.A$2().$ctor(this, this.H));
                this.RT();
            }
            /*Task *//*async*/  AT()
            {
                return $.$$.N.AR.A($.$$.STT.T, $.$$.S.V$2, async () => 
                {
                    if ($.$$.S.S$1.INO(this.tT) || this.tP === 0/*Priority.Select_Priority*/)
                    {
                        return;
                    }
                    this.TS.I$A(this.tTT, this.tP);
                    this.tT = "";
                    this.tP = 0/*Priority.Select_Priority*/;
                    this.RT();
                    if (this.A$1.IL)
                    {
                        await this.ST();
                    }
                });
            }
            /*Task *//*async*/  MC()
            {
                return $.$$.N.AR.A($.$$.STT.T, $.$$.S.V$2, async () => 
                {
                    this.TS.I$M(this.tTT, this.tP);
                    this.RT();
                    if (this.A$1.IL)
                    {
                        await this.ST();
                    }
                });
            }
            /*void */ AT$1()
            {
                this.cF = "All";
            }
            /*void */ P$1()
            {
                this.cF = "Pending";
            }
            /*void */ C$1()
            {
                this.cF = "Done";
            }
            /*void */ TT(/*int*/ id)
            {
                this.TS.I$T(id);
            }
            /*Task *//*async*/  DT(/*int*/ id)
            {
                return $.$$.N.AR.A($.$$.STT.T, $.$$.S.V$2, async () => 
                {
                    this.TS.I$D(id);
                    if (this.A$1.IL)
                    {
                        await this.ST();
                    }
                });
            }
            /*Task *//*async*/  CT()
            {
                return $.$$.N.AR.A($.$$.STT.T, $.$$.S.V$2, async () => 
                {
                    this.TS.I$C();
                    this.cC = false;
                    if (this.A$1.IL)
                    {
                        await this.ST();
                    }
                });
            }
            /*Task *//*async*/  ST()
            {
                return $.$$.N.AR.A($.$$.STT.T, $.$$.S.V$2, async () => 
                {
                    await this.TS.I$S();
                });
            }
            /*void */ RT()
            {
                this.t$1 = this.TS.I$G();
                this.SH();
            }
            /*void */ H()
            {
                this.RT();
                this.IA(new $.$$.S.A$2().$ctor(this, this.SH));
            }
            /*void */ D$1()
            {
                this.TS.I$r(new $.$$.S.A$2().$ctor(this, this.H));
            }
            /*IJSRuntime*/ JS = null;
            /*NavigationManager*/ N = null;
            /*ITaskService*/ TS = null;
            /*miniapp.Services.AuthService*/ A$1 = null;
            //Generated interface implemetation for System.IDisposable.Dispose()
            S$ID$D()
            {
                return this.D$1(...arguments);
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.tT = "";
                this.iL = false;
                this.t$1 = new ($.$$.SCG.L$$($.$m.A))().$ctor$1();
                this.cT = new ($.$$.SCG.L$$($.$m.A))().$ctor$1();
                this.T$1 = new $.$m.A().$ctor$1();
                this.cF = "All";
                this.JS = null;
                this.N = null;
                this.TS = null;
                this.A$1 = null;
            }
            static $h = 1294372;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":262145,"g":{"r":0,"d":0,"h":21476130852,"f":2},"s":{"r":0,"d":0,"h":25771098148,"f":2},"n":"isLoading","o":"iL","d":1294372,"h":17181163556,"f":2},{"p":1310721,"g":{"r":0,"d":0,"h":38656000036,"f":2},"n":"trimmedTaskTitle","o":"tTT","d":1294372,"h":34361032740,"f":2},{"p":$.$$.SCG.L$$($.$m.A).$h,"g":{"r":0,"d":0,"h":68720771108,"f":1},"n":"filteredtasks","o":"f$1","d":1294372,"h":64425803812,"f":1},{"p":524318,"g":{"r":0,"d":0,"h":150325149732,"f":2},"s":{"r":0,"d":0,"h":154620117028,"f":2},"n":"JS","d":1294372,"h":146030182436,"f":2,"a":[{"t":4259848,"c":21479096328}]},{"p":4980744,"g":{"r":0,"d":0,"h":167505018916,"f":2},"s":{"r":0,"d":0,"h":171799986212,"f":2},"n":"Nav","o":"N","d":1294372,"h":163210051620,"f":2,"a":[{"t":4259848,"c":21479096328}]},{"p":180260,"g":{"r":0,"d":0,"h":184684888100,"f":2},"s":{"r":0,"d":0,"h":188979855396,"f":2},"n":"TaskService","o":"TS","d":1294372,"h":180389920804,"f":2,"a":[{"t":4259848,"c":21479096328}]},{"p":1884196,"g":{"r":0,"d":0,"h":201864757284,"f":2},"s":{"r":0,"d":0,"h":206159724580,"f":2},"n":"Auth","o":"A$1","d":1294372,"h":197569789988,"f":2,"a":[{"t":4259848,"c":21479096328}]}],"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","o":"B","d":1294372,"h":4296261668,"f":32772},{"r":$.$$.SCG.L$$($.$m.A).$h,"n":"GetFilteredTasks","o":"GF","d":1294372,"h":73015738404,"f":2},{"r":133169153,"n":"OnInitializedAsync","o":"OIA","d":1294372,"h":77310705700,"f":36868},{"r":133169153,"p":[{"n":"firstRender","p":262145}],"n":"OnAfterRenderAsync","o":"OA","d":1294372,"h":81605672996,"f":36868},{"r":65537,"n":"OnInitialized","o":"OI","d":1294372,"h":85900640292,"f":32772},{"r":133169153,"n":"AddTask","o":"AT","d":1294372,"h":90195607588,"f":4098},{"r":133169153,"n":"MoveCompletedTask","o":"MC","d":1294372,"h":94490574884,"f":4098},{"r":65537,"n":"AllTasks","o":"AT$1","d":1294372,"h":98785542180,"f":2},{"r":65537,"n":"Pending","o":"P$1","d":1294372,"h":103080509476,"f":2},{"r":65537,"n":"Completed","o":"C$1","d":1294372,"h":107375476772,"f":2},{"r":65537,"p":[{"n":"id","p":655361}],"n":"ToggleTask","o":"TT","d":1294372,"h":111670444068,"f":2},{"r":133169153,"p":[{"n":"id","p":655361}],"n":"DeleteTask","o":"DT","d":1294372,"h":115965411364,"f":4098},{"r":133169153,"n":"ClearTask","o":"CT","d":1294372,"h":120260378660,"f":4098},{"r":133169153,"n":"SaveTask","o":"ST","d":1294372,"h":124555345956,"f":4098},{"r":65537,"n":"RefreshTasks","o":"RT","d":1294372,"h":128850313252,"f":2},{"r":65537,"n":"HandleStateChanged","o":"H","d":1294372,"h":133145280548,"f":2},{"r":65537,"n":"Dispose","o":"D$1","d":1294372,"h":137440247844,"f":1}],"l":[{"t":1310721,"n":"taskTitle","o":"tT","d":1294372,"h":8591228964,"f":2},{"t":1949732,"n":"taskPriority","o":"tP","d":1294372,"h":30066065444,"f":2},{"t":$.$$.SCG.L$$($.$m.A).$h,"n":"tasks","o":"t$1","d":1294372,"h":42950967332,"f":1},{"t":$.$$.SCG.L$$($.$m.A).$h,"n":"completedTasks","o":"cT","d":1294372,"h":47245934628,"f":1},{"t":262145,"n":"confirmClear","o":"cC","d":1294372,"h":51540901924,"f":1},{"t":114724,"n":"Taskss","o":"T$1","d":1294372,"h":55835869220,"f":2},{"t":1310721,"n":"currentFilter","o":"cF","d":1294372,"h":60130836516,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":1294372,"h":210454691876,"f":1}],"i":[2752520,3145736,3080200,57540609],"h":1294372,"a":[{"t":9895944,"c":4304863240,"a":[{"v":"/tasks","t":1310721}]}]}; }
            static get $b() { return $.$mac.MAC.CB; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IC, $.$mac.MAC.IHE, $.$mac.MAC.IH, $.$$.S.ID ]; }
            static get $fullName() { return `miniapp.Components.Pages.Tasks`; }
        });
        
        $asm.$cls("$m.mL.M", ($self) => class MainLayout extends $.$mac.MAC.LC
        {
            /*void */ B(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OE(0, "div");
                __builder.AA$2(1, "class", "page");
                __builder.AA$4(2, "b-51e18s3qyg");
                __builder.OE(3, "main");
                __builder.AA$4(4, "b-51e18s3qyg");
                __builder.OE(5, "article");
                __builder.AA$2(6, "class", "content");
                __builder.AA$2(7, "style", "padding: 10px;");
                __builder.AA$4(8, "b-51e18s3qyg");
                __builder.AC$5(9, this.B$1);
                __builder.CE();
                __builder.CE();
                __builder.CE();
                __builder.AM(10, "\n\n");
                __builder.AM(11, "<div id=\"blazor-error-ui\" data-nosnippet b-51e18s3qyg>\n    An unhandled error has occurred.\n    <a href=\".\" class=\"reload\" b-51e18s3qyg>Reload</a>\n    <span class=\"dismiss\" b-51e18s3qyg>\uD83D\uDDD9</span></div>");
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 1687588;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":4653064,"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","o":"B","d":1687588,"h":4296654884,"f":32772}],"c":[{"n":".ctor","o":"$ctor$3","d":1687588,"h":8591622180,"f":1}],"i":[2752520,3145736,3080200],"h":1687588}; }
            static get $b() { return $.$mac.MAC.LC; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IC, $.$mac.MAC.IHE, $.$mac.MAC.IH ]; }
            static get $fullName() { return `miniapp.Layout.MainLayout`; }
        });
        
        $asm.$str("$m.P$1", ($self) => class Priority extends $.$$.S.E$3
        {
            static Select_Priority = 0;
            static Low = 1;
            static Medium = 2;
            static High = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Select_Priority": 0n,
                    "Low": 1n,
                    "Medium": 2n,
                    "High": 3n
                };
            }
            static $h = 1949732;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.S.I$4; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1949732,"n":"Select_Priority","o":"S_","d":1949732,"h":4296917028,"f":33},{"t":1949732,"n":"Low","o":"L","d":1949732,"h":8591884324,"f":33},{"t":1949732,"n":"Medium","o":"M$1","d":1949732,"h":12886851620,"f":33},{"t":1949732,"n":"High","o":"H$1","d":1949732,"h":17181818916,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1949732,"h":21476786212,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1949732}; }
            static get $b() { return $.$$.S.E$3; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IC$1, $.$$.S.IS, $.$$.S.IF$1, $.$$.S.IC$2 ]; }
            static get $fullName() { return `Priority`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.Extensions.Validation", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.Logging", "NetJs.Microsoft.JSInterop.WebAssembly", "NetJs.Microsoft.AspNetCore.Components.WebAssembly", "NetJs.Microsoft.CSharp", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument"))