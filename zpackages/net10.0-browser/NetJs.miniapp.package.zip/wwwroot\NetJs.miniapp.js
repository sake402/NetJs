
(function ($global, $, $spc, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sri, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mam, $mep, $meca, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mxdi, $sca, $meo, $meda, $meoc, $mxdg, $mela, $maa, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sipl, $stew, $stj, $mac, $mev, $srsp, $macf, $med, $mj, $macw, $mefa, $mef, $sifw, $mefp, $mecf, $mecj, $mel, $mjw, $macwa, $mc, $slq, $snhj, $stec, $swh, $sxx, $sxxx) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.miniapp", 
    {"g":1,"h":48551,"f":"miniapp","v":"1.0.0.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"miniapp","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.0.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.0","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"miniapp","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"miniapp","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.0.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$m.ITaskService", ($self) => class ITaskService
        {
            static $h = 179623;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":133300225,"n":"SaveTask","o":"ITaskService$SaveTask","d":179623,"h":17180048807,"f":257},{"r":133300225,"n":"LoadTasks","o":"ITaskService$LoadTasks","d":179623,"h":21475016103,"f":257},{"r":$.$spc.System.Collections.Generic.List$$($.$m.AppTask).$h,"n":"GetAll","o":"ITaskService$GetAll","d":179623,"h":25769983399,"f":257},{"r":65537,"p":[{"n":"title","p":1310721},{"n":"priority","p":1949095}],"n":"Add","o":"ITaskService$Add","d":179623,"h":30064950695,"f":257},{"r":65537,"p":[{"n":"title","p":1310721},{"n":"priority","p":1949095}],"n":"MoveTask","o":"ITaskService$MoveTask","d":179623,"h":34359917991,"f":257},{"r":65537,"p":[{"n":"id","p":655361}],"n":"Delete","o":"ITaskService$Delete","d":179623,"h":38654885287,"f":257},{"r":65537,"n":"ClearAllTask","o":"ITaskService$ClearAllTask","d":179623,"h":42949852583,"f":257},{"r":65537,"p":[{"n":"id","p":655361}],"n":"ToggleCompleted","o":"ITaskService$ToggleCompleted","d":179623,"h":47244819879,"f":257},{"r":655361,"n":"GetCompletedCount","o":"ITaskService$GetCompletedCount","d":179623,"h":51539787175,"f":257},{"r":655361,"n":"GetPendingCount","o":"ITaskService$GetPendingCount","d":179623,"h":55834754471,"f":257}],"e":[{"e":11665409,"m":{"r":65537,"p":[{"n":"value","p":11665409}],"n":"add_OnChange","o":"ITaskService$add_OnChange","d":179623,"h":4295146919,"f":257},"r":{"r":65537,"p":[{"n":"value","p":11665409}],"n":"remove_OnChange","o":"ITaskService$remove_OnChange","d":179623,"h":8590114215,"f":257},"n":"OnChange","o":"ITaskService$OnChange","d":179623,"h":12885081511,"f":257}],"h":179623}; }
            static get $fullName() { return `ITaskService`; }
        });
        
        $asm.$cls("$m.miniapp._Imports", ($self) => class _Imports extends $.$spc.System.Object
        {
            /*void */ Execute()
            {
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 376231;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"n":"Execute","d":376231,"h":4295343527,"f":4}],"c":[{"n":".ctor","o":"$ctor$1","d":376231,"h":8590310823,"f":1}],"h":376231}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `miniapp._Imports`; }
        });
        
        $asm.$cls("$m.AppTask", ($self) => class AppTask extends $.$spc.System.Object
        {
            /*int*/ Id = 0;
            /*string*/ Title = null;
            /*Priority*/ Priority = 0;
            /*bool*/ IsComplete = false;
            /*string*/ Date = null;
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Title = "";
                this.Priority = 2;
                this.IsComplete = false;
                this.Date = "";
            }
            static $h = 114087;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885015975,"f":1},"s":{"r":0,"d":0,"h":17179983271,"f":1},"n":"Id","d":114087,"h":8590048679,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":30064885159,"f":1},"s":{"r":0,"d":0,"h":34359852455,"f":1},"n":"Title","d":114087,"h":25769917863,"f":1},{"p":1949095,"g":{"r":0,"d":0,"h":47244754343,"f":1},"s":{"r":0,"d":0,"h":51539721639,"f":1},"n":"Priority","d":114087,"h":42949787047,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":64424623527,"f":1},"s":{"r":0,"d":0,"h":68719590823,"f":1},"n":"IsComplete","d":114087,"h":60129656231,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":81604492711,"f":1},"s":{"r":0,"d":0,"h":85899460007,"f":1},"n":"Date","d":114087,"h":77309525415,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":114087,"h":90194427303,"f":1}],"h":114087}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `AppTask`; }
        });
        
        $asm.$cls("$m.UserModel", ($self) => class UserModel extends $.$spc.System.Object
        {
            /*string*/ FirstName = null;
            /*string*/ LastName = null;
            /*string*/ Email = null;
            /*DateTime?*/ DateOfBirth = null;
            /*string*/ Username = null;
            /*string*/ Password = null;
            /*string*/ ConfirmPassword = null;
            /*string*/ Role = null;
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.FirstName = "";
                this.LastName = "";
                this.Email = "";
                this.DateOfBirth = null;
                this.Username = "";
                this.Password = "";
                this.ConfirmPassword = "";
                this.Role = "";
            }
            static $h = 2145703;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12887047591,"f":1},"s":{"r":0,"d":0,"h":17182014887,"f":1},"n":"FirstName","d":2145703,"h":8592080295,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":30066916775,"f":1},"s":{"r":0,"d":0,"h":34361884071,"f":1},"n":"LastName","d":2145703,"h":25771949479,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":47246785959,"f":1},"s":{"r":0,"d":0,"h":51541753255,"f":1},"n":"Email","d":2145703,"h":42951818663,"f":1},{"p":$.$typeNullable($.$spc.System.DateTime).$h,"g":{"r":0,"d":0,"h":64426655143,"f":1},"s":{"r":0,"d":0,"h":68721622439,"f":1},"n":"DateOfBirth","d":2145703,"h":60131687847,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":81606524327,"f":1},"s":{"r":0,"d":0,"h":85901491623,"f":1},"n":"Username","d":2145703,"h":77311557031,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":98786393511,"f":1},"s":{"r":0,"d":0,"h":103081360807,"f":1},"n":"Password","d":2145703,"h":94491426215,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":115966262695,"f":1},"s":{"r":0,"d":0,"h":120261229991,"f":1},"n":"ConfirmPassword","d":2145703,"h":111671295399,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":133146131879,"f":1},"s":{"r":0,"d":0,"h":137441099175,"f":1},"n":"Role","d":2145703,"h":128851164583,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":2145703,"h":141736066471,"f":1}],"h":2145703}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `UserModel`; }
        });
        
        $asm.$cls("$m.Program", ($self) => class Program
        {
            static async $$$(args)
            {
                /*var*/ let builder = $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyHostBuilder.CreateDefault(args);
                builder.RootComponents.Add$1($.$m.miniapp.App, "#app");
                builder.RootComponents.Add$1($.$macw.Microsoft.AspNetCore.Components.Web.HeadOutlet, "head::after");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddScoped$4($.$m.miniapp.Services.AuthService, builder.Services);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddScoped$2($.$m.ITaskService, $.$m.TaskService, builder.Services);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddScoped$5($.$snh.System.Net.Http.HttpClient, builder.Services, new ($.$spc.System.Func$$$($.$scm.System.IServiceProvider, $.$snh.System.Net.Http.HttpClient))().$ctor(this,  (/*sp*/ sp) =>
                {
                    return (() =>
                    {
                        //new $.$snh.System.Net.Http.HttpClient()
                        const $t1 = $.$snh.System.Net.Http.HttpClient;
                        const $i1 = new $t1();
                        $i1.$ctor$3();
                        $i1.BaseAddress = new $.$spu.System.Uri().$ctor$2(builder.HostEnvironment.Microsoft$AspNetCore$Components$WebAssembly$Hosting$IWebAssemblyHostEnvironment$BaseAddress);
                        return $i1;
                    })();
                }, {"r":6422573,"p":[{"n":"sp","p":327717}],"n":"","d":2014631,"h":0,"f":1048578}));
                await builder.Build().RunAsync();
            }
            static $h = 2014631;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":133300225,"p":[{"n":"args","p":0}],"n":"\u003CMain\u003E$","o":"$$$","d":2014631,"h":4296981927,"f":4130}],"c":[{"n":".ctor","o":"$ctor$1","d":2014631,"h":8591949223,"f":1}],"h":2014631}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Program`; }
        });
        
        $asm.$cls("$m.miniapp.Components._Imports", ($self) => class _Imports extends $.$spc.System.Object
        {
            /*void */ Execute()
            {
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 507303;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"n":"Execute","d":507303,"h":4295474599,"f":4}],"c":[{"n":".ctor","o":"$ctor$1","d":507303,"h":8590441895,"f":1}],"h":507303}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `miniapp.Components._Imports`; }
        });
        
        $asm.$cls("$m.miniapp.Services.AuthService", ($self) => class AuthService extends $.$spc.System.Object
        {
            /*IJSRuntime*/ JS = null;
            $ctor$1(/*IJSRuntime*/ jS)
            {
                super.$ctor();
                {
                    this.JS = jS;
                }
                return this;
            }
            /*bool*/ IsLoggedIn = false;
            /*string*/ Username = null;
            /*string*/ Role = null;
            /*string*/ Firstname = null;
            /*string*/ Lastname = null;
            /*string*/ Email = null;
            /*string*/ DateOfBirth = null;
            /*string*/ Password1 = null;
            /*string*/ ConfirmPassword = null;
            /*bool*/ userExists = false;
            /*UserModel*/ newUser = null;
            /*List<UserModel>*/ _user = null;
            /*Action?*/ OnChange = null;
            add_OnChange(/*Action?*/ value)
            {
                this.OnChange = $.$spc.System.Delegate.Combine(this.OnChange, value);
            }
            remove_OnChange(/*Action?*/ value)
            {
                this.OnChange = $.$spc.System.Delegate.Remove(this.OnChange, value);
            }
            /*void */ Notify()
            {
                return (this.OnChange?.Invoke() ?? null);
            }
            /*List<UserModel>*/ users = null;
            /*Task<string> *//*async*/  SignUp(/*string*/ firstname, /*string*/ lastname, /*string*/ email, /*string*/ role, /*DateTime?*/ dateOfBirth, /*string*/ username, /*string*/ password, /*string*/ confirmPassword)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$spc.System.String), $.$spc.System.String, async () => 
                {
                    this.Firstname = firstname;
                    this.Lastname = lastname;
                    this.Email = email;
                    this.DateOfBirth = (dateOfBirth?.ToString$1("yyyy-MM-dd") ?? null) ?? "";
                    this.Username = username;
                    this.Password1 = password;
                    this.ConfirmPassword = confirmPassword;
                    this.Role = role;
                    if ($.$spc.System.String.op_Inequality(password, confirmPassword))
                    {
                        return "Passwords do not match.";
                    }
                    this.userExists = $.$sl.System.Linq.Enumerable.Any$1($.$m.UserModel, this.users, new ($.$spc.System.Func$$$($.$m.UserModel, $.$spc.System.Boolean))().$ctor(this,  (/*u*/ u) =>
                    {
                        return $.$spc.System.String.Equals$3.call(u.Username, username, 5/*StringComparison.OrdinalIgnoreCase*/);
                    }, {"r":262145,"p":[{"n":"u","p":2145703}],"n":"","d":1883559,"h":0,"f":1048578}));
                    if (this.userExists)
                    {
                        return "Username is already taken.";
                    }
                    this.newUser = (() =>
                    {
                        //new $.$m.UserModel()
                        const $t1 = $.$m.UserModel;
                        const $i1 = new $t1();
                        $i1.FirstName = firstname;
                        $i1.LastName = lastname;
                        $i1.Email = email;
                        $i1.DateOfBirth = dateOfBirth?.Clone() ?? null;
                        $i1.Username = username;
                        $i1.Password = password;
                        $i1.Role = role;
                        return $i1;
                    })();
                    this.users.Add(this.newUser);
                    await this.SaveUser();
                    await this.LoadUsers();
                    this.Notify();
                    return "Success";
                });
            }
            /*bool */ Login(/*string*/ username, /*string*/ password)
            {
                /*var*/ let user = $.$sl.System.Linq.Enumerable.FirstOrDefault$2($.$m.UserModel, this.users, new ($.$spc.System.Func$$$($.$m.UserModel, $.$spc.System.Boolean))().$ctor(this,  (/*u*/ u) =>
                {
                    return $.$spc.System.String.op_Equality(u.Username, username) && $.$spc.System.String.op_Equality(u.Password, password);
                }, {"r":262145,"p":[{"n":"u","p":2145703}],"n":"","d":1883559,"h":0,"f":1048578}));
                if (user === null)
                {
                    this.IsLoggedIn = false;
                    return false;
                }
                this.IsLoggedIn = true;
                this.Username = user.Username ?? "";
                this.Role = user.Role ?? "";
                this.Firstname = user.FirstName ?? "";
                this.Lastname = user.LastName ?? "";
                this.Email = user.Email ?? "";
                this.DateOfBirth = (user.DateOfBirth?.ToString$1("yyyy-MM-dd") ?? null) ?? "";
                this.Notify();
                return true;
            }
            /*void */ Logout()
            {
                this.IsLoggedIn = false;
                this.Username = "";
                this.Role = "";
                this.Firstname = "";
                this.Lastname = "";
                this.Email = "";
                this.DateOfBirth = "";
                this.Notify();
            }
            /*Task *//*async*/  SaveUser()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    /*var*/ let jsonString = $.$stj.System.Text.Json.JsonSerializer.Serialize$5($.$spc.System.Collections.Generic.List$$($.$m.UserModel), this.users, null);
                    await $.$mj.Microsoft.JSInterop.JSRuntimeExtensions.InvokeVoidAsync(this.JS, "localStorage.setItem", $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [ "All_Users", jsonString ], null, null));
                });
            }
            /*bool*/ loaded = false;
            /*Task *//*async*/  LoadUsers()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    if (this.loaded)
                    {
                        return;
                    }
                    /*var*/ let jsonString = await $.$mj.Microsoft.JSInterop.JSRuntimeExtensions.InvokeAsync($.$spc.System.String, this.JS, "localStorage.getItem", $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [ "All_Users" ], null, null));
                    if (!$.$spc.System.String.IsNullOrEmpty(jsonString))
                    {
                        /*var*/ let savedUsers = $.$stj.System.Text.Json.JsonSerializer.Deserialize$30($.$spc.System.Collections.Generic.List$$($.$m.UserModel), jsonString, null);
                        if (savedUsers !== null)
                        {
                            this.users = savedUsers;
                        }
                    }
                    this.loaded = true;
                });
            }
            /*Task *//*async*/  DeleteAccount()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    if (!this.IsLoggedIn)
                    {
                        return;
                    }
                    /*var*/ let userToRemove = $.$sl.System.Linq.Enumerable.FirstOrDefault$2($.$m.UserModel, this.users, new ($.$spc.System.Func$$$($.$m.UserModel, $.$spc.System.Boolean))().$ctor(this,  (/*u*/ u) =>
                    {
                        return $.$spc.System.String.Equals$3.call(u.Username, this.Username, 5/*StringComparison.OrdinalIgnoreCase*/);
                    }, {"r":262145,"p":[{"n":"u","p":2145703}],"n":"","d":1883559,"h":0,"f":1048578}));
                    if (userToRemove !== null)
                    {
                        this.users.Remove(userToRemove);
                    }
                    /*var*/ let jsonString = $.$stj.System.Text.Json.JsonSerializer.Serialize$5($.$spc.System.Collections.Generic.List$$($.$m.UserModel), this.users, null);
                    await $.$mj.Microsoft.JSInterop.JSRuntimeExtensions.InvokeVoidAsync(this.JS, "localStorage.setItem", $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [ "All_Users", jsonString ], null, null));
                    this.Logout();
                });
            }
            //default member initializer
            constructor()
            {
                super();
                this.IsLoggedIn = false;
                this.Username = "";
                this.Role = "";
                this.Firstname = "";
                this.Lastname = "";
                this.Email = "";
                this.DateOfBirth = "";
                this.Password1 = "";
                this.ConfirmPassword = "";
                this.userExists = true;
                this._user = new ($.$spc.System.Collections.Generic.List$$($.$m.UserModel))().$ctor$1();
                this.users = (() =>
                {
                    //new $.$spc.System.Collections.Generic.List$$($.$m.UserModel)()
                    const $t1 = $.$spc.System.Collections.Generic.List$$($.$m.UserModel);
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.Add((() =>
                    {
                        //new $.$m.UserModel()
                        const $t2 = $.$m.UserModel;
                        const $i2 = new $t2();
                        $i2.Username = "Olabode";
                        $i2.Password = "1234";
                        $i2.Role = "Admin";
                        $i2.Email = "benny@mail.com";
                        return $i2;
                    })());
                    $i1.Add((() =>
                    {
                        //new $.$m.UserModel()
                        const $t3 = $.$m.UserModel;
                        const $i3 = new $t3();
                        $i3.Username = "Benedicta";
                        $i3.Password = "2345";
                        $i3.Role = "Admin";
                        return $i3;
                    })());
                    $i1.Add((() =>
                    {
                        //new $.$m.UserModel()
                        const $t4 = $.$m.UserModel;
                        const $i4 = new $t4();
                        $i4.Username = "Blessing";
                        $i4.Password = "3456";
                        $i4.Role = "User";
                        return $i4;
                    })());
                    return $i1;
                })();
            }
            static $h = 1883559;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":21476720039,"f":1},"s":{"r":0,"d":0,"h":25771687335,"f":2},"n":"IsLoggedIn","d":1883559,"h":17181752743,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":38656589223,"f":1},"s":{"r":0,"d":0,"h":42951556519,"f":2},"n":"Username","d":1883559,"h":34361621927,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":55836458407,"f":1},"s":{"r":0,"d":0,"h":60131425703,"f":2},"n":"Role","d":1883559,"h":51541491111,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":73016327591,"f":1},"s":{"r":0,"d":0,"h":77311294887,"f":2},"n":"Firstname","d":1883559,"h":68721360295,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":90196196775,"f":1},"s":{"r":0,"d":0,"h":94491164071,"f":2},"n":"Lastname","d":1883559,"h":85901229479,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":107376065959,"f":1},"s":{"r":0,"d":0,"h":111671033255,"f":2},"n":"Email","d":1883559,"h":103081098663,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":124555935143,"f":1},"s":{"r":0,"d":0,"h":128850902439,"f":2},"n":"DateOfBirth","d":1883559,"h":120260967847,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":141735804327,"f":1},"s":{"r":0,"d":0,"h":146030771623,"f":2},"n":"Password1","d":1883559,"h":137440837031,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":158915673511,"f":1},"s":{"r":0,"d":0,"h":163210640807,"f":2},"n":"ConfirmPassword","d":1883559,"h":154620706215,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":176095542695,"f":1},"s":{"r":0,"d":0,"h":180390509991,"f":2},"n":"userExists","d":1883559,"h":171800575399,"f":1},{"p":2145703,"g":{"r":0,"d":0,"h":193275411879,"f":1},"s":{"r":0,"d":0,"h":197570379175,"f":2},"n":"newUser","d":1883559,"h":188980444583,"f":1}],"m":[{"r":65537,"n":"Notify","d":1883559,"h":219045215655,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.String).$h,"p":[{"n":"firstname","p":1310721},{"n":"lastname","p":1310721},{"n":"email","p":1310721},{"n":"role","p":1310721},{"n":"dateOfBirth","p":$.$typeNullable($.$spc.System.DateTime).$h},{"n":"username","p":1310721},{"n":"password","p":1310721},{"n":"confirmPassword","p":1310721}],"n":"SignUp","d":1883559,"h":227635150247,"f":4097},{"r":262145,"p":[{"n":"username","p":1310721},{"n":"password","p":1310721}],"n":"Login","d":1883559,"h":231930117543,"f":1},{"r":65537,"n":"Logout","d":1883559,"h":236225084839,"f":1},{"r":133300225,"n":"SaveUser","d":1883559,"h":240520052135,"f":4097},{"r":133300225,"n":"LoadUsers","d":1883559,"h":249109986727,"f":4097},{"r":133300225,"n":"DeleteAccount","d":1883559,"h":253404954023,"f":4097}],"l":[{"t":524318,"n":"JS","d":1883559,"h":4296850855,"f":2},{"t":$.$spc.System.Collections.Generic.List$$($.$m.UserModel).$h,"n":"_user","d":1883559,"h":201865346471,"f":1},{"t":$.$spc.System.Collections.Generic.List$$($.$m.UserModel).$h,"n":"users","d":1883559,"h":223340182951,"f":2},{"t":262145,"n":"loaded","d":1883559,"h":244815019431,"f":2}],"c":[{"p":[{"n":"jS","p":524318}],"n":".ctor","o":"$ctor$1","d":1883559,"h":8591818151,"f":1}],"e":[{"e":11665409,"m":{"r":65537,"p":[{"n":"value","p":11665409}],"n":"add_OnChange","d":1883559,"h":206160313767,"f":1},"r":{"r":65537,"p":[{"n":"value","p":11665409}],"n":"remove_OnChange","d":1883559,"h":210455281063,"f":1},"n":"OnChange","d":1883559,"h":214750248359,"f":1}],"h":1883559}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `miniapp.Services.AuthService`; }
        });
        
        $asm.$cls("$m.TaskService", ($self) => class TaskService extends $.$spc.System.Object
        {
            /*IJSRuntime*/ JS = null;
            $ctor$1(/*IJSRuntime*/ jS)
            {
                super.$ctor();
                {
                    this.JS = jS;
                }
                return this;
            }
            /*object*/ _lock = null;
            /*AppTask*/ newTask = null;
            /*List<AppTask>*/ tasks = null;
            /*Action?*/ OnChange = null;
            add_OnChange(/*Action?*/ value)
            {
                this.OnChange = $.$spc.System.Delegate.Combine(this.OnChange, value);
            }
            remove_OnChange(/*Action?*/ value)
            {
                this.OnChange = $.$spc.System.Delegate.Remove(this.OnChange, value);
            }
            /*void */ Notify()
            {
                return (this.OnChange?.Invoke() ?? null);
            }
            /*List<AppTask> */ GetAll()
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._lock)
                    {
                        return $.$sl.System.Linq.Enumerable.ToList($.$m.AppTask, this.tasks);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._lock)
                }
            }
            /*void */ Add(/*string*/ title, /*Priority*/ priority)
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._lock)
                    {
                        this.newTask = (() =>
                        {
                            //new $.$m.AppTask()
                            const $t1 = $.$m.AppTask;
                            const $i1 = new $t1();
                            $i1.Id = $.$sl.System.Linq.Enumerable.Any($.$m.AppTask, this.tasks) ? (($.$sl.System.Linq.Enumerable.Max$12($.$m.AppTask, this.tasks, new ($.$spc.System.Func$$$($.$m.AppTask, $.$spc.System.Int32))().$ctor(this,  (/*t*/ t) =>
                            {
                                return t.Id;
                            }, {"r":655361,"p":[{"n":"t","p":114087}],"n":"","d":2080167,"h":0,"f":1048578})) + 1) | 0) : 1;
                            $i1.Title = title;
                            $i1.Priority = priority;
                            $i1.Date = $.$spc.System.DateTime.Now.ToString$1("dd MMM yyyy");
                            $i1.IsComplete = false;
                            return $i1;
                        })();
                        this.tasks.Add(this.newTask);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._lock)
                }
                this.Notify();
            }
            /*void */ MoveTask(/*string*/ title, /*Priority*/ priority)
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._lock)
                    {
                        this.newTask = (() =>
                        {
                            //new $.$m.AppTask()
                            const $t1 = $.$m.AppTask;
                            const $i1 = new $t1();
                            $i1.Id = $.$sl.System.Linq.Enumerable.Any($.$m.AppTask, this.tasks) ? (($.$sl.System.Linq.Enumerable.Max$12($.$m.AppTask, this.tasks, new ($.$spc.System.Func$$$($.$m.AppTask, $.$spc.System.Int32))().$ctor(this,  (/*t*/ t) =>
                            {
                                return t.Id;
                            }, {"r":655361,"p":[{"n":"t","p":114087}],"n":"","d":2080167,"h":0,"f":1048578})) + 1) | 0) : 1;
                            $i1.Title = title;
                            $i1.Priority = priority;
                            $i1.Date = $.$spc.System.DateTime.Now.ToString$1("dd MMM yyyy");
                            $i1.IsComplete = true;
                            return $i1;
                        })();
                        this.tasks.Add(this.newTask);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._lock)
                }
                this.Notify();
            }
            /*void */ Delete(/*int*/ id)
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._lock)
                    {
                        this.tasks.RemoveAll(new ($.$spc.System.Predicate$$($.$m.AppTask))().$ctor(this,  (/*t*/ t) =>
                        {
                            return t.Id === id;
                        }, {"r":262145,"p":[{"n":"t","p":114087}],"n":"","d":2080167,"h":0,"f":1048578}));
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._lock)
                }
                this.Notify();
            }
            /*void */ ClearAllTask()
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._lock)
                    {
                        this.tasks.Clear();
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._lock)
                }
                this.Notify();
            }
            /*Task *//*async*/  SaveTask()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    /*var*/ let jsonString = $.$stj.System.Text.Json.JsonSerializer.Serialize$5($.$spc.System.Collections.Generic.List$$($.$m.AppTask), this.tasks, null);
                    await $.$mj.Microsoft.JSInterop.JSRuntimeExtensions.InvokeVoidAsync(this.JS, "localStorage.setItem", $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [ "All_Tasks", jsonString ], null, null));
                });
            }
            /*bool*/ loaded = false;
            /*Task *//*async*/  LoadTasks()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    if (this.loaded)
                    {
                        return;
                    }
                    /*var*/ let jsonString = await $.$mj.Microsoft.JSInterop.JSRuntimeExtensions.InvokeAsync($.$spc.System.String, this.JS, "localStorage.getItem", $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [ "All_Tasks" ], null, null));
                    if (!$.$spc.System.String.IsNullOrEmpty(jsonString))
                    {
                        /*var*/ let savedTasks = $.$stj.System.Text.Json.JsonSerializer.Deserialize$30($.$spc.System.Collections.Generic.List$$($.$m.AppTask), jsonString, null);
                        if (savedTasks !== null)
                        {
                            this.tasks = savedTasks;
                        }
                    }
                    this.loaded = true;
                });
            }
            /*void */ ToggleCompleted(/*int*/ id)
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._lock)
                    {
                        /*var*/ let task = $.$sl.System.Linq.Enumerable.FirstOrDefault$2($.$m.AppTask, this.tasks, new ($.$spc.System.Func$$$($.$m.AppTask, $.$spc.System.Boolean))().$ctor(this,  (/*t*/ t) =>
                        {
                            return t.Id === id;
                        }, {"r":262145,"p":[{"n":"t","p":114087}],"n":"","d":2080167,"h":0,"f":1048578}));
                        const $t1 = task;
                        $.$ifnn($t1, ($t) => $t.IsComplete = !task.IsComplete);
                        this.SaveTask();
                        this.LoadTasks();
                        this.Notify();
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._lock)
                }
            }
            /*int */ GetCompletedCount()
            {
                return $.$sl.System.Linq.Enumerable.Count$1($.$m.AppTask, this.tasks, new ($.$spc.System.Func$$$($.$m.AppTask, $.$spc.System.Boolean))().$ctor(this,  (/**/ t) =>
                {
                    return t.IsComplete;
                }, {"r":262145,"p":[{"n":"t","p":114087}],"n":"","d":2080167,"h":0,"f":1048578}));
            }
            /*int */ GetPendingCount()
            {
                return $.$sl.System.Linq.Enumerable.Count$1($.$m.AppTask, this.tasks, new ($.$spc.System.Func$$$($.$m.AppTask, $.$spc.System.Boolean))().$ctor(this,  (/**/ t) =>
                {
                    return !t.IsComplete;
                }, {"r":262145,"p":[{"n":"t","p":114087}],"n":"","d":2080167,"h":0,"f":1048578}));
            }
            //Generated interface implemetation for ITaskService.OnChange.add
            ITaskService$add_OnChange()
            {
                return this.add_OnChange(...arguments);
            }
            //Generated interface implemetation for ITaskService.OnChange.remove
            ITaskService$remove_OnChange()
            {
                return this.remove_OnChange(...arguments);
            }
            //Generated interface implemetation for ITaskService.OnChange
            ITaskService$OnChange()
            {
                this.OnChange;
            }
            //Generated interface implemetation for ITaskService.SaveTask()
            ITaskService$SaveTask()
            {
                return this.SaveTask(...arguments);
            }
            //Generated interface implemetation for ITaskService.LoadTasks()
            ITaskService$LoadTasks()
            {
                return this.LoadTasks(...arguments);
            }
            //Generated interface implemetation for ITaskService.GetAll()
            ITaskService$GetAll()
            {
                return this.GetAll(...arguments);
            }
            //Generated interface implemetation for ITaskService.Add(string, Priority)
            ITaskService$Add()
            {
                return this.Add(...arguments);
            }
            //Generated interface implemetation for ITaskService.MoveTask(string, Priority)
            ITaskService$MoveTask()
            {
                return this.MoveTask(...arguments);
            }
            //Generated interface implemetation for ITaskService.Delete(int)
            ITaskService$Delete()
            {
                return this.Delete(...arguments);
            }
            //Generated interface implemetation for ITaskService.ClearAllTask()
            ITaskService$ClearAllTask()
            {
                return this.ClearAllTask(...arguments);
            }
            //Generated interface implemetation for ITaskService.ToggleCompleted(int)
            ITaskService$ToggleCompleted()
            {
                return this.ToggleCompleted(...arguments);
            }
            //Generated interface implemetation for ITaskService.GetCompletedCount()
            ITaskService$GetCompletedCount()
            {
                return this.GetCompletedCount(...arguments);
            }
            //Generated interface implemetation for ITaskService.GetPendingCount()
            ITaskService$GetPendingCount()
            {
                return this.GetPendingCount(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this._lock = new $.$spc.System.Object().$ctor();
                this.newTask = new $.$m.AppTask().$ctor$1();
                this.tasks = new ($.$spc.System.Collections.Generic.List$$($.$m.AppTask))().$ctor$1();
            }
            static $h = 2080167;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"n":"Notify","d":2080167,"h":38656785831,"f":1},{"r":$.$spc.System.Collections.Generic.List$$($.$m.AppTask).$h,"n":"GetAll","d":2080167,"h":42951753127,"f":1},{"r":65537,"p":[{"n":"title","p":1310721},{"n":"priority","p":1949095}],"n":"Add","d":2080167,"h":47246720423,"f":1},{"r":65537,"p":[{"n":"title","p":1310721},{"n":"priority","p":1949095}],"n":"MoveTask","d":2080167,"h":51541687719,"f":1},{"r":65537,"p":[{"n":"id","p":655361}],"n":"Delete","d":2080167,"h":55836655015,"f":1},{"r":65537,"n":"ClearAllTask","d":2080167,"h":60131622311,"f":1},{"r":133300225,"n":"SaveTask","d":2080167,"h":64426589607,"f":4097},{"r":133300225,"n":"LoadTasks","d":2080167,"h":73016524199,"f":4097},{"r":65537,"p":[{"n":"id","p":655361}],"n":"ToggleCompleted","d":2080167,"h":77311491495,"f":1},{"r":655361,"n":"GetCompletedCount","d":2080167,"h":81606458791,"f":1},{"r":655361,"n":"GetPendingCount","d":2080167,"h":85901426087,"f":1}],"l":[{"t":524318,"n":"JS","d":2080167,"h":4297047463,"f":2},{"t":131073,"n":"_lock","d":2080167,"h":12886982055,"f":2},{"t":114087,"n":"newTask","d":2080167,"h":17181949351,"f":1},{"t":$.$spc.System.Collections.Generic.List$$($.$m.AppTask).$h,"n":"tasks","d":2080167,"h":21476916647,"f":1},{"t":262145,"n":"loaded","d":2080167,"h":68721556903,"f":2}],"c":[{"p":[{"n":"jS","p":524318}],"n":".ctor","o":"$ctor$1","d":2080167,"h":8592014759,"f":1}],"e":[{"e":11665409,"m":{"r":65537,"p":[{"n":"value","p":11665409}],"n":"add_OnChange","d":2080167,"h":25771883943,"f":1},"r":{"r":65537,"p":[{"n":"value","p":11665409}],"n":"remove_OnChange","d":2080167,"h":30066851239,"f":1},"n":"OnChange","d":2080167,"h":34361818535,"f":1}],"i":[179623],"h":2080167}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$m.ITaskService ]; }
            static get $fullName() { return `TaskService`; }
        });
        
        $asm.$cls("$m.Microsoft.CodeAnalysis.EmbeddedAttribute", ($self) => class EmbeddedAttribute extends $.$spc.System.Attribute
        {
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 245159;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14548993,"c":[{"n":".ctor","o":"$ctor$2","d":245159,"h":4295212455,"f":1}],"h":245159}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
        });
        
        $asm.$cls("$m.Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute", ($self) => class ValidatableTypeAttribute extends $.$spc.System.Attribute
        {
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 310695;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14548993,"c":[{"n":".ctor","o":"$ctor$2","d":310695,"h":4295277991,"f":1}],"h":310695,"a":[{"t":245159,"c":4295212455},{"t":14680065,"c":21489516545,"a":[{"v":4,"t":14614529}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
        });
        
        $asm.$cls("$m.miniapp.Components.LoadingCardMajor", ($self) => class LoadingCardMajor extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.AddMarkupContent(0, "<div style=\"margin-bottom: 20px;\"><div style=\"width: 100%; height: 30px; border-radius: 20px; background: rgb(127, 127, 127, 0.2); margin-bottom: 5px;\"></div>\n    <div style=\"width: 100%; height: 30px; border-radius: 20px; background: rgb(127, 127, 127, 0.2); margin-bottom: 5px;\"></div>\n    <div style=\"width: 100%; height: 30px; border-radius: 20px; background: rgb(127, 127, 127, 0.2); margin-bottom: 5px;\"></div>\n    <div style=\"width: 100%; height: 30px; border-radius: 20px; background: rgb(127, 127, 127, 0.2); margin-bottom: 5px;\"></div>\n    <div style=\"width: 100%; height: 30px; border-radius: 20px; background: rgb(127, 127, 127, 0.2); margin-bottom: 5px;\"></div>\n    <div style=\"width: 100%; height: 30px; border-radius: 20px; background: rgb(127, 127, 127, 0.2); margin-bottom: 5px;\"></div>\n    <div style=\"width: 100%; height: 30px; border-radius: 20px; background: rgb(127, 127, 127, 0.2);\"></div></div>\n");
                __builder.OpenElement(1, "p");
                __builder.AddContent(2, this.LoadingState);
                __builder.CloseElement();
            }
            /*string*/ LoadingState = null;
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.LoadingState = "";
            }
            static $h = 703911;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17180573095,"f":1},"s":{"r":0,"d":0,"h":21475540391,"f":1},"n":"LoadingState","d":703911,"h":12885605799,"f":1,"a":[{"t":5636104,"c":21480472584}]}],"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","d":703911,"h":4295671207,"f":32772}],"c":[{"n":".ctor","o":"$ctor$2","d":703911,"h":25770507687,"f":1}],"i":[2752520,3145736,3080200],"h":703911}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `miniapp.Components.LoadingCardMajor`; }
        });
        
        $asm.$cls("$m.miniapp.Components.LoadingCardMinor", ($self) => class LoadingCardMinor extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$2(1, "style", "margin-bottom: 20px;");
                __builder.AddMarkupContent(2, "<div style=\"width: 100%; margin: 20px 0 0; align-items: center; justify-content: center; margin-bottom: 50px;\"><div style=\"margin-bottom: 0;\"><div style=\"width: 100%; height: 30px; border-radius: 20px; background: rgb(127, 127, 127, 0.2); margin-bottom: 5px;\"></div>\n            <div style=\"width: 100%; height: 30px; border-radius: 20px; background: rgb(127, 127, 127, 0.2); margin-bottom: 5px;\"></div>\n            <div style=\"width: 100%; height: 30px; border-radius: 20px; background: rgb(127, 127, 127, 0.2);\"></div></div></div>\n    ");
                __builder.OpenElement(3, "p");
                __builder.AddContent(4, this.LoadingState);
                __builder.CloseElement();
                __builder.CloseElement();
            }
            /*string*/ LoadingState = null;
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.LoadingState = "";
            }
            static $h = 769447;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17180638631,"f":1},"s":{"r":0,"d":0,"h":21475605927,"f":1},"n":"LoadingState","d":769447,"h":12885671335,"f":1,"a":[{"t":5636104,"c":21480472584}]}],"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","d":769447,"h":4295736743,"f":32772}],"c":[{"n":".ctor","o":"$ctor$2","d":769447,"h":25770573223,"f":1}],"i":[2752520,3145736,3080200],"h":769447}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `miniapp.Components.LoadingCardMinor`; }
        });
        
        $asm.$cls("$m.miniapp.Components.ButtonCard", ($self) => class ButtonCard extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OpenElement(0, "button");
                __builder.AddAttribute$5($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, 1, "onclick", $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$9($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, this, new ($.$spc.System.Func$$($.$spc.System.Threading.Tasks.Task))().$ctor(this, this.HandleClick)));
                __builder.AddAttribute$2(2, "style", "background:" + " " + (this.BgColor) + ";" + " padding:" + " 10px" + " 20px;" + " border:" + " none;" + " border-radius:" + " 10px;");
                __builder.AddContent(3, this.BtnText);
                __builder.CloseElement();
            }
            /*bool*/ ConfirmClear = false;
            /*string*/ BgColor = null;
            /*string*/ BtnText = null;
            /*EventCallback*/ OnClick;
            /*Task *//*async*/  HandleClick()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    await this.OnClick.InvokeAsync$1();
                });
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.ConfirmClear = false;
                this.BgColor = "";
                this.BtnText = "";
                this.OnClick = $.$default($.$mac.Microsoft.AspNetCore.Components.EventCallback);
            }
            static $h = 572839;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17180442023,"f":1},"s":{"r":0,"d":0,"h":21475409319,"f":1},"n":"ConfirmClear","d":572839,"h":12885474727,"f":1,"a":[{"t":5636104,"c":21480472584}]},{"p":1310721,"g":{"r":0,"d":0,"h":34360311207,"f":1},"s":{"r":0,"d":0,"h":38655278503,"f":1},"n":"BgColor","d":572839,"h":30065343911,"f":1,"a":[{"t":5636104,"c":21480472584}]},{"p":1310721,"g":{"r":0,"d":0,"h":51540180391,"f":1},"s":{"r":0,"d":0,"h":55835147687,"f":1},"n":"BtnText","d":572839,"h":47245213095,"f":1,"a":[{"t":5636104,"c":21480472584}]},{"p":2097160,"g":{"r":0,"d":0,"h":68720049575,"f":1},"s":{"r":0,"d":0,"h":73015016871,"f":1},"n":"OnClick","d":572839,"h":64425082279,"f":1,"a":[{"t":5636104,"c":21480472584}]}],"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","d":572839,"h":4295540135,"f":32772},{"r":133300225,"n":"HandleClick","d":572839,"h":77309984167,"f":4098}],"c":[{"n":".ctor","o":"$ctor$2","d":572839,"h":81604951463,"f":1}],"i":[2752520,3145736,3080200],"h":572839}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `miniapp.Components.ButtonCard`; }
        });
        
        $asm.$cls("$m.miniapp.Components.NotFound", ($self) => class NotFound extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.AddMarkupContent(0, "<h3>Not Found</h3>\n");
                __builder.AddMarkupContent(1, "<p>Sorry, the content you are looking for does not exist.</p>");
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 900519;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","d":900519,"h":4295867815,"f":32772}],"c":[{"n":".ctor","o":"$ctor$2","d":900519,"h":8590835111,"f":1}],"i":[2752520,3145736,3080200],"h":900519,"a":[{"t":4587528,"c":4299554824,"a":[{"v":1686951,"t":142606337}]},{"t":9895944,"c":4304863240,"a":[{"v":"/not-found","t":1310721}]}]}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `miniapp.Components.NotFound`; }
        });
        
        $asm.$cls("$m.miniapp.Layout.ReconnectModal", ($self) => class ReconnectModal extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OpenElement(0, "script");
                __builder.AddAttribute$2(1, "type", "module");
                __builder.AddAttribute$2(2, "src", this.Assets.get_Item("Components/Layout/ReconnectModal.razor.js"));
                __builder.AddAttribute(3, "b-uxhtpx25is");
                __builder.CloseElement();
                __builder.AddMarkupContent(4, "\n\n");
                __builder.AddMarkupContent(5, "<dialog id=\"components-reconnect-modal\" data-nosnippet b-uxhtpx25is><div class=\"components-reconnect-container\" b-uxhtpx25is><div class=\"components-rejoining-animation\" aria-hidden=\"true\" b-uxhtpx25is><div b-uxhtpx25is></div>\n            <div b-uxhtpx25is></div></div>\n        <p class=\"components-reconnect-first-attempt-visible\" b-uxhtpx25is>\n            Rejoining the server...\n        </p>\n        <p class=\"components-reconnect-repeated-attempt-visible\" b-uxhtpx25is>\n            Rejoin failed... trying again in <span id=\"components-seconds-to-next-attempt\" b-uxhtpx25is></span> seconds.\n        </p>\n        <p class=\"components-reconnect-failed-visible\" b-uxhtpx25is>\n            Failed to rejoin.<br b-uxhtpx25is>Please retry or reload the page.\n        </p>\n        <button id=\"components-reconnect-button\" class=\"components-reconnect-failed-visible\" b-uxhtpx25is>\n            Retry\n        </button>\n        <p class=\"components-pause-visible\" b-uxhtpx25is>\n            The session has been paused by the server.\n        </p>\n        <button id=\"components-resume-button\" class=\"components-pause-visible\" b-uxhtpx25is>\n            Resume\n        </button>\n        <p class=\"components-resume-failed-visible\" b-uxhtpx25is>\n            Failed to resume the session.<br b-uxhtpx25is>Please reload the page.\n        </p></div></dialog>");
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 1818023;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","d":1818023,"h":4296785319,"f":32772}],"c":[{"n":".ctor","o":"$ctor$2","d":1818023,"h":8591752615,"f":1}],"i":[2752520,3145736,3080200],"h":1818023}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `miniapp.Layout.ReconnectModal`; }
        });
        
        $asm.$cls("$m.miniapp.Components.DeleteAccountPage", ($self) => class DeleteAccountPage extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                if (this.isLoading)
                {
                    __builder.OpenElement(0, "div");
                    __builder.AddAttribute$2(1, "style", "display: flex;; width: 100%; height: 100vh; align-items: center; justify-content: center; font-size: 30px;");
                    __builder.OpenComponent($.$m.miniapp.Components.LoadingCardMajor, 2);
                    __builder.AddComponentParameter(3, "LoadingState", "\u23F3 deleting user account...");
                    __builder.CloseComponent();
                    __builder.CloseElement();
                }
                else 
                {
                    __builder.OpenElement(4, "div");
                    __builder.AddAttribute$2(5, "style", "display: flex;; width: 100%; height: 100vh; align-items: center; justify-content: center;");
                    __builder.OpenComponent($.$m.miniapp.Components.NotLoginCard, 6);
                    __builder.AddComponentParameter(7, "Title", "Account deleted successful...");
                    __builder.AddComponentParameter(8, "SubTitle", "Click to login...");
                    __builder.CloseComponent();
                    __builder.CloseElement();
                }
            }
            /*bool*/ isLoading = true;
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    this.isLoading = true;
                    await $.$spc.System.Threading.Tasks.Task.Delay$4(4000);
                    this.isLoading = false;
                });
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 638375;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","d":638375,"h":4295605671,"f":32772},{"r":133300225,"n":"OnInitializedAsync","d":638375,"h":12885540263,"f":36868}],"l":[{"t":262145,"n":"isLoading","d":638375,"h":8590572967,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":638375,"h":17180507559,"f":1}],"i":[2752520,3145736,3080200],"h":638375,"a":[{"t":9895944,"c":4304863240,"a":[{"v":"/deleteacc","t":1310721}]}]}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `miniapp.Components.DeleteAccountPage`; }
        });
        
        $asm.$cls("$m.miniapp.Components.NotLoginCard", ($self) => class NotLoginCard extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$2(1, "style", "width: 100%; height: 30vh; font-size: 20px; display: flex; align-items: center; justify-content: center; text-align: center;");
                __builder.OpenElement(2, "div");
                __builder.OpenElement(3, "p");
                __builder.AddContent(4, this.Title);
                __builder.CloseElement();
                __builder.AddMarkupContent(5, "\n        ");
                __builder.OpenElement(6, "p");
                __builder.OpenComponent($.$macw.Microsoft.AspNetCore.Components.Routing.NavLink, 7);
                __builder.AddComponentParameter(8, "style", "text-decoration: none; color: white; background: rgb(133, 0, 133, 0.3); padding: 10px 20px; border-radius: 10px; font-weight: bold; font-size: 15px;");
                __builder.AddComponentParameter(9, "href", "/");
                __builder.AddComponentParameter(10, "Match", $.$box($.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$macw.Microsoft.AspNetCore.Components.Routing.NavLinkMatch, 1/*NavLinkMatch.All*/), $.$macw.Microsoft.AspNetCore.Components.Routing.NavLinkMatch));
                __builder.AddAttribute$3(11, "ChildContent", new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddMarkupContent(12, "\uD83D\uDEAA Login");
                })));
                __builder.CloseComponent();
                __builder.AddMarkupContent(13, "\n            ");
                __builder.AddContent(14, this.SubTitle);
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
            }
            /*string*/ Title = null;
            /*string*/ SubTitle = null;
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Title = "";
                this.SubTitle = "";
            }
            static $h = 966055;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17180835239,"f":1},"s":{"r":0,"d":0,"h":21475802535,"f":1},"n":"Title","d":966055,"h":12885867943,"f":1,"a":[{"t":5636104,"c":21480472584}]},{"p":1310721,"g":{"r":0,"d":0,"h":34360704423,"f":1},"s":{"r":0,"d":0,"h":38655671719,"f":1},"n":"SubTitle","d":966055,"h":30065737127,"f":1,"a":[{"t":5636104,"c":21480472584}]}],"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","d":966055,"h":4295933351,"f":32772}],"c":[{"n":".ctor","o":"$ctor$2","d":966055,"h":42950639015,"f":1}],"i":[2752520,3145736,3080200],"h":966055}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `miniapp.Components.NotLoginCard`; }
        });
        
        $asm.$cls("$m.miniapp.App", ($self) => class App extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OpenComponent($.$mac.Microsoft.AspNetCore.Components.Routing.Router, 0);
                __builder.AddComponentParameter(1, "AppAssembly", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$spc.System.Reflection.Assembly, $.$m.miniapp.App.$type.Assembly));
                __builder.AddComponentParameter(2, "PreferExactMatches", $.$box(true, $.$spc.System.Boolean));
                __builder.AddComponentParameter(3, "NotFoundPage", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$spc.System.Type, $.$m.miniapp.Components.NotFound.$type));
                __builder.AddAttribute$3(4, "Found", new ($.$mac.Microsoft.AspNetCore.Components.RenderFragment$$($.$mac.Microsoft.AspNetCore.Components.RouteData))().$ctor(this, ( (/*routeData*/ routeData) =>
                {
                    return new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this,  (/**/ __builder2) =>
                    {
                        __builder2.OpenComponent($.$mac.Microsoft.AspNetCore.Components.RouteView, 5);
                        __builder2.AddComponentParameter(6, "RouteData", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$mac.Microsoft.AspNetCore.Components.RouteData, routeData));
                        __builder2.AddComponentParameter(7, "DefaultLayout", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$spc.System.Type, $.$m.miniapp.Layout.MainLayout.$type));
                        __builder2.CloseComponent();
                        __builder2.AddMarkupContent(8, "\n        ");
                        __builder2.OpenComponent($.$macw.Microsoft.AspNetCore.Components.Routing.FocusOnNavigate, 9);
                        __builder2.AddComponentParameter(10, "RouteData", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$mac.Microsoft.AspNetCore.Components.RouteData, routeData));
                        __builder2.AddComponentParameter(11, "Selector", "h1");
                        __builder2.CloseComponent();
                    }, {"r":65537,"p":[{"n":"__builder2","p":7536648}],"n":"","d":441767,"h":0,"f":1048578});
                })));
                __builder.CloseComponent();
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 441767;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","d":441767,"h":4295409063,"f":32772}],"c":[{"n":".ctor","o":"$ctor$2","d":441767,"h":8590376359,"f":1}],"i":[2752520,3145736,3080200],"h":441767}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `miniapp.App`; }
        });
        
        $asm.$cls("$m.miniapp.Components.SignUpSuccess", ($self) => class SignUpSuccess extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                if (this.isLoading)
                {
                    __builder.OpenElement(0, "div");
                    __builder.AddAttribute$2(1, "style", "display: flex;; width: 100%; height: 100vh; align-items: center; justify-content: center; font-size: 30px;");
                    __builder.OpenComponent($.$m.miniapp.Components.LoadingCardMajor, 2);
                    __builder.AddComponentParameter(3, "LoadingState", "\u23F3 creating user account...");
                    __builder.CloseComponent();
                    __builder.CloseElement();
                }
                else 
                {
                    __builder.OpenElement(4, "div");
                    __builder.AddAttribute$2(5, "style", "display: flex;; width: 100%; height: 100vh; align-items: center; justify-content: center;");
                    __builder.OpenComponent($.$m.miniapp.Components.NotLoginCard, 6);
                    __builder.AddComponentParameter(7, "Title", "Account created successful...");
                    __builder.AddComponentParameter(8, "SubTitle", "Continue to login...");
                    __builder.CloseComponent();
                    __builder.CloseElement();
                }
            }
            /*bool*/ isLoading = true;
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    this.isLoading = true;
                    await $.$spc.System.Threading.Tasks.Task.Delay$4(4000);
                    this.isLoading = false;
                });
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 1490343;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","d":1490343,"h":4296457639,"f":32772},{"r":133300225,"n":"OnInitializedAsync","d":1490343,"h":12886392231,"f":36868}],"l":[{"t":262145,"n":"isLoading","d":1490343,"h":8591424935,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":1490343,"h":17181359527,"f":1}],"i":[2752520,3145736,3080200],"h":1490343,"a":[{"t":9895944,"c":4304863240,"a":[{"v":"/signupsuccess","t":1310721}]}]}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `miniapp.Components.SignUpSuccess`; }
        });
        
        $asm.$cls("$m.miniapp.Layout.NavMenu", ($self) => class NavMenu extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$2(1, "class", "top-row ps-3 navbar navbar-dark");
                __builder.AddAttribute(2, "b-2ys3sctjtr");
                __builder.OpenElement(3, "div");
                __builder.AddAttribute$2(4, "class", "container-fluid");
                __builder.AddAttribute(5, "b-2ys3sctjtr");
                __builder.AddMarkupContent(6, "<a class=\"navbar-brand\" href b-2ys3sctjtr>miniapp</a>\n        ");
                __builder.OpenElement(7, "button");
                __builder.AddAttribute$2(8, "title", "Navigation menu");
                __builder.AddAttribute$2(9, "class", "navbar-toggler");
                __builder.AddAttribute$5($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, 10, "onclick", $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$7($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, this, new $.$spc.System.Action().$ctor(this, this.ToggleNavMenu)));
                __builder.AddAttribute(11, "b-2ys3sctjtr");
                __builder.AddMarkupContent(12, "<span class=\"navbar-toggler-icon\" b-2ys3sctjtr></span>");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(13, "\n\n");
                __builder.OpenElement(14, "div");
                __builder.AddAttribute$2(15, "class", (this.NavMenuCssClass) + " nav-scrollable");
                __builder.AddAttribute$5($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, 16, "onclick", $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$7($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, this, new $.$spc.System.Action().$ctor(this, this.ToggleNavMenu)));
                __builder.AddAttribute(17, "b-2ys3sctjtr");
                __builder.OpenElement(18, "nav");
                __builder.AddAttribute$2(19, "class", "nav flex-column");
                __builder.AddAttribute(20, "b-2ys3sctjtr");
                __builder.OpenElement(21, "div");
                __builder.AddAttribute$2(22, "class", "nav-item px-3");
                __builder.AddAttribute(23, "b-2ys3sctjtr");
                __builder.OpenComponent($.$macw.Microsoft.AspNetCore.Components.Routing.NavLink, 24);
                __builder.AddComponentParameter(25, "class", "nav-link");
                __builder.AddComponentParameter(26, "href", "");
                __builder.AddComponentParameter(27, "Match", $.$box($.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$macw.Microsoft.AspNetCore.Components.Routing.NavLinkMatch, 1/*NavLinkMatch.All*/), $.$macw.Microsoft.AspNetCore.Components.Routing.NavLinkMatch));
                __builder.AddAttribute$3(28, "ChildContent", new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddMarkupContent(29, "<span class=\"bi bi-house-door-fill-nav-menu\" aria-hidden=\"true\" b-2ys3sctjtr></span> Home\n            ");
                })));
                __builder.CloseComponent();
                __builder.CloseElement();
                __builder.AddMarkupContent(30, "\n        ");
                __builder.OpenElement(31, "div");
                __builder.AddAttribute$2(32, "class", "nav-item px-3");
                __builder.AddAttribute(33, "b-2ys3sctjtr");
                __builder.OpenComponent($.$macw.Microsoft.AspNetCore.Components.Routing.NavLink, 34);
                __builder.AddComponentParameter(35, "class", "nav-link");
                __builder.AddComponentParameter(36, "href", "counter");
                __builder.AddAttribute$3(37, "ChildContent", new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddMarkupContent(38, "<span class=\"bi bi-plus-square-fill-nav-menu\" aria-hidden=\"true\" b-2ys3sctjtr></span> Counter\n            ");
                })));
                __builder.CloseComponent();
                __builder.CloseElement();
                __builder.AddMarkupContent(39, "\n        ");
                __builder.OpenElement(40, "div");
                __builder.AddAttribute$2(41, "class", "nav-item px-3");
                __builder.AddAttribute(42, "b-2ys3sctjtr");
                __builder.OpenComponent($.$macw.Microsoft.AspNetCore.Components.Routing.NavLink, 43);
                __builder.AddComponentParameter(44, "class", "nav-link");
                __builder.AddComponentParameter(45, "href", "weather");
                __builder.AddAttribute$3(46, "ChildContent", new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddMarkupContent(47, "<span class=\"bi bi-list-nested-nav-menu\" aria-hidden=\"true\" b-2ys3sctjtr></span> Weather\n            ");
                })));
                __builder.CloseComponent();
                __builder.CloseElement();
                __builder.AddMarkupContent(48, "\n\n        ");
                __builder.OpenElement(49, "div");
                __builder.AddAttribute$2(50, "class", "nav-item px-3");
                __builder.AddAttribute(51, "b-2ys3sctjtr");
                __builder.OpenComponent($.$macw.Microsoft.AspNetCore.Components.Routing.NavLink, 52);
                __builder.AddComponentParameter(53, "class", "nav-link");
                __builder.AddComponentParameter(54, "href", "login");
                __builder.AddAttribute$3(55, "ChildContent", new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this, ( (/**/ __builder2) =>
                {
                    __builder2.AddMarkupContent(56, "<span class=\"bi bi-list-nested-nav-menu\" aria-hidden=\"true\" b-2ys3sctjtr></span> Login\n            ");
                })));
                __builder.CloseComponent();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
            }
            /*bool*/ collapseNavMenu = true;
            /*string? */ get NavMenuCssClass()
            {
                return this.collapseNavMenu ? "collapse" : null;
            }
            /*void */ ToggleNavMenu()
            {
                this.collapseNavMenu = !this.collapseNavMenu;
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 1752487;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17181621671,"f":2},"n":"NavMenuCssClass","d":1752487,"h":12886654375,"f":2}],"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","d":1752487,"h":4296719783,"f":32772},{"r":65537,"n":"ToggleNavMenu","d":1752487,"h":21476588967,"f":2}],"l":[{"t":262145,"n":"collapseNavMenu","d":1752487,"h":8591687079,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":1752487,"h":25771556263,"f":1}],"i":[2752520,3145736,3080200],"h":1752487}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `miniapp.Layout.NavMenu`; }
        });
        
        $asm.$cls("$m.miniapp.Components.StatCard", ($self) => class StatCard extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$2(1, "class", "stat-container");
                __builder.AddAttribute(2, "b-85yfc36wqj");
                __builder.OpenElement(3, "div");
                __builder.AddAttribute$2(4, "class", "label");
                __builder.AddAttribute(5, "b-85yfc36wqj");
                __builder.OpenElement(6, "p");
                __builder.AddAttribute(7, "b-85yfc36wqj");
                __builder.AddContent(8, this.Icon);
                __builder.CloseElement();
                __builder.AddMarkupContent(9, "\n        ");
                __builder.OpenElement(10, "p");
                __builder.AddAttribute(11, "b-85yfc36wqj");
                __builder.AddContent(12, this.Label);
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(13, "\n    ");
                __builder.OpenElement(14, "p");
                __builder.AddAttribute$2(15, "class", "value");
                __builder.AddAttribute(16, "b-85yfc36wqj");
                __builder.AddContent(17, this.Value);
                __builder.CloseElement();
                __builder.CloseElement();
            }
            /*string*/ Icon = null;
            /*string*/ Label = null;
            /*string*/ Value = null;
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Icon = "";
                this.Label = "";
                this.Value = "";
            }
            static $h = 1555879;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17181425063,"f":1},"s":{"r":0,"d":0,"h":21476392359,"f":1},"n":"Icon","d":1555879,"h":12886457767,"f":1,"a":[{"t":5636104,"c":21480472584}]},{"p":1310721,"g":{"r":0,"d":0,"h":34361294247,"f":1},"s":{"r":0,"d":0,"h":38656261543,"f":1},"n":"Label","d":1555879,"h":30066326951,"f":1,"a":[{"t":5636104,"c":21480472584}]},{"p":1310721,"g":{"r":0,"d":0,"h":51541163431,"f":1},"s":{"r":0,"d":0,"h":55836130727,"f":1},"n":"Value","d":1555879,"h":47246196135,"f":1,"a":[{"t":5636104,"c":21480472584}]}],"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","d":1555879,"h":4296523175,"f":32772}],"c":[{"n":".ctor","o":"$ctor$2","d":1555879,"h":60131098023,"f":1}],"i":[2752520,3145736,3080200],"h":1555879}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `miniapp.Components.StatCard`; }
        });
        
        $asm.$cls("$m.miniapp.Components.Routes", ($self) => class Routes extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OpenComponent($.$mac.Microsoft.AspNetCore.Components.Routing.Router, 0);
                __builder.AddComponentParameter(1, "AppAssembly", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$spc.System.Reflection.Assembly, $.$m.Program.$type.Assembly));
                __builder.AddComponentParameter(2, "NotFoundPage", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$spc.System.Type, $.$m.miniapp.Components.NotFound.$type));
                __builder.AddAttribute$3(3, "Found", new ($.$mac.Microsoft.AspNetCore.Components.RenderFragment$$($.$mac.Microsoft.AspNetCore.Components.RouteData))().$ctor(this, ( (/**/ routeData) =>
                {
                    return new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent($.$mac.Microsoft.AspNetCore.Components.RouteView, 4);
                        __builder2.AddComponentParameter(5, "RouteData", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$mac.Microsoft.AspNetCore.Components.RouteData, routeData));
                        __builder2.AddComponentParameter(6, "DefaultLayout", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$spc.System.Type, $.$m.miniapp.Layout.MainLayout.$type));
                        __builder2.CloseComponent();
                        __builder2.AddMarkupContent(7, "\n        ");
                        __builder2.OpenComponent($.$macw.Microsoft.AspNetCore.Components.Routing.FocusOnNavigate, 8);
                        __builder2.AddComponentParameter(9, "RouteData", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$mac.Microsoft.AspNetCore.Components.RouteData, routeData));
                        __builder2.AddComponentParameter(10, "Selector", "h1");
                        __builder2.CloseComponent();
                    }, {"r":65537,"p":[{"n":"__builder2","p":7536648}],"n":"","d":1359271,"h":0,"f":1048578});
                })));
                __builder.CloseComponent();
            }
            static $___PrivateComponentRenderModeAttribute;
            static get __PrivateComponentRenderModeAttribute()
            {
                let $cls = $.$m.miniapp.Components.Routes;
                return $cls.$___PrivateComponentRenderModeAttribute ??= $asm.$ncls("$m.miniapp.Components.Routes.__PrivateComponentRenderModeAttribute", ($self) => class __PrivateComponentRenderModeAttribute extends $.$mac.Microsoft.AspNetCore.Components.RenderModeAttribute
                {
                    static /*global::Microsoft.AspNetCore.Components.IComponentRenderMode */ get ModeImpl()
                    {
                        return $.$macw.Microsoft.AspNetCore.Components.Web.RenderMode.InteractiveServer;
                    }
                    /*global::Microsoft.AspNetCore.Components.IComponentRenderMode */ get Mode()
                    {
                        return $.$m.miniapp.Components.Routes.__PrivateComponentRenderModeAttribute.ModeImpl;
                    }
                    //default reference type constructor overload
                    $ctor$3()
                    {
                        super.$ctor$2();
                        return this;
                    }
                    static $h = 1424807;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":7733256,"p":[{"p":2883592,"g":{"r":0,"d":0,"h":8591359399,"f":34},"n":"ModeImpl","d":1424807,"h":4296392103,"f":34},{"p":2883592,"g":{"r":0,"d":0,"h":17181293991,"f":32769},"n":"Mode","d":1424807,"h":12886326695,"f":32769}],"c":[{"n":".ctor","o":"$ctor$3","d":1424807,"h":21476261287,"f":1}],"d":1359271,"h":1424807}; }
                    static get $b() { return $.$mac.Microsoft.AspNetCore.Components.RenderModeAttribute; }
                    static get $fullName() { return `miniapp.Components.Routes.__PrivateComponentRenderModeAttribute`; }
                }, $cls, ($v) => $cls.$___PrivateComponentRenderModeAttribute = $v);
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 1359271;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","d":1359271,"h":4296326567,"f":32772}],"c":[{"n":".ctor","o":"$ctor$2","d":1359271,"h":12886261159,"f":1}],"i":[2752520,3145736,3080200],"j":[1424807],"h":1359271,"a":[{"t":1424807,"c":21476261287}]}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `miniapp.Components.Routes`; }
        });
        
        $asm.$cls("$m.miniapp.Components.Pages.Dashboard", ($self) => class Dashboard extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OpenComponent($.$m.miniapp.Components.NavBar, 0);
                __builder.CloseComponent();
                if (this.isLoading)
                {
                    __builder.OpenComponent($.$m.miniapp.Components.LoadingCardMajor, 1);
                    __builder.AddComponentParameter(2, "LoadingState", "\u23F3 Loading Dashboard...");
                    __builder.CloseComponent();
                }
                else 
                {
                    __builder.OpenElement(3, "div");
                    __builder.AddMarkupContent(4, "<h3>\uD83D\uDCCA Dashboard</h3>\n        ");
                    __builder.OpenElement(5, "p");
                    __builder.AddContent(6, "Welcome back, ");
                    __builder.AddContent(7, this.Auth.Username);
                    __builder.AddMarkupContent(8, " \uD83D\uDD90\uFE0F");
                    __builder.CloseElement();
                    if (this.Auth.IsLoggedIn)
                    {
                        __builder.OpenElement(9, "div");
                        __builder.AddAttribute$2(10, "style", "display: flex; gap: 10px; padding: 10px 0 30px;");
                        __builder.OpenComponent($.$m.miniapp.Components.StatCard, 11);
                        __builder.AddComponentParameter(12, "Icon", "\uD83D\uDCDD");
                        __builder.AddComponentParameter(13, "Label", "Total");
                        __builder.AddComponentParameter(14, "Value", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$spc.System.String, this.tasksCount));
                        __builder.CloseComponent();
                        __builder.AddMarkupContent(15, "\n                ");
                        __builder.OpenComponent($.$m.miniapp.Components.StatCard, 16);
                        __builder.AddComponentParameter(17, "Icon", "\u2705");
                        __builder.AddComponentParameter(18, "Label", "Done");
                        __builder.AddComponentParameter(19, "Value", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$spc.System.String, this.completedCount));
                        __builder.CloseComponent();
                        __builder.AddMarkupContent(20, "\n                ");
                        __builder.OpenComponent($.$m.miniapp.Components.StatCard, 21);
                        __builder.AddComponentParameter(22, "Icon", "\u23F3");
                        __builder.AddComponentParameter(23, "Label", "Left");
                        __builder.AddComponentParameter(24, "Value", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$spc.System.String, this.pendingCount));
                        __builder.CloseComponent();
                        __builder.CloseElement();
                    }
                    else 
                    {
                        __builder.OpenElement(25, "div");
                        __builder.AddAttribute$2(26, "style", "display: flex; gap: 10px; padding: 10px 0 30px;");
                        __builder.OpenComponent($.$m.miniapp.Components.StatCard, 27);
                        __builder.AddComponentParameter(28, "Icon", "\uD83D\uDCDD");
                        __builder.AddComponentParameter(29, "Label", "Total");
                        __builder.AddComponentParameter(30, "Value", "0");
                        __builder.CloseComponent();
                        __builder.AddMarkupContent(31, "\n                ");
                        __builder.OpenComponent($.$m.miniapp.Components.StatCard, 32);
                        __builder.AddComponentParameter(33, "Icon", "\u2705");
                        __builder.AddComponentParameter(34, "Label", "Done");
                        __builder.AddComponentParameter(35, "Value", "0");
                        __builder.CloseComponent();
                        __builder.AddMarkupContent(36, "\n                ");
                        __builder.OpenComponent($.$m.miniapp.Components.StatCard, 37);
                        __builder.AddComponentParameter(38, "Icon", "\u23F3");
                        __builder.AddComponentParameter(39, "Label", "Left");
                        __builder.AddComponentParameter(40, "Value", "0");
                        __builder.CloseComponent();
                        __builder.CloseElement();
                    }
                    if ($.$spc.System.String.op_Equality(this.Auth.Role, "Admin"))
                    {
                        __builder.OpenElement(41, "div");
                        __builder.AddMarkupContent(42, "<h5>\u2699\uFE0F Admin Panel</h5>\n                ");
                        __builder.OpenElement(43, "div");
                        __builder.OpenComponent($.$m.miniapp.Components.ButtonCard, 44);
                        __builder.AddComponentParameter(45, "BgColor", "rgb(140, 0, 140, 0.3)");
                        __builder.AddComponentParameter(46, "BtnText", "\uD83D\uDCC1 Go to Tasks");
                        __builder.AddComponentParameter(47, "OnClick", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$mac.Microsoft.AspNetCore.Components.EventCallback, $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$1(this, new $.$spc.System.Action().$ctor(this, this.GoToTask))));
                        __builder.CloseComponent();
                        __builder.AddMarkupContent(48, "\n                    ");
                        __builder.OpenComponent($.$m.miniapp.Components.ButtonCard, 49);
                        __builder.AddComponentParameter(50, "BgColor", "rgb(135, 135, 135, 0.3)");
                        __builder.AddComponentParameter(51, "BtnText", "\uD83D\uDE4E\u200D\u2642\uFE0F View Profile");
                        __builder.AddComponentParameter(52, "OnClick", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$mac.Microsoft.AspNetCore.Components.EventCallback, $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$1(this, new $.$spc.System.Action().$ctor(this, this.ViewProfile))));
                        __builder.CloseComponent();
                        __builder.CloseElement();
                        __builder.CloseElement();
                    }
                    __builder.CloseElement();
                    if (!this.Auth.IsLoggedIn)
                    {
                        __builder.OpenComponent($.$m.miniapp.Components.NotLoginCard, 53);
                        __builder.AddComponentParameter(54, "Title", "User not logged in....");
                        __builder.AddComponentParameter(55, "SubTitle", "Click to login...");
                        __builder.CloseComponent();
                    }
                }
            }
            /*bool*/ isLoading = true;
            /*List<AppTask> */ get tasks()
            {
                return this.TaskService.ITaskService$GetAll() ?? new ($.$spc.System.Collections.Generic.List$$($.$m.AppTask))().$ctor$1();
            }
            /*string */ get tasksCount()
            {
                return $.$spc.System.Int32.ToString.call(this.tasks.Count);
            }
            /*string */ get completedCount()
            {
                return $.$spc.System.Int32.ToString.call($.$sl.System.Linq.Enumerable.Count$1($.$m.AppTask, this.tasks, new ($.$spc.System.Func$$$($.$m.AppTask, $.$spc.System.Boolean))().$ctor(this,  (/**/ t) =>
                {
                    return t.IsComplete;
                }, {"r":262145,"p":[{"n":"t","p":114087}],"n":"","d":1031591,"h":0,"f":1048578})));
            }
            /*string */ get pendingCount()
            {
                return $.$spc.System.Int32.ToString.call($.$sl.System.Linq.Enumerable.Count$1($.$m.AppTask, this.tasks, new ($.$spc.System.Func$$$($.$m.AppTask, $.$spc.System.Boolean))().$ctor(this,  (/*t*/ t) =>
                {
                    return !t.IsComplete;
                }, {"r":262145,"p":[{"n":"t","p":114087}],"n":"","d":1031591,"h":0,"f":1048578})));
            }
            /*void */ GoToTask()
            {
                return this.Nav.NavigateTo$1("/tasks", false, false);
            }
            /*void */ ViewProfile()
            {
                return this.Nav.NavigateTo$1("/profile", false, false);
            }
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    if (this.isLoading)
                    {
                        this.isLoading = true;
                        await $.$spc.System.Threading.Tasks.Task.Delay$4(1500);
                        this.isLoading = false;
                    }
                });
            }
            /*Task *//*async*/  OnAfterRenderAsync(/*bool*/ firstRender)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    if (firstRender)
                    {
                        await this.TaskService.ITaskService$LoadTasks();
                        this.StateHasChanged();
                    }
                });
            }
            /*NavigationManager*/ Nav = null;
            /*ITaskService*/ TaskService = null;
            /*miniapp.Services.AuthService*/ Auth = null;
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Nav = null;
                this.TaskService = null;
                this.Auth = null;
            }
            static $h = 1031591;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":$.$spc.System.Collections.Generic.List$$($.$m.AppTask).$h,"g":{"r":0,"d":0,"h":17180900775,"f":2},"n":"tasks","d":1031591,"h":12885933479,"f":2},{"p":1310721,"g":{"r":0,"d":0,"h":25770835367,"f":2},"n":"tasksCount","d":1031591,"h":21475868071,"f":2},{"p":1310721,"g":{"r":0,"d":0,"h":34360769959,"f":2},"n":"completedCount","d":1031591,"h":30065802663,"f":2},{"p":1310721,"g":{"r":0,"d":0,"h":42950704551,"f":2},"n":"pendingCount","d":1031591,"h":38655737255,"f":2},{"p":4980744,"g":{"r":0,"d":0,"h":73015475623,"f":2},"s":{"r":0,"d":0,"h":77310442919,"f":2},"n":"Nav","d":1031591,"h":68720508327,"f":2,"a":[{"t":4259848,"c":21479096328}]},{"p":179623,"g":{"r":0,"d":0,"h":90195344807,"f":2},"s":{"r":0,"d":0,"h":94490312103,"f":2},"n":"TaskService","d":1031591,"h":85900377511,"f":2,"a":[{"t":4259848,"c":21479096328}]},{"p":1883559,"g":{"r":0,"d":0,"h":107375213991,"f":2},"s":{"r":0,"d":0,"h":111670181287,"f":2},"n":"Auth","d":1031591,"h":103080246695,"f":2,"a":[{"t":4259848,"c":21479096328}]}],"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","d":1031591,"h":4295998887,"f":32772},{"r":65537,"n":"GoToTask","d":1031591,"h":47245671847,"f":2},{"r":65537,"n":"ViewProfile","d":1031591,"h":51540639143,"f":2},{"r":133300225,"n":"OnInitializedAsync","d":1031591,"h":55835606439,"f":36868},{"r":133300225,"p":[{"n":"firstRender","p":262145}],"n":"OnAfterRenderAsync","d":1031591,"h":60130573735,"f":36868}],"l":[{"t":262145,"n":"isLoading","d":1031591,"h":8590966183,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":1031591,"h":115965148583,"f":1}],"i":[2752520,3145736,3080200],"h":1031591,"a":[{"t":9895944,"c":4304863240,"a":[{"v":"/dashboard","t":1310721}]}]}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `miniapp.Components.Pages.Dashboard`; }
        });
        
        $asm.$cls("$m.miniapp.Components.NavBar", ($self) => class NavBar extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OpenElement(0, "nav");
                __builder.AddAttribute$2(1, "style", "display: flex; justify-content: space-around; margin-bottom: 20px;");
                __builder.AddAttribute(2, "b-ztl0h4or35");
                __builder.OpenElement(3, "div");
                __builder.AddAttribute$2(4, "class", "mobile");
                __builder.AddAttribute(5, "b-ztl0h4or35");
                __builder.OpenComponent($.$macw.Microsoft.AspNetCore.Components.Routing.NavLink, 6);
                __builder.AddComponentParameter(7, "style", "text-decoration: none; color: white; font-weight: bold; font-size: 15px;");
                __builder.AddComponentParameter(8, "href", "/dashboard");
                __builder.AddComponentParameter(9, "Match", $.$box($.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$macw.Microsoft.AspNetCore.Components.Routing.NavLinkMatch, 1/*NavLinkMatch.All*/), $.$macw.Microsoft.AspNetCore.Components.Routing.NavLinkMatch));
                __builder.AddAttribute$3(10, "ChildContent", new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddMarkupContent(11, "\uD83C\uDFE0 Home");
                })));
                __builder.CloseComponent();
                __builder.CloseElement();
                if ($.$spc.System.String.op_Equality(this.Auth.Role, "Admin"))
                {
                    __builder.OpenElement(12, "div");
                    __builder.AddAttribute$2(13, "class", "mobile");
                    __builder.AddAttribute(14, "b-ztl0h4or35");
                    __builder.OpenComponent($.$macw.Microsoft.AspNetCore.Components.Routing.NavLink, 15);
                    __builder.AddComponentParameter(16, "style", "text-decoration: none; color: white; font-weight: bold; font-size: 15px;");
                    __builder.AddComponentParameter(17, "href", "/tasks");
                    __builder.AddComponentParameter(18, "Match", $.$box($.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$macw.Microsoft.AspNetCore.Components.Routing.NavLinkMatch, 1/*NavLinkMatch.All*/), $.$macw.Microsoft.AspNetCore.Components.Routing.NavLinkMatch));
                    __builder.AddAttribute$3(19, "ChildContent", new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                    {
                        __builder2.AddMarkupContent(20, "\uD83D\uDCDD Tasks");
                    })));
                    __builder.CloseComponent();
                    __builder.CloseElement();
                    __builder.AddMarkupContent(21, "\n        ");
                    __builder.OpenElement(22, "div");
                    __builder.AddAttribute$2(23, "class", "mobile");
                    __builder.AddAttribute(24, "b-ztl0h4or35");
                    __builder.OpenComponent($.$macw.Microsoft.AspNetCore.Components.Routing.NavLink, 25);
                    __builder.AddComponentParameter(26, "style", "text-decoration: none; color: white; font-weight: bold; font-size: 15px;");
                    __builder.AddComponentParameter(27, "href", "/profile");
                    __builder.AddComponentParameter(28, "Match", $.$box($.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$macw.Microsoft.AspNetCore.Components.Routing.NavLinkMatch, 1/*NavLinkMatch.All*/), $.$macw.Microsoft.AspNetCore.Components.Routing.NavLinkMatch));
                    __builder.AddAttribute$3(29, "ChildContent", new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                    {
                        __builder2.AddMarkupContent(30, "\uD83D\uDC64 Profile");
                    })));
                    __builder.CloseComponent();
                    __builder.CloseElement();
                }
                __builder.OpenElement(31, "p");
                __builder.AddAttribute$2(32, "style", "text-decoration: none; color: white; font-weight: bold; font-size: 15px;");
                __builder.AddAttribute(33, "href");
                __builder.AddAttribute$2(34, "Match", "NavLinkMatch.All");
                __builder.AddAttribute(35, "b-ztl0h4or35");
                __builder.AddMarkupContent(36, "\uD83D\uDC64 ");
                __builder.AddContent(37, this.Auth.Username);
                __builder.AddMarkupContent(38, " \uD83C\uDFF7\uFE0F ");
                __builder.AddContent(39, this.Auth.Role);
                __builder.CloseElement();
                if (this.Auth.IsLoggedIn)
                {
                    __builder.OpenElement(40, "div");
                    __builder.AddAttribute$2(41, "class", "mobile");
                    __builder.AddAttribute(42, "b-ztl0h4or35");
                    __builder.OpenComponent($.$macw.Microsoft.AspNetCore.Components.Routing.NavLink, 43);
                    __builder.AddComponentParameter(44, "style", "text-decoration: none; color: white; font-weight: bold; font-size: 15px;");
                    __builder.AddComponentParameter(45, "href", "/");
                    __builder.AddComponentParameter(46, "onclick", $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$7($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, this, new $.$spc.System.Action().$ctor(this, this.LogoutUser)));
                    __builder.AddComponentParameter(47, "Match", $.$box($.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$macw.Microsoft.AspNetCore.Components.Routing.NavLinkMatch, 1/*NavLinkMatch.All*/), $.$macw.Microsoft.AspNetCore.Components.Routing.NavLinkMatch));
                    __builder.AddAttribute$3(48, "ChildContent", new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent($.$m.miniapp.Components.ButtonCard, 49);
                        __builder2.AddComponentParameter(50, "BgColor", "white");
                        __builder2.AddComponentParameter(51, "BtnText", "\u232B Logout");
                        __builder2.AddComponentParameter(52, "OnClick", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$mac.Microsoft.AspNetCore.Components.EventCallback, $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$1(this, new $.$spc.System.Action().$ctor(this, this.LogoutUser))));
                        __builder2.CloseComponent();
                    })));
                    __builder.CloseComponent();
                    __builder.CloseElement();
                }
                else 
                {
                    __builder.OpenElement(53, "div");
                    __builder.AddAttribute$2(54, "class", "mobile");
                    __builder.AddAttribute(55, "b-ztl0h4or35");
                    __builder.OpenComponent($.$macw.Microsoft.AspNetCore.Components.Routing.NavLink, 56);
                    __builder.AddComponentParameter(57, "style", "text-decoration: none; color: white; font-weight: bold; font-size: 15px;");
                    __builder.AddComponentParameter(58, "href", "/");
                    __builder.AddComponentParameter(59, "onclick", $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$7($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, this, new $.$spc.System.Action().$ctor(this, this.LogoutUser)));
                    __builder.AddComponentParameter(60, "Match", $.$box($.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$macw.Microsoft.AspNetCore.Components.Routing.NavLinkMatch, 1/*NavLinkMatch.All*/), $.$macw.Microsoft.AspNetCore.Components.Routing.NavLinkMatch));
                    __builder.AddAttribute$3(61, "ChildContent", new $.$mac.Microsoft.AspNetCore.Components.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent($.$m.miniapp.Components.ButtonCard, 62);
                        __builder2.AddComponentParameter(63, "BgColor", "white");
                        __builder2.AddComponentParameter(64, "BtnText", "\uD83D\uDEAA Login");
                        __builder2.AddComponentParameter(65, "OnClick", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$mac.Microsoft.AspNetCore.Components.EventCallback, $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$1(this, new $.$spc.System.Action().$ctor(this, this.LoginUser))));
                        __builder2.CloseComponent();
                    })));
                    __builder.CloseComponent();
                    __builder.CloseElement();
                }
                __builder.CloseElement();
            }
            /*void */ LoginUser()
            {
                this.Nav.NavigateTo$1("/", false, false);
            }
            /*void */ LogoutUser()
            {
                this.Auth.Logout();
                this.Nav.NavigateTo$1("/", false, false);
            }
            /*NavigationManager*/ Nav = null;
            /*miniapp.Services.AuthService*/ Auth = null;
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Nav = null;
                this.Auth = null;
            }
            static $h = 834983;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":4980744,"g":{"r":0,"d":0,"h":25770638759,"f":2},"s":{"r":0,"d":0,"h":30065606055,"f":2},"n":"Nav","d":834983,"h":21475671463,"f":2,"a":[{"t":4259848,"c":21479096328}]},{"p":1883559,"g":{"r":0,"d":0,"h":42950507943,"f":2},"s":{"r":0,"d":0,"h":47245475239,"f":2},"n":"Auth","d":834983,"h":38655540647,"f":2,"a":[{"t":4259848,"c":21479096328}]}],"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","d":834983,"h":4295802279,"f":32772},{"r":65537,"n":"LoginUser","d":834983,"h":8590769575,"f":2},{"r":65537,"n":"LogoutUser","d":834983,"h":12885736871,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":834983,"h":51540442535,"f":1}],"i":[2752520,3145736,3080200],"h":834983}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `miniapp.Components.NavBar`; }
        });
        
        $asm.$cls("$m.miniapp.Components.Pages.Login", ($self) => class Login extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                if (this.isLoading)
                {
                    __builder.AddMarkupContent(0, "<p b-pkulom7sod>\u23F3 Loading...</p>");
                }
                else 
                {
                    __builder.OpenElement(1, "div");
                    __builder.AddAttribute$2(2, "class", "login-container");
                    __builder.AddAttribute(3, "b-pkulom7sod");
                    __builder.AddMarkupContent(4, "<h3 b-pkulom7sod>Login</h3>\n        ");
                    __builder.OpenElement(5, "div");
                    __builder.AddAttribute$2(6, "class", "sub-container");
                    __builder.AddAttribute(7, "b-pkulom7sod");
                    __builder.OpenElement(8, "div");
                    __builder.AddAttribute$2(9, "class", "input-container");
                    __builder.AddAttribute(10, "b-pkulom7sod");
                    __builder.AddMarkupContent(11, "<label for=\"username\" b-pkulom7sod>Username</label>\n                ");
                    __builder.OpenElement(12, "input");
                    __builder.AddAttribute$2(13, "type", "text");
                    __builder.AddAttribute$2(14, "placeholder", "enter username...");
                    __builder.AddAttribute$2(15, "value", $.$mac.Microsoft.AspNetCore.Components.BindConverter.FormatValue(this.username, null));
                    __builder.AddAttribute$5($.$mac.Microsoft.AspNetCore.Components.ChangeEventArgs, 16, "onchange", $.$mac.Microsoft.AspNetCore.Components.EventCallbackFactoryBinderExtensions.CreateBinder($.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory, this, new ($.$spc.System.Action$$($.$spc.System.String))().$ctor(this,  (/**/ __value) =>
                    {
                        return this.username = __value;
                    }, {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1097127,"h":0,"f":1048578}), this.username, null));
                    __builder.SetUpdatesAttributeName("value");
                    __builder.AddAttribute(17, "b-pkulom7sod");
                    __builder.CloseElement();
                    __builder.CloseElement();
                    __builder.AddMarkupContent(18, "\n\n            ");
                    __builder.OpenElement(19, "div");
                    __builder.AddAttribute$2(20, "class", "input-container");
                    __builder.AddAttribute(21, "b-pkulom7sod");
                    __builder.AddMarkupContent(22, "<label for=\"username\" b-pkulom7sod>Password</label>\n                ");
                    __builder.OpenElement(23, "input");
                    __builder.AddAttribute$2(24, "type", "password");
                    __builder.AddAttribute$2(25, "placeholder", "enter password...");
                    __builder.AddAttribute$2(26, "value", $.$mac.Microsoft.AspNetCore.Components.BindConverter.FormatValue(this.password, null));
                    __builder.AddAttribute$5($.$mac.Microsoft.AspNetCore.Components.ChangeEventArgs, 27, "onchange", $.$mac.Microsoft.AspNetCore.Components.EventCallbackFactoryBinderExtensions.CreateBinder($.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory, this, new ($.$spc.System.Action$$($.$spc.System.String))().$ctor(this,  (/*__value*/ __value) =>
                    {
                        return this.password = __value;
                    }, {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1097127,"h":0,"f":1048578}), this.password, null));
                    __builder.SetUpdatesAttributeName("value");
                    __builder.AddAttribute(28, "b-pkulom7sod");
                    __builder.CloseElement();
                    __builder.CloseElement();
                    __builder.AddMarkupContent(29, "\n\n            ");
                    __builder.OpenElement(30, "div");
                    __builder.AddAttribute$2(31, "class", "input-container");
                    __builder.AddAttribute(32, "b-pkulom7sod");
                    __builder.OpenElement(33, "button");
                    __builder.AddAttribute$5($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, 34, "onclick", $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$7($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, this, new $.$spc.System.Action().$ctor(this, this.LoginUser)));
                    __builder.AddAttribute(35, "b-pkulom7sod");
                    __builder.AddContent(36, "Login");
                    __builder.CloseElement();
                    __builder.CloseElement();
                    if (!this.Auth.IsLoggedIn)
                    {
                        __builder.OpenElement(37, "p");
                        __builder.AddAttribute(38, "b-pkulom7sod");
                        __builder.AddContent(39, this.errorMessage);
                        __builder.CloseElement();
                    }
                    __builder.OpenElement(40, "div");
                    __builder.AddAttribute$2(41, "class", "signup");
                    __builder.AddAttribute(42, "b-pkulom7sod");
                    __builder.AddMarkupContent(43, "<p b-pkulom7sod>Don't have an account?</p>\n                ");
                    __builder.OpenComponent($.$m.miniapp.Components.ButtonCard, 44);
                    __builder.AddComponentParameter(45, "BgColor", "rgb(127, 0, 127, 0.3)");
                    __builder.AddComponentParameter(46, "BtnText", "Sign Up");
                    __builder.AddComponentParameter(47, "OnClick", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$mac.Microsoft.AspNetCore.Components.EventCallback, $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$1(this, new $.$spc.System.Action().$ctor(this, this.SignUp))));
                    __builder.CloseComponent();
                    __builder.CloseElement();
                    __builder.CloseElement();
                    __builder.CloseElement();
                }
            }
            /*string*/ username = null;
            /*string*/ password = null;
            /*string*/ errorMessage = null;
            /*bool*/ isLoading = false;
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    this.isLoading = true;
                    await $.$spc.System.Threading.Tasks.Task.Delay$4(1000);
                    this.isLoading = false;
                });
            }
            /*Task *//*async*/  OnAfterRenderAsync(/*bool*/ firstRender)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    if (firstRender)
                    {
                        await this.Auth.LoadUsers();
                    }
                });
            }
            /*void */ OnInitialized()
            {
                if (this.Auth.IsLoggedIn)
                {
                    this.Nav.NavigateTo$1("/dashboard", false, false);
                }
            }
            /*void */ LoginUser()
            {
                /*bool*/ let success = this.Auth.Login(this.username, this.password);
                if (success)
                {
                    this.Nav.NavigateTo$1("/dashboard", false, false);
                }
                else 
                {
                    this.errorMessage = "\u26A0\uFE0F Username of Password is not correct";
                }
            }
            /*void */ SignUp()
            {
                this.Nav.NavigateTo$1("/signup", false, false);
            }
            /*NavigationManager*/ Nav = null;
            /*miniapp.Services.AuthService*/ Auth = null;
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.username = "";
                this.password = "";
                this.errorMessage = "";
                this.Nav = null;
                this.Auth = null;
            }
            static $h = 1097127;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":4980744,"g":{"r":0,"d":0,"h":55835671975,"f":2},"s":{"r":0,"d":0,"h":60130639271,"f":2},"n":"Nav","d":1097127,"h":51540704679,"f":2,"a":[{"t":4259848,"c":21479096328}]},{"p":1883559,"g":{"r":0,"d":0,"h":73015541159,"f":2},"s":{"r":0,"d":0,"h":77310508455,"f":2},"n":"Auth","d":1097127,"h":68720573863,"f":2,"a":[{"t":4259848,"c":21479096328}]}],"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","d":1097127,"h":4296064423,"f":32772},{"r":133300225,"n":"OnInitializedAsync","d":1097127,"h":25770900903,"f":36868},{"r":133300225,"p":[{"n":"firstRender","p":262145}],"n":"OnAfterRenderAsync","d":1097127,"h":30065868199,"f":36868},{"r":65537,"n":"OnInitialized","d":1097127,"h":34360835495,"f":32772},{"r":65537,"n":"LoginUser","d":1097127,"h":38655802791,"f":2},{"r":65537,"n":"SignUp","d":1097127,"h":42950770087,"f":2}],"l":[{"t":1310721,"n":"username","d":1097127,"h":8591031719,"f":2},{"t":1310721,"n":"password","d":1097127,"h":12885999015,"f":2},{"t":1310721,"n":"errorMessage","d":1097127,"h":17180966311,"f":2},{"t":262145,"n":"isLoading","d":1097127,"h":21475933607,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":1097127,"h":81605475751,"f":1}],"i":[2752520,3145736,3080200],"h":1097127,"a":[{"t":9895944,"c":4304863240,"a":[{"v":"/","t":1310721}]}]}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `miniapp.Components.Pages.Login`; }
        });
        
        $asm.$cls("$m.miniapp.Components.TaskCard", ($self) => class TaskCard extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OpenElement(0, "table");
                __builder.AddAttribute$2(1, "class", "task-container mobile");
                __builder.AddAttribute(2, "b-vrvjdqy2df");
                __builder.OpenElement(3, "tr");
                __builder.AddAttribute$2(4, "class", "tr");
                __builder.AddAttribute(5, "b-vrvjdqy2df");
                __builder.OpenElement(6, "td");
                __builder.AddAttribute$2(7, "class", "td1");
                __builder.AddAttribute(8, "b-vrvjdqy2df");
                __builder.OpenElement(9, "div");
                __builder.AddAttribute$5($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, 10, "onclick", $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$9($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, this, new ($.$spc.System.Func$$($.$spc.System.Threading.Tasks.Task))().$ctor(this,  () =>
                {
                    return this.OnToggle.InvokeAsync(this.Task.Id);
                }, {"r":133300225,"n":"","d":1621415,"h":0,"f":1048578})));
                __builder.AddAttribute$2(11, "class", "container-title");
                __builder.AddAttribute(12, "b-vrvjdqy2df");
                __builder.OpenElement(13, "p");
                __builder.AddAttribute(14, "b-vrvjdqy2df");
                __builder.OpenElement(15, "input");
                __builder.AddAttribute$2(16, "type", "checkbox");
                __builder.AddAttribute$1(17, "checked", $.$mac.Microsoft.AspNetCore.Components.BindConverter.FormatValue$1(this.Task.IsComplete, null));
                __builder.AddAttribute$5($.$mac.Microsoft.AspNetCore.Components.ChangeEventArgs, 18, "onchange", $.$mac.Microsoft.AspNetCore.Components.EventCallbackFactoryBinderExtensions.CreateBinder$2($.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory, this, new ($.$spc.System.Action$$($.$spc.System.Boolean))().$ctor(this,  (/*__value*/ __value) =>
                {
                    return this.Task.IsComplete = __value;
                }, {"r":65537,"p":[{"n":"__value","p":262145}],"n":"","d":1621415,"h":0,"f":1048578}), this.Task.IsComplete, null));
                __builder.SetUpdatesAttributeName("checked");
                __builder.AddAttribute(19, "b-vrvjdqy2df");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(20, "\n\n                ");
                __builder.OpenElement(21, "p");
                __builder.AddAttribute(22, "b-vrvjdqy2df");
                __builder.AddContent(23, this.Task.Title);
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(24, "\n        ");
                __builder.OpenElement(25, "td");
                __builder.AddAttribute$2(26, "class", "td2");
                __builder.AddAttribute(27, "b-vrvjdqy2df");
                __builder.OpenElement(28, "button");
                __builder.AddAttribute(29, "b-vrvjdqy2df");
                if (this.Task.Priority === 1/*Priority.Low*/)
                {
                    __builder.AddMarkupContent(30, "<span b-vrvjdqy2df><text b-vrvjdqy2df>\uD83D\uDD34</text></span>");
                }
                else if (this.Task.Priority === 2/*Priority.Medium*/)
                {
                    __builder.AddMarkupContent(31, "<span b-vrvjdqy2df><text b-vrvjdqy2df>\uD83D\uDFE1</text></span>");
                }
                else if (this.Task.Priority === 3/*Priority.High*/)
                {
                    __builder.AddMarkupContent(32, "<span b-vrvjdqy2df><text b-vrvjdqy2df>\uD83D\uDFE2</text></span>");
                }
                __builder.AddContent$5(33, $.$box(this.Task.Priority, $.$m.Priority));
                __builder.CloseElement();
                if (this.TaskIdToDelete === this.Task.Id)
                {
                    __builder.OpenElement(34, "button");
                    __builder.AddAttribute$2(35, "style", "width: 200px; margin-left: 5px; transition: 0.3s ease-in");
                    __builder.AddAttribute(36, "b-vrvjdqy2df");
                    __builder.OpenElement(37, "button");
                    __builder.AddAttribute$2(38, "style", "font-size: 12px; margin-right: 10px;");
                    __builder.AddAttribute$5($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, 39, "onclick", $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$9($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, this, new ($.$spc.System.Func$$($.$spc.System.Threading.Tasks.Task))().$ctor(this,  () =>
                    {
                        return this.OnDelete.InvokeAsync(this.Task.Id);
                    }, {"r":133300225,"n":"","d":1621415,"h":0,"f":1048578})));
                    __builder.AddAttribute(40, "b-vrvjdqy2df");
                    __builder.AddMarkupContent(41, "\u2705 Confirm");
                    __builder.CloseElement();
                    __builder.AddMarkupContent(42, "\n                    ");
                    __builder.OpenElement(43, "button");
                    __builder.AddAttribute$2(44, "style", "font-size: 12px;");
                    __builder.AddAttribute$5($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, 45, "onclick", $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$7($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, this, new $.$spc.System.Action().$ctor(this,  () =>
                    {
                        return this.TaskIdToDelete = null;
                    }, {"r":65537,"n":"","d":1621415,"h":0,"f":1048578})));
                    __builder.AddAttribute(46, "b-vrvjdqy2df");
                    __builder.AddMarkupContent(47, "\u274C Cancel");
                    __builder.CloseElement();
                    __builder.CloseElement();
                }
                else 
                {
                    __builder.OpenElement(48, "button");
                    __builder.AddAttribute$5($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, 49, "onclick", $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$7($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, this, new $.$spc.System.Action().$ctor(this,  () =>
                    {
                        return this.TaskIdToDelete = this.Task.Id;
                    }, {"r":65537,"n":"","d":1621415,"h":0,"f":1048578})));
                    __builder.AddAttribute(50, "b-vrvjdqy2df");
                    __builder.AddMarkupContent(51, "\uD83D\uDDD1\uFE0F");
                    __builder.CloseElement();
                }
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
            }
            /*int?*/ TaskIdToDelete = null;
            /*AppTask*/ Task = null;
            /*EventCallback<int>*/ OnDelete;
            /*EventCallback<int>*/ OnToggle;
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.TaskIdToDelete = null;
                this.Task = new $.$m.AppTask().$ctor$1();
                this.OnDelete = $.$default($.$mac.Microsoft.AspNetCore.Components.EventCallback$$($.$spc.System.Int32));
                this.OnToggle = $.$default($.$mac.Microsoft.AspNetCore.Components.EventCallback$$($.$spc.System.Int32));
            }
            static $h = 1621415;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":$.$typeNullable($.$spc.System.Int32).$h,"g":{"r":0,"d":0,"h":17181490599,"f":1},"s":{"r":0,"d":0,"h":21476457895,"f":1},"n":"TaskIdToDelete","d":1621415,"h":12886523303,"f":1,"a":[{"t":5636104,"c":21480472584}]},{"p":114087,"g":{"r":0,"d":0,"h":34361359783,"f":1},"s":{"r":0,"d":0,"h":38656327079,"f":1},"n":"Task","d":1621415,"h":30066392487,"f":1,"a":[{"t":5636104,"c":21480472584}]},{"p":$.$mac.Microsoft.AspNetCore.Components.EventCallback$$($.$spc.System.Int32).$h,"g":{"r":0,"d":0,"h":51541228967,"f":1},"s":{"r":0,"d":0,"h":55836196263,"f":1},"n":"OnDelete","d":1621415,"h":47246261671,"f":1,"a":[{"t":5636104,"c":21480472584}]},{"p":$.$mac.Microsoft.AspNetCore.Components.EventCallback$$($.$spc.System.Int32).$h,"g":{"r":0,"d":0,"h":68721098151,"f":1},"s":{"r":0,"d":0,"h":73016065447,"f":1},"n":"OnToggle","d":1621415,"h":64426130855,"f":1,"a":[{"t":5636104,"c":21480472584}]}],"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","d":1621415,"h":4296588711,"f":32772}],"c":[{"n":".ctor","o":"$ctor$2","d":1621415,"h":77311032743,"f":1}],"i":[2752520,3145736,3080200],"h":1621415}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `miniapp.Components.TaskCard`; }
        });
        
        $asm.$cls("$m.miniapp.Components.Pages.SignUp", ($self) => class SignUp extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                if (this.isLoading)
                {
                    __builder.AddMarkupContent(0, "<p b-4y7dh9dpok>\u23F3 Loading...</p>");
                }
                else 
                {
                    __builder.OpenElement(1, "div");
                    __builder.AddAttribute$2(2, "class", "login-container");
                    __builder.AddAttribute(3, "b-4y7dh9dpok");
                    __builder.AddMarkupContent(4, "<h3 b-4y7dh9dpok>Sign Up</h3>\n        ");
                    __builder.OpenElement(5, "div");
                    __builder.AddAttribute$2(6, "class", "sub-container");
                    __builder.AddAttribute(7, "b-4y7dh9dpok");
                    __builder.OpenElement(8, "div");
                    __builder.AddAttribute$2(9, "class", "input-container");
                    __builder.AddAttribute(10, "b-4y7dh9dpok");
                    __builder.AddMarkupContent(11, "<label for=\"username\" b-4y7dh9dpok>Firstname</label>\n                ");
                    __builder.OpenElement(12, "input");
                    __builder.AddAttribute$2(13, "type", "text");
                    __builder.AddAttribute$2(14, "placeholder", "enter firstname...");
                    __builder.AddAttribute$2(15, "value", $.$mac.Microsoft.AspNetCore.Components.BindConverter.FormatValue(this.firstname, null));
                    __builder.AddAttribute$5($.$mac.Microsoft.AspNetCore.Components.ChangeEventArgs, 16, "onchange", $.$mac.Microsoft.AspNetCore.Components.EventCallbackFactoryBinderExtensions.CreateBinder($.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory, this, new ($.$spc.System.Action$$($.$spc.System.String))().$ctor(this,  (/**/ __value) =>
                    {
                        return this.firstname = __value;
                    }, {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1228199,"h":0,"f":1048578}), this.firstname, null));
                    __builder.SetUpdatesAttributeName("value");
                    __builder.AddAttribute(17, "b-4y7dh9dpok");
                    __builder.CloseElement();
                    __builder.CloseElement();
                    __builder.AddMarkupContent(18, "\n\n            ");
                    __builder.OpenElement(19, "div");
                    __builder.AddAttribute$2(20, "class", "input-container");
                    __builder.AddAttribute(21, "b-4y7dh9dpok");
                    __builder.AddMarkupContent(22, "<label for=\"username\" b-4y7dh9dpok>Lastname</label>\n                ");
                    __builder.OpenElement(23, "input");
                    __builder.AddAttribute$2(24, "type", "text");
                    __builder.AddAttribute$2(25, "placeholder", "enter lastname...");
                    __builder.AddAttribute$2(26, "value", $.$mac.Microsoft.AspNetCore.Components.BindConverter.FormatValue(this.lastname, null));
                    __builder.AddAttribute$5($.$mac.Microsoft.AspNetCore.Components.ChangeEventArgs, 27, "onchange", $.$mac.Microsoft.AspNetCore.Components.EventCallbackFactoryBinderExtensions.CreateBinder($.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory, this, new ($.$spc.System.Action$$($.$spc.System.String))().$ctor(this,  (/*__value*/ __value) =>
                    {
                        return this.lastname = __value;
                    }, {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1228199,"h":0,"f":1048578}), this.lastname, null));
                    __builder.SetUpdatesAttributeName("value");
                    __builder.AddAttribute(28, "b-4y7dh9dpok");
                    __builder.CloseElement();
                    __builder.CloseElement();
                    __builder.AddMarkupContent(29, "\n\n            ");
                    __builder.OpenElement(30, "div");
                    __builder.AddAttribute$2(31, "class", "input-container");
                    __builder.AddAttribute(32, "b-4y7dh9dpok");
                    __builder.AddMarkupContent(33, "<label for=\"username\" b-4y7dh9dpok>Email</label>\n                ");
                    __builder.OpenElement(34, "input");
                    __builder.AddAttribute$2(35, "type", "email");
                    __builder.AddAttribute$2(36, "placeholder", "enter email...");
                    __builder.AddAttribute$2(37, "value", $.$mac.Microsoft.AspNetCore.Components.BindConverter.FormatValue(this.email, null));
                    __builder.AddAttribute$5($.$mac.Microsoft.AspNetCore.Components.ChangeEventArgs, 38, "onchange", $.$mac.Microsoft.AspNetCore.Components.EventCallbackFactoryBinderExtensions.CreateBinder($.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory, this, new ($.$spc.System.Action$$($.$spc.System.String))().$ctor(this,  (/*__value*/ __value) =>
                    {
                        return this.email = __value;
                    }, {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1228199,"h":0,"f":1048578}), this.email, null));
                    __builder.SetUpdatesAttributeName("value");
                    __builder.AddAttribute(39, "b-4y7dh9dpok");
                    __builder.CloseElement();
                    __builder.CloseElement();
                    __builder.AddMarkupContent(40, "\n\n            ");
                    __builder.OpenElement(41, "div");
                    __builder.AddAttribute$2(42, "class", "input-container");
                    __builder.AddAttribute(43, "b-4y7dh9dpok");
                    __builder.AddMarkupContent(44, "<label for=\"username\" b-4y7dh9dpok>Username</label>\n                ");
                    __builder.OpenElement(45, "input");
                    __builder.AddAttribute$2(46, "type", "text");
                    __builder.AddAttribute$2(47, "placeholder", "enter username...");
                    __builder.AddAttribute$2(48, "value", $.$mac.Microsoft.AspNetCore.Components.BindConverter.FormatValue(this.username, null));
                    __builder.AddAttribute$5($.$mac.Microsoft.AspNetCore.Components.ChangeEventArgs, 49, "onchange", $.$mac.Microsoft.AspNetCore.Components.EventCallbackFactoryBinderExtensions.CreateBinder($.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory, this, new ($.$spc.System.Action$$($.$spc.System.String))().$ctor(this,  (/*__value*/ __value) =>
                    {
                        return this.username = __value;
                    }, {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1228199,"h":0,"f":1048578}), this.username, null));
                    __builder.SetUpdatesAttributeName("value");
                    __builder.AddAttribute(50, "b-4y7dh9dpok");
                    __builder.CloseElement();
                    __builder.CloseElement();
                    __builder.AddMarkupContent(51, "\n\n            ");
                    __builder.OpenElement(52, "div");
                    __builder.AddAttribute$2(53, "class", "input-container");
                    __builder.AddAttribute(54, "b-4y7dh9dpok");
                    __builder.AddMarkupContent(55, "<label for=\"username\" b-4y7dh9dpok>Date of Birth</label>\n                ");
                    __builder.OpenElement(56, "input");
                    __builder.AddAttribute$2(57, "type", "date");
                    __builder.AddAttribute$2(58, "placeholder", "enter password...");
                    __builder.AddAttribute$2(59, "value", $.$mac.Microsoft.AspNetCore.Components.BindConverter.FormatValue$18(this.dateOfBirth?.Clone() ?? null, "yyyy-MM-dd", $.$spc.System.Globalization.CultureInfo.InvariantCulture));
                    __builder.AddAttribute$5($.$mac.Microsoft.AspNetCore.Components.ChangeEventArgs, 60, "onchange", $.$mac.Microsoft.AspNetCore.Components.EventCallbackFactoryBinderExtensions.CreateBinder$36($.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory, this, new ($.$spc.System.Action$$($.$spc.System.Nullable$$($.$spc.System.DateTime)))().$ctor(this,  (/*__value*/ __value) =>
                    {
                        return this.dateOfBirth = __value?.Clone() ?? null;
                    }, {"r":65537,"p":[{"n":"__value","p":$.$typeNullable($.$spc.System.DateTime).$h}],"n":"","d":1228199,"h":0,"f":1048578}), this.dateOfBirth?.Clone() ?? null, "yyyy-MM-dd", $.$spc.System.Globalization.CultureInfo.InvariantCulture));
                    __builder.SetUpdatesAttributeName("value");
                    __builder.AddAttribute(61, "b-4y7dh9dpok");
                    __builder.CloseElement();
                    __builder.CloseElement();
                    __builder.AddMarkupContent(62, "\n\n            ");
                    __builder.OpenElement(63, "div");
                    __builder.AddAttribute$2(64, "class", "input-container");
                    __builder.AddAttribute(65, "b-4y7dh9dpok");
                    __builder.AddMarkupContent(66, "<label for=\"username\" b-4y7dh9dpok>Role</label>\n                ");
                    __builder.OpenElement(67, "select");
                    __builder.AddAttribute$2(68, "name", "");
                    __builder.AddAttribute$2(69, "id", "");
                    __builder.AddAttribute$2(70, "value", $.$mac.Microsoft.AspNetCore.Components.BindConverter.FormatValue(this.role, null));
                    __builder.AddAttribute$5($.$mac.Microsoft.AspNetCore.Components.ChangeEventArgs, 71, "onchange", $.$mac.Microsoft.AspNetCore.Components.EventCallbackFactoryBinderExtensions.CreateBinder($.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory, this, new ($.$spc.System.Action$$($.$spc.System.String))().$ctor(this,  (/*__value*/ __value) =>
                    {
                        return this.role = __value;
                    }, {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1228199,"h":0,"f":1048578}), this.role, null));
                    __builder.SetUpdatesAttributeName("value");
                    __builder.AddAttribute(72, "b-4y7dh9dpok");
                    __builder.OpenElement(73, "option");
                    __builder.AddAttribute$2(74, "value", "Admin");
                    __builder.AddAttribute(75, "b-4y7dh9dpok");
                    __builder.AddContent(76, "Admin");
                    __builder.CloseElement();
                    __builder.AddMarkupContent(77, "\n                    ");
                    __builder.OpenElement(78, "option");
                    __builder.AddAttribute$2(79, "value", "User");
                    __builder.AddAttribute(80, "b-4y7dh9dpok");
                    __builder.AddContent(81, "User");
                    __builder.CloseElement();
                    __builder.CloseElement();
                    __builder.CloseElement();
                    __builder.AddMarkupContent(82, "\n\n            ");
                    __builder.OpenElement(83, "div");
                    __builder.AddAttribute$2(84, "class", "input-container");
                    __builder.AddAttribute(85, "b-4y7dh9dpok");
                    __builder.AddMarkupContent(86, "<label for=\"username\" b-4y7dh9dpok>Password</label>\n                ");
                    __builder.OpenElement(87, "input");
                    __builder.AddAttribute$2(88, "type", "password");
                    __builder.AddAttribute$2(89, "placeholder", "enter password...");
                    __builder.AddAttribute$2(90, "value", $.$mac.Microsoft.AspNetCore.Components.BindConverter.FormatValue(this.password, null));
                    __builder.AddAttribute$5($.$mac.Microsoft.AspNetCore.Components.ChangeEventArgs, 91, "onchange", $.$mac.Microsoft.AspNetCore.Components.EventCallbackFactoryBinderExtensions.CreateBinder($.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory, this, new ($.$spc.System.Action$$($.$spc.System.String))().$ctor(this,  (/*__value*/ __value) =>
                    {
                        return this.password = __value;
                    }, {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1228199,"h":0,"f":1048578}), this.password, null));
                    __builder.SetUpdatesAttributeName("value");
                    __builder.AddAttribute(92, "b-4y7dh9dpok");
                    __builder.CloseElement();
                    __builder.CloseElement();
                    __builder.AddMarkupContent(93, "\n\n            ");
                    __builder.OpenElement(94, "div");
                    __builder.AddAttribute$2(95, "class", "input-container");
                    __builder.AddAttribute(96, "b-4y7dh9dpok");
                    __builder.AddMarkupContent(97, "<label for=\"username\" b-4y7dh9dpok>Confirm password</label>\n                ");
                    __builder.OpenElement(98, "input");
                    __builder.AddAttribute$2(99, "type", "password");
                    __builder.AddAttribute$2(100, "placeholder", "enter password...");
                    __builder.AddAttribute$2(101, "value", $.$mac.Microsoft.AspNetCore.Components.BindConverter.FormatValue(this.confirmPassword, null));
                    __builder.AddAttribute$5($.$mac.Microsoft.AspNetCore.Components.ChangeEventArgs, 102, "onchange", $.$mac.Microsoft.AspNetCore.Components.EventCallbackFactoryBinderExtensions.CreateBinder($.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory, this, new ($.$spc.System.Action$$($.$spc.System.String))().$ctor(this,  (/*__value*/ __value) =>
                    {
                        return this.confirmPassword = __value;
                    }, {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1228199,"h":0,"f":1048578}), this.confirmPassword, null));
                    __builder.SetUpdatesAttributeName("value");
                    __builder.AddAttribute(103, "b-4y7dh9dpok");
                    __builder.CloseElement();
                    __builder.CloseElement();
                    __builder.AddMarkupContent(104, "\n\n            ");
                    __builder.OpenElement(105, "div");
                    __builder.AddAttribute$2(106, "class", "input-container");
                    __builder.AddAttribute(107, "b-4y7dh9dpok");
                    __builder.OpenElement(108, "button");
                    __builder.AddAttribute$5($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, 109, "onclick", $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$9($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, this, new ($.$spc.System.Func$$($.$spc.System.Threading.Tasks.Task))().$ctor(this, this.SignupUser)));
                    __builder.AddAttribute(110, "b-4y7dh9dpok");
                    __builder.AddContent(111, "Sign Up");
                    __builder.CloseElement();
                    __builder.CloseElement();
                    if (!this.Auth.IsLoggedIn)
                    {
                        __builder.OpenElement(112, "p");
                        __builder.AddAttribute(113, "b-4y7dh9dpok");
                        __builder.AddContent(114, this.errorMessage);
                        __builder.CloseElement();
                    }
                    __builder.CloseElement();
                    __builder.CloseElement();
                }
            }
            /*string*/ firstname = null;
            /*string*/ lastname = null;
            /*string*/ email = null;
            /*string*/ role = null;
            /*DateTime?*/ dateOfBirth = null;
            /*string*/ username = null;
            /*string*/ password = null;
            /*string*/ confirmPassword = null;
            /*string*/ errorMessage = null;
            /*bool*/ isLoading = true;
            /*List<UserModel>*/ users = null;
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    this.isLoading = true;
                    await $.$spc.System.Threading.Tasks.Task.Delay$4(1000);
                    this.isLoading = false;
                });
            }
            /*void */ OnInitialized()
            {
                if (this.Auth.IsLoggedIn)
                {
                    this.Nav.NavigateTo$1("/dashboard", false, false);
                }
            }
            /*Task *//*async*/  OnAfterRenderAsync(/*bool*/ firstRender)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    if (firstRender)
                    {
                        await this.LoadUsers();
                        this.isLoading = false;
                        this.StateHasChanged();
                    }
                });
            }
            /*Task *//*async*/  LoadUsers()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    await this.Auth.LoadUsers();
                });
            }
            /*Task *//*async*/  SignupUser()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    /*var*/ let user = this.Auth.SignUp(this.firstname, this.lastname, this.email, this.role, this.dateOfBirth?.Clone() ?? null, this.username, this.password, this.confirmPassword);
                    /*bool*/ let success = true;
                    /*var*/ let newUser = (() =>
                    {
                        //new $.$m.UserModel()
                        const $t1 = $.$m.UserModel;
                        const $i1 = new $t1();
                        $i1.FirstName = this.firstname;
                        $i1.LastName = this.lastname;
                        $i1.Email = this.email;
                        $i1.DateOfBirth = this.dateOfBirth?.Clone() ?? null;
                        $i1.Username = this.username;
                        $i1.Password = this.password;
                        $i1.Role = this.role;
                        return $i1;
                    })();
                    this.users.Add(newUser);
                    await this.SaveUser();
                    await this.LoadUsers();
                    if (success)
                    {
                        this.Nav.NavigateTo$1("/signupsuccess", false, false);
                    }
                    else 
                    {
                        this.errorMessage = "\u26A0\uFE0F User already exist.";
                    }
                });
            }
            /*Task *//*async*/  SaveUser()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    await this.Auth.SaveUser();
                });
            }
            /*IJSRuntime*/ JS = null;
            /*NavigationManager*/ Nav = null;
            /*miniapp.Services.AuthService*/ Auth = null;
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.firstname = "";
                this.lastname = "";
                this.email = "";
                this.role = "";
                this.dateOfBirth = null;
                this.username = "";
                this.password = "";
                this.confirmPassword = "";
                this.errorMessage = "";
                this.users = new ($.$spc.System.Collections.Generic.List$$($.$m.UserModel))().$ctor$1();
                this.JS = null;
                this.Nav = null;
                this.Auth = null;
            }
            static $h = 1228199;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":524318,"g":{"r":0,"d":0,"h":90195541415,"f":2},"s":{"r":0,"d":0,"h":94490508711,"f":2},"n":"JS","d":1228199,"h":85900574119,"f":2,"a":[{"t":4259848,"c":21479096328}]},{"p":4980744,"g":{"r":0,"d":0,"h":107375410599,"f":2},"s":{"r":0,"d":0,"h":111670377895,"f":2},"n":"Nav","d":1228199,"h":103080443303,"f":2,"a":[{"t":4259848,"c":21479096328}]},{"p":1883559,"g":{"r":0,"d":0,"h":124555279783,"f":2},"s":{"r":0,"d":0,"h":128850247079,"f":2},"n":"Auth","d":1228199,"h":120260312487,"f":2,"a":[{"t":4259848,"c":21479096328}]}],"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","d":1228199,"h":4296195495,"f":32772},{"r":133300225,"n":"OnInitializedAsync","d":1228199,"h":55835803047,"f":36868},{"r":65537,"n":"OnInitialized","d":1228199,"h":60130770343,"f":32772},{"r":133300225,"p":[{"n":"firstRender","p":262145}],"n":"OnAfterRenderAsync","d":1228199,"h":64425737639,"f":36868},{"r":133300225,"n":"LoadUsers","d":1228199,"h":68720704935,"f":4098},{"r":133300225,"n":"SignupUser","d":1228199,"h":73015672231,"f":4098},{"r":133300225,"n":"SaveUser","d":1228199,"h":77310639527,"f":4098}],"l":[{"t":1310721,"n":"firstname","d":1228199,"h":8591162791,"f":2},{"t":1310721,"n":"lastname","d":1228199,"h":12886130087,"f":2},{"t":1310721,"n":"email","d":1228199,"h":17181097383,"f":2},{"t":1310721,"n":"role","d":1228199,"h":21476064679,"f":2},{"t":$.$typeNullable($.$spc.System.DateTime).$h,"n":"dateOfBirth","d":1228199,"h":25771031975,"f":2},{"t":1310721,"n":"username","d":1228199,"h":30065999271,"f":2},{"t":1310721,"n":"password","d":1228199,"h":34360966567,"f":2},{"t":1310721,"n":"confirmPassword","d":1228199,"h":38655933863,"f":2},{"t":1310721,"n":"errorMessage","d":1228199,"h":42950901159,"f":2},{"t":262145,"n":"isLoading","d":1228199,"h":47245868455,"f":2},{"t":$.$spc.System.Collections.Generic.List$$($.$m.UserModel).$h,"n":"users","d":1228199,"h":51540835751,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":1228199,"h":133145214375,"f":1}],"i":[2752520,3145736,3080200],"h":1228199,"a":[{"t":9895944,"c":4304863240,"a":[{"v":"/signup","t":1310721}]}]}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `miniapp.Components.Pages.SignUp`; }
        });
        
        $asm.$cls("$m.miniapp.Components.Pages.Profile", ($self) => class Profile extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OpenComponent($.$m.miniapp.Components.NavBar, 0);
                __builder.CloseComponent();
                if (this.isLoading)
                {
                    if ($.$spc.System.String.op_Equality(this.Auth.Role, "Admin"))
                    {
                        __builder.OpenComponent($.$m.miniapp.Components.LoadingCardMajor, 1);
                        __builder.AddComponentParameter(2, "LoadingState", "\u23F3 Loading Admin profile...");
                        __builder.CloseComponent();
                    }
                    else if ($.$spc.System.String.op_Equality(this.Auth.Role, "User"))
                    {
                        __builder.OpenComponent($.$m.miniapp.Components.LoadingCardMajor, 3);
                        __builder.AddComponentParameter(4, "LoadingState", "\u23F3 Loading User profile...");
                        __builder.CloseComponent();
                    }
                    else 
                    {
                        __builder.OpenComponent($.$m.miniapp.Components.LoadingCardMajor, 5);
                        __builder.AddComponentParameter(6, "LoadingState", "\u23F3 Loading profile...");
                        __builder.CloseComponent();
                    }
                }
                else 
                {
                    __builder.AddMarkupContent(7, "<h3>\uD83D\uDC64 My Profile</h3>");
                    __builder.OpenElement(8, "div");
                    __builder.AddAttribute$2(9, "style", "background: rgb(255, 166, 0, 0.2); padding: 20px 40px; font-size: 20px; margin-top: 30px; flex-wrap: wrap;");
                    __builder.OpenElement(10, "div");
                    __builder.AddAttribute$2(11, "style", "background: rgb(255, 166, 0, 0.2); padding: 20px 40px; font-size: 20px; display: flex; justify-content: space-between; margin-top: 30px; flex-wrap: wrap;");
                    __builder.OpenElement(12, "p");
                    __builder.AddMarkupContent(13, "<b style=\"color: purple;\">\uD83D\uDE4E\u200D\u2642\uFE0F Fullname:</b>\n                ");
                    __builder.AddContent(14, this.fullName);
                    __builder.CloseElement();
                    __builder.AddMarkupContent(15, "\n            ");
                    __builder.OpenElement(16, "p");
                    __builder.AddMarkupContent(17, "<b style=\"color: purple;\">\uD83D\uDC66 Username:</b>\n                ");
                    __builder.AddContent(18, this.Auth.Username);
                    __builder.CloseElement();
                    __builder.AddMarkupContent(19, "\n            ");
                    __builder.OpenElement(20, "p");
                    __builder.AddMarkupContent(21, "<b style=\"color: purple; margin-right: 4px;\">\uD83D\uDCC5 Member since:</b>");
                    if (this.Auth.IsLoggedIn)
                    {
                        __builder.AddContent(22, $.$spc.System.DateTime.Now.ToString$1("MMM yyyy"));
                    }
                    __builder.CloseElement();
                    __builder.CloseElement();
                    __builder.AddMarkupContent(23, "\n        ");
                    __builder.OpenElement(24, "div");
                    __builder.AddAttribute$2(25, "style", "background: rgb(255, 166, 0, 0.2); padding: 20px 40px; font-size: 20px; display: flex; justify-content: space-between; margin-top: 30px; flex-wrap: wrap;");
                    __builder.OpenElement(26, "p");
                    __builder.AddMarkupContent(27, "<b style=\"color: purple;\">\uD83C\uDFF7\uFE0F Role:</b>\n                ");
                    __builder.AddContent(28, this.Auth.Role);
                    __builder.CloseElement();
                    __builder.AddMarkupContent(29, "\n            ");
                    __builder.OpenElement(30, "p");
                    __builder.AddMarkupContent(31, "<b style=\"color: purple;\">\uD83D\uDCC5 Date of Birth:</b>\n                ");
                    __builder.AddContent(32, this.Auth.DateOfBirth);
                    __builder.CloseElement();
                    __builder.AddMarkupContent(33, "\n            ");
                    __builder.OpenElement(34, "p");
                    __builder.AddMarkupContent(35, "<b style=\"color: purple; margin-right: 4px;\">\uD83D\uDCE7 Email:</b>\n                ");
                    __builder.AddContent(36, this.Auth.Email);
                    __builder.CloseElement();
                    __builder.CloseElement();
                    __builder.CloseElement();
                    if (!this.Auth.IsLoggedIn)
                    {
                        __builder.OpenComponent($.$m.miniapp.Components.NotLoginCard, 37);
                        __builder.AddComponentParameter(38, "Title", "User not logged in...");
                        __builder.AddComponentParameter(39, "SubTitle", "Click to log in...");
                        __builder.CloseComponent();
                    }
                    else 
                    {
                        __builder.OpenElement(40, "div");
                        __builder.AddAttribute$2(41, "style", "background: rgb(133, 133, 133, 0.2); padding: 20px 40px; font-size: 20px; margin: 30px 0;");
                        __builder.AddMarkupContent(42, "<h5>\uD83D\uDCCA My Stats</h5>\n            ");
                        __builder.OpenElement(43, "div");
                        __builder.AddAttribute$2(44, "style", "background: rgb(133, 133, 133, 0.2); padding: 20px 40px; font-size: 20px; display: flex; justify-content: space-between; flex-wrap: wrap; margin-top: 30px;");
                        __builder.OpenElement(45, "p");
                        __builder.AddMarkupContent(46, "<b style=\"margin-right: 20px\">\u2705 Completed: </b>\n                    ");
                        __builder.OpenElement(47, "i");
                        __builder.AddAttribute$2(48, "style", "font-size: 30px; color: purple; font-weight: bold;");
                        __builder.AddContent(49, this.completedCount);
                        __builder.CloseElement();
                        __builder.CloseElement();
                        __builder.AddMarkupContent(50, "\n                ");
                        __builder.OpenElement(51, "p");
                        __builder.AddMarkupContent(52, "<b style=\"margin-right: 20px\">\u23F3 Pending: </b>\n                    ");
                        __builder.OpenElement(53, "i");
                        __builder.AddAttribute$2(54, "style", "font-size: 30px; color: purple; font-weight: bold;");
                        __builder.AddContent(55, this.pendingCount);
                        __builder.CloseElement();
                        __builder.CloseElement();
                        __builder.AddMarkupContent(56, "\n                ");
                        __builder.OpenElement(57, "p");
                        __builder.AddMarkupContent(58, "<b style=\"margin-right: 20px\">\uD83D\uDCDD Total: </b>\n                    ");
                        __builder.OpenElement(59, "i");
                        __builder.AddAttribute$2(60, "style", "font-size: 30px; color: purple; font-weight: bold;");
                        __builder.AddContent(61, this.tasksCount);
                        __builder.CloseElement();
                        __builder.CloseElement();
                        __builder.CloseElement();
                        __builder.CloseElement();
                        __builder.OpenElement(62, "div");
                        __builder.AddAttribute$2(63, "style", "display: flex; justify-content: space-between; flex-wrap: wrap;");
                        __builder.OpenElement(64, "div");
                        __builder.AddAttribute$2(65, "style", "margin-bottom: 10px;");
                        __builder.OpenElement(66, "div");
                        __builder.AddAttribute$2(67, "style", "margin-bottom: 10px;");
                        __builder.OpenComponent($.$m.miniapp.Components.ButtonCard, 68);
                        __builder.AddComponentParameter(69, "BgColor", "rgb(140, 0, 140, 0.3)");
                        __builder.AddComponentParameter(70, "BtnText", "\u2B05 Back To DashBoard");
                        __builder.AddComponentParameter(71, "OnClick", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$mac.Microsoft.AspNetCore.Components.EventCallback, $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$1(this, new $.$spc.System.Action().$ctor(this, this.BackToDashboard))));
                        __builder.CloseComponent();
                        __builder.CloseElement();
                        __builder.AddMarkupContent(72, "\n                ");
                        __builder.OpenElement(73, "div");
                        __builder.AddAttribute$2(74, "style", "margin-bottom: 10px;");
                        __builder.OpenComponent($.$m.miniapp.Components.ButtonCard, 75);
                        __builder.AddComponentParameter(76, "BgColor", "rgb(135, 135, 135, 0.3)");
                        __builder.AddComponentParameter(77, "BtnText", "\uD83D\uDEAA Logout");
                        __builder.AddComponentParameter(78, "OnClick", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$mac.Microsoft.AspNetCore.Components.EventCallback, $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$1(this, new $.$spc.System.Action().$ctor(this, this.Logout))));
                        __builder.CloseComponent();
                        __builder.CloseElement();
                        __builder.CloseElement();
                        if (this.confirmAccountDelete === false)
                        {
                            __builder.OpenElement(79, "div");
                            __builder.AddAttribute$2(80, "style", "display: flex; gap:10px;");
                            __builder.OpenElement(81, "div");
                            __builder.AddAttribute$2(82, "style", "margin-bottom: 10px;");
                            __builder.OpenComponent($.$m.miniapp.Components.ButtonCard, 83);
                            __builder.AddComponentParameter(84, "BgColor", "rgba(255, 0, 0, 0.3)");
                            __builder.AddComponentParameter(85, "BtnText", "\u2705 Confirm");
                            __builder.AddComponentParameter(86, "OnClick", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$mac.Microsoft.AspNetCore.Components.EventCallback, $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$3(this, new ($.$spc.System.Func$$($.$spc.System.Threading.Tasks.Task))().$ctor(this, this.DeleteUserAccount))));
                            __builder.CloseComponent();
                            __builder.CloseElement();
                            __builder.AddMarkupContent(87, "\n                    ");
                            __builder.OpenElement(88, "div");
                            __builder.AddAttribute$2(89, "style", "margin-bottom: 10px;");
                            __builder.OpenComponent($.$m.miniapp.Components.ButtonCard, 90);
                            __builder.AddComponentParameter(91, "BgColor", "rgb(126, 126, 126, 0.3)");
                            __builder.AddComponentParameter(92, "BtnText", "\u274C Cancel");
                            __builder.AddComponentParameter(93, "OnClick", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$mac.Microsoft.AspNetCore.Components.EventCallback, $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$1(this, new $.$spc.System.Action().$ctor(this,  () =>
                            {
                                return this.confirmAccountDelete = true;
                            }, {"r":65537,"n":"","d":1162663,"h":0,"f":1048578}))));
                            __builder.CloseComponent();
                            __builder.CloseElement();
                            __builder.CloseElement();
                        }
                        else 
                        {
                            __builder.OpenElement(94, "div");
                            __builder.AddAttribute$2(95, "style", "margin-bottom: 10px;");
                            __builder.OpenComponent($.$m.miniapp.Components.ButtonCard, 96);
                            __builder.AddComponentParameter(97, "BgColor", "rgba(255, 0, 0, 0.3)");
                            __builder.AddComponentParameter(98, "BtnText", "\uD83D\uDDD1\uFE0F Delete Account");
                            __builder.AddComponentParameter(99, "OnClick", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$mac.Microsoft.AspNetCore.Components.EventCallback, $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$1(this, new $.$spc.System.Action().$ctor(this,  () =>
                            {
                                return this.confirmAccountDelete = false;
                            }, {"r":65537,"n":"","d":1162663,"h":0,"f":1048578}))));
                            __builder.CloseComponent();
                            __builder.CloseElement();
                        }
                        __builder.CloseElement();
                    }
                }
            }
            /*bool*/ isLoading = false;
            /*List<AppTask> */ get tasks()
            {
                return this.TaskService.ITaskService$GetAll() ?? new ($.$spc.System.Collections.Generic.List$$($.$m.AppTask))().$ctor$1();
            }
            /*string */ get tasksCount()
            {
                return $.$spc.System.Int32.ToString.call(this.tasks.Count);
            }
            /*string */ get completedCount()
            {
                return $.$spc.System.Int32.ToString.call($.$sl.System.Linq.Enumerable.Count$1($.$m.AppTask, this.tasks, new ($.$spc.System.Func$$$($.$m.AppTask, $.$spc.System.Boolean))().$ctor(this,  (/*t*/ t) =>
                {
                    return t.IsComplete;
                }, {"r":262145,"p":[{"n":"t","p":114087}],"n":"","d":1162663,"h":0,"f":1048578})));
            }
            /*string */ get pendingCount()
            {
                return $.$spc.System.Int32.ToString.call($.$sl.System.Linq.Enumerable.Count$1($.$m.AppTask, this.tasks, new ($.$spc.System.Func$$$($.$m.AppTask, $.$spc.System.Boolean))().$ctor(this,  (/*t*/ t) =>
                {
                    return !t.IsComplete;
                }, {"r":262145,"p":[{"n":"t","p":114087}],"n":"","d":1162663,"h":0,"f":1048578})));
            }
            /*string */ get fullName()
            {
                return `${this.Auth.Lastname} ${this.Auth.Firstname}`;
            }
            /*bool*/ confirmAccountDelete = true;
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    this.isLoading = true;
                    await $.$spc.System.Threading.Tasks.Task.Delay$4(2000);
                    this.isLoading = false;
                    this.StateHasChanged();
                });
            }
            /*void */ BackToDashboard()
            {
                this.Nav.NavigateTo$1("/dashboard", false, false);
                this.StateHasChanged();
            }
            /*Task *//*async*/  DeleteUserAccount()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    await this.Auth.DeleteAccount();
                    this.StateHasChanged();
                });
            }
            /*void */ Logout()
            {
                this.Nav.NavigateTo$1("/", false, false);
                this.Auth.Logout();
            }
            /*Task *//*async*/  OnAfterRenderAsync(/*bool*/ firstRender)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    if (firstRender)
                    {
                        await this.Auth.LoadUsers();
                        await this.TaskService.ITaskService$LoadTasks();
                        this.StateHasChanged();
                    }
                });
            }
            /*NavigationManager*/ Nav = null;
            /*ITaskService*/ TaskService = null;
            /*miniapp.Services.AuthService*/ Auth = null;
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.isLoading = false;
                this.Nav = null;
                this.TaskService = null;
                this.Auth = null;
            }
            static $h = 1162663;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17181031847,"f":2},"s":{"r":0,"d":0,"h":21475999143,"f":2},"n":"isLoading","d":1162663,"h":12886064551,"f":2},{"p":$.$spc.System.Collections.Generic.List$$($.$m.AppTask).$h,"g":{"r":0,"d":0,"h":30065933735,"f":2},"n":"tasks","d":1162663,"h":25770966439,"f":2},{"p":1310721,"g":{"r":0,"d":0,"h":38655868327,"f":2},"n":"tasksCount","d":1162663,"h":34360901031,"f":2},{"p":1310721,"g":{"r":0,"d":0,"h":47245802919,"f":2},"n":"completedCount","d":1162663,"h":42950835623,"f":2},{"p":1310721,"g":{"r":0,"d":0,"h":55835737511,"f":2},"n":"pendingCount","d":1162663,"h":51540770215,"f":2},{"p":1310721,"g":{"r":0,"d":0,"h":64425672103,"f":2},"n":"fullName","d":1162663,"h":60130704807,"f":2},{"p":4980744,"g":{"r":0,"d":0,"h":103080377767,"f":2},"s":{"r":0,"d":0,"h":107375345063,"f":2},"n":"Nav","d":1162663,"h":98785410471,"f":2,"a":[{"t":4259848,"c":21479096328}]},{"p":179623,"g":{"r":0,"d":0,"h":120260246951,"f":2},"s":{"r":0,"d":0,"h":124555214247,"f":2},"n":"TaskService","d":1162663,"h":115965279655,"f":2,"a":[{"t":4259848,"c":21479096328}]},{"p":1883559,"g":{"r":0,"d":0,"h":137440116135,"f":2},"s":{"r":0,"d":0,"h":141735083431,"f":2},"n":"Auth","d":1162663,"h":133145148839,"f":2,"a":[{"t":4259848,"c":21479096328}]}],"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","d":1162663,"h":4296129959,"f":32772},{"r":133300225,"n":"OnInitializedAsync","d":1162663,"h":73015606695,"f":36868},{"r":65537,"n":"BackToDashboard","d":1162663,"h":77310573991,"f":2},{"r":133300225,"n":"DeleteUserAccount","d":1162663,"h":81605541287,"f":4098},{"r":65537,"n":"Logout","d":1162663,"h":85900508583,"f":2},{"r":133300225,"p":[{"n":"firstRender","p":262145}],"n":"OnAfterRenderAsync","d":1162663,"h":90195475879,"f":36868}],"l":[{"t":262145,"n":"confirmAccountDelete","d":1162663,"h":68720639399,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":1162663,"h":146030050727,"f":1}],"i":[2752520,3145736,3080200],"h":1162663,"a":[{"t":9895944,"c":4304863240,"a":[{"v":"/profile","t":1310721}]}]}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `miniapp.Components.Pages.Profile`; }
        });
        
        $asm.$cls("$m.miniapp.Components.Pages.Tasks", ($self) => class Tasks extends $.$mac.Microsoft.AspNetCore.Components.ComponentBase
        {
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OpenComponent($.$m.miniapp.Components.NavBar, 0);
                __builder.CloseComponent();
                __builder.AddMarkupContent(1, "\n\n");
                __builder.OpenElement(2, "div");
                __builder.AddAttribute$2(3, "class", "mobile");
                __builder.AddAttribute$2(4, "style", "display: flex; flex-wrap: wrap; margin-bottom: 20px; gap: 5px; justify-content: space-between;");
                __builder.AddAttribute(5, "b-eh7nwjtt9e");
                __builder.AddMarkupContent(6, "<h3 style=\"margin-bottom: 30px;\" b-eh7nwjtt9e>\uD83D\uDCDD Task Manager </h3>");
                if (this.Auth.IsLoggedIn)
                {
                    if ($.$sl.System.Linq.Enumerable.Any($.$m.AppTask, this.tasks))
                    {
                        __builder.OpenElement(7, "div");
                        __builder.AddAttribute$2(8, "class", "i");
                        __builder.AddAttribute(9, "b-eh7nwjtt9e");
                        __builder.OpenElement(10, "i");
                        __builder.AddAttribute$2(11, "style", "font-size: 15px; color: white; margin-top: 5px; background: rgb(0, 107, 0, 0.7); padding: 0 30px; margin: 0; border-bottom-right-radius: 20px; border-top-right-radius: 20px; display: flex; align-items: center;");
                        __builder.AddAttribute(12, "b-eh7nwjtt9e");
                        __builder.AddContent$5(13, $.$box(this.tasks.Count, $.$spc.System.Int32));
                        __builder.AddContent(14, " task(s) added");
                        __builder.CloseElement();
                        __builder.CloseElement();
                    }
                }
                __builder.CloseElement();
                __builder.AddMarkupContent(15, "\n\n    ");
                __builder.AddMarkupContent(16, "<h5 b-eh7nwjtt9e>Priority</h5>\n\n    ");
                __builder.OpenElement(17, "div");
                __builder.AddAttribute$2(18, "style", "display: flex; flex-wrap: wrap; gap: 10px;");
                __builder.AddAttribute(19, "b-eh7nwjtt9e");
                __builder.OpenElement(20, "select");
                __builder.AddAttribute(21, "name");
                __builder.AddAttribute(22, "id");
                __builder.AddAttribute$2(23, "class", "opt-btn");
                __builder.AddAttribute$2(24, "style", "padding: 10px; border: none; background: rgb(255, 166, 0, 0.2); width: 50%; border-radius: 10px;");
                __builder.AddAttribute(25, "b-eh7nwjtt9e");
                __builder.OpenElement(26, "option");
                __builder.AddAttribute$2(27, "value", "All");
                __builder.AddAttribute(28, "b-eh7nwjtt9e");
                __builder.AddContent(29, "All");
                __builder.CloseElement();
                __builder.AddMarkupContent(30, "\n            ");
                __builder.OpenElement(31, "option");
                __builder.AddAttribute$2(32, "value", "Pending");
                __builder.AddAttribute(33, "b-eh7nwjtt9e");
                __builder.AddContent(34, "Pending");
                __builder.CloseElement();
                __builder.AddMarkupContent(35, "\n            ");
                __builder.OpenElement(36, "option");
                __builder.AddAttribute$2(37, "value", "Done");
                __builder.AddAttribute(38, "b-eh7nwjtt9e");
                __builder.AddContent(39, "Done");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(40, "\n        ");
                __builder.OpenElement(41, "div");
                __builder.AddAttribute$2(42, "class", "opt-btn");
                __builder.AddAttribute(43, "b-eh7nwjtt9e");
                __builder.OpenElement(44, "button");
                __builder.AddAttribute$2(45, "class", "btn-hov");
                __builder.AddAttribute$2(46, "style", "padding: 10px; border: none; background: rgb(255, 166, 0, 0.2); border-radius: 10px;");
                __builder.AddAttribute$5($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, 47, "onclick", $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$7($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, this, new $.$spc.System.Action().$ctor(this, this.AllTasks)));
                __builder.AddAttribute(48, "b-eh7nwjtt9e");
                __builder.AddContent(49, "All");
                __builder.CloseElement();
                __builder.AddMarkupContent(50, "\n            ");
                __builder.OpenElement(51, "button");
                __builder.AddAttribute$2(52, "class", "btn-hov");
                __builder.AddAttribute$2(53, "style", "padding: 10px; border: none; background: rgb(255, 166, 0, 0.2); border-radius: 10px;");
                __builder.AddAttribute$5($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, 54, "onclick", $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$7($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, this, new $.$spc.System.Action().$ctor(this, this.Pending)));
                __builder.AddAttribute(55, "b-eh7nwjtt9e");
                __builder.AddMarkupContent(56, "\u23F3\n                Pending");
                __builder.CloseElement();
                __builder.AddMarkupContent(57, "\n                ");
                __builder.OpenElement(58, "button");
                __builder.AddAttribute$2(59, "class", "btn-hov");
                __builder.AddAttribute$2(60, "style", "padding: 10px; border: none; background: rgb(255, 166, 0, 0.2); border-radius: 10px;");
                __builder.AddAttribute$5($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, 61, "onclick", $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$7($.$macw.Microsoft.AspNetCore.Components.Web.MouseEventArgs, this, new $.$spc.System.Action().$ctor(this, this.Completed)));
                __builder.AddAttribute(62, "b-eh7nwjtt9e");
                __builder.AddMarkupContent(63, "\u2705\n                    Done");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(64, "\n\n            ");
                __builder.OpenElement(65, "div");
                __builder.AddAttribute$2(66, "style", "display: flex; flex-wrap: wrap; gap: 10px; padding: 30px 0; width: 100%");
                __builder.AddAttribute(67, "b-eh7nwjtt9e");
                __builder.OpenElement(68, "div");
                __builder.AddAttribute(69, "style");
                __builder.AddAttribute(70, "b-eh7nwjtt9e");
                __builder.AddMarkupContent(71, "<label for=\"title\" b-eh7nwjtt9e>Title:</label>\n                    ");
                __builder.OpenElement(72, "input");
                __builder.AddAttribute$2(73, "type", "text");
                __builder.AddAttribute$2(74, "placeholder", "enter task title...");
                __builder.AddAttribute$2(75, "style", "padding: 10px; border: none; background: rgb(255, 166, 0, 0.2); width: 100%; border-radius: 10px;");
                __builder.AddAttribute$2(76, "value", $.$mac.Microsoft.AspNetCore.Components.BindConverter.FormatValue(this.taskTitle, null));
                __builder.AddAttribute$5($.$mac.Microsoft.AspNetCore.Components.ChangeEventArgs, 77, "onchange", $.$mac.Microsoft.AspNetCore.Components.EventCallbackFactoryBinderExtensions.CreateBinder($.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory, this, new ($.$spc.System.Action$$($.$spc.System.String))().$ctor(this,  (/*__value*/ __value) =>
                {
                    return this.taskTitle = __value;
                }, {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1293735,"h":0,"f":1048578}), this.taskTitle, null));
                __builder.SetUpdatesAttributeName("value");
                __builder.AddAttribute(78, "b-eh7nwjtt9e");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(79, "\n\n                ");
                __builder.OpenElement(80, "div");
                __builder.AddAttribute$2(81, "class", "input-container");
                __builder.AddAttribute(82, "b-eh7nwjtt9e");
                __builder.AddMarkupContent(83, "<label for=\"title\" b-eh7nwjtt9e>Priority:</label>\n                    ");
                __builder.OpenElement(84, "select");
                __builder.AddAttribute$2(85, "name", "Priority");
                __builder.AddAttribute$2(86, "id", "");
                __builder.AddAttribute$2(87, "style", "padding: 13px; border: none; background: rgb(255, 166, 0, 0.2); width: 100%; border-radius: 10px;");
                __builder.AddAttribute$6(88, "value", $.$mac.Microsoft.AspNetCore.Components.BindConverter.FormatValue$31($.$m.Priority, this.taskPriority, null));
                __builder.AddAttribute$5($.$mac.Microsoft.AspNetCore.Components.ChangeEventArgs, 89, "onchange", $.$mac.Microsoft.AspNetCore.Components.EventCallbackFactoryBinderExtensions.CreateBinder$62($.$m.Priority, $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory, this, new ($.$spc.System.Action$$($.$m.Priority))().$ctor(this,  (/*__value*/ __value) =>
                {
                    return this.taskPriority = __value;
                }, {"r":65537,"p":[{"n":"__value","p":1949095}],"n":"","d":1293735,"h":0,"f":1048578}), this.taskPriority, null));
                __builder.SetUpdatesAttributeName("value");
                __builder.AddAttribute(90, "b-eh7nwjtt9e");
                /*var*/ let values = $.$spc.System.Enum.GetValues($.$m.Priority);
                let $i1 = 0;
                let $arr1 = values;
                while ($i1 < $arr1.length)
                {
                    let value = $arr1[$i1++];
                    __builder.OpenElement(91, "option");
                    __builder.AddAttribute$6(92, "value", $.$box(value, $.$m.Priority));
                    __builder.AddAttribute(93, "b-eh7nwjtt9e");
                    if (value === 1/*Priority.Low*/)
                    {
                        __builder.AddMarkupContent(94, "\uD83D\uDD34");
                    }
                    else if (value === 2/*Priority.Medium*/)
                    {
                        __builder.AddMarkupContent(95, "\uD83D\uDFE1");
                    }
                    else if (value === 3/*Priority.High*/)
                    {
                        __builder.AddMarkupContent(96, "\uD83D\uDFE2");
                    }
                    __builder.AddContent(97, $.$spc.System.Enum.ToStringT($.$m.Priority, $.$spc.System.UInt32, value));
                    __builder.CloseElement();
                }
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(98, "\n\n            ");
                __builder.OpenElement(99, "div");
                __builder.AddAttribute$2(100, "style", "display: flex; flex-wrap: wrap; gap: 10px; margin-bottom: 50px;");
                __builder.AddAttribute(101, "b-eh7nwjtt9e");
                __builder.OpenComponent($.$m.miniapp.Components.ButtonCard, 102);
                __builder.AddComponentParameter(103, "BgColor", "rgb(140, 0, 140, 0.3)");
                __builder.AddComponentParameter(104, "BtnText", "\u2795 AddTask");
                __builder.AddComponentParameter(105, "OnClick", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$mac.Microsoft.AspNetCore.Components.EventCallback, $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$3(this, new ($.$spc.System.Func$$($.$spc.System.Threading.Tasks.Task))().$ctor(this, this.AddTask))));
                __builder.CloseComponent();
                __builder.AddMarkupContent(106, "\n                ");
                __builder.OpenComponent($.$m.miniapp.Components.ButtonCard, 107);
                __builder.AddComponentParameter(108, "BgColor", "rgb(126, 126, 126, 0.3)");
                __builder.AddComponentParameter(109, "BtnText", "Move Completed Task \u27A1");
                __builder.AddComponentParameter(110, "OnClick", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$mac.Microsoft.AspNetCore.Components.EventCallback, $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$3(this, new ($.$spc.System.Func$$($.$spc.System.Threading.Tasks.Task))().$ctor(this, this.MoveCompletedTask))));
                __builder.CloseComponent();
                __builder.CloseElement();
                __builder.AddMarkupContent(111, "\n\n            <hr b-eh7nwjtt9e>");
                if (!this.Auth.IsLoggedIn)
                {
                    __builder.OpenComponent($.$m.miniapp.Components.NotLoginCard, 112);
                    __builder.AddComponentParameter(113, "Title", "User not logged in...");
                    __builder.AddComponentParameter(114, "SubTitle", "Click to log in...");
                    __builder.CloseComponent();
                }
                else 
                {
                    __builder.OpenElement(115, "div");
                    __builder.AddAttribute$2(116, "style", "display: flex; flex-wrap: wrap; justify-content: space-between; padding-top: 10px;");
                    __builder.AddAttribute(117, "b-eh7nwjtt9e");
                    __builder.AddMarkupContent(118, "<h4 b-eh7nwjtt9e>\uD83D\uDCC1 Available Task</h4>");
                    if (this.confirmClear)
                    {
                        __builder.OpenElement(119, "div");
                        __builder.AddAttribute$2(120, "style", "display: flex; gap:10px;");
                        __builder.AddAttribute(121, "b-eh7nwjtt9e");
                        __builder.OpenComponent($.$m.miniapp.Components.ButtonCard, 122);
                        __builder.AddComponentParameter(123, "BgColor", "rgb(140, 0, 140, 0.3)");
                        __builder.AddComponentParameter(124, "BtnText", "\u2705 Clear");
                        __builder.AddComponentParameter(125, "OnClick", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$mac.Microsoft.AspNetCore.Components.EventCallback, $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$3(this, new ($.$spc.System.Func$$($.$spc.System.Threading.Tasks.Task))().$ctor(this, this.ClearTask))));
                        __builder.CloseComponent();
                        __builder.AddMarkupContent(126, "\n                            ");
                        __builder.OpenComponent($.$m.miniapp.Components.ButtonCard, 127);
                        __builder.AddComponentParameter(128, "BgColor", "rgb(126, 126, 126, 0.3)");
                        __builder.AddComponentParameter(129, "BtnText", "\u274C Cancel");
                        __builder.AddComponentParameter(130, "OnClick", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$mac.Microsoft.AspNetCore.Components.EventCallback, $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$1(this, new $.$spc.System.Action().$ctor(this,  () =>
                        {
                            return this.confirmClear = false;
                        }, {"r":65537,"n":"","d":1293735,"h":0,"f":1048578}))));
                        __builder.CloseComponent();
                        __builder.CloseElement();
                    }
                    else 
                    {
                        __builder.OpenComponent($.$m.miniapp.Components.ButtonCard, 131);
                        __builder.AddComponentParameter(132, "BgColor", "rgb(140, 0, 140, 0.3)");
                        __builder.AddComponentParameter(133, "BtnText", "\uD83E\uDDF9 Clear All Tasks");
                        __builder.AddComponentParameter(134, "OnClick", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$mac.Microsoft.AspNetCore.Components.EventCallback, $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$1(this, new $.$spc.System.Action().$ctor(this,  () =>
                        {
                            return this.confirmClear = true;
                        }, {"r":65537,"n":"","d":1293735,"h":0,"f":1048578}))));
                        __builder.CloseComponent();
                    }
                    __builder.CloseElement();
                    if ($.$sl.System.Linq.Enumerable.Any($.$m.AppTask, this.tasks))
                    {
                        if (this.isLoading)
                        {
                            __builder.OpenComponent($.$m.miniapp.Components.LoadingCardMinor, 135);
                            __builder.AddComponentParameter(136, "LoadingState", "\u23F3 Loading Available Tasks...");
                            __builder.CloseComponent();
                        }
                        else 
                        {
                            __builder.OpenElement(137, "div");
                            __builder.AddAttribute$2(138, "style", "background: rgba(228, 228, 228, 0.1);");
                            __builder.AddAttribute(139, "b-eh7nwjtt9e");
                            __builder.OpenElement(140, "ul");
                            __builder.AddAttribute$2(141, "style", "margin: 20px 0px 40px;");
                            __builder.AddAttribute(142, "b-eh7nwjtt9e");
                            var $en5 = this.filteredtasks.GetEnumerator();
                            while ($en5.MoveNext())
                            {
                                var task = $en5.Current;
                                {
                                    if (task.IsComplete)
                                    {
                                        __builder.OpenElement(143, "li");
                                        __builder.AddAttribute$2(144, "style", "margin: 10px 0; padding: 7px; list-style: none; border-left: 3px solid purple; text-decoration: line-through; background: rgb(129, 129, 129, 0.1);");
                                        __builder.AddAttribute(145, "b-eh7nwjtt9e");
                                        __builder.OpenComponent($.$m.miniapp.Components.TaskCard, 146);
                                        __builder.AddComponentParameter(147, "Task", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$m.AppTask, task));
                                        __builder.AddComponentParameter(148, "OnToggle", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$mac.Microsoft.AspNetCore.Components.EventCallback$$($.$spc.System.Int32), $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$8($.$spc.System.Int32, this, new ($.$spc.System.Action$$($.$spc.System.Int32))().$ctor(this, this.ToggleTask))));
                                        __builder.AddComponentParameter(149, "OnDelete", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$mac.Microsoft.AspNetCore.Components.EventCallback$$($.$spc.System.Int32), $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$10($.$spc.System.Int32, this, new ($.$spc.System.Func$$$($.$spc.System.Int32, $.$spc.System.Threading.Tasks.Task))().$ctor(this, this.DeleteTask))));
                                        __builder.AddComponentParameter(150, "TaskIdToDelete", $.$box($.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$typeNullable($.$spc.System.Int32), this.Taskss.Id), $.$spc.System.Nullable$$($.$spc.System.Int32)));
                                        __builder.CloseComponent();
                                        __builder.CloseElement();
                                    }
                                    else 
                                    {
                                        __builder.OpenElement(151, "li");
                                        __builder.AddAttribute$2(152, "style", "margin: 10px 0; padding: 7px; list-style: none; border-left: 3px solid purple; background: rgb(129, 129, 129, 0.1);");
                                        __builder.AddAttribute(153, "b-eh7nwjtt9e");
                                        __builder.OpenComponent($.$m.miniapp.Components.TaskCard, 154);
                                        __builder.AddComponentParameter(155, "Task", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$m.AppTask, task));
                                        __builder.AddComponentParameter(156, "OnToggle", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$mac.Microsoft.AspNetCore.Components.EventCallback$$($.$spc.System.Int32), $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$8($.$spc.System.Int32, this, new ($.$spc.System.Action$$($.$spc.System.Int32))().$ctor(this, this.ToggleTask))));
                                        __builder.AddComponentParameter(157, "OnDelete", $.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$mac.Microsoft.AspNetCore.Components.EventCallback$$($.$spc.System.Int32), $.$mac.Microsoft.AspNetCore.Components.EventCallback.Factory.Create$10($.$spc.System.Int32, this, new ($.$spc.System.Func$$$($.$spc.System.Int32, $.$spc.System.Threading.Tasks.Task))().$ctor(this, this.DeleteTask))));
                                        __builder.AddComponentParameter(158, "TaskIdToDelete", $.$box($.$mac.Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck($.$typeNullable($.$spc.System.Int32), this.Taskss.Id), $.$spc.System.Nullable$$($.$spc.System.Int32)));
                                        __builder.CloseComponent();
                                        __builder.CloseElement();
                                    }
                                }
                            }
                            __builder.CloseElement();
                            __builder.CloseElement();
                        }
                    }
                    else 
                    {
                        if (!this.isLoading)
                        {
                            __builder.AddMarkupContent(159, "<div style=\"display: flex; width: 100%; height: 100%; background: rgb(137, 137, 137, 0.1); margin: 20px 0 30px; height: 50vh; align-items: center; justify-content: center;\" b-eh7nwjtt9e><b b-eh7nwjtt9e>\uD83D\uDCC1 No tasks added.</b></div>");
                        }
                        else 
                        {
                            __builder.OpenElement(160, "div");
                            __builder.AddAttribute$2(161, "style", "margin-bottom: 60px;");
                            __builder.AddAttribute(162, "b-eh7nwjtt9e");
                            __builder.OpenComponent($.$m.miniapp.Components.LoadingCardMinor, 163);
                            __builder.AddComponentParameter(164, "LoadingState", "\u23F3 Loading Available Tasks...");
                            __builder.CloseComponent();
                            __builder.CloseElement();
                        }
                    }
                    __builder.AddMarkupContent(165, "<hr b-eh7nwjtt9e>");
                }
            }
            /*string*/ taskTitle = null;
            /*bool*/ isLoading = false;
            /*Priority*/ taskPriority = 0;
            /*string */ get trimmedTaskTitle()
            {
                return $.$spc.System.String.ToUpper.call($.$spc.System.String.Trim.call(this.taskTitle));
            }
            /*List<AppTask>*/ tasks = null;
            /*List<AppTask>*/ completedTasks = null;
            /*bool*/ confirmClear = false;
            /*AppTask*/ Taskss = null;
            /*string*/ currentFilter = null;
            /*List<AppTask> */ get filteredtasks()
            {
                return this.GetFilteredTasks();
            }
            /*List<AppTask> */ GetFilteredTasks()
            {
                /*var*/ let allTasks = this.TaskService.ITaskService$GetAll() ?? new ($.$spc.System.Collections.Generic.List$$($.$m.AppTask))().$ctor$1();
                return (() =>
                {
                    if (this.currentFilter === "Pending")
                    {
                        return $.$sl.System.Linq.Enumerable.ToList($.$m.AppTask, $.$sl.System.Linq.Enumerable.Where($.$m.AppTask, allTasks, new ($.$spc.System.Func$$$($.$m.AppTask, $.$spc.System.Boolean))().$ctor(this,  (/*t*/ t) =>
                        {
                            return !t.IsComplete;
                        }, {"r":262145,"p":[{"n":"t","p":114087}],"n":"","d":1293735,"h":0,"f":1048578})));
                    }
                    if (this.currentFilter === "Done")
                    {
                        return $.$sl.System.Linq.Enumerable.ToList($.$m.AppTask, $.$sl.System.Linq.Enumerable.Where($.$m.AppTask, allTasks, new ($.$spc.System.Func$$$($.$m.AppTask, $.$spc.System.Boolean))().$ctor(this,  (/*t*/ t) =>
                        {
                            return t.IsComplete;
                        }, {"r":262145,"p":[{"n":"t","p":114087}],"n":"","d":1293735,"h":0,"f":1048578})));
                    }
                    return allTasks;
                })();
            }
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    this.isLoading = true;
                    await $.$spc.System.Threading.Tasks.Task.Delay$4(3000);
                    this.TaskService.ITaskService$add_OnChange(new $.$spc.System.Action().$ctor(this, this.HandleStateChanged));
                    this.isLoading = false;
                });
            }
            /*Task *//*async*/  OnAfterRenderAsync(/*bool*/ firstRender)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    if (firstRender)
                    {
                        await this.TaskService.ITaskService$LoadTasks();
                    }
                });
            }
            /*void */ OnInitialized()
            {
                this.TaskService.ITaskService$add_OnChange(new $.$spc.System.Action().$ctor(this, this.HandleStateChanged));
                this.RefreshTasks();
            }
            /*Task *//*async*/  AddTask()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    if ($.$spc.System.String.IsNullOrEmpty(this.taskTitle) || this.taskPriority === 0/*Priority.Select_Priority*/)
                    {
                        return;
                    }
                    this.TaskService.ITaskService$Add(this.trimmedTaskTitle, this.taskPriority);
                    this.taskTitle = "";
                    this.taskPriority = 0/*Priority.Select_Priority*/;
                    this.RefreshTasks();
                    if (this.Auth.IsLoggedIn)
                    {
                        await this.SaveTask();
                    }
                });
            }
            /*Task *//*async*/  MoveCompletedTask()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    this.TaskService.ITaskService$MoveTask(this.trimmedTaskTitle, this.taskPriority);
                    this.RefreshTasks();
                    if (this.Auth.IsLoggedIn)
                    {
                        await this.SaveTask();
                    }
                });
            }
            /*void */ AllTasks()
            {
                this.currentFilter = "All";
            }
            /*void */ Pending()
            {
                this.currentFilter = "Pending";
            }
            /*void */ Completed()
            {
                this.currentFilter = "Done";
            }
            /*void */ ToggleTask(/*int*/ id)
            {
                this.TaskService.ITaskService$ToggleCompleted(id);
            }
            /*Task *//*async*/  DeleteTask(/*int*/ id)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    this.TaskService.ITaskService$Delete(id);
                    if (this.Auth.IsLoggedIn)
                    {
                        await this.SaveTask();
                    }
                });
            }
            /*Task *//*async*/  ClearTask()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    this.TaskService.ITaskService$ClearAllTask();
                    this.confirmClear = false;
                    if (this.Auth.IsLoggedIn)
                    {
                        await this.SaveTask();
                    }
                });
            }
            /*Task *//*async*/  SaveTask()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    await this.TaskService.ITaskService$SaveTask();
                });
            }
            /*void */ RefreshTasks()
            {
                this.tasks = this.TaskService.ITaskService$GetAll();
                this.StateHasChanged();
            }
            /*void */ HandleStateChanged()
            {
                this.RefreshTasks();
                this.InvokeAsync(new $.$spc.System.Action().$ctor(this, this.StateHasChanged));
            }
            /*void */ Dispose()
            {
                this.TaskService.ITaskService$remove_OnChange(new $.$spc.System.Action().$ctor(this, this.HandleStateChanged));
            }
            /*IJSRuntime*/ JS = null;
            /*NavigationManager*/ Nav = null;
            /*ITaskService*/ TaskService = null;
            /*miniapp.Services.AuthService*/ Auth = null;
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.taskTitle = "";
                this.isLoading = false;
                this.tasks = new ($.$spc.System.Collections.Generic.List$$($.$m.AppTask))().$ctor$1();
                this.completedTasks = new ($.$spc.System.Collections.Generic.List$$($.$m.AppTask))().$ctor$1();
                this.Taskss = new $.$m.AppTask().$ctor$1();
                this.currentFilter = "All";
                this.JS = null;
                this.Nav = null;
                this.TaskService = null;
                this.Auth = null;
            }
            static $h = 1293735;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245192,"p":[{"p":262145,"g":{"r":0,"d":0,"h":21476130215,"f":2},"s":{"r":0,"d":0,"h":25771097511,"f":2},"n":"isLoading","d":1293735,"h":17181162919,"f":2},{"p":1310721,"g":{"r":0,"d":0,"h":38655999399,"f":2},"n":"trimmedTaskTitle","d":1293735,"h":34361032103,"f":2},{"p":$.$spc.System.Collections.Generic.List$$($.$m.AppTask).$h,"g":{"r":0,"d":0,"h":68720770471,"f":1},"n":"filteredtasks","d":1293735,"h":64425803175,"f":1},{"p":524318,"g":{"r":0,"d":0,"h":150325149095,"f":2},"s":{"r":0,"d":0,"h":154620116391,"f":2},"n":"JS","d":1293735,"h":146030181799,"f":2,"a":[{"t":4259848,"c":21479096328}]},{"p":4980744,"g":{"r":0,"d":0,"h":167505018279,"f":2},"s":{"r":0,"d":0,"h":171799985575,"f":2},"n":"Nav","d":1293735,"h":163210050983,"f":2,"a":[{"t":4259848,"c":21479096328}]},{"p":179623,"g":{"r":0,"d":0,"h":184684887463,"f":2},"s":{"r":0,"d":0,"h":188979854759,"f":2},"n":"TaskService","d":1293735,"h":180389920167,"f":2,"a":[{"t":4259848,"c":21479096328}]},{"p":1883559,"g":{"r":0,"d":0,"h":201864756647,"f":2},"s":{"r":0,"d":0,"h":206159723943,"f":2},"n":"Auth","d":1293735,"h":197569789351,"f":2,"a":[{"t":4259848,"c":21479096328}]}],"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","d":1293735,"h":4296261031,"f":32772},{"r":$.$spc.System.Collections.Generic.List$$($.$m.AppTask).$h,"n":"GetFilteredTasks","d":1293735,"h":73015737767,"f":2},{"r":133300225,"n":"OnInitializedAsync","d":1293735,"h":77310705063,"f":36868},{"r":133300225,"p":[{"n":"firstRender","p":262145}],"n":"OnAfterRenderAsync","d":1293735,"h":81605672359,"f":36868},{"r":65537,"n":"OnInitialized","d":1293735,"h":85900639655,"f":32772},{"r":133300225,"n":"AddTask","d":1293735,"h":90195606951,"f":4098},{"r":133300225,"n":"MoveCompletedTask","d":1293735,"h":94490574247,"f":4098},{"r":65537,"n":"AllTasks","d":1293735,"h":98785541543,"f":2},{"r":65537,"n":"Pending","d":1293735,"h":103080508839,"f":2},{"r":65537,"n":"Completed","d":1293735,"h":107375476135,"f":2},{"r":65537,"p":[{"n":"id","p":655361}],"n":"ToggleTask","d":1293735,"h":111670443431,"f":2},{"r":133300225,"p":[{"n":"id","p":655361}],"n":"DeleteTask","d":1293735,"h":115965410727,"f":4098},{"r":133300225,"n":"ClearTask","d":1293735,"h":120260378023,"f":4098},{"r":133300225,"n":"SaveTask","d":1293735,"h":124555345319,"f":4098},{"r":65537,"n":"RefreshTasks","d":1293735,"h":128850312615,"f":2},{"r":65537,"n":"HandleStateChanged","d":1293735,"h":133145279911,"f":2},{"r":65537,"n":"Dispose","d":1293735,"h":137440247207,"f":1}],"l":[{"t":1310721,"n":"taskTitle","d":1293735,"h":8591228327,"f":2},{"t":1949095,"n":"taskPriority","d":1293735,"h":30066064807,"f":2},{"t":$.$spc.System.Collections.Generic.List$$($.$m.AppTask).$h,"n":"tasks","d":1293735,"h":42950966695,"f":1},{"t":$.$spc.System.Collections.Generic.List$$($.$m.AppTask).$h,"n":"completedTasks","d":1293735,"h":47245933991,"f":1},{"t":262145,"n":"confirmClear","d":1293735,"h":51540901287,"f":1},{"t":114087,"n":"Taskss","d":1293735,"h":55835868583,"f":2},{"t":1310721,"n":"currentFilter","d":1293735,"h":60130835879,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":1293735,"h":210454691239,"f":1}],"i":[2752520,3145736,3080200,57540609],"h":1293735,"a":[{"t":9895944,"c":4304863240,"a":[{"v":"/tasks","t":1310721}]}]}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.ComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender, $.$spc.System.IDisposable ]; }
            static get $fullName() { return `miniapp.Components.Pages.Tasks`; }
        });
        
        $asm.$cls("$m.miniapp.Layout.MainLayout", ($self) => class MainLayout extends $.$mac.Microsoft.AspNetCore.Components.LayoutComponentBase
        {
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$2(1, "class", "page");
                __builder.AddAttribute(2, "b-51e18s3qyg");
                __builder.OpenElement(3, "main");
                __builder.AddAttribute(4, "b-51e18s3qyg");
                __builder.OpenElement(5, "article");
                __builder.AddAttribute$2(6, "class", "content");
                __builder.AddAttribute$2(7, "style", "padding: 10px;");
                __builder.AddAttribute(8, "b-51e18s3qyg");
                __builder.AddContent$1(9, this.Body);
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(10, "\n\n");
                __builder.AddMarkupContent(11, "<div id=\"blazor-error-ui\" data-nosnippet b-51e18s3qyg>\n    An unhandled error has occurred.\n    <a href=\".\" class=\"reload\" b-51e18s3qyg>Reload</a>\n    <span class=\"dismiss\" b-51e18s3qyg>\uD83D\uDDD9</span></div>");
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                return this;
            }
            static $h = 1686951;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":4653064,"m":[{"r":65537,"p":[{"n":"__builder","p":7536648}],"n":"BuildRenderTree","d":1686951,"h":4296654247,"f":32772}],"c":[{"n":".ctor","o":"$ctor$3","d":1686951,"h":8591621543,"f":1}],"i":[2752520,3145736,3080200],"h":1686951}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.LayoutComponentBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IComponent, $.$mac.Microsoft.AspNetCore.Components.IHandleEvent, $.$mac.Microsoft.AspNetCore.Components.IHandleAfterRender ]; }
            static get $fullName() { return `miniapp.Layout.MainLayout`; }
        });
        
        $asm.$str("$m.Priority", ($self) => class Priority extends $.$spc.System.Enum
        {
            static Select_Priority = 0;
            static Low = 1;
            static Medium = 2;
            static High = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Select_Priority": 0n,
                    "Low": 1n,
                    "Medium": 2n,
                    "High": 3n
                };
            }
            static $h = 1949095;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1949095,"n":"Select_Priority","d":1949095,"h":4296916391,"f":33},{"t":1949095,"n":"Low","d":1949095,"h":8591883687,"f":33},{"t":1949095,"n":"Medium","d":1949095,"h":12886850983,"f":33},{"t":1949095,"n":"High","d":1949095,"h":17181818279,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1949095,"h":21476785575,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1949095}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `Priority`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.Extensions.Validation", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.Logging", "NetJs.Microsoft.JSInterop.WebAssembly", "NetJs.Microsoft.AspNetCore.Components.WebAssembly", "NetJs.Microsoft.CSharp", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument"))